SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7005bd975db83c67d3e2a3ec849146786071e73ccd91ff1ec83ba06f97b7f96',1980,'','','communications',5,'Railroads: 8,253 km standard gage (1.435 m); 143 km
double track; 72 km electrified
Highways: 60,000 km total; 21,000 km _ bituminous;
28,000 km gravel or crushed stone; 2,500 km improved
earth, 8,500 km unimproved earth
Inland waterways: approx. 1,689 km
253
Approved for Release: 2018/04/27 C06727041
Approved for Release: 2018/04/27 C06727041
“SECRET.
TURKEY}
January 1979
NR Record
Pipelines: 1,288 km crude oil; 2,055 km refined products
Ports: 10 major, 35 minor
Merchant marine: 162 ships (1,000 GRT or over) totaling
1,206,000 CRT, t,850,600 DWT; includes 14 passenger, 95
cargo, | liquefied gas, 22 tanker, 21 bulk, 7 specialized
carrier, 2. roll-on/roll-off cargo| |
Civil air: 24 major transport aircraft
Airfields: 120 total, 101 usable; 58 with permanent-sur-
face runways, 3 with runways over 3,660 m, 23 with
runways 2,440-3,659 m, 22 with runways 1,220-2.439 mn
Telecommunications: new trunk domestic radio-relay
net, good international service; 1.1 million telephones (2.7
per 100 popl.); 40 AM, 4 FM, and 36 TV stations; | coaxial
submarine cable; COMSAT. station near completion
DEFENSE FORCES
Military manpower: males 15-49, 9,786,000; 5,778,000 fit
for military service; about 430,000 reach military age (20)
annually
Personnel: 480,000 army, 45,400 navy, 53,000 air force
(970 pilots), 100,000 gendarmerie
Major ground units: 4 armies, 10 corps with corps troops,
15 infantry divisions, 2 mechanized divisions, 6 separate
armored brigades, 4 mechanized infantry brigades, 6
infantry brigades, 1 airborne brigade, 1 commando brigade,
3 mobile gendarmerie brigades, 2 regiments (1 infantry, !
armored), 33 battalions (22 artillery, 11 border); each field
army has | aviation regiment assigned und each corps has |
aviation hattalion
Shins: 12 destroyers, 2 Frigates, 13 submarines, 45 patrol
craft, 32 mine warfare, 5 amphibious ships, 74 amphibious
craft, 35 auxiliary, 55 service
Aircraft: 1,159 (464 jet); 647 (464 jet) in air force, 493 in
army aviation, 19 in naval air
Missiles: 8 SAM squadrons (Nike Hercules with 72
launchers)
Supply: mostly dependent on foreign sources, primarily
U.S.. Canada, and West Germany; manufactures some small
arms, trucks and adequate quantities of ammunition; builds
some of its naval ships including submarines with technical
and material assistance
Military budget: for fiscal year ending 28 February 1979,
$2.3 billion; about 20.7% of proposed central government
budget
INTELLIGENCE AND SECURITY
Turkish National Intelligence Organization (TNIO), in-
cluding Turkish National Security Service Directorate
(TNSS), domestic; Foreign Collection Directorate (FCD),
foreign; and Intelligence Directorate, Turkish General Staff
(J-2), domestic/foreign; Turkish National Police, domestic.
Ministry of Foreign Affairs, foreign; Gendarmerie, Intelli-
gence Section, domestic
NR Record
254
Approved for Release: 2018/04/27 C06727041','e15ab1be0a6b6ebcb9aae67d7ddc1e74018cab931be844b350fcf85746186f15','internet-archive','cia-readingroom-document-06727041','txt','e81594013193fd0f801a852bbb034b76c4bb95d6da2f549c5399458122a300ac','https://archive.org/download/cia-readingroom-document-06727041/06727041_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18e229b0d83dc21517138da5960cde7f684873ac2862f14896fd712c88b1e88d',1980,'','','communications',5,'Railroads: 4,991 mi.; 4,940 mi. 4''8 1/2" gage, 51 mi. double track: 45 mi.
electrified; 20 mi. 2''5 1/2" gage
Highways: 37,282 mi.; 13,049 mi. bituminous, 17,398 mi. grave? or crushed stone,
1,553 mi. improved earth, 5,282 mi. unimproved earth
Inland waterways: approx. 1,050 mi.
Pipelines: crude oi], 360 mi.; refined products, 1,340 mi.
Ports: 10 major, 35 minor
Merchant marine: 87 ships (1,000 GRT or over) totaling 594,900 GRT, 826,600 DWT;
includes 12 passenger, 52 cargo, 11 tanker, 10 bulk, 2 specialized carrier
Civil air: 22 major transport aircraft
Airfields: 123 total, 96 usable; 48 with permanent-surface runways; 3 with
runways over 12,000 ft., 19 with runways 8,000-11,999 ft., 22 with runways
4,000-7,999 ft.; 2 seaplane stations
Telecommunications: excellent international radiocommunication and fair domestic
telecommunication services; 654,500 telephones; 3.94 million radio and 133,000
TV receivers; 39 AM, 2 FM, and 7 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 9,707,000; 5,730,000 fit for military service;
about 402,000 reach military age (20) annual ly
78,000) ee navy 39,500, air force 54,600 (1,082 pilots), gendarmerie
75 ,000
Major ground units: 3 armies, 10 corps with corps troops, 13 infantry divisions,
2 mechanized divisions, 1 mechanized brigade, 1 armored division, 4 separate
armored brigades, 2 armored cavalry brigades, 4 infantry brigades, ] border
regiment, 34 battalions (22 artillery, 11 border, 1 on Cyprus), and 7
airborne/commando brigade; army aviation companies with about 5 aircraft
each are assigned to each army, corps, and division
Ships: 13 destroyers, 12 submarines, 71 patrol » 28 mine warfare, 60
amphibious craft, 40 auxiliary, 47 service
Aircraft: 1,252 including 437 (nonjet) in arny aviation, 15 (nonjet) in naval
air, 800 (605 jet) in air force
Missiles: 8 SAM squadrons (Nike Ajax/Hercules)
Supply: mostly dependent on foreign sources, primarily U.S., Canada, and West
Germany; manufactures some small arms, trucks and adequate quantities of
ammunition; builds some of its naval ships
448
““SECRE
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
_ SEsRET,
DEFENSE FORCES (cont''d):
Military budget: for fiscal year ending 28 February 1974, $792.8 million; about
16% of central government budget
INTELLIGENCE AND SECURITY:
National Intelligence Organization (MIT), including Turkish National Security
Service Directorate (TNSS), domestic/foreign; Turkish General Staff, J-2
Section, Intelligence Branch, domestic/foreign; Turkish National Polf
domestic; Ministry of Foreign Affairs, foreign; Gendarmerie, domestic
449
Approved for Release: 2018/04/27 C06727039','9d4a2b2fc51ea58b3df2ca018de5da87ff79463fa05f18e4af69d388d6b68cd4','internet-archive','cia-readingroom-document-06727039','txt','50b279e699039846ddd2e23926e0f2cdd54ecd6c38a877f833fb7055b1b66e05','https://archive.org/download/cia-readingroom-document-06727039/06727039_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03f598773fbc261a61ad8531f547323ad250f6cca070b6421c816c5862382c5e',1980,'','','communications',5,'Railroads: 4,991 mi.; 4,940 mi. 4''8 1/2" gage, 51 mi. double track; 45 mi.
electrified; 20 mi. 2''5 1/2" gage
Highways: 37,282 mi.; 13,049 mi. bituminous, 17,398 mi. gravel or crushed stone,
1,553 mi. improved earth, 5,282 mi. unimproved earth
Inland waterways: approx. 1,050 mi.
Pipelines: crude oi1, 360 mi.; refined products, 1,340 mi.
Ports: 10 major, 35 minor
Merchant marine: 87 ships (1,000 GRT or over) totaling 594,900 GRT, 826,600 DHT;
includes 12 passenger, 52 cargo, 11 tanker, 10 bulk, 2 specialized carrier
Civil air: 22 major transport aircraft
Airfields: 123 total, 96 usable; 48 with permanent-surface runways; 3 with
runways over 12,000 ft., 19 with runways 8,000-11,999 ft., 22 with runways
4 ,000-7 ,999 ft.; 2 seaplane stations
Teleconmunications: excellent international radiocommunication and fair domestic
telecommunication services; 654,500 telephones; 3.94 million radio and 133,000
TV receivers; 39 AM, 2 FM, and 7 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 9,707,000; 5,730,000 fit for military service;
about 402,000 reach military age (20) annually
Military budget: for fiscal year ending 28 February 1974, $792.8 million; about
16% of central government budget
346
Approved for Release: 2018/04/27 C06726998','3f12afb7679ed6d6fbd9995b63f1709fd9f751fa11e529d9e6974f040abec1d6','internet-archive','cia-readingroom-document-06726998','txt','4c23441e1d6b39306796a2156182709b40b2431f3362c61878fd34954840f079','https://archive.org/download/cia-readingroom-document-06726998/06726998_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5055dc650ab6358fe03006ff087a8fa0883a839241618db9bb2a06e8ca373842',1980,'UY','Uruguay','communications',7,'Railroads: 8,253 km standard gage (1.485 m); 143 km
double track; 72 km electrified
Highways: 60,000 km total; 21,000 km bituminous;
28,000 km gravel or crushed stone; 2,500 km improved
earth; 8,500 km unimproved earth
Inland waterways: approx. 1,689 km
Pipelines: 1,288 km crude oil; 2,055 km refined products
Ports: 10 major, 35 minor
Civil air; 24 major transport aircraft
Airfields: 120 total, 101 usable; 58 with permanent-sur-
face runways; 3 with runways over 3,660 m, 23 with
runways 2,440-3,659 m, 22 with runways 1,220-2,439 m
Telecommunications; new trunk domestic radio-relay
net, good international service; 1.1 million: telephones (2.7
per 100 popl.); 40 AM, 4 FM, and 36 TV stations; 1 coaxial
submarine cable; COMSAT station near completion
DEFENSE FORCES
Military manpower: males 15-49, 9,786,000; 5,778,000 fit
for military service; about 430,000 reach military age (20)
annually
Military budget: for fiscal year ending 28 February 1979,
$2.3 billion; about 20.7% of proposed central government
budget','7e816193155ad479397a55a2b2a1a5d3043b02aefe57e7e22dc1c730b59a35e1','internet-archive','cia-readingroom-document-06727040','txt','2d6152abbd8ec4ecabcf280ee87d020d3ddbe838dc10755087362c3afd85b71a','https://archive.org/download/cia-readingroom-document-06727040/06727040_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('021eaecf0e6f720fc04bf273971df62316eaf8773c891923021867927e21795c',1980,'TV','Tuvalu','communications',8,'(formerly Ellice Islands)
NOTE: On October 1, 1975, by Constitutional Order, the
Ellice Islands were formally separated from the British
colony of Gilbert and Ellice Islands, thus forming the new
Pacific Ocean.
5 OBERT =
{ISLANDS °.°7.’
(Sas referesce map Vis)
colony of Tuvalu. The remaining islands in the former
Gilbert and Ellice Islands Colony were renamed the Gilbert
Islands.
The new colony of Tuvalu includes the islands of
Nanumanga, Nanumea, Nui, Niutao, Vaitupu, and those
islands claimed by the United States: Funafuti, Nukufetau,
Nukulailai, and Nurakita.
LAND
26 km*
WATER
Limits of territorial waters: 3 nm
Coastline: about 24 km
Railroads: none
Highways: 8 km gravel
Inland waterways: none
Ports: 1 minor
Civil air: no major transport aircraft
211
Approved for Release: 2018/04/27 C06727040
teeta ey pied ater ee age','c6e4b7d483ed178badad0a15adba5ca0f06843585a1f60549b57d2f2cf1e95b2','internet-archive','cia-readingroom-document-06727040','txt','2d6152abbd8ec4ecabcf280ee87d020d3ddbe838dc10755087362c3afd85b71a','https://archive.org/download/cia-readingroom-document-06727040/06727040_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f02ff2ac1e7daf4de1c4fc6b5354dd30f8edaad62e99d52fd52abac6b9d3ce82',1980,'AF','Afghanistan','communications',8,'Railroads: 0.6 km (single track) - 1.524-meter gage,
government-owned spur of Soviet line
Highways: 20,885 km total (1975); 2,460 km paved, 3,910
km gravel, 8,735 km improved earth, and 5,780 km
unimproved earth
Inland waterways: total navigability 1,200 km; steamers
use Amu Darya
Ports: only minor river ports
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
AFGHANISTAN/ ALBANIA
Civil air: 6 major transport aircraft
Airfields: 36 total, 35 usable; 9 with permanent-surface
runways; 6 with runways 2,440-3,659 m, 1] with runways
],220-2,489 m
Telecommunications: limited telephone, telegraph, and
radiobroadcast services; television to be introduced by 1979;
35,000 telephones (0.2 per 100 popl.); 2 AM, no FM, no TV
stations
DEFENSE FORCES
Military manpower: males 15-49, about 4.1 million; 2.2
million fit for military service; about 162,000 reach military
age (22) annually
Supply: dependent on foreign sources, almost exclusively
the USSR. ~
Military budget: estimated expenditures for fiscal year
ending 31 March 1978, about $60.7 million; approximately
8.3% of central government budget
fran
Esfahan®
Al Basrah,''
wai Pais
suman Shiraz
(Bandar ‘Abbas
Riyadh,
ited Arab
Emirates','4624498f55c9525a38c031b6c387da35000740e4bbec0f631493990b3a6ccfc5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a988615c86a72304dc7bad0fc5fa8b4d071840354c4f8806a226e19b8785338',1980,'RO','Romania','communications',9,'i
Railroads: 13,186 km total; 12,881 km standard gage
(1.435 m), 112 km broad gage (1.524 m), 193 km narrow
gage (0.750 m and 0.760 m); 2,807 km double ‘track; 2,718
km electrified; government-owned (1977)
Highways: 73,677 km total;-60,157 km concrete, asphalt,
stone block; 13,520 km gravel, crushed stone (1976)
Inland waterways: 483 km (1977)
Pipelines: crude oil, 1,448 km; refined products, 861 km;
natural gas, 5,601 km
Freight carried: rail—274.3 million metric tons, .71.6
billion metric ton/km (1977);. highway—1,049.7 million
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
a ae
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
CZECHOSLOVAKIA/DENMARK
metric tons, 16.7 billion metric ton/km (1977); waterway—
6.8 million metric tons, 3.5 billion metric ton/km (excl. int’l.
transit traffic) in approximately 766 waterway craft with
454,370 metric ton capacity (1978)
Ports: no maritime ports; outlets are Gdynia, Gdansk, and
Szezecin in Poland; Rijeka and Koper in Yugoslavia;
Hamburg, FRG; Rostock, GDR; principal river ports are
Prague, Melnik, Usti nad ‘Labem, Decin, Komarno, Bra-
tislava (1977) é
DEFENSE FORCES
Military budget: announced for fiscal year ending 31
December 1978, est. 19.5 billion crowns, about 7.1% of total
budget
DEFENSE FORCES
Military manpower: males 15-49, 2,650,000; 2,314,000 fit
for military service; about 70,000 reach military age (18)
annually
Military budget: announced’ for fiscal year ending 31
December 1978, est. 14.4 billion forints; about 3.7% of total
budget
i a ROMANIA!
Bucharest ~“%
YUGOSLAVIA x
(See reference mop 1V)
LAND
237,503 km?*; 44% arable, 19% other agriculture, 27%
forested, 10% other
Land boundary: 2,969 km
WATER
Limits of territorial waters (claimed): 12 nm
173
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
fi ROMANIA
Coastline: 225 km
Railroads: 12,080 km total; 10,467 km standard gage
(1.435 m), 1,600 km narrow gage, 13 km broad gage; 1,407
km electrified, 2,040 km double track; government owned
(1976) .
Highways: 77,768 km total; 13,470 km concrete, asphalt,
stone block; 14,412 km asphalt treated, gravel, crushed stone;
49,886 km earth (1976)
Inland waterways: 1,660 km (1978)
Pipelines: 2,735 km crude oil; 1,429 km refined products;
5,149 km natural gas
Freight carried: rail—238.0 million metric tons, 67.6
billion metric ton/km (1976); highway—442.2 million
metric tons, 9.9 billion metric ton/km (1976); waterway—
7.9 million metric tons, 2.1 billion metric ton/km in
approximately 515 waterway craft, with 493,750 metric ton
capacity (1977)
Ports: 5 major (Constanta, Galati, Braila, Mangalia,
Tulcea), 1 minor; principal inland waterway ports are
Giurgiu, Turnu Severin, and Orsova (1978)
DEFENSE FORCES
Military budget (announced): for fiscal year ending 31
December 1978, 12.0 billion lei; about 3.8% of total budget
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Paar Re ee AAO AL AA nd A
RAR AAA RAR RA A mA A
ee ee eT ee: ee ee ee ee ee ee ee ee a
et ee.
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Bucharest Black
Belgrade, * ck Sea
Yugoslavia
Marseill&\\—
° , Ankara ,.
Madrid 2 - Corsica '' a
Barcelona ; \\ 5
N a
Turkey
Spain q
4 oO
. 2 f
© Balearic Is. 4
Gibraltar Algiers : —~ Saat
wn) ions ;
italta
valletla Mediterranean
Sardinia','e91b6b14448945df909409bd26fda9bb3974762e62833e026334e49e02caaab4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee211421c06363a2f2df7902c30a88af438ccdbb8efaf2249423a4e2f9efa28f',1980,'BG','Bulgaria','communications',10,'Li
a
)
0
red
Mediterranean Sea
(See reference map (V}
LAND
28,749 km?; 19% arable, 24% other agricultural, 43%
forested, 14% other
Land boundaries: 716 km
WATER
Limits of territorial waters (claimed): 15 nm
Coastline: 418 km (including Sazan Island)
Railroads: 277 km-standard gage (1.435 m), single track,
government-owned (1975)
Highways: 4,989 km total; 1,287 km paved, 1,609 km
crushed stone and/or gravel, 2,093 km improved or
unimproved earth (1975) ;
Inland waterways: 43 km plus Albanian sections of Lake
Scutari, Lake Ohrid, and Lake Prespa (1977)
Freight carried: rail—2.8 million metric tons, 180 million
metric ton/km (1971); highways—39 million metric tons,
900 million metric ton/km (1971).
Ports: 1 major (Durres), 8 minor (1977)
Pipelines: crude oil, 117 km; refined products, 65 km;
natural gas, 64 km ;
Civil air: no civil airline
DEFENSE FORCES
Military budget (announced): for fiscal year ending 31
December 1978, 824 million leks; 10.7% of total budget
LAND
111,852 km?; 41% arable, 11% other agricultural, 33%
forested, 15% other
Land boundaries: 1,883 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 354 km
Railroads: 4,314 km total; about 4,069 km standard gage
27
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
BULGARIA/BURMA
(1.435 m), 245 km narrow gage; 299 km double track; 1,446
km electrified; government-owned (1976)
Highways: 31,454 km total; 6,683 km concrete, asphalt,
stone block; 6,088 km asphalt treated, gravel, crushed stone;
18,683 km earth (1976)
Inland waterways: 471 km (1978) ;
Freight carried: rail—75.2 million metric tons, 17.1
billion metric ton/km (1977); highway—319 million metric
tons, 6.7 billion metric ton/km (1977); waterway—4.6
million metric tons, 2.5 billion metric ton/km (excl. int''l.
transit traffic) (1977); approximately 214 waterway craft
with 227,000 metric ton capacity (1976)
Ports: 3 major (Varna, Varna West, Burgas), 4 minor
(1977); principal river ports are Ruse and Lom (1978)
BURMA
Rangoon
Bay p
of Bengal
(See reference map Vii}
LAND
678,600 km?; 28% arable, of which 12% is cultivated, 62%
forest, 10% urban and other (1969)
Land boundaries: 5,850 km
WATER
Limits of territorial waters (claimed): 200 nm (200 nm
exclusive economic zone)
Coastline: 3,060 km
Railroads: 3,285 km total; 3,172 km meter gage (1.00 m),
113 km narrow-gage industrial lines; 328 km double track;
government-owned
Highways: 27,000 km total; 3,200 km bituminous, 17,700
km improved earth, gravel, 6,100 km unimproved earth
Inland waterways: 12,800 km; 3,200 km navigable by
large commercial vessels
Ports: 4 major, 6 minor
Civil air: about 20 major transport aircraft
Airfields: 80 total, 78 usable; 23 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 39 with runways
1,220-2,489 m
Telecommunications: provide minimum requirements
for local and intercity service; international service is poor;
radiobroadcast coverage is limited to the most populous
areas; 31,400 telephones (0.1 per 100 popl.); 1 AM, 1 FM,
and no TV stations; one ground satellite station U/C
DEFENSE FORCES
Military manpower: eligible 15-49, 7,309,000; 3,899,000
fit for military service; about 336,000 males and 330,000
females reach military age (18) annually; both are liable for
military service
Military budget: (announced) for fiscal year ending 31
March 1978; $148.9 million, 5% of central government
budget','d0bc025a4f1051957eed5d9d281f277a925daf7bee2ac0c92e8ff5002104ccc9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9019c97edfa199f54d1ec548f109d217c096ffd0cc49159e63735bc0b788fc67',1980,'DZ','Algeria','communications',14,'Atlantic
* o
Meditorra, een
(See reference map V}
LAND ;
2,460,500 km?; 3% cultivated, 16% pasture and meadows,
1% forested, 80% desert, waste, or urban
Land boundaries: 6,260 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 1,183 km
Railroads: 3,950 km total; 2,690 km standard gage (1.435
m), 1,140 km 1.055-meter gage, 120 km meter gage (1.000
m); 302 km electrified; 198 km double track
Highways: 78,410 km total; 45,070 km concrete or
bituminous, 33,340 km. gravel, crushed stone, unimproved
earth
Ports: 9 major, 8 minor
Pipelines: crude oil, 3,983 km; refined products, 298 km;
natural gas, 2,398 km
Civil air: 43 major transport aircraft
Airfields: 183 total, 170 usable; 55 with permanent-sur-
face runways; 22 with runways 2,440-3,659 m; 89 with
runways 1,220-2,439 m; 3 seaplane stations
Telecommunications: adequate domestic and interna-
tional service in the north; sparse in the south; Atlantic
Ocean satellite station plus domestic satellite system with 14
stations; 266,000 telephones (1.5 per 100 popl.); 18 AM and
40 TV stations; 5 submarine cables
DEFENSE FORCES .
Military manpower: males 15-49, 3,740,000; 2,233,000 fit
for military service; average number reaching military age
(19) annually 192,000
Military budget: for fiscal year ending 31 December
1978, $385 million; 5.7% ‘of national budget
Railroads: none
Highways: 56 km, mostly paved
Ports: 1 major (Gibraltar) *
Civil air: 1 major transport aircraft (leased in)
Airfields: 1 permanent-surface runway, 1,220-2,439 m; 1
seaplane station
Telecommunications: international radiocommunication
facilities; automatic telephone system serving 8,100 tele-
phones (27.1 per 100 popl.); 1 AM, 1 FM, and 2 TV stations
DEFENSE FORCES
Military manpower: males 15-49, about 8,000; about
4,000 fit for military service
Defense is responsibility of United Kingdom
GILBERT ISLANDS
’ NOTE: On October 1, 1975, by Constitutional Order, the
Ellice Islands were formally separated from the British
colony of Gilbert and Ellice Islands, thus forming the new
colony of Tuvalu. The remaining islands in the former
Gilbert and Ellice Islands Colony were renamed the Gilbert
Islands.
77
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
GILBERT ISLANDS/GREECE
united .
a STATES
Pacific Ocean
GILBERT
- ISLANDS
“tS: TUVALU
o \\
Boundary ‘epreseniation is
not necessanty authoritative
503984 1-79
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
U.S. S.R.
Tuapse
Black Sea
yw Ankara
Turkey
Adana
Cyprus +Aleppo
*Nicosia
Lebano:
Syria
Mediterranean Sea
§. Damascu
i Vi o
sta 4
in,
ae, Gyre
fJordan
Alexan
Jiddah
Port Sudan,| Red :
* Khartoum','123c01ed50c0fb29d238c43ed356047962ebcc5e6911ba13e6e0a7265db5f130','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcaf0cf02c29e15582a21426cbf22f34e35dca489a9376fea4c17233523b5326',1980,'AD','Andorra','communications',18,'Atlantic
Ocean
Mediterranean
Sea
(See reference map tV}
LAND
466 km?
Land boundaries: 105 km
Railroads: none
Highways: about 96 km
Civil air: no major transport aircraft
Airfields: none
Telecommunications: international circuits to Spain and
France; 2 AM stations, 1 FM, 1 TV station; about 3,900
telephones (14.3 per 100 popl.)
DEFENSE FORCES
Andorra has no defense forces; Spain and France are
responsible for protection as needed','431eeeea1de8d280863b92bab57399ca9b86356d61979bd54ab92f2270f3760f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c678e921eabc93bfaf020dc0beb20b764dd67b855b893bcd8f143e51429ec7b',1980,'AO','Angola','communications',22,'‘LAND
1,245,790 km?*; 1% cultivated, 44% forested, 22% meadows
and pastures, 33% other (including fallow)
Land boundaries: 5,070 km
WATER
Limits of territorial waters (claimed): 20 nm
Coastline: 1,600 km
Railroads: 3,108 km total; 2,798 km 1.067-meter gage,
310 km 0,.600-meter gage
Highways: 73,828 km total; 8,577 km bituminous-surface
treatment, 28,723 km crushed stone, gravel, or improved
earth, remainder unimproved earth
Inland waterways: 3,220 km _ navigable
Ports: 8 major (Luanda, Lobito, Mocamedes), 15 minor
Pipelines: crude oil, 179 km
Civil air: 22 major transport aircraft
Airfields: 563 total, 504 usable; 25 with permanent-
surface runways; 1 with runway over 3,660 m, 8 with
runways 2,440-3,659 m, 89 with runways 1,220-2,439 m
Telecommunications: fair network of open-wire and
radio-relay facilities; 1 Atlantic Ocean satellite station;
32,000 telephones (0.5 per 100 popl.); 24 AM, 12 FM, and 1
TV station
DEFENSE FORCES
Military manpower: males 15-49, 1,574,000; 791,000 fit
for military service; average number reaching military age
(20) annually, 59,000
ANTIGUA
(See reference map It}
LAND
280 km?; 54% arable, 5% pasture, 14% forested, 9% unused
but potentially productive, 18% wasteland and built on
WATER :
Limits of territorial waters (claimed): 3 nm
Coastline: 153 km
Railroads: 78 km narrow gage (0.760 m), employed
almost exclusively for handling cane
Highways: 380 km total; 240 km main, 140 km secondary
Ports: 1 major (St. John’s), 1 minor
Civil air: 10 major transport aircraft, including 1 leased ;
out ;
Airfields: 3 total, 3 usable; 1 with asphalt runway 2,745
m; 2 seaplane stations
Telecommunications: automatic telephone system; 3,500
telephones (4.9 per 100 popl.); tropospheric scatter links with
Tortola and St. Lucia; 3 AM stations, 1 FM station, and 1 TV
station; 1 coaxial submarine cable','5c2ffaead6be3c18ac1117c3f7a50d618f27a407b7359fff53345e0c44fb50be','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a75e17f74ba35b5e7e95c1bb0e49d2ca3431347dfc5abadff914067265626f21',1980,'AR','Argentina','communications',26,'BOLIVIA
Pacific
Ocean
Buenos Aires
Atlantic Ocean
wz FALKLAND ISLANDS
(See reference map til}
LAND
2,771,300 km?*; 57% agricultural (11% crops, improved
pasture and fallow, 46% natural grazing land), 25% forested
18% mountain, urban, or waste ‘
Land boundaries: 9,414 km
>
WATER
Limits of territorial waters (claimed): 200 nm (continen-
tal shelf, including sovereignty over superjacent waters)
Coastline: 4,989 km
Railroads: 39,738 km total; 3,086 km standard gage (1.435
m), 22,788 km broad gage (1.676 m), 13,461 km meter gage
(1.000 m), 403 km 0.750-meter gage
Highways: 207,300 km total, of which 43,900 km paved,
39,500 km gravel, 104,000 km improved earth, 19,900 km
unimproved earth
Inland waterways: 11,000.km navigable
Ports: 7 major, 21 minor
Pipelines: 4,090 km crude oil; 2,200 km refined products;
8,172 km natural gas
Civil air: 39 major transport aircraft
Airfields: 2,400 total, 2,127 usable; 92 with permanent-
surface runways; 21 with runways 2,440-3,659 m, 313 with
runways 1,220-2,439 m; 6 seaplane stations
Telecommunications: extensive modern system; tele-
phone network has 2.54 million sets (9.8 per 100 popl.), radio
relay widely used, | satellite station with 2 Atlantic Ocean
antennas; 160 AM, 12 FM, and‘ 64 TV statioris
DEFENSE FORCES :
Military manpower: males 15-49, 6,535, 000: 5, 299, 000 fit
for military service; average number reaching military age
(20) annually about 226,000
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Military budget: proposed for fiscal year ending 31
December 1978, $1,742.2 million; about 15% of total central
government budget
Atlantic
Ocean
FALKLAND
E> ISLANDS
(See reference map til}
LAND
Colony—12,168 km?; area consists of some 200 small
'' The possession of the Falkland Islands has been disputed by the
U.K. and Argentina (which refers to them as the Islas Malvinas)
since 1833.
62
islands, chief of which are East Falkland (6,680 km*)-and
West Falkland (5,276 km?*); dependencies—consists of the
South Sandwich Islands, South Georgia, and the Shag and
Clerke Rocks
WATER
Limits of territorial waters (claimed): 8 nm
Coastline: 1,288 km
Railroads: none
Highways: 510 km total; 30 km paved, 80 km gravel, and
400 km
Ports: 1 major (Port Stanley), 4 minor
Civil air: no major transport aircraft
Airfields: 2 usable, 1 seaplane station
Telecommunications: government-operated and_ radio-
telephone networks providing effective service to almost all
points 6n both islands; approximately 650 telephones (est. 30
per 100 popl.); 1 AM station :
Atlantic
” Montevideo Ocean
{See reference map {V}
LAND -
186,998 km*; 84% agricultural land (73% pasture, 11%
cropland), 16% forest, urban, waste and other
Land boundaries: 1,352 km
WATER
Limits of territorial waters (claimed): 200 nm (fishing
200 nm) aot
Coastline: 660 km
Railroads: 2,795 km, all standard gage (1.485 m) and
government owned
Highways: 49,900 km total; 6,700 km paved, 3,000 km
gravel, 40,200 km earth
Inland waterways: 1,600 km; used by coastal and
shallow-draft river craft
Freight carried: highways 80% of total cargo traffic, rail
15%, waterways 5%
Ports: 4 major (Montevideo, Colonia, Fray Bentos,
Paysandu), 6 minor .
Civil air: 6 major transport aircraft (including 2 leased in)
Airfields: 101 total, 63 usable; 10 with permanent-surface
runways; 1 with runway 2,440-3,659 m, il with runways
1,220-2,489 m; 2 seaplane stations
Telecommunications: most modern facilities concen-
trated in Montevideo; 258,000 telephones (9.0 per 100 popl.);
85 AM, 3 FM, and 27 TV stations:. 2 submarine cables
DEFENSE FORCES 7
Military manpower: males 15-49, 672,000; 544,000 fit for
military service; no conscription
Military budget: proposed for fiscal year ending 31
December 1977, $79.9 million; 17.3% of central government
budget
VATICAN CITY
Tyrrhenian
Sea
Mediterranean -
Sea
(See reference map V}
LAND
0.438 km?
Land boundaries: 3 km
Railroads: none
Highways: none (city streets)
Civil air: no major transport aircraft
Airfields: none
Telecommunications: 3 AM stations and 2 FM stations;
2,000-line automatic telephone exchange
DEFENSE FORCES
Defense is responsibility of Italy
VENEZUELA .
LAND
911,680 km?;-4% cropland, 18% pasture, 21% forest, 57%
urban, waste, -and other.
Land boundaries: 4,181 km
WATER
Limits of territorial waters (claimed): 12 nm (economic
including fishing 200 nm)
220
Coastline: 2,800 km
Railroads: 373 km standard gage (1.435 m) all sacs
track; 171 km government owned, 202 km privately owned
Highways: 58,900 km total; 21,800 km paved, 21,900 km
otherwise improved and 15,200 km unimproved earth
Inland waterways: 7,100 km; Orinoco River and Lake
Maracaibo accept oceangoing vessels
Pipelines: 6,110 km crude oil; 400 km refined products;
2,495 km natural gas
. Ports: 6 major, 17 minor .
Civil air: 70 major transport aircraft (including 4 leased in
‘and 1 leased out)
Airfields: 292 total, 262 usable; 109 with permanent-sur-
face runways; 8 with runways 2,440-3,659 m, 80 with
runways 1,220-2,4839 m; 2 seaplane stations ,
Telecommunications: modern expanding telecom system;
satellite ground station; 649,000 telephones (5.3 per 100
popl.); 157 AM, 50 FM, and 43 TV stations; 2 submarine
cables; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 3,033,000; 2,156,000 fit
for military service; 158,000 reach military age (18) annually
’ Military budget: proposed for fiscal year ending 31
December 1979, $708.4 million; ‘about 6.7% of central
government budget
VIETNAM
os Falkland Is.
SMa as Malvinas)
(Admin. by ULK.,
claimed by
Argentina)
"$40 Paulo, ue
III. South America
North
Atlantic
Ocean
Paramaribo
( “"\\ cayenne
Frenc
f \\
Guiana
Recife
5* Salvador
ybrasilia
Rio de Janeiro
South
f i
Atlantic
Ocean
1000 Kilometers
1000 Miles
South Georgia
Sy (Fatkland fs.)
. Boundary representation is
not necessarily authoritative
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
IV Europe','32cd96c402c3b4f1118b7204c0c05ff70f8db770c130b37700f7fa99de0f274a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc7ea1b89ed478bbc57cc11aeaf163748eeda1c86589d07c6ccb5bcf41b30301',1980,'AU','Australia','communications',30,'c-
NDONESIA.
a 2
Se 0c
2.
Indian Ocean
. NEW ZEALAND GH
{See reference map Vill)
LAND
7,692,300 km*; 6% arable, 58% pasture, 2% forested, 34%
other
WATER
Limits of territorial waters (claimed): 3 nm (fishing 12
nm; prawn and crayfish on continental shelf)
Coastline: about 25,760 km
Railroads: 40,636 km total (1976); 9,197 km 1.60-meter
gage, 13,894 km standard gage (1.435 m), 18,045 km
1.067-meter gage; 800 km electrified (June 1962); govern-
ment-owned (except for few hundred kilometers of privately
owned track)
Highways: 837,872 km total (1977); 207,650 km paved,
205,454 km gravel, crushed stone, or stabilized soil surface,
424,768 km unimproved earth
Inland waterways: 8,368 km; mainly by small, shallow-
draft craft
Ports: 12 major, numerous minor
Pipelines: crude oil, 740 km; refined products, 340 km;
natural gas, 6,947 km
Civil air: around 150 major transport aircraft
Airfields: 1,618 total, 1,546 usable; 198 with permanent-
surface runways, 2 with runways: over 3,660 m; 18 with
runways 2,440-3,659 m, 626 with runways 1,220-2,439 m
Telecommunications: very good international and do-
mestic service; 5.5 (39.5 per 100 popl.) million telephones;
204 AM stations, 5 FM stations, 112 TV stations and 66
repeaters; 3 earth satellite stations; submarine cables to New
Zealand, New Guinea, Singapore, Malaysia, Hong Kong, and
(See reference map VIII}
LAND
18,272 km?; landownership—83.6% Fijians, 1.7% Indians,
6.4% government, 7.2% European, 1.1% other; about 30% of
land area is suitable for farming
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 1,129 km
Railroads: 644 km narrow gage (0.610 m); owned by Fiji
Sugar Corp., Ltd.
Highways: 3,472 km total (1977); 346 km paved, 2,706
km gravel, crushed stone, or stabilized soil surface; 420 km
unimproved earth
Inland waterways: 203 km; 122 km _ navigable by
motorized craft and 200-metric ton barges
Ports: 1 major, 6 minor
Civil. air: 1 DC-8 and 1 light aircraft
Airfields: 15 total, 15 usable; 2 with permanent-surface
runways, 1 with runway 2,440-3,659 m, 1 with runway
1,220-2,439 m
Telecommunications: modern local, interisland, and
international (wire/radio integrated) public and special-pur-
pose telephone, telegraph, and teleprinter facilities; regional
radio center; important COMPAC cable link between
U.S./Canada and New Zealand/Australia, et al.; 30,700
telephones (5.3 per 100 popl.); 6 AM, 2 FM, and no TV
stations; 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 163,000; 91,000 fit for
military service; 8,000 reach military age (18) annually
Military budget: the defense of the Fiji Islands was the
responsibility of the U.K. until 10 October 1970; military
budget for 1971, $314,000
(See reference map Vill}
The islands that comprise the Gilbert Islands Colony are
the Gilbert Islands; Fanning Atoll and Washington Island in
the Line Islands; Ocean Island; and those islands claimed by
the United States: Caroline, Christmas, Flint, Malden,
Starbuck, and Vostok in the Line Islands; and Birnie,
Gardner, Hull, McKean, Phoenix, and Sydney in the
Phoenix Islands.
LAND
About 684 km?
WATER
Limits of territorial waters: 3 nm (fishing 200 nm)
Coastline: about 1,143 km
Railroads: none
Highways: 483 km of motorable roads
Inland waterways: small network of canals, totaling 5
km, in Northern Line Islands
Ports: 1 minor
Civil air: 2 Trislanders, however, no major transport
aircraft
Telecommunications: 1 AM _ broadcast station; 250
telephones (0.1 per 100 popl.)
(See reference map Vil)
WATER
‘Limits of territorial waters (claimed): under an archi-
pelago theory, claim is 12 nm, measured seaward from
straight baselines connecting the outermost islands
Coastline: 54,716 km
Railroads: 7,843 km total (1977); 7,246 km 1.067-meter
gage, 505 km 0.750-meter gage, 92 km 0.600-meter gage;
211 km double track; 101 km electrified; government owned
Highways: 93,053 km total; 26,573 km paved, 41,521 km
gravel or crushed stone, 24,959 km improved or unimproved
earth — a
Inland waterways: 21,579 km; Sumatra 5,471 km, Java
and Madura 820 km, Borneo 10,460 km, Celebes 241. km,
and Irian Barat 4,587 km
Ports: 10 major, 66 minor
Civil air: approximately 110 major transport aircraft
Airfields: 38] total, 370 usable; 71 with permanent-
surface runways; 11 with runways 2,440-3,659 m, 66 with
runways 1,220-2,489 m
Telecommunications: interisland microwave system and
HF police net; domestic service poor, international service
good; radiobroadcast coverage good; 314,000 telephones (0.2
per 100 popl.); 291 AM, 1 FM, and 13 TV stations; 1 -
international ground satellite station (1 Indian Ocean
antenna and 1 Pacific Ocean antenna), and 40 domestic
ground satellite stations
DEFENSE FORCES
Military manpower: males 15-49, 31,757,000; 18,138,000
fit for military service; about 1,594,000 reach military age
(18) annually
Military budget: for fiscal year ending 31 March 1979,
$1.7 billion; about 14.5% of central government budget
IRAN
ARABIA
Arabian
(See reference map V}
LAND ‘
1,647,240 km*; 14% agricultural, 11% forested, 16%
cultivable with adequate irrigation, 51% desert, waste, or
urban, 8% migratory grazing and other
Land boundaries: 5,318 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing, 50
nm)
Coastline: 3,180 km, including islands, 676 km
Railroads: 4,601 km total; 4,509 km standard gage (1.435
m), 92 km 1.676-meter gage
Highways: 81,800 km total; 36,000 km gravel and crushed
stone, 15,000 km improved earth ;
. Inland waterways: 904 km, excluding the Caspian Sea,
- 104 km on the Shatt al Arab
98
Pipelines: crude oil, 3,072 km; refined ‘products, 3,766
km; natural gas, 2,317 km
Ports: 7 major, 6 minor
Civil air: 60 major taispoteaieeentt (including 5 leased
in) :
Airfields: 178 total, 160 usable; 66 with permanent-
surface runways; 13 with runways over 3,660 m, 17 with
runways 2,440-3,659 m, 65 with runways 1,220-2,439 m
Telecommunications: advanced system of high-capacity
radio-relay links, open-wire lines, cables, and tropospheric
. links; principal center Tehran, secondary centers Isfahan,
Meshed, and Tabriz; 805,600 telephones (2.0 per 100 popl.);
85 AM, 2 FM, and 67 TV stations; 1 satellite station with
Atlantic Ocean and Indian Ocean antennas, extensive
upgrading in progress
DEFENSE FORCES
Military manpower: males 15-49, 7,826,000; 4,656,000 fit
for military service; about 345,000 reach military age (21)
annually
Caspian
Sea
(See reference map V}
LAND
445,480 km?; 18% cultivated, 68% desert, waste, or urban,
10% seasonal and other grazing land, 4% forest and
woodland
Land boundaries: 3,668 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 58 km
Railroads: 1,700 km total; 1,123 km standard gage (1.435
m), 577 km meter gage (1.00 m); 16 km meter gage double
track
Highways: 20,791 km total; 6,490 km paved, 4,645 km
improved earth, 9,656 km unimproved earth
Inland waterways: 1,015 km; Shatt al Arab navigable by
maritime traffic for about 104 km; Tigris and Euphrates
navigable by shallow-draft steamers
Ports: 3 major (Basra, Umm Qasr, Al Faw)
Pipelines: crude oil, 3,821 km; 585 km refined products;
1,360 km natural gas
Civil air: 25 major transport aircraft
Airfields: 76 total, 69 usable; 26 with permanent-surface
runways; 36 with runways 2,440-3,659 m, 18 with runways
1,220-2,489 m
Telecommunications: network consists of coaxial cables,
radio-relay links, and radiocommunication stations; 320,000
telephones (2.8 per 100 popl.); 9 AM, no FM and 10 TV
stations; ] satellite station with Atlantic Ocean and Indian
Ocean antennas; system expansion in process
DEFENSE FORCES
Military manpower: males 15-49, 2,721,000; 1,515,000 fit
for military service; about 137,000 reach military age (18)
annually
(See reference map Vill}
LAND
21.2 km?; insignificant arable land, no urban areas,
extensive phosphate mines
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 24 km
Railroads: none
Highways: about 27 km total; 2] km paved, 6 km
improved earth
Inland waterways: none
Ports: 1 minor
Civil air: 8 major transport aircraft, one on order
Airfields: 1, coral-surfaced, over 1,220 m
Telecommunications: adequate intraisland and interna-
tional radiocommunications provided via Australian facili-
ties; 700 telephones; 3,600 radio receivers, 1 AM, no FM and
no TV stations; 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, about 2,000; fit for
military service, about 1,000; average number reaching
military age (18) annually, 1978-82, less than 100
No formal defense structure and no regular armed forces
(See reference map Vill}
LAND
22,015 km?; 6% cultivable, 22% pasture land, 15% forests,
57% waste or other
WATER
Limits of territorial waters (claimed): 12 nm (fishing, 3
nm)
Coastline: 2,254 km
Railroads: none
Highways: 5,448 km total (1977); 558 km paved, 2,251
km improved earth, 2,639 km unimproved earth
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
§
ae a a eX
Aan AA,
eR Am na Ame kA a A Re RA
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
NEW CALEDONIA/NEW HEBRIDES/NEW ZEALAND
Inland waterways: none
Ports: 1 major (Noumea), 21 minor
Civil air: no major transport aircraft
Airfields:-31 total, 30 usable; 2 with permanent-surface
runways; 2 with runways 1,220-2,439 m; 1 airfield over
2,440 m; 1 seaplane station
Telecommunications: 20,600 telephones (14.9 per 100
popl.); 5 AM, no FM, and 7 TV stations; 1 earth satellite
station
NEW HEBRIDES
Pacific
Ocean
sane
ce
»
=
a
AS
»
- Coral Sea :
Ww cy
HEBRIDES .
new Sy
CALEDONIA
3
(See reference map Vill}
LAND
About 14,763 km?
WATER
Limits of territorial waters: 3 nm
Coastline: about 2,528 km
Railroads: none
Highways: at least 240 km sealed or all-weather roads
Inland waterways: none
Ports: 2 minor
Civil air: no major transport aircraft
Airfields: 27 total, 26 usable; 2 runways 1,220-2,439 m, 2
with permanent-surface runways
Telecommunications: 3 AM _ broadcast stations; 2,300
telephones (2.3) per 100 popl.); 1 ground satellite station
DEFENSE FORCES
Personnel: no military forces maintained; however, the
French and British maintain constabularies of about 100
men each
Railroads: 4,716 km total (1977); all 1.067-meter gage;
274 km double ‘track; 113 km electrified; over 99%
government owned
Highways: 92,617 km total (1977); 46,716 km paved,
45,901 km gravel or crushed stone
Inland waterways: 1,609:km; of little importance to
(See reference map Vill)
LAND
475,369 km?
Land boundaries: 966 km
162
WATER
Limits of territorial waters (claimed): 12 nm (economic
including fishing 200 nm)
Coastline: about 5,152 km
Railroads: none
Highways: 19,200 km total; 640 km paved, 10,960 km
gravel, crushed stone, or stabilized soil surface, 7,600 km
unimproved earth
Inland waterways: 10,940 km
Ports::5 principal, 8 minor
Civil air: about 15 major transport aircraft
Airfields: 525 total, 482 usable; 18 with permanent-sur-
face runways; 2 with runways 2,440-3,659 m: 41 with
runways 1,220-2,439 m :
Telecommunications: Papua New Guinea telecom serv-
ices are adequate and are being improved; principal telecom
centers include Goroka, Lae, Madang, Mount Hagen, and
Wewak in New Guinea; and Daru, Port Moresby and
Samarai in Papua; facilities provide radiobroadcast, radio-
telephone and telegraph, coastal radio, aeronautical radio
and international radiocommunication services; numerous
privately owned radio facilities exist; .submarine cables
extend from Madang to Australia and Guam; 37,500
telephones (1.3 per 100 popl.); 31 AM, no FM and no TV
stations ,
DEFENSE FORCES
Military manpower: males 15-49, 720,000; about 398,000
fit for military service
Supply: dependent on Australia
Military budget: for fiscal year ending 30 June 1978,
$24.8 million; 3.7% of central government budget
(See reference map Vil)
colony of Tuvalu. The remaining islands in the former
Gilbert and Ellice Islands Colony were renamed the Gilbert
Islands.
The new colony of Tuvalu includes the islands of
Nanumanga, Nanumea, Nui, Niutao, Vaitupu, and. those
islands claimed by the United States: Funafuti, Nukufetau,
Nukulailai, and Nurakita.
LAND
26 km?
WATER
Limits of territorial waters: 3 nm
Coastline: about 24 km
Railroads: none
Highways: 8 km gravel
Inland waterways: none
Ports: 1 minor
Civil air: no major transport aircraft
211
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
TUVALU/UGANDA
Airfields: 1 total; 1 usable with runway 1,220-2,439 m; 1
seaplane station
Telecommunications: 1 AM station; about 300 telephones
(0.5 per 100 popl.); 4,000 radio sets
NEW
ZEALAND
{See reference map Vi}
Railroads: none
Highways: 784 km total; 375 km bituminous, remainder
mostly gravel, crushed stone, or earth
Inland waterways: none
Ports:
Civil air: 2 major transport aircraft
1 principal (Apia), 1 minor
Airfields: 4 total, all usable; 1 with permanent-surface
runway 1,220-2,439 m :
Telecommunications: 3,300 telephones (2.2 per 100
popl.); 20,000 radio receivers; 2 AM stations
YEMEN (ADEN) .
LAND
287,490 km? (border with Saudi Arabia ‘daetibeay only
about 1% arable (of which less than 25% aa)
Land boundaries: 1,802 km
WATER
Limits of territorial waters (claimed): 12 nm (plus 6 nm
“necessary supervision zone’)
Coastline: 1,383 km
Railroads: none
’ Highways: 5,311 km total; 392 km bituminous treated,
290 km crushed stone and gravel, 4,699 km motorable track
Ports: 1 major (Aden)
Pipelines: refined products, 32° km
Civil air: 6 major transport aircraft
Airfields: 94 total, 56 usable; 4 with permanent-surface
runways; 4 with runways 2,440-3,659 m, 31 with runways
1,220-2,489 m
Telecommunications: small system of open-wire line,
multiconductor cable, and radiocommunications stations;
only center Aden; 9,900 telephones (0.6 per 100 popl.); 1
AM, .no FM and 8 TV stations; 2 submarine cables
- DEFENSE FORCES
Military manpower: males 15-49, 420,000; 234 ,000 fit for
military service
Military budget: .for fiscal year ending 31 December
1977, $55 million; about 19% of central government budget
YEMEN (SANA):
LAND
194,250 km? (parts of border with Saudi Arabia and
Southern Yemen undefined); 20% agricultural, 1% forested,
79% desert, waste, or urban
Land boundaries: 1,528 km
226
SAUDI
ARABIA
Indian
Ocean
(See reference map V}
WATER
Limits of territorial waters (claimed): 12 nm (plus 6 nm
“necessary supervision zone’)
Coastline: 523 km
Railroads: none
Highways: 3,477 km total; 467 km bituminous; 435 km
crushed stone -and gravel; 2,575 km earth, sand, and light
gravel
Ports: ] major (Al Hudaydah), 2 minor
_ Civil air: 9 major transport aircraft (including 3 leased in)
Airfields: 27 total, 16 usable; 4 with permanent-surface
runways; 4 with runways 2,440-3,659 m, 8 with runways
1,220-2,489 m
Telecommunications: system inadequate; consists of
meager open-wire lines and low-power radiocommunication
stations; principal center Sana, secondary centers Al
Hudaydah and Taizz; 4,600 telephones (0.1 per 100 popl.); 2
AM stations, no FM, 1 TV station; 1 Indian Ocean satellite
station
DEFENSE FORCES :
Military manpower: males 15-49: 1,313,000; 728,000 fit
for military service; about 60,000 reach military age (18)
annually ;
Military budget: for fiscal yearsending..30 June 1975,
$50,402,000; 54:6% of central government budget
YUGOSLAVIA
{See reference map ill)
LAND
255,892 km?*; 32% arable, 25% meadows and pastures, 34%
forested, 9% other
Land boundaries: 3,001 km
WATER
Limits of territorial waters (claimed): 10 nm (fishing 12
nm)
Coastline: 1,52] km (mainland), plus 2,414 km (offshore
islands) 3
Railroads: 9,967 km total; 9,619 km standard gage
(1.435 m), 348 km narrow gage; 794 double track; 2,912 km
electrified (1977)
Highways: 104,891 km total; 44,733 km asphalt, concrete,
stone block; 35,057 km asphalt treated, gravel, crushed stone;
25,101 km earth (1977) :
Inland waterways: 2,600 km (1978)
Freight carried: rail—73.7 million metric tons, 21.0
billion metric ton/km (1976); highway—84.1 million metric
tons, 11.2 billion metric ton/km (1976); waterway—23.1
million metric tons, 6.0 billion metric ton/km (incl. int''l.
transit traffic) in approximately 1,225 waterway craft with
703,600 metric ton capacity
Pipelines: 623 km crude oil; 1,860 km natural gas
Ports: 9 major (most important: Rijeka, Split, Koper, Bar,
and Ploce), 24 minor; principal inland water port is Belgrade
(1978)
DEFENSE FORCES
Military manpower: males 15-49, 5,866,000; 4,724,000 fit
for military service; 191,000 reach military age (19) annually
Military budget (announced): for fiscal year ending 31
December 1978, 42:7 billion dinars; about 4.7% of Gross
Social Product (Yugoslavia’s measure of production)
ZAIRE
LAND
2,343,950 km?; 22% agricultural land (1% cultivated), 45%
forested, 33% other
Land boundaries: 9,902 km
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
{
‘
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
ZAIRE
Atlantic
(See reference map V)}
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 37 km
Railroads: 5,256 km total; 3,970 km 1.067-meter gage
(851 km electrified), 125 km meter gage (1.000 m); 136 km
0.615-meter gage, 1,025 km 0.600-meter gage
Highways: 145,000 km total; 2,000 km_ bituminous,
66,000 km improved earth; 77,000 km unimproved
Inland waterways: comprising the Zaire, its tributaries,
and unconnected lakes, the waterway system affords over
15,000 km of navigable routes
229
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDPO8-00534R000100140001-7
January 1979
ZAIRE/ZAMBIA
Ports: 2 major (Matadi, Boma), 1 minor
Pipelines: refined products, 390 km
Civil air: 49 major transport aircraft
Airfields: 339 total, 285 usable; 23 with permanent-sur-
face runways; 2 with runways over 3,660 m, 3 with runways
2,440-3,659 m, 60 with runways 1,220-2,439 m
Telecommunications: limited, barely adequate telephone
service, telegraph service good; 28,000 telephones (0.1 per
100 popl.); 12 AM, 1 FM, and 2 TV stations;.1 Atlantic
Ocean satellite station; domestic Comsat network
DEFENSE FORCES
Military manpower: males 15-49, 6,054,000; 3,059,000 fit
for military service
o
0534R000100140001-7
U.S.S.R. and Asia
Adelaide
Melbourne
.
2
(7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7 !
| VIII Oceania
FE - Hawaiian*>Mou!
% yet ws Islands Hawaii
O mariana
ISLANDS United States
Philippine Sea Honnston
: Saipan
''
: i
Philippines Guam wSi05)
: ;
1
Trust Territory of the Paci
rust Territory NORTH
Brunei /
WK)
G =
=a “ laker (U.S. g a oS
Nauru’ 5 (U.S.U.K. joint admin)
Canton“ PHOENIX IS.
Phoenix —*, U.K. admin.. U.S. claim)
Bougainville = r Gardner" Hull
INS Coen, Solomon tstands-D : lb ert
c
>
z
Java Sea o
Iistand
4Indonesi Ss (WK, admin,
5 Solomon Sea { osm, Senta sabe! US. claim)
ae
a ¥ “ .
ne eae Hokiara,, \\Waleita cata ds me ceo Anise by Now Zeatand
oS 3 #
==
? (Gained US,
Guadalcanal $2" Cristobal “CRUZ , Faicss : a
= 2S eer Us. ; ILES MARQUISES','dbb83af7439523b3beac11566dc4b5d5e100cc19027e2e68db33c80518f3494f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a98706ec0cdf8dc7a9d377692ec4828b505d563fcf12e40d40a7503b127ecc6',1980,'GU','Guam','communications',34,'DEFENSE FORCES
Military manpower: males 15-49, 3,551,000; 3,142,000 fit
for military service; 130,000 reach military age (17) annually
Military budget: for fiscal year ending 30 June 1979,
$2,925,000,000; about 8.7%: of total central government
budget','38850e9f0f945a96a316638f33c287faf164ebc2f4ac2161ab54bc4b773fa43e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5fa9098ef557d4a9113ea27985f6c312f1ede2b8d57ce5ac627782954fdf1c4',1980,'AT','Austria','communications',35,'LAND
83,916 km*; 20% cultivated, 26% meadows and pastures,
15% waste or urban, 38% forested, 1% inland water
Land boundaries: 2,582 km
Railroads: 6,517 km total; 5.877 km government-owned;
5,397 km standard gage (1.435 m) of which 2,730 km
electrified and 1,333 km double tracked; 480 km narrow
gage (0.760 m) of which 91 km electrified; 640 km prvately
owned (1.435- and 1.000-meter gage)
Highways: approximately 33,600 km_ total atonal
classified network, including 10,400 km federal and 23,200
km provincial roads; about 20,800 km paved (bituminous,
concrete, stone block) and 12,800 km unpaved (gravel,
crushed stone, stabilized soil); additional 60,800 km commu-
nal roads (mostly gravel, crushed stone, earth)
Inland waterways: 427 km
Ports: 2 major river (Vienna, Linz)
Pipelines: 554 km crude oil; 2,611 km natural gas; 171 km
refined products
Civil air: 16 major transport aircraft
Airfields: 51 total, 50 usable; 12 with permanent-surface
runways; 3 with runways 2,440-3,659 m, a with runways
1,220-2,489 m ~
Telecommunications: highly developed and efficient;
extensive TV and radiobroadcast systems with 90 AM, 94
FM, and 350 TV stations; 1 Comsat station U/C; 2.28 million
telephones (29.9 per 100 popl.)
DEFENSE FORCES
Military manpower: males 15-49, 1,766,000; 1,495,000 fit
for military service; average number reaching military age
(19) annually about 62,000
Military budget: for fiscal year ending 31 December
1978, $720 million; about 4.0% of the federal budget +
THE BAHAMAS
LAND
11,396 km?; 1% cultivated, 29% forested, 70% built on,
wasteland, and other
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm) :
Coastline: 3,542 km (New Providence Is. 76 km)','c8c4f4dd9bdb4d1acc0dee7e42fffea7bf87b9fd9bd025741bd54ac183cad0e7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('825590b488ca45d8d49d3bce3725c9abebe464ea93bfe4f806849c9b6544178c',1980,'HT','Haiti','communications',42,'Railroads: .none
Highways: 3,350 km total; 1,350 km paved, 2,000 km
gravel
Ports: 2 major (Freeport, Nassau), 9 minor
Civil air: 7 major transport aircraft _
Airfields: 54 total, 51 usable; 25 with permanent-surface
’ runways; 3 with runways 2,440-3,659 m, 22 with runways
1,220-2,489 m; 4 seaplane stations ;
Telecommunications: telecom facilities highly developed,
including 58,000 telephones (27.5 per 100 popl.) in totally
automatic system; tropospheric scatter link with Florida; 3
AM, 2 FM stations and 1 TV station; 3 coaxial submarine
cables
_ Atlantic Ocean
SCUBA > _
oa
OMINICAN
REPUBLIC
‘ost-au-
SS
JAMAICA "Prince
Caribbean Sea
2
{See reference map tl)
LAND
27,713 km; 31% cultivated, 18% rough pastures, 7%
forested, 44% unproductive
Land boundary: 361 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm); 200 nm exclusive economic zone
Coastline: 1,771 km
Railroads: 80 km narrow gage (0.760 m), single-track,,
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
eee ane
——
wR Am em Re ne RACER AR OORT SET OA
ry aa a oa
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
HAITI/HONDURAS
privately owned industrial line; 8 km dual-gage 0.760- to
1.065-meter gage, government line, dismantled
Highways: 3,200 km total; 600 km paved, 950 km —
otherwise improved, 1,650 km unimproved
Inland waterways: negligible; about 100 km navigable
Ports: 2 major (Port-au-Prince, Cap Haitian), 12 minor
Civil air: 6 major transport aircraft
Airfields: 14 total, 13 usable; 3 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 4 with runways
1,220-2,439 m; 2 seaplane stations
Telecommunications: all domestic facilities inadequate,
international facilities slightly better; telephone expansion
program underway; 17,800 telephones (0.4 per 100 popl.); 40
AM, 5 FM, and 1 TV station; 1 Atlantic Ocean satellite
station
DEFENSE FORCES
Military manpower: males 15-49, 1,056,000; 569,000 fit
for military service; about 53,000 reach military age (18)
annually
Military budget: for fiscal year ending 30 September
1979, $13.8 million','f529db0000f02cd6233c2c50dbc24ed342b39b8a5ea921e46fb7b88ca96105d7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8c05ef53945b6b8222440237cb41acdcacc606aad4e2d1e899cb1161ce87268',1980,'BH','Bahrain','communications',43,'LAND
596 km? plus group of 32 smaller islands; 5% cultivated,
negligible forested area, remainder desert, waste, or urban
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 161 km
Highways: 93 km bituminous surfaced; undetermined
mileage of ‘natural surface tracks
Ports: 1 major (Bahrain)
Pipelines: crude oil, 56 km; refined products, 16 km;
natural gas, 32 km
’ Civil air: 2 major transport aircraft
Airfields: 2 total, 2 usable; 1 with permanent-surface
runway; 1 with runway over 3,660 m; 1 with runway 1,220-
2,439 m; 1 seaplane station
Telecommunications: excellent international telecom-
munications; limited domestic services; 31,000 telephones
(11.6 per 100 popl.); 1 AM station, 1 TV station, 1 Indian
Ocean satellite station; tropospheric scatter and microwave
to Qatar and United Arab Emirates
DEFENSE FORCES
Military manpower: males 15-49, 64,000; fit for military
service, 37,000
Supply: mostly from U.K.
Military budget: for fiscal year ending 31 December
1978; $42.8 million, 6% of total budget','89bc2be787d4d53f9ea279a2f6e1ee97caed8a56022124cb01ff7a4ea854af54','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b81cfd690a167e1f7910a3a12ac6ae1ac1b9afcc0040f5c54975cc6a745d07bf',1980,'BD','Bangladesh','communications',47,'LAND
142,500 km*; 66% arable (including cultivated and
fallow), 18% not available for cultivation, 16% forested
Land boundaries: 2,535 km
WATER
'' Limits of territorial waters (claimed): 12 nm; fishing 200
nm
Coastline: 580 km
Railroads: 2,909 km total (1977); 1,910 km meter gage
(1.000 m), 964 km broad gage (1.676 m), 35 km narrow gage
(0.762 m), 300 km double track; government-owned
Highways: 44,9380 km total; 4,044 km paved, 2,022 km
gravel, 38,864 km earth
Inland waterways: 7,000 km; river steamers navigate
main waterways
Ports: 1 major; 5 minor
Pipelines: 150 km natural gas
Civil air: 9 major transport aircraft
Airfields: 23 total, 16 usable; 18 with permanent surface
runways; 3 with runways 2,440-3,659 m, 8 with runways
],220-2,4389 m
Telecommunications: adequate international radiocom-
munications and landline service; fair domestic wire and
microwave service; fair broadcast service; 100,000 (est.)
telephones (0.1 per 100 popl.); 8 AM, 1 FM, 3 TV stations,
and 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 18,237,000; 10, 498,000
fit for military service
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
BANGLADESH /BARBADOS
Military. budget: for fiscal year ending 30 June 1978,
$145.0 million; about 8.8% of the central government budget','044d81a7dfd17ebc2a186e39ca1e778767bf1f54b4df4874434b267fc729168a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16810e068bc2e2c14ab891316c289fd484ee21d31d81cd897d2b94e2fb3d774c',1980,'BB','Barbados','communications',51,'DOMINICAN
=> REPUBLIC
Atlantic
+ Ocean
PUERTO™
RICO
(See reference map ti}
LAND
430 km?*; 60% cropped, 10% permanent meadows, 30%
built on, waste, other
WATER .
Limits of territorial waters (claimed): 12 nm (economic
including fishing 200 nm)
Coastline: 97 km
Railroads: none
Highways: 1,450 km total; 1,350 km paved, and 100 km
gravel, and earth
15
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
BARBADOS /BELGIUM
Ports: 1 major (Bridgetown), 2 minor
Civil air: 6 major transport aircraft (including 4 leased in)
Airfields: 1 with permanent-surface runway 2,440-3,659
m; 1 seaplane station :
Telecommunications: islandwide automatic telephone
system with 44,000 telephones (17.8 per 100 popl.);
tropospheric scatter link to Trinidad; UHF/VHF links to St.
Vincent and St. Lucia; 2 AM stations, 1 FM station, ] TV
station; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 58,000; 42,000 fit for
military service; average number reaching military age (18) -
annually, 3,000; no conscription
*Grenada
= “Trinidad
Pegor ses land Tobago
Caribbean Sea
Netherlands Antilles
Py ow
Barranquilla *
es Caracas','fab1d7191665c037544a52d41ae35595b8889eace553cf3d0f74668e9f6a160b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a311049e8ab96393bf54357a95999cc6bc97e1bbd6073c38f345cdfc07cb0d9',1980,'BE','Belgium','communications',55,'UNITED
KINGDOM
FEDERAL
REPUBLIC
OF GERMANY
(See reference map IV}
LAND
- 30,562 km?*; 28% cultivated, 24% meadow and pasture,
28% waste, urban, or other; 20% forested
Land boundaries: 1,377 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 12
nm)
Coastline: 64 km
Railroads: 4,394 km total; 4,117 km standard gage (1.435
m) and government-owned, 2,536 km double track, 1,224
km electrified; 277 km privately owned, electrified meter
gage (1.000 m)
Highways: 104,612 km total; 1,051 km paved, limited
access, divided.autoroute; 51,780 km other paved; 51,781 km
unpaved
Inland waterways: 2,043 km, of which 1,528 km. are in
regular use by commercial transport
Ports: 5 major, 1 minor
Pipelines: refined products, 1,115 km; crude, 161 km;
natural gas, 3,218 km
Civil air: 55 major transport aircraft
Airfields: 46 total, 45 usable; 23 with permanent-surface
runways; 14 with runways 2,440-3,659 m, 4 with runways
J,220-2,489 m
Telecommunications: excellent domestic and interna-
tional telephone and telegraph facilities; 2.95 million
telephones (30.0 per 100 popl.); 14 AM, 21 FM, and 25 TV
stations, 5 coaxial submarine cables; 1 Atlantic Ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 2,369,000; 1,999,000 fit
for military service; average number reaching military age
(19) annually 78,000
Military budget: proposed for fiscal year ending 31
December 1978, $2.3 billion; about 7% of proposed central
government budget','704d15d25bf74012413cd2e9d2a4c243640f81e0cd63e7147e4df284404edc39','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25a7d1d8fa8cc51753a6f2bc6fff9b3391aff5b0bac22bab9fbe36454f8599db',1980,'MX','Mexico','communications',59,'Caribbean
Sea
Pacific Ocean
{See reference mep tl}
LAND
108,880 km*;. 14% cultivated, 10% pasture, 57% forest,
19% other
Land boundaries: 1,625 km
WATER
Limits of territorial waters (claimed): 12. nm (fishing 200
nm); 200 nm exclusive economic zone
Coastline: 400 km
LAND
1,978,800 km?; 12% cropland, 40% pasture, 22% forested,
26% other (including waste, urban areas and public lands)
Land boundaries: 4,220 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm), 200 nm exclusive economic’ zone
Coastline: 9,330 km
137
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Gulf
of Mexico
Pacific Ocean
(See reference map ft)
Railroads: 19,680 km total; 18,576 km standard gage
(1.485 m); 1,104 km narrow gage (0.914 m); 102 km
electrified; 19,573 km government-owned, 107 km
privately-owned
Highways: 200,000 km total; 62,000 km paved, 88,300:
‘km otherwise improved, 49,700 km unimproved
Inland waterways: 2,900 km navigable rivers and coastal
canals ;
Pipelines: crude oil, 3,910 km; refined products, 3,490
‘km; natural gas, 5,710 km
Ports: 9 major, 20 minor
Civil air: 117 major transport aircraft
Airfields: 2,125 total, 2,062 usable; 143 with permanent-
surface runways; 2 with runways over 3,660 m, 20 with
runways 2,440-3,659 m, 279 with runways 1,220-2,489 m; 9
seaplane stations
Telecommunications: highly developed telecom system
with extensive radio-relay links; connection into Central
American microwave net; 1 Atlantic Ocean satellite ground
station; 3.31 million telephones (5.2 per 100 popl.); 574 AM,
109 FM, and 163 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 14,641,000; 11,133,000
fit for military service; average number reaching military
age (18) annually, 745,000
Military budget: for year ending 31 December 1978,
$632.8 million; about 2.9% of direct federa] budget (includes
merchant marine and military industry)
eGuadalajara
* Mérida
t ; > e Puerto Rico yi-gi
* mexi Cayman ts. font ace ART yDO™ (US), <n ON SoS RD
Mexico WK) + ti }Rep. <7 Anguilla (U.K)
: jamaica Port-au- Pris Pesci WD. ey, St Christopher (ux
? Domingo
Acapulco
Honduras __
«Te iG
San Salvaddr&, 3
EI Salvador
400 800 Kilometers
: 400 800 Miles
Boundary representation is
not necessarily authoritative
°
SGalapagos Is.
(Peusdor)
S
Declassified and Approved For Release 2012/09/02 :
| ; II
Middie America
''Washington®™ -
Permuda
{U.K}
|
Atlantic
Ocean
\\ as
Miami +6
le
eee 4 Bahamas
o
\\
?- Turk and Caicos Is.
comment)
me Antigua (U.K.)
: ES In, Nevis (U.K)
Kingsfon fo Péuadeloupe (Fr.
iy os
* Dominica
oh, (Martinique (Fr)
O St. Lucia{u.k.)
& St. Vincent
UK)','a46095bd9f16fddf3759c3bfa532d8b1aa9d3c8c605808bf1392edf676bd642c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1025c2045dc33a947f47c62d5da5fa506d552be61b666b782865dead5135ef7',1980,'HN','Honduras','communications',60,'As
Pacific
Ocean
(See reference map tl)
LAND
22,973 km?; 38% agricultural (5% cultivated); 46%
exploitable forest, 16% urban, waste, water, offshore islands
or other
Land boundaries: 515 km
WATER ©
Limits of territorial waters (claimed): 3 nm
Coastline: 386 km
Railroads: none
Highways: 2,550 km total; 300 km paved, 1,150 km
gravel, 950 km improved earth and 300 km unimproved
earth
Inland waterways: 800 km river network used by
shallow-draft craft
Ports: 1 major (Belize), 4 minor
Civil air: 5 major transport aircraft
Airfields: 36 total, 37 usable; 4 with permanent-surface
runways; 1 with runway 1,220-2,489 m
Telecommunications: 5,600 telephones in automatic and
manual network (4.3 per 100 popl.); radio-relay system; 6
AM sstations
DEFENSE FORCES
Military manpower: males 15-49, 34,000; 20,000 fit for
military service; 1,700 reach military age (18) annually
ONDURAS
Tegucigalpa
<<
eC
-» SALVADOR
Pacific Ocean
{See reference map fl}
LAND
112,150 km*; 27% forested, 30% pasture, 36% waste and
built-up, 7% cropland
Land boundaries: 1,530 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 820 km
Railroads: 574 km total; 325 km 1.067-meter gage, 249
km 0.914-meter gage
Highways: 7,300 km total; 1,450 km paved, 4,150 km
otherwise improved, 1,700 km unimproved earth
Inland waterways: 1,200 km navigable by. small] craft
Ports: 3 major (Puerto Cortes, La Ceiba, Tela), 9 minor
Civil air: 16 major transport aircraft
Airfields: 256 total, 226 usable; 4 with permanent-surface
runways; 2 with runways 2,440-3,659 m; 6 with runways
1,220-2,439 m; 1 seaplane station
Telecommunications: improved, but still inadequate;
connection into Central American microwave net; 19,500
telephones (0.7 per 100 popl.); 104 AM, 12 FM, and 6 TV
stations
90
DEFENSE FORCES
Military manpower: males. 15-49, 643,000; 381,000 fit for
military service; about 32,000 reach military age (18)
annually ,
Military budget: proposed for fiscal year ending 31
December 1978, $31.4 million; about 7.5% of central
government budget (includes the armed forces and other','e46fe75dd4756c10f4e91619547f72c17fb47c5778548e5f72f411d1f67128fe','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a2ffe85ecfe52b9d024f12f0e3ea5ff66a19f92ce0bde83702e5bdcf7edee27',1980,'BJ','Benin','communications',64,'(formerly Dahomey)
LAND
115,773 km*; southern third of country is most fertile;
arable land 80% (actually cultivated 11%), forests and game
preserves 19%, non-arable 1%
Land boundaries: 1,963 km
WATER
Limits of territorial waters (claimed): 200 nm (100 nm
mineral exploitation . limit)
Coastline: 121 km
Railroads: 579 km, all meter gage (1.00 m)
Highways: 3,303 km total; 705 km paved, 2,598 km
improved earth
Inland waterways: 645 km _ navigable
Ports: 1 major (Cotonou), 1 minor
Civil air: 1 major transport aircraft
Airfields: 10 total, 10 usable; 1 with permanent-surface
runway; 4 with runways 1,220-2,439 m
Telecommunications: system .of open wire and radio
relay; 9,900 telephones (0.3 per 100 popl.); 2 AM, 1 FM, and
no TV stations
DEFENSE FORCES
Military manpower: eligible 15-49, 735,000; 370,000 fit
for military service; about 34,000 males and 35,000 females
reach military age (18) annually; both sexes liable for
military service
Supply: dependent on France and Guinea; aid from North
Korea and PRC is pending
Military budget: for fiscal year ending 31 December
1977, $10.9 million; about 9.7% of central government
budget','09de882f6e226374e91a97059b01e3017bd40116997e973a83f4c416a9b7f621','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5de256c957770c2180bcb523cd72fd5f09c8a0fc1e38e83bd3f630a96cd9bf48',1980,'BM','Bermuda','communications',68,'LAND
54.4 km*; 8% arable, 60% forested, 21% built on,
-wasteland, and other, 11% leased for air and naval bases
19
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
‘January 1979
BERMUDA/BHUTAN
Atlantic
UNITED ~ Ocean
STATES
(See reference map tl)
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 103 km
Railroads: none
Highways: 190 km, all paved
Ports: 8 major (Hamilton, St. George Freeport, Ireland
Island)
Civil air: 2 major transport aircraft
Airfields: 1 with asphalt runway 2,945 m; 1 seaplane
station
Telecommunications: modern telecom system, includes
fully automatic telephone system with 38,600 sets (66.6 per
100 popl.); 8 AM, 1 FM, and 2 TV stations; 3 coaxial
submarine cables
BHUTAN |
LAND
46,600 km?; 15% agricultural, 15% desert, waste, urban,
70% forested
Land boundaries: about 870 km
Highways: 1,304 km total; 418 km surfaced, 515 km
improved, 371 km unimproved earth
Freight carried: not available, very light traffic
Civil air: no major transport aircraft
Airfields: 2 total, 1 asphalt runway 1,372 m, and 1 with
concrete runway 899 m ;
Telecommunications: facilities inadequate; 1,000 tele-
phones (0.1 per 100 popl.); 6,000 est. radio sets; no TV sets; 1
AM station and no TV stations :
DEFENSE FORCES
Military manpower: males 15-49, 299,000; 159,000 fit for
military service; about 14,000 reach military age (18)
annually
“Supply: dependent on India
BOLIVIA
LAND
1,098,160 km?; 2% cultivated and fallow, 11% pasture and
meadow, 45% urban, desert, waste, or other, 40% forest, 2%
inland water
Land boundaries: 6,083 km','572e9fa99aaffcc6b0e2d453813e49d67812a3edd9be7c320f9264a9df633285','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c85ba370d51930f26a63be19db1b772c58677dbb55f38ae0663a2394aab8192',1980,'BR','Brazil','communications',75,'Railroads: 3,572 km total, goverment owned, single track;
3,540 km meter gage (1.000 m), 32 km 0.760-meter gage; in
addition, 96 km meter gage (1.000 m) privately owned
Highways: 37,300 km total; 1,150 km paved, 6,550 km
gravel, 5,950 km improved earth, 23,650 km unimproved
earth :
Inland waterways: officially estimated to be 10,000 km
of commercially navigable waterways
Pipelines: crude oil, 1,670 km; refined products, 1,495
km; natural gas, 580 km
Ports: none (Bolivian cargo moved through Arica and
Antofagasta, Chile, and Matarani, Peru)
Civil air: 48 major transport aircraft —
Airfields: 576 total, 535 usable; 5 with permanent-surface
runways; 1 with runway over 3,660 m, 6 with runways
2,440-3,659 m, 128 with runways 1,220-2,439 m
Telecommunications: radio-relay system from La Paz to
Santa Cruz; improved international services; 55,000 tele-
phones (1.2 per 100 popl.); 122 AM, 18 FM, and 5 TV
stations ,
DEFENSE FORCES
Military manpower: males 15-49, 1,142,000; 723,000 fit
for military service; average number reaching military age
(19) annually about 60,000
Military budget: proposed for fiscal year ending 31
December .1978, $90.2 million; about 13.2% of central
government budget
LAND :
8,521,100 km?; 4% cuiltivated, 18% pasture, 23% built-on
area, waste, and other, 60% forested
Land boundaries: 13,076 km
24
Atlantic
Brasilia
BOLIVIA
(See reference map tll}
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 7,491 km
Railroads: 30,300 km total; 26,543 km meter gage (1.000
m), 3,361 km 1.60-meter gage, 194 km standard gage (1.435
m), 202 km 0.76-meter gage; 2,249 km electrified
Highways: 1,510,900 km total; 75,900 km_ paved,
1,485,000 km gravel or earth
Inland waterways: 50,000 km navigable
Ports: 8 major, 23 significant minor
Pipelines: crude oil, 2,000 km; refined products, 465 km;
natural gas, 257 km
Civil air; 118 major transport aircraft
Airfields: 4,298 total, 3,908 usable; 162 with permanent-
surface runways; 16 with runways 2,440-3,659 m, 412 with
runways 1,220-2,439 m; 18 seaplane stations
Telecommunications: fair telecom system; good radio
relay facilities; 1 Atlantic Ocean satellite station with 2
antennas; 3 domestic satellite stations; 3.99 million tele-
phones (3.5 per 100 popl.); 1,100 AM stations, 150 FM, and
175 TV stations; 2 coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 26,643,000; 17 ,338,000
fit for military service; 1,220,000 reach military age- (18)
annually :
Military budget: for fiscal year sain 31 December
1978, $2,150 million; 8.6% of central government budget
BRUNEI
LAND
5,776 km’; 3% cultivated; 22% industry; waste, urban or
other; 75% forested
Land boundaries: 381 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 161 km
Railroads: 9.6 km narrow gage (0.610 m)
Highways: 1,206 km total; 376 km paved (bituminous
treated), 402 km gravel cr stone, 428 km unimproved
Inland waterways: 209 km; navigable by craft drawing
less than 1.2 meters
Ports: 2 minor (Bandar Seri Begawan, formerly Brunei,
and Kuala Belait)
Pipelines: crude oil, 185 km; refined products, 56 km;
natural gas, 56 km; crude oil and natural gas, 241 km under
construction :
Civil air: 4 major transport aircraft
Airfields: 3 total, 3 usable; 2 with ‘permanent-surface
runway; 1 with runway over 3,660 m; 2 with runways
1,220-2,439 m
Telecommunications: service throughout country is: ade-
quate for present needs; international service good to
adjacent Sabah and Sarawak; radiobroadcast coverage good;
11,000 telephones (0.3 per 100 popl.); Radio Brunei
broadcasts from 6 AM stations and 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 41,000; 24,000 fit for
military service; about 1,900 reach military age (18)
annually
Pacific Ocean
(See reference map Il)
LAND
274,540 km? (including Galapagos Islands); 11% culti-
vated, 8% meadows and pastures, 55% forested, 26% waste,
urban, or other (excludes the Oriente and the Galapagos
Islands, for which information is not available)
Land boundaries: 1,931 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 2,237 km (includes Galapagos Is.)
{See reference map tl}
LAND
142,709 km?; negligible amount of arable land, meadows
and pastures, 76% forest, 8% unused but potentially
productive, 16% built-on area, wasteland, and other
Land boundaries: 1,561 km
196
WATER
Limits of territorial waters (claimed): 12 nm (economic
including fishing 200 nm)
Coastline: 386 km
Railroads: 166 km total; 86 km meter gage (1.00 m)
(government-owned) and 80 km narrow gage (industrial
lines); all single track |
Highways: 2,500 km total; 500.km paved, 200 km gravel,
600 km improved earth, 1,200 km unimproved earth
Inland waterways: 4,500 km; most important means of
transport; oceangoing vessels with drafts ranging from 4.2 m
to 7 m can navigate many of the principal waterways while
native canoes navigate upper reaches
Ports: 1 major (Paramaribo), 6 minor
Civil air: 1 major transport aircraft
1 Suriname guilder (S.
Airfields: 30 total, 29 usable; 2 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 2 with runways
1,220-2,489 m
Telecommunications: international facilities good; do-
mestic radio-relay system; 18,600 telephones (4.9 per 100
popl.); 6 AM, 1 FM, and 1 TV station with 4 relay
transmitters
DEFENSE FORCES
Military manpower: males 15-49, 86,000; 50,000 fit for
military service
SWAZILAND
SOUTHERN
RHODESIA','810bb2bd1fc37cbd7f7c6d4aa58c66d034543e54590399c6d8ca700fa51d9869','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('531e3a0c9fd73d95325f7ec945c80d0f52f81b9ed369a4c168f3538b500a51a5',1980,'BW','Botswana','communications',76,'Atlantic
Ocean
{See reference map Vi}
LAND .
569,800 km?; about 6% arable, less than 1% under
cultivation, mostly desert eM :
Land boundaries: 3,774 km
‘Railroads: 726 km 1.067-meter gage
Highways: 10,476 km total; 579 km paved; 1,453 km
crushed stone or gravel; 5,407 km improved earth and 3,037
km unimproved earth
Inland waterways: native craft only; of local.importance
Civil air: 2 major transport aircraft
Airfields: 83 total, 65 usable; 3 with permanent-surface
runways; 14 with runways 1,220-2,489 m
* Telecommunications: the system is a minimal combina-
tion of open-wire lines, radio-relay links, and a few
‘radiocommunication stations; Gaborone is the center; 7,900
telephones (1.2 per 100 popl.); 1 AM, 1 FM, and no TV
stations ;
DEFENSE FORCES
Military manpower: males 15-49, 142,000: 74,000 fit for
military service; 9,000 reach military age (18) annually
Indian Ocean
SOUTH AFRICA .
(See reference map Vi)
available for extensive cattle grazing; 39% European
alienated lands (farmed by modern methods), 48% African,
7% national land, 6% not alienated
Land ‘ boundaries: 3,017 km
Railroads: 3,434 km narrow gage (1.067 m); 42 km double
track
Highways: 78,428 km total; 7,995 km paved, 32,855 km
crushed stone, gravel, stabilized soil, or improved earth;
87,578 km unimproved earth (est.)
Inland waterways: 280 km. on Lake. Kariba
Pipelines: 8 km crude oil (nonoperating)
Airfields: 399 total, 392 usable; 17 with permanent-sur-
face runways; 2 with runways over 3,660 m, 3 with runways
2,440-3,659 m, 29 with runways 1,220-2,439 -m
Civil air: 11 major transport aircraft
Telecommunications: system is one of the best in Africa;
consists of radio-relay links, open-wire lines, and ‘radiocom-
munication stations; principal center Salisbury, secondary
center Bulawayo; 190,300 telephones (2.8 per 100 popl.); 8
AM, 1 FM, and 5 TV stations
DEFENSE FORCES .
Military manpower: males 15-49, 1,514,000; 928,000 fit’
for military service; average number reaching military age
(18) annually, 71,000','3eda0d3365f24a945322217c9f95aa2d31e5b9f6a46f72b41c7da095c264cbfa','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36e1d9e3cb0e72ab345394c6321b375e9d6505886fc5a1451d0bd8e87ec5863f',1980,'BI','Burundi','communications',81,'LAND
28,490 km?; about 37% arable (about 66% cultivated), 23%
pasture, 10% scrub and forest, 30% other
Land boundaries: 974 km
Railroads: none
Highways: 7,800 km total; 300 km bituminous, 2,500 km
crushed stone, gravel, or laterite, and 3,000 km improved
earth, and 2,000 km unimproved earth
Inland waterways: Lake Tanganyika navigable for lake
steamers and barges, 1 minor lake port
Civil air: 5 major transport aircraft
Airfields: 12 total, 12 usable; 1 with permanent-surface
runway; ] with runway 2,440-3,659 m
Telecommunications: sparse system of wire and low-
capacity radio-relax links; telegraph primary means of
communication; about 6,000 telephones (0.2 per 100 popl.);
2 AM, 1 FM, and no TV stations
DEFENSE - FORCES
Military manpower: males 15-49, 907,000; 469,000 fit for
military service; 45,000 reach military age (16) annually
Military budget: for fiscal year ending 31 December
1978, $21,278,000; about 17.4% of central government
budget','1e1d574f069c0ae60a24d0c59534b49aa3104c065007e86ba9cd8f00699a4088','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3f40c6efbac2374c43489b812e34e74eec2be535cf292a47dafb0fa68ff7ee3',1980,'CM','Cameroon','communications',85,'LAND
475,400 km?; 4% cultivated, 18% grazing, 13% fallow, 50%
forest, 15% other
‘Land boundaries: 4,554 km
30
CENTRAL
CAMEROON AFRICAN _EMPIRE
A) *y dé
EQUATORIAL vidio
Atlantic
Ocean
{See reference map Vi}
LAND
27,972 km?; Rio Muni, about 25,900 km?, largely forested;
Fernando Po, about 2,072 km?
Land boundaries: 539 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 296 km
59
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
EQUATORIAL GUINEA/ETHIOPIA
Railroads: none
Highways: Rio Muni—2,460 km, including approx. 185
km bituminous, remainder gravel and earth; Fernando Po—
300 km, including 146 km bituminous, remainder gravel and
earth
Inland waterways: Rio Muni has approximately 167 km
of year-round navigable waterway, -used mostly by pirogues
Ports: 2 major (Macias Nguema Biyogo, Rey Malabo), 3
minor
Civil air: 3 major transport aircraft (leased in)
Airfields: 5 total, 3 usable; 2 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 1 with runway
1,220-2,439 m
Telecommunications: fairly adequate for the size and
stage of development of the country; international commu-
nications by radio from Bata and Malabo to Cameroon,
Nigeria, and Spain; 1,700 telephones (0.5 per 100: popl.); 2
AM stations, no FM stations, and 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 89,000; 44,000 fit for
military service
Military budget: for fiscal year ending 31 December
1970, $3,475,700; 14.8% of central government budget','b71a2b42270d115d20781443c98d22832dd323ee2fb6ea57890dc81418f1b377','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26bdd1182b284f313b27c3f4f1efb49cac20ad587165eac6c13832908ea67153',1980,'GA','Gabon','communications',86,'(See reference map Vi}
WATER
Limits of territorial waters (claimed): 18 nm
Coastline: 402 km
Railroads: 1,008 km total; 858 km meter gage (1.00 m),
145 km 0.600-meter gage
Highways: approximately 29,866 km total; including
2,155 km bituminous, 27,711 km gravel and earth
Inland waterways: 2,090 km
Ports: 1 major (Douala), 3 minor
Civil air: 5 major transport aircraft
Airfields: 63 total, 60 usable; 7 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 21 with runways
1,220-2,489 m; 1 seaplane station
Telecommunications: fair telephone service; fair to good
telegraph service; 26,000 telephones (0.4 per 100 popl.); 4
AM, no FM, and no TV stations; 1 submarine cable; 1
Atlantic Ocean: satellite station
‘DEFENSE FORCES
Military manpower: males 15-49, 1,494,000; 751,000 fit
for military service; average number reaching military age
. (18) annually about 69,000
Military budget: for fiscal year ending 30 June 1978,
$62,534,667; 8.5% of central government budget-
LAND ’
264,180 km*; 75% forested, 15% savanna, 9% urban and
wasteland, less than 1% cultivated
Land boundaries: 2,422 km
WATER
Limits of territorial waters (claimed): 100 nm; fishing,
150 nm ‘
70
Atlantic
Ocean
{See reference map Vi}
Coastline: 885 km
Railroads: none
Highways: 6,797 km total; 308 km paved, 5,589 km
gravel and/or improved earth, 500 km unimproved earth
Inland waterways: approximately 1,600 km perennially
navigable
Pipelines: crude oil, 129 km
'' Ports: 3 major (Libreville, Port-Gentil, Owendo), 2 minor
Civil air: 24 major transport aircraft
Airfields: 163 total, 101 usable; 6 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 20 with runways
1,220-2,4389 m; 1 seaplane station
Telecommunications: system of open-wire, radio-relay,
tropospheric scatter links and radiocommunication stations;
1 Atlantic Ocean satellite station; 5 AM, no FM, and 3 TV
stations; 7,000 telephones (1.3 per 100 popl.)
DEFENSE FORCES
Military manpower: males 15-49, 127,000; 64,000 fit for
military service; 4,000 reach military age (20) annually
Military budget: for fiscal year ending 31 December
1978, $52,627,100; 5.1% of central government budget
THE GAMBIA
(See reference map Vi}
LAND
10,360 km?*; 25% uncultivated savanna, 16% swamps, 4%
forest parks, 55% upland cultivable areas, built-up areas, etc.
Land boundaries: 740 km
WATER
Limits of territorial waters (claimed): 50 nm
Coastline: 80 km
Railroads: none
Highways: 1,858 km total; 190 km_ bituminous-surface
treated, 1,330 km gravel/laterite, remainder unimproved
earth
Inland waterways: 605 km
Ports: 1 major (Banjul)
Civil air: no major transport aircraft
Airfields: 1 usable with permanent-surface runway
2,440-3,659 m; 1 seaplane station (non-operational)
Telecommunications: adequate network of radio-relay;
2,700 telephones (0.5 per 100 popl.); 1 AM station, 1 FM
station, and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 131,000; 66,000 fit for
military service
.GERMAN DEMOCRATIC REPUBLIC
{See reference map IV}
LAND
108,262 km?; 43% arable, 15% meadows and pasture, 27%
forested, 15% other
Land boundaries: 2,309 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 901 km (including islands)
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
a ee Ry
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
GERMAN DEMOCRATIC REPUBLIC
Railroads: 14,215 km total; 13,906 km standard gage
(1.4385 m), 309 km meter (1.00 m) or other narrow gage,
2,971 km double track standard gage (1.435 m); 1,511 km
overhead electrified (1977)
Highways: 127,530 km total; 47,530 km concrete, asphalt,
stone block, of which 1,679 km are autobahn and limited
access roads; over 80,000 km asphalt treated, gravel, crushed
stone, and earth (1976)
Inland waterways: 2,546 km (1978)
Freight carried: rail—298.6 million metric tons, 52.1]
billion metric ton/km (1977); highway—714.1 million
73
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
GERMAN DEMOCRATIC REPUBLIC/GERMANY, FEDERAL REPUBLIC OF
metric tons, 18.4 billion metric ton/km (1976); waterway—
14.0 million metric tons, 2.0 billion metric ton/km (excl.
int''l. transit traffic) (1977); approximately 1,410 waterway
craft with 570,000 metric ton capacity (1978)
Pipelines: crude oil, 1,075 km; refined products, 350 km;
natural gas 483 km
Ports: 4 major (Rostock, Wismar, Stralsund, Sassnitz), 13
minor; principal inland waterway ports are E. Berlin, Riesa,
and .Magdeborg (1978) .
DEFENSE FORCES
Military budget: announced for fiscal year ending 31
December 1978, 11.6 billion marks; about 8.9% of total
budget
GERMANY, FEDERAL REPUBLIC OF
(See reference map iV)
LAND
248,640 km? (including West Berlin); 33% cultivated, 23%
meadows and pastures, 13% waste or urban, 29% forested,
2% inland water
Land boundaries: 4,232 km
WATER :
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 1,488 km (approx.)
Railroads: 33,453 km total; 29,082 km government-
owned, standard gage (1.435 m), 12,491 km double track;
9,760 km electrified; 4,421 km non-government owned;
3,997 km standard gage (1.435 m); 214 km electrified; 424
km meter gage (1.00 m); 186 km electrified
Highways: 398,720 km total; 161,400 km classified,
includes 153,160 km cement-concrete, bituminous, or stone
block (includes 5,792 km of autobahnen); 8,240 km gravel,
crushed stone, improved earth; in addition, 237,320 km of
unclassified roads of various surface types :
Inland waterways: 5,222 km of which almost 70% usable
by craft of 990 metric-ton capacity or larger
Pipelines: crude oil, 1,931 km; refined products, 1,942
km; natural gas, 95,414 km
Ports: 10 major, 11 minor
Civil air: 181 major transport aircraft (including 9 leased
out)
Airfields: 421 total, 382 usable; 213 with permanent-
surface runways; 3 with runways over 3,660 m, 33 with
runways 2,440-3,659 m, 40 with runways 1,220-2,439 m
Telecommunications: highly developed, modern tele-
communication service to all parts of the country; fully
adequate in all respects; 21.2 million telephones (34.4 per
100 popl.); 90 AM, 129 FM, and 2,350 TV stations; 6
submarine cables; satellite station with 1 Indian Ocean and 2
Atlantic Ocean antennas, and symphonie antenna
DEFENSE FORCES
Military manpower: males 15-49, 15,796,000; 13,054,000
fit for military service; 513,000 reach military age (18)
annually ; ,
Military budget: for fiscal year ending 31 December
1979, $19,130 million; about 18% of the proposed central
government budget
(See reference mep V)
LAND
964 km? (Sao Tome, 855 km? and Principe, 109 km?;
including small islets of Pedras Tinhosas)
WATER .
Limits of territorial waters: 6 nm (fishing 12 nm)
Coastline: estimated 209 km
Ports: 1 major (Sao Tome)
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
SAO TOME AND PRINCIPE/SAUDI ARABIA
Civil air: 1 ‘major transport aircraft
Airfields: 4 total, 4 usable; 2 with permanent-surface
runways; 2 with runways 1,220-2,439 m
Telecommunications: minimal system; 750 telephones
(1.0 per 100 popl.); 2 AM, 1 FM, and no TV stations
4','ddeb043196f52e01c26f112762088b257eb44e4fd93bab313cdc065fd914fd08','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6574602c05e2a95cfdbb61523f9ec6c6b81391e59072c222c84fcb6cbaca1097',1980,'CA','Canada','communications',90,'10 Arctic Ocean
(See reference map |}
LAND
9,971,500 km!; 4% cultivated, 2% meadows and pastures,
44% forested, 42% waste or urban, 8% inland water
Land boundaries: 9,010 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm)
Coastline: 90,908 km
Railroads: 71,503 km total; 70,141 km standard gage
(1.435 m) (43 km electrified); 1,183 km 1.067-meter gage (in
Newfoundland); 179 km 0.914-meter gage
Highways: 829,325 km total; 640,850 km_ surfaced
(189,800 km paved), 188,475 km earth
Inland waterways: 3,000 km
Pipelines: oil, 23,564 km total crude and refined; natural
gas, 74,980 km
Ports: 19 major, 300 minor
Civil air: 551 major transport aircraft
Airfields: 1,801 total, 1,452 usable; 298 with permanent-
surface runways; 4 with runways over 3,659 m, 29 with
runways 2,440-3,659 m, 285 with runways 1,220-2,439 m; 58
seaplane stations
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
an KR AD Pt AR AA ATA RE
A A OMA
i i in
i 1 ee
bid
Side dl
SS a, a A re Oe ee ee ye ee, ee ee Oe ee ee a a ee
eS ey ee ee re en eg ONE ae > ae ae ee ee? ee.
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
CANADA/CAPE VERDE
Telecommunications: excellent service provided by mod-
ern telecom media; 13.8 million telephones (60.4 per 100
popl.); countrywide AM, .FM, and TV coverage including
630 AM, 80 FM, and 500 TV stations; 8 coaxial submarine
cables; 3 major COMSAT stations and 70 domestic COMSAT
stations
DEFENSE FORCES
Military manpower: males 15-49, 6,201,000; 5,332,000 fit
for military service; average number reaching military age
(17) annually 235,000
Military’ budget: proposed for fiscal year ending 31
March 1979, $3.47 billion; about 8.3% of proposed central
government budget
CAPE VERDE
CAPE VERDE
o
Atlantic Ocean
(See reference map (IV)
LAND
4,040 km?, divided among 10 islands and several islets
WATER
Limits of territorial waters: 100 nm
Coastline: 965 km
Ports: 1 major (Mindelo), 3 minor
Civil air: 2 major transport aircraft
Airfields: 6 total, 6 usable; 4 permanent-surface runways;
1 with runway 2,440-3,659 m, 4 with runways 1,220-2,439
m; 1 seaplane station
Telecommunications: interisland radio-relay system, HF
radio to mainland Portugal, about 1,600 telephones (0.3 per
100 popl.); 1 FM and 5 AM stations; 2 coaxial submarine
cables
33
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
CAPE VERDE/CENTRAL AFRICAN EMPIRE
DEFENSE FORCES
Military manpower: males 15-49, 77,000; 43,000 fit for
military service -
Military budget: for fiscal year including 31 December
1978, $3 million; about 5% of central government budget
CENTRAL AFRICAN EMPIRE
CoS
(See reference map Vi}
LAND
626,780 km’; 10%-15% cultivated, 5% dense forests,
80%-85% grazing, fallow, vacant arable land, urban, waste
Land boundaries: 4,981 km
Railroads: none
Highways: 21,950 km total; 290 km bituminous, 7,500 km
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
|
¢
i
§
¢
:
TN AA
a a A i i rt all i
i i i i a i er ia at a in ii a an A A A i ne i a a ne ae nee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
CENTRAL AFRICAN EMPIRE/CHAD
gravel and/or crushed stone, 14,160 km improved earth,
remainder unimproved earth
Inland waterways: 7,080 km; traditional trade carried on
by’ means of dugouts on the extensive system of rivers and
streams; the Oubangui River between Bangui and Brazza-
ville is navigable for about 8 months a year, and short
sections of the Sangha and the Lobaye Rivers are navigable
throughout year; during high-water period (July-December)
Oubangui navigable upstream from Bangui as far as Quango
Ports: Bangui, Ouango (river ports)
Civil air: 4 major transport aircraft
Airfields: 54 total, 46 usable; 3 with permanent-surface
runways; 1] with runway 2,440-3,659 m, 18 with runways
1,220-2,489 m
Telecommunications: facilities are meager; network is
composed of low-capacity, low-powered radiocommunica-
tion stations and radio-relay links; 5,540 telephones (0.3 per
100 popl.); 1 AM station, 1 FM station, and 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 427,000; 222,000 fit for
military service
Supply: mainly dependent on France, but has received
equipment from Israel, Italy, U.S.S.R., and FRG
Military budget: for fiscal year ending 31 December
1977, $7.5 million (current budget only); about 10.6% of
central government current budget
CAMEROON ’ , ae
bad
eo be
i-_
|
(See reference map Vi}
LAND ;
1,284,640 km*; 17% arable, 835% pastureland, 2% forest
and scrub, 46% other uses and waste
Land boundaries: 5,987 km
Railroads: none
Highways: 27,505 km total; 242 km bituminous, 4,385 km
gravel and laterite, and remainder unimproved
Inland waterways: approximately 2,090 km of year-
round navigability, increased to 4,830 km during high-water
period ,
Civil air: 4 major transport aircraft
Airfields: 67 total, 62 usable; 4 with permanent-surface
runways; | with runway 2,440-3,659 m, 22 with runways
1,220-2,489 m
Telecommunications: fair system of radiocommunication
stations only for intercity links; principal center N''Djamena,
secondary center Sarh; 5,480 telephones (0.1 per 100 popl.);
1 AM, no FM, and no TV stations; 1 Intelsat Comsat station
DEFENSE FORCES
Military manpower: males 15-49, 999,000; 518,000 fit for
military service; average number reaching military age (20)
annually about 41,000
Supply: dependent on France primarily
Military budget: for fiscal year ending 31 December
1977, $22.2 million; about 38% of total budget','43c2b96d35f92023d85dd7c4039097922b20b7181b2036c0d59d6b15e4a56614','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b550b8c89222117cfa1046e6e35da36f893c709d42f3102bee3cfb49c63c8fb',1980,'CL','Chile','communications',94,'LAND
756,626 km?; 2% cultivated, 7% other arable, 15%
36
g BOLIVIA
Pacific
{See reference map “My
permanent pasture, grazing, 29% forest, 47% barren
mountains, deserts, and cities
Land boundaries: 6,325 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 6,435 km
Railroads: 6,361 km total; 3,111 km 1.676-meter gage,
185 km standard gage (1.435 m), 3,115 km meter gage
(1.00 m)
Highways: 75,200 km total; 9,000 km paved, 38,200 km
gravel, 28,000 km improved and unimproved earth
Inland waterways: 725 km
Pipelines: crude oil, 755 km; refined products, 785 km;
natural gas, 320 km
Ports: 10 major, 20 minor
Civil air: 33 major transport aircraft
Airfields: 355 total 346 usable; 46 with permanent-
surface runways; 8 with runways 2,440-3,659 m, 52 with
runways 1,220-2,439 m; 6 seaplane stations
Telecommunications: modern telephone system based on
extensive radio relay facilities; 473,000 telephones (4.5 per
100 popl.); 1 Atlantic Ocean satellite station; 180 AM, 30
FM, and 56 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 2,717,000; 2,048,000 fit
for military service; average number reaching military age
(19) annually about 116,000
37
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
CHILE/CHINA
Military budget: for fiscal year ending 31 December
1978, US$732.6 million; about 26% of central government
budget
Valparaiso
Santi o*
Concepcién
503083 1-79
Declassified and Approved For Release 2012/09/02 : CIA-RDP0Q8-00534R000100140001-7
Fr
*Cardeas
a:','20cea8eff800c0bf2a44441da774704e818c46a0fef79ee38663fe9d9ef6725d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30c05316984c733fde04894f73045e68165408f7cb707ff6046ef815ff8e5b34',1980,'CN','China','communications',98,'{See reference map Vil}
LAND
9.6 million km?; 11% cultivated, sown area extended by
multicropping, 78% desert, waste, or urban (32% of this area
consists largely of denuded wasteland, plains, rolling hills,
and basins from which about 3% could be reclaimed), 8%
forested; 2%-3% inland water
Land boundaries: 24,000 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 14,500 km
Railroads: networks total about 45,000 route km com-
mon-carrier lines; about 600 km meter gage (1.00 m); rest -
standard gage (1.435 m); all single track except 9,000 km
double track on standard gage lines; approximately 1,025 km
electrified; about 9,700 km industrial lines (gages range from
0.59 to 1.485 m)
Highways: about 835,000 km all types roads; almost half
(about 300,000 km) unimproved natural earth roads and
tracks; about 215,000 km improved earth roads about 2- to
5-meters wide and in poor to fair condition; remainder
(about 260,000 km) includes maiority. of principal roads
Ports: 10 major, 180 minor
Airfields: 379 total; 9 with runways 3,500 m and over: 45
with runways 2,500 to 3,499 m; 187 with runways 1,200 to
2,499 m; 124 with runways less than 1,200 m; 2 seaplane
stations; 12 airfields under construction, of these, 249 have
permanent surface runways
Telecommunications: urban and industrial areas served
by reasonably adequate facilities for domestic and interna-
tional communication needs; facilities) being expanded;
effective broadcast coverage is provided by radio, extensive
wired-broadcast networks, and an expanding TV network;
estimated 5 million telephones, 45 million radio receivers,
140 million wired-speakers and est. 500,000 TV receivers;
250 AM, 7 FM, and 120 TV transmitter and rebroadcast
stations; 3 standard international communications satellite
ground stations; coaxial cable links Canton to Hong Kong;
submarine cable links Shanghai to Japan; additional subma-
rine cables planned
DEFENSE FORCES
Military manpower: males 15-49, 233,823,000, about
130,711,000 fit for military service; about 9,635,000 reach
military age (18) annually
TAIWAN
Taipei
TAIWAN
South China
Sea PHILIPPINES
2 coe
(See reference mep Vil} ,
LAND
32,260 km? (Taiwan and Pescadores); 24% cultivated, 6%
pasture, 55% forested. 15% ,other (urban, industrial, de-
nuded, water area)
WATER
Limits of territorial waters (claimed): 3 nm (fishing 12
nm)
Coastline: 990 km Taiwan, 459 km offshore islands
Railroads: about 1,000 km common-carrier and 3,500 km
industrial lines, all on Taiwan; common-carrier lines consist
of West System: 825 km meter gage (1.00 m) with 325 km
double track, complete line under construction for electrifi-
cation; East Line: 175 km narrow gage (0.762 m) (presently
under construction to convert to meter gage compatible with
‘West System); common-carrier lines owned by government
and operated by Railway Administration (TRA) under
Ministry of Communications; industrial lines owned and
operated by government enterprises
Highways: network totals 16,900 km (construction of
North-South Freeway approximately 84%—250 km—com-
plete), plus 483 km on Penghu and offshore islands; 7,564
km paved, 6,276 km gravel and crushed stone, 2,736 km
earth
Pipelines: 615 km refined products, 97 km natural gas
Ports: 5 major, 5 minor :
Airfields: 39 total, 37 usable; 27 with permanent-surface
runways; 2 with runways over 3,659 m, 12 with runways
2,440-3,659 m, 10 with runways 1,220-2,439 m; 1 seaplane
station
DEFENSE FORCES
Military manpower: males 15-49, 4,248,000; 3,426,000 fit
for military service; about 199,000 currently reach military
age (19) annually
Military budget: for fiscal year ending 30 June 1978,
$1,814.7 million including personnel costs; about 52.5% of
central government budget
Railroads: 4,535 km total operating in 1976; 3,870 km
standard gage (1.435 m), 665 km narrow gage (0.762 m); 259
km double tracked; about 1,140 km electrified; govern-
ment-owned
Highways: about 20,280 km (1976); 98.5% gravel, crushed
stone, or earth surface: 1.5% concrete or bituminous
Inland waterways: 2,253 km; mostly navigable by small
craft only
Ports: 6 major, 26 minor
DEFENSE FORCES
Military manpower: males 15-49, 3,905,000; 2,392,000 fit
for military service; 192,000 reach military age (18) annually
Military budget: announced for fiscal -year ending 31
December 1978, $1.27 billion; about 16% of total govern-
ment budget
KOREA, SOUTH
(See reference map Vil)
LAND
98,400 km?*; 23% arable (22% cultivated), 10% urban and
other, 67% forested
Land boundaries: 241 km
KOREA, NORTH/KOREA, SOUTH
WATER
Limits of territorial waters: 12 nm
Coastline: 2,413 km
January 1979
Fiscal year: calendar year
Freight carried: rai] (1976) 9.2 billion metric ton/km,
43.6 million metric tons; highway 21.8 million metric tons;
air (1959) 361,184 kg carried
Pipelines: 515 km refined products
Ports: 10 major, .18 minor
-Civil air: 28 major transport aircraft
Airfields:. 120 total, 114 usable; 55 with permanent-
surface runways; 15 with runways 2,440-3,659 m, 16 with
runways 1,220-2,439 m
DEFENSE FORCES
Military manpower: males 15-49, 9,741,000; 6,340,000 fit
for military service; average number reaching military age
(18) annually 416,000
Military budget: proposed for fiscal year ending 31
December 1979, $3.2 billion; about 88. 2% of central
goyernment | budget
Ch''eng-tu
Hsi-an
* (Sian)
eK''un-ming
Yogyakarta
: CIA-RDPO8-0
VII
gv akutsk
habarovsk
‘.
Ha-erh-pin,
(Harbin)
Shen-yang, aaa
y ,f&,, P''ySngyang
sedift,
Dy. .
Sovth
area
Chiing-tao § ;
{Tsingtao} 5
- “DShang-hai
oWurhan
Kuang-cho
} ‘aipei
Taiwan
Luzon
ton Philippines
Ss Ppp
Brunei pgahd
(LK.','2561ab7f6f55894bdf70105c50b077270abb2927559c71eb20bfdf8a0dff8289','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('879c9a0115a34a9b0edd99b330d925c6496dff3ed8d40e4a94dafc11a6f3c717',1980,'CO','Colombia','communications',102,'LAND
1,139,600 km?; settled area 28% consisting of cropland and
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
7 an
A i A AR AA A Ae A TR an
ee) ee, wweew a errs
Ee ee a ee ee ee Se ee a ee ee ee ee ee a, ee ee ee ae See wr VEU lUDE
eS ee ee
ee ee
ON RE 5 Rm aT OE Na I ON ONE ee ea ee a
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
» Bogota
COLOMBIA ~
Pacific ¢
Ocean BRAZIL -
(See reference map til)
fallow 5%, pastures 14%, woodland, swamps, and water 6%,
urban and other 8%; unsettled area 72%—mostly forest. and
savannah
Land_ boundaries: 6,085 km
WATER
Limits of territorial waters (claimed): 12 nm (economic
including fishing 200 nm)
Coastline: 2,414 km
Railroads: 3,436 km, all 0.914-meter gage, single track, 35
km electrified ,
Highways: 52,100 km total; 8,200 km paved, 43,900 km
gravel and earth
Inland waterways: 14,300 km, navigable by river boats
Pipelines: crude oil, 3,585 km; refined products, 1,350
km; natural gas, 830 km; natural gas liquids, 125 km
Ports: 5 major, 5 minor
Civil air: 79 major transport aircraft
Airfields: .674 total, 673 usable; 44 with -permanent-
surface runways; 1 with runway over 3,660 m; 5 with
runways 2,440-3,659 m, 88 with runways 1,220-2,439 m; 11
seaplane stations :
Telecommunications: nationwide radio-relay system; 1
Atlantic Ocean satellite station; 1.34 million telephones (5.5
per 100 popl.); 325 AM, 130 FM, and 48 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 5,857,000, 3,833,000 fit
for military service; average number reaching military age
(18) annually about 297,000
’ Military budget: proposed for fiscal year ending 31
December 1978, $181.8 million; about 7.7% of ecatral
government budget
(See reference map ti}
LAND
1,020 km’; 5% arable, 95% waste, urban, or other
WATER
Limits of territorial waters (claimed): 3 nm
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Lye SS ary
* — Rg a wn ann =
ee - iy
ee ee ee
DB;
eee
cee I aN RS ae ee ee a ee ee
EE I ee ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
NETHERLANDS ANTILLES
Coastline: 364 km
Railroads: none
Highways: 700 km total; 500 km paved, 200 km gravel
and earth
Ports: 3 major (Willemstad, Oranjestad, Caracasbaai,
Civil air: 12 major transport aircraft (including 4 leased
in)
Airfields: 7 total, all usable; 7 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 2 with runways
1,220-2,489 m; 1 seaplane station
149
Declassified and Approved For Release 2012/09/02 : CIA-RDP0O8-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
NETHERLANDS ANTILLES/NEW CALEDONIA
Telecommunications: generally adequate telecom facili-
ties; extensive interisland radio-relay links; 48,000 telephones
(19.9 per 100 popl.); 11 AM, 1 FM and 5 TV stations; 2
submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 57,000; 33,000 fit for
military service; about 2,000 reach military age (20)
annually
Defense is responsibility of the Netherlands
Pacific Ocean
(See reference map tl}
LAND
75,650 km? (excluding Canal Zone, 1,430 km?); 24%
agricultural land (9% fallow, 4% cropland, 11% pasture),
20% exploitable forest, 56% other forests, urban, and waste
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979 -
Brazil °
CIA-RDP08-00534R000100140001-7
a
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
f Fauite
{ Ecuador
Guayaqaily, Y
{ Iquitos,
South
Antofagastar -
Pacific
Ocean','4ad3c7f4276769dd216f9e9e8344a7ed063f28ba6447b92b7b3dbeee501089f5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4af37a5c02480c05e62d2c17405922d28a3525a092c375e6b5953837500096f',1980,'KM','Comoros','communications',106,'LAND
2,170 km?; 4 main islands; forests 16%, pasture 7%,
cultivable area 48%, non-cultivable area 29% ~
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm); 200 nm exclusive economic zone
Coastline: 340 km
Railroads: none
Highways: 999 km total; approximately 295 km bitumi-
nous, remainder crushed stone or gravel
Ports: 1 minor (Moroni on Grande Comore)
Civil air: 3 major transports (2 registered in France)
Airfields: 5 total, 5 usable; 5 with permanent surface
runways: 1 with runway 2,440-3,659 m, 4 with runways
1,220-2,489 m
Telecommunications: sparse system of HF radiocom-
munication stations for interisland, island and external
communications to Malagasy and Reunion; 1,100 telephones
(0.3 per 100 popl.); 2 AM, 1 FM, and no TV stations
CENTRAL
AFRICAN EMPIRE
Atlantic
Ocean
(See reference map VI}
LAND F
349,650 km?; 63% dense forest or woodland, 33%
cultivable or grazing (2% cultivated est.), 4% urban or waste
Land boundaries: 4,514 km
WATER
Limits of territorial waters (claimed): 30 nm
Coastline: 169 km
Railroads: 800 km, 1,067-meter gage, single track
Highways: 8,246 km total; 555 km bituminous surface
treated; 848 km gravel, laterite, 1,623 km improved earth,
and 5,220 km unimproved roads
Inland waterways: 6,485 km _ navigable
Pipelines: crude oil 25 km
Ports: 1 major (Pointe Noire)
Civil air: 4 major transport aircraft (including 1 leased in)
Airfields: 68 total, 51 usable; 3 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 20 with runways
1,220-2,489 m; 1 seaplane station
Telecommunications: services adequate for government
use; network is comprised of low-capacity, low-powered
radiocommunication stations, coaxial cables and wire lines;
key centers are Brazzaville, Pointe-Noire, and Loubomo;
10,500 telephones (0.7 per 100 popl.); 3 AM stations, 1 FM
station, and 1 TV station; 1 Atlantic Ocean COMSAT station
DEFENSE FORCES
Military manpower: males 15-49, 323,000; 164,000 fit for
military service; about 14,000 reach military age (20)
annually
Military budget: for fiscal year ending 31 December
1976, $37,517,400; about 17% of central government budget
44
gMoroni
r)
y Antananarivo
Namibia Mauritius
South Atrica }
) *
{Walvis Bay) | Windhoek] Gaborone
Port Louis.
Pe aiid
Reunion
Botswana (Fe)
‘A Pretoria
: Mbabane(“}
Swaziland
Maputo
" Moserus 4
\\, South Africa Ngsotho
Ca pe Town}
1000 Kilometers
500 1000 Miles
Boundary representation is
not necessarily authoritative
503986 1-79
Declassified and Approved For Release 2012/09/02
: CIA-RDPO8-00534R000100140001-7
\\
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
‘ tp Greenland
7 rv (Denmark)
Iceland e. .. &
K he
aKuybyshev es verdiovsk
Volgograd
. Omsk
Novosibirsk
C= f }
eTashkent Fey
Wu-lu-mu-ch’t
(Uru mehi)
\\ aa ladian claim
Ss :
Saudi
Arabia
j=
vemen \\.
(Adon) ¢','3234049d09967375d9371aa9674aade06f6282b5ede0e63559e36f32d9af686e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('884aac3f73be433292cbb2156d6adbcaf24ec67122b3b50eb9cccd8774770ffe',1980,'CK','Cook Islands','communications',112,'Pacific Ocean
* COOK
ISLANDS
(See reference map Vill}
LAND
About 240 km?
WATER
Limits of territorial waters: 3 nm
Coastline: about 120 km
Railroads: none
Highways: 187 km total (1977); 835 km paved, 35 km
gravel, 84 km improved earth, 33 km unimproved earth
Inland waterways: none
Ports: 2 minor
Civil air: no major transport aircraft
Airfields: 6 total, 5 usable; 1 with permanent-surface
runway 2,317 m, 1 with natural surface runway; 1 seaplane
station
Telecommunications: 6 AM, no FM, and no TV stations;
7,000 radio receivers, and 956 telephones
‘jew Zealand)
Ce: ‘sRennell
mans, Western US.)
INDIAN ee N rii Samee (| Page
. : \\ °c Ss f
OCEAN Santo « Ful tsLanDS> po,
New Hebrides >* Vonua Levu? — {j Tonga eC
(Angle Freeh Condoninion) sPapeete
, Tsu Qo: Nive : Pe rabiti
{
. 1
New* QL: a
oatedini Se : Fiurvatotal Rosine!
New Caledonia Gb |. les Gambier
(Fr) : ; sont
‘ Polynesia ee: aT
B)) Pitcairn Islands
WK)
SOUTH OCEA
==
N
| Rapa’ .
{
{
\\
t
New
Zealand North Island
Tasmania
lobart
féllington
<= = Line of separation
{not a formal international
2 South Island boundary or territorial limit) «
1090 Kilom
Invercargill : 6 860 1000 Mites
Boundary representation is
not necessarily authoritative
503988 1-79
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7 |','023837f3bf5937ab197c602a865b920f888ef50191e8854f35af2793248baf3d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7d4b9c6245339c790004c9759e2dfb25680817af97afd0c104836ecd44de364',1980,'CR','Costa Rica','communications',116,'LAND ;
51,000 km?; 30% agricultural land (8% cultivated, 22%
meadows and pasture), 60% forested, 10% waste, urban, and
other
Land boundaries: 670 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; specialized competence over living resources to 200 nm)
Coastline: 1,290 km
Railroads: 563 km 1.067-meter gage, all single track, 115
km electrified
Highways: 26,050 km total; 2,000 km paved, 15,900 km
gravel 8,150 km unimproved earth
Inland waterways: about 730 km perennially navigable
46
Pipelines: refined products, 318 km
Ports: 3 major (Limon, Golfito, Puntarenas), 4 minor
Civil air: 18 major transport aircraft
Airfields: 196 total, 189 usable; 29 with permanent-
surface runways; | with runway 2,440-3,659 m; 9 with
runways 1,220-2,489 m; 2 seaplane stations
Telecommunications: good domestic telephone service;
127,000 telephones (6.2 per 100 popl.); connection into
Central American microwave net; 55 AM, 10 FM, and 12
TV stations
DEFENSE FORCES
Military manpower: males 15-49, 514,000; 336,000 fit for
military service; average number reaching military age (18)
annually about 26,000
Supply: dependent on imports from U‘S.
Military budget: for fiscal year ending 31 December
1978, $16.2 million for Ministry of Public Security, including
the Civil Guard; about 3% of total central government
budget
j ; Atlantic
of Mexico f Ocean
THE
Havana \\ {BAHAMAS
S
CUBA :
JAMAICA eS
Caribbean Sea
{See reference map tl}
LAND
114,478 km*; 35% cultivated, 30% meadow and pasture,
20% waste, urban, or other, 15% forested
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm); 200 nm exclusive economic zone
Coastline: 3,735 km
Railroads: 14,640 km total, government-owned; 5,040 km
common-carrier lines of which 4,960 km standard gage
(1.4385 m), 80 km 0.914-meter gage; about 9,600 km
plantation/industrial lines, 6,400 km standard gage (1.435
m), 3,200 km narrow gage
Highways: 20,700 km total; 8,800 km paved, 11,900 km
gravel and earth surfaced
Inland waterways: 240 km
Pipelines: natural gas, 80 km
Ports: 8 major (including U.S. Naval Base at Guantan-
amo), 44 minor; Guantanamo under U.S. control
Civil air: 87 major transport aircraft
Airfields: 193 total, 182 usable; 48 with permanent-
surface runways; 1 with runway over 3,660 m, 8 with
runways 2,440-3,659 m, 25 with runways 1,220-2,439 m; 10
seaplane stations
Telecommunications: modern facilities adequately serve
military, governmental, and some civilian needs; excellent
international facilities via HF and satellite; 380,000 tele-
phones (3.9 per 100 popl.); 100 AM, 25 FM, and 24 TV
stations; 4 submarine cables
DEFENSE FORCES
Military budget: for fiscal year ending 31 December
1978, $949 million; about 8.6% of total budget -','d23aa92c90b8da120e8bc2f3478e2de5c75663720f3dad204b1aa94ee3e1db98','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a972714c5f7cf99a87a730c968f3219349e835fd527e0ad45ecdf7fa94e17e24',1980,'CY','Cyprus','communications',120,'LAND
9,251 km?; 47% arable and land under permanent crops,
47
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
NCES
Mediterranean
{See reference map V)
18% forested, 10% meadows and pasture, 25% waste, urban
areas, and other
WATER
Limits of territorial waters (claimed): 12 nm
Railroads: none
Highways: 9,710 km total; 4,580 km bituminous surface
treated; 5,180 km gravel, crushed stone, and earth
Ports: 3 major (Famagusta, Larnaca, Limassol), 6 minor;
Famagusta under Turkish control
Civil air: 6 major transport aircraft (including 4 leased in)
Airfields: 13 total, 12 usable; 8 with permanent-surface
‘runways; 3 with runways 1,220-2,439 m; 4 with runways
2,440-3:656 m
Telecommunications: moderately good telecommunica-
tion system in both Greek and Turkish sectors; 77,000
telephones (11.2 per 100 popl.); 12 AM, 4 FM, and 7 TV
stations; tropospheric scatter circuits to Greece and Turkey;
2 submarine coaxial cables
DEFENSE FORCES
Military manpower: males 15-49, 158,000; 111,000 fit for
military service, about 7,000 reach military age (18)
annually
Military budget: for fiscal year ceeaaing 31 December
1978, $43.2 million about 18% of central government budget .
CZECHOSLOVAKIA
LAND ;
127,946 km’; 42% arable, 14% other serial 85%
forested, 9% other
Land boundaries: 3,540 km','7bf7d7bdac8fee313d9860547b913a441041aef0b7fecc650cb7d2231c9e56f6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc0fe80d26f0c3b5b1aa0af84a2ad7b592fa6e4349c9828f4a0be113ba240d06',1980,'DK','Denmark','communications',126,'{See reference mep iV}
LAND
42,994 km? (exclusive of Greenland and Faroe Islands);
64% arable, 8% meadows and pastures, 11% forested, 17%
other
Land boundaries: 68 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm) ;
Coastline: 3,879 km
Railroads: 2,591 km standard gage (1.435 m); Danish
State Railways (DSB) operate 2,101 km (1,999. km rail line
and 102 km rail ferry services); 97 km electrified, 730 km
double tracked; 490 km of standard gage lines are
privately-owned and operated
Highways: approximately 66,482 km total; 64,551 km
concrete, bitumen, or stone block; 1,931 km gravel, crushed
stone, improved earth
Inland waterways: 417 km
Pipelines: refined products, 418 km
Ports: 16 maior, 44 minor
Civil air: 66 major transport aircraft, including 1 leased in
and 4 leased out
Airfields: 179 total, 136 usable; 23 with permanent-
surface runways; 9 with runways 2,440-3,659 m, 6 with
runways 1,220-2,489 m; 1 seaplane station
52
Telecommunications: excellent telephone, telegraph, and
broadcast services; 2.53 million telephones (48.9 per 100
popl.); 6 AM, 13 FM, and 34 TV stations; 14 submarine
coaxial cables
DEFENSE FORCES
Military manpower: males 15-49, 1,250,000; 1,096,000 fit
for military service; 39,000 reach military age (20) annually
Military budget: proposed for fiscal year ending 31
December 1979, $1,289 million; about 7% of proposed
central government budget','a13a89d72144e03ed7046d75e1c8eb8f932577e039bc61d4c292a6f4c318c1bf','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('073af71aa05c4997bb03729a8dcb7c96119616651154ddc05c7cb212f71a6425',1980,'DJ','Djibouti','communications',130,'(formerly French Territory of the Afars
and Issas)
THIOPIA .
23,310 km?; 89% desert wasteland, 10% permanent
pasture, and less than 1% cultivated
Land boundaries: 517 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 314 km (includes offshore islands)
PEOPLE i
Population: 180,000 (official estimate for 1972)
Nationality: noun—Afar(s), Issa(s); adjective—Afar, Issa
{See reference map Vi)
Ethnic divisions: (approximate figures) 96,300 Somalis,
mostly Issas (large number of the Somalis are temporary
immigrants from Somalia, not citizens of territory), 90,500
Afars, 6,000 Arabs, 7,000 French (inclusive of French
military forces)
Religion: 94% Muslim, 6% Christian
Language: Somali, Afar, French, Arabic, all widely. used
Literacy: about 5%
Labor force: a small number of semiskilled laborers at
port
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
DJIBOUTI/DOMINICA
Organized labor: some 3,000 railway workers organized
Railroads: 97 km meter gage (1.00 m)
Highways: 770 km total; 220 km paved, 550 km
improved earth
Ports: 1 major (Djibouti)
Airfields: 8 total, 8 usable; 1 with permanent-surface
runway; 1 with runway. 2,440-3,659 m, 4 with runways
1,220-2,489 m
Civil air: 1 major transport aircraft (leased in)
Telecommunications: fair system of urban facilities in
Djibouti and radiocommunication stations at outlying places;
3,600 telephones (2.0 per 100 popl.); 1 AM, no FM, and 1 TV
station
DEFENSE FORCES
Military manpower: males 15-49, about 43,000; about
25,000 fit for military service
Defense is responsibility of France','1fb1a7527851d4cdaa679eeb316a924c1ee9dd5adf390d9bd734cf958a308f84','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ab4d5a2a0bd62fae46ba0479ca6c36b91f1081ac7f671d08ffedfeacbc6bf8f',1980,'DM','Dominica','communications',133,'Atlantic”
re
DOMINICAY
Caribbean Sea
{See reference map tt}
LAND
790 km?; 24% arable, 2% pasture, 67% forests, 7% other
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 148 km
Railroads: none .
Highways: 750 km total; 500 km paved, 250 km gravel
and earth
Ports: 2 minor (Roseau, Portsmouth)
’ Civil air: no major transport aircraft
Airfields: 1 with asphalt runway 1,472 m
Telecommunications: 3,600 telephones in fully automatic
network (4.8 per 100 popl.); VHF and UHF link to St. Lucia;
1 AM and 1 TV station
&
Fi Barbados
oGrenata
4 7
-F3Trinidad and Tobago
aes
‘Georgetown
SES','50ef27bf9fc26d5bc6fc9857e4f7eb9acfc68ff7f89f96f1d34dcc57704d50d8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be016fea548521d3a4442cb8746a1416a234986e2c9d059be3a3823ca026baf6',1980,'DO','Dominican Republic','communications',137,'LAND
48,692 km?; 14% cultivated, 4% fallow, 17% meadows and
pastures, 45% forested, 20% built-on or waste
Land boundaries: 36] km
WATER
Limits of territorial waters (claimed): 6 nm (fishing 200
nm); 200 nm exclusive economic zone
54
Atlantic
Ocean
DOMINICAN
BAe ;
a es mat]
i—)
Sn Sant
JAMAICA * Domingo
Caribbean Sea
VENEZUELA’
(See reference mep tl}
Coastline: 1,288 km
Railroads: 1,600 km total; 104 km government-owned
common-carrier 1.065-meter gage; 1,496 km_ privately
aa
owned plantation lines of 4 different gages ranging from
0.60 m to 1.43 m, 0.760-meter gage predominating
_ Highways: 11,400 km total; 5,800 km paved, 5,600 km
gravel and’ improved earth
Pipelines?’ refined products, 69 km
Ports: 5 major (Santo Domingo, Barahona, Haina, Las
Calderas, San Pedro de Macoris), 17 minor
Civil air: 18 major transport aircraft (including 1 leased
in) -
Airfields: 52 total, 45 usable; 11 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 9 with runways
1,220-2,439 m; 1 séaplane station
Telecommunications: relatively efficient domestic system
based on islandwide radio relay network; 127,000 telephones
(2.6 per 100 popl.); 135 AM, 31 FM, and 11 TV stations; 1
coaxial submarine cable; 1 Atlantic Ocean satellite station:
DEFENSE FORCES
Military manpower: males 15-49, 1,116,000; 712,000 fit
for military service; 59,000 reach military age (18) annually','7ed321d6f2724bbbd5736305ae199696bdd5927e1a8f4cb8cc9c8c4cd4645e81','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6112aedd61d3913c6dfd8515517ad11db1f65fa92e45c07e926e684e5b83b775',1980,'EC','Ecuador','communications',141,'Galapagos
islands
‘Cy
Railroads: 1,121 km total; 966 km 1.067-meter gage, 155
km 0.750-meter gage; all single track
Highways: 22,250 km total; 3,300 km paved, 11,300 km
otherwise improved, 7,650 km unimproved earth
Inland waterways: 1,500 km
Pipelines: crude oil, 623 km; refined products, 1,358 km
Ports: 3 major (Guayaquil, Manta, Puerto Bolivar), 11
minor
Civil air: 25 major transport aircraft
Airfields: 173 total, 173 usable; 16 with permanent-
surface runways; 5 with runways 2,440-3,659 m, 22 with
runways 1],220-2,439 m; 8 seaplane stations
Telecommunications: facilities adequate only in largest
cities; 1 Atlantic Ocean satellite station; 174,000 telephones
(2.5 per 100 popl.); 250 AM, 38 FM, and 10 TV stations
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
a TOS OC UTES CITT OU OT 0 OUT OF OS WF Or OU On Oy Oe UTE TN
ee a a ee Coe Cae ae Oe Cone we Ore
i i a SE Et i la i A, Re, SO ke
Declassified and Approved For Release 2012/09/02 : CIA-RDPO8-00534R000100140001-7
January 1979
ECUADOR/EGYPT
DEFENSE FORCES
Military manpower: males 15-49, 1,743,000; 1,072,000 fit
for military service; average number reaching military age
(20) annually 84,000 a
Military budget: for fiscal year ending 3] December
1978, $169.8 million; about 17.5% of central government
budget ,
SAUDI
ARABIA
(See reference map V}
LAND
1,000,258 km? (including 57,498 km? occupied by Israel);
2.8% cultivated (of which about 70% multiple cropped);
96.5% desert, waste, or urban; 0.7% inland water
Land boundaries: 2,527 km (1967); approximately 2,580
km including border of occupied Sinai area (since September
1975)
WATER
Limits of territorial waters (claimed): 12 nm (plus 6 nm
“necessary supervision zone’)
Coastline: 2,450 km (1967); includes approximately 500
km within occupied Sinai area (since September 1975)
Railroads: 4,857 km total; 951 km double track; 25 km
electrified; 4,510 km standard gage (1.435-m), 347 km
0.750-meter gage . ;
Highways: 47,025 km total; 12,300 km paved, 2,500 km
gravel and crushed stone, 14,200 km improved earth, 18,025
km unimproved earth ;
Inland waterways: 3,360 km; Suez Canal, 160 km long,
used by ocean-going vessels drawing up to 11.5 meters of
water; Alexandria-Cairo waterway navigable by barges of
metric ton capacity; Nile and large canals by barges of
420-metric ton capacity; Ismailia Canal by barges of 200- to
300-metric ton capacity; secondary canals by sailing craft of
10- to 70-metric ton capacity
Freight carried: Suez Canal (1966)—242 million metric
tons of which 175.6 million metric tons were POL
Pipelines: crude oil, 675 km; refined products, 240 km;
natural gas, 365 km
Ports: 3 major (Alexandria, Port Said, Suez), 8 minor
Civil air: 27 major transport aircraft
Airfields: 99 total, 75 usable; 68 with permanent-surface
runways; 44 with runways 2,440-3,659 m, 1 with runway
over 3,660 m, 17 with runways 1,220-2,489 m
Telecommunications: second-largest system in Africa but
inadequate for needs and poorly maintained; principal
centers Alexandria and Cairo, secondary centers Al Man-
surah, Ismailia, and Tanta; intercity connections by coaxial
cable and microwave; extensive upgrading in progress;
500,000 telephones (1.3 per 100 popl.); 22 AM, no FM, and
29 TV stations; 1 Atlantic Ocean satellite station; Symphonie
satellite station; 2 submarine coaxial cables
DEFENSE FORCES
Military manpower: males 15-49, 9,724,000; 6,321,000 fit
for military service; about 420,000 reach military age (20)
annually','e963689ff1cdcf422df0b6a3b1acf0aaad575d19f14dc1490de4bd47f0f64597','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b7c92e00cf22e499a49cd49fb4014937dc1b53bfe155b476af1340eb1775b7d',1980,'SV','El Salvador','communications',145,'LAND
21,400 km?; 32% cropland (9% corn, 5% cotton, 7% coffee,
11% other), 26% meadows and pastures, 31% nonagricul-
tural, 11% forested
Land boundaries: 515 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 307 km
Railroads: 600 km 0.914-meter gage, single-tracked
Highways: 7,250 km total; 1,500 km paved, 1,300 km
gravel 4,400 km improved and unimproved earth
Inland waterways: Lempa River partially navigable
Ports: 2 major (Acajutla, La Union), 1 minor
Civil air: 8 major transport aircraft
Airfields: 160 total, 150 usable; 5 with permanent-
surfaced runways; 1 with runway 2,440-3,659 m; 9 with
runways 1,220-2,439 m; 1 seaplane station
Telecommunications: nationwide trunk radio relay sys-
tem; connection into Central American microwave net;
54,200 telephones (1.3 per 100 popl.); 60 AM, 9 FM, and 5
TV stations; 1 Atlantic Ocean COMSAT station
DEFENSE FORCES
Military manpower: males 15-49, 945,000; 580,000 fit for
military service; 51,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December
1978, $42.2 million; 8.4% of central government budget','e7282182ae9faa136a5f50859f2dc1114a37fad945ca6d82588a037247e5f0d3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c7a1f2532f3a082471e95c496bc19c8fe3413e78ce8b2e6fc670c530a2d60f4',1980,'ET','Ethiopia','communications',152,'LAND
1,178,450 km?; 10% cropland and orchards, 55% meadows
and natural pastures, 6% forests and woodlands, 29%
wasteland, built-on areas, and other
Land boundaries: 5,198 km
WATER
Limits of territorial waters (claimed): 12 nm; sedentary
fisheries extends to limit of fisheries
Coastline: 1,094 km (includes offshore islands)','daf6a9c6af00c1cc8e2a984728f4356092a3afb76a4f876a706dd795d9b054a6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5070786575a05a78910dc6d13a8fb12ec42d0c0f39702975aae149bd2187fe70',1980,'DE','Germany','communications',157,'Railroads: 1,014 km total; 676 km meter gage (1.00 m), 32
61
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
ETHIOPIA/FALKLAND ISLANDS
km 1.067-meter gage, 306 km 0.95-meter gage; all single
track
Highways: 11,435 km total; 3,770 km bituminous, 7,665
km crushed stone, gravel, or stabilized earth, remainder
earth
Inland waterways: navigation possible on Lake Tana and
on.approx. 225 km of unconnected and basically unim-
proved waterways, of which only 114 km are navigable year
round
Ports: 2 major (Assab, Massawa)
Civil airy 19 major transport aircraft
Airfields: 192 total, 178 usable; 7 with permanent-surface
runways; 1 with runway over 3,660 m, 6 with runways
2,440-3,659 m, 48 with runways 1,220-2,439 m
Telecommunications: system composed of open-wire
lines, radiocommunication stations, and small number of
multiconductor cable and radio-relay links; principal center
Addis Ababa, secondary center Asmara; 73,000 telephones
(0.3 per 100 popl.); 4 AM stations, no FM stations, and 1 TV
station
DEFENSE FORCES :
Military manpower: males 15-49, 6,965,000; 3,734,000 fit
for military service; average number reaching military age
(18) annually 324,000
Military budget: for fiscal year ending 6 July 1977,
$104,445,000; 14.7% of central government budget
FALKLAND ISLANDS
(Islas Malvinas) !
Railroads: 947 km, 0.914-meter gage, single-tracked; 832
km government-owned, 115 km privately owned
Highways: 25,500 km total; 2,750 km paved, 11,350 km
gravel, and 11,400 km earth
Inland waterways: 260 km navigable year-round; addi-
tional 730 km navigable during high-water season
Pipelines: crude oil, 48 km
Ports: 2 major:(Puerto Barrios, Santo Tomas de Castilla), 3
minor
84
Airfields: 470 total, 469 usable; 7 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 17 with runways
1,220-2,489 m
Civil air: 8 major transport aircraft
Telecommunications: modern telecom facilities limited
to Guatemala City; 58,500 telephones (0.9 per 100 popl.); 97
AM, 20 FM, and 5 TV stations; connection into Central
American microwave’ net
DEFENSE FORCES
Military manpower: males 15-49, 1,529,000; 998,000 fit
for military service; about 69,000 reach military age (18)
annually
Military budget: proposed for fiscal year ending 31
December 1978, $58.5 million; 6.2% of central government
budget
Railroads: 2,089 km total; 503 km standard gage (1.435
m), 1,586 km meter gage (1.000 m)
Highways: 17,140 km total; 7,940 km bituminous, 660 km
gravel; 2,000 km improved earth; 6,540 km unimproved
earth :
Pipelines: 797 km crude oil; 10 km refined products; 72
km natural gas
Ports: 4 major, 8 minor
Civil air: 16 major transport aircraft (including 1 leased
in)
Airfields: 27 total, 23 usable; 11 with permanent-surface
runways; 3 with runways 2,440-3,659 m; 11 with runways
1,220-2,4389 m; 1 seaplane station
Telecommunications: the system is above the African
average in amount and capacity of facilities which consist of:
open-wire lines with multicanductor cable or radio relay;
209
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
TUNISIA/TURKEY
key centers are Safaqis, Susah, Bizerte, and Tunis; 100,000
telephones (1.7 per 100 popl.); 3 AM, 3 FM, and 7 TV
stations; 3 submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 1,273,000; 713,000 fit
for military service; about 75,000 reach military age (20)
annually
Military budget: for fiscal year ending 31 December
1978, $153 million; 6% of central government budget
TURKEY
» Ankara
TURKEY
(See reference map V}
LAND
766,640 km?*; 85% cropland, 25% meadows and pastures,
23% forested, 17% other
Land boundaries: 2,574 km
WATER
Limits of territorial waters (claimed): 6 nm except in
Black Sea where it is 12 nm (fishing 12 nm) .
Coastline: 7,200 km
Railroads: 8,253 km standard gage (1.435 m); 143 km
double track; 72 km electrified
Highways: 60,000 km total; 21,000 km_ bituminous;
28,000 km gravel or crushed stone; 2,500 km improved
earth; 8,500 km. unimproved earth
Inland waterways: approx. 1,689 km
Pipelines: 1,288 km crude oil; 2,055 km refined products
Ports: 10 major, 35 minor
Civil air: 24 major transport aircraft
Airfields: 120 total, 101 usable; 58 with permanent-sur-
face. runways; 3 with runways over 3,660 m, 23 with
runways 2,440-3,659 m, 22 with runways 1,220-2,439 m
Telecommunications: new trunk domestic radio-relay
net, good international service; 1.1 million: telephones (2.7
per 100 popl.); 40 AM, 4 FM, and 86 TV stations; 1 coaxial
submarine cable; COMSAT station near completion.
DEFENSE FORCES
Military manpower: males 15-49, 9,786,000; 5,778,000 fit
for military service; about .430,000 reach military age (20)
annually
Military budget: for fiscal year ending 28 February 1979,
$2.3 billion; about 20.7% of proposed central government
budget
°','967ede6d91f6c6d627d4f3b8bf43006e8ce271edf892a1105350cd2644a82ec2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67703b088e7bf2315b7f0f4934c5e9dd1220c40da047743f54efc2d29eb5dd03',1980,'FO','Faroe Islands','communications',158,'; Norwegian
Ss
FAROE ¢
ISLANDS
Atlantic
Ocean
{See reference map iV}
LAND
1,340 km?; less than 5% arable, of which only a fraction
cultivated; archipelago consisting of 18 inhabited islands and
a few uninhabited islets
WATER
Limits of territorial waters (claimed): 12 nm; fishing
200 nm
Coastline: 764 km
Railroads: none
Highways: none
Ports: 1 minor
Airfields: 1 with permanent-surface runway, less than
1,220 m
Civil air; no major transport aircraft
Telecommunications: good international communica-
tions; fair domestic facilities, 15,000 telephones (35 per 100
popl.); 1 AM, and 3 FM stations; 3 coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49 included with Denmark','6444b59eb5bd56192190493d684eb58b9f3585cdb8049d9308596793b47d7f78','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6905ac8a67b5508c2e5ecd9e21b444d6b5ee1c10ce7dbefcab236f376ef499df',1980,'FI','Finland','communications',162,'Norwegian
{See reference map IV}
LAND
336,700 km?*; 8% arable, 58% forested, 34% other
Land boundaries: 2,534 km
WATER
Limits of territorial waters (claimed): 4 nm; fishing 12
nm; Aaland Islands, 3 nm
Coastline: 1,126 km (approx.) excludes islands and coastal
indentations
Railroads: 6,038 km total; Finnish State Railways (VR)
operate a total 6,010 km 1.524-meter gage, 477 km multiple
66
track, and 608 km electrified; 22 km 0.750-meter gage and 6
km 1.524-meter gage are privately owned
Highways: about 73,552 km total in national classified net
work, including 31,000 km paved (bituminous, concrete,
bituminous surface treated) and 42,552 km unpaved
(stabilized gravel, gravel, earth); additional 29,440 km of
private (state subsidized) roads
Inland waterways: 6,597 km total (including Saimaa
Canal); 3,700 km suitable for steamers; Saimaa Canal locks
(84 m by 13.2 m with a 5.2 m depth over sill) can
accommodate vessels of up to 82 m in length, 11.8 m beam,
4.4 m draft, and 24.5 m mast height
Pipelines: natural gas, 161 km
Ports: 11 major, 14 minor
Civil air: 41 major transport aircraft
Airfields: 134 total, 132 usable; 86 with permanent-
surface runways; 17 with runways 2,440-3,659 m, 24 with
runways 1,220-2.439 m
Telecommunications: good telecom service from cable
and radio-relay network; 1.94 million telephones (40.9 per
100 popl.); 15 AM, 40 FM, and 76 TV stations; 4 submarine
cables, including 1 coaxial
DEFENSE FORCES
Military manpower: males 15-49, 1,259,000; 1,022,000 fit
for military service; 39,000 reach military age (17) annually |
Military budget: proposed for fiscal year ending 31
December 1979, $520 million; about 4.8% of central
government budget','abf59cca0177da8712ad94b517aa2bf3458604df262f376d67f10e355b1d33a1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1341e9c9a4d97848c42b0edfa18b6245a2281412d5671e58b88cafe19fcb2bc5',1980,'FR','France','communications',166,'(See reference map {V)
LAND.
551,670 km*; 35% cultivated, 26% meadows and pastures,
14% waste, urban, or other, 25% forested
Land boundaries: 2,888 km
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
tts
TA
er on
AAT A A
stg Semen
a a ia
cai a A i Sar
ne i i ee, el ee le i el lk el a cle al I, ee el
?
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm)
Coastline: 3,427 km (includes Corsica, 644 km)
Railroads: 36,691 km total; French National Railways
(SNCF) operates 34,717 km standard gage (1.435 m); 9,374
km electrified, 15,630 km double or multiple track; 1,974
km of various gages (1,000 m to 1,445 m), privately owned
and operated
Highways: 788,580 km total; 128,745 km bitumen and
concrete (incl. 3,144 km of controlled access, divided
“AUTOROUTES”); 339,315 km_ bituminous _ treated;
301,000 km crushed stone and gravel; 19,520 km improved
‘earth; in addition, there are approximately 700,065 km of
local farm and forest roads
Inland waterways: 14,912 km; 5,604 km heavily traveled
Pipelines: crude oil. 2,253 km; refined products, 4,344
km; natural gas, 22,047 km ; :
Ports: 23 major, 165 minor
Civil air: 300 major transport aircraft
Airfields: 456 total, 437 usable; 223 with permanent-
surface runways; 2 with runways over 3,660 m, 31 with
runways 2,440-3,659 m, 122 with runways 1,220-2,439 m; 2
seaplane stations
Telecommunications: highly developed system provides
satisfactory telephone, telegraph, and radio and TV broad-
cast services; 15.5 million telephones (29.3 per 100 popl.); 55
AM, 94 FM, and 1,500 TV stations; 22 submarine cables; 2
communication satellite ground stations with 4 Atlantic
Ocean, and 2 Indian Ocean antennas
DEFENSE FORCES ‘
Military manpower: males 15-49, 18,246,000; fit for
military service 10,695,000; 425,000 reach military age (18)
annually
Military budget: proposed for fiscal year ending 31
December 1979, $17.6 billion; about 18% of proposed
central government budget
68
(See reference map 1V)
Railroads: 2,009 km 1.600-meter gage; 1,894 km govern-
ment-owned; 115 km privately-owned |
Highways: 88,302 km total; 78,616 km surfaced, 9,686
km earth
Inland ‘waterways: approximately 1,000 km
Ports: 6 major, 38- minor
Civil air: 28 major transport aircraft (including 1 leased
and 5 leased out) |
Airfields: 38 total, 838 usable; 8 with permanent-surface
runways; ) with-runway 2,440-3,659 m, 4 with runways
1,220-2,439 m; 1 seaplane station
Telecommunications: small, modern system; all cities
interconnected for telephone and telegraph service; 480,000
telephones (15.1 per 100 popl.); 6 AM, 7 FM, and 28 TV
stations; 4 coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 733,000; 573,000 fit for
military service; about 31,000 reach military age (17)
annually
Military budget: for fiscal year ending 31 December
1978, $182.1 million; about 4.2% of the central government
budget
{See reference map tV}
we tne
LAND
2,590 km?; 25% arable, 27% meadows and pasture, 15%
waste or urban, 33% forested, negligible amount of inland
water
Land boundaries: 356 km
RHODESIA
LAND
391,090 km*; 40% arable (of which 6% cultivated); 60%
172','ac0e310b05efe5913d73cf126ed3b1e695a9d0da1b23994e66759a22c750fe96','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b73604c2d44f42eb1f647bf6a3ff3dce9c3667ebea1d1e6793548851f718a0b',1980,'GY','Guyana','communications',170,'(See reference map til}
LAND
90,909 km?; 90% forested, 10% wasteland, built-on, inland
water and other, of which .05% is cultivated and pasture
‘Land boundaries: 1,183 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 378 km
Railroads: 32 km private plantation line, 0.600-meter
gage
Highways: 600 km total; 450° km paved, 150 km
improved and unimproved earth
Inland waterways: 460 km, navigable by small ocean-
going vessels and river and coastal steamers; 3,300 km
possibly navigable by native craft
Ports: 1 major (Cayenne), 7 minor
Civil air: no major transport aircraft
Airfields: 13 total, 10 usable; 2 with permanent-surface
runways; 1 with runway 2,440-3,659 m
Telecommunications: limited open-wire and radio-relay
system with about 8,906 telephones (17.8 per 100 popl.); 9
AM, 2 FM, and 2 TV stations; 1 Atlantic Ocean satellite
station
DEFENSE FORCES
Military manpower: males 15-49, 14,000; 10,000 fit for
military service
Caribbean Atlantic
a
ea Ocean
(See reference map tit)
LAND
214,970 km?; 1% cropland, 3% pasture, 8% savanna, 66%
forested, 22% water, urban, and waste
Land boundaries: 2,575 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Declassified and Approved For Release 2012/09/02 : CIA-RDP0O8-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Coastline: 459 km
Railroads: 109 km total, all single track; 80 km 0.914-
meter gage, 29 km 1.067-meter gage
Highways: 5,700 km total; 550 km paved, 1,850 km
gravel, and 3,300 km earth
Inland waterways: 5,900 km; Demerara River navigable
to Mackenzie by ocean steamers, others by ferryboats, small
craft only
Ports: 1 major (Georgetown), 3 minor
Civil air: 6 major transport aircraft (including 1 leased in)
Airfields: 95 total, 88 usable; 4 with permanent-surface
runways; 12 with runways 1,220-2,439 m; 2 seaplane stations
Telecommunications: highly developed telecom system
with radio-relay network and over 22,500 telephones (2.6
per 100 popl.); tropospheric scatter link to Trinidad; 5 AM, 1
FM and no TV stations; 1 COMSAT station
“DEFENSE FORCES
Military manpower: males 15-49, 189,000; 144,000 fit for
military service
87
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDPO8-00534R000100140001-7
January 1979
Suriname’.
Manaus,
Bolivia
*Sucre
\\ Paraguay
; cordoba
f .
(Uruguay ¢
‘Buenos Aires : 2
Montevideo','93467dcfc00084d531ceae652f85f500e81f77ad3423679b98b8154b8967f3bf','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d064993b1b75eb307a82d05509caa56384e3ba990b0b2f1b9fbe018e54de9f66',1980,'PF','French Polynesia','communications',174,'Pacific Ocean
CHRISTMAS IS.
=, PRENCH
POLYNESIA
_ COOK Is.”
{See reference map Vill)
LAND
About 4,000 km?
WATER
Limits of territorial waters: 12 nm
Coastline: about 2,525 km
Highways: 3,700 km, all types
Ports: 1 major, 6 minor
Airfields: 32 total, 32 usable; 12 with permanent-surface
runways, 2 with runways 2,440-3,659 m, 14 with runways
1,220-2,439 m; 2 seaplane stations
Civil air: about 3 major transport aircraft
Telecommunications: 14,700 telephones (11.3 per 100
popl.); 72,000 radio and 14,000 TV sets; 5 AM, 2 FM, and 6
TV stations; 1 ground satellite station
DEFENSE FORCES
Defense is responsibility of France.','cd56ab4647d15dd1fa3aab190e957e0abf443ccacddf5d59383a9a90980635e7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f770ff40f2fc73688dde2813930ecffea37d2b2ed0cf2b5405bb6f7ab49a9a4',1980,'GN','Guinea','communications',178,'{See reference map Vi}
LAND
238,280 km?; 19% agricultural, 60% forest and brush, 21%
other
Land boundaries: 2,285 km
WATER
‘Coastline: 539 km a
Limits of territorial waters (claimed): 200 nm
Railroads: 953 km, all 1.067-meter gage; 32 km double
track; diesel locomotives gradually replacing steam engines
Highways: 32,200 km total; 4,524 km concrete or
bituminous surface, 27,676 km gravel or laterite, 9,242 km
unimproved earth
Inland waterways: Volta, Ankobra, and Tano rivers
provide 235 km of perennial. navigation for launches and
lighters; additional routes navigable seasonally by small
craft; Lake Volta reservoir provides 1,125 km of arterial and
feeder waterways
Pipelines: refined products, 3 km
Ports: 2 major (Tema, Takoradi), 1 naval base (Sekondi), 4
minor :
Civil air: 12 major transport aircraft
Airfields: 19 total, 18 usable; 4 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 9 with runways
1,220-2,489 m
Telecommunications: fair system of open-wire and cable,
radio-relay links and radiocommunication stations; 66,000
telephones (0.7 per 100 popl.); 6 AM, no FM, and 8 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 2,351,000; 1,309,000 fit
for military service; 130,000 reach military age (18) annually
Cs
IVORY
LIBERIA, COAST
Atlantic Ocean
(See reference map Vi}
LAND
246,050 km?; 3% cropland, 10% forest
Land: boundaries: 3,476 km
WATER
Limits of territorial waters (claimed): 130 nm
Coastline: 346 km
Railroads: 805 km meter gage (1.00 m), 8 km standard
gage
Highways: 7,604 km total; 4,949 km paved, remainder
unimproved earth
Inland waterways: 1,795 km; 500 km navigable by small
oceangoing vessels, 1,295 km navigable by shallow-draft
steamers and barges
Ports: 1 major (Conakry), 3 minor
Civil air: 10 major transport aircraft
Airfields: 17 total, 16 usable; 4 with permanent-surface
runways; 3 with runways 2,440-3,659 m, 9 with runways
1,220-2,489 m; 3 seaplane landing areas
Telecommunications: inadequate system of -openwire
lines, small radiocommunication stations, and 1 radio-relay
link; principal center Conakry, secondary center Kankan;
8,300 telephones (0.2 per 100 popl.); 1 AM station, no FM,
and no TV stations
DEFENSE FORCES
Military manpower: males 15-49, 1,328,000; 667,000 fit
for military service
Military budget: for fiscal year ending 30 September
1970 (latest information available), $6,073,000; 8.0% of
central government budget
BISSAU
Atlantic
‘Ocean
(See reference map VI}
LAND :
196,840 km*, 13% forested, 40% agricultural (12%
cultivated), 47% built-up areas, waste, etc.
Land boundaries: 2,680 km
WATER
Limits of territorial waters (claimed): 150 nm (fishing
200 nm); 200 nm exclusive economic zone
Coastline: 531 km
Railroads: 1,033 km meter gage (1.00 m); 64 km double
track
Highways: 13,589 km total; 2,547 km paved, 11,042 km
other
Inland waterways: 1,505 km
Ports: 1 major (Dakar), 2 minor
Civil air: 4 major transport aircraft
Airfields: 27 total, 27 usable; 11 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 19 with runways
1,220-2,489 m; 3 seaplane stations
Telecommunications: above average urban system;
39,000 telephones (0.7 per 100 popl.); 3 AM stations, no FM
station, and 1 TV station; 2 submarine cables; 1 Atlantic
Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,206,000; 624,000 fit
for military service; 49,000 reach military age (18) annually
Military budget: for fiscal year ending 30 June 1979,
$62,062,000; about 7.9% of central government budget','5bedfb50e8421958487985ce2fe9b9c62e32c1dcb4c35561fe23cb7cfb635844','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58aaf8d2db5cdcfde223ed952a5ebe96fe77c0c64b0bdaa9cbd31f595522114f',1980,'GI','Gibraltar','communications',182,'LAND
6.5 km?
Land boundaries: 1.6 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 12 km','95316d0c6f4c61ad7bc7c5f1b2bced964f663e6134e121ed5c2b452b8e968fe3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3fe89684161b2178b9e64b4e7727410be1b4ca07aa5f8e2796c53bbc56b904a',1980,'GR','Greece','communications',184,'ek,
:
4 An
{See reference map iV)
LAND
132,608 km?; 29% arable and land under permanent
crops, 40% meadows and pastures, 20% forested, 11%
wasteland, urban, other :
Land boundaries: 1,191 km
WATER
Limits of territorial waters (claimed): 6 nm
Coastline: 13,676 km
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Railroads: 2,476 km total; 1,565 km standard gage (1.435
m) of which 36 km electrified and 100 km double track, 889
km meter gage (1.000 m), 22 km narrow gage (0.750 m); all
government-owned
Highways: 38,938 km total; 16,090 km paved, 13,676 km
crushed stone and gravel, 5,632 km improved earth, 3,540
km unimproved earth
Inland waterways: system consists of 3 coastal canals and
83 unconnected rivers which provide navigable Jength of just .
less than 80 km
79
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
GREECE/GREENLAND
Pipelines: crude oil, 26 km, refined products, 547 km
Ports: 17 major, 37 minor
Airfields: 70 total, 66 usable; 48 with permanent-surface
runways; 17 with runways 2,440-3,659 m, 22 with runways
1,220-2,439 m
Civil air: 833 major transport aircraft (including 1 leased
in)
Telecommunications: adequate modern networks reach
all areas on mainland and islands; 2.18 million telephones
(23.1 per 100 popl.); 31 AM, 30 FM, and 34 TV stations; 5
coaxial submarine cables; 1 satellite station with 1 Atlantic
Ocean antenna and 1 Indian Ocean antenna
DEFENSE FORCES
Military manpower: males 15-49, 2,156,000; 1,648,000 fit
for military service; about 76,000 reach military age (21)
annually
Military budget: for fiscal year ending 31 December
1978, $1,610 million; about 20% of central government
budget','87cb4a79ca3cb3504b47827adc234f7f025706abc669ca81b7eaad45e33b5e6d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('600f3692256039f68540d5ca624d2f5edc01b7dd89879c7db9e2ba441bfaf156',1980,'GL','Greenland','communications',188,'Norwegian
Sea
oe
Godthaab
Atlantic Ocean
(See reference map I}
LAND
2,175,600 km?; less than 1% arable (of which only a
fraction cultivated), 84% permanent ice and snow, 15%
other
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 44,087 km (approx., includes minor islands)
Railroads: none
Highways: 80 km
Ports: 7 major, 16, minor
Civil air: 2 major transport aircraft (registered in
Denmark)
Airfields: 11 total, 6 usable; 3 with permanent-surface
runways; 3 with runways 2,440-3,659 m, 2 with runways
},220-2,489 m; 7 seaplane’ stations
Telecommunications: adequate domestic and _ interna-
tional service provided by cables and radio relay; 9,000
telephones (17.0 per 100 popl.); 5 AM, 6 FM, and 2 TV
stations; 2 coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49, included with Den-
mark
_ (Denmark)
Thule
United
Baffin Bay
States
Fairbanks «
Yukon
Godthaab
Territory \\ Bear Lake
, Whitehorse ; Sy
~~’ f
Yellowknife
Great
SS Slave Lake
~~
i
‘a . Prince Rupert / Pe ae
Pacific ( _ British 7 1
Ocean Columbia / |
Alberta ; * Churchill \\
\\ Santee / ¢ / 4 n Schettevillea~~,
‘ { Manitoba . i - Be a
Saskatchewan f 3 L
/ AA
: Quebec
<—.-
wi Saskatoon ! Fa
Prince
Edward
‘Ne ydney
; . ;__Lake {
pean beanies da Ontario
“Wi Tr 1
innipeg” | stn
. P8 a: lottetown
\\ Quebec f :
Halifax
x iMentreal''s Ni lage i
Otawek,
¢y} take
% 9 aa > Ontario
Boston®
New York a
Vancouver \\
\\ ecalga
3
=y
\\%,
l. Michigan
Milwaukee ie
o! or
Ne
Na Salt Lake City
Chicago
Atlantic Ocean
« Denver
Washington + {
Kansas City * ae
e Lous
States
» Los Angeles
United
Oklahoma City *
§03981 1-79
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
®
«Los Angeles
503982 1-79
N
EEE REeemeesemeenmmemmemeioees setae ced
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
(@enmark) 400 Kilometers.
400 Miles
dan Mayen
sat wor}
Murmansk
Norwegian
Reykjavik : ; a Atkangel''sk
Iceland Sea ; aol
Faroe Is.
(Den.)
sa Norway
r) 2 7 Leningrad
Bergen, Oslo a
¢ x Stockholm
“f “7 ce
Goteborg Baltic in KMescoM
Edinburgh North
Atlantic
U.S.S.R.
{
Federal ral Dem. Rep. \\
Bonn IN
Avex Republic','62f9abec346fd0e3f2bf5d6d91c2666a22c08924732f31f95320807f5a65d9a5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57ed069b1e7bc93f20952c128957630e4bd2be82c7fe7e77cfcb7c0d4fe3f722',1980,'GD','Grenada','communications',192,'PUERTO i
si te
e
°
: %
Carhbean 4
2
~>sFRENCH
GUIANA
(See reference map tt}
LAND
344 km? (Grenada and southern Grenadines); 44%
cultivated,. 4% pastures, 12% forests, 17% unused but
potentially productive, 23% built on, wasteland, other
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm)
Coastline: 121] km
Railroads: none
Highways: 1,000 km total; 600 km paved, 300 km
otherwise improved; 100 km unimproved
Ports: 1 major (St. Georges), 1 minor
Civil air: no major transport aircraft
Airfields: 3 total, 2 usable; 2 with permanent-surface -
runways, 1 with runway 1,220-2,439 m
Telecommunications: automatic, islandwide telephone
system with 5,100 telephones (4.5 per 100 popl.); VHF and
UHF links to Trinidad and Carriacou; 3 AM stations','3bdcdf7a51990d2745bf64d0cf6878846b3ed45af1a18ec5a703480c39b96c30','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fbcac4de0608d199fffad78588d707322d12f0bcdd3f469e09b240152800ecb5',1980,'GP','Guadeloupe','communications',196,'“DOMINICAN
REPUBLIC
PUERTO
C> kico
°
°
Caribbean Sea
(See reference mep tl}
. LAND
1,779 km?; 24% cropland, 9% pasture, 4% potential
cropland, 16% forest, 47% wasteland, built on;-area consists
of two islands”
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 306 km
Railroads: privately owned, narrow-gage plantation lines
Highways: 3,500 km total: 2,200 km paved, 1,300 km
gravel and earth
Ports: 1 major (Pointe-a-Pitre), 3 minor
Civil air: 8 major transport aircraft (leased in)
Airfields: 8 total, 8 usable, 8 with permanent-surface
runways; 1 with runway 2,440-3,659 m; 2 seaplane stations
Telecommunications: domestic facilities inadequate;
26,800 telephones (7.9 per 100 popl.); interisland VHF radio
‘links; 2 AM and 3 TV transmitters
DEFENSE FORCES
Military manpower: males 15-49, included with France','31f1ba773fc87a4a7e9aec3cf19c48ce8fe156f43cf3cd2092234ea0677f72e7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19be879af42fde104b23414802f71ef190720274ff20b89f526a34750ab8ca7e',1980,'GW','Guinea-Bissau','communications',203,'(formerly Portuguese Guinea)
LAND
36,260 km? (includes Bijagos archipelago)
Land boundaries: 740 km
WATER
Limits of territorial waters (claimed): 150 nm (fishing
200 nm)
Coastline: 274 km
Railroads: none
Highways: approx. 3,218 km (418 km_ bituminous,
remainder earth)
Inland waterways: 1,600 km
Ports: 1 major (Bissau), 2 minor
Civil air: 3 major transport aircraft
Airfields: 60 total, 59 usable; 4 with permanent-surface
runways; 8 with runways 1,220-2,439 m; 1] seaplane station
Telecommunications: limited system of open-wire lines
and radiocommunication stations; 2,700 telephones (0.5 per
100 popl.); 1 AM, 1 FM and no TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 125,000; 69,000 fit for
military service','99461523a07a911288080b20bdf83d6d88a103ac78d6a4f9a4b425d07b99fb0a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c94aee9cb0fd9423bce1da35f0bc2cba9fb6cb5f5a7be02733df3b33c95ccdb',1980,'PH','Philippines','communications',211,'Railroads: 35 km standard gage (1.435 m); governnient
owned
Highways: 966 km total; 660 km paved, 306 km gravel
and crushed stone, or earth
Ports: 1 major
Civil air: 17 major transport aircraft
Airfields: 2 total, 2 usable; 2 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 1 with runway
1,220-2,439 m; 1 seaplane station
Telecommunications: modern facilities provide domestic
and international services; excellent broadcast coverage
provided by wired and radio broadcast stations; closed-cir-
cuit TV and TV broadcast facilities; 1.1 million telephones;
2.5 million radio receivers; 100,000 wired-speakers; 2 FM, 2
AM stations; wired-broadcast network; 859,000 TV receiv-
ers, 2 TV stations, 2 closed-circuit TV networks; radio relay
link to Taiwan; 2 international communications satellite -
ground stations; coaxial cable link to Canton; 5 submarine
cables; submarine cable to Japan and Philippines completed
DEFENSE FORCES
Military manpower: males 15-49, 1,244,000; 974,000 fit
for military service; about 55,000 reach military age (18)
annually
Defense, is the responsibility of U.K.
(See reference map Vil}
Highways: 42 km paved
Ports: 1 major
Civil air: no major transport aircraft
Airfields: none; 1 seaplane station
Telecommunications: fairly modern communication fa-
cilities provide adequate services for domestic and interna-
tional requirements; broadcasting coverage is provided by
AM and FM radio facilities and a wired broadcast network;
11,765 telephones; 75,000 radio receivers; 2 AM, 2 FM and
no TV stations; no submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 60,000; 35,000 fit for
military service ,
Defense is responsibility of Portugal
Personnel: there are no Portuguese military personnel in
Philippine Sea
(See reference map Vil}
LAND
300,440 km?, 53% forested, 30% arable land, 5%
permanent pasture, 12% other
WATER
Limits of territorial waters (claimed): 0-300 nm (under
an archipelago theory, waters within straight lines joining
appropriate points of outermost islands are considered
internal waters; waters between these baselines and the
limits described in the Treaty of Paris, December 10, 1898,
the U.S.-Spain Treaty of November 7, 1900, and the
U.S.-U.K. Treaty of January 2, 1930 are considered to be the
territorial - sea)
Coastline: about 22,540 km
Railroads: 3,510 km total (1977); 2 common-carrier
systems 1.067-meter gage totaling about 1,177 km; 19
industrial systems with 4 different gages totaling 2,333 km;
34% government owned
Highways: 119,218 km total (1977); 20,483 km paved:
51,643 km gravel, crushed stone, or stabilized soil surface;
47,092 km unimproved earth
Inland waterways: 3,219 km; limited to shallow-draft
(less than 1.5 m) vessels
Pipelines: refined products, 251 km
Ports: 11 major, numerous minor
Civil air: approximately 70 major transport aircraft
Airfields: 332 total, 304 usable; 58 with permanent-
surface runways; 7 with runways 2,440-3,659 m, 36 with
runways 1,220-2,489 m
DEFENSE FORCES
Military manpower: males 15-49, 10,393,000; 7,417,000
fit for military service; about 460,000 reach military age (20)
annually
Supply: limited small arms and small arms ammunition,
smal] patrol craft, and helicopter production; other materiel
obtained almost exclusively from U.S.; naval ships and
equipment from Australia, Japan, Singapore, U.S., and Italy;
aircraft and helicopters from West Germany and USS.
Military budget: for fiscal year ending 31 December
1979, $753.4 million; about 16% of central government
budget','8a6ba5029c8e605e9445bbb9990b0efa8e6ed17e43250691ac60bc7aee766ef8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a8f5217c308199502cc8774c05aeaabf4f0a1d1a553958f43c6e592e345a619',1980,'HU','Hungary','communications',212,'LAND
92,981 km?*; 60% arable, 14% other agricultural, 16%
forested, 10% other
Land boundaries: 2,245 km
Railroads: 8,669 km total; 7,750 km standard gage
(1.485 m), 405 km narrow gage (mostly 0.760 m), 35 km
broad gage (1.524 m), 1,162 km double track, 1,303 km
electrified; government owned (1977)
Highways: 99,595 km total; 32,583 km concrete, asphalt,
stone block; 10,408 km asphalt treated, gravel, crushed stone;
56,604 km earth (1977)
Inland waterways: 1,688 km (1977)
Pipelines: crude oil, 1,287 km; refined products, 500 km;
natural gas, 2,896 km
Freight carried: rail—134.8 million metric tons, 24.1
billion metric ton/km (1977); highway—563.5 million
metric tons, 10.4 billion metric ton/km (1977); waterway—
est. 14.2 million metric tons, 8.3 billion metric ton/km (incl.
int''l. transit traffic) in approximately 545 waterway craft
with 310,000 metric ton capacity
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
A al
KAA aA 28 AAA
~A ak A ee AA AAA
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
HUNGARY/ICELAND
River ports: 2 principal (Budapest, Dunaujvaros); no
maritime ports; outlets are Rostock, GDR; and Gdansk,
Gdynia, and Szczecin in Poland; and Galati and Brails in','1cef61e173cf0cb55a87376fe0c5bc23475bf3e463f852188c0b10c79439f810','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9af302d65e1ed78d853fc996fe696d87b7cc89056b54d398535fc746866156b',1980,'IS','Iceland','communications',216,'Jan Mayen
* Istand
Greenland :
Sea Norwegian
vit ICELAND Sea
Reykjavik
Atlantic
Ocean
{See reterence map 1V)
LAND
102,952 km?; arable negligible, 22% meadows and
pastures, forested negligible, 78% other
WATER
Limits of territorial waters (claimed): 4 nm (fishing 200
nm)
Coastline: 4,988 km
Railroads: none
Highways: 12,343 km total; 166 km bitumen and
concrete; 1,284 km bituminous treated and gravel; 10,893
km earth
Ports: 4 major (Akureyri, Hafnarfjordhur, Reykjavik,
Seydhisfjordhur), and about 50 minor
‘Civil air: 22 maior transport aircraft (including 4 leased in
and 1 leased out)
Airfields: 125 total, 101 usable; 3 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 10 with runways
1,220-2,4389 m; 1 seaplane station
Telecommunications: adequate domestic service, wire
and radio communication system; 93,700 telephones (42.4
per 100 popl.); 17 AM, 14 FM, and 80 TV stations; 2 coaxial
submarine cables; Comsat station under construction
DEFENSE FORCES
Military manpower: males 15-49, 58,000; 52,000 fit for
military service (Iceland has no conscription or compulsory
military service)','8160e51a457cf630c1efafb8e170033cd0a9cbcc1e125293b8be991a2b3ba7da','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bdc24e89e0c4b0825d443f38e7ca74892933f6ba10e586fd086b049b131886d7',1980,'IN','India','communications',220,'LAND
3,136,500 km? (includes Indian part of Jammu-Kashmir,
Sikkim, Goa, Damao and Diu); 50% arable, 5% permanent
meadows and pastures, 20% desert, waste, or urban, 22%
forested, 3% inland water
Land boundaries: 12,700 km?
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; additional 100 nm is fisheries conservation zone,
December 1968; archipelago concept. baselines); 200 nm
exclusive economic zone
Coastline: 7,000 km (includes offshore islands)
94
Arabian
Sea
{LANKA
Indian Ocean
(See reference map Vil)
Railroads: 61,313 km total (1977); 25,550 km meter gage
(1.00 m), 30,041 km broad gage (1.676 m), 4,476 km narrow *
gage (0.762 m and 0.610 m), government owned; 46 km
meter gage (1.00 m), 855 km broad gage (1.676 m), 345 km
narrow gage (0.762 m and 0.610 m), privately owned; 12,304
km double track; 4,191 km electrified
Highways: 1,327,450 km total; 415,250 km _ paved,
190,600 km gravel or crushed stone, 304,900 km improved _
earth, 416,700 km unimproved earth
Inland waterways: 14,300 km; 2,575 km navigable by
river steamers
Pipelines: crude oil, 1,767 km; refined products, 2,020
km; natural gas, 574 km
Ports: 9 major, 80 minor
Civil air: 93 major transport aircraft
Airfields: 355 total, 339 usable; 190 with permanent-
surface runways; 2 with runways over 3,660 m, 54 with
runways 2,440-3,659 m, 121 with runways 1,220-2,439 m
Telecommunications: fair domestic telephone service
where available, good internal microwave links; telegraph
facilities widespread; AM broadcast adequate; international
radio communications adequate; 2.1 million telephones (0.3
per 100 popl.); about 163 AM stations at 80 locations, 9 TV
stations, 4 earth satellite stations; submarine cables extend to
Sri Lanka. :
DEFENSE FORCES
Military manpower: males 15-49, 159,165,000;
93,891,000 fit for military service; about 7,566,000 reach
military age (17) annually ;
Military budget: for fiscal year ending 31 March 1979,
$3.6 billion; 16.6% of central government budget','06e5a4cddf8396185011d8a5a8bedc60bff9d9128d69486447f16fd963a2d3f8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8af735a446c73602331f1a63660f1a34830ca192f4087c9f392a6631dc1ff747',1980,'ID','Indonesia','communications',224,'LAND ‘
1,906,240 km?; 12% small holdings and estates, 64%
forests, 24% inland water, waste, urban, and other
Land boundaries: 2,736 km
95
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
“OTe INDONESIA _
eS
Indian Ocean','494747c1b8d5e429d3f6c21d198b3a60c60ff60ca08c3816a5fcbebe5b741229','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2584ec62f9045cd3571bd3198d25db3876c0c4932b8c2f2abe90b61c68ec6b8a',1980,'IE','Ireland','communications',225,'LAND
68,894 km’; 17% arable, 51% meadows and pastures, 3%
forested, 2% inland water, 27% waste and urban
Land boundaries: 360 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 1,448 km
99
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
. January 1979
Atlantic
IRELAND?','b4939a30b67ec24b25304001054490af555b633fc35cecfa174700a195904958','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8066ce34fe7cf28996db72359f4a635927970ee783baa5dcd850c4cb6a4b26b',1980,'IL','Israel','communications',226,'a
Mediterranean
Sea
ARABIA
{See reference map V)
NOTE: The Arab territories occupied since the 1967 war
are not included in the data below unless so indicated.
LAND
20,720 km? (excluding about 64,750 km? of occupied
territory in Jordan, Egypt, and Syria); 20% cultivated, 40%
pastureland and meadows, 4% forested, 4% desert, waste, or
urban, 3% inland water, 29% unsurveyed (mostly desert)
Land boundaries: 1,036 km (prior to 1967 war); including
occupied areas, approximately 1,050 km (1977)
WATER
Limits of territorial waters (claimed): 6 nm
Coastline: 273 km (prior to 1967 war); including occupied
areas, approximately 848 km (1977)
Railroads: 767 km standard gage (1.485 m)
Highways: 4,459 km paved, 7 km gravel/crushed stone,
remainder unknown
Pipelines: crude oil, 708 km; refined products, 290 km;
natural gas, 89 km
Ports: 3 major (Haifa, Ashdod, Elat), 5 minor
Airfields: 55 total, 46 usable; 20 with permanent-surface
runways; 5 with runways 2,440-3,659 m, 7 with runways
’ 1,220-2,4389 m
Civil air: 25 major transport aircraft (including 5 leased
in)
Telecommunications: most highly developed in the
Middle East though not the largest; good system of coaxial
cable and radio relay; 870,000 telephones (24.0 per 100
popl.); 14 AM, 10 FM stations, 15 TV stations and 30
repeater stations; 2'' submarine cables; 1 Atlantic Ocean
satellite station
DEFENSE FORCES
Military manpower: Jewish males 15-49, 859,000;
714,000 fit for military service; average number of Jews
reaching military age (18) annually—32,000 males, 30,000
females; both sexes liable for military service
4
ry na
Ay ipioee
Cairo* —','c392746ee19c70e10cbf8663c25302d39efc67166c5b2886b4b55afc44784d72','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('039e2ece86cd5bfb724bb002548a518323ebad7418ed7ec3da26da0e184db8b7',1980,'IT','Italy','communications',230,'LAND
301,217 km?; 50% cultivated, 17% meadow and pasture,
21% forest, 3% unused but potentially productive, 9% waste
or urban ,
Land boundaries: 1,702 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 4,996 km
Railroads: 20,690 km total; 15,970 km government-
owned standard gage (1.435 m), 7,850 km electrified; 4,720
km non-government owned, 2,507 km standard gage (1.435
m), 1,270 km electrified; 2,218 km narrow gage (0.950 m),
517 km electrified
Highways: 286,400 km total; autostrade 4,800 km, state
highways 41,200 km, provincial highways 91,200 km,
communal highways 149,200 km; 254,400 km concrete,
bituminous, or stone block, 24,800 km gravel and crushed
stone, 7,200 km earth
Inland waterways: 2,500 km navigable routes
Pipelines: crude oil, 1,770 km; refined products, 2,179
km; natural gas, 13,079 km
Ports: 16 major, 22 significant minor
Civil air: 123 major transport aircraft (including 1 leased
in and 1] leased out)
Airfields: 151 total, 15] usable; 81 with permanent-
surface runways; 2 with runways over 3,660 m, 29 with
runways 2,440-3,659 m, 42 with runways 1,220-2,439 m; 11
seaplane stations
Telecommunications: well engineered, well constructed,
and efficiently operated; 15.2 million telephones (27.1 per
100 popl.); 185 AM, 660 FM, and 900 TV stations; 16 coaxial
submarine cables; 2 communication satellite ground stations
with Atlantic Ocean and Indian Ocean antennas
DEFENSE FORCES ;
Military manpower: males 15-49, 13,745,000; 11,547,000
fit for military service; 460,000 reach military age ane
annually
Military budget: for fiscal year ending 31 December
1978, $4,957.2 million; about 7.1% of proposed central
government budget
104
IVORY COAST
Gulf of
- Guinea
Atlantic Ocean
{See reference map Vi}
LAND
323,750 km?; 40% forest and woodland, 8% cultivated,
52% grazing, fallow, and waste; 322 km of lagoons and
connecting canals extend east-west along eastern part of the
coast
Land boundaries: 3,227 km
WATER
Limits of territorial waters (claimed): 6 nm (fishing 12
nm) :
Coastline: 515 km
Railroads: 657 km of the 1,173 km Abidian to Quagadou-
gou, Upper Volta line, all single track meter gage (1.00 m);
only diesel locomotives in use
Highways: 46,775 km total; 2,388 km bituminous and
bituminous-surface treatment; 33,097 km gravel, crushed
stone, laterite, and improved earth; 11,190 km unimproved
Inland waterways: 740 km navigable rivers and numer-
ous coastal lagoons
Ports: 2 major (Abidjan, San Pedro), 3 minor
Civil air: 20 major transport aircraft
Airfields: 50 total, 48 usable; 3 with permanent-surface
runways; 2 with runways 2,440-3,659 m; 8 with runways
1,220-2,489 m; 1 seaplane station.
Telecommunications: system only slightly above African
average; consists of open-wire lines and radio relay links,
which provide incomplete coverage of country; Abidjan is
only center; 58,700 telephones (0.9 per 100 popl.); 2 AM, 4
FM, and 6 TV stations; 1 Atlantic Ocean satellite station; 1
coaxial submarine cable
DEFENSE FORCES
Military manpower: males 15-49, 1,680,000; 865,000 fit
for military service; 78,000 males reach military age (18)
annually ;
Military budget: for fiscal year ending 31 December
1978, $142,697,665; about 7.2% of total operating budget
Military budget: for fiscal year ending 31 March 1979,
$9,417,460 (includes funds for Pioneer Corps and the Arms
of Malta, totaling about $5.1 million); about 3.5% of central
government budget','c5a1e3797e78ebeccaadae9d64d9594dcd20912427270fbeff28208492ef7a62','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14b90267cd0ffc90d84af6423de4395cbecabe9d480928099b00b6a2bfa9343a',1980,'JM','Jamaica','communications',234,'LAND
11,422 km?; 21% arable, 23% meadows and pastures, 19%
forested, 37% waste, urban, or other
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 1,022 km
Railroads: 330 km, all standard gage (1.435 m), single
track
Highways: 11,250 km total; 7,600 km paved, 2,150 km
gravel, 1,500 km improved earth
Pipelines: refined products, 10 km
Ports: 3 major (Kingston, Montego Bay, Montego Free-
port), 10 minor
Civil air: 10 major transport aircraft
Airfields: 42 total, 22 usable; 12 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 1 with runway
1,220-2,489 m; 3 seaplane stations
Telecommunications: fully automatic domestic telephone
network with 109,000 telephones (5.4 per 100 popl.); 1
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
nn 2 ll a, a Ae Pe «OE. SN ee a ee ee” ae
Oe OM Ne ON ON Se ee SO ee ae. oe A RS: ™"
Se eS A SS ee
EE A es, Cee, ed, ee ee NT eee ee tn
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
JAMAICA/JAPAN
Atlantic Ocean satellite station; 8 AM, 11 FM, and 9 TV
stations; 3 coaxial submarine cables
DEFENSE FORCES
Military manpower: males 15-49, 438,000; 313,000 fit for
military service; no conscription; average number currently
reaching minimum volunteer age (18) 28,000
Supply: dependent on U.K. ‘and U.S.
Military budget: for fiscal year ending 31 March 1978,
$26.6 million; about 2.2% of central government budget
Pacific
Ocean
Philippine
Sea
(See reference map Vil}
LAND
370,370 km?; 16% arable and cultivated, 3% grassland,
12% urban and waste, 69% forested
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm)
“Coastline: 12,075 km Japan; 1,610 km Ryukyus
Railroads: 28,912 km total (1976); 1,077 km standard
gage (1.485 m), 27,8835 km predominantly narrow gage
(1.067 m), 6,195 km double track, 7,376 km or 26% of total
route length electrified; 73% government-owned
Highways: 1,067,643 km total (1976); 338,343 km paved,
most. of remainder gravel or crushed stone
Inland waterways: approx. 1,770 km; seagoing craft ply
all coastal “inland seas”
Pipelines: crude oil, 109 km; natural gas, 1,847 km -
Ports: 53 major, over 2,000 minor
Civil air: 24] major transport aircraft
Airfields: 186 total, 176 usable; 122 with permanent-
surface runways; 2 with runways over 3,660 m; 22 with
runways 2,440-3,659 m, 48 with runways 1,220-2,489 m, 5
seaplane stations
DEFENSE FORCES
Military manpower: males 15-49, 30,441,000; 25,522,000
fit for military service; about 815,000 reach military age (18)
annually .
Supply: defense industry potential is large, with capability
of producing the most sophisticated equipment; manufac-
tured equipment includes small arms artillery, armored
vehicles, and other types of ground forces materiel, aircraft
(jet and prop), naval vessels (submarines, guided missile and
108
other destroyers, patrol craft, mine warfare ships, and other
minor craft including amphibious, auxiliaries, service craft,
and small support ships), small amounts of all types of army
materiel
Military budget: for fiscal year ending 31 March 1979,
$9.5 billion; about 5.5% of total budget
-oflatdutas
Caribbean Sea
°
v
* Panama
Barranquilla,
Canal Zone q i
Venezuela
eMedeltin
Bogota','ea80b4974a1e49a0f6361cb0f39307254b18e5fd782472c16259c83ee812e3c4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d01354b16987743db53dee0eef7df9ffd3def58672e1f5c4c0fb20cd080630b5',1980,'JO','Jordan','communications',238,'_ ARABIA
(See reference map V)}
NOTE: The war between Israel and the Arab states in
June 1967 ended with Israel in control of West Jordan.
Although approximately 930,000 persons resided in this area
prior to the start of the war, fewer than 750,000 of them
remain there under the Israeli occupation, the remainder
having fled to East Jordan. Over 14,000 of those who fled
were repatriated in August 1967, but their return has been
more than offset by other Arabs who have crossed and are
continuing to cross from West to East Jordan. These and
certain other effects of the 1967 Arab-Israeli war are not
included in the data below.
LAND
96,089 km? (including about 5,489 km? occupied by
Israel); 11% agricultural, 88% desert, waste, or urban, 1%
forested
Land boundaries: 1,770 km (1967, 1,668 km excluding
occupied areas)
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 26 km
Railroads: 817 km 1.050-meter gage, single track
Highways: 6,332 km total; 4,887 km paved, 1,495 km-
gravel and crushed stone
Pipelines: crude oil, 209 km
Ports: 1 major (Aqaba)
Civil air: 15 major transport aircraft
Airfields: 25 total, 16 usable; 14 with permanent-surface
runways; 4 with runways over 3,660 m, 10 with runways
2,440-3,659 m, 1 with runway 1,220-2,439 m
Telecommunications: adequate system of radio relay,
wire, and radio; 44,000 telephones (1.6 per 100 popl.); 5 AM,
no FM and 6 TV stations; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 674,000; 476,000 fit for .
military service; average number currently reaching military
age (18) annually 33,000 ,
Military budget: for fiscal year ending 31 December
1978, $266 million; 22% of central government budget
KAMPUCHEA
LAND
181,300 km?; 16% cultivated, 74% forested, 10% built-on
area, wasteland, and other
Land boundaries: 2,438 km
WATER
Limits of territorial waters (claimed): 12 nm (economic
including fishing 200 nm)
109
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
KAMPUCHEA/KENYA
Gull of
Thailend = \\
(See reference map Vil)
Coastline: about 443: km
Railroads: 612 km meter gage (1.00 m); govern-
ment-owned
Highways: 13,351 km total; 2,622 km bituminous, 7,105
km crushed stone, gravel, or improved earth; and 3,624 km
unimproved earth; some roads in disrepair
Inland waterways: 3,700 km navigable all year to craft
drawing 0.6 meters; 282 km navigable to craft drawing 1.8
meters
Ports: 2 major, 5 minor
Airfields: 54 total, 25 usable; 7 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 6 with runways
],220-2,489 m; 1 seaplane station
DEFENSE FORCES
Military manpower: males 15-49, 1,815,000; 1,010,000 fit
for military service; 91,000 reach military age (18) annually
Military budget: unknown','ca341912eb43ac2839052baf8176f20bbc0345fe8451b2a7556802fad9b769f9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6dd356281faffe1fe02dc64ad24ceb93c4b80c474de0df332804bc61364831a7',1980,'KE','Kenya','communications',242,'LAND
582,750 km?; about 21% forest and woodland, 13%
suitable for agriculture, 66% mainly grassland adequate for
grazing (1971)
Land boundaries: 3,368 km
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
—
A i all
ae
SNE ee ee ee ee er ee Nar
~
a a a
ee
ee I
ee, ee
ie a dd a ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Indian
Ocean
(See reference map Vi}
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 536 km
Railroads: 2,040 km meter gage (1.00 m)
Highways: 50,840 km total; 4,300 km paved, 12,160 km
gravel and/or -earth; 26,880 km improved earth and. 7,500
km unimproved earth
111
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
KENYA/KOREA, NORTH
Inland waterways: part of Lake Victoria and Lake
Rudolph systems are within boundaries of Kenya
Pipelines: refined products, 483 km
Ports: 1 major (Mombasa)
Civil air: 18 major transport aircraft
Airfields: 236 total, 218 usable; 8 with permanent-surface
runways; 1 with runway over 3,660 m, 3 with runways
2,440-3,659 m, 37 with runways 1,220-2,439 m
Telecommunications: in top group of African systems;
consists of radio-relay links, open-wire lines, and radiocom-
munication stations; ‘principal center Nairobi, secondary
centers Mombasa and Nakuru; 132,000 telephones (1.0 per
100 popl.); 4 AM, 2 FM, and 5 TV stations; 1 Indian Ocean -
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 3,218,000; 1,914,000 fit
for military service; no conscription
Military budget: for fiscal year ending 30 June 1978,
$201,600,000; about 13.4% of central goverriment budget
KOREA, NORTH
China Sea
(See reference map Vil)
LAND
121,730 km?; 17% arable and cultivated, 74% in forest,
scrub, and brush; remainder wasteland and urban
Land boundaries: 1,675 km
WATER
Limits of territorial waters (claimed): 12 nm (economic
200 nm, military 50 nm)
Coastline: 2,495 km
Railroads: none
Highways: 9,020 km total; 320 km paved, 2,700 km
gravel and/or improved earth, 6,000 km unimproved
Inland waterways: Lake Kivu navigable by barges and
native craft
Civil air: 1 major transport aircraft
Airfields: 8 total, 8 usable; 2 with permanent-surface
runways; 2 with runways 1,220-2,439 m, 1 with runway
2,440-3,659 m
Telecommunications: low-capacity radio-relay- system
centered on Kigali; 3,600 telephones (0.1 per 100 popl.); 2
AM, 1 FM, no TV stations; Symphonie COMSAT station
DEFENSE FORCES
Military manpower: males 15-49, 924,000; 468,000 fit for
military service; no conscription; 43,000 reach military age
(18) annually
175
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
RWANDA/ST. CHRISTOPHER-NEVIS-ANGUILLA
Military budget: for fiscal year ending 31 December
1977, $12,436,450; 15.5% of central government budget
ST. CHRISTOPHER-NEVIS-ANGUILLA
Atlantic Ocean','9820360a26e57bebbf399d300d330c5508e97645b4b89e4c8f7bddf60e43c951','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c648a6393ca789447cc2fdc71d083252bec425fbdf1da1a1f889a597d5cf4c1',1980,'SA','Saudi Arabia','communications',246,'(See reference map V}
LAND 7 ; \\
16,058 km? (excluding neutral zone but including islands);
insignificant amount forested; nearly. all: desert, waste; or
_urban
Land boundaries: 459 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 499 km
Railroads: none
Highways: 2,545 km total; 2,255 km bituminous; 290 km
earth, sand, light gravel
Pipelines: crude oil, 877 km; refined products, 40 km;
natural gas, 121 km
Ports: 8 major (Ash Shuwaikh, Ash Shuaybah, Mina al
Ahmadi), 4 minor
Civil air: 18 major transport aircraft (including 6 leased
in)
Airfields: 11 total, 6 usable; 4 with permanent-surface
runways; 3 with runways 2,440-3,659 m, 3 with runways
1,220-2,489 m
Telecommunications: excellent international and ade-
quate domestic telecommunication facilities; 140,000 tele-
phones (13.0 per 100 popl.); 3 AM, 1 FM and 3 TV stations;
1 satellite station with Indian and Atlantic Ocean antennas
DEFENSE FORCES
Military manpower: males 15-49, about 288,000; about
168,000 fit for military service
Military budget: for fiscal year ending 30 June 1978, $845
million; 10% of central government budget
LAOS
LAND
236,804 km*; 8% agricultural, 60% forests, 32% urban,
waste, and other; except in very limited areas, soil is very
poor; most of forested area is not exploitable
Land boundaries: 5,053 km
Highways: about 18,000 km total; 1,300 km bituminous
or bituminous treated, 5,900 km gravel, crushed stone, or
improved earth; 10,800 km unimproved earth and often
impassable during rainy season mid-May to mid-September
Inland waterways: about 4,587 km, primarily Mekong
and tributaries; 2,897 additional kilometers are sectionally
navigable by craft drawing less than 0.5 m
Ports (river): 5 major, 4 minor
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
a
we ta na AA AA Ai ee A
Px
cred
ee RF Be RR ET er I ee: ee
>
]
3
$
,
>
>
5
>
*
»
>
>
>
x
>
;
>
:
I
i
:
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Airfields: 87 ‘total, 77 usable; 9 with permanent-surface
runways; 1] with runways 1,220-2,439 m, 1 with runway
2,440-3,659 m
DEFENSE FORCES
Military manpower: males 15-49, 776,000; 453,000 fit for
military service; average number currently reaching usual
military age (18) annually, 37,000; no conscription age
specified :
Lao People’s Liberation Army (LPLA): the LPLA
consists of an army with naval, aviation, and militia elements
Military budget: unknown
Railroads: none
Highways: 805 km total; 442 km bituminous; 362 km
gravel; undetermined mileage of earth tracks
Pipelines: crude oil, 169 km; natural gas, 97 km
Ports: 1 major (Ad Dawhah), 1 minor
Airfields: 2 total, 1 usable; 2 with permanent-surface
runways, 1 with runway over 3,660 m
Civil air: 2 major transport aircraft, 1 registered in the
U.K.
Telecommunications: good urban facilities; 24,000 tele-
phones (14.8 per 100 popl.); international service through an
Indian Ocean COMSAT station and a troposcatter link to
Bahrainu; 1 AM, 1 FM, and 2 TV stations.
DEFENSE FORCES
Military manpower: males 15-49, about 40,000; about
22,000 fit for military service
Military budget: for fiscal year ending 24 January 1974,
$53,680,900; 18% of central government budget
REUNION
LAND
2,512 km*; two-thirds of island extremely rugged,
consisting of volcanic mountains; 48,600 hectares (less than
one-fifth of the land) under cultivation
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 201 km
Indian
MAD AR
MOZAMBIQUE i ’
(See reference map V}
LAND
Estimated at about 2,331,000 km? (boundaries undefined
and disputed); 1% agricultural, 1% forested, 98% desert,
waste, or urban
Land boundaries: 4,537 km
WATER
Limits of territorial waters (claimed): 12:nm (plus 6 nm
“necessary supervision zone’’)
- Coastline: 2,510 km
Railroads: 575 km standard gage (1.435 m)
Highways: 30,100 km total; 16,500 km paved, 13,600 km
improved earth :
Pipelines: 2,430 km crude oil; 386 km refined products;
98 km natural gas
Ports: 3 major (Jidda, Ad Damman, Ras Tanura), 6 minor
Civil air: 73 major transport aircraft
181
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDPO8-00534R000100140001-7
January 1979
SAUDI ARABIA/SENEGAL
Airfields: 119 total, 88 usable; 30 with permanent-surface
runways; 15 with runways 2,440-3,659 m, 38 with runways
1,220-2,439 m, 5 with runways over 3,660 m
Telecommunications: fair system exists, major expansion
program underway with microwave, coaxial cable, satellite
systems; 200,000 telephones (2.5 per 100 popl.): 6 AM, 1 FM,
11 TV stations, 1 submarine cable; 2 COMSAT stations,
several domestic satellite stations
DEFENSE FORCES
Military manpower: males 15-49, 1,770,000; 1,014,000 fit
for military service; about 70,000 reach military age (18)
annually ;
Military budget: for fiscal year ending 1 July 1979,
$12,936 million; about 32% of central government budget
£
CIA-
Arabian Sea
© Rocotra
500 Kilometers
500 Miles
Boundary representation is
not necessarily authoritative
RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02
Ocean
ana Azores
{Port}
> ia
Canary Is. (Sp)
° 2
2''% 4
Western
Sahara
Partition line shown
by Mauritania-Morocey,
Accord, 1876 Se
ibraltar
Mediterranean Sea','8697a3674a8697933dd3bb4c1569701f52c7771750277d8fcb9ce1524200fc14','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f743aea8189a7bac6ea087dadc14004d1118b3c8063c7ef4d0c044b94adb239',1980,'LB','Lebanon','communications',250,'(See reference map V}
LAND
10,360 km’; 27% agricultural land, 64% desert, waste, or
urban, 9% forested
Land boundaries: 531 km
WATER
Limits of territorial waters (claimed): no specific claims
(fishing, 6 nm)
Coastline: 225 km
Railroads: 378 km total; 296 km standard gage (1.435 m),
82 km 1.050-meter gage; all single track :
Highways: 7,370 km total; 6,270 km paved, 450 km
gravel and crushed stone, 650 km improved earth
Pipelines: crude oil, 72 km
Ports: 3 major (Beirut, Tripoli, Sayda), 5 minor
Civil air: 34 major transport aircraft
Airfields: 8 total, 6 usable; 4 with permanent-surface
runways; 3 with runways 2,440-3,659 m; 2 with runways
1,220-2,439 m
Telecommunications: rebuilding program disrupted; in-
ternational facilities restored, domestic being rebuilt; fair
system of microwave, cable; approx 125,000 telephones (5.0
per 100 popl.); 2 FM, 7 AM, 7 TV stations; 1 Indian Ocean
satellite station; 8 submarine cables.
DEFENSE FORCES
Military manpower: males 15-49, 560,000; 341,000 fit for
military service; average of about 28,000 reach military age
(18) annually','3882e2df655f237c0018c147a574d4c7955cded5720c732d530bc80a351834f6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('940708329c63210c5f3f314162b42652e1abb3e2f7b396340db13e7f1b01157b',1980,'LS','Lesotho','communications',254,'LAND
30,303 km?; 15% cultivable; largely mountainous
Land boundaries: 805 ‘km
118
{See reference map Vi}
Railroads: 1.6 km; owned, operated, and included in the
statistics of the Republic of South Africa
Highways: approx. 3,916 km total; 218 km paved; 993 km
crushed stone, gravel, or stabilized soil; 1,046 km improved,
1,659 km unimproved earth
Civil air: no major transport aircraft
Airfields: 21 total, 21 usable; 3 with runways 1,220-2,439
m, | with permanent surface runway
Telecommunications: system a modest one consisting of a
few landlines, a small radio-relay system, and minor
radiocommunication stations; Maseru is the center; 3,725
telephones (0.3 per 100 popl.); 2 AM, 1 FM, 1 TV station
planned
DEFENSE FORCES .
Military manpower: males 15-49, 256,000; fit for military
service 136,000','f70b4937fe00f8708ea4628648c014cf4a7ea1b363ff7b401bc7dc08300fe59c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('026d5c94f788cb95763c0f99285370016fe62b8594cec04f0094c603267c71b3',1980,'LR','Liberia','communications',258,'a
Monrovia
Atlantic Ocean
(See reference map Vi}
LAND
111,370 km?; 20% agricultural, 30% jungle and swamps,
40% forested, 10% unclassified
Land boundaries: 1,336 km
WATER
Limits of territorial waters (claimed): 22 nm
Coastline: 579 km
Railroads: 499 km total; 354 km standard gage (1.435 m),
145 km narrow gage (1.067 m); all lines single track; rail
systems owned and operated by foreign steel and financial
interests in conjunction with Liberian Government
Highways: 7,952 km total; 603 km bituminous treated;
2.055 km gravel, and 4,731 km improved and 563 km
unimproved earth
Inland waterways: 370 km
Ports: 3 major (Monrovia, Buchanan, Greenville-Sino
Harbor), 4 minor
Civil air: 4 major transport aircraft (including 1 leased in)
Airfields: 80 total, 78 usable; 2 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 4 with runways
1,220-2,439 m; 1 seaplane station
Telecommunications: telephone and telegraph limited;
main center is Monrovia; 3,400 telephones (0.2 per 100
popl.); 5 AM, 2 FM, and 3 TV stations; 1 Atlantic Ocean
Comsat station
DEFENSE FORCES
Military manpower: males 15-49, 382,000; 204,000 fit for
military service; no conscription
Military budget: for year ending 30 June 1979, $8.5
million; 2.5% of central government budget','d4d008d9d496b139bb225cc249d3296c94a32983348708fdc609e1cbc575439b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('339db22c8da3329ac2ea5c914d873895e96060cd50128a6bde8b81a734d8ad5f',1980,'LY','Libya','communications',262,'LAND
1,758,610 km?; 6% agricultural, 1% forested, 93% desert,
waste, or urban
Land boundaries: 4,345 km
WATER
Limits of territorial waters (claimed): 12 nm (except for
‘Gulf of Sidra where sovereignty is claimed and northern
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
I NES TE Ee ee ae eee
ES ee ae es, ae
i i Nn A Tn
Ne ee Ee ee es ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
limit of jurisdiction fixed at 82°30''N. and the unilaterally
proclaimed 100 nm zone around Tripoli)
Coastline: 1,770 km
Railroads: none :
Highways: 16,250 km total; 7,750 km bituminous and
bituminous treated, 8,500 km gravel, crushed stone and
earth
Pipelines: crude oil 3,251 km; natural gas 282 km; refined
products 443 km (includes 217 km liquid petroleum gas)
Ports: 8 major (Tobruk, Tripoli, Benghazi), 4 minor, and 5
petroleum terminals ©
Civil air: 39 major transport aircraft (including 8 leased
in)
Airfields: 86 total, 74 usable; 16 with permanent-surface
runways, 1 with runway over 3,660 m, 13 with runways
2,440-3,659 m, 28 with runways 1,220-2,439 m
121
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
LIBYA/LIECHTENSTEIN
Telecommunications: system is in top one-third of
African systems; consists of radio-relay and _ tropo-
spheric-scatter links, open-wire lines, and radiocommunica-
tion stations; principal centers are Tripoli and Benghazi;
49,800 telephones (1.8 per 100 popl.); 15 AM, 1 FM, and 12
TV stations; 1 coaxial submarine cable
DEFENSE FORCES
Military manpower: males 15-49, 645,000; 382,000 fit for
military service; about 30,000 reach military age (17)
annually; conscription now being implemented
Military budget: for fiscal year ending 31 December
1978, $4389 million; 5% of central government budget','319986ace21a439596cc5b779d8d2af5f80f405bbe8110d47a16159772ba9286','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ba41a4a5a6401546761a78423f285eb2312cc50fd29c52f80b8e1aff321657c',1980,'LI','Liechtenstein','communications',266,'OF GERMANY
AUSTRIA -
(See reference map tV)}
LAND
168 km?
Land boundaries: 76 km
Railroads: 16.00 km, standard gage (1.435 m), electrified;
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Se eo el
ey
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
LIECHTENSTEIN/LUXEMBOURG
owned, operated, and included in statistics of Austrian
Federal Railways
Highways: no information on total kilometers
Civil air: 2 major transport aircraft registered and
operated in Switzerland
Airfields: none
Telecommunications: automatic telephone system serv-
ing about 16,200 telephones (67.7 per 100 popl.); no
broadcast facilities
DEFENSE FORCES
Defense is responsibility of Switzerland','12349687a7b3ef52d206fe0f1e3e86bfae6a68d1af6a270d25d0a83fd95a3f2d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6829af774aa3e6a0697b1806cd14671f227a710735c2702b53c068f3b53c6453',1980,'LU','Luxembourg','communications',270,'“FEDERAL REPUBLIC j
OF GERMANY
KEN BOURG
Railroads: 270 km standard gage (1.435 m); 160 km
double track; 136 km electrified :
Highways: 5,057 km total; 4,911 paved, 78 km gravel; 62
km earth; about 80 km limited access divided highway
completed or under construction
Inland waterways: 37 km; Moselle River
Pipelines: refined products, 48 km
Port: (river) Mertert
Civil air: 10 major transport aircraft
Airfields: 2 total, 2 usable; 1 with permanent-surface
runway; 1 with runway -2,440-3,659 m :
Telecommunications: adequate and efficient _system;
158,000 telephones (44.2 per 100 popl.); 4 AM, 3 FM, 2 TV
stations ;
DEFENSE FORCES .
Military manpower: males 15-49, 90,000; 75,000 fit for
military service; about 3,000 reach military age (19)
annually
Military budget: for fiscal year ending 31 December
1978, $32 million, 3% of the central government -budget','937caa9e699ec9a1d4d33e1041746a2f44f603d40a9ddd1b766cb054df369a11','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c39bdd8858ee9281a652242b846714e17b9f1d26a9b6d392a36b75cbcb9e64f7',1980,'MO','Macao','communications',271,'LAND
15.5 km?*; 10% agricultural, 90% urban
Land boundaries: 201 m
WATER
Limits of territorial waters (claimed): 6 nm; fishing, 12
nm
Coastline: 40 km
124
EJHONG KONG','31d9e43ebb01e6e7e4fb6e0f72d9564c2cde93e53128394d1795c6c0976de418','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b534983ded418d1a0cd25b2f7d9b7f9321032a13e54802d2559b4e940e0a085',1980,'MG','Madagascar','communications',272,'LAND ¢
595,700 km’; 5% cultivated, 58% pastureland, 21%
forested, 8% wasteland, 2% rivers and lakes, 6% other
WATER
Limits of territorial waters (claimed): 50 nm
Coastline: 4,828 km
Railroads: 884 km of meter gage (1.00 m)
Highways: 27,500 km total; 4,525 km paved, 228 km
crushed stone, gravel, or stabilized soil; remainder improved
and unimproved earth (est.)
Inland waterways: of local importance only, Lake
Alaotra, isolated streams and portions of Canal des
Pangalanes
Ports: 4 major (Tamatave, Diego Suarez, Majunga,
Tulear)
Civil air: 3 major transport aircraft
Airfields: 194 total, 120 usable; 28 with permanent-sur-
face runways; 3 with runways 2,440-3,659 m, 42 with
runways ],220-2,489 m
Telecommunications: system above African average;
includes open-wire lines, some radio-relay and coaxial links
and 1 Atlantic Ocean satellite ground station; 28,000
telephones (0.4 per 100 popl.); 10 AM, no FM, and 4 TV
stations
DEFENSE FORCES .
Military manpower: males 15-49, 1,759,000; 1,041,000 fit
for military service; average number reaching military age
(20) annually about 80,000
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
MADAGASCAR/MALAWI
Supply: nearly all from France in the past, now mostly
from West and East European countries; also PRC and
North Korea','7153993e8f986f755101a97de99135b6531f70d1dfad9846932ca844522d5163','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2755598dbd6e6aaaa989639ad18b85ef9e48ea3b57db5cf81c5625c2b8d2588',1980,'ZA','South Africa','communications',273,'Indian Ocean
{See reference map Vi}
NOTE: separate data on Transkei follows last entry for
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
NS ee ee
Se a ee ee ee ee ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
SQUTHERN
RHODESIA
SOUTH
AFRICA
Ocean
(See reference map Vi}
LAND
1,222,480 km? (includes enclave of Walvis Bay, 1,124 km’;
and Transkei, 44,000 km®*); 12% cultivable, 2% forested, 86%
desert, waste, or urban
Land boundaries: 2,044 km
WATER
Limits of territorial waters (claimed): 6 nm (fishing 12
nm)
Coastline: 2,881 km, including Transkei
Railroads: 25,560 km total (includes Namibia); 24,854 km
1.067-meter gage of which 5,292 km are multiple track; over
5,000 km electrified; 706 km 0.610-meter gage single track
Highways: 202,922 km total; 57,4385 km paved, 145,487
km crushed stone, gravel, or improved earth
Pipelines: 836 km crude oil; 1,048 km refined products;
322 km natural gas
Ports: 8 major
Civil air: 78 major transport aircraft
Airfields: 657 total, 520 usable; 66 with permanent-sur-
face runways; 3 with runways over 3,660 m, 6 with runways
2,440-3,659 m, 126 with runways 1,220-2,489 m
Telecommunications: the system is the best developed,
most modern, and highest capacity in Africa and consists of
carrier-equipped open-wire lines, coaxial cables, radio-relay
links, and radiocommunication stations; key centers are
Bloemfontein, Cape Town, Durban, Johannesburg, Port
Elizabeth, and Pretoria; 2.2 million telephones (8.3 per 100
popl.); 13 AM, 84 FM, and 34 TV stations; 1 submarine
cable; 1 satellite station with Atlantic Ocean and Indian
Ocean antennas
DEFENSE FORCES
Military manpower: males 15-49, 5,762,000; 3,549,000 fit
for military service; obligation for service in Citizen Force or
Commandos begins at 18; volunteers for service’ in
permanent force must be 17; national service obligation is
two years
Military budget: for year ending 31 March 1979, $2.0
billion; 18% of central government budget
Transkei
NOTE: Formerly an ‘autonomous tribal homeland in
South Africa, Transkei was granted independence by South
Africa on 26 October 1976, but has not been recognized by
190
SOUTHERN
RHODESIA
SOUTH uesfiu)
EZ,
AFRICA
(See reference map VI)
any other government or any international organization. It
remains heavily dependent on South Africa for administra-
tive and economic support.
LAND
44,000 km? in one large and two small pieces separated
from each other by parts of South Africa
Land boundaries: 1,200 km
WATER
Limits of territorial waters (claimed): 6 nm (fishing 12
nm)
Coastline: 250 km
Railroads: less than 160 km
Highways: 725 km paved, 7,768 km unpaved
Ports: none; Transkei dependent on the South African
port of East London
Telecommunications: open-wire lines to Durban and East -
London
DEFENSE FORCES ;
Military manpower: males 15-49, 501,000; 279,000 fit for
military service
Personnel: 320 army (including 7 officers)
Major ground units: 1 infantry battalion
>
Atlantic
CANARY
ey ee ALGERIA
o ]
{See reference map tV)
LAND
505,050 km®, including Canary (7,511 km?) and Balearic
Islands (5,025 km?); 41% arable and land under permanent
crops, 27% meadow and pasture, 22% forest, 10% urban or
other
Land boundaries: 1,899 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm); 200 nm exclusive economic zone
Coastline: 4,964 km (includes Balearic Islands, 677 km,
and Canary Islands, 1,158 km)','7e8bb4950909d4b6993272e75622b087ad678c2ff8ffa2aca28407f03bc49785','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74df467cad1c7c8ca747c7da653cb386ef24917c0fcc54e168f166dcf54750b4',1980,'MW','Malawi','communications',277,'Indian
Ocean
§ . MOZAMBIQUE
SOUTHERN
RHODESIA
{See reference map Vi}
LAND
95,053 km?; about 31% of land area arable (of which less
than half is cultivated), nearly 25% forested, 6% meadow
and pasture,. 38% other
Land boundaries: 2,881 km
Railroads: 668 km 1.067-meter gage
Highways: 14,913 km total; 1,385 km paved; 631 km
crushed stone, gravel, or stabilized soil; 8,714 km improved
earth, 4,183 km unimproved earth
Inland waterways: Lake Malawi, 1,290 km and. Shire
River, 144 km, 3 lake ports
127
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
MALAWI/MALAYSIA
Ports: no maritime ports
Civil air: 4 major transport aircraft
Airfields: 48 total, 48 usable; 1 with permanent-surface
runway; 9 with runways 1,220-2,439 m
Telecommunications: the system is above average for
African countries and consists of open-wire lines, radio-relay
links, and radiocommunication stations; principal centers are
Blantyre, Zomba, Lilongwe, and Muzuzu; 19,800 telephones
(0.4 per 100 popl.); 6 AM, 4 FM and no TV stations; 1 Indian
Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49,
558,000 fit for military service
Military budget: for fiscal year ending 31 March 1979,
$20.6 million; 6.8% of recurrent central government budget
1,104,000; about
Ports: 3 major (Dar es Salaam, Mtwara, Tanga)
Civil air: 10 major transport aircraft
Airfields: 103 total, 97 usable; 10 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 41 with runways
1,220-2,439 m
Telecommunications: fair system of open wire, radio
relay, and troposcatter; 68,400 telephones (0.4 per 100
popl.); 5 AM, no FM, 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 3,540,000; 2,040,000 fit
for military service
Military budget: for fiscal year ending 30 June 1979,
$148.2 million; 9.6% of central government budget','d880a9502efabbc2e2b3c7f766067d5363f5fbf68b14ea6790df360134f09096','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2632c1b9e52ced7fe4917487844a2211ac63c8f553fbd5a76d2597c1a4b59863',1980,'MY','Malaysia','communications',281,'South China
. Sea
4
(See reference map Vil}
NOTE: Malaysia, which came into being on 16 September
1963, consists of Peninsular Malaysia, which includes 11
states of the former Federation of Malaya, plus East
Malaysia, which includes the 2 former colonies of North
Borneo (renamed Sabah) and Sarawak
LAND .
Peninsular Malaysia: 131,313 km?; 20% cultivated, 26%
forest reserves, 54% other
Sabah: 76,146 km?; 13% cultivated, 34% forest reserves,
53% other
Sarawak: 125,097 km*; 21% cultivated, 24% forest
reserves, 55% other
Land boundaries: 509 km Peninsular Malaysia, 1,786 km
East Malaysia
WATER
Limits of territorial waters (claimed): 12 nm
128
Coastline: 2,068 km Peninsular Malaysia, 2,607 km East','a17101798f6e398c47876a9183a4a4b44298c08785f6da5fbd8fdc74ee56eb8f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6b3f4b2f028c23eb83eb60c0577d9b0e86ea86a42b0106140c8d169b1d4e2fa',1980,'SG','Singapore','communications',286,'Railroads:
Peninsular Malaysia: 1,665 km 1.04-meter gage; 13 km
double track; government-owned
East Malaysia: 154 km meter gage (1.00 m) in Sabah
Highways: |
Peninsular Malaysia: 19,778 km total; 15,925 km hard
surfaced (mostly bituminous surface treatment), 2,970 km
crushed stone/gravel, 883 km improved or unimproved
earth ,
East Malaysia: about 5,426 km total (1,644 km in
Sarawak, 3,782 km in Sabah); 819 km hard surfaced (mostly
bituminous surface treatment), 2,986 km gravel or crushed
stone, 1,671 km earth
Inland waterways:
Peninsular Malaysia: 3,194 km
East Malaysia: 4,087 km (1,569 km in Sabah, 2,518 km
in Sarawak)
Ports:
Peninsular Malaysia: 3 major, 14 minor
East Malaysia: 1 major, 14 minor (5 minor in Sabah; 1
major, 9 minor in Sarawak)
Civil air: approximately 26 major transport aircraft
Pipelines: crude oil, 69 km; refined products, 56 km
Airfields:
Peninsular Malaysia: 62 total, 62 usable; 16 with
130
permanent-surface runways; 3 with runways 2,440-3,659 m,
11 with runways 1,220-2,439 m
Sabah: 34 total, 34 usable; 5 with permanent-surface
runways; 1 with runway 2,440-3,659 m; 4 with runways
1,220-2,489 m
Sarawak: 45 total, 45 usable; 5 with permanent-surface
runways; 4 with runways 1,220-2,439 m
Telecommunications:
Peninsular Malaysia: good intercity service provided
mainly by microwave relay; international service good; good
coverage by radio and television broadcasts; 278,000
telephones (2.7 per 100 popl.); 26 AM, 1 FM, and 16 TV
stations; submarine cables extend to India, Sri Lanka, and
Singapore; connected to SEACOM submarine cable terminal
at Singapore by microwave relay; 1 ground satellite station
Sabah: adequate intercity radio-relay network extends
to Sarawak via Brunei; 23,068 telephones (2.7 per 100 popl.);
5 AM, 1 FM, 5 TV stations, SEACOM submarine cable links
to Hong Kong and Singapore; 1 ground satellite station
Sarawak: adequate intercity radio-relay network ex-
tends to Sabah via Brunei; 28,000 telephones (2.4 per 100
popl.); 4 AM stations, no FM, and 1 TV station
DEFENSE FORCES
Military manpower:
Peninsular Malaysia: males 15-49, . 2,497,000; .
1,588,000 fit for military service; 112,000 reach military age
(21) annually
Sabah: males 15-49, 208,000; 122,000 fit for military
service; 10,000 reach military age (21) annually
Sarawak: males 15-49, 274,000; 163,000 fit for military
service; 11,000 reach military age (21) annually
External defense dependent on loose Five Power Defense
Agreement (FPDA) which replaced Anglo-Malayan Defense
Agreement of 1957 as amended in 1963
Military budget: for fiscal year ending 31 December
1978, $689 million; about 13.4% of central government
budget
(See reference map Vil)
LAND
583 km?; 31% built up area, roads, railroads, and airfields,
22% agricultural, 47% other
WATER -
Limits of territorial waters (claimed); 3 nm
Coastline: 193 km
Railroads: 38 km of meter gage
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
AY ial nn, nl i A RO A A Ae Aa ee Ue Shae GA AR Ra Ae
AR AR ARR
Ne ea a ge a a Ne ee
ee,
NO a
ee ee
> i i, Aa a i a ee
ew
EO Ee ee EE Ee a ei ES ee a OS
ee Ne a Ee ee, ee
i 2 i a MO ek a a
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
SINGAPORE/SOLOMON ISLANDS
Highways: 2,218 km total (1977); 1,806 km paved, 412
km crushed stone or improved earth
Ports: 3 major
* Civil air: approximately 25 major transport aircraft
Airfields: 5 total, 5 usable; 4 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 2 with runways
1,220-2,489 m
Telecommunications: good domestic facilities; good
international service; good radio and television broadcast
coverage; 374,000 telephones (16.3 per 100 popl.); 13 AM, 4
FM, and 2 TV stations; SEACOM submarine cable extends
to Hong Kong via Sabah, Malaysia; 1 ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 660,000; 481,000 fit for
military service
Military budget: for fiscal year ending 31 March 1979,
$411.2 million; about 16.6% of central government budget','d58c849cff712af9cc1508fbe2c2d172f1d4b7ace1251c7901570e0cb1a54de0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5387e04e3c68d1d1b5db0e6972f41cc4590fc91cad5b8a68b3747add0b801025',1980,'MV','Maldives','communications',287,'LAND
298 km; 2,000 islands grouped into 12 atolls, about 220
‘islands inhabited
WATER
Limits of territorial waters (claimed): the land and sea
between latitudes 7°9’N. and 0°45’S. and between longi-
tudes 72°30''E. and 73°48’E; these coordinates form a
rectangle of approximately 37,000 nm‘; territorial sea ranges
from 2.75 to 55 nm; fishing, approximately 100 nm
Coastline: 644 km (approx.)
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
PS Ee, aD Oe ee ae =
ee a
x
~
pe ON OO
wh eet tee An AA
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
MALDIVES/MALI
Arabian
Sea:
F F SRI
*; leccadive LANKA:
| Sea
MALDIVES ; Me
Indian Ocean
{See reference mep Vil}
Railroads: none
Highways: none
Ports: 2 minor
Civil air: no major transport aircraft
Airfields: 2 total, 2 usable; 2 with permanent-surface
runways, 1 with runway 2,440-3,659 m, 1 with runway
1,220-2,439 m :
Telecommunications: minimal domestic and internation-
al telecommunication facilities; 480 telephones (0.4 per 100
popl.); 1 AM station; 1 Comsat station under construction
BamakorGpper
VOLTA
IVORY \\\\
eal |
Atlantic
Ocean
a
{See reference map Vi}
LAND
1,204,350 km?; only about a fourth of area arable, forests
negligible, rest sparse pasture or desert
131
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
MALI/MALTA
Land boundaries: 7,459 km
Railroads: 642 km meter gage (1.00 m)
Highways: approximately 15,699 km total; 1,669 km
bituminous, 3,670 km gravel and improved earth, 10,360 km
unimproved earth
Inland waterways: 1,815 km navigable
Civil air: 8 major transport aircraft
Airfields: 42 total, 38 usable; 7 with permanent-surface’
runways; 2 with runways 2,440-3,659 m, 11 with runways
1,220-2,489 m
Telecommunications: domestic system poor and provides
only minimal service; open-wire and radiocommunication
used for long distance telecommunications; 78,000. tele-
phones (0.1 per 100 popl.); 2 AM, no FM, and no TV
stations; 1 Atlantic Ocean and 1 Indian Ocean satellite
, Station
DEFENSE FORCES
Military manpower: males 15-49, 1,419,000; 801,000 fit
for military service; no conscription
Military budget: for fiscal year ending 31 December
1978, $29,058,304; about 21.7% of central government
budget
Indian Ocean
1200 Kilometers
i. 1200 Miles
Boundary representation is
not necessarily authoritative
503987 1-79
Declassified and Approved For Release 2012/09/02
nay
Ulaanbaatar, te
Mongolia rm
a
atP ei-ching
Pao-t''oue (Pekin
Lan-chou,','bc22dd77ea71adae5bf9797fac938b4fcca78001043978f0c4d746d556f079a3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5346ec1378c7bed36b32c21d696ea0aa598eeab8e2f0a079f35c6caca551f66b',1980,'MT','Malta','communications',291,'LAND
313 km?; 45% agricultural, negligible amount forested,
remainder urban, waste, or other (1965)
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Mediterranéan Sea
(See reference map 1V}
WATER
Limits of territorial waters (claimed): 6 nm (fishing 20
nm)
Coastline: 140 km
Highways: 1,271 km total; 1,159 km paved (asphalt), 77
km crushed stone or gravel, 35 km improved and
unimproved earth
Ports: 1 major (Valletta), 2 minor
Civil air: 4 major transport aircraft (including 3 leased in)
133
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
MALTA/MARTINIQUE
Airfields: 4 total, 2 usable; 2 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 1 with runway
1,220-2,489 m; 1 seaplane station
Telecommunications: modern automatic telephone sys-
tem centered in Valletta; 62,200 telephones (19.6 per 100
popl.); 1 TV, 5 AM, and 4 FM stations; 1 coaxial submarine
cable
DEFENSE FORCES
Military manpower: males 15-49, 79,000; 64,000 fit for
military service
Supply: has received 2 patrol boats, small arms, and
mortars from Libya; vehicles and engineer equipment from','5142d330eedeb65ec96a27d1a76819e02ad0914b58eb6595421af4374111c0e2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3c871ab143e8783287ea44807c92d3f2da6f16de39ef8495502c527e9b363a7',1980,'MQ','Martinique','communications',295,'(See reference map {1}
LAND ,
1,100 km?; 31% cropland, 16% pasture, 29% forest, 24%
wasteland, built on
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 290 km
Railroads: none
Highways: 1,606 km total; 1,200 km paved, 400 km
gravel and earth
‘Ports: 1 major (Fort-de-France), 5 minor
Civil air: 1 major transport aircraft (leased in)
Airfields: 3 usable; 1 with permanent-surface runway; 1
with runway 2,440-3,659 m; 1 seaplane station
Telecommunications: domestic facilities inadequate;
34,700 telephones (10.2 per 100 popl.); inter-island VHF and
UHF radio links; COMSAT ground station; ] AM, 1 FM, and
5 TV stations','32dbfbdf3ca8bf1592f03a6db2b40383d35a6a035550e29b9b6eb9dc4e6dec03','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7dceaed54dd0bfdfe8d8d83d86ae86e4ce817ea959341e4b7bd3230c0f624572',1980,'MR','Mauritania','communications',299,'’
LGERIA
WESTERN
SAHARA
Atlantic
Ocean
(See reference map Vi}
LAND
1,085,210 km’; less than 1% suitable for crops, 10%
pasture, 90% desert
Land boundaries: 5,118 km
WATER
Limits of territorial waters (claimed): 30 nm (fishing, 36
nm)
Coastline: 754 km
Railroads: 650 km standard gage (1.435 m), single track,
privately owned
- Highways: 6,090 km total; 558 km paved; 607 km gravel,
crushed stone, or otherwise improved; 4,925 km unimproved
Inland waterways:. 800 km
Ports: 1 major (Nouadhibou), 2 minor
.Civil air: 7 major transport aircraft
Airfields: 29 total, 29 usable; 9 with permanent-surface
runways; 4 with runways 2,440-3,659 m; 13 with runways
1,220-2,439 m; 1] seaplane station
Telecommunications: poor system of fragmentary open-
wire lines, a minor radio-relay link, and radiocommunica-
tions stations; 2,000 telephones (0.1 per 100 popl.); 1 AM, no ,
FM or TV stations
DEFENSE FORCES ‘
Military manpower: males 15-49, 356,000; 171,000 fit for
military service; conscription law not implemented
136
Supply: primarily dependent on France; has also received
material from Algeria, Morocco, U.K., and Spain
Military budget: for fiscal year ending 31 December 1976
(revised), $29 million; 22% of central government ‘budget
{See reference map Vij
LAND
409,200 km?; about 32% arable and grazing land, 17%
forest and esparto, 51% desert, waste, and urban
Land boundaries: 1,996 km
WATER
Limits of territorial waters (claimed): 12 nm (200 nm
exclusive economic zone)
Coastline: 1,835 km
Railroads: 1,756 km standard gage (1.435 m), 161 km
double track; 708 km electrified
Highways: 55,970 km total; 24,700 km . bituminous
treated, 4,000 km gravel, crushed stone, and improved earth,
27,270 km unimproved earth
142
Pipelines: 362 km crude oil; 491 km (abandoned) refined
products; 24] km natural gas
Ports: 8 major (including Spanish-controlled Ceuta and
Melilla), 10 minor
Civil air: 2] major transport aircraft
Airfields: 78 total, 77 usable; 26 with permanent-surface
_ runways; 2 with runways over 3,660 m, 13 with runways
2,440-3,659 m, 29 with runways 1,220-2,439 m; 4 seaplane
stations : , :
Telecommunications: good system by African standards
composed of open-wire. lines, coaxial, multiconductor and
submarine cables and radio-relay links; principal centers
Casablanca and Rabat, secondary centers Fes, Marrakech,
Oujda, Sebaa Aioun, Tangier and Tetouan; 199,000 tele-
phones (1.1 per 100 popl.); 25 AM, 4 FM, 27 TV stations; 3
submarine cables; 1° Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 3,978,000; 2,373,000 fit
for military service; about 219,000 reach military age (18)
annually; limited conscription
{See reference map Vi)
LAND
266,770 km?, nearly all desert
Land boundaries: 2,086 km
WATER
Limits of territorial waters (claimed): 6 nm (fishing 12
nm)
Coastline: 1,110 km
Railroads: none
Highways: 6,100 km total; 500 km bituminous treated;
5,600 km unimproved earth roads and tracks
Ports: 2 major (El Aaiun, Villa Cisneros), 2 minor
Civil air: approximately 3 major transport aircraft
Airfields: 13 total, 12 usable; 3 with permanent-surface
runways; 1. with runway over 3,660 m; 5 with runways
1,220-2,489 m
Telecommunications: telephone and telegraph poor;
1,000 telephones (0.7 per 100 popl.); 2 AM, no FM, 5 TV
stations
" WESTERN SAMOA
LAND |
2,849 km?; oud of 2 large islands of Savai’i and
Upolu and several smaller islands, including Manono and
Apolima; 65% forested, 24% cultivated, 11% industry, waste,
or urban
WATER
Limits of territorial. waters (claimed): 12 nm ¢
Coastline: 403 km .
224
2, WESTERN
° SAMOA
aCape Verde ''e Nouakchott
2 0','10743796c1c8154138ad1d5517e3fd665a490132f201faa3f9888b7ed25e8667','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42c003d90c7305e08a62f4e08c886f57a07529f376fd28b57e56c3255372d825',1980,'MU','Mauritius','communications',303,'"MADAGASCAR
REUNION
/ndian Ocean
(See reference map Vi}
LAND
1,856 km* (excluding dependencies); 50% agricultural,
intensely cultivated; 39% forests, woodlands, mountains,
river, and natural reserves; 3% built-up areas; 5% water
bodies, 2% roads and .tracks, 1% permanent wastelands
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 177 km
Highways: 1,786 km total; 1,636 km paved, 150 km earth
Civil air: 1 major transport aircraft
Ports: 1 major (Port Louis)
Airfields: 6 total, 5 usable; 1 with permanent surface
runway; 1 with runway 2,440-3,659 m
Telecommunications: ‘radio telegraph service with Re-
union, Malagasy Republic, Seychelles, Zanzibar, and other
places in Africa; 1 AM, no FM, and 4 TV stations; 26,500
telephones (2.9 per 100 popl.); 1 Indian Ocean Comsat
station :
DEFENSE FORCES
Military manpower: males 15-49, 238,000; 124,000 fit for
military service :
Military budget: for fiscal year ending 30 June 1973,
$3,981,038; 6.5% of central government budget
= e o
REUNION
Ocean
(See reference map Vi}
_ Railroads: none
Highways: 1,983 km total; 1,683 km paved, 300 km
gravel, crushed stone, or stabilized earth
Ports: 1 major (Port des Galets)
Civil air: no major transport aircraft
Airfields: 7 total, 7 usable; 2 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 2 with runways
1,220-2,439 m
Telecommunications: adequate system for needs; fairly
modern open-wire lines and radiocommunication stations;
principal center Saint-Denis; radiocommunication to Co-
moros Islands, France, Madagascar, and Mauritius; 32,000
telephones (6.5 per 100 popl.); 1 AM, 1 FM, and 2 TV
stations; 1 Indian Ocean COMSAT station.
DEFENSE FORCES
Military manpower: military age males included with','70045e99a5adc7597bc8c40ee494eadc723d9336d6a41acd9a6ddff3cece3019','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1061eeb5d21cc80947cfccbae07780495cdbeaad82a32b1fcaccd37c2e737d6d',1980,'MC','Monaco','communications',307,'LAND.
1.5 km?
Land boundaries: 3.7 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 4.1 km
Mediterranean Sea
(See reference map lV) °
‘Railroads: 1.6 km of 1.485 m gage
Highways: none; city streets
Ports: 1 minor
. Civil air: no major transport aircraft
Airfields: none
Telecommunications: served by the French communica-
tions system; automatic telephone system with about 23,700
telephones (96.5 per 100 popl.); 2 AM, 4 FM, and 3 TV
stations
DEFENSE FORCES
‘France responsible for defense','e414861a88937b0940bd3ab71e3d9a640188e1be3a79b9fbd95b3c4cb4dccdb8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('478ce58168c1727798186b92e7c896e35265d699a65e1a46eb356a8655335466',1980,'MN','Mongolia','communications',311,'2
Ulaanbaatar *
(See reference map Vil}
LAND
1,564,619 km?; almost 90% of land area is pasture or desert
wasteland, varying in usefulness, less than 1% arable, 10%
forested
’ Land boundaries: 8,000 km
Railroads: 1,516 km; all broad gage (1.524 m) (1976)
Inland waterways: 616 km of principal routes (1975)
, Freight carried: rail—8.1 million metric tons,. 2,718
million metric ton/km (1976); highway—15.2 million metric
tons, 1,060 million metric ton/km (1976); waterway—0.05
million metric tons, 0.04 billion metric ton/km (1975).
DEFENSE FORCES
Supply: military equipment supplied by U.S.S.R.
Military budget: for fiscal year ending 31 December
1977, 405 million tugriks, 12% of total budget','e8a3a24d1057fba92df95bff0d8651a6223e405e15f73ae9af5197d26cde4804','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8234135d03846fba385a0275fe767fb8c28ffc024bee2b73c7e0d6ca8ba35d8c',1980,'PT','Portugal','communications',315,'Atlantic
SAHARA
(See reference map {V}
LAND
Metropolitan Portugal: 94,276 km*, including the Azores
and Madeira Islands; 48% arable, 6% meadow and pasture,
31% forested, 15% waste and urban, inland water, and other
Land boundaries: 1,207 km
WATER
Limits of territorial waters (claimed): 6 nm (fishing 12
nm); 200 nm exclusive economic zone
Coastline: 860 km (excludes Azores (708 km) and
Madeira (225 km))
Railroads: 3,593 km total: state-owned Portuguese Rail-
road Co. (CP) operates 2,807 km 1.665-meter gage (406 km
electrified and 426 km double track), 760 km meter-gage
_ (1.000 m); 26 km 1.665-meter gage double track, electrified,
privately-owned ;
Highways: 29,773 km total; 17,703 km_ bituminous,
bituminous treatment, concrete and stoneblock; 11,587 km
gravel and crushed stone; 483 km improved earth; plus an
additional 16,898 km of unimproved earth roads (motorable
tracks)
Inland waterways: 820 km navigable; relatively unimpor-
tant to national economy, used by shallow-draft craft limited
to 297 metric ton cargo capacity
Pipelines: crude oil, 11 km
Ports: 6 major, 34 minor
Civil air: 81 major transport aircraft (including 2 leased
out and 1 leased in)
Airfields (including Azores and Madeira Islands): 50
total, 48 usable; 3] with permanent-surface runways; 1 with
runway over 3,660 m, 11 with runways 2,440-3,659 m, 9
with runways 1,220-2,439 m; 6 seaplane stations
Telecommunications: facilities are generally adequate;
1.19 million telephones (12.9 per 100 popl.); 39 AM, 34 FM,
and 42 TV stations; 3 submarine coaxial cables; 2 Atlantic
Ocean satellite stations
DEFENSE FORCES
Military manpower: males 15-49, 2,192,000; 1,781,000 fit
for military service; average number reaching age (20)
annually, about 85,000
Military budget: for fiscal year ending 3] December
1977, $575.8 million; about 14% of central government
budget','543453f72cde792eec1a700b77b97c39b6cd9d46729dd583498de729b7e77094','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6dcb1290d150ce1d4b50487004867aed45e501bf33e9c20b2e6886e9b708f502',1980,'MZ','Mozambique','communications',316,'SOUTH O
AFRICA Indian Qcean .
{See reference map Vi}
Land .
786,762 km*; 30% arable, of which 1% cultivated, 56%
woodland and forest, 14% wasteland and inland water
Land boundaries:. 4,627 km
WATER
Limits of territorial waters (claimed): 12 nm (200 nm
exclusive economic zone)
Coastline: 2,470 km
Railroads: 3,161 km total; 3,020 km 1.067-meter gage;
141 km narrow gage (0.750 m)
Highways: 26,477 km total; 4,322 km paved; 607 km
improved earth; 21,548 km unimproved earth, unconnected
Inland waterways: approx. 3,750 km of navigable routes
Pipelines: ¢rude oil, 306 km (not operating)
Ports: 3 major (Maputo, Beira, Nacala), 2 significant.
minor :
Civil air: 7 major transport aircraft (including 1 leased
out) :
Airfields: 325 total, 313 usable; 29 with permanent-sur-
face runways; 6 with runways 2,440-3,659 m; 35 with
runways 1,220-2,439 m
Telecommunications: fair system of troposcatter, open-
wire lines, and radiocommunications; principal centers
Maputo, Beira, and Nampula; 52,200 telephones (0.5 per 100
popl.); 10 AM, 2 FM, no TV «stations; 1 Atlantic Ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 2,192,000; 1,128,000 fit
for military service
Supply: mostly from the USSR and PRC, and to a lesser
extent from other Communist countries and Portugal
Military budget: for fiscal year ending 31 December
1978, $82.6 million; 21.7% of central government budget
a hb
SOUTH
AFRICA
{See reference map Vi}
LAND
17,364 km?; most of area suitable for crops or pastureland
Land boundaries: 485 km
Railroads: 222 km 1.067-meter gage, single track
Highways: 2,653 km total; 224 km paved, 1,114 km
crushed stone, gravel, or stabilized soil, and 1,315 km
improved earth
Civil air: 2 major transport aircraft
Airfields: 27 total, 21 usable; 1 with runway 1,220-
2,439 m :
Telecommunications: system consists of a few open-
wire lines and low-powered radiocommunication stations;
198
Mbabane is the center; 8,200 telephones (1.6 per 100 popl.);
1 AM, 2 FM, 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 109,000; 63,000 fit for
military service','128dfba7d53f17f8531ec465b09e7b5ddc7f41af55708e89e82de6c8829eeeaa','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45d1e9c0e3591b2cf79e0f526a49fd499386bf9ba20dfb479a9bc356915cca48',1980,'NA','Namibia','communications',320,'(South-West Africa)
LAND
823,620 km?; mostly desert except for interior plateau and
area along northern border
Land boundaries: 3,798 km
WATER
Limits of territorial waters (claimed): 6 nm (fishing 12
nm)
Coastline: 1,489 km
Railroads: 2,340 km 1.067-meter gage, single track
Highways: 33,800 km; 3,800 km paved, remainder gravel,
remainder earth roads and tracks
Ports: 2 major (Walvis Bay and Luderitz)
Civil air: 4 major transport aircraft (registered in South
Africa)
Airfields: 113 total, 84 usable; 13 with permanent-surface
runways; ] with runway over 3,660 m; 3 with runways
2,440-3,659 m, 33 with runways 1,220-2,439 m
Telecommunications: sparse system of open wire and
radio relay routes; out-lying areas connected by radiocom-
munication; Windhoek is the only major center; 46,400
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
An mat An Gi
1
AA
arg
‘ee
Rh eae Ae a Sk dee ew Re, A a a ee a Se
a
RAM AR AA
JAR AR AR_ARAA
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
NAMIBIA/NAURU/NEPAL
telephones (6.2 per 100 popl.); 1 FM, no AM and no TV
stations
DEFENSE FORCES
Military manpower: males 15-49, about 218, 000; about
129,000 fit for military service
Defense is responsibility of Republic of South Africa','ed04fd45555b1a0219c973f6cf00f549ee78f854973a29be7e867a3b874aa16a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a15d30d04b5c9ca8040b6f2e3f496a45f73a856deaf9790fad46793d5a00d72',1980,'NP','Nepal','communications',324,'LAND
141,400 km’; 16% agricultural area, 14% permanent
meadows and pastures, 38% alpine land (unarable), waste, or
urban; 32% forested
145
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Bay
of Bengal
{See reference map Vil}
Land boundaries: 2,800 km
Railroads: 63 km (1977), all narrow gage (0.762 m); all in
Terai close to Indian border; 10 km from Raxaul to Biranj is
government owned
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Fy vr i ew Fe Vv ere eV ee er OTR RE TOE YELLS OOP lls lClCUDOUUCOCUN ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
NEPAL/NETHERLANDS
Highways: 4;1386 km ‘total; 1,751 km paved, 556 km
gravel or crushed stone, 1,829 km improved and unim-
proved earth; additionally 322 km of seasonally motorable
tracks
Civil air: 5 major transport aircraft
Airfields: 52 total, 51 usable; 5 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 7 with runways
1,220-2,439 m .
Telecommunications: poor telephone and_ telegraph
service; good radiocommunication and broadcast service;
international radiocommunication service is poor; 14,000
telephones (0.1 per 100 popl.); 8 AM, no FM, and no TV
stations
DEFENSE FORCES :
Military manpower: males 15-49, 3,100,000; 1,612,000 fit
for military service; 145,000 reach military age (17) annually
Military budget: for fiscal year ending 14 July 1979,
$16.4 million; 5.2% of central government budget','f28ace303cd845e5243e68f7ecc13c4d6aa0ccfb002b71d03bf9964e366776c1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e9fd1e4922e4beacb92c23ac05c3044bf313aa27b29e86948a4e8125b39a4e2',1980,'NL','Netherlands','communications',328,'UNITED
KINGDOM
{See reference map 1V}
LAND
33,929 km*; 70% cultivated, 5% waste, 8% forested, 8%
inland water, 9% other
Land boundaries: 1,022 km
WATER .
Limits of territorial waters (claimed): 3 nm (fishing, 12
nm)
Coastline: 451 km
Railroads: 2,979 km standard gage (1.435 m); 2,813 km
government-owned (NS), 1,638 km electrified, 1,556 km
double track; 166 km _ privately-owned
Highways: 104,480 km total; 86,354 km paved (including
1,839 km of limited access, divided highways); 18,126 km
gravel, crushed stone
Inland waterways: 6,340 km, of which 35% is usable by
craft of 900 metric ton capacity or larger
Pipelines: 418 km crude oil; 965 km refined products;
4,489 km natural gas
Ports: 8 major, 5 minor
Civil air: 97 major transport aircraft (including 15 leased
out and 4 leased in)
Airfields: 29 total, 28 usable; 16 with permanent-surface
runways; 13 with runways 2,440-3,659 m, 3 with runways
1,220-2,439 m
Telecommunications: highly developed, well maintained,
and integrated; extensive system of multiconductor cables,
supplemented by radio-relay links; 5.41 million telephones
(39.2 per 100 popl.); 6 AM, 19 FM, and 16 TV stations; 12
coaxial submarine cables; 1 Atlantic Ocean and 1 Indian
Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 3,564,000; 3,197,000 fit
for military service; average number reaching military age
(20) annually 120,000
Military budget: for fiscal year ending 31 December
1978, $4.232 million; about 10% of central government
budget
NETHERLANDS ANTILLES
Atlantic Ocean
Eb
NETHERLANDS .
Caribbean ANTILLES ~
Sea .','e2978f7799d21ffadd6d768d749def60e5184121f21bf82e6e104e4b0261427c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b3e3807fab5a3689b218c6f5032b5ca391345e0f251f1391a26971573d77205',1980,'NZ','New Zealand','communications',332,'LAND
268,276 km?; 3% cultivated, 50% pasture; 10% parks and
reserves; 20% waste, water, etc., 1% urban, 16% forested; 4
principal islands, 2 minor inhabited islands, several minor
uninhabited islands
WATER
Limits of territorial waters (claimed): 12 nm (economic
including fishing 200 nm)
Coastline: about 15,134 km','111075223ef47efb52423e061355261ded1ba6a7ecab78d3f7e6933102e0fc85','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('930a6bc0167f9ddb822e85f1e7e8f545f49272eacfe7e940001ff710d215b5e9',1980,'NI','Nicaragua','communications',339,'Railroads: 318 km 1.067-meter gage, government owned
Highways: 18,150 km total; 1,550 km paved, 7,200 km
otherwise improved, 9,400 km unimproved
Inland waterways: 2,220 km, including 2 large lakes
Pipelines: crude oil, 56 km
. Ports: 4 major (Corinto, Puerto Cabezas, Puerto Somoza,
San Juan del Sur), 6 minor :
. Civil air: 12 major transport aircraft (including 2 leased
in)
Airfields: 426 total, 404 usable; 8 with permanent-surface
runways; 10 with runways 1,220-2,439 m; 2 seaplane stations
Telecommunications: low-capacity wire and radio-relay
network; connection into Central American microwave. net;
satellite ground station; 55,800 telephones (2.5 per 100
popl.); 85 AM, 30 FM, and:7 TV -stations
154
DEFENSE FORCES
Military manpower: males 15-49, 507,000; 313,000 fit for
_military service; 26,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December
1978, $56.2 million for the Ministry of Defense, including
civil functions (e.g., police and civil air); 13% of central
government budget ,
{See reference map Vi}
LAND
1,266,510 km*; about 3% cultivated, perhaps 20% some-
what arable, remainder desert
Land boundaries: 5,745 km','5bb1302116d954d4c015b80e632810e956e21d1ddf084e9bdf4d2937fc33ca05','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6792c6fceed653f4ad303b4494ead110fda8fe6925b7474e844d6c4018c26038',1980,'NE','Niger','communications',343,'Railroads: none
livestock; ©
Highways: 7,582 km total; 1,759 km bituminous, 2,79
km gravel, 3,082 km unimproved earth :
Inland waterways: Niger River navigable 300 km from
Niamey to Gaya on the Benin frontier from mid-December
through March
Ports: Niger landlocked; outlet to sea is Cotonou, Benin
Civil air: 3 major transport aircraft
Airfields: 66 total, 62 usable; 5 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 18 with runways
1,220-2,439 m
Telecommunications: sparse system of open-wire lines,
radio-relay links, and small radiocommunications stations;
principal telecommunication center Niamey; 8,000 tele-
phones (0.2 per 100 popl.); 10 AM stations, no FM, and 1 TV
‘Station; 1 Atlantic Ocean Comsat station
DEFENSE FORCES
Military manpower: males 15-49, 1,105,000; 593,000 fit
for, military service; about 50,000 reach military age (18)
annually
Military budget: for fiscal year ending 30 September
1978, $16.8 million; about 9.3% of central government
budget','3f08be2f0fb747baf2c8ee5c9ad2f82606d4cf73a996c39028edd1692a120d99','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f171510fb76ff2c798f4f8105fe3c3c2b5e8cb04485ccf90f425a969fece323',1980,'NG','Nigeria','communications',344,'(See reference map VI)
LAND ;
924,630 km*; 24% arable (13% of total land area under
cultivation), 35% forested, 41% desert, waste, urban, or other
Land boundaries: 4,034 km
WATER :
Limits of territorial waters (claimed): 30 nm
Coastline: 853 km
155
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Railroads: 3,505 km 1.067-meter gage
Highways: 89,318 km total 15,300 km paved (mostly
bituminous surface treatment); remainder laterite, gravel,
crushed stone, improved earth ;
Inland waterways: 8,575 km consisting of Niger and
Benue rivers and smaller rivers and creeks; additionally,
Kainji Lake has several hundred miles of navigable lake
routes
Pipelines: 1,207 km crude oil; 97 km natural gas; 5 km
refined products
Ports: 2 major (Lagos/Apapa, Port Harcourt), 10 minor
Civil air: 89 major transport aircraft (including 6 leased
in)
Airfields: 83 total, 79 usable; 17 with permanent-surface
runways; 7 with runways 2,440-3,659 m, 22 with runways
1,220-2,439 m ,
Telecommunications: above average system composed of
tadio-relay links, open-wire lines, and radiocommunication
stations; principal center Lagos, secondary centers Ibadan
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
ie ain i i a ae
eT ee ee ee ee ee ee Oe. a ee ee ee a ee eT ee ee a eT Ne. ee ee en a ee ae ee we
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
NIGERIA/NORWAY
and Kaduna; 121,000 telephones (0.2 per 100 popl.); 25 AM,
6 FM, and 9 TV stations; ‘1 Atlantic Ocean and 1 Indian
Ocean satellite station and 19 domestic stations
DEFENSE FORCES
Military manpower: males 15-49, 15,551,000; 8,895,000
fit for military service; average number reaching military
age (18) annually 716,000
'' Military budget: for fiscal year ending 3] March 1979,
$2.1 billion; about 16.8% of central government budget','31884d99b1a21af7f1706c505cf10dd1845ff63bf3cd5bcb6b28cb595faa5ac0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2cbb8a46b4ffc7596d04cceb8684a89ea0f45ff5a767deaf7a74e14ac381fd09',1980,'NO','Norway','communications',348,'Norwegian
(See reference map iV}
LAND
Continental Norway, 323,750 km*; Svalbard, 62,160 km?;
Jan Mayen, 373 km*; 3% arable, 2% meadows and pastures,
21% forested, 74% other
Land boundaries: 2,579 km
WATER
Limits of territorial waters (claimed): 4 nm (fishing 200
nm); 200 nm exclusive economic zone
Coastline: mainland 3,419 km; islands 2,413 km (excludes
Jong fjords and numerous small islands and minor indenta-
tions which total as much as 16,093 .km_ overall)
Railroads: 4,257 km standard gage (1.435 m); Norwegian
State Railways (NSB) operates 4,241 km (2,440 km
electrified and 91 km double track); 16 km privately-owned
and .electrified
Highways: 78,116 km total; 17,699 km concrete and
bitumen; 19,277 km bituminous treated; 41,140 km gravel,
crushed stone, and earth -
Inland waterways: 1,577 km; 1.5-2.4 m draft vessels
maximum
Pipelines: refined products, 53 km
Ports: 9 major, 69 minor
Civil air: 49 major transport aircraft
Airfields: 101 total, 101 usable; 52 with permanent-
surface runways; 12 with runways 2,440-3,659 m, 15-with
runways 1,220-2,439 m; 20 seaplane stations ;
158
Telecommunications: high-quality domestic and interna-
tional telephone, telegraph, and telex service; 1.48 million
telephones (36.6 per 100 popl.); 40 AM, 357 FM, and 740 TV
stations; 5 coaxial submarine ‘cables; 2 domestic satellite
stations
DEFENSE FORCES
Military manpower: males 15-49, 938,000; 763,000 fit for
military service; average number reaching military age (20)
annually, 31,000
Military budget: proposed for fiscal year. ending 31
December 1979, $1.4 billion; about 9.3% of proposed central
government budget
WEMEN YEMEN
is) A)
Arabian Sea
(See reference map V)
LAND
About 212,380 km?; negligible amount forested, remain-
der desert, waste, or urban
Land boundaries: 1,384 km
WATER .
Limits of territorial waters (claimed): 12 nm (fishing 50
nm) ;
Coastline: 2,092 km
Highways: 2,816 km total; 5 km bituminous surface,
2,811 km motorable track ,
Pipelines: crude oil 370 km; natural gas 200 km
Ports: 1 major (Qaboos), 3 minor
Civil air: 21 major transport aircraft
Airfields: 164 total, 180 usable; 4 with permanent-surface
runways; ] runway over 3,660 m, 5 with runways
2,440-3,659 m, 46 with runways 1,220-2,439 m
Telecommunications: fair system of open-wire, radio-re-
lay and radiocommunications stations; 2 satellite ground —
stations; 7,300 telephones (1.3 per 100 popl.); 3 AM, no FM,
2 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 124,000; 72,000 fit for
military service','0a8052c8add98b0b8ec2960497c6858ec81eca04c215e721f04c1bae77557589','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('179afc4530395f359cb2567f1a89c565db98bc0da515cf72a8042ba0f251f2b7',1980,'PK','Pakistan','communications',352,'Arabian Sea
{See reference mep Vil}
LAND
803,000 km? (includes Pakistani part of Jammu-Kashmir),
40% arable, including 24% cultivated; 23% unsuitable for
cultivation; 34% unreported, probably mostly waste; 3%
forested
Land boundaries: 5,900 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm; plus right to establish 100 nm conservation zones
beyond territorial sea); 200 nm exclusive economic zone
Coastline: 1,046 km
Railroads: 8,565 km total (1977); 446 km meter gage.
(1.000 m), 7,507 km broad gage (1.676 m), 612 km
narrow gage (0.762 m); 1,022 km double track; 286 km
electrified; government-owned
Highways: 70,424 km total (1977); 19,296 km paved,
13,019 km gravel, 1,854 km improved earth, 36,255 km
unimproved earth
Inland waterways: 1,850 km
Pipelines: 230 km crude oil; 1,931 km natural gas
Ports: 1 major, 5 minor
Civil air: 27 major transport aircraft
Airfields: 108 total, 102 usable; 63 with permanent-sur-
face runways; 1 with runway over 3,660 m, 25 with runways
2,440-3,659 m, 47 with runways 1,200-2,439 m
Telecommunications: good international radiocommuni-
cation service over CENTO microwave and intelsat satellite;
domestic radiocommunications poor; broadcast service very
good; 300,000 (est.) telephones (0.4 per 100 popl.); 27 AM,
no FM, 16 TV stations, and 4 repeaters; 1 ground satellite
station
DEFENSE
Military manpower: males 15-49, 17,054,000; 10,136,000
fit for military service; 858,000 reach military age (17)
annually
Military budget: for fiscal year ending 30 June 1978, $996
million; about 28.4% of central government budget','ea8e8b9ebcb09fb3007d0e31bfa2faeea83895ac748970ad4852cfb46801af0f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e3c756f528ea401633ca44c3626a4a52001e93748db9733364551bab863e342',1980,'PA','Panama','communications',356,'Land boundaries: 630 km
WATER
Limits of territorial waters (claimed): 200 nm (continen-
tal shelf including sovereignty over superjacent waters)
Coastline: 2,490 km :
Railroads: 249 km total; 77 km 1.524-meter gage, 172 km
0.914-meter gage ,
Highways: 7,700 km total; 2,500 km paved, 2,600 km
gravel or crushed stone, 2,600 km improved and: unim-
proved earth; Panama Canal Zone 240 km; 230 km paved
10 km gravel
>
Inland waterways: 800 km navigable by shallow draft _
vessels; 82 km Panama Canal
Pipelines: refined products, 96 km
Ports: 2 major (Cristobal/Colon/Coco Solo, Balboa/ .
Panama City), 10 minor
Civil air: 19 major transport aircraft (including 2 leased
in)
Airfields: (including Canal Zone) 152 total, 152 usable; 36
with permanent-surface runways; 2 with runways
2,440-3,659 m; 16 with runways 1,220-2,439 m; 2 seaplane
stations
Telecommunications: domestic and international telecom
facilities well developed; connection into Central American
microwave net; COMSAT ground station; 155,200 tele-
phones (9.0 per 100 popl.); 90 AM, 30 FM, and 13 TV
stations; 1 coaxial submarine cable
DEFENSE FORCES
Military manpower: males 15-49, 425,000; 293,000 fit for
military service; no conscription
Military budget: for fiscal year ending 31 December
1976, $32.6 million; about 10% of central government
budget
Canal Zone
_ (U.S. juris)
Re
Venezuela
4 Bogota','ca7c6fbe7f344283f14b630ecf2dc2d182311c56ad6258c9774e112987fac129','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('232bdcfc4037c0accf4fabd1bee7609d1a526fcfef412650a523af2e0e845e96',1980,'PY','Paraguay','communications',360,'LAND
406,630 km?*; 2% under crops, 24% meadow and pasture,
52% forested, 22% urban, waste, and other
Land boundaries: 3,444 km
BOLIVIA BRAZIL
d Atlantic Ocean -
(See reference map tit}
Railroads: 1,043 km total; 487 km standard gage (1.435
164
m), 186 km meter gage (1.00 m), 470 km various narrow
gage (privately owned)
Highways: 8,800 km total; 1,100 km paved, 7,700 km
earth
Inland waterways: 3,100 km
Ports: 1 major (Asuncion), 9 minor (all river)
Civil air: 4 major transport aircraft
Airfields: 953 total, 814 usable; 1 with permanent-surface
runway; 1 with runway 2,440-3,659 m, 16 with runways
1,220-2,439 m; 1 seaplane station
Telecommunications: local telecom facilities in Asuncion
good, intercity microwave net; 41,600 telephones (1.5 per
100 popl.); 25 AM, 9 FM stations, and 1 TV station; 1
Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 633,000; 483,000 fit for
military service; average number currently reaching military
age (17) annually, 33,000 ,
‘Military budget: for fiscal year ending 31 December
1978, $41.2 million; about 14.7% of central government
budget
Pacific
(See reference map til}
LAND
1,284,640 km? (other estimates range as low as 1,248,380
km?); 2% cropland, 14% meadows and pastures, 55%
forested, 29% urban, waste, other “>
Land boundaries: 6,131 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 2,414 km.','c590e9ccc0b1387e6ab5bac88c78b583e8822794fd6a05d33cb76e185914fd2b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44d8b9b873f1eab04b38277c6508e8f5dca3fe14686f7a6981afbb9e8bcaefc4',1980,'PE','Peru','communications',367,'Railroads: 2,148 km total; 1,776 km standard gage (1.435
m), 46 km 0.60-meter gage, 326 km 0.914-meter gage; 14 km
double track
Highways: 52,400 km total; 5,400 km paved, 9,900 km
gravel, 14,400 km improved earth, 22,700 km unimproved
earth
Inland waterways: 8,600 km of navigable tributaries of
Amazon River system and 208 km Lake Titicaca
Pipelines: crude oil, 730 km; natural gas and natural gas
liquids, 64 km
Ports: 7 major, 20 minor
Civil air; 29 major transport aircraft
Airfields: 305 total, 304 usable; 24 with permanent-sur-
face runways; 2 with runways over 3,660 m, 20 with
runways 2,440-3,659 m, 49 with runways 1,220-2,439 m; 3
seaplane stations
Telecommunications: fairly adequate for most require-
ments; new nationwide radio-relay system; 1 Atlantic Ocean
satellite station; 410,000 telephones (2.5 per 100 popl.); 200
AM, 7 FM, and 31 TV stations
DEFENSE FORCES
Military manpower: males 15-49, 3,952,000; 2,664,000 fit
165
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
PERU/ PHILIPPINES
for military service; average number currently reaching
military age (20) annually, 175,000
Military budget: for fiscal year ending 31 December
1978, $254 million; about 11.4% of central government
budget','237a95e6f08697510e7e4ae25479edebbc62a56a705afa51688a018cf8818d89','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c73ca4792db5a4f7018353436c8db64f1a01ddc9b597d53ab5d59a638f45c212',1980,'PL','Poland','communications',368,'LAND
312,854 km*; 49% arable, 14% other agricultural, 27%
forested, 10% other
Land boundaries: 3,090 km
WATER
Limits of territorial waters (claimed): 3 nm (3 nm
contiguous zone claimed in addition to the territorial sea)
(fishing 12 nm)
Coastline: 491 km
PHILIPPINES /POLAND
(See reference map {V}
Railroads: 26,695 km total; 23,816 km standard gage
(1.435 m), 2,879 km other gage; 7,474 km double track;
6,308 km electrified; government owned (1977)
Highways: 305,863 km total; 65,000 km concrete, asphalt,
stone block; 98,000 km crushed stone, gravel; 142,863 km
earth (1977)
168
Inland waterways: 3,759 km navigable streams and
canals (1977)
Pipelines: 3,540 km for natural gas; 1,515 km for crude
oil; 322 km for refined products
Freight carried: rail—48] million metric tons (1977),
135.4 billion metric ton/km (1977); highway—2,039 million
metric tons, 40.3 billion metric ton/km (1977); waterway—
19.1 million metric tons, 3.0 billion metric ton/km;
approximately 1,650 waterway craft with 525,600 metric ton
capacity (1977)
Ports: 4 major (Gdansk, Gdynia, Szczecin, Swinoujscie), 6
minor (1977); principal inland waterway ports are Kozle,
Wroclaw, and Warsaw (1978)','a99588fc604c17659f0be5b27afb3f67b6d80ba4c8ca1e02b9a750f72a8b69e1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c694aa61b794c478a8a6d52dfc6e4fabfe994389b1a10e40e92518e17140a2d1',1980,'QA','Qatar','communications',375,'LAND
About 10,360 km?; negligible amount forested; mostly
desert, waste, or urban
Land boundaries: 56 km
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 563 km','217966ebc8b832c6e5ae17c7ed95c282f6d24ebb0166a19359b6336056336e76','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dfae4c941cba8424437eeaa1b44c7bf72005beada8cfe54856fdc877303a2871',1980,'RW','Rwanda','communications',377,'{See reference map Vi}
LAND
25,900 km*; almost all the arable land, about 1/3 under
cultivation, about 1/3 pastureland
Land boundaries: 877 km','8a62bfe3526526f505ef463279259a1e962bb6e584c6ec89dec510f3f64cdd54','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ee4c03fe85051153ee0d2dbd034fbb3d567d85f5db268a106387f21ef184821',1980,'AI','Anguilla','communications',381,'2
Co :
ST. CHRISTOPHER %
NEVIS ° ee
2
(See reference map Il}
LAND .
389 km?; 40% arable, 10% pasture, 17% forest, 33%
wasteland and built-on
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 193 km
Railroads: 57 km, narrow gage (0.760 m) on St. Kitts for
sugar cane
Highways: 300 km total; 100 km paved, 150 km otherwise
improved, 50 km unimproved. earth
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
ST ATR
Ate PAR Le a Ue Re ee a
ATT Al A aA AA Ae. Ad.
a
AA RaaAA Asa RA aAR.AA OA AA,
Ce Se a ee ee Ee ee ee ee, ee er Te
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
ST. CHRISTOPHER-NEVIS-ANGUILLA/ST. LUCIA
Ports: 3 minor (1 on each island)
Civil air: no major transport aircraft
Airfields: 3 total, 3 usable; 3 with permanent-surface
runways; 1 with runway 1,220-2,439 m; 1 seaplane station
Telecommunications: good interisland VHF/UHF radio
connections and international link via Antigua; about 2,500
telephones (4.4 per 100 popl.); 8 AM and 5 TV stations
ST. LUCIA
Atlantic Ocean
nn
o
OOM.
REP.
oO
=>
Caribhean Sea %
: ° ST. LUCIA
Z|
(See reference map i)
LAND
616 km?; 50% arable, 3% pasture, 19% forest, 5% ‘unused
but potentially productive, 28% wasteland and _ built-on
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 158 km
Railroads: none
Highways: 750 km total; 450 km paved; 300 km otherwise
improved
Ports: 1 major (Castries), 1 minor
Civil air; no major transport aircraft
Airfields: 2 total, 2 usable; 2 with permanent-surface
runways, 1 with runway 2,440-3,659 m, 1 with runway
1,220-2,439 m; 1 seaplane station
Telecommunications: fully automatic telephone system
with 6,600 telephones (5.8 per 100 popl.); direct radio-relay
link with Martinique; interisland tropospheric links to
Barbados and Antigua; 3 AM stations, 1 TV station
177
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
ST. VINCENT/SAN MARINO
ST. VINCENT
Atlantic Ocean
REP.
oe A> o
(See reference map tl}
LAND
889 km? (including northern Grenadines); 50% arable, 3%
pasture, 44% forest, 8% wasteland and built-on
WATER
Limits of territorial waters (claimed): 3 nm
Coastline: 84 km
Railroads: none ;
Highways: 600 km total; 300 km paved; 150 km otherwise
improved; 150 km unimproved earth
Ports: 1 major, 1 minor
Civil air: no major transport ‘aircraft
Airfields: 5 total, 4 usable; 2 with permanent-surface
runways, 1 with runway 1,220-2,439 m
Telecommunications: islandwide fully automatic tele-
phone system with 4,900 sets (4.8 per 100 popl.); VHF/UHF
interisland links to Barbados and the Grenadines; 2 AM
stations','88e72b890b6697f665a0ee607c48d08d060a576bc192397219489cb6e82f922f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f49cfd9b72c5a10ec4d8601f8510204dedd6dabeec957f7601901e3088125ebc',1980,'SM','San Marino','communications',385,'‘LAND
62 km?*; 74% cultivated, 22% meadows and pastures, 4%
built-on
Land boundaries:.34 km
Railroads: none
Highways: about 104 km
Civil air: no major transport aircraft
‘Airfields: none
Telecommunications: automatic telephone system serv-
ing 5,700 telephones (28.1 per 100 popl.); no radiobroadcast-
ing or television facilities
SAO TOME AND PRINCIPE -
- CAMEROON ,
Ak:
SAG TOME
ON EQUATORIAL','85bad307caa17b40ce62c631dd3e8883c5376b10262dbb2d01e651d160e9108a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('933f9408d54e2edb52195cd4e3ea75e16b91ab82d9db4e12c201862a8006ab24',1980,'SC','Seychelles','communications',389,'Indian Ocean
oe Vie toria
(See reference map Vij}
LAND
404 km*; 54% arable land, nearly all of it is under
cultivation, 17% wood and forest land, 29% other (mainly
reefs and other surfaces unsuited for agriculture), 40 granitic
and 43 coral islands
WATER
Limits of territorial waters (claimed): 3 nm (fishing, 12
nm)
Coastline: 491 km (Mahe Island 93 km)
Railroads: none
Highways: 215 km total; 145 km bituminous, 70 km
crushed stone or earth
Ports: 1 small port (Victoria)
Civil air: no major transport aircraft
Airfields: 7 total, 7 usable (on Praslin Island, Astove
Island, Bird Island, Mahe Island); with 1 permanent-surface
runway 2,440-3,659
Telecommunications: direct radiocommunications with
adjacent island and African costal countries; 3,900 tele-
phones (6.4 per 100 popl.); 2 AM, no FM, and no TV
stations; Indian Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 14,000; 7,000 fit for
military service :
Supply: infantry-type weapons and ammunition from
Tanzania','eb89c0dc06cf02938ffc3e2092bf3561edb571440ab72b1ad81cdeb16366803e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f12226d1e6d304ddce3559631c296fdb71ed8c9df8bff21dc677a6e563195b9c',1980,'SL','Sierra Leone','communications',393,'GUINEET,
BISSAU
A tlantic
Ocean
(See reference map Vi}
LAND
72,261 km*; 65% arable (6% of total land area under
cultivation), 27% pasture, 4% swampland, 4% forested
Land boundaries: 933 km
WATER
Limits of territorial waters (claimed): 200° nm
Coastline: 402 km
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
a ag Sg "ggg a I gg age" =
a i i a cn a cn i i a A at el te es i tin a i i ni al
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Railroads: about 84 km narrow gage (1.067 m) jaiuataly
owned mineral line operated by the Sierra Leone Develop-
ment Company
Highways: 7,111 km total; 1,230 km biganiious 507 km
laterite (some gravel), and 5,374 km improved earth
Inland waterways: 800 km; 600 km navigable year-round
Ports: 1 major (Freetown), 2 minor
Civil air: no major transport aircraft 7
Airfields: 16 total, 16 usable; 6 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 5 with runways
1,220-2,489 m; 1 seaplane station
Telecommunications: telephone and tetegraph are inade-
quate; 15,000 telephones (0.5 per 100; popl.); 2 AM stations,
no FM, and 1 TV station
DEFENSE FORCES
Military manpower: males 15-49, 740,000; 357,000 fit for
military service; no conscription
'' Military budget: for year ending 30 June 1978,
$11,379,310 (excluding procurement funds); 8.5% of central
government budget —
185
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979','8671aba31a265a314a6ebb3076eb51820a32b22bb4b4bf035ca40330ca5cca7d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa9bcb570916cd490e78c193d992172673434225a8054ac64c9cb61ea669cbd5',1980,'SB','Solomon Islands','communications',399,'SOLOMON
‘sy % ISLANDS
Honiaraty %
Coral Sea
‘AUSTRALIA ; - Pacific |
’ Ocean
(See reference map Viil}
NOTE: This newly independent (as of 7 July 1978)
archipelagec nation includes southern Solomon Islands,
primarily Guadalcanal, Malaita, San Cristobal, Santa Isabel,
* Choiseul. Northern Solomon Islands constitue part of Papua
New Guinea.
LAND |
About 29,785 km*
WATER
Limits of territorial waters: 3 nm (fishing 200 nm)
Coastline: about 5,313 km
Railroad: none
Highways: 834 km total; 241‘km sealed or all-weather
Inland waterways: none ;
Ports: 5 minor
Civil air: no major transport aircraft
Airfields: 24 total, 22 usable; 1 with permanent-surface
runway; 5 with runways 1,220-2,439 m; 1 seaplane station
Telecommunications: 3 AM broadcast, no FM, and no
TV stations; 10,000 radio receivers, 1,726 telephones, no TV
187
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
SOLOMON ISLANDS/SOMALIA/SOUTH AFRICA
sets; international connections with London, England, via
high frequency radio','ec66c402c1e5143f1df3ede23f8a7b86b08b9a90c03531eb82616abba1176877','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d03861ad01f5fc028b70904971fdb5b0c90c0ffca25786cc5271c2a3a265da1',1980,'SO','Somalia','communications',403,'(See reference map Vi}
LAND
‘637,140 km?; 13% arable (0.3% cultivated), 32% grazing,
14% scrub and forest, 41% mainly desert, urban, or other
Land boundaries: 2,263 km
WATER
Limits of territorial waters (claimed): 200 nm
Coastline: 3,025 km
Railroads: none
Highways: 13,540 km total; 1,900 km paved, 770 km
crushed stone, gravel, or stabilized soil, 10,870 km improved
or unimproved earth (est.)
Ports: 3 major (Mogadiscio, Berbera, Chisimaio)
Civil air: 6 major transport aircraft *
Airfields: 55 total, 49 usable; 6 with permanent-surface
runways, 2 with runways over 3,660 m; 4 with runways
2,440-3,659 m; 15 with runways 1,220-2,439 m
~ Telecommunications: _telephone poor, telegraph fair;
6,000 telephones (0.2 per 100 popl.); 2 AM; no FM, 1 TV
station
DEFENSE FORCES
Military manpower: males 15-49, 788,000; 439,000 fit for
military service; no conscription
Military budget: for fiscal year ending 31 December
1976, 34,650,357; 20.3% of central government budget','d1dcf8631252100c9fdf04cea7dcf58fa8024a0a60ef4facd6b92c9d5004da81','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('429d2a8a1d5f71fd9964e50430938738a9c58a4539fa83bc6af67f345ca3c2e2',1980,'ES','Spain','communications',410,'Railroads: 15,975 km total; Spanish National Railways
(RENFE) operates 13,509 km 1.668-meter gage, 4,828 km
electrified and 2,162 km double track; FEVE (government-
owned narrow gage railways) operates 1,676 km, of
predominantly meter gage (1.000 m) and 310 km electrified;
privately-owned railways operate 790 km, of predominantly
‘meter gage (1.000 m), 245 km electrified and 56 km double
track
Highways: 139,350 km total; 78,585 km national—6,810
km bituminous, concrete, stone block; 56,650 km bituminous
treated; 15,125 km crushed stone; the remaining 60,765 km
are classified as provincial or local roads
Inland waterways: 1,045 km; of minor importance as.
transport arteries and contribute little to economy
Pipelines: 386 km crude oil; 1,030 km refined products;
98 km natural] gas
Ports: 23 major, 150 minor
Civil air: 174 major transport aircraft (including 1 leased
in)
Airfields (including Balearic and Canary Islands): 94
total, 86 usable; 51 with permanent-surface runways; 4 with
runways over 3,660 m, 19 with runways 2,440-3,659 m, 32
‘with runways 1,220-2,439 m; 4 seaplane stations
Telecommunications: generally adequate, modern facili-
ties; 8.6 million telephones (23.9 per, 100 popl.); 180 AM, 250
FM, and 791 TV stations; 14 coaxial submarine cables; 4
communication satellite ground stations
DEFENSE FORCES
Military manpower: males 15-49, 8,577,000; 6,607,000 fit
for military service; 310,000 reach military age (20) annually
- Military budget: for fiscal year ending 31 December
1978, $4,214 million; about 23.8% of the proposed central
government budget','62ad0650963379c4827dbefb981b46c1f4a8ba41cf46f41e8735fe4d03debed5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0069ae83a7b5134ae695d7f2bdf37bc2ea27661c5107dd2fb25c32be6691b5cc',1980,'LK','Sri Lanka','communications',411,'(formerly Ceylon)
Arabian ; :
Sea Kis _ Bay
; "of Bengaly *
sri a
: LANKA = ©
_ Colombo
Indian Ocean
{See reference map Vil}
LAND
65,500 km*; 25% cultivated; 44% forested; 31% waste,
urban, and other
WATER
Limits of territorial waters (claimed): 12 nm (fishing 200
nm, plus pearling in the Gulf of Mannar); 200 nm exclusive
economic zone
Coastline: 1,340 km
Railroads: 1,496 km total (1977); all broad gage (1.435 m);
102 km double track; no electrification; government owned —
Highways: 52,200 km total (1975); 24,300 km paved
(mostly bituminous treated), 18,800 km crushed stone or
gravel, 9,400 km improved earth or unimproved earth; in
addition several thousand km of tracks, mostly unmotorable
Inland waterways: 4380 km; navigable by shallow-draft
craft
Ports: 3 major, 9 minor
Civil air: 8 major transport (including 1 leased)
Airfields: 14 total, 12 usable; 12 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 7 with runways
1,220-2,489 m -
Telecommunications: good international service;._75,000
(est.) telephones (0.5 per 100 popl.); 530,000 radio sets, 500
TV sets; 14 AM stations, 2 FM stations, and 1 TV station;
submarine cables extend to India; 1. ground satellite station
DEFENSE FORCES
Military manpower: males 15-49, 3,603,000; 2,772,000 fit
for military service; 159,000 reach military age (18) annually
Military budget: for fiscal year ending 31 December
1978, $24.7 million, 2% of central government budget','29011a1d39a776affdd848a6801137649aa3c9b0f2fa89af2d21a4d398e2f970','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1bbc97afaa589369848cbc1c36e07884e73bcc7645a0bde5cb82f20dc359d2f5',1980,'SD','Sudan','communications',415,'LAND
2,504,530 km?; 37% arable (3% cultivated), 15% grazing,
33% desert, waste, or urban, 15% forest
Land boundaries: 7,805 km
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
:
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
{See reference map Vi}
WATER :
Limits of territorial waters (claimed): 12 nm (plus 6 nm
“necessary supervision zone’’)
Coastline: 853 km
Railroads: 5,470 km total; 4,754 km 1.067-meter gage,
716 km 1.6096-meter gage plantation line
Highways: 10,550 km total; 600 km bituminous-treated,
800 km crushed stone or gravel, and 9,150 km improved and
unimproved earth roads; in addition, there are an undeter-
mined number of tracks ;
Inland waterways: 5,310 km navigable
Pipelines: refined products, 800 km
Ports: 1 major (Port Sudan)
Civil air: 11 major transport aircraft
Airfields: 80 total, 75 usable; 8 with permanent-surface
runways; 3 with runways 2,440-3,659 m, 31 with runways
1,220-2,489 m :
Telecommunications: large system by African standards,
but barely adequate; consists of radio relay, cables,
radiocommunications, and troposcatter; domestic satellite
system with 14 stations under construction; centers are
Khartoum, Al Fashir, Port Sudan; 56,000 telephones (0.3 per
100 popl.); 2 AM, no FM, and 2 TV stations; 1 submarine
cable; 1 Atlantic Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 3,803,000; 2,316,000 fit
for military service; average number reaching military age
(18) annually, 152,000
Military budget: for fiscal year ending 30 June 1979, $244
million; 11% of central government budget
Ethiopia.
Addis Ababa*
503985 1-79
Declassified and Approved For Release 2012/09/02 :
Mecca
q
Batumi
Kirkdk,
traq
Baghdad,
{raq-Saudi Arab
Neutral Zone
sata ae ess so ieniin abe
V The Middle East
‘,
Caspian
Sea
erabriz
Tehran ,.','30c3f4dd35c4aa66caa3031a95d9c0c7216ab711e3ac6d2439badc27615856b2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ab3de060703620bd47274ca2cf74738cd73054b10f2dd1f04f8f2393c7a96f2',1980,'SE','Sweden','communications',419,'(See reference map 1V)
LAND
448,070 km?; 8% arable, 1% meadows and pastures, 55%
forested, 36% other
Land boundaries: 2,196 km
WATER
Limits of territorial waters (claimed): 4 nm (fishing 200
nm) .
Coastline: 3,218 km
Railroads: 12,220 km total; Swedish State Railways (SJ)—
11,179 km standard gage (1.435 m), 6,959 km electrified and
1,152 km double track; 182 km 0.891-meter gage: 159 km
rail ferry service; privately-owned railways—511 km stand-
ard gage (1.435 m), 332 km electrified; 189 km 0.891-meter
gage electrified ;
Highways: 97,400 km total; 51,899 km bitumen, concrete;
20,659 km bituminous treated, gravel, improved earth;
24,842 km unimproved earth
Inland waterways: 2,052 km navigable for small steamers
and barges :
Ports: 17 major, and 30 minor
Civil ‘air: 63 major transports (including 1 leased in)
Airfields: 246 total, 240 usable; 131 with permanent-sur-
face runways; 8 with runways 2,440-3,659 m, 85 with
runways 1,220-2,.439 m
Telecommunications: excellent domestic and interna-
tional facilities; 5.67 million telephones (68.9 per 100 popl.);
9 AM, 91 FM, and 240 TV stations; 10 submarine cables,
including 4 coaxial; 1 Atlantic Ocean satellite station
DEFENSE FORCES . ;
Military manpower: males 15-49, 1,953,000; 1,742,000 fit
for military service; 57,000 reach military age (19) annually
Military budget: for fiscal year ending 30 June 1979,
$2.99 billion; about 9.2% of central government budget
199
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979','c4545e71fabae08fe6122b495ca5d53073a9c2dd50f3e9fd7aee4dd2aaf8f6e0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5082185a5145b450e311e940bc238c4fa69edd0e121ec98d1613710d5a18f10',1980,'CH','Switzerland','communications',423,'flan |
FEDERAL ©
REPUBLIC
OF GERMANY
{See reference map {V)
LAND
41,440 km?; 10% arable, 43% meadows and pastures, 20%
waste or urban, 24% forested, 3% inland water
Land boundaries: 1,884 km
Railroads: 5,098 km total; 2,895 km government-owned
(SBB), 2,822 km standard gage (1.435 m); 73 km narrow
gage (1.00 m); 1,339 km double track, 99% electrified;
2,203 km non-government owned, 710 km standard gage
(1.435 m), 1,418 km meter-gage (1.00 m), 75 km 0.790-me-
ter gage, 100% electrified
Highways: 62,145 km total (all paved), of which 17,594
km are canton and 975 km are national highways
Pipelines: 314 km crude oil; 1,046 km natural gas
Inland waterways: 65 km; Rhine River-Basel to Rhein-
felden, Schaffhausen to Constanz; in addition, there are 12
navigable lakes ranging in size from Lake Geneva to
Hallwilersee
Ports: 1 major (Basel), 2 minor
Civil air: 80 major transport aircraft (including 2 leased
in)
Airfields: 80 total, 73 usable; 41 with permanent-surface
runways; 2 with runways over 3,660 m, 8 with runways
2,440-3,659 m, 12 with runways 1,220-2,439 m
Telecommunications: excellent domestic, international,
and broadcast services; 4.02 million telephones (63.8 per 100
popl.); 8 AM, 94 FM, and 350 TV stations; 1 Atlantic Ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,681,000; 1,455,000 fit
for military service; 49,000 reach military age (20) annually
Military budget: for fiscal year ending 31 December
1978, $1,602 million; 19.5% of central government budget
SYRIA
LAND
186,480 km? (including 1,295 km? of Israeli-occupied
territory); 48% arable, 29% grazing, 2% forest, 21% desert
Land boundaries: 2,196 km (1967) (excluding occupied
area 2,156 km)
(See reference map Vj
WATER
Limits of territorial waters (claimed): 12 nm (plus 6 nm
“necessary supervision zone’’)
Coastline: 1938 km
Railroads: 1,543 km total; 1,281 km standard gage, 262
km narrow gage (1.050 m)
- Highways: 16,939 km total; 12,051 km paved, 2,625 km
’ gravel or crushed stone, 2,263 km improved earth
Inland waterways: 672 km; of little importance
Pipelines: 1,304 km crude oil; 515 km refined products
Ports: 3 major (Tartus, Latakia, Baniyas), 2 minor
202
Civil air: 10 ‘Major transport aircraft
Airfields: 41 total, 35 usable; 24 with permanent-surface
runways; 21 with runways 2,440-3,659 m, 2 with runways
1,220-2,439 m
Telecommunications: good international and domestic
service; 177,000 telephones (2.2 per 100 popl.); 9 AM, no FM
and 5 TV stations; 1 Indian Ocean satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,787,000; 992,000 fit
for military service; about 85,000 reach military age (19)
annually :
TAIWAN
(See p. 39. United States recognition of the People’s Republic
of China as the sole legitimate government of China
occurred just before this edition of the Factbook was printed,
too late to move the section on Taiwan to the end of the
Factbook where it will appear in the next and succeeding
editions.) ,
TANZANIA
TANZANIA
Dar es Salaam
(See reference map VI)
LAND .
939,652 km? (including islands of Zanzibar and Pemba,
2,642 km?); 6% inland water, 15% cultivated, 31% grassland,
48% bush forest, woodland; on mainland, 60% arable, of
which 40% cultivated on islands of Zanzibar and Pemba
Land boundaries: 3,883 km
WATER
Limits of territorial waters (claimed): 50 nm
Coastline: 1,424 km (this includes 118 km Mafia Island;
177 km Pemba Island; and 212 km Zanzibar)
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
AO AALAA AR RA Re Ate
. ‘ a a we OE One
a a ar ae ae eae re line One Oe a, aa Oe ES OE a
i, SE i A ei a a a i i Bett ce i a i
a ee Sa
a i in EE Aas od
ann
ia i ial
NS Ne te
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
TANZANIA
Railroads:. 3,555.km_ total; 960 km 1.067-meter gage;
2,595 km meter gage (1.00 m), 6.4 km double track; 962 km
Tan-Zam Railroad 1.067-meter gage in Tanzania
Highways: total 17,010 km, 2,581 km paved; 5,529 km
gravel or crushed stone; 8,900 km improved earth
Pipelines: 982 km crude oil
Inland waterways: 1,168 km of navigable streams; several
thousand km navigable on Lakes Tanganyika, Victoria, and','bdde5930b424fbc0c0617453320d646539ea480c6bdc244c37357006767cd0c4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84a414b06223280b2de3633de55aead0bf257ae16eff54793ea7ff69a2fe7137',1980,'TH','Thailand','communications',427,'Bay
of Bengal
1
/ndian Ocean
LAND
512,820 km?; 24% in farms, 56% forested, 20% other
Land boundaries: 4,868 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 3,219 km
Railroads: 3,830 km meter gage (1.000 m), 97 km double
track
Highways: 28,806 km total; 14,773 km paved, 4,731 km
crushed stone or gravel, 9,302 km earth and laterite
Inland waterways: 3,999 km principal waterways; 3,701
km with navigale depths of 0.9 m or more throughout the
year; numerous minor waterways navigable by shallow-
draft native craft
Ports: 2 major, 16 minor
Civil air: 25 major transport aircraft
Airfields: 155 total, 151 usable; 55 with permanent- ~
surface runways; 10 with runways 2,440-3,659-m, 29 with
runways 1,220-2,439 m
Telecommunications: service to general public adequate;
bulk of service to government activities provided by multi-
channel cable and radio-relay network; satellite ground
station; 333,761 telephones; over 3 million radios; and over
650,000 televisions; approx. 150 AM, 15 FM, and 10 TV
transmitters in government-controlled networks
DEFENSE FORCES
Military manpower: males 15-49, 9,958,000; 6,099,000 fit
for military service; about 498,000 reach military age (18)
annually
Military budget: for fiscal year ending 30 September
1979, $950 million; 20.6% of central government budget
LAND
829,707 km?*; 14% cultivated, 50% forested, 36% urban
inland water, and other
22)
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
VIETNAM
Land boundaries: 4,562 km
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 3,444 km (excluding islands)
Highways: 41,190 km total; 5,471 km bituminous, 27,030
km gravel or improved earth, 8,690 km unimproved earth
Inland waterways: about 17,702 km navigable; more than
5,149 km navigable at all times by vessels up to 1.8-m draft
Ports: 9 major, 23 minor
Civil air: military controlled
Airfields: 172 total, 183 usable; 57 with permanent-
surface runways; 8 with runways 2,440-3,659 m, 18 with
runways 1,220-2,439 m; 2 seaplane stations —
DEFENSE FORCES
Supply: dependent on the U.S.S.R., and Eastern European
Communist countries, for virtually all new equipment;
produces negligible quantities of infantry weapons, ammuni-
tion and explosive devices (Vietnam possesses a huge
inventory of U.S.-manufactured weapons and equipment
captured from the RVN)
Military budget: no expenditure estimates are available;
military aid from the U.S.S.R. and PRC has been so
extensive that actual allocation of Vietnam’s domestic
resources to defense has not been indicative of total military
effort
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Se a eT ee er
ee eS A ee ee Oe ee Pe en aa A te ee i ee ee ee ed
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
WALLIS AND FUTUNA/WESTERN ‘SAHARA','f3a03aa7faffc00827d3a054bea4c3aa3193ea6454ced082299f5a1257abc8f6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2453aa9d035c69f21223ac2d0d8e444a75d5afd8a0005b7fc2a99ed1278e3a6',1980,'TG','Togo','communications',431,'LAND |
56,980 km?*; nearly one-half is arable, under 15%
cultivated
Land boundaries: 1,646 km
WATER is
Limits of territorial waters (claimed): 12 nm
Coastline: 56 km
Gulf of Guinea” |
f |
(See reference map Vi}
Railroads: 442 km meter gage (1.00 m), single track
Highways: 6,998 km total; 1,210 km paved, 166 km
improved earth, 4,575 km unimproved earth
Inland waterways: section of Mono River and about 50
km of coastal lagoons and tidal creeks
Ports: 1 major (Lome), 1 minor
Civil air; 2 major transport aircraft
Airfields: 11 total, 11 usable; 1 with permanent-surface
runway ''2,440-3,659 m
Telecommunications: fair system based on_ skeletal
network of open-wire lines supplemented by a radio relay
‘ route radiocommunication stations; only center is Lome;
6,300 telephones (0.3 per 100 popl.); 2 AM stations, 1 FM
radio station, 8 TV stations; 1 COMSAT ground station
\\
206
DEFENSE FORCES
Military manpower: males 15-49, 516,000; 268,000 fit for
military service; no conscription
Supply: most military materiel obtained from France
Military budget: -for fiscal year endirig 31 December
1978, $19,927,920; 7.8% of central government budget','a3959c3b1a1b2902474f6b164520a0e73dfc604d0af9ba8bb2c6c31005d6b738','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50aa0fcc8de020944785f4d0b5106f4968ef7313ab06be3be30e901db59285c1',1980,'TO','Tonga','communications',435,'o
ont
FIL: “ TONGA
Nuku''alofa
NEWS"
CALEDONIA
Pacific Ocean
NEW
ZEALAND’
(See reference mep wil)
LAND
997 km? (150 islands); 77% arable, 3% pasture, 13% forest,
3% inland water, 4% other
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 419 km (est.)
Railroads: none
Highways: 249 km total (1974); 177 km rolled stone; 72
km coral base
Ports: 2 minor
‘Civil air: no major transport aircraft
Airfields: 4 total, 4 usable; 1 with grass runway
1,220-2,439 m; 1 seaplane station; 1 ground satellite station
Telecommunications: 552 telephones (2.2 per 100 popl.);
11,000 radio sets; no TV sets; 1 AM station; 1 ground satellite
station','75ecef62ed8c44a6e1090f3ee044d7a968c2e2c318791dd37333d985cb5bb89f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('845eb879ed17543f4aa11074916a79f70ecf3520d6156fec7b040cde92f73f7f',1980,'TT','Trinidad and Tobago','communications',439,'LAND :
5,128 km*; 41.9% in farms (25.7% cropped or fallow, 1.5%
‘pasture, 10.6% forests, and 4.1% unused or built-on), 58.1%
outside of farms, including grassland, forest, built- -up .area,
and wasteland
TONGA/TRINIDAD AND TOBAGO
Caribbean See
Atlantic Ocean
Ne of 5 ;
- TRINIDAD
33 AND TOBAGO
(See reference mag ti}
WATER
Limits of territorial waters (claimed): 12 nm
Coastline: 362 km
Railroads: none
Highways: 7,900 km total; 3,600 km paved, 1,100 km
improved earth, 3,200 km unimproved earth
Pipelines: 1,082 km crude oil and refined products; 832
km natural gas
Ports: 3 major (Port of Spain, Chaquaramars Bay, Point
Tembladora), 6 minor
Civil air: 12 major transport aircraft
Airfields: 8 total, 6 usable; 3 with permanent-surface
runways; 1 with runway 2,440-3,659 m, 3 with runways
1,220-2,489 m; 2 seaplane stations
Telecommunications: excellent international service via
tropospheric scatter links to Barbados and Guyana; good
local service; 1 Atlantic Ocean satellite station; 70,400
telephones (6.6 per 100 popl.); 2 AM, 2 FM, and 8 TV
stations
DEFENSE FORCES
Military manpower: males 15-49, 254,000; 180,000 fit for
military service
'' Supply: mostly from U.K.
Military budget: proposed for fiscal year ending 31
December 1977, $48.4 million; about 4.8% of central
government budget','87d693889e5095287005869922b00b0891498ec18ff85273c0a9b27ca38a8159','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee331d9b5d84fa0774e7622cdabbeeda5107b4b12fd4d32e014d0c2c50f6bfeb',1980,'TN','Tunisia','communications',443,'LAND
164,206 km?; 28% arable land and tree crops, 23% range
and esparto grass, 6%: forest, 43% desert, waste or urban
Land boundaries: 1,408 km
WATER
Limits of territorial waters (claimed): 12 nm (fishing 12
nm exclusive fisheries zone follows the 50-meter isobath for
part of the coast, maximum 65 nm)
Coastline: 1,143 km (includes offshore islands)','19c9abc17c171424ac7921458027954a03ee06f30bdead472f9181472f9f7295','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3d668ba01adecebe9a3eea522311470c75c21933c3483f8fa530fb02eaf943b',1980,'TV','Tuvalu','communications',449,'(formerly Ellice Islands)
NOTE: On October 1, 1975, by Constitutional Order, the
Ellice Islands were formally separated from the British
colony of Gilbert and Ellice Islands, thus forming the new
TURKEY/TUVALU
unites":
‘ps o
Pacific Ocean alae
GILBERT
“|, ., ISLANDS
PAPUA “
\\NEW.GUINEA © -:. TUVALU
“SS','715beb3bb357ae670b0d53e1fcdbece5838c03615acf31a72d0284424a31d262','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54b3052dfed4c33ae7dfb27243d53cc42979c83e9c25456e781020fef60523db',1980,'UG','Uganda','communications',450,'(Seé reference map Vi} -
LAND
235,690 km?; 21% inland water and swamp, including
territorial waters of Lake. Victoria, about 21% cultivated,
13% national parks, forest, and game reserves; 45% forest,
woodland, and grassland
Land boundaries: 2,680 km —
Railroads: 1,216 km; meter gage (1.00 m), single’ track
Highways: 6,763 km total; 1,934 km paved; 4,829 km
crushed stone, gravel, and laterite; remainder earth roads
and tracks (est.)
Inland -waterways: Lake Victoria, Lake Albert, Lake
Kyoga, Lake George, and Lake Edward (9,670 km); Kagera
River .and Victoria Nile (610 km) :
Civil air: 5 major transport aircraft (including 2 leased in)
Airfields: 49 total, 47 usable; 5 with permanent-surface
runways; 1 with runway over 3,660 m, 3 with runways
2,440-3,659 m, 12 with runways 1,220-2,439 m
Telecommunications: fair system based on open wire
lines and radio relay links; 46,000 telephones (0.4 per 100
popl.); 6 AM, no FM, 6 TV stations; 2 COMSAT stations
DEFENSE FORCES
’ Military manpower: males 15-49, about 2,853,000; about
1,533,000. fit for military service :
Declassified and Approved For Release 2012/09/02 : CIA-RDPO8-00534R000100140001-7
an Ak Oe ee AN a MR RAR 2A AA AN AR AR AR RA Ue eR ee OR A me nt Ot che Rta at setae candies as aah eae!
Ma A nA AA ann 8K MA
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
U.S.S.R.
U.S.S.R.
{See reference map Vit}
LAND :
22,274,000 km?; 9.3% cultivated, 37.1% foie and brush,
2.6% urban, industrial, and transportation, 16. 8% pasture
and natural hay id. 34.2% desert, swamp, or waste
Land boundaries: 20,619 km
WATER ;
Limits of territorial waters (claimed): 12 nm (fishing 200
nm)
Coastline: 46,670 km incl.. Sakhalin)
Railroads: 139,805 km total; 187,972 km broad gage
(1.524 m); 1,833 km narrow gage (mostly 0.750 m); 109,316
km broad gage:single track; 40,399 km electrified: does not
include industrial lines (1977)
Highways: 1,564,000 km total; 322,000 km asphalt,
concrete, stone block; 372,000 km asphalt treated, gravel,
crushed stone; 870,000 km earth (1976)
Inland waterways: 146,400 km navigable, exclusive of
Caspian Sea (1978) ;
Pipelines: 57,000 km crude oil; 13,000 km refined
products; 115,000 km natural gas
Ports: 52 major (most important: Leningrad, Murmansk,
Odessa, Novorossiysk, Ilichevsk, Vladivostok, Nakhodka,
Arkhangel’sk, Riga, Tallinn, Kaliningrad, Liepaja, Ventspils,
Nikolayev, Sevastopol); 116 selected minor; major inland
ports: Rostov, Volgograd, Gorkiy, Khabarovsk, Kiev, and
Moscow (1978)
Freight carried: rail—3,705 million metric tons, 3,330.0
billion metric ton/km (1977); highways—22.7 billion metric
tons, 380 billion metric ton/km. (1977); waterway—520.0
million metric tons, 231.0 billion metric ton/km, excluding
Caspian Sea in approximately 16,000 waterway craft with
8,000,000 metric tons capacity (1977)','4092bcea535242cb9d1b55f6faec0d2e5e9f6fa797228e9d645aef5b795fc310','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2b15c54c3a49f2d4be6e0f4e03b0528a43c0078164d379ee027d449a85fd7d0',1980,'AE','United Arab Emirates','communications',454,'LAND:
82,880 km?; almost all -desert, waste or urban
214
January 1979
Gulf
of Oman
NEMIRATES
SAUDI
ARABIA
(See reference map V}
Land boundaries: 1,094 km (does not include boundaries
between adjacent U.A.E. states)
WATER
Limits of territorial waters (claimed): 3 nm for all states
except Sharjah (12 nm) ,
Coastline: 1,448 km
Railroads: none
Highways: 780 km bituminous, undetermined mileage of
earth tracks
Pipelines: 282 km crude oil
Ports: 3 major, 1 minor
Civil air: 11 major transport aircraft (including 5 leased
in)
Airfields: 57 total, 40 usable; 12 with permanent-surface
runways, 3 with runways over 3,660 m, 1 with runway
2,440-3,659 m, 10 with runways 1,220-2,439 m
Telecommunications: adequate system of radio relay and
coaxial cable; key centers are Abu Dhabi and Dubai; 70,800
telephones (10.8 per 100 popl.); 4 AM, 2 FM, and 3 TV
stations; 2 COMSAT ground stations
DEFENSE FORCES
Military manpower: males 15-49, 151,000; 87,000 fit for
military service','490df180b41331dcc2ad40a17b67107becde1a0b37703090dc2189b587eeb97d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8acfba05f4421a730306128b238dd9a041427fec3d9cbb00e241c278959a56b1',1980,'GB','United Kingdom','communications',458,'Atlantic
Ocean
(See reference map (V}
LAND
243,978 km?*; 30% arable, 50% meadow and pasture, 12%
waste or urban, 7% forested, 1% inland water
Land boundaries: 360 km
WATER
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 12,429 km
Railroads: Great Britain—18,287 km total; British Rail-
ways (BR) operates 18,012 km standard gage (1.435 m)
(3,735 km electrified, 11,410 km double track, 2,366 km
multiple track) and 19 km 0.597-meter gage; 256 km of
standard gage (1.435 m) and several ‘narrow gages are
privately-owned; Northern Ireland Railways (NIR) operates
827 km 1.600-meter gage, 190 km double track
Highways: approx. 343,315 km paved and 23,175 km in
Northern Ireland, 22,227 km paved; 949 km gravel
Inland waterways: 1,770 km of commercial routes
Pipelines: 933 km crude oil, almost all insignificant; 2,907
km refined products; 1,770 km natural gas ,
Ports: 23 major, 350 minor ,
Civil air: 506 major transport aircraft (including 4 leased
in and 17 leased out) ,
Telecommunications: modern, efficient domestic and
international system; 22.4 million telephones (39.4 per 100
popl.); excellent countrywide broadcast; 97 AM, 120 FM,
and 300 TV stations; 42 submarine cables; 1 earth satellite
station with 2 Atlantic Ocean antennas and 1 Indian Ocean
antenna
DEFENSE FORCES
Military manpower: males 15-49, 12,994,000; 11,012,000
fit for military service; no conscription; 455,000 reach
military age (18) annually :
Military budget: proposed for fiscal year ending 31]
March . 1979, $12,800 million; about 15.1% of central
government budget
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
a ar a. ars
Se ee. ee ee ee en ee SN ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
UPPER VOLTA
UPPER VOLTA
Atlantic
Ocean
(See reference map Vi) ,
LAND
274,540 km*; 50% pastureland, 21% fallow, .10% culti-
vated, 9% forest and scrub, 10% waste and other uses
Land boundaries: 3,307 km
Railroads: 1,173 km, 516 km meter gage (1.00 m), single
track; Ouagadougou to Abidjan, Ivory Coast line
Highways: 4,717 km total; 617 km paved, 4,100 km
improved
Civil air: no major transport aircraft
Airfields: 55 total, 54 usable; 2 with permanent-surface
runways; 2 with runways 2,440-3,659 m, 3 with runways
1,220-2,439 m
Telecommunications: all services generally poor; 3,400
telephones (0.1 per 100 popl.); 8 AM stations, 1 FM station,
and 1 TV station; 1 Atlantic Ocean Comsat station
DEFENSE FORCES
Military manpower: males 15-49, 1,481,000; 746,000 fit
for military service; no conscription
Supply: mainly dependent on France
Military budget: for fiscal year ending 31 December
1978, $23,269,076; 18.4% of central government budget','a6d78886a838ea3dec445c96764e6d2cc1f0526f04c80aa9e31b69685fb05c6c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcf9566f01f09242ed936785828bc3284752484a65c8c082f259e22bdf0fd39c',1980,'WF','Wallis and Futuna','communications',462,'NEW X* WALLIS
CALEDONIA” = AND FUTUNA-
Pacific Ocean
NEW
_ZEALAND
(See reference map Vill}
LAND
About 207 km?
WATER
Limits of territorial waters: 12 nm
Coastline: about 129 km
Highways: 100 km of improved road on Uvea Island
(1977)
Ports: 2 minor
Airfields: 2 total, 2 usable; 1 with runway 1,220-2,439 m
Telecommunications: 85 telephones (0.9 per 100 popl.)
DEFENSE
No formal defense structure; no regular Armed Forces','ecaf8a2fa0046ea595da13615af9684b33b52efc5e567957d464d11b771297a5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('547a37237fa34eb27922620c5c6cac77ec3efe1d46eee1a71de1f07c902b014e',1980,'ZM','Zambia','communications',466,'Indian
Ocean
(See reference map Vi}
LAND
745,920 km*; 5% under cultivation, 5% arable, 10%
grazing, 13% dense forest, 6% marsh, 61% scattered trees and
grassland
Land boundaries: 6,003 km
Railroads: 2,014 km, all narrow gage. (1.067 m); 13 km
double. track ,
Highways: 34,869 km total; 4,456 km paved, 2,853 km
crushed stone, gravel, or stabilized soil; 4,660 km improved
and unimproved earth
Inland waterways: 2,250 km including Zambezi River,
Luapula River, Lake Kariba, Lake Bangweulu, Lake
Tanganyika; principal port on Lake: Tanganyika is
Mpulungu (of only local importance)
Pipelines: 724 km crude oil
Civil air: 10 major transport aircraft
Airfields: 172 total, 165 usable; 14 with permanent-sur-
face runways; 1 with runway over 3,660 m, 3 with runways
2,440-3,659 m, 22 with runways 1,220-2,439 m
Telecommunications: facilities being modernized and
expanded; high-capacity wire and radio relay connect
centers of Kitwe in northern mining region and Lusaka
along axial north-south route; 77,400 telephones (1.7 per 100
popl.); 4 AM, 1 FM, and 3 TV stations; 1 Indian Ocean
satellite station
DEFENSE FORCES
Military manpower: males 15-49, 1,099,000; 571,000 fit
for military service
Military budget: for fiscal year ending 31 December
1977, $79 million; 12.9% of central government budget','d25b1f851ab6858bd0c36d90fab83befff41d1cae03d5596e8eaf920f086d808','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc902c41e14f53b13b17209e3f04e22186a82e12621519fbdc678c7be121b984',1980,'US','United States','communications',470,'This “Factsheet” on the U.S. is provided solely as a service
to those wishing to make rough comparisons of foreign
country data with a U.S. “yardstick.” Information is from
U.S. open sources and publications and in no sense represents
estimates by the U.S. intelligence community.
LAND
9,363,396 km? (contiguous U.S. plus Alaska and Hawaii);
19% cultivated, 27% grazing and pasture, 32% forested, 22%
waste, urban, and other
WATER :
Limits of territorial waters (claimed): 3 nm (fishing 200
nm)
Coastline: 19,924 km
Railroads: 277,686 km (1973)
Highways: 6,059,200 km (1972)
Inland waterways: 40,416 km of navigable inland
channels, exclusive of the Great Lakes; freight carried 951
million short tons (1970)
Pipelines: petroleum, 279,966 km (1972)
Ports: 25 major
Merchant marine: 600 ships (1,000 GRT or over) totaling
9,982,730 GRT, 14,722,666 DWT; includes 3 passenger, 5
short-sea passenger, 163 cargo, 119 container, 14 roll-on/
232
roll-off cargo,. 234 tanker, 1 liquefied gas, 17 bulk, 2
combination ore/oil, 23 LASH Seebee and barge carriers, 19
specialized carriers; in addition there are 178 ships in reserve
fleet
Civil air: 2,716 major transport aircraft (1976)
Airfields: 15,257 (1976)
Telecommunications: 155 million telephones (7.8 tele-
phones per 100 popl.); 4,500 AM, 3,600.FM, and 985 TV
broadcast stations; 486 million radio and 133 million TV.
receivers (1977)
DEFENSE FORCES
Personnel: army 1,133,000, navy and marines 1,029,000,
air force 827,000 (1976)
Military budget: $100.1 billion (1977)
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
ak A AA AR aka: &
a. ™!
ALARA BRA ALAA eR Rn A A A OA RA A A a A
the AL
AAA Le
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
I Canada
4
Ocean
Arctic
Ellesmere
Island
> Dall
El Paso fro
New Orleans@
Monterrey,
Gulf of Mexico -','9ccf3064a10e7ff2e1290ac02689f5fb83d7dd45d77977b748ab0af25a91547f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fa57a93bec228712a40ac1efa56891c9f44a5e690af40066a809b845d01e5f7',1980,'ML','Mali','communications',474,'Senegal é
‘ Timbuktu
Oakar ji
The Gambiaypeagiul
Guinea xp;
Bissau. (7: ‘Guinea
Conake''
Freetowns
Sierre.
Leone “,
Monrovia’.
Liberta
Eq.Guinea* ff
Sao Tome and : STI
Principe ~~ & Libreville’
Sao Tomés+
Eq. Guinea~ . Gabon
Brdzzaville
South
Atlantic
Ocean
North ge
Atlantic ae Can
: CIA-RDP08-00534R000100140001-7
VI Africa
Sea
Caspian
Sea
Black Sea
¢
co” vO','9461768e6e5b514545ec3b61461ca706e8e0716975dc5d87803ab5316dd3db35','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84f225deaa9c96e0153422b7d6a75359f475530a9d96ecf91b3b351324670758',1980,'EG','Egypt','communications',475,'a
“
7)
Port Sudan
Khartoum,
“Mogadiscio
Nairobi
Lakes,
Victoria F 4
Burundi ~. {Mombasa Seychelles
1 Victoria’.
aed
ain
S ar es Salaam','ba2eb8d8410a4adc4680d0024289de0f5ee28176b8b7c0af5e80e163c623a720','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

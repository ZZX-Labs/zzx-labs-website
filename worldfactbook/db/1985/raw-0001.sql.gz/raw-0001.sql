SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f39af15c2bf4297d91b42834e57f2d47b94ea677c53206328c6503967b0e47f0',1985,'','','raw',1,'iS
~ Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
co ,
Intelli
kee I he
Nineteen Hundred and Eighty-Five
byt ®
Rime ne” ce yn
CR WF 85-001
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09
This publication is prepared for the use of US
Government officials, and the format, coverage,
and content are designed to meet their specific
requirements. US Government officials may ob-
tain additional copies of this document directly
or through liaison channels from the Central
Intelligence Agency.
Requesters outside the US Government may ob-
tain subscriptions to CIA publications similar to
this one by addressing inquiries to:
or:
Document Expediting (DOCEX) Project
Exchange and Gift Division
Library of Congress
Washington, D.C. 20540
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Requesters outside the US Government not inter-
ested in subscription service may purchase spe-
cific publications either in paper copy or micro-
form from:
or:
Photoduplication Service
Library of Congress
Washington, D.C. 20540
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
To expedite service call the
NTIS Order Desk (703) 487-4650
This publication may also be purchased from:
Superintendent of Documents
US Government Printing Office
Washington, D.C. 20402
(Stock Number 041-015-00159-2)
Approved For Release 2011/02/09
: CIA-RDP86S00596R000200790001-2
: CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
ese Central
Intelligence
Agency
The
World
Factbook
Nineteen Hundred and Eighty-Five
The World Factbook is produced annually
by the Directorate of Intelligence of the
Central Intelligence Agency. The data are
provided by various components of the
Central Intelligence Agency, the Defense
Intelligence Agency, the Bureau of the
Census, and the US Department of State. In
general, information available as of 1
January 1985 was used in the preparation of
this edition, with the following exceptions:
* Population figures are projected estimates
for 1 July 1985; the average annual
growth rates listed are projected estimates
for the period mid-1984 to mid-1985.
¢ Military manpower estimates are as of ]
January 1985, except the numbers of
males reaching military age, which are
projected averages for the five-year
period 1985-89.
* Major political developments through 22
April 1985 have been included.
Comments and queries are welcome and
may be addressed to:
Central Intelligence Agency
Attn: Public Affairs
Washington, D.C. 20505
(708) 351-2053
For information on how to obtain addi-
tional copies, see the inside of the front
cover.
CR WF 85-001
(Supersedes CR WF 84-001)
May 1985
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Contents
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
iti
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Page
Definitions, Abbreviations, and Explanatory Notes ix
Abu Dhabi (see United Arab Emirates)
Afghanistan 1
Ajman (see United Arab Emirates)
Albania 2
Algeria 3
Andorra ee 5
Angola 6
Anguilla (formerly St. Christopher-Nevis-Anguilla) 7
Antigua and Barbuda 8
Argentina 9
Australia ll
Austria 13
th Satie tae Azores(see Portugal)
Bahamas, The _ 14
Bahrain 16
Balearic Islands (see Spain)
Bangladesh 17
Barbados 18
Belgian Congo (see Zaire)
Belgium 20
Belize (formerly British Honduras) _ 21
Benin (formerly Dahomey) 23
Bermuda 24
Bhutan 25
Bioko (see Equatorial Guinea)
Bolivia 26
Bophuthatswana (see South Africa)
Botswana 27
Brazil - 29
British Honduras (see Belize)
British Solomon Islands (see Solomon Islands)
Brunei 30
Bulgaria 82
Burkina Faso (formerly Upper Volta) 33
Burma 34
- Burundi eee 36
Cabinda (see Angola)
Cambodia (formerly Kampuchea) 87
Cameroon 38
Canada 40
Canary Islands (see Spain)
Cape Verde 41
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Dee ; Page
Central African Republic 42
Ceylon (see Sri Lanka)
Chad 44
Chile 45
China (Taiwan listed at end of table) 47
Colombia 48
Comoros 50
Congo 51
Cook Islands _ 52
Costa Rica 53
Cuba 55
Cyprus 56
a Czechoslovakia 58
D '' Dahomey (see Benin)
Denmark 59
Djibouti (formerly French Territory of the Afars and Issas) 61
Dominica 62
Dominican Republic 63
Dubai (see United Arab Emirates)
E Ecuador 64
Egypt 66
Ellice Islands (see Tuvalu)
EI Salvador 67
Equatorial Guinea 69
Ethiopia se 70
F Falkland Islands (Islas Malvinas) 72
Faroe Islands 78
Fernando Po (see Equatorial Guinea)
Fiji 7A
Finland 75
France 77
French Guiana 78
French Polynesia = 80
French Territory of the Afars and Issas (see Djibouti)
Fujayrah, al (see United Arab Emirates)
G Gabon 81
Gambia, The 82
Gaza Strip (see West Bank and Gaza Strip, listed at end of table)
German Democratic Republic 83
Germany, Federal Republic of 85
Ghana ee 87
Gibraltar 88
Gilbert Islands (see Kiribati)
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
_ Page
Greece __ . 89
Greenland 91
Grenada os 92
Guadeloupe . 93
Guatemala 94
Guinea 96
Guinea-Bissau (formerly Portuguese Guinea) 97
; Guyana 99
H Haiti 100
Honduras 101
Hong Kong 103
. : Hungary _ 104
Iceland 106
India 107
Indonesia 109
Iran = 110
Irag 112
Ireland oe 113
Israel (West Bank and Gaza Strip listed at end of table) 114
Italy a 116
_ 3 Ivory Coast 118
Jamaica 119
Japan 121
Jordan (West Bank and Gaza Strip listed at end of table) 122
Kampuchea (see Cambodia)
Kenya 124
Kiribati (formerly Gilbert Islands) 125
Korea, North 126
Korea, South - 127
____ Kuwait 129
Laos a: 130
Lebanon 132
Lesotho 2533 133
Liberia 135
Libya ; 136
Liechtenstein 137
a3 Luxembourg i 139
M Macau 140
Madagascar 141
Madeira Islands (see Portugal)
Malagasy Republic (see Madagascar)
Malawi 143
Malaysia 144
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
- fe, 7 Page
Maldives 147
Mali 148
Malta 149
Martinique 150
Mauritania 152
Mauritius 153
Mexico - 154
Monaco 156
Mongolia 157
Morocco 158
eaten a3 _ Mozambique 160
N Namibia (South-West Africa) _ 161
Nauru 162
Nepal 163
Netherlands 165
Netherlands Antilles 166
New Caledonia 7 168
New Hebrides (see Vanuatu)
New Zealand 169
Nicaragua 170
Niger 172
Nigeria 178
Northern Rhodesia (see Zambia)
ee 7 Norway 175
ae) Oman 176
P Pakistan / 178
Panama 179
Papua New Guinea 181
Paraguay 182
Pemba (see Tanzania)
Peru 184
Philippines 185
Poland 7 186
Portugal 188
Portuguese Guinea (see Guinea-Bissau)
mtd! Portuguese Timor (see Indonesia)
_Q Qatar 189
R Ra’s al-Khaymah (see United Arab Emirates)
Reunion 190
Rhodesia (see Zimbabwe)
Rio Muni (see Equatorial Guinea)
Romania 192
Rwanda 193
vi
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Page
S St. Christopher and Nevis (formerly St: Christopher-Nevis- Anguilla) 194
St. Lucia 195
St. Vincent and the Grenadines 196
San Marino 197
Sao Tome and Principe 199
Saudi Arabia 7 200
Senegal 201
Seychelles 202
Sharjah (see United Arab Emirates)
Sierra Leone 204
Singapore q 205
Solomon Islands (formerly British Solomon Islands) 206
Somalia 207
South Africa 209
Southern Rhodesia (see Zimbabwe)
South-West Africa (see Namibia) _
Soviet Union 210
Spain _ 212
Spanish Sahara (see Western Sahara)
Sri Lanka (formerly Ceylon) 214
Sudan ae 216
Suriname 217
Swaziland 218
Sweden 220
Switzerland 221
Syria = - 223
T Tanganyika (see Tanzania) ‘
Tanzania 224
Tasmania (see Australia) =
Thailand 226
Togo 7 ; 227
Tonga : 228
Transkei (see South Africa)
Trinidad and Tobago 229
Tunisia 231
Turkey ; 232
Turks and Caicos Islands at 233
7 Tuvalu (formerly Ellice Islands) | 234
U Uganda . 235
Umm al-Qaywayn (see United Arab Emirates)
United Arab Emirates (Abu Dhabi, Ajman, Dubai, al Fujayrah, 237
Ra’s al-Khaymah, Sharjah, Umm al-Qaywayn)
United Arab Republic (see Egypt)
vii
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Page
United Kingdom 238
United States 240
Upper Volta (see Burkina Faso)
Uruguay 241
Vanuatu (formerly New Hebrides) 243
Vatican City 244
Venezuela 245
Vietnam 246
Wallis and Futuna 247
Walvis Bay (see South Africa)
Western Sahara (formerly Spanish Sahara) 248
Western Samoa _ 249
Yemen Arab Republic (North Yemen) 250
Yemen, People’s Democratic Republic of (South Yemen) 251
Yugoslavia 252
Zaire 254
Zambia (formerly Northern Rhodesia) 255
Zanzibar (see Tanzania)
Zimbabwe (formerly Southern Rhodesia) 257
Taiwan (China listed alphabetically) 258
West Bank and Gaza Strip 260
Appendixes
A. The United Nations System 262
B. Selected UN Organizations 263
C. Selected International Organizations 264
D. Country Membership in Selected Organizations 266
E. Conversion Table 274
Maps
I. The World (Guide to Regional Maps II-XIII)
II. North America
III. Central America and the Caribbean
IV. South America
V. Europe
VI. Middle East
VIL. Africa
VIH. Soviet Union, East and South Asia
IX. Southeast Asia
X. Oceania
XL Arctic Region
XII. Antarctic Region
Viii
XIII. Standard Time Zones of the World
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Definitions, Abbreviations,
and Explanatory Notes
ere er ree SD
Fiscal Year: The abbreviation FY stands for fiscal year; all years are
calendar years unless otherwise indicated.
GDP and GNP: GDP is the total market value of all goods and
services produced within the domestic borders of a country over a
particular time period, normally a year. GNP equals GDP plus the
income accruing to domestic residents arising from investment abroad
less income earned in the domestic market accruing to foreigners
abroad.
Imports, Exports, and Aid: Standard abbreviations used in individual
entries throughout this factbook are c.i.f. (cost, insurance, and freight)
f.o.b. (free on board), ODA (official development assistance), and OOF
(other official flows).
5)
Land Utilization: Most of the land utilization percentages are rough
estimates. Figures for “‘arable” land in some cases reflect the area
under cultivation rather than the total cultivable area.
Maritime Zones: Fishing and economic zones claimed by coastal
states are included only when they differ from territorial sea limits.
Maritime claims do not necessarily represent the position of the
United States Government.
Money: All money figures are in contemporaneous US dollars unless
otherwise indicated.
Oil Terms: Barrel (bbl) and barrels per day (b/d) are used to express
volume of crude oil and refined products; a barrel equals 42.00
gallons, 158.99 liters, 5.61 cubic feet, or 0.16 cubic meters.
Note: Some of the countries and governments included in this
publication are not fully independent, and others are not officially
recognized by the United States Government.
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2','dfe38b53ce41ba0f25ce74c3a00db12946e32f82981e8108ac2b443e7d61241d','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f9a1926036a5678ea2715b1871d3f49f6833fb87603d834503c415c22f24738',1985,'AF','Afghanistan','raw',2,'300 km —
See regional map VII
Land
647,497 km?; about the size of Texas; 75%
desert, waste, or urban; 22% arable (12% cul-
tivated, 10% pasture); 3% forest
Land boundaries: 5,510 km','fae9528fa80bd955d6483afa55b3b3d77a0fe4d6a38516d0bdf21b5cf3e83168','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec13e447d96c76dce3bb4fe87cbac5dd4b889779d07e328bba47ec10c5ef4da8',1985,'','','raw',1,'Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
t
World ee OU)
Factbook ree.
Nineteen Hundred and Eighty-Five
Peleg The NOT MICROFILMED —
N
Mii
CLACE wr Es-PPL =
a Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7 om
Approved For Release 2009/09/03
This publication is prepared for the use of US
Government officials, and the format, coverage,
and content are designed to meet their specific
requirements. US Government officials may ob-
tain additional copies of this document directly
or through liaison channels from the Central
Intelligence Agency.
Requesters outside the US Government may ob-
tain subscriptions to CIA publications similar to
this one by addressing inquiries to:
Document Expediting (DOCEX) Project
Exchange and Gift Division
Library of Congress
Washington, D.C. 20540
or: National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Requesters outside the US Government not inter-
ested in subscription service may purchase spe-
cific publications either in paper copy or micro-
form from:
Photoduplication Service
Library of Congress
Washington, D.C. 20540
or: National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
To expedite service call the
NTIS Order Desk (703) 487-4650
This publication may also be purchased from:
Superintendent of Documents
US Government Printing Office
Washington, D.C. 20402
(Stock Number 041-015-00159-2)
Approved For Release 2009/09/03
: CIA-RDP90T01298R000200050001-7
: CIA-RDP90T01298R000200050001-7
A
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
ey, Central
\\ Intelligence
Agency
The
World
Factbook
Nineteen Hundred and Eighty-Five
The World Factbook is produced annually
by the Directorate of Intelligence of the
Central Intelligence Agency. The data are
provided by various components of the
Central Intelligence Agency, the Defense
Intelligence Agency, the Bureau of the
Census, and the US Department of State. In
general, information available as of 1
January 1985 was used in the preparation of
this edition, with the following exceptions:
Population figures are projected estimates
for 1 July 1985; the average annual
growth rates listed are projected estimates
for the period mid-1984 to mid-1985.
Military manpower estimates are as of 1
January 1985, except the numbers of
males reaching military age, which are
projected averages for the five-year
period 1985-89.
Major political developments through 22
April 1985 have been included.
Comments and queries are welcome and
may be addressed to:
Central Intelligence Agency
Attn: Public Affairs
Washington, D.C. 20505
(703) 351-2053
For information on how to obtain addi-
tional copies, see the inside of the front
cover.
pproved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
CR WF 85-001
(Supersedes CR WF 84-001)
May 1985
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Contents
Definitions, Abbreviations, and Explanatory Notes
Abu Dhabi (see United Arab Emirates)
Afghanistan a)
Ajman (see United Arab Emirates)','555b5e226156e9a809f1783ed99c36660daef9d8fd2ce723744fec8fe68d38be','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('896eb51308c65d949d7f2488490546eb476b5a143ede434345ab63dddefe2b41',1985,'BR','Brazil','raw',2,'British Honduras (see Belize)
British Solomon Islands (see Solomon Islands) |
Brunei
Bulgaria 7
Burkina Faso (formerly Upper Volta)
Burma 7 7','d7d286bddd996812a26adabcb2eb8ffaca18a94dba8eb7dce88030ffe9da1d84','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('052d9ab591b5d0e1219b28999fbf7dca97967a6ea57d87906c844485ab557302',1985,'CA','Canada','raw',3,'Canary Islands (see Spain)
Cape Verde
iii
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
—- OO ma nm WT SO DY
_
ao
—_—
p> +
17
18
20
21
23
24
25
26
27
29
30
32
33
34
36
37°
38
40
41
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Central African Republic _
Ceylon (see Sri Lanka)
Chad _
Chile __ —
China (Taiwan listed at end of table)','a613e3c1a9122f5e3986a6da3acb94aa9003c8bfff8d74e892c15c022f1a6998','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec1dfaa646a135c1e40452a1bcad47501e25f6f55c7abe95812a947a016e6b88',1985,'CY','Cyprus','raw',4,'_ Czechoslovakia
___Fujayrah, al (see United Arab Emirates)
Dahomey (see Benin)
Denmark _
Djibouti (formerly French Territory of the Afars and Issas)
Dominica _','568e96ec92e4a58c3aeb67ff7b08456dfb458efd08910720c2afddd053c83f7e','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae36d45531d266e055db635683c61836d052f96f744b8f461dc6a4f2632d7ad0',1985,'GA','Gabon','raw',5,'Gambia, The
Gaza Strip (see West Bank and Gaza Strip, listed at end of table)
German Democratic Republic
Germany, Federal Republic of','ff325a8e337827a485c09e15523116bfb96e39962221ef681afb943f7e31b8b7','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94fb20da98a2755bf9b262a085ccba79f258c326001afddb61279c86906e26ba',1985,'GI','Gibraltar','raw',6,'Gilbert Islands (see Kiribati)
iv
Page
42
44
45
47
48
50
51
52
53
55
56
58
59
61
62
63
64
66
67
69
70
72
73
74
75
77
78
80
81
82
83
85
87
88
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Greece EG eT fon ae Sst 89
Greenland el a Siok 91
Grenada ae meee ee 8
Guadeloupe —_ Boe seater ee, 93
Guatemala : _ _ zs 94
Guinea Ket 9 96
Guinea-Bissau (formerly Portuguese Guinea) oe
Guyana hin ci Ee he Nae RASS eee 99 at
Haiti ee Le
Honduras 2 lg tgs ee —_ _10l
Hong Kong fgg honed es 103
Hungary 2, as : ieee ey Pa aes 104
Iceland ee en ee ee 106 _
India bp ee eas 107
Indonesia eee ee _ 109
Tran De ee ee 110 ©
Iraq 7 eer er tak ee 112
Ireland US
Israel (West Bank and Gaza Strip listed atend of table) 14
Italy a nn ee es pone a 116
Ivory Coast an 7. ; 118
Jamaica eee, Gee ie ee . es : 9
Japan me ayitbn ce sac teme 2
Jordan (West Bank and Gaza Strip listed atend of table) 1220
Kampuchea (see Cambodia) ey, Seen ee nee ey
Kenya ; oo et seu See eet eien ae hes ‘124
Kiribati (formerly Gilbert Islands) 1250 | 7
Korea, North eee ree 126
Korea, South Boe. cats te Ms — (12T
Kuwait ; widths cam ag ote 129
Laos Se ee teeta he — 180 |
Lebanon ee ee 1320
Lesotho pees pan be ee eee «1388
Liberia ~~ eee ee ee oe
Libya 4 ens Bo RAGE 136
Liechtenstein ee oe sn fee 7 137
Luxembourg eat, Me pee ta ees, es 139
M Macau : ue, Ah ES oe _ 140
Madagascar eee eee 14]
Madeira Islands (see Portugal) _ ee
Malagasy Republic (see Madagascar) wee ees ee ae ty
Malawi 3 ene, ee ee 143
Malaysia 5 pee _ - (144
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Maldives he nc M7
Mali _ —— 148
Malta — 7 149,
Martinique ; 150
Mauritania ae ee oc ee
Mauritius sate Beer eee
Mexico . _. ., 154
Monaco 7 be cece: © OY
Mongolia ~ eas, BOh ect
Morocco shi. sede Sate, cE eA Ale
_, . Mozambique _ a: ae
N Namibia (South-West Africa) ; ; ; ee Co) Oe ;
Nauru 162
Nepal ee oe
Netherlands _ Sela Goodloe ete Stach seg POs sn aces
Netherlands Antilles : 166
New Caledonia 168
New Hebrides (see Vanuatu) BO ee : of) 2s
New Zealand _ a oe 169 Pon
Nicaragua Se, SG eh tn, pele i
Niger as Nahi ta eee
Nigeria Ra : 173
Northern Rhodesia (see Zambia) -
_Norway 175
O oo, Oman me, “uinee teat eae OO a ee
P Pakistan Rah bo MG op Baan? feo ite EO ae’
Panama : oy ee ; 179
Papua New Guinea. ; — i181
Paraguay iss ei PU ace ee
Pemba (see Tanzania) : ae eae ee
Peru Se ies a eee 184
Philippines iy eae 185
Poland 2 86
Portugal aie, Gel Be eetly ee Oe, ees ee Be
Portuguese Guinea (see Guinea-Bissau) See eee ee Be ee,
__ Portuguese Timor (see Indonesia) pain yo See cee Ate fis ee
Q Qatar uh Gu est sR a> haath endl OO
R Ra''s al-Khaymah (see United Arab Emirates) 7 ; 7
Reunion _ 190 he
Rhodesia (see Zimbabwe) _ : : Ng fone Boats
Rio Muni (see Equatorial Guinea) eile Me armeee ae nce Sete ee
Romania DS hin eh ert 00 et Oe Bsa aeons
Rwanda sre So done lag Ree Pea ABiain
vi
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7 —
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Z 7 Page
S St. Christopher and Nevis (formerly St. Christopher-Nevis- Anguilla) 194
St. Lucia 7 2 195
St. Vincent and the Grenadines : 196
San Marino 197
Sao Tome and Principe 199
Saudi Arabia As 200
Senegal 201
Seychelles 202
Sharjah (see United Arab Emirates) a
Sierra Leone 204
Singapore : 205
Solomon Islands (formerly British Solomon Islands) 206
Somalia ; 207
South Africa 209
Southern Rhodesia (see Zimbabwe)
South-West Africa (see Namibia) ;
Soviet Union 210
Spain 212
Spanish Sahara (see Western Sahara) _
Sri Lanka (formerly Ceylon) 214
Sudan 216
Suriname 217
Swaziland 7 218
Sweden 220
Switzerland * 221
Syria ; 2233
T Tanganyika (see Tanzania)
Tanzania ; 224
Tasmania (see Australia) - ;
Thailand ; 226
Togo : - 227
Tonga 7 = 228
Transkei (see South Africa) 7 - -
Trinidad and Tobago ; ; 229
Tunisia = so 231
Turkey ae 7 232
Turks and Caicos Islands _ ; 233
Tuvalu (formerly Ellice Islands) 7 aaa eee _ 234
U Uganda _ ; 235
Umm al-Qaywayn (see United Arab Emirates) a ; 7
United Arab Emirates (Abu Dhabi, Ajman, Dubai, al Fujayrah, 237
Ra’s al-Khaymah, Sharjah, Umm al-Qaywayn)
United Arab Republic (see Egypt)
Vii
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Poe ey ey ee a ; Page
United Kingdom _ 288
United States 240
Upper Volta (see Burkina Faso) .
Uruguay ; 241
Vv Vanuatu (formerly New Hebrides) — 243 —
Vatican City 244
Venezuela 245
—..Vietmam 246
Ww Wallis and Futuna _ 247 -
Walvis Bay (see South Africa) i) he 7 ;
Western Sahara (formerly Spanish Sahara) 248 7
- ... Western Samoa _ 2A9
Y Yemen Arab Republic (North Yemen) — 250
Yemen, People’s Democratic Republic of (South Yemen) ne)
Yugoslavia _ 252
Z Zaire 254
Zambia (formerly Northern Rhodesia) a 255 7 =
Zanzibar (see Tanzania)
__ Zimbabwe (formerly Southern Rhodesia) a _ 257 _ ree
__Taiwan (China listed alphabetically) 8
West Bank and Gaza Strip 260
Appendixes
see
A. The United Nations System — 2620 7
B. Selected UN Organizations _ 263
C. Selected International Organizations POU oy ihn
D. Country Membership in Selected Organizations : 2660 0°
E. Conversion Table 274
Maps
__I The World (Guide to Regional Maps II-XII)
_IV. South America _
_Y. Europe
VI. Middle East _
VIL Africa _
_IX. Southeast Asia
XIE. Antarctic Region _
XIII. Standard Time Zones of the World
viii
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Definitions, Abbreviations,
and Explanatory Notes
Fiscal Year: The abbreviation FY stands for fiscal year; all years are
calendar years unless otherwise indicated.
GDP and GNP: GDP is the total market value of all goods and
services produced within the domestic borders of a country over a
particular time period, normally a year. GNP equals GDP plus the
income accruing to domestic residents arising from investment abroad
less income earned in the domestic market accruing to foreigners
abroad.
Imports, Exports, and Aid: Standard abbreviations used in individual
entries throughout this factbook are c.i.f. (cost, insurance, and freight),
f.o.b. (free on board), ODA (official development assistance), and OOF
(other official flows).
Land Utilization: Most of the land utilization percentages are rough
estimates. Figures for “arable” land in some cases reflect the area
under cultivation rather than the total cultivable area.
Maritime Zones: Fishing and economic zones claimed by coastal
states are included only when they differ from territorial sea limits.
Maritime claims do not necessarily represent the position of the
United States Government.
Money: All money figures are in contemporaneous US dollars unless
otherwise indicated.
Oil Terms: Barrel (bbl) and barrels per day (b/d) are used to express
volume of crude oil and refined products; a barrel equals 42.00
gallons, 158.99 liters, 5.61 cubic feet, or 0.16 cubic meters.
Note: Some of the countries and governments included in this
publication are not fully independent, and others are not officially
recognized by the United States Government.
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7','777a4dbb6fa754aa2176aa8982e820af11c35a2d6a7898612eaff0f620cee2b2','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82cb087a24a877b2b1de0df2114dff78fb4571f8b5b87b6e9e174430a8507a7d',1985,'AF','Afghanistan','raw',7,'300 km
See regional map VUE
Land
647,497 km?; about the size of Texas; 75%
desert, waste, or urban; 22% arable (12% cul-
tivated, 10% pasture); 3% forest
Land boundaries: 5,510 km','71ca058ab1b8f591ba463295dfd3edcbdcbc0ac38f5922d951513c9cd4097476','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edd2f989b51f0f9cf8abd4eade18c68ba4c4e520d111820b60e0892dcb59a071',1985,'','','raw',1,'Sanitized Copy Approved for Release 2010/03/11 : CIA-RDP87M01152R000500640035-4
OLL
Office of Legislative Liaison
Routing Slip
ACTION
INFO
1. D/OLL
X
2. DD/OLL
X
3. Admin Officer
4. Liaisoa
•\\r
A
5. Legislation
X
X
1
8.
9.
1 J
10.
SUSPENSE 1 August. 85
Action Officer:
Remarks:
BC / 26 July 85
Name/Date
Sanitized Copy Approved for Release 2010/03/11 : CIA-RDP87M01152R000500640035-4
I
Sanitized Copy Approved for R elease 2010/03/ 11 : CIA-RDP87M01152R000500640035-4
Sanitized Copy Approved for Release 2010/03/11 : CIA-RDP87M01152R000500640035-4
Sanitized Copy Approved for Release 2010/03/11 : CIA-RDP87M01152R000500640035-4
Co«grc00 of % Jittiteb
Committee on foreign ^faira
^ISause of ^presentati6ea
July 22, 1985
Li t;f»LAl!y[
Editor
The World Factbook
Central Intelligence Agency
Attn: Public Affairs
Washington, D.C. 20505
Dear Editor:
In the World Factbook, there is apparently a
mistake for the listing of the Colombian independence
day. Your book has July 30, but my almananacv and the
Diplomatic List put out by the State Department, 1 ists
independence day as July 20. I have always seen July
20th listed as their independence day.
Thank you.
Sincerely yours.
Shirley DaWSon
House Foreign Affairs Comm.
2170 Rayburn House Office Bldg
Washington, D.C. 20515
Sanitized Copy Approved for Release 2010/03/11 : CIA-RDP87M01152R000500640035-4
Sanitized Copy Approved for Release 2J)1 0/03/1 1 : CIA-RDP87M01152R0005q0640q35-4
fflmtjma of tf,e
o» gareistt
^ottse of 3R*J>r*««itatifte0
^nlfittglou, Z051S
M.C.
The World Factbook
Washington, D.C. 20505
"ililihilil
Sanitized Copy Approved for Release 2010/03/11 ; CIA-RDP87M01152R000500640035-4','dab8bbf7ff7ca27252d5b926383f9a6e6cc1e0fc504cf2de2e1e683d721b2384','internet-archive','CIA-RDP87M01152R000500640035-4','txt','ba4f82d9f3d9ca1fbbd1abaef30e701c082d38a2869ae92310c00e37be867ea3','https://archive.org/download/CIA-RDP87M01152R000500640035-4/CIA-RDP87M01152R000500640035-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67bf0e933da35ffebebea158af2e11d0ab68b6d4ad6b64d605eb6ac7edd6fba7',1985,'','','raw',1,'Sanitized Copy Approved for Release 201 0/03/11 : CIA-RDP87M01 152R000500640035-4
Dib: note loa
Office of Legislative Liaison
Routing Slip
.[_______ J AGTION
1. D/OLL
repoou |
reall
ee
Pes
3. Admin Officer
4.Liaison, id
5. Legislation
oy
SUSPENSE
BC / 26 July 85
Name/Date
Sanitized Copy Approved for Release 2010/03/11 : CIA-RDP87M01152R000500640035-4
Sanitized Copy Approved for Release 2010/03/11 : CIA-RDP87M01152R000500640035-4
TRANSMITTAL SLIP
PN Oe oo
47)
REPLACES FORM 36-8 (
ree Ne 241 WHICH MAY BE USED.
Sanitized Copy Approved for Release 2010/03/11 : CIA-RDP87M01152R000500640035-4
Sanitized Copy Approved for Release 2010/03/11 : CIA-RDP87M01152R000500640035-4
Congress of the United States
Pementiec es avams: ata CAINE tien]
July 22, 1985
| Re ALE AP;
Editor iat Rec comer ra
The World Factbook if RH| # put arve C
Central Intelligence Agency
Attn: Public Affairs
Washington, D.C. 20505
Dear Editor:
In the World Factbook, there is apparently a
mistake for the listing of the Colombian independence
day. Your book has July 30, but my almananac, and the
Diplomatic List put out by the State Department, lists
independence day as July 20. I have always seen July
20th listed as their independence day.
Thank you.
ace ly yours, _
_ Shirley DawSon
House Foreign Affairs Comm.
2170 Rayburn House Office Bldg
Washington, D.C. 20515
Sanitized Copy Approved for Release 2010/03/11 : CIA-RDP87M01152R000500640035-4
galled Copy A Pploved TOU ReIo asses NOOO NE oo ROBB TMD Toh CObe00G 08S aaa
Congress of the Muted States
Comuitice on Foreign Affsies
House of Representations
Weshington, BO. 20515
Official Business
Mart 8 Fr. ¢
M.C.
Editor
The World Factbook
Central Intel]i e
nc
Attn: Public Af fates Agency
Washington, D.C. 20505
FesdaEMeseelahaldessdelateadst
Sanitized Copy Approved for Release 2010/03/11 : CIA-RDP87M01152R000500640035-4','de05368c285174bb3195699f004c77c1c0f5b55c3571516ddb61972f124632b3','internet-archive','cia-readingroom-document-cia-rdp87m01152r000500640035-4','txt','79c5d14f29e4e34dd4b44e4d4fefc04ad752ac011157b22463433a143f858b78','https://archive.org/download/cia-readingroom-document-cia-rdp87m01152r000500640035-4/cia-rdp87m01152r000500640035-4_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f33260514d1cc1cecfddeff8417dbdb1ebbfec7333cf0ef06467e4285b45d43',1985,'','','raw',1,'Declassified in Part - Sanitized Copy Approved for e 2012/12/17 : CIA-RDP08- 00534R000100060001 -6
5 nln
World
Factbook
Nineteen Hundred and Eighty-Five
CENTR,
25X1
IssujQ © SALq-AIYSIy pur poApUNFY UsdJOUIN] © YOoQ}0eq P]IOM GYTL
yuswiajddng poy
CR WF 85-002
nme. Ad
; Declassified in Part - Sanitized Copy Approved for Release 2012/12/17 : CIA-RDP0O8-00534R000100060001-6 3 5
25X11
Declassified in Part - Sanitized Copy Approved for Release 2012/12/17 : CIA-RDP08-00534R000100060001-6
~@&
V4
Pod
Declassified in Part - Sanitized Copy Approved for Release 2012/12/17 : CIA-RDP0O8-00534R000100060001-6
4 . 7 oe
Pree oot
Declassified in Part - Sanitized Copy Approved for Release 2012/12/17 : CIA-RDP08-00534R000100060001-6
KES Central Secret
® Intelligence 25X1
Ag
] 4} Agency
aay
The
World
Factbook
Nineteen Hundred and Eighty-Five
Classified Supplement
The World Factbook and this Classified
Supplement are produced annually by the
Directorate of Intelligence of the Central
Intelligence Agency. The supplement
contains the classified entries,
25X1
In general, information available as of 1
January 1985 was used in the preparation of _
this edition of the Factbook. be:
25X1
Comments and queries are welcome and
may be addressed to the Factbook Editor,
Office of Central Reference
25X1
Secret
CR WF 85-002
(Supersedes CR 84-002)
May 1985
Declassified in Part - Sanitized Copy Approved for Release 2012/12/17 : CIA-RDPO8-00534R000100060001-6
Declassified in Part - Sanitized Copy Approved for Release 2012/12/17 : CIA-RDP08-00534R000100060001-6
Contents
Page
Definitions, Abbreviations, and Explanatory Notes ix
A Abu Dhabi (see United Arab Emirates)
Afghanistan 1
Aiman (see United Arab Emirates) 7
Albania 1
° Algeria 2
, Andorra no supplemental data
- Angola ss}
Anguilla (formerly St. Christopher-Nevis-Anguilla) no supplemental data
Antigua and Barbuda 3
Argentina 4
Australia 4
Austria 5
: Azores (see Portugal)
: B Bahamas, The 5
Bahrain 6
Balearic Islands (see Spain)
Bangladesh 6
Barbados 7
Belgian Congo (see Zaire)
Belgium 7
Belize (formerly British Honduras) 8
Benin (formerly Dahomey) 8
Bermuda 9
Bhutan 9
" Bioko (see Equatorial Guinea)
Bolivia 10
Bophuthatswana (see South Africa)
Botswana 10
Brazil : 1]
. British Honduras (see Belize)
British Solomon Islands (see Solomon Islands)
st Brunei li
: Bulgaria 12
: Burkina Faso (formerly Upper Volta) 12
Burma 13
Burundi 13
Cc Cabinda (see Angola)
Cambodia (formerly Kampuchea) 14
Cameroon 14
Canada 15
: Canary Islands (see Spain)
a iii Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/12/17 : CIA-RDP0O8-00534R000100060001-6
Declassified in Part - Sanitized Copy Approved for Release 2012/12/17 : CIA-RDP08-00534R000100060001-6
Secret
Page
Cape Verde 15
Central African Republic 16
Ceylon (see Sri Lanka)
Chad 16
Chile 16
China (Taiwan listed at end of table) 17
Colombia 18
Comoros 19
Congo 19
Cook Islands 20
Costa Rica 20
Cuba 20
Cyprus 21
Czechoslovakia 22
Dahomey (see Benin)
Denmark 23
Djibouti (formerly French Territory of the Afars and Issas) 23
Dominica 24 __
Dominican Republic 24
Dubai (see United Arab Emirates)
Ecuador 25
Egypt 26
Ellice Islands (see Tuvalu)
El] Salvador 26
Equatorial Guinea 27
Ethiopia 27
Falkland Islands (Islas Malvinas) 28
Faroe Islands 28
Fernando Po (see Equatorial Guinea)
Fiji 28
Finland 29
France 29
French Guiana 30
French Polynesia 81
French Territory of the Afars and Issas (see Djibouti)
Fujayrah, al (see United Arab Emirates)
Gabon 31
Gambia, The 32
German Democratic Republic 82
Germany, Federal Republic of 33
Ghana 33
Gibraltar 34
Secret iv
Declassified in Part - Sanitized Copy Approved for Release 2012/12/17 : CIA-RDP0O8-00534R000100060001-6
25X11.
Declassified in Part - Sanitized Copy Approved for Release 2012/12/17 : CIA-RDP08-00534R000100060001-6
Secret
25X1
Page
Gilbert Islands (see Kiribati)
Greece 34
Greenland 35
Grenada 85 a
Guadeloupe 36
Guatemala 36
Guinea 36
Guinea-Bissau (formerly Portuguese Guinea) 87
Guyana 87
H Haiti 38
Honduras 38
Hong Kong 39
Hungary 39
I Iceland 40
India 40
Indonesia 41
Tran 42
Iraq 43
Ireland 44
Israel 44
Italy 45
Ivory Coast 45
J Jamaica 46
Japan 46
Jordan 47
K Kampuchea (see Cambodia)
Kenya 47
Kiribati (formerly Gilbert Islands) 48
Korea, North 48
Korea, South 49
Kuwait 50
L Laos 51
Lebanon 51
Lesotho 52
Liberia 52
Libya 53
Liechtenstein 54
Luxembourg 54
M Macau 54
Madagascar 55
Madeira Islands (see Portugal)
Malagasy Republic (see Madagascar)
v Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/12/17 : CIA-RDP08-00534R000100060001-6
Declassified in Part - Sanitized Copy Approved for Release 2012/12/17 : CIA-RDP08-00534R000100060001-6
Secret
Page
Malawi 55
Malaysia 56
Maldives 56
Mali 57
Malta 57
Martinique 57
Mauritania 58
Mauritius 58
Mexico 58
Monaco 59
Mongolia 59
Morocco 60
Mozambique 60
Namibia (South-West Africa) 6]
Nauru 61
Nepal 62
Netherlands 62
Netherlands Antilles 63
New Caledonia 63
New Hebrides (see Vanuatu)
New Zealand 63
Nicaragua 64
Niger 64
Nigeria 65
Northern Rhodesia (see Zambia)
Norway 65
Oman 66
Pakistan 66
Panama 67
Papua New Guinea 68
Paraguay 68
Pemba (see Tanzania)
Peru 69
Philippines 69
Poland 70
Portugal 71
Portuguese Guinea (see Guinea-Bissau)
Portuguese Timor (see Indonesia)
Qatar 72
Ra’s al-Khaymah (see United Arab Emirates)
Reunion 72
Rhodesia (see Zimbabwe)
Secret vi
Declassified in Part - Sanitized Copy Approved for Release 2012/12/17 : CIA-RDP08-00534R000100060001-6
25X11
Declassified in Part - Sanitized Copy Approved for Release 2012/12/17 : CIA-RDPO08-00534R000100060001-6
Secret
25X1
Page
Rio Muni (see Equatorial Guinea)
Romania 72
Rwanda 73
S St. Christopher and Nevis (formerly St. Christopher-Nevis-Anguilla) 73
St. Lucia 74
St. Vincent and The Grenadines 74
San Marino no supplemental data
Sao Tome and Principe 74
Saudi Arabia 75
Senegal 75
Seychelles 76
Sharjah (see United Arab Emirates)
Sierra Leone 77
Singapore 77
Solomon Islands (formerly British Solomon Islands) 78
Somalia 78
South Africa 79
Southern Rhodesia (see Zimbabwe)
South-West Africa (see Namibia)
Soviet Union 80
Spain 81
Spanish Sahara (see Western Sahara)
Sri Lanka 82
Sudan 83
Suriname 83
Swaziland 84
Sweden 84
Switzerland 85
Syria 85
T Tanganyika (see Tanzania)
Tanzania 86
Tasmania (see Australia)
Thailand 87
Togo 87
Tonga 88
Transkei (see South Africa)
Trinidad and Tobago — 88
Tunisia 89
Turkey 89
Turks and Caicos Islands no supplemental data
Tuvalu (formerly Ellice Islands) 90
vii Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/12/17 : CIA-RDP0O8-00534R000100060001-6
Declassified in Part - Sanitized Copy Approved for Release 2012/12/17 : CIA-RDPO8-00534R000100060001-6
Secret
; 25x11
Page
U Uganda 90
Umm al-Qaywayn (see United Arab Emirates)
United Arab Emirates (Abu Dhabi, Aiman, Dubai, al Fujayrah, 91
Ra’s al-Khaymah, Sharjah, Umm al-Qaywayn)
United Arab Republic (see Egypt)
United Kingdom 91
United States no supplemental data
Upper Volta (see Burkina Faso)
Uruguay 92
Vv Vanuatu (formerly New Hebrides) 93
Vatican City 93
Venezuela 93
Vietnam 94
WwW Wallis and Futuna no supplemental data
Walvis Bay (see South Africa)
Western Sahara (formerly Spanish Sahara) 95
Western Samoa 95
Y Yemen, Arab Republic (North Yemen) 95
Yemen, People’s Democratic Republic of (South Yemen) 96
Yugoslavia 97
Z Zaire 98
Zambia (formerly Northern Rhodesia) 98
Zanzibar (see Tanzania)
Zimbabwe (formerly Southern Rhodesia) 99
Taiwan 99
West Bank and Gaza Strip no supplemental data
Appendix
Conversion Factors 101
Secret viii
Declassified in Part - Sanitized Copy Approved for Release 2012/12/17 : CIA-RDP08-00534R000100060001-6
7
wn F 8
Declassified in Part - Sanitized Copy Approved for Release 2012/12/17 : CIA-RDP08-00534R000100060001-6
sec
rer
25X11
Definitions, Abbreviations,
and Explanatory Notes
a ee
Fiscal Year: The abbreviation FY stands for fiscal year; all years
are calendar years unless otherwise indicated.
GDP and GNP: GDP is the total market value of all goods and
services produced within the domestic borders of a country over
a particular time period, normally a year. GNP equals GDP plus
the income accruing to domestic residents arising from invest-
ment abroad less income earned in the domestic market accruing
to foreigners abroad.
Imports, Exports, and Aid: Standard abbreviations used in
individual entries throughout this factbook are c.i.f. (cost, insur-
ance, and freight), f.0.b. (free on board), ODA (official develop-
ment assistance), and OOF (other official flows).
Land Utilization: Most of the land utilization percentages are
rough estimates. Figures for “‘arable” land in some cases reflect
the area under cultivation rather than the total cultivable area.
Maps: References under the locator maps pertain to the area
maps at the back of the unclassified version of The World
Factbook.
Maritime Zones: Fishing and economic zones claimed by coastal
states are included only when they differ from territorial sea
limits. Maritime claims do not necessarily represent the position
of the United States Government.
Money: All money figures are in contemporaneous US dollars
unless otherwise indicated.
Oil Terms: Barrel (bbl) and barrels per day (b/d) are used to
express volume of crude oil and refined products; a barrel equals
42.00 gallons, 158.99 liters, 5.61 cubic feet, or 0.16 cubic meters.
Note: Some of the countries and governments included in this
publication are not fully independent, and others are not official-
ly recognized by the United States Government.
ix Secret
Declassified in Part - Sanitized Copy Approved for Release 2012/12/17 : CIA-RDPO8-00534R000100060001-6
,','b90d79cf9eab90a7da16f4ef19774bc7d897ef5e0a3d2d2a02365d00a3adb0de','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100060001-6','txt','18d057b52ca06dd958ce7ced0c142682e4c9f05d2f265173892cee92cf00975e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100060001-6/cia-rdp08-00534r000100060001-6_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('535f22ec208297ed528feb8e1ac52c655f8cb30668e38d3086832c7591de5fa4',1985,'','','raw',1,'Intolli^riuc
j| A^cik*>-
V^rhitMOf*^
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
The
World
NOT MICROFILMED
Factbook
For Data Erstry
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
This publication is prepared for the use of US
Government officials, and the format, coverage,
and content are designed to meet their specific
requirements. US Government officials may ob-
tain additional copies of this document directly
or through liaison channels from the Central
Intelligence Agency.
Requesters outside the US Government may ob-
tain subscriptions to CIA publications similar to
this one by addressing inquiries to:
Document Expediting (DOCEX) Project
Exchange and Gift Division
Library of Congress
Washington, D.C. 20540
or: National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Requesters outside the US Government not inter-
ested in subscription service may purchase spe-
cific publications either in paper copy or micro-
form from:
Photoduplication Service
Library of Congress
Washington, D.C. 20540
or: National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
To expedite service call the
NTIS Order Desk (703) 487-4650
This publication may also be purchased from:
Superintendent of Documents
US Government Printing Office
Washington, D.C. 20402
(Stock Number 041-015-00159-2)
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Ci-UTft
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Central
I Intelligence
Agency
The
World
Factbook
Nineteen Hundred and Eighty-Five
The World Facthook is produced annually
by the Directorate of Intelligence of the
Ontral Intelligence Agency, The data are
provided by various components of the
Ontral Intelligence Agency, the Defense
Intelligence Agency, the Bureau of the
C''ensus, and the US Department of State. In
general, information available as of 1
January 1985 was used in the preparation of
this edition, with the following exceptions:
• Population figures are projected estimates
for 1 July 1985; the average annual
growth rates listed are projected estimates
for the period mid- 1984 to mid- 1985.
• Military manpower estimates are as of 1
January 1985, except the numbers of
males reaching military age, which are
projected averages for the five-year
period 1985-89.
• Major political developments through 22
April 1985 have been included.
C’omments and queries are welcome and
may be addressed to:
Ontral Intelligence Agency
Attn: Public Affairs
Washington, D.C. 20505
(703)351-2053
For information on how to obtain addi-
tional copies, see the inside of the front
cover.
CR WF 85-001
(Supersedes CR WF 84-001)
May 1985
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
B
Contents
Page
Definitions, Abbreviations, and Explanat^y Notes ix
Abu Dhabi (see United Arab Emirates)
Afghanistan 1
Ajman (see United Arab Emirates)
Albania 2
Algeria ^
Andorra 5
Angola b
Anguilla (formerly St. Christopher-Nevis-Anguilla) 7
Antigua and Barbuda b
Argentina 9
Australia ^1
Austria b3
Azores (see Portugal)
Bahamas, The 14','e0918b3f8b1c0c7dc8d2cb1a770c979c2d33bd69bafc0bafc16b5bae75492532','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53d46377eb65ce2477c419554ee60604d6c58d89420c660ba7701a2803e3adb3',1985,'BD','Bangladesh','raw',2,'Barbados lb
Belgian Congo (see Zaire)
Belgium ^9
Belize (formerly British Honduras) 21
Benin (formerly Dahomey) 23
Bermuda 24
Bhutan 25
Bioko (see Equatorial Guinea)
Bolivia 26
Bophuthatswana (see South Africa)
Botswana 27
Brazil 29
British Honduras (see Belize)
British Solomon Islands (see Solomon Islands)
Brunei 30
Bulgaria 32
Burkina Faso (formerly Upper Volta) 33
Burma 34
Burundi 36
Cabinda (see Angola)
Cambodia (formerly Kampuchea) 37
Cameroon 38
Canada 40
Canary Islands (see Spain)
Cape Verde 41
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Page
Central African Republic 42
Ceylon (see Sri Lanka)
Chad 44
Chile 45
China (T aiwa n li^d at end of table) 47
Colombia 48
Comoros 50
Cong o 51
Cook Islands 52
^sta Ric^ 53
Cuba 55
Cyprus 50
Cz^hoslovakia 58
D Dahomey (see Benin)
Den mark 59
Djibouti (formerly French Territory of the Afars and Issas) 61
Dorninica 62
Dominican Republic 63
Dubai (see Uriited Arab Emirates)
E Ecuador 64
^Pt 66
Ellic e Islands (see Tuvalu)
El Salvador 67
Equ atorial Guinea 69
Ethiopia 70
F Falkland Islands (Islas Malvinas) 72
Faroe Islands 73
Fernando Po (see Equatorial Guinea)
Fin 74
Finland 75
France 77
FTench Guiana 78
French Polynesia 80
French Territory of the Afars and Issas (see Djibouti)
Fujayrah, al (see United Arab Emirates)
G Gabon 81
Gam bia, The 82
Gaza ^ip (see West Bank and Gaza Strip, listed at end of table)
German De moc ratic Republic 83
G erm any, Federal Republic of 85
Gha na 87
Gibraltar 88
Gilbert Isl^ds (see Kiribati)
iv
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
H
I
J
K
1 .
M
Greece _ _
Greenland _
Grenada —
Guadeloupe _ _
Guatemala _ _ _
Guinea .
Guinea-Bissau (formerly Portuguese Guinea)
Guyana . _
Haiti _ — —
Honduras _ _ __ _
Hong Kong _ _ —
Hungary __ _ _ _
Iceland —
India __ __
Indonesia . —
Iran __ _ —
Iraq _ _ —
Ireland —
Israel (West Bank and Gaza Strip list^ aj ej^
Italy .. -
Ivory ("oast _ _
Jamaica . ... _
Japan _ __ —
Jordan (West Bank and Gaza Strip jisted at_end of t abl e)
Kampuchea (see Cambodia)
Kenya _ _ —
Kiribati (formerly Gilbert Islands)
Korea, North _ _
Korea, South
Kuwait _ _ _ _ _
Laos _ _ ___ __ --
Lebanon _ ..
Lesotho _
Liberia _
Libya _ . -
Liechtenstein . - - -','27e584c90bd2508629d50281e0ebd8620f9baeca88da2259004583dffc0a164e','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb2594cf2fc8491bd40cf7750d6c4ddca154e9e7ab60f1619f7d228f3d33ddad',1985,'LU','Luxembourg','raw',3,'Macau
Madagascar _
Madeira Islands (see Portugal) _ _
Malagasy Republic (see Madagascar)
Malawi _ _ „ __ _ __
Malaysia _ _ _
Page
89
91
92
93
94
96
97
99
100
101
103
104
106
107
109
110
112
113
U4_
116
118
119
121
122
124
125
126
127
129
130
132
133
135
136
137
139
140
141
143
144
V
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
N
O
P
0
R','11b1fdbf816b991b5658edee48b88123a81bf4436db99ce3e09d4ce877a0a64f','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36084fc86ac3235395d7f23556e62a4ac5f7eb4fa6e862d75e9efbca5a2a7a11',1985,'PT','Portugal','raw',4,'Portuguese Guinea (see Guinea-Bissau)
Portuguese Timor (see Indonesia)
^atar
s abKhaymah (see United Arab Emirates)
Reunion
Rhodesia (see Zimbabwe)
Rio Mimi (see Equatorial Guinea)
Rom ania','49429347be510776bbba9945c764542dd372a5f3e58d71a2badb7be3a93a0ccb','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4aa4aa2ba5932b126457ff4716906319cbaff4ba3fff18fe01c9ed42d1bc64e',1985,'RW','Rwanda','raw',5,'^ Page
147
148
149
150
152
153
154
156
157
158
160
161
162
163
165
1^66
168
169
170
172
173
175
176
178
179
181
182
184
185
186
188
189
190
192
193
vi
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Page
S St. Christopher and Nevis (formerly St. Christopher-Nevis-Anguilla) 194
St. Lucia 195
St. Vincent and the Grenadines 19h
San Marino 197
Sao Tome and Principe 199
Saudi Arabia 200
Senegal 201
Seychelles 202
Sharjah (see United Arab Emirates)
Sierra Leone 204
Singapore 205
Solomon Islands (formerly British Solomon Islands) 206
Somalia 207
South Africa 209
Southern Rhodesia (see Zimbabwe)
South-West Africa (see Namibia)
Soviet Union 210
Spain 212
Spanish Sahara (see We.stern Sahara)
Sri Lanka (formerly Ceylon) 214
Sudan 216
Suriname 217
Swaziland 218
Sweden 220
Switzerland 221
Syria 223
T Tanganyika (see Tanzania)
Tanzania 224
Tasmania (see Australia)
Thailand 226
Togo 227
Tonga 228
Transkei (see South Africa)
Trinidad and Tobago 229
Tunisia 231
Turkey 232
Turks and Caicos Islands 233
Tuvalu (formerly Ellice Islands) __
U Uganda 235
Umm al-Oaywayn (see United Arab Emirates)
United Arab Emirates (Abu Dhabi, Ajman, Dubai, al Fujayrah, 237
Ra’s al-Khaymah, Sharjah, Umm al-Qaywayn)
United Arab Republic (see Egypt)
vii
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
— - - ■ - — -
Page','3b3398802e44153eb6b3195138822fd984cc1bec3d92488d3cd6aec3ef8abb0f','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f040e2d1d7c99ef2add5215c5a387630f6da2b6de37740cf06d98ec8cd5b5535',1985,'UY','Uruguay','raw',6,'241
V
Vanuatu (formerly New Hebrides)
243
Vatican City
244
Venezuela
245
Vietnam
246
w','6f9c0ef0d3650999ee7618b9872769d2e0479bd3ea49767f83dfbbc8d0241531','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('663f7db5e8c584140dcc88961b686ef98008a642281b75c546f3c0f98789a0af',1985,'WF','Wallis and Futuna','raw',7,'247
Walvis Bay (see South Africa)
Wes^rn Sahara (formerly Spanish Sahara)
248
Western Samoa
249
Y
Yemen Arab Republic (North Yemen)
250
l^opl^’s Democratic Republic of (South Yemen)
251
Yugoslavia
252
z
Zaire
254
Zambia (formerly Northern Rhodesia)
255
Zanzibar (see Tanzania)
Zimbabwe (formerly Southern Rhodesia)
257
Taiwan (China listed alphabetically)
258
West Bank and Gaza Strip
260
Appendixes
A. The United Nations System
262
B. Selected UN Organizations
263
C. Selected International Organizations
264
Membership in Selected Organizations
266
E. Conversion Table
274
Maps
L The World (Guide to Regional Maps II-XIII)
II. North America
III Central America and the Caribbean
IV. South America
V. Europe
VI. Middle East
VII. Africa
VIII. Soviet Union, East and South Asia
IX. Southeast Asia
X. Oceania
XI. Arctic Region
XII. Antarctic Region
XIII. Standard Time Zones of the World
viii
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Definitions, Abbreviations,
and Explanatory Notes
Fiscal Year: The abbreviation FY stands lor fiscal year; all years are
calendar years unless otherwise indicated.
GDP and GNP: GDP is the total market value of all goods and
services produced within the domestic borders of a country over a
particular time period, normally a year. GNP equals GDP plus the
income accruing to dornt^stic residents arising from investment abroad
less income earned in the domestic market accruing to foreigners
abroad.
Imports, Exports, and Aid: Standard abbreviations used in individual
entries throughout this lactbook are c.i.f. (cost, insurance, and freight),
f.o.b. (free on board), CD A (official developnu‘nt assistance), and OOF
(other official flows).
Land Utilization: Most of the land utilization percentages are rough
estimates. Figures for “arable land in some cases reflect the area
under cultivation rather than the total cultivable area.
Maritime Zones: Fishing and economic zones claimed by coastal
states are included only when they differ from territorial sea limits.
Maritime claims do not necessarily represent the position of the
United States (Government.
Money: All money figures are in contemporaneous US dollars unless
otherwise indicated.
Oil Terms: Barrel (bbl) and barrels per day (b/d) are used to express
volume of crude oil and rt‘fined products; a barrel equals 42. GO
gallons, 158.99 liters, 5.61 cubic feet, or 0.16 cubic meters.
Note: Some of the countries and governments included in this
publication are not fully independent, and others are not officially
recognized by the United States (Government.
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7','54d558427701497878630b410ceaa98580fd2f513427cefda26139111adcd77b','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9afb8c714d70dda51987c0f108ce949ee34014c6e20006512cd7498c9f24f69',1985,'AF','Afghanistan','raw',8,'300 km
See rr|ionil map Vlli
Land
647,497 km^; about the size of Texas; 75%
desert, waste, or urban; 22% arable (12% cul-
tivated, 10% pasture); 3% forest
Land botmdaries: 5,510 km','8bf08b7dda7bf10bfaf311f5b766e9058801109f3000c41444521f6ee42f773e','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

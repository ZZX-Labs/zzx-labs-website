SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a1b62b9bc3260e2938c94e8501aaee8e8d6d39711d82a06038466636554d638',1985,'AF','Afghanistan','people-and-society',3,'Population: 14,792,000 (July 1985), average
annual growth rate 1.7%; these estimates in-
clude an adjustment for emigration to
Pakistan during recent years, but they do not
take into account other demographic conse-
quences of the Soviet intervention in
Nationality: noun—Afghan(s), adjective—
Afghan
Ethnic divisions: 50% Pashtun, 25% Tajik,
9% Uzbek, 9% Hazara; minor ethnic groups
include Chahar Aimaks, Turkmen, Baluchi,
and others
Religion: 74% Sunni Muslim, 25% Shi''a Mus-
lim, 1% other
Language: 50% Pashtu, 35% Afghan Persian
(Dari), 11% Turkic languages (primarily
Uzbek and Turkmen), 10% thirty minor lan-
guages (primarily Baluchi and Pashai); much
bilingualism
Literacy: 12%
Labor force: 4.98 million (1980 est.); 67.8%
agriculture and animal husbandry, 10.2% in-
dustry, 6.3% construction, 5.0% commerce,
7.7% services and other; current figures un-
available because of fighting (1984)
Organized labor: government-controlled
unions are being established','086fb05df9b1aae952bab71e91bec5673c8befd8fcc216989021bef07d770dd8','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a1197d9f858b71f07ed72442b829c44d8b900d658c0eb50378b75589e81432b',1985,'AL','Albania','people-and-society',8,'Population: 2,968,000 (July 1985), average
annual growth rate 2.2%
Nationality: noun—Albanian(s); adjective—
Albanian
Ethnic divisions: 96% Albanian; remaining
4% are Greeks, Vlachs, Gypsies, and
Bulgarians
Religion: Albania claims to be the world’s
first atheist state; prewar est. 70% Muslim,
20% Albanian Orthodox, 10% Roman Catho-
lic; observances prohibited
Language: Albanian (Tosk is official dialect),
Greek
Literacy: 75%
Labor force: 584,000 (1978); about 22% agri-
culture, 40% industry and commerce, 38%
other (1978)
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2','2337fa7b1394161b7165eb838088dd9ccb5dd987eba2a514c3ed5c0ee268d7c6','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0041b00edb058972e98ac187240c72c89275b1917592582fe022c2bd7b0be1c',1985,'DZ','Algeria','people-and-society',12,'Population: 22,025,000 (July 1985), average
annual growth rate 3.1%
Nationality: noun—Algerian(s), adjective—
Algerian
Ethnic divisions: 99% Arab-Berbers, less
than 1% Europeans
Religion: 99% Sunni Muslim (state religion),
1% Christian and Jewish
Language: Arabic (official), French, Berber
dialects
Literacy: 46%
Labor force: 3.7 million (1984); 40% industry
and commerce, 30% agriculture, 17% gov-
ernment, 10% services; at least 11% of urban
labor unemployed
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Algeria (continued)
Organized labor: 16-19% of labor force
claimed; General Union of Algerian Workers
(UGTA) is the only labor organization and is
subordinate to the National Liberation Front','e188317a2eb801186bf1eb49f82131c1d6d1789fc18ba487612ac82745637af5','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85b9bec705960fa13aeed920aa579949f21bb6911a3850ac12996d5804043341',1985,'AD','Andorra','people-and-society',16,'Population: 47,000 (July 1985), average an-
nual growth rate 5.4%
Nationality: noun—Andorran(s); adjec-
tive—Andorran
Ethnic divisions: Catalan stock; 61% Spanish,
30% Andorran, 6% French, 3% other
Religion: virtually all Roman Catholic
Language: Catalan (official); many also
speak some French and Castilian
Literacy: 100%
Labor force: unorganized (unions prohib-
ited); largely shepherds and farmers','6dbbf8e70329007f8d95bcc2bec9d64ec0669ec7d7090d7e66b5a4f592840250','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9862ccd9c36b78fcaa922ee56963cd5e9c4469c0d9036e833859e62b9bcd3d99',1985,'AO','Angola','people-and-society',20,'Population: 7,953,000, including Cabinda
(July 1985), average annual growth rate 2.7%;
Cabinda, 129,000 (July 1985), average annual
growth rate 3.2%
Nationality: noun—Angolan(s); adjective—
Angolan
Ethnic divisions: 38% Ovimbundu, 23%
Kimbundu, 138% Bakongo, 2% Mestico, 1%
European
Religion: 68% Roman Catholic, 20% Protes-
tant, about 10% indigenous beliefs
Language: Portuguese (official); various
Bantu dialects ''
Literacy: 20%
Labor force: 1,865,000 economically active
(mid-1980 est.); 60% agriculture, 15%
industry
Organized labor: approx. 450,695 (1980)','52dd76f5e6684be72a769be46fde29eae4d732b85b930c56ef6c9f187b01dc55','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('747ed2758f1926ec97d097b6bbe0cbc44ebef8eb447935b44342f32d7319ce08',1985,'AI','Anguilla','people-and-society',24,'Population: 7,000 (1982 est.)
Nationality: noun—Anguillan(s); adjec-
tive—Anguillan
Ethnic divisions: mainly of African Negro
descent
Religion: Anglican and Methodist
Language: English (official)
Literacy: 80%
Labor force: 2,000 Anguillans living overseas
send remittances home; high unemployment
(40% in 1977)
Organized labor: none','62feb2954a4bd182427daaece05997bf3a7545570af5d8261ef6e9b6159701fa','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('559480700f6c6d1ebcb43d4af76f9d3d4e515ce2e1fbf29368753232132b0913',1985,'AG','Antigua and Barbuda','people-and-society',28,'Population: 80,000 July 1985), average an-
nual growth rate 0%
Nationality: noun—Antiguan(s); adjective—
Antiguan
Ethnic divisions: almost entirely African
Negro
Religion: Anglican (predominant), other
Protestant sects, some Roman Catholic
Language: English
Literacy: about 88%
Organized labor: 18,000, 22-26% unemploy-
ment (1983 est.)','11a151ef741b70e8e5f67fd6d6378b76b4ea40510ab15efeaeeaba533b2b7858','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d68c17a8575ec161d4129515e806e9a5d4a2b53be730210998fb43c3f17f5b5',1985,'AR','Argentina','people-and-society',32,'Population: 30,708,000 (July 1985), average
annual growth rate 1.6%
Nationality: noun—Argentine(s); adiec-
tive—Argentine
Ethnic divisions: approximately 85% white,
15% mestizo, Indian, or other nonwhite
groups
Religion: 90% nominally Roman Catholic
(less than 20% practicing), 2% Protestant, 2%
Jewish, 6% other
Language: Spanish (official), English, Italian,
German, French
Literacy: 94%
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Argentina (continued)
Labor force: 11.2 million (1982 est.); 19% ag-
riculture, 25% manufacturing, 20% services,
11% commerce, 6% transport and communi-
cations, 19% other; 6% estimated unem-
ployment (1982 est.)
Organized labor: 25% of labor force (est.)','b2728cff46d62243b26d938e878b24853d931c98388465db5c1b63a8833a0058','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7cbeebc7814e6ff5e4f59bf91e53fe58c63810a25cc1816ee3aafd3d4a34313f',1985,'AU','Australia','people-and-society',36,'Population: 15,658,000 (July 1985), average
annual growth rate 1.3%
Nationality: noun—Australian(s); adjec-
tive—Australian
Ethnic divisions: 99% Caucasian, 1% Asian
and aborigine
Religion: 27.7% Anglican, 25.7% Roman
Catholic, 25.2% other Protestant
Language: English, native languages
Literacy: 98.5%
Labor force: 7.2 million (November 1984);
8.7% unemployment (December 1984)
Organized labor: 57% of total employees
(December 1982)','20a94de26db82b93ef72623d95b06b2ad3c6a45c23d1890eff5f5003475eb6e5','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc9d9e0439af6a01cb82e1c8bfaf47b990f0ecc8e13a6fbb550abb7de2a60482',1985,'AT','Austria','people-and-society',40,'Population: 7,540,000 (July 1985), average
annual growth rate 0%
Nationality: noun—Austrian(s); adjective—
Austrian
Ethnic divisions: 99.4% German, 0.3% Cro-
atian, 0.2% Slovene, 0.1% other
Religion: 88% Roman Catholic, 6% Protes-
tant, 6% none or other
Language: German
Literacy: 98%
Labor force: 2.9 million (1983); 41.1% indus-
try and crafts, 57.55% services, 1.35%
agriculture and forestry; 4.1% unemployed
(October 1984); an estimated 200,000 Austri-
ans are employed in other European
countries; foreign laborers in Austria number
142,030 (1984)
Organized labor: 61.4% of wage and salary
workers (1983)
Population: 232,000 (July 1985), average an-
nual growth rate 2.0%
Nationality: noun—Bahamian(s): adjec-
tive—Bahamian
Ethnic divisions: 85% black, 15% white
Religion: Baptist 29%, Anglican 23%, Roman
Catholic 22%, smaller groups of other Protes-
tants, Greek Orthodox, and Jews
Language: English: some Creole among
Haitian immigrants
Literacy: 89%
Labor force: 82,000 (1982); 30% government,
25% hotels and restaurants, 10% business ser-
vices, 6% agriculture; 30% unemployment
(1983)
Organized labor: 25% organized
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2','07fcc8c1dc7b2d4f8583c71ed7220a9f0ca9bed58483ef917ae9f73e492265e8','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3100472a8cc2b836fa1101952f13e33d3d19ef240dfad3c73fa31536570f1790',1985,'BH','Bahrain','people-and-society',47,'Population: 427,000 uly 1985), average an-
nual growth rate 3.8%
Nationality: noun—Bahraini(s); adjective—
Bahraini
Ethnic divisions: 63% Bahraini, 13% Asian,
10% other Arab, 8% Tranian, 6% other
Religion: Muslim (60% Shi''a, 40% Sunni)
Language: Arabic (official); English also
widely spoken; Farsi, Urdu
Literacy: 40%
Labor force: 140,000 (1982); 42% of labor
force is Bahraini; 85% industry and com-
merce, 5% agriculture, 5% services, 3%','2112714e6eb7557afa27d9d75fb8f5ccb7c9e9b5e0b173327d3bb835eb069c27','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb4e8be4953132766d54f325d7f56b6fdc6ba0bc4adcd428f2ce3af6ef66dedb',1985,'BD','Bangladesh','people-and-society',52,'Population: 101,408,000 (July 1985), average
annual growth rate 2.8%
Nationality: noun—Bangladeshi(s), adiec-
tive—Bangladesh
Ethnic divisions: 98% Bengali; 250,000
“Biharis” and fewer than one million tribals
Religion: 83% Muslim, about 16% Hindu, less
than 1% Buddhist, Christian, and other
Language: Bangla (official), English widely
used
Literacy: 25%
Labor force: 32.4 million (FY83), extensive
export of labor to Saudi Arabia, UAE, Oman,
and Kuwait; 74% of labor force is in agricul-
ture, 15% services, 11% industry and
commerce (FY81 /82)
17','a112d600b1340441451f18d393913932dc4982241b6b1c1aaab11b2be790f7f4','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb0be5cd89f3bb07dcfc8978754bc5647dd67d13e45816c5ec8fa367e580279e',1985,'BB','Barbados','people-and-society',56,'Population: 252,000 (July 1985), average an-
nual growth rate 0.3%
Nationality: noun—Barbadian(s); adiec-
tive—Barbadian
Ethnic divisions: 80% African, 16% mixed,
4% European
Religion: 70% Anglican, 9% Methodist, 4%
Roman Catholic, 17% other, including Mora-
vian
Language: English
Literacy: 99%
Labor force: 103,900 (1982), 65.6% services
and government, 24.6% industry and com-
merce, 9.8% agriculture; 11% unemploy-
ment (1979)
Organized labor: 32%
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2','f5ad320a3086b1fa837d08beb55107d805a7741e0170cface0e0290e5bb662eb','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec2e9f01074cd8b2d0c53337d4c29298d5a745715ae96509f2bdd641c634eaa6',1985,'BE','Belgium','people-and-society',60,'Population: 9,856,000 (July 1985), average
annual growth rate 0%
Nationality: noun—Belgian(s); adjective—
Belgian
Ethnic divisions: 55% Fleming, 33% Wal-
loon, 12% mixed or other
Religion: 75% Roman Catholic, remainder
Protestant, none, or other
Language: 56% Flemish (Dutch), 32%
French, 1% German; 11% legally bilingual,
divided along ethnic lines
Literacy: 98%
Labor force: 4 million (1983); 36% transporta-
tion, 33% industry and commerce, 21%
public services, 2.3% agriculture; 11% unem-
ployed (1983)
Organized labor: 70% of labor force','e4ecc1ee017f8b2ae60656b68f978ab22a0c087b8e146bc1fca4b2e6027ed2ba','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aafe6f4971a69995464268e5b07ee08312f06f3c1979a1d2b2f5d5d67da4c60b',1985,'BZ','Belize','people-and-society',64,'Population: 161,000 (July 1985), average an-
nual growth rate 2.3%
Nationality: noun—Belizean(s), adjective—
Belizean
Ethnic divisions: 51% black, 22% mestizo,
19% Amerindian, 8% other
Religion: 50% Roman Catholic; Anglican,
Seventh-Day Adventist, Methodist, Baptist,
Jehovah’s Witnesses, Mennonite
Language: English (official), Spanish Maya,
Carib
Literacy: over 80%
Labor force: 51,500 (1984); 30% agriculture,
16% services, 15.4% government, 11.2% com-
merce, 10.3% manufacturing; shortage of
skilled labor and all types of technical person-
nel; over 14% are unemployed
: CIA-RDP86S00596R000200790001-2
Belize (continued)
Organized labor: 15% of labor force','19da2b1dae18b129829f43e55783ecbbf3a78330b8316249cdd16604ce838b09','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d1b928e82c9929b6bd3d0b0266a33a6d34c6d3cf5a43bd80dc8a55c8092b44b',1985,'BJ','Benin','people-and-society',68,'Population: 4,015,000 (July 1985), average
annual growth rate 3.1%
Nationality; noun—Beninese (sing. pl.); ad-
jective—Beninese
Ethnic divisions: 99% African (42 ethnic
groups, most important being Fon, Adia,
Yoruba, Bariba); 5,500 Europeans
Religion: 70% animist, 15% Muslim, 15%
Christian
Language: French (official); Fon and Yoruba
most common vernaculars in south; at least
six major tribal languages in north
Literacy: 20%
Labor force: 1.5 million (1982); 70% of labor
force employed in agriculture; less than 2% of
the labor force work in the industrial sector,
and the remainder are employed in trans-
port, commerce, and public services
Organized labor: approximately 75% of
wage earners, divided among two major and
several minor unions','dec16743537f039ccc6e36f9fc8be78fe08afacf03fa010258747ea602929538','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cfea174e314b5d920bfe3e24c1c6fb8cb04d27cceb13cd65565c2e1af3a0528',1985,'BM','Bermuda','people-and-society',72,'Population: 58,000 (July 1985), average an-
nual growth rate 0.5%
Nationality: noun—Bermudian(s); adiec-
tive—Bermudian
Ethnic divisions: 61% black, 39% white and
other
Religion: 37% Anglican, 21% other Protes-
tant, 28% Catholic, 28% Black Muslim and
other
Language: English
Literacy: 98%
Labor force: 29,669 employed (1980); 25%
clerical, 22% services, 22% laborers, 13% pro-
fessional and technical, 9% administrative
and managerial, 7% sales, 2% agriculture and
fishing
24','4aea4a8c2ddcbd5af94716497e7b6590dee398bea8d5447efe118039b83620b0','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8352a08013ba06781833995efba8f6d59b5740dc059fa38a8d164676ce42651e',1985,'BT','Bhutan','people-and-society',77,'Population: 1,417,000 (July 1985), average
annual growth rate 2.1%
Nationality: noun—Bhutanese (sing., pl.);
adjective—Bhutanese
Ethnic divisions: 60% Bhote, 25% ethnic
Nepalese, 15% indigenous or migrant tribes
Religion: 75% Lamaistic Buddhism, 25%
Buddhist-influenced Hinduism
Language: Bhotes speak various Tibetan dia-
lects—most widely spoken dialect is
Dzongkha (official); Nepalese speak various
Nepalese dialects
Literacy: 5%
Labor force: 95% agriculture, 1% industry
and commerce (1983); massive lack of skilled
labor
Population: 6,195,000 (July 1985), average
annual growth rate 2.6%
Nationality: noun—Bolivian(s); adjective
Bolivian
Ethnic divisions: 830% Quechua, 25% Ay-
mara, 25-30% mixed, 5-15% European
Religion: 95% Roman Catholic; active Prot-
estant minority, especially Methodist
Language: Spanish, Quechua, and Aymara
(all official)
Literacy: est. 75%
Labor force: 1.7 million (1983); 47% agricul-
ture, 23% services, 19% industry and
commerce, 11% government
Organized labor: 150,000-200,000, concen-
trated in mining, industry, construction, and','200a70fdba4222239fd98ca5a9b77a9f013f9ebd7e13f1216d56fe1d4d7f64d8','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4f1f5b9da231f68431483d6f0bcb21b419e7b96c1e193339b3bda81cde7439b',1985,'BW','Botswana','people-and-society',81,'Population: 1,068,000 (July 1985), average
annual growth rate 3.8%
Nationality: noun—Motswana (sing.),
Batswana (pl.); adjective—Botswana |
Ethnic divisions: 94% Tswana, 5% Bushmen,
1% European
Religion: 40% indigenous beliefs, 15% Chris-
tian
Language: English (official), Setswana
vernacular
Literacy: about 24% in English; about 35% in
Tswana; less than 1% secondary school grad-
uates
Labor force: about 400,000 total; 103,600 for-
mal sector employees (1980-81); most others
are engaged in cattle raising and subsistence
agriculture; 40,000 formal sector employees
spend at least six to nine months per year as
wage earners in South Africa (1980); 12% un-
employment (1983)
Organized labor: 16 trade unions organized
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Botswana (continued)','a8cbfb7356598afd23d09a65f3242df26a0b53b6824b3aa71f02e7a9e127e93b','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e52941f847e8e5feb761ca45e7654c48f6866f31225a9cbddd1c279ee6f5852a',1985,'BR','Brazil','people-and-society',85,'Population: 187,502,000 (July 1985), average
annual growth rate 2.8%
Nationality: noun—Brazilian(s); adjective—
Brazilian
Ethnic divisions: Portuguese, Italian, Ger-
man, Japanese, black, Amerindian; 55%
white, 38% mixed, 6% black, 1% other
Religion: (1980) 89% Roman Catholic (nomi-
nal)
Language: Portuguese (official)
Literacy: 74%
Labor force: about 50 million in 1982, 29.9%
agriculture, livestock, forestry, and fishing;
24.4% industry; 20.8% services, transporta-
tion, and communication; 9.4% commerce;
7.0% social activities; 4.1% public adminis-
tration; 2.9% other; significant
underemployment and unemployment
Organized labor: about 6 million (1982)
Population: 221,000 July 1985), average an-
nual growth rate 3.8%
Nationality: noun—Bruneian(s); adjective—
Bruneian
Ethnic divisions: 70% Malay, 25% Chinese,
5% other
Religion: 60% Muslim (Islam official reli-
gion); 8% Christian; 32% other (Buddhist and
animist)
Language: Malay official; English and Chi-
nese
Literacy: 45%
Labor force: 68,128 (includes members of the
Army); 63% trade and services; 23% manu-
facturing and construction; 11% agriculture,
forestry, fishing, and mining (1981)
30
Approved For Release 2011/02/09 ; CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Organized labor: 2% of labor force','7ca78f867a582252c26bdda30530d1a429edafa82b8c52449a6a8ca745763271','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d175b44da9c088372931c8e4b998925754cac033410dd396073a4bc694cb6d66',1985,'BG','Bulgaria','people-and-society',89,'Population: 8,980,000 (July 1985), average
annual growth rate 0.2%
Nationality: noun—Bulgarian(s); adjec-
tive—Bulgarian
Ethnic divisions: 85.3% Bulgarian, 8.5%
Turk, 2.6% Gypsy, 2.5% Macedonian, 0.3%
Armenian, 0.2% Russian, 0.6% other
Religion: regime promotes atheism; religious
background of population is 85% Bulgarian
Orthodox, 13% Muslim, 0.8% Jewish, 0.7%
Roman Catholic, 0.5% Protestant, Grego-
rian-Armenian and other
Language: Bulgarian; secondary languages
closely correspond to ethnic breakdown
Literacy: 95% (est.)
Labor force: 3,997,615 (1983); 42.6% indus-
try and commerce, 23.3% agriculture, 1.5%
government, 32.6% other','ef42f05adb4c37c7770f2b5e49bb46c37dc04dfc6fbc81582f711a302ea8550e','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66a59209964daca21f3f9c580c7cf5b2e371690d4131b52bfa1706b0f189f73d',1985,'BF','Burkina Faso','people-and-society',93,'Population: 6,907,000 (July 1985), average
annual growth rate 2.5%
Nationality: noun—Burkinabe; adjective—
Burkinan
Ethnic divisions: more than 50 tribes; princi-
pal tribe is Mossi (about 2.5 million); other
important groups are Gurunsi, Senufo, Lobi,
Bobo, Mande, and Fulani
Religion: 65% indigenous beliefs, about 25%
Muslim, 10% Christian (mainly Catholic)
Language: French (official); tribal languages
belong to Sudanic family, spoken by 50% of
the population
Literacy: 7%
Labor force: 90% agriculture; 10% industry,
commerce, services, and government; about
30,000 are wage earners; about 20% of male
labor force migrates annually to neighboring
countries for seasonal employment
Organized labor: four principal trade union
groups represent less than 1% of population
33
Population: 36,919,000 (July 1985), average
annual growth rate 2.0%
Nationality: noun—Burmese; adjective—
Burmese
Ethnic divisions: 72% Burman, 7% Karen,
6% Shan, 6% Indian, 3% Chinese, 2% Kachin,
2% Chin, 2% other
Religion: 85% Buddhist, 15% indigenous be-
liefs, Christian, or other
Language: Burmese; minority ethnic groups
have their own languages
Literacy: 78%
Labor force: 14.19 million (1982/83); 63.6%
agriculture, 12% government, 9.5% trade,
9.4% industry, 5.5% other
: CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Organized labor: Workers’ Asiayone or
“association” (1.56 million members) and
Peasants’ Asiayone (7.83 million members)
integrated into the country’s sole political
party','86f5aefd2c5d2a16280e13052f67a7ee7517e7b22551c1acb56b536db9db81fb','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e25da9e997eb09fb0a25fd0db2c9d8b23dad90c4a8579ca600426c82deb44a5',1985,'BI','Burundi','people-and-society',97,'Population: 4,788,000 (July 1985), average
annual growth rate 2.6%
Nationality: noun—Burundian(s); adjec-
tive—Burundi
Ethnic divisions: Africans—85% Hutu
(Bantu), 14% Tutsi (Hamitic), 1% Twa
(Pygmy); other Africans include around
70,000 refugees, mostly Rwandans and Zair-
ians; non-Africans include about 3,000
Europeans and 2,000 South Asians
Religion: about 67% Christian (62% Roman
Catholic, 5% Protestant), 32% indigenous be-
liefs, about 1% Muslim
Language: Kirundi and French (official);
Swahili (along Lake Tanganyika and in the
Bujumbura area)
Literacy: 25%
Labor force: about 1.9 million (1983); 93%
agriculture, 4% government, 1.5% industry
and commerce, 1.5% services
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Organized labor: sole group is the Union of
Burundi Workers (UTB); by charter, mem-
bership is extended to all Burundi workers
(informally); figures denoting “active
membership” have been unobtainable','f373216094b25440f0b30608591e514d1d036cc4fd564cea98b3cb3348e5558d','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d2689065255ebfc632b3aa7a6f5a71141250fece5fd14bc4d9e6458d455c4ac',1985,'TH','Thailand','people-and-society',102,'Population: 6,249,000 (July 1985), average
annual growth rate 2.1%
Nationality: noun—Cambodian(s); adjec-
tive—Cambodian
Ethnic divisions: 90% Khmer (Cambodian),
5% Chinese, 5% other minorities
Religion: 95% Theravada Buddhism, 5%
other
Language: Khmer (official), French
Literacy: 48%
Population: 52,700,000 (July 1985), average
annual growth rate 1.9%
Nationality: noun—Thai (sing. and pl.); ad-
jective—Thai
Ethnic divisions: 75% Thai, 14% Chinese,
11% other
Religion: 95.5% Buddhist, 4% Muslim, 0.5%
other
Language: Thai; English secondary language
of elite; ethnic and regional dialects
Literacy: 84%
Labor force: 23.4 million (1981 est.); 76% ag-
riculture, 9% industry and commerce, 9%
services, 6% government
Population: 60,492,000 (July 1985), average
annual growth rate 2.4%
Nationality: noun—Vietnamese (sing. and
pl.); adjective—Vietnamese
Ethnic divisions: 85-90% predominantly
Vietnamese; 3% Chinese; ethnic minorities
include Muong, Thai, Meo, Khmer, Man,
Cham; other mountain tribes
Religion: Buddhist, Confucian, Taoist, Ro-
man Catholic, indigenous beliefs, Islamic,
and Protestant
Language: Vietnamese (official), French,
Chinese, English, Khmer, tribal languages
(Mon-Khmer and Malayo-Polynesian)
Literacy: 78%
246
Labor force: approximately 29 million, not
including military','842804066adee1b385440186a357eb9b55b5fc5db77968c4ca24f87be54b7876','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a77cb33f14839c635269ca19dcd18a7244747d3e31e298f7c88421d63a49ac1e',1985,'CM','Cameroon','people-and-society',106,'Population: 9,771,000 (July 1985), average
annual growth rate 2.7%
Nationality: noun—Cameroonian(s); adjec-
tive—-Cameroonian
Ethnic divisions: over 200 tribes of widely
differing background; 31% Cameroon High-
landers, 19% Equatorial Bantu, 11% Kirdi,
10% Fulani, 8% Northwestern Bantu, 7%
Eastern Nigritic, 18% other African, less than
1% non-African
Religion: over one-half indigenous beliefs,
one-third Christian, one-sixth Muslim
Language: English and French (official), 24
major African language groups
Literacy: 65%
Labor force: (1983) 74.4% agriculture, 11.4%
industry and transport, 9.7% other services
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Organised labor: under 45% of wage labor
force','1a07e3e02c81cbbf539fbb8c465e277e097d1d9dee81a0987a97ce6e2ac19ead','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c736f4aa414dce222eb94a9f6be7aa1e7b240218992dee5a6db124ee27ae13d',1985,'CA','Canada','people-and-society',110,'Population: 25,399,000 (July 1985), average
annual growth rate 1.0%
Nationality: noun—Canadian(s); adjec-
tive—Canadian
Ethnic divisions: 45% British Isles origin,
29% French origin, 23% other European,
1.5% indigenous Indian and Eskimo
Religion: 46% Roman Catholic, 18% United
Church, 12% Anglican
Language: English and French official
Literacy: 99%
Labor force: 12.2 million (December 1983);
68% services (837% government, 23% trade
and finance, 8% transportation), 18% manu-
facturing, 6% construction, 4% agriculture,
5% other; 11.9% unemployment (1983 aver-
age); 11.1% unemployment (December 1983)
Organized labor: 33% of labor force
Population: 315,000 (July 1985), average an-
nual growth rate 2.0%
Nationality: noun—Cape Verdea n(s); adjec-
tive—Cape Verdean
Ethnic divisions: about 71% Creole (mu-
latto); 28% African; 1% European
Religion: Catholicism, fused with local su-
perstitions
Language: Portuguese and Crioulo, a blend
of Portuguese and West African words
Literacy: 37%
Labor force: bulk of population engaged in
subsistence agriculture','30d9d762eea6aa709d77bc41e1131046b87c8485ab0506c20634d00e69d8fa64','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23b3fc24208bc4b4873e5a3feb2d051309d1c77ecf23bf66539bbf1193507f37',1985,'CF','Central African Republic','people-and-society',114,'Population: 2,667,000 (July 1985), average
annual growth rate 2.8%
Nationality: noun—Central African(s); ad-
jective—Central African
Ethnic divisions: approximately 80 ethnic
groups, the majority of which have related
ethnic and linguistic characteristics, 34%
Baya, 28% Banda, 10% Sara, 9% Mandjia, 9%
Mboum, 7% M’Baka; 6,500 Europeans, of
whom 3,600 are French
Religion: 25% Protestant, 25% Roman Cath-
olic, 24% indigenous beliefs, 10% Muslim;
animistic beliefs and practices strongly influ-
ence the Christian majority
Language: French (official); Sangho, lingua
franca and national language
Literacy: est. 33%
Labor force: 1,320,000 (1983); 88% agricul-
ture, 4% industry and commerce, 4%
services, 4% government, approximately
64,000 salaried workers
Organized labor: 1% of labor force
CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2','43058df2b79763bf1b9b352ff5dce64e66d20c5ecbf778f2014bf00e5bf6f837','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de273e768262e4e2de1497391910b252863433b09ba09aa61066449467e79a5a',1985,'TD','Chad','people-and-society',118,'Population: 5,246,000 (July 1985), average
annual growth rate 2.5%
Nationality: noun—Chadian(s); adjective—
Chadian
Ethnic divisions: some 200 distinct ethnic
groups, including Muslims (Arabs, Toubou,
Fulani, Kotoko, Hausa, Kanembou,
Baguirmi, Boulala, and Maba) in the north
and center and non-Muslims (Sara, Mayo-
Kebbi, and Chari) in the south; some 150,000
nonindigenous, 3,000 of them French
Religion: 52% Muslim, 43% indigenous be-
liefs, 5% Christian
Language: French official; Chadian Arabic
is lingua franca in north, Sara and Sangho in
south; more than 100 different languages and
dialects are spoken
Literacy: about 20%
Labor force: 85% agriculture (engaged in un-
paid subsistence farming, herding, and
fishing)
Organized labor: about 20% of wage labor
force
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2','5871b4f97052d96e3972619e02a12ee44c0ce96d1bcfd20dd76865a28f7ed30b','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd0f7ed25a85bec62081149204b8086904d8660c0082c9fa8179a63fbcf34fb1',1985,'CL','Chile','people-and-society',122,'Population: 11,882,000 (July 1985), average
annual growth rate 1.5%
Nationality: noun—Chilean(s); adjective—
Chilean
Ethnic divisions: 95% European and Euro-
pean-Indian, 3% Indian, 2% other
Religion: 89% Roman Catholic, 11% Protes-
tant
Language: Spanish
Literacy: 90% (1978)
Labor force: 3.0 million total employment
(1982); 33% industry and commerce; 31% ser-
vices; 9% agriculture, forestry, and fishing;
9% mining; 5% construction
45
Organized labor: 12% of labor force orga-
nized into labor unions (1982)','95d24fe8c7bfb78bb5d11cf403d41efc6046f618dafccff97040f2e37c8e8ef0','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f79a43ce7d91ca5166be7d60363567e72104f2d65e79ce70d392d576c80724c4',1985,'CN','China','people-and-society',126,'Population: 1,041,346,000 (July 1985), aver-
age annual growth rate 0.9%
Nationality: noun—Chinese (sing., pl.); ad-
jective—Chinese
Ethnic divisions: 93.3% Han Chinese; 6.7%
Zhuang, Uygur, Hui, Yi, Tibetan, Miao,
Manchu, Mongol, Buyi, Korean, and numer-
ous lesser nationalities
Religion: officially atheist; most people, even
before 1949, have been pragmatic and eclec-
tic, not seriously religious; most important
elements of religion are Confucianism, Tao-
ism, Buddhism, ancestor worship; about 2-
3% Muslim, 1% Christian
Language: Standard Chinese (Putonghua) or
Mandarin (based on the Beijing dialect); also
Yue (Cantonese), Wu (Shanghainese), Minbei
(Fuzhou), Minnan (Hokkien-Taiwanese),
Xiang, Gan, Hakka dialects, and minority
languages (see ethnic divisions)
Literacy: over 75%
Labor force: est. 447.1 million (December
1983), 74.4% agriculture, 15% industry and
commerce, 10.6% other
Population: 56,808,000 (July 1985), average
annual growth rate 2.3%
Nationality: noun—Filipino(s); adjective—
Philippine
Ethnic divisions: 91.5% Christian Malay, 4%
Muslim Malay, 1.5% Chinese, 3% other
Religion: 83% Roman Catholic, 9% Protes-
tant, 5% Muslim, 3% Buddhist and other
Language: Pilipino (based on Tagalog) and
English (both official)
Literacy: about 88%
185
Labor force: 17.8 million (1982 est); 47% agri-
culture, 20% industry and commerce, 13.5%
services, 10% government, 9.5% other','87d4ce05122d1ac71bdfe1d2762598bcad71c2b221cc0f4629c156f5b9e5a584','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('328caa3ae56ae3965d54107a917d396e5818f69da46a9d74a0c3725d7c0d08d9',1985,'CO','Colombia','people-and-society',130,'Population: 29,506,000 (July 1985), average
annual growth rate 2.1%
Nationality: noun—Colombian(s); adiec-
tive—Colombian
Ethnic divisions: 58% mestizo, 20% Cauca-
sian, 14% mulatto, 4% black, 3% mixed black-
Indian, 1% Indian
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 81%
Labor force: 9 million (1982); 53% services,
26% agriculture, 21% industry (1980); 14%
official] unemployment (1984)
Organized labor: 1,418,321 members (1982)
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2','632b97f43dd5ba89dd4872966dbe7f07e2a9826e3b3e9ab60be6e098d4152cdd','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d4dfedf7cd93e876b7327717673a9a7d54652b30138af982b1b15adc067e139',1985,'KM','Comoros','people-and-society',134,'Population: 469,000 (July 1985), average an-
nual growth rate 2.9%
Nationality: noun—Comoran(s); adjective—
Comoran
Ethnic divisions: Antalote, Cafre, Makoa,
Oimatsaha, Sakalava
Religion: 86% Sunni Muslim, 14% Roman
Catholic
Language: Shaafi Islam (a Swahili dialect),
Malagasy, French
Literacy: 15%
Labor force: 140,000 (1982); 87% agriculture,
3% government; significant unemployment','a9a0aaceaf53f83516079c4efb9779ca25b1e340bd01d624bbaa5c3676c30303','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('980a64a85ce24eadab482983caeebb76a42735148e73e85fb6e487f2d9a359c2',1985,'CG','Congo','people-and-society',138,'Population: 1,798,000 (July 1985), average
annual growth rate 3.0%
Nationality: noun—Congolese (sing., pl.);
adjective—Congolese or Congo
Ethnic divisions: about 15 ethnic groups di-
vided into some 75 tribes, almost all Bantu;
most important ethnic groups are Kongo
(48%) in south, Sangha (20%) and M’Bochi
(12%) in north, Teke (17%) in center; about
8,500 Europeans, mostly French
Religion: 48% animist, 47% Christian, 2%
Muslim
Language: French (official); many African
languages with Lingala and Kikongo most
widely used
Literacy: over 50%
Labor force: about 40% of population eco-
nomically active (1983); 75% agriculture,
25% commerce, industry, government;
79,100 wage earners; 40,000-60,000 unem-
ployed
Organized labor: 20% of total labor force
(1979 est.)','fac9888142e297ed9d4e6a3909adaf26c93e6e50d89bb4ee5580c0cbc974c29f','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a94905199babfa08c0f1a40d76fe295f8ac3c6a64dec2386ef15b7150d60bbb2',1985,'CK','Cook Islands','people-and-society',142,'Population: 17,000 (July 1985), average an-
nual growth rate —0.7%
Nationality: noun—Cook Islander(s); adjec-
tive—Cook Islander
Ethnic divisions: 81.3% Polynesian (full
blood), 7.7% Polynesian and European, 7.7%
Polynesian and other, 2.4% European, 0.9%
other
Religion: Christian, majority of populace
members of Cook Islands Christian Church','33baefbb332c484463abb8b6ca9f9be421ac7032901422591c61d1fa2a6b1b90','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db0b0965b2d89f2107322fcd6366938004ba901a0ecf5f866ebada6a15105e88',1985,'CR','Costa Rica','people-and-society',146,'Population: 2,655,000 (July 1985), average
annual growth rate 2.5%
Nationality: noun—Costa Rican(s); adjec-
tive—Costa Rican '' ;
Ethnic divisions: 96% white (including mes-
tizo), 3% black, 1% Indian
Religion: 95% Roman Catholic
Language: Spanish (official), with Jamaican
dialect of English spoken around Puerto
Limon
Literacy: 93%
Labor force: 891,000 (1982 est.); 40.4% indus-
try and commerce, 32.6% agriculture, 25%
53
government and services, 2% other; 9.5% un-
employment (1984 official); 15% unem-
ployment (1984 unofficial)
Organized labor: about 13.8% of labor force','81ecf88544f6c0a38427c675aa8680e4d911a55a370368b4f092ad63b9fc8e95','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2731f45aa7baf479aa6857cb4a309344b2a80832bf71f25675a24dcb1fa62627',1985,'CU','Cuba','people-and-society',150,'Population: 10,105,000 (July 1985), average
annual growth rate 1.1%
Nationality: noun—Cuban(s); adjective—
Cuban
Ethnic divisions: 51% mulatto, 37% white,
11% black, 1% Chinese
Religion: at least 85% nominally Roman
Catholic before Castro assumed power
Language: Spanish
Literacy: 96%
Labor force: 3.0 million in 1982; 28% ser-
vices, 21% industry, 20% agriculture, 11%
commerce, 9% construction, 7% transporta-
tion and communication, 4% other','f0df6beafe036bde65c82df9262c9d61a017acec5d97a9c7514f6dfc32d37184','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ef0ce9294653ab28849bc2b40a3dfc0043cb3d9665d1f11cd157b2ed5ae4235',1985,'CY','Cyprus','people-and-society',154,'Population: 670,000 (July 1985), average an-
nual growth rate 1.3%
Nationality: noun—Cypriot(s); adjective—
Cypriot
Ethnic divisions: 78% Greek; 18% Turkish;
4% Armenian, Maronite, and other
Religion: 78% Greek Orthodox: 18% Muslim;
4% Maronite, Armenian, Apostolic, and other
Language: Greek, Turkish, English
Literacy: about 89%
Greek Sector labor force: 240,900( 1982); 42%
services, 33% industry, 22% agriculture: 3.1%
unemployed
Population: 15,503,000 (July 1985), average
annual growth rate 0.3%
Nationality: noun—Czechoslovak(s); adjec-
tive—Czechoslovak
Ethnic divisions: 64.3% Czech, 30.5% Slo-
vak, 3.8% Hungarian, 0.4% German, 0.4%
Polish, 0.3% Ukrainian, 0.1% Russian, 0.2%
other (Jewish, Gypsy)
Religion: 77% Roman Catholic, 20% Protes-
tant, 2% Orthodox, 1% other
Language: Czech and Slovak (official), Hun-
garian
Literacy: 99%
Labor force: 7.8 million; 38.1% industry;
12.5% agriculture; 49.4% construction, com-
munications, and other (1982)','f92f0beb51b1117b4794bac701cbdafe4a9c532c26117f16e8d00b18e9b7e8ab','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0d54d86b4658cbce3407b48cf83387c539f0196ac1968b78a6aba7d55d495d7',1985,'DK','Denmark','people-and-society',158,'Population: 5,109,000 (July 1985), average
annual growth rate — 0.1%
Nationality: noun—Dane(s); adjective—
Danish
Ethnic divisions: Scandinavian, Eskimo,
Faroese, German
Religion: 97% Evangelical Lutheran, 2%
other Protestant and Roman Catholic, 1%
other
Language: Danish, Faroese, Greenlandic (an
Eskimo dialect); sma]] German-speaking mi-
nority
Literacy: 99%
Labor force: 2,700,000 (1988 average); 34.1%
social services; 21% manufacturing; 13.8%
commerce; 8.2% agriculture, forestry, and
59
fishing; 7.9% construction; 7.0% banking and
business services; 6.8% transportation; 9.2%
unemployment rate
Organized labor: 65% of labor force','e8867ddc48e4054977c128057e8e6f4b5e921589fba71e90c9f49e78de26e390','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9acf1c9a78596bc161afa364d5c7b35f1bc139267488fe401da3247ef74e6f2',1985,'DJ','Djibouti','people-and-society',162,'Population: 297,000 (July 1985), average an-
nual growth rate 2.6%
Nationality: noun—Djiboutian(s); adjec-
tive—Djiboutian
Ethnic divisions: 60% Somali (Issa); 35%
Afar, 5% French, Arab, Ethiopian, and Ital-
ian
Religion: 94% Muslim, 6% Christian
Language: French (official), Somali and Afar
widely used
Literacy: 20%
Labor force: a small number of semiskilled
laborers at port
Organized labor: some 3,000 railway work-
ers organized','8e6b4baf5b868b6969649b2157a259fadddf0b56ff3f9299f98a5ac8524ff4bb','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83b1f995d356fb73900feef940fcd5954dc4f835362e1dabcd867593f4909b01',1985,'DM','Dominica','people-and-society',166,'Population: 74,000 (July 1985), average an-
nual growth rate —0.2%
Nationality: noun—Dominican(s); adjec-
tive—Dominican
Ethnic divisions: mostly black; some Carib-
Indians
Religion: 80% Roman Catholic; Anglican,
Methodist
Language: English (official); French patois
widely spoken
Literacy: about 95%
Labor force: 23,000; 40% agriculture, 32% in-
dustry and commerce, 28% services; 15-20%
unemployment
Organized labor: 25% of the labor force','781a796f89f037e11be87ea68e767d9e3072b327fc3da7080b5e57150045fd6b','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71e37e970d5190a7ef6645048f8c6b489404f0fdd5da9890aad78f54360dc923',1985,'DO','Dominican Republic','people-and-society',170,'Population: 6,588,000 (July 1985), average
annual growth rate 2.7%
Nationality: noun—Dominican(s); adjec-
tive—Dominican
Ethnic divisions: 73% mixed, 16% white,
11% black
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 68%
Labor force: 1.2 million; 47% agriculture,
23% industry and commerce, 16% govern-
ment, 14% services
Organized labor: 12% of labor force','7072d02a67aad6ab7682e2cc32e8489380128ea755496e62ad3ec8178ebdcc90','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cac1134a464fc8e151116c061a3d33f318bb88e90dfd0568899b4df9f5b0a60',1985,'EC','Ecuador','people-and-society',174,'Population: 8,884,000 (July 1985), average
annual growth rate 2.7%
Nationality: noun—Ecuadorean(s); adjec-
tive—Ecuadorean
Ethnic divisions: 55% mestizo (mixed Indian
and Spanish), 25% Indian, 10% Spanish, 10%
black
Religion: 95% Roman Catholic (majority
nonpracticing)
Language: Spanish (official); Indian dialects,
especially Quechua
Literacy: 84%
64
Labor force: (1983) 2.8 million; 52% agricul-
ture, 13% manufacturing, 7% commerce, 4%
construction, 4% public administration, 16%
other services and activities
Organized labor: less than 15% of labor force','445af949a7e922f13fb4c563fabe200cdcc7634bb21a980ae379298ece2ae221','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0601e9cbdd7526b4c3752514fe4b16d136b9a1ac6d054010dae823f6c260aa4',1985,'EG','Egypt','people-and-society',178,'Population: 48,305,000 (July 1985), average
annual growth rate 2.6%
Nationality: noun—Egyptian(s); adjective—
Egyptian or Arab Republic of Egypt
Ethnic divisions: 90% Eastern Hamitic stock;
10% Greek, Italian, Syro-Lebanese
Religion: (official estimate) 94% Muslim
(mostly Sunni), 6% Coptic Christian and
other
Language: Arabic (official), English and
French widely understood by educated
classes
Literacy: 40%
Labor force: 13.4 million; 45-50% agricul-
ture, 13% industry, 11% trade and finance,
Approved For
Release 2011/02/09 : CIA-RDP86S00596R000200
26% services and other; shortage of skilled la-
bor; unemployment about 7%
Organized labor: 1 to 8 million','2de4f0fe1d44f1e6c10b0026f00e105fb2ce5af763c9eb86fced02a299393c46','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3141071785730861d7a85c41fff91e63a3e969f35b42420676c28c728fe712fb',1985,'SV','El Salvador','people-and-society',183,'Population: 5,072,000 (July 1985), average
annual growth rate 2.8%
Nationality: noun—Salvadoran(s); adjec-
tive—Salvadoran
Ethnic divisions: 89% mestizo, 10% Indian
1% white
Religion: predominantly Roman Catholic
(probably 97-98%), with activity by Protes-
tant groups throughout the country
Language: Spanish, Nahua (among some In-
dians)
Literacy: 65%
Labor force: 1.7 million (est. 1982); 25% agri-
culture, 16% manufacturing, 16%
commerce, 13% government, 9% financial
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
El Salvador (continued)
services, 6% transportation, 15% other (1984
est.): shortage of skilled labor and large pool
of unskilled labor, but manpower training
programs improving situation, significant
unemployment
Organized labor: 8% total labor force; 10%
agricultural labor force; 7% urban labor force
(1982)','4587220ca84728eeddc48a681fcd838a65a297506ead15523f63e949637985ac','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a9517b4a5dd46919d4bc84d9b023058e095cce5251ee20c31f767d31927db8a',1985,'GQ','Equatorial Guinea','people-and-society',187,'Population: 282,000 (July 1985), average an-
nual growth rate 2.5% Rio Muni—212,000
(July 1985), average annual growth rate 2.5%;
Fernando Po—71,000 (July 1985), average
annual growth rate 2.5%
Nationality: noun—Equatorial Guinean(s);
adjective—Equatorial Guinean
Ethnic divisions: indigenous population of
Bioko, primarily Bubi, some Fernandinos; of
Rio Muni, primarily Fang; less than 1,000
Europeans, primarily Spanish
Religion: natives all nominally Christian and
predominantly Roman Catholic; some pagan
practices retained
Language: Spanish (official); pidgin English,
Fang
Literacy: 55%
69
Labor force: most Equatorial Guineans in-
volved in subsistence agriculture; labor
shortages on plantations','3cee9b5c2301700d97f0bb88ba8e832a9d5663e7c5d4e4dbcf0ddc1615233971','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8f5d18fb7fac34c9d8018ac1af71a77bf141578d3c19455b3c20c17f0327ea9',1985,'ET','Ethiopia','people-and-society',192,'Population: 42,289,000 (July 1985), average
annual growth rate 0.7%
Nationality: noun—Ethiopian(s); adjec-
tive—Ethiopian
Ethnic divisions: 40% Oromo, 32% Amhara
and Tigrean, 9% Sidamo, 6% Shankella, 6%
Somali, 4% Afar, 2% Gurage, 1% other
Religion: 40-45% Muslim, 35-40% Ethiopian
Orthodox, 15-20% animist, 5% other
Language: Amharic (official), Tigrinya,
Orominga, Arabic, English (major foreign
language taught in schools)
Literacy: about 15%
70
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Labor force: 90% agriculture and animal hus-
bandry; 10% government, military, and
quasi-government
Organized labor: All Ethiopian Trade Union
formed by the government in January 1977
to represent 273,000 registered trade union
members
Population: 2,000 (July 1985), average an-
nual growth rate 0%
Nationality: noun—Falkland Islander(s); ad-
iective—Falkland Island
Ethnic divisions: almost totally British
Religion: predominantly Anglican
Language: English
Literacy: compulsory education up to age 14
Labor force: 1,100 (est.); est. over 95% in agri-
culture, mostly sheepherding','e4cf56c7845a6ddeac791e0ae40096ff20960fafdd66b0100d6d11abb912b7ed','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b7bd9e9f3dc1df0671f4cfc790146e1d9fa65769b9344220e1b9e5d87150350',1985,'FO','Faroe Islands','people-and-society',196,'Population: 46,000 (July 1985), average an-
nual growth rate 1.0%
Nationality: noun—Faroese (sing., pl.); ad-
jective—Faroese
Ethnic divisions: homogeneous white popu-
lation
Religion: Evangelical Lutheran
Language: Faroese (derived from Old
Norse), Danish
Literacy: 99%
Labor force: 17,585; largely engaged in fish-
ing, manufacturing, transportation, and
commerce','e9bcf5ca6a8e6b86469c32a0c0f0f03e68626e2d01fdb98bd7d6314d7c1795d9','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('305075f6cc427ebd83f681eb8d4da0ee501985bbc951e3e913f6e65ff0cf9da6',1985,'FJ','Fiji','people-and-society',200,'Population: 700,000 (July 1985), average an-
nual growth rate 2.1%
Nationality: noun—Fijian(s); adjective—
Fijian
Ethnic divisions: 50% Indian, 45% Fijian; 5%
European, other Pacific Islanders, overseas
Chinese, and others
Religion: Fijians are mainly Christian, Indi-
ans are Hindu with a Muslim minority
Language: English (official), Fijian, Hindu-
stani spoken among Indians
Literacy: 80%
Labor force: 176,000 (1979); 43.8% agricul-
ture, 15.6% industry
Organized labor: about 50% of labor force
organized into about 60 unions; unions orga-
nized along lines of work and ethnic origin','1ba103c0ccee162d0463d9a69e47842ea15ff39932fc497c67a9aacbd236246e','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b43769f8261acf30d2b6e4fb7ade981d23fb1997fe0cccad8e60ff12d66e677',1985,'FI','Finland','people-and-society',204,'Population: 4,894,000 (July 1985), average
annual growth rate 0.4%
Nationality: noun—Finn(s); adjective—
Finnish
Ethnic divisions: Finn, Swede, Lapp, Gypsy,
Tatar
Religion: 97% Evangelical Lutheran, 1.2%
Greek Orthodox, 1.8% other
Language: 93.5% Finnish, 6.3% Swedish
(both official); small Lapp- and Russian-
speaking minorities
Literacy: almost 100%
Labor force: 2.546 million; 23.8% mining and 3
manufacturing; 25.4% services; 18.5% com-
merce; 11.9% agriculture, forestry, and
75
7
.* ary 1982),
4
Pe
fishing; 7.2% construcfon; 7.0% transporta-
tion and communicatins; 6.1% unemployed
(1983 average) — :
Organized labor: 8G of labor force
xy
Government - i.
Official name: Regblic of Finland
nN
Type: republic
si fe
Capital: Helsinki)
Political subdivions: 12 provinces, 443
communes, 78 tans
‘
‘ i
Legal system: cil law system based on
_ Swedish law; cojtitution adopted 1919; Su-
preme Court mirequest legislation
interpreting or odifying laws; legal educa-
tion at Universis of Helsinki and Turku;
accepts compulry IC] jurisdiction, with
reservations "
National holidi: Independence Day, 6 De-
4
cember OPO ae
Branches: legiitive authority rests jointly
with Presidentnd unicameral legislature
(Eduskunta); efutive power vested in Presi-
dent and exercéd through coalition Cabinet
responsible to rliament; Supreme court,
four superior aytts, a lower courts
We qs
Government Iders: Dr. Mauno
KOIVISTO, Piident (since January 1982);
/Kalevi SORSA''’time Minister (since Febru-
nt .
Suffrage: unitsal, 18 years and over; not
compulsory ;
Elections: piamentary, évery four years
(last in 1983)residential, every six years
Political paes and leaders: Social Demo-
cratic Partyalevi Sorsa; Center Party,
Paavo Vayien; People’s Democratic
League (Canunist front), Kalevi Kivisté;
ConservatiParty, Ilkka Suominen; Liberal
Party, KyéLallukka; Swedish Peoples
Party, Par:nback; Rural Party, Pekka
Vennamo;hnish Communist Party, Arvo
v2,
''
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Finland (contined)
Aalto; Finnish Chrisan League, Esko
Almgren; Constitutiqa] People’s Party,
Georg Ehrnrooth; Lezue for Citizen Power.
Kaarlo Pitsinki
Voting strength: (1985arliamentary elec-
tion) 26% Social Demoaatic, 22.1%
Conservative, 17.6% Ceter-Liberal, 14.0%
People’s Democratic Legue, 9.7% Rural,
4.9% Swedish Peoples, 9% Christian
League, 1.5% Greens, 0% Constitutional
People’s, 0.1% League f Citizen Power
Communists: 28,000 reg:ered members; an
additional 45,000 persondelong to People’s
Democratic League :
Member of: ADB, CEMAspecial coopera-
tion agreement), DAC, E(free trade
agreement), EFTA (associe), FAO, GATT,
IAEA, IBRD, ICAC, ICACCES, ICO, IDA,
[DB—Inter-American Delopment Bank,
IFAD, IFC, THO, ILO, Inrnational Lead
and Zinc Study Group, IM; IMO,
INTERPOL, IPU, ITU, IW—International
Wheat Council, Nordic Caicil, OECD,
UN, UNESCO, UPU, WH: WIPO, WMO,
WSG','e1da782b013e62e46f65aa35d02f5967847cf1e1ba9057b1f3cea4a6e9b0a1cd','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68f4304f74db6f62f8af9ffe12b620b3e840e96ff902480a8dcb1d7366856fee',1985,'FR','France','people-and-society',207,'Population: 55,094,000 (July 1985), average
annual growth rate 0.4%
Nationality: noun—Frenchman (men); ad-
jective—French
Ethnic divisions: Celtic and Latin with Teu-
tonic, Slavic, North African, Indochinese,
and Basque minorities
Religion: 90% Roman Catholic, 2% Protes-
tant, 1% Jewish, 1% Muslim (North African
workers), 6% unaffiliated
Language: French(100% of population); rap-
idly declining regional patois—Provencal,
Breton, Germanic, Corsican, Catalan,
Basque, Flemish
Literacy: 99%
Labor force: 23.4 million (1983); 54.5% ser-
vices, 29.5% industry, 8.5% agriculture; 8.5%
unemployed
Organized labor: approximately 20% of Ia-
bor force','2cf66c6297c5a05fd4618e53f3c4f9de48faae5fa16b97820836af646e3aa8bd','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4dfe5a1485d6139240d62ec2166d42791b77cd50360c0ec0fb4016184ed57b26',1985,'GF','French Guiana','people-and-society',211,'Population: 82,000 (July 1985), average an-
nual growth rate 2.9%
Nationality: noun—French Guianese (sing,
pl.); adjective—French Guiana
Ethnic divisions: 66% black or mulatto; 12%
Caucasian; 12% East Indian, Chinese, Amer-
indian; 10% other
Religion: predominantly Roman Catholic
Language: French
Literacy: 73%
Labor force: 23,265 (1980); services, govern-
ment, and commerce 60.6%; industry 21.2%,
agriculture 18.2%; information on unem-
ployment unavailable
Organized labor: 7% of labor force
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2','28f8604dbde07ab60a5b973d2a75056ec873e101c105f80e46be978337e212f1','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8e854a925cda09e6c663e3c07006fca02a424286b9329ca1dc91d6b9be7ba66',1985,'PF','French Polynesia','people-and-society',215,'Population: 166,000 (July 1985), average an-
nual growth rate 2.3%
Nationality: noun—French Polynesian(s);
. adjective—French Polynesian
Ethnic divisions: 78% Polynesian, 12% Chi-
nese, 6% local French, 4% metropolitan
French
Religion: mainly Christian; 55% Protestant,
32% Catholic','f386ad1a90f5a5bd0af0bff8530ab01563461dd7a379a5c7376965b231add66a','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03ecacd06dc065f7eca5ed49befd39c7a840fb2486f71c82162c89b9c52af400',1985,'GA','Gabon','people-and-society',219,'Population: 988,000 (July 1985), average an-
nual growth rate 3.1%
Nationality: noun—Gabonese (sing., pl.); ad-
jective—Gabonese
Ethnic divisions: about 40 Bantu tribes, in-
cluding 4 major tribal groupings (Fang,
Eshira, Bapounou, Bateke); about 100,000 ex-
patriate Africans and Europeans, including
85,000 French
Religion: 55-75% Christian, less than 1%
Muslim, remainder animist
Language: French (official), Fang, Myene,
Bateke
Literacy: 65%
Labor force: 120,000 salaried (1983); 65% ag-
ticulture, 30% industry and commerce, 2.5%
services, 2.5% government
Organized labor: there are 38,000 members
of the national trade union, the Gabonese
Trade Union Confederation (COSYGA)
Population: 751,000 (July 1985), average an-
nual growth rate 3.5%
Nationality: noun—Gambian(s); adjective—
Gambian
Ethnic divisions: 90% African (37.7%
Mandinka 16.2% Fula, 14% Wolof, 8.5% Jola,
7.8% Serahuli, 5.3% other); 10.5% non-Gam-
bian
Religion: 85% Muslim, 14% Christian, 1% in-
digenous beliefs
‘Language: English (official), Mandinka, Wo-
lof, Fula, other indigenous vernaculars
Literacy: about 15%
Labor force: 378,850 (1980 est.); 75% agricul-
ture; 18.9% industry, commerce, and
services; 6.1% government
82
6S00596R000200790001-2
Organized labor: 25-30% of wage labor force
at most
Population: 16,701,000, including East Ber-
lin July 1985), average annual growth rate
0.0% .
Nationality: noun—German(s), adjective—
German
Ethnic divisions: 99.7% German, 0.3% Slavic
and other
Religion: 47% Protestant, 7% Roman Catho-
lic, 46% unaffiliated or other; less than 5% of
Protestants and about 25% of Roman Catho-
lics active participants
Language: German, small Sorb (West Slavic)
minority
Literacy: 99%
: CIA-RDP86S00596R000200790001-2
German Democratic
Republic (continued)
Labor force: 8.87 million; 37.9% industry,
20.7% services, 10.7% commerce, 10.1% agri-
culture, 7.4% transport and communications,
6.9% construction, 3.1% handicrafts, 3.2%
other (1983)
Organized labor: 87.7% of total labor force
Population: 61,132,000, including West Ber-
lin July 1985), average annual growth
rate — 0.2%
Nationality: noun—German(s); adjective—
German
Ethnic divisions: primarily German; Danish
minority
Religion: 45% Roman Catholic, 44% Protes-
tant, 11% other
Language: German
Literacy: 99%
Labor force: 25.668 million (1982); 33.8%
manufacturing, 29.2% services, 16.8% gov-
ernment, 5.9% construction, 5.4%
agriculture, 1.7% other; 9.2% unemployed
(February 1985)
Organized labor: 37% of total labor force;
46.4% of wage and salary earners (1982)','92faf47e5bc06842e320cb9b2b6383c4013a169a06fae6e06921a5fa94ba3ac3','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82fda9b682dab6ee135d4816cff35fe58b5e8bdfa3a3a257eb61ebf79e57c87e',1985,'GH','Ghana','people-and-society',223,'Population: 13,197,000 (July 1985), average
annual growth rate 3.0%
Nationality: noun—Ghanaian(s), adjec-
tive—Ghanaian
Ethnic divisions: 99.8% black African (major
tribes Akan, Ewe, Ga), 0.2% European and
other
Religion: 42% Christian, 38% indigenous be-
liefs, 12% Muslim, 7% other
Language: English (official); African lan-
guages include 44% Akan, 16% Mole-
Dagbani, 13% Ewe, and 8% Ga-Adangbe
Literacy: 30%
Labor force: 3.7 million; 54.7% agriculture
and fishing; 18.7% industry; 15.2% sales and
clerical; 7.7% services, transportation, and
communications; 3.7% professional; 400,000
unemployed
Organized labor: 467,000 or approximately
13% of labor force','29fce820fe74bf2297d5a49375e0060fe15d63df594f68438dc03e0c8a612f67','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa79c1743e27633a1654432f1aac00460bfc9d150ddbd77c14c2d0840b626d39',1985,'GI','Gibraltar','people-and-society',227,'Population: 31,000 (July 1985), average an-
nual growth rate 0.9%
Nationality: noun—Gibraltarian; adjec-
tive—Gibraltar
Ethnic divisions: mostly Italian, English,
Maltese, Portuguese, and Spanish descent
Religion: 75% Roman Catholic, 8% Church
of England, 2.25% Jewish
Language: English and Spanish are primary
languages; Italian, Portuguese, and Russian
also spoken; English used in the schools and
for all official purposes
Literacy: illiteracy is negligible
Labor force: approx. 14,800, including non-
Gibraltar laborers
Organized labor: over 6,000','8e4cd31d35ed27a9d016a42fb7aca7fa02219502c8b1c81c57cfca3abfcccb46','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb62bfea68d13a89aef0c9d0db267c77cd5e0152efc221d0d32dad529028dde8',1985,'GR','Greece','people-and-society',231,'Population: 9,966,000 (July 1985), average
annual growth rate 0.6%
Nationality: noun—Greek(s); adjective—
Greek
Ethnic divisions: 97.7% Greek, 1.8% Turk-
ish; 1.0% Vlach, Slav, Albanian, Pomach
Note: The Greek Government states that
there are no ethnic minorities in Greece
Religion: 98% Greek Orthodox, 1.3% Mus-
lim, 0.7% other
Language: Greek (official); English and
French widely understood
Literacy: 95%
Labor force: 3.7 million (1981 census); ap-
proximately 39% services, 31% agriculture,
30% industry; urban unemployment is esti-
89
mated at 10%; substantial unreported unem-
ployment exists in agriculture
Organized labor: 10-15% of total labor force,
20-25% of urban labor force
Population: 51,259,000 (July 1985), average
annual growth rate 2.1%
Nationality: noun—Turk(s); adjective—
Turkish
Ethnic divisions: 85% Turkish, 12% Kurd,
3% other
Religion: 98% Muslim (mostly Sunni), 2%
other (mostly Christian and Jewish)
Language: Turkish (official), Kurdish Arabic
Literacy: 70%
Labor force: 18.1 million (1983); 61% agricul-
ture, 27% service, 12% industry and
commerce; surplus of unskilled labor (1982)
Organized labor: 10-15% of labor force
282','43574df1760d0ec5abb9ebfe308cac207dc7635e0d75cc1348b4d311a9bca79f','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3abb7fbdbc4be77ad5c10a7a5e173a0b71c5e348c7c511912471ebfdd6770d2',1985,'GL','Greenland','people-and-society',235,'Population: 54,000 (July 1985), average an-
nual growth rate 1.2%
Nationality: noun—Greenlander(s); adjec-
tive—Greenlandic
Ethnic divisions: 86% Greenlander (Eskimos
and Greenland-born whites), 14% Danish
Religion: Evangelical Lutheran
Language: Danish, Eskimo dialects
Literacy: 99%
Labor force: 21,378; largely engaged in fish-
ing, hunting, and sheep breeding','001ad07019a36f457e6b7bee21d32c3c9b941484eb48a0ffc1f34872f2102835','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2821b2a767b566374117753f82127b68d4d33b7ccb91e053f513313ed931031',1985,'GD','Grenada','people-and-society',239,'Population: 88,000 (July 1985), average an-
nual growth rate —0.4%
Nationality: noun—Grenadian(s); adjec-
tive—Grenadian
Ethnic divisions: mainly of African Negro
descent
Religion: largely Roman Catholic; Anglican;
other Protestant sects
Language: English (official); some French
patois
Literacy: unknown
Labor force: 38,000 (1980 est.); 38% services,
20% agriculture, 11% construction, 4% man-
ufacturing; 27% unemployment
Organized labor: 80% of labor force','a45c309c831422e56deb2af2bf9d8097e3f3da2b2dce029c3f7d016854f06a78','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc1894b07c7e03c4ecc0829cc236ef4ef98e891e6a10d0816db4e14c588a2db2',1985,'GP','Guadeloupe','people-and-society',243,'Population: 333,000 (July 1985), average an-
nual growth rate 0.4%
Nationality: noun—Guadeloupian(s); adiec-
tive—Guadeloupe
Ethnic divisions: 90% black or mulatto; 5%
Caucasian; less than 5% East Indian, Leba-
nese, Chinese
Religion: 95% Roman Catholic, 5% Hindu
and pagan African
Language: French, creole patois
Literacy: over 70%
Labor force: 120,000; services, government,
and commerce 53%; industry 25.8%; agricul-
ture 21.2%; significant unemployment
Organized labor: 11% of labor force
93','86c61187498562bc5413d09297879c3f133de12a4c9173ae869698b550a65b1d','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9485479d1c1a57561cc39bfc16b75a98488d61239ca6737d6fb20270f36d28a9',1985,'HN','Honduras','people-and-society',247,'Population: 8,335,000 (July 1985), average
annual growth rate 3.1%
Nationality: noun—Guatemalan(s); adjec-
tive—Guatemalan
Ethnic divisions: 58.6% Ladino (mestizo and
westernized Indian), 41.4% Indian
Religion: predominantly Roman Catholic;
also Protestant, traditional Mayan
Language: Spanish, but over 40% of the
population speaks an Indian language as a
primary tongue (18 Indian dialects, including
Quiche, Cakchiquel, Kekchi)
Literacy: 50%
Labor force (1984): 2.5 million; 57.0% agri-
culture, 14.0% manufacturing, 13.0%
services, 7.0% commerce, 4.0% construction,
3.0% transport, 0.8% utilities, 0.4% mining;
unemployment 33%
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Organized labor: 10% of labor force (1984)
Population: 4,394 000 (July 1985), average
annual growth rate 3.4%
Nationality: noun—Honduran(s); adjec-
tive—Honduran
Ethnic divisions: 90% mestizo (mixed Indian
and European), 7% Indian, 2% black, 1%
white
Religion: about 97% Roman Catholic; small
Protestant minority
Language: Spanish, Indian dialects
Literacy: 56%
Labor force: 1.2 million (1984); 54% agricul-
ture, 28% services, 18% manufacturing, 4%
construction, 1% other; 30% unemployed;
60% underemployed
Organized labor: 40% of urban labor force,
20% of rural work force (1981)
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
“Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Honduras (continued)','9830d89347dcabab61d5585ce6d6b1c37c86fb75a64da0f55a0ffeaf9ad8bbab','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7eb2a2ec9e8f04e24fa8c0dd75ab9c01d2a4862994aef86760234ef052b0bcb4',1985,'GN','Guinea','people-and-society',251,'Population: 5,734,000 (July 1985), average
annual growth rate 2.7%
Nationality: noun—Guinean(s); adjective—
Guinean
Ethnic divisions: Fulani, Malinke, Sousou, 15
smaller tribes
Religion: 75% Muslim, 24% indigenous be-
liefs, 1% Christian
Language: French (official); each tribe has
own language
Literacy: 20% in French; 48% in local lan-
guages
Labor force: 2.4 million (1983); 82% agricul-
ture, 11% industry and commerce, 5.4%
services, 1.6% government
96
Organized labor: virtually 100% of wage la-
bor force loosely affiliated with the National
Confederation of Guinean Workers
Population: 91,178,000 (July 1985), average
annual growth rate 3.4%
Nationality: noun—Nigerian(s); adjective—
Nigerian
Ethnic divisions: of the more than 250 tribal
groups, the Hausa and Fulani of the north,
the Yoruba of the southwest, and the Ibos of
the southeast comprise 65% of the popula-
tion; about 27,000 non-Africans
Religion: no exact figures on religious break-
down, but last census (1963) showed Nigeria
to be 47% Muslim, 34% Christian, and 18%
indigenous beliefs
Language: English (official), Hausa, Yoruba,
and Ibo also widely used
Literacy: 25-30%
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Nigeria (continued)
Labor force: est. 35-40 million (1983); 55%
agriculture; 17% industry, commerce, and
services; 15% government
Organized labor: 3.52 million wage earners
belong to one of 42 recognized trade unions,
which are under a single national labor fed-
eration, the Nigerian Labor Congress (NLC)
Population: 88,000 (July 1985), average an-
nual growth rate 0.8%
Nationality: noun—Sao Tomean(s); adjec-
tive—Sao Tomean
Ethnic divisions: mestico, angolares (descen-
dents of Angolan slaves), forros (descendents
of freed slaves), servicais (contract laborers
from Angola, Mozambique, and Cape
Verde), tongas (children of servicais born on
the islands), and Europeans (primarily Portu-
guese)
Religion: Roman Catholic, Evangelical Prot-
estant, Seventh Day Adventist
Language: Portuguese (official)
Literacy: est. 50%
Labor force: most of population engaged in
subsistence agriculture and fishing: some un-
employment, but labor shortages on
plantations and for skilled work','aa361d475673d57b6e09aacb435a90c9a7f72c4421f7d8b41057ec2d7bc2dcaf','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('047b9afd109221fb3b8ffdaf4946355f9fcf1810e1d3ecdd72c14d1268894095',1985,'GW','Guinea-Bissau','people-and-society',255,'Population: 858,000 (July 1985), average an-
nual growth rate 1.9%
Nationality: noun—Guinea-Bissauan(s); ad-
jective—Guinea-Bissauan
Ethnic divisions: about 99% African (30%
Balanta, 20% Fula, 14% Manjaca, 13%
Mandinga, 7% Papel); less than 1% European
and mulatto
Religion: 65% indigenous beliefs, 30% Mus-
lim, 5% Christian
Language: Portuguese (official); Criolo and
numerous African languages
Literacy: 9%
Labor force: 90% agriculture; 5% industry,
services, and commerce; 5% government
: CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP8
(continued)','2ab4e076a7439117f68d5f0f2e36fc4b7a1c219beba9f7375825eb153d9d5090','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfe9bf4ad59aa4ee2186fef6434ae09569ad47a4d65d5f60a25e2647b40b6107',1985,'GY','Guyana','people-and-society',259,'Population: 798,000 (July 1985), average an-
nual growth rate 0.4%
Nationality: noun—Guyanese (sing., pl.); ad-
jective—Guyanese
Ethnic divisions:51% East Indian, 43% black
and mixed, 4% Amerindian, 2% European
and Chinese
Religion: 57% Christian, 838% Hindu, 9%
Muslim, 1% other
Language: English, Amerindian dialects
Literacy: 85%
Labor force: 200,000 (1982); 44.5% industry
and commerce, 33.8% agriculture, 21.7% ser-
vices; 64% public sector employment;
approximately 21% unemployed
Organized labor: 34% of labor force','1adfb7ab3951007c495f15aac7d89c462590f36cbfc69281bc2b06dc9cd7ae1f','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ea60ba76ad7584b2954cba7380dc9ccb99af78a99ee02b8f3bd83583df66a30',1985,'HT','Haiti','people-and-society',263,'Population: 5,762,000 (July 1985), average
annual growth rate 1.9%
Nationality: noun—Haitian(s); adjective—
Haitian
Ethnic divisions: 95% black, 5% mulatto and
European
Religion: 75-80% Roman Catholic (of which
an overwhelming majority also practice Voo-
doo), 10% Protestant
Language: French (official) spoken by only
10% of population; all speak Creole
Literacy: 23%
Labor force: 2.3 million (est. 1975); 79% agri-
culture, 14% services, 7% industry;
significant unemployment; shortage of
skilled labor; unskilled labor abundant
100
Organized labor: less than 1% of labor force','b3f4a73ac0068ea880d162ba02d4ef05a00b0f8dcf3428d1825049ba3d885fe3','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('159e2a01685cb530077b12859c4f4331bba9283981da06b1131ab498e92b5288',1985,'HK','Hong Kong','people-and-society',267,'Population: 5,491,000 (July 1985), average
annual growth rate 1.6%
Nationality: adiective—Hong Kong
Ethnic divisions: 98% Chinese, 2% other
Religion: 90% eclectic mixture of local reli-
gions, 10% Christian
Language: Chinese (Cantonese), English
Literacy: 75%
Labor force: (June 1984) 2.52 million; 37.3%
manufacturing; 22.1% commerce; 18.4% ser-
vices; 7.6% construction; 7.6% transport and
communications; 5.4% financing, insurance,
and real estate; 1.2% agriculture, fishing,
mining, and quarrying; 0.4% other; unem-
ployment (seasonally adjusted) 3.6%
Organized labor: 15.2% of 1984 labor force
103','16dc30769b56554dbd3f88e60fca118cf88fd4b8158f36e425d7f54a8c5d2223','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3c09bc8c02e2c14737b1d98a0d99bf3cdd79e8c04721cc408b18b46599e3a55',1985,'HU','Hungary','people-and-society',271,'Population: 10,645,000 (July 1985), average
annual growth rate —0.2%
Nationality: noun—Hungarian(s); adiec-
tive—Hungarian
Ethnic divisions: 92.4% Hungarian, 3.3%
Gypsy, 2.5% German, 0.7% Jewish, 1.1%
other
Religion: 67.5% Roman Catholic, 20.0% Cal-
vinist, 5.0% Lutheran, 7.5% atheist and other
Language: 98.2% Hungarian, 1.8% other
Literacy: 98%
Labor force: 4,970,100 (1983); 32% industry;
22% agriculture; 46% services, trade, govern-
ment, and other','84017544cdd3821ad2a290b4e5860a146a121b57741ef049baf3b6e886486926','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71d70c098b2907acda727565c1a7304e9e7bd15c64ce80cbf24c9c68506d9abd',1985,'IS','Iceland','people-and-society',275,'Population: 241,000 (July 1985), average an-
nual growth rate 1.0%
Nationality: noun—Icelander(s); adjective——
Icelandic
Ethnic divisions: homogeneous mixture of
descendants of Norwegians and Celts
Religion: 95% Evangelical Lutheran, 3%
other Protestant and Roman Catholic, 2% no
affiliation
Language: Icelandic
Literacy: 99.9%
Labor force: 105,000; 18.6% commerce, fi-
nance, and services; 12.2% construction; 9.0%
agriculture; 6.3% transportation and commu-
nications; 5.4% fishing; 8.0% fish processing;
16.8% other manufacturing; 23.7% other;
1.0% unemployment (1983 average)
Organized labor: 60% of labor force','fc46e1cb2b8f2c2ca65857f498125a6a7e778bedcf52db31157a236bc1e5b16f','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a550c756eb147aed2979133f4983d08f8155da6af46fa77a06bc72e823a56a9',1985,'IN','India','people-and-society',279,'Population: 762,507,000, including Sikkim
and the Indian-held part of disputed Jammu
and Kashmir (July 1985); average annual
growth rate 2.1%
Nationality: noun—Indian(s); adjective—
Indian
Ethnic divisions: 72% Indo-Aryan, 25% Dra-
vidian, 3% Mongoloid and other
Religion: 83.5% Hindu, 11% Muslim, 2.6%
Christian, 2.0-2.5% Sikh, 0.7% Buddhist,
0.2% other
107
Language: Hindi, English, and 14 other offi-
cial languages; 24 languages spoken by a
million or more persons each; numerous
other languages and dialects, for the most
part mutually unintelligible; Hindi is the na-
tional language and primary tongue of 30
percent of the people; English enjoys
“associate” status but is the most important
language for national, political, and commer-
cial communication; Hindustani, a popular
variant of Hindi/Urdu, is spoken widely
throughout northern India
Literacy: 36%
Labor force: (1981) about 232 million; 67%
agriculture; more than 10% unemployed and
underemployed
Organized labor: less than 5% of total labor
force','c2c0382d23e924e99bf14cf657439f1ff8c77ad5ebecec4af673251c047d1411','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be4565ac25972d53f7187fca779ea495a48989407a4bef24a3e8bcfe9283255e',1985,'ID','Indonesia','people-and-society',283,'Population: 173,103,000, including East Ti-
mor and West Irian (July 1985), average
annual growth rate 2.1%
_ Nationality: noun—Indonesian(s); adjec-
tive—Indonesian
Ethnic divisions: majority of Malay stock
comprising 45% Javanese, 14% Sundanese,
7.5% Madurese, 7.5% coastal Malays, 26%
other
Religion: 88% Muslim, 6% Protestant, 3% Ro-
man Catholic, 2% Hindu, 1% other
Language: Indonesian (modified form of
Malay; official); English and Dutch leading
foreign languages; local dialects, the most
widely spoken of which is Javanese
Literacy: 64%
Labor force: 61 million (1982); 66% agricul-
ture, 23% trade and commerce, 10% services
Organized labor: est. 5% of labor force
Population: 45,191,000 (July 1985, average
annual growth rate 3.1%; figures do not take
into account the impact of the Iran-Iraq war
Nationality: noun—Iranian(s); adjective—
Iranian
Ethnic divisions: 63% ethnic Persian, 18%
Turkic, 13% other Iranian, 3% Kurdish, 3%
Arab and other Semitic, 1% other
Religion: 93% Shi''a Muslim: 5% Sunni Mus-
lim; 2% Zoroastrian, Jewish, Christian, and
Baha''i
Language: Farsi, Turki, Kurdish, Arabic,
English, French
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Literacy: 48%
Labor force: 12.0 million, est. (1979); 33% ag-
riculture, 21% manufacturing; shortage of
skilled labor; unemployment may be as high
as 35%','9a560b66d2274b72ab1d89bd9ccd73493fd8eb6fc6bb3194ff2f1cb44c61f267','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19d503aa7edcdfaa25569edf95f8670a83c0839f426a439c4ff9378f2fedfca0',1985,'IQ','Iraq','people-and-society',287,'Population: 15,507,000 July 1985), average
annual growth rate 3.3%; figures do not take
into account the impact of the Iran-Iraq war
Nationality: noun—lIraqi(s); adjective—
Iraqi
Ethnic divisions:75% Arab, 15-20% Kurdish,
10% Turkic, Assyrian, and other
Religion: 90% Muslim (55% Shia, 40%
Sunni), 10% Christian or other
Language: Arabic (official), Kurdish (official
in Kurdish regions); Assyrian, Armenian
Literacy: about 50%
Labor force: 3.1 million (1977); 80% agricul-
ture, 27% industry, 21% government, 22%
other; severe labor shortage due to war; ex-
patriate labor force est. at 900,000
Organized labor: 11% of labor force','7151900604ace4b65ec89acbda5010706be94a1032602ec915b1909f4999d8bf','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb52c84b5668cc353c16c4cb3337e642a2fa149852cbcf4763d1ababc1fc826a',1985,'IE','Ireland','people-and-society',291,'Population: 3,590,000 (July 1985), average
annual growth rate 1.0%
Nationality: noun—Irishman(men), Irish
(collective pl.); adjective—Irish
Ethnic divisions: Celtic, with English minor-
ity
Religion: 94% Roman Catholic, 4% Anglican,
2% other
Language: Irish (Gaelic) and English (offi-
cial); English is generally spoken .
Literacy: 99%
Labor force: about 1,173,000 (1981); 19.6%
manufacturing; 17.8% agriculture, forestry,
fishing; 16.2% commerce; 8.3% construction;
5.8% government; 5.5% transportation,
26.8% other; 10.9% unemployment (average
1981)
113
Organized labor: 36% of labor force','546f25705b6e5e9f3bfa77a798ec704bf14df625eda1af34be659033ae43276b','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8ccbea87f48fe3e0907c0f0082f738a0e3939ca974e55232ec7f3f53b38d307',1985,'IL','Israel','people-and-society',295,'Population: 4,085,000, excluding West
Bank, Gaza Strip, and East Jerusalem (J uly
1985), average annual growth rate 1.6%
Nationality: noun—Israeli(s); adjective—
Israeli
Ethnic divisions: 85% Jewish, 15% non-Jew-
ish (mostly Arab)
Religion: 85% Judaism, 11% Islam, 4% Chris-
tian and other
Language: Hebrew official; Arabic used offi-
cially for Arab minority; English most
commonly used foreign language
Literacy: 88% Jews, 70% Arabs
Labor force: est. 1,400,000 (1984); 29.5%
public services; 22.8% industry, mining, and
manufacturing; 12.8% commerce; 9.5% fi-
nance and business; 6.8% transport, storage,
and communications; 6.5% construction and
public works; 5.5% agriculture, forestry, and
fishing; 5.8% personal and other services;
1.0% electricity and water (1983); unemploy-
ment about 6% (1984 est.)
Organized labor: 90% of labor force','b493ce0d13762ba0bdda71f6eae485a2de76fcb4b7de354a5b83e788ba9476cc','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5a1de13a6e44ff1a3d942c491fa1c79b4656698329f933f1f7c4c04bf84ab53',1985,'IT','Italy','people-and-society',299,'Population: 57,149,000 (July 1985), average
annual growth rate 0.3%
Nationality: noun—Italian(s); adjective—
Italian
Ethnic divisions: primarily Italian but popu-
lation includes small clusters of German-,
French-, and Slovene-Italians in the north
and of Albanian-lItalians in the south
Religion: almost 100% nominally Roman
Catholic
Language: Italian; parts of Trentino-Alto
Adige region (for example, Bolzano) are pre-
dominantly German speaking; significant
French-speaking minority in Valle d''Aosta
region; Slovene-speaking minority in the
Trieste-Gorizia area
Literacy: 93%
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Labor force: 23,272,000 (October 1984);
29.9% industry, 10.6% agriculture, 49.3% ser-
vices (October 1984); 10.2% unemployment
(October 1984)
Organized labor: 50-55% (est.) of labor force
Population: 10,056,000 (July 1985), average
annual growth rate 4.0%
Nationality: noun—Ivorian(s); adjective
Ivorian
Ethnic divisions: 7 major indigenous ethnic
groups; no single tribe more than 20% of
population; most important are Agni, Baoule,
Krou, Senoufou, Mandingo; approximately 2
million foreign Africans, mostly Burkinabe;
about 70,000 to 75,000 non-Africans (40,000
French and 25,000 to 30,000 Lebanese)
Religion: 63% indigenous, 25% Muslim, 12%
Christian
Language: French (official), over 60 native
dialects; Dioula most widely spoken
Literacy: 24%
118
11/02/09 : CIA-RDP86S00596R000200790001-2
Labor force: over 85% of population engaged
in agriculture, forestry, livestock raising;
about 11% of labor force are wage earners,
nearly half in agriculture, remainder in gov-
ernment, industry, commerce, and
professions
Organized labor: 20% of wage labor force','5f4f53fc15127b501a821a2a4de4fd9ff21e2b62a0989fb754c925522cc57195','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba681d2af4ba724ecb12c2ee3336eb1fc37ee7314c8b0ec1e89ab0facf89a15c',1985,'JM','Jamaica','people-and-society',303,'Population: 2,428,000 (July 1985), average
annual growth rate 1.6%
Nationality: noun—Jamaican(s); adiective—
Jamaican
Ethnic divisions: 76.3% African, 15.1% Afro-
European, 3.4% East Indian and Afro-East
Indian, 3.2% white, 1.2% Chinese and Afro-
Chinese, 0.9% other
Religion: predominantly Protestant (includ-
ing Anglican and Baptist), some Roman
Catholic, some spiritualist cults
Language: English, Creole
Literacy: 76%
Labor force: 703,000 (1980); 36.4% agricul-
ture, 32.7% services, 16% government, 14.9%
industry and commerce; shortage of tech-
nical and managerial personnel; significant
unemployment
Organized labor: about $3% of labor force
(1980)
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
‘gered For Release 201 1/02/09 : CIA- RDP86S00596R000200790001 -2
Jamaica (continued)','3b2c3bfd948b3ddacc8ecdf3ff0f08fa18d127c3a7c5dd8e926c08ce89d088f4','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('797aed7c8ecb13af2df25723841b49deabe1c9d29ed9176cfe5b0ec2d663e6ed',1985,'JP','Japan','people-and-society',307,'Population: 120,691,000 (July 1985), average
annual growth rate 0.6%
Nationality: noun—Japanese (sing., pl.); ad-
jective—Japanese
Ethnic divisions: 99.4% Japanese, 0.6% other
(mostly Korean)
Religion: most Japanese observe both Shinto
and Buddhist rites; about 16% belong to other
faiths, including 0.8% Christian
Language: Japanese
Literacy: 99%
Labor force: (1983) 58.9 million; 52% trade
and services; 35% manufacturing, mining,
and construction; 10% agriculture, forestry,
and fishing; 3% government; 2.7% unem-
ployed
Organized labor: about 30% of labor force
Population: 42,643,000 July 1985), average
annual growth rate 1.5%
Nationality: noun—Korean(s); adjective—
Korean
Ethnic divisions: homogeneous: small Chi-
nese minority (approx. 20,000)
Religion: strong Confucian tradition; perva-
sive folk religion (Shamanism); Buddhism
(including estimated 20,000 members of Soka
Gakkai); Chondokyo (religion of the heav-
enly way), eclectic religion with nationalist
overtones founded in 19th century, claims
about 1.5 million adherents
Language: Korean; English widely taught in
high school
Literacy: over 90%
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
"Approved For Release 2011/02/09 :
Korea, South (continued)
Labor force: 15.1 million (1983); 47% services
and other; 30% agriculture, fishing, forestry;
21% mining and manufacturing; average un-
employment 4.1% (1983)
Organized labor: about 10% of nonagricul-
tural labor force','d603da5ad37d0a04a0844c2874c6a2bc082f00f66f21ff2a7784aad70a57eda6','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dfc51cff11bd769ba08145d6a27b73c2e0158115d1abf891c22f7dd201849196',1985,'JO','Jordan','people-and-society',311,'Population: 2,794,000, excluding West Bank
and East Jerusalem (July 1985), average an-
nual growth rate 3.8%
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Nationality: noun—Jordanian(s), adjec-
tive—Jordanian
Ethnic divisions: 98% Arab, 1% Circassian,
1% Armenian
Religion: 90-92% Sunni Muslim, 8-10%
Christian
Language: Arabic official, English widely
understood among upper and middle classes
Literacy: about 70%
Labor force: 463,000
Organized labor: about 10% of labor force','559e974b36dabb1958c4d77aa97776b66a571051da4e68c07a988c40123d4c78','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a911f3a7d8cea674510af9b7d03ab27986f1b12d62ddc229da406c066ff8a9ff',1985,'KE','Kenya','people-and-society',315,'Population: 20,194,000 (July 1985), average
annual growth rate 4.2%
Nationality: noun—Kenyan(s); adjective—
Kenyan
Ethnic divisions: 21% Kikuyu, 14% Luhya,
13% Luo, 11% Kalenjin, 11% Kamba, 6%
Kisii, 5% Meru, 1% Asian, European, and
Arab
Religion: 38% Protestant, 28% Catholic, 26%
indigenous beliefs, 6% Muslim
Language: English and Swahili (official); nu-
merous indigenous languages
Literacy: 47%
Labor force: 5.4 million; about 1.1 million
wage earners; 47% public sector, 18% indus-
try and commerce, 17% agriculture, 13%
services
Organized labor: about 390,000
Population: 44,000 (July 1985), average an-
nual growth rate —0.3%
Ethnic divisions: mainly of African Negro
descent
Nationality: noun—Kittsian(s), Nevisian(s);
adjective—Kittsian, Nevisian
Religion: Anglican, other Protestant sects,
Roman Catholic
Language: English
Literacy: 80%
Labor force: 20,000 (1981)
Organized labor: 6,700
Population: 122,000 (July 1985), average an-
nual growth rate 1.1%
Nationality: noun—St. Lucian(s); adiec-
tive—St. Lucian
Ethnic divisions: 90.3% African descent,
5.5% mixed, 3.2% East Indian, 0.8% Cauca-
sian
Religion: 90% Roman Catholic, 7% Protes-
tant, 3% Church of England
Language: English (official), French patois
Literacy: 78%
Labor force: 45,000 (1979); 43.4% agricul-
ture, 38.9% services, 17.7% industry and
commerce; 13% unemployment (1979)
Organized labor: 20% of labor force
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
St. Lucia (continued)
Population: 102,000 (July 1985), average an-
nual growth rate 1.4%
Nationality: noun—St. Vincentian(s) or Vin-
centian(s); adjectives—St. Vincentian or
Vincentian
Ethnic divisions: mainly of African Negro
descent; remainder mixed, with some white,
East Indian, Carib Indian
Religion: Anglican, Methodist, Roman Cath-
olic
Language: English, some French patois
Literacy: 82%
Labor force: 61,000(1979 est.); about 20% un-
employed (1978)
Organized labor: 10% of labor force
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2','678f9c04021b2313ac1188709618b0f1944b9dd7bd1c277d45e26edf99162634','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c006b63c6d9373d77f626a0cb8ec8ab32eee84743ecf3007f2d197e4240d2432',1985,'KI','Kiribati','people-and-society',319,'Population: 62,000 (July 1985), average an-
nual growth rate 1.6%
Nationality: noun—Kiribatian(s), adjec-
tive—Kiribati
Ethnic divisions: Micronesian
Religion: Roman Catholic, Protestant
Language: English (official), Gilbertese
Literacy: 90%
Labor force: 15,921 (1973): general unem-
ployment rate 4.9%
Population: 20,082,000 (July 1985), average
annual growth rate 2.3%
Nationality: noun—Korean(s); adjective—
Korean
Ethnic divisions: racially homogeneous
Religion: Buddhism and Confucianism; reli-
gious activities now almost nonexistent
Language: Korean
Literacy: 95% est.
Labor force: 6.1 million (1980); 48% agricul-
tural, 52% nonagricultural; shortage of
skilled and unskilled labor','e2d46ce0ea6a738f2fb6bde2cc55bd6f68908ee247a25ff44716dd206c8c0882','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ef26bd57d5b5c3e77966621aa04ebd2a0e2dadd6218ba81aaecee1392530d0f',1985,'KW','Kuwait','people-and-society',323,'Population: 1,870,000 (July 1985), average
annual growth rate 6.2%
Nationality: noun—Kuwaiti(s), adjective—
Kuwaiti
Ethnic divisions: 39% Kuwaiti, 39% other
Arab, 9% South Asian, 4% Iranian, 9% other
Religion: 95% Muslim, 5% Christian, Hindu,
Parsi, and other
‘Language: Arabic (official), English widely
spoken
Literacy: about 71%
Labor force: 630,000 (1983 est.); 74% ser-
vices, 11% industry, 11% construction; 70% of
labor force is non-Kuwaiti
Organized labor: labor unions, first autho-
rized in 1964, formed in oil industry and
among government personnel
129
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Population: 3,805,000 (July 1985), average
annual growth rate 2.2%
Nationality: noun—Lao (sing., Lao or Lao-
tian); adjective—Lao or Laotian
Ethnic divisions: 48% Lao; 25% Phoutheung
(Kha); 14% Tribal Tai; 13% Meo, Yao, and
other
Religion: 50% Buddhist, 50% animist and
other
Language: Lao (official), French, and En-
glish
Literacy: 28%
Labor force: about 1-1.5 million; 80-90% ag-
riculture
Organized labor: only labor organization is
subordinate to the Communist Party
Population: 2,619,000 (July 1985), average
annual growth rate 0.7%
Nationality: noun—Lebanese (sing., pl.); ad-
jective—Lebanese
Ethnic divisions: 93% Arab, 6% Armenian,
1% other
Religion: 57% Muslim (Sunni and Sh‘ia) and
Druze, 42% Christian (Maronite, Greek Or-
thodox and Catholic, Roman Catholic,
Protestant), 1% other (official estimates);
Muslims, in fact, constitute a majority
Language: Arabic (official); French is widely
spoken; Armenian, English
Literacy: 75%
Labor force: 650,000 (1981); 75% industry,
commerce, and services, 17% agriculture, 8%
goverment; high unemployment
Organized labor: about 65,000','6d5739ac102cfcd3ab3fed774420cc9f5e6df4a892b3b27b6259995dad7e4b43','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce5e231d4d17fe2c98abc13681499c3cd7c5bfa7f9b5d58163b7c7e10026f70c',1985,'LS','Lesotho','people-and-society',327,'Population: 1,512,000 (July 1985), average
annual growth rate 2.5%
Nationality: noun—Mosotho (sing.), Basotho
(pl.); adjective—Basotho
Ethnic divisions: 99.7% Sotho; 1,600 Europe-
ans, 800 Asians
Religion: 80% Christian, rest indigenous be-
liefs
Language: Sesotho (southern Sotho) and En-
glish (official); also Zulu and Xhosa
Literacy: 55%
Labor force: 426,000 economically active
(1976); 87.4% of resident population engaged
in subsistence agriculture; 150,000-250,000
spend from six months to many years as wage
earners in South Africa
Organized labor: negligible','42eed7534468a9052c1d1f09435ecc29835d21d16c6de84090255d4f915a59b4','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a3a18001b3d9467c81351bac24eab8d028ade6deeb4f629465fcefb96748fd5',1985,'LR','Liberia','people-and-society',332,'Population: 2,232,000 (July 1985), average
annual growth rate 3.3%
Nationality: noun—Liberian(s); adjective—
Liberian
Ethnic divisions: 95% indigenous African
tribes, including Kpelle, Bassa, Gio, Kru,
Grebo, Mano, Krahn, Gola, Ghandi, Loma,
Kissi, Vai, and Bella; 5% descendants of repa-
triated slaves known as Americo-Liberians
Religion: 75% traditional, 15% Muslim, 10%
Christian
Language: English (official); more than 20 lo-
cal languages of the Niger-Congo language
group; English used by about 20%
Literacy: 24%
t
Labor force: 510,000, of which 160,000 are in
monetary economy; non-African foreigners
hold about 95% of the top-level management
and engineering jobs; 70.5% agriculture,
10.8% services, 4.5% industry and commerce,
14.2% other
Organized labor: 2% of labor force','116c7fe080ddf60634d65eb0658bbf3e18e521fc594bb76210fb2a48f6e8ffd9','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76d44f32257ca40b783fd2f9ded5ee70cb53a8e5d00e49493b310683bfd0cfee',1985,'LY','Libya','people-and-society',335,'Population: 4,003,000 (July 1985), average
annual growth rate 6.5%
Nationality: noun—Libyan(s); adjective—
Libyan
Ethnic divisions: 97% Berber and Arab with
some black stock; some Greeks, Maltese,
Jews, Italians, Egyptians, Pakistanis, Turks,
Indians, and Tunisians
Religion: 97% Sunni Muslim
Language: Arabic; Italian and English
widely understood in major cities
Literacy: 50%
Labor force: 1.5 million, of which about
550,000 are resident foreigners
136','b40827f369ea80b7efcc0a1a0e87aff12d9a69b7b6e25586d9d2d32b35fada74','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7308695328547a2ef72612e86afff9653e4a7d5a9cd51fac99f47d4996f2916c',1985,'LU','Luxembourg','people-and-society',342,'Population: 367,000 (July 1985), average an-
nual growth rate 0.1%
Nationality: noun—Luxembourger(s); adjec-
tive—Luxembourg
Ethnic divisions: Celtic base, with French
and German blend; also guest and worker res-
idents from Portugal, Italy, and European
countries
Religion: 97% Roman Catholic, 3% Protes-
tant and Jewish
Language: Luxembourgish, German,
French; most educated Luxembourgers also
speak English
Literacy: 100%
Labor force: (1981) 161,700, one-third of
labor force is foreign, comprising mostly
workers from Portugal, Italy, France, Bel-
gium, and FRG (1981); unemployment 1.0%
(1981 average); 45% services, 42% industry
and commerce, 12% government, 0.5% agri-
culture
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Population: 393,000 (July 1985), average an-
nual growth rate 3.4%
Nationality: noun—Macanese (sing. and pl.);
adjective—Macau
Ethnic divisions: 98% Chinese, 2% Portu-
guese
Religion: mainly Buddhist; 17,000 Catholics,
of whom about half are Chinese
Language: 98% Chinese, 2% Portuguese
Literacy: almost 100% among Portuguese
and Macanese; no data on Chinese popula-
tion xt','2bcad90094380e2161183284d8057a61f741534919af102e6ab594284c63c915','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('438b8c0cf5c0384bbb5075792a95e20ed7fa1a8985b3ea390002def5b652d790',1985,'MG','Madagascar','people-and-society',346,'Population: 9,941,000 (July 1985), average
annual growth rate 2.8%
Nationality: noun—Malagasy (sing. and pl.);
adjective—Malagasy
Ethnic divisions: basic split between high-
landers of predominantly Malayo-
Indonesian origin, consisting of Merina
(1,643,000) and related Betsileo (760,000) on
the one hand and coastal tribes—collectively
termed the Cétiers—with mixed Negroid,
Malayo-Indonesian, and Arab ancestry on
the other; coastal tribes include
Betsimisaraka 941,000, Tsimihety 442,000,
Antaisaka 415,000, Sakalava 375,000; there
are also 10,000-12,000 European French,
5,000 Indians of French nationality, and
5,000 Creoles
Religion: more than half indigenous beliefs;
about 41% Christian, 7% Muslim
Language: French and Malagasy official
141
Literacy: 53%
Labor force: about 3.4 million, of which 90%
are nonsalaried family workers engaged in
subsistence agriculture; of 175,000 wage and
salary earners, 26% agriculture, 17% domes-
tic service, 15% industry, 14% commerce,
11% construction, 9% services, 6% transpor-
tation, 2% miscellaneous
Organized labor: 4% of labor force','5de1845686782c845bca4152b680816076755804e69f129d2c2a503d8a80eaca','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cd237c55307c72fca30c6985f6906c866621ca7b3975c06f18c3296aecd7adf',1985,'MW','Malawi','people-and-society',350,'Population: 7,056,000 (July 1985), average
annual growth rate 3.3%
Nationality: noun—Malawian(s); adjec-
tive—Malawian
Ethnic divisions: Chewa, Nyanja, Tumbuko,
Yao, Lomwe, Sena, Tonga, Ngoni, Asian, Eu-
ropean
Religion: 55% Protestant, 20% Roman Cath-
olic, 20% Muslim; traditional indigenous
beliefs are also practiced by some members
of these groups
Language: English and Chichewa (official),
Tombuka is second African language
Literacy: 25%
Labor force: 344,052 wage earners employed
in Malawi (1982); 52% agriculture, 16% per-
sonal services, 9% manufacturing, 7%
construction, 6% commerce, 4% miscella-
neous services, 5% other permanently
employed
Organized labor: small minority of wage
earners are unionized','425c238ae26b5fd99777df404b5cc7c383fdf7823f6fa562d903930eb8aa744e','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7004a138c35b89265671a08cae272bb8db6241974a89f39d88687b623e5c134',1985,'MY','Malaysia','people-and-society',354,'Population: 15,664,000 (July 1985), average
annual growth rate 2.2%
Peninsular Malaysia: 12,854,000 (July 1985),
average annual growth rate 2.0%
144
Sabah: 1,279,000 (July 1985), average annual
growth rate 3.9%
Sarawak: 1,532,000 (July 1985), average an-
nual growth rate 2.4%
Nationality: noun—Malaysian(s); adjec-
tive—Malaysian
Ethnic divisions: 50% Malay, 36% Chinese,
10% Indian, 4% other
Religion:
Peninsular Malaysia: Malays nearly all Mus-
lim, Chinese predominantly Buddhists,
Indians predominantly Hindu
Sabah: 38% Muslim, 17% Christian, 45%
other
Sarawak: 35% tribal religion, 24% Buddhist
and Confucianist, 16% Christian, 2% other
Language:
Peninsular Malaysia: Malay (official); En-
glish, Chinese dialects, Tamil
Sabah: English, Malay, numerous tribal dia-
lects, Mandarin and Hakka dialects
predominate among Chinese
Sarawak: English, Malay, Mandarin, numer-
ous tribal languages
Literacy:
Peninsular Malaysia: 75%
Sabah: 58%
Sarawak: 55%
Labor force:
Malaysia: 5.58 million (1983), 37% agricul-
ture, forestry, livestock, and fishing; 39%
trade, transport, and services; 22% manufac-
turing and construction
Organized labor: 612,000 (November 1983),
about 11% of total labor force; unemploy-
ment about 6.0% of total labor force (1983),
but higher in urban areas','3d8cf0b59c911f2ad1f4818bb732390a5004779b254320a87c2ce2ba638fb980','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('029a8ce3fb289c9e1acad9e2a4c4f3d0293e1638901650659dfc3ebd4924d586',1985,'MV','Maldives','people-and-society',358,'Population: 178,000 (July 1985), average an-
nual growth rate 3.0%
Nationality: noun—Maldivian(s); adjec-
tive—Maldivian
Ethnic divisions: admixtures of Sinhalese,
Dravidian, Arab, and black
Religion: Sunni Muslim
Language: Divehi (dialect of Sinhala, script
derived from Arabic); English spoken by
most government officials
Literacy: 36%
Labor force: total employment is approxi-
mately 66,000; fishing industry employs 80%
of the labor force','1e0f4cf1b5d3cfc391447c4c77616365afd2f9d3d0930c3ec50db4aabf11f1e2','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e53b010f7cc07eda51edda07531154ef4d552a7fc41cbbf0a355835b2cb45d3',1985,'ML','Mali','people-and-society',362,'Population: 7,735,000 (July 1985), average
annual growth rate 2.3%
Nationality: noun—Malian(s); adjective—
Malian
Ethnic divisions: 50% Mande (Bambara, Ma-
linke, Sarakole), 17% Peul, 12% Voltaic, 6%
Songhai, 5% Tuareg and Moor .
Religion: 90% Muslim, 9% indigenous be-
liefs, 1% Christian
Language: French (official); Bambara spo-
ken by about 80% of the population
Literacy: 10%
Labor force: 3.1 million (1981); 80% agricul-
ture, 19% services, 1% industry and
commerce :
Organized labor: National Union of Malian
Workers (UNTM) is umbrella organization
over 13 national unions','21b793bb9277a1d14f32aea832aa8555af648cfea207beee9fd99342910f9170','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21b0cff5dfe6579acc740a1e6a408ea7a94571d9529757a35f0f24b28e1cdb80',1985,'MQ','Martinique','people-and-society',369,'Population: 327,000 (July 1985), average an-
nual growth rate 0.1%
Nationality: noun—Martiniquais (sing. and
pl.); adjective—Martiniquais
Ethnic divisions: 90% African and African-
Caucasian-Indian mixture, 5% Caucasian,
less than 5% East Indian, Lebanese, Chinese
Religion: 95% Roman Catholic, 5% Hindu
and pagan African
Language: French, Creole patois
Literacy: over 70%
Labor force: 100,000; 31.7% service industry,
29.4% construction-and public works, 13.1%
agriculture, 7.3% industry, 2.2% fisheries,
16.3% other; 14% unemployed
Organized labor: 11% of labor force
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2','4adf1b18e800a589cf382982f29fa2b053d4c3872d1ddfda1b90c8ae65b5481d','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('945862d4d3327aefd99b8c7d6545333dab95ba5499e792f24d851686abcfea66',1985,'MR','Mauritania','people-and-society',373,'Population: 1,656,000 (July 1985), average
annual growth rate 2.0%
Nationality: noun—Mauritanian(s); adjec-
tive—Mauritanian
Ethnic divisions: 40% mixed Moor/black;
30% Moor, 30% black
Religion: nearly 100% Muslim
Language: Hasanya Arabic (national);
French (official); Toucouleur, F ula, Sarakole,
Wolof
Literacy: 17%
Labor force: total labor force 465,000 (1981
est.); about 45,000 wage earners (1980 IMF); —
47% agriculture, 29% services, 14% industry
and commerce, 10% government; consider-
able unemployment
Organized labor: 30,000 members claimed
by single union, Mauritanian Workers’
Union','8e4139f41ceecea3f7d912ee34f1c7563d2c8c1bbf5ed30d9295bfbde42bcf4f','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58c14ab8839511d3f345a88c8e1950961d2c7c15bad23d21d1f339eb64975758',1985,'MU','Mauritius','people-and-society',377,'Population: 1,011,000 July 1985), average
annual growth rate 0.9%
Nationality: noun—Mauritian(s); adjec-
tive—Mauritian
Ethnic divisions: 68% Indo-Mauritian, 27%
Creole, 3% Sino-Mauritian, 2% Franco-Mau-
ritian
Religion: 51% Hindu, 30% Christian (mostly
Roman Catholic with a few Anglicans), 17%
Muslim
'' Language: Creole, French, English, Hindi,
Urdu, Hakka, Bojpoeri
Literacy: 61%
Labor force: 335,000; 29% agriculture and
fishing, 28% government services, 23%
153
industry and commerce, 20% other; 14% are
unemployed
Organized labor: about 35% of labor force,
forming over 270 unions','fdec967d7662aaebb069bffedcef5bc1fa665a7fff5ffa5b87f3e445e9436327','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b480d858da4733d646379555e01e40df4f5a386adb2adbddd6593340662521f',1985,'MX','Mexico','people-and-society',381,'Population: 79,662,000 (July 1985), average
annual growth rate 2.5%
Nationality: noun—Mexican(s); adjective—
Mexican
Ethnic divisions: 60% mestizo (Indian-Span-
ish), 30% Amerindian or predominantly
Amerindian, 9% white or predominantly
white, 1% other
Religion: 97% nominally Roman Catholic,
3% Protestant
Language: Spanish
Literacy: 74%
Labor force: 21,500,000 (1982); 31.4% ser-
vices; 26% agriculture, forestry, hunting,
fishing; 18.9% commerce; 12.8% manufac-
turing; 9.5% construction; 4.8%
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
transportation; 1.3% mining and quarrying;
0.3% electricity; 10% unemployed, 40% un-
deremployed
Organized labor: 20% of total labor force','e3fae72c2917816c30074d30e4c5f6ae4a18c5ba9263572d55a210c38102cff3','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a772dff83a9bfed13af1064cdb15aef2a6decbb21a798f1d795b112623472d1c',1985,'MC','Monaco','people-and-society',385,'Population: 28,000 (July 1985), average an-
nual growth rate 1.2%
Nationality: noun—Monacan(s) or Mone-
gasque(s); adjective—Monacan or
Monegasque
Ethnic divisions: 58% French, 19% Mone-
gasque, 17% Italian, 6% unspecified
Religion: 95% Roman Catholicism
Language: French (official), English, Italian
Monegarque
’
Literacy: 99%','c0be82492e878822512ea825d3f7d814a524b4d59214d969c999fb04ed68c49a','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db7c5e8b4acb4f623a20acb483a8151bb2367106e5cd82969ab79b0578019b08',1985,'MN','Mongolia','people-and-society',389,'Population: 1,912,000 (July 1985), average
annual growth rate 2.7%
Nationality: noun—Mongolian(s); adjec-
tive—Mongolian
Ethnic divisions: 90% Mongol, 4% Kazakh,
2% Chinese, 2% Russian, 2% other
Religion: predominantly Tibetan Buddhist,
about 4% Muslim, limited religious activity
because of Communist regime
Language: Khalkha Mongol used by over
90% of population; minor languages include
Turkic, Russian, and Chinese
Literacy: about 80%
Labor force: primarily agricultural, over half
the adult population is in the labor force, in-
cluding a large percentage of women;
shortage of skilled labor (no reliable informa-
tion available)','b945a1f556ee36b5ae952a0702771485a4bcc19e6cd173c841bb938f3d8f72cb','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13777bbcf7f001d98c1fd160a4f082145534e2f926594014aa0a3c78fd3f6fa7',1985,'MA','Morocco','people-and-society',393,'Population: 24,258,000 (July 1985), average
annual growth rate 2.9%
Nationality: noun—Moroccan(s); adjec-
tive—Moroccan
Ethnic divisions: 99.1% Arab-Berber, 0.7%
non-Moroccan, 0.2% Jewish
Religion: 98.7% Muslim, 1.1% Christian,
0.2% Jewish
Language: Arabic (official); several Berber
dialects; French is language of much busi-
ness, government, diplomacy, and
postprimary education
Literacy: 28%
Labor force: 6.1 million (1982 est.); 50% agri-
culture, 26% services, 15% industry, 9%
other; at least 20% of urban labor unem-
ployed
158
Organized labor: about 5% of the labor force,
mainly in the Union of Moroccan Workers
(UMT) and the Democratic Confederation of
Labor (CDT)','c464f0ce9015e17d5a58d6e49b2a5a17cd02886dab87d2020804efceeb69f285','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ba7e119f562dee7eabd1746a26578824b766921bad31e7ea9edbfd7a05be574',1985,'MZ','Mozambique','people-and-society',398,'Population: 13,776,000 (July 1985), average
annual growth rate 2.8%
Nationality: noun—Mozambican(s); adjec-
tive—Mozambican
Ethnic divisions: majority from indigenous
tribal groups; approximately 10,000 Europe-
ans, 35,000 Euro-Africans, 15,000 Indians
Religion: 60% indigenous beliefs, 30% Chris-
tian, 10% Muslim
Language: Portuguese (official); many indig-
enous dialects
Literacy: 14%','f2d4ecb3704208d775a8616a784b694bbb643dbe30e7aadb8d7f7616b12388bc','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b2521127346546dddaf3a6a26635956ba4cecef926d399bdf683da0621bf275',1985,'NA','Namibia','people-and-society',402,'Population: 1,108,000 (July 1985), average
annual growth rate 3.0%
Nationality: noun—Namibian(s); adiec-
tive—Namibian
Ethnic divisions: 85.6% black, 7.5% white,
6.9% mixed; approximately half the Africans
belong to Owambo tribe
Religion: whites predominantly Christian,
nonwhites either Christian or indigenous be-
liefs
Language: Afrikaans principal language of
about 60% of white population, German of
33%, and English of 7% (all official); several
indigenous languages
Literacy: 100% whites, 28% nonwhites
161
Labor force: about 500,000 (1981); 60% agri-
culture, 19% industry and commerce, 8%
services, 7% government, 6% mining
Organized labor: 6 trade unions, member-
ship almost exclusively white and mulatto','7bef3bf2ac40cc0ed033794e523ec4281c85a54eb29255e39d724761e671b396','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9aec9927b7f83022d82fe51b01319e98531d99b1cba7a37e077a340c7098b287',1985,'NR','Nauru','people-and-society',406,'Population: 8,000 (July 1985), average an-
nual growth rate 1.3%
Nationality: noun—Nauruan(s); adjective—
Nauruan
Ethnic divisions: 58% Nauruan, 26% other
Pacific Islander, 8% Chinese, 8% European
Religion: Christian (two-thirds Protestant,
one-third Catholic)
Language: Nauruan, a distinct Pacific Island
language (official); English widely under-
stood and spoken
Literacy: 99%','1e29888a5957d9483e6f3910385fdf4eb922087caea2c769590ea641229ad0a3','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f17371d6536d8c052da2789edcdc9f89ac15fe9ab6953fd2c0223a09fdf3a61',1985,'NP','Nepal','people-and-society',410,'Population: 16,996,000 (July 1985), average
annual growth rate 2.5%
Nationality: noun—Nepalese (sing. and pl.):
adjective—Nepalese
Ethnic divisions: Newars, Indians, Tibetans,
Gurungs, Magars, Tamangs, Bhotias, Rais,
Limbus, Sherpas, as well as many smaller
groups
Religion: only official Hindu kingdom in
world, although no sharp distinction between
many Hindu (about 88%) and Buddhist
groups; small groups of Muslims and Chris-
tians
Language: Nepali (official); 20 mutually un-
intelligible languages divided into numerous
dialects
Literacy: 20% |
Labor force: 4.1 million; 93% agriculture, 5%
services, 2% industry; great lack of skilled
labor
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Nepal (continued)','6a0b2268af3dcf92163932aab8fc8f9398f91341a22b433d550c07a43ecbb0be','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aaea28eacf54f2e14d4fb7dd76b101796babda85d45605bbc5b2eb4825d87baf',1985,'NL','Netherlands','people-and-society',414,'Population: 14,467,000 (July 1985), average
annual growth rate 0.4%
Nationality: noun—Netherlander(s), adjec-
tive—Netherlands
Ethnic divisions: 99% Dutch, 1% Indonesian
and other
Religion: 40% Roman Catholic, 31% Protes-
tant, 24% unaffiliated
Language: Dutch
Literacy: 99%
Labor force: 4.9 million (1981); 30% manu-
facturing, 24% services, 16% commerce, 10%
agriculture, 9% construction, 7% transporta-
tion and communications, 4% other; 11.3%
unemployment, September 1982
Organized labor: 33% of labor force
Population: 256,000 (July 1985), average an-
nual growth rate 1.2%
Nationality: noun—Netherlands Antille-
an(s); adjective--Netherlands Antillean
Ethnic divisions: 85% mixed African; re-
mainder Carib Indian, European, Latin, and
Oriental
Religion: predominantly Roman Catholic;
Protestant, Jewish, Adventist
Language: Dutch (official); Papiamento, a
Spanish-Portuguese-Dutch-English dialect
predominates; English widely spoken;
Spanish
Literacy: 95%
Labor force: 89,000 (1983); 65% government,
28% industry and commerce, 1.5% agricul-
ture; unemployment about 16% on Curacao
and about 10% on Aruba (1984 est.)
Organized labor: 60-70% of labor force
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2','ac85cf08b093584fce5f4ab2c1de4d0dc94b80f05e620dec1855fd7c5f6542c3','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1de85688eb95b5ad3569053d208fb54226816f8702fee00f6100b0d378fed016',1985,'NC','New Caledonia','people-and-society',418,'Population: 153,000 July 1985), average an-
nual growth rate 1.7%
Nationality: noun—New Caledonian(s); ad-
jective—New Caledonian
Ethnic divisions: Melanesian 42.5%, Euro-
pean 37.1%, Wallisian 8.4%, Polynesian
3.8%, Indonesian 3.6%, Vietnamese 1.6%
Religion: over 60% Roman Catholic, 30%
Protestant
Language: French; Melanesian-Polynesian
dialects
Literacy: unknown
Labor force: 50,469 (1980 est.); Javanese and
Tonkinese laborers were imported for plan-
tations and mines in pre-World War II
period; immigrant labor now coming from
Wallis Islands, New Hebrides, and French
Polynesia; est. 8% unemployment
Organized labor: labor not organized','f1d637d84d17126ef0d4df47a630dc96b62b0783fee89a4aa7b9f7ed53614fb9','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d961fe4f1d51f23c1dd332726c2f20015727248d4cf29192499217324025900e',1985,'NZ','New Zealand','people-and-society',422,'Population: 3,295,000 (July 1985), average
annual growth rate 1.4%
Nationality: noun—New Zealander(s): ad-
jective—New Zealand
Ethnic divisions: 87% European, 9% Maori,
2% Pacific Islander, 2% other
Religion: 81% Christian, 18% none or un-
specified, 1% Hindu, Confucian, and other
Language: English (official), Maori
Literacy: 98%
Labor force: 1,825,000 (1981); 29.9% manu-
facturing, mining, and construction; 24.2%
commerce and finance; 21.2% services;
10.7% agriculture; 8.3% transportation and
communications; 2% other; unemployment
3.7% (February 1981)
Organized labor: 46% of labor force','f45ddd9e6d4e0729aaa3b5ba562a7dea5cb5e4a3d1e7320d39356ed4d7e29bfc','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8aa46a1e381d34b2ddfce94f58f17640a894a93d12d900493ebc392c62c3d73e',1985,'NI','Nicaragua','people-and-society',426,'Population: 3,038,000 (July 1985), average
annual growth rate 3.5%
Nationality: noun—Nicaraguan(s); adjec-
tive—Nicaraguan
Ethnic divisions: 69% mestizo, 17% white,
9% black, 5% Indian
Religion: 95% Roman Catholic
Language: Spanish (official), English- and
Indian-speaking minorities on Atlantic coast
Literacy: 66%
Labor force: 969,000 (1983 est.); 40% agricul-
ture, 34% service, 26% industry, 3%
construction, 5% other; 25% unemployment
170
Organized labor: 35% of Nicaragua''s labor
force is organized; of the seven confedera-
tions, five are Sandinista or Marxist
oriented—the government-sponsored Sandi-
nista Workers’ Central (CST), 115,000
members, including state and municipal em-
ployees; the Association of Campesino
Workers (ATC), 130,000 members; the Gen-
eral Confederation of Independent Workers
(CGI-I), approximately 15,000 members; the
Workers Front, about 100 members; and the
Central for Labor Action and Unity (CAUS),
about 3,000 members; the other two unions
are the Nicaraguan Workers’ Central (CTN),
25,000 members, and the Confederation of
Labor Unification (CUS), 50,000 members
Population: 6,495,000 (July 1985), average
annual growth rate 3.3%
Nationality: noun—Nigerien(s) adjective—
Nigerien
Ethnic divisions: 56% Hausa; 22% Djerma;
8.5% Fula; 8% Tuareg; 4.3% Beri Beri
(Kanouri), 1.2% Arab, Toubou, and
Gourmantche; about 4,000 French expatri-
ates
Religion: 80% Muslim, remainder indige-
nous beliefs and Christians
Language: French (official), Hausa, Dierma
Literacy: 5%
Labor force: 2.5 million (1982) wage earners;
90% agriculture, 6% industry and commerce,
4% government
Organized labor: negligible','362055876db660190f0144d7d0330158b0fdb0c53bd980a0a3c880fad85e4d2c','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7e4d1f7fd09e7ebc2465c3786eb87ee801f8a0d62f391b1950470ee77b81306',1985,'NO','Norway','people-and-society',430,'Population: 4,160,000 (July 1985), average
annual growth rate 0.4%
Nationality: noun—Norwegian(s); adjec-
tive—Norwegian
Ethnic divisions: Germanic (Nordic, Alpine,
Baltic) and racial-cultural minority of 20,000
Lapps
Religion: 94% Evangelical Lutheran (state
church), 4% other Protestant and Roman
Catholic, 2% other
Language: Norwegian (official); small Lapp-
and Finnish-speaking minorities
Literacy: 100%
Labor force: 2.024 million (1983); 30.9% ser-
vices; 19.6% mining and manufacturing;
16.7% commerce; 8.8% transportation; 7.6%
construction; 7.2% agriculture, forestry, fish-
ing; 5.7% banking and financial services;
3.3% unemployed
Organized labor: 60% of labor force','ed8c0e2c01b7da0284b5e8d74c7bad9371ce98744d0da6be6f197424eca4c4ee','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a3d0fec04ef44cb7034f68d91ccd70dc59b9082343e9bbcf5b8a3ffdda71151',1985,'OM','Oman','people-and-society',434,'Population: 1,228,000 (July 1985), average
annual growth rate 3.9%
Nationality: noun—Omani(s); adjective—
Omani
Ethnic divisions: almost entirely Arab, with
small Baluchi, Zanzibari, and Indian groups
Religion: 75% Ibadhi Muslim; remainder
Sunni Muslim, Sh‘ia Muslim, some Hindu
Language: Arabic (official), English, Balu-
chi, Urdu, Indian dialects
Literacy: 20%
Labor force: 500,000; 50% are non-Omani;
est. 60% agriculture','86d5230c8c051d3d588aaf02026576c7e5932048209e0a743185affc66287a74','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66054e9c7533d12a5a1cd64f78d158968ded7dec6b8fbbddcbf1b8b283cc3ea6',1985,'PK','Pakistan','people-and-society',438,'Population: 99,199,000, excluding
Junagardh, Manavadar, Gilgit, Baltistan, and
the disputed area of Jammu and Kashmir
(July 1985); average annual growth rate 2.6%
Nationality: noun—Pakistani(s); adjective—
Pakistani
Ethnic divisions: Punjabi, Sindhi, Pushtan
(Pathan), Baluchi
Religion: 97% Muslim, 3% Christian, Hindu,
and other
Language: Urdu and English (official); total
spoken languages—64% Punjabi, 12%
Sindhi, 8% Pushtu, 7% Urdu, 9% Baluchi and
other; English is lingua franca
Literacy: 24%
Labor force: 25.24 million (1982 est.); exten-
sive export of labor; 52% agriculture, 21%
industry, 8% services, 19% other
Organized labor: negligible','affa54dbe531c5badea3d204097a02f617434d21a4da156de1e9a1c9e2a13f15','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b9120f0e29b27e9ffad5aefa961d7f09b6b92954c7461c64d3b739788ae5923',1985,'PA','Panama','people-and-society',442,'Population: 2,038,000 (July 1985), average
annual growth rate 1.8%
Nationality: noun—Panamanian(s); adjec-
tive—Panamanian
Ethnic divisions: 70% mestizo, 14% West In-
dian, 10% white, 6% Indian
Religion: over 93% Roman Catholic, 6%
Protestant
Language: Spanish (official); 14% speak En-
glish as native tongue; many Panamanians
bilingual
Literacy: 90%
Labor force: est. 625,000 (January 1982), 45%
commerce, finance, and services, 29% agri-
culture, hunting, and fishing; 10%
: CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Panama (continued)
manufacturing and mining; 5% construction;
5% transportation and communications; 4%
Canal Zone; 1.2% utilities; 2% other; unem-
ployed estimated at 20% (January 1984),
shortage of skilled labor but an oversupply of
unskilled labor
Organized labor: approximately 15% of la-
bor force (1982)','6d68197149739d9b98855db5a2ddcab1ef558a2d73f7103c230dfab4f427f3c8','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb77cc4a7de33bba87276477839edfb3d30156336ac9f16edffa3e85b1b39505',1985,'PG','Papua New Guinea','people-and-society',446,'Population: 3,326,000 (July 1985), average
annual growth rate 2.1%
Nationality: noun—Papua New Guinean(s),
adjective—Papua New Guinean
Ethnic divisions: predominantly Melanesian
and Papuan; some Negrito, Micronesian, and
Polynesian
Religion: over half of population nominally
Christian (490,000 Catholic, 320,000 Lu-
theran, other Protestant sects); remainder
indigenous beliefs
Language: 715 indigenous languages; pidgin
English in much of the country and Motu in
Papua region are linguae francae; English
spoken by 1-2% of population
Literacy: 32%
181
Labor force: 1.44 million (1979), 352,500
(1980) in salaried employment; 53% agricul-
ture, 20% government, 17% industry and
commerce, 10% services','19b4e380e2e685b78f19f7e7acab0d5b5fff63627a9bc008c2b5fa7dfe59d9a6','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9e06844ed770b9364691d5a76131f0c86f2eaca4b86b41d2668c81ff06d99a7',1985,'PY','Paraguay','people-and-society',450,'Population: 3,722,000 (July 1985), average
annual growth rate 2.7%
Nationality: noun—Paraguayan(s); adjec-
tive—Paraguayan
Ethnic divisions: 95% mestizo (Spanish and
Indian), 5% white and Indian
Religion: 97% Roman Catholic; Mennonite
and other Protestant denominations
Language: Spanish (official) and Guarani
Literacy: 81%
Labor force: 1.1 million (1983 est.); 44% agri-
culture; 34% industry and commerce, 18%
services, 4% government; unemployment
rate 15% (1984)
Organized labor: about 5% of labor force','500790df79d648ebf763b95cbd89ef86072e45b451119cea970bf5d2f4c9b488','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6aaf47f09e56a66697548cad6bcef075b16454caee1151869cde77d37fd1ea20',1985,'PE','Peru','people-and-society',454,'Population: 19,532,000 July 1985), average
annual growth rate 2.4%
Nationality: noun—Peruvian(s); adjective—
Peruvian
Ethnic divisions: 45% Indian; 37% mestizo
(white-Indian); 15% white; 3% black, Japa-
nese, Chinese, and other
Religion: predominantly Roman Catholic
Language: Spanish and Quechua (official),
Aymara
Literacy: est. 72%
Labor force: 5.6 million (1980), 41% govern-
ment and other services, 40% agriculture,
19% industry and mining; unemployment
about 9% (1983 est.)
Organized labor: about 40% of salaried
workers (1983 est.)','ade566f70c5afd94589e7919032b93b9c7e51c1ce5a7ed4dc2a0d3dbcedca372','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f61cf86724ede25a6dfeec3fe32ee0d234bc5ac82074f2ad94f143c771292b7c',1985,'PL','Poland','people-and-society',458,'Population: 37,236,000 (July 1985), average
annual growth rate 0.9%
Nationality: noun—Pole(s); adjective—
Polish
Ethnic divisions: 98.7% Polish, 0.6% Ukrai-
nian, 0.5% Byelorussian, less than 0.05%
Jewish, 0.2% other
Religion: 95% Roman Catholic (about 75%
practicing), 5% Uniate, Greek Orthodox,
Protestant, and other
Language: Polish, no significant dialects
Literacy: 98%
Labor force: 19.3 million; 27% agriculture,
32% industry, 41% other nonagricultural
(1980)
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Organized labor: new government trade
unions formed following dissolution of Soli-
darity and all government unions in October
1982','2ea55437137ca3e7fa8c5a26eb70364c5cafbe382da99021cf7a5a5633fc2499','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec4ee5c8da39342f8c36dd71e3e448032bf06d2d2579ecfcc6b4e1fd109aee21',1985,'PT','Portugal','people-and-society',462,'Population: 10,045,000 (July 1985), includ-
ing the Azores and Madeira Islands; average
annual growth rate 0.5%
Nationality: noun—Portuguese (sing. and
pl.); adjective—Portuguese
Ethnic divisions: homogeneous Mediterra-
nean stock in mainland, Azores, Madeira
Islands; citizens of black African descent who
immigrated to mainland during decoloniza-
tion number less than 100,000
Religion: 97% Roman Catholic, 1% Protes-
tant sects, 2% other
Language: Portuguese
Literacy: 80%
Labor force: 4.6 million (1983); 37% services,
36% industry, 27% agriculture; unemploy-
ment, 10.2% (June 1984)
Organized labor: about 45% of Portuguese
labor is organized; the Communist-domi-
nated General Confederation of Portuguese
Workers—National Intersindical (CGTP-IN)
represents about half of the unionized labor
force; its main competition, the General
Workers Union (UGT), is organized by the
Socialists and Social Democrats and repre-
sents a little less than half of unionized labor
Government 2
Official name: Portuguese Republic
Type: republic, first government under new
constitution formed July 1976
Capital: Lisbon
Political subdivisions: 18 districts in main-
land Portugal; Portugal’s two autonomous
regions, the Azores and Madeira Islands, have
4 districts (3 of them in the Azores); Macau,
Portugal’s remaining overseas territory, was
granted broad executive and legislative au-
tonomy in February 1976; Portugal has not
officially recognized the unilateral annex-
ation of Portuguese Timor by Indonesia
Legal system: civil law system; constitution
adopted April 1976 and revised October
1982; the Constitutional Tribunal reviews the
constitutionality of legislation; legal educa-
tion at Universities of Lisbon and Coimbra;
accepts compulsory IC] jurisdiction, with
reservations
National holiday: 25 April
Branches: executive with President and
Prime Minister; unicameral legislature (pop-
ularly elected Assembly of the Republic);
independent judiciary
Government leaders: Gen. Anténio dos San-
tos Ramalho EANES, President (since June
1976); Mario SOARES, Prime Minister (since
June 1983)
Suffrage: universal over age 18
188
Elections: national elections for Assembly of.
the Republic normally to be held every four
years; Assembly elections held April 1983;
national election for President to be held ev-
ery five years, second constitutional
president elected in December 1980; local
elections to be held every three years, last
elections in December 1982
Political parties and leaders: Portuguese So-
cialist Party (PS), Mario Soares; Social
Democratic Party (PSD), formerly the Popu-
lar Democratic Party (PPD), Rui Machete;
Social Democratic Center (CDS), Francisco
Lucas Pires; Portuguese Communist Party
(PCP), Alvaro Cunhal; Party of Democratic
Renewal (PRD), Herminio Martinho
Voting strength; (1988 parliamentary elec-
tion) Socialists, 36.3%; Social Democrats,
27.0%; Center Democrats, 12.4%; Commu-
nists (in a front coalition called the United
Peoples Alliance—APU), 18.2%; (1982 local
elections) Democratic Alliance (AD), which
consists primarily of the PSD and the CDS,
41%; PS, 32.0%; APU, 21.5%
Communists: Portuguese Communist Party
claims membership of 200,753 (December
1983)
Member of: Council of Europe, EFTA, FAO,
GATT, IAEA, IATP, IBRD, ICAC, ICAO,
ICES, ICO, IDB—Inter-American Develop-
ment Bank, IEA, IFAD, IFC, IHO, ILO,
IMF, IMO, INTELSAT, INTERPOL,
IOOC, IRC, ISO, ITU, IWC—International
Wheat Council, NATO, OECD, UN,
UNESCO, UPU, WHO, WIPO, WMO, WSG','7b609a6624d3a801a78f8b32607b9ee95d8c1851721b4b503ad0a54a1676547e','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f517896a16f58806f457fc993919f8017e85fae37f866c8d55630734dc29c1a',1985,'QA','Qatar','people-and-society',465,'Population: 301,000 (July 1985), average an-
nual growth rate 3.4%
Nationality: noun—Qatari(s); adjective—
Qatari
Ethnic divisions: 40% Arab, 18% Pakistani,
18% Indian, 10% Iranian
Religion: 95% Muslim
Language: Arabic (official); English is com-
monly used as second language
Literacy: 40%
Labor force: 104,000 (1983), 85% non-Qatari
in private sector
Population: 537,000 (July 1985), average an-
nual growth rate 1.1%
Nationality: noun—Reunionese (sing. and
pl.); adiective—Reunionese
Ethnic divisions: most of the population is of
thoroughly intermixed ancestry of French,
African, Malagasy, Chinese, Pakistani, and
Indian origin
Religion: 94% Roman Catholic
Language: French (official); Creole widely
used
Literacy: over 80% among younger genera-
tion
Labor force: primarily agricultural workers,
high seasonal unemployment','f4be6dea6d822fa9900ff923caea4289c2d41c651ac4cc0437ef4fe6dfed920b','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6441721fca5754f5a01b050a31e65a0071dceb412e9890bb4fc3d76a933a7775',1985,'RO','Romania','people-and-society',469,'Population: 22,772,000 (July 1985), average
annual growth rate 0.5%
Nationality: noun—Romanian(s); adjec-
tive—Romanian
Ethnic divisions: 88.1% Romanian; 7.9%
Hungarian, 1.6% German; 2.4% Ukrainian,
Serb, Croat, Russian, Turk, and Gypsy
Religion: 80% Romanian Orthodox; 6% Ro-
man Catholic; 4% Calvinist, Lutheran,
Jewish, Baptist, and other
Language: Romanian, Hungarian, German
Literacy: 98%
Labor force: 10.5 million (1983); 37.8% indus-
try, 29.2% agriculture, 33% other
nonagricultural (1983)','b6c1e79e4b80c68bf656b3b9469854ae52ff8ccda5ee56075e7706eefe688ce2','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51e9f141df15cf85861cd7970c1d5a354ec3cbea65a499e4fb1e5401f8f934d6',1985,'RW','Rwanda','people-and-society',473,'Population: 6,246,000 (July 1985), average
annual growth rate 3.7%
Nationality: noun—Rwandan(s), adjective—
Rwandan
Ethnic divisions: 85% Hutu, 14% Tutsi, 1%
Twa (Pygmoid)
Religion: 65% Catholic, 9% Protestant, 1%
Muslim, rest indigenous beliefs
Language: Kinyarwanda and French offi-
cial; Kiswahili used in commercial centers
Literacy: 37%
Labor force: 2.7 million (1983); 93% agricul-
ture, 3% industry and commerce, 3%
government, 1% services','8754f28bbb9fdce1d175d7009ceb8769ef4c96fcbe739cb4f023a8916527728a','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73390dcc8797ec8e6425ded09d0b31c891439389171324dd6125257a911c4f7b',1985,'SM','San Marino','people-and-society',477,'Population: 23,000 (July 1985), average an-
nual growth rate 1.6%
Nationality: noun—Sanmarinese (sing. and
pl.); adjective—Sanmarinese
Religion: Roman Catholic
Language: Italian
Literacy: 97%
Labor force: approx. 4,300
Organized labor: Democratic Federation of
Sanmarinese Workers (affiliated with
ICFTU) has about 1,800 members; Commu-
nist-dominated General Federation of
Labor, 1,400 members','d15678af5e0fdd1d35b7b2ddffa8a5d5067bd867415f8dbc8747f646471e5cb0','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b222e6aa5be86a8182b4b013e549d72c990d8db79ccb74472b20a681e06d860',1985,'SA','Saudi Arabia','people-and-society',480,'Population: 11,152,000 July 1985), average
annual growth rate 3.3%
Nationality: noun—Saudi(s); adjective—
Saudi Arabian or Saudi
Ethnic divisions: 90% Arab, 10% Afro-Asian
Religion: 100% Muslim
Language: Arabic
Literacy: 52%
Labor force: about one-third (one-half for-
eign) of population; 45% commerce, services,
government, and other; 30% agriculture; 15%
construction; 5% industry; 5% oil and mining
Population: 21,733,000 (July 1985), average
annual growth rate 3.2%
Nationality: noun—Tanzanian(s); adjec-
tive—Tanzanian
Ethnic divisions: mainland—99% native Af-
rican consisting of well over 100 tribes; 1%
Asian, European, and Arab, Zanzibar—
almost all Arab
Religion: mainland—33% Christian, 33%
Muslim, 33% indigenous beliefs; Zanzibar—
almost all Muslim
Language: Swahili and English (official), En-
glish primary language of commerce,
administration, and higher education; Swa-
hili widely understood and generally used for
communication between ethnic groups; first
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
language of most people is one of the local
languages; primary education is generally in
Swahili
Literacy: 79%
Labor force: 208,680 in paid employment
(1983); 90% agriculture, 10% industry and
commerce
Organized labor: 15% of labor force','dcb6e783871af6e4809671f83e8cba6041dda7b05cc1d95bb0183be99ec5b5d2','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ce70a62735ced6a0d076554f195cbdc60bfdf10263b54671f78708873fccfbf',1985,'SN','Senegal','people-and-society',483,'Population: 6,755,000 (July 1985), average
annual growth rate 3.2%
Nationality: noun—Senegalese (sing. and
pl.); adjective—Senegalese
Ethnic divisions: 36% Wolof, 17.5% Fulani,
16.5% Serer, 9% Toucouleur, 9% Diola, 6.5%
Mandingo, 4.5% other African, 1% European
and Lebanese
Religion: 92% Muslim, 6% indigenous be-
liefs, 2% Christian (mostly Roman Catholic)
Language: French (official); Wolof, Pulaar,
Diola, Mandingo
Literacy: 10%
Labor force: 1,732,000; 70% subsistence agri-
cultural workers; 175,000 wage earners—
40% private sector, 60% government and
parapublic
201
Organized labor: majority of wage-labor
force represented by unions; however, dues-
paying membership very limited; major
confederation is National Confederation of
Senegalese Labor (CNTS), an affiliate of gov-
erning party','491b5eb5bc24f7553556586ba9c220fc65afcd840a2d91c0d7f2ba29c358c338','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83e25a3a52b2083dc6b51754817bad55406c7c61656bb287c92ef7806b96f30c',1985,'SC','Seychelles','people-and-society',487,'Population: 66,000 (July 1985), average an-
nual growth rate 0.9%
Nationality: noun—Seychellois (sing. and
pl.); adjective—Seychelles
Ethnic divisions: Seychellois (mixture of
Asians, Africans, Europeans)
Religion: 90% Roman Catholic, 8% Anglican,
2% other
Language: English and French (official);
Creole
Literacy: 60%
Labor force: 15,000 in monetized sector (ex-
cluding self-employed, domestic servants,
and workers on small farms), 49% govern-
ment, 19% industry and commerce, 18.5%
agriculture, 13.5% services
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Organized labor: 3 major trade unions','0defa7320ce1c2ade2c5482c1662fc774cb84ce17af188e5df1512112e754fdb','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('748a6a0cca7a58bbeda377d07b6212beb54f284ae5c89dc2ad08daccdca77f3b',1985,'SL','Sierra Leone','people-and-society',491,'Population: 3,883,000 (July 1985), average
annual growth rate 2.6%
Nationality: noun—Sierra Leonean(s); adjec-
tive—Sierra Leonean
Ethnic divisions: over 99% native African
(30% Temne, 30% Mende, 2% Creole), rest
European and Asian; 13 tribes
Religion: 60% Muslim, 30% indigenous be-
liefs, 10% Christian
Language: English (official); regular use lim-
ited to literate minority; principal
vernaculars are Mende in south and Temne
in north; “Krio,” the language of the resettled
exslave population of the Freetown area, is
used as a lingua franca
Literacy: about 15%
Labor force: about 1.5 million; most of popu-
lation engages in subsistence agriculture;
only small minority, some 65,000, earn wages
Organized labor: 35% of wage earners','d0a111f38a998783eee32c8ef74f950e4dfabb7a2b344199ff6f7af5488b4be1','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('faeaac513d8a12a1a389f3b8e72a12e67e5e5bf5f4a0129448e1e880b6150dcd',1985,'SG','Singapore','people-and-society',495,'Population: 2,562,000 (July 1985), average
annual growth rate 1.2%
Nationality: noun—Singaporean(s), adjec-
tive—Singapore
Ethnic divisions: 76.7% Chinese, 14.7% Ma-
lay, 6.4% Indian, 2.2% other
Religion: majority of Chinese are Buddhists
or atheists; Malays nearly all Muslim; minor-
ities include Christians, Hindus, Sikhs,
Taoists, Confucianists
Language: Chinese, Malay, Tamil, and En-
glish (official); Malay (national)
Literacy: 84.2%
Labor force: 1,142,374 (June 1982); 29.5%
manufacturing, 28.5% services, 22.3% trade,
11.4% transport and communication, 6.3%
construction, 1.0% agriculture and fishing,
1.0% other
205
Organized labor: 18.6% of labor force','23f9cc23b169e02ba1b5ee44ad8366efff46b40bb1d748ac724b7350353bdf0d','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6462450983998b3e1a19f958a4b44b397c324f51e19e95b1edd7ac456e3bc0f6',1985,'SB','Solomon Islands','people-and-society',499,'Population: 273,000 (July 1985), average an-
nual growth rate 3.7%
Nationality: noun—Solomon Islander(s); ad-
jective—Solomon Islander
Ethnic divisions: 93.0% Melanesian, 4.0%
Polynesian, 1.5% Micronesian, 0.8% Euro-
pean, 0.3% Chinese, 0.4% other
Religion: almost all at least nominally Chris-
tian; Roman Catholic, Anglican, and
Methodist churches dominant
Language: English (official), local languages
Literacy: 60%
: CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Labor force: 20,631 economically active
(1980); 30% forestry and fishing, 28.2% social
services, 10.8% manufacturing, 9.6% com-
merce, 7.7% construction, 7.1% transpor-
tation and communications','e3bcb403964d744803e7a9b11ca2baef589218647d3ca0656f5450fbb4e40869','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('531e417375ae5ea50b0ff1597c9c22ce71da0874187a49a410a1cca16214ebe8',1985,'SO','Somalia','people-and-society',503,'Population: 7,595,000 (July 1985), average
annual growth rate 3.0%
Nationality: noun-——Somali(s); adjective—
Somali
Ethnic divisions: 85% Somali, rest mainly
Bantu; 30,000 Arabs, 3,000 Europeans, 800
Asians
Religion: almost entirely Sunni Muslim
Language: Somali (official); Arabic, Italian,
English
Literacy: 60%
Labor force: about 2.2 million; very few are
skilled laborers; 70% pastoral nomad, 30% ag-
riculturists, government employees, traders,
fishermen, handicraftsmen, other
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Somalia (continued)
Organized labor: General Federation of So-
mali Trade Unions, a government-controlled
organization, established in 1977','b220bf0ff02bb70131fbe583204aa55cae745a273b5f34384ec914a52fa7dadd','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f9e43e1a087958077d5f58236da8a151c249e9bfa1075a8bb76a1a01fbf3382',1985,'ZA','South Africa','people-and-society',506,'Population: 32,465,000 (July 1985), includ-
ing Bophuthatswana, Ciskei, Kwazulu,
Lebowa, Transkei, and Venda; average an-
nual growth rate 2.4%; Bophuthatswana
1,623,000 (July 1985), average annual growth
rate 3.9%; Ciskei 763,000 (July 1985), average
annual growth rate 2.3%; Kwazulu 4,347,000
(July 1985), average annual growth rate 4.6%;
Lebowa 2,208,000 (July 1985), average an-
nual growth rate 4.5%; Transkei 2,960,000
(July 1985), average annual growth rate 3.4%,
Venda 412,000 (July 1985), average annual
growth rate 2.7%
Nationality: noun—South African(s); adjec-
tive—South African
Ethnic divisions: 69.9% African, 17.8%
white, 9.4% Colored, 2.9% Indian
Religion: most whites and Coloreds and
roughly 60% of Africans are Christian;
roughly 60% of Indians are Hindu, 20% Mus-
lim
Language: Afrikaans, English (official), Afri-
cans have many vernacular languages,
including Zulu, Xhosa, North and South So-
tho, Tswana
Literacy: almost all white population literate;
government estimates 50% of Africans liter-
ate
Labor force: 8.7 million economically active
(1980); 53% agriculture, 27% miscellaneous
services, 8% manufacturing, 7% mining, 5%
commerce
Organized labor: about 7% of total labor
force is unionized (mostly white workers), Af-
rican unions represent less than 15% of black
labor force
Population: 277,930,000 (July 1985), average
annual growth rate 1.0%
Nationality: noun—Soviet(s); adjective—So-
viet
Ethnic divisions: 52% Russian, 16% Ukrai-
nian, 832% among over 100 other ethnic
groups, according to 1979 census
Religion: 18% Russian Orthodox; 9% Muslim;
3% Jewish, Protestant, Georgian Orthodox, or
Roman Catholic; population is 70% atheist
Language: Russian (official); more than 200
languages and dialects (at least 18 with more
than 1 million speakers); 75% Slavic group,
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86800596R000200790001-2
8% other Indo-European, 12% Altaic, 3%
Uralian, 2% Caucasian
Literacy: 99.8%
Labor force: civilian 147 million (midyear
1982), 20% agriculture, 80% industry and
other nonagricultural fields; unemployed not
reported; shortage of skilled labor reported','5e3382286d50cb2be78acc8e63bd1ffd0b055b12962ec23a840735a3410279fc','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3140508d87cc977ab72db0845019a4fec695d30cfd7c15a42abc791e89af12b',1985,'ES','Spain','people-and-society',509,'Population: 38,629,000 (July 1985), includ-
ing the Balearic and Canary Islands and
Ceuta and Melilla (two towns on the Moroc-
can coast); average annual growth rate 0.5%
Nationality: noun—Spaniard(s); adjective—
Spanish
Ethnic divisions: composite of Mediterra-
nean and Nordic types
Religion: 99% Roman Catholic, 1% other
sects
Language: Castilian Spanish; second lan-
guages include 17% Catalan, 7% Galician,
and 2% Basque
Literacy: 97%
212
Labor force: 13.2 million (1984); 43% ser-
vices, 24% industry, 16% agriculture, 9%
construction; unemployment now estimated
at nearly 20.5% of labor force (September
1984)
Organized labor: labor unions legalized April
1977; represent no more than a quarter of the
labor force (1983)','b9e9a38d0ddafafc3cd50422fe1f19f7d05052e365e151f7047d2c9d5c098a8c','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53e46a1da41d59efbcbab60b508fd0754873a01255cb99fc1bc7db4de906597c',1985,'LK','Sri Lanka','people-and-society',512,'Population: 16,206,000 (July 1985), average
annual growth rate 1.8%
Nationality: noun—Sri Lankan(s); adjec-
tive—Sri Lankan
Ethnic divisions: 74% Sinhalese; 18% Tamil;
7% Moor; 1% Burgher, Malay, and Veddoh
Religion: 69% Buddhist, 15% Hindu, 8%
Christian, 8% Muslim, 0.1% other
Language: Sinhala (official): Sinhala and
Tamil listed as national languages; Sinhala
spoken by about 74% of population; Tamil
spoken by about 18%; English commonly
used in government and spoken by about 10%
of the population
Literacy: 87%
Labor force: 4 million; 15% unemployed:
employed persons—45.9% agriculture,
13.3% mining and manufacturing, 12.4%
214
trade and transport, 26.3% services and
other; extensive underemployment
Organized labor: about 33% of labor force,
over 50% of which employed on tea, rubber,
and coconut estates','4554b111219e570b7bf3b49ff715405499541bd4b6b7704c21b321f7aa638984','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b9fe64f8bdbd066eb7f64e70565ed5389ad13cf2a358aa8d20af3ad79ad940b',1985,'SR','Suriname','people-and-society',519,'Population: 377,000 (July 1985), average an-
nual growth rate 1.8%
Nationality: noun—Surinamer(s); adjec-
tive—Surinamese
Ethnic divisions: 37% Hindustani (East In-
dian), 31% Creole (black and mixed), 15.3%
Javanese, 10.3% Bush Negro, 2.6% Amerin-
dian, 1.7% Chinese, 1.0% Europeans, 1.7%
other
Religion: Hindu, Muslim, Roman Catholic,
Moravian, other
Language: Dutch (official), English widely
spoken; Sranang Tongo (Surinamese, some-
times called Taki-Taki) is native language of
Creoles and much of the younger population
and is lingua franca among others; Hindi; Ja-
vanese
217
Literacy: 65%
Labor force: 100,000; unemployment 20%
(1983)
Organized labor: approx. 33% of labor force
Population: 671,000 (July 1985), average an-
nual growth rate 3.0%
Nationality: noun—Swazi(s); adjective—
Swazi
Ethnic divisions: 96% Atrican, 3% European,
1% mulatto
Religion: 57% Christian, 48% indigenous be-
liefs
Language: English and siSwati (official); gov-
ernment business conducted in English
Literacy: 65%
Labor force: 195,000; over 60,000 engaged in
subsistence agriculture; 55,000-60,000 wage
earners, many only intermittently, with 36%
agriculture and forestry, 20% community
and social services, 14% manufacturing, 9%
construction, 21% other; 12,000 employed in
South Africa (1982)
Organized labor: about 15% of wage earners
are unionized','c859df7393cadd6e054f0f34761748747ea0602917fd93379cd14b6992ddff44','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1a7e14eb4cfb62e3854361e13eaefabb591f35655bdad0754a985a71749e172',1985,'SE','Sweden','people-and-society',523,'Population: 8,338,000 (July 1985), average
annual growth rate 0%
Nationality: noun—Swede(s); adjective—
Swedish
Ethnic divisions: homogeneous white popu-
lation; small Lappish minority; est. 12%
foreign born or first generation immigrants
(Finns, Yugoslavs, Danes, Norwegians,
Greeks)
Religion: 93.5% Evangelical Lutheran, 1.0%
Roman Catholic, 5.5% other
Language: Swedish, small Lapp- and Finn-
ish-speaking minorities; immigrants speak
native languages
Literacy: 99%
Labor force: 4.35 million; 31% private ser-
vices; 30.6% government services; 21.9%
mining and manufacturing; 7.2% construc-
tion; 5.2% agriculture, forestry, and fishing;
0.9% electricity, gas, and waterworks; 3.5%
unemployed (1983 average)
Organized labor: 80% of labor force','83e9927f7c9a9c164f782f4b94edc219ed93d576ce6e54e6078abfe01bbf7a43','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9206691603c627156dba386ca7e1ffc40c232905b0344fcdb9b6f509a635815b',1985,'CH','Switzerland','people-and-society',527,'Population: 6,512,000 (July 1985), average
annual growth rate 0.2%
Nationality: noun—Swiss (sing. & pl.); adjec-
tive—Swiss
Ethnic divisions: total population—65%
German, 18% French, 10% Italian, 1% Ro-
mansch, 5% other; Swiss nationals—74%
German, 20% French, 4% Italian, 1% Ro-
mansch, 1% other
Religion: 49% Catholic, 48% Protestant, 0.3%
Jewish
Language: total population—65% German,
18% French, 12% Italian, 1% Romansch, 4%
other; Swiss nationals—74% German, 20%
French, 4% Italian, 1% Romansch, 1% other
Literacy: 99%
Labor force: 3.05 million, about 706,000 for-
eign workers, mostly Italian; 42% services,
39% industry and crafts, 11% government,
7% agriculture and forestry, 1% other; ap-
proximately 0.8% unemployed in October
1988
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Switzerland (continued)
Organized labor: 20% of labor force
Population: 10,535,000 (July 1985), average
annual growth rate 3.7%
Nationality: noun—Syrian(s); adjective—
Syrian
Ethnic divisions: 90.3% Arab; 9.7% Kurds,
Armenians, and other
Religion: 74% Sunni Muslim; 16% Alawite,
Druze, and other Muslim sects; 10% Chris-
tian (various sects)
Language: Arabic (official), Kurdish, Arme-
nian, Aramaic, Circassian; French and
English widely understood
Literacy: about 50%
Labor force: 2.3 million; 837% miscellaneous
services, 32% agriculture, 31% industry
223
(including construction); majority unskilled;
shortage of skilled labor
Organized labor: 5% of labor force','e6b93a5305f461e516c9587ff29acd6953ef6afd17024f8a448f50e6934d46de','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d04417f3dbfc2c43a9458799d64f6b7b076d325e39814b1b01821cdae3cbc346',1985,'TG','Togo','people-and-society',531,'Population: 3,018,000 (July 1985), average
annual growth rate 3.1%
Nationality: noun—Togolese (sing. and pl.);
adjective—Togolese
Ethnic divisions: 37 tribes; largest and most
important are Ewe, Mina, and Kabyée; under
1% European and Syrian-Lebanese
Religion: about 70% indigenous beliefs, 20%
Christian, 10% Muslim
Language: French, both official and lan-
guage of commerce; major African languages
are Ewe and Mina in the south and Dagomba
and Kabye in the north
Literacy: 18%
Labor force: 78% agriculture, 22% industry;
about 88,600 wage earners, evenly divided
between public and private sectors
227
Organized labor: one national union, the Na-
tional Federation of Togolese Workers','620bffc5cdb557cced3c7f1c39318354425cbc4c6ad788c5b5a5ab85f8305762','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5cf24517dfabc2861b8d6c3d7b87ae410d9dd72c85078407a9c4386ce9f4b183',1985,'TO','Tonga','people-and-society',535,'Population: 107,000 (July 1985), average an-
nual growth rate 1.9%
Nationality: noun—Tongan(s); adjective—
Tongan
Ethnic divisions: Polynesian; about 300 Eu-
ropeans
Religion: Christian; Free Wesleyan Church
claims over 30,000 adherents
Language: Tongan, English
Literacy: 90-95%; compulsory education for
children ages 6-14
Labor force: agriculture 10,300; mining 600','868d54b962409e1ca097536caab2e03c419cb6d36281ff87a895f73cc240d3fc','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62dd7987020939e463a1378886adec1f7762c82bf15d47514839c24c9b38f10a',1985,'TT','Trinidad and Tobago','people-and-society',539,'Population: 1,185,000 (July 1985), average
annual growth rate 1.5%
Nationality: noun—Trinidadian(s),
Tobagan(s); adjective—Trinidadian,
Tobagan
Ethnic divisions: 43% black, 40% East In-
dian, 14% mixed, 1% white, 1% Chinese, 1%
other
Religion: 36.2% Roman Catholic, 23%
Hindu, 13.1% Protestant, 6% Muslim, 21.7%
unknown
Language: English (official), Hindi, French,
Spanish
Literacy: 95%
Labor force: about 473,000 (est. 1979-81);
23.0% service; 20.0% mining, quarrying, and
manufacturing; 17.4% commerce; 15.7%
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
(continued)
construction and utilities; 13.5% agriculture;
7.5% transportation and communication;
2.9% other
Organized labor: 30% of labor force','8acfe088b4a99f14666e4ce2283359b5f69428cef756bb9f50ae5a04cd0ce800','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80abae595fb2d47bf003d0d2ee54a9eec2a5cd791f6f89790c776be61d2178b3',1985,'TN','Tunisia','people-and-society',543,'Population: 7,352,000 (July 1985), average
annual growth rate 2.4%
Nationality: noun—Tunisian(s); adjective—
Tunisian
Ethnic divisions: 98% Arab, 1% European,
less than 1% Jewish
Religion: 98% Muslim, 1% Christian, less
than 1% Jewish
Language: Arabic (official), Arabic and
French (commerce)
Literacy: about 62%
Labor force: 1.9 million, 32% agriculture;
15%-25% unemployed; shortage of skilled
labor.
Organized labor: about 360,000 members
claimed, roughly 20% of labor force; General
Union of Tunisian Workers (UGTT), quasi-
independent of Destourian Socialist Party','f706348c375934365d53528d4aacf6fab9ca8657a235c57a91897ca5089032fa','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f07c6716dde145235a1f226d889a19ecbff057fb20c92a2699c25a6529551d7',1985,'TC','Turks and Caicos Islands','people-and-society',547,'Population: 7,436 (1980)
Ethnic division: majority of African descent
Religion: Anglican, Roman Catholic, Baptist,
Methodist, Church of God, Seventh-day Ad-
ventist
Language: English (official)
Literacy: about 99%
Labor force: some subsistence agriculture;
majority engaged in fishing and tourist indus-
tries
Organized labor: St. George’s Industrial
Trade Union (Cockburn Harbor), 250 mem-
bers','d5e50f16c252b8db9a61f5b912d513a977c936c1df011adbac17e5aaa5bd1a83','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efb6fd7b2156244a856f344e9e5bf4802692f92e22dbbfdacdd73477eb02a75f',1985,'TV','Tuvalu','people-and-society',551,'Population: 8,000 (July 1985), average an-
nual growth rate 1.7%
Nationality: noun—Tuvaluans(s); adjec-
tive—Tuvaluan
Ethnic divisions: 96% Polynesian
Religion: Christian, predominantly Protes-
tant
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Language: Tuvaluan, English
Literacy: less than 50%','bb8651b90231ac5799cc1187a40c9194d04d08251e04309e8ff1f184d41c19b4','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e42792e1d5c372e8272132d94dc09790e4d71775850fdce3b19197ad0c0a753',1985,'UG','Uganda','people-and-society',555,'Population: 14,733,000 July 1985), average
annual growth rate 3.2%
Nationality: noun—Ugandan(s); adiective—
Ugandan
Ethnic divisions: 99% African, 1% European,
Asian, Arab
Religion: 33% Roman Catholic, 33% Protes-
tant, 16% Muslim, rest indigenous beliefs
Language: English (official); Luganda and
Swahili widely used; other Bantu and Nilotic
languages
Literacy: 52%
Labor force: estimated 4.5 million; about
250,000 in paid labor; remainder in subsis-
tence activities
Organized labor: 125,000 union members','5d2807d20b9bdce439516d9c7ac04ed06ba9682f6439cf6599ea138dc2892dea','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43f1a471c7d4b86a6bfd5de2effd1ea3bfd4bf71d8163d17af3eb124463d81b3',1985,'AE','United Arab Emirates','people-and-society',559,'Population: 1,320,000 July 1985), average
annual growth rate 4.4%
Nationality: Noun—Emirian(s), adjective—
Emirian
Ethnic divisions: Emirian 19%, other Arab
23%, South Asian 50% (fluctuating), other ex-
patriates (includes Westerners and East
Asians) 8%; fewer than 20% of the population
are UAE citizens (1982)
Religion: Muslim 96%; Christian, Hindu, and
other 4%
Language: Arabic (official); Farsi and En-
glish widely spoken in major cities; Hindi,
Urdu
Literacy: 56.3% est.
Labor force: 541,000 (1980 est.); 85% indus-
try and commerce, 5% agriculture, 5%
services, 5% government; 80% of labor force
is foreign','5aa4a48ffa816bbdfe1cc347776619ca8bb9a56acc8ecc8eb025f6c2745fcbcf','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fdf7ff1b70ca580d6bbb333eb04c03bf1b14889c6705a64cbf9e021425eb4b3b',1985,'GB','United Kingdom','people-and-society',562,'Population: 56,437,000 (July 1985), average
annual growth rate 0.1%
Nationality: noun—Briton(s), British (collec-
tive pl.); adjective—British
Ethnic divisions: 81.5% English, 9.6% Scot-
tish, 2.4% Irish, 1.9% Welsh, 1.8% Ulster,
0.8% other; West Indian, Indian, Pakistani
2%
Religion: 27.0 million Anglican, 5.3 million
Roman Catholic, 2.0 million Presbyterian,
760,000 Methodist, 450,000 Jewish (regis-
tered)
Language: English, Welsh (about 26% of
population of Wales), Scottish form of Gaelic
(about 60,000 in Scotland)
Literacy: 99%
238
Labor force: (1982) 26.08 million; 54.4% in-
dustry and commerce, 29.9% services, 7.6%
self-employed, 6.6% government, 1.5% agri-
culture; 12.5% unemployed (early 1984)
Organized labor: 40% of labor force','244dc767093196042d8c0f0aec4d20affbe54ce552cb7ca24ba3f4a52a872e9c','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4bace5d2107f8859233d53b51fbe081eca09c11490dd9351fa0a4be16a0c87db',1985,'US','United States','people-and-society',566,'Population: 238,848,000 (July 1985), average
annual growth rate 0.9%
Ethnic divisions: 80% white; 11% black; 6.2%
Spanish origin; 1.6% Asian and Pacific Is-
lander; 0.7% American Indian, Eskimo, and
Aleut (1980)
Religion: total membership in religious bod-
ies 134.8 million; Protestant 73.479 million,
Roman Catholic 50.45 million, Jewish 5.92
million, other religions 4.968 million (1982)
Language: predominantly English; sizable
Spanish-speaking minority
Literacy: 99.5% of total population 15 years
or older
Labor force: 115.786 million (includes 2.208
million members of the armed forces in the
US); unemployment rate 7.2% (1985); 10.411
million unemployed (January 1984)
Organized labor: approximately 17.4 million
members; 18.8% of civilian labor force (1984)','3be3dc045d5048084123bb21addac7ab70aec862585b8df08ef46b95759f90b0','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fad0857d145e1e9e4623af957c4e674a52dce090bc5d7fc00ea6e4edd6b23746',1985,'UY','Uruguay','people-and-society',570,'Population: 2,936,000 (July 1985), average
annual growth rate 0.3%
Nationality: noun—Uruguayan(s); adjec-
tive—Uruguayan
Ethnic divisions: 85-90% white, 5-10% mes-
tizo, 3-5 black
Religion: 66% Roman Catholic (less than half
adult population attends church regularly),
2% Protestant, 2% Jewish, 30% nonprofessing
or other
Language: Spanish
Literacy: 94.3%
Labor force: about 1.28 million (1981); 19%
manufacturing; 19% government; 16% agri-
culture; 12% commerce; 12% utilities,
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Uruguay (continued)
construction, transport, and communica-
tions; 22% other services; unemployment
more than 15% (1984 est.)
Organized labor: government authorized
non-Communist union activities in 1981 for
the first time since 1973 military takeover','f26cf1dd2d0b214095ac0d2cd2b496060bd10a462a070c85bb3b4021c76d6960','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('168764599ef4bea834f673adb927b7a8b8bef783c1774c30b16556e3419a7f55',1985,'VU','Vanuatu','people-and-society',574,'Population: 134,000 (July 1985), average an-
nual growth rate 2.7%
Nationality; noun—Vanuatuan(s); adjec-
tive—Vanuatuan
Ethnic divisions: 90% indigenous Melane-
sian; 8% French; remainder Vietnamese,
Chinese, and various Pacific Islanders
Religion: most at least nominally Christian
Language: English and French (official); pid-
gin (known as Bislama or Bichelama)
Literacy: probably 10-20%
Population: 1,000 (July 1985), average an-
nual growth rate 0.1%
Ethnic divisions: primarily Italians but also
many other nationalities
Religion: Roman Catholic
Language: Italian, Latin, and various other
languages
Literacy: 100%
Labor force: approx. 700; Vatican City em-
ployees divided into three categories—
executives, office workers, and salaried em-
ployees
Organized labor: none
Population: 17,810,000 (July 1985), average
annual growth rate 3%
Nationality: noun—Venezuelan(s); adjec-
tive—Venezuelan
Ethnic divisions: 67% mestizo, 21% white,
10% black, 2% Indian
Religion: 96% nominally Roman Catholic,
2% Protestant
Language: Spanish (official); Indian dialects
spoken by about 200,000 Amerindians in the
remote interior
Literacy: 85.6%
Labor force: 5.5 million (1984); 27% services;
22% commerce; 16% agriculture; 16% manu-
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
facturing; 9% construction; 7% transporta-
tion; 3% petroleum, utilities, and other
Organized labor: 32% of labor force','2e905f88a9807662fc3744ae1079e8cd0a2b1ba402af6d4b1edac40241a3dba8','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e23e92285ddd3c99273b96c280c863338bd64b9b3977c8656ee0a17c22c4555',1985,'WF','Wallis and Futuna','people-and-society',578,'Population: 12,000 July 1985) average an-
nual growth rate 2.5%
Nationality: noun—Wallisian(s), Futunan(s),
or Wallis and Futuna Islanders; adjective—
Wallisian, Futunan, or Wallis and Futuna Is-
lander
Ethnic divisions: almost entirely Polynesian
Religion: largely Roman Catholic','ae3d87cccf0828ddb24c2d34552f5f537a39c8c05a9c9a479b31ad038fc0f242','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e737ddf6386975eeab3fb5cfdfb74a8d6b19c2c90c952d739a6f8eb67792bca',1985,'EH','Western Sahara','people-and-society',582,'Population: 91,000 (July 1985), average an-
nual growth rate 1.8%
Nationality: noun—Saharan(s), Moroccan(s);
adjective—Saharan, Moroccan
Ethnic divisions: Arab and Berber
Religion: Muslim
Language: Hassaniya Arabic, Moroccan Ar-
abic
Literacy: among Moroccans, probably nearly
20%; among Saharans, perhaps 5%
Labor force: 12,000; 50% animal husbandry
and subsistence farming, 50% other
Organized labor: none
Population: 163,000 (July 1985), average an-
nual growth rate 0.9%
Nationality: noun—Western Samoan(s); ad-
jective—Western Samoa
Ethnic divisions: Samoan; about 12,000
Euronesians (persons of European and Poly-
nesian blood), 700 Europeans
Religion: 99.7% Christian (about half of
population associated with the London Mis-
sionary Society; includes Congregational,
Roman Catholic, Methodist, Latter Day
Saints, Seventh Day Adventist)
Language: Samoan (Polynesian), English
Literacy: 90%
Labor force: about 37,000 (1983); about
22,000 employed in agriculture
249
Organized labor: none
Population: 6,058,000 (July 1985), average
annual growth rate 2.7%
Nationality: noun—Yemeni(s); adjective—
Yemeni
Ethnic divisions: 90% Arab, 10% Afro-Arab
(mixed)
Religion: 100% Muslim (Sunni and Shia)
Language: Arabic
Literacy: 15% (est.)
Labor force: approximately one-third ex-
patriate laborers; remainder almost entirely
agriculture and herding','c09ce9bb713d8a289ad427b99c989af92b2040788d87d4d5daf16a50ef16171a','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d964c474ccc52768dcb1fc3b2f9728f2e12c27d62dace06c47ae86523b08155',1985,'YE','Yemen','people-and-society',586,'Population: 2,211,000, excluding the islands
of Perim and Kamaran, for which no data are
available (July 1985); average annual growth
rate 2.9%
Nationality: noun—Yemeni(s); adjective—
Yemeni
Ethnic divisions: almost all Arabs; a few Indi-
ans, Somalis, and Europeans
Religion: Sunni Muslim, some Christian and
Hindu
Language: Arabic
Literacy: 25%
251
" Population: 23,137,000 (July 1985), average
annual growth rate —0.7%
Nationality: noun—Yugoslav(s); adjective—
Yugoslav
Ethnic divisions: 36.2% Serb, 19.7% Croat,
8.9% Muslim, 7.8% Slovene, 7.7% Albanian,
5.9% Macedonian, 5.4% Yugoslav, 2.5% Mon-
tenegrin, 1.9% Hungarian, 4.0% other (1981
census)
Religion: 41% Serbian Orthodox, 32% Ro-
man Catholic, 12% Muslim, 3% other, 12%
none (1953 census; later information unavail-
able)
Language: Serbo-Croatian, Slovene, Mac-
edonian (all official); Albanian, Hungarian,
Italian
Literacy: 85%
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Labor force: 9.7 million (1983); 29% agricul-
ture, 24% mining and manufacturing, 11%
noneconomic activities; (est.) unemployment
about 15% of domestic labor force
Population: 32,985,000 (July 1985), average
annual growth rate 2.9%
Nationality: noun—Zairian(s); adjective—
Zairian
Ethnic divisions: over 200 African ethnic
groups, the majority are Bantu; four largest
tribes—Mongo, Luba, Kongo (all Bantu), and
the Mangbetu-Azande (Hamitic) make up
about 45% of the population
Religion: 50% Roman Catholic, 20% Protes-
tant, 10% Kimbanguist, 10% Muslim, 10%
other syncretic sects and traditional beliefs
Language: French (official), English, Lin-
gala, Swahili, Kingwana, Kikongo, and
Tshiluba
Literacy: 40% males, 15% females
Labor force: about 8 million, but only about
13% in wage structure
254','296f2f0fb1b143e8063b24fbd5223098a4ef626c43dd7bb9afb52fc15b882251','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7789eeaae37645b105a6820634d982de7c8320c206f4264fc37f6901bd7ff5bb',1985,'ZM','Zambia','people-and-society',590,'Population: 6,770,000 (July 1985), average
annual growth rate 3.2%
Nationality: noun—Zambian(s); adjective—
Zambian
Ethnic divisions: 98.7% African, 1.1% Euro-
pean, 0.2% other
Religion: 50-75% Christian, 1% Muslim and
Hindu, remainder indigenous beliefs
Language: English (official); about 70 indige-
nous languages
Literacy: 54%
Labor force: 402,000 wage earners; 375,000
Africans, 27,000 non-Africans; 23% govern-
ment and miscellaneous services, 19%
construction, 15% mining, 10% manufactur-
ing, 9% agriculture, 9% domestic service, 9%
commerce, 6% transport
Organized labor: approximately 238,000
wage earners are unionized
Approved For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Approved F For Release 2011/02/09 : CIA-RDP86S00596R000200790001-2
Zambia (continued)','29f0a0b379beb569683e6a5b9035a4252fdb8c33035729358fa4e431919e0de4','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc4651d2711fc97213d02ba6c69866f6808b337f3c78a1507d6f6dc6965a89da',1985,'ZW','Zimbabwe','people-and-society',594,'Population: 8,667,000 (July 1985), average
annual growth rate 3.3%
Nationality: noun—Zimbabwean(s); adjec-
tive—Zimbabwean
Ethnic divisions: about 97% African (over
77% members of Shona-speaking subtribes,
19% speak Ndebele); about 3% white, 1%
mixed and Asian
Religion: 50% syncretic (part Christian, part
indigenous beliefs), 25% Christian, 24% in-
digenous beliefs, a few Muslim
Language: English (official); ChiShona and
Si Ndebele
Literacy: 45-55%
Labor force: 1,048,000 (1981); 35% agricul-
ture; 25% mining, manufacturing,
construction; 40% transport and services
Organized labor: about one-third of Euro-
pean wage earners are unionized, but only a
small minority of Africans
Population: 19,358,000, excluding the popu-
lation of Quemoy and Matsu Islands and
foreigners (July 1985), average annual
growth rate 1.5%
Nationality: noun—Chinese (sing., pl.); ad-
jective—Chinese
Ethnic divisions: 84% Taiwanese, 14% main-
land Chinese, 2% aborigine
Religion: 93% mixture of Buddhist, Confu-
cian, and Taoist; 4.5% Christian; 2.5% other
Language: Mandarin Chinese (official); Tai-
wanese and Hakka dialects-also used
Literacy: about 89.7%
Labor force: 7,266,000 (1983); 19% agricul-
ture, 40% industry and commerce, 30%
258
services, 7% civil administration, 1.6% unem-
ployment (1983)
Organized labor: about 15% of 1978 labor
force (government controlled)
Population: total, 1,443,000 (July 1985); av-
erage annual growth rate 2.7%; West Bank
(including East Jerusalem)—930,000 (July
1984), average annual growth rate 3.3%;
Gaza Strip—508,000 (July 1984), average an-
nual growth rate 3.7%
Nationality: West Bank—to be determined;
Gaza Strip—to be determined
Ethnic divisions: West Bank—84% Palestin-
ian Arab and other, 12% Jewish, 4% Bedouin;
Gaza Strip—-99.8% Palestinian Arab and
other, 0.2% Jewish
Religion: West Bank—80% Muslim (pre-
dominantly Sunni), 12% Jewish, 7% Christian
and other; Gaza Strip—99% Muslim (pre-
dominantly Sunni), 0.8% Christian, 0.2%
Jewish
Language:
West Bank: Arabic; Israeli settlers speak He-
brew; English widely understood
Gaza Strip: Arabic; Israeli settlers speak He-
brew; English widely understood
Literacy: West Bank—statistics unavailable;
Gaza Strip—statistics unavailable
Labor force:
West Bank: (excluding Israeli Jewish settlers)
29.6% small industry, commerce, and busi-
ness; 24.7% construction; 22.6% agriculture;
and 23.1% service and other (1983)
Gaza Strip: (excluding Israeli Jewish settlers)
30.7% small industry, commerce and busi-
260
ness; 26.1% construction; 25.2% service and
other; and 18.0% agriculture','eeae45113f11d2cdc471723d28a8f5b35ba5d5aff84ebc5519f9189303265615','internet-archive','cia-readingroom-document-cia-rdp86s00596r000200790001-2','txt','9ee4a91d75c9c29a914b64737c3b3684bf0cf799162b53e0f57a846b8eee285d','https://archive.org/download/cia-readingroom-document-cia-rdp86s00596r000200790001-2/cia-rdp86s00596r000200790001-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c0b1596aa091f5a13ea6911bcfdc04b27152c032edeaea9dd410a942f574fec',1985,'AF','Afghanistan','people-and-society',8,'Population: 14,792,000 (July 1985), average
annual growth rate 1.7%; these estimates in-
clude an adjustment for emigration to
Pakistan during recent years, but they do not
take into account other demographic conse-
quences of the Soviet intervention in
Nationality: noun—Afghan(s); adjective—
Afghan
Ethnic divisions: 50% Pashtun, 25% Taiik,
9% Uzbek, 9% Hazara; minor ethnic groups
include Chahar Aimaks, Turkmen, Baluchi,
and others
Religion: 74% Sunni Muslim, 25% Shi''a Mus-
lim, 1% other
Language: 50% Pashtu, 35% Afghan Persian
(Dari), 11% Turkic languages (primarily
Uzbek and Turkmen), 10% thirty minor lan-
guages (primarily Baluchi and Pashai); much
bilingualism
Literacy: 12%
Labor force: 4.98 million (1980 est.); 67.8%
agriculture and animal husbandry, 10.2% in-
dustry, 6.3% construction, 5.0% commerce,
7.7% services and other; current figures un-
available because of fighting (1984)
Organized labor: government-controlled
unions are being established','41ff1381f3f6e744838a589fd72493c00b68aeea1d6d862bfd0d8fd94fc4f109','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46f4b74eed3ee7637df89ce36782cb84fc1073b01e38e422d798cb9e42f4ea92',1985,'AL','Albania','people-and-society',13,'Population: 2,968,000 (July 1985), average
annual growth rate 2.2%
Nationality: noun—Albanian(s); adjective—
Albanian
Ethnic divisions: 96% Albanian; remaining
4% are Greeks, Vlachs, Gypsies, and
Bulgarians
Religion: Albania claims to be the world’s
first atheist state; prewar est. 70% Muslim,
20% Albanian Orthodox, 10% Roman Catho-
lic; observances prohibited
Language: Albanian (Tosk is official dialect),
Greek
Literacy: 75%
Labor force: 584,000 (1978); about 22% agri-
culture, 40% industry and commerce, 38%
other (1978)','793fef58b981321472a20d1e80de18d376bde2ed2eb41b49253d39eba533f861','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fbf26795749b0005bc09c687eddcf9b64209aee71397336c0d399b2a46316ee2',1985,'DZ','Algeria','people-and-society',17,'Population: 22,025,000 (July 1985), average
annual growth rate 3.1%
Nationality: noun—Algerian(s); adjective—
Algerian
Ethnic divisions: 99% Arab-Berbers, less
than 1% Europeans
Religion: 99% Sunni Muslim (state religion):
1% Christian and Jewish
Language: Arabic (official), French, Berber
dialects
Literacy: 46%
Labor force: 3.7 million (198-4); 40% industry
and commerce, 30% agriculture, 17% gov-
ernment, 10% services; at least 11% of urban
labor unemployed
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Algeria (continued)
Organized labor: 16-19% of labor force
claimed; General Union of Algerian Workers
(UGTA) is the only labor organization and is
subordinate to the National Liberation Front','f5cc445341bf85f87b839ea595c532a336acfe6a117a2698bc97334ad833fa50','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c0297b51cf16ac3c2a35a634466e9c35971d65b48903b639b255a1156db59b9',1985,'AD','Andorra','people-and-society',21,'Population: 47,000 (July 1985), average an-
nual growth rate 5.4%
Nationality: noun—Andorran(s); adjec-
tive—Andorran
Ethnic divisions: Catalan stock; 61% Spanish,
30% Andorran, 6% French, 3% other
Religion: virtually all Roman Catholic
Language: Catalan (official); many also
speak some French and Castilian
Literacy: 100%
Labor force: unorganized (unions prohib-
ited); largely shepherds and farmers','6dbbf8e70329007f8d95bcc2bec9d64ec0669ec7d7090d7e66b5a4f592840250','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5724136b3e3ea18cbb1821b315b4e07ee32459c6e9d5e588880914c2393c4011',1985,'AO','Angola','people-and-society',25,'Population: 7,953,000, including Cabinda
(July 1985), average annual growth rate 2.7%;
Cabinda, 129,000 (July 1985), average annual
growth rate 3.2%
Nationality: noun—Angolan(s); adjective—
Angolan
Ethnic divisions: 38% Ovimbundu, 23%
Kimbundu, 13% Bakongo, 2% Mestico, 1%
European
Religion: 68% Roman Catholic, 20% Protes-
tant, about 10% indigenous beliefs
Language: Portuguese (official); various
Bantu dialects ‘
Literacy: 20%
Labor force: 1,865,000 economically active
(mid-1980 est.); 60% agriculture, 15%
industry:
Organized labor: approx. 450,695 (1980)','449ad9653a03803b1a9c4e4687e046364e51d36a7314cb8e36dad248710d2b29','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04c27641ff553dbd9e736f32a9c25b1b710210c3dc27059086f7647d243e1415',1985,'AI','Anguilla','people-and-society',29,'Population: 7,000 (1982 est.)
Nationality: noun—Anguillan(s); adjec-
tive—Anguillan
Ethnic divisions: mainly of African Negro
descent
Religion: Anglican and Methodist
Language: English (official)
Literacy: 80%
Labor force: 2,000 Anguillans living overseas
send remittances home; high unemployment
(40% in 1977)
Organized labor: none','62feb2954a4bd182427daaece05997bf3a7545570af5d8261ef6e9b6159701fa','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4049e9b8ddf5334a85f0deb2f3dd6d2709e8bafc904d0b99aeeb5cded795377f',1985,'AG','Antigua and Barbuda','people-and-society',33,'Population: 80,000 (July 1985), average an-
nual growth rate 0%
Nationality: noun—Antiguan(s); adjective
Antiguan
Ethnic divisions: almost entirely African
Negro
Religion: Anglican (predominant), other
Protestant sects, some Roman Catholic
Language: English
Literacy: about 88%
Organized labor: 18,000, 22-26% unemploy-
ment (1983 est.)','ff28fe4bc02038f680c708d914c56aff1d9f8e359deb89f3dffd56bc6281cbdf','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('087dc1d6f08970a42c1e58112633a39eb6f9a626e0caca5e21d71599ab635fb6',1985,'AR','Argentina','people-and-society',37,'Population: 30,708,000 Guly 1985), average
annual growth rate 1.6%
Nationality: noun—Argentine(s); adjec-
tive—Argentine
Ethnic divisions: approximately 85% white,
15% mestizo, Indian, or other nonwhite
groups
Religion: 90% nominally Roman Catholic
(less than 20% practicing), 2% Protestant, 2%
Jewish, 6% other
Language: Spanish (official), English, Italian,
German, French
Literacy: 94%
\\
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Argentina (continued)
Labor force: 11.2 million (1982 est.); 19% ag-
riculture, 25% manufacturing, 20% services,
11% commerce, 6% transport and communi-
cations, 19% other; 6% estimated unem-
ployment (1982 est.)
Organized labor: 25% of labor force (est.)','4e9ddabcb8008d7464e47f8d45b3e5457301c2d2bf5e868fb03c5759aa1df132','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f3f0fac6e0700b6384a788d2fae614020424253f35764b0366273cc234095f4',1985,'AU','Australia','people-and-society',41,'Population: 15,658,000 (July 1985), average
annual growth rate 1.3%
Nationality: noun—Australian(s); adjec-
tive—Australian
Ethnic divisions: 99% Caucasian, 1% Asian
and aborigine
Religion: 27.7% Anglican, 25.7% Roman
Catholic, 25.2% other Protestant
Language: English, native languages
Literacy: 98.5%
Labor force: 7.2 million (November 1984);
8.7% unemployment (December 1984)
Organized labor: 57% of total employees
(December 1982)
ll
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7','90173043aa27bef6b841313877c7d0478744856b92d7547dbe9b356659e5d2d6','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d3644333308cfe824e6184dce27cd3012acaa90dee53841da0ef4dfed54c81f',1985,'AT','Austria','people-and-society',45,'Population: 7,540,000 (July: 1985), average
annual growth rate 0%
Nationality: noun— Austrians); adjective—
Austrian
Ethnic divisions: 99.4% German, 0.3% Cro-
atian, 0.2% Slovene, 0.1% other
Religion: 88° Roman Catholic, 6% Protes-
tant, 6% none or other
Language: German
Literacy: 98°
Labor force: 2.9 million (1983): 41.1% indus-
try and crafts, 57.55% services, 1.35%
agriculture and forestry; 4.1% unemployed
(October 1984); an estimated 200,000 Austri-
ans are employed in other European
countries; foreign laborers in Austria number
142.080 (1984)
Organised labor: 61.4% of wage and salary
workers (1983)
Population: 232,000 (July 1985), average an-
nual growth rate 2.0%
Nationality: noun—Bahamian(s); adjec-
tive—Bahamian
Ethnic divisions: 85% black, 15% white
Religion: Baptist 29%, Anglican 23%, Roman
Catholic 22%, smaller groups of other Protes-
tants, Greek Orthodox, and Jews
Language: English; some Creole among
Haitian immigrants
Literacy: 89%
Labor force: 82,000 (1982); 30% government,
25% hotels and restaurants, 10% business ser-
vices, 6% agriculture; 30% unemployment
(1983)
Organized labor: 25% organized
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7','16104582415b21f848f3f4e56b6d3b73f1ddcc904a00ee27a28d1bca3498c152','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b012908da20bc76514830d0a14d7fed5dc17cd20009fc5f5f1ad0f620232575',1985,'BH','Bahrain','people-and-society',52,'Population: 427,000 July 1985), average an-
nual growth rate 3.8%
Nationality: noun—Bahraini(s); adjective—
Bahraini
Ethnic divisions: 63% Bahraini, 13% Asian,
10% other Arab, 8 Tranian, 6° other
Religion: Muslim (60% Shi''a, 40% Sunni)
Language: Arabic (official), English also
widely spoken: Farsi, Urdu
Literacy: 40%
Labor force: 140,000 (1982): 42% of labor
force is Bahraini: 85° industry and com-
merce, 5% agriculture, 5% services, 3%','b9e3f6b9d27c592c7e8ecd3ccb31e081b7316da42c049d0b31c411fc5c7334f7','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e50323f3b7ec2713fa3d28847ce417028e2e0a47a88ea6263b588fc7b0f262b',1985,'BD','Bangladesh','people-and-society',57,'Population: 101,408,000 (July 1985), average
annual growth rate 2.8%
Nationality: noun—Bangladeshi(s); adiec-
tive—Bangladesh
Ethnic divisions: 98% Bengali; 250,000
“Biharis” and fewer than one million tribals
Religion: 83% Muslim, about 16% Hindu, less
than 1% Buddhist, Christian, and other
Language: Bangla (official), English widely
used
Literacy: 25%
Labor force: 32.4 million (FY83); extensive
export of labor to Saudi Arabia, UAE, Oman,
and Kuwait; 74% of labor force is in agricul-
ture, 15% services, 11% industry and
commerce (FY81/82)
17
es proved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7','1e156632595e4839bdce60ff220ba44a064f63898dc32790568140eb5f09cbdf','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61059a395cfe8975695412c2b62443ed46a3b621db40d412e00a2325996c2d55',1985,'BB','Barbados','people-and-society',61,'Population: 252,000 (July 1985), average an-
nual growth rate 0.3%
Nationality: noun—Barbadian(s); adiec-
tive—Barbadian
Ethnic divisions: 80% African, 16% mixed,
4% European
Religion: 70% Anglican, 9% Methodist, 4%
Roman Catholic, 17% other, including Mora-
vian
Language: English
Literacy: 99%
Labor force: 103,900 (1982); 65.6% services
and government, 24.6% industry and com-
merce, 9.8% agriculture; 11% unemploy-
ment (1979)
Organized labor: 32%
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7','26e6db77229190442766a5cb99adf4d923fc64f1bc443a68259263795fec1e12','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ecd4ef5ff84bf4caf7ea696ef89661e91445bf310ea5d041c7ad04e527e15d2',1985,'BE','Belgium','people-and-society',65,'Population: 9,856,000 (July 1985), average
annual growth rate 0%
Nationality: noun—Belgian(s); adjective—
Belgian
Ethnic divisions: 55% Fleming, 33% Wal-
loon, 12% mixed or other
Religion: 75% Roman Catholic, remainder
Protestant, none, or other
Language: 56% Flemish (Dutch), 32%
French, 1% German; 11% legally bilingual;
divided along ethnic lines
Literacy: 98%
Labor force: 4 million (1983); 36% transporta-
tion, 33% industry and commerce, 21%
public services, 2.3% agriculture; 11% unem-
ployed (1983)
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Organized labor: 70% of labor force
Population: 161,000 (July 1985), average an-
nual growth rate 2.3%
Nationality: noun—Belizean(s); adjective—
Belizean
Ethnic divisions: 51% black, 22% mestizo,
19% Amerindian, 8% other ''
Religion: 50% Roman Catholic; Anglican,
Seventh-Day Adventist, Methodist, Baptist,
Jehovah''s Witnesses, Mennonite
Language: English (official), Spanish Maya’
Carib :
Literacy: over 80%
Labor force: 51,500 (1984); 30% agriculture,
16% services, 15.4% government, 11.2% com-
merce, 10.3% manufacturing; shortage of
skilled labor and all types of technical person-
nel; over 14% are unemployed
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Belize (continued)
Organized labor: 15% of labor force','1bfc52df9a73dc901b4479aebbbbd80ae52bf316ac98b50cb120fa8aabd21761','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26dc38e8e72f4b10afba0631cd1b49bfe1e8c9da44c164b794a29c3fe6391dd1',1985,'BJ','Benin','people-and-society',69,'Population: 4,015,000 (July 1985), average
annual growth rate 3.1%
Nationality: noun—Beninese (sing., pl.); ad-
jective—Beninese
Ethnic divisions: 99% African (42 ethnic
groups, most important being Fon, Adia,
Yoruba, Bariba); 5,500 Europeans
Religion: 70% animist, 15% Muslim, 15%
Christian
Language: French (official); Fon and Yoruba
most common vernaculars in south; at least
six major tribal languages in north
Literacy: 20%
Labor force: 1.5 million (1982); 70% of labor
force employed in agriculture; less than 2% of
the labor force work in the industrial sector,
and the remainder are employed in trans-
port, commerce, and public services
Organized labor: approximately 75% of
wage earners, divided among two maior and
several minor unions','b4242c8c73674abff33c2b436e0ba50b28797d913e90d931c2ab192e3934090b','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('601031afc925d8494c5597c9b5b673e423b28948b3a7ca309ddc0b2add4276d6',1985,'BM','Bermuda','people-and-society',73,'Population: 58,000 (July 1985), average an-
nual growth rate 0.5%
Nationality: noun—Bermudian(s); adjec-
tive—Bermudian
Ethnic divisions: 61% black, 39% white and
other
Religion: 37% Anglican, 21% other Protes-
tant, 28% Catholic, 28% Black Muslim and
other
Language: English
Literacy: 98%
Labor force: 29,669 employed (1980); 25%
clerical, 22% services, 22% laborers, 13% pro-
fessional and technical, 9% administrative
and managerial, 7% sales, 2% agriculture and
fishing
24','6de3b202f8a7533d6a6fe1ee84ed326beb8f19451399187a74659ce34aa30a3c','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0093f94253a6fea50a7fa44d7abd72546b05a2cc8fa942315097eeb5fd2ca1b0',1985,'BT','Bhutan','people-and-society',78,'Population: 1,417,000 (July 1985), average
annual growth rate 2.1%
Nationality: noun—Bhutanese (sing., pl.);
adjective—Bhutanese
Ethnic divisions: 60% Bhote, 25% ethnic
Nepalese, 15% indigenous or migrant tribes
Religion: 75% Lamaistic Buddhism, 25%
Buddhist-influenced Hinduism
Language: Bhotes speak various Tibetan dia-
lects—most widely spoken dialect is
Dzongkha (official); Nepalese speak various
Nepalese dialects
Literacy: 5%
Labor force: 95% agriculture, 1% industry
and commerce (1983); massive lack of skilled
labor
Population: 6,195,000 (July 1985), average
annual growth rate 2.6%
Nationality: noun—Bolivian(s), adjective
Bolivian
Ethnic divisions: 30% Quechua, 25% Ay-
mara, 25-30% mixed, 5-15%. European
Religion: 95% Roman Catholic; active Prot-
estant minority, especially Methodist
Language: Spanish, Quechua, and Aymara
(all official)
Literacy: est. 75%
Labor force: 1.7 million (1983); 47% agricul-
ture, 23% services, 19% industry and
commerce, 11% government
Organized labor: 150,000-200,000, concen-
trated in mining, industry, construction, and','d23ce1f9cd6b0052b62fac8d25fd1de338697eb4d59f24cded08b7a7ce337d18','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5afb8586a2ad4caccb82464491ba02afbd609017b99d3f3bda3362590e09afa',1985,'BW','Botswana','people-and-society',82,'Population: 1,068,000 (July 1985), average
annual growth rate 3.3%
Nationality: noun—Motswana (sing.),
Batswana (pl.); adjective—Botswana .
Ethnic divisions: 94% Tswana, 5% Bushmen,
1% European
Religion: 40% indigenous beliefs, 15% Chris-
tian
Language: English (official), Setswana
vernacular
Literacy: about 24% in English; about 35% in
Tswana; less than 1% secondary school grad-
uates
Labor force: about 400,000 total; 103,600 for-
mal sector employees (1980-81); most others
are engaged in cattle raising and subsistence
agriculture; 40,000 formal sector employees
spend at least six to nine months per year as
wage earners in South Africa (1980); 12% un-
employment (1983)
Organized labor: 16 trade unions organized
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Botswana (continued)','837bf73947275c7d89fd4c6b95c2acf5d30c5e7d0ca9b6e1c88ba6978b8b6277','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55c5e08c2f29b8b834324465729688fd09cccffeacb2c94528661044a5a02a2b',1985,'BR','Brazil','people-and-society',86,'Population: 137,502,000 (July 1985), average
annual growth rate 2.38%
Nationality: noun—Brazilian(s); adjective—
Brazilian
Ethnic divisions: Portuguese, Italian, Ger-
man, Japanese, black, Amerindian; 55%
white, 38% mixed, 6% black, 1% other
Religion: (1980) 89% Roman Catholic (nomi-
nal) ;
Language: Portuguese (official)
Literacy: 74%
Labor force: about 50 million in 1982, 29.9%
agriculture, livestock, forestry, and fishing;
24.4% industry; 20.3% services, transporta-
tion, and communication; 9.4% commerce;
7.0% social activities; 4.1% public adminis-
tration; 2.9% other; significant
underemployment and unemployment
Organized labor: about 6 million (1982)
Population: 221,000 (July 1985), average an-
nual growth rate 3.3%
Nationality: noun—Bruneian(s); adjective—
Bruneian
Ethnic divisions: 70% Malay, 25% Chinese,
5% other
Religion: 60% Muslim (Islam official reli-
gion); 8% Christian; 32% other (Buddhist and
animist)
Language: Malay official; English and Chi-
nese
Literacy: 45%
Labor force: 68,128 (includes members of the -
Army); 63% trade and services; 23% manu-
facturing and construction; 11% agriculture,
forestry, fishing, and mining (1981)
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Organized labor: 2% of labor force','ef04fa589a126ab843482c9fe7ecd5951aaddab141c1e068641877934269ec8b','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('375cdcea8ac802b096989ecdebccf98dec164e2ec9572088a81dbf931a0f8126',1985,'BG','Bulgaria','people-and-society',90,'Population: 8, 980, 000 (July 1985), average
annual growth rate 0.2%
Nationality: noun—Bulgarian(s), adjec-
tive—Bulgarian
Ethnic divisions: 85.3% Bulgarian, 8.5%
Turk, 2.6% Gypsy, 2.5% Macedonian, 0.3%
Armenian, 0.2% Russian, 0.6% other
Religion: regime promotes atheism; religious
background of population is 85% Bulgarian
Orthodox, 13% Muslim, 0.8% Jewish, 0.7%
Roman Catholic, 0.5% Protestant, Grego-
rian-Armenian and other
Language: Bulgarian; secondary languages
closely correspond to ethnic breakdown
Literacy: 95% (est.)
Labor force: 3,997,615 (1983); 42.6% indus-
try and commerce, 23.3% agriculture, 1.5%
government, 32.6% other','99c5b79c2d7794d7ce98fd01110ee9a859b7c14647284c92568a8d196c37b8a3','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7afe5d8e74f398c841e65177fc4f700d629ab312c1f59bd94ad16c6152c307a7',1985,'BF','Burkina Faso','people-and-society',94,'Population: 6,907,000 (July 1985), average
annual growth rate 2.5%
Nationality: noun—Burkinabe; adjective—
Burkinan
Ethnic divisions: more than 50 tribes; princi-
pal tribe is Mossi (about 2.5 million); other
important groups are Gurunsi, Senufo, Lobi,
Bobo, Mande, and Fulani
Religion: 65% indigenous beliefs, about 25%
Muslim, 10% Christian (mainly Catholic)
Language: French (official); tribal languages
belong to Sudanic family, spoken by 50% of
the population
Literacy: 7%
Labor force: 90% agriculture; 10% industry,
commerce, services, and government; about
30,000 are wage earners; about 20% of male
labor force migrates annually to neighboring
countries for seasonal employment
Organized labor: four principal trade union
groups represent less than 1% of population
83
Population: 36,919,000 (July 1985), average
annual growth rate 2.0%
Nationality: noun—Burmese; adjective—
Burmese
Ethnic divisions: 72% Burman, 7% Karen,
6% Shan, 6% Indian, 3% Chinese, 2% Kachin,
2% Chin, 2% other
Religion: 85% Buddhist, 15% indigenous be-
liefs, Christian, or other
Language: Burmese; minority ethnic groups
have their own languages
Literacy: 78%
Labor force: 14.19 million (1982/83); 63.6%
agriculture, 12% government, 9.5% trade,
9.4% industry, 5.5% other
: CIA-RDP90T01298R000200050001-7
Organized labor: Workers’ Asiayone or
“association” (1.56 million members) and
‘Peasants’ Asiayone (7.83 million members)
integrated into the country’s sole political
party','2b6107b8a4f70b11b020e2ce33ae8ae53b43122a172aacdbdbe3227f8f2011fc','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87c34af2ae9a08bc63a94e24e0f120beaaf310d22816f2202fe9999f01e2cee2',1985,'BI','Burundi','people-and-society',98,'Population: 4,788,000 (July 1985), average
annual growth rate 2.6% :
Nationality: noun—Burundian(s); adjec-
tive—Burundi
Ethnic divisions: Africans—85% Hutu
(Bantu), 14% Tutsi (Hamitic), 1% Twa
(Pygmy); other Africans include around
70,000 refugees, mostly Rwandans and Zair-
ians; non-Africans include about 3,000
Europeans and 2,000 South Asians
Religion: about 67% Christian (62% Roman
Catholic, 5% Protestant), 32% indigenous be-
liefs, about 1% Muslim
Language: Kirundi and French (official),
Swahili (along Lake Tanganyika and in the
Bujumbura area) °
Literacy: 25%
Labor force: about 1.9 million (1983); 93%
agriculture, 4% government, 1.5% industry
and commerce, 1.5% services
Organized labor: sole group is the Union of
Burundi Workers (UTB); by charter, mem-
bership is extended to all Burundi workers
(informally); figures denoting “‘active |
membership” have been unobtainable','588c0af743250f3411256a3362f3e5073ae96e2613845dbf27fa18f646755625','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0db684bfc0298e3c7670f2677130cd145e699a52d7053d5eab894c3bb2067374',1985,'TH','Thailand','people-and-society',103,'Population: 6,249,000 (July 1985), average
annual growth rate 2.1%
Nationality: noun—Cambodian(s); adiec-
tive—Cambodian
Ethnic divisions: 90% Khmer (Cambodian),
5% Chinese, 5% other minorities
Religion: 95% Theravada Buddhism, 5%
other
Language: Khmer (official), French
Literacy: 48%
Population: 52,700,000 (July 1985), average
annual growth rate 1.9%
Nationality: noun—Thai (sing. and pl.); ad- —
jective—Thai
Ethnic divisions: 75% Thai, 14% Chinese,
11% other
Religion: 95.5% Buddhist, 4% Muslim, 0.5%
other
Language: Thai; English secondary language
of elite; ethnic and regional dialects
Literacy: 84%
Labor force: 23.4 million (1981 est.); 76% ag-
riculture, 9% industry and commerce, 9%
services, 6% government
Population: 60,492,000 (July 1985), average
annual growth rate 2.4%
Nationality: noun—Vietnamese (sing. and
pl.); adjective— Vietnamese
Ethnic divisions: 85-90% predominantly
Vietnamese; 3% Chinese; ethnic minorities
include Muong, Thai, Meo, Khmer, Man,
Cham; other mountain tribes
Religion: Buddhist, Confucian, Taoist, Ro-
man Catholic, indigenous beliefs, Islamic,
and Protestant
Language: Vietnamese (official), French,
Chinese, English, Khmer, tribal languages
(Mon-Khmer and Malayo-Polynesian)
Literacy: 78%
246
Labor force: approximately 29 million, not
including military','298245b83b5c7a695ca06e708dfa59ef3288f8bfb5f54b3f8db35d89c5abfe21','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc930a2e817397b5847cb8b760fe0d863c8433db9f9c28db3cbf4118fa5a4f40',1985,'CM','Cameroon','people-and-society',107,'Population: 9,771,000 (July 1985), average
annual growth rate 2.7%
Nationality: noun—Cameroonian(s); adjec-
tive—Cameroonian
Ethnic divisions: over 200 tribes of widely
differing background; 31% Cameroon High-
landers, 19% Equatorial Bantu, 11% Kirdi,
10% Fulani, 8% Northwestern Bantu, 7%
Eastern Nigritic, 18% other African, less than
1% non-African
Religion: over one-half indigenous beliefs,
one-third Christian, one-sixth Muslim
Language: English and French (official), 24
major African language groups
Literacy: 65%
Labor force: (1983) 74.4% agriculture, 11.4%
industry and transport, 9.7% other services
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Organized labor: under 45% of wage labor
force','9c4d856653d48a020242694e8c79f4810c393bb5ae4bc31eb2530a51a33d19b9','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9885c6a68e9669a882cd2eeaccbe0c92d0dd8fe7412d444c6205cbb42631fec',1985,'CA','Canada','people-and-society',111,'Population: 25,399,000 (July 1985), average
annual growth rate 1.0%
Nationality: noun—Canadian(s); adjec-
tive—Canadian
Ethnic divisions: 45% British Isles origin,
29% French origin, 23% other European,
1.5% indigenous Indian and Eskimo
Religion: 46% Roman Catholic, 18% United
Church, 12% Anglican
Language: English and French official
Literacy: 99%
Labor force: 12.2 million (December 1983),
68% services (37% government, 23% trade
and finance, 8% transportation), 18% manu-
facturing, 6% construction, 4% agriculture,
5% other; 11.9% unemployment (1983 aver-
age); 11.1% unemployment (December 1983)
Organized labor: 33% of labor force
Population: 315,000 (July 1985), average an-
nual growth rate 2.0%
Nationality: noun—Cape Verdean(s); adjec-
tive—Cape Verdean
Ethnic divisions: about 71% Creole (mu-
latto); 28% African; 1% European
Religion: Catholicism, fused with local su-
perstitions
Language: Portuguese and Crioulo, a blend
of Portuguese and West African words
Literacy: 37%
Labor force: bulk of population engaged in
subsistence agriculture','1c29f7669c51377d77d59e8ca0a243d8f97bf35b3feeb8e55337c0844fe6dc6f','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89ad50ba7741fa0d685ac5ec70b7a12051f9c633eafa2ba9337712cb38023ef1',1985,'CF','Central African Republic','people-and-society',115,'Population: 2,667,000 (July 1985), average
annual growth rate 2.8% ° :
Nationality: noun—Central African(s); ad-
jective—Central African
Ethnic divisions: approximately 80 ethnic
groups, the majority of which have related -
ethnic and linguistic characteristics; 34%
Baya, 28% Banda, 10% Sara, 9% Mandijia, 9%
Mboum, 7% M’Baka; 6,500 Europeans, of
whom 3,600 are French
Religion: 25% Protestant, 25% Roman Cath-
olic, 24% indigenous beliefs, 10% Muslim;
animistic beliefs and practices strongly influ-
ence the Christian majority -
Language: French (official), Sangho, lingua
franca and national language
Literacy: est. 33%
Labor force: 1,320,000 (1983), 88% agricul-
ture, 4% industry and commerce, 4%
services, 4% government; approximately
64,000 salaried workers
Organized labor: 1% of labor force
CIA-RDP90T01298R000200050001-7','220839489053f909e006ce659fce3a1f87e3dba4c1b32680a5dbb269eab7a6a3','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('601ae93f14e28c7dbc8ca3ca3b1f19feb55392765ba139776ad1b772cf9f70e9',1985,'TD','Chad','people-and-society',119,'Population: 5,246,000 (July 1985), average
annual growth rate 2.5%
Nationality: noun—Chadian(s); adjective—
Chadian
Ethnic divisions: some 200 distinct ethnic
groups, including Muslims (Arabs, Toubou,
Fulani, Kotoko, Hausa, Kanembou, ,
Baguirmi, Boulala, and Maba) in the north
and center and non-Muslims (Sara, Mayo-
Kebbi, and Chari) in the south; some 150,000
nonindigenous, 3,000 of them French
Religion: 52% Muslim, 43% indigenous be-
liefs, 5% Christian
Language: French official; Chadian Arabic
is lingua franca in north, Sara and Sangho in
south; more than 100 different languages and
dialects are spoken
Literacy: about 20%
Labor force: 85% agriculture (engaged in un-
paid subsistence farming, herding, and
fishing)
Organized labor: about 20% of wage labor
force','845a7f10428b4116aa4ea7c22591dffc256ca10d22c3804fd4f1751461c19ea3','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc200f60a5396a8ff3430cd629e0ae19836fbf5f13e7eac6340c4767f18782c1',1985,'CL','Chile','people-and-society',123,'Population: 11,882,000 (July 1985), average
annual growth rate 1.5%
Nationality: noun—Chilean(s), adjective—
Chilean
Ethnic divisions: 95% European and Euro-
pean-Indian, 3% Indian, 2% other
Religion: 89% Roman Catholic, 11% Protes-
tant
Language: Spanish
Literacy: 90% (1978)
Labor force: 3.0 million total employment
(1982); 33% industry and commerce; 31% ser-
vices; 9% agriculture, forestry, and fishing;
9% mining; 5% construction
45
Organized labor: 12% of labor force orga-
nized into labor unions (1982)','d49e784575fe941c2ec0ee728e3b32a70fc93f6363b2d5d191403b16ced4a14d','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a08b496277d7134f81a706460f63aeb72c4993b3ba3f319116569bc5262096df',1985,'CN','China','people-and-society',127,'Population: 1,041,346,000 (July 1985), aver-
age annual growth rate 0.9%
Nationality: noun—Chinese (sing., pl.); ad-
jective—Chinese
Ethnic divisions: 93.3% Han Chinese; 6.7%
Zhuang, Uygur, Hui, Yi, Tibetan, Miao,
Manchu, Mongol, Buyi, Korean, and numer-
ous lesser nationalities
Religion: officially atheist; most people, even _
before 1949, have been pragmatic and eclec-
tic, not seriously religious; most important
elements of religion are Confucianism, Tao-
ism, Buddhism, ancestor worship; about 2-
3% Muslim, 1% Christian
Language: Standard Chinese (Putonghua) or
Mandarin (based on the Beijing dialect); also
Yue (Cantonese), Wu (Shanghainese), Minbei
(Fuzhou), Minnan (Hokkien-Taiwanese),
Xiang, Gan, Hakka dialects, and minority
languages (see ethnic divisions)
Literacy: over 75%
Labor force: est. 447.1 million (December
1983); 74.4% agriculture, 15% industry and
commerce, 10.6% other','06690f5962f4fcfd46d2c1676943d27e50ce39e47937557e951e83c12a293f3d','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('708a851ec9b06a882032636c10a7b29b410174a0f06214b34292cbecbdccab51',1985,'CO','Colombia','people-and-society',131,'Population: 29,506,000 (July 1985), average
annual growth rate 2.1%
Nationality: noun—Colombian(s); adjec-
tive—Colombian
Ethnic divisions: 58% mestizo, 20% Cauca-
sian, 14% mulatto, 4% black, 3% mixed black-
Indian, 1% Indian
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 81%
Labor force: 9 million (1982); 53% services,
26% agriculture, 21% industry (1980); 14%
official unemployment (1984)
Organized labor: 1,418,321 members (1982)
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7','2ba5a867bfa7cdf69f311884b206ec6f908e17167aca8f308a546356ac469c3b','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66b561b124615dc087efcdc9bfafb57b897b3b7e382eba4ccce0c65e6ab26829',1985,'YT','Mayotte','people-and-society',135,'Population: 469,000 (July 1985), average an-
nual growth rate 2.9%
Nationality: noun—-Comoran(s); adjective—
Comoran
Ethnic divisions: Antalote, Cafre, Makoa,
Oimatsaha, Sakalava
Religion: 86% Sunni Muslim, 14% Roman
Catholic
Language: Shaafi Islam (a Swahili dialect),
Malagasy, French
Literacy: 15%
Labor force: 140,000 (1982); 87% agriculture,
3% government; significant unemployment','84eaed22ff8ba860ff6576ebac7985f4a450a50dfaa2aace6b74f515f69cf3de','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fec6e5cb03d2ebd7ece46a93e3a03301bcc333c07ddf716a21a795f632e1fe65',1985,'CG','Congo','people-and-society',139,'Population: 1,798,000 (July 1985), average
annual growth rate 3.0%
Nationality: noun—Congolese (sing., pl.);
adjective—Congolese or Congo
Ethnic divisions: about 15 ethnic groups di-
vided into some 75 tribes, almost all Bantu;
most important ethnic groups are Kongo
(48%) in south, Sangha (20%) and M’Bochi
(12%) in north, Teke (17%) in center; about
8,500 Europeans, mostly French
Religion: 48% animist, 47% Christian, 2%
Muslim
Language: French (official); many African
languages with Lingala and Kikongo most
widely used
Literacy: over 50%
Labor force: about 40% of population eco-
nomically active (1983); 75% agriculture,
25% commerce, industry, government;
79,100 wage earners; 40,000-60,000 unem-
ployed
Organized labor: 20% of total labor force
(1979 est.)','fac9888142e297ed9d4e6a3909adaf26c93e6e50d89bb4ee5580c0cbc974c29f','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2eb81eb997f4afa2141c575fc53944dade5bac45038271643f79c17236eda7f1',1985,'CK','Cook Islands','people-and-society',143,'Population: 17,000 (July 1985), average an-
nual growth rate —0.7%
Nationality: noun—Cook Islander(s); adjec-
tive—Cook Islander
Ethnic divisions: 81.8% Polynesian (full
blood),.7.7% Polynesian and European, 7.7%
Polynesian and other, 2.4% European, 0.9%
other
Religion: Christian, majority of populace
members of Cook Islands Christian Church','5c15bac357d14c0c9ed6cfac05f8858fd8205da6b001fb0209332cbba9dbe401','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7456520ba11b243fa7995426be80a09547a08777cdf9528650e05e8d9968a1a',1985,'CR','Costa Rica','people-and-society',147,'Population: 2,655,000 (July 1985), average
annual growth rate 2.5%
Nationality: noun—Costa Rican(s); adjec-
tive—Costa Rican
Ethnic divisions: 96% white (including mes-
tizo), 3% black, 1% Indian
Religion: 95% Roman Catholic
Language: Spanish (official), with Jamaican
dialect of English spoken around Puerto
Limén
Literacy: 938%
Labor force: 891,000 (1982 est.); 40.4% indus-
try and commerce, 32.6% agriculture, 25%
53
government and services, 2% other; 9.5% un-
employment (1984 official); 15% unem-
ployment (1984 unofficial)
Organized labor: about 13.8% of labor force','7b6001d3bf1c5c3a1bec09df37ff94f09227b291c932251086d6d5fcf0287cd0','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d435c522de636bce7ee02536795d0799944dcb64641981d93ea7de43d6ce5a4',1985,'CU','Cuba','people-and-society',151,'Population: 10,105,000 (July 1985), average
annual growth rate 1.1%
Nationality: noun—Cuban(s); adjective—
Cuban
Ethnic divisions: 51% mulatto, 37% white,
11% black, 1% Chinese
Religion: at least 85% nominally Roman
Catholic before Castro assumed power
Language: Spanish
Literacy: 96%
Labor force: 3.0 million in 1982; 28% ser-
vices, 21% industry, 20% agriculture, 11%
commerce, 9% construction, 7% transporta-
tion and communication, 4% other','f0df6beafe036bde65c82df9262c9d61a017acec5d97a9c7514f6dfc32d37184','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ca1e8344f982b0fc85ae320f7baf10b2621f2225950f5dc74c953e2c533d44d',1985,'CY','Cyprus','people-and-society',155,'Population: 670,000 (July 1985), average an-
nual growth rate 1.3%
Nationality: noun—Cypriot(s), adiective—
Cypriot
Ethnic divisions: 78% Greek; 18% Turkish;
4% Armenian, Maronite, and other
Religion: 78% Greek Orthodox; 18% Muslim;
4% Maronite, Armenian, Apostolic, and other
Language: Greek, Turkish, English
Literacy: about 89%
Greek Sector labor force: 240,900 (1982); 42%
services, 33% industry, 22% agriculture; 3.1%
unemployed
Population: 15,503,000 (July 1985), average
annual growth rate 0.3%
Nationality: noun—Czechoslovak(s); adjec-
tive—Czechoslovak
Ethnic divisions: 64.3% Czech, 30.5% Slo-
vak, 3.8% Hungarian, 0.4% German, 0.4%
Polish, 0.8% Ukrainian, 0.1% Russian, 0.2%
other (Jewish, Gypsy)
Religion: 77% Roman Catholic, 20% Protes-
tant, 2% Orthodox, 1% other
Language: Czech and Slovak (official), Hun-
garian
Literacy: 99%
Labor force: 7.8 million; 38.1% industry;
12.5% agriculture; 49.4% construction, com-
munications, and other (1982)','f43c0b6ef6099f4d501c2d1a88b49013e61d43b2833fa71ec77432be161af8b0','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ff4e8c85d782aca9274ac302298526f7f104922c3946d1dfcb4e1b06888494b',1985,'DK','Denmark','people-and-society',159,'Population: 5,109,000 (July 1985), average
annual growth rate —0.1%
Nationality: noun—Dane(s); adjective—
Danish
Ethnic divisions: Scandinavian, Eskimo,
Faroese, German
Religion: 97% Evangelical Lutheran, 2%
other Protestant and Roman Catholic, 1%
other
Language: Danish, Faroese, Greenlandic (an
Eskimo dialect); small German-speaking mi-
nority
Literacy: 99%
Labor force: 2,700,000 (1983 average); 34.1%
social services; 21% manufacturing; 13.3%
commerce; 8.2% agriculture, forestry, and
59
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
fishing; 7.9% construction; 7.0% banking and
business services; 6.8% transportation; 9.2%
unemployment rate
Organized labor: 65% of labor force','31f1cd3bd996104cc150c27e8ee52a03683594d0f7e3069f72bdc69059806a47','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3384ab4f129c700bd6dae7e84b0b39f59a3bb8c0d537f0510bca4d523f0d5a1e',1985,'DJ','Djibouti','people-and-society',163,'Population: 297,000 (July 1985), average an-
nual growth rate 2.6%
Nationality: noun——Djiboutian(s); adjec-
tive—Djiboutian
Ethnic divisions: 60% Somali (Issa), 35%
Afar, 5% French, Arab, Ethiopian, and Ital-
ian :
Religion: 94% Muslim, 6% Christian
Language: French (official), Somali and Afar
widely used
Literacy: 20%
Labor force: a small number of semiskilled
laborers at port
Organized labor: some 3,000 railway work-
ers organized','53639d282a02ab41aa243ef987d0a4d15842f63728beea721cc955defb3834b9','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba38c29ae6d47768937dd9fb1011ff945a57fb04e9132ac2df2e2e84bc0669f2',1985,'DM','Dominica','people-and-society',167,'Population: 74,000 (July 1985), average an-
nual growth rate —0.2%
Nationality: noun—Dominican(s); adjec-
tive—Dominican
Ethnic divisions: mostly black; some Carib-
Indians
Religion: 80% Roman Catholic; Anglican,
Methodist
Language: English (official); French patois
widely spoken
Literacy: about 95%
Labor force: 23,000; 40% agriculture, 32% in-
dustry and commerce, 28% services; 15-20%
unemployment
Organized labor: 25% of the labor force','781a796f89f037e11be87ea68e767d9e3072b327fc3da7080b5e57150045fd6b','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5432476adccd5380bcb7e4c5a6ccd2fa03270b1dc22910c7b5b276a3c9fd660',1985,'DO','Dominican Republic','people-and-society',171,'Population: 6,588,000 (July 1985), average
annual growth rate 2.7%
Nationality: noun—Dominican(s); adjec-
tive—Dominican
Ethnic divisions: 73% mixed, 16% white,
11% black
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 68%
Labor force: 1.2 million; 47% agriculture,
23% industry and commerce, 16% govern-
ment, 14% services
Organized labor: 12% of labor force','7072d02a67aad6ab7682e2cc32e8489380128ea755496e62ad3ec8178ebdcc90','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a02898a6e79d079124c2a3c96452fdb8bb2e82bba0f56b8ff971e10f7f10e24',1985,'EC','Ecuador','people-and-society',175,'Population: 8,884,000 (July 1985), average
annual growth rate 2.7%
Nationality: noun—Ecuadorean(s); adiec-
tive—Ecuadorean
Ethnic divisions: 55% mestizo (mixed Indian
and Spanish), 25% Indian, 10% Spanish, 10%
black
Religion: 95% Roman Catholic (majority
nonpracticing)
Language: Spanish (official); Indian dialects,
especially Quechua
Literacy: 84%
64
Labor force: (1983) 2.8 million; 52% agricul-
ture, 13% manufacturing, 7% commerce, 4%
construction, 4% public administration, 16%
other services and activities
Organized labor: less than 15% of labor force','2ca39509e803af292e146127495766220d4383917a66ecc84bd91ef34986993c','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2aabd982070b0b29799449f83c6d56cae270f3fda7ec782bdf0f2a895bfeaf70',1985,'EG','Egypt','people-and-society',179,'Population: 48,305,000 (July 1985), average
annual growth rate 2.6% ;
Nationality: noun—Egyptian(s); adjective—
Egyptian or Arab Republic of Egypt
Ethnic divisions: 90% Eastern Hamitic stock;
10% Greek, Italian, Syro-Lebanese -
Religion: (official estimate) 94% Muslim
(mostly Sunni), 6% Coptic Christian and
other
Language: Arabic (official); English and
French widely understood by educated
classes
Literacy: 40%
Labor force: 13.4 million; 45-50% agricul-
ture, 13% industry, 11% trade and finance,
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
26% services and other; shortage of skilled la-
bor; unemployment about 7%
Organized labor: 1 to 3 million','9438173bf560d491e617b5a339b7f104fcb3019e1221ed70457f9af87ad77df2','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('045d774ad31e7d660f7bad99f1c41f12a6aeee95efb1ebd2390b15b9a4a49388',1985,'LY','Libya','people-and-society',183,'Population: 5,072,000 (July 1985), average
annual growth rate 2.8%
Nationality: noun—Salvadoran(s), adjec-
tive—Salvadoran
Ethnic divisions: 89% mestizo, 10% Indian,
1% white
Religion: predominantly Roman Catholic
(probably 97-98%), with activity by Protes-
tant groups throughout the country
Language: Spanish, Nahua (among some In-
dians)
Literacy: 65%
Labor force: 1.7 million (est. 1982); 25% agri-
culture, 16% manufacturing, 16%
commerce, 13% government, 9% financial
67
Ne ADDroved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
El Salvador (continued)
services, 6% transportation, 15% other (1984
est.); shortage of skilled labor and large pool
of unskilled labor, but manpower training
programs improving situation; significant
unemployment
Organized labor: 8% total labor force; 10%
agricultural labor force; 7% urban labor force
(1982)
Population: 4,003,000 (July 1985), average
annual growth rate 6.5%
Nationality: noun—Libyan(s), adjective—
Libyan
Ethnic divisions: 97% Berber and Arab with
some black stock; some Greeks, Maltese,
Jews, Italians, Egyptians, Pakistanis, Turks,
Indians, and Tunisians
Religion: 97% Sunni Muslim
Language: Arabic; Italian and English
widely understood in major cities
Literacy: 50%
Labor force: 1.5 million, of which about
550,000 are resident foreigners
136
Government ag
Official name: Socialist People’ s Libyan
tak omaha :
Type: aediite major overhaul! ‘of: the’ con-
stitution and government structure in March
1977 established a‘system of popular con--
gresses, which theoretically controls the °
ule General Secretariat a3 2
Capital: Tripoli
Political pibaemods 10 tetas
provinces closely controlled by central gov-
ernment =?
Legal system: based on Italian civil law sys-
tem and Islamic law; separate religious’ ‘’
courts; no constitutional provision for judicial
review of legislative acts; legal education at
Law School at University of Libya at Ben-
ghazi; has not accepted compulsory Ic]
jurisdiction
National holiday: Independence Day, 1 =e
tember °
Branches: paramount political power and
authority rests with the Secretariat of the
General People’s Congress, which theoreti-
cally functions as a parliament with a cabinet
called the General People’s Committee
Government leaders: Col. Mu‘ammar Abu
-Minyar al- QADHAFI (no official title; runs
country aind is treated as chief of state; Miftah
al-Ista ‘UMAR, Secretary of the General
People’s Congress (chief of state in theory but
not treated : as such)
Suffrage: teal adult
Elections: representatives to the General
People’s Congress are drawn from popularly
elected municipal committees
a es >
Political parties: none
Communists: no organized party, negligible
membership :
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Other political or pressure groups: various
Arab nationalist movements and the Arab So-
cialist Resurrection (Ba‘th) party with almost
negligible memberships may be functioning
clandestinely
Member of: AfDB, Arab League, FAO, G-77,
IAEA, IBRD, ICAO, IDA, IDB—Islamic
Development Bank, IFAD, IFC, ILO, IMF,
IMO, INTELSAT, INTERPOL, IOOC, ITU,
NAM, OAPEC, OAU, OIC, OPEC, UN,
UNESCO, UPU, WHO, WIPO, WMO, WSG','ef5a1d0caa03f0b40baf3067f1ae6f2a78ed67d2e331fb151a5de1e7f4cb2261','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9664bf91e65d965eca178dc4e6c599d3632658f4d99d2360d136486bb65565a',1985,'GQ','Equatorial Guinea','people-and-society',186,'Population: 282,000 (July 1985), average an-
nual growth rate 2.5% Rio Muni—212,000
(July 1985), average annual growth rate 2.5%:
Fernando Po—71,000 (July 1985), average
annual growth rate 2.5%
Nationality: noun—Equatorial Guinean(s);
adjective—Equatorial Guinean
Ethnic divisions: indigenous population of
Bioko, primarily Bubi, some Fernaridinos; of
Rio Muni, primarily Fang; less than 1,000
Europeans, primarily Spanish
Religion: natives all nominally Christian and
predominantly Roman Catholic; some pagan
practices retained
Language: Spanish (official), pidgin English,
Fang
Literacy: 55%
69
Labor force: most Equatorial Guineans in-
volved in subsistence agriculture; labor
shortages on plantations','4d61b6fdeae7b147676d2bc189987639cf302248cee30d45314747c8e31bedcc','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11fa9547082a67d4701429ce336d6e3c236ffcdb18453c72ae83691595d84fa8',1985,'ET','Ethiopia','people-and-society',191,'Population: 42,289,000 (July 1985), average
annual growth rate 0.7%
. Nationality; noun—Ethiopian(s); adjec-
tive—Ethiopian
Ethnic divisions: 40% Oromo, 32% Amhara
and Tigrean, 9% Sidamo, 6% Shankella, 6%
Somali, 4% Afar, 2% Gurage, 1% other
Religion: 40-45% Muslim, 35-40% Ethiopian
Orthodox, 15-20% animist, 5% other
Language: Amharic (official), Tigrinya,
Orominga, Arabic, English (major foreign
language taught in schools)
Literacy: about 15%
70
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Labor force: 90% agriculture and animal hus-
bandry; 10% government, military, and
quasi-government
Organized labor: All Ethiopian Trade Union
formed by the government in January 1977
to represent 273,000 registered trade union
members
Population: 2,000 (July 1985), average an-
nual growth rate 0%
Nationality: noun—Falkland Islander(s); ad-
jective—Falkland Island
Ethnic divisions: almost totally British .
Religion: predominantly Anglican
Language: English .
Literacy: compulsory education up to age 14
Labor force: 1,100 (est.); est. over 95% in agri-
culture, mostly sheepherding
~ Branches: Civil Commissioner (replaced gov-','44fcdf55b0696c9991584240a4f63ea5ff1a784ff17e7b91c60a54cccb9b9862','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39c520feff5a8f0c1931262d3ae02897454b27b366c60575b0ba10317982d852',1985,'FO','Faroe Islands','people-and-society',195,'Population: 46,000 (July 1985), average an-
nual growth rate 1.0%
Nationality: noun—Faroese (sing., pl.); ad-
jective—Faroese
Ethnic divisions: homogeneous white popu-
lation
Religion: Evangelical Lutheran
Language: Faroese (derived from Old
Norse), Danish
Literacy: 99%
Labor force: 17,585; largely engaged in fish-
ing, manufacturing, transportation, and
commerce','e9bcf5ca6a8e6b86469c32a0c0f0f03e68626e2d01fdb98bd7d6314d7c1795d9','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8f1823104eda07783828766a0418f92771f48a02b02512837f20780448f09db',1985,'FJ','Fiji','people-and-society',199,'Population: 700,000 (July 1985), average an-
nual growth rate 2.1%
Nationality: noun—Fijian(s); adjective— .
Fijian
Ethnic divisions: 50% Indian, 45% Fijian; 5%
European, other Pacific Islanders; overseas
Chinese, and others
Religion: Fijians are mainly Christian, Indi-
ans are Hindu with a Muslim minority
Language: English (official), Fijian, Hindu-
stani spoken among Indians
Literacy: 80%
Labor force: 176,000 (1979); 43.8% agricul-
ture, 15.6% industry
Organized labor: about 50% of labor force
organized into about 60 unions; unions orga-
nized along lines of work and ethnic origin','f3c97501ab64fa83fba9bb368fa1e8f46fac06cd84dd9ba0070c3c55e5a4f94c','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bce5266f36f29a0f04cdf4643d7cbcea26e8d64a63c03d97f74238332b704f6',1985,'FI','Finland','people-and-society',203,'Population: 4,894,000 (July 1985), average
annual growth rate 0.4%
Nationality: noun—Finn(s); adjective—
Finnish
Ethnic divisions: Finn, Swede, Lapp, Gypsy,
Tatar
Religion: 97% Evangelical Lutheran, 1.2%
Greek Orthodox, 1.8% other
Language: 93.5% Finnish, 6.3% Swedish
(both official); small Lapp- and Russian-
speaking minorities
Literacy: almost 100%
Labor force: 2.546 million; 23.8% mining and
manufacturing; 25.4% services; 18.5% com-
merce; 11.9% agriculture, forestry, and
75
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
fishing; 7.2% construction; 7.0% transporta-
tion and communications; 6.1% unemployed
(1983 average)
Organized labor: 80% of labor force','4e5c2f816deea2e42393b287dd2bcb87a134e23438cb1f89d55f4b43e2856a5a','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f68e8d9eec7905b0660e006fe59b9e7197c5374e3e866a47628535013ecdf4b',1985,'FR','France','people-and-society',207,'Population: 55,094,000 (July 1985), average
annual growth rate 0.4%
Nationality: noun—Frenchman (men); ad-
jective—French
Ethnic divisions: Celtic and Latin with Teu-
tonic, Slavic, North African, Indochinese,
and Basque minorities
Religion: 90% Roman Catholic, 2% Protes-
tant, 1% Jewish, 1% Muslim (North African
workers), 6% unaffiliated
Language: French (100% of population); rap-
idly declining regional patois—Provencal,
Breton, Germanic, Corsican, Catalan,
Basque, Flemish
Literacy: 99%
Labor force: 23.4 million (1983); 54.5% ser-
vices, 29.5% industry, 8.5% agriculture; 8.5%
unemployed
Organized labor: approximately 20% of la-
bor force','5d8d48e6a8c4a752ba55735e90840c8acb9b7a6300a1d4d1b098d1a54ef1f50e','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6ba064081c85824cf533c556265e5441e12b4b8e5a05be558ff17f88234928f',1985,'GF','French Guiana','people-and-society',211,'Population: 82,000 (July 1985), average an-
nual growth rate 2.9%
Nationality: noun—French Guianese (sing.,
pl.); adjective—French Guiana
Ethnic divisions: 66% black or mulatto; 12%
Caucasian; 12% East Indian, Chinese, Amer-
indian; 10% other
Religion: predominantly Roman Catholic
Language: French
Literacy: 73%
Labor force: 23,265 (1980); services, govern-
ment, and commerce 60.6%; industry 21.2%;
agriculture 18.2%; information on unem-
ployment unavailable
Organized labor: 7% of labor force
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7','19277cac006ce03ff2c7023600acae90118f54a48052de84e1170ee7b6607974','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e328ba4fecf8660250cfb0d22252b173f67161f8aebc0fc28a44bd95f28a4f03',1985,'PF','French Polynesia','people-and-society',215,'Population: 166,000 (July 1985), average an-
nual growth rate 2.3%
Nationality: noun—French Polynesian(s);
adjective—French Polynesian
Ethnic divisions: 78% Polynesian, 12% Chi-~
nese, 6% local French, 4% metropolitan ,
rench
Religion: mainly Christian; 55% Protestant,
32% Catholic','a69f1dbe029af2924700d9403ad1ef632341c79cac761d371f4cca7eb52191be','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c162cd7709fe246ccdfe65e346592e7a10ff785440ee7ec67cf66003b75fc28',1985,'GA','Gabon','people-and-society',219,'Population: 988,000 (July 1985), average an-
nual growth rate 3.1%
Nationality: noun—Gabonese (sing., pl.); ad-
jective—Gabonese
Ethnic divisions: about 40 Bantu tribes, in-
cluding 4 major tribal groupings (Fang,
Eshira, Bapounou, Bateke); about 100,000 ex-
patriate Africans and Europeans, including
35,000 French
Religion: 55-75% Christian, less than 1%
Muslim, remainder animist
Language: French (official); Fang, Myene,
Bateke
Literacy: 65%
Labor force: 120,000 salaried (1983); 65% ag-
riculture, 30% industry and commerce, 2.5%
services, 2.5% government
Organized labor: there are 38,000 members
of the national trade union, the Gabonese
Trade Union Confederation (COSYGA)
Population: 751,000 (July 1985), average an-
nual growth rate 3.5%
Nationality: noun—Gambian(s); adjective—
Gambian
Ethnic divisions: 90% African (37.7%
Mandinka 16.2% Fula, 14% Wolof, 8.5% Jola,
7.8% Serahuli, 5.3% other), 10.5% non-Gam-
bian
Religion: 85% Muslim, 14% Christian, 1% in-
digenous beliefs
Language: English (official); Mandinka, Wo-
lof, Fula, other indigenous vernaculars
Literacy: about 15%
Labor force: 378,850 (1980 est.); 75% agricul-
ture; 18.9% industry, commerce, and
services; 6.1% government
82
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
‘ Organized labor: 25-30% of wage labor force
at most
Population: 16,701,000, including East Ber-
lin July 1985), average annual growth rate
0.0%
Nationality: noun—German(s); adjective—
German
Ethnic divisions: 99.7% German, 0.3% Slavic
and other
Religion: 47% Protestant, 7% Roman Catho-
lic, 46% unaffiliated or other; less than 5% of
Protestants and about 25% of Roman Catho-
lics active participants
Language: German, small Sorb (West Slavic)
minority
Literacy: 99%
A rove For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
German Democratic
Republic (continued)
Labor force: 8.87 million; 37.9% industry,
20.7% services, 10.7% commerce, 10.1% agri-
culture, 7.4% transport and communications,
6.9% construction, 3.1% handicrafts, 3.2%
other (1983)
Organized labor: 87.7% of total labor force
Population: 61,132,000, including West Ber-
lin July 1985), average annual growth
rate—0.2%
Nationality: noun—German(s); adjective—
German
Ethnic divisions: primarily German; Danish
minority
Religion: 45% Roman Catholic, 44% Protes-
tant, 11% other
Language: German
Literacy: 99%
Labor force: 25.668 million (1982); 33.8%
manufacturing, 29.2% services, 16.8% gov-
ernment, 5.9% construction, 5.4%
85
agriculture, 1.7% other; 9.2% unemployed
(February 1985)
Organized labor: 37% of total labor force;
46.4% of wage and salary earners (1982)','67f436d83e9c71aa54a1deb356d8bc7fc8a6328b04405ac510c5cf3ff3f1a157','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f041ea7fc7af2bde1ef25ed0c4659ab41ec09d57a13781f0d956bc6cbd44c337',1985,'GH','Ghana','people-and-society',223,'Population: 13,197,000 (July 1985), average
annual growth rate 3.0%
Nationality: noun—Ghanaian(s); adjec-
tive-—Ghanaian
Ethnic divisions: 99.8% black African (major
tribes Akan, Ewe, Ga), 0.2% European and
other
Religion: 42% Christian, 38% indigenous be-
liefs, 12% Muslim, 7% other
Language: English (official); African lan-
guages include 44% Akan, 16% Mole-
Dagbani, 18% Ewe, and 8% Ga-Adangbe
Literacy: 30%
Labor force: 3.7 million; 54.7% agriculture
and fishing; 18.7% industry; 15.2% sales and’
clerical; 7.7% services, transportation, and
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
communications; 3.7% professional; 400,000
unemployed
Organized labor: 467,000 or approximately
13% of labor force','45371ad96cfd498f4b21290d0db53db991f6def025d6ee077ce4a0de2d8e2880','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2212ed8fbc078c1f7a5cc3dfafbb167b7568fbecb66d72d83e2c849c0eb984f5',1985,'GI','Gibraltar','people-and-society',227,'Population: 31,000 (July 1985), average an-
nual growth rate 0.9%
Nationality: noun—Gibraltarian; adjec-
tive—Gibraltar
Ethnic divisions: mostly Italian, English,
Maltese, Portuguese, and Spanish descent
Religion: 75% Roman Catholic, 8% Church
of England, 2.25% Jewish
Language: English and Spanish are primary
languages; Italian, Portuguese, and Russian
also spoken; English used in the schools and
for all official purposes
Literacy: illiteracy is negligible
Labor force: approx. 14,800, including non-
Gibraltar laborers
Organized labor: over 6,000','8e4cd31d35ed27a9d016a42fb7aca7fa02219502c8b1c81c57cfca3abfcccb46','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c1d0691c334b508f38a7a59762e5ef717090f9f8ab8137b002209539c3c2508',1985,'GR','Greece','people-and-society',231,'Population: 9,966,000 (July 1985), average
annual growth rate 0.6%
Nationality: noun—Greek(s); adjective—_.
Greek
Ethnic divisions: 97.7% Greek, 1.3% Turk-
ish; 1.0% Vlach, Slav, Albanian, Pomach
Note: The Greek Government states that
there are no ethnic minorities in Greece
Religion: 98% Greek Orthodox, 1.3% Mus-
lim, 0.7% other
Language: Greek (official); English and
French widely understood
Literacy: 95%
Labor force: 3.7 million (1981 census); ap-
proximately 39% services, 31% agriculture,
80% industry; urban unemployment is esti-
89
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
mated at 10%; substantial unreported unem-
ployment exists in agriculture
Organized labor: 10-15% of total labor force,
20-25% of urban labor force
Population: 51,259,000 (July 1985), average
annual growth rate 2.1%
Nationality: noun—Turk(s); adiective—
Turkish
Ethnic divisions: 85% Turkish, 12% Kurd,
3% other
Religion: 98% Muslim (mostly Sunni), 2%
other (mostly Christian and Jewish)
Language: Turkish (official), Kurdish Arabic
Literacy: 70%
Labor force: 18.1 million (1983); 61% agricul-
ture, 27% service, 12% industry and
commerce; surplus of unskilled labor (1982)
Organized labor: 10-15% of labor force
232','a1e8dd8b327316d13f9f1642514c5744b46424f4a51ec89f0da2e220c225c197','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d08d7a90fcc8ae8aa4ab81f0f382ef58ed5dafecb51953cfa143edab0ce33ee',1985,'GL','Greenland','people-and-society',234,'Population: 54,000 (July 1985), average an-
nual growth rate 1.2%
Nationality: noun—Greenlander(s); adjec-
tive—Greenlandic
Ethnic divisions: 86% Greenlander (Eskimos
and Greenland-born whites), 14% Danish
Religion: Evangelical Lutheran
Language: Danish, Eskimo dialects
Literacy: 99%
Labor force: 21,378; largely engaged in fish-
ing, hunting, and sheep breeding','001ad07019a36f457e6b7bee21d32c3c9b941484eb48a0ffc1f34872f2102835','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76011a32001550c4bda8c5eba81d02bb6971cae171db8d57c3a7bb26f361a5a4',1985,'GP','Guadeloupe','people-and-society',240,'Population: 333,000 (July 1985), average an-
nual growth rate 0.4%
Nationality: noun—Guadeloupian(s); adiec-
tive—Guadeloupe
Ethnic divisions: 90% black or mulatto; 5%
Caucasian; less than 5% East Indian, Leba-
nese, Chinese
Religion: 95% Roman Catholic, 5% Hindu
and pagan African
Language: French, creole patois
Literacy: over 70%
Labor force: 120,000; services, government,
and commerce 53%; industry 25.8%; agricul-
ture 21.2%; significant unemployment
Organized labor: 11% of labor force
93','86c61187498562bc5413d09297879c3f133de12a4c9173ae869698b550a65b1d','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c3f4856641ff57b96412045f01b3f838b0dcf51d9f97f9517e5a5ed02af3e8e',1985,'HN','Honduras','people-and-society',244,'Population: 8,335,000 (July 1985), average
annual growth rate 3.1%
Nationality: noun—-Guatemalan(s); adjec-
tive—Guatemalan
Ethnic divisions: 58.6% Ladino (mestizo and
westernized Indian), 41.4% Indian
Religion: predominantly Roman Catholic;
also Protestant, traditional Mayan
Language: Spanish, but over 40% of the
population speaks an Indian language as a
primary tongue (18 Indian dialects, including
Quiche, Cakchiquel, Kekchi)
Literacy: 50%
Labor force (1984): 2.5 million; 57.0% agri-
culture, 14.0% manufacturing, 13.0%
services, 7.0% commerce, 4.0% construction,
3.0% transport, 0.8% utilities, 0.4% mining;
unemployment 33%
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Organized labor: 10% of labor force (1984)
Population: 4,394,000 (July 1985), average
annual growth rate 3.4%
Nationality: noun—Honduran(s); adjec-
tive—Honduran
Ethnic divisions: 90% mestizo (mixed Indian
and European), 7% Indian, 2% black, 1%
white
Religion: about 97% Roman Catholic; small
Protestant minority
Language: Spanish, Indian dialects
Literacy: 56%
Labor force: 1.2 million (1984); 54% agricul-
ture, 28% services, 13% manufacturing, 4%
construction, 1% other; 30% unemployed;
60% underemployed
Organized labor: 40% of urban labor force,
20% of rural work force (1981)
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Honduras (continued)','fa63290f7c6efa161427da1e3cbc1bacb974b2c3f8a76c87cfc40023d9316c61','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d2084f982b310ab40202ad6c71dc7c8922ec2160567289905eea97707a5f820',1985,'GN','Guinea','people-and-society',248,'Population: 5,734,000 (July 1985), average
annual growth rate 2.7%
Nationality: noun—Guinean(s); adjective—
Guinean
Ethnic divisions: Fulani, Malinke, Sousou, 15
smaller tribes
Religion: 75% Muslim, 24% indigenous be-
liefs, 1% Christian
Language: French (official); each tribe has
own language
Literacy: 20% in French; 48% in local lan-
guages
Labor force: 2.4 million (1983); 82% agricul-
ture, 11% industry and commerce, 5.4%
services, 1.6% government
96
Organized labor: virtually 100% of wage la-
bor force loosely affiliated with the National
Confederation of Guinean Workers
Population: 91,178,000 (July 1985), average
annual growth rate 3.4%
Nationality: noun—Nigerian(s); adjective—
Nigerian
Ethnic divisions: of the more than 250 tribal
groups, the Hausa and Fulani of the north,
the Yoruba of the southwest, and the Ibos of
the southeast comprise 65% of the popula-
tion; about 27,000 non-Africans
Religion: no exact figures on religious break-
down, but last census (1963) showed Nigeria
to be 47% Muslim, 34% Christian, and 18%
indigenous beliefs
Language: English (official); Hausa, Yoruba,
and Ibo also widely used
Literacy: 25-30%
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Nigeria (continued)
Labor force: est. 35-40 million (1983); 55%
agriculture; 17% industry, commerce, and
sérvices; 15% government
Organized labor: 3.52 million wage earners
belong to one of 42 recognized trade unions,
which are under a single national labor fed-
eration, the Nigerian Labor Congress (NLC)
Population: 88,000 (July 1985), average an-
nual growth rate 0.8%
Nationality: noun—Sao Tomean(s); adjec-
tive—Sao Tomean
Ethnic divisions: mestico, angolares (descen-
dents of Angolan slaves), forros (descendents
of freed slaves), servicais (contract laborers
from Angola, Mozambique, and Cape
Verde), tongas (children of servicais born on
the islands), and Europeans (primarily Portu-
guese)
Religion: Roman Catholic, Evangelical Prot-
estant, Seventh Day Adventist
Language: Portuguese (official)
Literacy: est. 50%
Labor force: most of population engaged in
subsistence agriculture and fishing; some un-
employment, but labor shortages on
plantations and for skilled work
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7','23e2e2053092e45a5ac6b3c11c35fd2365117055f58feba862ac9ad8b10f23b7','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('651d78f06e92283f0b76673e60b6a3133b14a28c31ad89d3381d7a314ed32037',1985,'GW','Guinea-Bissau','people-and-society',252,'Population: 858,000 (July 1985), average an-
nual growth rate 1.9%
Nationality: noun—Guinea-Bissauan(s); ad-
jective—Guinea-Bissauan
Ethnic divisions: about 99% African (30%
Balanta, 20% Fula, 14% Manjaca, 13%
Mandinga, 7% Papel); less than 1% European
and mulatto
Religion: 65% indigenous beliefs, 30% Mus-
lim, 5% Christian
Language: Portuguese (official), Criolo and
numerous African languages
Literacy: 9%
Labor force: 90% agriculture; 5% industry,
services, and commerce; 5% government
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
(continued)','4f46839473bec5484c74756a85691c374d2db18b6766c1a35337f981d452f84a','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21121bfc634d6f3911921ece7fdd7ea9e6ec5cac0fff48ec9c66ae491128b523',1985,'GY','Guyana','people-and-society',256,'Population: 798,000 (July 1985), average an-
nual growth rate 0.4%
Nationality: noun—Guyanese (sing., pl.); ad-
jective—Guyanese
Ethnic divisions: 51% East Indian, 43% black
and mixed, 4% Amerindian, 2% European
and Chinese
Religion: 57% Christian, 33% Hindu, 9%
Muslim, 1% other
Language: English, Amerindian dialects
Literacy: 85%
Labor force: 200,000 (1982), 44.5% industry
and commerce, 33.8% agriculture, 21.7% ser-
vices; 64% public sector employment;
approximately 21% unemployed
Organized labor: 34% of labor force','1f27dad3f6d48386ec2583c32a1180ba4558dfd39aae2be008adf54f86c7bb05','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('916b70a1b4f238adf8dba06f8bc08448691c38cbf823e93dc0ae8128296c4130',1985,'HT','Haiti','people-and-society',260,'Population: 5,762,000 (July 1985), average
annual growth rate 1.9%
Nationality: noun—Haitian(s), adjective—
Haitian
Ethnic divisions: 95% black, 5% mulatto and
European
Religion: 75-80% Roman Catholic (of which
an overwhelming majority also practice Voo-
doo), 10% Protestant
Language: French (official) spoken by only
10% of population; all speak Creole
Literacy: 23%
Labor force: 2.3 million (est. 1975); 79% agri-
culture, 14% services, 7% industry;
significant unemployment; shortage of
skilled labor; unskilled labor abundant
100
_ Capital: Port-au-Prince
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Organized: labor: less than 1% of labor force','f15f4cfabb5844c393afaa2b3b17c6938e6bc37733c68cfb7a9100a4a4f41299','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e624b83e21340012b4d267fc7919569fcf1054873711eba8c0af9e0135ec5e9',1985,'HK','Hong Kong','people-and-society',264,'Population: 5,491,000 (July 1985), average
annual growth rate 1.6%
Nationality: adjective—Hong Kong
Ethnic divisions: 98% Chinese, 2% other
Religion: 90% eclectic mixture of local reli-
gions, 10% Christian
Language: Chinese (Cantonese), English.
Literacy: 75%
Labor force: (June 1984) 2.52 million; 37.3%.
manufacturing; 22.1% commerce; 18.4% ser-
vices; 7.6% construction; 7.6% transport.and
communications; 5.4% financing: insuranee,.
and real estate; 1.2% agriculture, fishing,
mining, and quarrying; 0.4% other; unem-
ployment (seasonally adjusted) 3.6%
Organized labor: 15.2% of 1984 labor force
103','6e3e94d298aef1a8e2a2a8bcc3581c65197839c1655d72b56a3124b78f276aaf','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4073803a26d7a9737cc9f170eeeb24f246673ab216dee1482d206a0adb2b35c',1985,'HU','Hungary','people-and-society',268,'Population: 10,645,000 (July 1985), average
annual growth rate —0.2% |
Nationality: noun—Hungarian(s); adjec-
tive—Hungarian
Ethnic divisions: 92.4% Hungarian, 3.3%
Gypsy, 2.5% German, 0.7% Jewish, 1.1%
other
" Religion: 67.5% Roman Catholic, 20.0% Cal-
vinist, 5.0% Lutheran, 7.5% atheist and other
Language: 98.2% Hungarian, 1.8%. other
'' Literacy: 98%
"Labor force: 4,970,100 (1983); 32% industry;
22% agriculture; 46% services, trade, govern-
ment, and other','b2b5b37842993d7526ce0d058d44b2b142b432d34cbeaaa4f1b597c977c7c3eb','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c7bd3abaf397d904c6c70dcb30862e4d83d9cdbc895b6a72515e6162f403e61',1985,'IS','Iceland','people-and-society',272,'Population: 241,000 (July 1985), average an-
nual growth rate 1.0%
Nationality: noun—Icelander(s); adjective—
Icelandic
Ethnic divisions: homogeneous mixture of
descendants of Norwegians and Celts
Religion: 95% Evangelical Lutheran, 3%
other Protestant and Roman Catholic, 2% no
affiliation
Language: Icelandic
Literacy: 99.9%
Labor force: 105,000; 18.6% commerce, fi-
nance, and services; 12.2% construction; 9.0%
agriculture; 6.3% transportation and commu-
nications; 5.4% fishing; 8.0% fish processing;
16.8% other manufacturing; 23.7% other;
1.0% unemployment (1983 average) -
Organized labor: 60% of labor force','58bdca1fdb6ec21ee4f3b8c6b29fe2ec8991e3d4e04d87f438d0e0930d879b0a','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a99da8ed5f91fc1270b37420a40bf6c8456ac136a36157a89e4f714e8c440698',1985,'IN','India','people-and-society',276,'Population: 762,507,000, including Sikkim
and the Indian-held part of disputed Jammu
and Kashmir (July 1985); average annual
growth rate 2.1%
Nationality: noun—Indian(s); adjective—
Indian
Ethnic divisions: 72% Indo-Aryan, 25% Dra-
vidian, 3% Mongoloid and other
Religion: 83.5% Hindu, 11% Muslim, 2.6%
Christian, 2.0-2.5% Sikh, 0.7% Buddhist,
0.2% other
107
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Language: Hindi, English, and 14 other offi-
cial languages; 24 languages spoken by a
million or more persons each; numerous
other languages and dialects, for the most
part mutually unintelligible; Hindi is the na-
tional language and primary tongue of 30
percent of the people; English enjoys
“associate” status but is the most important
language for national, political, and commer-
cial communication; Hindustani, a popular
variant of Hindi/ Urdu, is spoken widely
throughout northern India
Literacy: 36%
Labor force: (1981) about 232 million; 67%
agriculture; more than 10% unemployed and
underemployed
Organized labor: less than 5% of total labor
force','ea0e63f7dbd8fa88c01d416d4ac50db898255f6d2944771f2d0afefcf4ab2e60','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f27f9d481c3e07f403a16cad91bc3287a960f0b6b18a8ac1f2b0bc6253a954da',1985,'ID','Indonesia','people-and-society',280,'Population: 173, 108, 000, including East Ti-
mor and West Irian (July 1985), average
annual growth rate 2.1%
Nationality: noun—Indonesian(s ); adjec-
tive—Indonesian | ‘
Ethnic diisions: majority of Malay stock
comprising 45% Javanese, 14% Sundanese,
7.5% Madurese, 7.5% coastal Malays, 26%
other
Religion:88% Muslim, 6% Protestant, 3% Ro-
man Catholic, 2% Hindu, 1% other
Language: Indonesian (modified form of
Malay; official), English and Dutch leading
foreign languages; local dialects, the most
widely spoken of which is Javanese
Literacy: 64%
Labor force: 61 million (1982); 66% agricul-
ture, 23% trade and commerce, 10% services
Organized labor: est. 5% of labor force
Population: 45,191,000 (July 1985, average
annual growth rate 3.1%; figures do not take
into account the impact of the Iran-Iraq war
Nationality: noun—Iranian(s); adjective—
Iranian
Ethnic divisions: 63% ethnic Persian, 18%
Turkic, 13% other Iranian, 3% Kurdish, 3%
Arab and other Semitic, 1% other
Religion: 938% Shi''a Muslim; 5% Sunni Mus-
lim; 2% Zoroastrian, Jewish, Christian, and
Bahai
Language: Farsi, Turki, Kurdish, Arabic,
English, French
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Literacy: 48%
Labor force: 12.0 million, est. (1979); 33% ag-
riculture, 21% manufacturing; shortage of
skilled labor; unemployment may be as high
as 359%','4265e80e7a8f1d4ca3e15e8063d34420be41a8a26e9719980be9e14109635178','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5766b38499e34b62519fb1c7bc29b0f735472e6be0a21562c2310d60df521c7a',1985,'IQ','Iraq','people-and-society',284,'Population: 15,507,000 (July 1985), a average
annual growth rate 3.8%; figures do not take
into account the impact of the Iran-Iraq war
Nationality: noun—Iraqi(s); adjective—
Iraqi ,
Ethnic divisions: 75% Arab, 15-20% Kurdish,
10% Turkic, Assyrian, and other
Religion: 90% Muslim (55% Sh''ia, 40%
Sunni), 10% Christian or other
Language: Arabic (official), Kurdish (official
in Kurdish regions); Assyrian, Armenian,
Literacy: about 50%
Labor force: 3.1 million (1977); 80% agricul-
ture, 27% industry, 21% government, 22%
other; severe labor shortage due to war; ex-
patriate labor force est. at 900,000
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Organized labor: 11% of labor force','95dfafdc775c3e15876c306300984a4fd4b2fd1f7baef9275259437aca3307b4','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('305bbdb55ae8e2dbe93ff36c914a088eec835a98c7c57212a95cc2ab4e340224',1985,'IE','Ireland','people-and-society',288,'Population: 3,590,000 (July 1985), average
annual growth rate 1.0%
Nationality: noun—Irishman(men), Irish
(collective pl.); adjective—Irish
Ethnic divisions: Celtic, with English minor-
ity
Religion: 94% Roman Catholic, 4% Anglican,
2% other *
Language: Irish (Gaelic) and English (offi-
cial); English is generally spoken
Literacy: 99%
Labor force: about 1,173,000 (1981); 19.6%
manufacturing; 17.8% agriculture, forestry,
fishing; 16.2% commerce; 8.3% construction;
5.8% government; 5.5% transportation;
26.8% other; 10.9% unemployment (average
1981)
118
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Organized labor: 36% of labor force','1b7dfe5ce361ab818593f5cab975715dda32be172a68e683547f5d15d26a5f66','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41132c36bed8d6f8a6a1a74a1fcd33ccd93dec5aa60fa66ebd65bd57b3e8ab8e',1985,'IL','Israel','people-and-society',292,'Population: 4,085,000, excluding West
Bank, Gaza Strip, and East Jerusalem (July
1985), average annual growth rate 1.6%
Nationality: noun—Israeli(s); adjective—
Israeli
Ethnic divisions: 85% Jewish, 15% non-Jew-
ish (mostly Arab)
Religion: 85% Judaism, 11% Islam, 4% Chris-
tian and other
Language: Hebrew official; Arabic used offi-
cially for Arab minority; English most
commonly used foreign language
Literacy: 88% Jews, 70% Arabs
Labor force: est. 1,400,000 (1984); 29.5%
public services; 22.8% industry, mining, and
- manufacturing; 12.8% commerce; 9.5% fi-
nance and business; 6.8% transport, storage,
and communications; 6.5% construction and
public works; 5.5% agriculture, forestry, and
fishing; 5.8% personal and other services;
1.0% electricity and water (1983); unemplay:
ment about 6% (1984 est.)
Organized labor: 90% of labor force','25f1d1ef1202b11cfdf3c23928bada553f06ea7ea2811637ab9056debc0c5713','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('945f5869ac331c244ef0f8eec82cea96a2fcb4d092b027a7369b102f6b6bc6e2',1985,'IT','Italy','people-and-society',296,'Population: 57,149,000 (July 1985), average
annual growth rate 0.3% -
Nationality: noun—lItalian(s); adjective—
Italian
Ethnic divisions: primarily Italian but popu-
lation includes small clusters of German-,
French-, and Slovene-Italians in the north
and of Albanian-Italians in the south
Religion: almost 100% nominally Roman
Catholic
Language: Italian; parts of Trentino-Alto
Adige region (for example, Bolzano) are pre-
dominantly German speaking; significant
French-speaking minority in Valle d’Aosta
region; Slovene-speaking minority in the
Trieste-Gorizia area
Literacy: 93%
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Labor force: 23,272,000 (October 1984);
29.9% industry, 10.6% agriculture, 49.3% ser-
vices (October 1984); 10.2% unemployment
. (October 1984)
Organized labor: 50-55% (est.) of labor force','f23ead348c3e81315af00af214dcb496975867674ed212036c5f2add089434d7','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('063f439da21e5fcaaf630b6d82f4085643fc422a1abd08b5315fc532c291d57f',1985,'JM','Jamaica','people-and-society',300,'Population: 2,428,000 (July 1985), average
annual growth rate 1.6%
Nationdlity: noun—Jamaican(s); adjective—
‘Jamaican
Ethnic divisions: 76.3% African, 15.1% Afro-
European, 3.4% East Indian and Afro-East
Indian, 3.2% white, 1.2% Chinese and Afro-
Chinese, 0.9% other
Religion: predominantly Protestant (includ-
ing Anglican and Baptist), some Roman
Catholic, some spiritualist cults
Language: English, Creole
Literacy: 16%
Labor force: 703,000 (1980); 36.4% agricul-
ture, 32.7% services, 16% government, 14.9%
industry and commerce; shortage of tech-
nical and managerial personnel; significant
unemployment
Organized labor: about 33% of labor force
(1980)
ee ADproved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Jamaica (continued)','7267aa8f0fd8f5810c8088e86e21eb61e70bc82afa19258edc8d1e5f29663e25','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60ffce894a8e60d13f925b2cd9cd3ed3063335f776e0992ee5389612d803688f',1985,'JP','Japan','people-and-society',304,'Population: 120,691,000 (July 1985), average .
annual growth rate 0.6%
Nationality: noun—Japanese (sing., pl.); ad-
jective—Japanese
Ethnic divisions: 99.4% Japanese, 0.6% other
(mostly Korean)
Religion: most Japanese observe both Shinto
and Buddhist rites; about 16% belong to other
faiths, including 0.8% Christian
Language: Japanese
Literacy: 99%
Labor force: (1983) 58.9 million; 52% trade
and services; 35% manufacturing, mining,
and construction; 10% agriculture, forestry,
and fishing; 3% government; 2.7% unem-
ployed
Organized labor: about 30% of labor force
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Population: 42,643,000 (July 1985), average
annual growth rate 1.5%
Nationality: noun—Korean(s); adjective—
Korean
Ethnic divisions: homogeneous; small Chi-
nese minority (approx. 20,000)
Religion: strong Confucian tradition; perva-
sive folk religion (Shamanism), Buddhism
(including estimated 20,000 members of Soka
Gakkai); Chondokyo (religion of the heav-
enly way), eclectic religion with nationalist
overtones founded in 19th century, claims
about 1.5 million adherents
Language: Korean; English widely taught in
high school
Literacy: over 90%
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Korea, South (continued)
Labor force: 15.1 million (1983); 47% services
and other; 30% agriculture, fishing, forestry;
21% mining and manufacturing; average un-
employment 4.1% (1983)
Organized labor: about 10% of nonagricul-
tural labor force','880fb6880cf3000814cdb8790b4905b776c416209de9cc1f07b611667055f74d','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('788a424e0c728912df930b1411efb73f2db275a55a324c60c16a12eaa9d81880',1985,'JO','Jordan','people-and-society',308,'Population: 2,794, 000, excluding West Bank
and East Jerusalem Guly 1985), average an-
nual Browth rate 3.8% :
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Nationality: noun—Jordanian(s); adjec-
tive—Jordanian
Ethnic divisions: 98% Arab, 1% Circassian,
1% Armenian
Religion: 90-92% Sunni Muslim, 8-10%
Christian
Language: Arabic official; English widely
understood among upper and middle classes
Literacy: about 70%
Labor force: 463,000
Organized labor: about 10% of labor force','dbac60b641a6ab36f29d3697b0f10b7812b86a14636147f9478988e261dbaaa2','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c45bf3895f996d51567a64633ff76c2010879912e079e048f7d56dffc829b660',1985,'KE','Kenya','people-and-society',312,'Population: 20,194,000 (July 1985), average
annual growth rate 4.2%
Nationality: noun—Kenyan(s); adjective—
Kenyan
Ethnic divisions: 21% Kikuyu, 14% Luhya,
13% Luo, 11% Kalenjin, 11% Kamba, 6%
Kisii, 5% Meru, 1% Asian, European, and
Arab
Religion: 38% Protestant, 28% Catholic, 26%
indigenous beliefs, 6% Muslim
Language: English and Swahili (official); nu-
merous indigenous languages
Literacy: 47%
Labor force: 5.4 million; about 1.1 million
wage earners; 47% public sector, 18% indus-
try and commerce, 17% agriculture, 13%
services
Organized labor: about 390,000
Population: 44,000 (July 1985), average an-
nual growth rate —0.3%
Ethnic divisions: mainly of African Negro
descent
Nationality: noun—Kittsian(s), Nevisian(s);
adjective—Kittsian, Nevisian
Religion: Anglican, other Protestant sects,
Roman Catholic ~
Language: English
Literacy: 80%
Labor force: 20,000 (1981)
Organized labor: 6,700
Population: 122,000 July 1985), average an-
nual growth rate 1.1%
Nationality: noun—St. Lucian(s); adjec-
tive—St. Lucian
Ethnic divisions: 90.3% African descent,
5.5% mixed, 3.2% East Indian, 0.8% Cauca-
sian
Religion: 90% Roman Catholic, 7% Protes-
tant, 3% Church of England
Language: English (official), French patois
Literacy: 78%
Labor force: 45,000 (1979); 43.4% agricul-
ture, 38.9% services, 17.7% industry and
commerce; 13% unemployment (1979)
Organized labor: 20% of labor force
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
St. Lucia (continued)
Govérnnient
Official name: St. Lucia
Type: independent state within Common-
wealth, recognizing Elizabeth II as Chief of
State
Capital: Castries
Political subdivisions: 16 parishes
Legal system: based on English common law;
constitution of 1960; highest judicial body is
Court of Appeal of Leeward and Windward
Islands :
Branches: bicameral legislative (Senate,
House of Assembly); executive, Cabinet
headed by Prime Minister
Government leaders: John G. M. COMP-
TON, Prime Minister (since February 1975);
Sir Allen LEWIS, Governor General (since
December 1982)
Suffrage: universal adult over age 18 -
Elections: every five years; last election held.
May 1982
Political parties and leaders: United a
Workers’ Party (UWP), John Compton; St.
Lucia Labor Party (SLP), Julian Hunte; Pro-
gressive Labor Party (PLP), George Odlum
Voting strength: (1982 election) House of As-
sembly—UWP, 14 seats; SLP, 2 seats; PLP, 1
seat
Communists: negligible
Member of: CARICOM, FAO, G-77, GATT:
(de facto), IBRD, IC AO, IDA, IFAD, IFC,
ILO, IMF, IMO, NAM, OAS, PAHO, UN,
UNE SCO, UPU, WFTU, WHO, WMO
Population: 102,000 (July 1985), average an-
nual growth rate 1.4%
Nationality: noun—St. Vincentian(s) or Vin-
centian(s); adjectives—St. Vincentian or
Vincentian
Ethnic divisions: mainly of African Negro
descent; remainder mixed, with some white,
East Indian, Carib Indian
Religion: Anglican, Methodist, Roman Cath-
olic
Language: English, some French patois
Literacy: 82%
Labor force: 61,000(1979 est.); about 20% un-
employed (1978)
Organized labor: 10% of labor force
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7','11e7390d30b5f6b92add0cdf6e19cd0bac6edd80bd2bde986ae641ab6f1bad94','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cc6dd19f55944902eee306e28e849d171bc078e170f412a1e5448589e157689',1985,'KI','Kiribati','people-and-society',316,'Population: 62,000 (July 1985), average an-
nual growth rate 1.6%
Nationality: noun—Kiribatian(s); adjec-
tive—Kiribati
Ethnic divisions: Micronesian
Religion: Roman Catholic, Protestant
-Language: English (official), Gilbertese
Literacy: 90%
Labor force: 15,921 (1973); general unem-
ployment rate 4.9%
Population: 20,082,000 (July 1985), average
annual growth rate 2.3%
Nationality: noun—Korean(s); adjective—
Korean
Ethnic divisions: racially homogeneous
Religion: Buddhism and Confucianism; reli-
gious activities now almost nonexistent
Language: Korean
Literacy: 95% est.
Labor force; 6.1 million (1980); 48% agricul-
tural, 52% nonagricultural; shortage of
skilled and unskilled labor','afdda6d1bf36c105e011673ccfb689faa707b42d14e6fa97add8ce3aeda36475','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad7fa7fa1465c5205dad228ad1678a8daed95d2c7f1b0f3505ba7b33d78e4bd3',1985,'KW','Kuwait','people-and-society',320,'Population: 1,870,000 (July 1985), average
annual growth rate 6.2%
Nationality: noun—Kuwaiti(s); adjective—
Kuwaiti
Ethnic divisions: 89% Kuwaiti, 39% other
Arab, 9% South Asian, 4% Iranian, 9% other
Religion: 95% Muslim, 5% Christian, Hindu,
Parsi, and other
Language: Arabic (official); English widely
spoken
Literacy: about 71%
Labor force: 630,000 (1983 est.); 74% ser-
vices, 11% industry, 11% construction; 70% of
labor force is non-Kuwaiti
Organized labor: labor unions, first autho-
rized in 1964, formed in oil industry and
among government personnel
129
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Population: 3,805,000 (July 1985), average
annual growth rate 2.2%
Nationality: noun-—Lao (sing., Lao or Lao-
tian); adjective-——Lao or Laotian
Ethnic divisions: 48% Lao; 25% Phoutheung
(Kha); 14% Tribal Tai; 18% Meo, Yao, and
other
Religion: 50% Buddhist, 50% animist and
other
Language: Lao (official), French, and En-
glish
Literacy: 28%
Labor force: about 1-1.5 million; 80-90% ag-
riculture
Organized labor: only labor organization is
subordinate to the Communist Party','264edd19de78149d303c1fec5e4cdb0eec29c55d2b8fe93108e1247f8ee23786','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6f434a8929e19e67a4bf09c9bb0f0b330fd9ba1811083366459413bb4eadd21',1985,'LB','Lebanon','people-and-society',324,'Population: 2,619,000 (July 1985), average
annual growth rate 0.7%
Nationality: noun—Lebanese (sing., pl.); ad-
jective—Lebanese
Ethnic divisions: 93% Arab, 6% Armenian,
1% other.
Religion: 57% Muslim (Sunni and Sh’‘ia) and
Druze, 42% Christian (Maronite, Greek Or-
thodox and Catholic, Roman Catholic,
Protestant), 1% other (official estimates); *
Muslims, Ny fact, constitute a majority
Language: Arabic (official); French i is euidely
spoken; Armenian, English as
Literacy: 75%
Labor force: 650,000 (1981); 75% industry;
commerce; and services, 17% agriculture; 8%
goverment; high unemployment
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Qieoniaes labor: about 65,000
te
Government ” ak
NOTE: Between Sails 1975 and late 1976
Lebanon was torn by civil war between its
Christians—then aided by Syrian troops—
and its Muslims and their Palestinian allies.
“The cease-fire established in October 1976
between the domestic political groups gener-
‘ally held for about six years, despité
occasional fighting. Syrian troops constituted
“as the. Arab Deterrent Force by the Arab
League have remained in Lebanon. Syria’s
move toward supporting the Lebanese Mus-
lims and the Palestinians and Israel''s growing
support for Lebanese Christians brought the
two sides into rough equilibrium, but no
progress was made toward national reconcili-
ation or political reforms—the original cause
of the war. . :
Continuing Israeli concern about the Pal-
estinian presence in Lebanon led to the
Israeli invasion of Lebanon in June 1982.
Israeli forces occupied all of the southern por-
tion of the country and mounted a summer-
long seige of Beirut, which resulted in the
evacuation of the PLO from Beirut in Sep-
tember under the supervision of a multi-
national force made up of US, French, and
Italian troops.
Within days of the departure of the multina-
tional force (MNF), Lebanon’s newly elected
president, Bashir Gemayel, was assassinated.
In the wake of his death, Christian militia
men massacred hundreds of Palestinian refu-
gees in two Beirut camps. This prompted the
return of the MNF to ease the security bur-
den on Lebanon’s weak army and security
forces. In late March 1984 the last MNF units
withdrew.
Lebanon continues to be occupied by Israel
in the south and by Syria in the north and
east. Israel and Lebanon signed a withdrawal
agreement on 17 May 1983. The agreement
was never implemented and was subse-
quently voided. A partial Israeli withdrawal
and government attempts to extend its au-
thority have led to renewed factional
fighting. The following description is based
on the present constitutional and.customary
practices of the Lebanese system.
» 132
Official name: Republic of Lebanon
Type: republic
: Capital: Beirut
Political subdivisions: 5 provinces
Legal system: mixture of Ottoman law,
canon law, and civil law system; constitution
mandated in 1926; no judicial review of legis-
lative acts; legal education at Lebanese
University; has not accepted compulsory IC]
jurisdiction
National holiday: Independence Day, 22
November
Branches: power lies with President elected
by unicameral legislature (National Assem-
bly, formerly Chamber of Deputies); Cabinet
appointed by President, approved by legisla-
ture; independent secular courts on French
pattern; religious courts for matters of mar-
riage, divorce, inheritance, etc.; by custom,
President is a Maronite Christian, Prime
Minister is a Sunni Muslim, and president of
legislature isa Sh‘ia Muslim; each of nine reli-
gious communities represented in legislature
in proportion to national numerical strength
Government leader: Amine Pierre
GEMAYEL, President (since September
1982); Rashid KARAMI, Prime Minister
(since May 1984)
Suffrage: compulsory for all males over 21;
authorized for women over 21 with elemen-
tary education
Elections: National Assembly held every
. four years or within three months of dissolu-
tion of Chamber; security conditions have
prevented parliamentary elections since
April ve
penal parties and leaders: political party
activity is organized along largely sectarian
lines; numerous political groupings exist, con-
sisting of individual political figures and
followers motivated by religious, clan, and
economic considerations; most parties have
well-armed militias, which are still involved
in occasional clashes
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Communists: the Lebanese Communist
Party was legalized in 1970; members and
sympathizers estimated at 2,000-3,000
Member of: Arab League, FAO, G-77, IAEA,
IBRD, ICAO, IDA, IDB—Islamic Develop-
ment Bank, IFAD, IFC, ILO, IMF, IMO,
INTELSAT, INTERPOL, IPU, ITU, IWC—
International Wheat Council, NAM, OIC,
UN, UNESCO, UPU, WFTU, WHO, WMO,
WSG, WTO','09e9f55395ee795173b59ce5c0ed5720b55046e80d37ae75041783904522ca60','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fa14336b38e2a758d8b160ae55af66c43a84035fbda2a5bbc7972d4a689b3e3',1985,'LS','Lesotho','people-and-society',327,'Population: 1,512,000 (July 1985), average
annual growth rate 2.5%
Nationality: noun—Mosctho (sing.), Basotho
(pl.); adjective—Basotho
Ethnic divisions: 99.7% Sotho; 1,600 Europe-
ans, 800 Asians
Religion: 80% Christian, rest indigenous be-
liefs
Language: Sesotho (southern Sotho) and En-
glish (official); also Zulu and Xhosa
Literacy: 55%
Labor force: 426,000 economically active
(1976); 87.4% of resident population engaged
in subsistence agriculture; 150,000-250,000
spend from six months to many years as wage
earners in South Africa
Organized labor: negligible','8fa126aa142088a8d56c513b5211ed6637977fbe94e196cd99d326ff2c63f5d7','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47195b467a9857f485e4c74da8fb96602dec874e0089453ce480abfe148b04d3',1985,'LR','Liberia','people-and-society',332,'Population: 2,232,000 (July 1985), average
annual growth rate 3.3%
Nationality: noun—Liberian(s); adjective—
Liberian
Ethnic divisions: 95% indigenous African
tribes, including Kpelle, Bassa, Gio, Kru,
Grebo, Mano, Krahn, Gola, Ghandi, Loma,
Kissi, Vai, and Bella; 5% descendants of repa-
triated slaves known as Americo-Liberians
Religion: 75% traditional, 15% Muslim, 10%
Christian :
Language: English (official); more than 20 lo-
cal languages of the Niger-Congo language
group; English used by about 20%
Literacy: 24%
Labor force: 510,000, of which 160,000 are in
monetary economy; non-African foreigners
¢
hold about 95% of the top-level management
and engineering jobs; 70.5% agriculture,
10.8% services, 4.5% industry and commerce,
14.2% other
Organized labor: 2% of labor force','20bb0592f0b123907fc2e7c2ce2f76bb0c248560c66c83fc7b87f8aced2ad828','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbc6f849ca55d35732d69707dc6a362449c2e8ec391c9c2acc25a8cbe984fc6f',1985,'LI','Liechtenstein','people-and-society',337,'Population: 28,000 (July 1985), average an-
nual growth rate 1.8%
Nationality: noun—Liechtensteiner(s); ad-
jective—Liechtenstein :
Ethnic divisions: 95% Alemannic, 5% Italian
and other
Religion: 82.7% Roman Catholic, 7.1% Prot-
estant, 10.2% other
Language: German (official), Alemannic di-
alect
Literacy: 100%
Labor force: 11,368; 5,078 foreign workers
(mostly from Switzerland and Austria),54.5%
industry, trade, and building; 41.6% services:
4.0% agriculture, fishing, forestry, and horti-
culture','bada75379e0407888ad2440f4202ab7c908263b734bdc65a9c91f51c268cc615','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fbef149ef563d774eabc2e11cff08699d449abe24f35dc079c03434904d6d59',1985,'LU','Luxembourg','people-and-society',341,'Population: 367,000 (July 1985), average an-
nual growth rate 0.1%
Nationality: noun—Luxembourger(s); adjec-
tive—Luxembourg
Ethnic divisions: Celtic base, with French
. and German blend; also guest and worker res-
idents from Portugal, Italy, and European
countries
Religion: 97% Roman Catholic, 3% Protes-
tant and Jewish
Language: Luxembourgish, German,
French; most educated Luxembourgers also
speak English
Literacy: 100%
Labor force: (1981) 161,700; one-third of
labor force is foreign, comprising mostly
workers from Portugal, Italy, France, Bel-
gium, and FRG (1981); unemployment 1.0%
(1981 average); 45% services, 42% industry
and commerce, 12% government, 0.5% agri-
culture
Population: 393,000 uly 1985), average an-
nual growth rate 3.4%
Nationality: noun—Macanese (sing. and pl.);
adjective Maran
ee Delabnss 98% enna 2% Portu-
guese « .
Religion: mainly Buddhist; 17,000 Catholics,
of whom about half are Chinese
Language: 98% Chinese, 2% Portuguese -
Literacy: almost 100% amiong Portuguese
and Macanese; no data on Chinese popula-
tion :','83092df2eab1483874aa34f8c0dc6a1b9b22d8ca0e0d003fd2d490253566846f','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82edde1262335b5eca2b14cfd61f2ff05db74e9b4ab624417b406e4dac02f6b3',1985,'MG','Madagascar','people-and-society',345,'Population: 9,941,000 (July 1985), average
annual growth rate 2.8%
Nationality: noun—Malagasy (sing. and pl.);
adjective—Malagasy
Ethnic divisions: basic split between high-
landers of predominantly Malayo-
Indonesian origin, consisting of Merina
(1,643,000) and related Betsileo (760,000) on
the one hand and coastal tribes—collectively
termed the Cétiers—with mixed Negroid,
Malayo-Indonesian, and Arab ancestry on
the other; coastal tribes include
Betsimisaraka 941,000, Tsimihety 442,000,
Antaisaka 415,000, Sakalava 375,000; there
are also 10,000-12,000 European French,
5,000 Indians of French nationality, and
5,000 Creoles
Religion: more than half indigenous beliefs;
about 41% Christian, 7% Muslim
Language: French and Malagasy official
141
Literacy: 53%
Labor force: about 3.4 million, of which 90%
are nonsalaried family workers engaged in
subsistence agriculture; of 175,000 wage and
salary earners, 26% agriculture, 17% domes-
tic service, 15% industry, 14% commerce,
11% construction, 9% services, 6% transpor-
tation, 2% miscellaneous
Organized labor: 4% of labor force','5de1845686782c845bca4152b680816076755804e69f129d2c2a503d8a80eaca','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d8c9ad91a050190a990c03265721f24ff23a0edbfdad11a817b701523a96043',1985,'MW','Malawi','people-and-society',349,'Population: 7,056,000 (July 1985), average
annual growth rate 3.3%
Nationality: noun—Malawian(s); adjec-
tive—Malawian
Ethnic divisions: Chewa, Nyanja, Tumbuko,
Yao, Lomwe, Sena, Tonga, Ngoni, Asian, Eu-
ropean
Religion: 55% Protestant, 20% Roman Cath-
olic, 20% Muslim; traditional indigenous
beliefs are also practiced by some members
of these groups
Language: English and Chichewa (official),
Tombuka is second African language
Literacy: 25% |
Labor force: 344,052 wage earners employed
in Malawi (1982); 52% agriculture, 16% per-
sonal services, 9% manufacturing, 7%
construction, 6% commerce, 4% miscella-
neous services, 5% other permanently
employed
Organized labor: small minority of wage
earners are unionized','2427504623a6475901c239cc0d28ec2f05ab1f4f7bf6a7aeba454036a333d58c','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c319ce0fa780c13484635e3c09cca30bc7826ca1a5acb997fdde8e8acc507fd1',1985,'MY','Malaysia','people-and-society',353,'Population: 15,664,000 (July 1985), average
annual growth rate 2.2%
Peninsular Malaysia: 12,854,000 (July 1985),
average annual growth rate 2.0%
144
Sabah: 1,279,000 (July 1985), average annual
growth rate 3. 9% : ‘
esi 1,532,000 (July. 1985), average an- -
nual growth rate 2.4% -
Nationality: noun—Malaysian(s), adjec-
tive—Malaysian
Ethnic deans 50% Malay, 36% Chinese,
10% Indian, ''4% other.
Religion:
Peninsular Malaysia: Malays nearly all Mus-
lim, Chinese predominantly Buddhists,
Indians predominantly. Hindu -
Sabah: 38% Muslim, 17% Christian, 45%
other
Sarawak: 35% tribal religion, 24% Buddhist .
and Confucianist, 16% Christian, 2% other
Language: ee
Peninsular Malaysia: Malay (official); En-
glish, Chinese dialects, Tamil
Sabah: English, Malay, numerous tribal dia-
lects, Mandarin and Hakka dialects. -
predominate among Chinese
Sarawak: English, Malay, Mandarin, numer-
ous tribal languages ;
Literacy:
Peninsular M Manu 75%
‘
Sabah 58%
Sarawak: 55%
Labor force:
Malaysia: 5.58 million (1983), 37% agricul-
ture, forestry, livestock, and fishing; 39%
trade, transport, arid Services; 22% manufac-
turing and construction
Organized labor: 612,000 (November 1983),
about 11% of total: labor force; unemploy-
ment about 6.0% of total labor force nG883)
but higher in urban areas','827df26efc2c5767054823f4f443b1c500908fe3d06bf856407a935314e07e63','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('863b7bcb8c60e0d30a0e003f16c385898f3a1974d1af5eabf84958070c357847',1985,'MV','Maldives','people-and-society',357,'Population: 178,000 (July 1985), average an-
nual growth rate 3.0%
Nationality: noun—Maldivian(s); adjec-
tive—Maldivian
Ethnic divisions: admixtures of Sinhalese,
Dravidian, Arab, and black
Religion: Sunni Muslim
Language: Divehi (dialect of Sinhala; script
derived from Arabic); English spoken by
most government officials
Literacy: 36%
Labor force: total enployment-is approxi-
mately 66,000; fishing industry employs 80%
of the labor force','95a724b61b80a4813e825cd1d24279095e3dcef32fe13abcc1f64efc616d27e0','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdf90af8b2b264059df2e058b73564a6c217e714b2908be976a7b02a5c83a757',1985,'ML','Mali','people-and-society',361,'Population: 7,735,000 (July 1985), average
annual growth rate 2.3%
Nationality: noun—Malian(s); adiective—
Malian
Ethnic divisions: 50% Mande (Bambara, Ma-
linke, Sarakole), 17% Peul, 12% Voltaic, 6%
Songhai, 5% Tuareg and Moor
Religion: 90% Muslim, 9% indigenous be-
liefs, 1% Christian
Language: French (official); Bambara spo-
ken by about 80% of the population
Literacy: 10%
Labor force: 8.1 million (1981); 80% agricul-
ture, 19% services, 1% industry and
commerce
Organized labor: National Union of Malian
Workers (UNTM) is umbrella organization
over 13 national unions','2b67a0fecbdf53e1945130925d02090dbbfd76f08fbe945bd2a746d49cfebb95','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7836a829534ab09e0beb937d05d5fbaa00ed877eb05e67eddaf8f1b99c788b1',1985,'MT','Malta','people-and-society',365,'Population: 355,000 (July 1985), average an-
nual growth rate —0.5%
Nationality: noun—Maltese (sing. and pl.);
adjective—Maltese
Ethnic divisions: mixture of Arab, Sicilian,
Norman, Spanish, Italian, English
Religion: 98% Roman Catholic
Language: Maltese and English (official)
Literacy: 83%
Labor force: 120,419 (1983); 33% services (ex-
cept government), 26% manufacturing, 23%
government (except job corps), 5% agricul-
ture, 5% utilities and drydocks; 8.2%
registered unemployed
Organized labor: approximately 40% of la-
bor force
149','255319fbc62fb33d3542ea9c1bbb702330859f8bbf82ad1ec1905c50c0b23124','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bc7c9304b94eae29e94a069b709801c494897ebefba68975fa422314a5a6a05',1985,'MQ','Martinique','people-and-society',369,'Population: 327,000 (July 1985), average an-
nual growth rate 0.1%
Nationality: noun—Martiniquais (sing. and
pl.); adjective—Martiniquais
Ethnic divisions: 90% African and African-
Caucasian-Indian mixture, 5% Caucasian,
less than 5% East Indian, Lebanese, Chinese
Religion: 95% Roman Catholic, 5% Hindu
and pagan African
Language: French, Creole patois
Literacy: over 70% ay a
Labor force: 100,000; 31.7% service industry,
29.4% construction:and publi¢ works, 13.1%
agriculture, 7.3% industry, 2.2% fisheries,
16.8% other; 14% unemployed
Organized labor: 11% of labor force
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7','22d2a913a42d63e700d80be95452be67f425bf94aa2043b676d075b40673ba5d','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0790fbd0715d4a210712fa334ad0981748f060e4aa29225e8ea5395dbbecde89',1985,'MR','Mauritania','people-and-society',373,'Population: 1,656,000 (July 1985), average
annual growth rate 2.0%
Nationality: noun—Mauritanian(s); adjec-
tive—Mauritanian
Ethnic divisions: 40% mixed Moor/black; ’
30% Moor, 30% black
Religion: nearly 100% Muslim
Language: Hasanya Arabic (national),
French (official); Toucouleur, Fula, Sarakole,
Wolof
Literacy: 17%
Labor force: total labor force 465,000 (1981
est.); about 45,000 wage earners (1980 IMF),
47% agriculture, 29% services, 14% industry
and commerce, 10% government; consider-
able unemployment -
Organized labor: 30,000 members claimed
by single union, Mauritanian Workers’
Union','8428438aa795732958581bdd3346f33f3990a9e6bc38827ad8fb1b8b4d8198fe','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('057387a8adbaac0dbce09839eede2a1415c554efd9bf7408675907110e906ce4',1985,'MU','Mauritius','people-and-society',377,'Population: 1,011,000 (July 1985), average
annual growth rate 0.9%
Nationality: noun—Mauritian(s); adiec-
tive—Mauritian
Ethnic divisions: 68% Indo-Mauritian, 27%
Creole, 3% Sino-Mauritian, 2% Franco-Mau-
ritian
Religion: 51% Hindu, 30% Christian (mostly
Roman Catholic with a few Anglicans), 17%
Muslim
Language: Creole, French, English, Hindi,
Urdu, Hakka, Bojpoori
Literacy: 61%
Labor force: 335,000; 29% agriculture and
fishing, 28% government services, 23%
153
industry and commerce, 20% other; 14% are
unemployed .
Organized labor: about 35% of labor force,
forming over 270 unions','997f1b27bf0013606f89133bf89642344d4c125ac7046bfebd455bfe69dfd0be','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36cd412dc76523a6af3eb4aeb6dcd82346d73ca09fc7b2628ca00a1dddee1988',1985,'MX','Mexico','people-and-society',381,'Population: 79,662,000 (July 1985), average
annual growth rate 2.5%
Nationality: noun—Mexican(s); adjective—
Mexican
Ethnic divisions: 60% mestizo (Indian-Span-
ish), 30% Amerindian or predominantly
Amerindian, 9% white or apredorminantly
white, 1% other
Religion: 97% nominally Roman Catholic,
8% Protestant
Language: aes ;
Literacy: 74%
Labor force: 21,500,000 (1982); 31.4% ser-
vices; 26% agriculture, forestry, hunting,
fishing; 13.9% commerce; 12.8% manufac-
turing; 9.5% construction; 4.8%
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
‘transportation; 1.8% mining and quarrying;
0.3% electricity; 10% unemployed, 40% un-
‘deremployed
Organized labor: 20% of total labor force','e56812483ce88f760ed8294c36a31986ed3a186ad9a6738756c729baaa14a2ee','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ebcddea1bc8e0f3b59d214f90dd56c6e21d328920ed91b5a8a004546c62be50',1985,'MC','Monaco','people-and-society',385,'Population: 28,000 (July 1985); average an-
nual growth rate 1.2%
Nationality: noun—Monacan(s) or Mone- -
gasque(s); adjective—Monacan or
Monegasque
Ethnic divisions: 58% French, 19% Mone-
gasque, 17% Italian, 6% unspecified
Religion: 95% Roman Catholicism
Language: French (official), English, Italian,
Monegarque
Literacy: 99%','45d4090088e4901675002d1ec8fe5876b8d4e7b618baaa7a7ac57e941a9ead4e','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a9baebcb78aa8575e453e68fef594ca22eb78189bf3008405a0f4184402182e',1985,'MN','Mongolia','people-and-society',389,'Population: 1,912,000 (July 1985), average
annual growth rate 2.7%
Nationality: noun—Mongolian(s); adjec-
tive—Mongolian
Ethnic divisions: 90% Mongol, 4% Kazakh,
2% Chinese, 2% Russian, 2% other
Religion: predominantly Tibetan Buddhist,
about 4% Muslim, limited religious activity
because of Communist regime
Language: Khalkha Mongol used by over
90% of population; minor Janguages include
Turkic, Russian, and Chinese
Literacy: about 80%
Labor force: primarily agricultural, over half
the adult population is in the labor force, in-
cluding a large percentage of women;
shortage of skilled labor (no reliable informa-
tion available)','b4fece3593456b2386a1004bd785deb964a79ae5017593fce879b615388fbfbf','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6bbb7530b9cc7dcdb651bbfc15b35c36bac7a6ea1c3f18a2c1512378dd0d688',1985,'MA','Morocco','people-and-society',393,'Population: 24,258,000 (July 1985), average
annual growth rate 2.9%
Nationality: noun—Moroccan(s); adjec-
tive—Moroccan
Ethnic divisions: 99.1% Arab-Berber, 0.7%
non-Moroccan, 0.2% Jewish
Religion: 98.7% Muslim, 1.1% Christian,
0.2% Jewish
Language: Arabic (official); several Berber
dialects; French is language of much busi-
ness, government, diplomacy, and
postprimary education
Literacy: 28%
Labor force: 6.1 million (1982 est.); 50% agri-
culture, 26% services, 15% industry, 9%
other; at least 20% of urban labor unem-
ployed
158
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Organized labor: about 5% of the labor force,
mainly in the Union of Moroccan Workers
(UMT) and the Democratic Confederation of
Labor (CDT)','89318e7a24a1b6b20017dff43e92e909441ec408b4b53a66f252c8c4aff50af5','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('923b435942b95dd555b03ceca54adf9250b01e2bfc0bda34a36e76839ebac8cb',1985,'MZ','Mozambique','people-and-society',398,'Population: 13,776,000 (July 1985), average
annual growth rate 2.8%
Nationality: noun—Mozambican(s); adjec-
tive—Mozambican
Ethnic divisions: majority from indigenous
tribal groups; approximately 10,000 Europe-
ans, 35,000 Euro-Africans, 15,000 Indians
Religion: 60% indigenous beliefs, 30% Chris-
tian, 10% Muslim
Language: Portuguese (official); many indig-
enous dialects
Literacy: 14%','f2d4ecb3704208d775a8616a784b694bbb643dbe30e7aadb8d7f7616b12388bc','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21fc247d0e1620ca870438fb828d119b4cf676635834029109924699bb05af9f',1985,'NA','Namibia','people-and-society',402,'Population: 1,108,000 (July 1985), average
annual growth rate 3.0%
Nationality: noun—Namibian(s); adjec-
tive—Namibian
Ethnic divisions: 85.6% black, 7.5% white,
6.9% mixed; approximately half the Africans
belong to Owambo tribe
Religion: whites predominantly Christian,
nonwhites either Christian or indigenous be-
liefs -
Language: Afrikaans principal language of:
about 60% of white population, German of
33%, and English of 7% (all official); several
indigenous languages
Literacy: 100% whites, 28% nonwhites
161
Labor force: about 500,000 (1981); 60% agri-
culture, 19% industry and commerce, 8%
services, 7% government, 6% mining
Organized labor: 6 trade unions, member-
ship almost exclusively white.and mulatto','e258e661de35734b9a6a5d906102e0fd49350de4bbbdb9d09c36d4ecd7fd2892','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54576c6ab4d55965121880cec79c88e6029cf8fc356e59e89113c84fbaf1789d',1985,'NR','Nauru','people-and-society',406,'Population: 8,000 July 1985), average an-
nual growth rate 1.3%
Nationality: noun—Nauruar(s); adjective—
Nauruan
Ethnic divisions: 58% Nauruan, 26% other
Pacific Islander, 8% Chinese, 8% European
Religion: Christian (two-thirds Protestant,
one-third Catholic)
Language: Nauruan, a distinct Pacific Island
language (official), English widely under-
stood and spoken
Literacy: 99%','1d1d2b7b6b31190d7d9c7c70b197f0fa129811c921b36b846d941f8f9fc9da58','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0eeda4617cc384d0eb04a4480f9094ce9cc8dde35f429089cab5e0d5972c8e56',1985,'NL','Netherlands','people-and-society',413,'Population: 14,467,000 (July 1985), average
annual growth rate 0.4%
Nationality: noun—Netherlander(s); adjec-
tive—Netherlands
Ethnic divisions: 99% Dutch, 1% Indonesian
and other
Religion: 40% Roman Catholic, 31% Protes-
tant, 24% unaffiliated
Language: Dutch
Literacy: 99%
Labor force: 4.9 million (1981); 30% manu-
facturing, 24% services, 16% commerce, 10%
agriculture, 9% construction, 7% transporta-
tion and communications, 4% other; 11.3%
unemployment, September 1982
Organized labor: 33% of labor force
Population: 256,000 (July 1985), average an-
nual growth rate 1.2%
Nationality: noun—Netherlands Antille-
an(s); adjective—Netherlands Antillean
Ethnic divisions: 85% mixed African; re-
mainder Carib Indian, European, Latin, and
Oriental
Religion: predominantly Roman Catholic;
Protestant, Jewish, Adventist
Language: Dutch (official); Papiamento, a
Spanish-Portuguese-Dutch-English dialect
predominates; English widely spoken;
Spanish
Literacy: 95% ©
Labor force: 89,000 (1983); 65% government,
28% industry and commerce, 1.5% agricul-
ture; unemployment about 16% on Curacao
and about 10% on Aruba (1984 est.)
Organized labor: 60-70% of labor force
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7','9266e4524d7ce891b4dd006f54578e82cddd66f66506881f20898ab4135aa6ac','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7cb9259f0a91d86b73eba6c50b5d47eee4b93ae068dc2c5db881bc0d7b9b0bf1',1985,'NC','New Caledonia','people-and-society',417,'Population: 153,000 (July 1985), average an-
nual growth rate 1.7%
Nationality: noun—New Caledonian(s); ad-
jective—New Caledonian
Ethnic divisions: Melanesian 42.5%, Euro-
pean 37.1%, Wallisian 8.4%, Polynesian
3.8%, Indonesian 3.6%, Vietnamese 1.6%
Religion: over 60% Roman Catholic, 30%
Protestant .
Language: French; Melanesian-Polynesian
dialects
Literacy: unknown
Labor force: 50,469 (1980 est.); Javanese and
Tonkinese laborers were imported for plan-
tations and mines in pre-World War II
period; immigrant labor now coming from
Wallis Islands, New Hebrides, and French
Polynesia; est. 8% unemployment
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Organized labor: labor not organized _','0a32f7bbd5a1a59793260900a831f9c7a7ab101a09930bb44d2bf11e70d19af8','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('654f8d60896aa8611957f6ae0b41deabcab127ffac434fde6344614e8882c5f5',1985,'NZ','New Zealand','people-and-society',421,'Population: 3,295,000 (July 1985), average
annual growth rate 1.4%
Nationality: noun—New Zealander(s); ad-
jective—New Zealand
Ethnic divisions: 87% European, 9% Maori,
2% Pacific Islander, 2% other
Religion: 81% Christian, 18% none or un-
specified, 1% Hindu, Confucian, and other
Language: English (official), Maori
Literacy: 98%
Labor force: 1,325,000 (1981); 29.9% manu-
facturing, mining, and construction; 24.2%
commerce and finance; 21.2% services;
10.7% agriculture; 8.3% transportation and
communications; 2% other; unemployment
3.7% (February 1981)
Organized labor: 46% of labor force','37368dc499e475fe449fa60b5605d2fc3e7aedae1605d25c94184b05b87c558b','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd25004a7ac2d9537d919a331a9ef88599946e4ca5b46c0931d86f3d9f91587b',1985,'NI','Nicaragua','people-and-society',425,'Population: 3,038,000 (July 1985), average
annual growth rate 3.5%
Nationality: noun—Nicaraguan(s); adjec-
tive—Nicaraguan
Ethnic divisions: 69% mestizo, 17% white,
9% black, 5% Indian
Religion: 95% Roman Catholic
Language: Spanish (official); English- and
Indian-speaking minorities on Atlantic coast
Literacy: 66%
Labor force: 969,000 (1983 est.); 40% agricul-
ture, 34% service, 26% industry, 3%
construction, 5% other; 25% unemployment
170
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Organized labor: 35% of Nicaragua’s labor
force is organized; of the seven confedera-
tions, five are Sandinista or Marxist
oriented—the government-sponsored Sandi-
nista Workers’ Central (CST), 115,000
members, including state and municipal em-
ployees; the Association of Campesino
Workers (ATC), 130,000 members; the Gen-
eral Confederation of Independent Workers
(CGI-D), approximately 15,000 members; the
Workers Front, about 100 members; and the
Central for Labor Action and Unity (CAUS),
about 3,000 members; the other two unions
are the Nicaraguan Workers’ Central (CTN),
25,000 members, and the Confederation of
Labor Unification (CUS), 50,000 members','af16c6a9e53bf0052b1a216067d14893e7d4ec5a7ce94ebbaba67c8781ac8b82','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8a0c9abdc8299e1549136fd29afe95f7bbe46140c8e6a0ca43899165dcb9dd5',1985,'NE','Niger','people-and-society',429,'Population: 6,495,000 (July 1985), average
annual growth rate 3.3%
Nationality: noun—Nigerien(s) adjective—
Nigerien
Ethnic divisions: 56% Hausa; 22% Dierma;
8.5% Fula; 8% Tuareg; 4.3% Beri Beri
(Kanouri); 1.2% Arab, Toubou, and
Gourmantche; about 4,000 French expatri-
ates
Religion: 80% Muslim, remainder indige-
nous beliefs and Christians
Language: French (official); Hausa, Dierma
Literacy: 5%
Labor force: 2.5 million (1982) wage earners;
90% agriculture, 6% industry and commerce,
4% government
Organized labor: negligible','b3b721acf84e9f411ba3ac77b3a53ccf388bd7df6dc14b456ce1dd6f3c5d6525','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fd9ab79bc15489883f5ff511756f3cd3a6e159c7b1c8031abd7525297449b1a',1985,'NO','Norway','people-and-society',434,'Population: 4,160,000 (July 1985), average
annual growth rate 0.4%
Nationality: noun—Norwegian(s); adjec-
tive—Norwegian
Ethnic divisions: Germanic (Nordic, Alpine,
Baltic) and racial-cultural minority of 20,000
Lapps
Religion: 94% Evangelical Lutheran (state
church), 4% other Protestant and Roman
Catholic, 2% other
Language: Norwegian (official); small Lapp-
and Finnish-speaking minorities
Literacy: 100%
Labor force: 2.024 million (1983); 30.9% ser-
vices; 19.6% mining and manufacturing;
16.7% commerce; 8.8% transportation; 7.6%
construction; 7.2% agriculture, forestry, fish-
ing; 5.7% banking and financial services;
3.8% unemployed
Organized labor: 60% of labor force','196e72d5155b1591c0b339a49ae66c2d8f41c80783f6dda4ee042be82f2ad46b','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8402a89eacf59db2b6e89f8e23205a5dd76c3a9abd9cd760a669164c6c6aa429',1985,'OM','Oman','people-and-society',438,'Population: 1,228,000(July’ 1985), average
annual growth rate 8. 9%
Nationality: noun—Omani(s); adjective—
Omani © oy
Ethnic divisions: almost entirely Arab, with
small Baluchi, Zanzibari, and Indian groups
Religion: 75% Ibadhi Muslim; remainder
Sunni Muslin, Sh‘ia Muslim, some Hindu
Language: Arabic (official) English, Balu-
chi, Urdu, Indian dialects
saad 20%
,
Labor force: 500,000; 50% are non-Omani;
est. 60% agriculture','d60f76ac8bb9c29f14fcdb110002762071edb8a481315d2f5c866e5e81e5f99a','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e1d09b3e58360b84740e91bfc56ce931268d4bf8c2eed18a4c2dcd53dcab6ca',1985,'PK','Pakistan','people-and-society',442,'Population: 99,199,000, excluding
Junagardh, Manavadar, Gilgit, Baltistan, and
the disputed area of Jammu and Kashmir
(July 1985); average annual growth rate 2.6%
Nationality: noun—Pakistani(s); adjective—
Pakistani
Ethnic divisions: Punjabi, Sindhi, Pushtan
(Pathan), Baluchi
Religion: 97% Muslim, 3% Christian, Hindu,
and other
Language: Urdu and English (official); total
spoken languages—64% Punjabi, 12%
Sindhi, 8% Pushtu, 7% Urdu, 9% Baluchi and
other; English is lingua franca
Literacy: 24%
Labor force: 25.24 million (1982 est.); exten-
sive export of labor; 52% agriculture, 21%
industry, 8% services, 19% other
Organized labor: negligible','affa54dbe531c5badea3d204097a02f617434d21a4da156de1e9a1c9e2a13f15','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b24416637d89dec4b407037f4e9ef5aca04a7b1e69fa83333fc6a3af77819b8d',1985,'PA','Panama','people-and-society',446,'Population: 2,038,000 (July 1985), average
annual growth rate 1.8%
Nationality: noun—Panamanian(s); adjec-
tive—Panamanian
Ethnic divisions: 70% mestizo, 14% West In-
dian, 10% white, 6% Indian
Religion: over 93% Roman Catholic, 6%
Protestant
Language: Spanish (official), 14% speak En-
glish as native tongue; many Panamanians
bilingual
Literacy: 90%
Labor force: est. 625,000 (January 1982); 45%
commerce, finance, and services; 29% agri-
culture, hunting, and fishing; 10%
Be Annroved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Panama (continued)
manufacturing and mining; 5% construction;
5% transportation and communications; 4%
Canal Zone; 1.2% utilities; 2% other; unem-
ployed estimated at 20% (January 1984);
shortage of skilled labor but an oversupply of
unskilled labor ,
Organized labor: approximately 15% of la-
bor force (1982)','606011b7c0f5b1f0ca4296f63784e13f83f4046f03b2bf76f0b9f69024f2edb8','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0613fe574911e989ddf7c5b7d4b991fe9742d58cf78de4ce727bf2fc10dd6f49',1985,'PG','Papua New Guinea','people-and-society',450,'Population: 3,326,000 (July 1985), average
annual growth rate 2.1%
Nationality: noun—Papua New Guinean(s);
adjective—Papua New Guinean
Ethnic divisions: predominantly Melanesian
and Papuan; some Negrito, Micronesian, and
Polynesian
Religion: over half of population nominally
Christian (490,000 Catholic, 320,000 Lu-
theran, other Protestant sects); remainder
indigenous beliefs
Language: 715 indigenous languages; pidgin
English in much of the country and Motu in
Papua region are linguae francae; English
spoken by 1-2% of population
Literacy: 32%
18]
Labor force: 1.44 million (1979); 352,500
(1980) in salaried employment; 53% agricul-
ture, 20% government, 17% industry and
commerce, 10% services','eb31b3dbfd5c2551ca33bc3ae6c858dffa4a2755d9c4130fef4aa7b3e4ffaec0','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e50e1384c45474e31139fb70eaba799bc654933922ce47774a41b55d5654d856',1985,'PY','Paraguay','people-and-society',454,'Population: 3,722,000 (July 1985), average
annual growth rate 2.7%
Nationality: noun—Paraguayan(s); adjec-
tive—Paraguayan
Ethnic divisions: 95% mestizo (Spanish and
Indian), 5% white and Indian
Religion: 97% Roman Catholic; Mennonite
and other Protestant denominations
Language: Spanish (official) and Guarani
Literacy: 81%
Labor force: 1.1 million (1983 est.); 44% agri-
culture; 34% industry and commerce, 18%
services, 4% government; unemployment
rate 15% (1984)
Organized labor: about 5% of labor force','500790df79d648ebf763b95cbd89ef86072e45b451119cea970bf5d2f4c9b488','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a7749c29ed582d548080f5d15cff9b37a7a5720ba67e13fc597d8582df3d375',1985,'PE','Peru','people-and-society',458,'Population: 19,532,000 (July 1985), average
annual growth rate 2.4%
Nationality: noun—Peruvian(s): adjective—
Peruvian
Ethnic divisions: 45% Indian; 37% mestizo ,
(white-Indian); 15% white; 3% black, Japa-
nese, Chinese, and other
Religion: sredlehiindntly Roman Catholic
Language: Spanish and Quechua (official), —
Aymara
Literacy: est. 72%
Labor force: 5.6 million (1980); 41% govern-
ment and other services, 40% agriculture,
19% industry and mining; unemployment .
about 9% (1983 est.)
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Organized labor: about 40% of salaried
workers (1988 est.)','4f8619fc4f88de2c99f4a5c42500659ba5d6aa100d8999c4714e94f9f3b8370f','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40e634f2667d011abdeb84046dc624c505c133828adc084b0b5848d6a65a40a3',1985,'PH','Philippines','people-and-society',461,'Population: 56,808,000 (July 1985), average
annual growth rate 2.3%
Nationality: noun -telipinet); adjective—
Philippine
Ethnic divisions: 91.5% Christian Malay, 4%
Muslim Malay, 1.5% Chinese, 3% other
Religion: 83% Roman Catholic, 9% Protes-
tant, 5% Muslim, 3% Buddhist and other
Language: Pilipino (based on Tagalog) and
English (both official)
Literacy: about 88%
185
Labor force: 17.8 million (1982 est); 47% agri-
culture, 20% industry and commerce, 13.5%
services, 10% government, 9.5% other','1f145806b3d5fbc913463caf8b688edb9f7bcda6cbd065c9a82d49a1ea8b4029','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e082c10c6b735c1bc091db61864c7b9fd1975d1d9aea084e6cdb27f1d52ea64',1985,'PL','Poland','people-and-society',465,'Population: 37,236,000 (July 1985), average
annual growth rate 0.9%
Nationality: noun—Pole(s); adjective—
Polish
Ethnic divisions: 98.7% Polish, 0.6% Ukrai-
nian, 0.5% Byelorussian, less than 0.05%
Jewish, 0.2% other
Religion: 95% Roman Catholic (about 75%
practicing), 5% Uniate, Greek Orthodox,
Protestant, and other
Language: Polish, no significant dialects
Literacy: 98%
Labor force: 19.3 million; 27% agriculture,
32% industry, 41% other nonagricultural
(1980)
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Organized labor: new government trade
unions formed following dissolution of Soli-
darity and all government unions in October
1982','c0cc6fcb1aba3a26c61ec1c9ed7d8dbc3cf3f9d536912896877eeff6d429b91f','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc393d9adac93947c68b973e061d0967914c73abd293bb475a0442fd2e333a85',1985,'PT','Portugal','people-and-society',469,'Population: 10,045,000 (July 1985), includ-
ing the Azores and Madeira Islands; average
annual growth rate 0.5%
Nationality: noun—Portuguese (sing. and
pl.); adjective—Portuguese
Ethnic divisions: homogeneous Mediterra-
nean stock in mainland, Azores, Madeira
Islands; citizens of black African descent who
immigrated to mainland during decoloniza-
tion number less than 100,000
Religion: 97% Roman Catholic, 1% Protes- -
tant sects, 2% other
Language: Portuguese
*
Literacy: 80%
Labor force: 4.6 million (1983); 37% services,
36% industry, 27% agriculture; unemploy-
ment, 10.2% (June 1984)
Organized labor: about 45% of Portuguese
labor is organized; the Communist-domi-
nated General Confederation of Portuguese
Workers—National Intersindical (CGTP-IN)
represents about half of the unionized labor
force; its main competition, the General
Workers Union (UGT), is organized by the
Socialists and Social Democrats and repre-
sents a little less than half of unionized labor','729750858d97d013a24caa65eddb4a20747833304dcc2d3572e89b3f59e6fc16','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc20962ca83cb12a6759114b9130403af4bcdd08ae50c885f1ed7bf7396e6c98',1985,'QA','Qatar','people-and-society',473,'Population: 301,000 (July 1985), average an-
nual growth rate 3.4%
Nationality: noun—Qatari(s); adjective—
Qatari
Ethnic divisions: 40% Arab, 18% Pakistani,
18% Indian, 10% Iranian
Religion: 95% Muslim
Language: Arabic (official), English is com-
monly used as second language
Literacy: 40%
Labor force: 104,000 (1983); 85% non-Qatari
in private sector :
Population: 537,000 (July 1985), average an-
nual growth rate 1.1%
Nationality: noun—Reunionese (sing. and
pl.); adjective—Reunionese
Ethnic divisions: most of the population is of
thoroughly intermixed ancestry of French,
African, Malagasy, Chinese, Pakistani, and
Indian origin
Religion: 94% Roman Catholic
Language: French (official); Creole widely
used
Literacy: over 80% among younger genera-
tion
Labor force: primarily agricultural workers;
high seasonal unemployment','35fbf06ade84975794121c4acfeb3b7fe663b515691f967259cc2da9c1d85030','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f91b6679ba9c96b4af4b7d99af577e71ea8bfb4858375e4f279dd735a802cf2',1985,'RO','Romania','people-and-society',477,'Population: 22,772,000 (July 1985), average
annual growth rate 0.5%
Nationality: noun—Romanian(s); adjec-
tive—Romanian
Ethnic divisions: 88.1% Romanian; 7.9%
Hungarian; 1.6% German; 2.4% Ukrainian,
Serb, Croat, Russian, Turk, and Gypsy
Religion: 80% Romanian Orthodox; 6% Ro-
man Catholic; 4% Calvinist, Lutheran,
Jewish, Baptist, and other
Language: Romanian, Hungarian, German
Literacy: 98%
Labor force: 10.5 million (1983); 37.8% indus-
try, 29.2% agriculture, 33% other
nonagricultural (1983)','7677d4b5737d227c1bc5685bebfc41d435f5f43a6b81df69d38e2c24f1d0af1b','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5201c82f99b640c764976c060563cb99dd0b1bf00cf99c7a9c31ba212f08f0eb',1985,'RW','Rwanda','people-and-society',481,'Population: 6,246,000 (July 1985), average
annual growth rate 3.7%
Nationality: noun—Rwandan(s); adjective—
Rwandan
Ethnic divisions: 85% Hutu, 14% Tutsi, 1%
Twa (Pygmoid)
Religion: 65% Catholic, 9% Protestant, 1%
Muslim, rest indigenous beliefs
Language: Kinyarwanda and French offi-
cial; Kiswahili used in commercial centers
Literacy: 37%
Labor force: 2.7 million (1983); 93% agricul-
ture, 3% industry and commerce, 3%
government, 1% services','098d23eb2523c56d5d9b27508c62c60a6c595fcd5196e9958cc1c0e51c65023d','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c63b0e4c7e2479cf26bf31c57ebbd81db1aaa23320c1313d6c5b575faca1519',1985,'SM','San Marino','people-and-society',485,'Population: 23,000 (July 1985), average an-
nual growth rate 1.6%
Nationality: noun—Sanmarinese (sing. and
pl.); adjective—Sanmarinese
Religion: Roman Catholic
Language: Italian
Literacy: 97%
Labor force: approx. 4,300
Organized labor: Democratic Federation of
Sanmarinese Workers (affiliated with
ICFTU) has about 1,800 members; Commu-
nist-dominated General Federation of
Labor, 1,400 members','d15678af5e0fdd1d35b7b2ddffa8a5d5067bd867415f8dbc8747f646471e5cb0','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d6dd63182205a7b8a0a518f89bea19a45e92188e3f7f4dc78309feb1209b25c',1985,'SA','Saudi Arabia','people-and-society',488,'Population: 11,152,000 (July 1985), average
annual growth rate 3.3%
Nationality: noun—Saudi(s); adjective—
Saudi Arabian or Saudi
Ethnic divisions: 90% Arab, 10% Afro-Asian
Religion: 100% Muslim
Language: Arabic
Literacy: 52%
Labor force: about one-third (one-half for-
eign) of population; 45% commerce, services,
government, and other; 30% agriculture; 15%
construction; 5% industry; 5% oil and mining','35c76fbde0e389621c6d74e771c3a40d4e694427d1d9ad10a3e80b2fc107682a','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bf6f3b4079a093ec8c2797eb87d2810bc7c97a72249cb1be2c6535c8ff4231f',1985,'SN','Senegal','people-and-society',491,'Population: 6,755,000 (July 1985), average
annual growth rate 3.2%
Nationality: noun—Senegalese (sing. and
pl.); adjective—Senegalese
Ethnic divisions: 36% Wolof, 17.5% Fulani,
16.5% Serer, 9% Toucouleur, 9% Diola, 6.5%
Mandingo, 4.5% other African, 1% European
and Lebanese
Religion: 92% Muslim, 6% indigenous be-
liefs, 2% Christian (mostly Roman Catholic)
Language: French (official); Wolof, Pulaar,
Diola, Mandingo
Literacy: 10%
Labor force: 1,732,000; 70% subsistence agri-
cultural workers; 175,000 wage earners—
40% private sector, 60% government and
parapublic
201
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Organized labor: majority of wage-labor
force represented by unions; however, dues-
paying membership very limited; major
confederation is National Confederation of
Senegalese Labor (CNTS), an affiliate of gov-
erning party','62ebeb4209e945186381e4b7673e80336f5e157744f16ee96f3db0a3597a4e6d','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06803f32a2c42b6f1aa27a173b70fc698c74140ab2968da3a9a7eb1473fbde56',1985,'SC','Seychelles','people-and-society',495,'Population: 66,000 (July 1985), average an-
nual growth rate 0.9%
Nationality: noun—Seychellois (sing. and
pl.); adjective—Seychelles
Ethnic divisions: Seychellois (mixture of
Asians, Africans, Europeans)
Religion: 90% Roman Catholic, 8% Anglican,
2% other
Language: English and French (official),
Creole ©
Literacy: 60%
Labor force: 15,000 in monetized sector (ex-
cluding self-employed, domestic servants,
and workers on small farms); 49% govern-
ment, 19% industry and commerce, 18.5%
agriculture, 13.5% services
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Organized labor: 3 major trade unions','fcf2182cc8ac011e15dcde6fd95d092db778a09d7bce2d62ed4bf960f917c82e','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('623efe5cf55afbe305f51ba1c0a93088627a20850df773a4c6e991c6563b233d',1985,'SL','Sierra Leone','people-and-society',499,'Population: 3,883,000 (July 1985), average
annual growth rate 2.6%
Nationality: noun—Sierra Leonean(s); adjec-
tive—Sierra Leonean
Ethnic divisions: over 99% native African
(30% Temne, 30% Mende, 2% Creole), rest
European and Asian; 18 tribes
Religion: 60% Muslim, 30% indigenous be-
liefs, 10% Christian
Language: English (official); regular use lim-
ited to literate minority; principal
vernaculars are Mende in south and Temne
in north; “Krio,” the language of the resettled
exslave population of the Freetown area, is
used as a lingua franca
Literacy: about 15%
Labor force: about 1.5 million; most of popu-
lation engages in subsistence agriculture;
only small minority, some 65,000, earn wages
Organized labor: 35% of wage earners
Population: 2,562,000 (July 1985), average
annual growth rate 1.2%
Nationality: noun—Singaporean(s), adjec-
tive—Singapore
Ethnic divisions: 76.7% Chinese, 14.7% Ma-
lay, 6.4% Indian, 2.2% other
Religion: majority of Chinese are Buddhists
or atheists; Malays nearly all Muslim; minor-
ities include Christians, Hindus, Sikhs,
Taoists, Confucianists
Language: Chinese, Malay, Tamil, and En-
glish (official); Malay (national)
Literacy: 84.2%
Labor force: 1,142,374 (June 1982); 29.5%
manufacturing, 28.5% services, 22.3% trade.
11.4% transport and communication, 6.3%
construction, 1.0% agriculture and fishing,
1.0% other
>
205
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Organized labor: 18.6% of labor force','b2faef5247dbe041ca5b172f525b821269586f785d9cae93774e134fb33518b8','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11c9f0340a728330e9b30d4e948a4e9a3beb3cc36bb5ba7c732e08a24966ef99',1985,'SB','Solomon Islands','people-and-society',503,'Population: 273,000 (July 1985), average an-
nual growth rate 3.7%
Nationality: noun—Solomon Islander(s); ad-
jective—Solomon Islander
Ethnic divisions: 93.0% Melanesian, 4.0%
Polynesian, 1.5% Micronesian, 0.8% Euro-
pean, 0.3% Chinese, 0.4% other
Religion: almost all at least nominally Chris-
tian; Roman Catholic, Anglican, and
Methodist churches dominant
Language: English (official), local languages
Literacy: 60%
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Labor force: 20,631 economically active
(1980); 30% forestry and fishing, 28.2% social
services, 10.8% manufacturing, 9.6% com-
merce, 7.7% construction, 7.1% transpor-
tation and communications','7e62b503817fff02a1104cbc61050eed1fb0b0be4312600fd34c4116451f09fc','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd28e4ac0a5ea83ba40890204e60502bfcd05615781dc728b129ea7f03c59c03',1985,'SO','Somalia','people-and-society',507,'Population: 7,595,000 (July 1985), average
annual growth rate 3.0%
Nationality: noun—Somali(s); adjective—
Somali
Ethnic divisions: 85% Somali, rest mainly
Bantu; 30,000 Arabs, 3,000 Europeans, 800
Asians
Religion: almost entirely Sunni Muslim
Language: Somali (official); Arabic, Italian,
English
Literacy: 60%
Labor force: about 2.2 million; very few are
skilled laborers; 70% pastoral nomad, 30% ag-
riculturists, government employees, traders,
fishermen, handicraftsmen, other
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Somalia (continued)
Organized labor: General Federation of So-
mali Trade Unions, a government-controlled
organization, established in 1977','92930290fb38ebd1d5591d4e65d8494d63d1710a516c8ffac7411714819fff9b','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50bfdb6b05328a4a8289b1113f7d76021f123e026ee85d9afc6da007c3eaaf78',1985,'ZA','South Africa','people-and-society',510,'Population: 32,465,000 (July 1985), includ-
ing Bophuthatswana, Ciskei, Kwazulu,
Lebowa, Transkei, and Venda; average an-
nual growth rate 2.4%; Bophuthatswana
1,623,000 (July 1985), average annual growth
rate 3.9%; Ciskei 763,000 (July 1985), average
annual growth rate 2.3%; Kwazulu 4,347,000
(July 1985), average annual growth rate 4.6%;
Lebowa 2,208,000 (July 1985), average an-
nual growth rate 4.5%; Transkei 2,960,000
(July 1985), average annual growth rate 3.4%;
Venda 412,000 (July 1985), average annual
growth rate 2.7%
Nationality: noun—South African(s); adjec-
tive—South African
Ethnic divisions: 69.9% African, 17.8%
white, 9.4% Colored, 2.9% Indian
Religion: most whites and Coloreds and
roughly 60% of Africans are Christian;
roughly 60% of Indians are Hindu, 20% Mus-
lim
Language: Afrikaans, English (official); Afri-
cans have many vernacular languages,
including Zulu, Xhosa, North and South So-
tho, Tswana
Literacy: almost all white population literate;
government estimates 50% of Africans liter-
ate
Labor force: 8.7 million economically active
(1980); 53% agriculture, 27% miscellaneous
services, 8% manufacturing, 7% mining, 5%
commerce
Organized labor: about 7% of total labor
force is unionized (mostly white workers); Af-
rican unions represent less than 15% of black
labor force
Population: 277,930,000 (July 1985), average
annual growth rate 1.0%
Nationality: noun-—Soviet(s), adjective—So-
viet
Ethnic divisions: 52% Russian, 16% Ukrai-
nian, 32% among over 100 other ethnic
groups, according to 1979 census
Religion: 18% Russian Orthodox; 9% Muslim;
3% Jewish, Protestant, Georgian Orthodox, or
Roman Catholic; population is 70% atheist
Language: Russian (official); more than 200
languages and dialects (at least 18 with more
than 1 million speakers); 75% Slavic group,
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
8% other Indo-European, 12% Altaic, 3%
Uralian, 2% Caucasian
Literacy: 99.8%
Labor force: civilian 147 million (midyear
1982), 20% agriculture, 80% industry and
other nonagricultural fields; unemployed not
reported; shortage of skilled labor reported','7dd47558c0a242a053b1a32bb1d74641a31385ef21f19f4bba608eb23072e568','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('692618c77091d872c9210bf5bd3b56fe2eba4e195a1adaf87ac28c1538238e89',1985,'ES','Spain','people-and-society',513,'Population: 38,629,000 (July 1985), includ-
ing the Balearic and Canary Islands and
Ceuta and Melilla (two towns on the Moroc-
can coast); average annual growth rate 0.5%
é é
Nationality: noun—Spaniard(s); adjective—
Spanish
Ethnic divisions: composite of Mediterra--
nean and Nordic types
Religion: 99% Roman Catholic, 1% other .
sects
Language: Castilian Spanish; second ba
guages include 17% Catalan, 7% Galician, ,
and 2% Basque |
Literacy: 97%
212
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Labor force: 13.2 million (1984); 43% ser- ,
vices, 24% industry, 16% agriculture, 9%
construction; unemployment now estimated
at nearly 20.5% of labor force (September
1984) ‘
Organized labor: labor unions legalized April
1977; represent no more thana quarter of the
labor force (1983)
Government i
Official name: Spanish State
Type: parliamentary monarchy defined by
new constitution of December 1978, that
completed transition from authoritarian re-
gime of the late Generalissimo Franco and
confirmed Juan Carlos I as monarch, but
without the exceptional powers inherited
from Franco on being proclaimed King 22.
November 1975
Capital: Madrid : ;
Political subdivisions: metropolitan Spain,
including the Canaries and Balearics, di-
vided into 50 provinces, which form 17
autonomous regions assuming numerous
powers previously exercised by the central
government; also five places of sovereignty
(presidios) on the Mediterranean coast of Mo-
rocco; transferred administration of Spanish
Sahara to Morocco and Mauritania on 26
February 1976
Legal system: civil law system, with regional
applications; new constitution provides for
rule of law, established jury system as well as
independent constitutional court to rule on’
unconstitutionality of laws and to serve as
court of last resort in protecting liberties and
rights granted i in constitution; does not accept
compulsory ICJ jurisdiction
National holiday: 24 June
Branches: executive, with King’s acts subject
to countersignature, Prime Minister
(Presidente) and his ministers responsible to
lower house; bicameral legislature—Cortes
Generales, consisting of more powerful Con-
gress of Deputies (8350 members) and Senate
(208 members), with possible addition of one
to six members from each new autonomous
region; judiciary, independent
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Government leaders: JUAN CARLOS I,
King (since November 1975); Felipe GON-
ZALEZ Marquez, Prime Minister
(Presidente; since December 1982)
Suffrage: universal at age 18
Elections: parliamentary election 28 Octo-
ber 1982 for four-year term; local elections
for municipal councils April 1983; regional
elections staggered
Political parties and leaders: principal na-
tional parties, from right to left—-Popular
Alliance (AP), Manuel Fraga Iribarne; Popu-
lar Democratic Party (PDP), Oscar Alzaga;
Liberal Union (UL), José Antonio Segurado;
Social Democratic Center (CDS), Adolfo
Sudrez; Spanish Socialist Workers Party
(PSOE), Felipe Gonzalez Marquez; Spanish
Communist Party (PCE), Gerardo Iglesias;
chief regional parties—Convergence and
Unity (CiU), Jordi Pujol, in Catalonia; Re-
publican Left of Catalonia (ERC), Herribert
Barrera; Basque Nationalist Party (PNV), Ro-
man Sudure; Basque radical coalitions
Popular Unity (HB) and Basque Left (EE);
Andalusian Party (PA), Luis Urufiuela; Dem-
ocratic Reform Party (PRD), Antonio
Garrigues Walker
Voting strength: (1982 parliamentary elec-
tion in lower house) PSOE 46%, and 202 seats
(26 seats over a majority); AP, PDP, and UL in
coalition 25.4%, 106 seats; UCD 7.31%, 12
seats; PCE 3.9%, 4 seats; CiU 3.7%, 12 seats;
CDS 2.9%, 2 seats; PNV 1.9%, 8 seats; HB 1%,
2 seats: EE .47%, 1 seat; ERC .47%, 1 seat; PA
.33% 0 seats
Communists: PCE membership has de-
clined from a possible high of 160,000 in 1977
to roughly 60,000 today; the party lost 64% of
its voters and 20 deputies in the 1982 election;
remaining strength is in labor where it domi-
nates the Workers Commissions trade union
(one of the country’s two major labor cen-
trals), which claims a membership of about 1
million; experienced a modest recovery in
1983 municipal election, receiving 8% of the
vote
Other political or pressure groups: on the ex-
treme left, the Basque Fatherland and
Liberty (ETA) and the First of October
Antifascist Resistance Group (GRAPO) use
terrorism to oppose the government; free la-
bor unions (authorized in April 1977) include
the Communist-dominated Workers Com-
missions (CCOO); the Socialist General
Union of Workers (UGT), and the smaller in-
dependent Workers Syndical Union (USO);
the Catholic Church; business and landown-
ing interests; Opus Dei; university students
Member of: Andean Pact (observer),
ASSIMER, Council of Europe, ESRO, FAO,
GATT, IAEA, IBRD, ICAC, ICAO, ICES,
ICO, IDA, IDB—Inter-American Develop-
ment Bank, IEA, IFAD, IFC, IHO, ILO,
IMF, IMO, INTELSAT, International Lead
and Zinc Study Group, INTERPOL, IOOC,
IPU, ITC, ITU, IWC—International Wheat
Council, NATO, OAS (observer), OECD,
UN, UNESCO, UPU, WHO, WIPO, WMO,
WSG, WTO; applied for full membership in
the EC 28 July 1977','935a8143a64c8985fc740c2206dcc793d687f6a352672590e23b5332638effca','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08769b6fd0d2daeefb874551464562ea818b8965556538b6fc6fbe5146fdd995',1985,'LK','Sri Lanka','people-and-society',515,'Population: 16,206,000 (July 1985), average
annual growth rate 1.8%
Nationality: noun—Sri Lankan(s); adjec-
tive—Sri Lankan
Ethnic divisions: 74% Sinhalese; 18% Tamil;
7% Moor; 1% Burgher, Malay, and Veddoh
Religion: 69% Buddhist, 15% Hindu, 8%
Christian, 8% Muslim, 0.1% other
Language: Sinhala (official); Sinhala and
Tamil listed as national languages; Sinhala
spoken by about 74% of population; Tamil
spoken by about 18%; English commonly
used in government and spoken by about 10%
of the population
Literacy: 87%
Labor force: 4 million; 15% unemployed;
employed persons—45.9% agriculture,
13.3% mining and manufacturing, 12.4%
214
trade and transport, 26.3% services and
other; extensive underemployment
Organized labor: about 33% of labor force,
over 50% of which employed on tea, rubber,
and coconut estates','8a685b276e9b5aaaa3b31868ad3c090769f79c00691b23eab9e8012d2ff11adb','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49028dbd54aa3f950901ba5bd4af71683f5185e757cdf659429f1b5fae5fdb50',1985,'SD','Sudan','people-and-society',519,'Population: 21,761,000 (July 1985), average
annual growth rate 2.7%
Nationality: noun—Sudanese (sing. and pl.);
adjective—Sudanese
Ethnic divisions: 52% black, 39% Arab, 6%
Beja, 2% foreigners, 1% other
Religion: 70% Sunni Muslim in north, 20%
indigenous beliefs, 5% Christian (mostly in
south)
Language: Arabic (official), Nubian, Ta
Bedawie, diverse dialects of Nilotic, Nilo-
Hamitic, and Sudanic languages, English;
program of Arabization in process
Literacy: 20%
Labor force: 8.6 million (1979); roughly 78%
agriculture, 12% services, 10% industry; la-
bor shortages for almost all categories of
employment coexist with urban unemploy-
ment','17b4bd09d84cd51ab83e37ad54be9e467e9ac4f44db206b103cc1171d364a3d2','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('538d097bf41cc493526cd3f9b2b316a0662a3535bb30a04b617a3f2e7acd9b37',1985,'SR','Suriname','people-and-society',523,'Population: 377,000 (July 1985), average an-
nual growth rate 1.8%
Nationality: noun—Surinamer(s); adijec-
tive-—Surinamese
Ethnic divisions: 37% Hindustani (East In-
dian), 31% Creole (black and mixed), 15.3%
Javanese, 10.3% Bush Negro, 2.6% Amerin-
dian, 1.7% Chinese, 1.0% Europeans, 1.7%
other
Religion: Hindu, Muslim, Roman Catholic,
Moravian, other
Language: Dutch (official); English widely
spoken; Sranang Tongo (Surinamese, some-
times called Taki-Taki) is native language of
Creoles and much of the younger population
and is lingua franca among others; Hindi; Ja-
vanese
217
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Literacy: 65%
Labor force: 100,000; unemployment 20%
(1983)
Organized labor: approx. 33% of labor force
Population: 671,000 (July 1985), average an-
nual growth rate 3.0%
Nationality: noun—Swazi(s); adjective—
Swazi
Ethnic divisions: 96% African, 3% European,
1% mulatto
Religion: 57% Christian, 43% indigenous be-
liefs
Language: English and siSwati (official); gov-
ernment business conducted in English
Literacy: 65%
Labor force: 195,000; over 60,000 engaged in
subsistence agriculture; 55,000-60,000 wage
earners, many only intermittently, with 36%
agriculture and forestry, 20% community
and social services, 14% manufacturing, 9%
construction, 21% other; 12,000 employed in
South Africa (1982)
Organized labor: about 15% of wage earners
are unionized','3415d5c0120ea05a80a9bdc5d665e816525b8f0609dc0878ae06fcaef2408c75','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c4ced858b34f7e5fb082172b478e39c37ded9211d465e008b30320cfeb82723',1985,'SE','Sweden','people-and-society',527,'Population: 8,338,000 (July 1985), average’
annual growth rate 0%
Nationality: noun—Swede(s); adjective—
Swedish
Ethnic divisions: homogeneous white popu-
lation; smal] Lappish minority; est. 12%
foreign born or first generation immigrants
(Finns, Yugoslavs, Danes, Norwegians,
Greeks)
Religion: 93.5% Evangelical Lutheran, 1.0%
Roman Catholic, 5.5% other
Language: Swedish, small Lapp- and Finn-
ish-speaking minorities; immigrants speak
native languages
Literacy: 99%
Labor force: 4.35 million; 31% private ser-
vices; 30.6% government services; 21.9%
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
mining and manufacturing; 7.2% construc-
tion; 5.2% agriculture, forestry, and fishing;
0.9% electricity, gas, and waterworks; 3.5%
unemployed (1983 average)
Organized labor: 80% of labor force','292c9b642d19bed4f13ff1747a48f8b87557a4ac98fce61a8bda41d454ce84a5','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffbff1a727757c32a17efe929cf825c1ff7b31d043dfbcfac4b64c95802cda9d',1985,'CH','Switzerland','people-and-society',531,'Population: 6,512,000 (July 1985), average
annual growth rate 0.2%
Nationality: noun—Swiss (sing. & pl.); adjec-
tive—Swiss
Ethnic divisions: total population—65%
German, 18% French, 10% Italian, 1% Ro-
mansch, 5% other; Swiss nationals—74%
German, 20% French, 4% Italian, 1% Ro-
mansch, 1% other
Religion: 49% Catholic, 48% Protestant, 0.3%
Jewish
Language: total population—65% German,
18% French, 12% Italian, 1% Romansch, 4%
other; Swiss nationals—74% German, 20%
French, 4% Italian, 1% Romansch, 1% other
Literacy: 99%
Labor force: 3.05 million, about 706,000 for-
eign workers, mostly Italian; 42% services,
39% industry and crafts, 11% government,
7% agriculture and forestry, 1% other; ap-
proximately 0.8% unemployed in October
1983
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Switzerland (continued)
Organized labor: 20% of labor force
Population: 10,535,000 (July 1985), average
annual growth rate 3.7%
Nationality: noun—Syrian(s); adjective—
Syrian
Ethnic divisions: 90.3% Arab; 9.7% Kurds,
Armenians, and other
Religion: 74% Sunni Muslim; 16% Alawite,
Druze, and other Muslim sects; 10% Chris-
tian (various sects)
Language: Arabic (official), Kurdish, Arme-
nian, Aramaic, Circassian; French and
English widely understood
Literacy: about 50%
Labor force: 2.8 million; 37% miscellaneous
services, 32% agriculture, 31% industry
223
(including construction); majority unskilled;
shortage of skilled labor
Organized labor: 5% of labor force','7c7042d321b71accebb9546588bd0eba92f7e0aef547deff62c3cd372fabb7d9','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7522cf4727b2ff5378312abecd2c2d19b18a4b9adf60d1438d2ac5823fa2823a',1985,'TG','Togo','people-and-society',535,'Population: 3,018,000 (July 1985), average
annual growth rate 3.1%
Nationality: noun—Togolese (sing. and pl.);
adjective—Togolese
Ethnic divisions: 37 tribes; largest and most
important are Ewe, Mina, and Kabyé; under
1% European and Syrian-Lebanese
Religion: about 70% indigenous beliefs, 20%
Christian, 10% Muslim
Language: French, both official and lan-
guage of commerce; major African languages
are Ewe and Mina in the south and Dagomba
and Kabyé in the north
Literacy: 18%
Labor force: 78% agriculture, 22% industry;
about 88,600 wage earners, evenly divided
between public and private sectors
227
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Organized labor: one national union, the Na-
tional Federation of Togolese Workers','3d6fac237ff567a5c8a3d6524fe9bd87c014b6cf57062cf8b8832dfd8e609756','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e0780ae59ea2b95ab245e3ad79faaf4ce31b65683930bb35c74c1310defdd41',1985,'TO','Tonga','people-and-society',539,'Population: 107,000 (July 1985), average an-
nual growth rate 1.9%
Nationality: noun—Tongan(s); adjective—
Tongan
Ethnic divisions: Polynesian; about 300 Eu-
ropeans
Religion: Christian; Free Wesleyan Church
claims over 30,000 adherents
Language: Tongan, English
Literacy: 90-95%; compulsory education for
children ages 6-14
Labor force: agriculture 10,300; mining 600','868d54b962409e1ca097536caab2e03c419cb6d36281ff87a895f73cc240d3fc','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('599f3a59dcccc73779db97e0f4b42200664eb3f88618c49ccf66335191597ddf',1985,'TT','Trinidad and Tobago','people-and-society',543,'Population: 1,185,000 (July 1985), average
annual growth rate 1.5%
Nationality: noun—Trinidadian(s),
Tobagan(s); adiective—Trinidadian,
Tobagan
Ethnic divisions: 43% black, 40% East In-
dian, 14% mixed, 1% white, 1% Chinese, 1%
other
Religion: 36.2% Roman Catholic, 23%
Hindu, 13.1% Protestant, 6% Muslim, 21.7%
unknown
Language: English (official), Hindi, French,
Spanish
Literacy: 95%
Labor force: about 473,000 (est. 1979-81);
23.0% service; 20.0% mining, quarrying, and
manufacturing; 17.4% commerce; 15.7%
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
(continued)
construction and utilities; 13.5% agriculture;
7.5% transportation and communication;
2.9% other
Organized labor: 30% of labor force','c3ea5c130f2166defd02cbc10486f7051b2c7b647770f2aed78d57306921cfcd','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d311b923cefb7d8e0a720630292767e8650253db73e147a3c044943b4c75737b',1985,'TN','Tunisia','people-and-society',547,'Population: 7,352,000 (July 1985), average
annual growth rate 2.4%
Nationality: noun—Tunisian(s); adjective—
Tunisian
Ethnic divisions: 98% Arab, 1% European,
less than 1% Jewish
Religion: 98% Muslim, 1% Christian, less
than 1% Jewish
Language: Arabic (official); Arabic and
French (commerce)
Literacy: about 62%
Labor force: 1.9 million, 32% agriculture;
15%-25% unemployed; shortage of skilled
labor
Organized labor: about 360,000 members
claimed, roughly 20% of labor force; General
Union of Tunisian Workers (UGTT), quasi-
independent of Destourian Socialist Party','f39df124c103bb02d482c3c5bb5c217c939e0e30f6b810699f39e4cb9c1193b7','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42eac2d691de16f74db1dbfd558a39f62d5f1e74eefd3640fd1a0c2eaad31e31',1985,'TC','Turks and Caicos Islands','people-and-society',552,'Population: 7,436 (1980)
Ethnic division: majority of African descent
Religion: Anglican, Roman Catholic, Baptist,
Methodist, Church of God, Seventh-day Ad-
ventist ‘
Language: English (official)
Literacy: about 99%
Labor force: some subsistence agriculture;
majority engaged in fishing and tourist indus-
tries
Organized labor: St. George’s Industrial
Trade Union (Cockburn Harbor), 250 mem-
bers','cc2d4ca2b7ce4103df9c9c40bd444eb07390d7ad314f474de888689cf601b8b3','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d2ab8fd5c328fb241f3efe2ff7c2dc8f3ca72e7df1fd0acf94a93dd04290898',1985,'TV','Tuvalu','people-and-society',556,'Population: 8,000 (July 1985), average an-
nua! growth rate 1.7%
Nationality: noun—Tuvaluans(s); adjec-
tive—Tuvaluan
Ethnic divisions: 96% Polynesian
Religion: Christian, predominantly Protes-
tant Oo
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Language: Tuvaluan, English
Literacy: less than 50%','e5d518434d1bf4f8704f23513a8218f8ee155c001ea5f6cf0c155be2fabecd63','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfb338b241fca5205dce91cecb607ed0625ff987135901ee4daf6c95d29b6a25',1985,'UG','Uganda','people-and-society',561,'Population: 14,733,000 (July 1985), average
annual growth rate 3.2%
Nationality: noun—Ugandan(s); adjective—
Ugandan
Ethnic divisions: 99% African, 1% European,
Asian, Arab
Religion: 33% Roman Catholic, 33% Protes-
tant, 16% Muslim, rest indigenous beliefs
Language: English (official); Luganda and
Swahili widely used; other Bantu and Nilotic
languages
Literacy: 52%
Labor force: estimated 4.5 million; about
250,000 in paid labor; remainder in subsis-
tence activities
Organized labor: 125,000 union members','f34ed06b5121c03ea907200c26c8920772688a0e7e65009d5057a21123ba52fe','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81718a8663a749a2dc914dd5dcb493615a5e2173079b0bc5a065cf62ca612a11',1985,'AE','United Arab Emirates','people-and-society',564,'Population: 1,320,000 (July 1985), average
annual growth rate 4.4%
Nationality: Noun—Emirian(s), adjective—
Emirian
Ethnic divisions: Emirian 19%, other Arab
23%, South Asian 50% (fluctuating), other ex-
patriates (includes Westerners and East
Asians) 8%; fewer than 20% of the population
are UAE citizens (1982)
Religion: Muslim 96%; Christian, Hindu, and
other 4%
Language: Arabic (official); Farsi and En-
glish widely spoken in major cities; Hindi,
Urdu
Literacy: 56.3% est.
Labor force: 541,000 (1980 est.); 85% indus-
try and commerce, 5% agriculture, 5%
services, 5% government; 80% of labor force
is foreign','c2ba2553bafc68911396b60770442087aae018853cee3605ed0c645dee70807c','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7af725a1abda3ae4126a03ff66f6c7b7d3af1b2a6b35996f547d345919bf22eb',1985,'GB','United Kingdom','people-and-society',567,'Population: 56,437,000 (July 1985), average
annual growth rate 0.1%
Nationality: noun—Briton(s), British (collec-
tive pl.); adjective—British
Ethnic divisions: 81.5% English, 9.6% Scot-
tish, 2.4% Irish, 1.9% Welsh, 1.8% Ulster,
0.8% other; West Indian, Indian, Pakistani
2%
Religion: 27.0 million Anglican, 5.3 million
Roman Catholic, 2.0 million Presbyterian,
760,000 Methodist, 450,000 Jewish (regis-
tered)
Language: English, Welsh (about 26% of
population of Wales), Scottish form of Gaelic
(about 60,000 in Scotland)
Literacy: 99%
238
Labor force: (1982) 26.08 million; 54.4% in-
dustry and commerce, 29.9% services, 7.6%
self-employed, 6.6% government, 1.5% agri-
culture; 12.5% unemployed (early 1984)
Organized labor: 40% of labor force','244dc767093196042d8c0f0aec4d20affbe54ce552cb7ca24ba3f4a52a872e9c','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e6132862544099c5e9066400001937e6fe910d2d6e78a226c896f43bfbc0a13',1985,'US','United States','people-and-society',571,'Population: 238,848,000 (July 1985), average
annual growth rate 0.9%
Ethnic divisions: 80% white; 11% black; 6.2%
Spanish origin; 1.6% Asian and Pacific Is-
lander; 0.7% American Indian, Eskimo, and
Aleut (1980)
Religion: total membership in religious bod-
ies 134.8 million; Protestant 73.479 million,
Roman Catholic 50.45 million, Jewish 5.92
million, other religions 4.968 million (1982)
Language: predominantly English; sizable
Spanish-speaking minority
Literacy: 99.5% of total population 15 years
or older
Labor force: 115.786 million (includes 2.208
million members of the armed forces in the
US); unemployment rate 7.2% (1985); 10.411
million unemployed (January 1984)
Organized labor: approximately 17.4 million
members; 18.8% of civilian labor force (1984)','3be3dc045d5048084123bb21addac7ab70aec862585b8df08ef46b95759f90b0','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fa2cf8847c31fee83420ccc804617b81b82aa7760474211b4608afd42c366ad',1985,'UY','Uruguay','people-and-society',575,'Population: 2,936,000 (July 1985), average
annual growth rate 0.3%
Nationality: noun—Uruguayan(s); adiec-
tive—Uruguayan
Ethnic divisions: 85-90% white, 5-10% mes-
tizo, 3-5 black
Religion: 66% Roman Catholic (less than half
adult population attends church regularly),
2% Protestant, 2% Jewish, 30% nonprofessing
or other
Language: Spanish
Literacy: 94.3%
Labor force: about 1.28 million (1981); 19%
manufacturing; 19% government; 16% agri-
culture; 12% commerce; 12% utilities,
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Uruguay (continued)
construction, transport, and communica-
tions; 22% other services; unemployment
more than 15% (1984 est.)
Organized labor: government authorized
non-Communist union activities in 1981 for
the first time since 1973 military takeover','077c841bef9449172c6929f581bff8cbc3d91835cf0d900435d787befe9d1913','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74955bb9ea6f629ce72e23084f2bdc2c51a0b869363421f8be7edc15ea6a7302',1985,'VU','Vanuatu','people-and-society',579,'Population: 134,000 (July 1985), average an-
nual growth rate 2.7%
Nationality: noun—Vanuatuan(s); adjec-
tive—Vanuatuan
Ethnic divisions: 90% indigenous Melane-
sian; 8% French; remainder Vietnamese,
Chinese, and various Pacific Islanders
Religion: most at least nominally Christian
Language: English and French (official); pid-
gin (known as Bislama or Bichelama)
Literacy: probably 10-20%
Population: 1,000 (July 1985), average an-
nual growth rate 0.1%
Ethnic divisions: primarily Italians but also
many other nationalities
Religion: Roman Catholic
Language: Italian, Latin, and various other
languages
Literacy: 100%
Labor force: approx. 700; Vatican City em-
ployees divided into three categories—
executives, office workers, and salaried em-
ployees
Organized labor: none
Population: 17,810,000 (July 1985), average
annual growth rate 3%
Nationality: noun—Venezuelan(s); adjec-
tive—Venezuelan
Ethnic divisions: 67% mestizo, 21% white,
10% black, 2% Indian
Religion: 96% nominally Roman Catholic,
2% Protestant
Language: Spanish (official); Indian dialects
spoken by about 200,000 Amerindians in the
remote interior
Literacy: 85.6%
Labor force: 5.5 million (1984); 27% services;
22% commerce; 16% agriculture; 16% manu-
facturing; 9% construction; 7% transporta-
tion; 38% petroleum, utilities, and other
Organized labor: 32% of labor force','6f96c7987aa483f0c5241611f877e21a7547a78faab05f485b88da63530f1b40','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b61fb126c9242fba26db578c1f0dd06dfdaa6a4e9af93f684a6ae69434c0de7a',1985,'WF','Wallis and Futuna','people-and-society',583,'Population: 12,000 (July 1985) average an-
nual growth rate 2.5%
Nationality: noun—Wallisian(s), Futunan(s),
or Wallis and Futuna Islanders; adjective—
Wallisian, Futunan, or Wallis and Futuna Is-
lander
Ethnic divisions: almost entirely Polynesian
Religion: largely Roman Catholic','c0e971d4c284824d17a037fb403f496e1b42bf9cd48984ee1bb89d04d694b710','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c727edf935a4180b57c3e9c90b383944479250c6ac97e23a66aabdd4a6516ad',1985,'EH','Western Sahara','people-and-society',587,'Population: 91,000 (July 1985), average an-
nual growth rate 1.8%
Nationality: noun—Saharan(s), Moroccan(s);
adjective—Saharan, Moroccan
Ethnic divisions: Arab and Berber
Religion: Muslim
Language: Hassaniya Arabic, Moroccan Ar-
abic
Literacy: among Moroccans, probably nearly
20%; among Saharans, perhaps 5%
Labor force: 12,000; 50% animal husbandry
and subsistence farming, 50% other
Organized labor: none
Population: 163,000 (July 1985), average an-
nual growth rate 0.9%
Nationality: noun—Western Samoan(s); ad-
jective—Western Samoa
Ethnic divisions: Samoan; about 12,000
Euronesians (persons of European and Poly-
nesian blood), 700 Europeans’
Religion: 99.7% Christian (about half of
population associated with the London Mis-
sionary Society; includes Congregational,
Roman Catholic, Methodist, Latter Day
Saints, Seventh Day Adventist)
Language: Samoan (Polynesian), English
Literacy: 90%
Labor force: about 37,000 (1983); about
22.000 employed in agriculture
249
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
4
Organized labor: none
Population: 6,058,000 (July 1985), average
annual growth rate 2.7%
Nationality: noun—Yemeni(s); adjective—
Yemeni
Ethnic divisions: 90% Arab, 10% Afro-Arab
(mixed)
Religion: 100% Muslim (Sunni and Shi‘a)
Language: Arabic
Literacy: 15% (est.)
Labor force: approximately one-third ex-
patriate laborers; remainder almost entirely
agriculture and herding','402513623c2842f4e4517ebcb9ab8df4ebdcb41db22b57776880f41db79fb299','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f021a15d3193c700e85537c5d80ba1e1040b4a4046f3befd8ae09defa8d4669b',1985,'YE','Yemen','people-and-society',591,'Population: 2,211,000, excluding the islands
of Perim and Kamaran, for which no data are
available (July 1985); average annual growth
rate 2.9%
Nationality: noun—Yemeni(s); adjective—
Yemeni
Ethnic divisions: almost all Arabs; a few Indi-
ans, Somalis, and Europeans
Religion: Sunni Muslim, some Christian and
Hindu
Language: Arabic
Literacy: 25%
251
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
" Population: 23,137,000 (July 1985), average
annual growth rate —0.7%
Nationality: noun—Yugoslav(s); adjective—
Yugoslav
Ethnic divisions: 36.2% Serb, 19.7% Croat,
8.9% Muslim, 7.8% Slovene, 7.7% Albanian,
5.9% Macedonian, 5.4% Yugoslav, 2.5% Mon-
tenegrin, 1.9% Hungarian, 4.0% other (1981
census)
Religion: 41% Serbian Orthodox, 32% Ro-
man Catholic, 12% Muslim, 3% other, 12%
none (1953 census; later information unavail-
able)
Language: Serbo-Croatian, Slovene, Mac-
edonian (all official); Albanian, Hungarian,
Italian
Literacy: 85%
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Labor force: 9.7 million (1983); 29% agricul-
ture, 24% mining and manufacturing, 11%
noneconomic activities; (est.) unemployment
about 15% of domestic labor force
Population: 32,985,000 (July 1985), average
annual growth rate 2.9%
Nationality: noun—Zairian(s); adjective—
Zairian
Ethnic divisions: over 200 African ethnic
groups, the majority are Bantu; four largest
tribes—Mongo, Luba, Kongo (all Bantu), and
the Mangbetu-Azande (Hamitic) make up
about 45% of the population
Religion: 50% Roman Catholic, 20% Protes-
tant, 10% Kimbanguist, 10% Muslim, 10%
other syncretic sects and traditional beliefs
Language: French (official), English, Lin-
gala, Swahili, Kingwana, Kikongo, and
Tshiluba
Literacy: 40% males, 15% females
Labor force: about 8 million, but only about
13% in wage structure
254','2440673ddc78da5b64239ee77c598600be85cb08ea11b883810beeedc0b52e51','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9f1a38f57b869bbf18b44fd5458c018bfddc142465d8ced63682d7ca72e82c5',1985,'ZM','Zambia','people-and-society',595,'Population: 6,770,000 (July 1985), average
annual growth rate 3.2%
Nationality: noun—Zambian(s), adjective—
Zambian
Ethnic divisions: 98.7% African, 1.1% Euro-
pean, 0.2% other
Religion: 50-75% Christian, 1% Muslim and
Hindu, remainder indigenous beliefs
Language: English (official); about 70 indige-
nous languages
Literacy: 54%
Labor force: 402,000 wage earners; 375,000
Africans, 27,000 non-Africans; 23% govern-
ment and miscellaneous services, 19%
construction, 15% mining, 10% manufactur-
ing, 9% agriculture, 9% domestic service, 9%
commerce, 6% transport
Organized labor: approximately 238,000
wage earners are unionized
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Zambia (continued)','62aedadde5e17bcd84c752a6b431e64ff4897abdbe1929c984fbcce6d30872ab','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('960bcc7de45e95652e39504d70c96a7b5626102f8dd014bc0f8e32584584777c',1985,'ZW','Zimbabwe','people-and-society',599,'Population: 8,667,000 (July 1985), average
annual growth rate 3.3%
Nationality: noun—Zimbabwean(s); adjec-
tive—Zimbabwean
Ethnic divisions: about 97% African (over
77% members of Shona-speaking subtribes,
19% speak Ndebele); about 3% white, 1%
mixed and Asian
Religion: 50% syncretic (part Christian, part
indigenous beliefs), 25% Christian, 24% in-
digenous beliefs, a few Muslim
Language: English (official), ChiShona and
Si Ndebele
Literacy: 45-55%
Labor force: 1,048,000 (1981); 35% agricul-
ture; 25% mining, manufacturing,
construction; 40% transport and services
Organized labor: about one-third of Euro-
pean wage earners are unionized, but only a
small minority of Africans
Population: 19,358,000, excluding the popu-
lation of Quemoy and Matsu Islands and
foreigners (July 1985), average annual
growth rate 1.5%
Nationality: noun—Chinese (sing., pl.); ad-
jective—Chinese
Ethnic divisions: 84% Taiwanese, 14% main-
land Chinese, 2% aborigine
Religion: 93% mixture of Buddhist, Confu-
cian, and Taoist; 4.5% Christian; 2.5% other
Language: Mandarin Chinese (official); Tai-
wanese and Hakka dialects-also used
Literacy: about 89.7%
Labor force: 7,266,000 (1983); 19% agricul-
ture, 40% industry and commerce, 30%
258
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
services, 7% civil administration; 1.6% unem-
ployment (1983)
Organized labor: about 15% of 1978 labor
force (government controlled)
Population: total, 1,443,000 (July 1985); av-
erage annual growth rate 2.7%; West Bank
(including East Jerusalem)—930,000 July
1984), average annual growth rate 3.3%;
Gaza Strip—508,000 (July 1984), average an-
nual growth rate 3.7% :
Nationality: West Bank—to be determined;
Gaza Strip—to be determined
Ethnic divisions: West Bank—84% Palestin-
ian Arab and other, 12% Jewish, 4% Bedouin;
Gaza Strip—99.8% Palestinian Arab and
other, 0.2% Jewish
Religion: West Bank—80% Muslim (pre-
dominantly Sunni), 12% Jewish, 7% Christian
and other; Gaza Strip—99% Muslim (pre-
dominantly Sunni), 0.8% Christian, 0.2%
Jewish
Language:
West Bank: Arabic; Israeli settlers speak He-
brew; English widely understood
Gaza Strip: Arabic; Israeli settlers speak He-
brew; English widely understood
Literacy: West Bank—statistics unavailable;
Gaza Strip—statistics unavailable
Labor force:
West Bank: (excluding Israeli Jewish settlers)
29.6% small industry, commerce, and busi-
ness; 24.7% construction; 22.6% agriculture;
and 23.1% service and other (1983)
Gaza Strip: (excluding Israeli Jewish settlers)
30.7% small industry, commerce and busi-
260
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
ness; 26.1% construction; 25.2% service and
other; and 18.0% agriculture','3bb421da01b8d1885e2fa5d084a8814bf9a0c293f055f0d960bc4856a1d08e26','internet-archive','cia-readingroom-document-cia-rdp90t01298r000200050001-7','txt','83594a3a0b28a4f11074a0dc44d96016afd200cf854ac2d78486e1f76f11c3cb','https://archive.org/download/cia-readingroom-document-cia-rdp90t01298r000200050001-7/cia-rdp90t01298r000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ffed2cce0a23b3484f360ca39b32a4128edcf119ef837aa1d40a33ae03d734f',1985,'AF','Afghanistan','people-and-society',9,'Population: 14,792,000 (July 1985), average
annual growth rate 1.7%; these estimates in-
clude an adjustment for emigration to
Pakistan during recent years, but they do not
take into account other demographic conse-
quences of the Soviet intervention in
Nationality: noun — Afghan(s); adjective —
Afghan
Ethnic divisions: 50% Pashtun, 25% Tajik,
9% Uzbek, 9% Hazara; minor ethnic groups
include Chahar Aimaks, Turkmen, Baluchi,
and others
R(digion: 74% Sunni Muslim, 25% Shi‘a Mus-
lim, 1% other
Language: 50% Pashtu, 35% Afghan Persian
(Dari), 11% Turkic languages (primarily
Uzl>ek and Turkmen), 10% thirty minor lan-
guages (primarily Baluchi and Pashai); much
bilingualism
Literacy: 12%
Labor force: 4.98 million (1980 est.); 67.8%
agriculture and animal husbandry, 10.2% in-
dustry, 6.3% construction, 5.0% commerce,
7.7% services and other; current figures un-
available because of fighting (1984)
Organized labor: government-controlled
unions are being established','f5e970445f1210100fff6d889f05c65008c7e4c7511750ab0d3fc6e0473cfaaa','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('722497ecdeabc3ebe62481aa466ee20242d4eaee166bdf6ec0069a916d4e1997',1985,'AL','Albania','people-and-society',14,'Population: 2,968,000 (July 1985), average
annual growth rate 2.2%
Nationality: noun — Albanian(s); adjective —
Albanian
Ethnic divisions: 96% Albanian; remaining
4% are Greeks, Vlachs, Gypsies, and
Bulgarians
Religion: Albania claims to be the world’s
first atheist state; prewar est. 70% Muslim,
20% Albanian Orthodox, 10% Roman Catho-
lic; observances prohibited
Language: Albanian (Tosk is official dialect),
Greek
Literacy: 75%
Labor force: 584,000 (1978); about 22% agri-
culture, 40% industry and commerce, 38%
other (1978)
2','b4b0541462b2be5d43ccd903511c93eb247285a9ab880e787f36b00ccdbb4739','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6894e9dde602977fcaf517120845836fc07f874b35194741d57f559e9e178971',1985,'DZ','Algeria','people-and-society',19,'Population: 22S)25Sm {]u\\\\ 1985), average
annual growth rate 3. 1 %
Nationality: noun — Algeriaii(s); adjective —
Algerian
Ethnic divisions: 99% Arab- Berbers, l(\\ss
than 1% Europeans
Religion: 99% Sunni Muslini (state* re''ligioei);
1% (Christian and Jew ish
Arabic (official), hVe*ne''li, Be*rbe*r
dialects
Literacy: 46%
Labor force: 6.7 million (1984); 40% industry
and commerce, 30% agriculture*, 17%'' gov-
ernment, 10% .service''s; at le''ast 1 1%'' e)t urban
labor iinemployt''d
3
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Algeria (continued)
Organized labor: 16-19% of labor force
claimed; General Union of Algerian Workers
(UGTA) is the only labor organization and is
subordinate to the National Liberation Front','a350af6dbf9b53fc93bf62efdea2d9adfcb13eb29266e70eea6c42eaa515fb2d','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7cabee3afa5d500fa4bf475a295e00a9524040c7cf08a908df6e07b1accb6751',1985,'AD','Andorra','people-and-society',22,'Population: 47,(KK) (July 1985), average an-
nual growth rate 5.4%
Nationality: noun — Andorran(s); adjec-
tive — Andorran
Ethnic divisions: ( Catalan stock; 61 % Spanish,
30% Andorran, 6% French, 3% other
Ridi^ion: virtually all Roman Catholic
Languafie: (Catalan (official); many also
speak some French and ("astilian
Literacy: 100%
Lalx)r force: unorganized (unions prohib-
ited); largely sliepherds and farmers','071cd72189568cc9698744779cd8996234097d708aa00e2513317a6422bf8153','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cccedac1aad903d2899efc7bdc608f1eb6425a001f5704018432e416983187ae',1985,'AO','Angola','people-and-society',26,'Population: 7,953,(K)0, including Cabinda
(July 1 985), average annual growth rate 2.7%;
(iabinda, 129,000 (July 1985), average annual
growth rate 3.2%
Nationality: noun — Angolan(s); adjective —
Angolan
Ethnic divisions: 38% Ovimbundu, 23%
Kimlnindu, 13% Bakongo, 2% Mestizo, 1%
Kuropt*an
Religion: 68% Roman Catholic, 20% Protes-
tant, about 10% indigenous beliefs
Language: Portuguese (official); various
Bantu dialects ''
Literacy: 20%
Lalxn force: 1 ,865,000 economically active
(mid-1980 e.st.); 60% agriculture, 15%
industry
Organized labor: approx. 450,695 (1980)','5ec421f2bd2fe7ae9957099b525caee92c0c4af592dd639e430fad7ed2c5c941','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0fb2ccf90ad9a90f098e30bbc2ba7bf030b0dc93f53af799319d255b89db631',1985,'AI','Anguilla','people-and-society',30,'Population: est.)
Nationality: noun — Anguillan(s); adjec-
tive* — Anguillan
Ethnic divisions: mainly of African Negro
descent
Religion: Anglican anel Methodist
Language: Paiglish (official)
Literaey: 80%
Labor force: 2,000 Anguillans living overseas
send remittances home; high unemployment
(40% in 1977)
Organized labor: none','d8289f83c05c575cdf6a866d0a6fda67e53684694ec6745a4e375f49861d0919','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2703fd0f69555b0f64d88f72ee3bc09fdcc04dbcac67ba1c5a881faef8760b64',1985,'AG','Antigua and Barbuda','people-and-society',34,'Population: 80,000 (July 1985), average an-
nual growth rate 0%
Nationality: noun — Antiguan(s); adjective —
Antiguan
Ethnic divisions: almost entirely African
Negro
Religion: Anglican (predominant), other
Protestant sects, some Roman ("atholic
Language: English
Literacy: about 88%
Organized labor: 18,000, 22-26% unemploy-
ment (1983 est.)','2f1be9c835bc94d59d0febf9538fe2580738b0296e8c66a6a560da1f0e3d2c3e','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dffb127484a9f49f27936b9de35c2730df783973b3154af1bf3f3f68fa995ee2',1985,'AR','Argentina','people-and-society',38,'Population: SO JOHSmOuh 1985), averag(‘
annual growth rate 1.6%
Nationality: noun — -Arg(uitin(‘(s); adjec-
tive — Argentine
Ethnic divisions: approximately 85% w hite,
15% mestizo, Indian, or otlu‘r nonw hil<*
groiips
Religion: 90% nominally Homan (Aitholic
(less than 20% practicing), 2%'' Prott‘stant, 2%''
Jewish, 6% other
Lanjgufljgc; Spanish (official), English, Italian,
German, French
Literacy: 94%
9
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Argentina (continued)
lAi}H)r force: 1 1.2 million (1982 est.); 19% ag-
riculture, 25% manufacturing, 20% services,
1 1 % commerce, 6% transport and communi-
cations, 19% other; 6% estimated unem-
ployment (1982 est.)
Organized lalwr: 25% of labor force (est.)','9e479bb0c68e7f01188fa0a43387249f92126867f516483616064fc7d325c34f','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a158798541fc6f0df74ce8df1c051b4b7f8f854c6087c2566d79829cfb53e99b',1985,'AU','Australia','people-and-society',41,'Population: 15,658,000 (July 1985), average
annual growth rate 1.3%
Nationality: noun— Australian(^; adjec-
tive — Australian
FAhnic divisions: 99% (Caucasian, 1% Asian
and aborigine
Religion: 27.7% Anglican, 25.7% Roman
Catholic, 25.2% other Protestant
Language: English, native languages
Literacy: 98.5%
Labor force: 7.2 million (November 1984);
8.7% unemployment (December 1984)
Organized labor: 57% of total employees
(December 1982)','81d212f5370d2f712f804e8bdf7f069f206b97678de76a402bcc0b1882c6a2a9','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da51060901921fbd1c875c6e172dbca61dee0855349625b61336c971eacbd692',1985,'AT','Austria','people-and-society',45,'Poimlation: 7,540,000 (July 1985), average
annual ^ro\\\\ th rale 0%
Nationality: noun— Aiistrian(s); adjective —
Austrian
Ethnic divisions: 99.4% CJt''rrnan, 0.3% Cro-
atian, 0.2%'' Slo\\t*ne, 0.1% oIIut
Religion: 88% lOtfnan ( aitholit*, 6% Protes-
tant, 6% noiu'' or other
l.an^tia^c: (ieiunan
Literacy: 98%
iMhor force: 2.9 million (1983); 41. !%■ indus-
try and crafts, 57.55% .st^rvices, 1.35%''
a^^riculturt'' and for(‘stry; 4.1% unemployed
(OctolxT 1984); an estimated 200,000 Austri-
ans ar(‘ (Muployed in otlu''r Puropt''an
countries; fort''i^n laborers in Austria number
142,030(1984)
Orf^anized labor: 61.4% of wa^e and salary
workers (1983)
Population: 232,000 (July 1985), average an-
nual growth rate 2.0%
Nationality: noun — Bahamian(s); adjec-
tive — Bahamian
Ethnic divisions: 85% black, 15% white
Religion: Baptist 29%, Anglican 23%, Roman
Catholic 22%, smaller groups of other Protes-
tants, Greek Orthodox, and Jews
Language: English; some Creole among
Haitian immigrants
Literacy: 89%
Labor force: 82,000(1982); 30% government,
25% hotels and restaurants, 10% business ser-
vices, 6% agriculture; 30% unemployment
(1983)
Organized labor: 25% organized
14
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7','51e71f232fdb679e784c8f93a0c3570e67ecff5a9300d76b3803416b5d96e970','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fee5a75a868129bcdad91e45d4f57c27e173bd8ff1b741466a82f5848fda3ea6',1985,'BH','Bahrain','people-and-society',52,'Population: 427,000 (July 1 985), average an-
nual grow ill rate 3.89
Nationality: noun — Bahraini(s); adjective —
Bahraini
hthnie dirisions: (^:Vi Bahraini, 13/7 Asian,
lO^''f other .Aral), 89 Iranian, 09 otluT
Peli0on: Muslim (009 Shi''a, 409 Sunni)
Lan^ua^^e: Arahie (ollicial); English also
w id(4> spoken; lOirsi. Urdu
Literaey: 409
Labor foree: 140,000(1982); 429 of labor
lore(‘ is Bahraini; 85^f industr> and com-
m(‘rc(‘, 59 agricailtuia*, 59 scawiees, 39
go\\(''rnment
Govern men I
Offieial j}ame: Statt'' of Bahrain
Type: traditional monarchy; independent
since 1971
Capital: Manama
Legal system: based on Islamic law- and En-
glish common law; constitution went into
effect Deceml)er 1973
National holiday: 16 December
Branches: Amir rules with help of a (Cabinet
led by Prime Minister; Amir dissolved the
National Assemidy in August 1975 and sus-
pended the constitutional provision for
election of the Assembly; independent judi-
ciary
Government leader: Isa bin Sulman Al
KHALIFA, Amir (since November 1961)
Suffrage: none
Political parties and pressure groups: politi-
cal parties prohibited; several small,
clandestine leftist and Shi‘a fundamentalist
groups are active
Communists: negligible
Member of: Arab League, FAG, G-77,
GATT(de facto), GCX:, IBRD, ICAO, IDB—
Islamic Development Bank, ILO, IMF, IMG,
INTERPOL, ITU, NAM, GAPEC, GIC, UN,
UNESCO, UPU, WHO, WMG','016b6153c7cd34cc9b2e3d256a33d5476f530f0d76b0b2d32ac6fb620cddcc16','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbb99c0720391e371dbca6dcc03e4746d2e6d973fed67e683c1945cafa232e6c',1985,'BD','Bangladesh','people-and-society',55,'Population: 101,408,000 (July 1985), average
annual growth rate 2.8%
Nationality: noun — Bangladeshi(s); adjec-
tive — Bangladesh
Ethnic divisions: 98% Bengali; 250,000
“Biharis and fewer than one million tribals
Religion: HS% Muslim, about 16% Hindu, less
than 1% Buddhist, Christian, and other
Language: Bangla (official), English widely
used
Literacy: 25%
Labor force: 32.4 million (FY83); extensive
export of labor to Saudi Arabia, UAE, Oman,
and Kuwait; 74% of labor force is in agricul-
ture, 15% services, 11% industry and
commerce (FY81/82)','611eac69b5f8b8fb6bf6cfd818ef79107f12126ea3d615dfa29d63960d3e796a','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24df00ec18e47d18275aa2308321d2286c767f3cd38030107a4ffb00861d5e91',1985,'BB','Barbados','people-and-society',58,'Population: 252,000 (July 1985), average an-
nual growth rate 0.3%
Nationality: noun — Barbadian(s); adjec-
tive — Barbadian
Ethnic divisions: 80% African, 16% mixed,
4% European
Religion: 70% Anglican, 9% Methodist, 4%
Roman Catholic, 17% other, including Mora-
vian
Language: English
Literacy: 99%
Labor force: 103,900(1982); 65.6% services
and government, 24.6% industry and com-
merce, 9.8% agriculture; 11% unemploy-
ment (1979)
Organized labor: 32%
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7','6ad189ee613d724c63ddab424fc95c7f273d6175f2d32e8ae59e10a138ff925d','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('753eafe0840e176983bd0a4279c8d00a3aec13cb3252c534abc056dbe11ab9f5',1985,'BE','Belgium','people-and-society',62,'Population: 9,856,000 (July 1985), average
annual grow th rate 0%
Nationality: noun — Belgian(s); adjective —
Belgian
Ethnic divisions: 55% Fleming, 33% Wal-
loon, 12%'' mixed or other
Religion: 75% Roman ("atholic, remainder
IVot(*stant, none, or other
Language: 56% Flemish (Dutch), 32%
French, 1% Ck^rman; 11% legally bilingual;
divided along ethnic lines
lAteracy: 98%
Labor force: 4 million (1983); 36% transporta-
tion, 33% industry and commerce, 21%
public services, 2.3%'' agriculture; 1 1 % unem-
ployed (1983)
Organized labor: 70% of labor force','07eab81497e225a66ec383a4633c2042a237faebd21e715cb2899c1b534b3656','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92bf74a1e40a5dc121979b9f5d9a88401274fcb7d17053093e190df4484ed359',1985,'BZ','Belize','people-and-society',66,'Population: 161,000 (July 1985), average an-
nual growth rate 2.3%
Nationality: noun — Belizean(s); adjective —
Belizean
Ethnic divisions: 51% black, 22% mestizo,
19% Amerindian, 8% other
Religion: 50% Roman Catholic; Anglican,
Seventh-Day Adventist, Methodist, Baptist,
Jehovah’s Witnesses, Mennonite
Language: English (official), Spanish Maya;
Carib
Literacy: over 80%
Labor force: 51,500 (1984); 30% agriculture,
16% services, 15.4% government, 11.2% com-
merce, 10.3% manufacturing; shortage of
skilled labor and all types of technical person-
nel; over 14% are unemployed
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Belize (continued)
Organized labor: 15% of labor force','a793ac8782d61a7564c228cff0a8da69ccb84e6e589d208f8dcdc40f61c1201e','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('142a6858d0b3d747cc04b9ac856ab0a867d7f433777e547338b096a33dfc01c2',1985,'BJ','Benin','people-and-society',70,'Population: 4,015,000 (July 1985), average
annual growth rate 3.1%
Nationality: noun — Beninese (sing., pi.); ad-
jective — Beninese
Ethnic divisions: 99% African (42 ethnic
groups, most important being Fon, Adja,
Yoruba, Bariba); 5,500 Europeans
Religion: 70% animist, 15% Muslim, 15%
Christian
Language: French (official); Fon and Yoruba
most common vernaculars in south; at least
six major tribal languages in north
Literacy: 20%
Labor force: 1.5 million (1982); 70% of labor
force employed in agriculture; less than 2% of
the labor force work in the industrial sector,
and the remainder are employed in trans-
port, commerce, and public services
Organized labor: approximately 75% of
wage earners, divided among two major and
several minor unions','5ecd0e9897875069a28afb1523b7d563547acece5014963d539e0d7eb88b21c0','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42a54ffcee9aca406c0da747406ea99c8b66869cc2e249139abf0af34ebe726d',1985,'BM','Bermuda','people-and-society',74,'Population: 58,000 (July 1985), average an-
nual growth rate 0.5%
Nationality: noun — Bermudian(s); adjec-
tive — Bermudian
Ethnic divisions: 61% black, 39% white and
other
Religion: 37% Anglican, 21% other Protes-
tant, 28% Catholic, 28% Black Muslim and
other
Language: English
Literacy: 98%
Labor force: 29,669 employed (1980); 25%
clerical, 22% services, 22% laborers, 13% pro-
fessional and technical, 9% administrative
and managerial, 7% sales, 2% agriculture and
fishing','10d366b6cf8d6edc75a681ea6af1d6fd4d519a2128f39810bf7081ee8ecc9746','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eda6b488b0dea9cefa173b8346caaf0daa2e8770d1bfc2761394a2675b32e6e5',1985,'GB','United Kingdom','people-and-society',80,'Population: 1,417,000 (July 1985), average
annual growth rate 2.1%
Nationality: noun — Bhutanese (sing., pi.);
adjective — Bhutanese
Ethnic divisions: 60% Bhote, 25% ethnic
Nepalese, 15% indigenous or migrant tribes
Religion: 75% Lamaistic Buddhism, 25%
Buddhist-influenced Hinduism
Language: Bhotes speak various Tibetan dia-
lects — most widely spoken dialect is
Dzongkha (official); Nepalese speak various
Nepalese dialects
Literacy: 5%
Labor force: 95% agriculture, 1% industry
and commerce (1983); massive lack of skilled
labor
Population: 6,195,000 (July 1985), average
annual growth rate 2.6%
Nationality: noun — Bolivian(s); adjective
Bolivian
Ethnic divisions: 30% Quechua, 25% A y-
mara, 25-30% mixed, 5-15% European
Religion: 95% Roman Catholic; active Prot-
estant minority, especially Methodist
Language: Spanish, Quechua, and Aymara
(all official)
Literacy: est. 75% .
Labor force: 1.7 million (1983); 47% agricul-
ture, 23% services, 19% industry and
commerce, 11% government
Organized labor: 150,000-200,000, concen-
trated in mining, industry, construction, and
Population: 56,437,000 (July 1985), average
annual growth rate 0.1%
Nationality: noun — Briton(s), British (collec-
tive pi); adjective — British
Ethnic divisions: 81.5% English, 9.6% Scot-
tish, 2.4% Irish, 1.9% Welsh, 1.8% Ulster,
0.8% other; West Indian, Indian, Pakistani
2 %
Religion: 27.0 million Anglican, 5.3 million
Roman Catholic, 2.0 million Presbyterian,
760,000 Methodist, 450,000 Jewish (regis-
tered)
Language: English, Welsh (about 26% of
population of Wales), Scottish form of Gaelic
(about 60,000 in Scotland)
Literacy: 99%
Labor force: (1982) 26.08 million; 54.4% in-
dustry and commerce, 29.9% services, 7.6%
self-employed, 6.6% government, 1.5% agri-
culture; 12.5% unemployed (early 1984)
Organized labor: 40% of labor force','ce265aebc571ab5beba22cde0075033430741ec7f7f1aacb20e5a965f98dd5dc','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fd1d2f8795cf53b5b73e8aa28fef07bb35a899b070ac54e84c219ec58e5ec2c',1985,'BW','Botswana','people-and-society',86,'Population: 1,068,000 (July 1985), average
annual growth rate 3.3%
Nationality: noun — Motswana (sing.),
Batswana (pi.); adjective— Botswana .
Ethnic divisions: 94% Tswana, 5% Bushmen,
1% European
Religion: 40% indigenous beliefs, 15% Chris-
tian
Language: English (official), Setswana
vernacular
Literacy: about 24% in English; about 35% in
Tswana; less than 1% secondary school grad-
uates
Labor force: about 400,000 total; 103,600 for-
mal sector employees (1980-81); most others
are engaged in cattle raising and subsistence
agriculture; 40,000 formal sector employees
spend at least six to nine months per year as
wage earners in South Africa (1980); 12% un-
employment (1983)
Organized labor: 16 trade unions organized
27
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Botswana (continued)','3d6f4780e668eee80aa8c28ea5fb70ebf020ec07c42fbb12614a02a3fb996437','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9289537a707cf61513a05ffb21100f028ba0365176b50ad15a210fc808811aa2',1985,'BR','Brazil','people-and-society',88,'Population: 137,502,000 (July 1985), average
annual growth rate 2.3%
Nationality: noun— Brazilian(s); adjective—
Brazilian
Ethnic divisions: Portuguese, Italian, Ger-
man, Japanese, black, Amerindian; 55%
white, 38% mixed, 6% black, 1% other
Religion: (1980) 89% Roman Catholic (nomi-
nal)
Language: Portuguese (official)
Literacy: 74%
Labor force: about 50 million in 1982, 29.9%
agriculture, livestock, forestry, and fishing;
24.4% industry; 20.3% services, transporta-
tion, and communication; 9.4% commerce;
7.0% social activities; 4.1% public adminis-
tration; 2.9% other; significant
underemployment and unemployment
Organized labor: about 6 million (1982)
Population: 221,000 (July 1985), average an-
nual growth rate 3.3%
Nationality: noun — Bruneian(s); adjective —
Bruneian
Ethnic divisions: 70% Malay, 25% Chinese,
5% other
Religion: 60% Muslim (Islam official reli-
gion); 8% Christian; 32% other (Buddhist and
animist)
Language: Malay official; English and Chi-
nese
Literacy: 45%
Labor force: 68,128 (includes members of the
Army); 63% trade and services; 23% manu-
facturing and construction; 11% agriculture,
forestry, fishing, and mining (1981)
30
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Organized labor: 2% of labor force
Covernment
Official name: State of Brunei Darussalam
Type: became independent 1 January 1984;
constitutional sultanate
Capital: Bandar Seri Begawan
National holiday: National Day, 23
February
Political subdivisions: four administrative
districts
Legal system: based on Islamic law; constitu-
tion promulgated by the Sultan in 1959
Branches: chief of state is Sultan (advised by
appointed Privy Council), who appoints Ex-
ecutive Council and Legislative Council
Government leader: Sir HASS ANAL
Bolkiah, Sultan (since August 1968)
Suffrage: universal age 21 and over; three-
tiered system of indirect elections; popular
vote cast for lowest level (district councilors)
Elections: last elections — March 1965; fur-
ther elections postponed indefinitely
Political parties and leaders: antigov-
ernment, exiled Brunei People s Party, A. M.
N. Azahari, chairman
Communisms: information not available (Jan-
uary 1985)
Member of: ASEAN, INTERPOL, OIC, UN','7213e51a4e0d5ae90990f9fdb8426630b07ec83f978232a9d4f38be1c39d3668','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9dddbf04adb63f30dc15032a29083721a6f7510c50e2316f76955ff7ea807cd5',1985,'BG','Bulgaria','people-and-society',92,'Population: 8,980,000 (July 1985), average
annual growth rate 0.2%
Nationality: noun — Bulgarian(s); adjec-
tive — Bulgarian
Ethnic divisions: 85.3% Bulgarian, 8.5%
Turk, 2.6% Gypsy, 2.5% Macedonian, *0.3%
Armenian, 0.2% Russian, 0.6% other
Religion: regime promotes atheism; religious
background of population is 85% Bulgarian
Orthodox, 13% Muslim, 0.8% Jewish, 0.7%
Roman Catholic, 0.5% Protestant, Grego-
rian-Armenian and other
Language: Bulgarian; secondary languages
closely correspond to ethnic breakdown
Literacy: 95% (est.)
Labor force: 3,997,615 (1983); 42.6% indus-
try and commerce, 23.3% agriculture, 1.5%
government, 32.6% other','d779658a2e9272fe0b8ad243cdde8976f6cfb5475b3b27157bd2bd7eabfe0df5','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f24136c0998851dd4410f636edfa13185b2812f081b39acee540d47d91d89564',1985,'BF','Burkina Faso','people-and-society',96,'Population: 6,907,000 (July 1985), average
annual growth rate 2.5%
Nationality: noun — Burkinabe; adjective —
Burkinan
Ethnic divisions: more than 50 tribes; princi-
pal tribe is Mossi (about 2.5 million); other
important groups are Gurunsi, Senufo, Lobi,
Bobo, Mande, and Fulani
Religion: 65% indigenous beliefs, about 25%
Muslim, 10% Christian (mainly Catholic)
Language: French (official); tribal languages
belong to Sudanic family, spoken by 50% of
the population
Literacy: 7%
Labor force: 90% agriculture; 10% industry,
commerce, services, and government; about
30,000 are wage earners; about 20% of male
labor force migrates annually to neighboring
countries for seasonal employment
Organized labor: four principal trade union
groups represent less than 1% of population
33
Population: 36,919,000 (July 1985), average
annual growth rate 2.0%
Nationality: noun — Burmese; adjective —
Burmese
Ethnic divisions: 72% Burman, 7% Karen,
6% Shan, 6% Indian, 3% Chinese, 2% Kachin,
2% Chin, 2% other
Religion: 85% Buddhist, 15% indigenous be-
liefs, Christian, or other
Language: Burmese; minority ethnic groups
have their own languages
Literacy: 78%
Labor force: 14.19 million (1982/83); 63.6%
agriculture, 12% government, 9.5% trade,
9.4% industry, 5.5% other
34
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Organized labor: Workers’ Asiayone or
“association” (1.56 million members) and
Peasants’ Asiayone (7.83 million members)
integrated into the country’s sole political
party','71b1c6a8552dc044f37e167b832fee142ce52b08065a68af0fd446de966525e1','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8dd96fd50c3a6640bc617b1eaee26102f70486482aaa595ff9a0e24b3898eb2b',1985,'BI','Burundi','people-and-society',100,'Population: 4,788,000 (July 1985), average
annual growth rate 2.6%
Nationality: noun — Burundian(s); adjec-
tive — Burundi
Ethnic divisions: Africans — 85% Hutu
(Bantu), 14% Tutsi (Hamitic), 1% Twa
(Pygmy); other Africans include around
70,000 refugees, mostly Rwandans and Zair-
ians; non- Africa ns include about 3,000
Europeans and 2,000 South Asians
Rcdigion: about 67% Christian (62% Roman
Catholic, 5% Protestant), 32% indigenous be-
liefs, about 1% Muslim
Language: Kirundi and French (official);
Swahili (along Lake Tanganyika and in the
Bujumbura area)
Literacy: 25%
Labor force: about 1.9 million (1983); 93%
agriculture, 4% government, 1.5% industry
and commerce, 1.5% services
Organized labor: sole group is the Union of
Burundi Workers (UTB); by charter, mem-
bership is extended to all Burundi workers
(informally); figures denoting “active
rnembership” have been unobtainable','a28752b06ba6e3da9bb5b77f7ae14976fc7e96f79409479ab245b9de50109339','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0653fa19e3a0337f8dc8a96284af588c3b9d36d38b018412fc437b58f2e420f1',1985,'KH','Cambodia','people-and-society',104,'Population: 6,249,000 (July 1985), average
annual growth rate 2.1%
Nationality: noun — Cambodian(s); adjec-
tive — Cambodian
Ethnic divisions: 90% Khmer (Cambodian),
5% Chinese, 5% other minorities
Religion: 95% Theravada Buddhism, 5%
other
Language: Khmer (official), French
Literacy: 48%','6b33a7319389cfcab85d76a8c46c3fd16d9a2866560a2b6e6cdcb64209e48528','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d68bc589b6b1fcacb0b4e36a21ffe9a912a782031eadff947f5553279a8c4b42',1985,'CA','Canada','people-and-society',108,'Population: 25,399,000 (July 1985), average
annual growth rate 1.0%
Nationality: noun — Canadian(s); adjec-
tive — Canadian
Ethnic divisions: 45% British Isles origin,
29% French origin, 23% other European,
1.5% indigenous Indian and Eskimo
Religion: 46% Roman Catholic, 18% United
Church, 12% Anglican
Language: English and French official
Literacy: 99%
Labor force: 12.2 million (December 1983);
68% services (37% government, 23% trade
and finance, 8% transportation), 18% manu-
facturing, 6% construction, 4% agriculture,
5% other; 11.9% unemployment (1983 aver-
age); 11.1% unemployment (December 1983)
Organized labor: 33% of labor force
Population: 315,000 (July 1985), average an-
nual growth rate 2.0%
Nationality: noun — Cape Verdean(s); adjec-
tive — Cape Verdean
Ethnic divisions: about 71% Creole (mu-
latto); 28% African; 1% European
Religion: Catholicism, fused with local su-
perstitions
Language: Portuguese and Crioulo, a blend
of Portuguese and West African words
Literacy: 37%
Labor force: bulk of population engaged in
subsistence agriculture','54b3c66e9888883ce77afb3f5a7e2a2379feb365e8e05a154ba6afd60b52a3e7','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('343c5a2ac782889fad5e32a58e6b5be61e9dafd5598c4a6bfa96d5a3f7400d94',1985,'CF','Central African Republic','people-and-society',112,'Population: 2,667,000 (July 1985), average
annual growth rate 2.8% ''
Nationality: noun — Central African(s); ad-
jective — Central African
Ethnic divisions: approximately 80 ethnic
groups, the majority of which have related ''
ethnic and linguistic characteristics; 34%
Baya, 28% Banda, 10% Sara, 9% Mandjia, 9%
Mboum, 7% M’Baka; 6,500 Europeans, of
whom 3,600 are French
Religion: 25% Protestant, 25% Roman Cath-
olic, 24% indigenous beliefs, 10% Muslim;
animistic beliefs and practices strongly influ-
ence the Christian majority
Language: French (official); Sangho, lingua
franca and national language
Literacy: est. 33%
Labor force: 1,320,000(1983); 88% agricul-
ture, 4% industry and commerce, 4%
services, 4% government; approximately
64,000 salaried workers
Organized labor: 1% of labor force
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7','e4e2e5030e5247d75af75a95d9d45fe97bf19c631d20ee452ebc4c6ec0acf023','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('453779bdf418349b8379864a484f2f26bca63e4026a838e9c9ee323547704b70',1985,'TD','Chad','people-and-society',116,'Population: 5,246,000 (July 1985), average
annual growth rate 2.5%
Nationality: noun — Chadian(s); adjective —
Chadian
Ethnic divisions: some 200 distinct ethnic
groups, including Muslims (Arabs, Toubou,
Fulani, Kotoko, Hausa, Kanembou,
Baguirmi, Boulala, and Maba) in the north
and center and non-Muslims (Sara, Mayo-
Kebbi, and Chari) in the south; some 150,000
nonindigenous, 3,000 of them French
Religion: 52% Muslim, 43% indigenous be-
liefs, 5% Christian
Language: French official; Chadian Arabic
is lingua franca in north, Sara and Sangho in
south; more than 100 different languages and
dialects are spoken
Literacy: about 20%
Labor force: 85% agriculture (engaged in un-
paid subsistence farming, herding, and
fishing)
Organized labor: about 20% of wage labor
force','553d4e8965f2a55b60eff5e0904f1e4d0516b742bd73b691d64c7651419526c5','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9378f61e03c3ebf7d490027089fce239cad3d00c78d66b59eb5c0e06f988e87',1985,'CL','Chile','people-and-society',121,'Population: 11,882,000 (July 1985), average
annual growth rate 1.5%
Nationality: noun — Chilean(s); adjective—
Chilean
Ethnic divisions: 95% European and Euro-
pean-Indian, 3% Indian, 2% other
Religion: 89% Roman Catholic, 11% Protes-
tant
Language: Spanish
Literacy: 90% (1978)
Labor force: 3.0 million total employment
(1982); 33% industry and commerce; 31% ser-
vices; 9% agriculture, forestry, and fishing;
9% mining; 5% construction
Organized labor: 12% of labor force orga-
nized into labor unions (1982)','a6217bb9549108a82502c2adf01c5a09b937a6389c240a8c3387fb551e2ccc71','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cbb25d5c6201dbe8bf0ec605effbf70e3041acaa2da8e460bf8bc9b342e1f06',1985,'CN','China','people-and-society',125,'Population: 1,041,346,000 (July 1985), aver-
age annual growth rate 0.9%
Nationality: noun — Chinese (sing., pi.); ad-
jective — Chinese
Ethnic divisions: 93.3% Han Chinese; 6.7%
Zhuang, Uygur, Hui, Yi, Tibetan, Miao,
Manchu, Mongol, Buyi, Korean, and numer-
ous lesser nationalities
Religion: officially atheist; most people, even
before 1949, have been pragmatic and eclec-
tic, not seriously religious; most important
elements of religion are Confucianism, Tao-
ism, Buddhism, ancestor worship; about 2-
3% Muslim, 1% Christian
Language: Standard Chinese (Putonghua) or
Mandarin (based on the Beijing dialect); also
Yue (Cantonese), Wu (Shanghainese), Minbei
(Fuzhou), Minnan (Hokkien-Taiwanese),
Xiang, Gan, Hakka dialects, and minority
languages (see ethnic divisions)
Literacy: over 75%
Labor force: est. 447.1 million (December
1983); 74.4% agriculture, 15% industry and
commerce, 10.6% other
Population: 9,941,000 (July 1985), average
annual growth rate 2.8%
Nationality: noun — Malagasy (sing, and pi.);
adjective — Malagasy
Ethnic divisions: basic split between high-
landers of predominantly Malayo-
Indonesian origin, consisting of Merina
(1,643,000) and related Betsileo (760,000) on
the one hand and coastal tribes — collectively
termed the Cotiers — with mixed Negroid,
Malayo-Indonesian, and Arab ancestry on
the other; coastal tribes include
Betsimisaraka 941,000, Tsimihety 442,000,
Antaisaka 415,000, Sakalava 375,000; there
are also 10,000-12,000 European French,
5,000 Indians of French nationality, and
5,000 Creoles
Religion: more than half indigenous beliefs;
about 41% Christian, 7% Muslim
Language: French and Malagasy official
141
Literacy: 53%
Labor force: about 3.4 million, of which 90%
are nonsalaried family workers engaged in
subsistence agriculture; of 175,000 wage and
salary earners, 26% agriculture, 17% domes-
tic service, 15% industry, 14% commerce,
11% construction, 9% services, 6% transpor-
tation, 2% miscellaneous
Organized labor: 4% of labor force','ab5fe877a4ad2876eb1c3ec5cdcfcef2e2efc0133bed4a013854c43e545b25a2','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91f5b35cd12a6c16f9327bce73fcaaeb4bb1b1bdda095bafe79d449f703b7eca',1985,'CO','Colombia','people-and-society',129,'Population: 29,506,000 (July 1985), average
annual growth rate 2.1%
Nationality: noun — Colombian(s); adjec-
tive — Colombian
Ethnic divisions: 58% mestizo, 20% Cauca-
sian, 14% mulatto, 4% black, 3% mixed black-
Indian, 1% Indian
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 81%
Labor force: 9 million (1982); 53% services,
26% agriculture, 21% industry (1980); 14%
official unemployment (1984)
Organized labor: 1,418,321 members (1982)
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7','5ffd0827b3d6bdf64b5aa2efd3e808e56675cb3b297680b6bf2af9e9d9a6c518','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('464171334279388c9a67bc6a052151578d5906b371d5903c3616dc16eba1d1cc',1985,'KM','Comoros','people-and-society',133,'Population: 469,000 (July 1985), average an-
nual growth rate 2.9%
Nationality: noun — Comoran(s); adjective —
Comoran
Ethnic divisions: Antalote, Cafre, Makoa,
Oimatsaha, Sakalava
Religion: 86% Sunni Muslim, 14% Roman
Catholic
Language: Shaafi Islam (a Swahili dialect),
Malagasy, French
Literacy: 15%
Labor force: 140,000(1982); 87% agriculture,
3% government; significant unemployment','8d2d86027b0b850d9809663a891e69898c5ee754b87c0580425ec0de234479a1','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74b3b7ce79dbbc8c1c5e00b8de9fa4c20ca9421787b4a941ef5732f3e33d3827',1985,'CG','Congo','people-and-society',137,'Population: 1,798,000 (July 1985), average
annual growth rate 3.0%
Nationality: noun — Congolese (sing., pi);
adjective — Congolese or Congo
Ethnic divisions: about 15 ethnic groups di-
vided into some 75 tribes, almost all Bantu;
most important ethnic groups are Kongo
(48%) in south, Sangha (20%) and M’Bochi
(12%) in north, Teke (17%) in center; about
8,500 Europeans, mostly French
Religion: 48% animist, 47% Christian, 2%
Muslim
Language: French (official); many African
languages with Lingala and Kikongo most
widely used
Literacy: over 50%
Labor force: about 40% of population eco-
nomically active (1983); 75% agriculture,
25% commerce, industry, government;
79,100 wage earners; 40,000-60,000 unem-
ployed
Organized labor: 20% of total labor force
(1979 est.)','651a6ac0e5ffbd4fd4adaeff5d1f934c24c0c21028a63a82159b6c54d1bb9b7a','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d41dca10cdfa9d2ccf50bed1815a37b2fdb9efa2703af950dc9a27a41056431d',1985,'CK','Cook Islands','people-and-society',141,'Population: 17,000 (July 1985), average an-
nual growth rate —0.7%
Nationality: noun — Cook Islander(s); adjec-
tive — Cook Islander
Ethnic divisions: 81.3% Polynesian (full
blood), .7.7% Polynesian and European, 7.7%
Polynesian and other, 2.4% European, 0.9%
other
Religion: Christian, majority of populace
members of Cook Islands Christian Church','f73f88e33fa9680c8ce518fd75af84e5245ee309b45748d40dc07f29918fcb3a','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45d55ea55fd05c39a458a33066323ac8a45e6a7d8c32c800cbd80dd87092d3f0',1985,'CR','Costa Rica','people-and-society',145,'Population: 2,655,000 (July 1985), average
annual growth rate 2.5%
Nationality: noun — Costa Rican(s); adjec-
tive — Costa Rican
Ethnic divisions: 96% white (including mes-
tizo), 3% black, 1% Indian
Religion: 95% Roman Catholic
Language: Spanish (official), with Jamaican
dialect of English spoken around Puerto
Limon
Literacy: 93%
Labor force :S9lfi00 {1982 est.)\\ 40.4% indus-
try and commerce, 32.6% agriculture, 25%
government and services, 2% other; 9.5% un-
employment (1984 official); 15% unem-
ployment (1984 unofficial)
Organized labor: about 13.8% of labor force','db7317113e1de22cb478dfe4eedbf29e55fccb5270d9bb7b5f16a4281c3a45d6','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de1b42af3effea8024b0327dc1ff1c8f92c8422da86001010b7b082284e43d64',1985,'CU','Cuba','people-and-society',149,'Population: 10,105,000 (July 1985), average
annual growth rate 1.1%
Nationality: noun — Cuban(s); adjective —
Cuban
Ethnic divisions: 51% mulatto, 37% white,
11% black, 1% Chinese
Religion: at least 85% nominally Roman
Catholic before Castro assumed power
Language: Spanish
Literacy: 96%
Labor force: 3.0 million in 1982; 28% ser-
vices, 21% industry, 20% agriculture, 11%
commerce, 9% construction, 7% transporta-
tion and communication, 4% other','c6ac489a32d412612967d4273ad40ec4dae5a2f7518027d56dff9a6e162eb290','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c330697cd68208e61db7e660f5dcb7234e298e3fa18dade2639b8dcc94516a22',1985,'CY','Cyprus','people-and-society',153,'Population: 670,000 (July 1985), average an-
nual growth rate 1.3%
Nationality: noun — Cypriot(s); adjective —
Cypriot
Ethnic divisions: 78% Greek; 18% Turkish;
4% Armenian, Maronite, and other
Religion: 78% Greek Orthodox; 18% Muslim;
4% Maronite, Armenian, Apostolic, and other
Language: Greek, Turkish, English
Literacy: about 89%
Greek Sector labor force: 240,900(1982); 42%
services, 33% industry, 22% agriculture; 3.1%
unemployed
Population: 15,503,000 (July 1985), average
annual growth rate 0.3%
Nationality: noun — Czechoslovak(s); adjec-
tive — Czechoslovak
Ethnic divisions: 64.3% Czech, 30.5% Slo-
vak, 3.8% Hungarian, 0.4% German, 0.4%
Polish, 0.3% Ukrainian, 0.1% Russian, 0.2%
other (Jewish, Gypsy)
Religion: 77% Roman Catholic, 20% Protes-
tant, 2% Orthodox, 1% other
Language: Czech and Slovak (official), Hun-
garian
Literacy: 99% •
Labor force: 7.8 million; 38.1% industry;
12.5% agriculture; 49.4% construction, com-
munications, and other (1982)','ef7e8929219dbcdf315bbbccc391109530f40ef80c174b5fa4e375271fb421ed','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2d9c020cc56df3d4873267046132d6b7f0b3b420c84c194b0272f597edc190f',1985,'DK','Denmark','people-and-society',157,'Population: 5,109,000 (July 1985), average
annual growth rate —0.1%
Nationality: noun — Dane(s); adjective —
Danish
Ethnic divisions: Scandinavian, Eskimo,
Faroese, German
Religion: 97% Evangelical Lutheran, 2%
other Protestant and Roman Catholic, 1%
other
Language: Danish, Faroese, Greenlandic(an
Eskimo dialect); small German-speaking mi-
nority
Literacy: 99%
Labor force: 2,700,000 (1983 average); 34. 1%
social services; 21% manufacturing; 13.3%
commerce; 8.2% agriculture, forestry, and
59
fishing; 7.9% construction; 7.0% banking and
business services; 6.8% transportation; 9.2%
unemployment rate
Organized labor: 65% of labor force','db80d7e6b9f5b7d0df8888d8b3b6ba0f4fbda7038b127fe6b3d63a75e619761e','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bec2905c1f08b6b874b0e16de787c8d7623d0c6544f94a069866040c63a69d4e',1985,'DJ','Djibouti','people-and-society',161,'Popidation: 297,000 (July 1985), average an-
nual growth rate 2.6%
Nationality: noun — Djiboutian(s); adjec- .
tive — Djiboutian
Ethnic divisions: 60% Somali (Issa); 35%
Afar, 5% French, Arab, Ethiopian, and Ital-
ian
Religion: 94% Muslim, 6% Christian
Language: French (official), Somali and Afar
widely used
Literacy: 20%
Labor force: a small number of semiskilled
laborers at port
Organized labor: some 3,000 railway work-
ers organized
Approved For','4ee6ccb144ba6378bf0ea068a794e014ecbb6222edda7bf95ebb4cef9bf1945f','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d986fd3f780e44a65227dee65cb400994c5098bb53e74cc3a57f848e53c4aa0',1985,'DM','Dominica','people-and-society',165,'Population: 74,000 (July 1985), average an-
nual growth rate —0.2%
Nationality: noun — Dominican(s); adjec-
tive — Dominican
Ethnic divisions: mostly black; some Carib-
Indians
Religion: 80% Roman Catholic; Anglican,
Methodist
Language: English (official); French patois
widely spoken
Literacy: about 95%
Labor force: 23,000; 40% agriculture, 32% in-
dustry and commerce, 28% services; 15-20%
unemployment
Organized labor: 25% of the labor force','b42002d6fcd5574bab46570d408a6091ee282da5a07211b99f009bbd11ab523f','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce064f4489537f9a828230e6fc8dadfe899d81a3d661a7f42071939e181ca17e',1985,'DO','Dominican Republic','people-and-society',169,'Population: 6,588,000 (July 1985), average
annual growth rate 2.7%
Nationality: noun — Dominican(s); adjec-
tive — Dominican
Ethnic divisions: 73% mixed, 16% white,
11% black
Religion: 95% Roman Catholic
Language: Spanish
Literacy: 68%
Labor force: 1.2 million; 47% agriculture,
23% industry and commerce, 16% govern-
ment, 14% services
Organized labor: 12% of labor force','22b4ada634f185d6ee172ae82bb2a36299c36ea04dac725bde59bc0a69f084ed','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68d6c38c065b3b0fe456903ad85143a24639834d253390a49f6b3b038d020670',1985,'EC','Ecuador','people-and-society',173,'Population: 8,884,000 (July 1985), average
annual growth rate 2.7%
Nationality: noun — Ecuadorean(s); adjec-
tive — Ecuadorean
Ethnic divisions: 55% mestizo (mixed Indian
and Spanish), 25% Indian, 10% Spanish, 10%
black
Religion: 95% Roman Catholic (majority
nonpracticing)
Language: Spanish (official); Indian dialects,
especially Quechua
Literacy: 84%
Labor force: (1983) 2.8 million; 52% agricul-
ture, 13% manufacturing, 7% commerce, 4%
construction, 4% public administration, 16%
other services and activities
Organized labor: less than 15% of labor force','681035fa0b30293b6bc05aefbd13ba47c8285f2b2a0d2a6c900ec89349fccbb3','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8285a96b28ce4f38fd13afda44940b12245ae6a1a0d2e614eacd10d45d609ad',1985,'EG','Egypt','people-and-society',177,'Population: 48,305,000 (July 1985), average
annual growth rate 2.6%
Nationality: noun — Egyptian(s); adjective —
Egyptian or Arab Republic of Egypt
Ethnic divisions: 90% Eastern Hamitic stock;
10% Greek, Italian, Syro- Lebanese
Religion: (official estimate) 94% Muslim
(mostly Sunni), 6% Coptic Christian and
other
Language: Arabic (official); English and
French widely understood by educated
classes
Literacy: 40%
Labor force: 13.4 million; 45-50% agricul-
ture, 13% industry, 11% trade and finance.
26% services and other; shortage of skilled la-
bor; unemployment about 7%
Organized labor: 1 to 3 million','5427e656c88a0480a9e14e5b1f0d2b0416175f0659d006ab71d89b7ca3d4be0b','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d931269bcff4601b0e8205a09e2b6a83df4ee79ef4b70968a97d09795bb7d10',1985,'LY','Libya','people-and-society',183,'Population: 5,072,000 (July 1985), average
annual growth rate 2.8%
Nationality: noun — Salvadoran(s); adjec-
tive — Salvadoran
Ethnic divisions: 89% mestizo, 10% Indian,
1% white
Religion: predominantly Roman Catholic
(probably 97-98%), with activity by Protes-
tant groups throughout the country
Language: Spanish, Nahua (among some In
dians)
Literacy: 65%
Labor force: 1.7 million (est. 1982); 25% agri-
culture, 16% manufacturing, 16%
commerce, 13% government, 9% financial
67
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
El Salvador (continued)
services, 6% transportation, 15% other (1984
est.); shortage of skilled labor and large pool
of unskilled labor, but manpower training
programs improving situation; significant
unemployment
Organized labor: S% total labor force; 10%
agricultural labor force; 7% urban labor force
(1982)
Population: 4,003,000 (July 1985), average
annual growth rate 6.5%
Nationality: noun — Libyan(s); adjective—
Libyan
Ethnic dimsions: 97% Berber and Arab with
some black stock; some Greeks, Maltese,
Jews, Italians, Egyptians, Pakistanis, Turks,
Indians, and Tunisians
Religion: 97% Sunni Muslim
Language: Arabic; Italian and English
widely understood in major cities
Literacy: 50%
Labor force: 1.5 million, of which about
550,000 are resident foreigners
136','1586f8fdd575a8443d4b6ad1324d30d6cda0322d7046eb43fa167a062eb22929','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea95a0c56e73421a0dc7a541578ae94996661e452443bd221d131d5eefeee230',1985,'GQ','Equatorial Guinea','people-and-society',186,'Population: 282,000 (July 1985), average an-
nual growth rate 2.5% Rio Muni — 212,000
(July 1985), average annual growth rate 2.5%;
Fernando Po — 71,000 (July 1985), average
annual growth rate 2.5%
Nationality: noun — Equatorial Guinean(s);
adjective — Equatorial Guinean
Ethnic divisions: indigenous population of
Bioko, primarily Bubi, some Fernaridinos; of
Rio Muni, primarily Fang; less than 1,000
Europeans, primarily Spanish
Religion: natives all nominally Christian and
predominantly Roman Catholic; some pagan
practices retained
Language: Spanish (official); pidgin English,
Fang
Literacy: 55%
Labor force: most Equatorial Guineans in-
volved in subsistence agriculture; labor
shortages on plantations','f6f0b4b3904d2a3a202304f62eae3f2b06d20561c314bcf1b007c143b3b782ac','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37042e5ccb75c78072c98bd8007072596661f0905908c3cfb9c84a171e53eec0',1985,'ET','Ethiopia','people-and-society',191,'Population: 42,289,000 (July 1985), average
annual growth rate 0.7%
Nationality: noun — Ethiopian(s); adjec-
tive — Ethiopian
Ethnic divisions: 40% Oromo, 32% Amhara
and Tigrean, 9% Sidamo, 6% Shankella, 6%
Somali, 4% Afar, 2% Gurage, 1% other
Religion: 40-45% Muslim, 35-40% Ethiopian
Orthodox, 15-20% animist, 5% other ,
Language: Amharic (official), Tigrinya,
Orominga, Arabic, English (major foreign
language taught in schools)
Literacy: about 15%
70
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Labor force: 90% agriculture and animal hus-
bandry; 10% government, military, and
quasi-government
Organized labor: All Ethiopian Trade Union
formed by the government in January 1977
to represent 273,000 registered trade union
members
Population: 2,000 (July 1985), average an-
nual growth rate 0%
Nationality: noun — Falkland Islander(s); ad-
jective — Falkland Island
Ethnic divisions: almost totally British
Religion: predominantly Anglican
Language: English
Literacy: compulsory education up to age 14
Labor force: 1,100 (est.); est. over 95% in agri-
culture, mostly sheepherding','7ab1bf7fd47a715eb399ed11c4f12d1ac09671e4c87c9e546e3b9c315fbd9404','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19ddb0d804a351ecc408e0d5f3afefab98a145ffd5046c9601c3fe44f66dca50',1985,'FO','Faroe Islands','people-and-society',195,'Population: 46,000 (July 1985), average an-
nual growth rate 1.0%
Nationality: noun — Faroese (sing., pi.); ad-
jective — Faroese
Ethnic divisions: homogeneous white popu-
lation
Religion: Evangelical Lutheran
Language: Faroese (derived from Old
Norse), Danish
Literacy: 99%
Labor force: 17,585; largely engaged in fish-
ing, manufacturing, transportation, and
commerce','c9450eb0148fafd246e7a00fe289c9f5a4e54fe9f87aee130347d042c7d148d9','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0ec9947ae541e7552062b2215a235d924bde118e674ac35c7938b77729b23a7',1985,'FJ','Fiji','people-and-society',199,'Population: 700,000 (July 1985), average an-
nual growth rate 2.1%
Nationality: noun — Fijian(s); adjective— .
Fijian
Ethnic divisions: 50% Indian, 45% Fijian; 5%
European, other Pacific Islanders; overseas
Chinese, and others
Religion: Fijians are mainly Christian, Indi-
ans are Hindu with a Muslim minority
Language: English (official), Fijian, Hindu-
stani spoken among Indians
Literacy: 80%
Labor force: 176,000(1979); 43.8% agricul-
ture, 15.6% industry
Organized labor: about 50% of labor force
organized into about 60 unions; unions orga-
nized along lines of work and ethnic origin','a2035bc6f507b5cf90bd22fa226c6df5cedb10363e279342110919614286aac4','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36cdec97647c4d7eee11f7941d77f010dfe2871f453522f3727b09d156581d64',1985,'FI','Finland','people-and-society',203,'Population: 4,894,000 (July 1985), average
annual growth rate 0.4%
Nationality: noun— Finn(s); adjective —
Finnish
Ethnic divisions: Finn, Swede, Lapp, Gypsy,
Tatar
Religion: 97% Evangelical Lutheran, 1.2%
Greek Orthodox, 1.8% other
Language: 93.5% Finnish, 6.3% Swedish
(both official); small Lapp- and Russian-
speaking minorities
Literacy: almost 100%
Labor force: 2.546 million; 23.8% mining and
manufacturing; 25.4% services; 18.5% com-
merce; 11.9% agriculture, forestry, and
fishing; 7.2% construction; 7.0% transporta-
tion and communications; 6.1% unemployed
(1983 average)
Legal system: civil law system based on
Swedish law; constitution adopted 1919; Su-
preme Court may request legislation
interpreting or modifying laws; legal educa-
tion at Universities of Helsinki and Turku;
accepts compulsory ICJ jurisdiction, with
reservations
National holiday: Independence Day, 6 De-
cember
Branches: legislative authority rests jointly
with President and unicameral legislature
(Eduskunta); executive power vested in Presi-
dent and exercised through coalition Cabinet
responsible to parliament; Supreme court,
four superior courts, 193 lower courts
Government leaders: Dr. Mauno
KOIVISTO, President (since January 1982);
Kalevi SORSA, Prime Minister (since Febru-
ary 1982)
Political parties and leaders: Social Demo-
cratic Party, Kalevi Sorsa; Center Party,
Paavo Vayrynen; People’s Democratic
League (Communist front), Kalevi Kivisto;
Conservative Party, Illka Suominen; Liberal
Party, Kyosti Lallukka; Swedish Peoples
Party, Par Stenback; Rural Party, Pekka
Vennamo; Finnish Communist Party, Arvo
Suffrage: universal, 18 years and over; not
compulsory
Elections: parliamentary, every four years
(last in 1983); presidential, every six years
Organized labor: 80% of labor force','a435f348d2212644736138c065c2ae05fa0f3cc56c30099d341f761a42bf1e0e','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bf54a006d219b9e554db85a3d6e820f42a41a5dc5eac8bd5691b99df4f8e02e',1985,'FR','France','people-and-society',207,'Population: 55,094,000 (July 1985), average
annual growth rate 0.4%
Nationality: noun — Frenchman (men); ad-
jective — French
Ethnic divisions: Celtic and Latin with Teu-
tonic, Slavic, North African, Indochinese,
and Basque minorities
Religion: 90% Roman Catholic, 2% Protes-
tant, 1% Jewish, 1% Muslim (North African
workers), 6% unaffiliated
Language: French (100% of population); rap-
idly declining regional patois— Provencal,
Breton, Germanic, Corsican, Catalan,
Basque, Flemish
Literacy: 99%
Approved For
Labor force: 23.4 million (1983); 54.5% ser-
vices, 29.5% industry, 8.5% agriculture; 8.5%
unemployed
Organized labor: approximately 20% of la-
bor force','a879d40d5fc24e7b5ccfaeccb9a27d067964cef941f524215ccece21bf375013','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae9ad2cd8e3ebe8fd255fb5767d0bfdd778dcbe1795f5ed3cdbf6930191dbef7',1985,'GF','French Guiana','people-and-society',211,'Population: 82,000 (July 1985), average an-
nual growth rate 2.9%
Nationality: noun — French Guianese (sing.,
pi.); adjective — French Guiana
Ethnic divisions: 66% black or mulatto; 12%
Caucasian; 12% East Indian, Chinese, Amer-
indian; 10% other
Religion: predominantly Roman Catholic
Language: French
Literacy: 73%
Labor force: 23,265 (1980); services, govern-
ment, and commerce 60.6%; industry 21.2%;
agriculture 18.2%; information on unem-
ployment unavailable
Organized labor: 7% of labor force
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7','d3d519bade24f89b440733540ea9522c80f49a3852328fb53a811aa13eb9a7d0','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a198735a4949536de8aab2d7a9e4a767c88425c9097ef97b2fa0a590d69b9f74',1985,'PF','French Polynesia','people-and-society',215,'Population: 166,000 (July 1985), average an-
nual growth rate 2.3%
Nationality: noun — French Polynesian(s);
adjective — French Polynesian
Ethnic divisions: 78% Polynesian, 12% Chi-
nese, 6% local French, 4% metropolitan
I^rench
Religion: mainly Christian; 55% Protestant,
32% Catholic
Branches: 30-member Territorial Assembly,
popularly elected; 5''member Council of
Government, elected by Assembly; popular
election of two deputies to National Assem-
bly and one senator to Senate in Paris
Government leader: Alain OHREL, High
Commissioner and President of the Council
of Government (since 1983), appointed by
French Government; Gaston FLOSSE, Vice
President of the Council of Government
(since May 1982; highest elected official in
the territory)
Suffrage: universal adult
Elections: every five years, last in May 1982
Political parties and leaders: Tahoeraa
Huiraatira (Gaullist), Gaston Flosse; Ai’a Api
(New Country Party), Emile Vernaudon;
Here Ai a; la Mana (Socialist)
Voting strength: (1982 election) Tahoeraa
Huiraatira, 13 seats; Ai a Api, 3 seats; Here
Ai a, 6 seats; la Mana, 3 seats; Independents, 4
seats; Te E a Api, 1 seat','a794e665c58a52efdea395027c2869328dfb299e0eb479ceacfe54071329c0cc','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3c033e8be4858a0c2bccb2eaa1dbfb4f8a15eafcac752c587244cbd8f1775d9',1985,'GA','Gabon','people-and-society',219,'Population: 988,000 (July 1985), average an-
nual growth rate 3.1%
Nationality: noun — Gabonese (sing., pi.); ad-
jective — Gabonese
Ethnic divisions: about 40 Bantu tribes, in-
cluding 4 major tribal groupings (Fang,
Eshira, Bapounou, Bateke); about 100,000 ex-
patriate Africans and Europeans, including
35,000 French
Religion: 55-75% Christian, less than 1%
Muslim, remainder animist
Language: French (official); Fang, Myene,
Bateke
Literacy: 65%
Labor force: 120,000 salaried (1983); 65% ag-
riculture, 30% industry and commerce, 2.5%
services, 2.5% government
Organized labor: there are 38,000 members
of the national trade union, the Gabonese
Trade Union Confederation (COSYGA)
Population: 751,000 (July 1985), average an-
nual growth rate 3.5%
Nationality: noun — Gambian(s); adjective —
Gambian
Ethnic divisions: 90% African (37.7%
Mandinka 16.2% Fula, 14% Wolof, 8.5% Jola,
7.8% Serahuli, 5.3% other); 10.5% non-Gam-
bian
Religion: 85% Muslim, 14% Christian, 1% in-
digenous beliefs
Language: English (official); Mandinka, Wo-
lof, Fula, other indigenous vernaculars
Literacy: about 15%
Labor force: 378,850 (1980 est.); 75% agricul-
ture; 18.9% industry, commerce, and
services; 6.1% government
82
Organized labor: 25-30% of wage labor force
at most
Population: 16,701,000, including East Ber-
lin (July 1985), average annual growth rate
0 . 0 %
Nationality: noun — German(s); adjective —
German
Ethnic divisions: 99.7% German, 0.3% Slavic
and other
Religion: 47% Protestant, 7% Roman Catho-
lic, 46% unaffiliated or other; less than 5% of
Protestants and about 25% of Roman Catho-
lics active participants
Language: German, small Sorb (West Slavic)
minority
Literacy: 99%
83
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
German Democratic
Republic (continued)
Labor force: 8.87 miilion; 37.9% industry,
20.7% services, 10.7% commerce, 10.1% agri-
culture, 7.4% transport and communications,
6.9% construction, 31% handicrafts, 3.2%
other (1983)
Organized labor: 87.7% of total labor force
Population: 61,132,000, including West Ber-
lin (July 1985), average annual growth
rate “0.2%
Nationality: noun — German(s); adjective —
German
Ethnic divisions: primarily German; Danish
minority
Religion: 45% Roman Catholic, 44% Protes-
tant, 11% other
Language: German
Literacy: 99%
Labor force: 25.668 million (1982); 33.8%
manufacturing, 29.2% services, 16.8% gov-
ernment, 5.9% construction, 5.4%
85
agriculture, 1.7% other; 9.2% unemployed
(February 1985)
Organized labor: 37% of total labor force;
46.4% of wage and salary earners (1982)','19df59344f089bab507a40961409fd0faff189daf3e9a14190af7db2a6de0869','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82d90b0f9c343f7770ae7cb0631580120d9928bd7ac8050b31bdbf04a58a48bc',1985,'GH','Ghana','people-and-society',223,'Population: 13,197,000 (July 1985), average
annual growth rate 3.0%
Nationality: noun — Ghanaian(s); adjec-
tive — Ghanaian
Ethnic divisions: 99.8% black African (major
tribes Akan, Ewe, Ga), 0.2% European and
other
Religion: 42% Christian, 38% indigenous be-
liefs, 12% Muslim, 7% other
Language: English (official); African lan-
guages include 44% Akan, 16% Mole-
Dagbani, 13% Ewe, and 8% Ga-Adangbe
Literacy: 30%
Labor force: 3.7 rhillion; 54.7% agriculture
and fishing; 18.7% industry; 15.2% sales and*
clerical; 7.7% services, transportation; and
communications; 3.7% professional; 400,000
unemployed
Organized labor: 467,000 or approximately
13% of labor force
Population: 31,000 (July 1985), average an-
nual growth rate 0.9%
Nationality: noun— Gibraltarian; adjec-
tive — Gibraltar
Ethnic divisions: mostly Italian, English,
Maltese, Portuguese, and Spanish descent
Religion: 75% Roman Catholic, 8% Church
of England, 2.25% Jewish
Language: English and Spanish are primary
languages; Italian, Portuguese, and Russian
also spoken; English used in the schools and
for all official purposes
Literacy: illiteracy is negligible
Labor force: approx. 14,800, including non-
Gibraltar laborers
Organized labor: over 6,000','d59344aecb15cc44d3d603ce12bc417da744d15a7e7f16da81678a28c80a4438','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2d834d174125fd23249ae041467ea46e791b87e85477fd33d251086f5f4ae98',1985,'GR','Greece','people-and-society',228,'Population: 9,966,000 (July 1985), average
annual growth rate 0.6%
Nationality: noun — Greek(s); adjective —
Greek
Ethnic divisions: 97.7% Greek, 1.3% Turk-
ish; 1.0% Vlach, Slav, Albanian, Pomach
Note: The Greek Government states that
there are no ethnic minorities in Greece
Religion: 98% Greek Orthodox, 1.3% Mus-
lim, 0.7% other
Language: Greek (official); English and
French widely understood
Literacy: 95%
Labor force: 3.7 million (1981 census); ap-
proximately 39% services, 31% agriculture,
30% industry; urban unemployment is esti-
89
mated at 10%; substantial unreported unem-
ployment exists in agriculture
Organized labor: 10-15% of total labor force,
20-25% of urban labor force
Population: 51,259,000 (July 1985), average
annual growth rate 2.1%
Nationality: noun — Turk(s); adjective —
Turkish
Ethnic divisions: 85% Turkish, 12% Kurd,
3% other
Religion: 98% Muslim (mostly Sunni), 2%
other (mostly Christian and Jewish)
Language: Turkish (official), Kurdish Arabic
Literacy: 70%
Labor force: 18,1 million (1983); 61% agricul-
ture, 27% service, 12% industry and
commerce; surplus of unskilled labor (1982)
Organized labor: 10-15% of labor force','51661fd4ce344b1b989d38e76bdb4a6fa7359453aa3053ba34e868189ca63391','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e00088f15cc651a8690a9f3d7d5b46bad11ec55c96c68e637210aaabb3edb58',1985,'GL','Greenland','people-and-society',231,'Population: 54,000 (July 1985), average an-
nual growth rate 1.2%
Nationality: noun — Greenlander(s); adjec-
tive — Greenlandic
Ethnic divisions: 86% Greenlander (Eskimos
and Greenland-born whites), 14% Danish
Religion: Evangelical Lutheran
Language: Danish, Eskimo dialects
Literacy: 99%
Labor force: 21,378; largely engaged in fish-
ing, hunting, and sheep breeding','f540b71fbdfc80a3f237f4986d298774586750a30f47f5a1cfc49c822b1c4726','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3093b9d83bc6bd16468768bb673ddc27db037d650c6774b419aaae2b0fbdccbf',1985,'GD','Grenada','people-and-society',235,'Population: 88,000 (July 1985), average an-
nual growth rate —0.4%
Nationality: noun — Grenadian(s); adjec-
tive — Grenadian
Ethnic divisions: mainly of African Negro
descent
Religion: largely Roman Catholic; Anglican;
other Protestant sects
Language: English (official); some French
patois
Literacy: unknown
Labor force: 38,000 (1980 est.); 38% services,
20% agriculture, 11% construction, 4% man-
ufacturing; 27% unemployment.
Organized labor: 80% of labor force','935b178f74585af9ad4e286ceb2ec96649ef5bee2e09044867d8a6b0a504ec06','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87f67dc8a0df455969fd2be5a2f72560b5232e3854d3f2bed9fed7d1b94b6139',1985,'GP','Guadeloupe','people-and-society',239,'Population: 333,000 (July 1985), average an-
nual growth rate 0.4%
Nationality: noun — Guadeloupian(s); adjec-
tive — Guadeloupe
Ethnic divisions: 90% black or mulatto; 5%
Caucasian; less than 5% East Indian, Leba-
nese, Chinese
Religion: 95% Roman Catholic, 5% Hindu
and pagan African
Language: French, creole patois
Literacy: over 70%
Labor force: 120,000; services, government,
and commerce 53%; industry 25.8%; agricul-
ture 21.2%; significant unemployment
Organized labor: 1 1 % of labor force
93','de15bfec86f2946ef61443cf63df1658a7fbbf456a2a223c15f1e014e8fb534d','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e0b8e857c8342dd13d90b30dd04f548ac89fd70f0c0f69bb5c91383a0152e38',1985,'GT','Guatemala','people-and-society',243,'Population: 8,335,000 (July 1985), average
annual growth rate 3.1%
Nationality: noun — Guatemalan(s); adjec-
tive — Guatemalan
Ethnic divisions: 58.6% Ladino (mestizo and
westernized Indian), 41.4% Indian
Religion: predominantly Roman Catholic;
also Protestant, traditional Mayan
Language: Spanish, but over 40% of the
population speaks an Indian language as a
primary tongue (18 Indian dialects, including
Quiche, Cakchiquel, Kekchi)
Literacy: 50%
Labor force (1984): 2.5 million; 57.0% agri-
culture, 14,0% manufacturing, 13.0%
services, 7.0% commerce, 4.0% construction,
3.0% transport, 0.8% utilities, 0.4% mining;
unemployment 33%
94
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Organized labor: 10% of labor force (1984)','9293c5ba5ac792295554adc8260730f17c5bb45bf7544c98b06c58f11df9ab55','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f39bd5c3149a766e27f5e5ec56fa594e943ba88ae90e4f82f987a72a0d78e2c',1985,'GN','Guinea','people-and-society',247,'Population: 5,734,000 (July 1985), average
annual growth rate 2.7%
Nationality: noun — Guinean(s); adjective —
Guinean
Ethnic divisions: Fulani, Malinke, Sousou, 15
smaller tribes
Religion: 75% Muslim, 24% indigenous be-
liefs, 1% Christian
Language: French (official); each tribe has
own language
Literacy: 20% in French; 48% in local lan-
guages
Labor force: 2.4 million (1983); 82% agricul-
ture, 11% industry and commerce, 5.4%
services, 1.6% government
Organized labor: virtually 100% of wage la-
bor force loosely affiliated with the National
Confederation of Guinean Workers
Population: 88,000 (July 1985), average an-
nual growth rate 0.8%
Nationality: noun — Sao Tomean(s); adjec-
tive — Sao Tomean
Branches: President heads the government
assisted by a cabinet of rninisters; unicameral
legislature (elected National Popular Assem-
bly)
Government leader: Dr. Manuel Pinto DA
COSTA, President (since 1975)
Suffrage: universal for age 18 and over
Elections: da Costa reelected May 1980 by
Popular Assembly; Assembly elections held
March-April 1980
Political parties and leaders: Movement for
the Liberation of Sao Tome and Principe
(MLSTP), Manuel Pinto da Costa
Aid: economic commitments — Western
(non-US) countries, ODA and OOF (1970-
81), $583 million; US(FY77-83), $2.7 million;
Communist countries (1970-83), $23 million
Budget: (1981 est.) central government bud-
get $22.0 million; (1979 est.) revenues, $15.7
million; current expenditures, $10.4 million;
capital expenditures, $9.1 million
Monetary conversion rate: 46.2051
dobra=US$l (December 1984)
Fiscal year: calendar year','f318ff7504e4f55c58319750ef9a79d896d85b43758ccd4d166adfc07d040d71','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43431ad2af84026a5d7b9dab01c252397259d996c31648e1e30bf2c8f8ea56db',1985,'GW','Guinea-Bissau','people-and-society',251,'Population: 858,000 (July 1985), average an-
nual growth rate 1.9%
Nationality: noun — Guinea-Bissauan(s); ad-
jective — Guinea-Bissauan
Ethnic divisions: about 99% African (30%
Balanta, 20% Fula, 14% Manjaca, 13%
Mandinga, 7% Papel); less than 1% European
and mulatto
Religion: 65% indigenous beliefs, 30% Mus-
lim, 5% Christian
Language: Portuguese (official); Criolo and
numerous African languages
Literacy: 9%
Labor force: 90% agriculture; 5% industry,
services, and commerce; 5% government
97
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
(continued)','487bf97cf8b824b652edf427f58966897be09844d979c733f58e10d436dd0c30','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27604fa3a2a116d1ba459fec057603f45c625351ca91f46d73509f4837d323ad',1985,'GY','Guyana','people-and-society',255,'Population: 798,000 (July 1985), average an-
nual growth rate 0.4%
Nationality: noun — Guyanese (sing., pi.); ad-
jective — Guyanese
Ethnic divisions: 51% East Indian, 43% black
and mixed, 4% Amerindian, 2% European
and Chinese
Religion: 57% Christian, 33% Hindu, 9%
Muslim, 1% other
Language: English, Amerindian dialects
Literacy: 85%
Labor force: 200,000(1982); 44.5% industry
and commerce, 33.8% agriculture, 21.7% ser-
vices; 64% public sector employment;
approximately 21% unemployed
Organized labor: 34% of labor force','bd3ded1ac32006a5e2362d3168b70f907fe5709689de8fb1cfebd34b4fa65a38','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d75491b24ba0888bb80dbc5b620cfd578b51fe02c956c8fc86ada9fc1791a82',1985,'HT','Haiti','people-and-society',259,'Population: 5,762,000 (July 1985), average
annual growth rate 1.9%
Nationality: noun — Haitian(s); adjective —
Haitian
Ethnic divisions: 95% black, 5% mulatto and
European
Religion: 75-80% Roman Catholic (of which
an overwhelming majority also practice Voo-
doo), 10% Protestant
Language: French (official) spoken by only
10% of population; all speak Creole
Literacy: 23%
Labor force: 2.3 million (est. 1975); 79% agri-
culture, 14% services, 7% industry;
significant unemployment; shortage of
skilled labor; unskilled labor abundant
100
Organized labor: less than 1% of labor force','1a3020646596c7ccdbf6d9f796c8fcd0e4a730241704fccbddec874da9561be1','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b133cc62efe5a8da8de2651f97cac841f9bae04dcca17c6301398658604bc68b',1985,'HN','Honduras','people-and-society',264,'Population: 4,394,000 (July 1985), average
annual growth rate 3.4%
Nationality: noun — Honduran(s); adjec-
tive — Honduran
Ethnic divisions: 90% mestizo (mixed Indian
and European), 7% Indian, 2% black, 1%
white
Religion: about 97% Roman Catholic; small
Protestant minority
Language: Spanish, Indian dialects
Literacy: 56%
Labor force: 1.2 million (1984); 54% agricul-
ture, 28% services, 13% manufacturing, 4%
construction, 1% other; 30% unemployed;
60% underemployed
Organized labor: 40% of urban labor force,
20% of rural work force (1981)
101
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Honduras (continued)','c47e41a7bfe1008416cfaf00cdf3fe9246a38dbe5fa6ee43e7237e3e0be503e6','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28a2127d6f5401c0e7b2426fcffa1fb2aa1c20b6d5a4aad9fdc063fdc869eb9f',1985,'HK','Hong Kong','people-and-society',266,'Population: 5,491,000 (July 1985), average
annual growth rate 1.6%
Nationality: adjective — Hong Kong
Ethnic divisions: 98% Chinese, 2% other
Religion: 90% eclectic mixture ofc local reli-
gions, 10% Christian
Language: Chinese (Cantonese), English:
Literacy: 75%
Labor force: (June 1984) 2.52 million;- 37.3%
manufacturing; 22.1% commerce; 18.4% ser-
vices; 7.6% construction; 7.6% transport and
communications; 5.4% financing; insurance,,
and real estate; 1.2% agriculture, fishing,
mining, and quarrying; 0.4% other; unem-
ployment (seasonally adjusted) 3.6%
Organized labor: 15.2% of 1984 labor force
103','876f4fd041a42faa5642ca7bf33f953e6957c187b9988e78235f1d9cfeacaabf','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4343e4b0b1810d714cac4de96f5a7c84b827bc58f979b9c9a13606eac9bc28cd',1985,'HU','Hungary','people-and-society',269,'Population: 10,645,000 (July 1985), average
annual growth rate — 0.2%
Nationality: noun — Hungarian(s); adjec-
tive — Hungarian
Ethnic divisions: 92.4% Hungarian, 3.3%
Gypsy, 2.5% German, 0.7% Jewish, 1.1%
other
Religion: 67.5% Roman Catholic, 20.0% Cal-
vinist, 5.0% Lutheran, 7.5% atheist and other
Language: 98.2% Hungarian, 1.8% other','eaa6be33907dff13b84800025a6ce14dd1a4233c22c150917e444f0bcd33e4b2','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('137c252807e5c1d27ed9f9ef9dfe61a079d421501bd35fc5ee7898f3378826f9',1985,'IS','Iceland','people-and-society',273,'Population: 241,000 (July 1985), average an-
nual growth rate 1.0%
Nationality: noun — Icelander(s); adjective —
Icelandic
Ethnic divisions: homogeneous mixture of
descendants of Norwegians and Celts
Religion: 95% Evangelical Lutheran, 3%
other Protestant and Roman Catholic, 2% no
affiliation
Language: Icelandic
Literacy: 99.9%
Labor force: 105,000; 18.6% commerce, fi-
nance, and services; 12.2% construction; 9.0%
agriculture; 6.3% transportation and commu-
nications; 5.4% fishing; 8.0% fish processing;
16.8% other manufacturing; 23.7% other;
1.0% unemployment (1983 average)
Organized labor: 60% of labor force','57f4b48fd0b85ebe8bd0f2fe9012f084159c74a676468fa38f7b050ce472afab','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38338c18ccf1eadf9c8b3076590aac2a3a78bb76fcaf6cf7b6e41f8b2cd8bb11',1985,'IN','India','people-and-society',277,'Population: 762,507,000, including Sikkim
and the Indian-held part of disputed Jammu
and Kashmir (July 1985); average annual
growth rate 2.1%
Nationality: noun — Indian(s); adjective —
Indian
Ethnic divisions: 72% Indo-Aryan, 25% Dra-
vidian, 3% Mongoloid and other
Religion: 83.5% Hindu, 11% Muslim, 2.6%
Christian, 2.0-2.5% Sikh, 0.7% Buddhist,
0.2% other
Language: Hindi, English, and 14 other offi-
cial languages; 24 languages spoken by a
million or more persons each; numerous
other languages and dialects, for the most
part mutually unintelligible; Hindi is the na-
tional language and primary tongue of 30
percent of the people; English enjoys
“associate” status but is the most important
language for national, political, and commer-
cial communication; Hindustani, a popular
variant of Hindi/Urdu, is spoken widely
throughout northern India
Literacy: 36%
Labor force: (1981) about 232 million; 67%
agriculture; more than 10% unemployed and
underemployed
Organized labor: less than 5% of total labor
force','980ed2f6d58fc1b50faf64a7b23b145bf4b9bdee19ea48c47d373e3fe65f4016','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f771b0ca8055426ead5b1d8b5b84ca5df844333e13c7992a052f36094a8e4a4',1985,'ID','Indonesia','people-and-society',281,'Population: 173,103,000, including East Ti-
mor and West Irian (July 1985), average
annual growth rate 2.1%
Nationality: noun — :Indonesian(s); adjec-
tive — Indonesian
Ethnic divisions: majority of Malay stock
comprising 45% Javanese, 14% Sundanese,
7.5% Madurese, 7.5% coastal Malays, 26%
other
Religion: 88% Muslim, 6% Protestant, 3% Ro-
man Catholic, 2% Hindu, 1% other
Language: Indonesian (modified form of
Malay; official); English and Dutch leading
foreign languages; local dialects, the most
widely spoken of which is Javanese
Literacy: 64%
Labor force: 61 million (1982); 66% agricul-
ture, 23% trade and commerce, 10% services
Organized labor: est. 5% of labor force
Population: 45,191,000 (July 1985, average
annual growth rate 3.1%; figures do not take
into account the impact of the Iran-Iraq war
Nationality: noun — Iranian(s); adjective —
Iranian
Ethnic divisions: 63% ethnic Persian, 18%
Turkic, 13% other Iranian, 3% Kurdish, 3%
Arab and other Semitic, 1% other
Religion: 93% Shi* a Muslim; 5% Sunni Mus-
lim; 2% Zoroastrian, Jewish, Christian, and
Baha’i
Language: Farsi, Turki, Kurdish, Arabic,
English, French
110
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Literacy: 48%
Labor force: 12.0 million, est. (1979); 33% ag-
riculture, 21% manufacturing; shortage of
skilled labor; unemployment may be as high
as 35%','53fadc77837289865fa0ff7f8e2893aa184042613540822c92228fee1babc7a1','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d49e0d61d45fb842696a078baa57619fb98b0609f007f8961f4d4fd3c7df21d1',1985,'IQ','Iraq','people-and-society',285,'Population: 15,507,000 (July 1985), average
annual growth rate 3.3%; figures do not take
into account the impact of the Iran-Iraq war
Nationality: noun — Iraqi(s); adjective —
Iraqi
Ethnic divisions: 7 5% Arab, 15-20% Kurdish,
10% Turkic, Assyrian, and other
Religion: 90% Muslim (55% Sh‘ia, 40%
Sunni), 10% Christian or other
Language: Arabic (official), Kurdish (official
in Kurdish regions); Assyrian, Armenian
Literacy: about 50%
Labor force: 3.1 million (1977); 30% agricul-
ture, 27% industry, 21% government, 22%
other; severe labor shortage due to war; ex-
patriate labor force est. at 900,000
Organized labor: 11% of labor force -','628a7d5f7f28d2e43d147b864ee2425333c2d9d2877aab9c6c3e203c43d542d9','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('440c647bfcaecc0f8b8fadd0d89ab6867008c5b652d6524ceb0ce4309229b71a',1985,'IE','Ireland','people-and-society',289,'Population: 3,590,000 (July 1985), average
annual growth rate 1.0%
Nationality: noun — Irishman(men), Irish
(collective pi.); adjective — Irish
Ethnic divisions: Celtic, with English minor-
ity
Religion: 94% Roman Catholic, 4% Anglican,
2% other
Language: Irish (Gaelic) and English (offi-
cial); English is generally spoken
Literacy: 99%
Labor force: about 1,173,000(1981); 19.6%
manufacturing; 17.8% agriculture, forestry,
fishing; 16.2% commerce; 8.3% construction;
5.8% government; 5.5% transportation;
26.8% other; 10.9% unemployment (average
1981)
Organized labor: 36% of labor force','1a8ea60a5f37eab8aa3eb33cc49e56a5cdf62eef4fd0081b6f5345f128e4d677','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('878cd97b48b61fcd87950c58cb2ee1724cae0984719aa9a8edbc7da1453a91f8',1985,'IL','Israel','people-and-society',293,'Population: 4,085,000, excluding West
Bank, Gaza Strip, and East Jerusalem (July
1985), average annual growth rate 1.6%
Nationality: noun — Israeli(s); adjective —
Israeli
Ethnic divisions: 85% Jewish, 15% non-Jew-
ish (mostly Arab)
Religion: 85% Judaism, 11% Islam, 4% Chris-
tian and other
Language: Hebrew official; Arabic used offi-
cially for Arab minority; English most
commonly used foreign language
Literacy: 88% Jews, 70% Arabs
Labor force: est. 1,400,000 (1984); 29.5%
public services; 22.8% industry, mining, and
manufacturing; 12.8% commerce; 9.5% fi-
nance and business; 6.8% transport, storage,
and communications; 6.5% construction and
public works; 5.5% agriculture, forestry, and
fishing; 5.8% personal and other services;
1.0% electricity and water (1983); unemploy-
ment about 6% (1984 est.)
Organized labor: 90% of labor force
Population: 57,149,000 (July 1985), average
annual growth rate 0.3%
Nationality: noun— Italian(s); adjective —
Italian
Ethnic divisions: primarily Italian but popu-
lation includes small clusters of German-,
French-, and Slovene-Italians in the north
and of Albanian-Italians in the south
Religion: almost 100% nominally Roman
Catholic
Language: Italian; parts of Trentino-Alto
Adige region (for example, Bolzano) are pre-
dominantly German speaking; significant
French-speaking minority in Valle d’Aosta
region; Slovene-speaking minority in the
Trieste-Gorizia area
Literacy: 93%
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Labor force: 23,272,000 (October 1984);
29.9% industry, 10.6% agriculture, 49.3% ser-
vices (October 1984); 10.2% unemployment
(October 1984)
Organized labor: 50-55% (est.) of labor force
Popu/afion; 10,056,000 (July 1985), average
annual growth rate 4.0%
Nationality: noun— Ivorian(s); adjective —
rivorian
Ethnic divisions: 7 major indigenous ethnic
groups; no single tribe more than 20% of
population; most important are Agni, Baoule,
Krou, Senoufou, Mandingo; approximately 2
million foreign Africans, mostly Burkinabe;
about 70,000 to 75,000 non- Africans (40,000
French and 25,000 to 30,000 Lebanese)
Religion: 63% indigenous, 25% Muslim, 12%
Christian
Language: French (official), over 60 native
dialects; Dioiila most widely spoken
Literacy: 24%
118
Labor force: over 85% of population engaged
in agriculture, forestry, livestock raising;
about 11% of labor force are wage earners,
nearly half in agriculture, remainder in gov-
ernment, industry, commerce, and
professions
Organized labor: 20% of wage labor force','c96ba6a179bea4722a85c4186d84996bae0cc528f9326070d86718afe3520f97','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b3c838a869811c8ffe9aaa08738fe661a24bfc5bfb295a3d227fd74b0beda90',1985,'JM','Jamaica','people-and-society',299,'Population: 2,428,000 (July 1985), average
annual growth rate 1.6%
Nationality: noun — Jamaican(s); adjective —
Jamaican
Ethnic divisions: 7 6.3% African, 15.1% Afro-
European, 3.4% East Indian and Afro-East
Indian, 3.2% white, 1.2% Chinese and Afro-
Chinese, 0.9% other
Religion: predominantly Protestant (includ-
ing Anglican and Baptist), some Roman
Catholic, some spiritualist cults
Language: English, Creole
Literacy: 76%
Labor force: 703,000(1980); 36.4% agricul-
ture, 32.7% services, 16% government, 14.9%
industry and commerce; shortage of tech-
nical and managerial, personnel; significant
unemployment
Organized labor: about 33% of labor force
(1980)
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Jamaica (continued)','7ef5a1e701618f3c65d79d6135beb4b5ae49b803a58f7755bd63162153668e22','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('506e627202a7dc29a72eedb7cf172b5a7e0ae030a7b5a7f5648c1ec1779a44fe',1985,'JP','Japan','people-and-society',301,'Population: 120,691,000 (July 1985), average ;
annual growth rate 0.6%
Nationality: noun — Japanese (sing., pi.); ad-
jective — Japanese
Ethnic divisions: 99.4% Japanese, 0.6% other
(mostly Korean)
Religion: most Japanese observe both Shinto
and Buddhist rites; about 16% belong toother
faiths, including 0.8% Christian
Language: Japanese
Literacy: 99%
Labor force: (1983) 58.9 million; 52% trade
and services; 35% manufacturing, mining,
and construction; 10% agriculture, forestry,
and fishing; 3% government; 2.7% unem-
ployed
Organized labor: about 30% of labor force','9738017a60189350b6c21d9724813aff9297e11e957d29101073fe5bf75c6888','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7b5dab23234372a46d839009320d5aa2c9c640982c20997df9f5f2c4449e1b4',1985,'JO','Jordan','people-and-society',305,'Population: 2,794,000, excluding West Bank
and East Jerusalem (July 1985), average an-
nual growth rate 3.8% " •
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Nationality: noun — Jordanian(s); adjec-
tive — Jordanian
Ethnic divisions: 98% Arab, 1% Circassian,
1% Armenian
Religion: 90-92% Sunni Muslim, 8-10%
Christian
Language: Arabic official; English widely
understood among upper and middle classes
Literacy: about 70%
Labor force: 463,000
Organized labor: about 10% of labor force','e3e5f2b5c12f86af38d22b9fc7a63c49e6d62e631081a42d067d21bbc679163f','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29c6204bdee8fcb0662022f4883ff8bbf24f49d898e26cce0548c0df09e9faff',1985,'KE','Kenya','people-and-society',309,'Population: 20,194,000 (July 1985), average
annual growth rate 4.2%
Nationality: noun — Kenyan(s); adjective —
Kenyan
Ethnic divisions: 21% Kikuyu, 14% Luhya,
13% Luo, 11% Kalenjin, 11% Kamba, 6%
Kisii, 5% Meru, 1% Asian, European, and
Arab
Religion: 38% Protestant, 28% Catholic, 26%
indigenous beliefs, 6% Muslim
Language: English and Swahili (official); nu-
merous indigenous languages
Literacy:47%
Labor force: 5.4 million; about 1.1 million
wage earners; 47% public sector, 18% indus-
try and commerce, 17% agriculture, 13%
services
Organized labor: about 390,000
Population: 44,000 (July 1985), average an-
nual growth rate —0.3%
Ethnic divisions: mainly of African Negro
descent
Nationality: noun — Kittsian(s), Nevisian(s);
adjective — Kittsian, Nevisian
Religion: Anglican, other Protestant sects,
Roman Catholic
Language: English
Literacy: 80%
Labor force: 20,000 (1981)
Organized labor: 6,700
Population: 122,000 (July 1985), average an-
nual growth rate 1.1%
Nationality: noun — St. Lucian(s); adjec-
tive — St. Lucian
Ethnic divisions: 90.3% African descent,
5.5% mixed, 3.2% East Indian, 0.8% Cauca-
sian
Religion: 90% Roman Catholic, 7% Protes-
tant, 3% Church of England
Language: English (official), French patois
Literacy: 78%
Labor force: 45,000 (1979); 43.4% agricul-
ture, 38.9% services, 17.7% industry and
commerce; 13% unemployment (1979)
Organized labor: 20% of labor force
195
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
St. Lucia (continued)
Population: 102,000 (July 1985), average an-
nual growth rate 1.4%
Nationality: noun — St. Vincentian(s) or Vin-
centian(s); adjectives — St. Vincentian or
Vincentian
Ethnic divisions: mainly of African Negro
descent; remainder mixed, with some white,
East Indian, Carib Indian
Religion: Anglican, Methodist, Roman Cath-
olic
Language: English, some French patois
Literacy: 82%
Labor force: 61,000(1979 est.); about 20% un-
employed (1978)
Organized labor: 10% of labor force
196
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7','74b3e960a999c3585a5b36b38591b6ea621d265a4a1747677aeb2f42997866eb','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a346a84fd79f51652f503fcefc20765a7e9fde3ee451a327ed78122db86fbc1a',1985,'KI','Kiribati','people-and-society',313,'Population: 62,000 (July 1985), average an-
nual growth rate 1.6%
Nationality: noun — Kiribatian(s); adjec-
tive — Kiribati
Ethnic divisions: Micronesian
Religion: Roman Catholic, Protestant
Language: English (official), Gilbertese
Literacy: 90%
Labor force: 15,921 (1973); general unem-
ployment rate 4.9%
Population: 20,082,000 (July 1985), average
annual growth rate 2.3%
Nationality: noun — Korean(s); adjective —
Korean
Ethnic divisions: racially homogeneous
Religion: Buddhism and Confucianism; reli-
gious activities now almost nonexistent
Language: Korean
Literacy: 95% est.
Labor force: 6.1 million (1980); 48% agricul-
tural, 52% nonagricultural; shortage of
skilled and unskilled labor
Population: 42,643,000 (July 1985), average
annual growth rate 1.5%
Nationality: noun — Korean(s); adjective —
Korean
Ethnic divisions: homogeneous; small Chi-
nese minority (approx. 20,000)
Religion: strong Confucian tradition; perva-
sive folk religion (Shamanism); Buddhism
(including estimated 20,000 members of Soka
Gakkai); Chondokyo (religion of the heav-
enly way), eclectic religion with nationalist
overtones founded in 19th century, claims
about 1.5 million adherents
Language: Korean; English widely taught in
high school
Literacy: over 90%
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Korea, South (continued)
Labor force: 15. 1 million (1983); 47% services
and other; 30% agriculture, fishing, forestry;
21 % mining and manufacturing; average un-
employment 4.1% (1983)
Organized labor: about 10% of nonagricul-
tural labor force','f3cc5c69a9336c5142734d47389541e72bd85b7d57ea2e35813d3ff490220997','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c783e66a7797befcd01c291246515d37c511091665fa12a24bd1b6097bb992a0',1985,'KW','Kuwait','people-and-society',317,'Population: 1,870,000 (July 1985), average
annual growth rate 6.2%
Nationality: noun — Kuwaiti(s); adjective —
Kuwaiti
Ethnic divisions: 39% Kuwaiti, 39% other
Arab, 9% South Asian, 4% Iranian, 9% other
Religion: 95% Muslim, 5% Christian, Hindu,
Parsi, and other
Language: Arabic (official); English widely
spoken
Literacy: about 71%
Labor force: 630,000 (1983 est.); 74% ser-
vices, 1 1 % industry, 1 1 % construction; 70% of
labor force is non-Kuwaiti
Organized labor: labor unions, first autho-
rized in 1964, formed in oil industry and
among government personnel
129
Population: 3,805,000 (July 1985), average
annual growth rate 2.2%
Nationality: noun — Lao (sing., Lao or Lao-
tian); adjective — Lao or Laotian
Ethnic divisions: 48% Lao; 25% Phoutheung
(Kha); 14% Tribal Tai; 13% Meo, Yao, and
other
Religion: 50% Buddhist, 50% animist and
other
Language: Lao (official), French, and En-
glish
Literacy: 28%
Labor force: about 1-1.5 million; 80-90% ag-
riculture
Organized labor: only labor organization is
subordinate to the Communist Party','90eae5f346911e8ba3b57943f18a5b2a22ec8d690fc17e7d5f25ee7b72805237','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34243004e4a8c4f94c75a948a218f099a7f096fd2d992df4f0a5cf2ef538a677',1985,'LB','Lebanon','people-and-society',321,'Population: 2,619,000 (July 1985), average
annual growth rate 0.7% •
Nationality: noun — Lebanese (sing., pi.); ad-
jective — Lebanese
Ethnic divisions: 93% Arab, 6% Armenian,
1% other
Religion: 57% Muslim (Sunni and Sh''ia) and
Druze, 42% Christian (Maronite, Greek Or-
thodox and Catholic, Roman Catholic,
Protestant), 1% other (official estimates);
Muslims, in fact, constitute a majority
Language: Arabic (official); French is widely
spoken; Armenian, English
Literacy: 75% ■ ’
Labor force: 650,000 (1981); 75% industry,''
commerce, and services, 17% agriculture; 8%
goverment; high unemployment
Organized labor: about 65,000
Governnieht
NOTE; Between early 1975 and'' late 1976
Lebanon was torn by civil war between its
Christians — then aided by Syrian troops—
and its Muslims and their Palestinian allies.
The cease-fire established in October 1976
between the domestic political groups gener-
ally held for about six years, despite
occasional fighting. Syrian troops constituted
as the Arab Deterrent Force by the Arab
League have remained in Lebanon. Syria’s
move toward supporting the Lebanese Mus-
lims and the Palestinians and Israel’s growing
support for Lebanese Christians brought the
two sides into rough equilibrium, but no
progress was made toward national reconcili-
ation or political reforms— the original cause
of the war. ''
Continuing Israeli concern about the Pal-
estinian presence in Lebanon led to the
Israeli invasion of Lebanon in June 1982.
Israeli forces occupied all of the southern por-
tion of the country and mounted a summer-
long seige of Beirut, which resulted in the
evacuation of the PLO from Beirut in Sep-
tember under the supervision of a multi-
national force made up of US, French, and
Italian troops.
Within days of the departure of the multina-
tional force (MNF), Lebanon’s newly elected
president, Bashir Gemayel, was assassinated.
In the wake of his death, Christian militia
men massacred hundreds of Palestinian refu-
gees in two Beirut camps. This prompted the
return of the MNF to ease the security bur-
den on Lebanon’s weak army and security
forces. In late March 1984 the last MNF units
withdrew.
Lebanon continues to be occupied by Israel
in the south and by Syria in the north and
east. Israel and Lebanon signed a withdrawal
agreement on 17 May 1983. The agreement
was never implemented and was subse-
quently voided. A partial Israeli withdrawal
and government attempts to extend its au-
thority have led to renewed factional
fighting. The following description is based
on the present constitutional and customary
practices of the Lebanese system.
Official narhe: Republic of Lebanon
Tt/p^;'' republic
Capital: Beirut
Political subdivisions: 5 provinces
Legal system: mixture of Ottoman law,
canon law, and civil law system; constitution
mandated in 1926; no judicial review of legis-
lative acts; legal education at Lebanese
University; has not accepted compulsory ICJ
jurisdiction
Ndtiorial holiday: Independence Day, 22
November
Branches: power lies with President elected
by unicameral legislature (National Assem-
bly, formerly Chamber of Deputies); Cabinet
appointed by President, approved by legisla-
ture; independent secular courts on French
pattern; religious courts for matters of mar-
riage, divorce, inheritance, etc.; by custom.
President is a Maronite Christian, Prime
Minister is a Sunni Muslim, and president of
legislature is a Sh‘ia Muslim; each of nine reli-
gious communities represented in legislature
in proportion to national numerical strength
Government leader: Amine Pierre
GEMAYEL, President (since September
1982); Rashid KARAMI, Prime Minister
(since May 1984)
Suffrage: compulsory for all males over 21;
authorized for women over 21 with elemen-
tary education
Elections: National Assembly held every
four years or within three months of dissolu-
tion of Chamber; security conditions have
prevented parliamentary elections since
April 1972
Political parties and leaders: political party
activity is organized along largely sectarian
lines; numerous political groupings exist, con-
sisting of individual political figures and
fblloweirs motivated by religious, clan, and
economic considerations; most parties have
well-armed militias, which are still involved
in occasional clashes
132
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7','e7be06d9c27ccbaa0f889869e17fb1255d0a8c513912c319d346789582728595','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('036f83a6fd802ea5b8439d7967242b41ac0ed8aac33c1b19b03e2f41fd5ac621',1985,'LS','Lesotho','people-and-society',322,'Communists: the Lebanese Communist
Party was legalized in 1970; members and
sympathizers estimated at 2,000-3,000
Member of: Arab League, FAO, G-77, IAEA,
IBRD, ICAO, IDA, IDB — Islamic Develop-
ment Bank, IFAD, IFC, ILO, IMF, IMO,
INTELSAT, INTERPOL, IPU, ITU, IWC—
International Wheat Council, NAM, OIC,
UN, UNESCO, UPU, WFTU, WHO, WMO.
WSG, WTO
Population: 1,512,000 (July 1985), average
annual growth rate 2.5%
Nationality: noun — Mosotho (sing.), Basotho
(pi.); adjective — Basotho
Ethnic divisions: 99.7% Sotho; 1,600 Europe-
ans, 800 Asians
Religion: 80% Christian, rest indigenous be-
liefs
Language: Sesotho (southern Sotho) and En-
glish (official); also Zulu and Xhosa
Literacy: 55%
Labor force: 426,000 economically active
(1976); 87.4% of resident population engaged
in subsistence agriculture; 150,000-250,000
spend from six months to many years as wage
earners in South Africa
Organized labor: negligible','2286df8c9bbd739acfdfc2adfa3ce21e399c61fc5b165cee1051bac28d1b9b7c','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c3fc2949b458038229477ae908028e680f0c818042c212f5423de5e895a04f9',1985,'LR','Liberia','people-and-society',328,'Population: 2,232,000 (July 1985), average
annual growth rate 3.3%
Nationality: noun— Liberian(s); adjective—
Liberian
Ethnic divisions: 95% indigenous African
tribes, including Kpelle, Bassa, Qio, Kru,
Grebo, Mano, Krahn, Gola, Gbandi, Loma,
Kissi, Vai, and Bella; 5% descendants of repa-
triated slaves known as Americo-Liberians
Religion: 75% traditional, 15% Muslim, 10%
Christian
Language: English (official); more than 20 lo-
cal languages of the Niger-Congo language
group; English used by about 20%
Literacy: 24%
Labor force: 510,000, of which 160,000 are in
monetary economy; non-African foreigners
hold about 95% of the top-level management
and engineering jobs; 70.5% agriculture,
10.8% services, 4.5% industry and commerce,
14.2% other
Organized labor: 2% of labor force','0896f6b25d9a92edd240fee231ea95c93745d6114ed94e58e016cd54efd6c670','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23c7b1750d235f36e41c8c85073ac0a6038c4a433b21d6a88fcf92efb8b30978',1985,'LI','Liechtenstein','people-and-society',333,'Population: 28,000 (July 1985), average an-
nual growth rate 1.8%
(1984); 11.870 billion kWh produced (1984),
3,170 kWh per capita
Exports: $10.0 billion (f.o.b., 1984); petro-
leum
Nationality: noun — Liechtensteiner(s); ad-
jective — Liechtenstein
Imports: $8.0 billion (f.o.b., 1984); manufac-
tures, food
Ethnic divisions: 95% Alemannic, 5% Italian
and other
Major trade partners: imports — Italy, FRG;
exports — Italy, FRG, Spain, France, Japan,
Religion: 82.7% Roman Catholic, 7.1% Prot-
estant, 10,2% other
UK
■ <
Language: German (official), Alemannic di-
alect
Budget: (1984 est.) revenues, $10.50 billion;
expenditures, $10.1 billion, including devel-
opment expenditure of $6.3 billion
Literacy: 100%
Monetary conversion rate: .2961 Libyan
dinar=US$l (February 1984)
Fiscal year: calendar year
Labor force: 11,368; 5,078 foreign workers
(mostly from Switzerland and Austria); 54.5%
industry, trade, and building; 41.6% services;
4.0% agriculture, fishing, forestry, and horti-
culture','595d2223cb61c483e88c35f225419cfdc8e764294ccfedc77502d15b6a79abc5','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1cadad863591cf1130c9db4fe0b4b2b7c5c395bfbe5eb43d758b38e149199e0',1985,'LU','Luxembourg','people-and-society',336,'Population: 367,000 (July 1985), average an-
nual growth rate 0.1%
Nationality: noun — Luxembourger(s); adjec-
tive — Luxembourg
Ethnic divisions: Celtic base, with French
and German blend; also guest and worker res-
idents from Portugal, Italy, and European
countries
Religion: 97% Roman Catholic, 3% Protes-
tant and Jewish
Language: Luxembourgish, German,
French; most educated Luxembourgers also
speak English
Literacy: 100%
Labor force: (1981) 161,700; one-third of
labor force is foreign, comprising mostly
workers from Portugal, Italy, France, Bel-
gium, and FRG (1981); unemployment 1.0%
(1981 average); 45% services, 42% industry
and commerce, 12% government, 0.5% agri-
culture
Population: 393,000 (July 1985), average an-
nual growth rate 3.4%
Nationality: noun — Macanese (sing, and pi.);
adjective — Macau
Ethnic divisions: 98% Chinese, 2% Portu-
guese
Religion: mainly Buddhist; 17,000 Catholics,
of whom about half are Chinese
Language: 98% Chinese, 2% Portuguese
Literacy: almost 100% arriong Portuguese
and Macanese; no data on Chinese popula-
tion','ad5819f3cf1b0a7260a18b12379c58d29c595cd3743ba72d507c6322dd085cf0','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9e98f1740d063c5f5f1409f28978016641c5af2cc35ede0d7d77183ffa4bf49',1985,'MW','Malawi','people-and-society',343,'Population: 7,056,000 (July 1985), average
annual growth rate 3.3%
Nationality: noun — Malawian(s); adjec-
tive — Malawian
Ethnic divisions: Chewa, Nyanja, Tumbuko,
Yao, Lomwe, Sena, Tonga, Ngoni, Asian, Eu-
ropean
Religion: 55% Protestant, 20% Roman Cath-
olic, 20% Muslim; traditional indigenous
beliefs are also practiced by some members
of these groups
Language: English and Chichewa (official);
Tombuka is second African language
Literacy: 25%
Labor force: 344,052 wage earners employed
in Malawi (1982); 52% agriculture, 16% per-
sonal services, 9% manufacturing, 7%
construction, 6% commerce, 4% miscella-
neous services, 5% other permanently
employed
Organized labor: small minority of wage
earners are unionized
Population: 15,664,000 (July 1985), average
annual growth rate 2.2%
Peninsular Malaysia: 12,854,000 (July 1985),
average annual growth rate 2.0%
Sabah: 1,279,000 (July 1985), average annual
growth rate 3.9%
Sarawak: 1,532,000 (July 1985), average an-
nual growth rate 2.4%
Nationality: noun — Malaysian(s); adjec-
tive — Malaysian .
Ethnic divisions: 50% Malay, 36% Chinese,
10% Indian, 4% other
Religion:
Peninsular Malaysia: Malays nearly all Mus-
lim, Chinese predominantly Buddhists,
Indians predominantly Hindu
Sabah: 38% Muslim, 17% Christian, 45%
other
Sarawak: 35% tribal religion, 24% Buddhist
and Confucianist, 16% Christian, 2% other
Language:
Peninsular Malaysia: Malay (official); En-
glish, Chinese dialects, Tamil
Sabah: English, Malay, numerous tribal dia-
lects, Mandarin and Hakka dialects
predominate among Chinese
Sarawak: English, Malay, Mandarin, numer-
ous tribal languages
Literacy:
Peninsular Malaysia: 75%
Sabah: 58%
Sarawak: 55% ;
Labor force:
Malaysia: 5.58 million (1983); 37% agricul-
ture, forestry, livestock, and fishing; 39%
trade, transport, arid services; 22% manufac-
turing and construction
. }■ -i
Organized labor: 612,000 (November 1983),
about 11% of totaMabor force; unemploy-
ment about 6.0% of total labor force (1983),
but higher in urban areas','7964b7966d67dc9a3bb639c4613f99f1c52fda614a04858efcc7efd9ff0b4d38','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f931587b6c7ae4231f1d6d2879cd2bd66d4b262c8c8bbd605004c30fadc8ba84',1985,'MV','Maldives','people-and-society',347,'Population: 178,000 (July 1985), average an-
nual growth rate 3.0%
Nationality: noun — Maldivian(s); adjec-
tive — Maldivian
Ethnic divisions: admixtures of Sinhalese,
Dravidian, Arab, and black
Religion: Sunni Muslim
Language: Divehi (dialect of Sinhala; script
derived from Arabic); English spoken by
most government officials
Literacy: 36%
Labor force: total employment is approxi-
mately 66,000; fishing industry employs 80%
of the labor force','a72821768c340e833cfaf5c58e5017e329bc3a2dcec4da92f5695cb360bcc28d','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bea86e1ed06326995b1021914366732f983f9a4fe3cd242edbc074a1d61bade1',1985,'ML','Mali','people-and-society',353,'Population: 7,735,000 (July 1985), average
annual growth rate 2.3%
Nationality: noun — Malian(s); adjective —
Malian
Ethnic divisions: 50% Mande (Bambara, Ma-
linke, Sarakole), 17% Peul, 12% Voltaic, 6%
Songhai, 5% Tuareg and Moor
Religion: 90% Muslim, 9% indigenous be-
liefs, 1% Christian
Language: French (official); Bambara spo-
ken by about 80% of the population
Literacy: 10%
Labor force: 3.1 million (1981); 80% agricul-
ture, 19% services, 1% industry and
commerce
Organized labor: National Union of Malian
Workers (UNTM) is umbrella organization
over 13 national unions','11314c7d55b7f571ab63f39bfd187a86b6d0eb805049dc89af700848980bd076','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61e3ffec4c40d34994bc0a37c4e85d95b71f05ec66ac63d90c53edbd99b2f549',1985,'MT','Malta','people-and-society',357,'Population: 355,000 (July 1985), average an-
nual growth rate —0.5%
Nationality: noun — Maltese (sing, and pi.);
adjective — Maltese
Ethnic divisions: mixture of Arab, Sicilian,
Norman, Spanish, Italian, English
Religion: 98% Roman Catholic
Language: Maltese and English (official)
Literacy: 83%
Labor force: 120,419 (1983); 33% services (ex-
cept government), 26% manufacturing, 23%
government (except job corps), 5% agricul-
ture, 5% utilities and drydocks; 8.2%
registered unemployed
Organized labor: approximately 40% of la-
bor force','1b7d12201c9b12ca690825444f776ffbf54e50f6d4a8200d8adb6f9caf35436d','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0a7db8283feafd69b2927dc028eccbf7dd86a713f7785c98d8ac4b696192dde5',1985,'MQ','Martinique','people-and-society',362,'Population: 327,000 (July 1985), average an-
nual growth rate 0.1%
Nationality: noun — Martiniquais (sing, and
pi.); adjective — Martiniquais
Ethnic divisions: 90% African and African-
Caucasian-Indian mixture, 5% Caucasian,
less than 5% East Indian, Lebanese, Chinese
Religion: 95% Roman Catholic, 5% Hindu
and pagan African
Language: French, Creole patois
Literacy: over 70% ■
Labor force: 100,000; 31.7% service industry,
29.4% construction and public works, 13.1%
agriculture, 7.3% industry, 2.2% fisheries,
16.3% other; 14% unemployed
Organized labor: 11% of labor force
150
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7','8e63a75225562a60102e9ffce956f8cf7670d1064da895911357c5fdf3ad855b','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f83ae1dbb28e3f04e3c744ff4795efadcb2aa4df88e1b04dd49414c964bdff5a',1985,'MR','Mauritania','people-and-society',364,'Population: 1,656,000 (July 1985), average
annual growth rate 2.0%
Nationality: noun— Mauritanian(s); adjec-
tive — Mauritanian
Ethnic divisions: 40% mixed Moor/black;
30% Moor, 30% black
Religion: nearly 100% Muslim
Language: Hasanya Arabic (national);
French (official); Toucouleur, Fula, Sarakole
Wolof
Literacy: 17%
Labor force: total labor force 465,000 (1981
est.); about 45,000 wage earners (1980 IMF);
47% agriculture, 29% services, 14% industry
and commerce, 10% government; consider-
able unemployment
Organized labor: 30,000 members claimed
by single union, Mauritanian Workers’
Union','fe0d94d618202e10e4c2917fa30dab20528f616d35c1645e410eda1ac0091cef','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f44da156ddeb4b55c7e734c959a825db22f112ca8b67370d310af3cc7052bf12',1985,'MU','Mauritius','people-and-society',368,'Population: 1,011,000 (July 1985), average
annual growth rate 0.9%
Nationality: noun — Mauritian(s); adjec-
tive — Mauritian
Ethnic divisions: 68% Indo-Mauritian, 27%
Creole, 3% Sino-Mauritian, 2% Franco-Mau-
ritian
Religion: 51% Hindu, 30% Christian (mostly
Roman Catholic with a few Anglicans), 17%
Muslim
Language: Creole, French, English, Hindi,
Urdu, Hakka, Bojpoori
Literacy: 61%
Labor force: 335,000; 29% agriculture and
fishing, 28% government services, 23%
industry and commerce, 20% other; 14% are
unemployed .
Organized labor: about 35% of labor force,
forming over 270 unions
Population: 79,662,000 (July 1985), average
annual growth rate 2.5%
Nationality: noun — Mexican(s); adjective —
Mexican
Ethnic divisions: 60% mestizo (Indian-Span-
ish), 30% Amerindian or predominantly
Amerindian, 9% white or predominantly
white, 1% other
Religion: 97% nominally Roman Catholic,
3% Protestant
Language: Spanish
Literacy: 74%
Labor force: 21,500,000 (1982); 31.4% ser-
vices; 26% agriculture, forestry, hunting,
fishing; 13.9% commerce; 12.8% manufac-
turing; 9.5% construction; 4.8%
154
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
'' transportation; 1.3% mining and quarrying;
0.3% electricity; 10% unemployed, 40% un-
deremployed
Organized labor: 20% of total labor force','0ea6badac357b7743df90fe75ff0301ee4c1a994b96c0431373e0b003ee3273b','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffcae7ae84439f3a75b090a042f4a4afe7c0057c6e168b3af225bbadf832d1d5',1985,'MC','Monaco','people-and-society',372,'Population: 28,000 (July 1985), average an-
nual growth rate 1.2%
Nationality: noun — Monacan(s) or Mone-
gasque(s); adjective— Monacan or
Monegasque
Ethnic divisions: 58% French, 19% Mone-
gasque, 17% Italian, 6% unspecified
Religion: 95% Roman Catholicism
Language: French (official), English, Italian,
Monegarque
Literacy: 99%','daf66b92399c3bb4d7422eb662a90efda135cb4b813bfc5c3ee0ab1ac0aec0fe','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f15aad22fcded6628f112990a3ecb55a23f7453d90148b17bdddf01046439fa',1985,'MN','Mongolia','people-and-society',377,'Population: 1,912,000 (July 1985), average
annual growth rate 2.7%
Nationality: noun — Mongolian(s); adjec-
tive — Mongolian
Ethnic divisions: 90% Mongol, 4% Kazakh,
2% Chinese, 2% Russian, 2% other
Religion: predominantly Tibetan Buddhist,
about 4% Muslim, limited religious activity
because of Communist regime
Language: Khalkha Mongol used by over
90% of population; minor languages include
Turkic, Russian, and Chinese
Literacy: about 80%
Labor force: primarily agricultural, over half
the adult population is in the labor force, in-
cluding a large percentage of women;
shortage of skilled labor (no reliable informa-
tion available)','a3d8b8db6c19e37af38492f226fc985490296d1a4f0d409edc9d50038377cdfd','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('205efd283c675cb5fbd1c85d837b8d936ca192bd92e42a0c7b50c3b487a268a4',1985,'MA','Morocco','people-and-society',380,'Population: 24,258,000 (July 1985), average
annual growth rate 2.9%
Nationality: noun — Moroccan(s); adjec-
tive — Moroccan
Ethnic divisions: 99.1% Arab- Berber, 0.7%
non-Moroccan, 0.2% Jewish
Religion: 98.7% Muslim, 1.1% Christian,
0.2% Jewish
Language: Arabic (official); several Berber
dialects; French is language of much busi-
ness, government, diplomacy, and
postprimary education
Literacy: 28%
Labor force: 6.1 million (1982 est.); 50% agri-
culture, 26% services, 15% industry, 9%
other; at least 20% of urban labor unem-
ployed
158
Organized labor: about 5% of the labor force,
mainly in the Union of Moroccan Workers
(UMT) and the Democratic Confederation of
Labor (CDT)','6cd3a6d332bdf4a5d9bfd0eb91f1f0f7e8d9cd54399baa7088237d38e774fff7','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68a1c12682c8a4469ec6c4c7699e6b8fe365e269c071d8d60f11b212e63dcad5',1985,'MZ','Mozambique','people-and-society',386,'Population: 13,776,000 (July 1985), average
annual growth rate 2.8%
Nationality: noun — Mozambican(s); adjec-
tive — Mozambican
Ethnic divisions: majority from indigenous
tribal groups; approximately 10,000 Europe-
ans, 35,000 Euro-Africans, 15,000 Indians
Religion: 60% indigenous beliefs, 30% Chris-
tian, 10% Muslim
Language: Portuguese (official); many indig-
enous dialects
Literacy: 14%','20a3d318124d5045af86c230dcf57ca7358809e9c0c2a22d43d583e94238bbb7','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('512332022a74156bcdbfba255ca7e79d17eab17c6c57c6bb845e1f35ca117399',1985,'NA','Namibia','people-and-society',390,'Population: 1,108,000 (July 1985), average
annual growth rate 3.0%
Nationality: noun — Namibian(s); adjec-
tive — Namibian
Ethnic divisions: 85.6% black, 7.5% white,
6.9% mixed; approximately half the Africans
belong to Owambo tribe
Religion: whites predominantly Christian,
non whites either Christian or indigenous be-
liefs ’
Language: Afrikaans principal language of
about 60% of white population, German of
33%, and English of 7% (all official); several
indigenous languages
Literacy: 100% whites, 28% nonwhites
Labor force: about 500,000 (1981); 60% agri-
culture, 19% industry and commerce, 8%
services, 7% government, 6% mining
Organized labor: 6 trade unions, member-
ship almost exclusively white and mulatto','0da51924e1c6e132ad79ed9d1e5ff73448451367e294fc8136fb2f09f0a8d4f5','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f37c77383568ede3814bf76420d794b57560dc28f088eecff4846538c3643e04',1985,'NR','Nauru','people-and-society',394,'Population: 8,000 (July 1985), average an-
nual growth rate 1.3%
Nationality: noun — Nauruan(s); adjective —
Nauruan
Ethnic divisions: 58% Nauruan, 26% other
Pacific Islander, 8% Chinese, 8% European
Religion: Christian (two-thirds Protestant,
one-third Catholic)
Language: Nauruan, a distinct Pacific Island
language (official); English widely under-
stood and spoken
Literacy: 99%','9add7ca2717d0f28b8a44ad0150d2a8b557257ea733aabb75f94de534cc27153','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3f460d68d7d2d3f2eccae1bd9ef5463eb508ea3ebd72eb255bea63e4f64dc09',1985,'NP','Nepal','people-and-society',399,'Population: 16,996,000 (J-uly 1985), average
annual growth rate 2.5%
Nationality: noun— Nepalese (sing, and pi.);
adjective — Nepalese
Ethnic divisions: Newars, Indians, Tibetans,
Gurungs, Magars, Tamangs, Bhotias, Rais,
Limbus, Sherpas, as well as many smaller
groups
Religion: only official Hindu kingdom in
world, although no sharp distinction between
many Hindu (about 88%) and Buddhist
groups; small groups of Muslims and Chris-
tians
Language: Nepali (official); 20 mutually un-
intelligible languages divided into numerous
dialects
Literacy: 20%
Labor force: 4.1 million; 93% agriculture, 5%
services, 2% industry; great lack of skilled
labor
163
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Nepal (continued)','c66c4845b987ee4c76ba42c6d56bb3f127b4be1195b061e8fe0a4025d42efcfc','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4101e0387c86dcb199d7992607da1f60afea6f0de94f6379f4e9bd4b303d5bac',1985,'NL','Netherlands','people-and-society',401,'Population: 14,467,000 (July 1985), average
annual growth rate 0.4%
Nationality: noun — Netherlander(s); adjec-
tive — Netherlands
Ethnic divisions: 99% Dutch, 1% Indonesian
and other
Religion: 40% Roman Catholic, 31% Protes-
tant, 24% unaffiliated
Language: Dutch
Literacy: 99%
Labor force: 4.9 million (1981); 30% manu-
facturing, 24% services, 16% commerce, 10%
agriculture, 9% construction, 7% transporta-
tion and communications, 4% other; 11.3%
unemployment, September 1982
Organized labor: 33% of labor force','6795ef25f54fef7ac8fa7d3a6807075366b9f158903e54e32d160aa7972848c4','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f03e18c1bca207e4d7375105d0880d1b607f78bb9fbd7cc5e6a4a5c651eca5ad',1985,'AW','Aruba','people-and-society',405,'Population: 256,000 (July 1985), average an-
nual growth rate 1.2%
Nationality: noun — Netherlands Antille-
an(s); adjective-— Netherlands Antillean
Ethnic divisions: 85% mixed African; re-
mainder Carib Indian, European, Latin, and
Oriental
Religion: predominantly Roman Catholic;
Protestant, Jewish, Adventist
Language: Dutch (official); Papiamento, a
Spanish- Portuguese-Dutch-English dialect
predominates; English widely spoken;
Spanish
Literacy: 95%
Labor force: 89,000(1983); 65% government,
28% industry and commerce, 1.5% agricul-
ture; unemployment about 16% on Curagao
and about 10% on Aruba (1984 est.)
Organized labor: 60-70% of labor force
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7','db4018e2c7cc7bd22e897e9d73a8c7c5ee713d4d5732e9afd2f3b6458ff700de','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a84eb7e8456247eda45ad130e2be788cfb9844890d493b1d40244f0b301b8ac2',1985,'NC','New Caledonia','people-and-society',409,'Population: 153,000 (July 1985), average an-
nual growth rate 1.7%
Nationality: noun — New Caledonian(s); ad-
jective — New Caledonian
Ethnic divisions: Melanesian 42.5%, Euro-
pean 37,1%, Wallisian 8.4%, Polynesian
3.8%, Indonesian 3.6%, Vietnamese 1.6%
Religion: over 60% Roman Catholic, 30%
Protestant
Language: French; Melanesian-Polynesian
dialects
Literacy: unknown
Labor force: 50,469 (1980 est.); Javanese and
Tonkinese laborers were imported for plan-
tations and mines in pre-World War II
period; immigrant labor now coming from
Wallis Islands, New Hebrides, and French
Polynesia; est. 8% unemployment
Organized labor: labor not organized','b2e6eb847fe85bbfe1304f193ac628d6eb82839c46ba342fc35f90c6f3e50a06','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c027b439b6d8500f82d672198ae5f4fce7931cc109151a1a042e6f22dd18afba',1985,'NZ','New Zealand','people-and-society',413,'Population: 3,295,000 (July 1985), average
annual growth rate 1.4%
Nationality: noun — New Zealander(s); ad-
jective — New Zealand
Ethnic divisions: 87% European, 9% Maori,
2% Pacific Islander, 2% other
Religion: 81% Christian, 18% none or un-
specified, 1% Hindu, Confucian, and other
Language: English (official), Maori
Literacy: 98%
Labor force: 1,325,000(1981); 29.9% manu-
facturing, mining, and construction; 24.2%
commerce and finance; 21.2% services;
10.7% agriculture; 8.3% transportation and
communications; 2% other; unemployment
3.7% (February 1981)
Organized labor: 46% of labor force','32c54aa066ce262345be0f9d28a6e5061cb4c3ae2ac0c307370e76284d9b6d39','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00cdef1fe8044c7f70d54e990a0bcecb4aefe1b1bf0261d1b4c9b806c64b91b0',1985,'NI','Nicaragua','people-and-society',417,'Population: 3,038,000 (July 1985), average
annual growth rate 3.5%
Nationality: noun — Nicaraguan(s); adjec-
tive — Nicaraguan
Ethnic divisions: 69% mestizo, 17% white,
9% black, 5% Indian
Religion: 95% Roman Catholic
Language: Spanish (official); English- and
Indian-speaking minorities on Atlantic coast
Literacy: 66%
Labor force: 969,000(1983 est.); 40% agricul-
ture, 34% service, 26% industry, 3%
construction, 5% other; 25% unemployment
Organized labor: 35% of Nicaragua’s labor
force is organized; of the seven confedera-
tions, five are Sandinista or Marxist
oriented — the government-sponsored Sandi-
nista Workers’ Central (CST), 115,000
members, including state and municipal em-
ployees; the Association of Campesino
Workers (ATC), 130,000 members; the Gen-
eral Confederation of Independent Workers
(CGI-I), approximately 15,000 members; the
Workers Front, about 100 members; and the
Central for Labor Action and Unity (CAUS),
about 3,000 members; the other two unions
are the Nicaraguan Workers’ Central (CTN),
25,000 members, and the Confederation of
Labor Unification (CUS), 50,000 members','4705905bf1d4413ad60591c6aca706374ddecd0238ef9211cd20ae4aebb5e46f','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('278ecde9ad05dd71c881bd2a64ce570c9728dba608f661688a16cfcf5d6c6e7c',1985,'NE','Niger','people-and-society',421,'Population: 6,495,000 (July 1985), average
annual growth rate 3.3%
Nationality: noun — Niger ien(s) adjective —
Nigerien
Ethnic divisions: 56% Hausa; 22% Djerma;
8.5% Fula; 8% Tuareg; 4.3% Beri Beri
(Kanouri); 1.2% Arab, Toubou, and
Gourmantche; about 4,000 French expatri-
ates
Religion: 80% Muslim, remainder indige-
nous beliefs and Christians
Language: French (official); Hausa, Djerma
Literacy: 5%
Labor force: 2.5 million (1982) wage earners;
90% agriculture, 6% industry and commerce,
4% government
Organized labor: negligible','ce194f6ed452fe37000ef9a125c062a957e2f8dc4fe6a4456d8d8ca60bc15724','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9937f4ef39b7bfbeb06709fd913089d0f1918f18bb4ff86c57a449aef6ac0da4',1985,'NG','Nigeria','people-and-society',426,'Population: 91,178,000 (July 1985), average
annual growth rate 3.4%
Nationality: noun — Nigerian(s); adjective —
Nigerian
Ethnic divisions: of the more than 250 tribal
groups, the Hausa and Fulani of the north,
the Yoruba of the southwest, and the Ibos of
the southeast comprise 65% of the popula-
tion; about 27,000 non-Africans
Religion: no exact figures on religious break-
down, but last census (1963) showed Nigeria
to be 47% Muslim, 34% Christian, and 18%
indigenous beliefs
Language: English (official); Hausa, Yoruba,
and Ibo also widely used
Literacy: 25-30%
173
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Nigeria (continued)
Labor force: est, 35-40 million (1983); 55%
agriculture; 17% industry, commerce, and
services; 15% government
Organized labor: 3.52 million wage earners
belong to one of 42 recognized trade unions,
which are under a single national labor fed-
eration, the Nigerian Labor Congress (NLC)','25a5fae8deacf79105fbe1e79266d1624bcf601b01d6492f07befe23d949e9e0','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4e86254acc20865489beada29c144a4a4c40876d58bb41ba52b5cbe09b1dcb9',1985,'NO','Norway','people-and-society',428,'Population: 4,160,000 (July 1985), average
annual growth rate 0.4%
Nationality: noun — Norwegian(s); adjec-
tive — Norwegian
Ethnic divisions: Germanic (Nordic, Alpine,
Baltic) and racial-cultural minority of 20,000
Lapps
Religion: 94% Evangelical Lutheran (state
church), 4% other Protestant and Roman
Catholic, 2% other
Language: Norwegian (official); small Lapp-
and Finnish-speaking minorities
Literacy: 100%
Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Labor force: 2.024 million (1983); 30.9% ser-
vices; 19.6% mining and manufacturing;
16.7% commerce; 8.8% transportation; 7.6%
construction; 7.2% agriculture, forestry, fish-
ing; 5.7% banking and financial services;
3.3% unemployed
Organized labor: 60% of labor force','863532e2b422c3d4d3806c5c7fbe312d0ee41c7364fb14e6ae176121ca52c3f9','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a75c517b0ceeec27c3e0abb964feccd6204fe22ece2949287ea9c59299b078e',1985,'OM','Oman','people-and-society',433,'Population: 1,228, 000'' (July ! 985), average
annual growth rate 3.9%
Nationality: n6un^Orhani(s); adjective —
Omani *
Ethnic divisions: almost entirely Arab, with
small Baluchi, Zanzibari, and Indian groups
Religion: 75% Ibadhi Muslim; remainder
Sunni Muslim, Sh‘ia Muslim,'' some Hindu
Language: Arabic (official); English, Balu-
chi, Urdu, Indian dialects
Literacy: 20%
Labor force: 500,000; 50% are hon-Omani;
est. 60% agriculture','184a4dc779658ed2bceb456f5f5362d40c64ed162f3264188cc484976aab1838','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41e9b50ad6acf87a1d2586a125556271ac6599d46e04cec0036fc9ddfd1b1b13',1985,'PK','Pakistan','people-and-society',436,'Population: 99,199,000, excluding
Junagardh, Manavadar, Gilgit, Baltistan, and
the disputed area of Jammu and Kashmir
(July 1985); average annual growth rate 2.6%
Nationality: noun — Pakistani(s); adjective —
Pakistani
Ethnic divisions: Punjabi, Sindhi, Pushtan
(Pathan), Baluchi
Religion: 97% Muslim, 3% Christian, Hindu,
and other
Language: Urdu and English (official); total
spoken languages — 64% Punjabi, 12%
Sindhi, 8% Pushtu, 7% Urdu, 9% Baluchi and
other; English is lingua franca
Literacy: 24%
Labor force: 25.24 million (1982 est.); exten-
sive export of labor; 52% agriculture, 21%
industry, 8% services, 19% other
Organized labor: negligible','094e9d165b3ba020bc9d20c9db606ff936bedb46e7b3f523ddf598ad355ed224','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('784dc6b3a767c3dee1d095e6c4b7227cf8fa38b364e4b17cf07cc953e47b3726',1985,'PA','Panama','people-and-society',441,'Population: 2,038,000 (July 1985), average
annual growth rate 1.8%
Nationality: noun — Panamanian(s); adjec-
tive — Panamanian
Ethnic divisions: 70% mestizo, 14% West In-
dian, 10% white, 6% Indian
Religion: over 93% Roman Catholic, 6%
Protestant
Language: Spanish (official); 14% speak En-
glish as native tongue; many Panamanians
bilingual
Literacy: 90%
Labor force: est 625,000 (January 1982); 45%
commerce, finance, and services; 29% agri-
culture, hunting, and fishing; 10%
179
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Panama (continued)
manufacturing and mining; 5% construction;
5% transportation and communications; 4%
Canal Zone; 1.2% utilities; 2% other; unem-
ployed estimated at 20% (January 1984);
shortage of skilled labor but an oversupply of
unskilled labor
Organized labor: approximately 15% of la-
bor force (1982)','85aee251daedd8b16ace4ce6f7ac0df660ea6037f41acb22b1eb6fd56578b3ca','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87e4b0937242b483f35cfc7599af826ba0c44ebdb516e7a2770b2223c5bff11e',1985,'PG','Papua New Guinea','people-and-society',444,'Population: 3,326,000 (July 1985), average
annual growth rate 2.1%
Nationality: noun — Papua New Guinean(s);
adjective — Papua New Guinean
Ethnic divisions: predominantly Melanesian
and Papuan; some Negrito, Micronesian, and
Polynesian
Religion: over half of population nominally
Christian (490,000 Catholic, 320,000 Lu-
theran, other Protestant sects); remainder
indigenous beliefs
Language: 715 indigenous languages; pidgin
English in much of the country and Motu in
Papua region are linguae francae; English
spoken by 1-2% of population
Literacy: 32%
Labor force: 1.44 million (1979); 352,500
(1980) in salaried employment; 53% agricul-
ture, 20% government, 17% industry and
commerce, 10% services
Population: 3,722,000 (July 1985), average
annual growth rate 2.7%
Nationality: noun — Paraguayan(s); adjec-
tive — Paraguayan
Ethnic divisions: 95% mestizo (Spanish and
Indian), 5% white and Indian
Religion: 97% Roman Catholic; Mennonite
and other Protestant denominations
Language: Spanish (official) and Guarani
Literacy: 81%
Labor force: 1.1 million (1983 est.); 44% agri-
culture; 34% industry and commerce, 18%
services, 4% government; unemployment
rate 15% (1984)
Organized labor: about 5% of labor force','394f51ba3ce6e5e60d8370adb647a5bccdc3810c177339e65f374919e8f0267e','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce7584ccc51a9e2f0a65d5e580c04ac41bcfd8f63ca17bef4b76b053a157c743',1985,'PE','Peru','people-and-society',448,'Population: 19,532,000 (July 1985), average
annual growth rate 2.4%
Nationality: noun — Peruvian(s); adjective—
Peruvian
Ethnic divisions: 45% Indian; 37% mestizo ,
(white-Indian); 15% white; 3% black, Japa-
nese, Chinese, and other
Religion: predominantly Roman Catholic
Language: Spanish and Quechua (official),
Aymara
Literacy: est. 72%
Labor force: 5.6 million (1980); 41% govern-
ment and other services, 40% agriculture,
19% industry and mining; unemployment .
about 9% (1983 est.)
Organized labor: about 40% of salaried
workers (1983 est.)','0b8aaf494c89663dffc1a0deaf979d1551aed97fc77b3fb263d82f317e6b1fcb','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('273158091dc68356fbccfc248064cbc9d235a1822ad6c8863a1362ffc5e79c24',1985,'PH','Philippines','people-and-society',452,'Population: 56,808,000 (July 1985), average
annual growth rate 2.3%
Nationality: noun — Filipino(s); adjective —
Philippine
Ethnic divisions: 91.5% Christian Malay, 4%
Muslim Malay, 1.5% Chinese, 3% other
Religion: 83% Roman Catholic, 9% Protes-
tant, 5% Muslim, 3% Buddhist and other
Language: Pilipino (based on Tagalog) and
English (both official)
Literacy: about 88%
Labor force: 17.8 million (1982 est); 47% agri-
culture, 20% industry and commerce, 13.5%
services, 10% government, 9.5% other','62df8882b3365f3b53f20eaf18c0f7a333b10b98b3c2180b9a3e006c2c1780a1','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20e512b946ef28d54817729fe4f737ece964dfa357aefe4c6f3225241773309a',1985,'PL','Poland','people-and-society',456,'Population: 37,236,000 (July 1985), average
annual growth rate 0.9%
Nationality: noun — Pole(s); adjective —
Polish
Ethnic divisions: 98.7% Polish, 0.6% Ukrai-
nian, 0.5% Byelorussian, less than 0.05%
Jewish, 0.2% other
Religion: 95% Roman Catholic (about 75%
practicing), 5% Uniate, Greek Orthodox,
Protestant, and other
Language: Polish, no significant dialects
Literacy: 98%
Labor force: 19.3 million; 27% agriculture,
32% industry, 41% other nonagricultural
(1980)
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Organized labor: new government trade
unions formed following dissolution of Soli-
darity and all government unions in October
1982','90f8428bb780e49b02e28a1338974474c2dde98a633ccb7389564cd2a7c56710','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6d265b6881e64caad84951c3f877229109917d35bae632af14f56c95882b1ad',1985,'PT','Portugal','people-and-society',460,'Population: 10,045,000 (July 1985), includ-
ing the Azores and Madeira Islands; average
annual growth rate 0.5%
Nationality: noun — Portuguese (sing, and
pi.); adjective — Portuguese
Ethnic divisions: homogeneous Mediterra-
nean stock in mainland, Azores, Madeira
Islands; citizens of black African descent who
immigrated to mainland during decoloniza-
tion number less than 100,000
Religion: 97% Roman Catholic, 1% Protes-
tant sects, 2% other
Language: Portuguese
Literacy: 80%
Labor force: 4.6 million (1983); 37% services,
36% industry, 27% agriculture; unemploy-
ment, 10.2% (June 1984)
Organized labor: about 45% of Portuguese
labor is organized; the Communist-domi-
nated General Confederation of Portuguese
Workers— National Intersindical (CGTP-IN)
represents about half of the unionized labor
force; its main competition, the General
Workers Union (UGT), is organized by the
Socialists and Social Democrats and repre-
sents a little less than half of unionized labor','90f6d1bfdb1142b436abcd717db8ddfd882a186ddabd1c8156fad0b7142ef8b3','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd25f72ed49db4162281168ed51c9a1a50dd6c94cf001df8b179fff50fc128d3',1985,'QA','Qatar','people-and-society',465,'Population: 301,000 (July 1985), average an-
nual growth rate 3.4%
Nationality: noun — Oatari(s); adjective —
Qatari
Ethnic divisions: 40% Arab, 18% Pakistani,
18% Indian, 10% Iranian
Religion: 95% Muslim
Language: Arabic (official); English is com-
monly used as second language
Literacy: 40%
Labor force: 104,000(1983); 85% non-Qatari
in private sector
Population: 537,000 (July 1985), average an-
nual growth rate 1.1%
Nationality: noun — Reunionese (sing, and
pi.); adjective — Reunionese
Ethnic divisions: most of the population is of
thoroughly intermixed ancestry of French,
African, Malagasy, Chinese, Pakistani, and
Indian origin
Religion: 94% Roman Catholic
Language: French (official); Creole widely
used
Literacy: over 80% among younger genera-
tion
Labor force: primarily agricultural workers;
high seasonal unemployment','5eab240de2815974193c24d2274932acee7e0e2d0840299eed7868aa966a4a1d','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a939be9d7588e877ddc517c87cd51398d81c033b73638a2e5db237cee6b0541',1985,'RO','Romania','people-and-society',468,'Population: 22,772,000 (July 1985), average
annual growth rate 0.5%
Nationality: noun — Romanian(s); adjec-
tive — Romanian
Ethnic divisions: 88.1% Romanian; 7.9%
Hungarian; 1.6% German; 2.4% Ukrainian,
Serb, Croat, Russian, Turk, and Gypsy
Religion: 80% Romanian Orthodox; 6% Ro-
man Catholic; 4% Calvinist, Lutheran,
Jewish, Baptist, and other
Language: Romanian, Hungarian, German
Literacy: 98%
Labor force: 10.5 million (1983); 37.8% indus-
try, 29.2% agriculture, 33% other
nonagricultural (1983)','6f74f18ca1271a80537b9691aca1ad5870c4c89cda5827a44b7375a7dd02ce45','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('529040904a477d2ba075f930f4054db2ed9fee830b606701f1134a48ffc661ad',1985,'RW','Rwanda','people-and-society',472,'Population: 6,246,000 (July 1985), average
annual growth rate 3.7%
Nationality: noun — Rwandan(s); adjective —
Rwandan
Ethnic divisions: 85% Hutu, 14% Tutsi, 1%
Twa (Pygmoid)
Religion: 65% Catholic, 9% Protestant, 1%
Muslim, rest indigenous beliefs
Language: Kinyarwanda and French offi-
cial; Kiswahili used in commercial centers
Literacy: 37%
Labor force: 2.7 million (1983); 93% agricul-
ture, 3% industry and commerce, 3%
government, 1% services','9d32a14063000455ef17c36da5458052192c5cf2552305cae9ee3aebb76692e1','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2892848739afd698252483dd59e3461951cd7d6faf12973cd6a2f959e2b6d41b',1985,'SM','San Marino','people-and-society',478,'Population: 23,000 (July 1985), average an-
nual growth rate 1.6%
Nationality: noun — Sanmarinese (sing, and
pi.); adjective — Sanmarinese
Religion: Roman Catholic
Language: Italian
Literacy: 97%
Labor force: approx. 4,300
Organized labor: Democratic Federation of
Sanmarinese Workers (affiliated with
ICFTU) has about 1,800 members; Commu-
nist-dominated General Federation of
Labor, 1,400 members','fda0b19fe46e8601e7353885993efa9c3e6ab1ae06ab5ab2364f6a03371b0440','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1161dbce3b3189601e3fb3f14c14715bc1cf50ce28eaacad26cde8e550ef05fe',1985,'SA','Saudi Arabia','people-and-society',480,'Population: 11,152,000 (July 1985), average
annual growth rate 3.3%
Nationality: noun — Saudi(s); adjective —
Saudi Arabian or Saudi
Ethnic divisions: 90% Arab, 10% Afro- Asian
Religion: 100% Muslim
Language: Arabic
Literacy: 52%
Labor force: about one-third (one-half for-
eign) of population; 45% commerce, services,
government, and other; 30% agriculture; 15%
construction; 5% industry; 5% oil and mining
Population: 21,733,000 (July 1985), average
annual growth rate 3.2%
Nationality: noun — Tanzanian(s); adjec-
tive — Tanzanian
Ethnic divisions: mainland — 99% native Af-
rican consisting of well over 100 tribes; 1%
Asian, European, and Arab*; Zanzibar —
almost all Arab
Religion: mainland— 33% Christian, 33%
Muslim, 33% indigenous beliefs; Zanzibar —
almost all Muslim
Language: Swahili and English (official); En-
glish primary language of commerce,
administration, and higher education; Swa-
hili widely understood and generally used for
communication between ethnic groups; first
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
language of most people is one of the local
languages; primary education is generally in
Swahili
Literacy: 79%
Labor force: 208,680 in paid employment
(1983); 90% agriculture, 10% industry and
commerce
Organized labor: 15% of labor force','217f5ac9e4cda0e71a48756ba80b8a980d3bd523fd7ccd5ac7a5ae78ed20f9bf','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82ea26b8e89d0a72e0080ccfb71025170bbd68e06b6deb5dea94b76f26e5bd05',1985,'SN','Senegal','people-and-society',483,'Population: 6,755,000 (July 1985), average
annual growth rate 3.2%
Nationality: noun — Senegalese (sing, and
pi.); adjective — Senegalese
Ethnic divisions: 36% Wolof, 17.5% Fulani,
16.5% Serer, 9% Toucouleur, 9% Diola, 6.5%
Mandingo, 4.5% other African, 1% European
and Lebanese
Religion: 92% Muslim, 6% indigenous be-
liefs, 2% Christian (mostly Roman Catholic)
Language: French (official); Wolof, Pulaar,
Diola, Mandingo
Literacy: 10%
Labor force: 1,732,000; 70% subsistence agri-
cultural workers; 175,000 wage earners —
40% private sector, 60% government and
parapubiic
201
Organized labor: majority of wage- labor
force represented by unions; however, dues-
paying membership very limited; major
confederation is National Confederation of
Senegalese Labor (CNTS), an affiliate of gov-
erning party
Population: 66,000 (July 1985), average an-
nual growth rate 0.9%
Nationality: noun — Seychellois (sing, and
pi.); adjective — Seychelles
Ethnic divisions: Seychellois (mixture of
Asians, Africans, Europeans)
Religion: 90% Roman Catholic, 8% Anglican,
2% other
Language: English and French (official);
Creole
Literacy: 60%
Labor force: 15,000 in monetized sector (ex-
cluding self-employed, domestic servants,
and workers on small farms); 49% govern-
ment, 19% industry and commerce, 18.5%
agriculture, 13.5% services
202
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Organized labor: 3 major trade unions','19fd1112be5b4ed401c64c0476479720bc20ecc7ca3a98a684eab219b7bfd887','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a21378598c27028ccf4bf2376aa7a4f60db255255b7889bf224ba6c1d6b777c',1985,'SL','Sierra Leone','people-and-society',487,'Population: 3,883,000 (July 1985), average
annual growth rate 2.6%
Nationality: noun — Sierra Leonean(s); adjec-
tive — Sierra Leonean
Ethnic divisions: over 99% native African
(30% Temne, 30% Mende, 2% Creole), rest
European and Asian; 13 tribes
Religion: 60% Muslim, 30% indigenous be-
liefs, 10% Christian
Language: English (official); regular use lim-
ited to literate minority; principal
vernaculars are Mende in south and Temne
in north; “Krio,” the language of the resettled
exslave population of the Freetown area, is
used as a lingua franca
Literacy: about 15%
Labor force: about 1.5 million; most of popu-
lation engages in subsistence agriculture;
only small minority, some 65,000, earn wages
Organized labor: 35% of wage earners','8d327a8d0b38a125d7caba1eb5ac62ce021b089d60e1e36e657b7eb78d59950a','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('999223425cdc92bc494c32d26546eb83142a0cee2116ba72b6ca6130303ac0ea',1985,'SG','Singapore','people-and-society',491,'Population: 2,562,000 (July 1985), average
annual growth rate 1.2%
Nationality: noun — Singaporean(s), adjec-
tive — Singapore
Ethnic divisions: 76.7% Chinese, 14.7% Ma-
lay, 6.4% Indian, 2.2% other
Religion: majority of Chinese are Buddhists
or atheists; Malays nearly all Muslim; minor-
ities include Christians, Hindus, Sikhs,
Taoists, Confucianists
Language: Chinese, Malay, Tamil, and En-
glish (official); Malay (national)
Literacy: 84.2%
Labor force: 1,142,374 (June 1982); 29.5%
manufacturing, 28.5% services, 22.3% trade,
11.4% transport and communication, 6.3%
construction, 1.0% agriculture and fishing,
1.0% other
Organized labor: 18.6% of labor force','d05dcb3f5fa838655ce02b8802581c0ba9eed4788ffd3875e40a3617e15ea240','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9322ba4ac5e22f0e5dc2332d948c87203d94e223ec257eed6bd2a66c3bd61860',1985,'SB','Solomon Islands','people-and-society',494,'Population: 273,000 (July 1985), average an-
nual growth rate 3.7%
Nationality: noun — Solomon Islander(s); ad-
jective — Solomon Islander
Budget: (FY83/84) revenues, $4.7 billion; ex-
penditures, $7.5 billion; deficit, $2.8 billion
Monetary conversion rate: 2.20 Singapore
dollars=US$l (8 January 1985)
Fiscal year: 1 Aprii-31 March','a6b65edcfca965df14c958a2e57728dd891ef74e687b20974245b18de4b608be','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5578a59976868d0c450bb4fba79f7406329efa72d0f4a73a54392d2ac0a11116',1985,'SO','Somalia','people-and-society',498,'Population: 7,595,000 (July 1985), average
annual growth rate 3.0%
Nationality: noun — Somali(s); adjective —
Somali
Ethnic divisions: 85% Somali, rest mainly
Bantu; 30,000 Arabs, 3,000 Europeans, 800
Asians
Religion: almost entirely Sunni Muslim
Language: Somali (official); Arabic, Italian,
English
Literacy: 60%
Labor force: about 2.2 million; very few are
skilled laborers; 70% pastoral nomad, 30% ag-
riculturists, government employees, traders,
fishermen, handicraftsmen, other
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Somalia (continued)
Organized labor: General Federation of So-
mali Trade Unions, a government-controlled
organization, established in 1977','ab86f32ae36cfa1f7d8b6f99f8341cc865ad8f3c28f725bea2d9e828b1a47eed','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc9ec7f916b0e1d527f05a4832722e5b685ef5aaa65b9b7aabede65ff1678f04',1985,'ZA','South Africa','people-and-society',501,'Population: 32,465,000 (July 1985), includ-
ing Bophuthatswana, Ciskei, Kwazulu,
Lebowa, Transkei, and Venda; average an-
nual growth rate 2.4%; Bophuthatswana
1 ,623,000 (J uly 1985), average annual growth
rate 3,9%; Ciskei 763,000 (July 1985), average
annual growth rate 2.3%; Kwazulu 4,347,000
(July 1985), average annual growth rate 4.6%;
Lebowa 2,208,000 (July 1985), average an-
nual growth rate 4.5%; Transkei 2,960,000
(July 1985), average annual growth rate 3.4%;
Venda 412,000 (July 1985), average annual
growth rate 2.7%
Nationality: noun — South African(s); adjec-
tive — South African
Ethnic divisions: 69.9% African, 17.8%
white, 9.4% Colored, 2.9% Indian
Religion: most whites and Coloreds and
roughly 60% of Africans are Christian;
roughly 60% of Indians are Hindu, 20% Mus-
lim
Language: Afrikaans, English (official); Afri-
cans have many vernacular languages,
including Zulu, Xhosa, North and South So-
tho, Tswana
Literacy: a\\mos[ all white population literate;
government estimates 50% of Africans liter-
ate
Labor force: 8.7 million economically active
(1980); 53% agriculture, 27% miscellaneous
services, 8% manufacturing, 7% mining, 5%
commerce
Organized labor: about 7% of total labor
force is unionized (mostly white workers); Af-
rican unions represent less than 15% of black
labor force
Population: 277,930,000 (July 1985), average
annual growth rate 1.0%
Nationality: noun — Soviet(s); adjective — So-
viet
Ethnic divisions: 52% Russian, 16% Ukrai-
nian, 32% among over 100 other ethnic
groups, according to 1979 census
Religion: 18% Russian Orthodox; 9% Muslim;
3% Jewish, Protestant, Georgian Orthodox, or
Roman Catholic; population is 70% atheist
Language: Russian (official); more than 200
languages and dialects (at least 18 with more
than 1 million speakers); 75% Slavic group.
210
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
8% other Indo-European, 12% Altaic, 3%
Uralian, 2% Caucasian
Literacy: 99.8%
Labor force: civilian 147 million (midyear
1982), 20% agriculture, 80% industry and
other nonagricultural fields; unemployed not
reported; shortage of skilled labor reported','fbc23c1fc44bb83d601c2d60c89d64c5731d33b7a0b296f08d24c901bfcf7424','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43e6fe4e4bb9ccc3e6dae5c62478ad936afb7e7c496d1aaceff18341efc9404e',1985,'ES','Spain','people-and-society',504,'Population: 38,629,000 (July 1985), includ-
ing the Balearic and Canary Islands and
Ceuta and Melilla (two towns on the Moroc-
can coast); average annual growth rate 0.5%
Nationality: noun — Spaniard(s); adjective —
Spanish
Ethnic divisions: composite of Mediterra-
nean and Nordic types
Religion: 99% Roman Catholic, 1% other
sects
Language: Castilian Spanish; second lan-
guages include 17% Catalan, 7% Galician, .
and 2% Basque
Literacy: 97%
Labor force: 13.2 million (1984); 43% ser-
vices, 24% industry, 16% agriculture, 9%
construction; unemployrnent now estimated
at nearly 20.5% of labor force (September
1984)
Organized labor: labor unions legalized April
1977; represent no more than a quarter of the
labor force (1983)
Population: 16,206,000 (July 1985), average
annual growth rate 1.8%
Nationality: noun— Sri Lankan(s); adjec-
tive — Sri Lankan
Ethnic divisions: 74% Sinhalese; 18% Tamil;
7% Moor; 1% Burgher, Malay, and Veddoh
Religion: 69% Buddhist, 15% Hindu, 8%
Christian, 8% Muslim, 0.1% other
Language: Sinhala (official); Sinhala and
Tamil listed as national languages; Sinhala
spoken by about 74% of population; Tamil
spoken by about 18%; English commonly
used in government and spoken by about 10%
of the population
Literacy: 87%
Labor force: 4 million; 15% unemployed;
employed persons — 45.9% agriculture,
13.3% mining and manufacturing, 12.4%
214
trade and transport, 26.3% services and
other; extensive underemployment
Organized labor: about 33% of labor force,
over 50% of which employed on tea, rubber,
and coconut estates','82ef216b76b02f15d52f0cf8c19cafa634659d1291ed2497eabcef9b506e6203','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('465007273e85fe8d278de10b5b9ac0f8c82e2f2c41e14438e489fbc20f7e9044',1985,'SD','Sudan','people-and-society',507,'Population: 21,761,000 (July 1985), average
annual growth rate 2.7%
Nationality: noun — Sudanese (sing, and pi.);
adjective — Sudanese
Ethnic divisions: 52% black, 39% Arab, 6%
Beja, 2% foreigners, 1% other
Religion: 70% Sunni Muslim in north, 20%
indigenous beliefs, 5% Christian (mostly in
south)
Language: Arabic (official), Nubian, Ta
Bedawie, diverse dialects of Nilotic, Nilo-
Hamitic, and Sudanic languages, English;
program of Arabization in process
Literacy: 20%
Labor force: 8.6 million (1979); roughly 78%
agriculture, 12% services, 10% industry; la-
bor shortages for almost all categories of
employment coexist with urban unemploy-
ment','cd43531cc44f8f6f8bbed2ae377da7f3b122789972e58929d34d6eae447d2713','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ded5af1dd2ebd43725c21f4aa1fb466775a3fd938e769857b71c5df614eb2f4b',1985,'SR','Suriname','people-and-society',511,'Population: 377,000 (July 1985), average an-
nual growth rate 1.8%
Nationality: noun — Surinamer(s); adjec-
tive — Surinamese
Ethnic divisions: 37% Hindustani (East In-
dian), 31% Creole (black and mixed), 15.3%
Javanese, 10.3% Bush Negro, 2.6% Amerin-
dian, 1.7% Chinese, 1.0% Europeans, 1.7%
other
Religion: Hindu, Muslim, Roman Catholic,
Moravian, other
Language: Dutch (official); English widely
spoken; Sranang Tongo (Surinamese, some-
times called Taki-Taki) is native language of
Creoles and much of the younger population
and is lingua franca among others; Hindi; Ja-
vanese
217
Literacy: 65%
Labor force: 100,000; unemployment 20%
(1983)
Organized labor: approx. 33% of labor force
Population: 671,000 (July 1985), average an-
nual growth rate 3.0%
Nationality: noun — Swazi(s); adjective —
Swazi
Ethnic divisions: 96% African, 3% European,
1% mulatto
Religion: 57% Christian, 43% indigenous be-
liefs
Language: English and siSwati (official); gov-
ernment business conducted in English
Literacy: 65%
Labor force: 195,000; over 60,000 engaged in
subsistence agriculture; 55,000-60,000 wage
earners, many only intermittently, with 36%
agriculture and forestry, 20% community
and social services, 14% manufacturing, 9%
construction, 21% other; 12,000 employed in
South Africa (1982)
Organized labor: about 15% of wage earners
are unionized','f468184fb4e43a0e0dbef02813401c9a5f13535721d395df0639410df02f2f53','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eae1c7b4ff64f0e67681083a16b3f3bc8d3625d14377d867734d5dc4b79538c1',1985,'SE','Sweden','people-and-society',515,'Population: 8,338,000 (July 1985), average
annual growth rate 0%
Nationality: noun — Swede(s); adjective —
Swedish
Ethnic divisions: homogeneous white popu-
lation; small Lappish minority; est. 12%
foreign born or first generation immigrants
(Finns, Yugoslavs, Danes, Norwegians,
Greeks)
Religion: 93.5% Evangelical Lutheran, 1.0%
Roman Catholic, 5.5% other
Language: Swedish, small Lapp- and Finn-
ish-speaking minorities; immigrants speak
native languages
Literacy: 99%
Labor force: 4.35 million; 31% private ser-
vices; 30.6% government services; 21.9%
mining and manufacturing; 7.2% construc-
tion; 5.2% agriculture, forestry, and fishing;
0.9% electricity, gas, and waterworks;, 3.5%
unemployed (1983 average)
Organized labor: 80% of labor force','73f93a1238616ec761aeac2d51af8b7979a0216c944111c7018d2ee8b359acb6','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75f499b1dcc0cf8ceeb93556b91b512280d3d448392959494e29c400d2ba8fd8',1985,'CH','Switzerland','people-and-society',520,'Population: 6,512,000 (July 1985), average
annual growth rate 0.2%
Nationality: noun — Swiss (sing. & pi.); adjec-
tive — Swiss
Ethnic divisions: total population — 65%
German, 18% French, 10% Italian, 1% Ro-
mansch, 5% other; Swiss nationals — 74%
German, 20% French, 4% Italian, 1% Ro-
mansch, 1% other
Religion: 49% Catholic, 48% Protestant, 0.3%
Jewish
Language: total population — 65% German,
18% French, 12% Italian, 1% Romansch, 4%
other; Swiss nationals — 74% German, 20%
French, 4% Italian, 1% Romansch, 1% other
Literacy: 99%
Labor force: 3.05 million, about 706,000 for-
eign workers, mostly Italian; 42% services,
39% industry and crafts, 11% government,
7% agriculture and forestry, 1% other; ap-
proximately 0.8% unemployed in October
1983
221
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Switzerland (continued)
Organized labor: 20% of labor force
Population: 10,535,000 (July 1985), average
annual growth rate 3.7%
Nationality: noun — Syrian(s); adjective —
Syrian
Ethnic divisions: 90.3% Arab; 9.7% Kurds,
Armenians, and other
Religion: 74% Sunni Muslim; 16% Alawite,
Druze, and other Muslim sects; 10% Chris-
tian (various sects)
Language: Arabic (official), Kurdish, Arme-
nian, Aramaic, Circassian; French and
English widely understood
Literacy: about 50%
Labor force: 2.3 million; 37% miscellaneous
services, 32% agriculture, 31% industry
223
(including construction); majority unskilled;
shortage of skilled labor
Organized labor: 5% of labor force','689ef8aa0a7e75d0ab1d5aa80e306e98e94338756fbbc09b9f78fac78f21802c','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebea902289c554f2f4bdfc97eb7f9c7ba4e5262bc7ab18397339b4eaeb312bbf',1985,'TH','Thailand','people-and-society',522,'Population: 52,700,000 (July 1985), average
annual growth rate 1.9%
Nationality: noun — Thai (sing, and pi.); ad-
jective — Thai
Ethnic divisions: 75% Thai, 14% Chinese,
11% other
Religion: 95.5% Buddhist, 4% Muslim, 0,5%
other
Language: Thai; English secondary language
of elite; ethnic and regional dialects
Literacy: 84%
Labor force: 23.4 million (1981 est.); 76% ag-
riculture, 9% industry and commerce, 9%
services, 6% government','81db4752f489a336fe448a7f50ac722429156e420d905f4e638566ed697ce720','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa42e1a2fdb0d1a947ae5768798878f8353a7e4609f6c5d2cb54a91ac7876083',1985,'TG','Togo','people-and-society',525,'Population: 3,018,000 (July 1985), average
annual growth rate 3.1%
Nationality: noun — Togolese (sing, and pi,);
adjective — Togolese
Ethnic divisions: 37 tribes; largest and most
important are Ewe, Mina, and Kabye; under
1% European and Syrian-Lebanese
Religion: about 70% indigenous beliefs, 20%
Christian, 10% Muslim
Language: French, both official and lan-
guage of commerce; major African languages
are Ewe and Mina in the south and Dagomba
and Kabye in the north
Literacy: 18%
Labor force: 78% agriculture, 22% industry;
about 88,600 wage earners, evenly divided
between public and private sectors
227
Organized labor: one national union, the Na-
tional Federation of Togolese Workers','3f16f392d7f5090f3ef0d28095af8448d2008b723d30eb0d51beefa997d1a6b7','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23123cf7e203c14163256f571fbdf85aac0a3ebd18609fdfe1e6890d379568f6',1985,'TO','Tonga','people-and-society',529,'Population: 107,000 (July 1985), average an-
nual growth rate 1.9%
Nationality: noun — Tongan(s); adjective —
Tongan
Ethnic divisions: Polynesian; about 300 Eu-
ropeans
Religion: Christian; Free Wesleyan Church
claims over 30,000 adherents
Language: Tongan, English
Literacy: 90-95%; compulsory education for
children ages 6-14
Labor force: agriculture 10,300; mining 600','a7e0907daf96842f75e2afeff993aaf5413994854286aaa4d2d3b98bddd332ae','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5a033050062daf6471eb195b109e1c0c84ec0f6ad63474404f8e76e92ce59d6',1985,'TT','Trinidad and Tobago','people-and-society',534,'Population: 1,185,000 (July 1985), average
annual growth rate 1.5%
Nationality: noun — Trinidadian(s),
Tobagan(s); adjective — Trinidadian,
Tobagan
Ethnic divisions: 43% black, 40% East In-
dian, 14% mixed, 1% white, 1% Chinese, 1%
other
Religion: 36.2% Roman Catholic, 23%
Hindu, 13.1% Protestant, 6% Muslim, 21.7%
unknown
Language: English (official), Hindi, French,
Spanish
Literacy: 95%
Labor force: about 473,000 (est. 1979-81);
23.0% service; 20.0% mining, quarrying, and
manufacturing; 17.4% commerce; 15.7%
229
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
(continued)
construction and utilities; 13.5% agriculture;
7.5% transportation and communication;
2.9% other
Organized labor: 30% of labor force','88f47e0c31fae697a09092477edeb7ef3a708cb62fd195ef4b11e97798c90272','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b0404ddfcc33bbc70281e9e94ee871734ad3d55f823eddb1e3d99fe169e7ee6',1985,'TN','Tunisia','people-and-society',536,'Population: 7,352,000 (July 1985), average
annual growth rate 2.4%
Nationality: noun — Tunisian(s); adjective —
Tunisian
Ethnic divisions: 98% Arab, 1% European,
less than 1% Jewish
Religion: 98% Muslim, 1% Christian, less
than 1% Jewish
Language: Arabic (official); Arabic and
French (commerce)
Literacy: about 62%
Labor force: 1.9 million, 32% agriculture;
15%-25% unemployed; shortage of skilled
labor
Organized labor: about 360,000 members
claimed, roughly 20% of labor force; General
Union of Tunisian Workers (UGTT), quasi-
independent of Destourian Socialist Party','517c1cfc7def9e21470a6d98a9f7a4a920f0be8bf9cd9a923905d664a32fc0a6','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5515dff655f0b5a53e64ea806c017d4a20f74c2a01e6f36cb0d4f44811ae808f',1985,'TC','Turks and Caicos Islands','people-and-society',542,'Population: 7,436 (1980)
Ethnic division: majority of African descent
Religion: Anglican, Roman Catholic, Baptist,
Methodist, Church of God, Seventh-day Ad-
ventist
Language: English (official)
Literacy: about 99%
Labor force: some subsistence agriculture;
majority engaged in fishing and tourist indus-
tries
Organized labor: St. George s Industrial
Trade Union (Cockburn Harbor), 250 mem-
bers','8a1abdc0890b7ccf3976910655e20efdeea6e992cb72b410618004149a53e92b','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ce95838ec5a7dc9ad55bec98279abe3c2641d9201ae1c4b6a4e916fde199859',1985,'TV','Tuvalu','people-and-society',544,'Population: 8,000 (July 1985), average an-
nual growth rate 1.7%
Nationality: noun — Tuvaluans(s); adjec-
tive — Tuvaluan
Ethnic divisions: 96% Polynesian
Religion: Christian, predominantly Protes-
tant
234
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7','4d39315524fa091e56c1f0f97a5c8c3ba83be033f6c8ea9ad2e19318291b0fe8','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb1f90aadc59cdafb427f606a9c098d7973388c67ed1723510e865c0ec29b4c2',1985,'UG','Uganda','people-and-society',545,'Language: Tuvaluan, English
Literacy: less than 50%
Population: 14,733,000 (July 1985), average
annual growth rate 3.2%
Nationality: noun — Ugandan(s); adjective —
Ugandan
Ethnic divisions: 99% African, 1% European,
Asian, Arab
Religion: 33% Roman Catholic, 33% Protes-
tant, 16% Muslim, rest indigenous beliefs
Language: English (official); Luganda and
Swahili widely used; other Bantu and Nilotic
languages
Literacy: 52%
Labor force: estimated 4.5 million; about
250,000 in paid labor; remainder in subsis-
tence activities
Organized labor: 125,000 union members','4764907fc2ba08ea00c574e52c85ae124350da50eb93f841e85e79d719c89248','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('957cf0ac5e78be3a26640634c968125a5d1ace529be63f199a7faa7561c9c0fa',1985,'AE','United Arab Emirates','people-and-society',550,'Population: 1,320,000 (July 1985), average
annual growth rate 4.4%
Nationality: Noun — Emirian(s), adjective —
Emirian
Ethnic divisions: Emirian 19%, other Arab
23%, South Asian 50% (fluctuating), other ex-
patriates (includes Westerners and East
Asians) 8%; fewer than 20% of the population
are UAE citizens (1982)
Religion: Muslim 96%; Christian, Hindu, and
other 4%
Language: Arabic (official); Farsi and En-
glish widely spoken in major cities; Hindi,
Urdu
Literacy: 56.3% est.
Labor force: 541,000(1980 est.); 85% indus-
try and commerce, 5% agriculture, 5%
services, 5% government; 80% of labor force
is foreign','843d3ab43e62f8d8e01c1da7bbba071e7ec39a855ab78931f777d58fd88b17b3','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10a6a708563967f39b7b40c579dc3d80c70b93ef27c8497bfe54046b7b0fda2b',1985,'US','United States','people-and-society',554,'Population: 238,848,000 (July 1985), average
annual growth rate 0.9%
Ethnic divisions: 80% white; 1 1 % black; 6.2%
Spanish origin; 1.6% Asian and Pacific Is-
lander; 0.7% American Indian, Eskimo, and
Aleut (1980)
Religion: total membership in religious bod-
ies 134.8 million; Protestant 73.479 million,
Roman Catholic 50.45 million, Jewish 5.92
million, other religions 4.968 million (1982)
Language: predominantly English; sizable
Spanish-speaking minority
Literacy: 99.5% of total population 15 years
or older
Labor force: 115.786 million (includes 2.208
million members of the armed forces in the
US); unemployment rate 7.2% (1985); 10.411
million unemployed (January 1984)
Organized labor: approximately 17.4 million
members; 18.8% of civilian labor force (1984)','e38335a8af1c8b5ac5c0f3d8f4a1e708a82af055339a2ea7d4ebfbb6b35bd954','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c9abb52b37bae8cddb71ef7ec4387efbba87bb2c945c6a8e5c809f7863baf64',1985,'UY','Uruguay','people-and-society',559,'Population: 2,936,000 (July 1985), average
annual growth rate 0.3%
Nationality: noun — Uruguayan(s); adjec-
tive — Uruguayan
Ethnic divisions: 85-90% white, 5-10% mes-
tizo, 3-5 black
Religion: 66% Roman Catholic (less than half
adult population attends church regularly),
2% Protestant, 2% Jewish, 30% nonprofessing
or other
Language: Spanish
Literacy: 94.3%
Labor force: about 1.28 million (1981); 19%
manufacturing; 19% government; 16% agri-
culture; 12% commerce; 12% utilities,
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Uruguay (continued)
construction, transport, and communica-
tions; 22% other services; unemployment
more than 15% (1984 est.)
Organized labor: government authorized
non-Communist union activities in 1981 for
the first time since 1973 military takeover','df87b74b1e70bff3f581e451bc771042b8a8b6bd346e949dffd9156b22f5d872','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f56320450c8e235507a652517d13f431242514cf3b2ce710529543cda002940',1985,'VU','Vanuatu','people-and-society',562,'Population: 134,000 (July 1985), average an-
nual grow^th rate 2.7%
Nationality: noun — Vanuatuan(s); adjec-
tive — Vanuatuan
Ethnic divisions: 90% indigenous Melane-
sian; 8% French; remainder Vietnamese,
Chinese, and various Pacific Islanders
Religion: most at least nominally Christian
Language: English and French (official); pid-
gin (known as Bislama or Bichelama)
Literacy: probably 10-20%
Population: 1,000 (July 1985), average an-
nual growth rate 0.1%
Ethnic divisions: primarily Italians but also
many other nationalities
Religion: Roman Catholic
Language: Italian, Latin, and various other
languages
Literacy: 100%
Labor force: approx. 700; Vatican City em-
ployees divided into three categories —
executives, office workers, and salaried em-
ployees
Organized labor: none
Population: 17,810,000 (July 1985), average
annual growth rate 3%
Nationality: noun — Venezuelan(s); adjec-
tive — Venezuelan
Ethnic divisions: 67% mestizo, 21% white,
10% black, 2% Indian
Religion: 96% nominally Roman Catholic,
2% Protestant
Language: Spanish (official); Indian dialects
spoken by about 200,000 Amerindians in the
remote interior
Literacy: 85.6%
Labor force: 5.5 million (1984); 27% services;
22% commerce; 16% agriculture; 16% manu-
facturing; 9% construction; 7% transporta-
tion; 3% petroleum, utilities, and other
Organized labor: 32% of labor force
Population: 60,492,000 (July 1985), average
annual growth rate 2.4%
Nationality: noun — Vietnamese (sing, and
pi.); adjective — Vietnamese
Ethnic divisions: 85-90% predominantly
Vietnamese; 3% Chinese; ethnic minorities
include Muong, Thai, Meo, Khmer, Man,
Cham; other mountain tribes
Religion: Buddhist, Confucian, Taoist, Ro-
man Catholic, indigenous beliefs, Islamic,
and Protestant
Language: Vietnamese (official), French,
Chinese, English, Khmer, tribal languages
(Mon-Khmer and Malayo-Polynesian)
Literacy: 78%
Labor force: approximately 29 million, not
including military','84ab6235f5d53825a26941097e29808407273454ed1f400d5d047db695ecf40c','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a4740de6f58f2014a1a639ff2f1c0c0bb3b50407b90fbf7b8d15b47f78fe755',1985,'WF','Wallis and Futuna','people-and-society',567,'Population: 12,000 (July 1985) average an-
nual growth rate 2.5%
Nationality: noun — Wallisian(s), Futunan(s),
or Wallis and Futuna Islanders; adjective —
Wallisian, Futunan, or Wallis and Futuna Is-
lander
Ethnic divisions: almost entirely Polynesian
Religion: largely Roman Catholic','030c4c41ff5d3570263437e9ce57d8c4b1c4a30c9c76e1a39471b9618abd4dd0','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16aab78fc06ab77b2dbc5a49ad51e6206307b7a31fa285324b0c4acaebb35482',1985,'EH','Western Sahara','people-and-society',570,'Population: 91,000 (July 1985), average an-
nual growth rate 1.8%
Nationality: noun — Saharan(s), Moroccan(s);
adjective — Saharan, Moroccan
Ethnic divisions: Arab and Berber
Religion: Muslim
Language: Hassaniya Arabic, Moroccan Ar-
abic
Literacy: among Moroccans, probably nearly
20%; among Saharans, perhaps 5%
Labor force: 12,000; 50% animal husbandry
and subsistence farming, 50% other
Organized labor: none
Population: 163,000 (July 1985), average an-
nual growth rate 0.9%
Nationality: noun — V/estern Samoan(s); ad-
jective — Western Sam oa
Ethnic divisions: Samoan; about 12,000
Euronesians (persons of European and Poly-
nesian blood), 700 Europeans
Religion: 99.7% Christian (about half of
population associated with the London Mis-
sionary Society; includes Congregational,
Roman Catholic, Methodist, Latter Day
Saints, Seventh Day Adventist)
Language: Samoan (Polynesian), English
Literacy: 90%
Labor force: about 37,000 (1983); about
22,000 employed in agriculture
249
Organized labor: none
Population: 6,058,000 (July 1985), average
annual growth rate 2.7%
Nationality: noun — Yemeni(s); adjective —
Yemeni
Ethnic divisions: 90% Arab, 10% Afro-Arab
(mixed)
Religion: 100% Muslim (Sunni and Shi‘a)
Language: Arabic
Literacy: 15% (est.)
Labor force: approximately one-third ex-
patriate laborers; remainder almost entirely
agriculture and herding','8f3b2d7b2719a5d92bd1eded95d0a815c8ccb2aa42f6dd54fe77d8400f6ffdb8','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3a29206aa93b789002080024fce827b1e9e25da4db8f7709aded1bfe6858360',1985,'YE','Yemen','people-and-society',574,'Population: 2,211,000, excluding the islands
of Perim and Kamaran, for which no data are
available (July 1985); average annual growth
rate 2.9%
Nationality: noun — Yemeni(s); adjective —
Yemeni
Ethnic divisions: almost all Arabs; a few Indi-
ans, Somalis, and Europeans
Religion: Sunni Muslim, some Christian and
Hindu
Language: Arabic
Literacy: 25%
Population: 23,137,000 (July 1985), average
annual growth rate —0.7%
Nationality: noun — Yugoslav(s); adjective —
Yugoslav
Ethnic divisions: 36.2% Serb, 19.7% Croat,
8.9% Muslim, 7.8% Slovene, 7.7% Albanian,
5.9% Macedonian, 5.4% Yugoslav, 2.5% Mon-
tenegrin, 1.9% Hungarian, 4.0% other (1981
census)
Religion: 41% Serbian Orthodox, 32% Ro-
man Catholic, 12% Muslim, 3% other, 12%
none (1953 census; later information unavail-
able)
Language: Serbo-Croatian, Slovene, Mac-
edonian (all official); Albanian, Hungarian,
Italian
Literacy: 85%
252
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Labor force: 9.7 million (1983); 29% agricul-
ture, 24% mining and manufacturing, 11%
noneconornic activities; (est.) unemployment
about 15% of domestic labor force
Population: 32,985,000 (July 1985), average
annual growth rate 2.9%
Nationality: noun — Zairian(s); adjective —
Zairian
Ethnic divisions: over 200 African ethnic
groups, the majority are Bantu; four largest
tribes — Mongo, Luba, Kongo (all Bantu), and
the Mangbetu-Azande (Hamitic) make up
about 45% of the population
Religion: 50% Roman Catholic, 20% Protes-
tant, 10% Kimbanguist, 10% Muslim, 10%
other syncretic sects and traditional beliefs
Language: French (official), English, Lin-
gala, Swahili, Kingwana, Kikongo, and
Tshiluba
Literacy: 40% males, 15% females
Labor force: about 8 million, but only about
13% in wage structure
254','8ab37092c4007ed8e39b2ae31a2cd624d0943a8a009a65b978c734fce80eed2d','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28c07cff68f52546165fb59ae0c4f1b51951f1cdc173017bc68b12d1fb6022ab',1985,'ZM','Zambia','people-and-society',580,'Population: 6,770,000 (July 1985), average
annual growth rate 3.2%
Nationality: noun — Zambian(s); adjective —
Zambian
Ethnic divisions: 98.7% African, 1.1% Euro-
pean, 0.2% other
Religion: 50-75% Christian, 1% Muslim and
Hindu, remainder indigenous beliefs
Language: English (official); about 70 indige-
nous languages
Literacy: 54%
Labor force: 402,000 wage earners; 375,000
Africans, 27,000 non- Africans; 23% govern-
ment and miscellaneous services, 19%
construction, 15% mining, 10% manufactur-
ing, 9% agriculture, 9% domestic service, 9%
commerce, 6% transport
Organized labor: approximately 238,000
wage earners are unionized
255
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Approved For Release 2009/09/03 : CIA-RDP90T01298R000200050001-7
Zambia (continued)','b5eed4e16f664a50c0c9860ec7a610ed1334f67bd959924ae87af933d6b5546f','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b8d17f153f2fccd69047ddabf5c8221c505c721da56e3668afc6a93e49e9edc',1985,'ZW','Zimbabwe','people-and-society',582,'Population: 8,667,000 (July 1985), average
annual growth rate 3.3%
Nationality: noun — Zimbabwean(s); adjec-
tive — Zimbabwean
Ethnic divisions: about 97% African (over
77% members of Shona-speaking subtribes,
19% speak Ndebele); about 3% white, 1%
mixed and Asian
Religion: 50% syncretic (part Christian, part
indigenous beliefs), 25% Christian, 24% in-
digenous beliefs, a few Muslim
Language: English (official); ChiShona and
Si Ndebele
Literacy: 45-55%
Labor force: 1,048,000(1981); 35% agricul-
ture; 25% mining, manufacturing,
construction; 40% transport and services
Organized labor: about one-third of Euro-
pean wage earners are unionized, but only a
small minority of Africans
Population: 19,358,000, excluding the popu-
lation of Ouemoy and Matsu Islands and
foreigners (July 1985), average annual
growth rate 1.5%
Nationality: noun — Chinese (sing., pi.); ad-
jective — Chinese
Ethnic divisions: 84% Taiwanese, 14% main-
land Chinese, 2% aborigine
Religion: 93% mixture of Buddhist, Confu-
cian, and Taoist; 4.5% Christian; 2.5% other
Language: Mandarin Chinese (official); Tai-
wanese and Hakka dialects also used
Literacy: about 89.7%
Labor force: 7,266,000 (1983); 19% agricul-
ture, 40% industry and commerce, 30%
services, 7% civil administration; 1.6% unem-
ployment (1983)
Organized labor: about 15% of 1978 labor
force (government controlled)
Population: total, 1,443,000 (July 1985); av-
erage annual growth rate 2.7%; West Bank
(including East Jerusalem) — 930,000 (July
1984), average annual growth rate 3.3%;
Gaza Strip — 508, 000 (July 1984), average an-
nual growth rate 3.7%
Nationality: West Bank — to be determined;
Gaza Strip — to be determined
Ethnic divisions: West Bank — 84% Palestin-
ian Arab and other, 12% Jewish, 4% Bedouin;
Gaza Strip — 99.8% Palestinian Arab and
other, 0.2% Jewish
Religion: West Bank — 80% Muslim (pre-
dominantly Sunni), 12% Jewish, 7% Christian
and other; Gaza Strip — 99% Muslim (pre-
dominantly Sunni), 0.8% Christian, 0.2%
Jewish
Language:
West Bank: Arabic; Israeli settlers speak He-
brew; English widely understood
Gaza Strip: Arabic; Israeli settlers speak He-
brew; English widely understood
Literacy: West Bank — statistics unavailable;
Gaza Strip — statistics unavailable
Labor force:
West Bank: (excluding Israeli Jewish settlers)
29.6% small industry, commerce, and busi-
ness; 24.7% construction; 22.6% agriculture;
and 23.1% service and other (1983)
Gaza Strip: (excluding Israeli Jewish settlers)
30.7% small industry, commerce and busi-
ness; 26.1% construction; 25.2% service and
other; and 18.0% agriculture','72a9387e89b1e542e01623da4ceb6418d41353237e439be14d59d868735c7d00','internet-archive','CIA-RDP90T01298R000200050001-7','txt','4df2f242a2a3a91583364482456e7cda1384913d5c29f79bb4dda9b3408ed2fe','https://archive.org/download/CIA-RDP90T01298R000200050001-7/CIA-RDP90T01298R000200050001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

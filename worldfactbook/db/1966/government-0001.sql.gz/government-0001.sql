SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e6860afabba4b413174d66b01ab8125ce4943f98cbfdddb2003c8908148f3da',1966,'AF','Afghanistan','government',6,'Legal name: Democratic Republic of Afghanistan
Type: martial law
Capital: Kabul
Political subdivisions: 26 provinces with centrally ap-
pointed governors
Legal system: not established; legal education at Uni-
versity of Kabul; has not accepted compulsory ICJ
jurisdiction : ;
Branches: leaders of the Communist People’s Democratic
Party (PDPA) day-to-day policy decisions are made by the
political bureau of the party’s central committee
Government leaders: President of the Revolutionary
Council, Secretary General of the PDPA, and Prime
Minister Nur Mohammad Taraki; Deputy Prime Minister,
Secretary of the Central Committee, and Minister of Foreign
Affairs Hafizullah Amin
Suffrage: universal from age 18
Political parties and leaders: The People’s Democratic
Party of Afghanistan is the sole legal political party
Communists: Parcliam, a rival faction in the PDPA, is Jed
by exiled former Deputy Prime Minister Babrak Karmal; the
Sholaye-Jaweid is a much smaller pro-Peking group
Other political or pressure groups: the military supports
the government; tribal rebellion continues in the eastern
provinces; possible religious opposition
Member of: ADB, Colombo Plan, FAO, G-77, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, NAM, U.N.,
UNESCO, UPU, WHO, WMO, WTO, WSG','ebd1b0e4191c02fe197ef494940bd5ffa55b0da30edc3d8a4e0d5b5a38a4e6f4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20d9d77a589657e0e2861322ed73814c5ac4621e6e020c9f31bcaf5911151634',1966,'BG','Bulgaria','government',12,'Legal name: People’s Socialist Republic of Albania
Type: Communist state
Capital: Tirané
Political subdivisions: 27 rethet (districts), including
capital, 200 localities, 2,600 villages
Legal system: based on constitution adopted in 1976;
judicial review of. legislative acts only in the Presidium of the
People’s Assembly, which is not a true court; legal education
at State University of Tirané; has not accepted compulsory
IC] jurisdiction
National holiday: Liberation Day, 29 November _
Branches: People’s Assembly, Council of Ministers,
judiciary
Government leaders: Chairman of Council of Ministers,
Mehmet Shehu; Chairman, Presidium of the People’s
Assembly, Haxhi Lleshi (Chief of State)
Suffrage: universal and compulsory over age 18
Elections: national elections theoretically held every 4
years; last elections 6 October 1974; 99.9% of electorate
voted ;
'' Political parties and leaders: Albanian Workers Party
only; First Secretary, Enver Hoxha
Communists: 101,500 party members (November 1976)
Member of: CEMA, IAEA, IPU, ITU, U.N., UNESCO,
UPU, WFTU, WHO, WMO; has not participated in CEMA
since rift with U.S.S.R. in 196]; officially withdrew from
Warsaw Pact 13 September 1968
Legal name: People’s Republic of Bulgaria
Type: Communist state
Capital: Sofia
Political subdivisions: 28 okrugs (districts), including
capital city of Sofia
Legal system: based on civil law system, with Soviet law
influence; new constitution adopted in 1971; judicial review
of legislative acts in the State Council; legal education at
University of Sofia; has accepted compulsory IC) jurisdiction
National holiday: National Liberation Day, 9 September
Branches: legislative, National Assembly; judiciary, Su-
preme Court
Government leaders: Todor Zhivkov, Chairman, State
Council (President and Chief of State); Stanko Todorov,
Chairman, Council of Ministers (Premier)
Suffrage: universal and compulsory over age 18
Elections: theoretically held every 5 years for National
Assembly; last elections held on 20 Mey 1976; 99.85% of the
electorate voted
Political parties and leaders: Bulgarian Communist
Party, Todor Zhivkov, First Secretary; Bulgarian National
Agrarian Union, a puppet party, Petur Tanchev, secretary of
Permanent Board
Communists: 817,000 party members (January 1978)
Mass organizations and front groups: Fatherland Front,
Dimitrov Communist Youth League, Central Council of
Trade Unions, National Committee for Defense of Peace,
Union of Fighters Against Fascism and Capitalism, Commit-
tee of Bulgarian Women, All-National Committee for
-‘Bulgarian-Soviet Friendship
Member ‘of: CEMA, FAO, IAEA, ICAO, ILO, Interna-
tional Lead and Zine Study Group, IMCO, IPU, ITC, ITU,
IWC— International Wheat Council, U.N., UNESCO, UPU,
WHO, WIPO, WMO, WTO; Warsaw Pact, International
Organization of Journalists, International Medical Associ-
ation, International Radio and Television Organization
Legal name: Socialist Republic of the Union of Burma
Type: republic under 1974 constitution
Capital: Rangoon
Political subdivisions: seven divisions-and seven constitu-
ent states; subdivided into townships, villages, and’ wards
Legal system: People’s Justice system and People’s Courts
instituted under 1974 constitution; legal education at
Universities of Rangoon and Mandalay; has not accepted
compulsory ICJ jurisdiction
National holiday: Independence Day, 4 January
Branches: State Council rules through a Council of
Ministers; People’s Assembly has legislative power
Government leader: Chairman of State Council and
President, Gen. U. Ne Win
Suffrage: universal over age 18
Elections: People’s Assembly and local People’s Councils
elected in 1978
Political parties and leaders: government-sponsored
Burma Socialist Program Party only legal party
Communists: estimated 5,000-8,000
Other political or pressure groups: People’s Patriotic
Party; Kachin Independence Army; Karen Nationalist
Union, several Shan factions
Member of: ADB, Colombo Plan, FAO, G-77, GATT,
IAEA, IBRD, ICAO, IDA, IFC, IHO, ILO, IMCO, IMF,
ITU, NAM, U.N., UNESCO, UPU, WHO, WMO','c6d32d434fba54adfa18f84976d53f9f2e37282296b350cbfc87ae8a394fce20','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('285462cf48c725db6ae25ab680545520b8232a867d2e82e26bbb9d025b2bd01a',1966,'DZ','Algeria','government',16,'Legal name: Democratic and Popular Republic of Algeria
Type: republic
Capital: Algiers
Political subdivisions: 31 Wilayas (departments or
provinces)
Legal system: based on French and Islamic law, with
socialist principles; new constitution adopted by referendum
November 1976; judicial review of legislative acts in ad hoc
Constitutional Council composed of various public officials,
including several Supreme Court justices; Supreme Court
divided into 4 chambers; legal education at Universities of
Algiers, Oran, and Constantine; has not accepted compulsory
ICJ jurisdiction
National holiday: 1 November
Branches: executive dominant; unicameral legislature
reconvened in March 1977;: judiciary
Government leader: President Houari Boumediene died
27 December 1978; Acting President Rabah Bitat assumed
duties for 45 days
Suffrage: universal over age 19
Elections (latest): presidential 10 December 1976; depart-
-mental assemblies 2 June 1974; local assemblies 30 March
1975; legislative elections held 25 February 1977
Political parties and leaders: National Liberation Front
(FLN), Mohamed Salah Yahiaoui
Communists: 400 (est.); Communist Party illegal (banned
1962)
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
ALGERIA/ANDORRA
Member of: AFDB, AIOEC , Arab League, ASSIMER,
FAO, G-77, GATT (de facto), IAEA, IBRD, ICAO, IDA,
ILO, International Lead and Zinc Study Group, IMCO,
IMF, IOOC, ITU, NAM, OAPEC, OAU, OPEC, U.N.,
UNESCO, UPU, WHO, WIPO, WMO
Legal name: Gibraltar
Type: U.K. colony
Capital: none
Legal system: English law; constitutional talks in July
1968; new system effected in 1969 after electoral enquiry
Branches: parliamentary system comprised of the Gibral-
tar House of the Assembly (15 elected members and 3 ex
officio members), the Council of Ministers headed by the
Chief Minister, and the Gibraltar Council; the Governor is
appointed by the Crown
Government leaders: Governor and Commander in
Chief, Marshall of the RAF Sir John Grandy, Chief Minister,
Sir Joshua Hassan :
Suffrage: all adult Gibraltarians, plus’ other U.K. subjects
resident 6 months or more
Elections: every 5 years; last held in September 1976
Political parties and leaders: Labor, Sir Joshua Hassan;
Democratic Movement, Joe Boscano
Voting strengths: (September 1976) Labor, 8 seats;
Democratic Movement, 4 séats; independents, 3 seats
Communists: negligible ,
Other political or pressure groups: the Housewives
Association; the Chamber of Commerce; Gibraltar Repre-
sentatives Organization :','35c2c0eae0cd06900a53e1ce144c2d21a62935d528c3594d29e6f1acb873965c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b1ec3a264c6caca6126a0b965a70bc02704c7ef32c6b929e2c082cece695476',1966,'AD','Andorra','government',20,'Legal name: Andorra; Valls d’Andorra (Catalan)
Type: unique coprincipality under formal sovereignty of
President of France and Spanish Bishop of Seo de Ureel,
who are represented locally by officials called verguers
Capital: Andorra :
Political subdivisions: 6 districts—Andorra la Vella, Saint
Julia de Loria, Encamp, Canillo, La Massana, and Ordino
Legal system: based on French and Spanish civil codes;
Plan of Reform adopted 1866 serves as constitution; no
judicial review of legislative acts; has not accepted
compulsory ICJ jurisdiction
Branches: legislature (General Council) consisting of 24
members with one-half elected every 2 years for 4-year
term; executive—syndic (manager) and a deputy sub-syndic
chosen by General Council for 3-year. terms; judiciary
chosen by coprinces who appoint 2 civil judges, a judge of
appeals, and 2 Batles (court prosecutors); final appeal to the
Supreme Court of Andorra at Perpignan, France, or to the
Ecclesiastical Court of the Bishoo of Seo de Urgel. Spain
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
ANDORRA/ANGOLA
Suffrage: males of 2]-or over who are third generation
Andorrans vote for General Council members; same right
granted to women in April 1970
Elections: half of General Council chosen every 2 years,
last election December 1977
Political parties and leaders: traditionally no political
parties but only partisans for particular independent
candidates for the General Council, on the basis of
competence, personality and orientation toward Spain or
France; various small pressure groups developed in 1972;
first formal political party—Andorran Democratic Associ-
ation—formed in November 1976
Communists: negligible
Member of: UNESCO','54d2bb898fe6c66177b013db78b9557ed1cb142cffc94219248258968ae83e71','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8403e48e3e5b0f5742863691c69ffdfc8a5f291ad18a9348411fbfccdd9b775e',1966,'AO','Angola','government',24,'Legal name: People’s Republic of Angola
Type: republic; achieved independence from Portugal in
November 1975; constitution promulgated 1975; govern-
ment formed after civil war which ended in early 1976
Capital: Luanda
Political subdivisions: 17 administrative districts includ-
ing the coastal exclave of Cabinda
Legal system: formerly based on Portuguese civil law
system and customary law; being modified along “socialist”
model
National holiday: Independence Day, 11 November
Branches: the official party is the supreme political
institution
Government leaders: Agostinho Neto, President
Suffrage: to be determined
Elections: none held to date
Political parties and leaders: Popular Movement for the’
Liberation of Angola-Labor Party (MPLA-Labor Party), led
by Agostinho Neto, only legal party; National Front for the
Liberation of Angola (FNLA) and National Union for the
Total Independence of Angola (UNITA), defeated in civil
war, carrying out insurgencies
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
ANGOLA/ANTIGUA
Member of: G-77, ILO, NAM, OAU, U.N., UNICEF,
WHO
Monetary conversion rate: 40.643 escudos=US$1 as of
November 1977
Fiscal year: calendar year
Legal name: State of Antigua
Type: dependent territory with full internal autonomy
as a British “Associated State”
Capital: St. Johns
Political subdivisions: 6 parishes, 2 dependencies (Bar-
buda, Redonda)
Legal system: based on English law; British Caribbean
Court of Appeal has exclusive original jurisdiction and an
appellate jurisdiction, consists of Chief Justice and 5 justices
Branches: legislative, 2l-member popularly elected
House of Representatives; executive, Prime Minister and
Cabinet
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
ee Ee COTY ST OE a a nee NO OO Fo eT a on tO en NS ee NE nen ee ee Oe a ee Oe ee Oe
ei Ts i el te
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
ANTIGUA/ ARGENTINA
Government leaders: Premier Vere C. Bird, Sr.; Deputy
Premier Lester Bird; Governor Sir Wilfred Ebenezer Jacobs
Suffrage: universal suffrage age 18 and over
Elections: every 5 years; last general election 11 February
1976
Political parties and leaders: Antigua Labor Party (ALP),
Vere C. Bird, Sr., Lester Bird; Progressive Labor Movement
(PLM), George Herbert Walter; Antigua People’s Party
(APP), J. Rowan Henry ''
Voting strength: 1976 election—House of Representative
seats—ALP 10, PLM 5, independent 1, tie 1
Communists: negligible
Other political or pressure groups: Afro-Caribbean
Liberation Movement (ACLM), a small black nationalist
group led by Timothy Hector; Antigua Freedom Fighters
(AFF), a small black radical group, leaders unknown
Member of: CARICOM, ISO','48d3090d877674333b7ee387102068dc4e12857f6b381eacd794497245d1d2e6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a964d0229b24f058e74aa9d1155f0176dd6b36028c459f616c98435ca0547d81',1966,'AR','Argentina','government',28,'Legal name: Argentine Republic
Type: republic
Capital: Buenos Aires
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Political subdivisions: 22 provinces, 1 district (Federal
Capital), and 1 territory
Legal system: based on Spanish and French civil codes;
constitution adopted 1853 partially superseded in 1966 by
the Statute of the Revolution which takes precedence over
the constitution when the two are in conflict, further
changes may be made by new government; judicial review
of legislative acts; legal education at University of Buenos
Aires and other public and private universities; has not
accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 25 May
Branches: presidency; legislature; national judiciary
Government leader: President, Lt. Gen. (Ret.) Jorge
Rafael Videla, chosen by the three-man Junta that took
power on 24 March 1976
Government structure: the Junta, composed of the chiefs
of the three armed ‘services, retains supreme authority;
active duty or retired officers fill all but two cabinet posts
and administer all provincial and many local governments;
in addition, the military now oversee the nation’s principal
labor confederation and unions, as well as other civilian
pressure groups; Congress has been disbanded and _ all
political activity suspended; a nine-man Legislative Council,
composed of senior officers, advises the junta on lawmaking
Political parties: a number of civilian political groupings
remain potentially influential, despite the suspension of all
partisan activity; these include Justicialist Party (Peronist
coalition that formerly governed) and the Radical Civic
Union, center-left party providing the chief civilian
opposition to the Peronists; the Moscow-oriented Communist
Party remains legal, but extreme leftist splinter groups have
been outlawed
Communists: some 70,000 members in various party
organizations, including a small nucleus of activists
Other political or pressure groups: Peronist-dominated
labor movement, General Economic Confederation (Peron-
ist-leaning association of small businessmen), Argentine
Industrial Union (manufacturer’s association), Argentine
Rural Sociéty (large landowner’s association), business
organizations, students, and the Catholic Church
Member of: FAO, G-77, GATT, IADB, IAEA; -IBRD,
ICAC, ICAO, IDA, IDB, IFC, IHO, ILO, IMCO, IMF,
IOOC, ISO, ITU, IWC
-sion, IWC International Wheat Council, LAFTA, NAM,
OAS, SELA, ULN., UNESCO, UPU, WHO, WMO, WTO,
WSG
Legal name: Colony of the Falkland Islands
Type: British crown colony
Capital: Stanley
Political subdivisions: local government is confined to
capital
Legal system: English common law
Branches: Governor, Executive Council, Legislative
Council
Government leader: Governor and Commander in Chief
J.R.W. Parker (also High Commissioner for British. Antarctic
Colony)
Suffrage: universal
Legal name: Oriental Republic of Uruguay
Type: republic, government under military control
Capital: Montevideo
Political subdivisions: 19 departments with limited
autonomy
Legal system: based on Spanish civil law system; new
constitution implemented 1967; judicial review of legislative
acts in court of justice; legal education at University of the
Republic at Montevideo; accepts compulsory IC] jurisdiction
National holiday: Independence Day, 25 August
Branches: executive, headed by President; since 1973 the
military has had considerable influence in policymaking;
bicameral legislature (closed indefinitely by presidential
decree in June 1973), Council of State set up to act as
legislature; national judiciary headed by court of justice
Government leader: President Aparicio Mendez
Manfredini
Suffrage: universal over age 18
Elections: projected for last Sunday in November 1981
Political parties and _ leaders: political activities are
proscribed; government has indicated two major traditional
parties (Colorado and Blanco) will be permitted to resume
activity in conjunction with 1981 election
Voting strength (1971 elections): 40.8% Colorado, 40.1%
Blanco, 18.6% Frente Amplio, 0.5% Radical Christian Union
Communists: 5,000-10,000 including former youth group
and sympathizers
Other political or pressure groups: Communist Party
(PCU), Rodney Arismendi (in exile in the U.S.S.R.);
Christian Democratic Party (PDC); Socialist Party of
Uruguay (PSU); Revolutionary Movement of Uruguay
(MRO) pro-Cuban Communist Party; National Liberation
Movement (MLN-Tupamaros) Marxist revolutionary terror-
ist group :
Member of: FAO, G-77, GATT, IADB, IAEA, IBRD,
ICAO, IDB, IFC, ILO, IMCO, IMF, ITU, LAFTA, OAS,
SELA, U.N., UNESCO, UPU, WHO, WMO, WSG
Legal name: State of the Vatican City
Type: monarchical-sacerdotal state
Capital: Vatican City
Political subdivisions: Vatican City includes St. Peter''s,
the Vatican Palace and Museum and neighboring buildings
covering more than 13 acres; 13 buildings in Rome, although
outside the boundaries, enjoy extraterritorial rights
Legal system: Canon law; constitutional laws of 1929
serve some of the functions of ‘a constitution
National holiday: 30 June
Branches: the Pope possesses full executive, legislative,
and judicial powers; he delegates these powers to the ©
governor of Vatican City, who is subject to pontifical
appointment and -recall; high Vatican offices include the
Secretariat of State, the College of Cardinals (chief papal
advisers), the Roman Curia (which carries on the central
administration of the Roman Catholic Church), the Presi-
dence of the Prefecture for the Economy, and the synod of
bishops (created in 1965)
219
Declassified and Approved For Release 2012/09/02 : CIA-RDP0O8-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
VATICAN CITY/VENEZUELA
Government leader: Supreme Pontiff, John Paul II (Karol
Wojtyla, born 18 May 1920, elected Pope 16 October 1978)
Suffrage: limited to cardinals less than 80 in age
Elections: Supreme Pontiff elected for life by College of
Cardinals
Communists: none known
Other political or pressure groups: none (exclusive of
influence exercised by other church officers in universal
Roman Catholic Church)
Member: IAEA, IWC—International Wheat Council,
U.N. (permanent observer), WTO
Legal name: Republic of Venezuela
Type: republic
Capital: Caracas
Political subdivisions: 20 states, 1 federal district, 2
federal territories
Legal system: based on Spanish civil law system with
influence of U.S. law; constitution promulgated 1961;
judicial review of legislative acts in Cassation Court only;
dual court system, state and federal; legal education at
Central University of Venezuela; has not accepted compul-
sory IC] jurisdiction
National holiday: Independence Day, 5 July
Branches: executive (President), bicameral legislature,
judiciary
Government leader: President Carlos Andres Perez; new
president, Luis Herrera Campins to be inaugurated March
1979
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
oa
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
.January 1979
VENEZUELA/VIETNAM
Suffrage: universal and compulsory over age 18
Elections:, every 5 years; last held December 1978; next
national election 1983
Political parties and leaders:. Social Christian Party
(COPEI), Luis Herrera Campins, Rafael Caldera; Accion
Democratica (AD), Carlos Andres Perez, Romulo Betan-
court; Movement to Socialism (MAS), Teodoro Petkoff,
Pompey Marquez; Partido Communista de Venezuela
(PCV), Secretary-General, Jesus Faria j
Voting strength (1978 election): 46% COPE, 43% AD,
5% MAS, 6% others ~
Communists: 4,000-6,000 members (est.)
Other political or pressure groups: Fedeéamaras -(a
conservative business group); PRO VENEZUELA (leftist,
nationalist economic group); DESARROLLISTAS (group of
wealthy, independent businessmen led by former finance
minister Pedro Tinoco and historian Guillermo Moron)
Member of: Andean Pact, AIOEC, FAO, G-77, IADB,
IAEA, IBRD, ICAO, ICO, IDB, IFC, IHO, ILO, IMF, IPU,
ITU, IWC—lInternational Wheat Council, LAFTA, NAMU-
CAR ‘(Caribbean Multinational Shipping Line—Naviera
Multinacional del Caribe), OAS, OPEC, SELA, U.N.,
UNESCO, UPU, WHO, WMO, WTO','54420a48f926a5b8951b2b636ad14c7689497e4c2fc7f5f321b9d6cd4d2ba623','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ce1517ff7329974613417647b8aac9a046dcd3f6e8ad7882660d6774eb74719',1966,'AU','Australia','government',32,'Legal name: Commonwealth of Australia :
Type: federal state recognizing Elizabeth II as sovereign
or head of state
; Capital: Canberra
Political subdivisions: 6 states and 2 territories (Austra-
lian, Capital Territory (Canberra) and Northern Territory)
Legal system: based on English common law; constitution
adopted 1900; High Court has jurisdiction over cases
involving interpretation of the constitution; accepts compul-
sory IC] jurisdiction, with reservations
ARGENTINA/AUSTRALIA
National holiday: 26 January
Branches: Parliament (House of Representatives and
Senate); Prime Minister and Cabinet responsible to House;
independent judiciary
Government leaders: Governor General Sir Zelman
Cowen; Prime Minister John Malcolm Fraser
Suffrage: universal over age 18
Elections: held at 3-year intervals, or sooner if Parliament ;
is dissolved by Prime Minister; last election December 1977
Political parties and leaders: Government—Liberal
Party (Malcolm Fraser) and National Country Party
(Douglas Anthony); opposition—-Labour Party (William J.
Hayden) ;
Voting strength (1977 Parliamentary election): lower
house: Liberal-Country Coalition, 86 seats; Labour Party, 38°
seats; Senate: Liberal Country Coalition, 35 seats; Labour, 26:
seats; Democrats, 2 seats; Independents, 1 seat
Communists: 3,900 members (est.)
Other political or pressure. groups: Democratic Labour
Party (anti-Communist Labour Party splinter group)
Member of: ADB, AIOEC, ANZUS, CIPEC (associate),
Colombo Plan, Commonwealth, DAC, ELDO, ESCAP,
FAO, GATT, IAEA, IATP, IBA, IBRD, ICAC, ICAO, ICO,
IDA, IEA, IFC, IHO, ILO, International Lead and Zinc
Study Group, IMCO, IMF, IOOC, IPU, ISO, ITC, ITU,
IWC—International Whaling Commission, IWC—Interna-
tional Wheat Council, OECD, U.N., UNESCO, UPU, WHO,
WIPO, WMO, WSG
Legal name: Dominion of Fiji
Type: independent state within Commonwealth; Eliza-
beth II recognized as chief of state ,
Capital: Suva
Political subdivisions: 14 provinces
Legal system: based on British
National holiday: 10 October
Branches: executive—Prime Minister; legislative—
52-member House of Representatives (Alliance Party 36
seats, National Federation Party 15 seats); 1 independent 22
member appointed Senate; judicial—Supreme court
.Government leader: Prime Minister Ratu Sir Kamisese
Mara ;
Suffrage: universal adult
Elections: every 5 years unless House dissolves earlier, last
held Séptember 1977
Political parties: Alliance, primarily Fijian, headed by
Ratu Mara; National Federation, primarily Indian, headed
by Jai Ram Reddy
Communists: few, no figures available
Member of: ADB, Colombo Plan, Commonwealth, EEC
(associate), FAO, G-77, GATT (de facto), IBRD, ICAO, IDA,
ILO, IMF, ISO, ITU, U.N., UPU, WHO, WIPO
Legal name: Gilbert Islands
Type: British crown colony with large measure of
self-government
Capital: Tarawa
Branches: 37-member House of Assembly elects a Chief
Minister. :
Government leader: Governor John H. Smith; Chief
Minister, Naboua Ratieta
Political parties and leaders: Gilbertese National Party,
Christian Democratic Party
Member of: ADB
78
Legal name: Republic of Indonesia
Type: republic
Capital: Jakarta
Political subdivisions: 27 first-level administrative subdi-
visions or provinces which are further subdivided into 282
second-level areas
Legal system: based on Roman-Dutch law, substantially
modified by indigenous concepts; constitution of 1945 is
legal basis of government; legal education at University of
Indonesia, Jakarta; has not accepted compulsory ICJ
jurisdiction
National holiday: Independence Day, 17 August
96
Branches: executive headed by President who is chief of
state and head of ‘cabinet; cabinet selected by President;
unicameral legislature (DPR, or parliament), of 460 mem-
bers (100 appointed, 360 elected); second and larger body
(MPR, or congress) of 920 members includes the legislature
and 460 other members (chosen by several processes, but not
directly elected) elects President and Vice President, and
theoretically determines national policy; judicial, Supreme
Court is highest court
Government leader: President, Gen. Suharto (reelected
by Congress, March 1978)
Suffrage: universal over age 17 and married persons
regardless of age
Political parties and leaders: Golkar (quasi-official
“party” based on functional groups), Amir Moertono;
Indonesia Democracy Party (federation of former Nation-
alist and Christian parties), Mohammed Isnaeni; Unity
Development Party (federation of former Islamic parties),
Idham Chalid ;
Voting strength (1977 election): Golkar 232 seats,
Indonesia Democracy 29, Unity Development 99
Communists: Communist Party (PKI) was officially
banned in March 1966; current strength est. at 1,000, with
less than 10% engaged in organized activity; pre-October
1965 hard-core membership has been estimated at 1.5
million ;
Member of: ADB, ANRPC, ASEAN, CIPEC, ESCAP,
FAO, G-77, IAEA, IBA, IBRD, ICAO, ICO, IDA, IFC, THO,
ILO, IMCO, IMF, IPU, ISO, ITC, ITU, NAM, OPEC, U.N.,
UNESCO, UPU, WHO, WMO, WTO
Legal name: Empire of Iran
Type: constitutional monarchy, controlled by the Shah
Capital: Tehran.
Political subdivisions: 23 provinces, subdivided into
districts, sub-districts, counties, and villages
Legal system: based largely on French law, with elements
drawn from other continental systems; personal law based on
Islamic practice generally with residual traces of Roman
law; constitution adopted 1906 and constitutional law of
1907; High Court of Appeal may judge disputes relating to
government departments acting according to law; legal
education at University of Teheran; has not accepted
compulsory IC] jurisdiction
National holiday: Birthday: of the Shah, 26 October
Branches: executive power rests in Shah who appoints a
Prime Minister; Prime Minister must be approved by lower
house (Majlis); while Cabinet theoretically responsibility of
Prime Minister, Shah usually exerts strong influence over its
selection; bicameral legislature; Majlis has 268 members
elected to 4-year terms, and Senate 60 members. serving
4-year terms; half of Senate members appointed by Shah,
other half elected; no provision for judicial review of
constitutionality of legislative acts
Government leaders: Shah Mohammad Reza Pahlavi and
Prime Minister Gen. Qolam Reza Azhari
Suffrage: universal over age 20
97
Declassified and Approved For Release 2012/09/02 : CIA-RDP0O8-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
¢ IRAN/IRAQ
Elections: Majlis every 4 years; Senate every 4 years;
latest national elections June 1975, last district and
municipal October 1976
Political parties and leaders: a single party system,
designated The Resurgence Party of the People of Iran
(RPPI), was formed by Shah in March 1975; all other
political parties disbanded ;
Voting strength: all candidates government approved and
members of the RPPI
Communists: 1,000 to 2,000 est. hard-core, est.; 15,000 to
20,000 est. sympathizers; mostly pro-U.S.S.R. but pro-Chi-
nese faction developing ;
Other political or pressure groups: Tudeh Party (Com- -
munist, illegal); nationalist opposition coalition; Confeder-
ation of Iranian Students (illegal)
Member of: CENTO, Colombo Plan, FAO, G-77, IAEA,
IBRD, ICAC, ICAO, IDA, IFC, IHO, ILO, IMCO, IMF,
IPU, ITU, OPEC, RCD, U.N., UNESCO, UPU, WFTU,
WHO, WMO, WSG, WTO
Legal name: Republic of Iraq
Type: republic; National Front Government consisting of
Ba''th Party (BPI), Iraq Communist Party (CPI), and pro-
administration Kurds formed in July 1973; Communists play
nominal ‘role in government
Capital: Baghdad
Political subdivisions: 18 provinces under centrally
appointed officials
Legal system: based on Islamic law in special religious
courts, civil law system elsewhere; provisional constitution
adopted in 1968; judicial review was suspended; legal
education at University of Baghdad; has not accepted
compulsory ICJ jurisdiction
National holiday: 14 July
Branches: Ba’th Party of Iraq has been in power since
1968 coup
Government leaders: President Ahmad Hasan al-Bakr;
Deputy Chairman of the Revolutionary Command Council
Saddam Husayn ‘Abd-al-Maiid al-Tikriti
Suffrage: no elective bodies exist
Elections: no national elections since overthrow of
monarchy in 1958
Communists: Communist Party allowed token representa-
tion in cabinet; est. 2,000 hard-core members
Political or pressure groups: political parties banned,
possibly some opposition to regime from disaffected
members of the regime and army officers
Member of: Arab League, FAO, G-77, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMF, ITU, NAM, OAPEC, OPEC,
U.N., UNESCO, UPU, WFTU, WHO, WIPO, WMO, WSG,
WTO
Legal name: Republic of Nauru
Type: republic; independent since January 1968
Capital: no capital city per se; government offices in
Yeran District —
Political subdivisions: 14 districts
Branches: President elected from and by Parliament for
an unfixed term; popularly elected 18-member unicaméral
legislature, the Parliament; Cabinet to assist the President,
four members, appointed by President from Parliament
members
Government leader: President Hammer DeRoburt
Suffrage: universal adult
Elections: last held in November 1977
Political parties and leaders: governing faction, Presi-
dent DeRoburt; opposition Nauru Party, Lagumot Harris
Member of: no present plans to join U.N.; enjoys “special
membership” in Commonwealth; South Pacific Commission,
ESCAP, INTERPOL, ITU, UPU
Legal name: Territory of New Caledonia and
Dependencies
Type: French overseas territory; represented in French
parliament by one deputy and one Senator
Capital: Noumea ,
Political subdivisions: 4 islands or island group depend-
encies—Isle of Pines, Loyalty Islands, Huon Islands, Island
of New Caledonia
Legal system: French law
Branches: administered by Governor, who is also High
Commissioner for France in the Pacific; responsible to
French Ministry for Overseas France and Governing
Council; Assemblee Territoriale
Government leader: Jean-Gabrie] Eriau, Governor and
French High Commissioner
Suffrage: universal
‘Elections: Assembly elections every 5 years, last in
’ September 1977
Political parties: Rassemblement Pour La Caledonie—
Conservative; Union Caledonienne—eventual independ-
ence; Union Multiraciale and Palika—independence parties
Voting strength (1977 election): Rassemblement Pour La
Caledonie, 12 seats; Union Caledonienne, 9 seats; Palika, 2
seats; 8, other parties divide up remaining 12 seats
Communists: number unknown; Union Caledonienne
strongly leftist; some politically active Communists were
deported during 1950’s; small number of North Vietnamese
Other political parties and pressure groups: several
lesser parties
Member of: EIB (associate)
Legal name: New Hebrides Condominium
Type: Anglo-French condominium
Capital: Vila ;
Political subdivisions: 4 administrative districts
Legal system: 8 sets of courts; one each for French and
British subjects, one for New Hebrides native affairs
Branches: Representative Assembly of 42 members,
elected November 1977; election boycotted by major party
Government leaders: two resident commissioners, one
French; one British
Political parties and leaders: National Party (Vanuaaku
Pati), chairman Walter Lini; NA Griamel Party, leader
Jimmy Stevens; Mouvement d’Action des Nouvelles Hebri-
des (MANH)
Legal name: Dominion of New Zealand (rarely used)
’ Type: independent state within Commonwealth, recogniz-
ing Elizabeth II as head of state
Capital: Wellington
Political subdivisions: 112 counties
Legal system: based on English law, with special land
legislation and land courts for Maori tribesmen; constitution
consists of various documents, including certain acts of the
U.K. and New Zealand Parliaments; legal education at
Victoria, Auckland, Canterbury, and Otago Universities;
accepts compulsory ICJ jurisdiction, with reservations
National holiday: Waitangi Day, 6 February
Branches: unicameral legislature (General Assembly,
commonly called Parliament); Cabinet responsible to Parlia-
ment; 3-level court system (Magistrates, Courts, Supreme
Court, and Court of Appeal)
Government leader: Prime Minister Robert D. Muldoon
Suffrage: universal age 18 and over
Elections: held at 3 year intervals or sooner if parliament
is dissolved by Prime Minister; last election November 1975
Political parties and leaders: National Party (Govern-
ment), Robert D. Muldoon; Labour Party (Opposition),
Wallace E. Rowling; Social Credit Political League, Bruce
152
Beetham; Communist Party, George Victor Wilcox; pro-
Soviet Socialist Unity Party, George Edward Jackson
Voting strength (1978 election): National Party 49 seats,
Labour Party 42 seats, Social Credit 1 seat
Communists: CPNZ about 300, SUP about 100
Member of: ADB, ANZUS, ASPAC, Colombo Plan, DAC,
ESCAP, FAO, GATT, IAEA, IBRD, ICAO, ICO, IEA, IFC,
IHO, ILO, IMCO, IMF, IPU, ISO, ITU, OECD, U.N.,
UNESCO, UPU, WHO, WMO, WSG
Legal name: Papua New Guinea
Type: independent state within Commonwealth recogniz-
ing Elizabeth II as head of state |
Capital: Port Moresby
‘Political subdivisions: 18 administrative districts (12 in
New Guinea, 6 in Papua)
Legal system: based on English common law
National holiday: Independence Day, 16 September -
Branches: executive—Executive Council; legislature—
House of Assembly (109 members); judiciary—court system
consists of Supreme Court of Papua New Guinea and various
inferior courts (District Courts, Local Courts, Children’s
Courts, Wardens’ Courts)
Government leaders: Governor General, Sir Tore Loko-
loko; Prime Minister, Michael Thomas Somare
Suffrage: universal adult suffrage
Elections: preferential-type elections for 109-member
House of Assembly every 4 years, last held in June 1977
Political parties: Pangu Party, People’s Progress Party,
United Party, Papua Besena
Communists: no significant strength
Member of: ADB, CIPEC (associate), Commonwealth,
ESCAP (associate), G-77, IBRD, ILO, IMF, U.N., WHO
(associate)
Legal name: Tuvalu
Type: independent state within commonwealth
Capital: Funafuti
House of Assembly: eight deabues
Government leader: Prime Minister Toalipi Lauti
Legal name: Independent State of Western Samoa,
Type: constitutional monarchy under native chief; special
treaty relationship with New Zealand
Capital: Apia
Legal system: based on English common Aah and local
customs; constitution came into effect upon independence in
1962; judicial - review of legislative acts with respect’ to
fundamental rights of the citizen; has not accepted
compulsory ICJ jurisdiction : :
National holiday: 1 January
Branches: Head of State and Executive Council; Legisla-
‘tive Assembly; Supreme Court, Court of Appeal,.Land and
Titles Court, village courts
Government leaders: Head of State, Malietoa Tanumafili
II, Prime Minister, Taisi Tupuola Efi
Suffrage: 45 Samoan members of Legislative Assembly
are elected by holders of matai (heads of family) titles (about
5,000); 2 European members are_elected by universal adult
suffrage
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
WESTERN SAMOA/YEMEN (ADEN)
Elections: held triennially, last in February 1976
Political parties and leaders: no clearly defined political
party structure
Communists: unknown
Member of: ADB, Commonwealth, ESCAP, G-77, IBRD,
IFC, IMF, U.N.,, WHO
ECONOMY ee
GNP: $45 million (1974), $290 per capita
Agriculture: cocoa, bananas, copra; staple foods include
coconut, bananas, taro, and yams
Electric. power: 9,000 kW capacity (1977); 27 million
kWh produced (1977), 180 kWh per capita
Exports: $15 million (f.0.b., 1977); copra 38%, cocoa 26%,
timber 3%
Imports: $38 million (c.if., 1977); food, manufactured
goods, machinery
Major trade partners: exports—37% New Zealand, 7%
Netherlands, 836% West Germany, 8% U.S.; imports—28%
New Zealand, 20% Australia, 15% Japan, 13% US.
Aid: New Zealand, $7 million (est. 1972-76)
Budget: 1976 est., revenues and Brants $34 million,
expenditures $46 million
Monetary conversion rate: WS Tala~US$1.3494 (July
1978), 0.74 WS Tala=US$1
Major industries: timber, tourism
Legal name: People’s Democratic Republic of Yemen
Type: republic; power centered in ruling Yemeni Socialist
Party (YSP).
Capital: Aden; Madinat ash Sha’b, administrative capital
Political subdivisions: 6 provinces
Legal system: based on Islamic Jaw (for sna matters)
and English common law (for commercial matters); highest
judicial organ, Federal High Court, interprets constitution
and determines disputes between states
National holiday: 14 October
Branches: Presidential Council; cabinet; Supreme Peo-
ple’s Council : ;
Government leaders: Chairman of Presidential Council
and Prime Minister Ali Nasir Muhammed al-Hasani; YSP
Secretary General Abd Al]-Fattah Ismail
Suffrage: granted by-constitution to all citizens 18 and
over ,
Elections: elections for legislative body, Supreme People’s
Council, called for in constitution; none have been held
Political parties and leaders: Yemeni Socialist Party
(YSP), the only legal party, is coalition of National Front,
Baath, and Communist parties
-. Communists: unknown number
‘Member of: Arab League, FAO, G-77, GATT (de facto),
IBRD, ICAO, IDA, ILO, IMF, ITU, NAM, U.N., UNESCO,
UPU, WHO, WMO, WTO
225
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
ns '' January 1979
YEMEN (ADEN)/YEMEN (SANA)
Legal name: Yemen Arab Republic
Type: republic; military regime assumed power in June
1974
Capital: Sana
Political subdivisions: 8 provinces
Legal system: based on Turkish law, Islamic law, and
local customary law; first promulgated
December 1970, suspended June 1974; has not accepted
compulsory ICJ jurisdiction
constitution
National holiday: Proclamation of the Republic, 26
‘September’
Branches: President, Prime Minister, cabinet; Constituent
Assembly
Government leaders: President Ali Abdallah Salih; Prime
Minister Abd al-Aziz Abd al-Ghani
Communists: small number
Political parties or pressure groups: conservative tribal
groups, some Muslim Brotherhood followers, leftist senti-
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Ee ee ae Te ye ee eg es eee ye |
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
YEMEN (SANA)/YUGOSLAVIA
ment represented by pro-Iraqi Baathists, Nasirists, small
clandestine groups supported by Yemen (Aden)
Member of: Arab League, FAO, G-77, IBRD, ICAO,
IDA, IFC, ILO, IMF, ITU, NAM, U.N., UNESCO, UPU,
WHO, WMO :
Legal name: Socialist Federal Republic of Yugoslavia
Type: Communist state, federal republic in form
Capital: Belgrade
_ Political subdivisions: 6 republics with 2 autonomous
provinces (within the Republic of Serbia)
Legal system: mixture of civil law system and Communist
legal theory; constitution adopted 1974; legal education at
227
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
YUGOSLAVIA/ZAIRE
several law schools; has not accepted compulsory ICJ
jurisdiction .
National holiday: Proclamation of the Socialist Federal
Republic of Yugoslavia, 29 November
Branches: parliament (Federal Assembly) constitutionally
supreme; executive includes cabinet (Federal Executive
Council) and the federal administration; judiciary; the State
Presidency is a collective policymaking body composed of a
representative from each republic and province, Tito
presides as President of the Republic
Government leader: Josip Broz Tito, President of
Republic and President of League of Communists of
Yugoslavia
Suffrage: universal over age 18
Elections: Federal Assembly elected every 4 years by a
complicated, indirect system of voting
Political parties and leaders: League of Communists of
Yugoslavia (LCY) only; leaders are President Tito and
influential Presidium members Edvard Kardelj, Vladimir
Bakaric, and Stane Dolanc
Communists: 1,629,082 party members (December 1977)
Other political or pressure groups: Socialist Alliance of
Working People of Yugoslavia (SAWPY), the major mass
front organization for the LCY; Confederation of Trade
Unions of Yugoslavia (CTUY), Union of Youth of Yugoslavia
(UYY), Federation of Yugoslav War Veterans (SUBNOR)
Member of: ASSIMER, CEMA (observer but participates
in certain commissions), EC (5-year non-preferential trade
agreement signed in May 1973 currently being renegoti-
ated), FAO, G-77, GATT, IAEA, IBA, IBRD, ICAC, ICAO,
IDA, IFC, IHO, ILO, International Lead and Zine Study
Group, IMCO, IMF; IPU, ITC, ITU, NAM, OECD
(participant in some activities), U.N., UNESCO, UPU,
WHO, WIPO, WMO, WTO
Legal name: Republic of Zaire (until October 197] known
as Democratic Republic of the Congo)
Type: republic; constitution establishes strong presidential
system ;
Capital: Kinshasa
Political subdivisions: 8 regions and federal district of
Kinshasa
Legal system: based on Belgian civil law system and tribal
law; new constitution promulgated February 1978; legal
education at National University of Zaire; has not accepted
compulsory ICJ jurisdiction
National holiday: Independence Day, 30 June
Branches: president elected 1970 for seven-year term;
Gen. Mobutu reelected December 1977; limits on reelection
removed by new constitution; National Legislative Council
of 210 members elected for five-year term; the official party
is the supreme political institution
Government leader: Lt. Gen. Mobutu Sese Seko,
President ''
Suffrage: universal and compulsory over age 18
Elections: presidential and legislative elections-in October
and November 1970; elections for urban zone councils,
legislative council; and political bureau of sole political party
held in October 1977
Political parties and leaders: Mouvement Populaire de la
Revolutiori (MPR), only legal party, organized from above
Voting strength: MPR slate polled 96.3% of vote in 1970
elections :
Communists: no Communist Party; U.S.S.R. and Peoples
Republic of China have diplomatic missions in Zaire
Member of: AFDB, APC, CIPEC, EAMA, EIB (associate),
FAO, G-77, GATT, IAEA, IBRD, ICAO, ICO, IDA, IFC,
IHO, ILO, IMF, IPU, ITC, ITU, NAM, OAU, OCAM,
UDEAC, U.N., UNESCO, UPU, WHO, WIPO, WMO,
WTO','faf588aa3a0fd65129dc29c37b683c93992eea9cf45f84fadcf914525f5d6b9e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be1c37a0af39cc4400ccb1b0ea372097ea88ea45e1e1d9a9931fde0fe76a0c9c',1966,'AT','Austria','government',37,'Legal name: Republic of Austria
Type: federal republic
Capital: Vienna
Political subdivisions: 9 states (Laender) including the
capital
Legal system: civil Jaw system with Roman law origin;
constitution adopted 1920, repromulgated in 1945; judicial
review of legislative acts by a Constitutional Court; separate
administrative and civil/penal supreme courts; legal educa-
tion at Universities of Vienna, Graz, Innsbruck, Salzburg,
and Linz; has not accepted compulsory ICJ jurisdiction
National holiday: 26 October
Branches: bicameral parliament, directly elected Presi-
dent whose functions are largely representational, independ-
ent federal judiciary
Government leaders: President Rudolf Kirchschlaeger,
Chancellor Bruno Kreisky leads a one-party Socialist
Suffrage: universal over age 19; compulsory for presiden-
tial elections
Declassified and Approved For Release 2012/09/02 : CIA-RDP0O8-00534R000100140001-7
RT SE ER Re Re a a ag et Ce ee ee a pen
ar, eed Pe ee Qe eee ee. Oe, ee eee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
AUSTRIA/THE BAHAMAS
Elections: presidential, every 6 years (next 1980);
parliamentary, every 4 years (next 1979)
Political parties and leaders: Socialist Party of Austria
(SPOe), Bruno Kreisky, Chairman; Austrian People’s Party
(OeVP), Josef Taus, Chairman; Liberal Party (FPOe),
Alexander Gotz, Chairman; Communist Party, Franz Muhri,
Chairman
Voting strength (1975 election): 50.6% SPOe, 42.7%
OeVP, 5.3% FPOe, 1.2% Communist
Communists: membership 25,000 est.; activists
_ 7,000-8,000
Other political or pressure groups: Federal Chamber of
Commerce and Industry; Austrian Trade Union Federation
(primarily Socialist); three composite leagues of the Austrian
People’s Party (OeVP) representing business, labor, and
farmers; the OeVP-oriented League of Austrian Industrial-
ists; Roman Catholic Church, including its chief lay
organization, Catholic Action
Member of: ADB, Council of Europe, DAC, ECE, EFTA,
EMA, ESRO (observer), FAO, GATT, IAEA, IBRD, ICAC,
ICAO, IDA, IEA, IFC, ILO, International Lead and Zinc
Study Group, IMF, ITU, 1WC—International Wheat Coun-
cil, OECD, U.N., UNESCO, UPU, WHO, WIPO, WMO,
WTO, WSG','9071b798145d955c19b1b0512a88f43e63554b9dff9764db5a11e575c42272ac','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d67b5327f51682b81998cb7fc00c66d6a9c9ca41a1eca3545b4290619547c00',1966,'HT','Haiti','government',40,'Legal name: The Commonwealth of The Bahamas
Type: independent commonwealth since July 1978,
recognizing Elizabeth JI as Chief of State
Capital: Nassau (New Providence Island)
Legal system: based on English law
National holiday: Independence Day, 10 July
Branches: bicameral legislature (appointed Senate,
elected House); executive (Prime Minister and cabinet);
judiciary
. Government leaders: Prime Minister Lynden O.
Pindling; Acting Governor General Gerald C. Cash
Suffrage: universal over age 18; registered voters (July
1977) 73,309 ;
Elections: House of Assembly (19 July 1977); next
election due constitutionally in 5 years
Political parties and leaders: Progressive Liberal Party
(PLP), predominantly black, Lynden O. Pindling; Bahamian
Democratic Party (BDP), Henry Bostwick; Free National
Movement (FNM), Cecil Wallace-Whitfield
Voting strength (1977 election): PLP (55%) 30 seats, BDP
(27%) 6 seats, FNM (15%) 2 seats, others (8%) 0 seats
Communists: none known
Member of: CDB, G-77, IBRD, ICAO, IDB, ILO, IMCO,
IMF, U.N., WHO, WIPO, WMO, WTO
Legal name: Republic of Haiti
Type: republic under the 14-year dictatorship of Francois
Duvalier who was succeeded upon his death on 2] April
1971 by his son, Jean-Claude
Capital: Port-au-Prince
Political subdivisions: 5 departments (despite constitu-
tional provision for 9)
Legal system: based on Roman civil law system;
constitution adopted 1964 and amended 1971; legal educa-
tion at State University in Port-au-Prince and private law
88
colleges in Cap-Haitien, Les Cayes, Gonaives, and Jeremie;
accepts compulsory ICJ jurisdiction
National holiday: Independence Day, 1 January
Branches: lifetime President, unicameral 58-member
legislature of very limited powers, judiciary appointed by
President
Government leader: President-for-life, Jean-Claude
Duvalier
Suffrage: universal over age 18
Elections: constitution as amended in 1971 provides for
lifetime president to be designated by his predecessor and
ratified by electorate in plebiscite; legislative elections,
which are held every 6 years, last held February 1973
Political parties: National Unity Party, only legal party;
United Haitian Communist Party (PUCH), illegal (Com-
munist)
Voting strength (1973 legislative elections): 100% Na-
tional Unity Party (Duvalier)
Communists: strength unknown; party leaders believed in
exile
Other political or pressure groups: none
Member of: FAO, G-77, GATT, IADB, IAEA, IBA,
IBRD, ICAO, ICO, IDA, IDB, IFC, ILO, IMCO, IMF, ITU,
OAS, SELA, U.N., UNESCO, UPU, WHO, WMO, WTO','288cd1c29f625404162efc0973410f577e49ab44efedc4f9c317f11b9a0ac155','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ff54e6aebac6e48f49f4578943fb3f2cbfbe0e5f9bc0d041734400371d3928c',1966,'BH','Bahrain','government',45,'Legal name: State of Bahrain
Type: traditional monarchy; independence declared in
1971 :
Capital: Manama
Legal system: based on Islamic law and English common
law; constitution ‘went into effect December 1973
National holiday: 16 December
Branches: Amir rules with help of a cabinet led by Prime
Minister; a National Assembly, made up of cabinet and 30
directly elected members, was formed in early 1974; Amir
dissolved assembly in August 1975 and suspended. the
constitutional provision for election of the assembly
Government leader: Amir ‘Isa ibn Salman Al Khalifa
Political parties and pressure groups: political parties
prohibited; no significant pressure groups although numer-
ous small clandestine groups are active
Communists: negligible
Member of: Arab League, FAO, G-77, GATT (de facto),
IBRD, ICAO, IMF, NAM, OAPEC, U.N., UNESCO, WHO','c9cc3d7c3c773383363902eaa853bb5bb8c056f9a9defd2bfae40e2649de889c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('704dd054953eaa9be2b07f51d7652a90c21662832556506e88aa79f6f26f2e2b',1966,'BD','Bangladesh','government',49,'Legal name: People’s Republic of Bangladesh
Type: independent republic since December 1971; Gov-
ernment of President Sheikh Mujibur Rahman overthrown
in August 1975; two other coups followed; country currently
governed by an elected president who is also chief martial
law administrator, and his council of civilian advisers
Capital: Dacca
Political subdivisions: 19 districts, 413 thanas (counties),
4,053 unions (village groupings)
Legal system: based on English common law; constitution
adopted December 1972; amended January 1975 to more.
authoritarian presidential system, changed by proclamation
in April 1977 to reflect Islamic character of nation; President
has promised a new constitution will be written following
the parliamentary elections of February 1979
National holiday: Independence Day, 26 March
Branches: constitution provides for unicameral legisla-
ture, strong president; controlled judiciary; parliament
dissolved by current regime
Government leader: President, Maj. Gen. Ziaur Rahman
Suffrage: universal: over age 18
Elections: First Parliament (House of the Nation) elected
in March 1978; elections every 5 years; President elected
June 3, 1978; a separate parliamentary election is planned
for 12 February. 1979
14
Communists: 2,500 members (est.)
Other political or pressure groups: 18 political parties
legalized by government as of October 1978, student groups,
bands of former guerrillas —
Member of: ADB, Afro-Asian People’s Solidarity Organi-
zation, Colombo Plan, Commonwealth, ESCAP, G-77,
GATT, IAEA, IBRD, ICAO, IDA, IMF, ILO, NAM, U.N.,
UNCTAD, UNESCO, UPU, WHO, WTO','ae2a826be030ddbfb1b4febd349c9c1f4e2ab121b2dacd93fdbcc70c62e731d6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b644719502a3f816427ab5ecb441dace74ed5a1ab30a35232a181efef30881b',1966,'BB','Barbados','government',53,'Legal name: Barbados
Type: independent sovereign state within the Common-
wealth since November 1966, recognizing Elizabeth II as
Chief of State
Capital: Bridgetown
Political subdivisions: 1] parishes and city of Bridgetown
Legal system: English common law; constitution came
into effect upon independence in 1966; no judicial review of
legislative acts; has not accepted compulsory ICJ jurisdiction
National holiday: 30 November
‘Branches: legislature consisting of a 2l-member ap-
pointed Senate and a 24-member elected. House of
Assembly; cabinet headed by Prime Minister
Government leader: Prime Minister J. M. G. “Tom”
Adams; Governor General Sir Deighton H. L. Ward
Suffrage: universal over age 18
Elections: House of Assembly members have’ terms no
longer than 5 years; last general election held 2 September -
1976
Political parties and leaders: Barbados Labor Party
(BLP), J. M. G. “Tom” Adams; Democratic Labor Party
(DLP), Errol Barrow
Voting strength (1976 election): Barbados Labor Party
(BLP), 53%; Democratic Labor Party, 46%; Independent,
negligible; House of Assembly seats—BLP 17, DLP 7
Communists: negligible
Other political or pressure groups: People’s Progressive
Movement (PPM), a small black-nationalist group led by
Calvin Alleyne
Member of: CARICOM, Commonwealth, FAO, G-77,
GATT,.IADB, IBRD, ICAO, IDB, ILO, IMCO, IMF, ISO,
ITU, IWC—International Wheat Council, OAS, SELA,
U.N., UNESCO, UPU, WHO, WMO','94c6fd1704f26e9b3b59ebd1f01e4855482d879efc1d2d3a63438d49de86cd0f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b63c622fabf7035faef91db0fa17bc1dab4edb258056749f1c331eabcfbf7466',1966,'BE','Belgium','government',57,'Legal name: Kingdom of Belgium
Type: constitutional monarchy
Capital: Brussels
Political subdivisions: 9 provinces
Legal system: civil law system influenced by English
constitutional theory; constitution adopted 1831, since
amended; judicial review of legislative acts; legal education
at 4 law schools; accepts compulsory ICJ jurisdiction, with
reservations
National holiday: National Day, 21 July
Branches: executive branch consists of King and cabinet;
cabinet responsible to bicameral parliament; independent
judiciary; coalition governments are usual
Government leader: Head of State, King Baudouin;
Prime Minister Paul vanden Boeynants (interim until
election of Constituent Assembly in January 1979)
_ Suffrage: universal over age 21
Elections: held 17 April 1977 (held at least once every 4
years) :
Political parties and leaders: Social Christian, Charles
Nothomb and Wilfred Martens, co-presidents; Socialist,
Andre Cools and Karl Van Miert, co-presidents; Liberal,
Pierre Dechamps, national president; Brussels Liberal, Basile
Risopoulos, party president; Francophone Democratic Front,
Antoinette Spaak, party president; Walloon Rally, Paul-
Henri Gendebien, party president; Volksunie (Flemish
nationalist), Hugo Schiltz, party president; Communist,
Louis Van Gent, president of political bureau
Voting strength (1977 election): 80 seats Social Christian,
62 seats Socialist, 31 seats Liberal, 20 seats Volksunie, 10
seats Francophone Democratic Front, 5 seats Walloon Rally,
2 seats Brussels Liberal, 2 seats Communist
Communists: 10,000 members (est.)
Other political or pressure groups: Christian and Socialist
_Trade Unions; the Federation of Belgium Industries;
numerous other associations representing bankers, manufac-
turers, middle-class ‘artisans, and the legal and medical
professions; two major organizations’ represent the cultural
interests of Flanders and Wallonia
Member of: ADB, Benelux, BLEU, Council of Europe,
DAC, EC, ECE, ECOSOC, ECSC, EEC, EIB, ELDO, EMA,
ESRO, EURATOM, FAO, GATT, IAEA, IBRD, -ICAC,
ICAO, ICO, ICES, IDA, IEA, IFC, ILO, International Lead
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
BELGIUM/BELIZE
and Zinc Study Group, IMCO, IMF, IOOC, IPU, ITC, ITU,
NATO, OAS (observer), OECD, U.N., UNESCO, UPU,
WEU, WHO, WIPO, WMO, WSG','54e83c48d2d3626f0a3e665058957a3a84fceedd36f1af4d52f51735e4fb2b9b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01bda8b9bed87a74c8efdeffb697b23451517a65152cd071dca645cbceb9fe04',1966,'HN','Honduras','government',62,'Legal name: Belize
Type: internal self-governing British colony
Capital: Belmopan
Legal system: English law; constitution came into force in
1964, although country remains a British colony
" Branches: 18-member elected National Assembly and
8-member Senate (either house may choose its speaker or
president, respectively, from outside its elected member-
ship); cabinet; judiciary
Government leaders: Premier George C. Price; Governor
Peter Donovan McEntee
Suffrage: universal adult (probably 21)
Elections: must be held within 5 years of last elections
held in October 1974
Political parties and leaders: People’s United Party
(PUP), George Price; United Democratic Party (UDP), a
coalition comprised of the National Independence Party
(NIP) led by Philip Goldson, the People’s Democratic Union
(PDM) led by Dean Lindo, and the Liberal Party (LP) led
by Harry Lawrence; Corozal United Front (CUF), San-
tiago Ricalde; United Black Association for Development
(UBAD), Evan X. Hyde
Voting strength (National Assembly): PUP 12 seats, UDP
6 seats
’ Communists: negligible
Other political or pressure groups: Christian Workers’
Union (CWU) which is connected with PUP
Member. of: CARICOM, ISO
Legal name: Republic of Honduras
Type: republic
Capital: Tegucigalpa
Political subdivisions: 18 departments
Legal system: based on Roman and Spanish civil law;
some influence of English common law; constitution adopted
1965; judicial review of legislative acts in Supreme Court;
legal education at University of Honduras in Tegucigalpa;
accepts compulsory ICJ jurisdiction, with reservations
National holiday: Independence Day, 15 September
Branches: constitution provides for elected President,
unicameral legislature, and national judicial branch
Government leader: Chief of State Brig. Gen. Policarpo
PAZ Garcia dominates a three-man junta __ a
Suffrage: universal and compulsory over age 18
Elections: government leaders have indicated an inten-
tion to hold elections in 1980
Political parties and leaders: while denied an institution-
al role in government since the 4 December 1972 military
takeover, the political parties were allowed to hold internal
elections, issue public declarations, and continue their
organizational activities; with the scheduling of elections the
parties are expected to become more active; ... .beginning
the process of refurbishing: Liberal Party (PLH), Modesto
Rodas Alvarado, Carlos Roberto Reina Idiaguez, Jorge Bueso
Arias; National Party (PNH), Alejandro Lopez Cantarero,
Ricardo Zuniga Augustinus; Mario Rivera Lopez, Martin
Aquero; Popular Progressive Party (PPP) (uninscribed),
Gonzalo Carias Castillo; National Innovation and Unity
Party (PINU) (uninscribed), Miguel Andonie Fernandez;
Workers Party of Honduras (PTH) (Communist) ‘ (unin-
scribed), Rogue Ochoa; Communist Party of Honduras/So-
viet (PCH/S-outlawed), Dionisio Ramos Bejarano; Commu-
nist Party of Honduras/ China (PCH/C-outlawed), Agapito
Robledo Castro .
Voting strength (1971 elections): National Party (PNH)
306,028; Liberal Party (PLH) 276,777
Communists: about 650; 500 sympathizers
Other political or pressure groups: National Association
of Honduran Campesinos {ANACH); Council of Honduran
89
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
HONDURAS/HONG KONG
Private Enterprise (COHEP); Confederation of Honduran
Workers (CTH)
Member of: CACM, FAO, G-77, IADB, IBRD, ICAO,
ICO, IDA, IDB, IFC, ILO, IMCO, IMF, ISO, ITU, OAS,
U.N., UNESCO, UPEB, UPU, WHO, WMO','fe473c6470fe6645bc6d0955b249b15db01296d7be98b9cba9fce894ebcad607','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2fa2c67eac2d586bddad99ba8625c90a8b164d86f23465ecf77d307e869c19fe',1966,'BJ','Benin','government',66,'Legal name: People’s Republic. of Benin
Type: party state, under military rule since 26 October
1972 :
Capital: Porto-Novo (official), Cotonou (de facto)
Political subdivisions: 6 provinces, 46 districts
Legal system: based on French civil law and customary
law; legal education generally obtained in France; has not
accepted compulsory IC] jurisdiction
National holiday: 30 November
Branches: National Revolutionary Council, Council of
Ministers, Central Committee -of Party
Government leader: Col. Mathieu Kérékou, President,
and Chief of State Charged with National Defense
Suffrage: suspended
Elections: current government has held no elections and
-none are scheduled
Political parties: People’s. Revolutionary Party of Benin
established in 1975
Communists: sole party espouses Marxism-Leninism
Member of: AFDB, CEAO, EAMA, ECA, ECOWAS;
Entente, FAO, G-77, GATT, IBRD, ICAO, ICO, IDA, ILO,
IMF, ITU, NAM, Niger River Commission, OAU, OCAM,
U.N., UNESCO, UPU, WHO, WIPO, WMO, WTO','ebb8cd00ea6409cb306d7cb44db55f22cea6e7b8485db243d1f209f9ba5eeece','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39b1f85a1be8212ac3dbe3666d5dc4ae890f976c20871267c52ef6704dc27ebd',1966,'BM','Bermuda','government',70,'Legal name: Bermuda
Type: British colony
Capital: Hamilton
Political subdivisions: 9 parishes
Legal system: English law
Branches: Executive Council (cabinet) appointed by
governor, led by government leader; bicameral legislature
with an appointed Legislative Council, and a 40-member
directly elected House of Assembly; Supreme Court
Government leaders: Governor, Sir Peter Ramsbotham;
Premier, J. David Gibbons
Suffrage: universal over age 21
Elections: at least once every 5 years; last general election,
May 1976
Political parties and leaders: United Bermuda Party
(UBP), J. David Gibbons; Progressive Labor Party (PLP),
Lois Browne Evans
Voting strength (1976 elections): UBP 55.5%, PLP 44.4%;
House of Assembly seats—UBP 26%, PLP 14%
Communists: negligible
20
Other political or pressure groups: Bermuda Industrial
Union (BIU)
Legal name: Kingdom of Bhutan
Type: monarchy; special treaty relationship with India
Capital: Thimphu
Political subdivisions: 4 regions (east, central, west,
south), further divided into 15-18 subdivisions
Legal system: based on Indian law and English common
law; in 1964 the monarch assumed full power—no
constitution existed beforehand; a Supreme Court hears
appeals from district administrators; has not accepted
compulsory ICJ jurisdiction
National holiday: 17 December
Branches: appointed Minister and indirectly elected
Assembly consisting of village elders, monastic representa-
tives, and all district and senior government administrators
Government leader: King Jigme Singye Wangchuk
Suffrage: each family has one vote
Elections: popular elections on village level held every 3
years
Political parties: all parties illegal
Communists: no overt Communist presence
Other political or pressure groups: Buddhist clergy
Member of: Colombo Plan, G-77, NAM, UPU, U.N.','a5eae6cfb33e5a3eaf883ed5bc23ee9b378ca027b94bee042477715ed1c3f95f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc51d14f93aa6f0a22593f52b43d0bfbfe887b0931d00790a1414f5fdf10d1be',1966,'BR','Brazil','government',73,'Legal name: Republic of Bolivia
Type: republic; de facto military dictatorship government
Capital: La Paz (seat of government); Sucre (legal capital
and seat of judiciary)
Political subdivisions: 9 departments with limited
autonomy :
Legal system: based on Spanish law and Code Napoleon;
constitution adopted 1967; constitution in force except
where contrary to dispositions dictated by governments since
1969; legal education at University of San Andres and
several others; has not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 6 August
Branches: executive; congress of two chambers (Senate
and Chamber of Deputies), congress disbanded after 26
September 1969 ouster of President Siles; judiciary
Government leaders: President David PADILLA
Arancibia
Suffrage: universal and compulsory at age 18 if married,
21 if single
Elections: presidential and congressional elections held on
9 July 1978, Bolivia’s first elections in 12 years were
subsequently declared invalid by the Banzer government
following widespread reports of fraudulent balloting; on 21
July General Pereda, the official candidate, took power in a
bloodless coup; (Pereda has since been deposed by Padilla);
elections are now tentatively set for early 1979
Political parties and leaders: ban on political parties was
lifted in December 1977, but party activity is disorganized
so far; the two traditional political parties in Bolivia are the
Nationalist Revolutionary Movement (MNR) and the Boliv-
ian Socialist Phalange (FSB), both are seriously factionalized;
Bolivian Socialist Falange; (Mario Gutierrez); Nationalist
22
Revolutionary Movement of the People (Jaime Arellano);
Nationalist Revolutionary Movement of Left (Hernan Siles
Zuazo); Authentic Revolutionary Party (Walter Guevara
Arce); Christian Democratic Party (Benjamin Miguel);
Nationalist Revolutionary Party of Left (Juan Lachin
Oquendo); Paz Estenssorista MNR (Leonidas Sanchez)
Voting strength (1966 elections): Frente de la Revolucion
Boliviana (a coalition composed of the MPC, PIR, PRA,
PSD, and two interest groups, the campesinos and Chaco
War Veterans) 61%, FSB 12%, MNR 10%, other 17%
Communists: three parties; PCB/Soviet led by Jorge Kolle
Cueto, about 300 members; PCB/Chinese led by Oscar
Zamora, 150 (including 100 in exile); POR (Trotskyist),
about 50 members divided between three factions led by
Hugo Gonzalez Moscoso, Guillermo Lora Escobar, and
Amadeo Arze
Member of: FAO, G-77, IAEA, IADB, IATP, IBRD,
ICAO, ICO, IDA, IDB, IFC, ILO, IMF, ISO, ITC, ITU,
IWC—International Wheat Council, LAFTA and Andean
Sub-Regional Group (created in May 1969 within LAFTA),
OAS, SELA, U.N., UNESCO, WHO, WMO, WTO
Legal name: Federative Republic of Brazil
Type: federal republic; military-backed presidential re-
gime since April 1964
Capital: Brasilia ;
Political subdivisions: 22 states, 3 territories, federal
district (Brasilia) ,
Legal system: based on Latin codes; dual system of courts,
state and federal; constitution adopted 1967 and extensively
amended in 1969; has not accepted compulsory ICJ
jurisdiction
National holiday: Independence Day, 7 September
Branches: strong executive with very broad powers;
bicameral legislature (powers of the two bodies have been
sharply reduced); 11-man Supreme Court
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
;
|
a aoa ow we we oe
re rer
ee
i a Oe De ee oe Oe ee ae
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
BRAZIL/BRUNEI
Government leader: President Ernesto Geisel
Suffrage: compulsory over age 18, except illiterates and
those stripped of their political rights; approximately 30
million registered voters in October 1970
Elections: President Geisel’s successor, Joao Baptista de
Oliveira Figuerido, was chosen by an electoral college,
composed of the members of Congress and delegates
selected from the state legislatures on 15 October 1978; to
take office 15 March 1979
Voting strength: (November 1974 congressional elections)
33.6% ARENA, 31.9% MDB, 35.5% blank and void
Political parties and leaders: National Renewal Alliance
(ARENA), pro-government Francelino Pereira, president;
Brazilian Democratic Movement (MDB), opposition, Ulisses
Guimaraes, president
Communists: 6,000, 1,000 militants
Other political or pressure groups: excepting the
military, the Catholic Church is the only active nationwide
pressure group, however, divisions within the Church often
prevent it from speaking with one voice; labor and student
groups have become more vocal in recent months
Member of: FAO, G-77, GATT, IADB, IAEA, IBRD,
ICAC, ICAO, ICO, IDA, IDB, IFC, IHO , ILO, IMCO, IMF,
IPU, ISO, ITU, IWC —International Wheat Council,
LAFTA, OAS, SELA, U.N., UNESCO, UPU, WHO, WIPO,
WMO, WTO
Legal name: State of Brunei
Type: British protectorate; constitutional sultanate
Capital: Bandar Seri Begawan
Political subdivisions: 4 administrative districts
Legal system: based on Islamic law; constitution promul-
gated by the Sultan in, 1959
Branches: Chief of State is Sultan (advised by appointed
Privy Council) who appoints Executive Council and
Legislative Council . :
Government leader: Sultan Hassanal Bolkiah
Suffrage: universal age 21 and over; 3-tiered system of
indirect elections; popular vote cast for lowest level (district
councilors)
Elections: last elections—March 1965; further elections
postponed indefinitely
Political parties and leaders: antigovernment, exiled
Brunei People’s Party, Chairman A. M. N. ‘Azahari
Communists: information not available
Legal name: Republic of Suriname
Type: Parliamentary Democracy
Capital: Paramaribo
Political subdivisions: 9 districts, each headed by District
Commissioner responsible to Minister of District government
and Decentralization except for Paramaribo, whose commis-
sioner is responsible to Minister of Home Affairs
Legal system: Dutch civil law system; constitution
adopted November 1975
National holiday: Independence Day, 25 November
Branches: President (Chief of State) elected by Parlia-
ment for five-year term; Council of Ministers headed by a
Prime Minister constitutes the Cabinet; 89-member Parlia-
ment popularly elected for 4-year term; court system
administered by Attorney-General under Minister of Justice
and Police
Government leaders: President, Johan H. E. Ferrier;
Prime Minister, Henck Arron
Suffrage: universal over age 21
Elections: every 4 years or earlier upon request of Prime
Minister; latest held October 1977 won by National Party
Combination (NPK), a creole-based election coalition in
which the National Party of Suriname (NPS) is the largest
party :
Political parties and leaders: National Party of Suriname
(NPS), Henck Arron; Nationalist Republic Party (PNR),
Edward Bruma (principal leftist party); Progressive Reform
Party (VHP), J. Lachmon; Pendawa Lima, S. Somohardjo;
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
TOE ea AO EN OO
a At A
eae
AAR AA RAR AA AA Ae A Ue A ee AA ne A CR RUA ALE AACR AGU AA AR MA an a A JRA
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
SURINAME/SWAZILAND
Javanese Farmets’ Party (KTPI), Willy Soemita; Progressive
Suriname People’s Party (PSV), Emile Wijntuin; Reformed
Progressive Party (HPP), Pannalal Parmessar
Voting strength (1977): NPK 22 seats, Opposition United
Democratic Parties Combination (VDP) 17 seats
(all small groups) Democratic Peoples
Front, Communist Party of Suriname (KPS)
Member of: EC (associate), ECLA, IBA, ILO, ITU, OAS,
U.N., UNESCO, UPU, WIPO, WMO','37312d18121a37fd464a53c904812b2d5523af40cee017514112ee00991b2a5e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7968422273df4fc956fc4dcb360e58b982287811efe1440c790e3f510674e8aa',1966,'BW','Botswana','government',78,'Legal name: Republic of Botswana
Type: parliamentary republic; independent member of
Commonwealth since 1966
Capital: Gaborone
Political subdivisions: 12 administrative districts
Legal system: based on Roman-Dutch law and local
customary law; constitution came into effect 1966; judicial
review limited to matters of interpretation; legal education
at University of Botswana and Swaziland (24% years) and
University of Edinburgh (2 years); has not accepted
compulsory ICJ jurisdiction
National holiday: 30 September
Branches: executive—President appoints and presides
over the cabinet which is responsible to Legislative
Assembly; legislative—Legislative Assembly with 32 popu-
larly elected members and 4 members elected by the 32
representatives, House of Chiefs with deliberative powers
only; judicial—local courts administer customary law, High
Court and subordinate courts have criminal jurisdiction over
all residents, Court of Appeal has appellate jurisdiction
Government leader: President, Sir Seretse M. Khama
Suffrage: universal, age 21 and over
Elections: general elections held 26 October 1974
Political parties and leaders: Botswana Democratic Party
(BDP), Seretse Khama; Botswana National Front (BNF),
Kenneth Koma; Bechuanaland People’s Party (BPP), Philip
Matante; Botswana Independence Party (BIP), Motsamai
Mpho
Voting strength: (October 1974 election) BDP (27 seats);
BPP (2 seats); BNF (2 seats); BIP (1 seat)
Communists: no known Communist organization; Koma
of BNF has long history of Communist . contacts
23
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
BOTSWANA/BRAZIL
Member of: AFDB, Commonwealth, FAO, G-77, GATT
(de facto), IBRD, IDA, IMF, ITU, NAM, OAU, U.N., UPU,
WMO
Legal name: Colony of Southern Rhodesia
Type: self-proclaimed independent state since 1965 (not
recognized by U.S.); provisional settlement with U.K. in
November 1971 cancelled by U.K. in May 1972 in response
to Pearce Commission’s conclusion -that its terms were
unacceptable to the majority of black Rhodesians. A
conference in Geneva in late 1976, failed to agree on a new
multiracial interim government in Rhodesia to govern the
country during a transition to black majority rule. In March
1978, Prime Minister Smith and three black nationalist
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
ee ee ES. ae er ON
ee a ee a er ee
OM ee eS RS ae
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
RHODESIA/ROMANIA
leaders set up an interim government to prepare for transfer
to black majority rule by 31 December 1978. The interim
goverment has not been recognized by the U.S. and U.K.,
who are attempting to negotiate a settlement that will
include external nationalist leaders.
Capital: Salisbury
Political subdivisions: 1] magisterial districts
Legal system: Smith government implemented a republi-
can constitution on 2 March 1970 which institutionalized
white rule
Branches: President Wrathall is ceremonial head of state;
executive council (cabinet) lead by Prime Minister Smith;
National Assembly gives highly disproportionate representa-
tion to white minority—50 white constituency seats and 16
black constituency seats
Government leaders: Prime Minister Jan Smith, Acting
‘President J. W. Pithey
Suffrage: franchise is based on income, property holdings,
and education; there are separate rolls for Africans and
non-Africans
Elections: must be held every 5 years
Political parties and leaders: Rhodesian Front, Prime
Minister Smith; Rhodesian Action Party, Ian Sandeman;
National Unifying Force, Allan Savory; Zimbabwe United
People’s Organization, Jeremiah Chirau; United African
National Council, Bishop Abel Muzorewa; Zimbabwe
African National Union, Ndabaningi Sithole
Voting strength (1977 elections): Rhodesian Front won all
50 white constituency seats in Parliament in August 1977
elections
Communists: negligible
Other pressure groups and leaders: external black
nationalists Joshua Nkomo and Robert Mugabe are loosely
allied in the Patriotic Front
Member of: ITU','7143edf7d00de661ac00d4fd0b175158f5490766d70b3e9e6e4028f89d170df6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de5cbfcbe490a4749f8e7ba7241e48e7bb1e4542feb423dd98e4a21c6eb880ac',1966,'BI','Burundi','government',83,'Legal name: Republic of Burundi
Type: republic; military government overthrown by
military coup, November 1976; constitution abolished
Capital: Bujumbura
Political subdivisions: 8 provinces, subdivided into 18
arrondissements and 78 communes; Bujumbura city (popula-
tion est. 160,000) has status equal to a province
Legal system: based on German and French civil codes
and customary law; has not accepted compulsory ICJ
jurisdiction
National holiday: Independence Day, 1 July
Branches: Supreme Revolutionary Council is governing
body
Government leader: Col. Jean-Baptiste Bagaza, Chairman
of Supreme Revolutionary Council, established November
1976
Elections: last legislative election May 1965; legislature
dissolved in 1966
Political parties and leaders: National Party of Unity and
Progress (UPRONA), a Tutsi led party, declared sole
legitimate party in 1966
Communists: no Communist party; resumed diplomatic
relations with the People’s Republic of China in October
1971 following a six-year suspension; U.S.S.R., North Korea,
and Romania also have diplomatic missions in Burundi
29
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
BURUNDI/CAMEROON
Member of: AFDB, EAMA, ECA, FAO, G-77, GATT,
IBRD, ICAO, ICO, IDA, ILO, IMF, ITU, NAM, OAU, U.N,
UNESCO, UPU, WHO, WMO, WTO','4b017cef6941e8b028cc572e7fb724e58ccf64a4c6a74c047b4bc2d90138446a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97e0b7686284bac6a1268f5a4a76c609a08e06dd31263a6a366d746ccde2a9dc',1966,'GA','Gabon','government',88,'Legal name: United Republic of Cameroon
Type: unitary republic; one-party presidential regime
Capital: Yaounde
Political subdivisions: 7 provinces divided into 39
departments
Legal. system: based on French civil law system, with
common law influence; new unitary constitution adopted
1972; judicial review in Supreme Court, when a question of
constitutionality is referred to it by the President of the
Republic; has not accepted compulsory ICJ jurisdiction
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Fa a ae
|
“RA Aa maAlem_AT
a, ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
CAMEROON/CANADA
National holiday: National Day, 20 May
Branches: executive. (President), legislative (National
Assembly), and judicial (Supreme Court) ;
Government leader: President Ahmadou Ahidjo
Suffrage: universal over age 21
Elections: presidential elections held 5 April 1975; —
parliamentary elections held 28 May 1978
Political parties and leaders: single party, Cameroonian
National Union (UNC), President Ahmadou Ahidjo
Communists: no Communist Party or significant number
of sympathizers
Other political or pressure groups: Cameroon Peoples
Union (UPC), an illegal terrorist group now reduced to
scattered acts of banditry with its factional leaders in exile
Member of: AFBD, EAMA, ECA, EIB (associate), FAO,
G-77, GATT, IAEA, IBRD, ICAC, ICAO, ICO, IDA, IFC,
ILO, IMCO, IMF, IPU, ISO, ITU, Lake Chad Basin
Commission, NAM, Niger River Commission, OAU,
UDEAC, U.N., UNESCO, UPU, WHO, WIPO, WMO,
WTO
Legal name: Gabonese Republic
Type: republic; one-party presidential regime since 1964
Capital: Libreville
‘Political subdivisions: 9 provinces subdivided into 36
prefectures .
Legal system: based on French civil law system and
customary law; constitution adopted 1961; judicial review of
legislative acts in Constitutional Chamber of the Supreme
Court; legal education at Center of Higher and Legal Studies
at Libreville; compulsory ICJ jurisdiction not accepted
National holiday: 17 August
Branches: power centralized in President, elected by
universal suffrage for 7-year term; unicameral 70-member
National Assembly has limited powers; judiciary
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
PPR ALA
aie,
EN OS ee Ne ee a ee ee, Se ee
OR ee ee ee ee er Oe ee ee ee ee EN Ee ee EO ee eee a NO a ee ee ee a RE ee ee ee Lee.
Ne ee ee EE ee ee ee ae ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
GABON/THE GAMBIA
Government leader: President El Hadi Omar Bongo
Suffrage: universal over age 2]
Elections: Presidential and parliamentary elections last
held February 1973
. Political parties and leaders: Gabonese Democratic Party
(PDG) led by President Bongo is only legal party
Communists: no organized party; probably some Com-
munist sympathizers
Member of: AFDB, Conference of East and Central
African States, EAMA, EIB (associate), FAO, G-77, GATT,
IAEA, IBRD, ICAO, ICO, IDA, IFC, ILO, IMF, IPU, ITU,
NAM, OAU, OPEC, UDEAC, U.N., UNESCO, UPU, WHO,
WIPO, WMO, WTO
Legal name: Republic of The Gambia
Type: republic; independent since February 1965
Capital: Banjul
Political subdivisions: Banjul and 5 divisions
Legal system: based on English common law and
customary law; constitution came into force upon independ-
ence in 1965, new republican constitution adopted in April
1970; accepts compulsory ICJ jurisdiction, with reservations
National holiday: 18 February
Branches: cabinet of 10 members; 44-member House of
Representatives, in which 4 seats are reserved for chiefs, 4
are appointed, 35 are filled by election for 5-year terms, a
Speaker is elected by the House, and the Attorney General is
an appointed member; independent judiciary
Government leader: Sir Alhaji Dawda Kairaba Jawara,
President
Political parties and leaders: People’s Progressive Party
(PPP), Sécretary General Dawda K. Jawara, United Party
(UP), John Forster, and National Convention Party, Sherrif
Dibba
Suffrage: universal adult
Elections: general elections held April 1977; PPP 29 seats,
NCP 5 seats, UP 1 seat
Communists: insignificant number
Member of: AFBD, APC, Commonwealth, ECA,
ECOWAS, FAO, G-77, GATT, IBRD, IDA, IMF, NAM,
OAU, U.N., WHO, WTO
Legal name: German Democratic Republic
Type: Communist state
Capital: East Berlin (not officially recognized by U.S.,
U.K., and France, which together with the U.S.S.R. have
special rights and responsibilities in Berlin)
Political subdivisions: (excluding East Berlin) 14 districts
(Bezirke), 218 counties (Kreise), 7,643 communities
(Gemeinden)
Legal system: civil law system modified by Communist
legal theory; new constitution adopted 1974; court system
parallels administrative divisions; no judicial review of
legislative acts; legal education at Universities of Berlin,
Leipzig, Halle and Jena; has not accepted compulsory ICJ
jurisdiction; more stringent penal code adopted 1968,
amended in 1974 ;
National holiday: Foundation of German Democratic
Republic, 7 October
Branches: legislative—Volkskammer (elected directly);
executive—Chairman of Council of State, Chairman of
Council of Ministers, Cabinet (approved by Volkskammer);
judiciary—Supreme Court; entire structure dominated by
Socialist Unity (Communist) Party
Government leaders: Chairman, Council of State, Erich
Honecker (Head of State); Chairman, Council of Ministers,
Willi Stoph (Premier)
Suffrage: all citizens age 18 and over
Elections: national every 5 years; prepared by an electoral
commission of the National Front; ballot supposed to be
secret and voters permitted to strike names off ballot; more
candidates than offices available; parliamentary elections
held 17 October 1976
Political parties and leaders: Socialist Unity (Commu-
nist) Party (SED), headed. by General Secretary Erich
Honecker, dominates the regime; 4 token parties (Christian
Democratic Union, National Democratic Party, Liberal
Democratic Party, and Democratic Peasant’s Party) and an
‘amalgam of special interest organizations participate with
the SED in National Front ;
Voting strength: 1976 parliamentary elections: 99.86%
voted the regime slate; 1970 local elections: 99.85% voted the
regime slate
Communists: 1.9 million party members.
Other special interest groups: Free German Youth, Free
German Trade Union Federation, Democratic Women’s
Federation of Germany, German Cultural Federation (all
Communist dominated)
Member of: CEMA, ICES, IPU, ITU, U.N., UNESCO,
UPU, Warsaw Pact, WHO, WIPO; WTO
Legal name: Federal Republic of Germany
Type: federal republic
Capital: Bonn
Political subdivisions: 10 Laender (states); Western
sectors of Berlin are ultimately controlled by U.S., U.K., and
France which, together with the U.S.S.R., have special rights
and responsibilities in Berlin
Legal system: civi] law system with indigenous concepts;
’ constitution adopted 1949; judicial review of legislative acts
in the Supreme Federal Constitutional Court; has not
accepted compulsory ICJ jurisdiction
Branches: bicameral parliament—Bundesrat (upper
house), Bundestag (lower house); President (titular head of
state), Chancellor . (executive head of government);
independent judiciary
Government leaders: President, Walter Scheel; Chancel-
lor, Helmut Schmidt leads coalition of Social Democrats and
Free Democrats
Suffrage: universal over age 18
Elections: next national election scheduled for fall of 1980
Political parties and leaders: Christian Democratic
Union/Christian Social Union (CDU/CSU), Helmut Kohl,
Franz-Josef Strauss, Karl Carstens, Kurt Biedenkopf; Social
Democratic Party. (SPD), Willy Brandt, Hans Koschnick,
Helmut Schmidt; Free Democratic Party (FDP), Hans-Die-
trich Genscher, Hans Friderichs, Wolfgang Mischnick;
National Democratic Party (NPD), Martin Mussgnug;
Communist Party (DKP), Herbert Mies ;
Voting strength (1976 election): 42.6% SPD, 48.6%
CDU/CSU, 7.9% FDP, 0.9% Splinter groups of left and right
(no parliamentary representation)
Communists: about 40,000 members and supporters
Other political or pressure groups: expellee, refugee, and
veterans groups
Member of: ADB, Council of Europe, DAC, EC, ECSC,
EJB, ELDO, EMA, ESRO, EURATOM, FAO, GATT, IAEA,
IBRD, ICAC, ICAO, ICES, ICO, IDA, IEA, IFC, IHO, ILO,
International Lead and Zinc Study Group, IMCO, IMF, IPU,
ITC, ITU, NATO, OAS (observer), OECD, U.N., UNESCO,
UPU, WEU, WHO, WIPO, WMO, WSG, WTO
Legal name: Democratic Republic of Sao Tome and
Principe
Type: republic established when independence received
from Portugal in July 1975; constitution adopted December
1975 ;
Capital: Sao Tome
Legal system: based on Portuguese law system and
customary law; has not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 12 July
Branches: Da Costa heads the government assisted by a
cabinet of ministers
Government leaders: President Manuel] Pinto da Costa,
Prime Minister Miguel Trovoada
Suffrage: universal for age 18 and over
Elections: elections were held July 1975 for the President
Political parties and leaders: Movement for the Liber-
ation of Sao Tome and Prineipe (MLSTP), Secretary-General
Manuel Pinto Da Costa
Communists: no Communist party, probably a few
Communist sympathizers :
Member of: G-77, NAM, OAU, U.N.','f74e1d6b670a6b9fb1358e086ad3434a15c74345ad963d5179b77a3a3c737c6e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcb1cd6bbbef0ada9763ebdfcc083fff37b8e47895da79ca4f1231a226426ff6',1966,'CA','Canada','government',92,'Legal name:. Canada
Type: federal state recognizing Elizabeth II as sovereign
Capital: Ottawa
Political subdivisions: 10 provinces and 2 territories
Legal system: based on English common law, except in’
Quebec, where civil law system based on French law
prevails; constitution is British North America Act of 1867
and various amendments; accepts compulsory ICJ jurisdic-
tion, with reservations
National holiday: Dominion Day, 1 July
Branches: federal executive power vested in cabinet
collectively responsible to House of Commons, and headed
by Prime Minister; federal legislative authority resides in
Parliament consisting of Queen represented by Governor-
General, Senate, and Commons; judges appointed by
Governor-General on the advice of the government;
Supreme Court is highest tribunal
Prime Minister Pierre Elliott
Trudeau; Governor General Jules Léger
Government leaders:
Suffrage: universal over age 18
Elections: legal limit of 5 years but in practice usually
held within 4 years, last election July 1974
Political parties and leaders: Liberal, Pierre Trudeau;
Progressive-Conservatives, Joe Clark; New Democratic,
Edward Broadbent; Social Credit, Lorne Reznowski
Voting strength (1974 election (numbers in parens
indicate current party strengths in Parliament)): Liberal
43% (136 seats), Progressive Conservative 35% (97 seats),
New Democratic Party 16% (17 seats), Social Credit 5% (9
seats), other 1%, Independents hold 5 seats; Parliament
enlarged from 264 seats to 282 seats but new seats will not be
filled until next general election expected in 1979
Communists: 2,000 approx.
Member of: ADB, Colombo Plan, Commomwealth, DAC,
FAO, GATT, IAEA, IBRD, ICAO, ICES, ICO, ICRC, IDA,
IDB, IEA, IFC, IHO, ILO, International Lead and Zinc
Study Group, IMCO; IMF, IPU, ISO, ITC, ITU, IWC—
International Whaling Commission, I[WC—lInternational
Wheat Council, NATO, OAS (observer), OECD, U.N,
UNCTAD, UNESCO, UPU, WHO, WIPO, WMO, WSG
Legal name: Republic of Cape Verde
National holiday: 12 September
Type: republic; achieved independence from Portugal in
July 1975
Capital: Praia ;
Political subdivisions: 10 islands
Legal system: to be determined
National holiday: 12 September
Branches: National Assembly, 56 members; the official
party is the supreme political institution
Government leaders: President, Aristides Pereira; Prime
Minister, Pedro Pires; Minister of Foreign Affairs, Abilio
Duarte
Suffrage: universal over age 18
Elections: to be determined
Political parties and leaders: only legal party, Partido
Africano da Independencia da Guinee e Cabo Verde
(PAIGC), led by Aristides Pereira, Secretary-General
Communists: a few Communists, some sympathizers
Member of: G-77, NAM, OAU, U.N.
Legal name: Central African Empire
Type: constitutional monarchy, founded on a single party
34
’ . January 1979
Capital: Bangui :
Political subdivisions: 14 prefectures, 47 subprefectures
Legal system: based on French law; in 1966 the Chief of
State assumed all power and abrogated the constitution; in
1976 he promulgated a new constitution; has not accepted
compulsory ICJ jurisdiction
National holiday: 4 December
Branches: Emperor Bokassa is Chief of State and rules by
decree; government is headed by a Prime Minister assisted
by the Council of Ministers; judiciary, Supreme Court, court
of appeals, criminal court, and numerous lower courts;
constitution calls for a National Assembly
Government leader: Emperor Bokassa I
Suffrage: universal over age 21
Elections: none have been held yet under Bokassa regime;
provided for in new constitution
Political parties and leaders: Movement for the Social
Evolution of Black Africa (MESAN), ruling party under
former regime, continues as a key body for ‘organizing
support for the regime led by Emperor Bokassa
Communists: no Communist Party or significant number
of sympathizers
Member of: AFDB, Conference of East and Central
African States, EAMA, ECA, FAO, G-77, GATT, IBRD,
ICAO, ICO, IDA, ILO, IMF, ITU, NAM, OAU, OCAM,
UDEAC, U.N., UNESCO, UPU, WHO, WMO
Legal name: Republic of Chad
Type: republic; New Government of National Union
formed August 1978
Capital: N’Djamena
Political subdivisions: 14 prefectures
Legal system: based on. French civil law system and
Chadian customary law; constitution adopted 1962; constitu-
tion suspended and national assembly dissolved April 1975:
judicial review of legislative acts in theory a power of the
Supreme Court; has not accepted compulsory ICJ juris-
diction
National holiday: 13 April
Branches: Presidency; Council of Ministers; Prime Minis-
ter; Committee of Defense and Security; and Council. of
National Union
Government leader: President General Felix Malloum;
Prime Minister Hissein Habre
Suffrage: universal
Elections: all political activity banned
Political parties and leaders: political parties banned
Communists: no front organizations or underground
party; probably a few Communists and some sympathizers
Other political or pressure groups: armed Muslim rebel
bands have been opposing the government since October
1965 in east-central, and since August 1969 in northern.
Chad; rebels. currently control the northern half of the
country; as a result of reconciliation negotiations with rebel
groups, some were integrated into the central government to
form the New Government of National Union
Member of: AFDB, Conference of East and Central
African States, EAMA, ECA, EEC (associate), FAO, G-77,
GATT, ICAC, ICAO, IBRD, IDA, ILO, IMF, ITU, Lake
35
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
CHAD/CHILE
Chad Basin Commission, NAM, OAU, OCAM, UEAC, U.N.,
UNESCO, UPU, WHO, WIPO, WMO','9e56b3e1a87f2760b88a35ce01469a37c16c69f8a785fdcf5509b0b8ec6655f9','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdd4e933d3340f4aabada7dcf6a3b2dd5651d0876b5bb77fd65bbcb6203798c9',1966,'CL','Chile','government',96,'Legal name: Republic of Chile
Type: republic
Capital: Santiago
Political subdivisions: 12 regions plus one metropolitan
district, 41 provincial subdivisions.
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
4
4
¢
‘
{
{
At OR ARO LAR LP Aa ALA
i ie i
rn ae
a aa I a ea aa a A cael li OS i i I a ce a re a aaa i a a al
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Legal system: based on Code 1857 derived from Spanish
law and subsequent codes influenced by French and
Austrian law; constitution adopted 1925, amended since
then, currently being revised; judicial review of legislative
acts in the Supreme Court; legal education at University of
Chile, Catholic University, and several others; has not
accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 18 September
Branches: four-man Military-Police Junta, which exer-
cises constituent and legislative powers and has delegated
executive powers to President of Junta; the President has
announced a plan for transition from military to civilian rule
by 1985; Congress dissolved; civilian judiciary remains’
Government leader: President, Gen. Augusto PINO-
CHET Ugarte; other Junta members, Adm. Jose Toribio
MERINO Castro, Brig. Gen. Fernando MATTHEI Aubel,
Gen. Cesar MENDOZA Duran
Suffrage: none
Elections: prohibited by decree; all electoral registers
were destroyed in 1974
Political parties and leaders: Christian Democratic Party
(PDC), Andres Zaldivar and Eduardo Frei; National Party
(PN), Sergio Onofre Jarpa; PDC and (PN) are officially
banned; Popular Unity coalition parties (outlawed)—
Communist Party (PCCh), Luis Corvalan (in exile); Socialist
Party (PS), Clodomiro Almeyda and Carlos Altamirano
(both in exile); Radical Party (PR); Christian Left (IC);
United Popular Action Movement (MAPU); Independent
Popular Action (API)
Voting strength (1970 presidential election): 36.6%
Popular Unity coalition, 35.3% conservative independent,
28.1% Christian Democrat; (1973 Congressional election)
44% Popular Unity coalition, 56% Democratic Confeder-
ation (PDC and PN)
Communists: 248,000 when PCCh was legal in 1973;
active militants now estimated at about 20,000
Other political or pressure groups: organized labor;
business organizations; landowners’ associations (SNA—
Sociedad Nacional de Agricultural); Catholic church; ex-
treme leftist, Movement of Revolutionary Left (MIR),
outlawed; rightist, Patria y Libertad (PyL), outlawed
Member of: CIPEC, ECOSOC, FAO, G-77, GATT,
IADB, IAEA, IBRD, ICAO, IDA, IDB, IFC, IHO, ILO,
IMCO, IMF, IPU, ITU, LAFTA, OAS, SELA, U.LN.,
UNESCO, UPU, WHO, WIPO, WMO, WSG, WTO','fab4cf88022a898fab9f848158b64b15d6bf84f431a669cea9d1f9b602a5ec52','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed574f88562e5679ff87a4a938b3515a863b992aaa801eec38f16f8291be2f58',1966,'CN','China','government',100,'Legal name: People’s Republic of China
Type: Communist state; real authority lies with Commu-
nist party’s political bureau; the National People’s Congress,
in theory the highest organ of government, in reality merely
rubber stamps the party’s programs; the State Council is the
actual governing organism
Capital: Beijing (Peking)
Political subdivisions: 21 provinces, 3 centrally governed
municipalities, and 5 autonomous regions
Legal system: before 1966, a complex amalgam of custom
and statute, largely criminal; little ostensible development of
uniform code of administrative and civil law; highest judicial
organ is Supreme People’s Court although legal activity
centered in parallel network of Public Security organs; laws
and legal procedure clearly subordinated to priorities of
party policy; whole system largely suspended during
Cultural Revolution, but has been revived
National holiday: National Day, 1 October
Branches: prior to 1966 control was exercised by Chinese
Communist Party, through State Council, which supervised
more than 50 ministries, commissions, bureaus, etc., all
technically under the standing committee of the National
People’s Congress; this system broke down under “Cultural
Revolution” pressures but has been reconsolidated and
streamlined to 37 ministries
Government leader: Premier of State Council, Hua
Guofeng (Kuo-feng); government subordinate to central
committee of CCP, under Chairman Hua Guofeng
Suffrage: universal over age 18, though this is academic
Elections: no meaningful ‘elections
Political parties and leaders: Chinese Communist Party
(CCP), headed by Hua Guofeng; Hua is Chairman of
Central Committee; a new central committee was formed at
the llth Party Congress held in August 1977
Voting strength: 100% Communist for practical purposes;
no political nonconformity permitted
Communists: about 35 million party members in 1977
Other political or pressure groups: army (PLA) remains a
major force, although many soldiers who acquired a wide
range of civil political-administrative duties during the
Cultural Revolution have been removed; many veteran
civilian officials, in eclipse since the Cultural Revolution,
have been reinstated; mass organizations, such as the trade
unions and the youth league, have been rebuilt
Member of: FAO, IAEA, IBRD, ICAO, IDA, IFC, IHO,
ILO, IMCO, IMF, ITU, Red Cross, U.N., UNESCO, UPU,
WHO, WMO, other international bodies
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
yr Oa ee ae ee ee
wey ae ay ae a eS
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
CHINA/TAIWAN
Legal name: Taiwan
Type: one-party presidential regime
Capital: Taipei
Political subdivisions: 16 counties, 4 cities, 1 special
municipality (Taipei)
Legal system: based ‘on civil law system; constitution
adopted 1947, amended 1960 to permit Chiang Kai-shek to
be reelected, and amended 1972 to permit President to
restructure certain government organs; accepts compulsory
IC) jurisdiction, with reservations
Branches: 5 independent branches (executive, legislative,
judicial, plus traditional Chinese functions of examination .
and control), dominated by executive branch; President and
Vice President elected by National Assembly
Government leaders: President Chiang Ching-kuo; Pre-
mier Sun Yun-hsuan
Suffrage: universal over age 20
‘Elections: national level—legislative yuan every 3 years
but no general election held since 1948 election on mainland
(partial elections for Taiwan province representatives
December 1969, December 1972, and December 1975);
local level—provincial: assembly, county and municipal
executives every 4 years; county and municipal assemblies
every 4 years
Political parties. and leaders: Kuomintang, or National
Party, led by Chairman Chiang Ching-kuo, had no real
opposition; lately a loosely organized anti-Kuomintang
opposition has emerged; 2 insignificant parties are Demo-
cratic Socialist Party, Young China Party
Voting strength (1972 provincial assembly election): 58
seats Kuomintang, 13 seats independents
Other political or pressure groups: none
Member of: expelled from U.N. General Assembly and
Security Council on 25 October 1971 and withdrew on same
date from other charter-designated subsidiary organs;
attempting to retain membership in international financial
institutions, ICAC, ISO, IWC-International Wheat Council
Legal name: Republic of Korea
Type: republic; power centralized in a strong executive
Capital: Seoul
Political subdivisions: 9 provinces, 2 special cities; heads
centrally appointed
Legal system: combines elements of continental Europe-
an civil law systems, Anglo-American law, and Chinese
classical thought; constitution approved 1972; has not
accepted compulsory IC] jurisdiction
National holiday: 15 August
Branches: executive, legislative (unicameral), judiciary,
National Conference of Unification
Government leaders: President Pak Chong-hui; Prime
Minister Choe Kyu-ha
Suffrage: universal over age 20
Elections: presidential every 6 years indirectly by the
National Conference of Unification, last election May 1978;
two-thirds of the 219-member National Assembly is elected
directly for the same period within six months of the
presidential election, remaining third nominated: by the
President and elected by the National Conference for a
three-year term; last election February 1973, Revitalization
Group—73 seats, Democratic Republican Party—68 seats,
New Democratic Party—55 seats, Democratic Unification
Party—3 seats, Independents—15 seats; National Assembly
election Décember 1978
113
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDPO8-00534R000100140001-7
KOREA, SOUTH/KUWAIT
Political parties and leaders: pro-government—Revital-
ization Group (appointed) (Chairman, Paek Tu-Chin) and -°
Democratic Republican Party (Acting Chairman, Yi
Hyo-sang); New Democratic Party (Chairman, Yi Chol-
sung); Democratic Unification (Chairman, Yang II-tong)
Voting strength: (1973 election) popular vote 11,896,484;
DRP 38.8%, NDP 32.8%, DUP 10.2%, Independent 18.1%,
0.1% invalid
Communists: Communist activity banned by govern- -
ment; an iiaane 37,000-50,000 former members and
supporters
Other political or pressure groups: Federation of Korean
Trade Unions; Korean Veterans’ Association; Korean Nation-
al Christian Council; large potentially volatile - ‘student
population concentrated in Seoul
Member of: ADB, Asian Parliamentary Union, APACL—
Asian People’s Anti-Communist League, ASPAC, Colombo
Plan, ESCAP, FAO, G-77, GATT, Geneva Conventions of
1949 for the protection of war victims, IAEA, IBRD, ICAC,
‘ICAO, IDA, IFC, IHO, IMCO, IMF, INTELSAT, INTER-
POL, IPU, ITU, IWC—International Wheat Council,
UNESCO, U.N. Special Fund, UPU, WACL—World Anti-
Communist League, WHO, WMO, WTO; official observer
at U.N., does not hold U.N. membership','1e80a19b4340fd3469b300a62d6c939d58b6830fa8c96e934417725f70b72729','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc3e2189ac0b4ba9bd15a5b5b3b3beca020689e55602fc41803ae7b2a6b6e5c6',1966,'CO','Colombia','government',104,'Legal name: Republic of Colombia
Type: republic; executive branch dominates government
structure
Capital: Bogota
Political subdivisions: 22 departments, 3 Intendants, 5
Commissariats, Bogota Special District
Legal system: based on Spanish law; religious courts
regulate marriage and divorce; constitution decreed in 1886,
amendments codified in 1946 and 1968; judicial review of
legislative acts in the Supreme Court; accepts compulsory
IC) jurisdiction, with reservations
National holiday: Independence Day, 30 July
Branches: President, bicameral legislature, judiciary
Government leader: President Julio César TURBAY
Ayala
Suffrage: universal over age 2]
Elections: every fourth year; last presidential and
congressional] elections June 1978; municipal and depart-
mental elections, February 1978
Political parties and leaders: Liberal Party, President
Julio César Turbay; Conservative Party, Alvaro Gomez
Hurtado; Alianza Nazional Popular, Maria Eugenia Rojas de
Moreno 7
Voting strength: 1978 presidential election—Julio César
Turbay 49%, Belisario Betancur 46%, Gen. Alvaro Valencia
1.3%; 1978 municipal election, 55% Liberal Party, 36%
Conservative Party, 9% combined far left parties; 70%
abstention of. eligible voters
Communists: 10,000-12,000 members est.
Other political or pressure groups: Communist Party
(PCC), Gilberto Vieira White; PCC/ML, Chinese Line
Communist Party
Member of: FAO, G-77, IADB, IAEA, IBRD, ICAC,
ICAO, ICO, IDA, IDB, IFC, IHO, ILO, IMF, ISO, ITU,
LAFTA and Andean Sub-Regional Group (created in May
1969 within LAFTA), OAS, SELA, U.N., UNESCO, UPEB,
UPU, WHO, WMO, WSG, WTO
Legal name: Netherlands Antilles
Type: territory within Kingdom of the Netherlands,
enjoying complete domestic autonomy
Capital: Willemstad, Curacao
Political subdivisions: 4 island territories—Aruba, Bon-
aire, Curacao, and the Windward Islands—St. Eustatius,
southern part of St. Martin (northern part is French), Saba
Legal system: based on Dutch civil law system, with some
English common law influence; Constitution adopted 1954
Branches: federal executive power rests nominally with
Governor (appointed by the Crown), actual power exercised
by 8-member Council of Ministers or cabinet presided over
by Minister-President; legislative power rests with 22-mem-
ber Legislative Council; independent court system under
control of Chief Justice of Supreme Court of Justice
(administrative functions under Minister of Justice); each
island territory has island council headed by Lieutenant
Governor ‘ ;
Government leader: Minister-President Silvius G. M.
Rozendal ,
Suffrage: universal age 18 and over
Elections: Federal elections held every 4 years, last held
17 June 1977; Island council elections every 4 years, last held
April and May 1975
Political parties and leaders: political parties are
indigenous to each island:
Curacao: Democratic Party (DP), S. G. M. Rozendal;
National People’s Party-United (NVP-U) Edsel Jenerun;
Frente Obrero de Liberation’ 30 di Mayo (FOL), Wilson
“Papa” Godett; Social Democratic Party (PSD), R. J. Isa
‘Bullennbaai); 6 minor
Aruba: People’s Electoral Movement (MEP), G. F..
“Betico” Croes; Aruban Patriotic Party (PPA), L. O. Chance;
Aruban People’s Party (AVP), D. G. Croes
Bonaire: Labor Party (POB); Democratic Party Bonaire
(UPB); New Democratic Action (ADEN)
Windward Islands: Windward Islands Democratic
Party (DPWI); United Federation of Antillean Workers
(UFA); Windward Islands Political Movement (WIPM); and
others
Voting strength: (1977 federal election) 6 seats DP, 5 seats
MEP, 3 seats FOL, 3 seats NVP, 3 seats PPA, 1 seat DPWI, 1
seat UPB |
Communists: no Communist Party
Member of: EC (associate), WHO','001e4dca18d03288233ac449786c9f6669cf8158b9854cf9dc53105b60932c7e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8fc9840a2a14f074b7754ece78e3be1b68de0736b7880307673a22eef76a52c',1966,'MG','Madagascar','government',109,'Legal name: Federal and Islamic Republic of the
institutions; new constitution accepted by referendum in
December 1975; legal education at National School of Law,
University of Madagascar; has not accepted compulsory ICJ
jurisdiction
National holiday: Independence Day, 26 June
Branches: executive—a 21-member Supreme Revolution-
ary Council (made up of. military and political leaders);
assisted by cabinet called Council of Ministers; People’s
National Assembly; Military Committee for Development;
regular courts are patterned after French system, and a High
Council of Institutions reviews all legislation to determine its
constitutional validity
Government leader: Commander Didier Ratsiraka,
President
Suffrage: universal for adults (18 and above)
Elections: referendum held in December 1975 gave
overwhelming approval to government and new constitu-
tion; elections for People’s National Assembly held in June
1977; only one political grouping allowed to take part in the
election, “The Front for the Defense of Malagasy Socialist
Revolution,” which presented a single list of candidates
Political parties and leaders: 6 parties are now allowed
political activity under the National Front and are
represented on the Supreme Revolutionary Council; the 6
parties are: AREMA (President Ratsiraka’s Advance Guard
of the Malagasy Revolution); AKFM (Pastor Richard
Andriamanjato’s pro-Soviet Congress Party for Malagasy
Independence); VONJY (Dr. Pazanabahiny Marojama’s
Movement for National Unity); UDECMA (Norbert Andria-
morasata’s Malagasy Christian Democratic Union); MFM
(Manandafy Rakotonirina’s Militants for the Establishment
of a Proletarian Regime); MONIMA (Mouvement Nationale
pour L’Independence de Madagascar) party apparently split
over issue of joining’ National Front, leader of faction
supporting Front unknown, Monja Jaona leads other faction
Voting strength: number of registered voters (1977)—3.5
million, in 1977 local elections, President Ratsiraka’s
AREMA captured approximately 89.5% of the 73,000
available positions on 11,400 local Executive Committees;
AKFM won about 7.3% of the seats, MONIMA 1.7%, and
VONJY 1.4%; UDECMA won only about 45 seats
Communists: Communist party of virtually no impor-
tance; small and vocal group of Communists has gained
strong position in leadership of AKFM, the rank and file of
which is non-Communist
_ Member of: EAMA, FAO, G-77, GATT, IAEA, IBRD,
ICO, IFC, ILO, IMF, ISO, ITU, NAM, OAU, OCAM, U.N.,
UNESCO, WHO; WMO, WTO','99876d17fb76e2d22ab69875ec20cbd9c54473b51c495aa7a6ca1585b98134f1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c7f8cf59590b25683e826dddd37ef3ea6c26ed24863c69c930fd3b3df7c996e',1966,'KM','Comoros','government',110,'_ Type: three of the four islands comprise an independent
republic, following local government’s unilateral declaration
of independence from France in July 1975; other island,
Mayotte, disallowed declaration and is now a French
Territorial community
Capital: Moroni
Political subdivisions: the three islands are organized into
7 regions
Legal system: French and Muslim law
Branches: Mohamed Abdallah elected President of the -
Comoros, October 21, 1978, having regained power last May
following a coup, led by French-born mercinary Bob
Denard, which toppled Ali Soilih; Soilih had come to power
in 1977 through a coup that ousted Abdallah; Soilih was
killed in the recent coup
Suffrage: universal adult
Elections: next presidential election scheduled to take
place in 1984 -_
Communists: information not available
Member of: G-77, NAM, OAU, U.N.
ECONOMY 2
GDP: $69.5 million (1975), about $240 per capita; growth
probably negligible through 1974
Agriculture: food crops—rice, manioc, maize, fruits,
vegetables; export crops—essential oils for perfumes (mainly
ylang-ylang), vanilla, copra, cloves
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
BRR mt he Ad
=~ Ae ek A AR A OA
TAR TT EA wR aA ee A A A kn Rm em
ae me
on nn
li Bi i ie i i el
i a a: id
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
COMOROS /CONGO
Exports: $10.3 million (f.0.b., 1976); perfume oils, vanilla,
copra, cloves
Imports: $13.9 million (c.if., 1976); foodstuffs, cement,
fuels, chemicals, textiles
Major trade partners: France, Malagasy Republic, Italy,
Kenya, Tanzania and USS.
Electric power: 2,400 kW capacity (1977); 3 million kWh
produced (1977); 10 kWh per capita
Aid: economic—Western (non-U.S.) countries (1970-76),
$99.1 million, OPEC (ODA) (1973-76), $26.8 million
Budget: 1977 projected—revenues, $4 million; expendi-
tures, $10 million; investment expenditures, $5 million;
deficit, $10 million
Monetary conversion rate: 245.67 Communaute Finan-
riere Africaine (CFA) francs=US$1 in 1977, floating
Legal name: People’s Republic of the Congo
Type: republic; military regime established September
1968 ;
Capital: Brazzaville
Political subdivisions: 9 regions divided into districts
Legal system: based on French civil law system and
customary law; constitution adopted 1973
National holiday: National Day, 15 August
Branches: President, Military Committee, Council of
State; judiciary; all policy made by Congolese Workers Party
Central Committee and Politburo
Government leaders: President, Brigadier General
Joachim Yhombi-Opango; Prime Minister Louis Goma
Suffrage: universal over age 18
Elections: last legislative elections June 1973
Political parties and leaders: Congolese Workers Party
(PCT) is only legal party
Communists: unknown number of Communists and
sympathizers
Other political or pressure groups: Union of Congolese
Socialist Youth (UJSC), Congolese Trade Union Congress
(CSC), Revolutionary Union of Congolese Union (URFC),
General Union of Congolese Pupils and Students (UGEEC)
Member of: AFDB, Conference of East and Central
African States, EAMA, ECA, EIB (associate), FAO, G-77,
GATT, IBRD, ICAO, ICO, IDA, ILO, IMF, ITU, NAM,
43
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
CONGO/COOK ISLANDS
OAU, UDEAC, UEAC, U.N., UNESCO, UPU, WHO,
WIPO, WMO','363196535a15cba35974ee7ab37f5c0cb8c1197890391e8346236912b36d97eb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37ff35d8e87d24c52a765eab329bf27ce53ff82a6a54641a5b5eedfca80a4318',1966,'CK','Cook Islands','government',114,'Legal name: Cook Islands
Type: self-governing in “free association” with New
Zealand; Cook Islands government fully responsible for
internal affairs and has right at any time to move to full
independence by unilateral action; New Zealand retains
responsibility for external affairs, in consultation with Cook
Islands government
Capital: Rarotonga
Branches: New Zealand Governor General appoints
Representative to Cook Islands, who represents the Queen
and the New Zealand government; Representative appoints
the Premier; Legislative Assembly of 22 members, popularly
elected; House of Arikis (chiefs), 15 members, appointed by
Representative, an advisory body only
Government leader: Premier Dr. Tom Davis
Suffrage: universal adult
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
PAL Rom am Mk AR TRA month AAA AA te. PA AA 2
TAWAA aR AA oe 2A A me RA A RA AOA SR A
=o;
Oe lh
“AT
AL Oe OA mr ATR ADR AA
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
COOK ISLANDS/COSTA RICA
Elections: every 4 years, latest in March 1978
Political parties and leaders: Cook Islands Party, Sir
Albert Henry; Democratic Party, Dr. Thomas Davis
Voting strength (1978): Democratic Party, 15 seats, Cook
Islands Party, 6 seats; final seat to be settled','b4383459b58c7a341c005e00befc39a5831153ad995c7b6b188d66cf4abaa6ad','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e7478239cdb1b25625b5f5adc40e3d529a4623caff28ee7f840d3f47376a58b',1966,'CR','Costa Rica','government',118,'Legal name: Republic of Costa Rica
Type: unitary republic
Capital: San Jose
Political subdivisions: 7 provinces
Legal system: based on Spanish civil law system;
constitution adopted 1949; judicial review of legislative acts
in the Supreme Court; legal education at University of Costa
Rica; has not accepted compulsory IC] jurisdiction
National holiday: Independence Day, 15 September
Branches: President,: unicameral legislature, Supreme
Court elected by legislature
Government leader: President Rodrigo CARAZO Odio
Suffrage: universal and compulsory age 18 and over
Elections: every 4 years; next, February 1982
Political parties and leaders: National Liberation Party
(PLN), Daniel Oduber, Luis Alberto Monge, Carlos Manuel
Castillo; Democratic Renovation Party (PRD), Rodrigo
Carazo; Christian. Democratic Party (PDC), Jorge Monge
Zamora; Popular Vanguard Party (PVP, Communist),
Manuel Mora Valverde; Republican Calderonista Party
(PRC), Rafael Angel Calderén Fournier; Popular Union
Party (PUP), San Joaquin Trejos Fernandez; Unity Coalition
composed of the PRD, the PDC, the PUP, and the PRC
45
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
COSTA RICA/CUBA
Voting strength (1978 election): Unity Coalition 43.4%,
27 seats; PLN 38.8%, 25 seats; Leftist Coalition Party (PPU)
7.6%, 3 seats; others, 2 seats
Communists: 3,200 members, 10,000 sympathizers
Other political or pressure groups: Costa Rican Confed-
eration of Democratic Workers (CCTD), General Confeder-
ation of Workers (CGT), Chamber of Coffee Growers,
National Association for Economic Development (ANFE)
Member of: CACM, FAO, IADB, IAEA, IBRD, ICAO,
ICO, IDA, IDB, IFC, ILO, IMF, IPU, ITU, IWC—
International Wheat Council, NAMUCAR (Caribbean Mul-
tinational Shipping Line—Naviera Multinacional del Car-
ibe), OAS, ODECA, SELA, U.N., UNESCO, UPEB, UPU,
WHO, WMO, WTO
Legal name: Republic of Cuba
Type: Communist state
Capital: Havana
Political subdivisions: 14 provinces and 169 munici-
palities
Legal system: based on Spanish and American law, with
large elements of Communist legal theory; Fundamental
Law of 1959 replaced Constitution of 1940; a new
constitution was approved at the Cuban Communist Party’s
First Party Congress in December 1975 and by a popular
referendum which took place on 15 February 1976; portions
of the’ new constitution were put into effect on 24 February
1976, by means of a Constitutional Transition Law, and the
entire constitution became effective on 2 December 1976;
legal education at Universities of Havana, Oriente, and Las
Villas; does not accept compulsory ICJ jurisdiction
National holiday: Anniversary of the Revolution, 1
January
Branches: executive; legislature (National People’s Assem-
bly); controlled judiciary
Government leader: President Fidel CASTRO Ruz
Suffrage: universal, but not compulsory, over age 16
Elections: National People’s Assembly (indirect election)
every five years; election held November 1976
Political parties and leaders: Cuban Communist Party
(PCC), First Secretary Fidel Castro Ruz, Second Secretary
Raul Castro Ruz
Communists: approx. 200,000 party members
Member of: CEMA, ECLA, FAO, G-77, GATT, IADB
(nonparticipant), ICAO, IHO, ILO, IMCO, International
Rice Commission, ISO, ITU, IWC—International Wheat
Council, NAM, NAMUCAR (Caribbean Multinational Ship-
ping Line—Naviera Multinacional del Caribe), OAS (non-
participant), Permanent Court of Arbitration, Postal Union
of the Americas and Spain, SELA, U.N., UNESCO, UPU,
WHO, WIPO, WMO, WSG, WTO
ECONOMY 5
GDP: $8.0 billion (1976 est., in 1976 prices), $840 per
capita; 60% private consumption, 20% public consumption,
20% gross investment, réal growth rate 1976, 3.5%
Agriculture: main crops—sugar, tobacco, coffee,’ rice,
potatoes, tubers, citrus fruits
Fishing: catch 220,000 metric tons (1977); exports $84
million (1977)
Major industries: sugar milling, petroleum refining, food
and tobacco processing, textiles, chemicals, paper and wood
products, metals
Shortages: spare parts for transportation and industrial
machinery, consumer goods
Crude steel: 0.35 million metric tons capacity (planned);
300,000 metric tons produced (1977); 30 kg per capita
Electric power: 1,775,300 kW capacity (1977); 6.6 billion
kWh produced (1977), 700 kWh per capita
Exports: $3.9 billion (f.0.b., 1977 est.); sugar, nickel,
tobacco ;
Imports: $4.2 billion (c.if., 1977 est.); capital goods,
industrial raw materials, food, petroleum
Major trade partners: exports—65% U.S.S.R., 15% other
Communist countries; imports—49% U.S.S.R., 14% other
Communist countries, 6% Spain (1976)
Budget: $11.1 billion
Monetary conversion: rate: 1 peso=US$1.21 (nominal)
Fiscal year: calendar year','a0c6129c6b1162fc79e48f74b12a8fc75d3681d223cdc36bacbe7d7b76ef0b75','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('219b7832a43819b5b80780304cba2056af466a9cbd4a3bc0afb714f6bf0906cd',1966,'CY','Cyprus','government',122,'Legal name: Republic of Cyprus
Type: republic since August 1960; separate de facto Greek
Cypriot, and Turkish Cypriot governments. have evolved
since outbreak of communal strife in 1963; this separation
was further solidified following the Turkish invasion of the
island in July 1974; negotiations, which have been going on
since January 1975, have focused on the creation of a federal
system of government with substantial autonomy for each of
the two communities
48
Capital: Nicosia
Political subdivisions: 6 administrative districts
Legal system: based on common law, with civil law
modifications; negotiations to create the basis for a new or
revised constitution to govern the island and_ relations
between Greek and Turkish Cypriots have been going on
intermittently
National holiday: Independence Day, 1 October
Branches: currently a rump government with effective
authority only over the Greek Cypriot community, consist-
ing of Greek Cypriot parts of bodies provided for by
constitution; headed by President of the Republic and
comprised of Council of Ministers, House of Representatives,
and Supreme Court; Turkish Cypriots have their own
“Constitution” and governing bodies within the “Turkish
Federated State of Cyprus”
Government leaders: Greek Sector: President, Spyros
Kyprianou, elected interim President in September 1977, to
serve out the remainder of the term of Archbishop Makarios
who died on 3 August 1977, and elected President in his own
right by acclamation in February 1978; Turkish. Sector:
“President,” Rauf Denktas; “Prime Minister,” Osman Orek
Suffrage: universal age 2] and over
Elections: officially every 5 years; Turkish Cypriot
“Presidential” and “Parliamentary” elections held June
1976; Greek Cypriot parliamentary elections held in
September 1976
Political parties and leaders: Greek Sector: Restorative
Party of the Working People (AKEL) (Communist Party),
Ezekias Papaioannou; Democratic Rally (DS), Glavkos
Kliridis; Democratic Party (DK) (pro-Makarios), Spyros
Kyprianou; United Democratic Union of the Center
(EDEK), Vasos Lyssaridis; Turkish Sector: National Unity
Party (UBP), Rauf Denktas; Populist Party (HP), Alper
Orhon; Communal Salvation Party (TKP), Alpay Durduran;
Republican Turkish Party (CTP), Ozker Ozgur
Voting strength: Rauf Denktas won the 1976 “Presiden-
tial” contest in the Turkish Cypriot zone with 76% of the
vote and his party won 30 of 40 seats in the “Assembly” with
54% of the vote. In the Greek Cypriot parliamentary
election of September 1976, a pro-Makarios coalition
composed of AKEL, EDEK, and the Democratic Faction
(DF) received 69.5% of the vote and 34 of 35 seats while
Kliridis’ Democratic Rally (DS) won 25% of the vote and no
seats; the remaining seat was given to independent Tasos
Papadopoulos
Communists: 12,000; sympathizers estimated to number
60,000
Other political or pressure groups: United Democratic
Youth Organization (EDON) (Communist-controlled); Pan
Cyprian Labor Federation (PEO) (Communist-controlled);
Confederation of Cypriot Workers (SEK) (pro-West);
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
CYPRUS /CZECHOSLOVAKIA
Federation of Turkish Cypriot Labor Unions (KTIBF):
Confederation of Revolutionary Labor Unions (DISK)
Member of: Commonwealth, Council of Europe, FAO, G-
77, GATT, IAEA, IBRD, ICAO, ICO, IDA, IFC, ILO, IMF,
ITU, NAM, U.N., UNESCO, UPU, WHO, WMO, WTO','91ca44e1998c65e89ccff2d00b4208839e267444d6b951c9f41bffeb9ac87dd4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd7e06f099f12e1b69b67dbfce58f766ad71818f6466df61f1d64d691fceb00e',1966,'RO','Romania','government',124,'Legal name: Czechoslovak Socialist Republic (C.S.S.R.)
Type: Communist state
Capital: Prague
Political subdivisions: 2 ostensibly separate and nomi-
nally autonomous republics (Czech Socialist Republic and
Slovak Socialist Republic); 7 regions (kraj) in Czech lands,
three regions in Slovakia; national capitals of Prague and
Bratislava have regional status
Legal system: civil law system based on Austrian-
Hungarian codes, modified by Communist legal theory;
revised constitution adopted 1960, amended in 1968 and
1970; no judicial review of legislative acts; legal education at
Karlova University School of Law; has not accepted
compulsory ICJ jurisdiction
National holiday: Liberation Day, 9 May
Branches: executive—President (elected by Federal As-
sembly), cabinet (appointed by President); legislative—
Federal Assembly (elected directly); Czech. and Slovak
‘ National Councils (also elected directly) legislate on limited
area of regional matters; judiciary-——Supreme Court (elected
by Federal Assembly); entire governmental structure domi-
nated by Communist Party
Government leaders: President Gustav Husak (elected
May 1975),.Premier Lubomir Strougal
Suffrage: universal over age 18
Elections: governmental bodies every 5 years (last
election, October 1976); President every 5 years
Dominant political party_and.leader: Communist Party
of Czechoslovakia (KSC), Gustav Husak, General Secretary;
Communist Party of Slovakia (KSS) has status of “provincial
KSC organization”
ot
Voting strength (1976 election): 99.7% for Communist-
sponsored single slate
Communists: 1.45 million party members and candidate
members (January 1978)’
Other political groups: puppet parties—Czechoslovak
Socialist Party, Czechoslovak People’s Party. Slovak Free-
dom Party, Slovak Revival Party
Member of: CEMA, FAO, GATT, IAEA, ICAO, ICO,
IDA, IFC, ILO, International Lead and Zinc Study Group,
IMCO, IPU, ISO, ITC, ITU, U.N., UNESCO, UPU, Warsaw
Pact, WHO, WIPO, WMO, WSG, WTO
Legal name: Socialist Republic of Romania
Type: Communist state
Capital: Bucharest
Political subdivisions: 40 counties including city of
Bucharest, that has administrative status equal to a county,
and 46 municipalities,
Legal system: mixture of civil law system and Communist.
legal theory which increasingly reflects Romanian traditions;
constitution adopted 1965; legal education at University of
Bucharest and two other law schools; has not accepted
compulsory ICJ jurisdiction
National holiday: Liberation Day, 23 August
. Branches: Presidency; Council of Ministers; the Grand
National Assembly, under which is Office of Prosecutor
General and Supreme Court; Council of State 7
Government leaders: Nicolae Ceausescu, President of the
Socialist Republic, head of state; Manea Manescu, Prime
Minister
Suffrage: universal over age 18, compulsory
Elections: elections held every 5 years for Grand National
Assembly deputies and local people’s councils
Political parties and leaders: Communist Party of
Romania only functioning party, Nicolae Ceausescu, Secre-
tary General
Voting strength (1975 election): overall participation
reached 99.96%; of those registered to vote (14,900,032),
98.8% voted for party candidates
Communists: 2,747,000 (end of 1975)
Member of: CEMA, FAO, G-77, GATT, IAEA, IBRD,
ICAO, ILO, IMF, IPU, ITC, ITU, U.N., UNESCO, UPU,
Warsaw Pact, WHO, WIPO, WMO, WTO','28b601467115ffb9a9d55446cc975bdce24b8de0f0fbcd82c0d67c40158015c7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cceeaa3b5040672f44632e2467b512a3586de509af814668afdf70e885012fdd',1966,'DK','Denmark','government',128,'Legal name: Kingdom of Denmark
Type: constitutional monarchy
Capital: Copenhagen
Political subdivisions: 14 counties, 277 communes, 88
towns
Legal system: civil law system; constitution adopted 1953;
judicial review of legislative acts; legal education at
Universities of Copenhagen and Arhus; accepts compulsory
ICJ jurisdiction, with reservations
National holiday: Birthday of the Queen, 16 April
Branches: legislative authority rests jointly with Crown
and parliament (Folketing); executive power vested in
Crown but exercised by cabinet responsible to parliament:
Supreme Court, 2 superior courts, 106 lower courts
Government leaders: Queen Margrethe II; Prime Minis-
ter, Anker Jorgensen
Suffrage: universal over age 2]
Elections: on call of prime minister but at least every four
years (last election 15 February 1977)
Political parties and leaders: Social Democratic, Anker
Jorgensen; Liberal, Henning Christopherson (interim party
chairman) Conservative, Poul Schluter; Radical Liberal,
Kristen Helveg Petersen; Socialist Peoples, Gert Petersen;
Communist, Joergen Jensen; Left Socialist, Preben Wilhjelm;
Center Democratic, Erhard Jakobsen; Christian People’s,
Jens Moller; Justice, Ib Christensen; Communist League
Marxist-Leninist, Benito Scocozza
Voting strength (1977 election): 37.5% Social Democratic,
14.3% Progressive, 12.3% Moderate Liberals, 8.3% Conserva-
tive, 6.4% Center Democratic, 3.9% Socialist Peoples, 3.7%
Communist, 3.6% Radical Liberal, 3.5% Christian, 3.2%
Justice, 2.7% Leftist Socialist
Communists: 7,500-8,000; a number of sympathizers, as
indicated by 114,084 Communist votes cast in 1977 elections
Member of: ADB, Council of Europe, DAC, EC, EEC,
ELDO (observer), EMA, ESRD, EURATOM, FAO, GATT,
IAEA, IBRD, ICAC, ICAO, ICES, ICO, IDA, IEA, IFC,
IHO, ILO, International Lead and Zinc Study Group,
IMCO,. IMF, IPU, ISO, ITC, ITU, [WC—International
Wheat Council, NATO, Nordic Council, OECD, U.N.,
UNESCO, UPU, WHO, WIPO, WMO, WSG','cef47df375548740c892f97b71b1258a73aaf09fd6cfa630e17a4897f37f659b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('810e79546ad5b982def3891d5a753a451abd7362b5e364ed4093c305d5deab0f',1966,'DJ','Djibouti','government',131,'Legal name: Republic of Djibouti
Type: republic
Capital: Djibouti
Legal system: based on French civil law system,
traditional practices and Islamic law
Branches: 65-member parliament, cabinet, president,
prime minister
Government leader: President, Hassan Gouled Aptidon
Suffrage: universal
Elections: Parliament elected May 1977
Political parties and leaders: National Independence
Union (UNJ), Ali Aref Bourhan; African People’s Independ-
ence League (LPAI), Hassan Gouled and Ahmed Dini;
Popular Liberation Movement, Kamil Ali; Front for the
Liberation of the Somali Coast (FLCS)
Communists: possibly a few sympathizers
Member of: Arab League','924a7b5bbd024999d9634ba26418d4dcd11965adab618699e50072dadc2b46d0','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16c3bca81d2d066e54608b520446cfa00bee23a0ec537f258aa481bf88f0f11b',1966,'DM','Dominica','government',135,'Legal name: Dominica
Type: independent state within Commonwealth as of 3
November 1978
Capital: Roseau
Political subdivisions: 10 parishes
Legal system: based on English common law; three local
magistrate courts and the British Caribbean Court of
Appeals
Branches: legislature, 11 member popularly elected
House of Assembly; executive, cabinet headed by Premier
53
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
DOMINICA/DOMINICAN REPUBLIC
Government leaders: Prime Minister Patrick Roland John
Suffrage: universal adult suffrage over age 18
Elections: every 5 years; most recent March 1975
Political parties and leaders: Dominica Labor Party
(DLP), Patrick John; Dominica Freedom Party (DFP), Miss
M. Eugenia Charles (unofficial) ;
Voting strength: House of Assembly seats—DFP 33 seats,
DLP 16 seats, independent 2 seats
Communists: negligible
Member of: CARICOM, U.N.','835fca74f7d49a5ed3c5548a3cee9cc4940829f6e702c1e7f816e8c54c9f6972','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa35be83674befac3885603bec7acab2b6cd2ede4786e732253936709305178d',1966,'DO','Dominican Republic','government',139,'Legal name: Dominican Republic
Type: republic
Capital: Santo Domingo
Political subdivisions: 26 provinces and the National
District
Legal system: based on French civil codes; 1966
constitution
National holiday: Independence Day, 27 February
Branches: President popularly elected for a 4-year term;
bicameral legislature consisting of Senate (27 seats) and
Chamber of Deputies (91 seats) elected for 4-year terms;
Supreme Court
Government leader: President Antonio (Silvestre) GUZ-
MAN Fernandez
Suffrage: universal and compulsory, over age 18 or
married, except members of the armed forces and police,
who cannot vote
Elections: last national election May 1978; next election
May 1982
Political parties and leaders: Reformist Party (PR),
Joaquin Balaguer; Dominican Revolutionary Party (PRD),
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
| DOMINICAN REPUBLIC/ECUADOR,
Jorge Blanco; Dominican Liberation Party (PLD), Juan
Bosch; Democratic Quisqueyan Party (PQD), Elias Wessin y
Wessin; Revolutionary Social Christian Party (PRSC),
Rogelio Delgado Bogaert; Movement for National .Concilia-
tion (MNC), Jaime Manuel Fernandez Gonzalez; Antire-
election Movement of Democratic ‘Integration (MIDA),
Francisco Augusto Lora; National Civic Union (UCN),
Guillermo Delmonte Urraca; National ‘Salvation Movement
(MSN), Luis Julian Perez; Popular Democratic Party (PDP),
Homero Lajara Burgos; Fourteenth of ‘June Revolutionary
Movement (MR-1J4), split into several factions, illegal;
Dominican Communist Party (PCD), central committee,
legalized in 1978; Dominican Popular Movement (MPD),
illegal; 12th of January National Liberation Movement
(ML-12E), Plinio Matos Moquete, illegal; Communist Party
of the Dominican Republic (PACOREDO), Luis Montas
Gonzalez, illegal; Popular Socialist Party (PSP), illegal
Voting strength (1978 election): 51.7% PRD, 40.9% PR,
7.4% thirteen minor parties
Communists: an estimated 1,500 to 1,800 members in six
different factions; effectiveness limited by ideological
differences and organizational inadequacies
Member of: FAO, G-77, GATT, IADB, JAEA, IBA,
IBRD, ICAO, ICO, IDA, IDB, IFC, IHO, ILO, IMCO, IMF,
100C, ISO, ITU, OAS, SELA, U.N., UNESCO, UPU, WHO,
WMO, WTO','8ba1a349e87dbf70f12598b0f46564608ec18a58809577edd1c9afa5d98da3b2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa2058ff4c38cbbbc76db11d1283ba142b776dcb52782b5bd53f161a06ae1eea',1966,'EC','Ecuador','government',143,'Legal name: Republic of Ecuador
National holiday: Independence Day, 10. August
Type: republic; under military regime since 1972
Capital: Quito
Political subdivisions: 20 provinces including Galapagos
Islands
Legal system: based on civil law’system; progressive new
constitution passed in January, 1978 referendum will come
into effect following the inauguration of a new civilian
president in August 1979; legal education at 4 state and 2
private universities; has not accepted compulsory ICJ
jurisdiction
National holiday: Independence Day, 10 August
Branches: Supreme Council of Government, made up of
the three military chiefs, assumed power January 1976;
judiciary system supervised by Supreme Court; six special
tribunals established in July 1972
Government leader: President of Supreme Council Vice
Admiral Alfredo POVEDA Burbano
Suffrage: universal for literates over age 18
Elections: first round of presidential election and
municipal elections were held 16 July 1978; will be followed
by second round of presidential election and parliamentary
elections in April 1979
Political parties and leaders: Popular Christian Party,
Sixto Antonio Duran-Ballen, center right; Radical Liberal
Party, Francisco Huerta, center left; Concentration of
Popular Forces, Assad Bucaram, Jaime Roldos, populist;
Christian Democrats, Osvaldo Hurtado, center left; Demo-
cratic Left, Rodrigo Borja, center left; National Velasquistas
Front, Jose Maria Velasco Ibarra, personalistic
Voting strength: unofficial results of July 1978 presiden-
tial election (first round): Jaime Roldos, Concentration of
Popular Forces, 31%; Sixto Duran-Ballen, center-right
coalition, 24%; Raul Clemente Huerta, center-left coalition,
23%; others, 22%
Communists: Communist Party of Ecuador (PCE, pro-
Moscow, Pedro Saad—secretary-general), 500 members plus
an estimated 3,000 sympathizers; Communist Party of
Ecuador (PCE/ML, pro-Peking), 100 members; Revolution-
ary Socialist Party of Ecuador (PSRE), 200 members
56
Member of: ECOSOC, FAO, G-77, IADB, IAEA, IBRD,
ICAO, ICO, IDA, IDB,: IFC, IHO, ILO, IMCO, IMF, ITU,
LAFTA and Andean Sub-Regional Group (formed in May
1969 within LAFTA), OAS, OPEC, -SELA, U.N., UNESCO,
UPEB, UPU, WHO, WMO, WTO
Legal name: Arab Republic of Egypt
Type: republic; under presidential rule since June 1956
Capital: Cairo ~
Political subdivisions: 26 governorates
Legal system: based on English common law, Islamic law,
and Napoleonic codes; permanent constitution written in
1971; judicial review of limited nature in Supreme Court,
also in Council of State which oversees validity of
administrative decisions; legal education at Cairo University;
accepts compulsory ICJ jurisdiction, with reservations
National holiday: National Day, 23 July
Branches: executive power vested in President, who
appoints cabinet; People’s Assembly gradually gaining power
as political liberalization program is implemented; independ-
ent judiciary administered by Minister of Justice
Government leader: President Anwar al-Sadat
Suffrage: universal over age 18
Elections: elections to People’s Assembly every 5 years
(most recent October 1976); presidential elections every 6
years (most recent September 1976)
Political parties and leaders: formation of political
parties must be approved by government; National Demo-
cratic Party, formed in mid-1978 by President Sadat, is the
major party; various small opposition parties
Communists: approximately 500, party members
Member of: AAPSO, AFDB, Arab League, FAO, G-77,
GATT, IAEA, IBRD, ICAC, ICAO, IDA, IFC, IHO, ILO,
IMCO, IMF, JOOC, IPU, ITU, IWC—International Wheat
Council, NAM, OAPEC, OAU, U.N., UNESCO, UPU,
WHO, WIPO, WMO, WPC, WSG, WTO','d571f02432b3a9eadefad4d722331c42832de2b76e2213687c7cfe8528fbd0bb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97d00061d4687d3913bbf343b8d4ab6388cddbbda680b178212e264b46c53385',1966,'SV','El Salvador','government',147,'Legal name: Republic of El Salvador
Type: republic
Capital: San Salvador
Political subdivisions: 14 departments
Legal system: based on Spanish law, with traces of
common law; constitution adopted 1962; judicial review of
legislative acts in the Supreme Court; legal education at
University of E] Salvador; accepts compulsory ICJ jurisdic-
tion, with reservations
National holiday: Independence Day, 15 September
Branches: traditionally dominant executive, unicameral
legislature, Supreme Court
Government leader: President, Gen. Carlos .Humberto
ROMERO Mena
Suffrage: universal over age 18
Elections: legislative elections every 2 years; presidential
elections every 5 years; presidential elections 1982, legisla-
tive and municipal elections March 1980
Political parties and leaders: National Conciliation Party
(PCN), President Arturo A. Molina, and replaced by Carlos
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
[ay eae en ES OPC i ee SUEY
JA em A!
a NO ee ee ee
ae RAR Ae
Alby fs ea A aA A AA
}
!
?
t
i
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
EL SALVADOR/EQUATORIAL GUINEA
Humberto Romero on 1 July; Christian Democratic. Party
(PDC), Juan Ramirez Rauda, Dr. Pablo Mauricio Alvergue,
Jose Napoleon Duarte; Salvadoran Popular Party (PPS),
Benjamin Wilfredo Navarrete, Roberto Quinonez Meza, Dr.
Jose Antonio Guzman; Communist Party of El Salvador
(PCES), illegal, Jorge Shafick Handal; National Revolution-
ary Movement (MNR), Dr. Guillermo Manuel Ungo;
National Democratic Union Party (PUDN), Communist
Front, Jorge Shafick Handal, Francisco Roberto Lima, Julio
Ernesto Contreras, Julio Castro Belloso; Independent Demo- .
cratic United Front (FUDI), Gen. Jose A. Medrano, Raul
Salaverria
Voting strength: February 1977 presidential election—
PCN 66%, PDC, PUDN, and MNR coalition, 34%; March
1978 legislative election—PCN, 50 seats; PPS, 4 seats: all
other opposition parties boycotted the election
Communists: 220 to 225 active members; sympathizers,
5,000; several hundred members of radical terrorist groups
Other political or pressure groups: the military; about
100 prominent families; General Confederation of Trade
Unions (CGS); Unifying Federation of Salvadoran Trade
Unions (FUSS), Communist dominated; Federation of
Construction and Transport Workers Unions (FESINCONS-
TRANS), independent; Catholic Church; Salvadoran Na-
tional Association of Educators (ANDES); National Associ-
ation of Private Enterprise (ANEP); National Democratic
Organization (ORDEN)
Member of: Central American Common Market (CACM),
FAO, G-77, IADB, IAEA, IBRD, ICAC, ICAO, ICO, IDA,
IDB, IFC, ILO, IMF, ITU, IWC—International Wheat
Council, OAS, ODECA, SELA, U.N., UNESCO, UPU,
- WHO, WMO, WTO','7998143d068d2e649de537fbeabe3d22065b9a10d6ef837b297a7c280c60f9e6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43b27a68f535424946bf3ec139c90ffdf6b6f0424c3da7d0ffc65032b68e9c2b',1966,'CM','Cameroon','government',150,'Legal name: Republic of Equatorial Guinea
Type: republic, one-party presidential regime since 1968
Capital: Malabo, Province Macias Nguema Biyogo
Political subdivisions: 2 provinces (Province Macias
Nguema Biyogo and Rio Muni)
Legal system: based on Spanish Civil law system and
customary law, new constitution adopted August 1973; has
not accepted compulsory ICJ jurisdiction
National holiday: 5 March
Branches: there are legislative and judicial branches but
President exercises virtually unlimited power
Government leader: President for life. Masie Nguema
Biyogo Negue Ndong
Suffrage: universal age 21 and over
Elections: parliamentary elections held December 1973
Political parties and leaders: National Unity Party of
Workers (PUNT) is the sole legal party, led by President
Masie ,
~ Communists: no significant number of Communists or
sympathizers
Member of: Conference of East and Central African
States, ECA, G-77, IBRD, ICAO, IDA, IMCO, IMF, ITU,
NAM, OAU, U.N., UPU','d36606dd814b1262511a6e642cc8a9ab114a9e218cb9d49a1de4e8d4e6578e30','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48123a3a6d9df0a9a2993cc10e37ec26982f82928e76062fe7aeb11585101ca8',1966,'ET','Ethiopia','government',154,'Legal name: Ethiopia
Type: under military rule since mid-1974; monarchy
abolished in March 1975, but republic not yet declared
Capital: Addis Ababa
Political subdivisions: 14 provinces (also referred to as
regional administrations)
Legal system: complex structure with civil, Islamic,
common and customary law influences; constitution sus-
pended September 1974; military leaders-have promised a
new constitution but established no time frame for its
adoption; legal education at Addis Ababa University; has not
accepted compulsory IC] jurisdiction
National holiday: Popular Revolution Commemoration
Day, 12 September
Branches: effective power exercised by Provisional
Military Administrative Council (PMAC), a group estimated
at 40-100 officers and enlisted men which operates on
committee system; predominantly civilian cabinet is ineffec-
tual and holds office at suffrance of military; legislature
dissolved September 1974; judiciary at higher levels based on
Western pattern, at lower levels on traditional pattern,
without jury system in either
Government leader: Lieutenant Colonel Mengistu Haile-
Mariam Chairman of the Provisional Military Administra-
tive Council
Suffrage: universal over age 21
Elections: union dwellers’ association officials elected
October-December 1976
Political parties and leaders: Common front of Ethiopian
Marxist-Leninist organizations, encompassing five quasi-
official groups—All-Ethiopian Socialist Movement (Me’l
Sone), Revolutionary Flame (Seded), and three less impor-
tant ‘ones
Communists: Ethiopian Communist Party is a small
group opposed to military government
Other political or pressure groups: important dissident
groups include Eritrean Liberation Front (ELF), Eritrean
People’s Liberation Front (EPLF), and Eritrean Liberation
Front/Populan Liberation Forces in Eritrea; Ethiopian
People’s Revolutionary Party (EPRP), a radical left under-
ground movement concentrated in Addis Ababa and made
up predominantly of students and intellectuals; it has been
severely reduced by a recent government eradication
campaign; and Ethiopian Democratic Union (EDU), primar-
ily an exile group, although it has made some inroads inside
Ethiopia; several other dissident groups with ethnic or
provincial bases of support
Member of: AFDB, ECA, FAO, G-77, IAEA, IBRD, ICO,
ICAO, IDA, IFC, ILO, IMF, IPU, ITU, NAM, OAU, U.N.,
UNESCO, UPU, WHO, WMO, WTO','40a972d511ff15f6131522591fd3227ba6eed35d0a57d2ef1d4584c892965703','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('661605a81fd40a620fc0c0b70adefe640de6e70135165602561e1fcebca146b2',1966,'FO','Faroe Islands','government',160,'Legal name: Faroe Islands
Type: self-governing province within the Kingdom of
Denmark; 2 representatives in Danish parliament
Capital: Torshavn on the island of Streymoy
Political subdivisions: 7 districts, 49 communes, 1 town
Legal system: based on Danish law; Home Rule Act
enacted 1948
Branches: legislative authority rests jointly with Crown,
acting through appointed High Commissioner, and provin-
cial parliament (Lagting) in matters’ of strictly Faroese
concern; executive power vested in Crown, acting through
High Commissioner, but exercised by provincial cabinet
responsible to provincial parliament
Government leaders: Queen Margrethe IJ; Prime Minis-
ter, Atli Dam; Danish Governor, Leif Groth
Suffrage: universal, but not compulsory, over age 21
Elections: held every 4 years; next election 198]
(coincides with Danish elections)
Political parties and leaders: Peoples, Hakun Djurhuus;
Republican, Erlendur Patursson; Home Rule, Samuel
Petersen; Progressive, Kjartan Mohr; Social Democratic, Atli
Dam; Union, Kristian Djurhuus
Voting strength (1975 election): Social Democratic 25.8%,
Republican 22.5%, Peoples 20.5%, Union 19.1%, Home Rule
7.2%, Progressive 2.5%
Communists: insignificant number
Member of: Nordic Council','7d80d099dd8b86348a3314e707226fa36c0c9baeabec7c824557ae062bf8e55b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f80f855b8de7226ad5f7a41f92ccd88335763d7c8c2f6130d48c0d5f877435a',1966,'FI','Finland','government',164,'Legal name: Republic of Finland
Type: republic
Capital: Helsinki
Political subdivisions: 12 provinces; 443 communes, 78
towns
Legal system: civil law system based on Swedish law;
constitution adopted 1919; Supreme Court may request
legislation interpreting or modifying laws; legal education at
Universities of Helsinki and Turku; accepts compulsory ICJ
jurisdiction, with reservations
National holiday: Independence Day, 6 December
Branches: legislative authority rests jointly with President
and parliament (Eduskunta); executive power vested in
President and exercised through cabinet responsible to
parliament; Supreme Court, 4 superior courts, 193 lower
courts
Government leader: President Urho K. Kekkonen; Prime
Minister Kalevi Sorsa
Suffrage: universal, 18 years and over; not compulsory
Elections: parliamentary, every 4 years (next in 1979);
presidential, every 6 years (President Kekkonen reelected to
6-year term in January 1978)
Political parties and leaders: Social Democratic, Kalevi
Sorsa; Center, Johannes Virolainen; Peoples Dernocratic
League (Communist front), Ele Alenius; Conservative, Harri
Holker; Liberal, Jaakko Itala; Swedish Peoples Party, Par
Stenback; Rural, Veikko Vennamo; Finnish People’s Unity
Party, Eino Haikala; Communist, Aarne Saarinen
Voting strength (1978 election): 23.3% Social Democratic,
19.5% Center, 18.2% People’s Democratic League, 14.7%
65
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
FINLAND/FRANCE
Unionist, 8.8% Christian League, 4.7% Finnish Rural Party,
3.6% Swedish Peoples, 3.4% Constitutional Peoples, 2.9%
Liberal Peoples, 0.8% Finnish Peoples Unity Party, 0.1%
Socialist Workers’ Party
Communists: 43,000; an additional 65,000 persons belong
to Peoples’ Democratic League; a further number of
sympathizers, as indicated by 438,757 votes cast for Peoples
Democratic League in 1975 elections
Member of: ADB, CEMA (special cooperation agree-
ment), DAC, EC (free trade agreement), EFTA (associate),
FAO, GATT, IAEA, IBRD, ICAC, ICAO, ICES, ICO, IDA,
IFC, IHO, ILO, International Lead and Zinc Study Group,
IMCO, IMF, IPU, ITU, [WC—International Wheat Coun-
cil, Nordic Council, OECD, U.N., UNESCO, UPU, WHO,
WIPO, WMO, WSG','2c567aec1902a3d7d6999b306e0b25f789c977de0c62a2dfcc0b758f525c55bb','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a24424cf6c25475db4cdd6f3ef98f1442659778625d5ae3a189c9c497f8a5198',1966,'FR','France','government',168,'‘Legal name: French Republic
Type: republic, with president having wide powers
Capital: Paris
Political subdivisions: 96 metropolitan departments, 21
regional economic districts —
Legal system: civil law system with indigenous concepts;
new constitution adopted 1958, amended concerning elec-
tion of President in 1962; judicial review of administrative
but not legislative acts; legal education at over 25 schools of
law
National holiday: National Day, 14 July
Branches: presidentially appointed Prime Minister heads
Council of Ministers, which -is formally responsible to
National Assembly; bicameral legislature—National Assem-
bly (491 members), Senate (295 members) restricted to a
delaying action: judiciary independent in principle
Government leader: President Valery Giscard d’Estaing
Suffrage: universal over age 18; not compulsory
Elections: National Assembly—every 5 years, last election
March 1978, direct universal suffrage, 2 ballots; Senate—
indirect collegiate system for 9 years, renewable by
one-third every 8 years, last election September 1977:
President, direct, universal suffrage every 7 years, 2 ballots,
last election May 1974
Political parties and leaders: Majority Coalition—Rally
for the Republic (RPR, formerly UDR), Jacques Chirac;
Republicans (PR), Jacques Blanc; Center for Social Demo-
crats (CDS), Jean Lecanuet; Radical Socialist (RS), Jean-
Jacques Servan-Schreiber; Union for French Democracy.
(federation of PR, CDS, and RS), Jean Lecanuet; Left
Opposition—Socialist Party (PS), Francois Mitterrand; Com-
munist Party (PCF), Georges Marchais; Left Radical
Movement (MRG), Michel Cregnan; Unified Socialist Party
(PSU), Michel Mousel
Voting strength (first ballot, 1978 election): extreme left,
3.3%; Communist, 21.25%; Socialist, 23.03%; left Radicals
2.28%; RPR, 22.19%; UDF, 21.39%; divided right, 1.68%;
other 4.87%
Communists: 600,000 claimed; Communist voters, 5
million average
Other political or pressure groups: Communist-con-
trolled labor union (Confederation Generale du Travail)
nearly 2.4 million members (claimed); Socialist leaning labor
union (Confederation Francaise Democratique du Travail—
CFDT) about 800,000 members est.; Independent labor
union (Force Ouvriere) about 800,000 members est.;
Independent white collar union (Confederation Generale des
Cadres) 200,000 members (claimed); National Council of
French Employers (Conseil National du Patronat Francais—
CNPF or Patronat)
Member of: ADB, Council of Europe, DAC, EC, ECSC,
EEC, EIB, ELDO, EMA, ESRO, EURATOM, FAO, GATT,
IAEA, IATP, IBRD, ICAC, ICAO, ICES, ICO, IDA, IFC,
THO, ILO, International Lead and Zinc Study Group,
IMCO, IMF, IOOC, IPU, ISO, ITC, ITU, IWC—Interna-
tional Whaling Commission, NATO (signatory), OAS (ob-
server), OECD, South Pacific Commission, U.N., UNESCO,
UPU, WEU, WHO, WIPO, WMO, WSG, WTO
Legal name: Ireland, Eire (Gaelic)
Type: republic
Capital: Dublin
Political subdivisions: 26 counties
Legal system: based on English common law, substan-
tially modified by indigenous concepts; constitution adopted
1937; judicial review of legislative acts in Supreme Court;
has not accepted compulsory ICJ jurisdiction
National holiday: St. Patrick’s Day, 17 March
Branches: elecved President; bicameral parliament re-
flecting proportional and vocational representation; judici-
ary appointed by President on advice of government
Government leaders: President Patrick Hillery; Prime
Minister (Taoiseach) John (Jack) Lynch; Deputy Prime
Minister (Tanaiste) George Colley
Suffrage: universal over age 18
Elections: Dail (lower house) elected every 5 years—last
election June 1977; President elected for 7-year term—last
election November 1976
100
Political parties and leaders: Fianna Fail, John (Jack)
Lynch; Labor Party, Frank Cluskey; Fine Gael, Garret
Fitzgerald; Communist Party of Ireland, Michael O''Riordan
Voting strength: (1977 election) Fianna Fail (84 seats),
Fine Gael (43 seats), Labor Party (17 seats), Independents
hold 4 seats
Communists: approximately 600
Member of: Council of Europe, EC, EEC, ESRO
(observer), EURATOM, FAO, GATT, IBRD, ICAO, ICES,
IDA, IEA, IFC, ILO, IMCO, IMF, IPU, ISO, ITC, ITU,
IWC—International Wheat Council, OECD, U.N.,
UNESCO, UPU, WHO, WIPO, WMO, WSG
Legal name: Grand Duchy of Luxembourg
Type: constitutional monarchy
Capital: Luxembourg
Political subdivisions: unitary state, but for administra-
tive purposes has 3. districts (Luxembourg, Diekirch,
Grevenmacher) and 12 cantons
Legal system: based on civil law system; constitution
adopted 1868; judicial review of legislative acts in ‘the
Cassation Court only; accepts compulsory ICJ jurisdiction
National holiday: 23 June
Branches: parliamentary democracy; seven ministers
comprise Council of Government headed by President,
which constitutes the executive; it is responsible to. the
unicameral legislature, the Chamber of Deputies; the
Council of State, appointed for indefinite term, exercises
some powers of an upper house; judicial power exercised by
independent courts
Government leaders: Grand Duke Jean, Head of State;
Gaston Thorn, Prime Minister -
Suffrage: universal and compulsory over age 18
Elections: every 5 years for entire Chamber of Deputies;
latest elections May 1974 d :
Political parties and leaders: Christian Social Party, |
Pierre Werner (Parliamentary President) and Jacques Santer
(Party President); Socialist, Lydie Schmit (Party President);
Social Democrat, Henry Cravatte (Party President); Demo-
cratic, Gaston Thorn (Party President and Prime Minister);
Communist, Dominique Urbany
Voting strength in Chamber of Deputies (1974):
Christian Socialist, 18; Socialist Workers, 17; Democrats, 14;
Social Democrats, 5; Communists, 5
Communists: 500 party members (1974)
Other political or pressure groups: .group of steel
industries representing iron and steel industry, Centrale
Paysanne representing agricultural producers; Christian and
Socialist labor unions, Federation of Industrialists; Artisans
and Shopkeepers Federation
Member of: Benelux, BLEU, Council of Europe, EC,
ECSC, EEC, EIB, EURATOM, FAO, GATT, IAEA, IBRD,
ICAO, IDA, IEA, IFC, ILO, IMF, IOOC, IPU, ITU, NATO,
OECD, U.N., UNESCO, UPU, WEU, WHO, WIPO, WMO','bf753ded15d62a56468814e7f576f73e5244e1be6d7e34eff1684892c3fe99de','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83fa9e93eabad6e24bfb6c6e67d9e22701c7af5280702db2e274dc863291d9df',1966,'GY','Guyana','government',172,'Legal name: Department of French Guiana
Type: overseas department and region of France;
represented by one deputy in French National Assembly and
one senator in French Senate; Deputy Hector Rivierez
reelected to National Assembly 12 March 1978
Capital: Cayenne
Political subdivisions: 2 arrondissements, 19 communes
each with a locally elected municipal council
Legal system: French legal system; highest court is Gourt
of Appeal based in Martinique with jurisdiction over
Martinique, Guadeloupe, and French Guiana
Declassified and Approved For Release 2012/09/02 : CIA-RDP0O8-00534R000100140001-7
DE Sn tA ee tb se Ss bo 8 5 bo 6 4b
ere ney
=
a
ah et
ye oe
Peet stato"
a TE Ae.
-
OM de kk
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
FRENCH GUIANA/FRENCH POLYNESIA
Branches: executive: prefect appointed by Paris; legisla-
tive: popularly elected 16-member General Council and a
Regional Council composed of members of the local General
Council and of the locally elected deputy and senator to the
French parliament; judicial, under jurisdiction of French
judicial system
Government leader: Prefect Herve Bourseiller
Suffrage: universal over age 18
Elections: General Council elections normally are held
every 5 years; last election March 1978
Political parties and leaders: Parti Socialiste Guyanais
(PSG), Leopold Heder, Senator; Union du Peuple Guyanaise
(UPG), weak leftist allied with, but also reported, to have
been absorbed by the PSG; Rassemblement Pour La
Republique (RPR), Hector Rivierez, delegate to French
National Assembly
Communists: Communist party membership negligible
Legal name: Cooperative Republic of Guyana
Type: republic within Commonwealth
Capital: Georgetown
Political subdivisions: 9 administrative districts
Legal system: based on English common law with certain
admixtures of Roman-Dutch law; has not accepted compul-
sory ICJ jurisdiction
National holiday: 23 February
Branches: Council of Ministers presided over by Prime
Minister; 53-member unicameral legislative National Assem-
bly (elected); Supreme Court
Government leader: Prime Minister L. F. S. Burnham;
President Arthur Chung
Suffrage: universal over age 18 as of constitutional
amendment August 1973
Elections: last held in July 1973; results of government
sponsored referendum, held 10 July 1978, postponed
required elections and empowered ruling party to draft a
new constitution
Political parties and leaders: People’s National Congress
(PNC), L. F. S. Burnham; People’s Progressive Party (PPP),
Cheddi Jagan; United Force (UF), Feilden Singh
Voting strength (1973 election): 70.2% PNC, 26.2% PPP,
3.6% other
Communists: est. 100 hard-core within PPP; top echelons
of PPP and PYO (Progressive Youth Organization, militant
wing of the PPP) include many Communists, but rank and
file is conservative and non-Communist; small but unknown
number of orthodox Marxist-Leninists within PNC, some of
whom are PPP turncoats
Other political or pressure groups: Trades Union
Congress (TUC); Working People’s Alliance (WPA); Work-
ing People’s Vanguard Party (WPVP); Guyana Council of
Indian Organizations (GCIO); Civil Liberties Action Com-
mittee (CLAC); the latter two organizations are small and
active but not well organized
Member of: CARICOM, CDB, FAO, G-77, GATT, IADB,
IBA, IBRD, ICAO, IDA, IFC, ILO, IMF, ISO, ITU, NAM,
OAS (observer), SELA, U.N., UNESCO, UPU, WHO, WMO','51ff0a47bc7bbc176b4779f887e4abc221d20c2dfb621abbf2e0e059daccb997','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4929bee2a3b9bbb17037093abd307fa48d3d7a4e3376d7bda655ae36d86988b',1966,'PF','French Polynesia','government',176,'Legal name: Territory of French Polynesia
Type: overseas territory of France, administered by
French Ministry for Overseas Territories
Capital: Papeete
Political subdivisions: 5 districts
69
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
FRENCH POLYNESIA/GABON
Legal system: based on French; lower and higher courts
Branches: 33-member Territorial Assembly, popularly
elected; 5-member Council of Government, elected by
Assembly; popular election of one deputy to National
Assembly in Paris, also one Senator
Government leader: Charles Schmitt, Governor, ap-
pointed by French government :
Suffrage: universal adult
Elections: every 5 years, May 1977
Political parties and leaders: Le Front Uni, autonomist
coalition, Francis Sanford; Tahoeraa Hairaatira, conservative
Gaullist, Gaston Flosse
Voting strength (1977 election): Le Front Uni, 14 seats;
Tahoerra Huiraatira, 10 seats; Independents, 9 seats','43e2c36fc2fc63f349a8c7218d0e331e2ff09f245b2d0bcde223ebcaef53a412','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7327b3a62ae95357001198621c92d4c94e03d92361851a1398cc0718f9857798',1966,'GN','Guinea','government',180,'Legal name: Republic of Ghana
Type: republic; independent since March 1957; Military
regime since January 1972
Capital:. Accra
Political subdivisions: 8 administrative regions and
separate Greater Accra Area; regions subdivided irito 58
districts and 267 local administrative districts
Legal system: based on English common law and
customary law; constitution suspended January 1972; new
constitution being prepared for civilian rule in July 1979;
legal: education at University of Ghana (Legon); has not..
accepted compulsory IC] jurisdiction
National holiday: Independence Day, 6 March
Branches: executive and legislative authority vested in
Supreme Military Council (SMC); independent judiciary
Government leader: Chief of State, Chairman of SMC,
Lt. Gen. Frederick W. K. Akuffo
Suffrage: universal over 21 under previous constitution,
now suspended
Elections: no elections since 1969; the military has
promised to return power to an elected civilian regime in
July 1979
Political parties and leaders: parties banned by military
junta which took power 13 January 1972
Communists: a small number of Communists and
sympathizers
Member of: AFDB, Commonwealth, ECA, ECOWAS,
FAO, G-77, GATT, IAEA, IBA, IBRD, ICAO, ICO, IDA,
IFC, ILO, IMCO, IMF, ISO, ITU, NAM, OAU, U.N.,
UNESCO, UPU, WCL, WHO, WIPO, WMO, WTO
Legal name: Republic of Guinea
Type: republic; under one-party presidential regime
Capital: Conakry |
Political subdivisions: 29 administrative regions, 209
arrondissements, about 8,000 local entities at village level
Legal system: based on French civil law system,
customary law, and presidential decree; constitution adopted
1958; no constitutional provision for judicial review of
legislative acts; has not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 2 October
Branches: executive branch dominant, with power
concentrated in President’s hands and a small group who are
both ministers and members of the party’s politburo;
unicameral National Assembly and judiciary have little
independence
Government leader: President Ahmed Sekou Toure, who
has been designated “The Supreme Leader of the
Revolution”
Suffrage: universal over age 18
Elections: approximate schedule—5 years parliamentary,
latest in 1975; 7 years presidential, latest in 1975
Political parties and leaders: only party is Democratic.
Party of Guinea (PDG), headed by Sekou. Toure
Communists: no Communist party, although there. are
some sympathizers
Member of: AFDB, ECA, ECOWAS, FAO, G-77, IBA,
IBRD, ICAO, .ICO, IDA, ILO, IMF, ITU, Niger River
Commission, NAM, _OAU, U.N., UNESCO, UPU, WHO,
WMO
Legal name: Republic of Senegal
Type: republic
Capital: Dakar ;
Political subdivisions: 8 regions, subdivided into 27
departments, 95 arrondissements
Legal system: based on French civil law system;
constitution adopted 1960, revised 1963 and 1970: judicial
review of legislative acts in Supreme Court (which also
audits the government’s accounting office); legal education
at University of Dakar; has not accepted compulsory IC]
jurisdiction
National holiday: Independence Day, 4 April
Branches: government dominated by President who is
assisted by Prime Minister, appointed by President and
subject to dismissal by President or censure by National
Assembly; 100-member National Assembly, elected for 5
years (effective 1978); President elected for 5-year term
(efféctive 1978) by universal suffrage; judiciary headed by
Supreme Court, with members appointed by President
Government leaders: Leopold Sedar Senghor, President;
Abdou Diouf, Prime Minister
Suffrage: universal adult
Elections: presidential and legislative elections held
February 1978 for 5-year term
Political parties and leaders: Jegal parties are Parti
Socialiste (PS), ruling party led by President Leopold
Senghor; Parti Democratique Senegalaise (PDS), “‘liberal
democratic” party founded July 1974, and “Marxist-Lenin-
ist” African Independence Party (PAI), legalized in August
1976; unauthorized parties include clandestine PAI splinter
group, leftist Rassemblement Nationale Democratique, and’
Parti Communiste Senegalais (PCS)
Communists: smal] number of Communists and sympa-
thizers associated with PAI and PCS
Other political or pressure groups: students and teachers
occasionally strike
Member of: AFDB, APC, CEAO, EAMA, ECA,
ECOWAS, EIB (associate), FAO, G-77, GATT, IAEA,
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
a eee ee ee ee ee ee ee ee ee ge ee Swe ae ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
SENEGAL/SEYCHELLES
IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF, ITU, NAM,
OAU, OCAM, OMVS (Organization for the Development of
the Senegal River Valley), U.N., UNESCO, UPU, WHO,
WIPO, WMO, WTO','ec9a91c377041dd60d53d108f47a77d27238e30baae838e5e6287959762d731e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2072fa4b33588dd77c1fe545eb6a638c4be805867ce79e0f3ac12295b80154a6',1966,'GR','Greece','government',186,'Legal name: Hellenic Republic
Type: presidential parliamentary government; monarchy
rejected by referendum 8 December 1974
Capital: Athens
Political subdivisions: 52 departments (nomoi) constitute
basic administrative units for country; each nomos headed
by officials appointed by central government and policy and
programs tend to be formulated by central ministries; degree
of flexibility each nomos may have in altering or avoiding
programs imposed by Athens depends upon tradition and
influence which prominent local leaders and citizens may
exercise vis-a-vis key figures in central government. The
departments of Macedonia and Thrace exercise some degree
of autonomy from Athens since they are governed through
the Ministry of Northern Greece.
Legal system: new constitution enacted in June 1975
National holiday: Independence Day, 25 March
Branches: executive consisting of a President’ (to be
elected by the Vouli parliament) and a Prime Minister and
cabinet; legislative comprising the 300-member Vouli;
independent judiciary
Government leaders: President Konstandinos Tsatsos;
Prime Minister Konstandinos Karamanlis
Suffrage: universal age 20 and over
Elections: every 4 years; the government called for new
elections on 20 November 1977 and was returned to power,
albeit with a reduced majority
Political parties and leaders: Democratic Center Union,
Georgios Mavros; New Democracy, Konstandinos Karaman-
lis; Panhellenic Socialist Movement, Andreas Papandreou; -
Communist Party—Exterior, Kharilaos Florakis; Communist
Party—Interior, Kharalambos Drakopoulos; United Demo-
cratic Left; Ilias Iliou; Socialist Initiative, Georgios Mangakis;
Socialist March; Christian Democracy; Nationalist Camp,
Stefanos Stefanopoulos , ‘
Voting strength: New Democracy, 172 seats; Democratic
Center Union, 15 seats; Panhellenic Socialist Movement, 93
seats; Communists, 11 seats; The Alliance (leftist), 2 seats;
National Camp, 5 seats; Neoliberals, 2 seats
Communists: an estimated 25,000-30,000 members and
sympathizers ;
Member of: EC (associate), EIB (associate), EMA, GATT,
FAO, IAEA, IBRD, ICAO, IDA, IFC, IHO, ILO, IMCO,
IMF, IOOC, ITU, [WC—International Wheat Council,
NATO, OECD, U.N., UNESCO, UPU, WHO, WIPO,
WMO, WSG, WTO','450e71d49ec155cbe72b26b02655e9daba1f26faba23afe228189e35f6c6e1b8','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('559e845961f4b9108ae768c5363f1faaaf4f82340a2dfa8c5ecfe8f75d86ffab',1966,'GL','Greenland','government',190,'Legal name: Greenland
Type: province of Kingdom of Denmark; 2 representatives
in Danish parliament; separate Minister for Greenland in the
Danish cabinet -
Capital: Godthaab (administrative center)
Political subdivisions: 3 counties, 19 communes
Legal system: Danish law; transformed from colony to
province in 1953; due for home rule in spring 1979
Branches: legislative authority rests jointly with Crown
and Danish parliament; executive power vested in Crown,
acting through provincial governor responsible to Minister
for Greenland; local affairs handled by provincial council
(Landsrad) subject to approval of provincial governor; 19
lower courts
Government leader: Queen Margrethe II, Governor Hans
Lassen
Suffrage: universal, but not compulsory, over age 21
Elections: held every 4 years (next 1981—coincides with
Danish elections)
Political parties: Inuit (advocating close ties with
Denmark); Sukaq (moderate socialist, advocating more
distinct Greenland identity); Siumut (a more radical party
advocating greater autonomy from Denmark)','e00eb54f08ee22bb010647d62135590c6d989f4f71c9643e7250a8e1f59b290b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d05f3d23c70f99bc98d2d366babb04455cf000e5e0fb41cefcfae56e71649572',1966,'GD','Grenada','government',194,'Legal name: Grenada
Type: independent state since February 1974, recognizes
Elizabeth JJ as Chief of State
Capital: St. Georges
Political subdivisions: 6 parishes
Legal system: based on English common law
National holiday: Independence Day, 7 February
Branches: legislative branch consists of 15-member
elected House of Representatives and 13-member Senate
appointed by the Governor; executive branch is cabinet led
by Prime Minister
Government leaders: Prime Minister Sir Eric Matthew
Gairy; U.K. Governor General Sir Leo V. deGale
Suffrage: universal adult
Elections: every 5 years; most recent general election 7
December 1976
Political parties and leaders: Grenada United Labor
Party (GULP), Eric Matthew Gairy; Peoples Alliance—a
coalition consisting. of the New Jewel Movement (NJM),
Maurice Bishop; United People’s Party (UPP), Winston
Whyte; Grenada National Party (GNP), Herbert A. Blaize
Voting strength (1976 election): GULP 51.7%, Peoples
Alliance, 48.3%; Legislative Council seats, GULP 9, Peoples
Alliance 6 (NJM 8, UPP 1, GNP 1], unaffilated 1)
Communists: negligible
Member of: CARICOM, G-77, IMF, OAS, SELA, U.N.','4bd70c09e5d2d4f1770734d5d9629454049a1d1f5f67c8e2820b37d67dec26c4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e5400d181c9b602816aa5581c8bc0056ae912588b38bfdf0ade40f4b21b1869',1966,'GP','Guadeloupe','government',198,'Legal name: Department of Guadeloupe
Type: overseas department and region of France;
represented by 3 deputies in the French National Assembly
and 2 Senators in the Senate; last deputy election, 12 March
1978
Capital: Basse-Terre
Political subdivisions: 3 arrondissements; 34 communes,
each with a locally elected municipal council
Legal system: French legal system; highest court is a court
of appeal based, in Martinique with jurisdiction over
Guadeloupe, French Guiana, and Martinique |
Branches: executive, Prefect appointed by Paris: legisla-
tive, popularly elected General Council of 36 members and
a Regional Council composed of members of the local
General Council and the locally elected deputies and.
senators to the French parliament; judicial, under jurisdic-
tion of French judicial system
Government leader: Prefect Jean Claude Aurousseau
Suffrage: universal over age 18
Elections: General Council elections are held normally
every 5 years; last General Council election took place in
March 1978
Political parties and leaders: Rassemblement Pour la
Republique (RPR), Gabriel Lisette; Communist Party of
Guadeloupe (PCG), Henri Bangou; Socialist Party (MSG),
leader unknown; Progressive Party of Guadeloupe (PPG),
Henri Rodes; Independent Republicans; Federation of the
Left
Voting strength: MSG, 1 seat in French National
Assembly; UDG, 2 seats; (1973 election)
Communists: 3,000 est.
Other political or pressure groups: Group of National
Organization of Guadeloupe (GONG)','efbc72dfb68383cba5a7d4a7bc23ba1490ebc53004344c821993f1174c82051d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7048660233625f6313f789f977703cc222891a0275997fccc159e87b73d73a2d',1966,'MX','Mexico','government',201,'Legal name: Republic of Guatemala
Type: republic
Capital: Guatemala
Political subdivisions: 22 departments
Legal system: civil law system; constitution came into
effect 1966; judicial review of legislative acts; legal
education at University of San Carlos of Guatemala; has not
accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 15 September
Branches: traditionally dominant executive; elected uni-
cameral legislature; 7-member (minimum) Supreme Court
Government leader: President Brig. Gen. Fernando
Romeo LUCAS Garcia 7
Suffrage: universal over age 18, compulsory for literates;
optional for illiterates
Elections: next elections (President and Congress) 1982
Political parties and leaders: Democratic Institutional
Party (PID), Donaldo Alvarez Ruiz; Revolutionary Party
(PR), Jorge Garcia-Granados Quinonez (secretary general);
National Liberation Movement (MLN), Mario Sandoval
Alarcon; Guatemalan Christian Democratic Party (DCG),
Vinicio Cerezo Arevalo (sec. gen.); Rene de Leon Schlotter
(honorary President and party strongman); several unregis-
tered parties
Voting strength: (1978) for President—PID/PR, 269,973
(42.3%); MLN, 211,393 (33.1%); DCG, 156,730 (24.6%); for
_congressional seats—PID/PR, 34 seats; MLN, 20 seats; DCG,
7 seats
83
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
GUATEMALA/GUINEA
Communists: Guatemalan Labor Party (PGT) outlawed;
underground membership estimated at 750
Other political or pressure groups: several personalist
political associations seeking registration as parties
Member of: CACM, FAO, G-77, IADB, IAEA, IBRD,
ICAC, ICAO, ICO, IDA, IDB, IFC, IHO, ILO, IMF, ISO,
ITU, IWC—International Wheat Council, OAS, ODECA,
SELA, U.N., UNESCO, UPEB, UPU, WHO, WMO
Legal name: United Mexican States
Type: federal republic operating in fact under a
centralized government
Capital: Mexico
Political subdivisions: 31 states, Federal District
Legal system: mixture of U.S. constitutional theory and
civil law system; constitution established in 1917; judicial
review of legislative acts; accepts compulsory ICJ jurisdic-
tion, with reservations
National holiday: Independence Day, 16 September
Branches: dominant executive, bicameral legislature,
Supreme Court
Government leader: President Jose LOPEZ PORTILLO y
Pacheco
Suffrage: universal over age 18; compulsory but
unenforced
Elections: congressional elections July 1979
138
Political parties and leaders: Institutional Revolutionary
Party (PRI), Carlos Sansores -Perez; National Action Party
(PAN), Manuel Gonzalez Hinojosa; Popular Socialist Party
(PPS), Jorge Cruickshank Garcia; Authentic Party of the
Revolution (PARM), Pedro Gonzalez Azcuaga
Voting strength: 1976 presidential election: 98.7% PRI
(unopposed), 1.3% other; 1976 congressional election: 80.2%
PRI, 8.5% PAN; 5.8% other opposition (votes cast for PPS,
PARM, and unregistered candidates), 5.4% annulled
Communists: Mexican Communist Party (estimated
25,000) and other far-left parties seeking legal registration
under government’s 1977 political reform’ program
Other political or pressure groups: Roman Catholic
Church, Confederation of Mexican Workers (CTM), Con-
federation of Industrial Chambers (CONCAMIN), Confed-
eration of National Chambers of Commerce (CONCA-
NACO), National Cofederation of Campesinos (CNC),
National Confederation of Popular Organizations (CNOP),
Revolutionary Confederation of Workers and Peasants
(CROC)
Member of: FAO, G-77, IADB, IAEA, IBRD, ICAC,
ICAO, ICO, IDA, IDB, IFC, ILO, International Lead and
Zinc Study Group, IMCO, IMF, ISO, ITU, IWC—
International Whaling Commission, LAFTA, NAMUCAR
(Carribean Multinational Shipping Line—Naviera Multina-
cional de] Caribe), OAS, SELA, U.N., UNESCO, UPU,
WHO, WIPO, WMO, WSG, WTO','edb6deb557141ed805b7a3c6334bd26bf422fd09ea33a281ddef644a546a9727','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a245f83f64e1ee6e00698741f95cc28b23c020e0de95abb42cc9f745bb7231ed',1966,'GW','Guinea-Bissau','government',205,'Legal name: Republic of Guinea-Bissau
Type: republic; achieved independence from Portugal in
September 1974; constitution promulgated 1974
Capital: Bissau
Political subdivisions: 9 municipalities, 3 circumscrip-
tions (predominantly indigenous population)
Legal system: to be determined
National holiday: 12 September
Branches: National.Popular Assembly to be elected for
three-year term; Council of State Commissars, 16 members;
the official party is the supreme political institution.
Government leaders: President of Council of State and
Chief of State is Luis de Almeida Cabral; Principal
Commissioner (Head of Government), Maj. Jodo Bernardo
Vieira; Secretary General of the Official party, Aristides
Pereira
Suffrage: universal over age 18
Elections: none held to date
Political parties and leaders: Partido Africano da
Independencia da Guinee e Cabo Verde (PAIGC), led by
Aristide Pereira, only legal party ;
Communists: a few Communists, some sympathizers
Member of: G-77, NAM, OAU, U.N., UPU','351c2a65c457f856b421e3e4061cf841b0dddc79e708e66ade1f04c816a2887a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('550d5eced0100f04c343f1ec9ade6ed8c9b295adc0cfb57fa8fb897f68dd53a3',1966,'PH','Philippines','government',209,'Legal name: Hong Kong
Type: U.K. crown colony
Capital: none
Political subdivisions: Hong Kong, Kowloon, and New
Territories
Legal system: English common law
Branches: Governor assisted by advisory Executive
Council; he legislates with advice and consent of Legislative
Council; Urban Council which alone includes elected
representatives, responsible for health, recreation, and
resettlement; indepéndent judiciary
Government leader: Sir C. M. MacLehose, Governor and
Commander in Chief
Suffrage: limited to 200,000 to 300,000 professional or
skilled persons
Elections: every 2 years to select one-half of elected
membership of Urban Council; other Urban Council
members appointed by the Governor
Political parties: Civic Association; Reform Club; Socialist
Democratic Party; Hong Kong Labour Party
Voting strength: (elected Urban Council members) Civic
Association 4, Reform Club 3, and 1 independent
Communists: an estimated 2,000 cadres affiliated with
Communist Party of China
Other political or pressure groups: Federation of Trade
Unions (Communist controlled), Hong Kong and Kowloon
Trade Union Council (Nationalist Chinese dominated),
Hong Kong General Chamber of Commerce, Chinese
General Chamber of Commerce (Communist controlled),
Federation of Hong Kong Industries, Chinese Manufactur-
ers) Association of Hong Kong
Member of: ADB
Legal name: Province of Macao
Type: overseas province of Portugal
Capital: Lisbon (Portugal)
Political subdivisions: municipality of Macao, and 2
islands
Legal system: Portuguese civil law system
Branches: 17-member Legislative Assembly, with Gover-
nor and 5 appointed, 1 specially nominated, and 10 elected
representatives
Government leader: Col. Eduardo Garcia Leandro
Suffrage: Portuguese, Chinese and foreign residents over
18 é
Elections: conducted every 4 years; last held 1976
Political parties and leaders: Association to Defend the
Interests of Macao; .Macao Democratic Center; Group to
Study the Development of Macao; Macao Independent
Group
Communists: numbers unknown
Other political or pressure groups: wealthy Macanese
and Chinese representing local interests, wealthy pro-Com-
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
i a a i a all
i i i a ee ll i ll
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
MACAO/MADAGASCAR
munist merchants representing China’s interests; in January
1967 Macao Government acceded to Chinese demands
which gave Chinese veto power over administration of the
enclave
Legal name: Republic of the Philippines
‘Type: republic
Capital: Manila
Political subdivisions: 72 provinces
Legal system: based on Spanish, Islamic, and Anglo-
American law; parliamentary constitution passed 1978;
judicial review of legislative acts in the Supreme Court; legal
education at University of the Philippines, Ateneo de Manila
University, and 71 other law schools; accepts compulsory ICJ
jurisdiction, with reservations; currently being ruled under
martial law .
National holiday: Independence Day, 12 June
Branches: new constitution (currently suspended) pro-
vides for unicameral National Assembly, and a_ strong
executive branch under a Prime Minister; judicial branch
headed by Supreme Court with descending authority in a
Court, of Appeals, courts of First Instance in various
provinces, municipal courts in chartered cities, and justices
of the peace in towns and municipalities; these justices have
considerably more authority than do justices of the peace in
the U.S.
Government leader: President Ferdinand Marcos
Suffrage: universal over age 18
Elections: elections held for an interim National Assem-
bly to meet in June ,
Political parties-and leaders: political parties currently in
limbo because of martial law
Communists: about 2,100-2,400 armed insurgents
Member of: ADB, ASEAN, ASPAC, Colombo Plan,
ESCAP, FAO, G-77, IAEA, IBRD, ICAO, IDA, IFC, THO,
ILO, IMCO, IMF, IPU, ISO, ITU, U.N., UNESCO, UPU,
WHO, WTO','918b1eca4c0a3b2781e74b8f9a47c9884b0d30cd736cd343ee4de79c48852467','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a9c6c22be18c5d8fdc50c7a54722f78aebf0332072ac2382e1dadfe47bccf2b',1966,'HU','Hungary','government',214,'Legal name: Hungarian People’s Republic
Type: Communist state
Capital: Budapest
Political subdivisions: 19 megyes (counties), 5 ‘autono-
mous cities in county status, 97 jaras (districts)
‘Legal system: based on Communist legal theory, with
both civil law system (civil code of 1960) and common law
elements; constitution adopted 1949 amended 1972; Su-
preme Court renders decisions of principle that sometimes
have the effect of declaring legislative acts unconstitutional;
legal education at Lorand Eotvos Tudomanyegyetem School
of Law in Budapest and 2 other schools of law; has not
accepted compulsory ICJ jurisdiction
National holiday: Anniversary of the Liberation, 4 April
Branches: executive—Presidential Council (elected by
Parliament); legislative—Parliament (elected by direct suf-
frage);- judicial—Supreme Court (elected by Parliament)
Government leaders: Pal Losonczi, President, Presiden-
tial Council; Gyorgy Lazar, Chairman, Council of Ministers ’
Suffrage: universal over age 18
Elections: every 5 years; national and local elections are
held separately
Political parties and leaders: Hungarian Socialist (Com-
munist) Workers Party (sole party); Janos Kadar is First
Secretary of Central Committee
Voting strength (1975 election): 7,497,061 (99.6 %) for
Communist-approved candidates; 30,108 (0.4%) invalid and
negative votes; total eligible electorate about 7.76 million;
next elections will be held in 1980
Communists: about 754;000 party members (March 1975)
Member of: CEMA, Danube Commission, FAO, GATT,
‘IAEA, ICAC, ICAO, ILO, International Lead and Zinc
Study Group, IMCO, IPU, ISO, ITC, ITU, U.N., UNESCO,
UPU, Warsaw Pact, WHO, WIPO, WMO
92','0f4a1994312497ad01eb38b13fd3082353b6c0c17f7366a5555391bbba3f886d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a35317b02f3a6894d09ad7056c2523ab973a5f2180154c4c115e34bc39ebbff8',1966,'IS','Iceland','government',218,'Legal name: Republic of Iceland
Type: republic
Capital: Reykjavik
Political subdivisions: 23 rural districts, 215 parishes, 14
incorporated towns
Legal system: civil law system based on Danish law;
constitution adopted 1944; legal education at University of
Iceland; does not accept compulsory ICJ jurisdiction
National holiday: Anniversary of the Establishment of
the Republic, 17 June
Branches: legislative authority rests jointly with President
and parliament (Althing); executive power vested in
President but exercised by cabinet responsible to parliament;
Supreme Court and 29 lower courts
Government leaders: President Kristjan Eldjarn; Prime
Minister Olafur Johannesson
Suffrage: universal, over age 20; not compulsory
Elections: parliamentary to take place 25 June 1978,
every 4 years; presidential, every 4 years
Political parties and leaders: Independence (conserva-
tive), Geir Hallgrimsson; Progressive, Olafur Johannesson;
Social Democratic, Benedikt Grondal; People’s Alliance
(Communist front), Luduik Josefsson
Voting strength (1978 election): 32.7% Independence,
16.9% Progressive, 22.0% Social Democratic, 22.9% People’s
Alliance, 5.5% other
Communists: est. 2,200; a number of sympathizers, as
indicated by 20,922 votes cast for People’s Alliance in 1974
election
Member of: Council] of Europe, EC (free trade agreement
pending resolution of fishing limits issue), EFTA, FAO,
GATT, JAEA, IBRD, ICAO, ICES, IDA, IFC, IHO, ILO,
IMCO, IMF, IPU, ITU, IWC—International Whaling
Commission, NATO, Nordic Council, OECD, U.N.,
UNESCO, UPU, WHO, WMO, WSG','93fb152274834d580edbfd54ac6917398b51f2dcb448cf23eda4585047858d02','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f9c18c9b2a182a7f38aef25e2b6ef0726db0d99ab9a1d1232d7a9029706dd05',1966,'IN','India','government',222,'Legal name: Republic of India
Type: federal republic
Capital: New Delhi
Political subdivisions: 22 states, 9 union territories
Legal system: based on English common law; constitution
adopted 1950; limited judicial review of legislative acts;
accepts compulsory ICJ jurisdiction, with reservations
National holiday: Anniversary of the Proclamation of the
Republic, 26 January
Branches: parliamentary government, national and state;
relatively independent judiciary
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
a ae a
pp AA
ae ee RE
wee NT FF OE TOP
i te ne Bl i i i a ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
INDIA/INDONESIA
Government leader: Prime Minister Morarii Desai
Suffrage: universal over age 21
'' Elections: national and state elections ordinarily held
every 5 years; may be postponed in emergency and may be
held more frequently if government loses confidence vote;
next general election due by March 1982; next state elections
staggered in 1982 and 1983
Political parties and leaders: Indian National Congress,
controlled national government from independence to
March 1977, and split in January 1978; larger Congress
group is headed by former Prime Minister Indira Gandhi;
the smaller “official’’ Congress Party is headed by Swaran
Singh as provisional president; Janata Party (a merger of 5
pre-1977 election parties) led by Prime Minister Desai and
party president, Chandra Shekar; Communist Party of India
(CPI), C. Rajeswara Rao, general secretary; Communist
Party of India/Marxist’ (CPI/M), E. M. S. Namboodiripad,
general secretary; Communist Party of India/MarxistLenin-
ist (CPI/ML), Satyanarayan Singh, general secretary; All-
India-Anna Dravida Munnetra Kazhagam (ADMK), a
regional party in Tamil Nadu led by M. G. Ramachandran;
Akali Dal representing Sikh religious community in the
Punjab
Voting strength (1977 election): 43.17% Janata and CFD,
34.54% Congress, 4.30% CPI/M, 2.82% CPI, 15.17% regional
parties and others
Communists: 90,000 members of CPI (est.), 85,000
members of CPI/M (est.); Communist sympathizers, 13
million
Other political or pressure groups: various separatist
groups seeking reorganization of states; numerous “‘senas”’ or
militant/chauvinistic organizations, including Shiv Sena and
Dalit Panthers in Bombay, the Anand Marg, and the
Rashtriya Swayamserak Sangh
Member of: ADB, AIOEC, Colombo Plan, Common-
wealth, FAO, G-77, GATT, IAEA, IBRD, ICAC, ICAO,
ICO, IDA, IFC, IHO, ILO, International Lead and Zinc
Study Group, IMCO, IMF, IPU, ITC, ITU, IWC—
International Wheat Council, NAM, U.N., UNESCO, UPU,
WHO, WIPO, WMO. WSG, WTO','aec0f37e05d9a832c3f5297ec20a007aa3c05fc08a75778d6420e9a4cb45499f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('937f877e752423384ea5775d9878db72b3e7291ec8f61ecc8999608d4066ee94',1966,'IL','Israel','government',228,'Legal name: State of Israel
Type: republic
Capital: Jerusalem; not recognized by U.S. which
maintains Embassy in Tel Aviv
Political subdivisions: 6 administrative districts
Legal system: mixture of English common law and, in
personal area, Jewish, Christian and Muslim legal systems;
commercial matters regulated substantially by codes
adopted since 1948; no formal constitution; some of the
functions of a constitution are filled by the Declaration of
Establishment (1948), the basic laws of the Knesset
(legislature) relating to the Knesset, Israeli lands, the
president, the government and the Israel citizenship law; no
judicial review of legislative acts; legal education at Hebrew
University in Jerusalem; accepts compulsory ICJ jurisdiction,
with reservations
National holiday: Independence Day, 11 May
Branches: President Yitzhak Navon has largely ceremo-
nial functions; executive power vested in cabinet; unicam-
eral parliament (Knesset) of 120 members elected under a
system of proportional representation; legislation provides
fundamental laws in absence of a written constitution; 2
distinct court systems (secular and religious)
Government leader: Prime Minister Menachem Begin
101
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
ISRAEL/ITALY
Suffrage: universal over age 18
Elections: held every 4 years unless required by
dissolution of Knesset; last election held in May 1977
Principal political parties and leaders: Herut, Prime
Minister Menachem Begin, Defense Minister Ezer Weizman;
Liberal Party, Finance Minister Simcha Ehrlich; La’am,
Yigal Hurvitz; (Likud is a coalition formed of Herut,
Liberals and La’am); National Religious Party, Joseph Burg,
Zevulun Hammer; Democratic Movement, Yigael Yadin,
Shmuel Tamir; Israel Labor Party, Shimon Peres, Yitzhak
Rabin, Yigal Allon; SHELLI, Arieh Eliav
Voting strength: Likud 45 seats; National Religious Party
12 seats; Orthodox Augudat parties 5 seats; Samuel Flatto-
Sharon 1 seat; Moshe Dayan 1 seat; Labor Party-MAPAM-
Arab List Alignment 32 seats; Democratic Movement 7 seats;
Shai 7 seats; Assaf Yaguri ] seat; Independent Liberal Party
1 seat; Citizens Rights Movement 1 seat; RAKAH 5 seats;
SHELLI 2 seats :
Communists: RAKAH (predominantly Arab but with
Jews in its leadership) has some 1,500 members; the Jewish
Communist Party, MAKI, is now part of Moked, which is a
far-left Zionist party
Other political or pressure groups: right-wing Jewish
Defense League led by Rabbi Meir Kahane; Black Panthers,
a loosely organized youth group seeking more benefits for
oriental Jews;.Gush Emunim, Jewish religious zealots
pushing for freedom for Jews to settle anywhere on the West
Bank
Member of: FAO, GATT, IAEA, IBRD, ICAC, ICAO,
IDA, IFC, ILO, IMCO, IMF, IOOC, IPU, ITU, IWC—
International Wheat. Council, OAS (observer), U.N.,
UNESCO, UPU, WHO, WIPO, WMO, WSG, WTO','db4d7c8e2341d9b5f1d6d6fce2b878761529be60ad4897f536b785f4f3dc1222','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59907df2f8d67404cff7d55984bf1b261efac10322ee1b184c0abdad3874e9b3',1966,'IT','Italy','government',232,'Legal name: Italian Republic
Type: republic
Capital: Rome
Political subdivisions: constitution provides for establish-
ment of 20 regions; 5 (Sicilia, Sardegna, Trentino-Alto Adige,
Friuli-Venezia Giulia, and Valle d''Aosta) have been
functioning for some time and the remaining 15 regions
were instituted on 1 April 1972; 94 provinces
Legal system: based on civil law system, with ecclesiasti-
cal law influence; constitution came into effect 1 January
1948; judicial review under certain conditions in Constitu-
tional Court; has not accepted compulsory ICJ jurisdiction
National holiday: Anniversary of the Republic, 2 June
Branches: executive—President empowered to dissolve
Parliament and call national election; he is also Commander
of the Armed Forces and presides over the Supreme Defense
Council; otherwise, authority to govern invested in Council
of Ministers; legislative power invested in bicameral,
popularly elected Parliament; Italy has an independent
judicial establishment
Government leaders: President Alessandro Pertini; Pre-
mier Giulio Andreotti
Suffrage: universal over age 18 (except in Senatorial
elections where minimum age of voter is 25)
Elections: national elections for Parliament held every 5
years (most recent, June 1976); provincial and municipal
elections held every 5 years with some out of phase; regional
elections every 5 years (held June 1975)
Political parties and leaders: Christian Democratic Party
(DC), Benigno Zaccagnini (secretary general); Communist
Party (PCI), Enrico Berlinguer (secretary general), Luigi
Longo (party president); Socialist Party (PSI), Bettino Craxi
(secretary general), Pietro Nenni (party president); Social
Democratic Party (PSDI), Pietro Longo (secretary general);
Liberal Party (PLI), Valerio Zanone (party secretary); Italian:
Social Movement (MSI), Giorgio Almirante; Republican
Party (PRI), Oddo Biasini (party secretary); Ugo La Malfa
(party president)
Voting strength (1976 election); 38.7% DC, 34.4% PCI,
9.6% PSI, 6.1% MSI, 3.4% PSDI, 3.1% PRI, 1.3% PLI, 3.4%
other
Communists: 1,814,740 members (February 1978)
Other political or pressure groups: the Vatican; three
major trade union confederations (CGIL—Communist
dominated, CISL—Christian Democratic, and UIL—Social
Democratic, Socialist, and Republican); Italian manufactur-
ers association (Confindustria); organized farm groups
Member of: ADB, ASSIMER, Council of Europe, DAC,
EC, ECOWAS, ECSC, EEC, EIB, ELDO, ESRO,
EURATOM, FAO, GATT, IAEA, IBRD, ICAC, ICAO, IDA,
IEA, IFC, IHO, ILO, International Lead and Zinc Study
Group, IMCO, IMF, IOOC, IPU, ITU, NATO, OAS
(observer), OECD, U.N., UNESCO, UPU, WEU, WHO,
WMO, WSG
Legal name: Republic of the Ivory Coast
Type: republic, one-party presidential regime established
1960
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
t
‘
«
i
‘
rn
c |
a
a Oar, ee eee
om fa
i ie
w
ee A i i i i i i i i
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
IVORY COAST/JAMAICA
Capital: Abidjan .
Political subdivisions: 24 departments subdivided into
127 subprefectures
Legal system: based on French civil law system and
customary law; constitution adopted 1960; judicial review in
the Constitutional Chamber of the Supreme Court; legal
education at Abidjan School of Law; has not accepted
compulsory ICJ jurisdiction
National holiday: 7 December
Branches: President has sweeping powers, unicameral
legislature, separate judiciary
Government leader: President Felix Houphouet-Boigny
Suffrage: universal over age 21 :
Elections: uncontested Presidential and legislative elec-
tions held in November 1975 for 5-year term
Political parties and leaders: Parti Democratiqué de la
Cote d''Ivoire (PDCI), (only party); official party leader is
Secretary General Philippe Yace, but Houphouet-Boigny is
in control
Communists: -no Communist party; possibly some
sympathizers
Member of: AFDB, CEAO, EAMA, ECA, ECOWAS, EIB
(associate), Entente, FAO, G-77, GATT, IAEA, IBRD,
ICAO, ICO, IDA, IFC, ILO, IMCO, IMF, IPU, ITU, Niger
River Commission, NAM, OAU, OCAM, U.N., UNESCO,
UPU, WHO, WIPO, WMO, WTO','da4fb61f9093fe28a5cfa962a6c987a4709dec1b4a119e2992bb44c3c9a2e843','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('969967211550a928e2067cdf9c24267b6b5b853e5c24b6639d81dfc4062e029e',1966,'JM','Jamaica','government',236,'Legal name: Jamaica
Type: independent state within Commonwealth since
August 1962, recognizing Elizabeth II as head of state
Capital: Kingston
Political subdivisions: 12 parishes and the Kingston-St.
Andrew corporate area
Legal system: based on English common law; has not
accepted compulsory ICJ jurisdiction
National holiday: 7 August
Branches: cabinet headed by Prime Minister; 60-member
elected House of Representatives; 2l-member Senate (13
nominated by the Prime Minister, 8 by opposition leader);
judiciary follows British tradition under a Chief Justice
Government leader: Prime Minister Michael N. Manley;
Governor General Fiorizel Glasspole
Suffrage: universal, age 18 and over
Elections: at discretion of Governor-General upon advice
of Prime Minister but within 5 years; latest held 15
December 1976
Political parties and leaders: People’s National Party
(PNP), ‘Michael Manley; Jamaica Labor Party (JLP),
Edward Seaga
Voting strength: (1976 general elections) 56.8% PNP,
43.2% JLP
106
Communists: Communist Party of Jamaica (1975) and
Worker''s Party of Jamaica (1978) probably have combined
membership of only several hundred
Other political or pressure groups: New World Group
(Caribbean regionalists, nationalists, and leftist intellectual
fraternity); Rastafarians (Negro religious/racial cultists,
pan-Africanists); New Creation International Peacemakers
Tabernacle (leftist group); Workers Liberation League (a
Marxist coalition of students/labor)
Member of: CARICOM, FAO, G-77, GATT, IADB,
IAEA, IBA, IBRD, ICAO, ICO, IDB, IFC, ILO, IMF, ISO,
ITU, NAM, OAS, Pan American Health Organization,
SELA, U.N., UNESCO, UPU, WHO, WMO, WTO
Legal name: Japan
Type: constitutional monarchy
Capital: Tokyo
Political subdivisions: 47 prefectures (Ryukyus became
47th prefecture on 15 May 1972)
Legal system: civil law system with English-American
influence; constitution promulgated in 1946; judicial review
of legislative acts in the Supreme Court; accepts compulsory
IC} jurisdiction, with reservations
National holiday: Birthday of the Emperor, 29 April
Branches: Emperor is merely symbol of state; executive
power is vested in cabinet dominated by the Prime Minister,
chosen by the Lower House of the bicameral, elective
legislature (Diet); judiciary is independent
Government leader: Emperor Hirohito; Prime Minister
Masayoshi Ohira
Suffrage: universal over age 20
Elections: general elections held every 4 years or upon,
dissolution of Lower House, triennially for one-half of
Upper House
Political parties and leaders: Liberal Democratic Party
(LDP), T. Fukuda, President; Japan Socialist Party (JSP),
I. Asukata, Chairman; Democratic Socialist Party (DSP),
R. Sasaki, Chairman; Japan Communist Party (JCP), K.
Miyamoto, Presidium Chairman; Komeito (CGP), Y.
Takeiri, Chairman; New Liberal Club (NLC), Y. Kono;
Social Democratic Federation (SDF), H. Den
Voting strength (1977 election): 37.6% LDP, 21.6% JSP,
10.2% CGP, 9.6% JCP, 5.6% DSP, 4.8% NLC, minor parties,
6.1% independents
Communists: 350,000; 3,000,000 sympathizers
Member of: ADB, ASPAC, Colombo Plan, DAC, ESCAP,
FAO, GATT, IAEA, IBRD, ICAC, ICAO, ICO, IDA, IEA,
IFC, IHO, ILO, International Lead and Zinc Study Group,
IMCO, IMF, IPU, IRC, ISO, ITC, ITU, !WC—International
Whaling Commission, IWC—International Wheat Council,
OECD, U.N., UNESCO, UPU, WHO, WIPO, WMO, WSG','0dabca7b1b50285fc76a34654787df74f09da780a0fc8dc75c455d10aa0479d3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f078872c9fc97ec386aae0fb6c3f5ece88689dd3cb78fb32f942d0de14189ea1',1966,'JO','Jordan','government',240,'Legal name: Hashemite Kingdom of Jordan
Type: constitutional monarchy
Capital: ‘Amman
Political subdivisions: 8 governorates (3 are under Israeli
occupation) under centrally appointed officials
Legal system: based on Islamic law and French codes;
constitution adopted 1952; judicial review of legislative acts
in a specially provided High Tribunal;. has not accepted
compulsory ICJ jurisdiction
National holiday: Independence Day, 25 May
Branches: King holds balance of power; Prime Minister
exercises executive authority in name of King; Cabinet
appointed by King and responsible to parliament; bicameral
parliament with House of Representatives last chosen by
national elections in April 1967, and dissolved by King in
February 1976; Senate last appointed by King in November
1974; met briefly in February 1976 to amend constitution
allowing King to postpone elections; present parliament
subservient to executive; secular court system based on
differing legal systems of the former Transjordan and
Palestine; law Western in concept and structure; Sharia
(religious) courts for Muslims, and religious community
council courts for non-Muslim communities; desert police
carry out quasi-judicial functions in desert areas
Government leader: King Hussein
Suffrage: all citizens over age 20
Political parties’ and leaders: political party activity
illegal since 1957; Palestine Liberation Organization and
various smaller fedayeen groups clandestinely active on
West Bank; Muslim Brotherhood
Communists: party actively repressed, membership esti-
mated at less than 500:
Member of: Arab League, FAO, G-77, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMF, IPU, ITU, NAM, U.N.,
UNESCO, UPU, WHO, WIPO, WMO, WTO
Legal name: Democratic Kampuchea (Cambodia)
Type: Communist state
Capital: Phnom Penh
Political subdivisions: 19 or 20 provinces
Legal system: Judicial Committee chosen by People’s
Representative Assembly
National holiday: 17 April
Branches: State Presidium, composed of chairman and
two vice chairmen; cabinet, totally Communist; 250-mem-
ber People’s Representative Assembly elected 20 March
1976 for 5-year term; ten-member Assembly Standing
Committee
Government leader: Presidium Chairman, Khieu Sam-
phan; Prime Minister, Pol Pot; Deputy Prime Ministers, Ieng
Sary, Vorn Vet, Son Sen; Assembly Standing Committee
Chairman, Nuon Chea
Suffrage: universal over age 18
Political parties and leaders: political life dominated by
Khmer Communist Party
Member of: Colombo Plan, G-77, Mekong Committee
(inactive), NAM, U.N., WTO
110','4726804a8d247ed2c12ca1779254c3ea38c3d618e09b1d4b21b254a7c9ebd4bf','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c0466a3b38eb66039b57e252964e1e9e2ce7bcc072a319b555e9bdd412af74f',1966,'KE','Kenya','government',244,'‘Legal name: Republic of Kenya
Type: republic within Commonwealth since December
1963 ,
Capital: Nairobi
Political subdivisions: 7 provinces plus Nairobi Area
Legal system: based on English common law, tribal law
and Islamic law; constitution enacted 1963; judicial review
in Supreme Court; legal education at University Kenya
School of Law in Nairobi; accepts compulsory ICJ jurisdic-
tion, with reservations
National holiday: 12 December
Branches: President and Cabinet responsible to unicam-
eral legislature (National Assembly) of 170 seats, 158 directly
elected by constituencies and 12 appointed by the President;
Assembly must be reelected at least every 5 years; High
Court, with Chief Justice and at least 11 justices, has
unlimited original jurisdiction to hear and determine any
civil or criminal proceeding; provision for systems of courts
of appeal
Government leader: President Daniel T. arap Moi
Suffrage: universal over age 2]
Elections: general election (October 1974) elected present
National Assembly; next elections due 1979
Political party and leaders: Kenya Africa National Union
(KANU), president, Daniel arap Moi
Voting strength: KANU holds all seats in the National
Assembly
Communists: may be a few Communists and sym-
pathizers
Other political or pressure groups: labor unions
Member of: AFDB,. FAO, G-77, GATT, IAEA, IBRD,
ICAO, ICO, IDA, IFC, ILO, IMF, ISO, ITU, IWC—
International Wheat Council, NAM, OAU, U.N., UNEP,
UNESCO, UPU, WHO, WIPO, WMO, WTO
Legal name: Democratic People’s Republic of Korea
Type: Communist state; one-man rule
Capital: P’yongyang
Political subdivisions: 9 provinces, 2 special cities
(P’yongyang and Kaesong)
Legal system: based on German civil law system with
Japanese influences and Communist legal theory; constitu-
tion adopted 1948 and revised 1972; no judicial review of
legislative acts; has not accepted compulsory ICJ jurisdiction
National holiday: 9 September
Branches: Supreme Peoples Assembly theoretically super-
vises Legislative and Judicial function; State Administration
Council (cabinet) oversees ministerial operations
Government and party leaders: Kim II-song, ‘President
DPRK, and General Secretary of the Korean Workers Party;
Yi Chong-ok, Premier
Suffrage: universal at age 17
Elections: election to SPA every 4 years, but this
constitutional provision not necessarily followed—last elec-
tion November 1977
Political party: Korean Workers (Communist) Party;
claimed membership of about 2 million, or about 11% of
population
Member of: FAO, IAEA, ICAO, IPU, IRCS, ITU, U.N.
(observer status only), UNCTAD, UNESCO, WHO, WIPO,
WMO','75a7ae1378a59680787e7cfa09ee85555f5c171595e9195a1cce4f7bff9d899f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2697bd8422a6e9595cf4545db14b9e94d7a8774b4d6c48f93d0a69f1ce4b3c7',1966,'SA','Saudi Arabia','government',248,'Legal name: State of Kuwait
Type: nominal constitutional monarchy
Capital: Kuwait
Political subdivisions: 3 governorates, 10 voting
constituencies :
Legal system: civil law system with Islamic law
significant in personal matters; constitution took effect 1963;
key provisions regarding election of National Assembly
suspended in August 1976; judicial review of legislative acts
not yet determined; has not accepted compulsory IC]
jurisdiction
National holiday: 25 February
Branches: Council of Ministers
Government leader: Amir Jabir al-Ahmad al-Sabah
Suffrage: native born and naturalized males age 21 or
over — :
Elections: National Assembly dissolved by Emir’s decree
in August 1976 .
Political parties and leaders: political parties prohibited,
some small clandestine groups are active
Communists: insignificant
Other political or pressure groups: none
Member of: Arab League, FAO, G-77, GATT, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF, IPU, ITU,
OAPEC, OPEC, U.N., UNESCO, UPU, WHO, WIPO,
WMO, WTO
Legal name: Lao People’s Democratic Republic
Type: Communist state
Capital: Vientiane
Political subdivisions: 13 provinces subdivided into
districts, cantons, and villages
Legal system: based on civil law system; has not accepted
compulsory ICJ jurisdiction
National holiday: 2 December
Branches: President; 45-member Supreme People’s Coun-
cil; cabinet; cabinet is tota!ly Communist but council
contains a few nominal neutralists and non-Communists;
National Congress of People’s Representatives established
the current government structure in December 1975
Government leaders: President, Souphanouvong; Prime
Minister, Kaysone Phomvihan; Deputy Prime Ministers,
Nouhak Phoumsavan, Phoumi Vongvichit, Phoun Sipaseut,
and Khamtai Siphandon
Suffrage: universal over age 18
Elections: elections for new National Assembly, scheduled
for April 1, 1976, have been postponed
Political parties and leaders: Lao People’s Revolutionary
Party (Communist) includes Lao Patriotic Front and
Alliance Committee of Patriotic Neutralist Forces; other
parties are moribund
~ Communists: Lao People’s Revolutionary Party; member-
ship unknown
116
Other political or pressure groups: non-Communist
political groups are moribund; most leaders have fled the
country
Member of: ADB, Colombo Plan, ESCAP, FAO, G-77,
IBRD, ICAO, IDA, ILO, IMF, IPU, ITU, Mekong Commit-
tee, NAM, SEAMES, U.N., UNCTAD, UNESCO, UPU,
WHO, WMO, WTO
Legal name: State of Qatar
Type: traditional monarchy; independence declared in
1971
Capital: Doha
Legal system: discretionary system of law controlled by
the ruler, although new civil codes are being implemented,
Islamic law is significant in personal matters; a constitution
was promulgated in 1970 :
National holiday: 3 September
Government leader: Amir, Khalifa ibn. Hamad Al Thani |
Suffrage: no specific provisions for suffrage laid down
Elections: constitution calls for elections for part of State
Advisory Council, semi-legislative body, but none have been
held
Political parties and pressure groups: none; a few small
clandestine organizations are active
Branches: Council of Ministers; appointive 80-member
Advisory Council
Member of: Arab League, FAO, G-77, GATT (de facto),
IBRD, ICAO, ILO, IMF, NAM, OAPEC, OPEC, U.N.,
UNESCO, UPU, WHO, WIPO
Legal name: Kingdom of Saudi Arabia
Type: monarchy ,
Capital: Riyadh; foreign ministry and foreign diplomatic
representatives located in Jiddah
Political subdivisions: 18 amirates
Legal ‘system: largely based on Islamic law, several
secular codes have been introduced; commercial disputes
handled by special committees; has not accepted compulsory
ICJ jurisdiction ;
National holiday: 23 September
Branches: King Khalid (Al Saud, Khalid ibn Abd al-Aziz)
rules in consultation with royal family (especially Crown
Prince Fahd), and Council of Ministers
Government leader: King Khalid ibn "Abd al-’Aziz Al
Sa’ud
Communists: negligible
Member of: Arab League, FAO, G-77, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMF, ITU, IWC—International
Wheat Council, NAM, OAPEC, OPEC, U.N., UNESCO,
UPU, WHO, WMO','c8a55a1f6802c5a535e48c12876ac432b514bac48b2af7330635345e64ce1f9e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6bd8b22848e1ac17e1180eeee717a8cfb6a1c15c24c05fdbe0b352149465a97b',1966,'LB','Lebanon','government',252,'NOTE: Between early 1975 and late 1976, Lebanon was
torn by civil war between its Christians—then aided by
Syrian troops—and its Muslims and their Palestinian allies.
The cease-fire established in October 1976 between the
domestic political groups has generally held, despite
occasional fighting, although the country is still under the
occupation of Arab peacekeeping forces, almost entirely
Syrian. In March 1978 southern Lebanon was invaded by
Israeli troops. When the Israelis: withdrew in June, they
turned much of the south over to a United Nations interim
force, but left Christian militias in control of zones along the
border. The country’s own army is gradually being re-
established but is still too fragile to give the central
government effective power. Israel’s support of the Chris-
tians and Syria’s recent support of the Palestinians have
brought the two sides into rough equilibrium, but. no
progress has been made on national reconciliation or
political reforms—the original cause of the war. The
following description is based on the present constitutional
and customary practices of the Lebanese system.
Legal name: Republic of Lebanon
Type: republic
Capital: Beirut
Political subdivisions: 5 provinces
Legal system: mixture of Ottoman law, canon law, and
civil law system; constitution mandated in 1920: no judicial
review of legislative acts; legal education at University of
Lebanon; has not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 22 November
Branches: power lies with President elected by parlia-
ment (Chamber of Deputies); cabinet appointed by Presi-
dent, approved by parliament; independent secular courts
on French pattern; religious courts for matters of marriage,
divorce, inheritance, etc.; by custom, President is a Maronite
Christian, Prime Minister 4 Sunni Muslim, and president of
parliament a Shia Muslim; each of 9 religious communities
represented in parliament in proportion to national numeri-
cal strength ;
Government leader: President Ilyas Sarkis
Suffrage: compulsory for all males over 21; authorized for
women over 21 with elementary education
Elections: Chamber of Deputies held every 4 years or
within 3 months of dissolution of Chamber; latest April 1972
Political parties and leaders: political party activity is
organized along sectarian lines; numerous political groupings
exist, consisting of individual political figures and followers
motivated by religious, clan, and economic considerations;
all parties have well-armed militias which are still involved
in occasional clashes
117
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
LEBANON/LESOTHO
Communists: only legal Communist party in Middle East;
legalized in 1970: members and sympathizers estimated at
2,000-3,000
Other political or pressure groups: Palestinian guerrilla
organizations ;
Member of: Arab League, FAO, G-77, IAEA, IBRD,
ICAO, IDA, IFC, ILO, IMCO, IMF, IPU, ITU, IWC—
International Wheat Council, NAM, U.N., UNESCO, UPU,
WHO, WMO, WSG, WTO','5c934466f1e2accce07e092c082fab2f4de1243a070d26c0c75e36db3ed34277','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('413f3e8c7fd2f35211250eef1f095bfb7fd8353f0cba6784258efbc72d540c7f',1966,'LS','Lesotho','government',256,'Legal name: Kingdom. of Lesotho
Type: constitutional monarchy under King Moshoeshoe II;
independent member of commonwealth since 1966
Capital: Maseru
Political subdivisions: 9 administrative districts
Legal system: based on English common law and
Roman-Dutch Jaw; constitution came into effect 1966;
judicial review of legislative acts in High Court and Court of
Appeal; legal education at National University of. Lesotho;
has not accepted compulsory ICJ jurisdiction
National holiday: 4 October
Branches: executive, divided between a largely ceremo-
nial King and a Prime Minister who leads cabinet of at least
7 members; Prime Minister dismissed bicameral legislature
in early 1970 and subsequently ruled by decree until 1973
when he appointed Interim National Assembly to act as
legislative branch; judicial—63 Lesotho courts administer
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
A AR A ee lt |
AL AA
Ma Moe RAN
A PRA AA AA NAA RAL
PWT TTT Oe
Se eee Oe ae ae ee a
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
LESOTHO/LIBERIA
customary law for Africans, High Court and subordinate
courts have criminal jurisdiction over all residents, Court of
‘Appeal at Maseru has appellate jurisdiction
Government leader: Prime Minister Chief Leabua
Jonathan
Suffrage: universal for adults
Elections: elections held in January 1970; nullified
allegedly because of election irregularities, subsequent
elections promised at unspecified date
Political parties and leaders: National Party (BNP),
Chief Leabua Jonathan; Basutoland Congress Party (BCP),
Ntsu Mokhehle
Voting strength: in 1965 elections for National Assembly,
BNP won 382 seats; BCP, 22 seats; minor parties, 4 seats
Communists: negligible, Communist Party of Lesotho
banned in early 1970
Member of: Commonwealth, FAO, G-77, GATT (de
facto), IBRD, IDA, IFC, IMF, ITU, NAM, OAU, U.LN.,
UNESCO, UPU, WHO','77ccc798855136d3a7b59fc686cbb02897f92b5e1bb0d8c5dfee64c7eeabf68a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d312db6f07301a5bd9ef87697fa7b1d6cf3049fde483c893ed204483ed40100',1966,'LR','Liberia','government',260,'Legal name: Republic of Liberia
Type: republic in form; strong executive dominates, with
few constraints :
Capital: Monrovia
Political subdivisions: country divided into 9 counties;
President appoints all officials of significance
Legal system: based on U.S. constitutional theory; recent
codes drawn up by Cornéll University; constitution adopted
1847; amended 1907, 1926, 1934, 1955, and 1975;. no
constitutional provision for judicial review of legislative acts;
legal education at Louis Arthur Grimes School of Law,
University of Liberia; accepts compulsory ICJ jurisdiction,
with reservations
National holiday: Independence Day, 26 July
Branches: President, elected by popular vote, limited to a
single eight-year term, controls through appointive powers,
authority over national expenditures, and a variety of
informal sanctions; 2-house legislature elected by popular
vote; judiciary consisting of Supreme Court and variety of
lower courts .
Government leader: President William R. Tolbert, Jr.
Suffrage: universal 18 years and over
Elections: members of House of Representatives elected
for 4-year ‘terms, most recently in October 1975; Senate
members elected for 6-year terms, one-half elected in May
1973; President Tolbert, constitutional successor to President
Tubman who died in July 1971, completed the four year
term to which Tubman was elected and was then elected in
October 1975 for an eight-year term beginning in January
1976
Political parties and leaders: True Whig Party, in power
since 1878, only political party; President Tolbert is leader
Voting strength: 1975 elections uncontested; True Whig
Party won all but a handful of votes
Communists: no Communist Party and only a few
sympathizers
Member of: AFDB, ECA, ECOWAS, FAO, G-77, IAEA,
IBRD, ICAO, ICO, IDA, IFC, ILO, IMCO, IMF, IPU, ITU,
~ NAM, OAU, U.N., UNESCO, UPU, WHO','383ddf37fa7d4a7548cb341194f355c92e5f9e5452ab10e056d1894979728a03','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9503d5ebfe597ef188d46daa0d4764adf41721743d41e2a9494d19e60945715',1966,'LY','Libya','government',264,'Legal name: Socialist People’s Libyan Arab Jamahiriya
Type: republic; major overhaul of the constitution and
government structure in March 1977 established a system of
popular congresses which theoretically controls the ruling
General Secretariat; nominally confederated with Egypt and
Syria in Confederation of Arab Republics (CAR) on 1
September 1971
Capital: Tripoli
Political subdivisions: 10 administrative provinces closely
controlled by central government ,
Legal system: based on Italian civil law system and
Islamic -law; separate religious courts;. no constitutional
provision for judicial review of legislative acts; legal
education at Law School, at University of Libya at Benghazi;
has not accepted compulsory ICJ jurisdiction ,
National holiday: Independence Day, i September
Branches: paramount political power and authority rests
with the Secretariat of the General People’s Congress which
‘theoretically functions as a parliament with a cabinet called
the General People’s Committee
Government leaders: Col. Mu’ammar Qadhafi; Prime
Minister, “Abd al-’Ati ’Ubaydi
Suffrage:. universal
Elections: resentatives to the General People’s Congress
are drawn from popularly elected municipal committees
(elections are more or less continuous) election for CAR
assembly in March 1972
Political parties and leaders: Libyan Arab Socialist
Union, Ahmad Shahati, Secretary General; Mu’ammar
Qadhafi, President
Communists: no organized party, negligible membership
Other political or pressure groups: various Arab nation-
alist movements and the Arab Socialist Resurrection (Bath):
party with small, almost negligible memberships may be
functioning clandestinely -
Member of: AFDB, Arab League, FAO, G-77, IAEA,
IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF, IOOC, ITU,
NAM, OAPEC, OAU, OPEC, U.N., UNESCO, UPU, WHO,
WIPO, WMO, WSG','f751bcde834132fe44aa4630d793a8e929b27b05d4fbe3c73715dc182ee2cf00','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20f402db227701a0dd587adeece88424b5e65529dfdd2fc1e7ca1ea7aa3f13d7',1966,'LI','Liechtenstein','government',268,'Legal name: Principality of Liechtenstein
Type: hereditary constitutional monarchy
122
Capital: Vaduz
Political subdivisions: 11. districts
Legal system: based on Swiss law; constitution adopted
1921; judicial review of legislative acts in a special
Constitutional Court; accepts compulsory ICJ jurisdiction,
with reservations :
Branches: unicameral Parliament, hereditary Prince,
independent judiciary
Government leaders: Head of State, Grand Duke Jean;
Prime Minister Gaston Thorn
Suffrage: males age 20 and over
Elections: every 4 years; next elections 1978
Political parties and leaders: Fatherland Union Party
(VU), Dr. Alfred Hilbe; Progressive Citizens’ Party (FBP),
Dr. Gerard Batliner
Voting strength (1974 election): FBP over 50%
Communists: none
Member of: IAEA, ITU, UPU, considering U.N. member-
ship; desires affiliation with The Council of Europe; under a
1923 treaty, Switzerland handles Liechtenstein’s post and
telegraph systems, customs, and foreign relations, WIPO','b2c16e048fa1c19b64d7dc297ffaa3ff134ced2ac4560a490ee74e453ae4a95a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f894bd77ae9ff13ca6d4a459025e7018c1323354a6978ce42402680a34f4ace8',1966,'ZA','South Africa','government',275,'Legal name: Democratic Republic of Madagascar
Type: republic; real authority in hands of military-
dominated Supreme Revolutionary Council
Capital: Antananarivo
Political subdivisions: 6 provinces
Legal system: based on French civil law system and
traditional Malagasy law; constitution of 1959 modified in
October 1972 by law establishing provisional government
125
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Legal name: Republic of South Africa
Type: -republic
Capital: administrative, Pretoria; legislative, Cape Town;
judicial, Bloemfontein
Political subdivisions: 4 provinces, each headed by
centrally appointed administrator; provincial councils, elect-
ed by white electorate, retain limited powers
Legal system: based on Roman-Dutch law and English
common law; constitution enacted 1961, changing the Union
of South Africa into a Republic; possibility of judicial review
of Acts of Parliament concerning’ dual official languages:
accepts compulsory ICJ jurisdiction, with reservations
National holiday: Republic Day, 31 May
Branches: President as formal chief of state; Prime
Minister as head of government; Cabinet responsible to
bicameral legislature; lower house elected directly by white
electorate; upper house indirectly elected and appointed;
judiciary maintains substantial independence of government
influence
Government leaders: Prime Minister Pieter W. Botha;
President Johannes Vorster
Suffrage: general suffrage limited to whites over 18 (17 in
Natal Province)
Elections: must be held at least every 5 years; last
elections 30 November 1977
Political parties and leaders: National Party, P. W.
Botha, C. Mulder, R. F. Botha; Progessive Federal Party,
Colin Eglin, Ray Swart, Helen Suzman; New Republic
Party, Radclyffe Cadman; South Africa Party, Myburgh
Streicher; Herstigte Nasionale Party, J. Marais
Voting strength: (1977 general elections) parliamentary
seats: 134 National Party, 17 Progressive Federal Party, 10
New Republic Party, 3 South Africa Party
Communists: small Communist Party illegal since 1950;
party in exile maintains headquarters in London; Dr. Yasuf
Dadoo, Moses Kotane, Joe Slovo
Other political groups: (insurgent groups in exile) African
National Congress (ANC), Oliver Tambo; Pan-Africanist
Congress (PAC), leadership in dispute
Member of: GATT, IAEA, IBRD, ICAO, IDA, IFC, IHO,
International Lead and Zinc Study Group, IMF, ISO, ITU,
1WC—International Whaling Commission, IWC—Interna-
tional Wheat Council, U.N., UPU, WHO, WIPO, WMO,
WSG
Legal name: Republic of Transkei
Type: republic
Capital: Umtata
Political subdivisions: 28 administrative districts
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
SOUTH AFRICA/SPAIN
Legal system: based on English common law and African
customary law; decisions of Transkei Supreme Court can be
appealed to South African Supreme Court
Branches: President is formal chief of state; Prime
Minister is head of government; Cabinet responsible to
National Assembly, which has 75 seats for hereditary tribal
chiefs and 75 seats for popularly elected members
Government leader: Prime Minister Kaiser Matanzima
Suffrage: Transkeian citizens over 2] years of age
Elections: must be held at least every 5 years; last general
election October 1976
Political parties and leaders: Transkei National Inde-
pendence Party, Chief Kaiser Matanzima; Transkei People’s
Freedom Party, Cromwell Diko; Democratic Party, Hector
Ncokazi; New Democratic Party, Knowledge Guzana
Voting strength: (1976 general election) National Assem-
bly seats; 142 Transkei National Independence Party, 4
Transkei People’s Freedom Party, 2 Democratic Party, 2
New Democratic Party
Communists: no Communist Party
Legal name: Spanish State
Type: parliamentary monarchy defined by new constitu-
tion of December 1978, that completed transition from
191
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979','88e3c9a3e853153c608ead029c27376d3ce13fb2de945dd379c2dd6053775abe','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58ed3e630bd7adcebec20527c8222cbfd7ce9607548224dfad560c71752e98c4',1966,'MW','Malawi','government',279,''' Legal name: Republic of Malawi
Type: republic since July 1966; independent member of
Commonwealth since July 1964
Capital: Lilongwe:
Political subdivisions:.8 administrative regions and 24
districts
Legal system: based on English common law: and
customary law; constitution adopted 1964; judicial review of
legislative acts in the Supreme Court of Appeal; has not
accepted compulsory ICJ jurisdiction
National holiday: Republic Day, 6 July
Branches: strong presidential system with cabinet ap-
pointed by President; unicameral National Assembly of 87
elected and up to 15 nominated members; High Court with
Chief Justice and at least 2 justices
Government leader: Life President Dr. H: Kamuzu
Banda
Suffrage: universal adult (21 years)
Elections: parliamentary elections June 1978
Political parties and leaders: Malawi Congress Party
(MCP), Secretary General E. Bakili Muluzi, Deputy
Secretary Robson W. Chirwa
Communists: no Communist Party; Malawi maintains no
foreign relations with Communist governments
Member of: AFDB, EEC (associate member), FAO, G-77,
GATT, IBRD, ICAO, IDA, IFC, ILO, IMF, IPU, ISO, ITU,
OAU, U.N., UNESCO, .WHO, WIPO, WMO, WTO','42c2b99cf79ab70bc404563202a6555410981f3415d0b4186c8e2ceefb13e66d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0379ca02f150b0669cc776b8a7fe205b3613a0895e390c0a57f3a1f12d25a1f6',1966,'MY','Malaysia','government',283,'Legal name: Malaysia
Type:
Malaysia: constitutional monarchy nominally headed
by Paramount Ruler (King); a bicameral Parliament
consisting of a 58-member Senate and a 154-member House
of Representatives
Peninsular Malaysian states: hereditary rulers in all
but Penang and Malacca where Governors appointed by
Malaysian Government; powers of state governments limited
by federal. constitution
Sabah: self-governing state within Malaysia in which it
holds 16 seats in House of Representatives; foreign affairs,
defense, internal security, and other powers delegated to
federal government
Sarawak: self-governing state within Malaysia in which
it holds 24 seats in House of Representatives; foreign affairs,
defense, and internal security, and other powers are
delegated to federal government
Capital:
Peninsular Malaysia: Kuala Lumpur
Sabah: Kota Kinabalu
Sarawak: Kuching
Political subdivisions: 13 states (including Sabah and
Sarawak)
Legal system: based on English common law; constitution
came into force 1963; judicial review of legislative acts in the
Supreme Court at request of Supreme Head of the
Federation; has not accepted compulsory ICJ jurisdiction
National holiday: 31 August
Branches: 9 state rulers alternate as Paramount Ruler for
5-year terms; locus of executive power vested in Prime
Minister and cabinet, who are responsible to bicameral
parliament; following communal rioting in May 1969,
government imposed state of emergency and suspended
constitutional rights of all parliamentary bodies; parliamen-
tary democracy resumed in February 1971
Peninsular Malaysia: executive branches of 1] states
vary in detail but are similar in design; a Chief Minister,
appointed by hereditary ruler or Governor, heads an
executive council (cabinet) which is responsible to an
elected, unicameral legislature
Sarawak and Sabah: executive branch headed by
‘Governor appointed by central government, largely ceremo-
nial role; executive power exercised by Chief Minister who
heads parliamentary cabinet responsible to unicameral
legislature; judiciary part of Malaysian judicial system
Government leader: Prime Minister Hussein bin Onn
Suffrage: universal over age 20
Elections: minimum of every 5 years, last elections July
1978
Political parties and leaders:
Peninsular Malaysia: National Front, a confederation
of 11 political parties dominated by United Malays National
Organization (UMNO), Hussein Onn; opposition parties are
Democratic Action Party (DAP) and Islamic Party (PAS)
Sabah: Berjaya Party, Datak Harris Sallah; United
Sabah National Organization (USNO), Tan Sri Haji Mohd
Said Keruak; Sabah Chinese Association (SCA), Khoo Siak
Chiew
Sarawak: coalition Sarawak Alliance composed of the
Pesaka/Bumipatra Party, Rahman Yaacub, the United
People’s Party (SUPP), Ong Kee Hui, and Sarawak Chinese
Association; Sarawak National Party (SNAP), Stephen
Ningkan; Sarawak Native Peoples Party (PAJAR), Alli Kawi
Voting strength:
Peninsular Malaysia: (1978 election) National Front,
131 of 154 seats in lower house of parliament; Democratic
Action Party, 16 seats; Islamic Party, 5 seats; Sarawak
People’s Organization 1 seat; 1 independent seat
Sabah: (April 1976 Assembly Elections) Berjaya Party
controls 35 of 54 seats in State Assembly, USNO controls 19
remaining seats
Sarawak: (1974 elections) National Front controls all 48
State Assembly seats
Communists:
Peninsular Malaysia: approximately 3,000 armed
insurgents on Thailand side of Thai/Malaysia border;
approximately 300 full-time inside Peninsular Malaysia
Sarawak: 125 armed insurgents in Sarawak
Sabah: insignificant
Member of: ADB, ANRPC, ASEAN, Colombo Plan,
Commonwealth, FAO, G-77, GATT, IAEA, IBRD, ICAO,
IDA, IFC, ILO, IMCO, IMF, IPU, ITC, ITU, NAM, U.N.,
UNESCO, UPU, WHO, WMO, WTO','b0cf13310673758254fd2329cb81300d57fe010838929444ef04d130cf4ad16f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08af20ee66c35d2c13673f4b2de837db7563c1628feb514edca92699bbf7da75',1966,'MV','Maldives','government',289,'Legal name: Republic of Maldives
Type: republic
Capital: Male
Political subdivisions: 19 administrative districts corre-
sponding to <atolls .
Legal system: based on Islamic law with admixtures of
English common law primarily-in commercial matters; has
not accepted compulsory ICJ jurisdiction
National holiday: 29 March
Branches: popularly elected unicameral national legisla-
ture (Majlis) (members elected for 5-year terms); elected
President, chief executive; appointed Chief Justice responsi-
ble for administration of Islamic law
Government leader: President Maumoon Abdul Gayoom
Suffrage: universal over age 2]
Political parties and leaders: no organized political
parties; country governed by the Didi clan for the past eight
centuries :
Communists: negligible number
Member of: Colombo Plan, FAO, G-77, GATT (de facto),
IBRD, IMCO, IMF, ITU, NAM, U.N., UPU, WHO
Legal name: Republic of Mali
Type: republic; under military regime since November
1968
Capital: Bamako —
Political subdivisions: 6 administrative regions; 42
administrative districts (cercles), arrondissements, villages;
all subordinate to central government
Legal system: based on French civil law system and
customary law; constitution adopted 1974, comes into full
effect in 1979; judicial review of legislative acts in
Constitutional Section of Court of State; has not accepted
compulsory ICJ jurisdiction
National holiday: Independence Day, 22 September
Branches: executive authority exercised by Military
Committee of National Liberation (MCNL) composed of 11
army officers; under MCNL functional cabinet composed of
civilians and army officers; judiciary
Government leaders: Brig. Gen. Moussa Traore, President
of MCNL, Chief of State and head of government
'' Suffrage: universal over age 2]
Political parties and leaders: political activity proscribed
by military government but government in process of
forming new single party called the Democratic Union of
Malian People (UDPM), which will be the sole party under
civilian leadership, scheduled for 1979
Elections: constitutionally designated for 1979
Communists: a few Communists and some sympathizers
Member of: AFDB, APC, CEAO, ECA, ECOWAS, FAO,
G-77, GATT (de facto), IAEA, IBRD, ICAO, IDA, ILO,
IMF, ITU, Niger River Commission, NAM, OAU, OMVS
(Organization for the Development of the Senegal River
Valley), U.N., UNESCO, UPU, WHO, WMO, WTO
132','408732e2ffbf0375abbb530bfb6b47c6f2903a6328ec7a28433bc3e42ca53496','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f74ae8cefd6dd322da710587ee9b7d28896be3474fa2ad10d3b065d3bfba0c7',1966,'MT','Malta','government',293,'Legal name: Republic of Malta
Type: parliamentary democracy, independent republic
within the Commonwealth since December 1974
Capital: Valletta
Political subdivisions: 2 main populated islands, Malta
and Gozo, divided into 183 electoral districts (divisions)
Legal system: based on English common law; constitution
adopted 1961, came into force 1964; has accepted compul-
sory IC] jurisdiction, with reservations
Branches: executive, consisting of Prime Minister and
cabinet; legislative, comprising 65-member House of Repre-
sentatives; independent judiciary
National holiday: Republic Day, 13 December
Government leader: Prime Minister Dominic Mintoff
Suffrage: universal over age 18; registration required
Elections: at the discretion of the Prime Minister, but
must be held before the expiration of a 5-year electoral
mandate; last election September 1976
Political parties and leaders: Nationalist Party, Edward
Fenech Adami; Malta Labor Party, Dom Mintoff
Voting strength (1976 election): Labor, 34 seats (51.54%)
Nationalist, 31 seats (48.43%)
Communists: less than 100 (est.)
Member of: Commonwealth, Council of Europe, FAO,
G-77, GATT, IBRD, ICAO, ILO, IMCO, IMF, ITU, NAM,
U.N., UNESCO, UPU, WHO','1a32de4d6c07da32844dba05b6a106e183bcdb0bc458f405db79776c98300a1d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9de3aa722964418d707932cd5228c80e719a67062c1e23f30e39aeb5054de62',1966,'MQ','Martinique','government',297,'Legal name: Department of Martinique
Type: overseas department of France; represented by 3
deputies in the French National Assembly and 2 Senators in
the Senate; incumbent deputies Aime Cesaire, Camille Petit,
and Victor Sable reelected to National Assembly, 12 March
1978
Capital: Fort-de-France
Political subdivisions: 2 arrondissements; 34 communes,
each with a locally elected municipal council
Legal system: French legal system; highest court is a court
of appeal based in Martinique with jurisdiction over
Guadeloupe, French Guiana, and Martinique
Branches: executive, Prefect appointed by Paris; legisla-
tive, popularly elected council of 36 members and a
Regional Council including all members of the local general
council and the locally elected deputies and senators to the
French parliament; judicial, under jurisdiction of French
judicial system
Government leader: Prefect Raymond Heim
Suffrage: universal over age 18
Elections: General Council elections normally are held
every five years; last General Council election took place in
March 1978
Political parties and leaders: Rassemblement Pour la
Republique (RPR), Emile Maurice; Progressive Party of
Martinique (PPM), Aime Cesaire,; Communist Party of
Martinique (PCM), Armand Nicolas; Democratic Union of
Martinique (UDM), Leon-Laurent Valere; Socialist Party,
leader unknown; Federation of the Left, leader unknown
Voting strength: RPR, 2 seats in French National
Assembly; PPM, 1 seat (1973 election)
Communists: 1,000 estimated
Other political or pressure groups: Proletarian Action
Group (GAP), Socialist Revolution Group (GRS)','33211beed63417892a8419278f94c8e40ecb6b5e140687250c7a737d3e5ab8db','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb0a53bd47a8c355edaa5fcae426f9f21bbc3ff8988155d14e970c9ffe1e5947',1966,'MR','Mauritania','government',301,'Legal name: Islamic Republic of Mauritania
Type: republic; military seized power in bloodless coup 10
July 1978
Capital: Nouakchott
Political subdivisions: 12 regions and a capital district
NOTE: Mauritania has acquired administrative control of
the southern third of Western (formerly Spanish) Sahara
under an agreement with Morocco, but the legal question of
sovereignty over the area has yet to be determined. Spain''s
role as co-administrator of the disputed territory ended
February 1976. The newly acquired region, which lies below
the 24th parallel, becomes the district of Tiris el Gharbia—a
territorial division of the state. The district''s headquarters is
Dakhla, formerly Villa Cisneros. Tiris el Gharbia is
subdivided into three departments—Dakhla, Ausert, and
Aargub.
Legal system: based on French and Islamic law;
constitution suspended
National holiday: Independence Day, 28 November
Branches: executive, Military Committee for National
Recovery rules by decree; National Assembly and judiciary
suspended pending restoration of civilian rule
Government leader: President Moustapha Ould Mo-
hamed Saleck
Suffrage: universal for adults
Elections: in abeyance; last election October 1975
Political parties and leaders: suspended
135
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
oes 7 ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
MAURITANIA/MAURITIUS
Communists: no Communist Party, but there is a
scattering of Maoist sympathizers
Member of: AFDB, AIOEC, Arab League, CEAO,
CIPEC (associate), EAMA, EIB (associate), FAO, G-77,
GATT, IBRD, ICAO, IDA, IFC, ILO, IMCO, IMF, IPU,
ITU, NAM, OAU, OMVS (Organization for the Develop-
ment of the Senegal River Valley), U.N., UNESCO, UPU,
WHO, WIPO, WMO
Legal name: Kingdom of Morocco
Type: constitutional monarchy (constitution adopted
1972)
Capital: Rabat
Political subdivisions: 31 provinces and 2 prefectures
NOTE: Morocco has acquired administrative control over
the northern two-thirds of the former Spanish Sahara under
an agreement with Mauritania, but the legal question of
sovereignty over the area has yet to be determined. Spain’s
role as co-administrator of the disputed territory ended in
February 1976. Rabat has established three additional
provinces in its area of control, with headquarters at El
Aaiun, Semara, and Cabo Bojador.
Legal system: based on Islamic Jaw and French and
Spanish civil law system; judicial review of legislative acts in
Constitutional Chamber of Supreme Court; modern legal
education at branches of Mohamed V University in Rabat
and Casablanca and Karaouine University in Fes; has not
accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 3 March
Branches: constitution provides for Prime Minister and
ministers named by and responsible to King; King has
paramount executive powers;. unicameral legislature two-
thirds directly elected, one-third indirectly; judiciary inde-
pendent of other branches
Government leaders: King Hassan JJ; Prime Minister
Ahmed Osman
Suffrage: universal over age 20
Elections: local elections held 12 November 1976;
provincial elections held 25 January 1977; elections for new
National Assembly provided for in Constitution adopted 15
March 1972 were held June 1977
Political parties and leaders: Istiqlal Party, M’hamed
Boucetta; Socialist Union of Popular Forces, Abderrahim
Bonabid; Popular Movement (MP), Mahjoubi Aherdan;
Constitutional and Democratic Popular Movement (MPCD),
Dr. Abdelkrim Khatib; National Union of Popular Forces
(UNFP), Abdallah Ibrahim and Mahjoub Ben Seddik;
141
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
MOROCCO/MOZAMBIQUE
National Assembly of Independents (RNI) formed in
October 1978 is pro-government grouping of previously
unaffiliated deputies in parliament, Ahmed Osman, Demo-
cratic Constitutional Party (PDC), Mohamed Hassan Ouaz-
zani; Party for Progress and Socialism (PPS), legalized in
‘August 1974, is front for Moroccan Communist Party
(MCP), which was proscribed in 1959, Ali Yata; Istiqlal and
the UNFP formed a National Front in-July 1970 to oppose
the new constitution, boycotted the parliamentary elections
and the 1972 constitutional referendum
Voting strength: pro-government independents hold
absolute majority in new Chamber of Representatives; with
‘palace-oriented Popular Movement deputies, the govern-
ment holds over two-thirds of the seats
Communists: 300 est.
Member of: AFDB, Arab League, EC (association until
1974), FAO, G-77, GATT, IBRD, ICAO, IDA, IFC, ILO,
International Lead and Zine Study Group, IMCO, IMF,
IOOC, IPU, ITU, NAM, OAU, U.N., UNESCO, UPU,
WHO, WIPO, WMO, WTO .
Type: legal status of territory and question of sovereignty
unresolved; territory partitioned between Morocco and
223
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDPO8-00534R000100140001-7
January 1979
WESTERN SAHARA/WESTERN SAMOA
Mauritania in April 1976, with Morocco acquiring the
Northern two-thirds including the rich phosphate reserves at
Bu Craa; both countries have established political adminis-
tration within their own zones of. influence; the line of
partition begins at a point on the coast where the Atlantic
Ocean intersects the 24th parallel, and extends in a
southeasterly direction to the point where the 23d parallel
intersects ‘the 13th meridian','0403e7f25d28e79a92c62c14ca0966e6228d2a43820dd962b486c463775c621f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ea9ebef9865ca8344c6309f7bca3255caa4e01b632a71db58e938962e66f8be',1966,'MU','Mauritius','government',305,'Legal name: Mauritius
Type: independent state since 1968, recognizing Elizabeth
II as Chief of State
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Capital: Port Louis
Political subdivisions: 5 organized municipalities and
various island dependencies
Legal system: based on French civil law system with
elements of English common law in certain areas; constitu-
tion adopted 6 March 1968
National holiday: Independence Day, 12 March
Branches: executive power exercised by Prime Minister
and 2l-man Council of Ministers; unicameral legislature
(National Assembly) with 62 members elected by direct
suffrage, 8 specially elected
Government leader: Prime Minister Dr. Seewoosagur
Ramgoolam
Suffrage: universal over age 18
Elections: legislative elections held in December 1976;
municipal elections held in 1977
Political parties and leaders: a government coalition
consisting of Labor Party (S. Ramgoolam) and Parti
Mauricien Social Democrate (G. Duval); opposition parties—
Independent Forward Bloc (S. Bissoondoyal), Mauritius
Democratic Union (M. Lesage), Mouvement Militant Mauri-
tian (P. Berenger), Mouvement Militant Mauritian Socialiste
Progressist (D. Virahsawmy)
Voting strength: the Mauritius Labor Party and the Parti
Mauricien Social Democrate have a coalition in the National
Assembly of 38 seats; the Movement Militant Mauritian has
32 seats
Communists: may be 2,000 sympathizers; several Com-
munist organizations; Mauritius Lenin Youth Organization,
Mauritius Women’s Committee, Mauritius Communist
Party, Mauritius People’s Progressive Party, Mauritius
Young Communist League, Mauritius Liberation Front,
Chinese Middle School Friendly Association, Mauri-
tius/USSR Friendship Society
Other political or pressure groups: Tamil United Party,
Mauritius Workers Party
Member of: Commonwealth, FAO, G-77, GATT, IBRD,
ICAO, IDA, IFC, ILO, IMF, ISO, ITU, IWC—International
Wheat Council, NAM, OAU, OCAM, U.N., UNESCO, UPU,
WHO, WIPO, WMO, WTO
Legal name: Department of Reunion
Type: overseas department of France; represented in
French Parliament by three Deputies and two Senators
Capital: Saint-Denis
Legal system: French law
Branches: Reunion is administered by a Prefect ap-
pointed by the French Minister of Interior, assisted by a
Secretary-General and an elected 36-man General Council
Government leader: Prefect Paul Cousseran
Suffrage: universal adult:
Elections: last municipal and géneral council elections in
1976; Parliamentary election March 1978
Political parties and leaders: Reunion Communist Party
(RCP) led by Paul Verges, only organized political
movement on island; other political candidates affiliated
with metropolitan French parties, which do not maintain
permanent organizations on Reunion
Voting strength (Parliamentary election 1978): Rally for
the Republic (formerly Union of Democrats for the
Republic) elected one deputy; Giscardian alliance elected
one Republican deputy and one Centrist deputy
17]
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDPO8-00534R000100140001-7
January 1979
REUNION/RHODESIA
Communists: Communist Party small—probably only
15-20 hard-line Communists—but has support among
sugarcane cutters and in Le Port district
Member of: EC, WFTU','a35914e5da748feaa708a8f8873ae1cde463566a92debf2c84d8595a61656c42','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1621c6faaaa06ae7fbb19dd2e153dbe7ec39c9cb7482f90776bd1c553d23689b',1966,'MC','Monaco','government',309,'Legal name: Principality of Monaco
Type: constitutional monarchy
Capital: Monaco
Political subdivisions: 4 sections
Legal system: based on French law; new constitution
adopted 1962; has not accepted compulsory ICJ jurisdiction
National holiday: 19 November
Branches: National Council (18 members); Communal
Council (15 members, headed by a mayor)
Government leader: Prince Rainier III
Suffrage: universal
Elections: National Council every 5 years; most recent
1978
Political parties and leaders: National Democratic
Entente, Democratic Union Movement, Monegasque Action-
ist (1973)
Voting strength: figures for 1978: National Democratic
Entente, 18 seats : :
Member of: IAEA, IHO, IPU, ITU, U.N. (permanent
observer), UNESCO, UPU, WHO, WIPO','cf09bd81ae3870e336350203be723081b463e943beffc24bc419aa43dd95b9d1','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19493d79bd5d484b82a68e807a8bbafd012f76a036e5fc3f648db8f0bda5f56e',1966,'MN','Mongolia','government',313,'Legal name: Mongolian People’s Republic
Type: Communist state
Capital: Ulaanbaatar
Political subdivisions: 18 provinces and 2 autonomous
municipalities (Ulaanbaatar and Darhan)
Legal system: blend of Russian, Chinese, and Turkish
systems of law; new constitution adopted 1960; no constitu-
tional provision for judicial review of legislative acts; legal
education at Ulaanbaatar State University; has not accepted
compulsory ICJ jurisdiction
National holiday: People’s Revolution Day, 11 July
Branches: constitution provides for a People’s Great
Hural (national assembly) and a highly centralized
administration os
Party.and government leaders: Yumjaagiyn Tsedenbal,
First Secretary of the MPRP and Chairman of the Presidium
of the People’s Great Hural; Jambyn Batmonh, Chairman of
the Council of Ministers
‘Suffrage: universal; age 18 and over
Elections: national assembly elections held every 4 years;
last election held June 1977
Political party: Mongolian People’s Revolutionary (Com-
munist) Party (MPRP); estimated membership, 67,000
(1976) .
Member of: CEMA, ESCAP, IAEA, ILO, IPU, ITU, U.N.,
UNESCO, UPU, WHO, WMO','027ec5659d304e866fcec36c166a6ee35a2d81007f43c122473877947eea9d3d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1c73725af9d2d28184b0a4002e7d944f61461f9f6d75155dad8bb75f307ea07',1966,'MZ','Mozambique','government',318,'Legal name: People’s Republic of Mozambique
Type: peoples republic; achieved independence from
Portugal in June 1975"
Capital: ‘Maputo
Political subdivisions: 10 districts administered by
district governors; municipalities governed by appointed
official
Legal system: based on Portuguese civil law system and
customary law
National holiday: Independence Day; 25 June
Branches: none established
Government leader: President Samora Moises Machel
Suffrage: not yet established
Elections: information not available on future election
schedule
Political parties and leaders: the Mozambique Liber-
ation Front (FRELIMO), led by Samora Machel, is only
legal party
Communists: none known
Member of: G-77, ILO, NAM, OAU, U.N.
Legal name: Kingdom of Swaziland
‘Type: monarchy, under King Sobhuza II, independent
member of Commonwealth since September 1968
Capital: Mbabane (administrative)
Political subdivisions: 4 administrative districts
Legal system: based on South African Roman-Dutch law
in statutory courts, “Swazi traditional law and custom in
traditional courts; legal education at University of Botswana
and Swaziland; has not accepted compulsory ICJ jurisdiction
about 15% of wage earners are
197
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
‘ January 1979
SWAZILAND/SWEDEN
National holiday: Independence Day, 6 September
Branches: in October 1978 King promulgated a new
constitution; specifics are not available but plans include
nomination by each of the 40 local councils (Tinkhundla) of
several candidates for a national consultative body; King
would then select from among these nominees, members for
a national committee (Libundla) which would be unicam-
eral. Elections were held on 27 October 1978; previous
constitution was abrogated in April 1973; since that time
King has asserted personal rule
Government leaders: Head of State King Sobhuza II,
Prime. Minister Maj. Gen. Maphevu Dlamini
Suffrage: universal for adults
Communists: no Communist Party
Member of: AFDB, FAO, G-77, GATT (de facto), IBRD,
ICAO, IDA, IFC, ILO, IMF, ISO, ITU, NAM, OAU, U.N.,
UPU, WHO','7d2cb1c7e3fa0c1ba4d5d1ef3dea102a113d079fdbd6cadbd559cac70385045e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba24413013101265f98a07a9bc5ae70fd850fd40ced3965c38941248b0eff61e',1966,'NA','Namibia','government',322,'Legal name: Namibia
Type: former German colony of South-West Africa
mandated to South Africa by League of Nations in 1920;
U.N. formally ended South Africa’s mandate on October 27,
1966, but South Africa has retained administrative control
Capital: Windhoek
Political subdivisions: 10 tribal homelands, mostly in
northern sector, and zone open to white settlement with
administrative subdivisions similar to-a province of South
Africa
Legal system: based on Roman-Dutch law and customary
law ;
Branches: since September 1977 an administrator-gen-
eral, appointed by South African government, has exercised
coordinative functions over zone of: white settlement, where
white-elected Legislative Assembly handles some _ local
matters, and tribal homelands, where traditional chiefs and
representative bodies exercise limited autonomy
Government leader: Martinus T. Steyn, Administrator-
general :
Suffrage: franchise for Legislative Assembly limited to
white adults; several tribal homelands have adult franchise
144
for homeland legislatures; all ethnic groups eligible to vote in
projected election for constituent assembly
Elections: last general election, Legislative Assembly,
1974
Political parties and leaders: white parties—National
Party of South-West Africa (NPSWA), Abraham H.
du Plessis; Federal Party, Bryan O’Linn; Republican Party,
Dirk Mudge; most of the nonwhite parties belong to one of
two muli-ethnic alliances—the Democratic Turnhalle Alli-
ance (the traditional tribal leaders and the white Republican
Party) or the Namibian National Front (the white Federal
Party and nonwhite groups that oppose the bantustan
system)
Voting strength: (1974 election) NPSWA won all 18 seats
in Legislative Assembly
Communists: no Communist Party, SWAPO guerrilla
force is supported by U.S.S.R., Cuba, and other Communist
states as well as OAU
Other political or pressure groups: South-West Africa
People’s Organization (SWAPO), led by Sam Nujoma,
maintains a foreign-based guerrilla movement; is predomi-
nantly Ovambo but has some influence among other tribes;
is the only Namibian group recognized by the U.N. General
Assembly and the Organization of African Unity','fa905877a1be1ed96ca73e2021baf4d73d453a3641acb5817ad6900de6007521','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b2f077c8c70927e72483977f8a499f661abf9d700fa7742c162e6c02954388a',1966,'NP','Nepal','government',326,'Legal name: Kingdom of Nepal
Type: constitutional monarchy; King Birendra exercises
autocratic control over multitiered panchayat system of
Capital: Kathmandu
Political subdivisions: 75 districts, 14 zones
Legal system: based on Hindu legal concepts and English
common law; legal education at Nepal Law College in
Kathmandu; has not accepted compulsory ICJ jurisdiction
National holiday: Birthday of the King, 28 December
Branches: Council of Ministers appointed by the King;
indirectly elected National Panchayat (Assembly)
146
_ Government leaders: King Birendra Bir Bikram Shah -
Dev; Prime Minister Kirti Nidhi Bista
Suffrage: universal over age 21
Elections: village and town councils (panchayats) elected
by universal suffrage; district, zonal, and National Pan-
chayat members indirectly elected, most for 6-year terms; 15
National Panchayat members elected from five class and
professional organizations (women, workers, peasants, youth,
and ex-servicemen), four directly elected by all voters
possessing a B.A: or its equivalent, and 16 are appointed by
the: King ;
Political parties and leaders: all political parties
outlawed
Communists: the combined membership of the two wings
of the Communist Party of Nepal (CPN) about 6,500, the
majority (perhaps 5,000) in the pro-Chinese wing; the CPN
continues to operate more or less openly, but internal
dissension has greatly hindered its effectiveness
Other political or pressure groups: proscribed Nepali
Congress Party led by B. P. Koirala
Member of: ADB, Colombo Plan, FAO, G-77, IBRD,
ICAO, IDA, IFC, ILO, IMF, IPU, ITU, NAM, U.N.,
UNESCO, UPU, WHO, WMO, WTO','aed20a78851649683f3ae7a868b305f34567335cb1341c8f12ed2fa14ded4909','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7177609d62329a0e394ceb9ca9a394ab77c5407b5b128f07208c3243a4a72f57',1966,'NL','Netherlands','government',330,'Legal name: Kingdom of the Netherlands
Type: constitutional monarchy
Capital: Amsterdam, but government resides at The
Hague
Political subdivisions: 11 provinces governed by centrally
appointed commissioners of Queen
Legal system: civil law system incorporating French
penal theory; constitution of 1815 frequently amended,
reissued 1947; judicial review in the Supreme Court of
legislation of lower order than Acts of Parliament; legal
education at six law schools; accepts compulsory ICJ
jurisdiction, with reservations ;
National holiday: Birthday of the Queen, 30 April
Branches: executive (Queen and Cabinet of Ministers),
which is responsible to bicameral States General (parlia-
ment); independent judiciary
Government leaders: Head of State, Queen Juliana;
Prime Minister, Andreas A. M. van Agt
Suffrage: universal over age 18
Elections: must be held at least every 4 years for lower
house (most recent held May 1977), and every 3 years for
half of upper house (most recent July ©1977)
Political parties and leaders: Christian Democratic
Appeal (CDA), coalition of KVP, ARP, and CHU formed
prior to 1977 elections; Catholic People’s Party (KVP), W.
J. Vergeer; Antirevolutionary (ARP), H. A. de Boer; ~
Labor (PvdA), Mrs. C. (Ien) van den Heuvel; Liberal (VVD),
F. Korthals Altes; Christian Historical Union (CHU), Otto
W. A. Baron van Verschuer; Democrats ''66 (D-66), F.
Eenstra; Communist (CPN), Henk Hoekstra; Pacifist Social-
ist (PSP), Lamber Meertens; Political Reformed (SGP), H. G.
Abma; Reformed Political Union (GVP), G. Veurink;
‘Radical Party (PPR), Wisnand Van Hoogevest; Democratic
Socialist "70 (DS-70), H. Staneke; Farmers’ Party (BP),
Hendrik Koekoek
Voting strength (1977 election): 33.81% PvdA, 31.91%
CDA, 17.95% VVD, 5.43% D’66; 2.13% SGP, 1.73%. CPN,
1.69% PPR, 0.96% GPV, 0.94% PSP, 0.84% BP, 0.72% DS’70
147
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
ee
Declassified and Approved For Release 2012/09/02 : CIA-RDPO8-00534R000100140001-7
January 1979
NETHERLANDS /NETHERLANDS ANTILLES
Communists: 13,000 est. members
Other political or pressure groups: great multinational
firms; Socialist, Catholic, and Protestant trade .unions;
Federation of Catholic and Protestant Employers Associ-
ations; the non-denominational Federation of Netherlands
Enterprises
Member of: ADB, Benelux, Council of Europe, DAC, EC,
ECE, EEC, EIB, ELDO, EMA, ESRO, EURATOM, FAO,
GATT, IAEA, IBRD, ICAC, ICAO, ICES, ICO, IDA, IEA,
IFC, IHO, ILO, International Lead and Zinc Study Group,
IMCO, IMF, IPU, ITC, ITU, IWC—International Wheat
Council (with respect to interests of the Netherlands Antilles
and Surinam), NATO, OAS (observer), OECD, U.N.,
UNESCO, UPU, WEU, WHO, WIPO, WMO, WSG','bdd7d437da4167fa4b3e3ddf6577bb3c565f4a8fa157e9adac12e2bb29d5658b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7965344f81e52819b534c0178d9f9a3cefde81a70f1b7542c655dd993af8b220',1966,'NI','Nicaragua','government',337,'Legal name: Republic of Nicaragua
Type: republic
Capital: Managua
Political
departments
subdivisions: ] national district and 16
Legal system: based on Spanish civil law system;
constitution adopted in 1974; legal education at Universidad
Nacional de Nicaragua and Universidad Centroamericana;
accepts compulsory ICJ jurisdiction
National holiday: Independence Day, 15 September
Branches: President (traditionally dominant), bicameral
legislature, judiciary elected by legislature, and Supreme
Electoral Tribunal (4th branch)
Debayle
Suffrage: universal over age 18 if married or literate,
otherwise 21
leader: President Anastasio SOMOZA
Elections: every 6 years; municipal elections every 3 years
Political parties and leaders: Nationalist Liberal Party
(PLN), Anastasio Somoza; Nicaraguan Conservative Party
(PCN), Rene Sandino
_ Voting strength (1974 elections): PLN, 95% of votes;
PCN, 5% of votes; PCN will, however, occupy 40% of
legislative seats by constitutional provision
Communists: Communist movement split into hard-line
Nicaraguan Socialist Party (PSN) illegal, 60 members;
soft-line Nicaraguan Communist Party (PCN) illegal, 40
members, and small anti-Somoza terrorist organization
Sandinist National Liberation Front (FSLN) 1,200 members
and larger number of sympathizers
Other political or pressure groups: Democratic Union of.
Liberation (UDEL), an opposition front lacking legal status
of a political party, composed of anti-Somoza_ political
movements and labor groups with orientations ranging from
conservative to Christian Democrat to Communist, leader-
ship includes Rafael Cordova Rivas, Ramiro Sacasa, Ignacio
Zelaya, Domingo Sanchez; Nicaraguan Development Insti-
tute (INDE), a private sector pressure group with two
FUNDE and EDUCREDITO which,
respectively, promote cooperatives and disburse educational
loans; group of 12, an FSLN associated opposition group of
prominent professional men; Nicaraguan Democratic Move-
ment (MDN), a private sector anti-Somoza organization led
by Alfonso Robelo
Member of: CACM, FAO, G-77, GATT, IADB, IBRD,
ICAC, ICAO, ICO, IDA, IDB, IFC, ILO, IMF, INTELSAT,
IPU, ISO, ITU, NAMUCAR (Caribbean Multinational
operative arms:
153
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
NICARAGUA/NIGER
Shipping Line—Naviera nacional del Caribe), OAS,
ODECA, SELA, U.N., UNESCO, UPEB, UPU, WHO,
WMO, WTO','4b7f8d9d005e98d7aa79622b3180e67e57fae0eaaeefb4e524ce09900b77263d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04ee3f6967f2e6866bb9d4695bdc2a57a6ba458425cfb6209ed55c213d8de0ee',1966,'NE','Niger','government',341,'Legal name: Republic of Niger
Type: republic; military regime in power since April 1974
Capital: Niamey-
Political subdivisions: 7 departments, 32 arrondissements
‘Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
URAL ARR AAR AA ERA RAR A AO RO AR OO Ue AR aR OP Ue
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
NIGER/NIGERIA
Legal system: based on French civil law system and
customary law; constitution adopted 1960, suspended 1974;
judicial review of legislative acts in Constitutional Chamber
of the Supreme Court; has not accepted compulsory ICJ
jurisdiction ;
National holiday: Proclamation of the Republic, 18
December
Branches: executive authority exercised by Supreme
Military Council (SMC) composed of army officers; cabinet
includes civilians , :
Government leader: Lt. Col. Seyni Kountche, President
of Supreme Military Council and Chief of State
Suffrage: suspended
Elections: political activity banned
Political parties and leaders: political parties banned
Communists: no Communist party; some sympathizers in
outlawed, Sawaba party
Member of: AFDB, APC, CEAO, EAMA, ECA,
ECOWAS, Entente, "FAO, G-77, GATT, IAEA, IBRD,
ICAO, IDA, ILO, IMF, IPU, ITU, Lake Chad Basin
Commission, Niger River Commission, NAM, OAU, OCAM,
U.N., UNESCO, UPU, WHO, WIPO, WMO','f9c73c9ed1b9536697b4c4b7d59c5470d0e4a45a45b5a48bc3e9babef0fe872e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c31398385e104c7fea44d546eeb2544fa4f352edda884a1a9b4ede69f1e3023',1966,'NG','Nigeria','government',346,'Legal name: Federal Republic of Nigeria
Type: federal republic since 1963; under military rule
since January 1966
Capital: Lagos
Political subdivisions: 19 states, headed by military
governors
Legal system: based on English common law, tribal law,
and Islamic law; new constitution has been promulgated for
restoration of civilian rule in October 1979; accepts
compulsory ICJ jurisdiction, with reservations
National holiday: Independence Day, 1 October
Branches: Federal Military Government; decrees issued
by Supreme Military Council, advised by largely civilian
Federal Executive Council
Government leader: Lieutenant General Olusegun Oba-
sanjo, Head of Federal Military Government and Com-
mander in Chief of Nigerian Armed Forces
Suffrage: universal adult suffrage
Elections: nonpartisan elections for local government
councils held in late 1976; the military has promised to
restore power to an elected civilian regime after state and
federal elections are held between April and October 1979
Political parties and leaders: political activity was
legalized in September 1978, after a 12-year ban, to permit
the organization of parties in preparation for election in
1979 ;
Communists: the Nigerian left is divided among three
minor socialist-oriented political parties and a small pro-
’ Communist underground, leftist leaders are prominent in
the country’s central labor organization but have little
influence on government
156
Member of: AFDB, APC, Commonwealth, ECA,
ECOWAS, FAO, G-77, IAEA, IBRD, ICAO, ICO, IDA, IFC,
ILO, IMCO, IMF, ISO, ITC, ITU, [WC—International
Wheat Council, Lake Chad Basin Commission, Niger River
Commission, NAM, OAU, OPEC, U.N., UNESCO, UPU,
WHO, WMO, WTO','14fdfc10ab43848e9673a4bdc2a96b8c8cd77d496539ca2edb0d73ef2c462205','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b306e350823845c3c0b76f684d7dc5639a43be337ae573fd4665b27382524d6d',1966,'NO','Norway','government',350,'Legal name: Kingdom of Norway
Type: constitutional -monarchy
Capital:, Oslo
Political subdivisions: 19 counties, 2 territories, 404
communes, 47 towns
Legal system: mixture of customary law, civil law system,
and common law traditions; constitution adopted 1814,
‘modified 1884; Supreme Court renders advisory opinions to
legislature when asked; legal education at University of Oslo;
accepts compulsory ICJ jurisdiction, with reservations
National holiday: Constitution Day, 17 May
Branches: legislative authority rests jointly with Crown
and parliament (Storting); executive power vested in Crown
but exercised by cabinet responsible to parliament; Supreme
Court, 5 superior courts, 104 lower courts
Government leaders: King Olav V; Prime Minister Odvar
Nordli
Suffrage: universal, but not compulsory, over age 20
Elections: held every 4 years (next in September 1981)
Political parties and leaders: Labor, Reiulf Steen;
Conservative, Erling Norvik; Center, Gunnar Stalsett;
Christian People’s, Lars Kosvald; Liberal, Hans Hammond
Rossbach; New People’s Party, Magne Lerheim; Socialist
Left, Berge Furre; Norwegian Communist, Martin Gunnar
Knutsen; Progressive, Arve Loennum
Voting strength (1977 election): Labor, 42.5%; Conserva-
tive, 24.6%; Christian People’s, 12.1%: Center, 8.6%; New
People’s Party (anti-tax), 1.7%; Socialist Left (Socialist .
Electoral Alliance) (formerly anti-tax), 4.1%; liberal, 3.2% .
Progressive, 1.9%; Norwegian Communist, 0.4%; Red Elec-
tion Alliance, 0.6%, latter two are communist parties
Communists: 2,500 est.; a number of sympathizers as
indicated by the 22,500 Communist votes cast in the 1969
election (in the 1973 election the Communist Party vote total
was submerged in the 241,851 votes won by the Socialist
Electorial Alliance which included the Norwegian Commu-
nist Party and two other parties)
Member of: ADB, Council of Europe, DAC , EC (Free |
Trade Agreement), EFTA, ESRO (observer), FAO, GATT,
IAEA, IBRD, ICAC, ICAO, ICES, ICO, IDA, IEA (associate
member), IFC, IHO, ILO, International Lead and Zinc
Study Group, IMCO, IMF, IPU, ITU, IWC—International
Whaling Commission, I]WC—International Wheat Council,
NATO, Nordic Council, OECD, U.N., UNESCO, UPU,
WHO, WIPO, WMO, WSG
157
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
NORWAY/OMAN
Legal name: Sultanate of Oman
'' Type: absolute monarchy; independent, with strong
residual U.K. influence
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
he a a i it, a il
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
OMAN/PAKISTAN
Capital: Muscat
Political subdivisions: 1 province (Dhofar), 9 regions, and
numerous districts (wilayats)
Legal system: based on English common law and Islamic
law; no constitution; ultimate appeal to the Sultan; has not
accepted compulsory ICJ. jurisdiction .
National holiday: 18 November
Government leader: Sultan Qabus ibn Sa‘id Al Bu Sa‘id
Other political or pressure groups: Popular Front for the
Liberation of Oman (PFLO), based in South Yemen
Member of:. Arab League, FAO, G-77, IBRD, ICAO,
IDA, IFC, IMF, NAM, U.N., UNESCO, UPU, WHO >','879cf7115c6cbaa5279076a8aa11bef4606ed366c3dc296a7e3a52a746b60c38','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e1a6a9879a6a6ea2b69ce52f62390482df4c93f70809f4b3705d8ab71187c0f',1966,'PK','Pakistan','government',354,'Legal name: Islamic Republic of Pakistan
Type: parliamentary, federal republic; military seized-
power 5 July 1977 and temporarily suspended some
constitutional provisions
Capital: Islamabad
Political subdivisions: 4 provinces—Punjab, Sind, Balu-
chistan, and North-West Frontier—with the capital territory
of Islamabad and certain tribal areas centrally administered;
159
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP0O8-00534R000100140001-7
January 1979
PAKISTAN/PANAMA
Pakistan claims that Azad Kashmir is independent pending a
settlement of the dispute with India, but it is in fact urider
Pakistani control
Legal system: based on English common law; accepts
compulsory ICJ jurisdiction, with reservations
National: holiday: Pakistan Day, 23 March
Government leader: President and Chief Martial Law
Administrator Gen. Mohammad Zia-ul-Haq
Suffrage: universal from age 18
Elections: opposition agitation against rigging of elections
in March 1977 eventually led to military coup; military
promised to hold new national and provincial assembly
elections in October 1977 but later postponed them _
indefinitely
Political parties and leaders: Pakistan People’s Party
(PPP), pro-Bhutto wing, Mrs. Z. A. Bhutto, moderate wing,
Maulana Kauser Niazi; Tehrik-i-Istiglal, Asghar Khan;
National Democratic Party (NDP), Sherbaz Mazari (formed
in 1975 by members of outlawed National Awami Party
(NAP) of Abdul Wali Khan, who is de facto NDP leader);
Jamiat-ul-Ulema-i-Pakistan (JUP), Maulana Shah Ahmed
Noorani; Pakistan National Alliance (PNA), a coalition of
eight parties including Pakistan Muslim League (PML)—Pir
of Pagaro group; Jamaat-i-Islami (JI), Tofail Mohammed;
Jamiat-ul-Ulema-i-Islam (JUI), Mufti Mahmud; Pakistan
Democratic Party (PDP), Nasrullah Khan
Communists: party membership very small; sympathizers
estimated at several thousand
Other political or pressure groups: military remains
strong political force
Member of: ADB, CENTO, Colombo Plan, FAO, GATT,
G-77, IAEA, IBRD, ICAC, ICAO, IDA, IFC, THO, ILO,
IMCO, IMF, ITU, IWC—International Wheat Council,
RCD, U.N., UNESCO, UPU, WHO, WMO, WSG, WTO','ef200cdff61e392456188188de154d76c1853f208f3a2370418c4186180f4af6','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('691757e57e920ea5b2b6c19e215bba631f8997d863aa9f49cbcc2d6950d83d9d',1966,'PA','Panama','government',358,'Legal name: Republic of Panama
Type: republic
‘Capital: Panama
Political subdivisions: 9 provinces, 1 intendancy
Legal system: based on civil law system; constitution
adopted in 1972; judicial review of legislative acts in the
Supreme Court; legal education at University of Panama;
accepts compulsory ICJ jurisdiction, with reservations
National holiday: Independence Day, 3 November
Branches: President (subordinate to National Guard
Commandant, Gen. Omar Torrijos)’: and Vice President,
elected by National Assembly; popularly elected unicameral
legislature, National Assembly of Community (Corregi-
miento) Representatives; legislative powers currently exer-
cised in the main by executive branch appointees, but
constitutional amendments, approved in October 1978, will
give greater legislative role to National Assembly; presiden-
tially appointed Supreme Court
Government leaders: Aristides Royo is Constitutional
President and Chief of State, but subordinate to Brig. Gen.
Omar Torrijos, the National Guard Commandant
Suffrage: universal and compulsory over age 18
Elections: elections for National Assembly in August
1978, Assembly chose President and Vice President in.
October 1978; constitutional reforms will allow Assembly to
elect from its own membership representatives to constitute
a new legislative organ, the National Council on Legislation;
additional representatives to the council will be chosen in
direct, popular elections in 1980; direct popular elections for
president and vice president, and corregimiento will be held
in 1984
Political parties and leaders: legislation providing for
legalization of political parties, which were suspended for
the last nine years, approved October 1978;- Communist
Party, although illegal, has been allowed to operate;
beginning in September 1977, activity by other political
parties was also tolerated
Voting strength: no parties participated in the 1978
elections
Communists: 500 active and several hundred inactive
members People’s Party (PdP); 500-600 members of rival
Fraccion movement which split from PdP in 1974; 2,500
sympathizers
Other political or pressure groups: National Council of
Private Enterprise (CONEP); Panamanian Association of
Business Executives (APEDE)
Member of: FAO, G-77, IADB, IAEA, IBRD, ICAO, ICO,
IDA, IDB, IFC, ILO, IMCO, IMF, ITU, IWC—Internation-
‘al Whaling Commission, [WC—International Wheat Coun-
cil, NAM, OAS, SELA, U.N., UNESCO, UPEB, UPU, WHO,
- WMO, WTO','6cda2f17043ddd2d5612352333c94f0ebe95562fa5119aa29c024e9c5b909278','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('191a2138aec5f0fd0a65445261f26be02513b19efb2ad61b132d9d1d16ecafc7',1966,'PY','Paraguay','government',362,'Legal name: Republic of Paraguay
Type: republic; under authoritarian rule
Capital: Asuncion
Political subdivisions: 16 departments and the national
capital, 154 municipalities
Legal system: based on Argentine codes, Roman law, and
French codes; constitution promulgated 1967; judicial
review of legislative acts in Supreme Court; legal education
at National University of Asuncion and Catholic University
of Our Lady of the Assumption; does not accept compulsory
IC] jurisdiction
National holiday: Independence Day, 14 May
Branches: President heads executive; bicameral legisla-
ture; judiciary headed by Supreme Court
Government leader: President Gen. Alfredo Stroessner
_ Suffrage: universal; compulsory between ages of 18-60
Elections: President and Congress elected together every
5 years; last election held in February 1978
Political parties and leaders: Colorado Party, Juan
Ramon Chavez; Liberal Party (Levi-Liberal Party), Carlos
163
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
PARAGUAY/PERU
Levi Ruffinelli; Febrerista Party, Roque Gaona; Radical
Liberal Party and United Liberal Party (provisional
unification of Liberal and Radical Liberal parties), Miguel
Angel Martinez Yaryes; Christian Democratic Party, Anibal
Recalde Sosa
Voting strength (February 1978 general election): 90%
Colorado Party, 5% Radical Liberal Party, 3% Liberal Party,
Febrerista Party boycotted elections
Communists: Oscar Creydt faction and Miguel Angel
Soler faction (both illegal); est. 3,000 to 4,000 party members
and sympathizers in Paraguay, very few are hard core; party
in exile is small and deeply divided
Other political or pressure groups: Popular Colorado
Movement (MoPoCo) led by Epifanio Mendez Fleitas, in
exile
Member of: FAO, G-77, IADB, IAEA, IBRD, ICAO, ICO,
IDA, IDB, IFC, ILO, IMF, IPU, ITU, LAFTA, OAS, SELA,
U.N., UNESCO, UPU, WHO, WMO, WSG','d428e4a5239b5239d445dabbecf8db52b7a318dec2c7779a22207e72cedf9456','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc84a4bfad7bb1a0912f5f1278892a4e5be9fc8ad6fe1b42621b0a47073112c2',1966,'PE','Peru','government',365,'Legal name: Republic of Peru
Type: republic; under military regime since October 1968
Capital: Lima
Political subdivisions: 23 departments with limited
autonomy plus constitutional Province of Callao
Legal system: based on: civil law system; military
government rules by decree and functions under Revolution-
ary Statute which supersedes 1933 constitution; legal
education at the National Universities in Lima, Trujillo,
Arequipa, and Cuzco; has not accepted compulsory ICJ
jurisdiction
National holiday: Independence Day, 28 July
Branches: executive, judicial; congress disbanded after 3
October 1968 ouster of President Fernando Belaunde Terry
Government leader: President, Div. Gen. Francisco
MORALES BERMUDEZ Cerrutti
Suffrage: obligatory for literate citizens (defined as adult
men and women and married persons over age 18) until age
60
Elections: June of 1978 a constituent assembly was
elected to draw up a new constitution; issuance of the new
charter to be followed by presidential and parliamentary
elections in 1980 .
Political parties and leaders: Popular Action Party (AP),
Fernando Belaunde Terry; American Popular Revolutionary
Alliance (APRA), Victor Raul Haya de la Torre; and Popular
Christian Party (PPC), Luis Bedoya Reyes; Popular Student,
Peasant and Workers Front (FOCEP), Genaro Ledesma
Voting strength (1978 election): 37% APRA, 25% PPC,
12% FOCEP, 26% other
Communists: pro-Soviet (PCP/S) 2,000; pro-Chinese (2
factions) 1,200
Member of: AIOEC, ASSIMER, CIPEC, FAO, G-77,
GATT, IADB, IAEA, IATP, IBRD, ICAO, ICO, IDA, IDB,
IFC, ILO, International Lead and Zinc Study Group, IMCO,
IMF, ISO, ITU, IWC—International Wheat Council,
LAFTA and Andean Pact, NAM; OAS, U.N., UNESCO,
UPU, WHO, WMO, WSG, WTO','01be8aaf107f99c34a968d3865cb9942729c0b0ea8d180358fc390204250f9f5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ddfe12af66a273c0ee6a3ed6d24f34ac80a016c99d6f3d17d95da9a283414f7e',1966,'PL','Poland','government',370,'Legal name: Polish People’s Republic (PRL)
Type: Communist state
Capital: Warsaw
Political subdivisions: 49 provinces
Legal system: mixture of Continental (Napoleonic) civil
law and Communist legal theory; constitution adopted 1952;
court system parallels administrative divisions with Supreme
Court, composed of 104 justices, at apex; no judicial review
of legislative acts; legal education at 7 law schools; has not
accepted compulsory ICJ jurisdiction
National holiday: National Liberation Day, 22 July
Branches: legislative, executive, judicial system domi-
nated by parallel Communist party apparatus
Government leaders: Piotr Jaroszewicz, Premier; Henryk
Jablonski, Chairman of Council of State (President)
Suffrage: universal and compulsory over age 18
Elections: parliamentary and local government every 4
years
Dominant political party and leader: Polish United
Workers’ Party (PZPR) (Communist), Edward Gierek, First
Secretary
167
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
POLAND/PORTUGAL
Voting strength (1975 election): 99% voted for Commu-
nist-approved single slate
Communists: 2,758,000 party members (March 1978)
Other political or pressure groups: National Unity Front
(FJN), including United Peasant Party (ZSL), Democratic
Party (SD), progovernment pseudo-Catholic Pax Association
and Christian Social Association, Catholic independent Znak
group; powerful Roman Catholic Church, Stefan Cardinal
Wyszynski, Primate
Member of: CEMA, GATT, ICAO, ICES, IHO, Indochina
Truce Commission, ILO, International Lead and Zinc Study
Group, IPU, ISO, ITC, Korea Truce Commission, U.N. and
all specialized agencies except IMF and IBRD, Warsaw Pact,
WIPO, WTO','65d13960e1f1f20b3842d73be0523e613404164d84d65352e8865bb49a62b292','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef6accd1cc6dfcb36a5365b823ff6e1c2dc0aec7b87b7dad8ef05ac972f573b5',1966,'PT','Portugal','government',373,'Legal name: Portuguese Republic
Type: republic, first government under new constitution
formed July 1976; major political parties and officers of
all-military Revolutionary Council signed document in
December 1975 agreeing to multiparty parliamentary
democracy with military oversight for period of 4 years
following presidential elections in June 1976
Capital: Lisbon
Political subdivisions: 18 districts in mainland Portugal;
Portugal’s two autonomous regions, the Azores and Madeira
Islands, have 4 districts (3 of them in the Azores); Macao,
Portugal’s remaining overseas territory, was granted broad
executive and legislative autonomy in February 1976;
Portugal has not officially recognized the unilateral annex-
ation of Portuguese Timor by Indonesia
Legal system: civil law system; new constitution adopted
April 1976; for next four years, legislative assembly acts to be
reviewed for constitutionality by Revolutionary Council;
vetoes of laws by the Council, through the agency of the
presidency, may be appealed to a Constitutional Commis-
sion as a court of last resort; legal education at Universities of
Lisbon and Coimbra; accepts compulsory ICJ jurisdiction,
with reservations
National holiday: 25 April
Branches: executive with President and Prime Minister,
with 18-member Revolutionary Council as advisory body. to
the President; popularly elected Assembly of the Republic;
independent judiciary
Government leaders: President Antonio dos Santos
Ramalho Eanes; Prime Minister Mota . Pinto
Suffrage: universal over age 18, except for those barred by
law for participation in “undemocratic” institutions prior to
April 25, 1974
Elections: national elections for Assembly of the Republic
to be held every 4 years, first Assembly under new
constitution elected April 1976, will sit until October 14,
1980 unless earlier dissolved by the -President; national
election for president to be held every 5 years, term of first
constitutional president—elected in June 1976—will end
with 4 year transitional *period; local elections to be held
every 3 years, last elections in December 1976
Political parties and leaders: the Portuguese Socialist
Party (PS) is led by Mario Soares, the Social Democratic
Party (PSD), formerly the Popular Democratic-Party-(PPD),
by Francisco Sa Carneiro, the Social Democratic Center
(CDS) by Diogo Freitas do Amaral, and the Portuguese
Communist Party (PCP) by Alvaro Cunhal
Voting strength: (1976 parliamentary election) the
Socialists polled 35% of the vote; the PSD received 24%, the
CDS 16%, and the Communists 15%; (1976 local elections)
PS 33%, PSD 24%, PCP 18%, CDS 17%
Communists: Portuguese Communist Party claims mem-
bership of 142,512 (March 1978)
Member of: Council of Europe, EFTA, FAO, GATT,
IAFKA, IATP, IBRD, ICAC, ICAO (restricted membership),
ICES, ICO, IFC, IHO, ILO, IMF, JOOC, ISO, ITU, IWC
International Wheat Council, NATO, OECD, U.N.,
UNESCO, UPU, WHO, WIPO, WMO, WSG','e85aa13fe1b0e357b02a4b973a32064e74bf7cb9bbad0b97799d427fbe757472','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df5035b461cb1d0979901051f5e6266e804ae5a8fea949f9ba9c3e0886f8ff01',1966,'RW','Rwanda','government',379,'Legal name: Republic of Rwanda
‘Type: republic, presidential system in which military
leaders hold key offices; new constitution submitted to voters
December 1978
Capital: Kigali -
Political subdivisions: 10 prefectures, subdivided into
142 communes |
Legal system: based on German and Belgian civil law
systems and customary law; judicial review of legislative acts
in the Supreme Court; has not accepted compulsory ICJ
jurisdiction
National holiday: Independence Day, 1 July
Branches: President, and 15-member cabinet
Government leader: Maj. Gen. Juvenal Habyarimana,
Head of State ;
Suffrage: universal
Elections: last legislative election September 1969; none
allowed by present government; elections of Communal
Counsellors held November 1974; national elections includ-
ing constitutional referndum and presidential plebiscite held
December 1978
Political parties and leaders: National Revolutionary
Movement for Development, General Habyarimana (offi-
cially not a party—a “development movement’ only)
Communists: no Communist party
Member of: AFDB, EAMA, FAO, G-77, GATT, IBRD,
ICAO, ICO, IDA, ILO, IMF, IPU, ITU, NAM, OAU,
OCAM, U.N., UNESCO, UPU, WHO, WMO, WTO','41f50861d8c10ae0b3fffab3c29efa1f13a6bf82f23f698f14a5576043f0d963','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e298262badf137771964cc0c460e46e6b8ba0d11befc7bb30fd54ad9fc43351',1966,'AI','Anguilla','government',383,'Legal name: State of St. Christopher-Nevis-Anguilla
Type: dependent territory with full internal autonomy as
a British “Associated State”; Anguilla formally seceded in
May 1967 but has not been recognized as an independent
state by any government; in July 1968 a legislative council
headed by Ronald Webster was elected to govern Anguilla;
in March 1969 the U.K. sent troops to Anguilla, placing the
island again under colonial rule; in 1971, Anguilla reverted
to its former colonial relationship with the U.K. although
nominally remaining part of the Associated state of St.
Christopher-Nevis-Anguilla,; Webster became leader of
Anguillan Council after constitutionally held elections
176
(1972); in February 1976, the U.K. granted a new
constitution to Anguilla which gave it a greater degree of
autonomy in domestic affairs; in February 1977 Emile
Gumbs replaced Webster as Chief Minister
Capital: Basseterre
Political subdivisions: 10 districts
Legal system: based on English common law; constitution
of 1960; highest judicial organ is Court of Appeal of
Leeward and Windward Islands
Branches: legislative, 10-member popularly elected
House of Assembly; executive, cabinet headed by Premier
Government leaders: Premier, C. A. P. Southwell; U.K.
Governor, Probyn Inniss
Suffrage: universal adult suffrage
Elections: at least every 5 years; most recent December
1975
Political parties and leaders: St. Chirstopher-Nevis-An-
guilla Labor Party, C. A. P. Southwell; People’s Action
Movement (PAM), William Herbert; Nevis Reformation
Party (NRP), Ivor Stevens
Voting strength (December 1975 election): St. Christo-
pher-Nevis-Anguilla Labor Party won 7 seats in the House of
Assembly, NRP won 2, and 1 seat remains open for Anguilla
which did not participate in the election
Communists: none known
Member of: CARICOM, ISO
Legal name: State of St. Lucia
Type: dependent territory with full internal autonomy as
a British “Associated State”
Capital: Castries
Political subdivisions: 16 parishes
Legal system: based on English common law; constitution
of 1960; highest judicial body is Court of Appeal of Leeward
and Windward Islands
Branches: legislative, 17-member popularly elected
House of Assembly; executive, cabinet headed by Premier
Government leaders: Premier John Compton; U.K.
Governor Sir Allen Lewis
Suffrage: universal adult suffrage
Elections: every 5 years; most recent May 1974
‘Political parties and leaders: United Worker’s Party
(UWP), John Compton; St. Lucia Labor Party (SLP), Allan
Louisy
Voting strength (1974 election): UWP (53%) won 10 of
the 17 elected seats in House of Assembly; SLP (45%) won 7
seats; independents (2%) no seats
Communists: negligible
Member of: CARICOM
Legal name: State of St. Vincent
Type: dependent territory with full internal autonomy as_
a British “Associated State”
Capital: Kingstown
Legal system: based on English common law; constitution
of 1960; highest judicial body is Court of Appeal of Leeward
and Windward Islands
Government leaders: Premier R. Milton Cato; Governor
General (U.K.) Sir Rupert G. John
Suffrage: universal adult suffrage (18 years old and over)
Elections: every 5 years; most recent December 9, 1974
178
Political parties and leaders: People’s Political Party
(PPP), Ebenezer Joshua; St. Vincent Labor Party (LP), R
Milton Cato; Democratic Freedom Movement, Parnell
Campbell and Kenneth John
Voting strength (1975 election): LP 10 seats, PPP 2 seats,
independent 1 seat in the Legislature
Communists: negligible; Marxist opposition group, Youlou
United Liberation Organization (Yulimo)
Member of: CARICOM','01cd4b636eeb07711c0b1e481da8b7d7747ad3b10d370dc433fb8ab2819b8cfa','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c55c37232f94a51c16870601f6798d58a1966193790cc9bcf2bdaad4b1d86e8',1966,'SM','San Marino','government',387,'Legal name: Republic of San Marino
Type: republic (dates from 4th century A.D.): in 1862 the
Kingdom of Italy concluded a treaty guaranteeing the
independence of San Marino; although legally sovereign, San
Marino is vulnerable to pressure from the Italian
Capital: San Marino
Political subdivisions: San Marino is divided into 9
castelli: Acquaviva, Borgo Maggiore, Chiesanuova, Dog-
manano, Faetano, Fiorentino, Monte Giardino, San Marino,
Serravalle : gk
Legal system: based on civil law system with Italian law
influences; electoral law of 1926 serves some of the functions
of a constitution; has not accepted compulsory ICJ
jurisdiction
National holidays: 1 April, 1 October
- Branches: the Grand and General Council is the
legislative body elected by popular vote; its 60 members
serve 5-year terms; Council in turn elects two Captains-Re-
gent who exercise executive power for term of 6 months, the
Council of State whose members head government adminis-
trative departments and the Council of Twelve, the supreme
judicial body; actual executive power is wielded by the.
Secretary of State for Foreign Affairs and the Secretary: of
State for Internal Affairs
Government leaders: since 17 July 1978 Secretary of State
for Foreign and Political Affairs and for Information,
Giordano Bruno Reffi- (Socialist); Secretary of State for
Internal Affairs and Justice, Alvaro Selva (Communist);
Secretary of State for Budget, Finance, and Planning, Emilio
Baldo (Unitary Socialist)
Suffrage: universal (since 1960)
Elections: elections to the Grand and General Council
required at léast every 5 years; an election was held 28 May
1978 .
Political parties and leaders: Christian Democratic party
(DCS), Gian Luigi Berti; Social Democratic Party (PSDSM),
Alvaro Casali; Socialist Party (PSS), Remy Giacomini;
Communist Party (PCS), Umberto Barulli; People’s Demo-
cratic Party. (PDP), leader unknown; Committee for the
Defense of the Republic (CDR), leader unknown
Voting strength (1974 election): 39.6% DCS, 23.7% PCS,
15.4% PSDIS, 18.9% PSS, 1.9% PDP, 2.9% CDR ;
Communists: approx. 300 members (number of sympa-
thizers cannot be determined); PSS, in government with
Christian. Democrats since March 1978, formed a govern-
ment with the PCS from the end of World War II to 1957
Other political parties or pressure groups: political
parties influenced by policies of their counterparts in Italy,
the two Socialist parties are not united
Member of: ICJ, International Institute for Unification of
Private Law, International Relief Union, IRC, UPU, WTO','f2f1716b31955354def53f6361eb89171e560e32c1412e2a5dd5d3053bcf17d4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6e02169f9ee3dfeddbd55338836777749e38cb14bdab42c315ce29f9d77bca2',1966,'SC','Seychelles','government',391,'Legal name: Republic of Seabees
Type: republic; member of the Commonwealth.
Capital: Victoria, Mahe Island
Legal system: based on English common law, French civil
law system, and customary law
183
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
SEYCHELLES/SIERRA LEONE
National holiday: 29 June-
Branches: President, Council of Ministers
Government leader: President, France Albert Rene
Suffrage: universal adult
Elections: April 1974, new government has promised
election by June 1979, but not before new constitution
drafted
Political parties and leaders: Rene, who heads the
Seychelles People’s United Party, came to power by a
military coup in June 1977, until then he had been Prime
Minister in an uneasy coalition with then President James
Mancham, who headed the Seychelles Democratic Party.
Rene banned the Seychelles Democratic Party in mid-March
and plans to turn the country into a one-party state. Rene
dissolved the Nationa] Assembly, and plans to rule by
presidential decree until] a new constitution is drafted. Rene
abrogated the constitution without qualification upon taking
power. Subsequently the government decided to retain some
provisions, but presidential decree enables the President and
specified subordinates to violate constitutional safeguards in
interests of state security
Communists: negligible
Other political or pressure groups: trade unions which
are appendages of political parties
Member of: G-77, NAM, OAU, U.N.','9bbe7ccb83a72f16a91b539fdb8ac8057fb25cc36f23547e3eb944efbc704c7d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa95559d0ecdd0face62bb57c861c04454927adc2e3b4ec010f57e2a4d09c541',1966,'SL','Sierra Leone','government',395,'Legal name: Republic of Sierra Leone.
Type: republic under presidential regime since April 1971
Capital: Freetown
Political subdivisions: 3 provinces; divided into 12
districts with 146 chiefdoms, where paramount chief and
council of elders constitute basic unit of government; plus
western area, which comprises Freetown and other coastal
areas of the former colony
Legal system: based on English law and customary laws
indigenous to local tribes; constitution adopted April 1971;
highest court of appeal is the Sierra Leone Court of Appeals;
has not accepted compulsory ICJ jurisdiction
National holiday: National Day, 19 April
Branches: executive authority exercised by President;
parliament consists of 100 authorized seats, 85 of which are
filled by elected representatives of constituencies and 12 by
Paramount Chiefs elected by fellow Paramount Chiefs in
each district; President authorized to appoint four members,
of which two, currently, are filled by the heads of the Army
and the Police; independent judiciary
Government leader: Siaka P. Stevens, President, heads
APC government composed of members of his political
party Bee
Suffrage: universal over age 2]
Elections: the Constitution of Sierra Leone Act, 1971, has
been replaced by the Constitution of Sierra Leone, 1978,
which provides for one-party rule; Dr. Siaka Stevens was
named as the first Executive President under the one-party
constitution; the President’s tenure has been extended from 5
to 7 years; next presidential election 1983
Political parties and leaders: All People’s Congress
(APC), headed by Stevens -
Communists: no party, although there are a few
Communists and a slightly larger number of sympathizers
Member of: AFDB, AIOEC, Commonwealth, ECA,
ECOWAS, FAO, G-77, GATT, IAEA, IBA, IBRD, ICAO,
ICO, IDA, IFC, ILO, IMF, IPU, ITU, NAM, OAU, U.N.,
UNESCO, UPU, WHO, WMO, WTO','7df395fb35b57f7dda2cc246543332444b4dda4b1f4eff4cc8e39b8683f3a6e3','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('acb4ea22fb33d35d131a02403beb4c462e44218b3568ee99be7ed8d0e3974895',1966,'SG','Singapore','government',398,'Legal name: Republic of Singapore
Type: republic within Commonwealth since separation
from Malaysia in August 1965:
Capital: Singapore
Legal system: based on English common law; constitution
based on preindependence State of Singapore constitution;
legal education at University of Singapore; has not accepted
compulsory ICJ jurisdiction
National holiday: 9 August
186
Branches: ceremonial President; executive power exer-
cised by Prime Minister and cabinet responsible to unitary
legislature
Government leaders: President, Dr. Benjamin Henry
Sheares; Prime Minister, Lee Kuan Yew
Suffrage: universal over age 20; voting compulsory
Elections: normally every 5 years
Political parties and leaders: government—People’s
Action Party (PAP), Lee Kuan Yew; opposition—Barisan
Sosialis Party (BSP), Dr. Lee Siew Choh; Workers’ Party, J.
B. Jeyaretnam; Communist Party illegal
Voting strength (1976 election): PAP won all 69 seats in
Parliament and received 72.4% of vote; remaining 27.6% to
four opposition parties
Communists: 200-500; Barisan Sosialis Party infiltrated
by Communists
Member of: ADB, ANRPC, ASEAN, Colombo Plan, G-77,
GATT, IBRD, ICAO, IFC, IHO, ILO, IMCO, IMF, IPU,
ISO, ITU, NAM, U.N., UNESCO, UPU, WHO, WMO,
WTO','6b56afe5974e11bd45e295bdf99a3c1fdb1f0020b21950196d84ce18e4b4c41f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53f2bcdfbefdbd15463ca1040b4be9991c6448ee697c83f009c0fe0b67ebf603',1966,'SB','Solomon Islands','government',401,'Legal name: Solomon Islands
Type: independent state within commonwealth
Capital: Honiara on the island of Guadalcanal
Political subdivisions: 4 administrative districts
Legal system: a High Court plus Magistrates Courts, also 4
system of native courts throughout the islands
Branches: executive authority in Governor General; a
legislative assembly of 38 members
Government leaders: Governor General Baddeley Devesi,
Prime Minister Peter Kenilorea
Suffrage: universal age 21 and over
Elections: every 4 years, latest June 1976
Political parties and leaders: no real political parties,
groupings of independents
Member of: ADB','71306493632962e6021c58d763ba84136b21d5c3b762e7fc1e449673c7ef6e73','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('accc99020391590c295d7f8cc806be91c8c59a4549a041ae59b2679cebc76efa',1966,'SO','Somalia','government',405,'Legal name: Somali Democratic Republic
Type: republic
Capital: Mogadiscio
National holiday: 21 October
Political subdivisions: 16 regions, ‘60 districts
Organization: the Somali Revolutionary Socialist Party,
created on July 1, 1976, has become the new executive body
188
in the country; party has 74-man central committee and
5-man politburo headed by President Siad
Government leader: President Maj. Gen. Mohamed Siad
Barre
Communists: possibly some Communist sympathizers in
the government : hierarchy
Member of: AFDB, ARAB LEAGUE, EAMA, FAO,
G-77, IBRD, ICAO, IDA, IFC, ILO, IMF, ITU, NAM, OAU,
U.N., UNESCO, UPU, WHO, WMO','19e44648440ce29b788f38fa6dbc11b75e4792530c65fb8c2cfba51da36751ed','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77191818aadbd4b602a40103b08cb50b3b3d3b7da3356af1d41fe0dfdfa9625f',1966,'ES','Spain','government',408,'authoritarian regime of the late Generalissimo Franco and
confirmed Juan Carlos I as monarch, but without the
exceptional powers inherited from Franco on being pro-
claimed King 22 November 1975
Capital: Madrid
Political subdivisions: metropolitan Spain, including the
Canaries and Balearics, divided into 50 provinces which are
to be allowed to form autonomous regions—probably
numbering 13—assuming numerous powers previously
exercised by the central government; also 5 places of
sovereignty (presidios) on the Mediterranean coast of
Morocco; transferred administration of Spanish Sahara to
Morocco and Mauritania on February 26, 1976
Legal system: civil law system, with regional applications;
new constitution provides for rule of law, established jury
system as well as independent constitutional court to rule on
unconstitutionality of laws and to serve as court of last resort
in protecting liberties and rights granted in constitution; does
not accept compulsory ICJ jurisdiction
National holiday: 12 October
Branches: executive, with King’s acts subject to counter-
signature, Prime Minister (presidente) and his ministers
responsible to lower house; legislative with bicameral Cortes
consisting of more powerful Congress of Deputies (350
members) and providing future Cortes with Congress of
between 300 to 400 members and Senate with 4 members
from each province with addition of 1 to 6 members from
each new autonomous region; judicial, independent
Government leaders: King Juan Carlos I—Chief of State,
and Commander in Chief of the armed forces; and Prime
Minister (Presidente) Adolfo Suarez Gonzalez
Suffrage: universal at age 18
Elections: free parliamentary elections in June 1977 for
4-year term; postponed local elections likely to be delayed
until fal] 1978 or early 1979
Political parties and leaders: principal parties to emerge
from 1977 election are from right to left: the Popular
'' Alliance (AP)—the conservative coalition led by ex-minister
Fraga and including 6 other former ministers under Franco, -
the major rightist group—made a poor showing in the
parliamentary election; the Union of the Democratic Center
(UCD)—a centrist coalition of 15 reform-minded parties
backing Prime Minister Suarez who is party president and:
Secretary General Rafael Arias-Salgado; the Spanish Socialist
Workers Party (PSOE), led by Felipe Gonzalez, is the major
party of the democratic left; a much smaller contender, the
Popular Socialist Party of Enrique Tierno Galvan merged
with the PSOE in May 1978; the Spanish Communist Party —
(PCE), led by Santiago Carrillo, and its several regional
branches espouse Eurocommunism; there are also several
Basque and Catalan regional parties of mixed orientation
which are united by their goal of greater regional autonomy
192
Voting strength: (1977 parliamentary election) UCD
polled 34% of votes and received 165 chamber seats (47.1%),
11 seats short of a majority; the PSOE polled 28.5% and
received 118 seats (34%); the PCE polled 9.2% and received
20 seats (5.7%); the AP polled 8.2% and received 16 seats; the
PSP polled 4.3% and received 6 seats; the various Basque
and Catalan regional parties received 22 seats; minor parties
received 3 seats
Communists: PCE claims to have over 200,000 members,
but this figure is difficult to verify; the PCE’s greatest
strength is in labor where it dominates thé country’s
strongest trade union, the Workers Commissions, which now
claims a membership of around 1 million.
Other political or pressure groups: on the extreme left,
“the Basque Fatherland and Liberty (ETA), the First of
October Antifascist Resistance Group (GRAPO), and the
Anti-Fascist and Patriotic Revolutionary Front (FRAP) use
terrorism to oppose the government; on the extreme right,
the Guerrillas of Christ the King and the Anticommunist
Apostolic Alliance (AAA) carry out vigilante attacks on ETA
members and other leftists; free labor unions (authorized in
April 1977) include the Communist-dominated Workers
Commissions; the Socialist General Union of Workers
(UGT), and the independent Workers Syndical Union
(USO); the Catholic Church; business and land owning _
interests; Opus Dei; Catholic Action; university’ students
Member of: ASSIMER, ESRO, FAO, GATT, IAEA,
IBRD, ICAC, ICAO, ICES, ICO, IDA, IEA, IFC, THO, ILO,
International Lead and Zinc Study Group, IMCO, IMF,
IOOC, IPU, ITC, ITU, IWC—International Wheat Council,
OAS (observer), OECD, U.N., UNESCO, UPU, WHO,
WIPO, WMO, WSG, WTO; applied for full membership in
the EC 28 July 1977; joined Council of Europe 18 October
1977','3d9e2cb69a4b60fae24d815f323318125568285cc8d42a5a5ea62690acd0e853','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93d27b92c103981d8ab36de0de77fa312cc25c61c34d3c65272309722424a44a',1966,'LK','Sri Lanka','government',413,'Legal name: Democratic Socialist Republic of Sri Lanka
Type: independent state since 1948
Capital: Colombo :
Political subdivisions: 9 provinces, 22 administrative
districts, and four categories of semiautonomous elected
local governments :
Legal system: a highly complex mixture of English
common law, Roman-Dutch, Muslim and customary law;
new constitution 7 September 1978 reinstituted a strong,
independent judiciary; legal education at Sri Lanka Law
College and University of Sri Lanka, Peradeniya; has not
accepted compulsory IC] jurisdiction
National holiday: Independence Day, 22 May
Branches: the 1978 constitution established a strong
presidential form of government under J. R. Jayewardene,
who became Prime Minister following his party’s election
victory in July 1977; Jayewardene will remain president
until 1983, regardless of whether parliament is dissolved and
subsequent parliamentary elections are held; when his term
in office expires, a new president will be chosen by a direct
national election for a six year term.
Government leader: President J. R. Jayewardene
Suffrage: universal over age 18
Elections: national elections, ordinarily held. every 6
years; must be held more frequently if government loses
confidence vote; last election held July 1977
Political parties and leaders: Sri Lanka Freedom Party,
Sirimavo Ratwatte Dias Bandaranaike, President; Lanka
Sama Samaja Party (Trotskyite), N. M. Perera, President;
Tamil United Liberation Front, A. Amirthalingam leader;
United National Party, J. R. Jayewardene; Communist
Party/Moscow, Pieter Keuneman, General Secretary; Com-
munist Party/Peking, N. Shanmugathasan, General Secre-
‘tary; Mahajana Eksath Peramuna (People’s United Front),
M. B. Ratnayaka, President
" Voting strength (1977 election): 30% Sri Lanka Freedom
Party, 51% United National Party, 3.9% Lanka Sama Samaja
Party, 1.8% Communist Party/Moscow, 6.5% TULF minor
parties and independents accounted for remainder
Communists: approximately 107,000 voted for the
Communist Party in the July 1977 general election;
Communist Party/Moscow approximately 5,000 members
(1975), Communist Party/Peking 1,000 members (1970 est.)
Other political or pressure groups: Buddhist clergy,
Sinhalese Buddhist lay groups; far-left violent revolutionary
groups; labor unions
Member of: ADB, ANRPC, Colombo Plan, Common-
wealth, FAO, G-77, IAEA, IBRD, ICAO, IDA, IFC, ILO,
IMCO, IMF, IPU, NAM, U.N., UNESCO, UPU, WHO,
WMO, WTO
194
January 1979','ccc90d2486ff7bf01140e76db4019c7dd41590699d957168f9c01c4a57e4730d','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b670a3e0d659705900f8dc39052485bdd6029e5780fbc17674b462bc5a705469',1966,'SD','Sudan','government',417,'Legal name:. Democratic Republic of the Sudan
Type: republic under military control since coup in May
1969
Capital: Khartoum :
Political subdivisions: 18 provinces, provincial and local
administrations controlled by central government; limited
regional autonomy in 6 southern provinces
Legal system: based on English common law and Islamic
law; some separate religious courts; permanent constitution
promulgated April 1973; legal education at University of
Khartoum and Khartoum extension of Cairo University at
Khartoum; accepts compulsory IC] jurisdiction, with
reservations
National holiday: Independence Day, 1 January
Government leader: President, Gen. Ja’far Muhammad
Numayri
Suffrage: universal adult
Elections: elections for National People’s Assembly and
‘Southern Regional People’s Assembly held in February 1978;
most recent Presidential election held April 1977 with
Numayri as sole candidate
Political parties and leaders: all parliamentary political
parties outlawed since May 1969; the ban on the Sudan
Communist Party was not enforced until after abortive coup
in July 1971; the government’s mass political organization,
the Sudan Socialist Union, was formed in January 1972
Communists: party decimated following July 1971 coup
and counter-coup, several top leaders executed; actual
hard-core membership down to lowest point in years; party
control over labor unions, professional groups and university
student groups ended; Communists purged from govern-
ment; party is being reorganized underground under
leadership of Secretary-General Muhammad Nujud, 3,500
CP members ,
Other political or pressure groups: Muslim Brotherhood;
Ansar Muslim sect, at odds with the military regime since
the May coup, are being reintegrated into national political
life; members of opposition National Front, composed of
former political party elements and other disgruntled
conservative interests, agreed to disband and join national
reconciliation efforts in April 1978
Member of: AFDB, APC, Arab League, FAO, G-77,
IAEA, IBRD, ICAC, ICAO, IDA, IFC, ILO, IMF, ITU,
NAM, OAU, U.N., UNESCO, UPU, WHO, WIPO, WMO,
WTO :','c2b67c41c32507877e39118fd409314b30470f05ce7af473aeaeb8ac1bd17086','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42dc8d31fee2e1e74d68bd62f9fce444392a10a89eaf3c9a34079ac0d6cf727b',1966,'SE','Sweden','government',421,'Legal name: Kingdom of Sweden
Type: constitutional monarchy
Capital: Stockholm
Political subdivisions: 24 provinces, 624 communes, 224
towns
Legal system: civil law system influenced by customary
law; Acts of 1809, 1810, 1866, and 1949 serve as constitution;
legal education at Universities of Lund, Stockholm, and
Uppsala; accepts compulsory ICJ jurisdiction, with reser-
vations ,
National holiday: Birthday of the King, 30 April
Branches: legislative authority rests with parliament
(Riksdag); executive power vested in cabinet, responsible to
parliament; Supreme Court, 6 superior courts, 108 lower
courts ®
Government leaders: King Carl XVI Gustaf; Prime
Minister Ola Ullsten
Suffrage: universal, but not compulsory, over age 20
Elections: every 3 years (next in September 1979)
Political parties and leaders: Moderate Coalition (con-
servative), Gosta Bohman; Center, Thorbjorn Falldin;
Liberal, Ola Ullsten; Social Democratic, Olof Palme; Left
Party Communist, Lars Werner; Swedish Communist Party,
Roland Petersson; Swedish Workers’ Party, Rolf Hagel;
Communist League of Marxist Leninists-Revolutionary
(KFML-R), Frank Baude
Voting strength (1976 election): 15.6% Moderate Coali-
tion, 24.1% Center, 11.0% Liberal, 42.9% Social Democratic, ©
4.7% Communist, 1.7% other
Communists: 17,000; a number of sympathizers as
indicated by the 257,967 Communist votes cast in 1973
elections; an additional 17,274 votes cast for Maoist KFML
Member of: ADB, Council of Europe, DAC, EC (Free
Trade Agreement), EFTA, ESRO, FAO, GATT, IAEA,
IBRD, ICAC, ICAO; ICES, ICO, IDA, IEA, IFC, IHO, ILO,
International Lead and Zinc Study Group, IMCO, IMF, IPU,
ISO, ITU, IWC—International Whaling. Commission,
IWC—International Wheat Council, Nordic Council,
OECD, U.N., UNESCO, UPU, WHO, WIPO, WMO, WSG','210331419e232871a2a2a8e91d3e33317de30ac0a0cd0300947012a97ddd2be4','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b55ce9abb505c6c76f6cc5157537cdec66fc30bb909f2b06d1d58406c5cab831',1966,'CH','Switzerland','government',425,'Legal name: Swiss Confederation‘
Type: federal republic
Capital: Bern
Political subdivisions: 22 cantons (3 divided into half ©
cantons); a national referendum in September 1978 ap-
proved the establishment of the 23rd canton in the northern
Jura region, which will become part of the confederation
next year after elections for local government and
parliament
200
Legal system: civil law system influenced by customary
law; constitution adopted 1874, amended since; judicial
review of legislative acts, except with respect to Federal
decrees of general obligatory character; legal education at
Universities of Bern, Geneva and Lausanne, and four other
university schools of law; accepts compulsory ICJ jurisdic-
tion, with reservations
National holiday: 1 August
Branches: bicameral parliament has legislative authority;
federal council (Bundesrat) has executive authority; justice
left chiefly to cantons
Government leaders: Willi Ritschard, President; Hans
Hurlimann, Vice President - :
Suffrage: universal over age 20
Elections: held every 4 years; next elections 1978
Political parties and leaders: Socia} Democratic Party
(SPS), Arthur Schmid, president; Radical Democratic Party
(FDP), Henri Schmitt, president; Christian Conservative
People’s Party (CVP), Franz Josef Kurmann, president; Swiss
People’s Party (SVP), Hans Conzett, president, Communist
Party (PdA), Jean Vincent, leading Secretariat member;
National Action Party (N.A.), James Schwarzenbach
Voting strength (1975 election): 22.2% FDP, 20.6% CVP,
25.4% SPS, 10.2% BGB, 2.2% PdA, 2.5% N.A., 3.0% Rep,
6.2% LdU, 2.3% Lidus, 2.0% EvP, 1.3% POSH, 2.2% other
Communists: less than 60,000 votes in 1975 election
Other parties: Landesring (LdU); Republican Movement
(Rep); Liberal Democratic Union (Lidus); Evangelical Party
(EvP); Maoist Party (POSH/PSA) =
Member of: ADB, Council of Europe, DAC, EFTA,
ELDO (observer), ESRO, FAO, GATT, IAEA, ICAC, ICAO,
ICO, IEA, ILO, IMCO, IPU, ITU, IWC—International
Wheat Council, OECD, U.N. (permanent observer),
UNESCO, UPU, WCL, WHO, WIPO, WMO, WSG, WTO
Legal name: Syrian Arab Republic
Type: republic; under left-wing military regime since
March 1963
Capital: Damascus
Political subdivisions: 13 provinces and city of Damascus
administered as separate unit
Legal system: based on Islamic law and civil law system,
special religious courts; constitution promulgated in 1973;
legal education at Damascus University and University of
Aleppo; has not accepted compulsory ICJ jurisdiction
National holiday: Independence Day, 17 April
Branches: executive powers vested in President and
Council of Ministers; legislative power rests in the People’s
Assembly; seat of power is the Ba’th Party Regional (Syrian)
Command
201
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
SYRIA/TAIWAN/TANZANIA
Government leader: President Hafiz al-Asad
Suffrage: universal at age 18
Elections: People’s Assembly election August 1977;
Presidential election February 1978
Political parties and leaders: ruling party is the Arab
Socialist Resurrectionist (Ba’th) Party; the “national front”
cabinet is dominated by Ba’thists, but includes independents
and members of the Syrian Arab Socialist Party (ASP), Arab
Socialist Union (ASU), and Syrian Communist Party (SCP)
Communists: mostly sympathizers, numbering about
5,000
Other political or pressure groups: non-Ba’th parties
have little effective political influence; Communist Party
ineffective; greatest threat to Ba’thist regime lies in
factionalism in Ba’th Party itself; conservative religious
leaders
Member of: Arab League, FAO, G-77, IAEA, IBRD,
ICAO, IDA, IFC; ILO, IMCO, IMF, IOOC, IPU, ITU,
IWC—International Wheat Council, NAM, OAPEC, U.N.,
UNESCO, UPU, WFTU, WHO, WMO, WSG, WTO
Legal name: United Republic of Tanzania
Type: republic; single party on the mainland and on-
Zanzibar -
Capital: Dar es Salaam
Political subdivisions: 25 regions—20 on mainland, 5 on
Zanzibar islands :
Legal system: based on English common law, Islamic law,
customary. law, and German civil law system; permanent
constitution adopted 1977, replaced interim constitution
adopted 1965; judicial review of legislative acts limited to
matters of interpretation; legal education at University of
Dar es Salaam; has not accepted compulsory ICJ jurisdiction
National holiday: “Union Day,” 26 April
Branches: President Julius Nyerere has full executive
authority on the mainland; National Assembly dominated by
Nyerere and the Chama Cha Mapinduzi (Revolutionary
Party); National Assembly consists of 2833 members, 72 from
Zanzibar, of which 10 are directly elected, 65 appointed
from the mainland, plus 96 directly elected from the
mainland; Vice President Aboud Jumbe (President of
Zanzibar) and the Revolutionary Council still run Zanzibar
except for certain specifically designatetl union matters
Government leaders: President Julius K:-Nyerere; Prime
Minister Edward M. Sokoine
Suffrage: universal adult
Political party and leaders: Chama Cha Mapinduzi
(Revolutionary Party), only political party, dominated by
Nyerere and Vice President Jumbe, his top lieutenant; party
was formed in 1977 as a result of the union of the
Tanganyika African National Union, the sole mainland
party, and the Afro-Shirazi Party, the only party in Zanzibar
Voting strength (October-1975 national elections): over 5
million registered voters; Nyerere received 95% of about 4
million votes cast; general parliamentary elections scheduled
for late 1980
Communists: a few Communist sympathizers, especially
on Zanzibar.
Member of: AFDB, Commonwealth, FAO, G-77, GATT,
IBRD, ICAC, ICAO, ICO, IDA, IFC, ILO, IMF, ITU, NAM,
OAU, U.N., UNESCO, UPU, WHO, WMO, WTO','86056b2e84dd6c163778d58ab60a49911189e9edbe32d9c3c077913828419857','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aad0a48b8cb9f023d0372bcaa948bb99e4fa94746a13d1ff20c58523161a2137',1966,'TH','Thailand','government',429,'Legal name: Kingdom of Thailand
Type: constitutional monarchy
Capital: Bangkok
Political subdivisions: 71 centrally controlled provinces
Legal system: based on civil law system, with influences
of common law; new constitution being drafted; legal
education at Thammasat University; has not accepted
compulsory ICJ jurisdiction ;
National holiday: National Day, 5 December
Branches: King is head of state with nomina] powers;
civilian government suspended on 20 October 1977; military
- staffed Revolutionary Party governing in interim pending
drafting of new constitution; judiciary relatively independ-
ent except in important political subversive cases
King Phumiphon Adunyadet,
Prime Minister Gen. Kriangsak Chamanan
Government leaders:
Elections: tentatively scheduled for early 1979
Political parties: suspended pending new election law
Communists: strength of illegal Communist Party is about
1,200; Thai Communist insurgents throughout Thailand total
an estimated 9,000 to 12,000
Member of: ADB, ANRPC, ASEAN, ASPAC, Colombo
Plan, ESCAP, FAO, G-77, IAEA, IBRD, ICAO, IDA, IFC,
JIHO, ILO, IMF, IPU, ITC, ITU, SEAMES, U.N., UNESCO,
UPU, WHO, WMO, WTO
Legal name: Socialist Republic of Vietnam
Type: Communist state
Capital: Hanoi
Political subdivisions: 38 provinces
Legal system: based on Communist legal theory and
French civil law system
National holiday: 2 September
Branches: constitution provides for a National Assembly
and highly centralized executive nominally subordinate to it
Party and government leaders: Ton Duc Thang, Presi-
dent of DRV; Le Duan, Party Secretary General; Truong
Chinh, Chairman, Standing Committee of National Assem-
bly; Pham Van Dong, Premier; Gen. Vo Nguyen Giap,
Minister of National Defense; Nguyen Duy Trinh, Minister .
for Foreign Affairs; Tran Quoc Hoan, Minister of Interior
Suffrage: over age 18
Elections: pro forma elections held for national and local
assemblies; lastest election for National Assembly held on 25
April 1976
Political parties: National United Front, consisting of the
predominate Vietnam Communist Party, successor to the
Vietnam Workers Party and several other political
organizations
Member of: ADB, CEMA, Colombo Plan, ESCAP, FAO,
G-77, IBRD, ICAO, IMF;.Mekong Committee, NAM, U.N.,
UNDP, UNESCO, UNICEF, WHO, WIPO, WTO','c2b17e282578fc631de26172ad609c39ea4f2ab509e1ec433707edd33e7aebef','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ea95fa57e1a6ac57a25f3ee98835cc226e64b29f294311016159e1bbce4bd7d',1966,'TG','Togo','government',433,'Legal name: Republic of Togo
Type: republic; under military rule since January 1967
Capital: Lome ,
Political subdivisions: 21 circumscriptions
Legal system: based on French civil law and customary
practice; no constitution; has not -accepted compulsory IC]
jurisdiction
National holiday: Independence Day, 27 April
Branches: military government, with civilian-dominated
cabinet, took over on 14 April 1967, replacing provisional
government created after January coup; no legislature;
separate judiciary including State Security Court established
1970
Government leader: Gen. Gnassingbé Eyadéma, Presi-
dent, Minister of National Defense, and Armed Forces Chief
of Staff :
205
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
TOGO/TONGA
Suffrage: universal adult
Elections: presidential referendum of January 1972
elected Gen. Eyadéma for indefinite period
Political party: single party formed by President Eya-
déma in September 1969, Rassemblement du Peuple
Togolais, structure and staffing of party closely controlled by
Communists: no Communist Party; possibly
sympathizers
Member of: AFDB, CEAO (observer), EAMA, ECA,
ECOWAS, ENTENTE, FAO, G-77, GATT, IBRD, ICAO,
ICO, IDA, IFC, ILO, IMF, ITU, NAM, OAU, OCAM, U.N.,
UNESCO, UPU, WHO, WIPO, WMO, WTO .','280e977f9906a1c5d60738b13462c9d42ed9901b822ffdaa9093b9e8d2c3e27b','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9f3363b6940d52e1e50296ffac2cad99f26871e6fbbe197dc30eb5b8c40d2ce',1966,'TO','Tonga','government',437,'Legal name: Kingdom of Tonga
Type: constitutional monarchy
Capital: Nukualofa /
Political subdivisions: 8 main island groups (Tongatapu,
Haapi, Vavau) ,
Legal system: based on English law
Branches: Executive (King and Privy Council); Legisla-
tive (Legislative Assembly composed of 7 nobles elected by
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
—— FS Vl hUhU
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
their peers, 7 elected representatives of the people, 8
Ministers of the Crown; the King appoints one of the 7
nobles to be the speaker); Judiciary (Supreme Court,
magistrate courts, Land Court)
Government leaders: King Taufa’ahau Tupou IV; Pre-
mier, Prince Fatafehi Tu’ipelehake (younger brother of the
King)
Suffrage: deanted to all literate adults over 21 years of age
who pay taxes
Elections: held every 3 years, last in April 1978
Communists: none known :
Member of: ADB, Commonwealth','d902d0d9890fda5ab80be9895967ee06f68cfea803d7bd36d7ba86033c2e01d5','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b99bfb248dd6fcce66c6354ccb2c9e9764c8a851568b8455c2416cbe36c064f',1966,'TT','Trinidad and Tobago','government',441,'Legal name: Republic of Trinidad and Tobago
Type: independent state since August 1962; in August
1976 country officially became a republic severing legal ties
with British crown
Capital: Port-of-Spain
Political subdivisions: 8 counties (29 wards,. Tobago is
80th)
Legal system: based on English common law; constitution
came into effect 1976; judicial review of legislative acts in
the Supreme Court;:has not accepted compulsory ICJ
jurisdiction
National holiday: 31 Augast
_ Branches: legislative branch consists of 36-member
elected House of Representatives and 3l-member appointed
Senate; executive is cabinet led by the Prime Minister;
207
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
TRINIDAD AND TOBAGO/TUNISIA
judiciary is headed by the Chief Justice and includes a Court
of Appeal, High Court, and lower courts
Government leaders: Prime Minister Dr. Eric, Williams,
President Ellis Clarke
Suffrage: universal over age 18
Elections: elections to be held at intervals of not more
than five ‘years; last election held 13 September 1976
Political parties and leaders: People’s National Move-
ment (PNM), Dr. Eric Williams; United Labor Front (ULF),
Bosdeo Panday; Democratic Labor Party (DLP), Dr.
Romesh Mootoo; Democratic Action Congress (DAC),
Arthur Napoleon Raymond Robinson; West Indian National
Party (WINP), Ashford Sinanani; Tapia House Movement,
Lloyd Best
Voting strength (1976 election): 56% of registered voters
cast ballots; PNM captured 24 seats in House of Representa-
tives, ULF 10, and DAC the two Tobago seats
Communists: not significant
Other political pressure groups: National Joint Action
Congress (NJAC), radical anti-government Black-identity
organization; United Revolutionary Organization (URO),
Marxist amalgam; Trinidad and Tobago Peace Council,
leftist organization affiliated with the World Peace Council;
Trinidad and Tobago Chamber of Industry and Commerce;
Trinidad and Tobago Labor Congress, moderate - labor
_ federation; Council of Progressive Trade Unions, radical
labor federation
Member of: CARICOM, Commonwealth, FAO, G-77,
GATT, IADB, IBRD, International Coffee Agreement,
ICAO, ICO, IDA, IDB, IFC, ILO, IMCO, IMF, ISO, ITU,
IWC—International Wheat Council, NAM, OAS, SELA,
U.N., UNESCO, UPU, WHO, WMO, WTO','02bbecf514c2d786c75cdaa3f7ba7d993d51b5f9b88f357593eb4f8b9ae149dd','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d6d532c06abd0d179f5414db386def0f6b02680f60fb98cb08da620275c14cf',1966,'TN','Tunisia','government',445,'Legal name: Republic of Tunisia
Type: republic
Capital: Tunis
Political subdivisions: 17 governorates (provinces)
Legal system: based on French civil law system and
Islamic law; constitution patterned on Turkish and U.S.
constitutions adopted 1959; some judicial review of legisla-
tive acts in the Supreme Court in joint session; legal
education at Institute of Higher Studies and Ecole Super-
ieure de Droit of the University of Tunis; has not accepted
compulsory ICJ jurisdiction ,
National holiday: Independence Day, 1 June
Branches: executive dominant, unicameral legislative
largely advisory; judicial, patterned on French system and
Koranic law
Government leaders: President Habib Bourguiba; Prime
Minister Hedi Nouira
Suffrage: universal over age 2]
Elections: national elections held every 5 years; last
elections 2 November 1974
Political party and leader: Destourian Socialist Party,
Habib Bourguiba
Voting strength (1974 election): 100% Destourian Social-
ist Party
Communists: a small number of nominal Communists,
mostly students; Tunisian Communist Party proscribed in
January 1963 .
Member of: AFDB, Arab League, AIOEC, EC (associ-
ation until 1974), FAO, G-77, IAEA, IBRD, ICAO, IDA,
IFC, ILO, International Lead and Zinc Study Group, IMCO,
IMF, IOOC, ITU, IWC—International Wheat Council,
NAM, OAU, U.N., UNESCO, UPU, WHO, WIPO, WMO,
WTO','d163d35deb2557ff83cfcf6539c418a9665f5a92416b9b9de7fa2e18b47460e7','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a595b095331b9d46890f8d115c6cc6bf3968ca1fdf60dda2f4678df7181ab8de',1966,'DE','Germany','government',448,'Legal name: Republic of Turkey
210
Type: republic
Capital: Ankara
Political subdivisions: 67 provinces
Legal system: derived from various continental legal
systems; constitution adopted 1961; judicial review of
legislative acts by Constitutional Court; legal education at
Universities of Ankara and Istanbul; accepts compulsory IC]
jurisdiction, with reservations _
National holiday: Republic Day, 29 October
Branches: President elected by parliament; Prime Minis-
ter appointed by President from members of parliament;
Prime Minister is effective executive; cabinet, selected by
Prime Minister and approved by President, must command
majority support in lower house; parliament bicameral
under constitution promulgated in 1961; National Assembly
has 450 members serving 4 years; Senate has 150 elected
members, one-third elected every 2 years, 15 appointed by
the President to 6-year terms (one-third appointed every 2
years), and 19 life members; highest court for ordinary
criminal and civil cases is Court of Cassation, which hears
appeals directly from criminal, commercial, basic, and peace
courts
Government leaders: President Fahri Koruturk; Prime
Minister Bulent Ecevit
Suffrage: universal over age 2]
Elections: National Assembly and Senate (1/3 of seats), ,
Republican People’s Party won a plurality in June 1977;
Presidential (1980)
Political parties and leaders: Justice Party (JP),
Suleyman Demirel; Republican People’s Party (RPP), Bulent
Ecevit; National Salvation Party (NSP), Necmettin Erbakan;
Democratic Party (DP), Ferruh Bozbeyli; Republican
Reliance Party (RRP), Turhan Feyzioglu; Nationalist Action
Party (NAP), Alpaslan Turkes; Unity Party (UP), Mustafa
Timisi; Communist Party illegal
Communists: strength and support negligible
Other political or pressure groups: military forced
resignation of Demirel government in March 197] and
remains an influential force in national affairs
Member of: ASSIMER, CENTO, Council of Europe, EC
(associate member), ECOSOC, FAO, GATT, IAEA, IBRD,
ICAC, ICAO, IDA, IEA, IFC, IHO, ILO, IMCO, IMF,
IOOC, IPU, ITC, ITU, NATO, OECD, Regional Coopera-
-tion for Development, U.N., UNESCO, UPU, WHO, WIPO,
WMO, WSG, WTO','fc39c73e4681860d70244eb813d56b9ce6cee91c5c619ecf6c7027a899f80f79','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c186cc6314452d08d295a14467ce8379159a1c92d96548ec777f52d570232bc',1966,'UG','Uganda','government',452,'Legal name: Republic of Uganda
Type: republic, independent since October 1962
Capital: Kampala
Political subdivisions: 10 provinces and 34 districts
Legal system: based on English common law and
customary law; constitution adopted 1967; present govern-
ment rules despotically, has intimidated judicial officials and
has made constitution of no consequence; legal education at
-
Makerere University, Kampala; accepts compulsory ICJ
jurisdiction, with reservations
212
National holiday: Independence Day, 9 October
Branches: Gen. Amin rules by decree; assisted by Council
of Ministers and Defense Council, a group of military
officers
Government leader: Gen. Idi Amin Dada, President for
life
Suffrage: universal adult
Elections: none scheduled by military government
Political parties: none
Communists: possibly a few sympathizers
Member of: AFDB, Commonwealth, FAO, G-77, GATT,
IAEA, IBRD, ICAC, ICAO, ICO, IDA, IFC, ILO, IMF, ISO,
ITU, NAM, OAU, U.N., UNESCO, UPU, WHO, WIPO,
WMO, WTO
Legal name: Union of Soviet Socialist Republics
Type: Communist state
Capital: Moscow :
Political subdivisions:.15 union ‘republics, 20 autonomous
republics, 6 krays, 121 oblasts, and 8 autonomous oblasts
Legal system: civil law system as modified by Communist
legal theory; revised constitution adopted 1977; no judicial
review of legislative acts; legal education at 18 universities
and 4 ‘law institutes; has not accepted compulsory ICJ
jurisdiction
National holiday: Oster Revdlition Day, 7 November
Branches: ‘Council of Ministers (executive), Supreme
Soviet: (legislative), Supreme Court of U.S.S.R. (judicial)
Government leaders: Leonid J. Brezhnev, General
Secretary of the Central Committee of the Communist Party
and Chairman of the Presidium of the U.S.S.R. Supreme
Soviet; Aleksey N. Kosygin, Chairman of the U.S.S.R.
Council of Ministers
Suffrage: ‘universal over age 18; ‘direct, equal
Elections: to Supreme Soviet every 5 years; 1,517 deputies
elected in 1974; 72.2% party members
Political party: Communist .Party. of the Soviet Union
(CPSU) only party permitted ,
Voting strength (1974 election): 153,287, 112; persons over
18; allegedly 99.98% voted
Communists: over 16 million. party mnenibers
Other political or pressure groups: Komsomol, trade
unions, and other organizations which facilitate Communist
control
Member of: CEMA, Geneva Disarmament Conference,
IAEA, IGAC, ICAO, ICES, ILO, International Lead and
Zinc Study Group, IMCO, IPU, ISO, ITC, ITU, IWC—
International Whaling Commission, IWC—International
Wheat Council, U.N., UNESCO, UPU, Warsaw Pact, WHO,
WIPO, WMO, WTO','39a16c10319cbc0621db5b67f1065dcbf4345eea6edb50598aa344149cceaae2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cec3d6c7d51c07d46fe43846dd7b7d16e195e22a85c0608bdc0567f36d40c4e4',1966,'AE','United Arab Emirates','government',456,'Legal name: United Arab Emirates (composed of former
Trucial States)
Member states: Abu Dhabi; Ajman; Dubai; Fujairah; Ras
alKhaimah; Sharjah; Umm alQaiwain
Type: federation; constitution signed December 1971,
which delegated specified powers to the United Arab
Emirates central government and reserved other powers to
member shaykhdoms
Capital: Abu Dhabi
Legal system: secular codes are being introduced by the
U.A.E. Government and in several member shaykhdoms;
Islamic law remains very influential
National holiday: 2 December
Branches: Supreme Council of Rulers (7 members), from
which a President and Vice President are elected; Prime
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
A A) AR avn, eS ee LA
RAM A kak An AM ARLAR Aa em A tm UR an CA
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
UNITED ARAB EMIRATES/UNITED KINGDOM
Minister and Council of Ministers; National Consultative
Council; federal Supreme Court
Government leaders: Shaykh Zayid of Abu Dhabi,
President; Shaykh Rashid of Dubai, Vice President; Shaykh
Maktum’ of Dubai, Prime Minister
Suffrage: none
Elections: none
Political or pressure groups: none; a few small clandes-
tine groups are active
Member of: Arab League, G-77, IBRD, ICAO, ILO, IMF,
NAM, OAPEC, OPEC, ‘U.N., UNESCO, UPU, WHO,
WIPO, WTO','6b1f45eefebef547f57e19edd1cc46887f92fdab08b972a1a6f58062abebbe19','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b6031bee4e8e33e72a630822534ae5fbefa23549030d85047c9d907f5041abf',1966,'GB','United Kingdom','government',460,'Legal name: United Kingdom of Great Britain and
Northern Ireland
British (collective pl.);
Type: constitutional monarchy
Capital: London
Political subdivisions: 635 parliamentary constituencies
215
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Legal system: common law tradition with early Roman
and modern continental influences; no judicial review of
Acts of Parliament; accepts compulsory ICJ jurisdiction,
with reservations
National holiday: Celebration of Birthday of the Queen,
16 June
Branches: legislative authority resides in Parliament;
executive authority lies with.collectively responsible cabinet
led by Prime Minister; House of Lords is supreme judicial
authority and highest court of appeal
Government leader: Prime Minister James Callaghan
Suffrage: universal over age 18
Elections: at discretion of Prime Minister, but must be
held before expiration of a 5-year electoral mandate; last
election 10 October 1974
Political parties and leaders: Conservative, Margaret
Thatcher; Labor, James Callaghan; Liberal, David Steel;
Communist, Gordan McLennan; Scottish National, William
Wolfe; Plaid Cymru, Phil Williams
Voting strength (1974 election): Conservative 277 seats
(35.9%); Labor 319 seats (39.3%); Liberal 13 seats (18.3%);
Scottish National 11] seats (2.8%); Plaid Cymru 3 seats (0.6%);
other 12 seats (3.2%).
Communists: 29,000
Other political or pressure groups: Trades Union
Congress, Confederation of British Industry, National
Farmers’ Union _
’ Member of: ADB, CENTO, Colombo Plan, Council of
Europe, DAC, EC, EEC, ELDO, ESRO, EURATOM, FAO,
GATT, IAEA, IBRD, ICAC, ICAO, ICES, ICO, IDA, IEA,
IFC, IHO, ILO, International Lead and Zinc Study Group,
IMCO, IMF, IOOC, IPU, ISO, ITC, ITU, ‘1}WC—Interna-
tional Whaling Commission, IWC—International Wheat
Council, NATO, OECD, UN., UNESCO, UPU, WEU,
WHO, WIPO, WMO, WSG
’ Legal name: Republic of Upper Volta
Type: republic; in 1978 a moderate military government,
in power for 12 years, fulfilled plans to turn power over to a
civilian parliamentary democracy; former head-of military
government retained presidency
Capital: Ouagadougou ;
Political subdivisions: 10 departments, composed of 44
cercles, headed by civilian. prefects ;
Legal system: based on French civil law system and
customary law; a national referendum -held in November
1977 approved a new constitution and country returned to
civilian rule in July 1978; has not accepted compulsory-ICJ
jurisdiction :
National holiday: Proclamation of the Republic, . 11
December — .
Branches: President is an army officer; 57-man National
Assembly was elected 30 April 1978
Government leaders: Maj. Gen. Aboubacar Sangoule
Lamizana, President; Dr. Joseph Conombo, Prime Minister;
Gerard Kango Ouedraogo, President of the National
Assembly ;
. Suffrage: universal for adults
Elections: Parliamentary elections held on 30 April 1978
and Presidential elections on 14 May; date of next election
unknown : :
Political parties and leaders: 3 parties elected to seats in
the National Assembly: Voltan Democratic Union (UDV)
holds the majority of seats; National Union for the ‘Defense
of Democracy (UNDD); Voltan Progressive Union (UPV)
Communists: no Communist party; some sympathizers
Other political or pressure groups: labor organizations
are badly splintered, students and teachers occasionally
strike ;
Member of: AFDB, CEAO, EAMA, ECA, EIB (associate),
Entente, FAO, G-77, IBRD, ICAO, IDA, ILO, IMF, IPU,
ITU, NAM, Niger River Commission, OAU; OCAM, U.N.,
UNESCO, UPU, WCL, WHO, WIPO, WMO, WTO','bc138844ec0a54f22619d4d7fbf971653bf75da27f17c1027679b31090879aac','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f98c0cc2e791be9e23902187c9e6355c001d43c9e820ae3a6f3c1164d58bf7ee',1966,'WF','Wallis and Futuna','government',464,'Legal name: Territory of the Wallis and Futuna Islands
Type: overseas territory of France
Capital: Matu Utu
Political ‘subdivisions: 3 districts
Branches: territorial assembly of 20 members; popular
election of one deputy to National Assembly in Paris, and
one Senator
Government leader: Superior Administrator Jacques de
Agostini
Suffrage: universal adult
Elections: every 5 years','f5ddc949446edc8f73bc7a76d5a45a43e19f6d3721b90e4c59f6c2ca872522c2','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6eee11cd0a750533f2034683ffdb6b2ce755f96b6ce507d0951e1f729c5f0065',1966,'ZM','Zambia','government',468,'Legal name: Republic of Zambia
Type: republic since October 1964
Capital: Lusaka
Political subdivisions: 9 provinces
Legal system: based on English common law and
customary law; new constitution adopted September 1973;
judicial review of legislative acts in an ad hoc constitutional
council; legal education at University of Zambia in Lusaka;
has not accepted compulsory ICJ jurisdiction
National holiday: 24 October
Branches: modified presidential system; unicameral legis-
lative; judiciary
Government leaders: President Kenneth David Kaunda;
Prime Minister Daniel Lisulo
Suffrage: universal adult
Elections: general election held 12 December 1978
Political parties and leaders: United National Independ-
ence Party (UNIP), Kenneth Kaunda; former opposition
party banned in December 1972 when 1 party state
proclaimed
Voting strength (1973 election): in first presidential and
parliamentary elections under single-party system, 43% of
eligible voters went to polls; Kaunda was only candidate for
President; National Assembly seats were contested by
members of UNIP
Communists: no Communist Party, but sympathizers of
socialism in upper levels of government, UNIP, and labor
unions
Member of: AFDB, Commonwealth, FAO, G-77, GATT
(de facto), IAEA, IBRD, ICAO, IDA, IDB, IEA, IFC, ILO,
International Lead and Zinc Study Group, IMF, IPU, ITU,
NAM, OAU, U.N., UNESCO, UPU, WHO, WMO, WTO','0802616e20e3e6aa1f5dac6d8ed4df27f1dcdfb2ffa94ba593a7388b0ffaf40c','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07cfd6ee6c0c900330a714cb9104bfddaba52bbb2678d1e8fc7dc9e37caf2c6c',1966,'US','United States','government',472,'Legal name: United States of America:
Legal system: based on English common law; dual system
of courts, state and federal; constitution adopted 1789;
judicial review of legislative acts; accepts compulsory ICJ
jurisdiction, with reservations
National holiday: Independence Day, 4 July
Voting strength (1976 presidential election): Democratic
Party (Carter), 40,829,000 (50.1%); Republican Party (Ford),
39,146,000 (48%); minor parties, 1,578,000 (preliminary
figures)
Communists: party membership, 10,000-11,000 (est.);
General Secretary, Gus Hall
Member of: ADB,, ANZUS, CENTO, Colombo Plan,
DAC, FAO, GATT, IADB, IAEA, IBRD, ICAC, ICAO,
ICES, ICO, IDA, IDB, IEA, IFC, IHO, International Lead
and Zinc Study Group, IMCO, IMF, IPU, ITC, ITU, IWC—
International Whaling Commission, IWC—International
Wheat Council, NATO, OAS, OECD, U.N., UNESCO,
UPU, WHO, WIPO, WMO, WSG, WTO','61f2dece569942772828b35e675ddda3d85693d3ab4877c7bc1faea339d3999f','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

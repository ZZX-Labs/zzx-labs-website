SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d11f7f29697ace7a5f91b12e63a20bd05be82038e2544e84f9c05548b42a2970',1970,'','','people-and-society',2,'Population: 37,717,000, average annual growth rate 2.6%
(current) ,
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly Christian and Jewish)
Language: Turkish, Kurdish, Arabic, English ;
Literacy: 55%
Labor force: 13.8 million; 68% agriculture, 16% industry, 16% service;
substantial shortage of skilled labor; ample unskilled labor
Organized labor: 10% of labor force
ARABIA','f8b7605ba1b2a23088aac7fcfb362b6313b7efb6c969c93029fd1c2dc7706c95','internet-archive','cia-readingroom-document-06726997','txt','76d9d27af689699d8bc7a1ecbd9198b2812b73ca43290dc0ca20f8a528e04b14','https://archive.org/download/cia-readingroom-document-06726997/06726997_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('247a57195b8fd67f8d9a80ca10719e9fbe83ec58bfdb66b63364e97c7e0679a6',1970,'','','people-and-society',2,'Population: 43,767,000 (January 1979), average annual
growth’ rate 2.6% (current)
Nationality: noun—Turk(s); adiective—Turkish
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly
Christian and Jewish)
Language: Turkish, Kurdish, Arabic
Literacy: 55%
Labor force: 16.4 million; 61% agriculture, 13% industry,
25% service; substantial shortage of skilled labor; ample
unskilled Jabor (1978)
Organized labor: 12% of labor force','22268bb44b86a205c3b4ea61403dc1dc6cd510e8f55b8a6eaab3eacf86bd965b','internet-archive','cia-readingroom-document-06727041','txt','e81594013193fd0f801a852bbb034b76c4bb95d6da2f549c5399458122a300ac','https://archive.org/download/cia-readingroom-document-06727041/06727041_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bef4038ae0675778c7e57ee7f4e89ebe6dbed62b61170e160a851971dadd77b',1970,'','','people-and-society',2,'Population: 38,198,000, average annual growth rate 2.6%
(10/65-10/70)
Ethnic divisions: 90% Turkish, 7% Kurd, 3% other
Religion: 99% Muslim (mostly Sunni), 1% other (mostly Christian and Jewish)
Language: Turkish, Kurdish, Arabic, English
Literacy: 55%
Labor force: 13.8 million; 68% agriculture, 16% industry, 16% service;
substantial shortage of skilled labor; ample unskilled labor
Organized labor: 10% of labor force','49fded7edad1505d176731698caed4da46556420727747bae87bb3d1dba995fc','internet-archive','cia-readingroom-document-06727039','txt','50b279e699039846ddd2e23926e0f2cdd54ecd6c38a877f833fb7055b1b66e05','https://archive.org/download/cia-readingroom-document-06727039/06727039_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('620ac84a5d4edc922c0e75aff5984bf4b9ee88d3100a07867dbee9f1ab5052ce',1970,'','','raw',1,'A pproved for Release: 2018/04/27 C06726997 =
NATIONAL INTELLIGENCE SURVEY
; BASIC INTELLIGENCE FACTBOOK
JANUARY 1973
$
Py
; CHIVAL RECORD
des t 1972 i f this Factbook, ''ARCHIV. ,
Supersedes the July 1972 issuance of this Factboo i PLEASE RETURN TO |
copies of which should be destroyed. AGEN i ARCHIVES,
a ORT
Approved for Release: 2018/04/27 C06726997
Approved for Release: 2018/04/27 C06726997
“SECRE—
FOREWORD
The Basic Intelligence Factbook, a compilation of basic data
on political entitics worldwide, is coordinated and published
scmiamnually as part of the NIS Program by the Office of Basic
and Geographic Intelligence, Central Intelligence Agency. The
data are prepared by components of the Defensc Intelligence
Agency and the Central Intelligence Agency. Comments and
suggestions should be addressed to the Office of Basic and
Geographic Intelligence (Attn: NIS Factbook), Central Intel-
ligence Agency, Washington, D.C. 20505.
Additional copics of the Factbook, both classificd and un-
classificd issucs, are obtainable through established channels for
disscmination of the NIS.
THIS MATERIAL CONTAINS INFORMATION AFFECTING
THE NATIONAL DEFENSE OF TIIE UNITED STATES
WITHIN THE MEANING OF THE ESPIONAGE LAWS,
TITLE 18, USC, SECS. 793 AND 794, THE TRANSMISSION
OR REVELATION OF WHICH IN ANY MANNER TO AN
UNAUTIIORIZED PERSON IS PROHIBITED BY LAW.
CLASSIFIED BY 58-0001, EXEMPT FROM GENERAL DECLASSIFICATION SCHEDULE
OF €. O. 11652 EX zea CATEGORIES SB (2) AND (3). DECLASSIFIED ONLY
ON APPROVAL OF OCI
Approved for Release: 2018/04/27 C06726997
em det
ee ee
Approved for Release: 2018/04/27 C06726997
WARNING
The NIS is National Intelligence and may not be re-
leased or shown to representatives of any foreign govern-
ment or international body except by specific authorization
of the Director of Central Intelligence in accordance with
the provisions of National Security Council Intelligence Di-
rective No. 1.
For NIS containing unclassified material, however, the
portions so marked may be made available for official pur-
poses to foreign nationals and nongovernment personnel
provided no attribution is made to National Intelligence or
the National Intelligence Survey.
Unless otherwise indicated, individual items
are UNCLASSIFIED/FOR OFFICIAL USE ONLY.
Classification designations are:
(2) ee Confidential
(S)...... Secret
Approved for Release: 2018/04/27 C06726997
Approved for Release: 2018/04/27 C06726997
SECRET
Table of Contents (cont''d):
SENEGAL. oe be so ec bs Bate oor Ra we ee el ee SO ale le or SP es
SEYCHELLES =o) 5.95. et te ee A fe ee ee Sa es oa hte erie eae
Sharjah (see UNITED ARAB EMIRATES)
STERRA LEONE: 3. 3. 3,6: jose aoe koe: eee eo Aca 4 be ee RE are
SIKKIM esol aoe Wn ea ey eee ae ee SO We we Aaa ter eS ete
SOMALT As. for) ec se coh Oe ewe se ee Gc ce ites) Srl a as ae ew ele
SOUTHARRIGCA |e. oi: eh ee il el oe ere ww Bea ch Swe wwe als
Southern Rhodesia (see RHODESIA)
SOUTH=WEST |AFRIGAS: e555 55 Soke, Woe les ae ec OS es
SPAIWNs o.oo oe lertene ce mar Cove! Cee oh Wow LSS? o> He Rua coy See ee Ged Saas
SRT LANKA si i50c3. oe hate faa tes. a ER a ee EK ey
i i i i i i |
2Tz
|
Middl (see peace
THAILAND... .... B Meas i) Ate ha kak oA Gheeiued Ma, Mor iy ode te melee fo
TONGA. ee, ee rare
TRINTOAD AND TOBAGOs 2 3 Gav 0 Soba actbnoe and fo aces a
TUNISIA. 2... ww ee Sol Gat cat anh oy Weel oe aoe ol Ga Sakae fee be oh Oe
TURKEY, |, 5353-6 co: sic ae Ges Gos 0 as a te ec Bye Pol Gn eS Tecate faire a
-U-
S.R
UNITED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm "al Qaiwain. .. 1. ee ew eee
United Arab Republic (see EGYPT)
UNITED KINGDOM. 2... 1 2 we ee ee ee
UNITED: STATES > 5. eas ce. Ss ber evs ie el en a eee ee
UPPER ‘VOLTA S. a ten ves és ce ete oe Nel ie Sele a? ec ee ea Mee ea
URUGUAY 6 ese ccs aise Melee yee og oo ley ty ce: Sa i a ea ey tea eS La ee
-\\-
VATICAN CLIN io a oe dee ae ht a Rees ae es I ae ae cas
VENEZUELA cece seas ol a as $05 ar dk a ce ave dap Pe ay Sa a Se, lw Ae
VIETNAM, NORTH... ....., BS Ae Sia Bye ROSENT RS Jet te be a dh, ae eect, ye
VIETNAM, SOUTH . . 1 eee ee eee we ee eee tt tts
Approved for Release: 2018/04/27 C06726997
Approved for Release: 2018/04/27 C06726997
—~Sterer—
NIS 27 TURKEY
LAND:
296,000 sq. mi.; 34% cropland, 34% meadows and pastures,
23% forested, 9% unproductive
Land boundaries: 1,600 mi.
WATER: Pare
Limits of territorial waters (claimed): 6 n. mi. .
except in Black Sea where it is 12 n. mi.
(fishing, 12 n. mt.)
Coastline: 4,475 mi.','3d010a63a9223686fb0d93a0591b381470714a42cab3b49d027269a6eff5c8a9','internet-archive','cia-readingroom-document-06726997','txt','76d9d27af689699d8bc7a1ecbd9198b2812b73ca43290dc0ca20f8a528e04b14','https://archive.org/download/cia-readingroom-document-06726997/06726997_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a960c01e97fb4588d2ceb625093fd97b8c1331a992bf7deef17a09525a927473',1970,'','','raw',1,'Bee
Approved for Release: 2018/04/27 C06727041
National 59 U (3° “Secret
Foreign
Assessment
Center
National
Basic Intelligence
Factbook
January 1979
~Seeret_
GC BIF 79-001
January 1979
Approved for Release: 2018/04/27 C06727041
Approved for Release: 2018/04/27 C06727041
NATIONAL SECURITY INFORMATION
Unauthorized Disclosure Subject to Criminal Sanctions
DISSEMINATION CONTROL ABBREVIATIONS
NOFORN-— Not Releasable to Foreign Nationals
NOCONTRACT~- Not Releasable to Contractors or
Contractor /Consultants
PROPIN- Caution—Proprietary Information Involved
NFIBONLY— NFIB Departments Only
ORCON- Dissemination and Extraction of Information
REL...
Controlled by Originator
This Information has been Authorized for
Release to...
Unless otherwise indicated, individual items are
TUNCTASSHHED.———
Approved for Release: 2018/04/27 C06727041
Approved for Release: 2018/04/27 C06727041
National Basic Intelligence
FACTBOOK
January 1979
Supersedes the July 1978 issuance of this
Factbook, copies of which should be destroyed.
Approved for Release: 2018/04/27 C06727041
Approved for Release: 2018/04/27 C06727041
FOREWORD
The National Basic Intelligence Factbook, a compilation of basic data
on political entities worldwide, is coordinated and published semiannually
by the Central Intelligence Agency. The data are prepared by components
of the Central Intelligence Agency, the Defense Intelligence Agency, and
the Department of State. Comments and suggestions should be addressed to
the Office of Geographic and Cartographic Research (Att: Factbook),
Central Intelligence Agency, Washington, D.C. 20505.
This publication is prepared for the use of U.S. Government officials.
The format, coverage and contents of the publication are designed to mect
the specific requirements of those users. U.S. Government officials may
obtain additional copies of this document directly or through liaison
channels from the Central Intelligence Agency.
Approved for Release: 2018/04/27 C06727041
Approved for Release: 2018/04/27 C06727041
~SECRET- January 1979
-t- Page
TANZANIA, loses ht tee teak te tl Ra A aM poate al oN ath 244
Tasmania (see AUSTRALIA)
THAILAND: os sscisechtist Seustecs eae aee cet, Shab clei ab a OR eels Pts cout Maree tt elaes BOR ot 245
FOG, ieecrisk EL AI Nol Sole hk AN EY Oya tt ote dedthee ch ped nd eve 247
TONGA ooo llassiinad tia dba ots ale het ae ea oa ee ed tenth tal Mids faut Seven 248
Transkei (see SOUTH AFRICA)
TRINIDAD AND TOBAGO ooo. cceccecececcecesestctetevtte coves ceteveseiteteeeetece 249
TUNISIA ee 2oee Se STON get ales SPN es eel ee ase SAN etl Oct a pe 251
CORRE ic. 2e5ote 502 oN ciel ats po eile as ee aN Me la on Be ek oat a ete ee ta vt 252
TUVALU (formerly Ellice Islands) 00.0.0 ceccccccecee tcc cecececeeeeeeeeeeeeeee ce, 254
=
UGANDA 2) acted ese acd deed te i Trt Lele a tak ttn togh ote 255
Umm al Qaiwain (see UNITED ARAB EMIRATES)
USSR? siesta ee Nees a eet Sas tet el ee ne a Saf Te OT a 256
UNITED ARA® EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm al Qaiwain oo. 259
United Arab Republic (see EGYPT)
UNITED KINGDOM ooo ccc cece cccececacecetevavenerestetieevins ss ccutvevestititeteveveneees 260
UNITED “STATES © ects. csc inal Pah Sia Re COT uh Ee peda itn oie ay 280
UPPER VOLEAS f3cccess3 20) ag ea Ge Ee ae se ea ts aaa 262
URUGUAY > -5s:che eset och iat ath tes lahat ae Le Ma A Cat, (heel val iy 263
ye.
VATICAND CIV. 2.3 ited Stat etek e al Orie ld, Grech tte ce eee A ade 265
VENEZUELA 220.3 5 footy Ei ec ett reech conden aloha es eR es oe 266
VIETNAM 252.022 css. Dect LE sea seerass Seen t Nl inn Sane chet ee tet ge! Be 268
—w—
WALLIS and FUTUNA once cc ccsesceecesteeestevsecetevesesceteeceveteteteeeteeere, 270
Walvis Bay (see SOUTH AFRICA)
WESTERN SAHARA (formerly Spanish Sahara) 0.0.0.0. cocccceccccceseeeeeceeeeccce 270
WESTERN SAMOA ooo ccceecces sees sense nes ecucevevevevevesteseatsisesitivatesttavstivesteseterteceece. 271
—y—
YEMEN. (Adon). ¢:c0:2.35.05 Sy. esa tn a en Hei dewees din lee Ai rece, nie & 272
YEMEN ''(Sona) \\ 20: 30.6 Ones aes Recetas eon, Ga 8 OR a a ak 273
VUGOSLAVIA 4. iee tases, etegsle iS ea bebe Aten tenty hvac Mae aba 275
—7—
LAURE ects weet teen beaded land ihe So, nA RO Nt et tat ate cms ee a Ht ae Le Pog 277
AMBIA Shep Me vet Beret recenseblen at ert ithe, Wee EE De BER as ot tee ae Ct aie! 278
Zanzibar (see TANZANIA)
viii ~SECREF-
Approved for Release: 2018/04/27 C06727041
Approved for Release: 2018/04/27 C06727041
January 1979
SECRER.
NR Record TURKEY NR Record
NR Record
LAND
766,640 km*; 35% cropland, 25% meadows and pastures,
23% forested, 17% other
Land boundaries: 2,574 km
252 “SEGREL_
Approved for Release: 2018/04/27 C06727041
Approved for Release: 2018/04/27 C06727041
January 1979
“SECRET
TURKEY
WATER
Limits of territorial waters (claimed): 6 nm except in
Black Sea where it is 12 nm (fishing 12 nm)
Coastline: 7,200 km','91cbd5d071dd25ea465713c0f86903693de45bbebdbbbc2608e54b323ca18688','internet-archive','cia-readingroom-document-06727041','txt','e81594013193fd0f801a852bbb034b76c4bb95d6da2f549c5399458122a300ac','https://archive.org/download/cia-readingroom-document-06727041/06727041_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c901ced5c39e4f85c8c423cb063ea34e6c96070407e0ad4eacc7c5ca766f50d',1970,'','','raw',1,'Approved for Release: 2018/04/27 C06727039
>
“NATIONAL INTELLIGENCE SURVEY
BASIC INTELLIGENCE FACTBOOK
JULY 1973
Supersedes the January 1973 issuance of this “ ARCHIVAL RECOR!
Factbook, copies of which should be destroyed FLEAS? RETURN TO ;
AGENCY ARCHIVES, ELDG. 4+.
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
FOREWORD
The Basic Intelligence Factbook, a compilation of basic data
on political entities worldwide, is coordinated and published
semiannually as part of the NIS Program by the Office of Basic
and Geographic Intelligence, Central Intelligence Agency. The
data are prepared by Office of the Geographer, Department of
State and by components of the Defense Intelligence Agency
and the Central Intelligence Agency. Comments and suggestions
should be addressed to the Office of Basic and Geographic
Intelligence (Attn: NIS Factbook), Central Intelligence Agency,
Washington, D.C. 20505.
Additional copies of the Factbook, both classified and un-
classified issues, are obtainable through established channels for
dissemination of the NIS.
THIS MATERIAL CONTAINS INFORMATION AFFECTING
THE NATIONAL DEFENSE OF THE UNITED STATES
WITHIN THE MEANING OF THE ESPIONAGE LAWS,
TITLE 18, USC, SECS. 793 AND 794, THE TRANSMISSION
OR REVELATION OF WHICH IN ANY MANNER TO AN
UNAUTHORIZED PERSON IS PROHIBITED BY LAW.
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
WARNING
The NIS is National Intelligence and may not be re-
leased or shown to representatives of any foreign govern-
ment or international body except by specific authorization
of the Director of Central Intelligence in accordance with
the provisions of National Security Council Intelligence Di-
rective No. 1.
For NIS containing unclassified material, however, the
portions so marked may be made available for official pur-
poses to foreign nationals and nongovernment personnel
provided no attribution is made to National Intelligence or
the National Intelligence Survey.
Unless otherwise indicated, individual items
are UNCLASSIFIED/FOR OFFICIAL USE ONLY.
Classification designations are:
(OC) testes Confidential
(S)ve. 32) Secret
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
“SECRET.
Table of Contents
Page
SAN: MARINO: ce 6 cee See ge Sere Se a lade Gee an A ee ie a ae 383
SAUDE ARABIA g:o5 3 sd. ceed & Reel Se) eS ee es 385
SENEGAL 2. fms oe So te a te Se at ee LE Si eh aes PE eee 387
SEYCHELLES cigar ee eas oe be este eS he Ge so es eee Sa ae So Be 389
Sharjah (see UNITED ARAB EMIRATES)
STERRA (LEONE: ~) 05. &. gee Sees ete A Sa ae te Re ey ne ye pe en ee 391
ST KKEM 3.2 caste see A es ce sl ee Gave Con Be eee, Ree ee We eS 393
STINGAPORE 6 ~ eieccoe otesecs desea We: obo eG" Annee Moh ee io oes nao es Wee eee 395
SOMALTA Sic: senor SBS ee Pa EE ne ae ie een ee eee “al GE ws Rees of? 397
SOUTH: AFRICA? oc. cei eo 8 See eer te ar ee Ss Tee 0 We ee Se 399
Southern Rhodesia (see RHODESIA)
SOUTH-WEST AFRICA. . . 2. 2 1 ee we ee te we te 403
SPAINGG se Se oe Se ee ls Ba Sera tS re wl hee os tay Janine 8s 405
SPANTSH ‘SAHARA 5. 232-0. ee kee ee ee see ee eee ww Ce 409
SRE LANKA Ses setae ib tie es re ote Sore a wren ie) eo ee tated See ae 411
SUDAN o. ie-.g. oe sehen Sek mol as he Bh “Seer se tgs Sha tah re win et ems NS Ge tee eh oe 415
SURINAME. 02 xsc260 ve sei Soro ce A SE ee eR he ee as ar tar Sh eee eee 419
SWAZILAND =. 2.62 ccs S) nO ee Fe Oo Se Blea Mek % Bee, Byway teu ke 421
SWEDEN cue ce nea caetot le conte on medic phase, Gti Gams Mean Se 423
SWITZERUAND sc od ce ''o: 1,006 os van ts Fen Saas Ag Be, eae! Tey Cage 427
SYR TRG oy ec secs etek be ee ek eng es areas 429
-T:
Tanganyika (see TANZANIA)
TANZANTAS ob cake. oie eh ce etn eh nin 8 Case a a te cle Ca aS wate Se 431
Tasmania (see AUSTRALIA)
THAILAND 3. wc -8 we ees eR ee be aoe & ie we ee 495
TOGO a: yee UR Ow aw ae ee wd Se ee A Se wee ee 439
TONGA © 6. edge ee Se Sc ae eS rae ; : ‘ 44]
oe AND TOBAGO. F Bae bode al eh awe hare ee ss . . =. 443
iia Bah GPL Baa aE ND ON Cie DER ea vs ect aay ce Fs 445
TURKEY gn eh weet Ai APS ae i sg ge eet, BMG ee eit te aa Sk: 447
-U-
UGANDA 555 io oe eo do reser ree ee nse ae a eles wes es ee 451
nes al Qaiwain (see UNITED ARAB EMIRATES)
Sk, ake Byles Be Sw Gon Ey fa els NDR ne Ot age, ee 453
ED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm al Qaiwain. ........2... 457
United Arab Republic (see EGYPT)
UNITED KINGDOM. 2... 1 1 we ee ee ee we tt ee te et 459
UNETED “STATES. o°-2 oc. se? Gece oe an ce ere Vel Gh ewe Sal Bek ele ne a 497
UPPER: VOLTA so: o:ce) te tee es oe I ee Be BO be Oe bes 463
URUGUAY cei eo ie eho eae Ser ay Boal ww Boer SP Gee: Be, Sas 82 weer 8 465
-V-
VATICAN: CLI a: 22-2, ecg: sés fortes Se et Se ea SCR te. ae a Gales 469
VENEZUELA se 5- ower ver era RS, “eee eee te yee el HS Bey Sere Re 471
VIETNAM, ‘NORTH gees detec tee ca eel ceive ei Ba ee ee 475
VEETNAM,. “SQUTHD ec. ce ios wee ae Se ee ee ae ee EP 479
v
SEGRE.
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
““SRCRET.
NIS 27 TURKEY
D:
296,000 sq. mi.; 34% cropland, 34% meadows and pastures,
23% forested, 9% unproductive
Land boundaries: 1,600 mi.
WATER:
Limits of territorial waters (claimed): 6 n. mi.
except in Black Sea where it is 12 n. mi.
(fishing, 12 n. mi.)
Coastline: 4,475 mi.','d81506181d04ffbecc364831122ff5a940f94bbc6ccef504917bcbbdae630814','internet-archive','cia-readingroom-document-06727039','txt','50b279e699039846ddd2e23926e0f2cdd54ecd6c38a877f833fb7055b1b66e05','https://archive.org/download/cia-readingroom-document-06727039/06727039_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95111b46a52df338616c5284b25d6d95f76768c211453bf8fde83af9f9d0f56e',1970,'','','raw',1,'STAT
STAT
JOHN H. BUCHANAN HOVved For Release 2006/07/27 : CIA-RDP81M00980R0012000 1 002 4ug snare sesicrawr
6rH District, ALAg. ES T. APPLE
24159 HAYBURN HOUSE
OFFICE BUILDING
MEMBER:
WASHINGTON, D.C. 20515
nrentitenaincinens — Congress of the United States ae
SUBCOMMITTEES:
Neuen House of Representatives CAROLYN F, GOLDEN
COMMITTEE ON Washington, D.C. 20515 ROOM 105, FEDERAL BUILDING
EDUCATION AND LABOR 1800 FIFTH AVENUE NORTH
BIRMINGHAM, ALABAMA 33203
SUBCOMMITTEES: 205-254-1525
ELEMENTARY, SECONDARY AND 17 October 1978
>
VOCATIONAL EDUCATION
POST-SEGONDARY EDUCATION _
COMPENSATION, HEALTH, AND Nhe a ve ce Sore Ta
GLO 4678. 3507 |
Ree es be era ae
ce tg tae
COM MISSION ON SECURITY
ANID COOPERATION IN EUROPE ry
[ spect
Office of Legislative Counsel
Central Intelligence Agency
Washington, D.C. 20505 -
Please be so kind as to forward me the following publications:
China: International Trade, 1976-77, ER 77-10674, November 1977
China O11] Production Prospects, ER 77-10030U, June 1977
China: Real Trends in Trade with Non-Communist Countries Since 1970, ER 77-10477,
October 1977
China''s Economy, ER 77-10738, November 1977
Foreign Trade Organizations of the People''s Republic of China, CR 77-103037,
July 1977, wall chart
Chinese Communist Party Organizations, CR 77-13125, September 1977, wall chart
Foreign Affairs Organization of the People''s Republic of China, CR 77-12843,
June 1977, wall chart
Military Organizations of the People''s Republic of China, CR 76-12748, June 1976,
wal] chart
Organization and Management in the Soviet Economy: The Ceaseless Search for
Panaceas, ER 77-10769, December 1977
Prospects for Soviet 017 Production: A Supplemental Analysis, ER 77-10425,
July 1977
Reconciliation of Soviet and Western Foreign Trade Statistics, ER 77-10132, May
1977 —
Prospects for Soviet Oi] Production, ER 77-10270, April
Soviet Economic Problems and Prospects, ER 77-10436U, July 1977
The Soviet State Budget Since 1965, ER 77-10529, December 1977
USSR Ministry of Freign Trade, CR 77-13114, June 1977, wall chart
Directory of USSR Ministry of Defense and Armed Forces Officials, CR 77-12060,
'' May 1977
A Dollar Cost Comparison of Soviet and US Defense Activities, 1966-76, SR 77-
10001U, January 1977
Communist Party of the Soviet Union (CPSU) Central Committee: Executive and
Administrative Apparatus, CR 77-13211, October 1977, wall chart
Communist Party of the Soviet Union (CPSU) Politburo and Secretariat: Positions
am and Responsibilities, CR 77-10225, January 1977, wall chart
~ USSR Council of Ministers, CR 77-13213, September 1977, wall chart
Communist Aid to the Less Developed Countries of the Free World, 1976, ER 77-
10296U, August 1977
MORICD
Approved For Release 2006/07/27 : CIA-RDP81M00980R001200010024-2
Approved For Release 2006/07/27 : CIA-RDP81M00980R001200010024-2
~ | |
The International Energy Situation: Outlook to 1985, ER 77-10240U, April 1977
International Terrorism in 1976, RP 77~ 10034U, July 1977
Major Oi} and Gas Fields of the Free World, ER 77-10313, June 1977
Natural Gas, ER 77-10062, February 1977
Nuclear Energy, ER 77-10468, August 1977
World Shipbuilding: Facing up to Overcapacity, ER 77-10678, November 1977
World Steel Market: Continued Trouble Ahead, ER 77~10351U, May 1977
National Basic Intelligence Factbook, published semiannually - January and July
Please forward the above to the attention of Martin William Christie, my Research
Assistant. 2
With kind regards, I am,
canmpgiasiact 2 AREA toe RA tere
ona
i JOHN H. BUCHANAN , JR.
Member of Congress
JHB: mwe
Approved For Release 2006/07/27 : CIA-RDP81M00980R001200010024-2','fad573bde251161d8947a76d3aa3c8c779b6bf3dc101cb7b04460480bbb11717','internet-archive','cia-readingroom-document-cia-rdp81m00980r001200010024-2','txt','d24b7c0c382760c2686c95249101cd60a17fd7ec6a03d1809928c37288c9e361','https://archive.org/download/cia-readingroom-document-cia-rdp81m00980r001200010024-2/cia-rdp81m00980r001200010024-2_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e47cfb22ec2997f87cb5fbb5a9b6000f424a66c34d5aa7db5162acc2ea92501',1970,'','','raw',1,'JOHN H. BUCHANAN, JR. ADMINISTRATIVE ASSISTANT
Wit Disrrict, ALABAMA JAMES T. AP? =
Approved For Release 2004/07/08 : CIA-RDP81MO0980RO0080008001Z-tesunes
MEMBER;
WASHINGTON, D... 20519
wrensehithatmerinens Congress of the United States ceca
SUBCOMMITTEES:
IMEDIASIONAU Oren AniONs House of Representatives chnoe Ne a onces
eoUSeMMT TES ON on Washington, D.C. 20515 peoenlepenen testa
SUBCOMMITTEES: ee eee 35203
ELEMENTARY, SECONDARY AND 17 October 1978
VOCATIONAL EDUCATION
POST-SECONDARY EDUCATION
COMPENSATION, HEALTH, AND
SAFETY
[¢ on eerie tat
amen 9
[ #78 3547|
COMMISSION ON SECURITY }
AND COOPERATION IN EUROPE F Lease
A pee )
Tce of Legtstative Counsel
STAT
Central Intelligence Agency
Washington, D.C. 20505 -
Please be so kind as to forward me the following publications:
China: International Trade, 1976-77, ER 77-10674, November 1977
China Oil Production Prospects, ER 77-10030U, June 1977
China: Real Trends in Trade with Non-Communist Countries Since 1970, ER 77-3.9477,
October 1977
China''s Economy, ER 77-10738, November 1977
Foreign Trade Organizations of the People''s Republic of China, CR 77-10303".
July 1977, wall chart
Chinese Communist Party Organizations, CR 77-13125, September 1977, wall chart
Foreign Affairs Organization of the People''s Republic of China, CR 77-1284.
June 1977, wall chart
Military Organizations of the People''s Republic of China, CR 76-12748, June 1976,
wall chart
Organization and Management in the Soviet Economy: The Ceaseless Search for
Panaceas, ER 77-10769, December 1977
Prospects for Soviet Oi] Production: A Supplemental Analysis, ER 77-10425,
July 1977
Reconciliation of Soviet and Western Foreign Trade Statistics, ER 77-10132, May
1977
Prospects for Soviet 011 Production, ER 77-10270, April
Soviet Economic Problems and Prospects, ER 77-10436U, July 1977
The Soviet State Budget Since 1965, ER 77-10529, December 1977
USSR Ministry of Freign Trade, CR 77-13114, June 1977, wall chart
Directory of USSR Ministry of Defense and Armed Forces Officials, CR 77-129°0,
~ May 1977
A Dollar Cost Comparison of Soviet and US Defense Activities, 1966-76, SR 7i-
10001U, January 1977
Communist Party of the Soviet Union (CPSU) Central Committee: Executive and
Administrative Apparatus, CR 77-13211, October 1977, wall chart
Communist Party of the Soviet Union (CPSU) Politburo and Secretariat: Positions
Teas and Responsibilities, CR 77-10225, January 1977, wall chart
‘= USSR Council of Ministers, CR 77-13213, September, 1977, wall chart
Communist Aid to the Less Developed Countries of the Free World, 1976. ER 7/-
10296U, August 1977
Approved For Release 2004/07/08 : CIA-RDP81M00980R000800080012-3
STAT
Approved For Release 2004/07/08 : CIA-RDP81M00980R00080008001 2-3
The International Energy Situation: Outlook to 1985, ER 77-10240U, April 1977
International Terrorism in 1976, RP 77- 10034U, July 1977
Major Oi] and Gas Fields of the Free World, ER 77-10313, June 1977
Natural Gas, ER 77-10062, February 1977
Nuclear Energy, ER 77-10468, August 1977
World Shipbuilding: Facing up to Overcapacity, ER 77-10678, November 1977
World Steel Market: Continued Trouble Ahead, ER 77-10351U, May 1977
National Basic Intelligence Factbook, published semiannualy - January and July
Please forward the above to the attention of Martin William Christie, my Research
Assistant. =
With kind regards, I am,
ceapenainc tain arate rel aa At ta
TT ee See
VY Member of Congress
JHB:mwec
Approved For Release 2004/07/08 : CIA-RDP81M00980R000800080012-3','57e2d65a3d1a7b65649c31f0482df3fe68341468653000bb74e21bed8d708c86','internet-archive','cia-readingroom-document-cia-rdp81m00980r000800080012-3','txt','58a039c8d41af2d2d5a757b93e0507ac5efba591c154be887035ccb0573a3b41','https://archive.org/download/cia-readingroom-document-cia-rdp81m00980r000800080012-3/cia-rdp81m00980r000800080012-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09c435609c971757d8620ff1adee4db43fb02c93bb4fb82f4448cb606dfbacb4',1970,'','','raw',1,'Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
q a
LISTING OF AGENCY UNCLASSIFIED PUBLICATIONS
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
OO
Approved For Release 2008/01/30 : os RDP85M00363R000901960031-7
Directorate of
Intelligence
CIA Publications
Released to the Public
Listing for 1972-81
DI 82-10029
(Supersedes NF 81-10007)
May 1982
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
3 1
This publication is prepared for the use of US Government
officials, and the format, coverage, and content are designed to
meet their specific requirements. US Government officials may
obtain additional copies of this document directly or through
liaison channels from the Central Intelligence Agency.
Requesters outside the US Government may obtain subscriptions to
CIA publications similar to this one by addressing inquiries to:
Document Expediting (DOCEX) Project
Exchange and Gift Division
Library of Congress
Washington, D.C. 20540
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Requesters outside the US Government not interested in subscription
service may purchase specific publications either in paper copy or
microform from:
Photoduplication Service
Library of Congress
Washington, D.C. 20540
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
(To expedite service call the
NTIS Order Desk (703) 487-4650)
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release eo Oee : CIA-RDP85M00363R000901960031-7
Preface Publications of the Central Intelligence Agency are prepared to support US
policymaking officials. However, the Agency releases its unclassified publications
to improve public understanding of key policy issues and to provide additional
research aids to academic and business communities. This program began in 1972
with CIA participation in the Document Expediting (DOCEX) Project of the
Library of Congress. Since that time a large number of unclassified Agency
publications have been distributed through this subscription service. The majority
of these reports concern foreign or international economic and political affairs, or
are directories of foreign officials. Publications have been included in the
Government Printing Office’s Depository Library program since late 1977 and,
beginning in 1979, are also available from the Department of Commerce, National
Technical Information Service (NTIS).
This catalogue, issued annually since 1978, lists Central Intelligence Agency
publications released through DOCEX from 1972 through 1979 and through
NTIS since 1979, It is arranged alphabetically. by country or geographic area with
the titles of the reports in chronological order. The entries for the People’s
Republic of China and the Soviet Union are further subdivided by broad subject
headings; for example, political, economic, and so forth. Reports concerning more
than one country or area are listed in the international section of the catalogue.
Publications issued semiannually or more frequently are listed separately as
serials.
Selected maps and atlases produced by CIA since 1971 are available through the
Superintendent of Documents and are listed in the GPO Monthly Catalog. Maps
produced since 1 January 1982 are available through DOCEX or NTIS.
Publications are not available to the public from the Central Intelligence Agency.
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7','2044ff70e57ef30f3bde8d469b26830f006ff753b8550b43da4740ad15435ab1','internet-archive','cia-readingroom-document-cia-rdp85m00363r000901960031-7','txt','613e1ce7027e4cd49a52e0ab8d3fb032d9b35ce33d77ef8b481f44c08d4ac436','https://archive.org/download/cia-readingroom-document-cia-rdp85m00363r000901960031-7/cia-rdp85m00363r000901960031-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('719ef3b235fd8c83242fba083f97ca5f3472ac3f79499aa9da262726eff43e1f',1970,'AL','Albania','raw',2,'Albanian Worker’s Party,
CR 81-10095, June 1981, wall chart
Government of the People’s Socialist Republic of Albania,
CR 81-10094, June 1981, wall chart
Directory of Officials of the People’s Socialist Republic of Albania,
CR 80-14733, December 1980
Directory of Officials of the People’s Socialist Republic of Albania,
CR 79-12598, May 1979
Directory of Officials of the People’s Socialist Republic of Albania,
CR 77-10848, March 1977
People’s Socialist Republic of Albania: Government and Party Structure,
CR 77-11802, April 1977, wall chart
Directory of Officials of the People’s Republic of Albania,
A (CR) 74-22, June 1974','6b20c76131eb849eae55990531184b870ff5faaf1b50d41214957775e0bc507d','internet-archive','cia-readingroom-document-cia-rdp85m00363r000901960031-7','txt','613e1ce7027e4cd49a52e0ab8d3fb032d9b35ce33d77ef8b481f44c08d4ac436','https://archive.org/download/cia-readingroom-document-cia-rdp85m00363r000901960031-7/cia-rdp85m00363r000901960031-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb087a3da9cfb80da07c6acd315e3226edb302f80d83673aec4d882ba36cde29',1970,'BG','Bulgaria','raw',3,'Directory of Officials of the Bulgarian People’s Republic,
CR 79-10008, January 1979
Bulgarian Communist Party Leadership,
CR 78-15135, November 1978, wall chart
Government of the People’s Republic of Bulgaria,
CR 78-15136, November 1978, wall chart
Bulgarian People’s Republic Government and Party Structure,
CR 76-10051, January 1976, wall chart
Directory of Officials of the Bulgarian People’s Republic,
A (CR) 75-38, September 1975
Directory of Bulgarian Officials,
A 72-5, March 1972
China, People’s Republic of
Geographic
Beijing City Brief,
GS 81-10141, June 1981
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
Approved For Release 2008/01/30 : CIA-RDP85M00363R000901960031-7
y) q
China, People’s Republic of (continued)
A Perspective on the Pinyin
Romanization of Chinese Characters
GS 81-10250, September 1981','1d8abd875b914c93b3d043e07b94fc58a488f0bf8674ca830eedffb4dd1dd10a','internet-archive','cia-readingroom-document-cia-rdp85m00363r000901960031-7','txt','613e1ce7027e4cd49a52e0ab8d3fb032d9b35ce33d77ef8b481f44c08d4ac436','https://archive.org/download/cia-readingroom-document-cia-rdp85m00363r000901960031-7/cia-rdp85m00363r000901960031-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f77755fa56d78e904e9e1ddfe789cb5672a506f8d290e642fa9c7abc549f0c37',1970,'','','raw',1,'25X11
25X11
25X11
25X11
25X11
25X11
25X11
25X11
25X11
Approved For Release 2006/11/21 : CIA-RDP81M00980R002100080071-3
25X11
OFFICE OF LEGISLATIVE COUNSEL
Thursday - 25 May 1978 a
APPL Te s7
1 [ rotasutatson I called Mr. Joseph Sisk,
in the office of Representative Henry S, Reuss (D., i concernin
the Congressman''s most recent inquiry on behalf _ cama
[______|15 May 1978). I explained that the final response t 25X1
was now in the hands of our Office of General Counsel, who are deep 25X1
in FOIA litigation, The General Counsel''s office needs to review it
and the letter should be going out to jn about two weeks,
Mr, Sisk responded that the letter was only a routine check and I
promised I would call him as soon as the letter goes out,
7) on te
25X11
that the meeting set for this afternoon be cancelled and rescheduled for
Tuesday, 30 May at 10:00 a.m, if __—~«ég office, Jim Cline, HC
Staff Director, and Peter Regis, will also attend, This will be a pre-
limi nary discussion of the Subcommittee''s plans to request the Agency
to testify in an executive session hearing on the GAO report of its
war crimes investigation.
25X11
25X1
3. (____________}IAISON Alison Rosenberg and
‘Scott Cohen, on the staff of Senator Charles H. Percy (R., Ml.), visited
Headquarters for a current intelligence briefing on trouble spots in Africa.
[NPAC /oRPa, provided the briefing.
A= LIAISON Helen Mattas, House. International
Relations Committee staff, requested the Agency publications, "Value Added
by Work Brigades in Railroad and Highway Construction in China (1952-1957)"'',
"China: Real Trends in Trade with Non-Community Countries Since 1970",
"China: 1977 Midyear Grain Outlook", and "China Oil Production Prospects."
I callea{_____ NF AC/Css. She said she would assemble the publications
and send them directly to Ms. Mattas. I called Ms. Mattas to advise her.
5. [ie LIAISON Per her request, I sent to
arbara Allem, Subcommittee on Arms Control, Oceans and International
Environment staff, Committee on Foreign Relations, two copies of Arms
Control Subcommittee 22 May transcript.
6. LIAISON Received a call from
Gabe Schoenfeld, in the office of Senator Daniel P. Moynihan (D., N. Yow )3
who requested a copy of the National Basic Intelligence Factbook. I told 25X14
him I would forward a copy #- = Ss gate
Approved For Release 200@/11/21 : CIA-RDP81M00980R002100080071-3
25X1
25X11
25X1
25X11
25X11
Approved For Release 2006 be ae iY O00g0071-3
Journal - Office of Legislative Counsel Page 3
Thursday - 25 May 1978
| (fe? | fest
3fSSS™*~*~é—‘“SCSCS*~*d’SCWLL- ASSN Martti G.. aga,
House Permanent Select Committee on Intelligence staff, called to
advise me that he and Duane P. Andrews, also of the staff, will be
coming out to the Agency at 11;00 a.m, to get their pictures taken for
CIA badges. of our office, advised the badge office
that they would be arriving.
14, Sse LIAISON Herb Romerstein,
House Permanent Select Committee on Intelligence staff, called with
two questions; (1) To ask about the status of the unclassified paper on
KGB utilization of the press, I told Romerstein that the paper was in fairly
final form and would be going up to the DCI to sign off either today or
tommorrow. (2) Romerstein asked if the Agency had any objection to Larry
Sule, House International Relatiéns Committee Minority Staffer and
ing in open session on terrorism..
OGC, I told Romerstein there is no
After checking
Agency problem
15, | LIAISON Called Loch Johnson, House
Permanent Select Commuttee on Intelligence staff, to ask him whether he
knew anything about Representative Les Aspin''s (D., Wis.) statement -
included in the 29 May issue of Time magazine on the general issue of
whether Congress should set up an arbitrator to determine what is or is
not appropriately classified.
“16, [nt atson In response to her request of
yesterday, sent via courier to Mary Dooley, on the staff of the Senate
Judiciary Subcommittee on Criminal Laws and Procedures, a copy of
an article entitled "Scenario for Snooping: Soviets Picking Silicon
Valley Clean'''' from the May 1978 issue of Electronic Warfare - Defense
Electronics.
1%, eee LIAISON Received a call from
Janice O''Connell, Senate Foreign Relations Subcommittee on Foreign
Economic Policy staff, who requested that the Committee be put on
distribution to receive the classified ''''Economic Intelligence Weekly
Review.!'''' I told her I would check and get back to her. I passed the
reque st on the NFAC/CSS,
Approved For Pe ene 1/21 : CIA-RDP81M00980R0021 ier
25X11
25X1
25x11','e46c6a7c3200baa744070efaf9b22a7b71dc54c2d3cbb87d1ffa82aab46df4d6','internet-archive','cia-readingroom-document-cia-rdp81m00980r002100080071-3','txt','a5926da50d3c07bf665a3bb081add00b99a3b19b65928daed8468f89d5d3df7b','https://archive.org/download/cia-readingroom-document-cia-rdp81m00980r002100080071-3/cia-rdp81m00980r002100080071-3_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b410d37e8ff9f20d91be85802fb58819b97abd58314626389bc608d7abd45c6',1970,'','','economy',4,'GNP: $12,016 million (1971), about $330 per capita; 9.2% average annual real
growth 1971
Agriculture: cotton, tobacco, cereals, sugar beets, figs, raisins, silk, olives,
fruits, nuts, opium, and livestock products; self-sufficient in food in
average years
Major industries: textiles, food processing, mining (coal, chromite, copper,
boron minerals), steel, petroleum
Crude steel: .68 million tons produced (1970), 20 kilograms per capita
Electrtc power: 2.6 million kw, capacity (1971); 9,724 million kw.-hr. produced
(1971), 267 kw.-hr. per capita
Exports: $616.5 million (f.0.b., 1971); cotton, tobacco, fruits, nuts, metals,
livestock products
Imports: $1,171 million (c.i.f., 1971); machinery, transport equipment, metals,
mineral fuels, fertilizers, chemicals
Major trade partners: exports -- West Germany 192, U.S. 102, Switzerland 10%,
USSR 5%; imports -- West Germany 18%, U.S. 15%, U.K. 10%, Italy 10%
Aid: $1,602 million assistance disbursed 1963-69 by the Aid of Turkey Consortium
consisting of the U.S., 13 additiona) OECD member countries, the IMF, IBRD,
and European Fund of the EMA; $390.5 million extended by Communist countries
1955-December 1971; none extended in 1971; total U.S. economic, $2,727.9
million (July 1946-Ju : total U.S. military $3,250.2 million
(July 1946-June 1971)
Monetary conversion rate: urkish liras=US$] (official rate)
Fiscal year: 1 March - 28 February','1de57ea31cf866407b6e812547f4485a4e5342ee730fa5f2945b98c2595fcb1c','internet-archive','cia-readingroom-document-06726997','txt','76d9d27af689699d8bc7a1ecbd9198b2812b73ca43290dc0ca20f8a528e04b14','https://archive.org/download/cia-readingroom-document-06726997/06726997_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c91131da4390e2c5089572f5ed7e634a1ffc74e1d4c1e4d527dfce0e9e4c44f',1970,'','','economy',4,'GNP: $45.0 billion (1977), $1,070 per capita; 3.8% real
growth 1977, 7%-8% average annual real growth 1970-76
Agriculture: main products—cotton, tobacco, cereals,
sugar bects, fruits, nuts, and livestock products; self-suffi-
cient in food in average years
Major industries: textiles, food processing, mining (coal,
chromite, copper, boron minerals), steel, petroleum
Crude steel: 1.9 million tons produced (1976), 45 kg per
capita
Electric power: 5,000,000 kW capacity (1977); 22.0
billion kWh produced (1977), 510 kWh per capita
Exports: $2,671 million (£.0.b., 1977); cotton, tobacco,
fruits, nuts, metals, livestock products, textiles and clothing
Imports: $6,999 million (f.0.b., 1977); crude oil, machin-
ery, transport equipment, metals, mineral fuels, fertilizers,
chemicals .
Major trade partners: 22% West Germany, 9% U.S., 9%
Iraq, 7% U.K., 7% Italy (1976)
Aid: economic authorizations: U.S., $512 million (FY70-
77); other Western (ODA and OOF), $1,575 million (1971-
77); Communist, $808 million (1970-77), OPEC, ODA,
$1,553 million (1974-76); military authorizations: U.S.,
$1,289 million (FY70-77)
Budget: (FY77) revenues $11.2 billion, expenditures $12.2
billion, deficit $1.01 billion
Monetary conversion rate: 25.25 Turkish liras=US$1
(July 1978)
Fiscal year: 1 March-28 February','f065ae42814d383b3ed98a795c4b6e29d59c19b97c157830a90148f812c491e6','internet-archive','cia-readingroom-document-06727041','txt','e81594013193fd0f801a852bbb034b76c4bb95d6da2f549c5399458122a300ac','https://archive.org/download/cia-readingroom-document-06727041/06727041_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f7d16e1cb8caa279274a8501c5bfb9904623cb8fac3c829355dd78b455c2863',1970,'','','economy',4,'GNP: $15.9 billion (1972), about $430 per capita; 9.2% average annual real
growth 1971
Agriculture: cotton, tobacco, cereals, sugar beets, figs, raisins, silk, olives,
fruits, nuts, opium, and livestock products; self-sufficient in food in
average years
Major industries: textiles, food processing, mining (coal, chromite, copper,
boron minerals), steel, petroleum
Crude steel: .68 million tons produced (1970), 20 kilograms per capita
Electric power: 2.8 million kw. capacity (1972); 11 billion kw.-hr. produced
(1972), 280 kw.-hr. per capita
Exports: $616.5 million (f.0.b., 1971); cotton, tobacco, fruits, nuts, metals,
livestock products
Imports: $1,171 million (c.i.f., 1971); machinery, transport equipment, metals,
mineral fuels, fertilizers, chemicals
Major trade partners: exports -- West Germany 19%, U.S. 10%, Switzerland 10%,
USSR 5%; imports -- West Germany 18%, U.S. 15%, U.K. 10%, Italy 10%
Aid: $390.5 million extended by Communist countries 1955-December 1971; none
extended in 1971; total U.S. economic, $2,727.9 million (1946-71); total
U.S. military $3,250.2 million (July 1946-June 1971); $603 million in aid
commitments from international tes (1946-71); $657 million in bilateral
aid from other sources 1960-70
Monetary conversion rate: 14 Turkish liras=US$1 (official rate)
Fiscal year: 1 March - 28 February','4c5921c18d539de60f8b6e157cd7b171fa7672f2c9502dc3d789c30404de55ea','internet-archive','cia-readingroom-document-06727039','txt','50b279e699039846ddd2e23926e0f2cdd54ecd6c38a877f833fb7055b1b66e05','https://archive.org/download/cia-readingroom-document-06727039/06727039_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

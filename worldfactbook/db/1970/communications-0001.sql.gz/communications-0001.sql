SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('620af3f9532036c7bee8ddd7fb6e197814c4a0a0bf8cb39b19ccddf4677cb3f5',1970,'','','communications',5,'Ratlroads: 4,991 mi.; 4,940 mi. 4''8 1/2” gage, 5] mi, double track; 45 mi.
electrified; 20 mi. 2''5 1/2" gage
Highways: 37,282 mi.; 13,049 mi. bituminous, 17,398 mi. gravel or crushed stone,
1,553 mi. improved earth, 5,282 mi. unimproved earth
Inland waterways: approx. 1,050 mi.
Pipelines: crude oi], 402 mi.; refined products, 1,277 mi.
Ports: 10 major, 35 minor
Merchant marine: 88 ships (1,000 GRT or over) totaling 596,300 GRT, 829,500 DWT;
includes 12 passenger, 52 cargo, 11 tanker, 11 bulk, 2 specialized carrier
Civil air: 17 major transport aircraft
Airfields: 119 total, 96 usable; 48 with permanent-surface runways; 3 with
runways over 12,000 ft., 18 with runways 8,000-11,999 ft., 25 with runways
4,000-7 ,999 ft.; 2 seaplane stations
Teleconmunications: excellent international radioconmunication and fair domestic
telecommunication services; 577,000 telephones; 3.1 million radio and 50,000
TV receivers; 39 AM, 2 FM, and 7 TV stations; communications satellite ground
station to be operational in 1972 .
DEFENSE FORCES:
Military manpower: males 15-49, 9,585,000; 5,655,000 fit for military service;
about 402,000 reach military age (20) annually
Personnel: army 375,000 navy 39,500, air force 54,600 (1,082 pilots),
gendarmerie 75,000 (S)
Major ground units: 3 armfes, 10 corps with corps troops, 13 infantry divisions,
2 mechanized divisions, 1 mechanized brigade, 1 armored division, 4 separate
armored brigades, 2 armored cavalry brigades, 4 infantry brigades, 2 regiments
(1 border, 1 armored cavalry), 32 battalions (20 artillery, 11 border, 1 on
Cyprus), and 1 commando brigade; army aviation companies with about 5 aircraft
each are assigned to each army, corps, and divisfon
438
Seca
‘Approved for Release: 2018/04/27 C06726997
Approved for Release: 2018/04/27 C06726997
SECRET
DEFENSE FORCES (cont''d):
Ships: 15 destroyers, 1 destroyer escort, 16 submarines, 71 patrol craft, 33
mine warfare, 62 amphibious craft, 38 auxiliary, 47 service
Aircraft: 1,223 including 428 (nonjet) in army aviation, 4 (nonjet) in naval
air, 791 (602 jet) in air force
Missiles: 8 SAM squadrons (Nike Ajax/Hercules)
Supply: mostly dependent on foreign sources, primarfly U.S., Canada, and West
Germany; manufactures some smatl arms, tru adequate quantities of
ammunition; builds some of its naval ships
Military budget: for fiscal year ending 28 February 1973, $599.7 million;
about 19% of central government budget
INTELLIGENCE AND SECURITY:
National Intelligence Organization (MIT), including Turkish National Security
Service Directorate (TNSS), domes tic/foreign; Turkish General Staff, J-2
Section, Intelligence Branch, domestic/foreign; Turkish National Police,
domestic; Ministry of Foreign Affairs, foreign; Gendarmerie, domestic
439
Approved for Release: 2018/04/27 C06726997','c7a3c13800a7f80209df199f4e15cd31ac06b3366a1526781ce16a01816910d3','internet-archive','cia-readingroom-document-06726997','txt','76d9d27af689699d8bc7a1ecbd9198b2812b73ca43290dc0ca20f8a528e04b14','https://archive.org/download/cia-readingroom-document-06726997/06726997_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fad38d63f5103f7672b56a1ff254b73cfbae84b13759c812eaa5a713d8cedb7',1970,'','','communications',5,'Railroads: 8,253 km standard gage (1.435 m); 143 km
double track; 72 km electrified
Highways: 60,000 km total; 21,000 km _ bituminous;
28,000 km gravel or crushed stone; 2,500 km improved
earth, 8,500 km unimproved earth
Inland waterways: approx. 1,689 km
253
Approved for Release: 2018/04/27 C06727041
Approved for Release: 2018/04/27 C06727041
“SECRET.
TURKEY}
January 1979
NR Record
Pipelines: 1,288 km crude oil; 2,055 km refined products
Ports: 10 major, 35 minor
Merchant marine: 162 ships (1,000 GRT or over) totaling
1,206,000 CRT, t,850,600 DWT; includes 14 passenger, 95
cargo, | liquefied gas, 22 tanker, 21 bulk, 7 specialized
carrier, 2. roll-on/roll-off cargo| |
Civil air: 24 major transport aircraft
Airfields: 120 total, 101 usable; 58 with permanent-sur-
face runways, 3 with runways over 3,660 m, 23 with
runways 2,440-3,659 m, 22 with runways 1,220-2.439 mn
Telecommunications: new trunk domestic radio-relay
net, good international service; 1.1 million telephones (2.7
per 100 popl.); 40 AM, 4 FM, and 36 TV stations; | coaxial
submarine cable; COMSAT. station near completion
DEFENSE FORCES
Military manpower: males 15-49, 9,786,000; 5,778,000 fit
for military service; about 430,000 reach military age (20)
annually
Personnel: 480,000 army, 45,400 navy, 53,000 air force
(970 pilots), 100,000 gendarmerie
Major ground units: 4 armies, 10 corps with corps troops,
15 infantry divisions, 2 mechanized divisions, 6 separate
armored brigades, 4 mechanized infantry brigades, 6
infantry brigades, 1 airborne brigade, 1 commando brigade,
3 mobile gendarmerie brigades, 2 regiments (1 infantry, !
armored), 33 battalions (22 artillery, 11 border); each field
army has | aviation regiment assigned und each corps has |
aviation hattalion
Shins: 12 destroyers, 2 Frigates, 13 submarines, 45 patrol
craft, 32 mine warfare, 5 amphibious ships, 74 amphibious
craft, 35 auxiliary, 55 service
Aircraft: 1,159 (464 jet); 647 (464 jet) in air force, 493 in
army aviation, 19 in naval air
Missiles: 8 SAM squadrons (Nike Hercules with 72
launchers)
Supply: mostly dependent on foreign sources, primarily
U.S.. Canada, and West Germany; manufactures some small
arms, trucks and adequate quantities of ammunition; builds
some of its naval ships including submarines with technical
and material assistance
Military budget: for fiscal year ending 28 February 1979,
$2.3 billion; about 20.7% of proposed central government
budget
INTELLIGENCE AND SECURITY
Turkish National Intelligence Organization (TNIO), in-
cluding Turkish National Security Service Directorate
(TNSS), domestic; Foreign Collection Directorate (FCD),
foreign; and Intelligence Directorate, Turkish General Staff
(J-2), domestic/foreign; Turkish National Police, domestic.
Ministry of Foreign Affairs, foreign; Gendarmerie, Intelli-
gence Section, domestic
NR Record
254
Approved for Release: 2018/04/27 C06727041','e15ab1be0a6b6ebcb9aae67d7ddc1e74018cab931be844b350fcf85746186f15','internet-archive','cia-readingroom-document-06727041','txt','e81594013193fd0f801a852bbb034b76c4bb95d6da2f549c5399458122a300ac','https://archive.org/download/cia-readingroom-document-06727041/06727041_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3816143b561022318bb7be1e8f14edc1c095e2f707c9c9f9591f5588e9be55d2',1970,'','','communications',5,'Railroads: 4,991 mi.; 4,940 mi. 4''8 1/2" gage, 51 mi. double track: 45 mi.
electrified; 20 mi. 2''5 1/2" gage
Highways: 37,282 mi.; 13,049 mi. bituminous, 17,398 mi. grave? or crushed stone,
1,553 mi. improved earth, 5,282 mi. unimproved earth
Inland waterways: approx. 1,050 mi.
Pipelines: crude oi], 360 mi.; refined products, 1,340 mi.
Ports: 10 major, 35 minor
Merchant marine: 87 ships (1,000 GRT or over) totaling 594,900 GRT, 826,600 DWT;
includes 12 passenger, 52 cargo, 11 tanker, 10 bulk, 2 specialized carrier
Civil air: 22 major transport aircraft
Airfields: 123 total, 96 usable; 48 with permanent-surface runways; 3 with
runways over 12,000 ft., 19 with runways 8,000-11,999 ft., 22 with runways
4,000-7,999 ft.; 2 seaplane stations
Telecommunications: excellent international radiocommunication and fair domestic
telecommunication services; 654,500 telephones; 3.94 million radio and 133,000
TV receivers; 39 AM, 2 FM, and 7 TV stations
DEFENSE FORCES:
Military manpower: males 15-49, 9,707,000; 5,730,000 fit for military service;
about 402,000 reach military age (20) annual ly
78,000) ee navy 39,500, air force 54,600 (1,082 pilots), gendarmerie
75 ,000
Major ground units: 3 armies, 10 corps with corps troops, 13 infantry divisions,
2 mechanized divisions, 1 mechanized brigade, 1 armored division, 4 separate
armored brigades, 2 armored cavalry brigades, 4 infantry brigades, ] border
regiment, 34 battalions (22 artillery, 11 border, 1 on Cyprus), and 7
airborne/commando brigade; army aviation companies with about 5 aircraft
each are assigned to each army, corps, and division
Ships: 13 destroyers, 12 submarines, 71 patrol » 28 mine warfare, 60
amphibious craft, 40 auxiliary, 47 service
Aircraft: 1,252 including 437 (nonjet) in arny aviation, 15 (nonjet) in naval
air, 800 (605 jet) in air force
Missiles: 8 SAM squadrons (Nike Ajax/Hercules)
Supply: mostly dependent on foreign sources, primarily U.S., Canada, and West
Germany; manufactures some small arms, trucks and adequate quantities of
ammunition; builds some of its naval ships
448
““SECRE
Approved for Release: 2018/04/27 C06727039
Approved for Release: 2018/04/27 C06727039
_ SEsRET,
DEFENSE FORCES (cont''d):
Military budget: for fiscal year ending 28 February 1974, $792.8 million; about
16% of central government budget
INTELLIGENCE AND SECURITY:
National Intelligence Organization (MIT), including Turkish National Security
Service Directorate (TNSS), domestic/foreign; Turkish General Staff, J-2
Section, Intelligence Branch, domestic/foreign; Turkish National Polf
domestic; Ministry of Foreign Affairs, foreign; Gendarmerie, domestic
449
Approved for Release: 2018/04/27 C06727039','9d4a2b2fc51ea58b3df2ca018de5da87ff79463fa05f18e4af69d388d6b68cd4','internet-archive','cia-readingroom-document-06727039','txt','50b279e699039846ddd2e23926e0f2cdd54ecd6c38a877f833fb7055b1b66e05','https://archive.org/download/cia-readingroom-document-06727039/06727039_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

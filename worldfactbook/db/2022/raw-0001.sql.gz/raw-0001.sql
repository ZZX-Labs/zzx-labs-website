SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb21a8a64b4b8d3323aeea91410dc9a8cb7d79a9cd81438dc4d5586b64f54ac8',2022,'','','raw',1,'C ENTRAL Approved for Release: 2022/12/08 C06979333
winact Us
INTELLIGENCE
AGENCY
English
Library
THE WORLD FACTBOOK
La ae APPENDICES | FAQs (../docs/faqs.html) | CONTACT
Ch
THE WORLD FACTBOOK ARCHIVE (/library/publications/download)
North America :: Mexico & (../geos/print_mx.htm))
PAGE LAST UPDATED ON SEPTEMBER 10, 2020
(_/attachments/summaries/MX-summary.pdf)
(../attachments/maps/MX-map.iog.
"sho Tyuanay Vex calli ay?
Erna Ro
UNITED STATES tls
Guif of oa
(../attachmentg
ONE-PAGE|
SUMMARY i..
% opolobampo = —-_Torre6n
Culilacén *
lan
TRAVEL - NORTH
FACTS (../alta - PACIFIC : Aguascatientes, Potosi ‘i ms
‘| Puarto Leén pico
OCEAN . A Vallarta, if ie Querdiard bance
. Guadalaiars MEXICO CITY Grrovere
1 ISAS *” anzanilio” Toluca® ™ ‘3 Veractuz
REVILLAGICEDO . . . Puebla Yolen:
Jumptodepioe27608 FFA5T4G GIRt4G TH LASTP4AS TA7PG7H SPINS THBAAy FEBTA-4599 - /
Approved for Release: 2022/12/08 C06979333
e« Open All
« Close All Approved for Release: 2022/12/08 C06979333
introduction :: Mexico
Background (../docs/notesanddefs.html#325): This entry usually highlights major historic events and current issues and may include a
statement about one or two key future trends.
(_/fields/325.htmi#MX)
The site of several advanced Amerindian civilizations - including the Olmec, Toltec, Teotihuacan, Zapotec, Maya, and Aztec - Mexico
was conquered and colonized by Spain in the early 16th century. Administered as the Viceroyalty of New Spain for three centuries, it
achieved independence early in the 19th century. Elections held in 2000 marked the first time since the 1910 Mexican Revolution that
an opposition candidate - Vicente FOX of the National Action Party (PAN) - defeated the party in government, the Institutional
Revolutionary Party (PRI). He was succeeded in 2006 by another PAN candidate Felipe CALDERON, but Enrique PENA NIETO
regained the presidency for the PRI in 2012. Left-leaning antiestablishment politician and former mayor of Mexico City (2000-05) Andres
Manuel LOPEZ OBRADOR, from the National Regeneration Movement (MORENA), became president in December 2018.
The global financial crisis in late 2008 caused a massive economic downturn in Mexico the following year, although growth returned
quickly in 2010. Ongoing economic and social concerns include low real wages, high underemployment, inequitable income distribution,
and few advancement opportunities for the largely indigenous population in the impoverished southern states. Since 2007, Mexico''s
powerful drug-trafficking organizations have engaged in bloody feuding, resulting in tens of thousands of drug-related homicides.
Geography :: Mexico
Location (../docs/notesanddefs.html#276): This entry identifies the country''s regional location, neighboring countries, and adjacent
bodies of water.
Es
(. fields/276. htmi#Mx)
North America, bordering the Caribbean Sea and the Gulf of Mexico, between Belize and the United States and bordering the North
Pacific Ocean, between Guatemala and the United States
Geographic coordinates (../docs/notesanddefs.html#277): This entry includes rounded latitude and longitude figures for the centroid or
center paint of a country expressed in degrees and minutes; it is based on the locations provided in the Geographic Names Server
(GNS), maintained by the National Geospatial-Intelligence Agency on behaif of the US Board on Geographic Names.
_(..fields/277.htmi#MXx)
23 00 N, 102 00 W
Map references (../docs/notesanddefs.html#278): This entry includes the name of the Factbook reference map on which a country may
be found. Note that boundary representations on these maps are not necessarily authoritative. The entry on Geographic coordinates
ee be helpful in finding some smaller countries.
LEM
(../fields/278.html#MX)
North America
Area (../docs/notesanddefs.html#279): This entry includes three subfields. Total area is the sum of all land and water areas delimited by
international boundaries and/or coastlines. Land area is the aggregate of all surfaces delimited by international boundaries and/or
coastlines, excluding inland water bodies (lakes, reservoirs, rivers). Water area is ‘the sum of the surfaces of all inland water bodies,
such as lakes, reservoirs, or rivers, as delimited by international boundaries and/or coastlines.
(..fields/279.html#MX)
total: 1,964,375 sq km
land: 1,943,945 sq km
water: 20,430 sq km
country comparison to the world: 15 (../fields/279rank.html#MX)
Area - comparative (../docs/notesanddefs.html#280): This entry provides an area comparison based on total area equivalents. Most
entities are compared with the entire US or one of the 50 states based on area measurements (1990 revised) provided by the US
Bureau of the Census. The smaller entities are compared with Washington, DC (178 sq km, 69 sq mi) or The Mall in Washington, DC
(0.59 sq km, 0.23 sq mi, 146 acres).
(./fields/280.htmt#MX)
slighily less than three times the size of Texas
Area eompatieen map:
Land boundaries (../docs/notesanddefs.html#281): This entry contains the total length of all land boundaries and the individual lengths
for each of the contiguous border countries. When available, offi icial lengths published by national statistical agencies are used.
+QPRtTNZAPIAGS TIGAE4IG GtAt4G tH cGStF45 THPAFA PBSS THORPG FASTA-4E 97 /
Approved for Release: 2022/12/08 C06979333
Because surveying methods may differ ~~ ntry border lengths reported by contiguous ¢~""~ies may aier.
Approved for Release: 2022/12/08 C06979333
(. Mields/281 .tml#MX) -
total: 4,389 km
border countries (3): Belize 276 km, Guatemala 958 km, US 3155 km
Coastline (../docs/notesanddefs.html#282): This entry gives the total length of the boundary between the land area (including islands)
and the sea.
(..fields/282.htmi#MX)
9,330 km
Maritime claims (../docs/notesanddefs.htmi#283): This entry includes the following claims, the definitions of which are excerpted from
the United Nations Convention on the Law of the Sea (UNCLOS), which alone contains the full and definitive descriptions: territorial
sea - the sovereignty of a coastal state extends beyond its land territory and internal waters to an adjacent belt of sea, described as the
territorial sea in the UNCLOS (Part Il); this sovereignty extends to the air space over the territorial sea as well as its underlying s. . .
more (../docs/notesanddefs.html#283)
(..ffields/283.html#MX)
territorial sea: 12 nm
exclusive economic zone: 200 nm
contiguous zone: 24 nm
continental shelf: 200 nm or to the edge of the continental margin
Climate (../docs/notesanddefs.html#284): This entry includes a brief description of typical weather regimes throughout the year; in the
Word entry only, it includes four subfields that describe climate extremes:ten driest places on earth (average annual precipitation)
describes the annual average precipitation measured in both millimeters and inches for selected countries with climate extremes. ten
wettest places on earth (average annual precipitation) describes the annual average precipitation measured in both millimeters andi. .
. more (../docs/notesanddefs.html#284)
(../fields/284.html#MX) :
varies from tropical to desert
Terrain (../docs/notesanddefs.html#285): This entry contains a brief description of the topography.
(../fields/285.htmi#MX)
high, rugged mountains; low coastal plains; high plateaus; desert
Elevation (../docs/notesanddefs.html#407): This entry includes the mean elevation and elevation extremes, lowest point and highest
point.
(..fields/407.htmi#MX)
mean elevation: 1,111 m
lowest point: Laguna Salada -10 m
highest point: Volcan Pico de Orizaba 5,636 m
Natural resources (../docs/notesanddefs.html#287): This entry lists a country''s mineral, petroleum, hydropower, and other resources of
commercial importance, such as rare earth elements (REEs). In general, products appear only if they make a significant contribution to
the economy, or are likely to do so in the future.
(..fields/287 htmi#MX)
petroleum, silver, antimony, copper, gold, lead, zinc, natural gas, timber
Land use (../docs/notesanddefs. html#288): This entry contains the percentage shares of total land area for three different types of land
use: agricultural land, forest, and other; agricultural land is further divided into arable land - land cultivated for crops like wheat, maize,
and rice that are replanted after each harvest, permanent crops - land cultivated for crops like citrus, coffee, and rubber that are not
replanted after each harvest, and includes land under flowering shrubs, fruit trees, nut trees, and vines, and permane . . . more
(..docs/notesanddefs.htmi#288)
(..fields/288.html#MX)
agricultural land: 54.9% (2011 est.) :
arable land: 11.8% (2011 est.) / permanent crops: 1.4% (2011 est.) / permanent pasture: 41.7% (2011 est.)
forest: 33.3% (2011 est.)
other: 11.8% (2011 est.)
irrigated land (../docs/notesanddefs.htmi#289): This entry gives the number of square kilometers of land area that is artificially supplied
with water.
(../fields/289.htmi#MX)
65,000 sq km (2012)
Population distribution (../docs/notesanddefs.html#348): This entry provides a summary description of the population dispersion within
a country. While it may suggest population density, it does not provide density figures.
(_ifields/348.htmi#MX)
most of the population is found in the middle of the country between the states of Jalisco and Veracruz; approximately a quarter of the
populgtiqntivesinand@round Mexico Gilet 4 46 cAREF4S FAPO7AR PHAR THBRPG FERRARA TF /
Approved for Release: 2022/12/08 C06979333
Natural hazards (../docs/notesanddets *''-''"zyz): Inis entry lists potential natural aisarr~"~ ~or Counties where vuIuariG avuviy io
common, a voleanism subfield highligt = Approved for Release: 2022/12/08 C06979333
le
(~Hfields/292.htmi#MX)
tsunamis along the Pacific coast, volcanoes and destructive earthquakes .in the center and south, and hurricanes on the Pacific, Gulf of
Mexico, and Caribbean coasts
volcanism: volcanic activity in the central-southern part of the country; the volcanoes in Baja California are mostly dormant; Colima
(3,850 m), which erupted in 2010, is Mexico''s most active volcano and is responsible for causing periodic evacuations of nearby
villagers; it has been deemed a Decade Volcano by the International Association of Volcanology and Chemistry of the Earth''s Interior,
worthy of:study due to its explosive history and close proximity to human populations; Popocatepetl (5,426 m) poses a threat to Mexico
City; other historically active volcanoes include Barcena, Ceboruco, El Chichon, Michoacan-Guanajuato, Pico de Orizaba, San Martin,
Socorro, and Tacana; see note 2 under "Geography - note"
Environment - current issues (../docs/notesanddefs.html#293): This entry lists the most pressing and important environmental
problems. The following terms and abbreviations are used throughout the entry: Acidification - the lowering of soil and water pH due to
acid precipitation and deposition usually through precipitation; this process disrupts ecosystem nutrient flows and may kill freshwater
fish and plants dependent on more neutral or alkaline conditions (see acid rain). Acid rain - characterized as containing harmful levels
of sulfur dioxi . .. more (../docs/notesanddefs.html#293) :
(..fields/293.htmi#MX)
scarcity of hazardous waste disposal facilities; rural to urban migration; natural freshwater resources scarce and polluted in north,
inaccessible and poor quality in center and extreme southeast; raw sewage and industrial effluents polluting rivers in urban areas;
deforestation; widespread erosion; desertification; deteriorating agricultural lands; serious air and water pollution in the national capital
and urban centers along US-Mexico border; land subsidence in Valley of Mexico caused by groundwater depletion
note: the government considers the lack of clean water and deforestation national security issues
Environment - international agreements (,./docs/notesanddefs.html#294): This entry separates country participation in international
environmental agreements into two levels - party to and signed, but not ratified. Agreements are listed in alphabetical order by the
abbreviated form of the full name.
(..ields/294.html#MX)
party to: Biodiversity, Climate Change, Climate Change-Kyoto Protocol, Desertification, Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Dumping, Marine Life Conservation, Ozone Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected agreements
Geography - note (../docs/notesanddefs.himl#295): This entry includes miscellaneous geographic information of significance not
included elsewhere.
(..ields/295.html#MX)
note 1: strategic location on southern border of the US; Mexico is one of the countries along the Ring of Fire, a belt of active volcanoes
and earthquake epicenters bordering the Pacific Ocean; up to 90% of the world’s earthquakes and some 75% of the world''s volcanoes
occur within the Ring of Fire
note 2: the "Three Sisters” companion plants - winter squash, maize (corn), and climbing beans - served as the main agricultural crops
for various North American Indian groups; all three apparently originated in Mexico but then were widely disseminated through much of
North America; vanilla,.the world''s most popular aroma and flavor spice, also emanates from Mexico
note 3: the Sac Actun cave system at 348 km (216 mi) is the longest underwater cave in the world and the second longest cave
worldwide, after Mammoth Cave in the United States (see "Geography - note" under United States)
note 4: the prominent Yucatan Peninsula that divides the Gulf of Mexico from the Caribbean Sea is shared by Mexico, Guatemala, and
Belize; just on the northern coast of Yucatan, near the town of Chicxulub (pronounce cheek-sha-loob), lie the remnants of a massive
crater (some 150 km in diameter and extending well out into the Gulf of Mexico); formed by an asteroid or comet when it struck the earth
66 million years ago, the impact is now widely accepted as initiating a worldwide climate disruption that caused a mass extinction of
75% of all the earth''s plant and animal species - including the non-avian dinosaurs
People and Society :: Mexico
Population (../docs/notesanddefs.html#335): This entry gives an estimate from the US Bureau of the Census based on statistics from
population censuses, vital statistics registration systems, or sample surveys pertaining to the recent past and on assumptions about
future trends. The total population presents one overall measure of the potential impact of the country on the world and within its
region. Note: Starting with the 1993 Factbook, demographic estimates for some countries (mostly African) have explicitly taken into
account t...more (./docs/notesanddefs.himi#335) ;
(..fields/335.html#MX)
128,649,565 (July 2020 est.)
country comparison.to the world: 10 /fields/335rank him: + ace 222 168526 TEBTA-459F |
&
Approved for Release: 2022/12/08 C06979333
Nationality (../decs/notesanddefs.htmi#22** This entry provides the identifying terms fe~ ~"~ens - noun and adjective.
ee Approved for Release: 2022/12/08 C06979333
(../fields/336.htmi#MX) : -
noun: Mexican(s)
adjective: Mexican
Ethnic groups (../docs/notesanddefs.hitml#400): This entry provides an ordered listing of ethnic groups starting with the largest and
normally includes the percent of total population.
( fi elds/400.htmi#MX)
mestizo (Amerindian-Spanish) 62%, predominantly Amerindian 21%, Amerindian 7%, other 10% (mostly European) (2012 est. )
. note: Mexico does not collect census data on ethnicity
Languages (../docs/notesanddefs.html#402): This entry provides a listing of languages spoken in each country and specifies any that
are official national or regional languages. When data is available, the languages spoken in each country are broken down according to
the percent of the total population speaking each language as a first language. For those countries without available data, languages
are listed in rank order based on prevalence, starting with the most-spoken language.
(. /fields/402. htmi#MX)
Spanish only 92.7%, Spanish and indigenous languages 5.7%, indigenous only 0. 8%, unspecified 0.8% (2005)
note: indigenous languages include various Mayan, Nahuatl, and other regional ianadauee
Religions (../docs/notesanddefs.htm!#401): This entry is an ordered listing of religions by adherents starting with the largest group and
sometimes includes the percent of total population. The core characteristics and beliefs of the world''s major religions are described
below. Baha''i - Founded by Mirza Husayn-Ali (known as Baha''u''llah) in Iran in 1852, Baha''i faith emphasizes monotheism and believes
in one eternal transcendent God. Its guiding focus is to encourage the unity of all peoples on the earth so that justice and peacem...
more (../docs/notesanddefs.html#401)
(..fields/401 .htmi#MX)
Roman Catholic 82.7%, Pentecostal 1.6%, Jehovah''s Witness 1.4%, other Evangelical Churches 5%, other 1.9%, none 4.7%,
unspecified 2.7% (2010 est.)
Age structure (../docs/notesanddefs.html#341): This entry provides the distribution of the population according to age. Information is
included by sex and age group as follows: 0-14 years (children), 15-24 years (early working age), 25-54 years (prime working age), 55-
64 years (mature working age), 65 years and over (elderly). The age structure of a population affects a nation’s key socioeconomic
issues. Countries with young populations (high percentage under age 15) need to invest more in schools, while countries with older
population . . . more (../docs/notesanddefs.html#341)
ey)
(..fields/341 .ntmi#MX)
0-14 years; 26.01% (male 17,111,199/female 16,349,767)
15-24 years: 16.97% (male 11,069,260/female 10,762,784)
25-54 years: 41.06% (male 25,604,223/female 27,223,720)
55-64 years: 8.29% (male 4,879,048/female 5,784,176)
65 years and over: 7.67% (male 4,373,807/female 5,491,581) (2020 est.)
population pyramid:
a
Dependency ratios (../docs/notesanddefs.htmi#342): Dependency ratios are a measure of the age structure of a population. They
relate the number of individuals that are likely to be economically "dependent" on the support of others. Dependency ratios contrast the
ratio of youths (ages 0-14) and the elderly (ages 65+) to the number of those in the working-age group (ages 15-64). Changes in the
dependency ratio provide an indication of potential social support requirements resulting from changes in population age structures. As
fertility leve .. . more (../docs/notesanddefs.html#342)
+
(..fields/342.html#MX)
total dependency ratio: 50.3
youth dependency ratio: 38.8
elderly dependency ratio: 11.4
potential support ratio: 8.7 (2020 est.)
Median age (../docs/notesanddefs.html#343): This entry is the age that divides a population into two numerically equal groups; that is,
half the people are younger than this age and half are older. It is a single index that summarizes the age distribution of a population.
Currently, the median age ranges from a low of about 15 in Niger and Uganda to 40 or more in several European countries and Japan.
See the entry for "Age structure” for the importance of a young versus an older age structure and, by implication, a low versus a high ..
. more (../docs/notesanddefs.html#343)
( ifields/343.htmi#MxX) .
total 29S MAS tag TFO514R Ltd 16 iG2tF45 FOOHPe 286052 THASIH TEATA-4594 /
Approved for Release: 2022/12/08 C06979333
male: 28.2 years
female: 30.4 years (2020 est.) - Approved for Release: 2022/12/08 C06979333
country comparison to the world: 132 (..1000u3/343rank.himl#MX)
Population growth rate (../docs/notesanddefs.htmi#344): The average annual percent change in the population, resulting from a surplus
(or deficit) of births over deaths and the balance of migrants entering and leaving a country. The rate may be positive or negative. The
growth rate is a factor in determining how great a burden would be imposed on a country by the changing needs of its people for
infrastructure (e.g., schools, hospitals, housing, roads), resources (e.g., food, water, electricity), and jobs. Rapid population growth can
be seen as .. . more (../docs/notesanddefs.html#344)
(_.fields/344.htmi#MX)
1.04% (2020 est.)
country comparison to the world: 102 (../fields/344rank.html#MX)
Birth rate (../docs/notesanddefs.html#345): This entry gives the average annual number of births during a year per 1,000 persons in the
population at midyear; also known as crude birth rate. The birth rate is usually the dominant factor in determining the rate of population
growth. it depends on both the level of fertility and the age structure of the population.
(..Aields/345.htmi#MX)
17.6 births/1,000 population (2020 est.)
country comparison to the world: 95 (../fields/345rank.html#MX)
Death rate (../docs/notesanddefs.html#346): This entry gives the average annual number of deaths during a year per 1,000 population
at midyear; also known as crude death rate. The death rate, while only a rough indicator of the mortality situation in a country,
accurately indicates the current mortality impact on population growth. This indicator is significantly affected by age distribution, and
most countries will eventually show a rise in the overall death rate, in spite of continued decline in mortality at all ages, as declining...
more (../docs/notesanddefs.htmi#346)
es
(../fields/346.htmi#MX)
5.4 deaths/1,000 population (2020 est.) :
country comparison to the world: 186 (../fields/346rank.htmil#MX)
Net migration rate (../docs/notesanddefs.html#347): This entry includes the figure for the difference between the number of persons
entering and leaving a country during the year per 1,000 persons (based on midyear population). An excess of persons entering the
country is referred to as net immigration (e.g., 3.56 migrants/1,000 population); an excess of persons leaving the country as net
emigration (e.g., -9.26 migrants/1,000 population). The net migration rate indicates the contribution of migration to the overall level of
population chan . . . more (../docs/notesanddefs.html#347)
(../fields/347.htmi#MX)
1.9 migrant(s)/1,000 population (2020 est.)
‘country comparison to the world: 166 (../fields/347rank.html#MX)
Population distribution (../docs/notesanddefs.html#348): This entry provides a summary description of the population dispersion within
a country. While it may suggest population density, it does not provide density figures.
(../fields/348.html#fMX)
most of the population is found in the middle of the country between the states of Jalisco and Veracruz; approximately a quarter of the
population lives in and around Mexico City
Urbanization (../docs/notesanddefs.html#349): This entry provides two measures of the degree of urbanization of a population. The
first, urban population, describes the percentage of the total population fiving in urban areas, as defined by the country. The second,
rate of urbanization, describes the projected average rate of change of the size of the urban population over the given period of time. It
is possible for a country with a 100% urban population to still display a change in the rate of urbanization (up or down). For example . .
. more (../docs/notesanddefs.html#349)
(es
(..fields/349.html#MX)
urban population: 80.7% of total population (2020)
rate of urbanization: 1.59% annual rate of change (2015-20 est.)
Major urban areas - population (../docs/notesanddefs.html#350): This entry provides the population of the capital and up to six major
cities defined as urban agglomerations with populations of at least 750,000 people. An urban agglomeration is defined as comprising
the city or town proper and also the suburban fringe or thickly settled territory lying outside of, but adjacent to, the boundaries of the
city. For smaller countries, lacking urban centers of 750,000 or more, only the population of the capital is presented.
(..{fields/350.html#MX)
21.782 million MEXICO CITY (capital), 5.179 million Guadalajara, 4.874 million','f95d816b46624aa413e4e9ba72cf19257cae722ba9b873b2d5792b6bccc75dc4','internet-archive','cia-readingroom-document-06979333','txt','984e0c045c9a468f2ff29ce97e446d2422bc468407fa988a05f7b591d54893f9','https://archive.org/download/cia-readingroom-document-06979333/06979333_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('187bbc8f1c0c8912d9f0f96d8a5e7a856e9498f7829a18d4b601eccfb8bc558c',2022,'','','raw',2,'Monterrey, 3.195 million Puebla, 2.467 million Toluca de
Lerdo, 2.140 million Tijuana (2020)
Sex ratio (../docs/notesanddefs.htmi#351): This entry includes the number of males for each female in five age groups - at birth, under
15 years, 15-64 years, 65 years and over, and for the total population. Sex ratio at birth has recently emerged as an indicator of certain
kinds of sex discrimination in some countries. For instance, high sex ratios at birth in some Asian countries are now attributed to sex-
selective abortion and infanticide due to a strong preference for sons. This will affect future marriage patterns and fertilit .. . more
(../docs/notesanddefs.htmi#351) .
(../fields/351 .htmi#MX) oa
at birfh> iOS Tala(SitemaleFGSt 4H ORISA TH ARPES THAIS PERS PABST FEST A-F45 FF /
Approved for Release: 2022/12/08 C06979333
0-14 years: 1.05 male(s)/female im.
15-24 years: 1.03 male(s)/female ‘ Approved for Release: 2022/12/08 C06979333
25-54 years: 0.94 male(s)/female ail
55-64 years: 0.84 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 0.96 male(s)/female (2020 est.)
Mother''s mean age at first birth (../docs/notesanddefs.html#352): This entry provides the mean (average) age of mothers at the birth of
their first child. It is a useful indicator for gauging the success of family planning programs aiming to reduce maternal mortality, increase
contraceptive use — particularly among married and unmarried adolescents — delay age at first marriage, and improve the health of
newborns.
(.Mields/352.htmi#MX)
21.3 years (2008 est.)
Maternal mortality rate (../docs/notesanddefs.htmi#353): The maternal mortality rate (MMR) is the annual number of female deaths per
100,000 live births from any cause related to or aggravated by pregnancy or its management (excluding accidental or incidental
causes). The MMR includes deaths during pregnancy, childbirth, or within 42 days of termination of pregnancy, irrespective of the
duration and site of the pregnancy, for a specified year.
(..ields/353.html#MX)
33 deaths/100,000 live births (2017 est.)
country comparison to the world: 108 (../fields/353rank.html#MX)
Infant mortality rate (../docs/notesanddefs.html#354): This entry gives the number of deaths of infants under one year old in a given
i per 1,000 live births in the same year. This rate is often used as an indicator of the level of health in a country.
Es
(..fields/354,.htmi#MX)
total: 10.7 deaths/1,000 live births
male: 12 deaths/1,000 live births
female: 9.2 deaths/1,000 live births (2020 est.)
country comparison to the world: 127 (../fields/354rank.html#MX)
Life expectancy at birth (../docs/notesanddefs.html#355): This entry contains the average number of years to be lived by a group of
people born in the same year, if mortality at each age remains constant in the future. Life expectancy at birth is also a measure of
overall quality of life in a country and summarizes the mortality at all ages. It can also be thought of as indicating the potential return on
investment in human capital and is necessary for the calculation of various actuarial measures.
(../fields/355.html#MX)
total population: 76.7 years
male: 73.9 years
female: 79.6 years (2020 est.)
country comparison to the world: 94 (../fields/355rank.himl#MX) :
Total fertility rate (..;docs/notesanddefs.html#356): This entry gives a figure for the average number of children that would be born per
woman if all women lived to the end of their childbearing years and bore children according to a given fertility rate at each age. The
total fertility rate (TFR) is a more direct measure of the level of fertility than the crude birth rate, since it refers to births per woman. This
indicator shows the potential for population change in the country. A rate of two children per woman is considered the replaceme ...
more (../docs/notesanddefs.html#356)
es
(..Aields/356.htmi#MX)
2.19 children born/woman (2020 est.) ;
country comparison to the world: 94 (../fields/356rank.htmi#MX)
Contraceptive prevalence rate (../docs/notesanddefs.html#357): This field gives the percent of women of reproductive age (15-49) who
are married or in union and are using, or whose sexual partner is using, a method of contraception according to the date of the most
recent available data. The contraceptive prevalence rate is an indicator of health services, development, and women’s empowerment.
it is also useful in understanding, past, present, and future fertility trends, especially in developing countries.
By,
(../fields/357.html#MX)
66.9% (2015)
Drinking water source (../docs/notesanddefs.html#361): This entry provides information about access to improved or unimproved
- drinking water sources available to segments of the population of a country. Improved drinking water ~ use of any of the following
sources: piped water into dwelling, yard, or plot; public tap or standpipe; tubewell or borehole; protected dug well; protected spring; or
rainwater collection. Unimproved drinking water - use of any of the following sources: unprotected dug well; unprotected spring; cart
with small tank or... more (../docs/notesanddefs.html#361)°
(..ffields/361.himl#MX)
improved: urban; 100% of population
rural: 96.6% of population
total: 100% of population :
unimproved: urban: 0% of population
rural: 3.4% of population : : :
total: O%Adf DEAMISHOAU20 11798 4G GERI 4H te iGAt7As TEPAPE FA: F2 T8G57R FRBTA-A5 9% fh
Approved for Release: 2022/12/08 C06979333
Current Health Expenditure (../docs/not----ddefs.himl#409): Current Health Expenditur~ ‘“4E) describes the share of spending on
health in each country relative to the si) Approved for Release: 2022/12/08 C06979333ing to the final consumption of health
care goods and services and excludes ....<stment, exports, and intermediate consumptiun. CHE shows the importance of the health
sector in the economy and indicates the priority given to health in monetary terms. Note: Current Health Expenditure replaces the
former Health Expenditures field .. . more (../docs/notesanddefs.html#409)
(..fields/409,html#MX)
5.5% (2017)
Physicians density (../docs/notesanddefs.html#3§9): This entry gives the number of medical doctors (physicians), including generalist
and specialist medical practitioners, per 1,000 of the population. Medical doctors are defined as doctors that study, diagnose, treat, and
prevent illness, disease, injury, and other physical and mental impairments in humans through the application of modern medicine.
They also plan, epee and evaluate care and treatment plans by other health care providers. The World Health Organization
estimates that f.. . more (../docs/notesanddefs.html#359)
(iields/389. html#MX)
2.38 physicians/1,000 population (2017)
Hospital bed density (../docs/notesanddefs.html#360): This entry provides the number of hospital beds per 1,000 people; it serves as a
general measure of inpatient service availability. Hospital beds include inpatient beds available in public, private, general, and
specialized hospitals and rehabilitation centers. In most cases, beds for both acute and chronic care are included. Because the level of
inpatient services required for individual countries depends on several factors - such as demographic issues and the burden of disease
~ there is... more (../docs/notesanddefs.html#360)
(..fields/360.htmi#MX)
1.5 beds/1,000 population (2015)
Sanitation facility access (../docs/notesanddefs.htmi#398): This entry provides information about access to improved or unimproved
sanitation facilities available to segments of the population of a country. Improved sanitation - use of any of the following facilities: flush
or pour-flush to a piped sewer system, septic tank or pit latrine; ventilated improved pit (VIP) latrine; pit latrine with slab; or a
composting toilet. Unimproved sanitation - use of any of the following facilities: flush or pour-flush not piped to a sewer system, septic
tank... more (../docs/notesanddefs.htmi#398)
Oe ca nas
improved: urban: 99.3% of population
rural: 91.9% of population
total: 97.8% of population
unimproved: urban: 0.7% of population
rural: 8.1% of population
-total: 2.2% of population (2017 est.)
HIV/AIDS - adult prevalence rate (. /docs/notesanddefs. html#363): This entry gives an estimate of the percentage of adults (aged 15-
49) living with HIV/AIDS. The adult prevalence rate is calculated by dividing the estimated number of adults living with HIV/AIDS at
yearend by the total adult population at yearend.
(..Mields/363.html#MX)
0.2% (2018 est.)
country comparison to the world: 107 (../fields/363rank.html#MXx)
HIV/AIDS - people living with HIV/AIDS (../docs/notesanddefs.html#364): This entry gives an estimate of all peopie (adults and
children) alive at yearend with HIV infection, whether or not they have developed symptoms of AIDS.
(../fields/364.html#MX)
230,000 (2018 est.)
country comparison to the world: 25 (../fields/364rank.html#MX)
HIV/AIDS - deaths (../docs/notesanddefs.html#365): This entry gives an estimate of the number of adults and children who died of
AIDS during a given calendar year.
Ci elds/365.htmi#MX)
4,000 (2017 est.)
country comparison to the world: 32 (../fields/365rank.html#MX)
Major infectious diseases (../docs/notesanddefs.html#366): This entry lists major infectious diseases likely to be encountered in
countries where the risk of such diseases is assessed to be very high as compared to the United States. These infectious diseases
represent risks to US government personnel traveling to the specified country for a period of less than three years. The degree of risk
is assessed by considering the foreign nature of these infectious diseases, their severity, and the probability of being affected by the
_ diseases present. Th... more (../docs/notesanddefs.html#366)
i
(../fields/366.html#MX)
degree of risk: intermediate (2020)
food or waterborne diseases: bacterial diarrhea and hepatitis A
vectorborne diseases: dengue fever
note: a new coronavirus is causing sustained community spread of respiratory iliness (COVID-19) in Mexico; sustained community
spreacsmearSahatinddple havitiekh itfegted with thevidé, BEnhCMaAMErS they Beda iMfecléd’td Aatkagwn, and the spreadis /
Approved for Release: 2022/12/08 C06979333
ongoing; illness with this virus has range~ *~m mild to severe with fatalities reported; as ~*~ “ugust 2U2U, Mexico nas reported 445,015
confirmed cases of COVID19 with 48,01. Approved for Release: 2022/12/08 C06979333
Obesity - adult prevalence rate (../docs,,...sanddefs.htmi#367): This entry gives the pé.cci. of a country''s population considered to be
obese. Obesity is defined as an adult having a Body Mass Index (BMI) greater to or equal to 30.0. BMI is calculated by taking a
person''s weight in kg and dividing it by the person''s squared height in meters. P
(..Aields/367.html#MX)
28.9% (2016)
country comparison to the world: 29 (../fields/367 rank.html#MX)
Children under the age of § years underweight (../docs/notesanddefs.html#368): This entry gives the percent of children under five
considered to be underweight. Underweight means weight-for-age is approximately 2 kg below for standard at age one, 3 kg below
standard for ages two and three, and 4 kg below standard for ages four and five. This statistic is an indicator of the nutritional status of
a community, Children who suffer from growth retardation as a result of poor diets and/or recurrent infections tend to have a greater
risk. of suffering illness and death.
fe}
(..ffields/368.htmi#MX)
4.2% (2016)
country comparison to the world: 87 (../fields/368rank.htmi#MX)
Education expenditures (../docs/notesanddefs.html#369): This entry provides the public expenditure on education as a percent of GDP.
(../fields/369.htmnl#MX)
4.9% of GDP (2016) :
country comparison to the world: 66 (../fields/369rank.htmi#MX)
Literacy (../docs/notesanddefs.html#370): This entry includes a definition of literacy and UNESCO''s percentage estimates for
populations aged 15 years and over, including total population, males, and females. There are no universal definitions and standards of
literacy. Unless otherwise specified, all rates are based on the most common definition - the ability to read and write at a specified age.
Detailing the standards that individual countries use to assess the ability to read and write is beyond the scope of the Factbook. Info . .
. more (../docs/notesanddefs.html#370)
(..fields/370.htmi#MX)
definition: age 15 and over can read and write
total population: 95.4%
male: 95.8%
female: 94.6% (2018) . .
School life expectancy (primary to tertiary education) (../docs/notesanddefs.html#371): School life expectancy (SLE) is the total number
of years of schooling (primary to tertiary) that a child can expect to receive, assuming that the probability of his or her being enrolled in
schoo! at any particular future age is equal to the current enrollment ratio at that age. Caution must be maintained when utilizing this
indicator in international comparisons. For example, a year or grade completed in one country is not necessarily the same in terms of
educational content or qualit .. . more (../docs/notesanddefs.html#37 1)
eee
total: 14 years
male: 14 years
female: 14 years (2016)
Unemployment, youth ages 15-24 (../docs/notesanddefs.html#373): This entry gives the percent of the total labor force ages 15-24
unemployed during a specified year.
(../fields/373.html#MX)
total: 6.9%
male: 6.5%
female: 7.6% (2018 est.)
country comparison to the world: 152 (../fields/373rank.html#MX)
Government :: Mexico ;
Country name (../docs/notesanddefs.htmi#296): This entry includes all forms of the country''s name approved by the US Board on
Geographic Names (Italy is used as an example): conventional long form (Italian Republic), conventional short form (Italy), local long
form (Repubblica Italiana), local short form (Italia), former (Kingdom of Italy), as well as the abbreviation. Also see the Terminology
note.
Es
(..fields/296.html#MX)
conventional long form: United Mexican States
conventional short form: Mexico
local long form: Estados Unidos Mexicanos
local short form: Mexico ; .
etymology: named after the capital city, whose name stems from the Mexica, the largest and most powerful branch of the Aztecs; the
meaning of the name is uncertain
Government type (../docs/notesanddefs.html#299): This entry gives the basic form of government. Definitions of the major
governmental terms are as follows. (Note that for some countries more than one definition applies. ): Absolute monarchy - a form of
vernmental terms are aS follows, (Note a Or Same CONES TOS AE Dasee VeMe Tao ta tas
Approved for Release: 2022/12/08 C06979333
government where the monarch rules u~*''~dered, i.e., without any laws, constitution, or ''~~-"y organized opposition. Anarcny - a
condition of lawlessness or political dig Approved for Release: 2022/12/08 C0697933300rity. Authoritarian - a form of
government in whic . . . more (../docs/nucoanddefs.html#299)
(../flelds/299.html#MX)
federal presidential republic :
Capital (../docs/notesanddefs.htmi#301): This entry gives the name of the seat of government, its geographic coordinates, the time
difference relative to Coordinated Universal Time (UTC) and the time observed in Washington, DC, and, if applicable, information on
daylight saving time (DST). Where appropriate, a special note has been added to highlight those countries that have multiple time
zones.
(..ields/301 .html#MX)
name: Mexico City (Ciudad de Mexico)
geographic coordinates: 19 26 N, 99 08 W
time difference: UTC-6 (1 hour behind Washington, DC, during Standard Time)
daylight saving time: +1hr, begins first Sunday in April; ends last Sunday in October
note: Mexico has four time zones
etymology: named after the Mexica, the largest and most powerful branch of the Aztecs; the meaning of the name is uncertain
Administrative divisions (../docs/notesanddefs.html#302): This entry generally gives the numbers, designatory terms, and first-order
administrative divisions as approved by the US Board on Geographic Names (BGN). Changes that have been reported but not yet
acted on by the BGN are noted. Geographic names conform to spellings approved by the BGN with the exception of the omission of
diacritical marks and special characters.
(..fields/302.html#MX)
32 states (estados, singular - estado); Aguascalientes, Baja California, Baja California Sur, Campeche, Chiapas, Chihuahua, Coahuila,
Colima, Cuidad de Mexico, Durango, Guanajuato, Guerrero, Hidalgo, Jalisco, Mexico, Michoacan, Morelos, Nayarit, Nuevo Leon,
Oaxaca, Puebla, Queretaro, Quintana Roo, San Luis Potosi, Sinaloa, Sonora, Tabasco, Tamaulipas, Tlaxcala, Veracruz, Yucatan,
Zacatecas
Independence (../docs/notesanddefs.html#305): For most countries, this entry gives the date that sovereignty was achieved and from
which nation, empire, or trusteeship. For the other countries, the date given may not represent "independence" in the strict sense, but
rather some significant nationhood event such as the traditional founding date or the date of unification, federation, confederation,
establishment, fundamental change in the form of government, or state succession. For a number of countries, the establishment of
statehood . .. more (../docs/notesanddefs.html#305)
(..ields/305.html#MX)
16 September 1810 (declared independence from Spain); 27 September 1821 (recognized by Spain)
= holiday (../docs/notesanddefs.htmi#306): This entry gives the primary national day of celebration - usually independence day.
(FE,
(../fields/306.html#MX)
independence Day, 16 September (1810)
Constitution (../docs/notesanddefs.html#307): This entry provides information on a country''s constitution and’includes two subfields.
The history subfield includes the dates of previous constitutions and the main steps and dates in formulating and implementing the
latest constitution. For countries with 1-3 previous constitutions, the years are listed; for those with 4-9 previous, the entry is fisted as
“several previous,” and for those with 10 or more, the entry is “many previous.” The amendments subfield summarizes the process of
am... more (../docs/notesanddefs.html#307)
fe
(../fields/307.hitmi#MX)
history: several previous; latest approved 5 February 1917
amendments: proposed by the Congress of the Union; passage requires approval by at least two thirds of the members present and
approval by a majority of the state legislatures; amended many times, last in 2020 :
Legal system (../docs/notesanddefs.html#308): This entry provides the description of a country''s legal system. A statement on judicial
review of legislative acts is also included for a number of countries. The legal systems of nearly all countries are generally modeled
upon elements of five main types: civil law (including French law, the Napoleonic Code, Roman law, Roman-Dutch law, and. Spanish
law); common law (including United State law); customary law; mixed or pluralistic law; and religious law (including islamic law). An
addition . . . more (../docs/notesanddefs.html#308)
ES
(../fields/308.html#MX)
civil law system with US constitutional law influence; judicial review of legislative acts
international law organization participation (../docs/notesanddefs.html#309): This entry includes information on a country''s acceptance
of jurisdiction of the International Court of Justice (ICJ) and of the International Criminal Court (ICCt); 59 countries have accepted ICJ
jurisdiction with reservations and 11 have accepted ICJ jurisdiction without reservations; 122 countries have accepted ICCt jurisdiction.
Appendix B: International Organizations and Groups explains the differing mandates of the ICJ and ICCt.
(..fields/309.htmi#MX)
accepts compulsory LC.) jursdiction with reservations, agcepts4eChinvedigiona 5% TAOR7H TRATA-45 94 ''
Approved for Release: 2022/12/08 C06979333
Citizenship (../docs/notesanddefs.htmi#?*™: This entry provides information related to thagacquisition and exercise of citizenship; it
includes four subfields: citizenship by bh Approved for Release: 2022/12/08 C06979333}lace of birth, known as Jus soli,
regardless of the citizenship of parents. uu.enship by descent only describes the acquisition of citizenship based on the sea of
Jus sanguinis, or by descent, where at least one parent is a citizen of the state and being born within the territorial limits of the s .
more (../docs/notesanddefs. html#310)
( ffields/310.htmi#MX)
citizenship by birth: yes
citizenship by descent only: yes
dual citizenship recognized: not specified
residency requirement for naturalization: 5 years
Suffrage (../docs/notesanddefs.html#311): This entry gives the age at enfranchisement and whether the right to vote is universal or
restricted.
(.ifields/311.ntmi#MX)
18 years of age: universal and compulsory :
Executive branch (../docs/notesanddefs.html#312): This entry includes five subentries: chief of state; head of government; cabinet;
elections/appointments; election results. Chief of state includes the name, title, and beginning date in office of the titular leader of the
. Country who represents the state at official and ceremonial functions but may not be involved with the day-to-day activities of the
government. Head of government includes the name, title of the top executive designated to ameanege the executive branch of the
government, a... more (../docs/notesanddefs.html#312)
4}
(. fi elds/312.html#MX)
chief of state: President Andres Manuel LOPEZ OBRADOR (since 1 December 2018); note - the president is both chief of state and
head of government
head of government: President Andres Manuel LOPEZ OBRADOR (since 1 December 2018)
cabinet: Cabinet appointed by the president; note - appointment of attorney general, the head of the Bank of Mexico, and senior treasury
officials require consent of the Senate
elections/appointments: president directly elected by simple majority popular vote for a single 6-year term; election last held on 1 July
2018 (next to be held in July 2024)
election results: Andres Manuel LOPEZ OBRADOR elected president; percent of vote - Andres Manuel LOPEZ OBRADOR (MORENA)
53.2%, Ricardo ANAYA (PAN) 22.3%, Jose Antonio MEADE Kuribrena (PRI) 16.4%, Jaime RODRIGUEZ Calderon 5.2% (independent),
other 2.9%
Legislative branch (../docs/notesanddefs. html#313): This entry has three subfields. The description subfield provides the legislative
structure (unicameral — single house; bicameral — an upper and a lower house); formal name(s); number of member seats; types of
constituencies or voting districts (single seat, multi-seat, nationwide); electoral voting system(s); and member term of office. The
elections subfield includes the dates of the last election and next election. The election results subfield lists percent of vote by
party/coalition an . . . more (../docs/notesanddefs.html#313)
(..fields/313.htmi#MX)
description: bicameral National Congress or Congreso de la Union consists of:
Senate or Camara de Senadores (128 seats; 96 members directly elected in multi-seat-constituencies by simple majority vote and 32
directly elected in a single, nationwide constituency by proportional representation vote; members serve 6-year terms)
Chamber of Deputies or Camara de Diputados (500 seats; 300 members directly elected in single-seat constituencies by simple majority
vate and 200 directly elected in.a single, nationwide constituency by proportional representation vote; members serve 3-year terms)
elections:
Senate - last held on 1 July 2018 (next to be held on 1 July 2024)
Chamber of Deputies - last held on 1 July 2018 (next to be held on 1 July 2021)
election results:
Senate - percent of vote by party - percent of vote by party. - NA; seats by party - MORENA 58, PAN 22, PRI 14, PRD 9, MC 7, PT 7,
PES 5, PVEM 5, PNA/PANAL 1; composition - men 65, women 63, percent of women 49.3%
Chamber of Deputies - percent of vote by party - NA; seats by party - MORENA 193, PAN 79, PT 61, PES 58, PRI 42, MC 26, PRD 23,
PVEM 17, PNA/PANAL 1; compositi','f27da93db5fd61ba62f2937d2a7ce1a09df1146beb8d6a1ee0530d4856b5b7e8','internet-archive','cia-readingroom-document-06979333','txt','984e0c045c9a468f2ff29ce97e446d2422bc468407fa988a05f7b591d54893f9','https://archive.org/download/cia-readingroom-document-06979333/06979333_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dfd08b70a1ac036192dd95ab4022998c1e85391002ef3ac04c54cf30331d595b',2022,'','','raw',3,'on - men 259, women 241, percent of women 48.2%; note - total National Congress percent of
women 48.4%
note: for the 2018 election, senators will be eligible for a second term and deputies up to 4 consecutive terms
Judicial branch (../docs/notesanddefs.html#314): This entry includes three subfields. The highest court(s) subfield includes the name(s)
of a country''s highest level court(s), the number and titles of the judges, and the types of cases heard by the court, which commonly
are based on civil, criminal, administrative, and constitutional law. A number of countries have separate constitutional courts. The judge
selection and term of office subfield includes the organizations and associated officials responsible for nominating and appointing j ..
more (../docs/notesanddefs.himl#314)
(..ffields/314.html#MX)
highest courts: Supreme Court of Justice or Suprema Corte de Justicia de la Nacion (consists of the chief justice and 11 justices and
organized into civil, criminal, administrative, and labor panels) and the Electoral Tribunal of the Federal Judiciary (organized into the
superior court, with 7 judges including the court president, and 5 regional courts, each with 3 judges)
judge selection and term of office: Supreme Court justices nominated by the president of the republic and approved by two-thirds vote of
the members present in the Senate; justices serve fg ind terms; Electoral Tribunal su uperier. and regional court qui judges nominated by
THOME ES SA7GHY TIGCT4EG STATS 1H iASTP4S FAPAPR PETSS TEGO TARt a+ /
Approved for Release: 2022/12/08 C06979333
the Supreme Court and elected by two-th''-+- vote of members present in the Senate; sur~"-" court president elected trom among is
members to hold office for a 4-year term Approved for Release: 2022/12/08 C06979333taggered, 9-year terms
subordinate courts: federal level includes v., wit, collegiate, and unitary courts; state and wou: level courts
Note: in mid-February 2020, the Mexican president endorsed a bill on judicial reform, which proposes changes to 7 articles of the
constitution and the issuance of a new Organic Law on the Judicial Branch of the Federation
Political parties and leaders (../docs/notesanddefs.html#315): This entry includes a listing of significant political parties, coalitions, and
electoral lists as of each country''s last legislative election, unless otherwise noted.
Ey
(./fieids/315.himl#MX) :
Citizen''s Movement (Movimiento Ciudadano) or MC [Clemente CASTANEDA]
institutional Revolutionary Party (Partido Revolucionario Institucional) or PRI [Claudia RUIZ Massieu]
Labor Party (Partido del Trabajo) or PT [Alberto ANAYA Gutierrez]
Mexican Green Ecological Party (Partido Verde Ecologista de Mexico) or PVEM [Carlos Alberto PUENTE Salas]
Movement for National Regeneration (Movimiento Regeneracion Nacional) or MORENA [Andres Manuel LOPEZ Obrador]
National Action Party (Partido Accion Nacional) or PAN [Damian ZEPEDA Vidales]
Party of the Democratic Revolution (Partido de la Revolucion Democratica) or PRD [Manuel GRANADOS]
International organization participation (../docs/notesanddefs.html#317): This entry lists in alphabetical order by abbreviation those
international organizations in which the subject country is a member or participates in some other way.
(../fieids/317 .htmi#MX)
APEC, Australia Group, BCIE, BIS, CAN (observer), Caricom (observer), CD, CDB, CE (observer), CELAC, CSN (observer), EBRD,
FAO, FATF, G-3, G-15, G-20, G-24, G-5, IADB, IAEA, IBRD, ICAO, ICC (national committees), ICCt, ICRM, IDA, IFAD, IFC, IFRCS,
IHO, ILO, IMF, IMO, IMSO, Interpol, OC, IOM, IPU, ISO, ITSO, ITU, ITUC (NGOs), LAES, LAIA, MIGA, NAFTA, NAM (observer), NEA,
NSG, OAS, OECD, OPANAL, OPCW, Pacific Alliance, Paris Club (associate), PCA, SICA (observer), UN, UNASUR (observer),
UNCTAD, UNESCO, UNHCR, UNIDO, Union Latina (observer), UNWTO, UPU, WCO, WFTU (NGOs), WHO, WIPO, WMO, WTO
Diplomatic representation in the US (../docs/notesanddefs.html#318): This entry includes the chief of mission, chancery address,
telephone, FAX, consulate general locations, and consulate locations. The use of the annotated title Appointed Ambassador refers to a
new ambassador who has presented his/her credentials to the secretary of state but not the US president. Such ambassadors fulfill all
diplomatic functions except meeting with or appearing at functions attended by the president until such time as they formally present
their credentials at a White Hou . . . more (../docs/notesanddefs.htmi#318)
(..ields/318.html#MX)
Ambassador Martha BARCENA Coqui (since 11 January 2019); note - Ambassador BARCENA Coaui is Mexico''a first-ever female
ambassador to the US
chancery: 1911 Pennsylvania Avenue NW, Washington, DC 20006
telephone: [1] (202) 728-1600
FAX: [1] (202) 728-1698
consulate(s) general; Atlanta, Austin, Boston, Chicago, Dallas, Denver, El Paso (TX), Houston, Laredo (TX), Los Angeles, Miami, New
York, Nogales (AZ), Phoenix, Sacramento (CA), San Antonio (TX), San Diego, San Francisco, San Jose (CA), San Juan (Puerto Rico),
Saint Paul (MN)
consulate(s): Albuquerque (NM), Anchorage (AK), Boise (ID), Brownsville (TX), Calexico (CA), Del Rio (TX), Detroit, Douglas (AZ),
Eagle Pass (TX), Fresno (CA), Indianapolis (IN), Kansas City (MO), Las Vegas, Little Rock (AR), McAllen (TX), Minneapolis (MN), New
Orleans, Omaha (NE), Orlando (FL), Oxnard (CA), Philadelphia, Portland (OR), Presidio (TX), Raleigh (NC), Salt Lake City, San
Bernardino (CA), Santa Ana (CA), Seattle, Tucson (AZ), Yuma (AZ); note - Washington DC Consular Section is located in a separate
building from the Mexican Embassy and has jurisdiction over DC, parts of Virginia, Maryland, and West Virginia
Diplomatic representation from the US (../docs/notesanddefs.html#319): This entry includes the chief of mission, embassy address,
Ee address, telephone number, FAX number, branch office locations, consulate general locations, and consulate locations.
Ele
(../fields/319.html#MX)
chief of mission: Ambassador Christopher LANDAU (since 26 August 2019)
telephone: (011) 52-55-5080-2000
embassy: Paseo de la Reforma 305, Colonia Cuauhtemoc, 06500 Mexico, Distrito Federal
mailing address: P. O, Box 9000, Brownsville, TX 78520-9000
FAX; (011) §2-55-5080-2005
consulate(s) general: Ciudad Juarez, Guadalajara, Hermosillo, Matamoros, Merida, Monterrey, Nogales, Nuevo Laredo, Tijuana
Flag description (../docs/notesanddefs.html#320): This entry provides a written flag description produced from actual flags or the best
information available at the time the entry was written. The flags of independent states are used by their dependencies unless there is
an officially recognized local flag. Some disputed and other areas do not have flags.
(..fields/320.htmi#MX)
three equal vertical bands of green (hoist side), white, and red; Mexico''s coat of arms (an eagle with a snake in its beak perched on a
cactus) is centered in the white band; green signifies hope, joy, and love; white represents peace and honesty; red stands for hardiness,
bravery, strength, and valor; the coat of arms is derived from a legend that the wandering Aztec people were to settle at a location where
they would see an eagle on a cactus eating a snake; the city they founded, Tenochtitlan, is now Mexico City
notes similarto-the:fiag of itaigewhich isshortes, uses lighter SHadestoF 9fen Afid Ken, BAGAES idt@isplaxafything in its white band /
Approved for Release: 2022/12/08 C06979333
National symbol(s) (../docs/notesa
distinctive object - that over time h
OE rrve }: A national symbol Is a faunal, fre" -r ntner abstract representation - or some
few countries have more than one.
pproved for Release: 2022/12/08 C06979333¢ all countries have national symbols; a
(..fields/321 .html#MX)
golden eagle; national colors: green, white, red
National anthem (../docs/notesanddefs.html#322): A generally patriotic musical composition - usually in the form of a song or hymn of
praise - that evokes and eulogizes the history, traditions, or struggles of a nation or its people. National anthems can be officially
recognized as a national song by a country''s constitution or by an enacted law, or simply by tradition. Although most anthems contain
lyrics, some do not.
(_ifields/322.html#MX)
name: "Himno Nacional Mexicano” (National Anthem of Mexico)
lyrics/music: Francisco Gonzalez BOCANEGRA/Jaime Nuno ROCA
note: adopted 1943, in use since 1854; also known as "Mexicanos, al grito de Guerra” (Mexicans, to the War Cry); according to
tradition, Francisco Gonzalez BOCANEGRA, an accomplished poet, was uninterested in submitting lyrics to a national anthem contest;
his fiancee locked him in a room and refused to release him until the lyrics were completed
0:00 / 1:41
Economy :: Mexico
Economy - overview (../docs/notesanddefs.html#207): This entry briefly describes the type of economy, including the degree of market
orientation, the level of economic development, the most important natural resources, and the unique areas of specialization. It also
characterizes major economic events and policy changes in the most recent 12 months and may include a statement about one or two
eo future macroeconomic trends.
Ee:
(..fields/207 .ntmi#MX)
Mexico''s $2.4 trillion economy — 11th largest in the world - has become increasingly oriented toward manufacturing since the North
American Free Trade Agreement (NAFTA) entered into force in 1994. Per capita income is roughly one-third that of the US; income
distribution remains highly unequal.
Mexico has become the US'' second-largest export market and third-largest source of imports. In 2017, two-way trade in goods and
services exceeded $623 billion. Mexico has free trade agreements with 46 countries, putting more than 90% of its trade under free trade
agreements. In 2012, Mexico formed the Pacific Alliance with Peru, Colombia, and Chile.
Mexico''s current government, led by President Enrique PENA NIETO, has emphasized economic reforms, passing and implementing
sweeping energy, financial, fiscal, and telecommunications reform legislation, among others, with the long-term aim to improve
competitiveness and economic growth across the Mexican economy. Since 2015, Mexico has held public auctions of oil and gas
exploration and development rights and for long-term electric power generation contracts. Mexico has also issued permits for private
sector import, distribution, and retail sales of refined petroleum products in an effort to attract private investment into the energy sector
and boost production.
Since 2013, Mexico''s economic growth has averaged 2% annually, falling short of private-sector expectations that President PENA
NIETO''s sweeping reforms would bolster economic prospects. Growth is predicted to remain below potential given failing oil production,
weak oil prices, structural issues such as low productivity, high inequality, a large informal sector employing over half of the workforce,
weak rule of law, and corruption. Mexico''s economy remains vulnerable to uncertainty surrounding the future of NAFTA — because the
United States is its top trading partner and the two countries share integrated supply chains — and to potential shifts in domestic
policies following the inauguration of a new a president in December 2018.
GDP (purchasing power parity) (../docs/notesanddefs.html#208): This entry gives the gross domestic product (GDP) or value of all final
goods and services produced within a nation in a given year. A nation''s GDP at purchasing power parity (PPP) exchange rates is the
sum value of all goods and services produced in the country valued at prices prevailing in the United States in the year noted. This is
the measure most economists prefer when looking at per-capita welfare and when comparing living conditions or use of resources
across countries. The measur . . . more (../docs/notesanddefs.html#208)
(../fields/208.htmi#MX)
$2.463 trillion (2017 est.)
$2.413 trillion (2016 est.)
$2.346 trillion (2015 est.)
note: data are in 2017 dollars
couniry comparison to the world: 11 (../fields/208rank.html#MX) :
GDP (official exchange rate) (../docs/notesanddefs.html#209): This entry gives the gross domestic product (GDP) or value of all final
goods and services produced within a nation in a given year. A nation''s GDP at official exchan tes (OER) is the home- a
PEAT ORT EOD TaOC Tae CTAT AD. TE tear eae TORR Sas TROL Oe TEOTACae a omecurency
Approved for Release: 2022/12/08 C06979333
denominated annual GDP figure divided hy the bilateral average US exchange rate with that country in thal year. [he measure Is
simple to compute and gives a oo ae for Release: 2022/12/08 C06979333this measure when gauging the
s power an economy maint -... more (../docs/notesanddefs.html#20-,
(.. fields/209.htmi#MX)
$1.151 trillion (2017 est.)
GDP - real growth rate (../docs/notesanddefs.html#210): This entry gives GDP growth on an annual basis adjusted for inflation and
expressed as a percent. The growth rates are year-over-year, and not compounded.
fed
(.. fields/210.html#MX)
2% (2017 est.)
2.9% (2016 est.)
3.3% (2015 est.)
‘country comparison to the world: 152 (../fields/2 10rank.html#MX)
GDP - per capita (PPP) (../docs/notesanddefs.htmi#211): This entry shows GDP on a purchasing power parity basis divided by
population as of 1 July for the same year.
E)
(..ffields/211.html#MX)
$19,900 (2017 est.)
$19,700 (2016 est.)
$19,400 (2015 est.)
note: data are in 2017 dollars
country comparison to the world: 90 (../fields/211rank.html#MX) :
Gross national saving (../docs/notesanddefs.html#212): Gross national saving is derived by deducting final consumption expenditure
(household plus government) from Gross national disposable income, and consists of personal saving, plus business saving (the sum
of the capital consumption allowance and retained business profits), plus government saving (the excess of tax revenues over
’ expenditures), but excludes foreign saving (the excess of imports of goods and services over exports). The figures are presented as a
percent of GDP. A negative .. . more (..docs/notesanddefs.html#212)
(../fields/212.html#MX)
21.4% of GDP (2017 est.)
21.6% of GDP (2016 est.)
20.7% of GDP (2015 est.)
country comparison to the world: 85 (../fields/212rank.html#MX)
GDP - composition, by end use (../docs/notesanddefs.html#213): This entry shows who does the spending in an economy: consumers,
businesses, government, and foreigners. The distribution gives the percentage contribution to total GDP of household consumption,
government consumption, investment in fixed capital, investment in inventories, exports of goods and services, and imports of goods
and services, and will total 100 percent of GDP if the data are complete. household consumption consists of expenditures by resident
households, and by nonprofit insti. . . more (../docs/notesanddefs.html#213)
(../fields/213.htmi#MX)
household consumption: 67% (2017 est.)
government consumption: 11.8% (2017 est.)
investment in fixed capital: 22.3% (2017 est.)
investment in inventories: 0.8% (2017 est.)
exports of goods and services: 37.8% (2017 est.)
imports of goods and services: -39.7% (2017 est.)
GDP - composition, by sector of origin (../docs/notesanddefs.html#214): This entry shows where production takes place. in an economy.
The distribution gives the percentage contribution of agriculture, industry, and services to total GDP, and will total 100 percent of GDP if
the data are complete. Agriculture includes farming, fishing, and forestry. Industry includes mining, manufacturing, energy production,
and construction. Services cover government activities, communications, transportation, finance, and all other private economic
a that do not prod . . . more (../docs/notesanddefs.himi#214)
El:
(.. fields/214.html#MX)
agriculture: 3.6% (2017 est.)
industry: 31.9% (2017 est.)
services: 64.5% (2017 est.)
Agriculture - products (../docs/notesanddefs.htmi#215): This entry is an ordered listing of major crops and products starting with the
most important.
eae
(../fields/215.htmil#MX) .
corn, wheat, soybeans, rice, beans, cotton, coffee, fruit, tomatoes; beef, poultry, dairy products; wood products
industries (../docs/notesanddefs.html#216): This entry provides a rank ordering of industries starting with the largest by value of annual
output. . E
Ey
(igl@si2 1GRIMNPD 19a5t4 BALE. TH cORETIS PACMAG PESR THOM FABLA-A999. /
Approved for Release: 2022/12/08 C06979333.
food and beverages, tobacco, che
tourism pproved for Release: 2022/12/08 C06979333
Industrial production growth rate (..eecsmotesanddefs.html#217): This entry gives t... u.....ul percentage increase in industrial
production (includes manufacturing, mining, and construction).
(..fields/217 html#MX)
-0.6% (2017 est.)
country comparison to the world: 174 (..fields/217rank.html#MX)
Labor force (../docs/notesanddefs.html#218): This entry contains the total labor force figure.
(ee
(..ffields/218.html#MX)
54.51 million (2017 est.)
country comparison to the world: 12 (..fields/218rank.html#MX)
Labor force - by occupation (../docs/notesanddefs.html#219): This entry lists the percentage distribution of the labor force by sector of
occupation. Agriculture includes farming, fishing, and forestry. Industry includes mining, manufacturing, energy production, and
construction. Services cover government activities, communications, transportation, finance, and all other economic activities that do
not produce material goods. The distribution will total less than 100 percent if the data are incomplete and may range from 99-101
percent due to rounding. more (../docs/notesanddefs.htmi#219)
''e q and steel, petroleum, mining, textiles, c''o*"in~ motor vehicles, consumer durables,
(../fields/219.html#MX)
agriculture: 13.4%
industry: 24.1%
services: 61.9% (2011)
Unemployment rate (../docs/notesanddefs.html#220): This entry contains the percent of the labor force that is without jobs. Substantial
- underernployment might be noted.
if
(../fields/220.htmi#MXx)
3.4% (2017 est.)
3.9% (2016 est.)
note: underemployment may be as high as 25%
country comparison to the world: 42 (../fields/220rank.html#MX)
Population below poverty line (../docs/notesanddefs.htmi#221): National estimates of the percentage of the population falling below the
poverty line are based on surveys of sub-groups, with the results weighted by the number of people in each group. Definitions of
poverty vary considerably among nations. For example, rich nations generally employ more generous standards of poverty than poor
nations.
(.fields/221.htmi#MX)
46.2% (2014 est.)
note: from a food-based definition of poverty; asset-based poverty amounted to more than 47%
Household income or consumption by percentage share (../docs/notesanddefs.html#222): Data on household income or consumption
come from household surveys, the results adjusted for household size. Nations use different standards and procedures in collecting
and adjusting the data. Surveys based on income will normally show a more unequal distribution than surveys based on consumption.
The quality of surveys is improving with time, yet caution is still necessary in making inter-country comparisons.
(_Mields/222, htmi#Mx)
lowest 10%: 2%
highest 10%: 40% (2014)
Budget (../docs/notesanddefs.html#224): This entry includes revenues, expenditures, and capital expenditures. These figures are
calculated on an exchange rate basis, i.e., not in purchasing power parity (PPP) terms.
(../fields/224.html#MX)
revenues: 261.4 billion (2017 est.)
expenditures: 273.8 billion (2017 est.)
Taxes and other revenues (../docs/notesanddefs.html#225): This entry records total taxes and other revenues received by the national
government during the time period indicated, expressed as a:percent''of GDP. Taxes include personal and corporate income taxes,
value added taxes, excise taxes, and tariffs. Other revenues include social contributions - such as payments for social security and
hospital insurance - grants, and net revenues from public enterprises. Normalizing the data, by dividing total revenues by GDP, enables
easy comparisons acr . . . more (../docs/notesanddefs.html#225)
(..fields/225.htmi#MX)
22.7% (of GDP) (2017 est.)
country comparison to the world: 137 (. fields/225rank.html#MX)
Budget surplus (+) or deficit (-) (../docs/notesanddefs.html#226): This entry records the difference between national government
revenues and expenditures, expressed as a percent of GDP. A positive (+) number indicates that,revenues exceeded expenditures (a
Boe eat ee eee eee eo aeRO Oates Tame ye LOTR tar ;
Approved for Release: 2022/12/08 C06979333
budget surplus), while a negative (-) numer indicates the reverse (a budget dericit). Norm="zing Ine aala, Dy alviding ine Duaget
balance by GDP, enables easy OO sc: for Release: 2022/12/08 C06979333}0vernment saves or borrows money.
Countries with high budget deficits more (../docs/notesanddefs.himl#226)
(../fields/226.htmi#MX)
-1.1% (of GDP) (2017 est.)
country comparison to the world: 83 (../fields/226rank.html#MX)
Public debt (../docs/notesanddefs.html#227): This entry records the cumulative total of all government borrowings less repayments that
are denominated in a country''s home currency. Public debt should not be confused with external debt, which reflects the foreign
currency liabilities of both the private and public sector and must be financed out of foreign exchange earnings.
{../fields/227.html#MX)
54.3% of GDP (2017 est.)
56.8% of GDP (2016 est.)
country comparison to the world: 82 (../fields/227rank.htmi#MxX)
Fiscal year (../docs/notesanddefs.html#228): This entry identifies the beginning and ending months for a country’s accounting period of
12 months, which often is the calendar year but which may begin in any month. All yearly references are for the calendar year (CY)
unless indicated as a noncalendar fiscal year (FY).
idl
(../fields/228,.html#MX)
calendar year
Inflation rate (consumer prices) (../docs/notesanddefs.html#229): This entry furnishes the annual percent change in consumer prices
compared with the previous year''s consumer prices.
(..ffields/229, html#MX)
6% (2017 est.)
2.8% (2016 est.)
country comparison to the world: 186 (../fields/229rank.htmi#MX)
Current account balance (../docs/notesanddefs.html#238): This entry records a country’ ''s net trade in goods and services, plus net
earnings from rents, interest, profits, and dividends, and net transfer payments (such as pension funds and worker remittances) to and
from the rest of the world during the period specified. These figures are calculated on an escnange rate basis, i.e., not in purchasing
power parity (PPP) terms.
(ifields/238.htmi#MX)
-$19.35 billion (2017 est.)
-$23.32 billion (2016 est.)
country comparison to the world: 198 (../fi elds/238rank.htmi#MX)
Exports (../docs/notesanddefs.html#239): This entry provides the total US dollar amount of merchandise exports on an f.o.b. (free on
board) basis. These figures are calculated on an exchange rate basis, i.e., not in purchasing power parity (PPP) terms.
(../fields/239,html#MX)
$409.8 billion (2017 est.) -
$374.3 billion (2016 est.)
country comparison to the world: 12 (../fields/239rank.html#MX)
Exports - partners (../docs/notesanddefs.html#241): This entry provides a rank ordering of trading partners starting with the most
important; it sometimes includes the percent of total dollar value.
(../fields/241 .htmi#MX)
US 79.9% (2017)
Exports - commodities (. Idocsinotesanddefs. html#240): This entry provides a listing of the highest-valued exported products; it
sometimes includes the percent of total dollar vaiue.
Le
manufactured goods, electronics, vehicles and auto parts, oil and oil products, silver, plastics, fruits, vegetables, coffee, cotton; Mexico
is the world''s leading producer of silver
Imports (../docs/notesanddefs.html#242): This entry provides the total US dollar amount of merchandise imports on a c.if. (cost,
insurance, and freight) or f.o.b. (free on board) basis. These figures are calcul','d0226b83cce0449d466d4294dc0b5540a81deb5201f28b415b6571738922b16d','internet-archive','cia-readingroom-document-06979333','txt','984e0c045c9a468f2ff29ce97e446d2422bc468407fa988a05f7b591d54893f9','https://archive.org/download/cia-readingroom-document-06979333/06979333_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba4ae6d272f6d392c3473c0e151cb20e6226d5f6e486c2056c6a932f1f513733',2022,'','','raw',4,'ated on an exchange rate basis, i.e., not in purchasing
power parity (PPP) terms.
et
(../fields/242.htmH##MX)
$420.8 billion (2017 est.)
$387.4 billion (2016 est.)
country comparison to the world: 14 (../fields/242rank.html#MX)
Imports - commodities (../docs/notesanddefs.html#243): This entry provides a listing of the highest-valued imported products; it
on includes the percent of total dollar vaiue.
ed
(Hields/243. htmi#MX) :
tOOOPESSSPEGG FIGS 4K TRIS 46 ESTT SS EEO OR: C2 TAGE FEGEA-F59F |
Approved for Release: 2022/12/08 C06979333
aircraft, aircraft parts, plastics, natur pproved for Release: 2022/12/08 C06979333 oe
Imports - partners (../docs/notesandGers.mml#403): This entry provides a rank orderiny uru ading partners starting with the most
important; it sometimes includes the percent of total dollar value.
metalworking machines, steel mill ot agricultural macninery, Sieciical Equipme™ —nuUIE pans iul aascniviy anu rspan,
Seat rd
(../fields/403.htmi#MX)
US 46.4%, China 17.7%, Japan 4.3% (2017)
Reserves of foreign exchange and gold (../docs/notesanddefs.html#245): This entry gives the dollar value for the stock of all financial
assets that are available to the central monetary authority for use in meeting a country''s balance of payments needs as of the end-date
of the period specified. This category includes not only foreign currency and gold, but also a country''s holdings of Special Drawing
Rights in the International Monetary Fund, and its reserve position in the Fund.
(..ffields/245.html#MX)
$175.3 billion (31 Decernber 2017 est.)
$178.4 billion (81 December 2016 est.)
note: Mexico also maintains access to an $88 million Flexible Credit Line with the IMF
country comparison to the world: 14 (../fields/245rank.htmi#MX)
Debt - external (../docs/notesanddefs.htmi#246): This entry gives the total public and private debt owed to nonresidents repayable in
internationally accepted currencies, goods, or services. These figures are calculated on an exchange rate basis, i.e., not in purchasing
power parity (PPP) terms. ‘
(..fields/246.html#MX)
$445.8 billion (31 December 2017 est.)
$450.2 billion (31 December 2016 est.)
country comparison to the world: 28 (../fields/246rank.html#MX)
Exchange rates (../docs/notesanddefs.html#249): This entry provides the average annual price of a country''s monetary unit for the time
period specified, expressed in units of local currency per US dollar, as determined by international market forces or by official fiat. The
International Organization for Standardization (ISO) 4217 alphabetic currency code for the national medium of exchange is presented
in parenthesis. Closing daily exchange rates are not presented in The World Factbook, but are used to convert stock values - e.g., the .
.. more (../docs/notesanddefs.html#249)
(..fields/249.html#MX)
Mexican pesos (MXN) per US dollar -
18.26 (2017 est.)
18.664 (2016 est.)
18.664 (2015 est.)
15.848 (2014 est.)
13.292 (2013 est.)
Energy :: Mexico
Electricity access (../docs/notesanddefs.htmi#251): This entry provides information on access to electricity. Electrification data ~
collected from industry reports, national surveys, and international sources — consists of four subfields. Population without electricity
provides an estimate of the number of citizens that do not have access to electricity. Electrification — total population is the percent ofa
country''s total population with access to electricity, electrification — urban areas is the percent of a country''s urban populationw...
more (../docs/notesanddefs.html#251)
(../fields/251.htmi#MX)
electrification - total population: 100% (2016)
Electricity - production (../docs/notesanddefs.htmi#252): This entry is the annual electricity generated expressed in kilowatt-hours. The
discrepancy between the amount of electricity generated and/or imported and the amount consumed and/or exported is accounted for
as loss in transmission and distribution.
(.fields/252,htmi#MX)
302.7 billion kWh (2016 est.)
country comparison to the world: 73 (../fields/252rank.htmi#MX)
Electricity - consumption (../docs/notesanddefs.html#253): This entry consists of total electricity generated annuaily plus imports and
minus exports, expressed in kilowatt-hours. The discrepancy between the amount of electricity generated and/or imported and the
amount consumed and/or exported is accounted for as loss in transmission and distribution.
_ (#fields/253.html#MX)
258.7 billion kWh (2016 est.)
country comparison to the world: 14 (_/fields/253rank.htmi#MxX)
Electricity - exports (../docs/notesanddefs.html#254): This entry is the total exported electricity in kilowatt-hours.
(..fields/254.html#MX)
7.308 billion kWh (2016 est.)
COUn YS. RAMBATSOR ieuihe wore 2io(--GiPeSZEAPATNS TA2E7G AAAS THBA7S TAETA- AATF: /
Approved for Release: 2022/12/08 C06979333
Electricity - imports (../docs/notesanddefs,html#255): This entry is the total imported e!e~''-ity in kilowatt-hours.
ey GB or0v01 for Release: 2022/12/08 C06979333
(..fields/255.html#MX)
3,532 billion kWh (2016 est.)
country comparison to the world: 47 (..fields/255rank.htmi#MX)
Electricity - installed generating capacity (../docs/notesanddefs.html#256): This entry is the total capacity of currently installed
generators, expressed in kilowatts (kW), to produce electricity. A 10-kilowatt (kW) generator will produce 10 kilowatt hours (kWh) of
electricity, if it runs continuously for one hour.
(../fields/256.html#MX)
72.56 million kW (2016 est.)
country comparison to the world: 17 (../fields/256rank.html#MX)
‘Electricity - from fossil fuels (../docs/notesanddefs.html#257): This entry measures the capacity of plants that generate electricity by
burning fossil fuels (such as coal, petroleum products, and natural gas), expressed as a share of the country''s total generating
capacity.
(..fields/257.html#MX)
71% of total installed capacity (2016 est.)
country comparison to the world: 106 (../fields/257rank.html#MX)
Electricity - from nuclear fuels (../docs/notesanddefs.html#258): This entry measures the ree of plants that generate electricity
through radioactive decay of nuclear fuel, expressed as a share of the country''s total generating capacity.
(Hfields/258. html#MX)
2% of total installed capacity (2017 est.)
country comparison to the world: 27 (../fields/258rank.htmi#MxX)
Electricity - from hydroelectric plants (../docs/notesanddefs.html#259): This entry measures the capacity of plants that generate
a by water-driven turbines, expressed as a share of the country''s total generating capacity.
[iz}¢,
(..ields/259.htmi#MX)
17% of total installed capacity (2017 est.)
country comparison to the world: 96 (../fields/259rank.html#MX)
Electricity - from other renewable sources (../docs/notesanddefs.html#260): This entry measures the capacity of plants that generate
electricity by using renewable energy sources other than hydroelectric (including, for example, wind, waves, solar, and geothermal),
‘ a as a share of the country''s total generating capacity.
( i elds/260.htmi#MX)
9% of total installed capacity (2017 est.)
country comparison to the world: 82 (../fields/260rank.html#MX)
Crude oil - production (../docs/notesanddefs.html#261): This entry is the total amount of crude oil produced, in barrels per day
(bbi/day).
(../fields/261 .html#MX)
1.852 million bbi/day (2018 est.)
country comparison to the world: 13 (../fields/261rank.html#MX)
Crude oil - exports (../docs/notesanddefs.html#262): This entry is the total amount of crude oil exported, in barrels per day (bbi/day).
(../fields/262.html#MX)
4.214 million bbi/day (2017 est.)
country comparison to the world: 11 (../fields/262rank.html#MX)
Crude oil - imports (../docs/notesanddefs.html#263): This entry is the total amount of crude oil imported, in barrels per day (bbi/day).
(..fields/263.htmi#MX)
0 bbi/day (2017 est.)
country comparison to the world: 166 (../fields/263rank.himl#MX)
Crude oil - proved reserves (../docs/notesanddefs.html#264): This entry is the stock of proved reserves of crude oil, in barrels (bbl).
Proved reserves are those quantities of petroleum which, by analysis of geological and engineering data, can be estimated with a high
degree of confidence to be commercially recoverable from a given date forward, from known reservoirs and under current econornic
conditions.
(..ffields/264.htmH#MX)
6.63 billion bbl (1 January 2018 est.)
country comparison to the world: 19 (../fields/264rank.html#MX)
Refined petroleum products - production (../docs/notesanddefs.html#265): This entry is the country''s total output of refined petroleum
products, in barrels per day (bbi/day). The discrepancy between the amount of refined petroleum products produced and/or imported
the amount consumed and/or exported is due to the omission of stock changes, refinery gains, and other complicating factors.
Ely:
(../fields/265.html#MX) : ;
B441GOO Ody A204Mest.} FHST AG ARTI 1A sGSEFAG TAPHOR PHS PHA AR FER TA-45-44
Approved for Release: 2022/12/08 C06979333
Refined petroleum products - cons pproved for Release: 2022/12/08 C069793330uNtIy''s total consumption of refined
petroleum products, in barrels per d day). The discrepancy between the amou... -. ....ned petroleum products produced and/or
imported and the amount consumed and/or exported is due to the omission of stock changes, refinery gains, and other complicating
factors.
country comparison to the world: 23 GB ro vesterres
(../fields/266.html#MX)
1.984 million bbi/day (2017 est.)
country comparison to the world: 11 (../fields/266rank.html#MX)
Refined petroleum products - exports (../docs/notesanddefs.html#267): This entry is the country''s total exports of refined petroleum
products, in barrels per day (bbi/day).
(../fields/267 .html#MX)
155,800 bbl/day (2017 est.)
country comparison to the world: 35 (../fields/267rank.html#MX)
Refined petroleum products - imports (../docs/notesanddefs.html#268): This entry is the country''s total imports of refined petroleum
products, in barrels per day (bbi/day).
(../fields/268.html#MX)
867,500 bbi/day (2017 est.)
country comparison to the world: 10 (../fields/268rank.htmi#MX)
Natural gas - production (../docs/notesanddefs.html#269): This entry is the total natural gas produced in cubic meters (cu m). The
discrepancy between the amount of natural gas produced and/of imported and the amount consumed and/or exported is due to the
omission of stock changes and other complicating factors.
(../fields/269.html#MX)
31.57 billion cu m (2017 est.)
country comparison to the world: 24 (../fields/269rank.html#MX)
Natural gas - consumption (../docs/notesanddefs.html#270): This entry is the total natural gas consumed in cubic meters (cu m). The
discrepancy between the amount of natural gas produced and/or imported and the amount consumed and/or exported is due to the
omission of stock changes and other complicating factors.
Ee
(../fieids/270.htmi#MX)
81.61 billion cu m (2017 est.)
country comparison to the world: 9 (../fields/270rank. html#MX)
Natural gas - exports (../docs/notesanddefs.html#271): This entry is the total natural gas exported in cubic meters (cu m).
(..fields/27 1.html#MX)
36.81 million cu m (2017 est.)
country comparison to the world: 51 (../fields/27 1rank.html#MX)
Natural gas - imports (../docs/notesanddefs.htmi#272): This entry is the total natural gas imported in cubic meters (cu m).
(../fields/272.htmi#MX)
50.12 billion cu m (2017 est.)
country comparison to the world: 8 (../fields/272rank.html#MX) :
Natural gas - proved reserves (../docs/notesanddefs.htmi#273): This entry is the stock of proved reserves of natural gas in cubic
meters (cu m). Proved reserves are those quantities of natural gas, which, by analysis of geological and engineering data, can be
estimated with a high degree of confidence to be commercially recoverable from a given date forward, from known reservoirs and
under current economic conditions.
(..Mields/273.html#MX)
279.8 billion cu m (1 January 2018 est.)
country comparison to the world: 38 (..fields/273rank.html#MX)
Carbon dioxide emissions from consumption of energy (../docs/notesanddefs.html#274): This entry is the total amount of carbon
dioxide, measured in metric tons, released by burning fossil fuels in the process of producing and consuming energy.
(../fields/274.html#MX)
454.1 million Mt (2017 est.)
country comparison to the world: 14 (../fields/274rank.html#MX)
Communications :: Mexico
Telephones - fixed lines (../docs/notesanddefs.html#196): This entry gives the total number of fixed telephone lines in use, as well as
the number of subscriptions per 100 inhabitants.
!
(../fields/196.html#MX)
total subscriptions: 21,645,699
subscriptions per 100 inhabitants: 17 (2018 est.)
country comparison to the world: 12 (../fields/196rank.html#MX)
+AOOETEATPLGG tIGTt4G GLAT4G TH GSEF4S FAOAPH PHIGe HASH TERtA-4099
Approved for Release: 2022/12/08 C06979333
Telephones - mobile cellular (../doc
subscribers, as well as the number
developed countries, the number of
pproved for Release: 2022/12/08 C06979333¢ Ubiquity of mobile phone use in
ptions per 100 inhabitants can exceed 10L.
yee 97): This entry gives the tote! ™''''™ner of Mobile Celular teiepnone
[ey
(..fields/197.htmi#MX)
total subscriptions: 120,173,510
subscriptions per 100 inhabitants: 95 (2018 est.)
country comparison to the world: 14 (../fields/197rank.html#MX)
Telecommunication systems (../docs/notesanddefs.html#198): This entry includes a brief general assessment of a country''s
telecommunications system with details on the domestic and international components. The following terms and abbreviations are
used throughout the entry: 2G - is short for second-generation cellular network. After 2G was launched, the previous mobile wireless
network systems were retroactively dubbed 1G. While radio signals on 1G networks are analog, radio signals on 2G networks
are digital. Both systems use digital signaling . . . more (../docs/notesanddefs. html#198)
Ey
(..fields/198.htmi#MX)
general assessment: adequate telephone service for business and government; improving quality and increasing mobile cellular
availability, with mobile subscribers far outnumbering fixed-line subscribers; relatively low broadband and mobile penetration, potential
for growth; extensive microwave radio relay network; considerable use of fiber-optic cable and coaxial cable; two main MNOs despite
efforts for competition; 5G development slow given the existing capabilities of LTE; Mexico''s first local Internet Exchange Point opens in
Mexico City; regulator strives to bring competition and foreign investment to Mexico; regulator brings back SIM card registration program
(2020)
domestic: competition has spurred the mobile-cellular market; fixed-line teledensity exceeds 17 per 100 persons; mobile-cellular
teledensity is about 95 per 100 persons; domestic satellite system with 120 earth stations (2018)
international: country code - 52; Columbus-2 fiber-optic submarine cable with access to the US, Virgin islands, Canary Islands, Spain,
and Italy; the ARCOS-1 and the MAYA-1 submarine cable system together provide access to Central America, parts of South America
and the Caribbean, and the US; satellite earth stations - 120 (32 Intelsat, 2 Solidaridad (giving Mexico improved access to South
America, Central America, and much of the US as well as enhancing domestic communications), 1 Panamsat, numerous Inmarsat
mobile earth stations); linked to Central American Microwave System of trunk connections (2016)
the COVID-19 outbreak is negatively impacting telecommunications production and supply chains globally; consumer spending on
telecom devices and services has also slowed due to the pandemic''s effect on economies worldwide; overall progress towards
improvements in all facets of the telecom industry - mobile, fixed-line, broadband, submarine cable, and satellite - has moderated
Broadcast media (../docs/notesanddefs.html#199): This entry provides information on the approximate number of public and private TV
and radio stations in a country, as well as basic information on the availability of satellite and cable TV services.
(../fields/499.htmi#MX)
telecom reform in 2013 enabled the creation of new broadcast television channels after decades of a quasi-monopoly; Mexico has 821
TV stations and 1,745 radio stations and most are privately owned; the Televisa group once had a virtual monopoly in TV broadcasting,
but new broadcasting groups and foreign satellite and cable operators are now available; in 2016, Mexico became the first country in
Latin America to complete the transition from analog to digital transmissions, allowing for better image and audio quality and a wider
selection of programming from networks :
Internet country code (../docs/notesanddefs.htmi#202): This entry includes the two-letter codes maintained by the International
Organization for Standardization (ISO) in the ISO 3166 Alpha-2 list and used by the Internet Assigned Numbers Authority (IANA) to
country-coded top-level domains (ccTLDs).
Bay
(..fields/202.htmi#MX)
.mx
Internet users (../docs/notesanddefs.html#204): This entry gives the total number of individuals within a country who can access the
internet at home, via any device type (computer or mobile) and connection. The percent of population with Internet access (i.e., the
penetration rate) helps gauge how widespread Internet use is within a country. Statistics vary from country to country and may include
a who access the Internet at least several times a week to those who access it only once within a period of several months.
ig)
(../fields/204 html#MX)
total: 82,843,369
percent of population: 65.77% (July 2018 est.)
country comparison to the world: 9 (../fields/204rank.html#MX)
Broadband - fixed subscriptions (../docs/notesanddefs.html#206): This entry gives the total number of fixed-broadband subscriptions,
as well as the number of subscriptions per 100 inhabitants. Fixed broadband is a physical wired connection to the Internet (e.g., coaxial
cable, optical fiber) at speeds equal to or greater than 256 kilobits/second (256 kbit/s).
f
(../fields/206.htmi#MX)
total: 18,359,028
subscriptions per 100 inhabitants: 15 (2018 est.)
country comparison to the world: 10 (..Mields/206rank.himl#MX)
Military and Security :: Mexico
Military and security forces (../docs/notesanddefs.html#331): This entry lists the military and security forces subordinate to defense
ministries or the equivalent (typically ground, naval, air, and marine forces), as well as those belonging to interior ministries or the
equivalent (typically gendarmeries, border/coast guards, pare Te police, and other internal security forces),
toe
FROROETESQECRG «FIOST4A GPATGG 7G :ASt74& FOGG 2H5R TAOPG THBTA-TS
Approved for Release: 2022/12/08 C06979333
a
(../fields/33 1 .Atml#MX) Approved for Release: 2022/12/08 C06979333
Secretariat of National Defense (Sec... «we Defensa Nacional, SEDENA): Army (Ejc.~...,, Mexican Air Force (Fuerza Aerea
Mexicana, FAM); Secretariat of the Navy (Secretaria de Marina, SEMAR): Mexican Navy (Armada de Mexico (ARM), includes Naval Air
Force (FAN), Mexican Naval Infantry Corps (Cuerpo de Infanteria de Marina, Mexmar or CIM)); Ministry of Security and Citizen
Protection: Federal Police (includes Gendarmerie), National Guard (2019)
note: the National Guard was formed in 2019 and consists of personnel from the Federal Police and military police units of the Army and
Navy
Military expenditures (../docs/notesanddefs.html#330): This entry gives estimates on spending on defense programs for the most
recent year available as a percent of gross domestic product (GDP); the GDP is calculated on an exchange rate basis, i.e., not in terms
of purchasing power parity (PPP). For countries with no military forces, this figure can include expenditures on public security and
police. :
(../fields/330.html#MX)
0.5% of GDP (2019)
0.54% of GDP (2018)
0.47% of GDP (2017)
0.56% of GDP (2016)
0.66% of GDP (2015)
country comparison to the world: 148 (../fields/330rank.htmi#MX)
Military and security service personnel strengths (../docs/notesanddefs.html#410): This entry provides estimates of military and security
services personnel strengths. The numbers are based on a wide-range of publicly available information. Unless otherwise noted,
military estimates focus on the major services (army, navy, air force, and where applicable, gendarmeries) and do not account for
activated reservists or delineate military service members assigned to joint staffs or defense ministries.
EM
(../fields/410.htmi#MX)
the Mexican armed forces have approximately 270,000 active personnel (200,000 Army; 60,000 Navy; 8,000 Air Force); approximately
60,000 National Guard (2019 est.)
Military equipment inventories and acquisitions (../docs/notesanddefs.html#4 11): This entry provides basic information on each
country''s military equipment inventories, as well as how they acquire their equipment; it is intended to show broad trends in major
military equipment holdings, such as tanks and other armored vehicles, air defense systems, artillery, naval ships, helicopters, and
fixed-wing aircraft. Arms acquisition information is an overview of major arms suppliers over a specific period of time, including second-
hand arms delivered as aid, with a focus on m. . . more (../docs/notesanddefs.html#4 11)
et
(.. Mields/411 btmi#MX)
the Mexican military inventory includes a mix of domestically-produced and imported equipment from a variety of mostly Western
suppliers; since 2010, France, Spain, and the US are the leading suppliers of military hardware to Mexico; Mexico''s defense industry
produces naval vessels and light armored vehicles (2019 est.)
Military service age and obligation (../docs/notesanddefs.htmi#333): This entry gives the required ages for voluntary or conscript
military service and the length of service obligation.
(../fields/333.html#MX)
18 years of age for compulsory military service (selection for service determined by lottery), conscript service obligation is 12 months; 16
years of age with consent for voluntary enlistment; cadets enrolled in military schools from the age of 15 are considered members of the
armed forces; women are eligible for voluntary military service (2012)
Transportation :: Mexico
National air transport system (../docs/notesanddefs.html#377): This entry includes four subfields describing the air transport system of
a given country in terms of both structure and performance. The first subfield, number of registered air carriers, indicates the total
number of air carriers registered with the country''s national aviation authority and issued an air operator certificate as required by the
Convention on International Civil Aviation. The second subfield, inventory of registered aircraft operated by air carriers, lists the total
number .. . more (../docs/notesanddefs.html#377)
(.ields/377.htmi#MX)
number of registered air carriers: 21 (2015)
inventory of registered aircraft operated by air carriers: 357 (2015)
annual passenger traffic on registered air carriers: 45,560,063 (2015)
annual freight traffic on registered air carriers: 713,985,467 mt-km (2015)
Civil aircraft registration country code prefix (../docs/notesanddefs.html#378): This entry provides the one- or two-character
alphanumeric code indicating the nationality of civil aircraft. Article 20 of the Convention on International Civil Aviation (Chicago
Convention), signed in 1944, requires that all aircraft engaged in international air navigation bear appropriate nationality marks, The
aircraft registration number consists of two parts: a prefix consisting of a one- or two-character alphanumeric code indicating nationality
and a registration suffix of one to fi... more (../docs/notesanddefs.html#378)
(..fields/378.html#MX)
XA (2016)
Airports (../docs/notesanddefs.html#379): This entry gives the total number of airports or airfields recognizable from the air. The
runway(s) may be paved (concrete or asphalt surfaces) or unpaved (gr','3f4602db5aa5ed8009e7f578c5f9b726f8d6ac6eabfb2fb1b7b4bcf020770017','internet-archive','cia-readingroom-document-06979333','txt','984e0c045c9a468f2ff29ce97e446d2422bc468407fa988a05f7b591d54893f9','https://archive.org/download/cia-readingroom-document-06979333/06979333_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d0328c43461c8e456a6870074002ad6ba9c4b159ba5834505637947fba5b903',2022,'','','raw',5,'ass, earth, sand, or gravel surfaces) eng, may include closed or
$PORTETLICGGE FOUTS GERT4H TA VERtF4S LAOMCH PACES TEGRPS TATA
Approved for Release: 2022/12/08 C06979333
abandoned installations. Airports or ~**~''“~ that are no longer recognizable (overgrov''" ~~ “aciiues, ew; are Hot iGiuueY, ote iat
not all airports have accommodatio! Approved for Release: 2022/12/08 C06979333
(ey
(..fields/379.htmi#MX)
1,714 (2013)
country comparison to the world: 3 (../fields/379rank.html#MX)
Airports - with paved runways (../docs/notesanddefs.html#380): This entry gives the total number of airports with paved runways
(concrete or asphalt surfaces) by length. For airports with more than one runway, only the longest runway is included according to the
following five groups - (1) over 3,047 m (over 10,000 ft), (2) 2,438 to 3,047 m (8,000 to 10,000 ft), (3) 1,524 to 2,437 m (5,000 to 8,000
ft), (4) 914 to 1,523 m (3,000 to 5,000 ft), and (5) under 914 m (under 3,000 ft). Only airports with usable runways are included in this
listing. Not all... more (../docs/notesanddefs.html#380)
(../fields/380.html#MX)
total: 243 (2017)
over 3,047 m: 12 (2017)
2,438 to 3,047 m: 32 (2017)
1,524 to 2,437 m: 80 (2017)
914 to 1,523 m: 86 (2017)
under 914 m: 33 (2017)
Airports - with unpaved runways (../docs/notesanddefs.html#381): This entry gives the total number of airports with unpaved runways
(grass, dirt, sand, or gravel surfaces) by length. For airports with more than one runway, only the longest runway is included according
to the following five groups - (1) over 3,047 m (over 10,000 ft), (2) 2,438 to 3,047 m (8,000 to 10,000 ft), (3) 1,524 to 2,437 m (5,000 to
8,000 ft), (4) 914 to 1,523 m (3,000 to 5,000 ft), and (5) under 914 m (under 3,000 ft). Only airports with usable runways are included in
this listin. .. more (../docs/notesanddefs.html#381) :
P ;
(..ields/381 btmi#MX)
total: 1,471 (2013)
over 3,047 m: 1 (2013)
2,438 to 3,047 m: 1 (2013)
1,524 to 2,437 m: 42 (2013)
914 to 1,523 m: 281 (2013)
under 914 m: 1,146 (2013)
Heliports (../docs/notesanddefs.html#382): This entry gives the total number of heliports with hard-surface runways, helipads, or
landing areas that support routine sustained helicopter operations exclusively and have support facilities including one or more of the
following facilities: lighting, fuel, passenger handling, or maintenance. It includes former airports used exclusively for helicopter
operations but excludes heliports limited to day operations and natural clearings that could support helicopter landings and takeoffs.
rf.
(./fields/382.htmi#MX)
4 (2013)
Pipelines (../docs/notesanddefs.htmi#383): This entry gives the lengths and types of pipelines for transporting products like natural gas,
crude oil, or petroleum products.
15,986 km natural gas (2019), 10,365 km oil (2017), 8,946 km refined products (2016)
Railways (../docs/notesanddefs.html#384): This entry states the total route length of the railway network and of its component parts by
gauge, which is the measure of the distance between the inner sides of the load-bearing rails. The four typical types of gauges are:
broad, standard, narrow, and dual. Other gauges are listed under note. Same 60% of the world''s railways use the standard gauge of
1.4 m (4.7 ft). Gauges vary by country and sometimes within countries. The choice of gauge during initial construction was mainly in
resp... more (../docs/notesanddefs.html#384)
EN
(..fields/384,htmt#MX)
total: 20,825 km (2017)
standard gauge: 20,825 km 1.435-m gauge (27 km electrified) (2017)
country comparison to the world: 14 (../fields/384rank.himl#MX)
Roadways (../docs/notesanddefs.htmi#385): This entry gives the total length of the road network and includes the length of the paved
and unpaved portions.
ey :
(../fields/385.htmi#MX)
total: 398,148 km (2017) ;
paved: 174,911 km (includes 10,362 km of expressways) (2017)
unpaved: 223,237 km (2017)
country comparison to the world: 18 (../fields/385rank.himl#MX)
Waterways (../docs/notesanddefs.html#386): This entry gives the total length of navigable rivers, canals, and other inland bodies of
water. aad
(-ffields/386.htmi#MX)
2,900 km (navigable rivers and coastal canals mostly connected with ports on the country''s east coast) (2012)
country comparison to the world: 33 (../fields/386rank.himl#MX) oo ek ein Feet A aCe
Approved for Release: 2022/12/08 C06979333
Merchant marine (../docs/notesandd=f= #14387): This entry provides the total and tr ~~ er of eacn type OT privaleély or pupiicry
owned commercial ship for each co Approved for Release: 2022/12/08 C06979333!clude: bulk carrier - for cargo such as
coal, grain, cement, ores, and grave., u.....ner ship - for loads in truck-size containers, « «.1sportation system called containerization;
general cargo - also referred to as break-bulk containers - for a wide variety of packaged merchandise, such as textiles, furniture . ..
more (../docs/notesanddefs.html#387)
er
(..fields/387 htmi#MX)
total: 637
by type: bulk carrier 6, general cargo 10, oil tanker 35, other 586 (2019)
country comparison to the world: 35 (../fields/387 rank.html#MX)
Ports and terminals (../docs/notesanddefs.html#388): This entry lists major ports and terminals primarily on the basis of the amount of
cargo tonnage shipped through the facilities on an annual basis. in some instances, the number of containers handled or ship visits
were also considered. Most ports service multiple classes of vessels including bulk carriers (dry and liquid), break bulk cargoes (goods
loaded individually in bags, boxes, crates, or drums; sometimes palletized), containers, roll-on/roll-off, and passenger ships. The listing
le... more (../docs/notesanddefs.html#388) ,
(..Aields/388.htmlf#MX)
major seaport(s): Altamira, Coatzacoalcos, Lazaro Cardenas, Manzanillo, Veracruz
oil terminal(s): Cayo Arcas terminal, Dos Bocas terminal
cruise port(s): Cancun, Cozumel, Ensenada
container port(s) (TEUs): Manzanillo (2,830,370), Lazaro Cardenas (1,149,079) (2017)
LNG terminal(s) (import): Altamira, Ensenada
Transnational Issues :: Mexico
Disputes - international (../docs/notesanddefs.html#326): This entry includes a wide variety of situations that range from traditional
bilateral boundary disputes fo unilateral claims of one sort or another. Information regarding disputes over international terrestrial and
maritime boundaries has been reviewed by the US Department of State. References to other situations involving borders or frontiers
may also be included, such as resource disputes, geopolitical questions, or irredentist issues; however, inclusion does not necessarily
constitute .. . more (../docs/notesanddefs.html#326)
ir
abundant rainfall in recent years along much of the Mexico-US border region has ameliorated periodically strained water-sharing
arrangements; the US has intensified security measures to monitor and control legal and illegal personnel, transport, and commodities
across its border with Mexico; Mexico must deal with thousands of impoverished Guatemalans and other Central Americans who. cross
the porous border looking for work in Mexico and the US; Belize and Mexico are working to solve minor border demarcation
discrepancies arising from inaccuracies in the 1898 border treaty
Refugees and internally displaced persons (../docs/notesanddefs.htmi#327): This entry includes those persons residing in a country as
refugees, internally displaced persons (IDPs), or stateless persons. Each country''s refugee entry includes only countries of origin that
are the source of refugee populations of 5,000 or more. The definition of a refugee according to a UN Convention is "a person who is
outside his/her country of nationality or habitual residence; has a well-founded fear of persecution because of his/her race, religion,
nationality, membership in a . . . more (../docs/notesanddefs.html#327)
(../fields/327.html#MX)
refugees (country of origin): 5,155 (El Salvador) (2018); 73,494 (Venezuela) (economic and political crisis; includes Venezuelans who
have claimed asylum, are recognized as refugees, or have received alternative legal stay) (2020) ‘ ‘
IDPs: 345,000 (government''s quashing of Zapatista uprising in 1994 in eastern Chiapas Region; drug cartel violence and government''s
military response since 2007; violence between and within indigenous groups) (2019)
stateless persons: 13 (2018)
Illicit drugs (../docs/notesanddefs.html#329): This entry gives information on the five categories of illicit drugs - narcotics, stimulants,
depressants (sedatives), hallucinogens, and cannabis. These categories include many drugs legally produced and prescribed by
doctors as well as those illegally produced and sold outside of medical channels. Cannabis (Cannabis sativa) is the common hemp
plant, which provides hallucinogens with some sedative properties, and includes marijuana (pot, Acapulco gold, grass, reefer),
tetrahydroca . . . more (../docs/notesanddefs.html#329)
(../fields/329.html#MX)
major drug-producing and transit nation; Mexico is estimated to be the world''s third largest producer of opium with poppy cultivation in
2015 estimated to be 28,000 hectares yielding a potential production of 475 metric tons of raw opium; government conducts the largest
independent illicit-crop eradication program in the world; continues as the primary transshipment country for US-bound cocaine from
South America, with an estimated 95% of annual cocaine movements toward the US stopping in Mexico; major drug syndicates control
the majority of drug trafficking throughout the country; producer and distributor of ecstasy; significant money-laundering center; major
supplier of heroin and largest foreign supplier of marijuana and methamphetamine to the US market
Privacy (/about-cia/site-policies/#privacy-notice) Copyright (/about-cia/site-policies/#copy)
De wk A 8 RE Re EE et ek EP
Approved for Release: 2022/12/08 C06979333
Site Policies (/about-cia/site-policie-" *~ USA. cov (http:/Awww.ur 7 0")
Approved for Release: 2022/12/08 C06979333
FOIA (https:/Mwww.cia.govilibrary/r LINE. YUY UInparwy weer
NoFEAR Act (/about-cia/no-fear-act/) Inspector General (/offices-of-cia/inspector-general/)
Contact CIA Site Map (/sitemap.html)
KGOV :
(/open/)
GO TOP
eet A Sie EO 2 ae TEBEE-40 94
Approved for Release: 2022/12/08 C06979333','f8f59d909f413d90321c580dad2babfef6b3506d7b05ce1cfa2478468dfc27f9','internet-archive','cia-readingroom-document-06979333','txt','984e0c045c9a468f2ff29ce97e446d2422bc468407fa988a05f7b591d54893f9','https://archive.org/download/cia-readingroom-document-06979333/06979333_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f139d99b289de408ac0dfb81e9c58a3dd2fe9a2fed74160f156ad39bb9669350',2022,'','','raw',1,'CIA - The World Factbook, ; Caye tule
“Approved for Release: 2022/12/08 C06979323
Central Intelligence Agency
_ The Work of a Nation. The Center of Intelligence
“.) Search’
!
pee rr CPS ee ie en ea
Publication: :. ee-ts wee
‘ Ea ee ey Nba
SUD 2 BS yy? eae bc Be ad os De hia bee eee rat
banca ~ v ar ga :
THE WORLD FACTBOOK
4
ety
% = SELECT A COUNTRY OR LOCATION ---
+ SIEVE TENTLOW SANSVACT a Vi
ABOUT REFERENCES APPENDICES FAQs © CONTACT See nc
preaennovctyamsanaman ater te nn pee
CENTRAL AMERICA AND CARIBBEAN :: EL SALVADOR
PAGE LAST UPDATED ON DECEMBER 5, 2012
i rst
fx -“ vrew 1 PHOTO
b> OF EL SALVADOR
CLICK MAP TO ENLARGE | ''
EXPAND ALL | COLLAPS
intreduction :: EL SALVADOR','b85c68fd6d6530ebbc88f6861d12458aa1e28452082140d6101d8ffe36e8b443','internet-archive','cia-readingroom-document-06979328','txt','2e7c8b567acb97b4e4913dbdb2da073810c419b3e7f5cf81ed6ade91d1c3bd26','https://archive.org/download/cia-readingroom-document-06979328/06979328_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

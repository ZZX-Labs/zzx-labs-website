SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03fb316d0fbe592abb112b0ae391afe8d85afe08ba0f6f3cff66cb3c448720df',1994,'CO','Colombia','energy',962,'members — (117) Afghanistan, Albania, Algeria, Argentina, Armenia, Australia, Austria,
Bangladesh, Belarus, Belgium, Bolivia. Brazil, Bulgaria, Burma, Cambodia, Cameroon, Canada,
Chile, China, Colombia, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic,
Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Estonia, Ethiopia, Finiand, France.
Gabon, Germany, Ghana, Greece, Guatemala, Haiti, Holy See, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, North Korea, South
Korea, Kuwait, Lebanon, Liberia. Libya, Liechtenstein, Luxembourg, Madagascar, Malaysia,
Mali. Mauritius, Mexico, Monaco, Mongolia, Morocco, Namibia, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Norway. Pakistan, Panama, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania. Russia, Saudi Arabia, &negBl, Sierra Leone, Singapore. Slovakia. Slovenia, South
Africa, Spain, Sri Lanka, Sudan, Sweden, Switzerland, Syria, Tanzania, Thailand, Tunisia,
Turkey. Uganda, Ukraine, UAE, UK. US, Uruguay, Venezuela, Vietnam, Yugoslavia
(suspended), Zaire, Zambia, Zimbabwe
International Bank for Economic
Cooperation (IBEC)
was estabiished on 22 October 1963 to promote economic cooperation and development:
members were Bulgaria. Cuba. Czechoslovakia. East Germany, Hungary. Mongolia, Poland,
Romania, USSR, Vietnam; now it is a Russian bank with a new chatter
International Bank for Reconstruction
and Development (IBRD)
note — also known as the World Bank
established — 22 July 1944
effective — 27 December 1945
aim — UN specialized agency that initially
promoted economic rebuilding after World
! War 11 and now provides economic
development loans
members — (177) Afghanistan, Albania, Algeria. Angola, Antigua and Barbuda, Argentina,
Armenia, Australia, Austria. Azerbaijan, llte Bahamas, Bahrain, Bangladesh, Barbados, Belarus,
Belgium. Belize, Benin. Bhutan. Bolivia. Botswana. Brazil, Bulgaria, Burkina, Burma, Burundi.
Cambodia, Cameroon. Canada, Cape Verde. Central African Republic, (Thad, Chile, China,
Colombia, Comoros, Congo, Costa Rica, Cote d’Ivoire, Croatia, Cyprus, Czech Republic,
Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Estonia. Ethiopia, Fiji. Finland, France, Gabon, The Gambia. Georgia, Germany. Ghana,
Greece, Grenada, Guatemala, Guinea. Guinea-Bissau, Guyana, Haiti, Honduras, Hunga^,
Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia,
Libya, Lithuania, Luxembourg, Madagascar. Malawi, Malaysia, Maldives, Mali, Malta, Marshall
Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Mongolia,
Morocco, Mozambique, Namibia. Nepal. Netherlands, NZ, Nicaragua. Niger, Nigeria, Norway,
Oman, Pakistan, Panama, Papua New Guinea. Paraguay. Peru, Philippines, Poland, Portugal,
Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Sao Tome and Principe. Saudi Arabia, Senegal, Seychelles, Siern Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US,
Uruguay, Uzbekistan. Vanuatu, Venezuela, Vietnam, Western Samoa, Yemen, Yugoslavia
(suspended), Zaire, Zambia, Zimbabwe
International Chamber of Commerce
(ICC)
established — NA 1919
aim — to promote free trade and private
enterprise and to represent business interests
at national and international levels
members — (.59 national councils) Argentina. Australia, Austria, Belgium, Brazil, Burkina,
Cameroon. Canada, Colombia, Cote d''Ivoire, Cyprus, Denmark, Ecuador. Egypt, Finland,
France, Gabon. Germany, Greece. Iceland. India, Indonesia, Iran, Ireland, Israel, Italy, Japan,
Jordan, South Korea, Kuwait, Lebanon, Luxembourg, Madagascar, Mexico, Morocco,
Netherlands, Nigeria. Norway. Pakistan, Portugal. Saudi Arabia, Senegal, Singapore, South
Africa, Spain, Sri Lanka, Sweden, Switzerland. Syria, Taiwan, Togo, Tunisia, ''Itirkey, UK, US,
Uruguay, Venezuela, Yugoslavia, Zaire
International Civil Aviation Organiiatlon members — (181) Afghanistan. Albania. Algeria, Angola, Antigua and Barbuda, Argentina,
(ICAO) Armenia, Australia, Austria. Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus,
Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei,
esiahlished — 7 December 1944 Bulgaria, Burkina, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African
Republic, Chad, (Thile, China, Colombia, Comoros, Congo, Cook Islands, Costa Rica, Cote
effeciiw — 4 April 1947 d''Ivoire, Croatia. Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominican Republic.
Ecuador, Egypt, El Salvador, Equatorial Guinea, Estonia, Ethiopia, Fiji, Finland, France, Gabon,
aim — UN specialized agency to promote The Gambia, Gemiany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
international cooperation in civil aviation Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kazakhstan, Kenya, Kiribati. North Korea, South Korea, Kuwait, Kyrgyzstan,
Laos, Latvia, Lebanon, Lesotho, Liberia. Libya, Lithuania, Luxembourg, Madagascar, Malawi,
Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania. Mauritius, Mexico, Federated
States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru,
Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
Saint Lucia, Saint Vincent and the Grenadines, San Marino, Sao Tome and Principe, Saudi
Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia. Slovenia, Solomon Islands,
Somalia. South Africa (suspended), Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden,
Switzerland, Syria, Tanzania, The Former Yugoslav Republic of Macedonia, Thailand, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmeni.stan, Uganda, Ukraine, UAE, UK, US,
Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia (suspended), Zaire,
_ Zambia. Zimbabwe _
International Committee of the Red Cross members — (25 individuals) all Swiss nationals
(ICRC)
esuiblisheil — NA 1 863
aim — to provide humanitarian aid in wartime
International Confederation of Free TVade members — (164 national organizations in the following 117 areas) Antigua and Barbuda,
Unions (ICFTU) Argentina, Australia, Austria, The Bahamas, Bangladesh, Barbados, Ba.sque Country, Belgium.
Belize, Benin, Bermuda, Botswana, Brazil, Bulgaria, Burkina, Cameroon, Canada, Cape Verde,
esiahlished — NA December 1949 Chad, Chile. China, Colombia, Cook Islands. Costa Rica, Curacao, Cyprus, Czech Republic.
Denmark, Dominica, Dominican Republic, Ecuador, El Salvador, Estonia, Falkland Islands, Fqi,
to promote the trade union movement Finland, France, Gabon. The Gambia. Germany. Ghana, Greece, Grenada, Guatemala, Guyana,
Holy See. Honduras, Hong Kong, Iceland. India, Indonesia, Israel, Italy, Jamaica, Japan, Ken;^a.
Kiribati, .South Korea. Lebanon. Lesotho, Liberia, Lu.xembourg, Madagascar, Malawi, Malaysia,
Mali, Malta, Mauritius. Mexico, Montserrat, Morocco, Netherlands, New Caledonia, NZ,
Nicaragua, Norway, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland.
Portugal, Pueno Rico. Romania, Rwanda, Saint Helena. Saint Kitts and Nevis, Saint Lucia,
Saint Vincent and the Grenadines, San Marino, Senegal. Seychelles, Sierra Leone. Singapore,
Slovakia, Strain, Sri Lanka, Suriname, Swaziland, Sweden, Switzerland, Thailand. Togo, Tonga,
Trinidad and Tobago, Tunisia, Turke), Uganda, UK. US, Venezuela, Western Samoa, Zambia,
Bashi Channel
Pacific Ocean
Basilan Strait
Pacific Ocean
Bass Strait
Indian Ocean
Basse-Terre
Gaudeloupe
496
Name _
Basseterre
Batan Islands
Basutoland
Bavaria (Bayern)
Beagle Channel
Bear Island (Bjomoya)
Beaufort Sea
Bechuanaland
Beijing [US Embassy]
Beirut [US Embassy]
Belau
Belem [US Consular Agency]
Belep Islands (lies Belep)
Belfast [US Consulate General]
Belgian Congo
Belgrade [US Embassy; US does not maintain full
diplomatic relations with Serbia and Montenegro]
Belize City [US Embassy]
Belle Isle, Strait of
Bellingshausen Sea
Belmopan
Belorussia
Bengal, Bay of
Bering Sea
Bering Strait
Berkner Island
Berlin [US Branch Office]
Berlin, East
Berlin, West
Bern [US Embassy]
Bessarabia
Bijagos, Arquipelago das
Bikini Atoll
Bilbao [US Consulate]
Bioko
Biscay, Bay of
Bishkek [Interim Chancery]
Bishop Rock
Bismarck Archipelago
Bismarck Sea
Bissau [US Embassy]
Bjomoya (Bear Island)
Black Rock
Black Sea
Bloemfontein
Boa Vista
Bogota [US Embassy]
Bombay [US Consulate General]
Bonaire
Bonifacio, Strait of
Bonin Islands
Bonn [US Embassy]
Bophuthatswana
Bora-Bora
Bordeaux [US Consulate General]
Borneo
Bornholm
Bosporus
Bothnia. Gulf of
Bougainville Island
Entry in The World Factbook _
Atlantic Ocean
Falkland Islands (Islas Malvinas)
Paciflc Ocean','7db1b805bf127cc27e2bc8c2920eec093ff4aa5f6c06610e4d6b99641ccb09b4','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3a750e933ea3f0d8874e8ccfd1898404bcce95de77ab031c1a3eb8476752a49',1994,'ZW','Zimbabwe','energy',963,'members — ( 1 5 judges) elected by the UN General Assembly and Security Council to represent
all principal legal systems
International Court of Justice (ICJ)
iiaie — also known as the World Court
established — 26 June 1945
effective — 24 October 1945
aim — primary judicial organ of the UN
466
T
InternatioiiBl Criminal Police
Organbatlon (INTERPOL)
established — 1 3 June 1956
aim — to p''.omote international cooperation
between criminal police authorities
International Development Association
(IDA)
established — 26 January 1960
effective — 24 September 1960
aim — UN specialized agency and IBRD
affiliate that provides economic loans for
low income countries
International Energy Agency (lEA)
established — 15 November 1974
aim — established by the OECD to promote
cooperation on energy matters, especially
emergency oil sharing and relations between
oil consumers and oil producers
International Finance Corporation (IFC)
established — 25 May 1955
effective — 20 July 1956
aim — UN specialized agency and IBRD
affiliate that helps private enterprise sector in
economic development
members — (170) Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia,
Aruba, Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belgium,
Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina,
Burma. Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad,
Chile, China, Colombia, Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador. Egypt, Equatorial
Guinea, Estonia, Ethiopia, Fiji, Finland, France. Gabon, The Gambia. Germany, Ghana, Greece,
Grenada, Guatemala. Guinea. Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Ira(|, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati,
South Korea. Kuwait. Laos. Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania,
Luxembourg, Madagascar, Malawi, Malaysia. Maldives, Mali, Malta. Marshall Islands,
Mauritania, Mauritius, Mexico, Monaco, Mongolia, Morocco. Mozambique, Namibia, Nauru,
Nepal, Netherlands, Netherlands Anti''les, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Ponama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Sao Tome a .d Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone.
Singapore, Slovakia, Slovenia, Somalia, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden,
Switzerland, Syria, Tanzania, Thoiiand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Uganda, Ukraine, UAE, UK. US, Uruguay, Venezuela, Vietnam, Yemen, Yugoslavia, Zaire,
Zambia, Zimbabwe
subbureaus — (ID American Samoa, Anguilla, Bermuda, British Vimin Islands, Cayman Islands,
Gibraltar, Hong Kong, Macau, Montserrat, Puerto Rico. Turks and Caicos Islands
members — (156)
Part I — (24 more economically advanced countries) Australia, Austria, Belgium, Canada,
Denmark, Finland, France, Germany. Iceland, Ireland, Italy, Japan, Kuwait, Luxembourg,
Netherlands, NZ, Norway, Russia, South Africa. Sweden. Switzerland, UAE, UK, US
Part 11 — (132 less developed nations) Afghanistan, Albania. Algeria, Angola, Argentina,
Armenia, Bangladesh, Belize, Benin, Bhutan, Bolivia. Botswana. Brazil. Bulgarin, Burkina.
Burma, Burundi. Cambodia. Cameroon, Cape Verde. Central African Republic, Chad, Chile,
China, Colombia, Comoros. Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech Republic.
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Ethiopia, Fiji, Gabon, The Gambia, Georgia, Ghana. Greece, Grenada. Guatemala, Guinea,
Guinea-Bissau, Guyana. Haiti. Honduras, Hungary. India. Indonesia, Iran, Iraq. Israel, Jordan,
Kuzakhstun, Kenya, Kiribati. South Korea, Kyrgyzstan. Laos, Latvia, Lebanon, Lesotho, Liberia.
Libya, Madagascar. Malawi. Malaysia. Maldives. Mali, Marshall Islands, Mauritania, Mauritius,
Mexico. Federated States of Micronesia, Mongolia. Morocco, Mozambique, Nepal, Nicaragua.
Niger. Nigeria, Oman. Pakistan. Panama, Papua New Guinea, Paraguay, Peru. Philippines,
Poland, Portugal. Rwanda, Saint Kilts and Nevis. Saint Lucia, Saint Vincent and the Grenadines,
Sao Tome and Principe, Saudi Arabia, Senegal, Sierra Leone, Slovakia, Slovenia. Solomon
Islands, Somalia, Spain. Sri Lanka, Sudan, Swaziland, Syria. Tajikistan. Tanzania, Thailand.
Togo, Tonga, Trinidad and Tobago, Tunisia. Turkey, Uganda, Uzbekistan, Vanuatu, Vietnam,
Western Samoa, Yemen, Yugoslavia (suspended), Zaire, Zambia. Zimbabwe
members — (2.^) Au.stralia, Au.stria. Belgium, Canada, Denmark, Finland, France, Germany.
Greece, Ireland, Italy. Japan, Luxembourg. Netherlands, NZ, Norway, Portugal, Spain, Sweden,
Switzerland, Turkey, UK, US
members — (159) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina,
Australia, Austria. The Bahamas, Bangladesh, Barbados, Belarus. Belgium. Belize, Benin,
Bolivia, Botswana. Brazil. Bulgaria, Burkina, Burma. Burundi, Cameroon, Canada. Cape Verde.
Central African Republic, Chile, China, Colombia, Comoros, Congo, Costa Rica, Cote d’Ivoire,
Croatia, Cyprus, Czech Republic, Denmark. Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Estonia, Ethiopia, Fiji, Fiiiland. France. Gabon, The
Gambia, Germany, Ghana. Greece. Grenado. Guatemala, Guinea, Guinea-Bissau. Guyana, Haiti,
Honduras. Hungary, Iceland, India. Indonesia, Iran. Iraq, Ireland. Israel. Italy, Jamaica. Japan,
Jordan, Kazakhstan, Kenya. Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon,
Lesotho, Liberia, Libya. Luxembourg, Maduguscar. Malawi. Malaysia. Maldives, Mali, Marshall
Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Mongolia, Morocco,
Mozambique, Namibia, Nepal, Netherlands, NZ. Nicaragua, Niger. Nigeria. Norway, Oman,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland. Portugal, Romania,
Russia, Rwanda, Saint Lucia, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Slovakia, Siovenia. Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan,
Swaziland. Sweden. Switzerland, Syria, Tanzania, Thailand. Togo. Tonga. Trinidad and Tobago.
Tunisia, Turkey, Uganda, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Western Samoa, Yemen. Yugoslavia (suspended), Zaire, Zambia. Zimbabwe
467
members — ( ISO)
International Fund for Agricultural
Development (IFAD)
established— tiA November 1974
aim — UN specialiicd agency lhal promotes
agricultural development
“id contributors) Australia. Austria, Belgium, Canada, Denmark.
S Sw^dem''s?i™cri/nd urb? N^h''^onds. NZ. Noruay,
Category 11— (12 petroleum-exporting aid contributors) Algeria. Gabon.
Kuwait, Libya, Nigeria. Qatar, Saudi Arabia, UAE. Veneruela
Indonesia, Iran, Iraq,
International Investment Bank (IIB)
International Labor Organixation (ILO)
estab/isbed— II April 1919 (affiliated with
the UN 14 December 1946)
aim — UN specialized agency concerned with
world labor issues
International Maritime Organization
(IMO)
note — name changed fioni Inteigovemmental
Maritime Consultative Organization (IMCO)
on 22 May 1982
established— n March I9.S8
aim — UN specialized agency concerned with
world maritime affairs
Cwegory III— (117 aid recipients) Afghanistan, Albania, Angola, Antigua and Barbuda,
Argentina. Armenia, Bangladesh. Barbados, Belize. Benin, Bhutan, Bolivia, Botswana, Brazil,
Can’efoon- Cape Vetde, Central African Republic. Chad.
Chile, Cmnu. Coltmbin. Comoros. Congo. Cook Islands. Costa Rica. Cote d’Ivoire, Cuba
*'' CtominiMn Republic, Ecuador. Egypt. El Salvador. Equatorial
Guinea, ^hiopia, Fiji, The Gambia. Ghana, Grenada, Guatemala. Guinea, Guinea-Bissau
Guyana. Han. Honduras. India. Israel. Jamaica. Jordan. Kenya, North Korea, South Korea.
M Lesotho. Liberia. Madagascar, Malawi, Malaysia, Maldives, Mali,
Mauruius. Mexico, Morocco, Mozambique. Namibia. Nepal, Nicaragua.
Niger. Oman, Pakisun, Poiiama, Papua New Guinea, Paraguay, ftru, Philippines, Portugal.
Romania, ^anda. Saint Kitts and Nevis, Saint Lucia. Saint Vincent and the Grenadine^ Sao
Pnncipe. Senegal. SeycheHes. Sierra Leone. Solomon Islands, Somalia. Sri Lanka,
Sudan. Sunname, Swaziland. Syria. Tanzania, Thailand, Tbgo. Tonga. Trinidad and Tobago,
Zalre''^nibia^^tebwe^™*”''*^’ Samoa. Yemen, Yugoslavia (suspended).
established on 7 July 1970. to promote economic development; members were Bulgaria. Cuba
Czechoslovakia, East Germany. Hungary. Mongolia, Poland. Romania. USSR, Vietnam: now it
IS a Russian bank with a new charter
wem/»er.?-^169) Afghanistan, Albania. Algeria. Angola, Antigua and Barbuda. Areentina,
Q**,**™’^’ Austna. Azeibaijan. Tbc Bahamas. Bahrain. Bangladesh. Barbados. Belarus,
Belgium. Belize, ^nin. Bolivia. Bosnia and Herzegovina, Botswana. Brazil. Bulgaria, Burkina
Bunna Burundi. CamboAa. Cameroon. Canada, Cape Verde. Central African Republic. Chad, ’
Chile, China. Col^bia. Crmoros. Congo, Costa Rica. Cote d''Ivoire. Croatia. Cuba. Cyprus.
Czech Republic. Denma^, Djibouti. Dominica. Dominican Republic. Ecuador, Egypt, El
Salvador, ^uatonal Guinea. Eritrea. Estonia. Ethiopia. Fiji. Finland. France. Gofcn, Geoigia.
Germany, (uhana. Greece. Grenada. Guatemala. Guinea. Guinea-Bissau. Guyana. Haiti.
Hwdiiras. Hungary, Iceland. India. Indonesia. Iran. Iraq. Ireland. Israel. Italy. Jamaica, Japan.
Joidan, Kazakhstan, Kenya. South Korea. Kuwait. Kyrgyzstan. Laos. Latvia. Lebanon, Lesotho
Liberia, Libya. Lithuania. Luxembourg, Madagascar. Malawi. Malaysia. Mali, Malta
MiT''r ''u Mexico Moldova. Mongolia. Morocco. Mozambique. Namibia. Nepal,
Netherlands. NZ. l^caragua. Niger. Nigeria. Norway, Oman. Pakistan, Panama, Papua New
Guinea, Paraguay, ^ilippines. Poland, Portugal, (jatar, Romania, Russia, Rwanda. Saint
Lucia, San Manno, S.m Tonric and Principe, Saudi Arabia. Senegal. Seychelles. Sierra Leone,
SwfzK ’c T"''i"'' inlands Somalia. Spain. Sri Lanka. Sudan. Suriname.
TTlkn^ Syria Tanzania, The Former Yugoslav Republic of Macedonia,
mr lie iT ® Tobago, Tunisia. Turkey, Turkmenistan. Uganda. Ukraine, UAE,
Zambia ^m^we^***^''''***”'' ''^®"®**''**‘*’ Yemen, Yugoslavia (suspended), Zaire.
Alyeria, Angola. Antigua and Barbuda, Argentina, Australia, Austria.
The Bahamas, Bahrain, Bangladesh. Barbados, Belgium. Belize, Benin, Bolivia, Bosnia and
Herzegovina. Brazil. Brunei. Bulgiria. Burma. Cambodia. Cameroon, Canada. Cape Verde.
Chile, China, ColomNa Congo. Costa Rica, Cote d''Ivoire. Croatia, Cuba, Cyprus, Czech
Republic, Itenmark, Djibouti. Dominica, Dominican Republic. Ecuador. Egypt, El Salvador
Equatorial Guinea, Entrea. Estonia. Ethiopia, Fiji. Finland. France, Gabon. The Gambia
Geo^ia. Germany, Ghana, Greece, Guatemala. Guinea. Guinea-Bissau, Guyana. Haiti,
Honduras, Hungary. Iceland. India. Indonesia, Iran. Iraq, Ireland, Israel, Italy. Jamaica. Japan.
Jordan Kenya, North Korea. South Korea. Kuwait, Latvia. Lebanon, Liberia. Libya. ^
Luxembourg. Madagascar, Malawi. Malaysia, Maldives, Malta. Mauritania, Mauritius, Mexico.
Monaco. Morocco. Mozambique. Nepal, Netherlands, NZ, Nicaragua. Nigeria. Norway, Gman,
Pakistan, Panama, Papua New Guinea. Paraguay. Peru, Philippines, Poland, Portugal Qatar
Romania. Russia. Saint Lucia. Saint Vincent and the Grenadines. Sao Tome and Principe. Saudi
e „ Seychelles. .Sierra Leone. Singapore, Slovakia. Slovenia. Solomon Isl^ds.
Somalia. Spain, Sri Unka. Sudan. Suriname, Sweden. Switzerland, Syria. Tanzania. Thailand,
Titgo. Trinidad and Tobago. Tunisia. Turkey, Turkmenistan, UAE, UK, US, Uruguay Vanuatu
Venezuela. Vietnam, Yemen, Yugoslavia (suspended), Zaire ^
associate members — (2) Hong Kong. Macau
468
international Maritime Satellite i/irmArr.v— (69) Algeria, Argentina. Australia. Bahrain, Bclaru.s, Belgium. Brazil, Bulgaria.
Organliatlon (INMARSAT) Cameroon, Canada, Chile, China. Colombia, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Egypt, Finland. France. Gabon. Georgia, Germany, Greece, Iceland, India, Indonesia, Iran, Iraq,
esiahlished — 3 .September 1976 Israel. Italy, Japan, South Korea. Kuwait, Liberia, Malaysia. Malta. Mauritius, Monaco,
Mozambique, Netherlands, NZ. Nigeria, Norway, Oman, Pakistan, Panama, Peru, Philippines,
effective— July 1979 Poland, Portugal, Qatar, Romania, Russia. Saudi Arabia, Singapore, Slovakia Spain, Sri Lanka,
Sweden. Switzerland, Tunisia. Turkey, Ukraine, UAE, UK, US, Yugoslavia
tiim — to provide worldwide communications
for maritime shipping and other applications
International Monetary Fund (IMF) members — (179) Afghanistan, Albania, Alseria, Angola, Antigua and Barbuda, Argentina,
Armenia, .Australia, Austria, Azerbaijan. The Bahamas, Bahrain, Bangladesh, Barbados, Belarus,
esiahlished — 22 July 1944 Belgium, Belize. Benin, Bhutan, Bolivia, Botswana, Brazil, Bulgaria, Burkina, Burma, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China,
effective — 27 December 1945 Colombia, Comoros, Congo, Costa Rica, Cote d''Ivoire, Croatia. Cyprus, Czech Republic,
Denmark, Djibouti, Dominica. Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
trim — UN specialized agency concerned with Guinea, Estonia, Ethiopia, Fiji. Finland. France, Gabon, The Gambia, Georgia, Germany, Ghana,
world monetary stability ana economic Greece, Grenada, Guatemala, Guinea. Guinea-Bissau, Guyana, Haiti, Honduras, Hungary,
development Iceland. India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica. Japan, Jordan, Kazakhstan,
Kenya, Kiribati, South Korea. Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia,
Libya, Lithuania, Luxembourg, Madagascar, Malawi, Malaysia. Maldives, Mali, Malta. Marshall
Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia. Moldova, Mongolia,
Morocco, Mozambique, Namibia, Nepal, Netherlands. NZ. Nicaragua, Niger, Nigeria, Norway,
Oman. Pakistan, Panama, Papua New Guinea, Paraguay. Peru, Philippines, Poland, Portugal,
Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines. San Marino. Sao Tome and Principe, Saudi Arabia, Senegal. Seychelles, Sierra
Leone, Singapore, Slovakia. Slovenia. Solomon Islands, Somalia, South Africa, Spain. Sri
Lanka. Sudan. Suriname. Swaziland, Sweden, Switzerland, Syria. Tajikistan. Tanzanio. Thailand,
The Former Yugoslav Republic of Macedonia, Togo, Tonga. Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine. UAE. UK, US, Uruguay. Uzbekistan, Vanuatu,
Venezuela, Vietnam, Western Samoa, Yemen, Yugoslavia (suspended). Zaire, Zambia, Zimbabwe
ohsen-ers — (3) Holy See. North Korea, Monaco
memhirs — (184) Afghanistan, Albania, Algeria, American Samoa, Andorra. Angola, Antigua
and Barbuda, Argentina, Armenia. Aruba. Australia. Austria. Azerbaijan. The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belgium, Belize. Benin. Bermuda. Bhutan, Bolivia. Bosnia and
Herzegovina. Botswana. Brazil. British Virgin Islands. Brunei, Bulgaria, Burkina, Bumia,
Cameroon, Canada. Cayman Islands, Central African Republic. Chad, Chile, China, Colombia,
Congo, Cook Islands, (Tosta Rico. Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic,
Denmark, Djibouti, Dominican Republic. Ecuador. Egypt. El Salvador. Equatorial Guinea,
Estonia, Ethiopia. Fiji, Finland. France. Gabon, The Gambia. Georgia, Germany, Ghana, Greece,
Grenada, Guam, Guatemala, Guinea, Guyana. Haiti, Honduras. Hong Kong. Hungary. Iceland,
India. Indonesia. Iran. Iraq. Ireland. Israel, Italy, Jamaica, Japan. Jordon. Kazahkstan, Kenya,
North Korea, South Korea. Kuwait, Kyrgyzstan. Laos, Latvia, Lebanon. Lesotho, Liberia, Libya,
Liechtenstein. Lithuania, Luxembourg. Madagascar, Malawi. Malaysia, Maldives, Mali. Malta,
Mauritania, Mauritius, Mexico. Moldova, Monaco, Mongolia. Morocco, Mozambique. Namibia,
Nepal. Netherlands, Netherlands Antille,s, NZ, Nicaragua, Niger. Nigeria, Norway, Oman,
Pakistan, Panama, Papua New Guinea, Paraguay. Peru. Philippines. Poland, Portugal, Pueno
Rico, Qatar. Romania. Russia. Rwanda. Saint Vincent and the Grenadines, San Marino. Saudi
Arabia, Senegal, Seychelles. Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands,
Somalia. South Afric.i. Spain, Sri Lanka, Sudan. Suriname. Swar’.iland. Sweden. Switzerland,
Syria, Taiwan, Tajikistan, Tanzania. Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia.
Turkey, Turkmenistan. Uganda, Ukraine, UAE. UK, US, Uruguay, Uzbekistan, Vanuatu,
Venezuela, Vietnam, Virgin Islands. Western Samoa, Yemen, Yugoslavia, Zaire, Zambia,
members — (48) Angola, Argentina. Australia. Austria. Bangladesh, Belgium, Bolivia, Canada,
Chile. Colombia. Costa Rica, Cyprus. Denmark. Dominican Republic. Ecuador. Egypt. El
Salvador, Finland, F-''rance, Germany, Greece. Guatemala, Honduras, Hungary. Israel, Italy,
Kenya, South Korea. Luxembourg. Netherlands, Nicaragua, Norway, Pakistan, Panama,
Paraguay, Peru. Philippines, Poland, Portugal, Sri Lanka, Sweden, Switzerland. Thailand,
Uganda, US. Uruguay, Venezuela. Zambia
iihsencrs — (40) Albania. Belize, Brazil. Bulgaria. Cape Verde. Croatia. Czech Republic.
Federation of Ethnic Communities’ Council of Australia Inc., Ghana, Guinea-Bissau, Holy See,
India. Indonesia. Japan, Japan International Friendship and Welfare Foundation. Jordan. Latvia,
Malta. Mexico, Morocco, Namibia. NZ, Niwano Peace Foundation, Partnership with the
Children of the Third World, Presiding Bishop''s Fund for World Relief/Episcopal Church,
Refugee Council of Australia. Romania, Russia, San Marino, Sao Tome and lYincipe. Senegal,
Slovakia. Slovenia. Somalia, Spain, Turkey, UK, Vietnam, Yugoslavia. Zimbabwe
International Olympic Committee (IOC)
established— 23 ime 1894
tiim — to promote the Olympic ideals and
administer the Olympic games: 1994 Winter
Olympics in Lillehammer, Norway (12-27
February); 1996 Summer Olympics in
Atlanta, United States (20 July-4 August);
1998 Winter Olympics in Nagano, Japan
(date NA)
International Organization for Migration
(lOM)
established as Provisional Intergovernmental
Coi'',n,lttee for the Movement cf Migrants
from Europe; renamed Intergovernmental
Committee for European Migration (ICEM)
on I.*! November 1952; renamed
Intergovernmental Committee for Migration
llCM) in November 1980; current name
adopted 14 November 1989
established — 5 December 1951
aim — to facilitate orderly international
emigration and immigration
International Organization for
Standardization (ISO)
established — NA February 1947
aim — to promote the development of
international standards
members — (73 national standards organizations) Albania, Algeria, Argentina, Australia, Austria,
Bangladesh, Belgium, Brazil, Bulgaria, Canada, Chile, China, Colombia, Cuba, Cyprus, Czech
Republic, Denmark, Egypt, Ethiopia, Finland, France, Germany, Ghana, Greece, Hungary,
Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Kenya, North Korea,
South Korea, Libya, Malaysia, Mexico, Mongolia, Morocco, Netherlands, NZ, Norway,
Pakistan, Philippines, Poland, Ponugal, Romania, Russia, Saudi Arabia, Singapore, Slovakia,
South Africa, Spain, Sri Lanka, Sweden, Switzerland, Syria, Tanzania, Thailand, Trinidad and
Tobago, Tunisia, TXirkey, UK, US, Uruguay, Venezuela, Vietnam, Yugoslavia, Zimbabwe
International Red Cross and Red Crescent
Movement
established — NA 1928
correspondent members— (20) Bahrain, Barbados, Brunei, Estonia, Hong Kong, Jordan, Kuwait,
Lithuania, Madagascar, Malawi, Mali, Malta, Mauritius, Nepal, Oman, Papua New Guinea,
Peru, Seychelles, Uganda, UAE
members— (9) 2 representatives from ICRC, 2 from LORCS, and 5 from national societies
elected by the international conference of the International Red Cross and Red Crescent
Movement
aim — to promote worldwide humanitarian
aid through the International Committee of
the Red Cross (ICRC) in wartime, and
League of Red Cross and Red Crescent
Societies (LORCS) in peacetime _
International Telecommunication Union
(ITU)
established — 9 December 1932
effective — 1 January 1934
affiliated with the UN — 15 November 1947
aim — UN specialized agency concerned with
world telecommunications
International Telecommunications Satellite
Organization (INTELSAT)
established — 20 August 1 97 1
effective — 12 February 1973
aim — to develop and operate a global
commercial telecommunications satellite
system
members — ( 1 82) Afghanistan, Albania, Algeria, Angola. Antigua and Barbuda, Argentina,
Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus,
Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei,
Bulgaria, Burkina, Burma, Burundi. Cambodia. Cameroon, Canada, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Comoros, Congo, Costa Rica, Cote d’Ivoire, Croatia,
Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominican Republic, Ecuador, Egypt, El
Salvador, Equatori^ Guinea. Eritrea. Estonia, Ethiopia, Fiji, Finland, France, Gabon, The
Gambia, Georgia. Germany, Ghana, Greece, Grenada, Guatemala, Guinea. Guinea-Bissau,
Guyana, Haiti, Holy See, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland,
Israel. Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati. North Korea. South Korea,
Kuwait, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia,
Nauru. Nepal, Netherlands. NZ. Nicaragua, Niger, Nigeria. Norway, Oman. Pakistan. Panama.
Papua New Guinea, Paraguay, Peru, Philippines, Poland. Portugal, Qatar, Romania, Russia,
Rwanda, Saint Vincent and the Grenadines, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal. Sierra Leone. Singapore, Slovakia, Slovenia, Solomon Islands. Somalia, South Africa
(suspended), Spain, Sri Lanka, Sudan, Suriname. Swaziland, Sweden. Switzerland, Syria,
Tanzania, Thailand. The Former Yugoslav Republic of Macedonia, Togo, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda. Ukraine, UAE, UK, US. Uruguay,
Uzbekistan, Vanuatu. Venezuela, Vietnam. Western Samoa. Yemen. Yugoslavia (suspended),
Zaire, Zambia, Zimbabwe
members — (126) Afghanistan. Algeria. Angola, Argentina, Armenia, Australia, Austria,
Azerbaijan, The Bahamas, Bangladesh, Barbados, Belgium. Benin, Bhutan, Bolivia, Brazil,
Burkina, Cameroon. Canada. Cape Verde, Central African Republic, Chad. Chile, China,
Colombia, Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech Republic, Denmark,
Dominican Republic. Ecuador, Egypt. El Salvador, Ethiopia, Fiji, Finland, France, Gabon,
Germany, Ghana, Greece, Guatemala, Guinea, Haiti, Holy See. Hondur--..,, Iceland, India,
Indonesia, Iran, Iraq. Ireland. Israel, Italy. Jamaica. Japan, Jordan, Ke- >a. South Korea, Kuwait,
Lebanon, Libya, Liechtenstein, Luxembourg, Madagascar, Malawi, Niulaysia, Mali, Mauritania,
Mauritius, Mexico, Monaco. Morwco, Mozambique. Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Portugal, Qatar, Romania. Russia. Rwanda, Saudi Arabia, Senegal, Singapore, Somalia^ South
Africa, Spain, Sri Lanka. Sudan, Swaziland, Sweden, Switzerland, Syria, Tanzania, Thailand,
Togo, Trinidad and Tobago, Tunisia, Turkey. Uganda, UAE. UK. US, Uruguay, Venezuela,
Vietnam, Yemen, Yugoslavia, Zaire. Zambia, Zimbabwe
Islamic Development Bank (IDB)
established — 15 December 1973
aim — to promote Islamic econttmic aid and
social development
nonsignatory irieri— (56) Albania, Antigua and Barbuda, Bahrain. Belarus, Belize, Bosnia and
Herzegovina, Botswana. Brunei. Bulgaria. Burma. Burundi, Cambodia, Comoros, Cook Islands,
Cuba. Djibouti, Equatorial Guinea, Eritrea, Gambia, Guinea-Bissau, Guyana, Hungary,
Kazakhstan, Kiribati, North Korea. Laos. Latvia, Lesotho, Liberia, Lithuania, Maldives, Malta.
Marsha','bafbf74d1c152ca2c58ce724b351c38006a2e4ef05b6fa1d793d6d45bfac80ac','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39317fddf8aacb7e46a1a804a35f2dd73969552ecdd44428f55f637319bae470',1994,'ZW','Zimbabwe','energy',964,'ll Islands, Moldova, Mongolia, Namibia, Nauru, Niue, Poland, Sao Tome and Principe,
Seychelles, Sierra Leone, Slovakia, Slovenia, Solomon Islands, Saint Lucia, Saint Vincent and
the Grenadines, Suriname, Tajikistan, The Former Yugoslav Republic of Macedonia, Tonga,
Turkmenistan, Tuvalu. Ukraine. Vanuatu. Western Samoa
members— (Al plus the Palestine Liberation Organization) Afghanistan (suspended), Albania,
Ajgeria. Azerbaijan. Bahrain. Bangladesh, Benin. Brunei, Burkina, Cameroon, Chad. Comoros,
Djibouti, Egypt. Gabon, The Gambia, Guinea, Guinea-Bissau, Indonesia, Iran, Iraq, Jordan,
Kuwait, Kyrgyzstan, Lebanon, Libya, Malaysia, Maldives, Mali, Mauritania, Morocco, Niger,
Oman, Pakistan. Qatar, Saudi Arabia, Senegal. Sierra Leone, Somalia, Syria, Tajikistan, Tunisia.
Turkey, Turkmenistan. Uganda. UAE. Yemen. Palestine Liberation Organization
470
Latin American Economic System (LAES)
note — also known as Sistema Economico
Latinoamericana (SELA)
established — 17 October 1975
members — (27) Argentina, Barbados, Belize, Bolivia, Brazil, Chile, Colombia, Costa Rica,
Cuba, Dominican Republic, Ecuador, El Salvador, Grenada, Guatemala, Guyana, Haiti,
Honduras, Jamaica, Mexico, Nicaragua, Panama, Paraguay, Peru, Suriname, Tdnidad and
Tobago, Uruguay, Venezuela
aim — to promote economic and social
development through regional cooperation
Latin American Integration Association
(LAIA)
members — (11) Argentina, Bolivia, Brazil, Chile, Colombia, Ecuador, Mexico, Paraguay, Peru,
Uruguay, Venezuela
note — also known as Asociacion
Latinoamericana de Integracion (ALADI)
established — 12 August 1980
effective — 18 March 1981
aim — to promote fixer regional trade
observers — (16) Commission of the European Communities, Costa Rica, Cuba, Dominican
Republic, El Salvador. Guatemala. Honduras, Inter-American Development Bank, Italy,
Nicaragua, Organization of American States, Panama, Portugal, Spain, United Nations
Development Program, United Nations Economic Commission for Latin America and the
Caribbean
League of Arab States (LAS)
see Arab League (AL)
League of Red Cross and Red Crescent
SodeUes (LORCS)
established — 5 May 1919
aim — to provide humanitarian aid in
peacetime
members — (153) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina,
Australia, Austria, The Bahamas, Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin,
Bolivia, Botswana, Brazil, Bulgaria, Burkina, Burma, Burundi, Cambria, Cameroon, Canada,
Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Congo, Costa Rica, Cote
d’Ivoire, Cuba, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Ethiopia, Fiji. Finland, France, The Gambia, Germany, Ghana, Greece,
Grenada, Guatemala, Guinea, C^inea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Italy, Jamaica. Japan, Jordan, Kenya, North Korea, South Korea,
Kuwait, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg,
Madagascar. Malawi, Malaysia. Mali, Mauritania, Mauritius. Mexico, Monaco, Mongolia,
Morocco, Mozambique, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, San
Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Sierra Leone, Singapore, Slovakia,
Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Syria, Tanzania. Thailand. Togo, Tonga. Trinidad and Tobago, Tunisia,
Turkey, Uganda, UAE, UK, US, Uruguay, Venezuela, Vietnam, Western Samoa, Yemen,
Yugoslavia, Zaire, 2^mbia. Zimbabwe
associate members — (2) Equatorial Guinea. Gabon
least developed countries (LLDCs)
that subgroup of the less developed countries (LDCs) initially identified by the UN General
Assembly in 1971 as having no significant economic growth, per capita GNPs/GDPs normally
less than $1,000, and low literacy rates; also known as the undeveloped countries. The 42
LLDCs are: Afghanistan, Bangladesh, Benin, Bhutan. Botswana, Burkina. Burma, Burundi,
Cape Verde, Central African Republic. Chad, Comoros, Djibouti, Equatorial Guinea, Eritrea.
Ethiopia, The Gambia, Guinea, Guinea-Bissau, Haiti. Kiribati. Laos, Lesotho, Malawi, Maldives,
Mali. Mauritania. Mozambique, Nepal, Niger, Rwanda, Sao Tome and Principe, Sierra Leone,
Somalia, Sudan, Tanzania, Togo, Tuvalu, Uganda, Vanuatu, Western Samoa, Yemen
less developed countries (LDCs) the bouoin group in the comprehensive but mutually exclusive hieraa''hy of developed countries
(DCs), former USSR/Eastem Europe (former USSR/EE), and less developed countries (LDCs):
mainly countries with low levels of output, living standards, and technology; per capita
GNPs/GDPs are generally below SS.fKX) and often less than $l,.^00; however, the group also
includes a number of countries with high per capita incomes, areas of advanced technology, and
rapid rates of growth; includes the advanced developing countries, developing countries. Four
Dragons (Four Tigers), least developed countries (LLDCs). low-income countries,
middle-income countries, newly industrializing economies (NIEs), the South. Third World,
underdeveloped countries, undeveloped countries; the 174 LDCs are: Afghanistan, Algeria,
American Samoa, Angola. Anguilla. Antigua and Barbuda, Argentina. Aruba, The Bahamas.
Bahrain, Bangladesh, Barbados. Belize, Benin, Bhutan, Bolivia, Botswana. Brazil, British Virgin
Islands, Brunei, Burkina. Burma. Burundi, Cambodia. Cameroon, Cape Verde, Cayman Islands,
Central African Republic, Chad. Chile. China, Christmas Island. Cocos Islands. Colombia,
Comoros, Congo, (Took Lsland,s. Costa Rica. C''ote d''Ivoire. Cuba, Cyprus. Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea. Eritrea. Ethiopia,
Falkland Islands, Fiji. French Guiana, French Polynesia, Gabon. The Gambia, Gaza Strip,
Ghana. Gibraltar, Greenland, Grenada, Guadeloupe, Guam. Guatemala. Guern.sey, Guinea,
Guinea-Bissau, Guyana. Haiti. Honduras, Hong Kong, India, Indonesia. Iran, Iraq, Jamaica.
Jersey. Jordan, Kenya. Kiribati. North Korea. South Korea. Kuwait, Laos. Lebanon, Lesotho,
Liberia, Libya, Macau, Madagascar. Malawi, Malaysia, Maldives. Mali, Isle of Man, Marshall
Islands. Martinique. Mauritania, Mauritius. Mayotte Federated States of Micronesia. Mongolia,
Montserrat, Morocco, Mozambique, Namibia, Nauru. Nepal, Netherlands Antilles, New
Caledonia. Nicaragua. Niger. Nigeria, Niue. Norfolk Island, Northern Mariana Islands, Oman,
Trust Territory of the Pacific Isiands (Palau). Pakistan, Panama. Papua New Guinea, Paraguay.
Peru. Philippines, Pitcairn Islands, Puerto Rico. Qatar, Reunion, Rwanda. Saint Helena. Saint
Kitts and Nevis, Saint Lucia. Saint Pierre and Miquelon, Saint Vincent and the Grenadines, Sao
Tome and Principe. Saudi Arabia, Senegai. Seychelles. Sierra Leone. Singapore. Solomon
Islands, Somalia, Sri Lanka. Sudan. Suriname. Swaziland. Syria. Taiwan, Tanzania. Thailand,
Togo, Tokelau, Tonga. Trinidad and Tobago, Tunisia. Turks and Caicos Islands, Tuvalu, UAE.
Uganda. Uruguay. Vanuatu. Venezuela, Vietnam. Virgin Islands, Wallis and Futuna, West Bank.
Western Sahara, Western Samoa. Yemen. Zaire, Zambia, Zimbabwe
low-income countries
another temi for those less developed countries with below-average per capita GNP.s/GDPs: .see
less developed countries (LDCs)
London Suppliers Group
see Nuclear Suppliers Group (NSG)
Mercado Comun del Cono Sur
(MERCOSUR)
see Southern Cone Common Market
middle-income countries
another tertn for those less developed countries with ttbove-average per capita GNP.s/GDPs; see
le.ss developed countries (LDCs)
Missile Technology Control Regime
(MTCR)
members — (2,^) Argentina. Australia. Austria. Belgium, Canada, Denmark. Finland. France.
Germany. Greece, Hungary. Iceland, Ireland. Italy. Japan. Luxembourg, Netherlands, NZ.
Norway. Portugal. Spain, Sweden. Switzerland, UK. US
esluhlished — April 1987
aim — to arrest missile proliferation by
coniroliing the export of key missile
technologies and equipment
Near Abroad
the 14 non-Ru.ssian succe.ssor states of the USSR, in which 25 million ethnic Russians live and
in which Moscow has expressed a strong rational security interest
newly industrializing countries (MCs)
former term for the newly industrializing economies; see newly industrializing economies
(NIEs)
newly industrializing economies (NIEs)
that subgroup of the less develo|wd countries (LDCs) ''hat has experienced particularly rapid
industrialization of their economies; formerly known as the newly industrializing countries
(NlCs); also known as advanced developing countries: usually includes the Four Dragons (Hong
Kong, South Korea, Singapore. Taiwan) plus Brazil
472
Nonaligned Movement (NAM)
established — 1-6 September 1961
aim — to establish political and military
cooperation apart from the traditional East or
West blocs
members— i\\07 phis the Palestine Liberation Organization) Afghanistan. Algeria, Angola, The
Bahamas, Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Botswana, Brun''^i,
Burkina. Burma, Burundi. Cambodia, Cameroon. Cape Verde, Central African Republic, Chad,
Chile. Colombia. Comoros. Congo. Cote d’Ivoire, Cuba, Cyprus, Djibouti, Ecuador, Egypt,
Equatorial Guinea, Ethiopia, Gabon, The Gambia, Ghana, Grenac'' Guatemala, Guinea,
Guinea-Bissau, Guyana. India, Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya, North Korea,
Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya, Madagascar. Malawi, Malaysia, Maldives,
Mali, Malta, Mauritania, Mauritius. Mongolia, Morocco, Mozambique, Namibia, Nepal,
Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Peru, Philippines,
Qatar, Rwanda, Saint Lucia. Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra
Leone, Singapore, Somalia, Sri Lanka, Sudan, Suriname, Swaziland, Syria, Tanzania, Togo.
Trinidad and Tobago, Tunisia. Uganda, UAE. Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Yugoslavia, Zaire, Zambia, Zimbabwe, Palestine Liberation Organization
ohsen''ers — (2 1 ) African National Congress. Afro-Asian Solidarity Organization, Antigua and
Barbuda, Arab League. Armenia, Brazil, China, Co.sta Rica, Croatia, Dominica, El Salvador,
Islamic Conference. Kanaka Socialist National Liberation Front (New Caledonia), Mexico,
Mongolia. Organization of African Unity, Pan Africanist Congress of Azania, Sociali.st Party of
Puerto Rico, Thailand. UN, Uruguay
Nordic Council (NC)
established — 16 March 1952
guests — (21) Australia. Austria. Bosnia and Herzegovina. Bulgaria. Canada. Dominican
Republic, Finland. Germany, Greece. Hungary, Netherlands. NZ. Norway. Poland. Portugal,
Romania. San Marino. Slovenia. Spain. Sweden. Switzerland
members — (5) Denmark. Finland. Iceland, Norway. Sweden: note — Denmark includes Faroe
Islands and Greenland, and Finland includes Aland Islands
effective — 12 February 1953
aim — to promote regional economic,
cultural, and environmental cooperation
Nordic Investment Bank (NIB)
established — 4 December 1975
members — (5) Denmark (including Faroe Islands and Greenland), Finland (including Aland
Islands). Iceland. Norway. .Sweden
effective — I June 1976
aim — to promote economic cixiperation and
development _
North
North Atlantic Cooperation Council
(NACC) — an extension of NATO
established—^ November 1991
effective — 20 December 1991
a popular tenn for the rich industrialized countries generally located In the nonhem portion of
the Northern Hemisphere; the counterpart of the South; see developed countries (DCs)
members — (3K) Albania. Amtenia. Azerbaijan. Belarus. Belgium. Bulgaria. Canada, Czech
Republic. Denmark, listonia. l-rance. Georgia. Ciermany. Greece, Hungary. Iceland. Italy,
Kazakhstan, Kyrgyzstan. Latvia. Lithuania. Luxembourg. Moldova. Netherlands. Norway,
Poland. Portugal, Romania. Russia. .Slovakia. Spain. Tajikistan. Turkev. Turkmenistan. Ukraine.
UK. US, Uzbekistan
aim — to form a forum to discuss ctxiperution
concerning mutual political and security
issues _
North Atlantic TYeaty Organization members — ( 16) Belgium. Canada. IX''nmark. France, Gennany. CJreece. Iceland, Italy,
(NATO) '' Luxembxiurg, Netherlands, Nrtrway. Portugal, Spain. Turkey. UK, fiS
established — 17 September 1949
aim — to promote mutual defense and
cooperation _ _ _
Nuclear Energy Agency (NEA) members — (2.t) Australia. Austria. Belgium. Canada, IX''nmark. Finland. France. Germany,
Greece. Iceland. Ireland. Italy. Japan. Luxembourg. Netherlands. Norway. Portugal. Spain.
established — NA 1958 Sweden. Switzerland, Turkey. UK, US
aim — assix;iated with OECD, seeks to
promote the peaceful uses of nuclear energy
47.t
Nuclear Suppliers Group (NSG)
note — also known as the London Suppliers
Group
established — 1974
aim — to establish guidelines for exports of
technical information, processing equipment
for uranium enrichment and nuclear
materials to countries of proliferation
concern and regions of conflict and
instability _
Organismo para la Proscripcion de las
Armas Nucleares en la America Latina y
d Caribe (OPANAL) _
OrnmIaatloB for Economic Cooperalkm
and Devdopment (OECD)
established — 14 December I960
effective — 30 September 1961
aim — to promote economic cooperation and
development _
Organtaatioa of African Unity (OAU)
established — 25 May 1963
aim — to promote unity and cooperation
among African states
Organisation of American States (OAS)
established — 30 April 1948
effective — 13 December 1951
aim — to promote regional peace and security
as well as economic and social development
OrganiaatioB of Arab Petroleum
Exporting Countries (OAPEC)
established — 9 January 1968
aim — to promote cooperation in the
petroleum industry _
Organiiation of Eastern Caribbean States
(OECS)
members — (28) Australia, Austria, Belgium, Bulgaria, Canada, Czech Republic, Denmark,
Finland, France. Germany, Greece, Hungary, Ireland, luly, Japan. LuxemWirg, Netherlands,
Norway, Poland, Portugal, Romania, Russia, Slovakia, S^in, Sweden, Switzerland, UK, US
see Agency for the Prohibition of Nuclear Weapons in Latin America and the Caribbean
(OPANAL)
members — (25) Australia, Austria. Belgium, Canada, Denmark, Finland, France, Germany,
Greece, Iceland, Ireland. Italy, Japan, Luxembourg, Mexico, Netherlands, NZ, Norway, Ikrttugal,
Spain, Sweden, Switzerland. Tbrlcey. UK, US
special member — (1) EU
members— i52) Algeria. Angola. Benin. Botswana, Burkina, Burundi, Cartteroon. Cape Verde,
Central African Republic, C%ad, Comoros, Congo, Cote d''Ivoire, Djibouti, Egypt, Equatorial
Guinea. Eritrea, Ethiopia, Gabon. The Gambia. Ghana. Guinea. Guinea-Bismu, Kenya, Lesotho.
Liberia. Libya, Madagascar. Malawi. Mali, Mauritania. Mauritius, Mozambique. Namibia. Niger,
Nigeria. Rwanda. Sahrawi Arab Democratic Republic. Sao Tome and Principe. Senegal,
Seychelles. Sierra Leone, Somalia. Sudan, Swaziland, Tanzania, Togo. Tunisia, UgatMa. Zaire.
ZOTbia. Zimbabwe _
members — (35) Antigua and Barbuda. Argentina. The Bahamas. Barbados, Belize. Bolivia,
Brazil, Canada. CTiile. Colombia. Costa Rica, Cuba (excluded fhom formnl participation since
1962), Dominica. Dominican Republic. Ecuador. El Salvador. Grenada. Guatemala, Guyana.
Haiti. Honduras, Jamaica. Mexico. Nicaragua. Pananta. Paraguay. (Vrru. Saint Kitts and Nevis.
Saint Lucia, Saint Vincent and the Grenadines, Suriname. Tnnidad and Tobago. US, Uruguay.
Venezuela
ttbserwrs — (31) Algeria. Angola. Ausuia, Belgium. Central American Parliament. Cyprus.
Egypt. Equatorial Guinea. EU. Finland, France. Geimany, Greece, Holy See. Hungan. Inditu
Israel. Italy. Jam. South Korea, Morocco. Netheriands.''Pakistan, Poland. Portugiu, Romania.
Russia. Saudi Arabia. Spain. Switzerland, Tunisia _
members — (10) Algeria. Bahrain. Egypt, Iraq, Kuwait. Libya. (}aiar. Saudi Arabia. Syria. UAE
members — (7) Antigua and Barbuda. Dominica. Grenada. Montserrat, Saint Kitts and Nevis,
Saint Lucia. Saint Vincent and the Grenadines
established — 18 June 1981 assm-iaie member — (1) British Virgin Islands
effective — 4 July 1981
aim — to promote political, economic, and
defense cooperation _
Orgntiixalion of Petroleum Exporting members — (12) Algeria, Gabon, Indonesia, Iran, Iraq, Kuwait. Libya. Nigeria, (}atar. Saudi
Countrlei (OPEC) Arabia. UAE, Venezuela
established — 14 September 1960
aim — to coordinate petroleum policies
Organliation of the Islamic Conference
(QIC)
established — 22-25 September 1969
aim — to promote Islamic solidarity and
cooperation in economic, social, cultural,
and political affairs
members — (47 plus the Palestine Liberation Organization) Afghanistan (suspended), Albania,
AjMria, Azerbaijan, Bahrain, Bangladesh, Benin, Brunei, Bumna, Cameroon, Chad, Comoros,
Djibouti, Egypt, Gabon, The Gambia, Guinea, Guinea-Bissau, Indonesia, Iran, Iraq, Jor^,
Kuwait, K)|rgyzstan, Lebanon, Libya, Malaysia, Maldives, Mali, Mauritania, Morocco, Niger,
Oman, Pakistan, Qatar, Saudi Arabia, Senegal, Sierra Leone, Somalia, Syria, Thjikistan, Tunisia,
Turkey, Turkmenistan, Uganda, UAE, Yemen, Palestine Liberation Organization
observers — (4) Kazakhstan, Mozambique, Nigeria, "Turkish Republic of Northern Cyprus"
Paris Club
see Group of 10
Permanent Court of Arbitration (PCA)
established — 29 July 1899
aim — to facilitate the settlement of
international disputes
mem^rs — (78) Argentina, Australia, Austria, Belarus, Belgium, Bolivia. Brazil, Bulgaria,
Burkina, Cambodia, Cameroon, Canada, Chile, China, Colombia, Cuba, Czech Republic,
Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Fiji, Finland, France, Germany,
Greece, Guatemala, Haiti, Honduras, Hungary, Iceland, India, Iran, Iraq, Israel, Italy, Japn.
Jordan, Kyrgyzstan, Laos. Lebanon, Luxembourg. Malta, Mauritius, Mexico, Netherlands, NZ.
Nica^ua. Nigeria, Norway, Pakistan, Panama, nuaguay. Peru, Poland, Portugal. Romania,
Russia, Senegal, Slovakia, Spin, Sri Lanka, Sudan, Swaziland, Sweden. Switzerland, Thailand,
Turkey, Uganda, Ukraine. Uk. US. Uruguay, Venezuela, Yugoslavia, Zaire, Zimbabwe
Population Commission
members — (27) selected on a rotating basis from all regions
establi''^hed — 3 October 1946
aim — Economic and Social Council
organization dealing with poptilaiion matters
of importance to the UN
Rio Group (RG)
note — formerly known as Grupo de los
Ocho. established in December 1986
members — (II) Argentina. Bolivia, Brazil, Chile. Colombia. Ecuador. Mexico. Paraguay. Peru
(suspnded), Uruguay, Venezuela; note-Panama was explled in 1988; Peru was suspnided after
April 1992 coup
established — NA 1988
aim — a consultation mechanism on regional
Latin American issues
Second World
another term for the traditionally Marxist-Leninist states with authoritarian governments and
command economies based on the Soviet model; the term is fading from use: see centrally
planned economies
socialist countries
in general, t''ountries in which the government owns and plans the use of the major factors of
production: note — the term is sometimes used incorrectly as a symmym for Communist
counuies
South
a popular term for the poorer, less industrialized countries generally located south of the
developed countnes; the counterpart of the North; see less develop^ countries (LDCs)
South Asian Aaaocialian for Reghmal
Cooperadou (SAARCI
members — (7) Bangladesh, Bhutan. India. Maldives, Nepl. Pakistan, Sn Lanka
established — 8 December 1985
aim — to pnrnHMe economic, social, and
cultural cooperation
South Paciflc CommMon (SPC)
established — 6 February 1947
effective — 29 July 1948
members— {27) American Samoa. Australia, Cook Islands. Fiji. France. French Polynesia.
Guam. Kiribati. Marshall Islands, Federated States of Micronesia, Nauru, New Caledonia, NZ.
Niue, Northern Mariana Islands, Trust Territory of the Pacific Islands (Palaul. Papua New
Guinea. Pitcairn Islands, Solomon Islands, Tokelau. Tonga. Tuvalu. UK, US, Vanuatu, Wallis
and Futuna. Western Samoa
aim — to promote regional cooperation in
economic and social matters
South Pacific Forum (SPF)
estahlisbrd — 5 August 1971
members — ( 15) Australia. CcnA Islands. Fiji, Kiribati. Marshall Islands. Federated Slates of
Micronesia. Nauru. NZ. Niue, Papua New Guinea. Solomon Islands. Tonga. Tuvalu, Vanuatu,
Western Samoa
aim— to ptomoie regional cooperation in
political matters
obsener — ( 1 ) Trust Territory of the Pacific Islands (Palau)
South Pocidc RegiomI lyode ond
Economic Cooperation AgRcmcnt
(SPARTECA)
members — (IS) Australia, Cook Islands, pyi, Kiribati, Marshall Islands, Federated States of
Micronesia, Nauru, NZ, Niue, Papua New Guinea, Solomon Islands, Tonga, Tuvalu. Vanuatu,
Western Samoa
tstahlished—N^ 1981
aim — to redress unequal trade relationship of
Australia and New inland with small island
economies in Pacific region
Swthern AfHcan Customs Unloa (SACU)
established— \\ 1 December 1969
aim — to promote free trade and cooperation
in customs matters
members — (9) Bophuthatswana, Botswana, Ciskei, Lesotho, Namibia, South Africa, Swaziland,
Ttanskei, Venda
note — the US does not recognize the South African homelands of Bophuthatswana, Ciskei,
TYanskei, and Venda
Southern AfHcnn Development
Community (SADC)
members — (10) Angola. Botswana, Lesotho, Malawi, Mozambique, Namibia. Swaziland,
Tanzania, Zambia. Zimbabwe
note — evolved from the Southern African
Development Coordination Conference
(SADCC)
established — 17 August 1992
aim—\\o promote regional economic
developrnem and integration
Southern Cone Common Market
(MERCOSUR)
members — (4) Argentina. Brazil, Paraguay. Uruguay
estaMished — 26 March 1991
aim — regional economic cixiperatum
Statistical Commiaatan
members — (25) sele<''ted on a rotating basis from all regions
established— 21 June 1946
aim- -Economic and Social Council
ofgani/alion dealing with development and
standardization of national statistics of
interest to the UN
Ttrird World
another temi for the less developed countries; the term is fading from use; see less developed
ctainiries (LOCs)
refers to those less devekrped countries with the potential for above■a^e^age economic growth;
see less developed cswniries (LDCs)
undevcioped countries
refers to those extremely poor less develop^ countries (LDCs) with little prospect for economic
growth; see least develop^ countries (LLDCs)
Union Dnuanirrr ct Econonrique de
PAnrique Centrale (UDEACI
see Central African Customs and Economic Union (UDEAC)
Ml’mbers — (183 excluding Yugnsluviu) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua
and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Barbados, Beiaru.s, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil. Brunei, Bulgaria, Burkina, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile. China, Colombia.
Comoros. Congo, Costa Rica. Cote d''Ivoire, Croatia, Cuba, Cyprus. Czech Republic, Denmark.
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador. Equatorial Guinea,
Eritrea, Estonia, Ethiopia, Fiji. Finland. France. Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, North Korea, South Korea, Kuwait. Kyrgyzstan, Luos, Latvia, Lebanon. Lesotho,
Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Madagascar. Malawi, Malaysia, Nlaldives,
Moli. Malta, Marshall Islands, Mauritania, Mauritius. Mexico. Federated States of Micronesia,
Moldova, Monaco. Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Oman. Pakistan, Panama, Papua New Guinea, Paraguay,
Peru, ^ilippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines. Sun Marino. Sao Tome and l^ncipe, Saudi
Arabia, Senegal, Seychelles, Sierra Leone. Singapore, Slovakia,','52d9df3b037e111c8044057f166e5fb00754783dcfb578637557fe40f17f1de7','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6097eb3c55114cd90140613802e3cc80540c7a1f75065b07893d1d3c553ac637',1994,'ZW','Zimbabwe','energy',965,'Slovenia, Solomon Islands,
Somalia, South Africa, S|>ain, Sri Lanka, Sudan. Suriname, Swaziland, Sweden. Syria,
Tlijikistan, Tanzania, Ihailand, The Former Yugoslav Republic of Macedonia, Togo, Trinidad
and Tobago. Tunisia, Turkey. Turkmenistan, Uganda. Ukraine. UAE. UK. US. Uruguay.
Uzbekistan. Vanuatu. Venezuela. Vietnam, Western Samoa, Yemen, Yugoslavia (suspended),
Zaire. Zambia, Zimbabwe; note-all UN members are represented in the General Assembly
fihseivers — (2 plus the Palestine Liberaiion Organization) Holy See. Switzerland, Palestine
Liberation Organization
United Nalioas Angola Veriflcatlon memhers — (25) Algeria. Argentina. Brazil. Canada. Congo. Czech Republic, Egypt,
Mission (UNAVRM II) Guinea-Bissau, Hungary. India, Ireland. Jordan, Malaysia. Monaco. Netherlands. NZ. Nigeria,
Norway. Senegal, Singaprtn.''. Slovakia, Spain, Sweden, Yugoslavia, Zimbobwe
now — successor to original UNAVEM
20 December lUSg
aim — established by the UN Security
Crtuncil to verify the withdrawal of Cuban
tixHtps from Angola
United Nations CliiMrrn''s Fund memherv — (41 1 selected on a rotating basis fn>m all regions
(UNICEF)
nrrrc— acronym letaincd from the
predecessor organization I''N Imemuiional
Children''s EtiK''igency Fund
esiahlishfil — II December I •Mb
aim — to help establish child health and
welfare services
United Nations Conference on IVnde and wn-mAi-rs— ( KSTi all UN members plus Holy See, Swiizcrland. Tonga
Deveiopnient (UNCTAD)
fMahlishftt — .3(1 December 1964
aim -to promtUe international trade
Unit''^ Nations Dcvetonnient ProRnim niemhrr.s— (48r selected on a nwating basis fnriu all ragions
(UNDP)
fstahlisiwd — 22 Novenrber I*fft5
aim — to prrrvidc technical assistance (»»
siimiilate economic and stvial development
United Nations Disengattement Observer m^■m^H■r^ — (4) Austria. Canada. Finland. PoluntI
Force lUNDOF)
rmiW/vhrt/— .31 May 1974
aim — established by the UN .Security
s^ouncil to observe the IU7.3 Arab-lsraeli
ceasetin.''
United Nations (UN)
esiahlishtd — 26 June 1945
effective — 24 October 1945
aim — to maintain international peace and
security and to promote cooperation
involving economic, social, cultural and
humanitarian problems
477
memhtr.% — (178) AfghaniMan. Albania, Algeria. Angola, Antigua and Bafbuda, Argentina,
Armenia, Australia, Austria, Aierbaljan, Inc Bahamas, Bahrain. Bangladesh, Barbados, Belaru,s,
Belgium, Belize, Benin, Bhutan, Bolivia. Bosnia and Herzwvina, Botswana, Brazil, Bulgaria,
Buiaina, Burma, Burundi. Cambodia, Cameroon, Canada, Cape Vtordc, Central African
Republic. Chad, Chile, China. Colombia, Comoros, Congo, Cook Islands, Costa Rica, Cole
d''Ivoire, Croatia. Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, E.stonia, Ethiopia, Fyi,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece. Grenada. Guatemala,
Guinea, Guinea-Bissau, Guyana. Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq,
Ireland, Israel, Italy, Jamaica. Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South
Korea, Kuwait, Kvigyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya. Lithuania,
Luxembourg, Madagascar, Malawi, Malavsia, Maldives. Mali, Malta, Mauritania, Mauritius,
Mexico, Moldova, Monaco, Mongolia. Morocco, Mozambique, Namibia. Nepal, Netherlands,
NZ, Nicaragua, Niger. Nigerio. Norway, Oman, Pakistan, Panama, Papua New Guinea,
Paraguay. I%ru, Philippines, Poland. Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, San Marino, Sao Tbme and Principe,
Saudi Arabia, Senegal, Seychelles, Sierra Leone, Slovakia, Slovenia, Solomon Islands, Somalia,
Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden. Switzerland, Syria, Tajikistan,
Ihnzania, Thailand, The Former Yugoslav Republic of Macedonia, Togo, Tonga, Trinidad and
Tobago. Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, Uruguay, Venezuela,
Vietnam, Western Samoa, Yemen, Yugoslavia (suspended), Zaire, Zambia, Zimbabwe
wuMH''iau members — (3) Aruba, British Virgin Islands, Netheriands Antilles _
United Nations Environment Program members — (58) selected on a rotating basis from all regions
(UNEP)
established — 15 December 1972
aim — to promote international cooperation
on all environmental matters
United Nations Force In Cyprus members — (8) Australia, Austria, Canada, Denmark, Finland. Ireland, Sweden. UK
(UNFICYP)
established— ‘i March |9S4
urn— established by the UN Security
Council to serve as a peacekeeping force
between Greek Cypriots and Turkish
Cypriots in Cypnis _
United Nations General Assembly members — (184) all UN members are represented in the General Assembly
established — 26 June 1945
effective — 24 October 1945
aim — primary deliberative organ in the UN
United Nations Industrial Development
Organization (UNIDO)
established — 17 November 1966
effective — 1 January 1%7
aim — UN specialized agency that promotes
industrial development especially among the
members
members — (165) Afghanistan, Albania. Algeria, Angola, Argentina, Armenia, Australia. Austria,
The Bahamas, Bahrain. Bangladesh, Barbados, Belarus, Belgium. Belize, Benin, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria. Burkina. Burma, Burundi,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile. China, Colombia.
Comoros. Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador. Equatorial Guinea.
Ethiopia, Fiji, Finland, France. Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Grenada, Guatemala, Guinea. Guinea-Bissau. Guyana. Haiti, Honduras, Hungary, India,
Indonesia, Iran, Iraq, Ireland, Israel. Italy. Jamaica. Japan, Jordan, Kenya, North Korea, South
Korea, Kuwait, Kyrgyzstan. Laos, Latvia, Lebanon, Lesotho. Liberia. Libya, Luxembourg,
Madagascar. Malawi, Malaysia. Maldives, Mali, Malta, Mauritania. Mauritius, Mexico,
Moldova. Mongolia, Morocco, Mozambique, Namibia. Nepal, Netherlands, NZ, Nicaragua,
Niger. Nigeria, Norway. Oman, Pakistan. Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar. Romania, Russia, Rwanda. Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Sao Tome and Principe, Saudi Arabia, Senegal,
Seychelles. Sierra Leone. Slovakia, Slovenia. Somalia, Spain, Sri Lanka, Sudan. Suriname.
Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, The Former Yugoslav
Republic of Macedonia, Togo, Tonga. ''Trinidad and Tobago, Tunisia. ''Turkey, Uganda. Ukraine,
UAE, UK, US. Uruguay. Vanuatu, Venezuela, Vietnam. Yemen, Yugoslavia (suspended), Zaire,
Zambia, Zimbabwe
United Nations Educational, Scientific,
and Cultural Organiialion (UNESCO)
established— \\ft November 1945
effective— 4 November 1946
aim — to promote cooperation in education,
science, and culture
V
478
United Nattom Interim Force In Lebanon membrn— (10) Fhi, Finland, Prance, Ghana, Ireland, luly, Nepal, Norway, Poland, Sweden
(UNinL)
€siaMsfud~\\9 March 1978
olm— established by the UN Security
Council to confirm the withdrawal of Israeli
forces, restore peace, and reestablish
Lebanese authority in southern Lebanon
United Nations traq«Kuwatt Obaervatlon
Mhaion (UNIKOM)
eMblished—9 April 1991
members— <33) Argentina, Austria, Bangladesh, Canada, China, Denmark, Frii, Finland, Ftance,
Ghana, Greece, Hungary, India, Indonesia, Ireland, Italy, Kenya, Malaysia, Nigeria, Norway,
Pakistan, Poland, Romania, Russia, Senegal, f . tgapore, Sweden, Thailand, Turkey, UK, US,
Uruguay, Venezuela
aim— established by the UN Security
Council to observe and monitor the
demilitarized zone established between Iraq
and Kuwoit
United Nationi MHitary Obwrver Group
in India and Pakistan (UNMOGIP)
members — (8) Belgium, Chile, Denmark, Finland, Italy, Norway, Sweden, Uruguay
established — 13 August 1948
ai»»— established by the UN Security
Council to observe the 1949 India-f^kistan
ceasefire
United Nations Mission for the
Referendum in Western Sahara
(MINURSO)
members — (26) Argentina, Australia, Austria, Bangladesh, Belgium, Canada, China, Egypt,
France, Ghana, Greece, Guinea, Honduras, Ireland, Italy, Kenya, Malaysia, Nigeria, Pakistan,
Poland, Russia, Switzerland, ''fonisia, UK, US, Venezuela
established — 29 April 1991
aim — established by the UN Security
Council to supervise the referendum in
Hatay
Dirkey
Havana [US post not maintained; representation by US
Interests Section (USINT) of the Swiss Embassy]','8f0c79bfada3a1352491dadc4004ab91e2dac8c67aa79beb6b07a55594d470c4','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28b7dba8d751cd241877b623c193ead39e6f787b452d7d251c9ca44f4dc64d10',1994,'EH','Western Sahara','energy',966,'United Nations Ohserver Mission in El
Salvador (ONUSAL)
members — (16) Austria, Brazil, Canada. Chile, Colombia. Ecuador. Prance. Guyana, India.
Ireland, Italy, Mexico, Norway. Spain, Sweden, Venezuela
established — 20 May 1991
atm— established by the UN Security
Council to verify ceaserire arrangements and
to monitor the maintenance of public order
pending the otganization of a new National
Civil Police
United Nations Observer Mission in
Georgia (UNOMIG)
members — (10) Austria. Bangladesh, Czech Republic, Denmark. Germany, Greece, Poland,
Sierra Leone, Sweden, Switzerland
established — 1993 for a period of six
months
aim — to verify compliance with the
cease-fire agreement reached 27 July 1993
and investigate reports of violations of that
agreement
United Nations Observer Mission
Uganda-Rwanda (UNOMUR)
members — (10) Bangladesh, Botswana, Brazil, Canada. Fiji. Hungary, Netherlands. Senegal
Slovakia. Zimbabwe
established~\\993 for six months
aim — to monitor the Uganda/Rwanda border
to verify that no military assistance reaches
Rwanda across the border
United Nations Oflkt of the HMi
Commissioner tor Reto|ecs (UNHCRi
3 December 194*>
tffiH''ih''f — I January 1951
mrmherx — (4b) Alseria. Argentina. Australia. Austria, Belgium. Braril. Canada, China.
Colombia. Denmark. Ethiopia. Finland, Prance, Oermany, Oreece, Holy See, Hungary, irnn.
Israel. Italy, Japan, Lebanon, Lesotho. Madagascar, Morocco, Namibia, Netherlands. Nicaragua,
Nigeria, Norway, Pakistan, Philippines, Somalia, Sudan, Sweden. Switteriand. ''DuMania.
Thailand. Tunisia, Turkey, UganM, UK, US, Veitezuela, Yugoslavia, Zaire
aim — to tty to ensure the humanitarian
treatment of refugees and find permanent
solutions to refugee problems _
United Nations Operation In Moaamblqiic
(UNOMOZ)
esiahli.shrd — 16 December 1992
members — (18) Argentina, Bangladesh, Botswana. Brazil. Canada. Cape Verde, Czech Republic,
Egypt, Guinea-Bissau. Hungary, India, Malaysia. Portugal, Russia, Spain, Sweden, Uruguay,
Svalbard
Falkland Islands (Islas Malvinas)','49b3e9e4ee39cca844a7b50997b7244a23864d5b017dce9a7d4fb75344dcfc10','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9fe4a242b1a72bb0d1646c19fee462cd96bcc75fde48269871693234bc7a83de',1994,'ZM','Zambia','energy',967,'aim — established by the UN Security
Council to !iupervi.sc the ceasefire
United Nations Operation in Somalia members— Argentina, Australia. Bansladeslt, Belgium, Botswana, Egypt. Prance. Germany.
(UNOSOM) Greece, Hungary, India, Indonesia, Ireland, Italy, Jordan, South Korea, Malaysia, Ni‘>rocco,
Namibia, NZ, Nigeria. Norww. Pakistan, Romania, Saudi Arabia, Sweden, Tunisia. TUrkey,
estahlisheii—2''* April 1992 Uganda, UAE, US, Zambia. Zimbabwe
Mini— establi.shed by the UN Security
Council to facilitate an immediate cessation
of hostilities, to maintain a ceasefire in order
to promote a political settlement, and to
provide urgent humanitarian assistance _
United Nations Population Fund (UNFPA) members — (51) selected on a rotating basis from all regions
note — acronym retained from predecessor
organization UN Fund for PofAilation
Activities
established — NA July l%7
aim — to assist in both developed and
developing countries dealing with population
problems _ _
United Nations Protection Force members — (.34) Argentina, Australia. Bangladesh, Belgium. Brazil, Canada, Colombia, Czech
(UNPROFOR) Republic, Denmark, Egypt. Finland. France, Ghana, India, Ireland. Jordan. Kenya. Luxembourg,
Nepal, Netherlands, NZ, Nigeria, Norway, ^land, Portugal, Russia. Slovakia, Spain. Sweden.
eslablished~2i February 1992 Switzerland. Tunisia, Ukraine, UK, Venezuela
aim— established by the UN Security
Council to create conditions for peace and
security required for the negotiation of an
overall settlement of the "V^goslav" crisis _
United Nations Relief and Works Agency members — (10) Belgium. Egypt. France, Japan, Jordan, Lebanon, Syria, Turkey. UK, US
for Palestine Refugees in the Near E«t
(UNRWA)
established — 8 December 1949
aim — to provide assistance to Palestinian
refugees _
United Nations Secretariat
established — 26 June 1945
effective — 24 October 1945
aim — to serve as the primary administrative
organ of the UNt a Secretary General is
appointed for a five-year term by the
General Assembly on the recommendation
of the Security Council
480
United Nations Security Council pentumtni memhers — (3) China. France, Russia. UK. US
rstahlishitd — 26 June 1943 nonpemanent memherx — (10) elected for two>year terms by the UN Oenerel Assembly; Braeil
(1993-94). Cape Vbrde (1992-93), Djibouti (1993-94). Hungarv (1992-93), Japan (1992-93),
effiectixf—lA October 1945 Morocco (1992-93). NZ (1993-94). Pakistan (1993-94), Spain ) 1993-94). Veneeuela (1992-93)
aim — to maintain international peace and
security _
United NathMM Transitional Authority In
Cambodia (UNTAC)
established — 28 February 1992
aim — established by the UN Security
Council to contribute to the restoration and
maintenance of peace and to the holding of
free elections _
United Nations IVuce Supervision members — (19) Argentina. Australia, Austria, Belgium, Canada, Chile. China, Denmark,
Organisation (UNTSO) Finland, France, Ireland, Italy, Netherlands, NZ, Norway, Russia, Sweden, Switzerland, US
established — NA May i948
members — (43) Algeria, Amntina, Australia. Austria, Bangladesh, Belgium, Brunei, Bulgaria,
Cameroon. Canada, Chile, China, Colombia. Egypt, Fiji, Franc-, Germany, Ghana, Hungary,
India, Indonesia, Ireland. Italy. J^n. Jordan. Kenya. Malaysia, Morocco. Nepal, Netherlands,
NZ, Nigeria. Norway. Pakistan, Philippines, Poland, Russia, Senegal, Singapore, Sweden,
Thailand, Tunisia. UK. US, Uruguay
aim — initially e.stablished by the UN
Security Council to .supervise the 1948
Arah-lsroeli cea.serire and subsev,j .aily
extended to work in the Sinai. Lebanon.
Jordan. Afghanistan, and Pakistan _
United Nathms Trusteeship Council members — (5) China, France. Russia, UK. US
established — 26 June 1945
effective — 24 October 1945
aim — to supervi.se the administration of the
UN trust territories; only one of the original
i I tru.stoeships remaias — the Trust Temiory
of the Pacific Islands (Pahu) _
members — (185) Afghanistan, Albania. Algeria, Angola, Argentina, Armenia, Australia, Austria,
Azerbaijan, Tf,e Bahamas. Bahrain, Bangladesh, Barbados, Belarus, Belgium. Belize, Benin,
Bhutan. Bolivia, Bosnia and Herzegovina. Botswana, Brazil, Brunei. Bulgaria. Burkina. Burma,
Burundi, Cambodia. Cameroon. Canada, Cape Verde. Central African Rraublic, Chad, Chile.
China. Colombia. Comoros, Congo, Costa Rica, Cote dTvoiie, Croatia. Cuba, Cyprus, Czech
Republic, Denmark. Djibouti, Dominica, Dominican Republic, ^uador, Eg^, Fl Salvador,
Equatorial Guinea. Eritrea. Estonia, Ethiopia. Fiji. Finland. France, Gabon. The Gambia,
(jwigia, Germany, Ghana. Greece, Grenada. Guotemala, Guinea, Guinea-Bissau, Guyana, Haiti.
Holy See. Honduras. Hungary, Iceland. India. Indonesia, Iran, Iraq, Ireland, Israel. Italy.
Jamaica, Japan. Jordan. Kazakhstan, Kenya, Kiribati, Nonh Korea, South Korea, Kuwait.
Kyrgyzstan. Laos. Latvia. Lebanon, Lesotho, Liberia. Libya, Liechtenstein, Lithuania,
Luxembouig, Madagascar. Malawi, Malaysia. Maldives, Mali, Malta, Mauritania, Mauritius,
Mexico, Moldova. Monaco. Mongolia, Morocco, Mozambit^ue, Namibia. Nauru, Nepal.
Netherlands, Netherlands Antilles, NIZ, Nicaragua, Niger, Nigeria. Norway. Oman. (Overseas
Territories of the UK, Pakistan, Panama, Papua New Guinea, Paraguay, I^ru, Philippines,
Poland, Portugal. Qatar, Romania. Russia, Rwanda, Saint Kilts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, San Marino, Sao Tome and Principe. Saudi Arabia, Senegal.
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia. Solomon Islands, Somalia, Spain, Sri
Lanka. Sudan, Suriname, Swaziland, Sweden. Switzerland, Syria, Tanzania, Thailand. The
Former Yugoslav Republic of Macedonia. Togo, Tonga. Trinidad and Tobaga Tunisia, Tdrkey,
Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Vanuatu, Venezuela. Vietnam.
Western Samoa. Yemen. Yugoslavia (suspended), Zaire, Zambia. Zimbabwe _
Warsaw Pact (WP) was established 14 May 1955 to promote imitual defense: members met I July 1991 to dissolve
the alliance; member stales at the time of dissolution were Bulgaria. Czechoslovakia, Hungary.
_ Poland. Romania, and the USSR; earlier members included East Germany and Albania _
West ARican Development Bank (WADB) members — (7) Benin, Burkina. Cote d''Ivoire. Mali. Niger, Senegal. Togo
Universal Postal Union (UPU)
established — 9 October 1874, affiliuted with
the UN 15 November 1947
effective — 1 July 1948
<iim — UN specialized agency that promotes
iniemational postal cooperation
note — also known as Banque
Quest- Africaine de Developpement (BOAD)
established — 14 November 1973
aim — to promote regional economic
development and integration
West AfHcan E^nomlc Community members — (7) Benin, Burkina, Cote d’Ivoire, Mali, Mauritania, Niger, Senegal
(CEAO)
observers — (2) Guinea, Togo
note — acronym from Communaute
Economique de I’Afrique de I’Ouest
established — 3 June 1972
aim — to promote regional economic
development
Western European Union (WEU)
established — 23 October 1954
effective — 6 May 1955
aim — mutual defense and progressive
political unification
World Bank _ see International Bank for Reconstruction and Development (IBRD) _
World Bank Group includes International Bank for Reconstruction and Development (IBRD), International
_ Development Association (IDA), and International Finance Corporation (IFC) _
World Confederation of L4ibor (WCL)
established — 19 June 1920 as the
International Federation of Christian Trade
Unions (IFCTU), renamed 4 October 1968
aim — to promote the trade union movement
World Court _ see International Court of Justice (ICJ)
World Federation of Drade Unions
(WFTU)
established — 3 October 1945
aim — to promote the trade union movement
World Food Council (WFC)
members — (36) selected on a rotating basis from all regions
established — 17 December 1974
aim — ECOSOC organization that studies
world food problems and <ecomn-nds
solutions
World Food Program (WFP)
members — (42) selected on a rotating basis from all regions
established — 24 November 1961
aim — ECOSOC organization that provides
food aid to assist in development or disaster
relief
members— (i6) Afghanistan, Albania. Angola, Argentina, Australia. Austria, Bahrain,
Bangladesh, Benin, Bolivia, Brazil, Bulgaria. Burluna, Cambodia, (Thile, Colombia, Congo,
Costa Rica, Cuba, Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador, El
Salvador, Ethiopia, Finland, France, The Gambia, Greece, Guadeloupe, Guatemala,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, India, Indonesia, Iran, Iraq, Jamaica, Japan,
Jordan, North Korea, Kuwait, Laos, Lebanon, M^agascar, Martinique, Mauritius, Mexico,
Mongolia, Namibia, Nepal, New Caledonia, Nicaragua, Oman, Pakistan, Panama, Papua New
Guinea, Peru, Philippines, Poland, Puerto Rico, Reunion, Romania. Saint Pierre and Miquelon,
Saint Vincent and the Grenadines, Saudi Arabia, Senegal, Slovakia, Solomon Islands, South
Africa, Sri Lanka, Sudan. Sweden, Syria, Thailand, Trinidad and Tobago, Turkey, Uruguay,
Venezuela, Vietnam, Yemen, Zaire
members — (99 national organizations) Algeria, Angola, Antigua and Barbuda, Argentina, Aruba,
Austria, Bangladesh, Belgium, Belize, Benin, Bolivia, Bonaire Island. Botswana, Brazil,
Burkina, Cameroon, Canada, Cape Verde, Central Afirican Republic, Chad, Chile, Colombia,
Costa Rica, Cote d’Ivoire, Cuba, Curacao, Cyprus, Dominica, Dominican Republic, Ecuador, El
Salvador, France, French Guiana, Gabon, The Gambia, Ghana, Grenada, Guadeloupe,
Guatemala, Guinea, Guyana, Haiti, Honduras, Hong Kong, Indonesia, Iran, Italy, Jamaica,
Kenya, Lesotho, Liberia, Liechtenstein, Luxembou^, Madagascar, Malaysia, Mali, Malta,
Martinique, Mauritius, Mexico, Montserrat, Namibia, Netherlands, Nicaragua, Niger, Nigeria,
Pakistan, Panama, Paraguay, Peru, Philippines, Poland, Portugal, ^erto Rico, Romania,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Martin, Satnt Vincent and the Grenadines,
Senegal, Seychelles, Sierra Leone, Spain, Sri Lanka, Suriname, Switzerland, Taiwan, Tanzania,
Thailand, Togo, UK, US, Uruguay, Venezuela, Vietnam, Zaire, Zambia, Zimbabwe
members — (9) Belgium, France, Germany, Italy, Luxembourg, Netherlands, Portugal, Spain, UK
associate members — (4) Greece, Iceland, Norway, Turkey
observers — (2) Denmark, Ireland
World Health Organization (WHO)
established — 22 July 1946
effective — 7 April 1948
aim — UN specialized agency concerned with
health matters
World Intellectual Property Organization
(WIPO)
established — 14 July 1967
effective — 26 April 1970
aim — UN specialized agency concerned with
the protection of literary, artistic, and
scientillc works
World Meteorological Organization
(WMO)
established — II October 1947
effective—^ April 1951
aim — specialized UN agency concerned with
meteorological cooperation
members — (186) Afghanistan. Albania, Algeria, Angola, Antigua and Barbuda, Argentina,
Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus,
Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei,
Bulgaria. Burkina. Burma. Burundi. Cambodia. Catnenmn, Canada, Cape Verde, Central African
Republic, Chad, Chile, China. Colombia, Comoros, Congo, Cook Islands, Costa Rica, Cote
d''Ivoire, Croatia, Cuba. Cyprus. Czech Republic. Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador. Egypt. El Salvador, Equatorial Guinea. Estonia. Ethiopia. Fiji. Finland,
France, Gabon, The Gambia. Georgia. Germany. Ghana, Greece, Grenada, Guatemala. Guinea.
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia. Iran, Iraq, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea,
Kuwait, Kyrgyzstan, Laos, Latvia. Lebanon. Lesotho. Liberia, Libya. Lithuania. Luxembourg,
Madugu.scur. Malawi, Malaysia. Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius,
Mexico, Federated States of Micronesia. Moldova, Monaco, Mongolia, Morwco, Mozambique.
Namibia, Nepal, Netherlands, NZ, Nicaragua. Niger. Nigeria, Norway, (Jman, Pakistan, Panama,
Papua New Guinea, Paraguay, Peru. Philippines, Poland. Portugal, Qatar, Romania. Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Gtenadines, San Marino, Sao
Tome and Principe, Saudi Arabia, Senegal, Seychelles, SieiTU Leone, Singapore. Slovakia,
Slovenia. Solomon Islands, Somalia. South Africa, Spain, Sri Lanka. Sudan, S„iinume,
Swaziland, Sweden. Switzerland. Syria. Tajikistan. Tanzania. Thailand. The Former Yugoslav
Republic of Macedonia, Togo, Tonga. Trinidad and Tobago. Tunisia, Turkey, Turkmenistan,
Tuvalu. Uganda. Ukraine. UAE. UK. US. Uruguay, Uzbekistan. Vanuatu. Venezuela. Vietnam,
Western Samoa, Yemen. Yugoslavia (suspended), Zaire, Zambia, Zimbabwe
associate members — (2) Puerto Rico, Tokelau
members — (140) Albania. Algeria, Angola. Argentina. Armenia. Australia. Austria. Tlie
Bahamas. Bangladcst''. Barbados. Belarus, Belgium. Benin, Bolivia, Brazil, Bulgaria. Burkina,
Burundi, Cameroon, Canada. Central African Republic, Chad, Chile. China, Colombia. Congo.
Costa Rica. Cote d''Ivoire, Croatia. Cuba, Cyprus, Czech Republic, Denmark. Ecuador, Egypt.
El Salvador, Fiji, Finland, France, Gabon. The Gambia, Germany, Ghana, Greece, Guatemala,
Guinea, Guinea-Bissau, Haiti, Holy See. Honduras. Hungary, Iceland. India. Indonesia, Iran,
Iraq. Ireland. Israel, Italy, Jamaica. Japtm. Jordan. Kenya, North Korea. South Korea. Latvia.
Lebanon. Le.sotho, Liberia. Libya, Liechtenstein. Lithuania. Luxembourg, Madagascar. Malawi.
Malaysiii. Maldives. Mali. Malta. Mauritania. Mauritius, Mexico. Moldova, Monaco. Mongolia,
Morocco. Namibia. Netherlands, NZ. Nicaragua, Niger, Norway. Pakistan. Panama, Paraguay,
Peru. Philippines, Poland. Portugal, Qatar. Romania. Russia. Rwanda. Saint Lucia, Sun Marino,
Saudi Arabia. Senegal. Sierra Leone, Singapore. Slovakia, Slovenia, Somalia, South Africa,
Spain. Sri Lanka. Sudan. Suriname. Swaziland. Sweden. Switzerland. Syria. Tan/ania. Thailand.
The Former Yugoslav Republic of Macedonia, Togo. Trinidad and Tobago. Tunisia, Turkey,
Uganda, Ukraine, UAE. UK, US, Uruguay. Venezuela. Vietnam. Yemen. Yugoslavia
(suspended), Zaire. Ziimbia, Zimbabwe
members — (173) Afghanistan. Albania. Algeria. Angola. Antigua and Barbuda, Argentina.
Armenia, Australia, Austria, The Bahamas, Bahrain, Bangladesh. Barbados. Belarus. Belgium,
Belize, Benin. Bolivia, Botswana. Brazil. British Caribbean Territories, Brunei. Bulgaria,
Burkina, Burma, Burundi, Cambodia. Cameroon, Canada, Cape Verde. Central African
Republic. Chad. Chile, China. Colombia. Comoros. Congo. Costa Rica. Cote d''Ivoire, Croatia.
Cuba, Cyprus, Czech Republic. Denmark. Djibouti. Dominica. Dominican Republic, Ectiador,
Egypt. El Salvador, Eritrea. Estonia. Ethiopia. Fiji. Finland. France. French Polynesia. Gabon.
The Gambia. Germany. Ghana, Greece. Guatemala. Guinea, Guinea-Bissau. Guyana, Haiti,
Honduras. Hong Kong. Hungary. Iceland. India. Indonesia. Iran. Iraq. Ireland. Israel. Italy.
Jatnaica. Japan, Jordan, Kazakhstan, Kenya, North Korea, South Korea. Kuwait, Luos, Latvia,
Lcbution. Lesotho. IJberia. Libya. Lithuania. Luxemhourg. Madagascar. Malawi. Malaysia,
Maldives, Mali. Malta. Mauritania, Mauritius, Mexico, Mongolia, Morttcco, Mozambique,
Niitnihia. Nepal. Netherlands. Netherlands Antilles. New Caledonia. NZ. Nicaragua. Niger.
Nigeria, Norway, Oman. Pakistan. Panama, Papua New Guinea, Paraguay, Pent. Philippines,
Poland. Portugal, Qatar. Romania. Rassia. Rwanda. Saint Lucia. Sao Tome and Principe. Saudi
Arabia. Senegal, Seychelles. Sierra Leone, Singapore. Slovakia, Slovenia, Solomon Islands.
Somalia. South Africa (suspended). Spain. Sri Lanka. Sudan. Suriname. Swaziland. Sweden.
Switzerland, Syria, Tajikistan, Tanzania. Thailand. The Foitner Yugtrslav Republic of
Macedonia. Ttrgo. Trinidad and Tobago. Tunisia. Turkey. Turkmenistan. Uganda. Ukraine. UAE.
UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela. Vietnam. Yemen, Yugoslavia (suspended),
Zaire. Zambia. Zimbabwe
483
World Tourism Organization (WTO)
established — 2 January 1975
aim — to promote tourism as a means of
contributing to economic development,
international understanding, and peace
Zangger Committee (ZC)
established — early 1970s
aim — to establish guidelines for the export
control provisions of the nuclear
Non-Proliferation Treaty
members — ( 109) Afghanistan, Algeria, Anj^ola, ,^rgentina, Austria, Bangladesh, Belgium, Benin,
Bolivia, Brazil, Bulgaria. Burkina, Burundi, Cambria, Cameroon, Canada, Chad, Chile, China,
Colombia, Congo, Cote d''Ivoire, Cuba, Cypnis, Czech Republic, Dominican Republic, Ecuador,
Egypt, Ethiopia, Finland. France. Gabon, The Gambia, Germany, Ghana. Greece, Grenada,
Guinea, Guinea-Bissau, Haiti, Hungary, India, Indonesia, Iran, Iraq, Israel, Italy, Jamaica, Japan,
Jordan. Kenya, North Korea, South Korea, Kuwait, Laos. Lebanon, Lesotho, Libya. Madagascar,
Malawi. Malaysia. Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Mongolia. Morocco,
Nepal, Netherland.s, Nicaragua. Niger, Nigeria, Pakistan, Panama, Paraguay, Peru, Poland,
Portugal, Romania, Russia. Rwanda, San Marino, Sao Tome and Fhincipe, Senegal, Seychelles,
Sierra Leone, Slovakia, Spain, Sri Lanka, Sudan, Switzerland, Syria, Tanzania, Togo, Tunisia,
Turkey, Uganda, UAE, US, Uruguay, Venezuela. Vietnam, Yemen, Yugoslavia (suspended),
Zaire, Zambia, Zimbabwe
associate members — (4) Aruba, Macau, Netherlands Antilles, Puerto Rico
observer — (1) Holy See
members — (29) Australia. Austria. Belgium, Bulgaria, Canada. Czech Republic, Denmark,
Finland. France, Germany, Greece, Hungary. Ireland. Italy. Japan, Luxembourg, Netherlands.
Norway. Poland, Portugal. Romania, Russia, Slovakia. South Africa, Spain, Sweden,
Switzerland, UK, US
Appendix D:
AbbreviPtions for Selected International
Environmental Agreements
Air Pollution Convention on Long-Range Transboundary Air Pollution
Air Pollution-Nitrogen
Oxides
Convention on Long-Range Transboundary Air Pollution (Nitrogen
Oxides Protocol)
Air Pollution-Sulphur
Convention on Long Range Transboundary Air Pollution (Sulphur
Protocol)
Air Pollution- Volatile
Organic Compounds
Convention on Long-Range Transboundary Air Pollution (Volatile
Organic Compounds Protocol)
Antarctic-Environmental
Protocol
Protocol on Environmental Protection to the Antarctic Treaty
B
Biodiversity
Convention on Biological Diversity
C
Climate Change
United Nations Framework Convention on Climate Change
E
Endangered Species
Convention on the International Trade in Endangered Species
of Wild Flora and Fauna (CITES)
Environmental
Modification
Convention on the Prohibition of Military or Any Other Hostile
Use of Environmental Modification Techniques
H
Hazardous Wastes
Basel Convention on the Control of Transboundary Movements
of Hazardous Wastes and Their Disposal
L
Law of the Sea
United Nations Convention on the Law of the Sea (LOS)
M
Marine Dumping
Convention on the Prevention of Marine Pollution by Dumping
Wastes and Other Matter; note — also known as the London Conven¬
tion
Marine Life
Conservation
Convention on Fishing and Conservation of Living Resources of
the High Seas
N
Nuclear Test Ban
Treaty Banning Nuclear Weapons Tests in the Atmosphere, in
Outer Space, and Under Water
0
Ozone Layer Protection
Montreal Protocol on Substances That Deplete the Ozone Layer
s
Ship Pollution
International Convention for the Prevention of Pollution From Ships
(MARPOL)
''r
Tropical Timber
International Tropical Timber Agreement
w
Wetlands
Convention on Wetlands of International Importance Especially As
Waterfowl Habitat; note — also known as Ramsar
Whaling
International Convention for the Regulation of Whaling
1 Note: Not all of the selected international environmental agreements have abbreviations.
485
T
Appendix E:
Selected International
Environmental Agreements
Air Pollution
see Convention on Long-Range Transboundary Air Pollution
Air Pollution-Nitrogen Oxides
see Convention on Long-Range Transboundary Air Pollution (Nitrogen Oxides Protocol)
Air Pollution-Sulphur
see Convention on Long-Range Transboundary Air Pollution (Sulphur Protocol)
Air Pollution- Volatile Organic Compounds
see Convention on Long-Range Transboundaiy Air Pollution (Volatile Organic Compounds
Protocol)
Antarctic-Environmental Protocol
see Protocol on Environmental Protection to the Antarctic Treaty
Antarctic Tteaty
date opened for signature — 1959
objective — to ensure that Antarctica is used
for peaceful purposes, for international
cooperation in scientific research, and that it
does not become the scene or object of
international discord
parties — (42) Aigentina, Australia, Austria, Belgium, Brazil, Bulgaria, Canada, Chile, China,
Colombia, Cuba, Czech Republic. Denmark, Ecuador. Finland, France, Germany, Greece,
Guatemala, Hungary. India, Italy, Japan, North Korea, South Korea. Netherlands, New Zealand.
Norway, Papua New Guinea, Peru. Poland. Romania. Russia, Slovakia, South Africa, Spain,
Sweden, Switzerland, Ukraine. United Kingdom, United States, Uruguay
Basel Convention on the Control of
IVansboundary Movements of Hazardous
Wastes and Their Disposal
note — abbreviated as Hazardous Wastes
date opened for signature — 1989
objective — to reduce transboundary
movements of wastes subject to the
Convention to a minimum consistent with
the environmentally sound and efficient
management of such wastes; to minimize the
amount and toxicity of wastes generated and
ensure their environmenluily sound
management as closely as ^ssible to the
source of generation; and to assist LDCs in
environmentally sound management of the
hazardous and other wastes they generate
parties — (65) Antigua and Barbuda. Argentina, Australia, Austria, The Bahamas, Bahrain,
Bangladesh, Belgium, Brazil. Canada, Chile, China, Cyprus. Czech Republic, Denmark,
Ecuador, Egypt, El Salvador, Estonia, European Union, Finland, France, Hungary, India,
Indonesia, Iran, Ireland, Italy, Japan, Jordan. South Korea, Kuwait, Latvia, Liechtenstein,
Luxembourg. Malaysia. Maldives, Mauritius, Mexico, Monaco, Netherlands, Nigeria, Norway,
Panama, Peru, Philippines, Poland, Portugal, Romania, Saint Lucia, Saudi Arabia, Senegal,
Seychelles, Slovakia, Slovenia, Spain, Sri Lanka, Sweden, Switzerland, Syria, Tanzania,
Trinidad and Tobago, United Arab Emirates. United Kingdom. Uruguay
note— the following countries have signed, but not yet ratified the convention: Afghanistan,
Bolivia, Colombia. Germany. Greece, Guatemala, Haiti. Israel, Lebanon, New Zealand, Russia,
Thailand, Turkey, United Slates. Venezuela
Biodiversity
see Convention on Biological Diversity
Convention on Biological Diversity
note — abbreviated as Biodiversity
date opened for signature — 1992
objective — to develop national strategies for
the conservation and sustainable use of
biological diversity
parties — (53) Albania, Antigua and Barbuda, Armenia. Australia. The Bahamas, Barbados,
Belarus, Belize, Brazil, Burkina, Canada. China, Cook Islands. Cuba. Czech Republic, Denmark,
Ecuador. European Union, Fiji. Germany. Guinea. Hungary, India. Japan, Jordan, Malawi,
Maldives. Marshall Islands, Mauritius, Mexico, Monaco, Mongolia, Nauru, Nepal, New
Zealand, Norway. Papua New Guinea. Paraguay, Peru. Philippines, Portugal, Saint Kitts and
Nevis. Saint Lucia, ^ychelles, Spain. Sri Lanka, Sweden. Tunisia, Uganda, Uruguay, Vanuatu,
Western Samoa. Zambia
note — the following countries have signed, but not yet ratified the convention: Afghanistan.
Algeria, Angola, Argentina. Austria, Azerbaijan. Bahrain. Bangladesh, Belgium, Benin. Bhutan.
Bolivia. Botswana, Bulgaria. Burma. Burundi, Cameroon, Cape Verde, Central African
Republic, Chad, Chile, Colombia, Comoros. Congo Costa Rica. Cote d''Ivoire, Croatia, Cyprus,
Djibouti. Dominican Republic. Egypt, El Salvador, itstonia, Ethiopia, Finland, France, Gabon,
The Gambia, Ghana, Greece. Guatemala, Guinea-Bissau. Guyana. Haiti, Honduras, Iceland,
Indonesia. Iran. Ireland, Israel. Italy. Jamaica. Kazakhstan, Kenya, North Korea, South Korea,
Kuwait. Latvia, Lebanon. Lesotho, Liberia, Libya, Liechtenstein, Lithuania','fdbaa118c6dbaac0d14ed5dc55b1331209535e101b67a5776adf1c5970ddf3bb','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1bf99119340bede4b124ac0cb335c9232b11044a5276146d88db1ac3a0afd521',1994,'ZM','Zambia','energy',968,', Luxembourg.
Madagascar. Malaysia. Malta. Mauritania, Federated States of Micronesia, Moldova, Morocco.
Mozambique, Namibia, Netherlands. Nicaragua. Niger. Nigeria, Oman. Pakistan. Panama.
Poland, Qatar. Romania. Russia. Rwanda. San Marino, Sao Tome and Principe, Senegal,
Singapore. Slovakia. Slovenia, Solomon Islands, South Africa, Sudan, Suriname, Swaziland.
Switzerland. Syria. Tanzania, Thailand, Togo, Trinidad and Tobago. Turkey, Tuvalu, Ukraine,
United Arab Emirates, United Kingdom. United States. Venezuela, Vietnam. Yemen, former
Yugoslavia. Zaire. Zimbabwe
Climate Change
see United Nations Framework Convention on Climate Change
486
Convention on Fishing and Conservation
of Living Resources of the High Seas
note — abbreviated as Marine Life
Conservation
dare opened for signature — 1958
objective — to suive through international
cooperation the problems involved in the
conservation of living resources of the
high seas, considering that through the
development of modem techniques some of
these resources are in danger of being over
exploited
Convention on Long-Range
IVansboundary Air Pollution
note — abbreviated as Air Pollution
date opened for signature — 1979
objective — to protect the human environment
against air pollution and to gradually reduce
and prevent air pollution, including
long-range transboundary air pollution
Convention on Long-Range
IFansboundary Air Pollution
(Nitrogen Oxides Protocol)
note — abbreviated as Air Pollution-Nitrogen
Oxides
date opened for signature — 1988
objective — to provide for the control or
reduction of nitrogen oxides and their
transboundary fluxes
Convention on Long-Range
IVansboundary Air Pollution
(Sulphur Protocol)
note — abbreviated as Air Pollution-Sulphur
date opened for signature — 1985; a second
protocol to further reduce sulfur dioxide
emissions was completed in 1994
objective — to provide for a 30% reduction in
sulfur emissions or transboundary fluxes by
1993
Convention on Long-Range
Dransboundary Air Pollution
(Volatile Organic Compounds Protocol)
note — abbreviated as Air Pollution- Volatile
Organic Compounds
date opened for signature — 1991, but not yet
in force
objective — to provide for the control and
reduction of emissions of Volatile Organic
Compounds in order to reduce their
transboundary fluxes so as to protect human
health and the environment from adverse
effects
parties — (37) Australia, Belgium, Bosnia and Herzegovina, Burkina, Cambodia, Colombia,
Denmark, Dominican Republic, Fiji, Finland, France, Haiti, Jamaica, Kenya, Lesotho,
Madagascar, Malawi, Malaysia, Mauritius, Mexico, Netherlands, Iberia, Portugal, Senegal,
Sierra Leone, Solomon Islands, South Africa. Spain, Switzerland, Thailand, Tonga, Trinidad and
Tobago. Uganda. United Kingdom. United States, Venezuela, former Yugoslavia
note — the following countries have signed, but not yet ratified the convention: Afghanistan,
Argentina, Bolivia, Costa Rica, Cuba. Ghana. Iceland, Indonesia. Iran, Ireland, Israel. Lebanon,
Liberia, Nepal, New Zealand, Pakistan, Panama, Sri Lanka. Taiwan (Canada signed on behalf of
Taiwan). Tunisia. Uruguay
parties — (38) Austria. Belarus, Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia,
Cyprus, Czech Republic, Denmark. European Union. Finland, France, Germany, Greece,
Hungary, Iceland. Ireland. Italy. Liechtenstein. Lithuania, Luxembourg, Netherlands, Norway,
Poland, Portugal, Romania. Russia, Slovakia. Slovenia, Spain, Sweden, Switzerland, Turkey,
Ukraine, United Kingdom. United States, former Yugoslavia
note — the following countries have signed, but not yet ratified the convention: Holy See. San
Marino
parties — (23) Austria. Belarus. Bulgaria, Canada. Czech Republic, Denmark, European Union.
Finland, France, Germany. Hungary. Italy, Liechtenstein. Luxembourg. Netherlands, Norway,
Russia. Slovakia, Sweden. Switzerland. Ukraine, United Kingdom, United States
note — the following countries have signed, but not yet ratified the convention: Belgium. Greece,
Ireland. Poland, Spain
parties — (2 1 ) Austria. Belarus, Belgium, Bulgaria. Canada, Czech Republic. Denmark, Finland,
France, Germany, Hungary, Italy, Liechtenstein, Luxembourg, Netherlands. Norway. Russia.
Slovakia, Sweden, Switzerland. Ukraine
parties — (8) Finland. Liechtenstein, Luxembourg, Netherlands, Norway, Spain, Sweden,
Endangered Species
see Convention on the International Trade in Endangered Species of Wild Flora and Fauna
(CITES)
Environmental Modification
see Convention on the Prohibition of Military or Any Other Hostile Use of Environmental
Mixlification Techniques
Hazardous Wastes
see Basel Convention on the Control of Transboundary Movements of Hazardous Wastes and
Their Disposal
18
Coiivcntlon for the
Prevenlhm of Polhitlon From Ships
(MARPOL)
note — uhhrevittied as Ship Pollulion
ftiite opened for xiynature — I97.V7H
ohjeetive — to preserve the marine
environment by achieving the complete
elimination of pollution hy nil and other
harmful substances and thic minimisation
of accidental discharge of such substances
IHirtiex — (8.1) Algeria, Antigua and Barbuda, Argentina. Australia. Austria, The Bahamas,
Belgium. Bni/.il, Brunei, Bulgaria, Burma, Canada, China, Colombia, Cote d''Ivoire, (''roatia,
Culw, Cyprus, Czech Republic. Denmark, Djibouti, Ecuador, Egypt, Estonia, Finland. France,
Gabon, Gambia, Germany, Ghana, Greece, Hungary, Iceland, India, Indonesia, Israel, Italy,
Jamaica, Japan, Kenya, North Kraea, South Korea, Latvia, Lebanon, Liberia. Lithuania,
Luxembourg, Malta, Marshall Islands, Mexico, Monaco, Morocco, Netherlands, Norway, Oman,
Panama, Papua New Guinea, i^ru, Poland. Portugal, Romania, Russia, Saint Vincent and the
Grenadines, Seychelles, Singapore. Slovenia, South Africa, Spain, Suriname, Sweden.
Switzerland, Syria, Togo, Tunisia, Turkey, Tuvalu. Ukraine, United Kingdom, United Stales,
Uruguay. Vanuatu, Vietnam, former Yugoslavia
Intematioiiai Convcntloii for the
Regulation of Whaling
note — abbreviated as Whaling
dote opened for xiffnotiire — r* *6
IHirtiex — (.J9) Antigua and Barbuda. Argentina. Australia. Belize. Brazil, Chile. China. Costa
Rica, Denmark, Egypt, Finland. France, Germany. India, Ireland, Japan, Kenya, South Korea,
Mauritius, Mexico, Monaco. Netherlands, Netherlands Antilles, New Zealand, Norway, Oman,
Peru, Philippines, Saint Lucia, Saint Vincent and the Grenadines, Senegal, Seychelles, Solomon
Islands, South Africa. Spain. Sweden, Switzerland, United Kingdom. United States
ohjeetive — to protect all species of whales
from overfishing and safeguard for future
generations the great natural resources
represented hy whale slocks; to establish a
system of international regulation for the
whale fisheries to ensure proper conservation
and development of whale sim''ks
International IVopkal TImher Agreement
note — abbreviated as Tntpical Timber
dote opened for siitnotuie — 198.t; a new
agreement was opened for signature in 1994.
but is not yet in force
ohjeetive — to provide an effective framework
for ciHiperalion between tn>pical limber
producers and consumers and to encourage
the development of national policies aimed
at sustainable utilisation and conservation of
Inrpical forests and their genetic resouives
portiex — (4.^) Australia, Austria. Belgium, Burma. Cameroon, Canada, China, Colombia.
Congo, Denmark, Ecuador. Egypt, Finland. France. Gabon. Germany. Ghana. Greece, Guyana.
India. Indonesia, Ireland. Italy. Japan. South Korea, Liberia, Luxembourg, Malaysia, Nepal,
Netherlands, New Zealand. Norway. Panama. Papua New Guinea. Portugal. Russia. Spain.
Sweden. Switzerland, Thailand Togo. Trinidad and Tobago. United Kingdom. United States.
Zaire
note — the following countries have signed, hut not yet ratified the agreement: Bolivia. Brazil.
Cote d''Ivoire, European Union, Honduras. Peru. Philippin''".
L4IW of the Sea
see United Nations Convention on the Law of the Sea (LOS)
Marine Dumping
see Convention on the Prevention of Murine Pollution by Dumping Wastes and Other Matter
(London Convention)
Marine Life Conservation
see Convention on Fishing and Conservation of Living Resources of the High Seas
Montreal Protocol on Substances That
Deplete the Ozone Layer
Mote— abbreviated us O/one Layer
Protection
ilote opened for xigtuiture — 1987
ohjeetive — to protect the o/onc layer by
taking precautionary measures lo control
emissions of substances that deplete it
IHirtiex — ( I.Jb) Algeria, .Antigua and Barbuda, Argentina. Australia. Austria. The Bahamas.
Bahrain. Bangladesh, Barbados. Belarus. Belgium. Benin, Bosnia and Herzegovina, Botswana,
Brazil, Brunei, Bulgaria. Burkina. Burma. Cameroon. Canada. Central African Republic. Chile.
China. Colombia, Costa Rica, Cote d’Ivoire, Croatia. Cuba. Cyprus, Czech Republic, Denmark,
I^iminica. Dominican Republic, Ecuador, Egypt. El Salvador, European Union. Fiji. Finland.
France, Gabon, The Gambia. Germany. Ghana. Greece, Grenada, Guatemala, Guinea, Guyana,
flonduras. Hungary. Iceland. India. Indonesia, Iran. Ireland. Israel. Italy, Jan ica. Japan. Jordan.
Kenya, Kiribati, South Korea, Kuwait. Lebanon, Lesotho. Libya, Liechtenstein, Luxembourg,
Macau. Malawi. Malay.sia. Maldives. Malta, Marshall Islands. Mauritius. Mexico. Monaco.
Namibia, Netherlands, New Zealand, Nicaragua, Niger, Nigeria, Norway, Panama, Papua New
Guinea, Peru. Philippines. Poland, Portugal. Romania. Russia. Saint Kins and Nevis, Saint
Lucia. Saudi Arabia. Senegal. Seychelles. Singapore. Slovakia, Slovenia, Solomon Islands,
South Africa, Spain, Sri Lanka, Sudan. Sweden. Switzerland. Syria. Tanzania. Thailand. The
Former Yugoslav Republic of Macedonia, Togo, Trinidad and Tobago, Tunisia. Turkey,
Turkmenistan, Tuvalu, Uganda. Ukraine. United Arab Emirates, United Kingdom. United States.
Uruguay. Uzbekistan, Venezuela, Vietnam, Zambia
note — the following countries have signed, but not yet ratified the protixiol; Congo, Morixtco
Nuclear Ibst Ban
sec Treaty Banning Nuclear Weapons Tests in the Atmosphere, in Outer Space, ap.d Under
Water
Ozone Layer Protection
see Montreal PtoukoI on Substances that Deplete the Ozone Layer
489
rralocoi on Environmental Protection
to the Antarctic IVca^
note — obbreviated as
Aniarciic''Enviroiimemal Protocol
datf openn! for signature — 1991, but not
yet in force
objective — to enhance the protection of the
Antaiytic environment and dependent and
associated ecosystems
Ship PoHution
lycnty Banatim Nudeiir Weapon Ihsts
in the Atmoapiiere, In Outer Space, and
Under Water
note — abbreviated as Nuclear Test 3an
date opened for signature — 196.1
objective—io obtain an agreement on
general and complete disarmament under
strict international control in accordance
with the objectives of the United Nations:
to put an end to the armaments race and
eliminate incentives for the production and
testing of all kinds of weapons, including
nuclear weapons _
Tropical Timber _
United Nations Convention on the Law of
the Sea (LOS)
note — abbreviated as Law of the Sea
date opened for signature — 1982. but not vet
in force
objective— to set up a comprehensive new
legal regime fur the sea and oceans and,
as far as environmental provisions are
concerned, to establish material rules
concerning environmental standards as
well as enforcement provisions dealing
with pollution of the marine environment
pantes —(9) Aigentin. Australia, Ecuador, France, Nelhertands, Norway, Pcni, Spain, Sweden
note —the following countries have signed, but not yet ratified the protocol: Austria, Belgium,
Brazil, Bulgaria. Canada. Chile. China. Colombia, Cuba. Czech Republic, Denmark, Finland,
Germany, Greece, Guatemala, Hungary. India, Italy. Japan, North Korea, South Korea, New
Zealand, Papua New Guinea, Poland, Romania. Russia, Slovakia, South Africa, Switzerland.
United Kingdom, United States. Uruguay
see International Convention fur the Prevention of Pollution From Ships (MARPOL)
/aartiM— (1 12) Afghanistan. Argentina, Australia. Austria. Bangladesh. Belgium. Benin, Bhutan,
Bolivia, BoiswaM. Brazil. Bulgaria, Burma, Canada, Cape Verde, Central African Republic.
Chad, Chile. China. Colombia, Ci«ta Rica. Cote d''Ivoire, Croatia, Cyprus, Denmark. Dominican
Republic. Ecuador. Egypt. El Salvador, Equatorial Guinea, Fiji. Finland. Gabon. The Gambia,
Germany, Ghana, Greece, Guatemala, Guinea-Bis.sau. Honduras, Hungary, Iceland, India,
Indonesia, Iran. li^. Ireland. Israel. Italy, Jamaica, Japan, Jordan, Kenya. South Korea, Kuwait,
Laos, Lebanon, Libma, Libya, Luxembourg. Madagascar, Malawi, Malaysia, Malta, Mauritania
Mauritius. Mexico. Mongolia. Morocco. Nepal. Netherlands, New Zealand. Nicaragua. Niger.
Nigeria. Norway, Pakistan. Panama. Papua New Guinea. Peru, Philippines, Poland, Romania,
Rwanda, Senegal. Sierra Leone, Singapore. Slovakia, Slovenia. South Africa, Spain. Sri i jnitu
Sudan. Suriname. Swaziland. Sweden. Switzerland. Syria. Tanzania, Thailand. Togo, Trinidad
and Tobago, Tunisia. Turkey. Uganda. United Kingdom, United Stales. Uruguay. Venezuela,
former Yugoslavia. Zaire, ^mbia
rtofe— the following countries have signed, but not yet raiifled the treaty: Algeria, Burkina,
Burundi. Cameroon. Ethiopia. Haiti, Mali, Paraguay. Portugal, Somalia, Vietnam _
see International Tropical Timber Agreement
parties— (60) Angola. Amigua and Barbuda, The Bahamas, Bahrain, Barbados. Belize,
Botswana. Brazil. Cameroon. Cape Verde, Costa Rica. Cole d''Ivoire. Cuba, Cyprus. Czech
Republic, Djibouti. Dominica, Egypt. Fiji, The Gambia, Ghana, Grenada, Guinea,
Guinea-Bissau, Guyana, Honduras, Iceland. Indonesia. Iraq, Jamaica, Kenya, Kuwait, Mali.
Malta, Marshall Islands. Mexico, Federated States of Micronesia, Namibia, Nigeria. Oman,
Paraguay, Philippines, Saint Kitts and Nevis. Saint Lucia. Saint Vincent and the Grenadines, Sao
Tome and Principe, Senegal, Seychelles. Slovakia. Somalia. Sudan, Tanzania, Togo, Trinidad
and Tobago. Tunisia. Uganda, Yemen, former Yugoslavia. Zaire. Zambia, Zimbabwe
nofe— the following countries have signed, but not yet raliried the convention: Afghanistan,
Algeria, Argentina, Australia. Austria, Bangladesh, Belarus, Belgium, Benin. Bhutan, Bolivia,
Brunei, Bulgaria, Burkina. Burma, Burundi. Cambodia, Canada. Central African Republic,
Chad. Chile, China, Colombia, Comoros. Congo. Cook Islands. Denmark, Dominican Republic,
El Salvador. Equatorial Guinea, Ethiopia, European Union. Finland. France, Gabon. Greece,
Guatemala, Haiti, Hunga^. India. Irw, Ireland, Italy, Japan, North Korea. South Korea, Laos,
Lebanon, Lesotho, Liberia, Libya, Liechtenstein. Luxemmiutg, Madagascar, Malawi, Malaysia,
Maldives, Mauritania. Mauritius. Monaco, Mongolia. Morocco, Mozambique. Nauru, Nepal,
Netherlands. New Zcaiand, Nicaragua, Niger. Niue, Norway, Pakistan, Panama. Papua New
Guinea. Poland. Portugal. Qatar. Romania. Russia, Rwanda. Saudi Arabia. Sierra Leone,
Singapore. Solomon Islands. South Africa. Spain, Sri Lanka. Suriname, Swaziland. Sweden,
Switzerland. Thailand. Tuvalu. Ukraine. United Arab Emirates, Uruguay, Vanuatu, Vietnam,
Western Samoa
United Nations Framework Convention
on CHmalc Change
nprr— abbreviated as Climate Change
date optntd for signature — 1992
objective — to achieve stabilization of
greenhouse gas concentrations in the
atmosphere at a low enough level to
prevent dangerous anthropogenic
interference with the climate system
Wetlands
putties — (64) Algeria, Antigua and Barbuda, Argentina, Armenia, Australia. Austria, The
Bahamas, Barbados, Botswana, Brazil, Burkina, Canada, China, Cook Islands, Cuba, Czech
Republic, Denmark, Dominica. Ecuador, European Union. Fiji, France, Germany, Guinea,
Hungary, Iceland. India, Japan, Jordan. South Korea, Maldives, Malu, Marshall Islands.
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Monaco, Mongolia, Nauru,
Netherlands, New Zealand, Norway. Papua New Guinea, Paraouay, Peru, Portugal. Saint Kitts
and Nevis, Skint Lucia, Seychelles, Spain, Sri Lanka, Sudan, Sw^n, Switzerland, ‘Dinisia,
Tuvulu, Uganda, United Kingdom, United States, Uzbekistan, Vanuatu, Zambia, Zimbabwe
note — the following countries have signed, but not wt ratified the convention: Afghanistan.
Angola, Azerbaijan, Bahrain, Bangladesh, Belarus, Belgium. Belize, Benin, Bhutan, Bolivia,
Bulgaria, Burma, Burundi. Cameroon, Cape Verde, Central African Republic, Chad, Chile,
Colombia, Comoros, Congo, Costa Rica, Cote dTvoire, Croatia. Qprus, Djibouti, Dominican
Republic, F.gypt, El Salvi^. Estonia. Ethiopia, Finland. Gabon, The Gambia, Ghana. Greece,
Grenada, Guatemala, Guinea-Bissau. Guyana. Haiti, Honduras. Indonesia, Iran, Ireland, Israel,
Italy, Jamaica. Kazakhstan. Kenya. Kiribati, North Korea, Latvia, Lebation. Lesotho, Liberia,
Libya, Liechtenstein, Lithuania, Luxembou^, Madagascar, Malawi. Malaysia, Mali, Moldova,
Morocco, Mozambique, Namibia, Nepal, Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama,
Philippines, Poland. Romania, Russia. Rwanda, San Marino, Sao Tome and Principe, Senegal,
Sierra Leone, Singapore, Slovakia. Slovenia. Solomon Islands, South Africa, Suriname,
Swaziland, Tanzania. Thailand, Togo. Trinidad and Tobago, Ukraine, Uruguay, Venezuela.
Vietnam, Western Samoa, Yemen, former Yugoslavia, Zaire _
see Convention on Wetlands of International Importance Especially As Waterfowl Habitat
(Ramsar) _
see International Convention for the Regulation of Whaling _
Whaling
Appendix F:
Weights and Measures
MalhtflMtkal Notaliaii
Metric Inlcrrrlatioiishi|is
Mathematkal f^:lwer
Name
10 " or 1.000.000,000.000.000, OOO
one quintillion
10" or 1,000,000.000.000.000
one quadrillion
10 - or 1,000,000,000.000
one trillion
10'' or 1,000,000.000
one billion
KTw 1.000,000
one million
10'' or 1.000
one thousand
10 or 100
one hundred
10'' or 10
ten
■O'' or 1
one
10 or 0.1
one-tenth
10 ■'' or 0.01
one-hundnedth
10 '' or 0,001
one-thousandth
10" or 0.000 001
one-millionth
10 '' or 0.000 000 001
one-billionth
10 '' ■ or 0.000 000 000 001
one-trillionth
10 '''' or 0.000 000 000 000 001
one-quadrillionth
lO " or 0.000 000 000 000 000 001
one-quintillionth
Conversions from a multiple or submultiple to the basic units of meters,
liters, or grams can be done using the table. For example, to convert from
kilometers to meters, multiply by 1 ,000 (9.26 kilometers equals 9,260
meters) or to convert from meters to kilometers, multiply by 0.001 (9.260
Prefix
Symbol
Length,
weight, or
capacity
Area
Volume
exa
E
10“
10’“
10"
peta
P
10"
10"
10''''
tera
T
10"
lO"
10"
giga
G
10''
10''"
10’
mega
M
Iff
10''-
10''“
hectokilo
hk
Kf
10“
10"
myna
ma
10''
lO"
10"
kilo
k
10''
10“
10''
hecto
h
10
10''
10“
basic unit
—
1 meter.
1 meter
1 meter''
1 gram.
1 liter
deci
d
10 •
10 ''
10''
centi
c
10’
10''
10"
milli
m
10''
10“
10"
decimilli
dm
10''
10“
10 ''■
cenlimilli
cm
10''
10
10"
micro
u
10“
10''
10"
nano
n
10''
10
10"
pico
p
10 ''•
10 ''
10*
femto
f
10''“
10"
10"
atto
u
10''“
10 *
10"
492
Equivalents Unit Metric Equivalent US Equivalent
acre
0.404 685 64 hectares
43,560 feet’
acre
4,046,856 4 meters''
4,840 yards ’
acre
0,004 046 856 4 kilometers’
0.001 562 5 miles’, statute
are
100 meters’
119.599 yards’
barrel (petroleum, US)
158.987 29 liters
42 gallons
(proof spirits, US)
151.416 47 T iers
40 gallons
(beer, US)
117.347 77 liters
31 gallons
bushel
35.239 07 liters
4 pecks
cable
219.456 meters
120 fathoms
chain (surveyor''s)
20.116 8 meters
66 feet
cord rwood)
3.624 556 meters''
128 feet''
cup
0.2.36 588 2 liters
8 ounces, liquid (US)
degrees. Celsius
(water boils at l(X)'''' degrees C,
freezes at 0‘ C)
multiply by 1 .8 and add 32 to
obtain F
degrees, fahrenheit
subtract 32 and divide by 1 .8 to
obtain *C
(water boils at 212 ‘F, freezes at
.32 ‘F)
dram, avoirdupois
1.771 845 2 grams
0.0625 5 ounces, avoirdupois
dram, troy
3.887 934 6 grams
0. 1 25 ounce.s, troy
dram, liquid (US)
3.696 69 milliliters
0. 1 25 ounces, liquid
fathom
1.828 8 meters
6 feet
foot
.30.48 centimeters
12 inches
foot
0..304 8 meters
0.33.3 .333 3 yards
foot
0.000 304 8 kilometers
0.0(X) 1 89 .39 miles, statute
foot’
929.030 4 centimeters’
144 inches''
foot
2 0,092 903 04 meters’
O.lll III 1 yards’
foot''
28.316 846 592 liters
7.480 519 gallons
foot''
0.028 316 847 meters''
1,728 inches''
furlong
201.168 meters
220 yards
gallon, liquid (US)
3.785 411 784 liters
4 quarts, liquid
gill (US)
118.294 118 milliliters
4 ounces, liquid
grain
64.798 91 milligrams
0.002 285 7 1 ounces, udvp.
gram
1,000 milligrams
0.035 273 % ounces, advp.
hand (height of horse)
10.16 centimeters
4 inches
hectare
10,000 meters’
2.47 1 053 8 acres
hundredweight, long
50.802 345 kilograms
112 pounds, avoirdupois
hundredweight, short
45.359 237 kilograms
100 pounds, avoirdupois
inch
2.54 centimeters
0.083 333 33 feet
inch’
6.45 1 6 centimeters’
0,006 944 44 feet’
inch''
16.387 064 centimeters''
0,000 578 7 feet''
inch''
16.387 064 milliliters
0.029 761 6 pints, dry
inch''
16.387 064 milliliters
0.0.34 632 0 pints, liquid
kilogram
0.001 tons, metric
2.204 623 pounds, avoirdupois
kilometer
1 .000 meters
0,621 ,371 19 miles, statute
kilometer
ItX) hectares
247.105 38 acres
kilometer
1.000.000 meters’
0.386 102 16 miles'', statute
knot ( 1 nautical mi/hr)
1 .852 kilometers/hour
I.I5I statute mile.s/hour
league, nautical
5.559 552 kilometers
.3 miles, nautical
league, statute
4.828.032 kilometers
3 miles, statute
link (surveyor''s)
20.116 8 centimeters
7.92 inches
493
Equlvaknts Unit Metric Equivalent US Equivalent
liter
Q.00I meters''
61.023 74 inches''
liter
0.) dekaliter
0.908 083 quarts, dry
titer
1,000 milliliters
1 .056 688 quans, liquid
meter
too centimeters
1.093 613 yards
meter*
10,000 centimeters''
1.195 990 yards*
meter''
1,000 liten
1.307 951 yards''
micron
0,000 001 meter
0.000 039 4 inches
mil
0.02S 4 millimeters
0.001 inch
mile, nautical
1.S52 kilometers
1.150 779 4 miles, statute
mile*, nautical
3.429 904 kilometers*
1.325 miles'', statute
mile, statute
I.d09 344 kilometers
5,280 feet or 8 furlongs
mile*, statute
2S8.998 811 hectares
640 acres or 1 section
mile'', sutute
2.S89 988 11 kilometers''
0.755 miles'', nautical
minim (US)
0.061 611 S2 milliliters
0.002 083 33 ounces, liquid
ounce, avoirdupois
28.349 S23 I2S grams
437.5 grains
ounce, liquid (US)
29.573 53 milliliters
0.062 5 pints, liquid
ounce, troy
31.103 476 8 grams
480 grains
pace
76.2 centimeters
30 inches
peck
8.809 767 5 liters
8 quarts, dry
pennyweight
1.555 173 84 grams
24 grains
pint, dry (US)
0.550 610 47 liters
O.S quarts, dry
pint, liquid (US)
0.473 176 473 liters
0.5 quarts, liquid
point (typographical)
0.351 459 8 millimeters
0.013 837 inches
pound, avoirdupois
453,592 37 grams
16 ounces, avourdupois
pound, troy
373.241 721 6 grams
12 ounces, troy
quart, dry (US)
1.101 221 liters
2 pints, dry
quan, liquid (US)
0.946 352 946 liters
2 pints, liquid
quintal
100 kilograms
220.462 26 pounds, avdp.
rod
5,029 2 meters
5.5 yards
scruple
1.295 978 2 grams
20 grains
section (US)
2.589 988 1 kilometers*
1 mile'', statute or 640 acres
span
22,86 centimeters
9 inches
stere
1 meter''
1.307 95 yards''
tablespoon
14,786 76 milliliters
3 teaspoons
teaspoon
4,928 922 milliliters
0.333 333 tablespoons
ton, long or deadweight
1,016.046 909 kilograms
2.240 pounds, avoirdupois
ton, metric
1,000 kilograms
2.204.623 pounds, avoirdupois
ton, metric
1,000 kilograms
32,150 75 ounces, troy
ton, register
2.831 684 7 meters''
100 feet''
ton, short
907.184 74 kilograms
2,0(X) pounds, avoirdupois
township (US)
93.239 572 kilometers''
36 miles'', statute
yard
0.914 4 meters
3 feet
yard*
0.836 127 36 meters*
9 feet''
yard''
0.764 554 86 meters''
27 feet''
yard''
764.554 857 984 liters
201.974 gallons
494
Appendix G:
Cross-Reference List of Geographic Names
This lisi indicates where various names, entities, can be found in The Hbrid are included in parentheses; additional
including all United States Foreign Service Factbook. Spellings are not necessarily those information is included in brackets.
Posts, alternate names, former names, and ^proved by the United States Board on
political or geographical portions of larger Grographic Names (BON). Alternate names
Name
Entry in The Factbook
A Abidjan [US Embassy)
Cote d''Ivoire
Abu Dhabi (US Embassy]
North Island','64e7fe3ee0d150d5074673b20a91c00d74b874af41109d98dc8606ff2b6bbedc','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df0ab08653531624a5a4356fba8b13dd6366e4d4a1c4ffa2130d610b34df77cd',1994,'CH','Switzerland','energy',969,'note — the following countries have signed, but not yet ratified the convention; Austria. Belgium,
Pi''lgaria, Canada, Denmark. European Union, France, Germany, Greece, Hungary, Italy,
Portugal, Ukraine, United Kingdom. United States
Convention on the Intemationnl IVade in
Endanitend Species of WiM Flora and
Fauna (CITES)
note — abbreviated as Endangered Species
date opened for signature — 1973
objective — to protect certain endangered
species from overexploitation by means of a
system of import/expon permits
pttrties — (104) Afghanistan. Algeria. Argentina. Australia, Austria. Bangladesh. Belgium. Belize.
Benin, Bolivia, Botswana, Brazil. Bulgaria, Burkina. Burundi, Cameroon, Canada, Central
African Republic, Chad. Chile. China. Colombia, Congo, Costa Rica, Cuba. Cyprus, Denmark.
Djibouti, Dominican Republic. Ecuador. Egypt. El Salvador. Ethiopia. Finland. France. Gabon,
The Gambia. Germany, Ghana. Guatemala. Guinea, Guinea-Bissau. Guyana. Honduras. Hungary,
India. Indonesia. Iran. Israel, Italy. Japan, Jordan. Kenya. Liberia. Luxembourg, Madagascar.
Malawi, Malaysia. Malta. Mauritius. Mexico. Morocco, Mozambique. Namibia, Nepal,
Netherlands, New Poland. Nicaragua. Niger. Nigeria. Norway, Paki.stan, Panama. Papua New
Guinea. Paraguay. Peru, Philippines. Poland. Portugal. Rwanda, Senegal. Singapore. Somalia,
South Africa. Spain. Sri Lanka. Sudan. Suriname. Sweden. Switzerland, Tanzania. Thailand.
Togo, Trinidad and Tobago. Tunisia, Uganda. United Arab Emirates. United Kingdom. United
States. Uruguay, Venezuela. Zaire, ^mbia, Zimbabwe
note — the following countries have signed, but not yet ratified the convention: Cambodia,
Ireland, Kuwait, Lesotho. Vietnam
Convention on the Prevention of Marine
Pollution by Dumping Wastes and Other
Matter (Loiidon Convention)
note — abbreviated as Marine Dumping
date opened for signature — 1972
objective — to control pollution of the sea
by dumping, and to encourage regional
agreements supplementary to the Convention
parties— (70) Afghanistan, Argentina, Australia. Belams, Belgium. Canada, Cape Verde.
Chile. China. Costa Rica. Cote d''Ivoire. Croatia. Cuba. Cyprus. Denmark. Dominican Republic.
Egypt. European Union, Finland. France. Gabon, Germany, Greece. Guatemala, Haiti. Honduras.
Hungary. Iceland, Ireland. Italy, Jamaica, Japan. Jordan, Kenya. Kiribati. Libya. Luxembourg.
Malta. Mexico. Monaco. Morocco. Nauru. Netherlands. New Zealand. Nigeria, Norway. Oman.
Panamt.. Papua New Guinea, Philippines, Poland. Portugal. Russia. Saint Lucia, Seychelles.
Slovenia, Solomon Islands, South Africa, Spain. Suriname, Sweden. Switzerland, Tunisia,
Ukraine. United Arab Emirates. United Kingdom. United States. Vanuatu, former Yugoslavia.
2^ire
Convention on the Prohibition of Military
dr Any Other Hostile Use of
Environmental Modification l^chniques
note — abbreviated as Environmental
Modification
date opened for signature — 1976
Itanies — (62) Afghanistan, Algeria. Antigua and Barbuda. Argentina. Australia. Austria,
Bangladesh. Belarus. Belgium, Benin. Brazil. Bulgaria. Canada, Cape Verde, Cuba, Cyprus.
Czech Republic, Denmark. Dominica. Egypt. Finland, Germany. Ghana. Greece. Guatemala.
Hungary. India. Ireland. Italy. Japan, North Korea. South Korea. Kuwait, Laos. Malawi.
Mauritius. Mongolia. Netherlands. New Zealand. Niger. Norway. Pakistan. Papua New Guinea,
Poland, Rumania. Russia, Saint Lucia. Sao Tome and Principe, Slovakia. Solomon Islands.
Spain. Sri Lanka. Sweden, Switzerland, Tunisia. Ukraine. United Kingdom, United States.
Uruguay, Uzbekistan, Vietnam, Yemen
objective — to prohibit the military or other
hostile use of environmental modification
techniques in order to further world peace
and trust among nations
note — the following countries have signed, but not yet ratified the convention; Bolivia, Ethiopia,
Holy See. Iceland. Iran. Iraq, Lebanon. Liberia. Luxembourg. Monrcco. Nicaragua. Portugal.
Sierra Leone, Syria, Turkey, Uganda, Zaire
Convention on Wetlands of International
Importance Especially As Waterfowl
Habitat (Ramsar)
note — abbreviated as Wetlands
date opened for signature — 1971
objective — to stem the progressive
encroachment on and loss of wetlands
now and in the future, recognizing the
fundamental ecological functions of wetlands
and their economic, cultural, scientific, and
recreational value
[Kirties — (65) Algeria, Australia. Austria. Belgium. Bolivia. Bulgaria. Burkina. Canada.
Chad. Chile. Costa Rica, Czech Republic. Denmark, Ecuador, Egypt, Finland. France. Gabon.
Germany, Ghana, Greece, Guatemala, Guinea-Bissau. Hungary, Iceland, India, Iran, Ireland.
Italy. Japan. Jordan. Kenya. Lesotho. Liechtenstein. Mali. Malta, Mauritania, Mexico, MonKCu,
Netherlands. New Zealand. Niger, Norway. Pakistan, Panania. Poland. Portugal. Romania,
Russia, Senegal. South Africa, Spain. Sri Lanka. Suriname, Sweden, Switzerland, 1''unisia.
Uganda. United Kingdom. United States. Uruguay, Venezuela, Vietnam, former Yugoslavia,
Romania; Moldova
Genoa [US Consulate General]','7db4f9f6d242c5f046d3c5ccb4c80af30c386caf10e3406c55b57b9d762cca6f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('048f18f86f8013146583f83d6d655f377b4428d59f3edeb7d7f435f41376eb61',1994,'MX','Mexico','energy',970,'Accra [US Embassy]
Canton (Guangzhou)
Bolivia
Durban [US Consulate General]
Guadalcanal
Guangzhou [US Consulate General]
Hispaniola
Dominican Republic; Haiti
Hol^aido
Swaziland
Atlantic Ocean
Atlantic 0»an
Nuuk (Godthab)
Gieenlaitd
Nyasaland
Ocean Island (Banaba)
Pusan [US Consulate]
Korea, South
P''yongyang
Korea, North
Q
Quebec [US Consulate General]
507
Nune _
§air Amtocs y hovkiencta, Archipleligo
San Bernardino Strait
San Felix, Itia
San Jose (US Embauy)
San Juan
San Luis Potosi [US Consular Agency]
Tanzania
Vetde Island Passage
Pacific Ocean
Victoria [US Embassy]','b9b98b40d21045368486d2ae7a6ebd99122adaf58a18e5d8d1a6546d625ffa9a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bb807fac3c1d6e9e28c30b0e15c5b6e106f54e5a6d3336a9eec4121436ec731',1994,'GH','Ghana','energy',971,'Adamstown
Pitcairn Islands
Adana (US Consulate]
Turkey
Addis Ababa [US Embassy]
Golan Heights
Syria
Good Hope, Cape of','e1d63ffba002536e358de0e132dd8b6a893ea47211e7c9feb2e218b57e4b481b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c54e15404fcf0abcfc460643ed7d75fa123e0e2ee4323f49e61749181a0494db',1994,'AU','Australia','energy',972,'Adelie Land (Terre Adelie) [claimed by France]
British East AfHca
Cancun [US Consular Agency]
Cayenne
503
M
Name
Entry in The World Factbook
Louisiade Archipelago
Loyalty Islands (lies Loyaute)
Luanda [US Liaison Office]
Lubumbashi (US Consulate General closed since October
1991]
Lusaka [US Embassy]
Luxembourg [US Embassy]
Luzon
Luzon Strait
Lyon [US Consulate General] _
Pescadores
TUwan
Peshawar [US Consulate]
Pakisttn
Peter I Island
Pacific Ocean
Russia','2a7729ca30088011bd94a708003d399339273a6740e35e0370a28ed469ab4c90','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2922c8ddc5f03b1e58cb929f3495ec285af5fc1eceadf0d93464fe7f77778e8',1994,'AQ','Antarctica','energy',973,'Aden
Alexandria (US Consulate General]
Baluchistan
Atlantic Ocean
Philip Island
Quito [US Embassy]
Pacific Ocean
Pacific Ocean
310
Name Entiy in The World Factbook','f150a28268b23ec6095bc22c487f671352f490a9a4941c43287e1f0109710585','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2003d2b2ff94113065c98df22361182bd829706330b66392084f5731cfd685ea',1994,'YE','Yemen','energy',974,'Aden, Gulf of
Indian Ocean
Admiralty Islands
Norwegian Sea
Atlantic Ocean
Nouakchott [US Embassy]
Pefouse Strait, La
PaciRc Ocean
Persian Oulf
Indian Ocean
Perth (US Consulate General]
Armenia, Azerbaijan, Belarus, Estonia, Georgia, Kazakhstan,
Kyrgyzstan, Latvia, Lithuania, Moldova, Russia,
Tajilustan, Dirkmenistan, Ukraine, Uzbekistan
Yemen Arab Republic
Yemen, North [Yemen Arab Republic]
Yemen (Sanaa) [Yemen Arab Republic]
Yemen, People’s Democratic Repubiic of
Yemen, South [People’s Democratic Republic of Yemen]
Yerevan [US Embassy]','d3991f72d1ba69c2281b992cb8c0874e5f3f558642d1a04c3f073193c93308b3','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05806360a4d466347745bb1908fb0f45838a1731e567d420002103b9069a1fd1',1994,'PG','Papua New Guinea','energy',975,'Adriatic Sea
Atlantic Ocean
Aegean Islands
Pacific Ocean
497
Name
Entry in The World Factbook
Bougainville Strait
Pacific Ocean
Bounty Isiands
Greenland Sea
Arctic Ocean
Grenadines, Northern
Saint Vincent and die Grenadines
Grenadines, Southern
Porto Alegre [US Consulate]','e572be5be08afbd46cf1149a64805a31d3eaa3b3575bea058fe68211c1c0b586','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22e23006138fd061e88845a0570ed5a194e1256abc025cf564dd4816d386bc0c',1994,'GR','Greece','energy',976,'Aegean Sea
Atlantic Ocean
Afars and Issas, French Territory of the (F.T.A.I.)
Attu
Atlantic Ocean
French Southern and Antarctic Lands
Netherlands Antilles
Dodoma
Tanzania
Doha [US Embassy]
Ionian Sea
Atlantic Ocean
Irian Jaya','e467ad32d24260e33573cc35e34b037bef3d67efd61737b993f6b10f99cd7020','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5289d2b48b442a0962e231e24bc8c0c427e82a8bac8a02583524596cd3fc499',1994,'MU','Mauritius','energy',977,'Agana
Caroline Islands
Micronesia, Federated Slates of; Pacific Islands, Trust
Territory of the
Caribbean Sea
Atlantic Ocean
Carpentaria, Gulf of
Pacific Ocean
Casablanca [US Consulate General]
Port Moresby [US Embassy]','4d51ae692387e1b560a3b3c4675ead3b3c0b72ecb5a3743c98281d441677f0d1','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3835a5d365c95c72b9ef99e50d3ba567818a93eb5d016af3540bcf21d09a2b4e',1994,'US','United States','energy',978,'Alaska. Gulf of
Pacific Ocean
Aldabra Islands
Alexander Island
Auckland [US Consulate General]
Heard Island
Kola Peninsula (Kol’skiy Poluostrov)
Russia
Kolonia [US Embassy]
Oaxaca [US Consular Agency]
Ogaden
Ethiopia; Somalia
Oil Islands (Chagos Archipelago)
Revillagigedo Liands','36f75ca4b03116dedc0b6ec9df37e64f4dbf31b632f20672e502ddd6b83cfb96','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0eda0b7a4bfc29171ce6bf867c192523c336040b19c4a2da536122a39013cd2',1994,'SC','Seychelles','energy',979,'Alderney
Amami Strait
Pacific Ocean
Amindivi Islands
Amman [US Embassy]
Asuncion [US Embassy]
Fernando de Noronha
Vienna [US Embassy, US Mission to International
Organizations in Vienna (UNVIE)]','2f79bc429aeb5d8b0295d7a6d263091c25f87a47b235c6e2a59075161da13519','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b71ff6772990abe606e535edc8c3aaf527af8d5167537eae727365c2de1bccaa',1994,'ES','Spain','energy',980,'Alma-Ata (Almaty)
Balearic Sea (Iberian Sea)
Atlantic Ocean
Bali [US Consular Agency]
Barents Sea
Arctic Ocean
Barranquilla [US Consulate]
Canberra [US Embassy]
Ceylon
Chagos Archipelago (Oil Islands)
Lagos [US Embassy]
Lau Group
Atlantic Ocean
Algeria, Libya, Mauritania, Morocco, Tunisia
Pamirs
China; Tajikistan
Panama [US Embassy]
Venda','2ef46d9a0ffc34360769a3e2d1473341ed85ba4f118512406da10786be86d8e6','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('505f161dea63076066782b13c4e25978c5e7d55a701cd9359e4d61ce41cf0e57',1994,'IN','India','energy',981,'Amirante Isles
Andaman Sea
Indian Ocean
Andorra la Vella
Netheriands Antilles
Atlantic Ocean
Calgary [US Consulate General]
Syria
499
Name
Entry in The World Faetbook
Djibouti [US Embassy]
Gold Coast
Laccadive Sea
Indian Ocean
La Coruna [US Consular Agency]
La Paz [US Embassy]
Bolivia
La Perouse Strait
Pacific Ocean
Laptev Sea
Arctic Ocean
Las Palmas [US Consular Agency]','dac83366798346463c85d905f96649eae514b08a78b48d601c661b56e4463f13','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bcab476280e0a461b0147c4ef0555b96ff12dc3a510e941b32fa93949fc9279',1994,'NL','Netherlands','energy',982,'Amsterdam Island (He Amsterdam)
French Southern and Antarctic Lands
Amundsen Sea
Pacific Ocean
Amur
China; Russia
Andaman Islands
Haifa [US Consular Agency]','a65b7ca7dbb1d9864283676165a4c421cc23c79e59dd3066bcecef007b2ae160','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50434308eb5a24648cfcd8145747a9c37986bcb20cb489dd2518469969d381fc',1994,'KM','Comoros','energy',983,'Ankara [US Embassy]
Turkey
Annobon
Micronesia, Federated Suites of
Russia
Indian Ocean','030c9afe0cc5071858cade8dabb3cb88413b50044cfd8f4f0d43f21018f6b5a7','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3cb82f501ecde478e76b304a68608a7bab75bd6bea07e90487073437111e01d',1994,'GQ','Equatorial Guinea','energy',984,'Antananarivo [US Embassy]
Atlantic Ocean
Enderbury Island
Finland, Gulf of
Atlantic Ocean
Florence [US Consulate General]
Indian Ocean','470a8582bedd86106c18363de1c2b86fb53315e2e4ab7fc5799027cc3e1721d8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3578ba6de5413139002ac3cc3e66e5683d641d442dca6e37c72003386086645e',1994,'NZ','New Zealand','energy',985,'Antwerp {US Consulate General]
Auckland Islands
Australes lies (lies Tubuai)
Brasiiia [US Embassy]
Canal Zone
Cheju-do
Korea, South
Cheju Strait
Pacific Ocean
Chengdu [US Consulate General]
Khabarovsk
Russia
Khartoum [US Embassy]
North Korea
Korea, North
North Pacific Ocean
Pacific Ocean
North Sea
Atlantic Ocean
North Vietnam
Vietnam
Northwest Passages
Arctic Ocean
North Yemen (Yemen Arab Republic)
Korea, South
Western Channel (West Korea Strait)
Pacific Ocean
West Germany (Federal Republic of Germany)','6a36875fe27bfe4097cdd7c2dc7fad87449d680b6ad9cfbb27feddf683d359f9','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd700ea2b6195b5120413fe924521ad6b74e43ee0f182b2757421f27941ed5ef',1994,'TD','Chad','energy',986,'Apia [US Embassy]
Western Samoa
Aqaba, Gulf of
Indian Ocean
Arabian Sea
Indian Ocean
Arafura Sea
Pacific Ocean
Argun
China; Russia
Ascension Island
Saint Helena
Ashgabat (Ashkhabad)','9e429a1efc8a811921adcf9e1a7a17bd9110dd7eb231b1f9d6d36056bfae6b6a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1289610d29468bfe55fbe91e1ec11739a82beac23db30ed70a2dbca076060069',1994,'CL','Chile','energy',987,'Athens [US Em''t''sssy]
Russia [Big Diomede]: United States [Little Diomede]
Eastern Channel (East Korea Strait or Tsushima Strait)
Pacific Ocean
East Germany (German Democratic Republic)
Home, lies de
Juventud, Isla de la (Isle of Youth)
Mauritius; Reunion
Passion, lie de la
Clipperton Island
Pashtunistan
Afghanistan: Pakistan
Peking (Beijing)
Cotu Rica','3976989d61a93aa690e83969260068ed65993766148afb4f089cf83ff90c14f6','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('499031a9c76b62ea858ccee02f52cfcfe158a37abf6b8717001585d9fa47393b',1994,'PF','French Polynesia','energy',988,'Avarua
Gaspar Strait
Indian Ocean
Geneva [Branch Office of the US Embassy, US Mission to
European Office of the UN and Other International
Organizations]
Paramaribo [US Embassy]
Taiwan
Pacific Ocean','65c3f9e3c81bb6bd89db16da2902b6a8ce74644063aeddff4e76cf21fcfc4bb5','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74649b6a3e6f246dd2ebcf08c8145a084160e4e417d9f89dbb77a6c1b7f3a224',1994,'CA','Canada','energy',989,'Azores
Baghdad [US Embassy temporarily suspended; US Interests
Banks Islands (lies Banks)
California, Gulf of
Pacific Ocean
Campbell Island
Ellesmere Island
Ellice Islands
"nivalu
Elobey, Islas de
Halmahera
Laccadive Islands
Czech Republic
Indonesia; Papua New Guinea
Ouagadougou [US Embassy]
Buriuna
Outer Mongolia
Prince Edward Islands
Principe
(Jueen Charlotte Islands
Queen Elizabeth Islands
Queen Maud Land [claimed by Norway]
Pacific Ocean
Vancouver Island
Van Diemen Strait
Pacific Ocean
Thessaloniki [US Consulate General]
Thimphu
Thurston Island
Tibet (Xizang)
Tibilisi (Tbilisi) [US Embassy]
Tierra del Fuego
Tijuana [US Consulate General]
Timor
Timor Sea
Tinian
Tlran, Strait of
Tirane [US Embassy]
Tobago
Tokyo [US Embassy]
Tonkin, Gulf of
Toronto [US Consulate General]
Torres Strait
Torshavn
Toshkent (Tashkent)
Transjordan
Transkei
Transylvania
Trieste [US Consular Agency]
Trindade, Ilha de
Tripoli [US post not maintained; representation by Belgian
Embassy]
Tristan da Cunha Group
TVobriand Islands
Thicial States
Truk Islands
Tsugatu Strait
Tiiamotu Islands (lies TUamotu)
Tubuai Islands (lies TUbuai)
Tunis [US Embassy]
Turin
Turkish Straits
TUrkmeniya
Turks Island Passage
Tyrol, South
Tyrrhenian Sea
511
Name
Entry in The World Factbook
Vatican City [US Embassy]
Holy See
Velez de la Gomera, Penon de
Wrangel Island (Ostrov Vrangelya)
Russia [de facto]
Y
Yamoussoukro
Cote d’Ivoire
Yaounde [US Embassy]','7c4ab381ffe8d7f3c44a84fd7e4296b7df8fbb65cf6fa2a72a8fc4cbafac1cc5','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b137b6feb23ea6e889152a66165910faeceafd67b808c62b3890d513dfd72f75',1994,'PT','Portugal','energy',990,'Azov, Sea of
Atlantic Ocean
Bab el Mandeb
Indian Ocean
Babuyan Channel
Pacific Ocean
Babuyan Islands
500
Name
Entry in The World Factbook
Fundy, Bay of
Atlantic Ocean
Futuna Islands (Hoom Islands)
Wallis and ''’utuna
G
Gaborone [US Embassy]
Ljubljana [US Embassy]
Oran [US Consulate)
Port-au-Prince [US Embassy]','4395eef170f5d4248deb9d551a29f8054d33a2bda470ee78472d083daf856309','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('217165e3a6a53317e52b6f31871193c7c18519aa642a726760ed411077a9e1db',1994,'PH','Philippines','energy',991,'Baffin Bay
Arctic Ocean
Batfin Island
Balleny Islands
Celebes
i.:,uicourt Rocks [claimed by Japan]
Korea, South
Libreville [US Embassy]
Pacific Ocean
Pacific Ocean
Indian Ocean
Pacific Ocean
Palermo [US Consulate General]
Pacific Ocean','ff1b2908616bdfad769d1a0b77887a407500a633a50c117bb993493c465b87ff','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aad2979719a39cc0f02227b123ead8616602bf73c71a1c9532c150d6529a87fe',1994,'ID','Indonesia','energy',992,'Bali Sea
Indian Ocean
Balintang Channel
Pacific Ocean
Balintang Islands
Celebes Sea
Pacific Ocean
Celtic Sea
Atlantic (}cean
Central African Empire
Dutch Guiana
Edinburgh [US Consulate General]
Hamburg [US Consulate General]
Irish Sea
Atlantic Ocean
Islamabad [US Embassy]
Jamestown
Saint Helena
Japan, Sea of
Pacific Ocean
Java
Java Sea
Indian Ocean
Jeddah [US Consulate General]
Kamchatka Peninsula (Poluostrov Kamchatka)
Russia
Kampala [US Embassy]
Leyte
504
_ Name _
Mediterranean Sea
Melbourne [US Consulate General]
Mellila
Mensk (Minsk)
Merida [US Consulate]
Messina, Strait of
Mexico [US Embassy]
Mexico, Gulf of
Milan [US Consulate General]
Minami-tori-shima
Mindanao
Mindoro Strait
Minicoy Island
Minsk [US Embassy]
Mogadishu [US Liaison Office]
Moldovia
Mombasa [US Consulate]
Port-Vila
Indonesia; Malaysia
Indian Ocean
Pacific Ocean
Indian Ocean','4a6a23933022845e6af400d1958560ee03b421885120e3d21baf0323387e2af1','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b49dc7d499dad42f0ff6c02240b26039bf76286497aa0633bf968a71b903e83a',1994,'PK','Pakistan','energy',993,'Baltic Sea
Atlantic Ocean
Bamako [US Embassy]
Islas Malvinas
Falkland Islands (Islas Malvinas)
Istanbul [US Consulate General]
Turkey
Italian Somaliland
Kara Sea
Arctic Ocean
Karimata Strait
Indian Ocean
Kathmandu [US Embassy]
502
Name
Entry in The World Facibook
Kiel Canal (Nord-Ostsee Kanal)
Atlantic Ocean
Kiev [US Embassy]
Lakshadweep
Wetar Strait
Pacific Ocean
White Sea
Arctic Ocean
Willemstad
Netherlands Antilles
Windhoek [US Embassy]','6becda355fe7f828848183d7b50210ac3a916ffcd8da2dd761bb401ef31c3636','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('831756890f4cc35228e956dcb30f868343b4d54d2c6a35294e564a96b622314e',1994,'KI','Kiribati','energy',994,'Bandar Seri Begawan [US Embassy[
Brunei
Banda Sea
Pacific Ocean
Bangkok [US Embassy]
Cape Town [US Consulate General]
Arctic Ocean
Enewetak Atoll (Eniwetok Atoll)
Goa
Kishinev (Chisinau)
Moldova
Kithira Strait
Atlantic Ocean
Kodiak Island
Ocean Island (Kure Island)
Pines, Isle of (Isla de la Juvennid)
Pacific Ocean
Vrangelya, Osuov (Wrangel Island)
Russia
w
Wakhan Corridor (now Vakhan Corridor)','b1ccf139deee1e5c261d485f814d664611a03fb5b0c3a2e5f477fd464a7ec735','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('800279bedf87f4e3f79ecb9aa55606a31a7054667b002c1a57734a2b5ee4eb2c',1994,'TH','Thailand','energy',995,'Bangui [US Embassy]
Pacific Ocean
Pacific Ocean
Ittly
Atlantic Ocean
Atlantic Ocean
Atlantic Ocean
Pacific Ocean','b3a06620e5d46ebd62961c8ecf29554d4fc005249652105376ddea58b5b28a04','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0e50384cf23a3f9f1dd6a30a0845bb10e2f40da6c2fc74145ecae41896d042c',1994,'DE','Germany','energy',996,'Atlantic Ocean
Svalbard
Arctic Ocean
Dutch East Indies
East Korea Strait (Eastern Channel or Tsushima Strait)
Pacific Ocean
East Pakistan
Franz Josef Land
Russia
Freetown [US Embassy]
German Federal Republic of (West Germany)
Hamilton [US Consulate General]
Oman; United Arab Emirates
Indian Ocean
West Island','ae4f06b65f7a1a4cadb2b3759c84bad2bd853a470789afc6c9591b3f34509be0','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfe61a7cd6e50947ae22f37f57947292e11b112ab2437b6791d6597b03cef668',1994,'GB','United Kingdom','energy',997,'Zaire
Serbia and Montenegro
Elba
English Channel
Atlantic Ocean
Eniwetok Atoll
Great Channel
Indian Ocean
Greater Sunda Islands
Brunei; Indonesia; Malaysia
Green Islands
Longyearbyen
Svalbard
Lord Howe Island
Northern Rhodesia
Osaka-Kobe [US Consulate General]
Walvis Bay
South Afnca
Warsaw [US Embassy]','cd9f21a0fc182a8b7bf9b5231cf53ca8f2d841465d66689534f0365d54d2b4ce','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f4c88dfb37c22e9e19d76d5046be6b4b6e0ef7c93f162fdd012acec2900284d',1994,'GW','Guinea-Bissau','energy',998,'Svalbard
Falkland Islands (Islas Malvinas)
Atlantic Ocean
Portuguese Timor (East Timor)','081e1ade435ed4356c9e1e102f2270fe3cb04fb9d6a03f7a8ceec6b9af203348','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05c04081d0ddbd6177a9aa4a1ff52913df7f02688ea6d492c7fb793f3b4ea95e',1994,'ZA','South Africa','energy',999,'Cape Verde
Caracas [US Embassy]
Venezuela
Cargados Carajos Shoals
Dushanbe [Interim Chancery]
Goteborg
Atlantic Ocean
Pribilof Islands
United Sutes
Prince Edward Island
Prince Patrick Island
Veracniz [US Consular Agency]','bcd2e227e50b2033228683de394c7e137f893d3d706371be1c53f6fd25016076','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ff6f3e67a55ec1cb26d535edf831369496d49e013ed44912c2745383926acaf',1994,'FR','France','energy',1000,'Brunei; Indonesia; Malaysia
1
Name
Entry in The VhrU Faetbook
Pascua, hla de (Easter Island)','851ade78c1701e88d962966d0d7790c64427ff48ca9e922d98ab4a2d1518b702','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd24e3c0746030c345fc5a960d256328db02b61854162193a2f6499934016680',1994,'BR','Brazil','energy',1001,'Bratislava [US Embassy]
Fernando Po (Bioko)
Pott-of-Spain [US Embassy]
Trinidad and Ibbago
Porto-Novo
Redonda
Bruil','f4630c96ed26665e8865c8da47506d4a1f7dec6bd6f6ad74e3db2114a6856790','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bef1f07c3128447b23a595d92d53ccb973568692daa70965bc71a89ac59d8a23',1994,'GY','Guyana','energy',1002,'British Honduras
Etorofu
Russia [de facto]
F
Farquhar Group
German Democratic Republic (East Germany)','239be172eea419a4570f7722ab80dd12ce8c967dc828a0366a6b5081152b29d5','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aad71a98ae0c8ab486ccc63d6ffe1a0a670f61822e68404a10fe3518d56a84f9',1994,'SB','Solomon Islands','energy',1003,'Bridsh Somaliland
Guadalupe, Isla de
Honshu
509
T
Name _
Soloman Sea
Songkhta [US Consulate]
Sound, The (Oresund)
Soudi Atlantic Ocean
South China Sea
Southern Grenadines
Southern Rhodesia
South Georgia
South Island
South Korea
South Orkney Islands
South Pacific Ocean
South Sandwich Islands
South Shetland Islands
South Tyrol
South Vieiiiam
South-West Africa
South Yemen (People’s Democratic Republic of Yemen)
Soviet Union
Spanish Guinea
Spanish Sahara
Spitsbergen
Stanley
Stockholm (US Embassy]
Strasbouig [US Consulate General]
Stuttgart [US Consulate General]
Suez, Gulf of
Sutu Archipelago
Sulu Sea
Sumatra
Sumba
Sunda Islands (Soenda Isles)
Sunda Strait
Surabaya [US Consulate]
Surigao Strait
Surinam
Suva [US Embassy]
Swains Island
Swan Islands
Sydney [US Consulate General] _
Tahiti
Taipei
Taiwan Strait
Tallin [US Embassy]
Tampico [US Consular Agency]
Tanganyika
Tangier
Tarawa
Tartar Strait
Tashkent [US Embassy]
Tasmania
Tasman Sea
Taymyr Peninsula (Poluostrov Taymyra)
Tegucigalpa [US Embassy]
Tehran [US post not maintained; representation by Swiss
Embassy]
Tel Aviv [US Embassy]
Terre Adelie (Adelie Land) [claimed by France]
Thailand, Gulf of
Endy in The World Faetbook _
Pacific Ocean','a00e86fd114c3b67f368eba48ea60af8e405e08c34e43b3eaa04b925da931943','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00ab247ef16cbb37efbac5d7fa794e35a7c94b74d418e03347d8f8cdaf969494',1994,'SO','Somalia','energy',1004,'Brussels [US Embassy, US Mission to European
Communities, US Mission to the North Atiantic Treaty
Oi^ganization (USNATO)]
Ivory Coast
Cote d''Ivoire
Iwo Jima
Moldova','decc7e7e539bf768a5804c97045728002ffc422bacea7a0c5422c63201d73c34','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8dbe274d8d94c72728eed6bc8ca348aa7cbb659adc1ced15412db75a50d597b7',1994,'TC','Turks and Caicos Islands','energy',1005,'Cairo [US Embassy]
Great Australian Bight
Indian Ocean
Great Belt (Store Baelt)
Atlantic Ocean
Great Britain','f73f68cd09614c749f484c5998eb097178acfd81fa6d00fff671d0b64c56b25b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c1aab07044eb30d24af34be667362964e7654967e9dd298ed30a49720909a6d',1994,'CN','China','energy',1006,'Canton Island
498
_ Name _
Chesterfield Islands (lies Chesterfield)
Chiang Mai [US Consulate General]
Chihli, Gulf of (Bo Hai)
China, People’s Republic of
China, Republic of
Chisinau [US Embassy]
ChoiseuI
Christchurch [US Consular Agency]
Christmas Island [Indian Ocean]
Christmas Island [Pacific Ocean] (Kiritimati)
Chukchi Sea
Ciskei
Ciudad Juarez [US Consulate General]
Cochabamba [US Consular Agency]
Coco, Isla del
Cocos Islands
Colombo [US Embassy]
Colon [US Consular Agency]
Colon, Archipielago de (Galapagos Islands)
Commander Islands (K'' mandorskiye Ostrova)
Conakry [US Embassy]
Congo (Brazzaville)
Congo (Kinshasa)
Congo (Leopoldville)
Con Son Islands
Cook Strait
Copetihagen [US Embassy]
Coral Sea
Com Islands (Islas del Maiz)
Corsica
Cosmoledo Group
Cotonou [US Embassy]
Crete
Crooked Island Passage
Crozet Islands (lies Crozet)
Curacao [US Consulate General]
Cusco [US Consular Agency]
_ Czechoslovakia _
D Dahomey
Daito Islands
Dakar [US Embassy]
Daman (Damao)
Damascus [US Embassy]
Danger Atoll
Danish Straits
Danzig (Gdansk)
Dao Bach Long Vi
Dardanelles
Dar es Salaam [US Embassy]
Davis Strait
Deception Island
Denmark Strait
D''Entrecasteaux Islands
Devon Island
Dhahran [US Consulate General]
Dhaka [US Embassy]
Diego Garcia
Diego Ramirez
Diomede Islands
Diu
Entry in The World Factbook _
Taiwan
Moldova
Guantanamo [US Naval Base]
Halifax [US Consulate General]
Ionian Islands
Pemba Island
Tanzania
Pentland Filth
Atlantic Ocean
Parim
Netherlands Antilles
Netherlands Antilles
Atlantic Ocean
The Former Yugoslav Republic of Macedonia','5cbadca856ae41a4583a45c58043aec88e0883172a518a51cbc3357efd56859b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('788ada9fc3a3797d3b8daef1203de0b613f398adc310531c225f0773c0de20a0',1994,'IO','British Indian Ocean Territory','energy',1007,'Channel Islands
Guernsey; Jersey
Charlotte Amalie
Virgin Islands
Chatham Islands
Okhotsk, Sea of
Pacific Ocean
Okinawa','cb8f4d468e06a49a95b951638b4ca5ba00bc76b6acd13e2cb0841eb98940b955','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82b6d4d78f0d4c2ae1349d1f32f6557904f46c1460ad7aa8650bec7dbc8a0814',1994,'EC','Ecuador','energy',1008,'Russia
Galleons Passage
Atlantic Ocean
Gambler Islands (lies Gambler)
H
Ha''apai Group
R
Rabat [US Embassy]','ed864ecbe01c9a98a1d9156c0f65016646c5e48364fa9e6e67492c2553763ec8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12642fa92bd9824eebbfa7cd66958a722374b89bb06e72fd0e73bfb6a8b91e2e',1994,'PE','Peru','energy',1009,'Czech Republic; Slovakia _
Lincoln Sea
Arctic Ocean
Line Islands
Kiribati; Palmyra Atoll
Lisbon [US Embassy]
Pleasant Island','245a5557cefd6b4ee5f80f22622a4f7b3c8158749a7de84de681bf46168a5040','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('489a3cf16f0e7ccfeff15bf126fc7aa095f3a7dfd48463635250c0787a3fe514',1994,'PL','Poland','energy',1010,'Vietnam
Atlantic Ocean
Tanzania
Atlantic Ocean
Kuala Lumpur [US Embassy]
Prague [US Embassy]
Czech Republic
Praia [US Embassy]
Cape
Pretoria [US Embassy]
Washington, DC [The Permanent Mission of the USA to the
Organization of American States (OAS)]
United Slates
Weddell Sea
Atlantic Ocean
Wellington [US Embassy]','ff832ce4383932b945bbbdbd3b372b1a3ede3c6fe94095cf7b5185785b4b3b48','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c06b658fa0a9c2ac0053e4236e0c717992adf65235a3f116f292e7da4073a8c6',1994,'CM','Cameroon','energy',1011,'Douglas
Man, Isle of
Dover, Stttiit of
Atlantic Ocean
Drake Passage
Atlantic Ocean
Dubai (Dubayy) [US Consulate General]
French Indochina
Cambodia: Laos; Vietnam
French Guinea
Yap Islands
Micronesia
Yellow Sea
Pacific Ocean
Yemen (Aden) [People’s Democratic Republic of Yemen]','c5cfb2ebacfe5e8128401b7f2978130ca0f530163ecb7d0bf08d71a736a38d4c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63b9d4108f4d575b1b7f21158dae6660805ae3168024f5bbf9a1902f318d8ee1',1994,'IT','Italy','energy',1012,'Ellef Ringnes Island
Florida, Straits of
Atlantic Ocean
Formosa
Taiwan
Formosa Strait (Taiwan Strait)
Pacific Ocean
Fort-de-France [US Consulate General]
George Town [US Consular Agency]
Palk Strait
Indian Ocean
Palma de Mallorca [US Consular Agency]
Atlantic Ocean
Viemam
Atlantic Ocean
Atlantic Ocean
u
Udom [US Consulate]
Ulaanbaatar [US Embassy]
Ullung-do
Unimak Pass [strait]
Union of Soviet Socialist Republics','c8d921fc08d56a30f14d94f7dec6872b411181124ef6f614d63cd137655c2d5f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31d4af5c85c8def3e80088c89d4039c960f5d016e98bb9c73c922ba54576a579',1994,'MH','Marshall Islands','energy',1013,'England
Epirus, Northern
Albania; Greece
Essequibo [claimed by Venezuela]
Kyushu
Pacific Ocean
Rangoon [US Embassy]
Burma
Ratak Chain
Recife [US Consulate]','a41e93c97e3d4ca06b8aa8bf368461badc7465cd5408714707f02e3b1b36c184','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf2df99d7dfd6365bfbf52a9b965da227991bd49f9236d47cbf59fc9a8aa7e6a',1994,'TO','Tonga','energy',1014,'Frunze (Bishkek)
Habomai Islands
Russia [de facto]
Hague, The [US Embassy]
Novaya Zemlya
Russia
Nuevo Laredo [US Consulate]','6d8176d551be1c381b8af3defb6e93ce38ead5cc91547dd9060ccfc41de81b53','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5448b4f57f1340b81e01e264fbe49d5530e92727537690bd98aa6da5f4ce4595',1994,'JP','Japan','energy',1015,'Funafuti
Hong Kong [US Consulate General]
Hormuz, Strait of
Indian Ocean
Horn, Cape (Cabo de Homos)
Izmir [US Consulate General]
Turkey
J
Jakarta (US Embassy]
Kyyiv (Kiev)
Guam; Northern Mariana Islands
Itdy
Bahamas, The
Oman, Gulf of
Indian Ocean
Ombai Suait
Pacific Ocean
Oporto [US Consulate]
Oslo [US Embassy]
Paris [US Embassy, US Mission to the Organization for
Economic Cooperation and Development (OECD), US
Observer Mission at the UN Educational, Scientific, and
Cultural Organization (UNESCO)]
506
Indian Ocean
Pacific Ocean
Vostok Island','f3f9a2271f24f572dd991ec84d7de7e6dd4c7f1505e231c0eb033853206be80e','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2eb3a51130a340ac7b8f33b606b4728d239ce95f6fb861744ef8396ab8c9ff56',1994,'CU','Cuba','energy',1016,'Guatemala [US Embassy]
501
Name
Entry in The World Factbook
Hawaii
K
Kabul [US Embassy now closed]
Piura [US Consular Agency]
Yucatan Channel
Atlantic Ocean
Yugoslavia
Bosnia and Herz»ovina, Croatia, Serbia and Montenegro,
Slovenia, The Former Yugoslav Republic of Macedonia
Z
Zagreb [US Embassy]','bdf56dd2e38d1024cc11aa4bea34334f08a7dda9ea2662ce0d6aaff3d86d7155','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4839865738e85dd164e6c292dcf1f19ccc8711ea22cc8d573a3a628dadc27c5',1994,'GT','Guatemala','energy',1017,'Gubal, Strait of
Indian Ocean
Guinea, Gulf of
Atlantic Ocean
Guayaquil [US Consulate General]','a848916e74ff92cf1e06099151f716b8d055974f5036a06911ea12144245b30d','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09dcaddb1e80eae36e7000857388bba69a488997a3fa8a3a59896fe8cf249ef8',1994,'WF','Wallis and Futuna','energy',1018,'Horn of Afiica
Ethiopia; Somalia
Hudson Bay
Arctic Ocean
Hudson Strait
Arctic Ocean
I
Inaccessible Island
Saint Helena
Indochina
Cambodia; Laos; Vietnam
Inner Mongolia (Nei Mongol)','dd62ad6939f468b55831ee377842c44bdb95c977429d48472bc66cbf093b4a64','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83ea1b8dff836a0878b9fba3508a703b44f2d885c211333a5423f295fab337d1',1994,'SA','Saudi Arabia','energy',1019,'Jerusalem [US Consulate General]
Israel; West Bank
Johannesburg [US Consulate General]
South Afnca
Juan de Fuca, Strait of
Pacific Otean
Juan Fernandez, Isla de','a885c30b58a33ba83a404465432625288d37d4341be65ab6f202d1bcc1bab94f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1af3fc4dc88788eb4545b8d43f727c482dd3b40a3ad4f32fd6f852a90796473',1994,'KH','Cambodia','energy',1020,'Karachi [US Consulate General]
Khuriya Muriya Islands (Kuria Muria Islands)
Phoenix Islands','feafd6ae845620e0403d730fddca10928302c5075b2d6e48271ed8d892a34a6f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfbfc1e7600001130c270cff50bef0d8cbcd1a60cb21d7f26bb4963d4e0c678d',1994,'CC','Cocos (Keeling) Islands','energy',1021,'Kerguelen, lies
French Southern and Antarctic Lands
Kermadec Islands
West Korea Strait (Western Channel)
Pacific Ocean
West Pakistan','65fdfa2ea3aea6e2dff014158a757ae48fa467730166ac001d6f7dac60ac0f4b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('469ff172c26421a057de51fa083816ae48fa6ab5891e33ac35dd4baf894ea2ce',1994,'FM','Micronesia, Federated States of','energy',1022,'Korea Bay
Pacific Ocean
Korea, Democratic People’s Republic of
Korea, North
Korea, South
Serbia and Montenegro','7794fcbe1886374565ffd12d29fb504ce6fa572d714d2d06bb2045c4766ccea1','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d2a9a5dd901885051ea8f6df36c97fce22e15aa78e83e3ad37b6ec2d7c2c2d9',1994,'KR','Korea, Republic of','energy',1023,'Korea, South
Korea Strait
Pacific Ocean
Koror [US Liaison Office]
Pacific Islands, Thist Territory of
Kosovo
Serbia and Montenegro
Kowloon','28f5126daf6d891eaa480bccaf6f7f66e48a722d2f3077a91ae928718a9ecf65','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3bcc156b1ea64e8c44e5d11bf085ca5b1b0fadb9892a57fe50cd30c07b82de81',1994,'MY','Malaysia','energy',1024,'Kunashiri (Kunashir)
Russia [de facto]
Kuril Islands
Russia [de facto]
Kuwait [US Embassy]','11ff0425c7aa4b678791f4db2c83d34e639936c033f57b1cc2d54fa6ffa5803c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73da64978fcc8fc4a393a2301056481418031f25e72ec4ce0e6621be49047bda',1994,'FJ','Fiji','energy',1025,'Leipzig [US Consulate General]
CJermany
ningrad (see Saint Petersburg)
Russia
. .,sser Sunda Islands','87cf7771dda7edffb54b12f5d38ddfdedfdad417499ad0b864b68691ec4e27f8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('946e59bd4bea4fa2b5feaed817b49c492fe343850ff6fb0d8429802adca0382c',1994,'MO','Macao','energy',1026,'Macedonia
Macquarie Island
Madeira Islands
Madras [US Consulate General]
Madrid [US Embassy]
Magellan, Strait of
Maghreb
Mahe Island
Maiz, Islas del (Com Islands)
Majorca (Mallorca)
Majuro [US Embassy]
Makassar Strait
Malabo [US Embassy]
Malacca, Strait of
Malaga [US Consular Agency]
Malagasy Republic
Male [US post not maintained; representation from
Colombo, Sri Lanka]
Mallorca (Majorca)
Malpelo, Isla de
Malu Channel
Malvinas, Islas
Mamoutzou
Managua [US Embassy]
Manama [US Embassy]
Manaus [US Consular Agency]
Manchukuo
Manchuria
Manila [US Embassy]
Manipa Strait
Mannar, Gulf of
Manua Islands
Maputo [US Embassy]
Maracaibo [US Consulate]
Marcus Island (Minami-tori-shima)
Mariana Islands
Marion Island
Marmara, Sea of
Marquesas Islands (lies Marquises)
Marseille [US Consulate General]
Martin Vaz, Ilhas
Mas a Tierra (Robinson Cnisoe Island)
Mascarene Islands
Maseru [US Embassy]
Matamoros [US Consulate]
Mata Utu
Mazatlan [US Consulate]
Mbabane [US Embassy]
McDonald Islands
Medan [US Consulate]
Macau
The Former Yugoslav Republic of Macedonia','0f78c669ef37ca7441a49417371cc7775fb15ea6431fab1aa573073fdf300c22','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f83cb1de7d82c256be382e1cec9c3b4a971406f9d943673b097b646318aded4',1994,'MC','Monaco','energy',1027,'Mona Passage
Monrovia [US Embassy]
Montego Bay [US Consular Agency]
Atlantic Ocean','5298459c0f293e4e0407acf34150c3056311fdbbebd34096b9d593a067e0c58f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc71fe739916c75c594c82e0e63e931b78feb3f3e2437bb4be625395b9ce0d29',1994,'ME','Montenegro','energy',1028,'Monterrey [US Consulate General]
Montevideo [US Embassy]
Montreal [US Consulate General, US Mission to the
International Civil Aviation Organization (ICAO)]
Moravian Gate
Moroni [US Embassy]
Mortlock Islands
Moscow [US Embassy]
Mozambique Channel
Mulege [US Consular Agency]
Munich [ JS Consulate General]
Musandam Peninsula
Muscat [US Embassy]
Muscat and Oman
_ Myanma, Myanmar _
N Naha [US Consulate General]
Nairobi [US Embassy]
Nampo-shoto
Naples [US Consulate General]
Nassau [US Embassy]
Natuna Besar Islands
N’Djamena [US Embassy]
Netherlands East Indies
Netherlands Guiana
Nevis
New Delhi [US Embassy]
Newfoundland
New Guinea
New Hebrides
New Siberian Islands
New Territories
New York, New York [US Mission to the United Nations
(USUN)]
Niamey [US Embassy]
Nice [US Consular Agency]
Nicobar Islands
Nicosia [US Embassy]
Nightingale Island
Entry in The World Factbook
Atlantic Ocean','02beccb4156664a335fa25ef309ab85bf3507c9728d91b6686cee3ecba7fd465','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bdb36b8e2b81987abfd2153407fecdd08a7d80473e38568709d1d0392aad7a40',1994,'CY','Cyprus','energy',1029,'Saint Helena
503
Name
Entry in The HbrU Facibook
North Atlantic Ocean
Atlantic Ocean
North Channel
Atlantic Ocean
Northeast Providence Channel
Atlantic Ocean
Northern Epirus
Albania; Greece
Northern Ctenadines','35c0e9f83de0eeba33e75474803a9f7e8b510b84cab61770ff93fb3c398f2359','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb0ab53e618bd8bb52d81bef382070651be2ecca3661e94ecf87ee59da3a37f1',1994,'MN','Mongolia','energy',1030,'p
Pagan
Korea, South
Pacific Ocean
Armenia, Azerbaijan, Belarus, Estonia, Georgia, Kazakhstan,
Kyrgyzstan, Latvia, Lithuania, Moldova, Russia,
Tajikistan, Turkmenistan, Ukraine, Uzbekistan
United Arab Republic
Egypt; Syria
Upper Volta
Burkina
USSR
Armenia, Azerbaijan, Belarus, Estonia, Georgia, Kazakhstan,
Kyrgyzstan, Latvia, Lithuania, Moldova, Russia,
Tajikistan, Turkmenistan, Ukraine, Uzbekistan
V
Vaduz [US post not maintained; representation from Zurich,
Switzerland]
Vakhan Corridor (Wakhan)','b1b93c89ae019956047086f0830b81b6425e9f5c2d87d3a2e47980251be7be36','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76a98d434fd71f34be3ad6406488119e1e91023be9b28be587815cfc11925909',1994,'SM','San Marino','energy',1031,'San Miguel Allende (US Consultf Agency]
San Salvador [US Embassy]
Santa Cnia [US Consular Agency]
Santa Crux Islands
Santiago [US Embassy]
Santo Domingo [US Embassy]
Sao Luis [US Consular Agency]
Sao Paulo [US Consulate Qene^]
Sao Pedro e Sao Paulo, Penedos de
Sao Tome
Sapporo [US Consulate General]
Sapudi Strait
Sa^evo
Sarawak
Sardinia
Sargasso Sea
Sark
Scotia Sea
Scotland
Scott Island
Senyavin Islands
Seoul [US Embassy]','a6ae12042015c7ad55fcf9b9460b08b5238232a82f0d1eb3d0cd18d2ad8e35b2','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70e70a09c42bccb7d027dda5407445b3d89d8259de705ff0b033c8bebdc90ad4',1994,'RS','Serbia','energy',1032,'Seirana Bonk
Serranilla Bank
Settlement, The
Severnaya Zemlya (Northland)
Seville [US Consular Agency]
Shag Island
Shag Rocks
Shanghai [US Consulate General]
Shenyang [US Consulate General]
Shetland Islands
Shikoku
Shikotan (Shikotan-to)
Siam
Sibutu Passage
Sicily
Sicily, Strait of
Sikkim
Sinai
Singapore [US Embassy]
Singapore Strait
Sinkiang (Xinjiang)
Sint Eustatius
Sint Maarten (Saint Martin)
Skagerrak
Skopje
Society Islands (lies de la Societe)
Socotra
Sofia [US Embassy]
Solomon Islands, northern
Solomon Islands, southern
Entry in The Bbrfcf FocHmik','b37bcd57ea74f2eab3695520bbeb009ab1117bc9c8a95313e0f19d3860773248','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('685f53a436d299baadf146e76d52f0a570445d66ca9be05d8c6dd37a0c0be453',1994,'HR','Croatia','energy',1033,'Zanzibar
Tanzania
Zurich [US Consulate General]
Switzeriand
512
Political Map of the World
150
Arctic Ocean
120
North
/
Pacific
Ocean
I At! anti Cl
!
Ocean
8023S0 (B01267) 6 94
802292 (545928) 9*94
8022S3 (R010S3) 6-»4
Ethnic Groups in Eastern Europe
Majority Minority
praaanct prMinoa
ata»4(R01QM)M4
Commonwealth off Independent States - Central Asian States
Southeast Asia
UPlpUf
602262 (S45666) 0-04
Nfmliin of 26 Airtiiclic camuMiw
mttom hM modt no cMm lo AnIiRtic
^ taittaryfalllKM^RuMMlthoUniM
SIMM hiM loMnod tho rigit to 6o «o)
Ml do not focopilit tho dalint of tho
othirniiKm.
South
A ttantic
\\ Ocean
atehamatmntHm
y<Mith CmAiM Mtndt
^ (HWimoUBHU-K-.
\\d»lmw)ftMIOCTnPai
TH CLAIM
NORWEGIAN ClAm
(iwnfwa i.}‘UK..
cMntObyAlOeNTlNA)
AR^NTiNeCUlM^
I Bellingshausen
I Sea
chileancLaim ! T. . I - /
T \\ " y
\\ \\ ^mondsen^.
\\ South ^
^.iShacklaton I
""hfJcaBhaB
^Pacifi^
Ocean
\\ /
\\/
\\ \\
\\
\\
\\
.t
''■■!/
/ ''x
I ff05S /
tesT’
, ocN/m/ ij''
\\^LAND ClAIM
y\\PRCNi
iMMduiflitMMd
uumiMJAi
\\
/ • Selected jnerwound reweirh iMon
Soifc 1:56.000.000
’ AiinueiifEdiaMnihqlKetan /
0 BOO lOOOieuiifl /
NEK
ShMIiW
ZEALAND
Indian
Ocean
Add timt tone numMr to loeot tim* lo obloin utc
Sudlroct iimt <ont numeor trom ulc lo oDioin loci* timi','3130eb3e754ab9e47e1d21a520c31b5acaea1c1046818b8ea98b4876057e2bc1','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('057f70b3f6becdbeef04ee08406fed2c8f54614fe88c2738dc6285df400a31d1',1994,'UZ','Uzbekistan','energy',232,'members - (23) Australia, Austria, Belgium, Canada, Denmark, Finland,
France, Germany, Greece, Iceland, Ireland, Italy, Japan, Luxembourg,
Netherlands, Norway, Portugal, Spain, Sweden, Switzerland, Turkey, UK, US
-----
Nuclear Suppliers Group (NSG)
note - also known as the London Suppliers Group
established - 1974
aim - to establish guidelines for exports of technical information,
processing equipment for uranium enrichment and nuclear materials to
countries of proliferation concern and regions of conflict and instability
members - (28) Australia, Austria, Belgium, Bulgaria, Canada, Czech
Republic, Denmark, Finland, France, Germany, Greece, Hungary, Ireland,
Italy, Japan, Luxembourg, Netherlands, Norway, Poland, Portugal, Romania,
Russia, Slovakia, Spain, Sweden, Switzerland, UK, US
-----
Organismo para la Proscripcion de las Armas Nucleares en la America Latina
y el Caribe (OPANAL)
see Agency for the Prohibition of Nuclear Weapons in Latin America and the
Caribbean (OPANAL)
-----
Organization for Economic Cooperation and Development (OECD)
established - 14 December 1960
effective - 30 September 1961
aim - to promote economic cooperation and development
members - (25) Australia, Austria, Belgium, Canada, Denmark, Finland,
France, Germany, Greece, Iceland, Ireland, Italy, Japan, Luxembourg,
Mexico, Netherlands, NZ, Norway, Portugal, Spain, Sweden, Switzerland,
Turkey, UK, US
special member - (1) EU
-----
Organization of African Unity (OAU)
established - 25 May 1963
aim - to promote unity and cooperation among African states
members - (53) Algeria, Angola, Benin, Botswana, Burkina, Burundi,
Cameroon, Cape Verde, Central African Republic, Chad, Comoros, Congo, Cote
d''Ivoire, Djibouti, Egypt, Equatorial Guinea, Eritrea, Ethiopia, Gabon, The
Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Lesotho, Liberia, Libya,
Madagascar, Malawi, Mali, Mauritania, Mauritius, Mozambique, Namibia,
Niger, Nigeria, Rwanda, Sahrawi Arab Democratic Republic, Sao Tome and
Principe, Senegal, Seychelles, Sierra Leone, Somalia, South Africa, Sudan,
Swaziland, Tanzania, Togo, Tunisia, Uganda, Zaire, Zambia, Zimbabwe
-----
Organization of American States (OAS)
established - 30 April 1948
effective - 13 December 1951
aim - to promote regional peace and security as well as economic and social
development
members - (35) Antigua and Barbuda, Argentina, The Bahamas, Barbados,
Belize, Bolivia, Brazil, Canada, Chile, Colombia, Costa Rica, Cuba
(excluded from formal participation since 1962), Dominica, Dominican
Republic, Ecuador, El Salvador, Grenada, Guatemala, Guyana, Haiti,
Honduras, Jamaica, Mexico, Nicaragua, Panama, Paraguay, Peru, Saint Kitts
and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Suriname,
Trinidad and Tobago, US, Uruguay, Venezuela
observers - (31) Algeria, Angola, Austria, Belgium, Central American
Parliament, Cyprus, Egypt, Equatorial Guinea, EU, Finland, France, Germany,
Greece, Holy See, Hungary, India, Israel, Italy, Japan, South Korea,
Morocco, Netherlands, Pakistan, Poland, Portugal, Romania, Russia, Saudi
Arabia, Spain, Switzerland, Tunisia
-----
Organization of Arab Petroleum Exporting Countries (OAPEC)
established - 9 January 1968
aim - to promote cooperation in the petroleum industry
members - (10) Algeria, Bahrain, Egypt, Iraq, Kuwait, Libya, Qatar, Saudi
Arabia, Syria, UAE
-----
Organization of Eastern Caribbean States (OECS)
established - 18 June 1981
effective - 4 July 1981
aim - to promote political, economic, and defense cooperation
members - (7) Antigua and Barbuda, Dominica, Grenada, Montserrat, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines
associate member - (1) British Virgin Islands
-----
Organization of Petroleum Exporting Countries (OPEC)
established - 14 September 1960
aim - to coordinate petroleum policies
members - (12) Algeria, Gabon, Indonesia, Iran, Iraq, Kuwait, Libya,
Nigeria, Qatar, Saudi Arabia, UAE, Venezuela
-----
Organization of the Islamic Conference (OIC)
established - 22-25 September 1969
aim - to promote Islamic solidarity and cooperation in economic, social,
cultural, and political affairs
members - (47 plus the Palestine Liberation Organization) Afghanistan
(suspended), Albania, Algeria, Azerbaijan, Bahrain, Bangladesh, Benin,
Brunei, Burkina, Cameroon, Chad, Comoros, Djibouti, Egypt, Gabon, The
Gambia, Guinea, Guinea-Bissau, Indonesia, Iran, Iraq, Jordan, Kuwait,
Kyrgyzstan, Lebanon, Libya, Malaysia, Maldives, Mali, Mauritania, Morocco,
Niger, Oman, Pakistan, Qatar, Saudi Arabia, Senegal, Sierra Leone, Somalia,
Syria, Tajikistan, Tunisia, Turkey, Turkmenistan, Uganda, UAE, Yemen,
Palestine Liberation Organization
observers - (4) Kazakhstan, Mozambique, Nigeria, "Turkish Republic of
Northern Cyprus"
-----
Paris Club
see Group of 10
-----
Permanent Court of Arbitration (PCA)
established - 29 July 1899
aim - to facilitate the settlement of international disputes
members - (78) Argentina, Australia, Austria, Belarus, Belgium, Bolivia,
Brazil, Bulgaria, Burkina, Cambodia, Cameroon, Canada, Chile, China,
Colombia, Cuba, Czech Republic, Denmark, Dominican Republic, Ecuador,
Egypt, El Salvador, Fiji, Finland, France, Germany, Greece, Guatemala,
Haiti, Honduras, Hungary, Iceland, India, Iran, Iraq, Israel, Italy, Japan,
Jordan, Kyrgyzstan, Laos, Lebanon, Luxembourg, Malta, Mauritius, Mexico,
Netherlands, NZ, Nicaragua, Nigeria, Norway, Pakistan, Panama, Paraguay,
Peru, Poland, Portugal, Romania, Russia, Senegal, Slovakia, Spain, Sri
Lanka, Sudan, Swaziland, Sweden, Switzerland, Thailand, Turkey, Uganda,
Ukraine, UK, US, Uruguay, Venezuela, Yugoslavia, Zaire, Zimbabwe
-----
Population Commission
established - 3 October 1946
aim - Economic and Social Council organization dealing with population
matters of importance to the UN
members - (27) selected on a rotating basis from all regions
-----
Rio Group (RG)
note - formerly known as Grupo de los Ocho, established in December 1986
established - NA 1988
aim - a consultation mechanism on regional Latin American issues
members - (11) Argentina, Bolivia, Brazil, Chile, Colombia, Ecuador,
Mexico, Paraguay, Peru (suspended), Uruguay, Venezuela; note-Panama was
expelled in 1988; Peru was suspended after April 1992 coup
-----
Second World
another term for the traditionally Marxist-Leninist states with
authoritarian governments and command economies based on the Soviet model;
the term is fading from use; see centrally planned economies
-----
socialist countries in general, countries in which the government owns and
plans the use of the major factors of production; note - the term is
sometimes used incorrectly as a synonym for Communist countries
-----
South
a popular term for the poorer, less industrialized countries generally
located south of the developed countries; the counterpart of the North; see
less developed countries (LDCs)
-----
South Asian Association for Regional Cooperation (SAARC)
established - 8 December 1985
aim - to promote economic, social, and cultural cooperation
members - (7) Bangladesh, Bhutan, India, Maldives, Nepal, Pakistan, Sri
Lanka
-----
South Pacific Commission (SPC)
established - 6 February 1947
effective - 29 July 1948
aim - to promote regional cooperation in economic and social matters
members - (27) American Samoa, Australia, Cook Islands, Fiji, France,
French Polynesia, Guam, Kiribati, Marshall Islands, Federated States of
Micronesia, Nauru, New Caledonia, NZ, Niue, Northern Mariana Islands, Trust
Territory of the Pacific Islands (Palau), Papua New Guinea, Pitcairn
Islands, Solomon Islands, Tokelau, Tonga, Tuvalu, UK, US, Vanuatu, Wallis
and Futuna, Western Samoa
-----
South Pacific Forum (SPF)
established - 5 August 1971
aim - to promote regional cooperation in political matters
members - (15) Australia, Cook Islands, Fiji, Kiribati, Marshall Islands,
Federated States of Micronesia, Nauru, NZ, Niue, Papua New Guinea, Solomon
Islands, Tonga, Tuvalu, Vanuatu, Western Samoa
observer - (1) Trust Territory of the Pacific Islands (Palau)
-----
South Pacific Regional Trade and Economic Cooperation Agreement (SPARTECA)
established - NA 1981
aim - to redress unequal trade relationship of Australia and New Zealand
with small island economies in Pacific region
members - (15) Australia, Cook Islands, Fiji, Kiribati, Marshall Islands,
Federated States of Micronesia, Nauru, NZ, Niue, Papua New Guinea, Solomon
Islands, Tonga, Tuvalu, Vanuatu, Western Samoa
-----
Southern African Customs Union (SACU)
established - 11 December 1969
aim - to promote free trade and cooperation in customs matters
members - (9) Botswana, Lesotho, Namibia, South Africa, Swaziland
-----
Southern African Development Community (SADC)
note - evolved from the Southern African Development Coordination
Conference (SADCC)
established - 17 August 1992
aim - to promote regional economic development and integration
members - (10) Angola, Botswana, Lesotho, Malawi, Mozambique, Namibia,
Swaziland, Tanzania, Zambia, Zimbabwe
-----
Southern Cone Common Market (MERCOSUR)
established - 26 March 1991
aim - regional economic cooperation
members - (4) Argentina, Brazil, Paraguay, Uruguay
-----
Statistical Commission
established - 21 June 1946
aim - Economic and Social Council organization dealing with development and
standardization of national statistics of interest to the UN
members - (25) selected on a rotating basis from all regions
-----
Third World
another term for the less developed countries; the term is fading from use;
see less developed countries (LDCs)
-----
underdeveloped countries
refers to those less developed countries with the potential for above-
average economic growth; see less developed countries (LDCs)
-----
undeveloped countries
refers to those extremely poor less developed countries (LDCs) with little
prospect for economic growth; see least developed countries (LLDCs)
-----
Union Douaniere et Economique de l''Afrique Centrale (UDEAC)
see Central African Customs and Economic Union (UDEAC)
-----
United Nations (UN)
established - 26 June 1945
effective - 24 October 1945
aim - to maintain international peace and security and to promote
cooperation involving economic, social, cultural and humanitarian problems
members - (183 excluding Yugoslavia) Afghanistan, Albania, Algeria,
Andorra, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus,
Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana,
Brazil, Brunei, Bulgaria, Burkina, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt,
El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kazakhstan, Kenya, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein,
Lithuania, Luxembourg, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama,
Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent
and the Grenadines, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon
Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Syria, Tajikistan, Tanzania, Thailand, The Former
Yugoslav Republic of Macedonia, Togo, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu,
Venezuela, Vietnam, Western Samoa, Yemen, Yugoslavia (suspended), Zaire,
Zambia, Zimbabwe; note - all UN members are represented in the General
Assembly
observers - (2 plus the Palestine Liberation Organization) Holy See,
Switzerland, Palestine Liberation Organization
-----
United Nations Angola Verification Mission (UNAVEM II)
note - successor to original UNAVEM
established - 20 December 1988
aim - established by the UN Security Council to verify the withdrawal of
Cuban troops from Angola
members - (25) Algeria, Argentina, Brazil, Canada, Congo, Czech Republic,
Egypt, Guinea-Bissau, Hungary, India, Ireland, Jordan, Malaysia, Morocco,
Netherlands, NZ, Nigeria, Norway, Senegal, Singapore, Slovakia, Spain,
Sweden, Yugoslavia, Zimbabwe
-----
United Nations Children''s Fund (UNICEF)
note - acronym retained from the predecessor organization UN International
Children''s Emergency Fund
established - 11 December 1946
aim - to help establish child health and welfare services
members - (41) selected on a rotating basis from all regions
-----
United Nations Conference on Trade and Development
(UNCTAD)
established - 30 December 1964
aim - to promote international trade
members - (187) all UN members plus Holy See, Switzerland, Tonga
-----
United Nations Development Program (UNDP)
established - 22 November 1965
aim - to provide technical assistance to stimulate economic and social
development
members - (48) selected on a rotating basis from all regions
-----
United Nations Disengagement Observer Force (UNDOF)
established - 31 May 1974
aim - established by the UN Security Council to observe the 1973 Arab-
Israeli ceasefire
members - (4) Austria, Canada, Finland, Poland
-----
United Nations Educational, Scientific, and Cultural Organization (UNESCO)
established - 16 November 1945
effective - 4 November 1946
aim - to promote cooperation in education, science, and culture
members - (178) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina, Burma,
Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic,
Chad, Chile, China, Colombia, Comoros, Congo, Cook Islands, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia,
Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius,
Mexico, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama,
Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent
and the Grenadines, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Seychelles, Sierra Leone, Slovakia, Slovenia, Solomon Islands,
Somalia, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland,
Syria, Tajikistan, Tanzania, Thailand, The Former Yugoslav Republic of
Macedonia, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan,
Tuvalu, Uganda, Ukraine, UAE, Uruguay, Venezuela, Vietnam, Western Samoa,
Yemen, Yugoslavia (suspended), Zaire, Zambia, Zimbabwe
associate members - (3) Aruba, British Virgin Islands, Netherlands Antilles
-----
United Nations Environment Program (UNEP)
established - 15 December 1972
aim - to promote international cooperation on all environmental matters
members - (58) selected on a rotating basis from all regions
-----
United Nations Force in Cyprus (UNFICYP)
established - 4 March 1964
aim - established by the UN Security Council to serve as a peacekeeping
force between Greek Cypriots and Turkish Cypriots in Cyprus
members - (8) Australia, Austria, Canada, Denmark, Finland, Ireland,
Sweden, UK
-----
United Nations General Assembly
established - 26 June 1945
effective - 24 October 1945
aim - primary deliberative organ in the UN
members - (184) all UN members are represented in the General Assembly
-----
United Nations Industrial Development Organization (UNIDO)
established - 17 November 1966
effective - 1 January 1967
aim - UN specialized agency that promotes industrial development especially
among the members
members - (165) Afghanistan, Albania, Algeria, Angola, Argentina, Armenia,
Australia, Austria, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus,
Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana,
Brazil, Bulgaria, Burkina, Burma, Burundi, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, China, Colombia, Comoros, Congo,
Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Ethiopia, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Hungary, India, Indonesia, Iran, Iraq, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kenya, North Korea, South Korea,
Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Luxembourg, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco, Mozambique,
Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Sao Tome and Principe, Saudi
Arabia, Senegal, Seychelles, Sierra Leone, Slovakia, Slovenia, Somalia,
Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, The Former Yugoslav Republic of Macedonia,
Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, UAE,
UK, US, Uruguay, Vanuatu, Venezuela, Vietnam, Yemen, Yugoslavia
(suspended), Zaire, Zambia, Zimbabwe
-----
United Nations Interim Force in Lebanon (UNIFIL)
established - 19 March 1978
aim - established by the UN Security Council to confirm the withdrawal of
Israeli forces, restore peace, and reestablish Lebanese authority in
southern Lebanon
members - (10) Fiji, Finland, France, Ghana, Ireland, Italy, Nepal, Norway,
Poland, Sweden
-----
United Nations Iraq-Kuwait Observation Mission (UNIKOM)
established - 9 April 1991
aim - established by the UN Security Council to observe and monitor the
demilitarized zone established between Iraq and Kuwait
members - (33) Argentina, Austria, Bangladesh, Canada, China, Denmark,
Fiji, Finland, France, Ghana, Greece, Hungary, India, Indonesia, Ireland,
Italy, Kenya, Malaysia, Nigeria, Norway, Pakistan, Poland, Romania, Russia,
Senegal, Singapore, Sweden, Thailand, Turkey, UK, US, Uruguay, Venezuela
-----
United Nations Military Observer Group in India and Pakistan (UNMOGIP)
established - 13 August 1948
aim - established by the UN Security Council to observe the 1949
India-Pakistan ceasefire
members - (8) Belgium, Chile, Denmark, Finland, Italy, Norway, Sweden,','14f2ec8a85beb9aea24b11002ddc0a1ffc41cc6bd36566c6cf87f1664644039e','internet-archive','theciaworldfactb00180gut','txt','b76993377cfa6bdd51979833301976cfc440911ee1fe0b90c117008758860b3f','https://archive.org/download/theciaworldfactb00180gut/180.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d6ce5551a7fd69c70339cc5911042a701d7f5ee14aa65c5310e8f86b761036e',1994,'UY','Uruguay','energy',233,'-----
United Nations Mission for the Referendum in Western Sahara
(MINURSO)
established - 29 April 1991
aim - established by the UN Security Council to supervise the
referendum in Western Sahara
members - (26) Argentina, Australia, Austria, Bangladesh, Belgium, Canada,
China, Egypt, France, Ghana, Greece, Guinea, Honduras, Ireland, Italy,
Kenya, Malaysia, Nigeria, Pakistan, Poland, Russia, Switzerland, Tunisia,
UK, US, Venezuela
-----
United Nations Observer Mission in El Salvador (ONUSAL)
established - 20 May 1991
aim - established by the UN Security Council to verify ceasefire
arrangements and to monitor the maintenance of public order pending the
organization of a new National Civil Police
members - (16) Austria, Brazil, Canada, Chile, Colombia, Ecuador, France,
Guyana, India, Ireland, Italy, Mexico, Norway, Spain, Sweden, Venezuela
-----
United Nations Observer Mission in Georgia (UNOMIG)
established - 1993 for a period of six months
aim - to verify compliance with the cease-fire agreement reached 27 July
1993 and investigate reports of violations of that agreement
members - (10) Austria, Bangladesh, Czech Republic, Denmark, Germany,
Greece, Poland, Sierra Leone, Sweden, Switzerland
-----
United Nations Observer Mission Uganda-Rwanda (UNOMUR)
established - 1993 for six months
aim - to monitor the Uganda/Rwanda border to verify that no military
assistance reaches Rwanda across the border
members - (10) Bangladesh, Botswana, Brazil, Canada, Fiji, Hungary,
Netherlands, Senegal Slovakia, Zimbabwe
-----
United Nations Office of the High Commissioner for Refugees (UNHCR)
established - 3 December 1949
effective - 1 January 1951
aim - to try to ensure the humanitarian treatment of refugees and find
permanent solutions to refugee problems
members - (46) Algeria, Argentina, Australia, Austria, Belgium, Brazil,
Canada, China, Colombia, Denmark, Ethiopia, Finland, France, Germany,
Greece, Holy See, Hungary, Iran, Israel, Italy, Japan, Lebanon, Lesotho,
Madagascar, Morocco, Namibia, Netherlands, Nicaragua, Nigeria, Norway,
Pakistan, Philippines, Somalia, Sudan, Sweden, Switzerland, Tanzania,
Thailand, Tunisia, Turkey, Uganda, UK, US, Venezuela, Yugoslavia, Zaire
-----
United Nations Operation in Mozambique (UNOMOZ)
established - 16 December 1992
aim - established by the UN Security Council to supervise the ceasefire
members - (18) Argentina, Bangladesh, Botswana, Brazil, Canada, Cape Verde,
Czech Republic, Egypt, Guinea-Bissau, Hungary, India, Malaysia, Portugal,
Russia, Spain, Sweden, Uruguay, Zambia
-----
United Nations Operation in Somalia (UNOSOM)
established - 24 April 1992
aim - established by the UN Security Council to facilitate an immediate
cessation of hostilities, to maintain a ceasefire in order to promote a
political settlement, and to provide urgent humanitarian assistance
members - (33) Argentina, Australia, Bangladesh, Belgium, Botswana, Egypt,
France, Germany, Greece, Hungary, India, Indonesia, Ireland, Italy, Jordan,
South Korea, Malaysia, Morocco, Namibia, NZ, Nigeria, Norway, Pakistan,
Romania, Saudi Arabia, Sweden, Tunisia, Turkey, Uganda, UAE, US, Zambia,','11226e9b291266bfe135c4173ee96f4430b2ec2193759ee5eb4e5196bcb85b99','internet-archive','theciaworldfactb00180gut','txt','b76993377cfa6bdd51979833301976cfc440911ee1fe0b90c117008758860b3f','https://archive.org/download/theciaworldfactb00180gut/180.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd013bbdea54606a8a4bdd49c0aa0fceb6a724b629ee034a306af19581f226b7',1994,'ZW','Zimbabwe','energy',234,'-----
United Nations Population Fund (UNFPA)
note - acronym retained from predecessor organization UN Fund for
Population Activities
established - NA July 1967
aim - to assist in both developed and developing countries dealing with
population problems
members - (51) selected on a rotating basis from all regions
-----
United Nations Protection Force (UNPROFOR)
established - 28 February 1992
aim - established by the UN Security Council to create conditions for peace
and security required for the negotiation of an overall settlement of the
"Yugoslav" crisis
members - (34) Argentina, Australia, Bangladesh, Belgium, Brazil, Canada,
Colombia, Czech Republic, Denmark, Egypt, Finland, France, Ghana, India,
Ireland, Jordan, Kenya, Luxembourg, Nepal, Netherlands, NZ, Nigeria,
Norway, Poland, Portugal, Russia, Slovakia, Spain, Sweden, Switzerland,
Tunisia, Ukraine, UK, Venezuela
-----
United Nations Relief and Works Agency for Palestine Refugees in the Near
East (UNRWA)
established - 8 December 1949
aim - to provide assistance to Palestinian refugees
members - (10) Belgium, Egypt, France, Japan, Jordan, Lebanon, Syria,
Turkey, UK, US
-----
United Nations Secretariat
established - 26 June 1945
effective - 24 October 1945
aim - to serve as the primary administrative organ of the UN; a Secretary
General is appointed for a five-year term by the General Assembly on the
recommendation of the Security Council
-----
United Nations Security Council
established - 26 June 1945
effective - 24 October 1945
aim - to maintain international peace and security
permanent members - (5) China, France, Russia, UK, US
nonpermanent members - (10) elected for two-year terms by the UN General
Assembly; Brazil (1993-94), Cape Verde (1992-93), Djibouti (1993-94),
Hungary (1992-93), Japan (1992-93), Morocco (1992-93), NZ (1993-94),
Pakistan (1993-94), Spain (1993-94), Venezuela (1992-93)
-----
United Nations Transitional Authority in Cambodia (UNTAC)
established - 28 February 1992
aim - established by the UN Security Council to contribute to the
restoration and maintenance of peace and to the holding of free elections
members - (45) Algeria, Argentina, Australia, Austria, Bangladesh, Belgium,
Brunei, Bulgaria, Cameroon, Canada, Chile, China, Colombia, Egypt, Fiji,
France, Germany, Ghana, Hungary, India, Indonesia, Ireland, Italy, Japan,
Jordan, Kenya, Malaysia, Morocco, Nepal, Netherlands, NZ, Nigeria, Norway,
Pakistan, Philippines, Poland, Russia, Senegal, Singapore, Sweden,
Thailand, Tunisia, UK, US, Uruguay
-----
United Nations Truce Supervision Organization (UNTSO)
established - NA May 1948
aim - initially established by the UN Security Council to supervise the
1948 Arab-Israeli ceasefire and subsequently extended to work in the Sinai,
Lebanon, Jordan, Afghanistan, and Pakistan
members - (19) Argentina, Australia, Austria, Belgium, Canada, Chile,
China, Denmark, Finland, France, Ireland, Italy, Netherlands, NZ, Norway,
Russia, Sweden, Switzerland, US
-----
United Nations Trusteeship Council
established - 26 June 1945
effective - 24 October 1945
aim - to supervise the administration of the UN trust territories; only one
of the original 11 trusteeships remains - the Trust Territory of the
Pacific Islands (Palau)
members - (5) China, France, Russia, UK, US
-----
Universal Postal Union (UPU)
established - 9 October 1874, affiliated with the UN 15 November 1947
effective - 1 July 1948
aim - UN specialized agency that promotes international postal cooperation
members-(185) Afghanistan, Albania, Algeria, Angola, Argentina, Armenia,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados,
Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Brunei, Bulgaria, Burkina, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Holy See,
Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel,
Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea,
South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia,
Libya, Liechtenstein, Lithuania, Luxembourg, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands,
Netherlands Antilles, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Overseas
Territories of the UK, Pakistan, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts
and Nevis, Saint Lucia, Saint Vincent and the Grenadines, San Marino, Sao
Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tanzania, Thailand,
The Former Yugoslav Republic of Macedonia, Togo, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK,
US, Uruguay, Vanuatu, Venezuela, Vietnam, Western Samoa, Yemen, Yugoslavia
(suspended), Zaire, Zambia, Zimbabwe
------
Warsaw Pact (WP)
was established 14 May 1955 to promote mutual defense; members met 1 July
1991 to dissolve the alliance; member states at the time of dissolution
were Bulgaria, Czechoslovakia, Hungary, Poland, Romania, and the USSR;
earlier members included East Germany and Albania
-----
West African Development Bank (WADB)
note - also known as Banque Ouest-Africaine de Developpement (BOAD)
established - 14 November 1973
aim - to promote regional economic development and integration
members - (7) Benin, Burkina, Cote d''Ivoire, Mali, Niger, Senegal,
associate members - (2) Puerto Rico, Tokelau
-----
World Intellectual Property Organization (WIPO)
established - 14 July 1967
effective - 26 April 1970
aim - UN specialized agency concerned with the protection of literary,
artistic, and scientific works
members - (140) Albania, Algeria, Angola, Argentina, Armenia, Australia,
Austria, The Bahamas, Bangladesh, Barbados, Belarus, Belgium, Benin,
Bolivia, Brazil, Bulgaria, Burkina, Burundi, Cameroon, Canada, Central
African Republic, Chad, Chile, China, Colombia, Congo, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Ecuador, Egypt,
El Salvador, Fiji, Finland, France, Gabon, The Gambia, Germany, Ghana,
Greece, Guatemala, Guinea, Guinea-Bissau, Haiti, Holy See, Honduras,
Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kenya, North Korea, South Korea, Latvia, Lebanon,
Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico,
Moldova, Monaco, Mongolia, Morocco, Namibia, Netherlands, NZ, Nicaragua,
Niger, Norway, Pakistan, Panama, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Lucia, San Marino, Saudi
Arabia, Senegal, Sierra Leone, Singapore, Slovakia, Slovenia, Somalia,
South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden,
Switzerland, Syria, Tanzania, Thailand, The Former Yugoslav Republic of
Macedonia, Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine,
UAE, UK, US, Uruguay, Venezuela, Vietnam, Yemen, Yugoslavia (suspended),
Zaire, Zambia, Zimbabwe
-----
World Meteorological Organization (WMO)
established - 11 October 1947
effective - 4 April 1951
aim - specialized UN agency concerned with meteorological cooperation
members - (173) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, The Bahamas, Bahrain, Bangladesh,
Barbados, Belarus, Belgium, Belize, Benin, Bolivia, Botswana, Brazil,
British Caribbean Territories, Brunei, Bulgaria, Burkina, Burma, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad,
Chile, China, Colombia, Comoros, Congo, Costa Rica, Cote d''Ivoire, Croatia,
Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Eritrea, Estonia, Ethiopia, Fiji,
Finland, France, French Polynesia, Gabon, The Gambia, Germany, Ghana,
Greece, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hong
Kong, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel,
Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea, South Korea,
Kuwait, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania,
Luxembourg, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Mauritania, Mauritius, Mexico, Mongolia, Morocco, Mozambique, Namibia,
Nepal, Netherlands, Netherlands Antilles, New Caledonia, NZ, Nicaragua,
Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay,
Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint
Lucia, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra
Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South
Africa (suspended), Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden,
Switzerland, Syria, Tajikistan, Tanzania, Thailand, The Former Yugoslav
Republic of Macedonia, Togo, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu,
Venezuela, Vietnam, Yemen, Yugoslavia (suspended), Zaire, Zambia, Zimbabwe
-----
World Tourism Organization (WTO)
established - 2 January 1975
aim - to promote tourism as a means of contributing to economic
development, international understanding, and peace
members - (109) Afghanistan, Algeria, Angola, Argentina, Austria,
Bangladesh, Belgium, Benin, Bolivia, Brazil, Bulgaria, Burkina, Burundi,
Cambodia, Cameroon, Canada, Chad, Chile, China, Colombia, Congo, Cote
d''Ivoire, Cuba, Cyprus, Czech Republic, Dominican Republic, Ecuador, Egypt,
Ethiopia, Finland, France, Gabon, The Gambia, Germany, Ghana, Greece,
Grenada, Guinea, Guinea-Bissau, Haiti, Hungary, India, Indonesia, Iran,
Iraq, Israel, Italy, Jamaica, Japan, Jordan, Kenya, North Korea, South
Korea, Kuwait, Laos, Lebanon, Lesotho, Libya, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Mongolia, Morocco,
Nepal, Netherlands, Nicaragua, Niger, Nigeria, Pakistan, Panama, Paraguay,
Peru, Poland, Portugal, Romania, Russia, Rwanda, San Marino, Sao Tome and
Principe, Senegal, Seychelles, Sierra Leone, Slovakia, Spain, Sri Lanka,
Sudan, Switzerland, Syria, Tanzania, Togo, Tunisia, Turkey, Uganda, UAE,
US, Uruguay, Venezuela, Vietnam, Yemen, Yugoslavia (suspended), Zaire,
Zambia, Zimbabwe
associate members-(4) Aruba, Macau, Netherlands Antilles, Puerto Rico
observer-(1) Holy See
-----
Zangger Committee (ZC)
established-early 1970s
aim-to establish guidelines for the export control provisions of the
nuclear Non-Proliferation Treaty
members-(29) Australia, Austria, Belgium, Bulgaria, Canada, Czech Republic,
Denmark, Finland, France, Germany, Greece, Hungary, Ireland, Italy, Japan,
Luxembourg, Netherlands, Norway, Poland, Portugal, Romania, Russia,
Slovakia, South Africa, Spain, Sweden, Switzerland, UK, US
Appendix D: Abbreviations for Selected International Environmental
Agreements
A Air Pollution
Convention on Long-Range Transboundary Air Pollution
Air Pollution-Nitrogen Oxides
Convention on Long-Range Transboundary Air Pollution (Nitrogen
Oxides Protocol)
Air Pollution-Sulphur
Convention on Long-Range Transboundary Air Pollution (Sulphur
Protocol)
Air Pollution-Volatile Organic Compounds
Convention on Long-Range Transboundary Air Pollution (Volatile Organic
Compounds Protocol)
Antarctic-Environmental Protocol
Protocol on Environmental Protection to the Antarctic Treaty
B Biodiversity
Convention on Biological Diversity
C Climate Change
United Nations Framework Convention on Climate Change
E Endangered Species
Convention on the International Trade in Endangered Species of
Wild Flora and Fauna (CITES)
Environmental Modification
Convention on the Prohibition of Military or Any Other Hostile Use of
Environmental Modification Techniques
H Hazardous Wastes
Basel Convention on the Control of Transboundary Movements of
Hazardous Wastes and Their Disposal
L Law of the Sea
United Nations Convention on the Law of the Sea (LOS)
M Marine Dumping
Convention on the Prevention of Marine Pollution by Dumping Wastes and
Other Matter; note - also known as the London Convention
Marine Life Conservation
Convention on Fishing and Conservation of Living Resources of the High
Seas
N Nuclear Test Ban
Treaty Banning Nuclear Weapons Tests in the Atmosphere, in Outer
Space, and Under Water
O Ozone Layer Protection
Montreal Protocol on Substances That Deplete the Ozone Layer
S Ship Pollution
International Convention for the Prevention of Pollution From Ships
(MARPOL)
T Tropical Timber
International Tropical Timber Agreement
W Wetlands
Convention on Wetlands of International Importance Especially As
Waterfowl Habitat; note - also known as Ramsar
Whaling
International Convention for the Regulation of Whaling
Note: Not all of the selected international environmental agreements have
abbreviations.
6 April 1994
Appendix E: Selected International Environmental Agreements
Air Pollution
see Convention on Long-Range Transboundary Air Pollution
-----
Air Pollution-Nitrogen Oxides
see Convention on Long-Range Transboundary Air Pollution (Nitrogen
Oxides Protocol)
-----
Air Pollution-Sulphur
see Convention on Long-Range Transboundary Air Pollution (Sulphur
Protocol)
-----
Air Pollution-Volatile Organic Compounds
see Convention on Long-Range Transboundary Air Pollution (Volatile
Organic Compounds Protocol)
-----
Antarctic-Environmental Protocol
see Protocol on Environmental Protection to the Antarctic Treaty
-----
Antarctic Treaty
date opened for signature - 1959
objective - to ensure that Antarctica is used for peaceful purposes,
for international cooperation in scientific research, and that it does
not become the scene or object of international discord
parties - (42) Argentina, Australia, Austria, Belgium, Brazil,
Bulgaria, Canada, Chile, China, Colombia, Cuba, Czech Republic,
Denmark, Ecuador, Finland, France, Germany, Greece, Guatemala, Hungary,
India, Italy, Japan, North Korea, South Korea, Netherlands, New
Zealand, Norway, Papua New Guinea, Peru, Poland, Romania, Russia,
Slovakia, South Africa, Spain, Sweden, Switzerland, Ukraine, United
Kingdom, United States, Uruguay
-----
Basel Convention on the Control of Transboundary Movements of Hazardous
Wastes and Their Disposal
note - abbreviated as Hazardous Wastes
date opened for signature - 1989
objective - to reduce transboundary movements of wastes subject to the
Convention to a minimum consistent with the environmentally sound and
efficient management of such wastes; to minimize the amount and
toxicity of wastes generated and ensure their environmentally sound
management as closely as possible to the source of generation; and to
assist LDCs in environmentally sound management of the hazardous and
other wastes they generate
parties - (65) Antigua and Barbuda, Argentina, Australia, Austria, The
Bahamas, Bahrain, Bangladesh, Belgium, Brazil, Canada, Chile, China,
Cyprus, Czech Republic, Denmark, Ecuador, Egypt, El Salvador, Estonia,
European Union, Finland, France, Hungary, India, Indonesia, Iran,
Ireland, Italy, Japan, Jordan, South Korea, Kuwait, Latvia,
Liechtenstein, Luxembourg, Malaysia, Maldives, Mauritius, Mexico,
Monaco, Netherlands, Nigeria, Norway, Panama, Peru, Philippines,
Poland, Portugal, Romania, Saint Lucia, Saudi Arabia, Senegal,
Seychelles, Slovakia, Slovenia, Spain, Sri Lanka, Sweden, Switzerland,
Syria, Tanzania, Trinidad and Tobago, United Arab Emirates, United
Kingdom, Uruguay
note - the following countries have signed, but not yet ratified the
convention: Afghanistan, Bolivia, Colombia, Germany, Greece,
Guatemala, Haiti, Israel, Lebanon, New Zealand, Russia, Thailand,
Turkey, United States, Venezuela
-----
Biodiversity
see Convention on Biological Diversity
-----
Convention on Biological Diversity
note - abbreviated as Biodiversity
date opened for signature - 1992
objective - to develop national strategies for the conservation and
sustainable use of biological diversity
parties - (53) Albania, Antigua and Barbuda, Armenia, Australia, The
Bahamas, Barbados, Belarus, Belize, Brazil, Burkina, Canada, China,
Cook Islands, Cuba, Czech Republic, Denmark, Ecuador, European Union,
Fiji, Germany, Guinea, Hungary, India, Japan, Jordan, Malawi, Maldives,
Marshall Islands, Mauritius, Mexico, Monaco, Mongolia, Nauru, Nepal,
New Zealand, Norway, Papua New Guinea, Paraguay, Peru, Philippines,
Portugal, Saint Kitts and Nevis, Saint Lucia, Seychelles, Spain, Sri
Lanka, Sweden, Tunisia, Uganda, Uruguay, Vanuatu, Western Samoa, Zambia
note - the following countries have signed, but not yet ratified the
convention: Afghanistan, Algeria, Angola, Argentina, Austria,
Azerbaijan, Bahrain, Bangladesh, Belgium, Benin, Bhutan, Bolivia,
Botswana, Bulgaria, Burma, Burundi, Cameroon, Cape Verde, Central
African Republic, Chad, Chile, Colombia, Comoros, Congo, Costa Rica,
Cote d''Ivoire, Croatia, Cyprus, Djibouti, Dominican Republic, Egypt, El
Salvador, Estonia, Ethiopia, Finland, France, Gabon, The Gambia, Ghana,
Greece, Guatemala, Guinea-Bissau, Guyana, Haiti, Honduras, Iceland,
Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Kazakhstan, Kenya,
North Korea, South Korea, Kuwait, Latvia, Lebanon, Lesotho, Liberia,
Libya, Liechtenstein, Lithuania, Luxembourg, Madagascar, Malaysia,
Malta, Mauritania, Federated States of Micronesia, Moldova, Morocco,
Mozambique, Namibia, Netherlands, Nicaragua, Niger, Nigeria, Oman,
Pakistan, Panama, Poland, Qatar, Romania, Russia, Rwanda, San Marino,
Sao Tome and Principe, Senegal, Singapore, Slovakia, Slovenia, Solomon
Islands, South Africa, Sudan, Suriname, Swaziland, Switzerland, Syria,
Tanzania, Thailand, Togo, Trinidad and Tobago, Turkey, Tuvalu, Ukraine,
United Arab Emirates, United Kingdom, United States, Venezuela,
Vietnam, Yemen, former Yugoslavia, Zaire, Zimbabwe
-----
Climate Change
see United Nations Framework Convention on Climate Change
-----
Convention on Fishing and Conservation of Living Resources of the High
Seas
note - abbreviated as Marine Life Conservation
date opened for signature - 1958
objective - to solve through international cooperation the problems
involved in the conservation of living resources of the high seas,
considering that through the development of modern techniques some of
these resources are in danger of being over exploited
parties - (37) Australia, Belgium, Bosnia and Herzegovina, Burkina,
Cambodia, Colombia, Denmark, Dominican Republic, Fiji, Finland, France,
Haiti, Jamaica, Kenya, Lesotho, Madagascar, Malawi, Malaysia,
Mauritius, Mexico, Netherlands, Nigeria, Portugal, Senegal, Sierra
Leone, Solomon Islands, South Africa, Spain, Switzerland, Thailand,
Tonga, Trinidad and Tobago, Uganda, United Kingdom, United States,
Venezuela, former Yugoslavia
note - the following countries have signed, but not yet ratified the
convention: Afghanistan, Argentina, Bolivia, Costa Rica, Cuba, Ghana,
Iceland, Indonesia, Iran, Ireland, Israel, Lebanon, Liberia, Nepal, New
Zealand, Pakistan, Panama, Sri Lanka, Taiwan (Canada signed on behalf
of Taiwan), Tunisia, Uruguay
-----
Convention on Long-Range Transboundary Air Pollution
note - abbreviated as Air Pollution
date opened for signature - 1979
objective - to protect the human environment against air pollution and
to gradually reduce and prevent air pollution, including long-range
transboundary air pollution
parties - (38) Austria, Belarus, Belgium, Bosnia and Herzegovina,
Bulgaria, Canada, Croatia, Cyprus, Czech Republic, Denmark, European
Union, Finland, France, Germany, Greece, Hungary, Iceland, Ireland,
Italy, Liechtenstein, Lithuania, Luxembourg, Netherlands, Norway,
Poland, Portugal, Romania, Russia, Slovakia, Slovenia, Spain, Sweden,
Switzerland, Turkey, Ukraine, United Kingdom, United States, former
Yugoslavia
note - the following countries have signed, but not yet ratified the
convention: Holy See, San Marino
-----
Convention on Long-Range Transboundary Air Pollution (Nitrogen Oxides
Protocol)
note - abbreviated as Air Pollution-Nitrogen Oxides
date opened for signature - 1988
objective - to provide for the control or reduction of nitrogen oxides
and their transboundary fluxes
parties - (23) Austria, Belarus, Bulgaria, Canada, Czech Republic,
Denmark, European Union, Finland, France, Germany, Hungary, Italy,
Liechtenstein, Luxembourg, Netherlands, Norway, Russia, Slovakia,
Sweden, Switzerland, Ukraine, United Kingdom, United States
note - the following countries have signed, but not yet ratified the
convention: Belgium, Greece, Ireland, Poland, Spain
-----
Convention on Long-Range Transboundary Air Pollution (Sulphur Protocol)
note - abbreviated as Air Pollution-Sulphur
date opened for signature - 1985; a second protocol to further reduce
sulfur dioxide emissions was completed in 1994
objective - to provide for a 30% reduction in sulfur emissions or
transboundary fluxes by 1993
parties - (21) Austria, Belarus, Belgium, Bulgaria, Canada, Czech
Republic, Denmark, Finland, France, Germany, Hungary, Italy,
Liechtenstein, Luxembourg, Netherlands, Norway, Russia, Slovakia,
Sweden, Switzerland, Ukraine
-----
Convention on Long-Range Transboundary Air Pollution (Volatile Organic
Compounds Protocol)
note - abbreviated as Air Pollution-Volatile Organic Compounds
date opened for signature - 1991, but not yet in force
objective - to provide for the control and reduction of emissions of
Volatile Organic Compounds in order to reduce their transboundary
fluxes so as to protect human health and the environment from adverse
effects
parties - (8) Finland, Liechtenstein, Luxembourg, Netherlands, Norway,
Spain, Sweden, Switzerland
note - the following countries have signed, but not yet ratified the
convention: Austria, Belgium, Bulgaria, Canada, Denmark, European
Union, France, Germany, Greece, Hungary, Italy, Portugal, Ukraine,
United Kingdom, United States
-----
Convention on the International Trade in Endangered Species of Wild
Flora and Fauna (CITES)
note - abbreviated as Endangered Species
date opened for signature - 1973
objective - to protect certain endangered species from overexploitation
by means of a system of import/export permits
parties - (104) Afghanistan, Algeria, Argentina, Australia, Austria,
Bangladesh, Belgium, Belize, Benin, Bolivia, Botswana, Brazil,
Bulgaria, Burkina, Burundi, Cameroon, Canada, Central African Republic,
Chad, Chile, China, Colombia, Congo, Costa Rica, Cuba, Cyprus, Denmark,
Djibouti, Dominican Republic, Ecuador, Egypt, El Salvador, Ethiopia,
Finland, France, Gabon, The Gambia, Germany, Ghana, Guatemala, Guinea,
Guinea-Bissau, Guyana, Honduras, Hungary, India, Indonesia, Iran,
Israel, Italy, Japan, Jordan, Kenya, Liberia, Luxembourg, Madagascar,
Malawi, Malaysia, Malta, Mauritius, Mexico, Morocco, Mozambique,
Namibia, Nepal, Netherlands, New Zealand, Nicaragua, Niger, Nigeria,
Norway, Pakistan, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Rwanda, Senegal, Singapore, Somalia,
South Africa, Spain, Sri Lanka, Sudan, Suriname, Sweden, Switzerland,
Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Uganda, United
Arab Emirates, United Kingdom, United States, Uruguay, Venezuela,
Zaire, Zambia, Zimbabwe
note - the following countries have signed, but not yet ratified the
convention: Cambodia, Ireland, Kuwait, Lesotho, Vietnam
-----
Convention on the Prevention of Marine Pollution by Dumping Wastes and
Other Matter (London Convention)
note - abbreviated as Marine Dumping
date opened for signature - 1972
objective - to control pollution of the sea by dumping','b183dfbd171b5382053dc6ad5ad8bcfb1a61dbc195266a95415a933b229c2e07','internet-archive','theciaworldfactb00180gut','txt','b76993377cfa6bdd51979833301976cfc440911ee1fe0b90c117008758860b3f','https://archive.org/download/theciaworldfactb00180gut/180.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b93e14637500984373f51fb28570cac815c0baa1407fc32bfd2d1f7e59000ad',1994,'ZW','Zimbabwe','energy',235,', and to
encourage regional agreements supplementary to the Convention
parties - (70) Afghanistan, Argentina, Australia, Belarus, Belgium,
Canada, Cape Verde, Chile, China, Costa Rica, Cote d''Ivoire, Croatia,
Cuba, Cyprus, Denmark, Dominican Republic, Egypt, European Union,
Finland, France, Gabon, Germany, Greece, Guatemala, Haiti, Honduras,
Hungary, Iceland, Ireland, Italy, Jamaica, Japan, Jordan, Kenya,
Kiribati, Libya, Luxembourg, Malta, Mexico, Monaco, Morocco, Nauru,
Netherlands, New Zealand, Nigeria, Norway, Oman, Panama, Papua New
Guinea, Philippines, Poland, Portugal, Russia, Saint Lucia, Seychelles,
Slovenia, Solomon Islands, South Africa, Spain, Suriname, Sweden,
Switzerland, Tunisia, Ukraine, United Arab Emirates, United Kingdom,
United States, Vanuatu, former Yugoslavia, Zaire
-----
Convention on the Prohibition of Military or Any Other Hostile Use of
Environmental Modification Techniques
note - abbreviated as Environmental Modification
date opened for signature - 1976
objective - to prohibit the military or other hostile use of
environmental modification techniques in order to further world peace
and trust among nations
parties - (62) Afghanistan, Algeria, Antigua and Barbuda, Argentina,
Australia, Austria, Bangladesh, Belarus, Belgium, Benin, Brazil,
Bulgaria, Canada, Cape Verde, Cuba, Cyprus, Czech Republic, Denmark,
Dominica, Egypt, Finland, Germany, Ghana, Greece, Guatemala, Hungary,
India, Ireland, Italy, Japan, North Korea, South Korea, Kuwait, Laos,
Malawi, Mauritius, Mongolia, Netherlands, New Zealand, Niger, Norway,
Pakistan, Papua New Guinea, Poland, Romania, Russia, Saint Lucia, Sao
Tome and Principe, Slovakia, Solomon Islands, Spain, Sri Lanka, Sweden,
Switzerland, Tunisia, Ukraine, United Kingdom, United States, Uruguay,
Uzbekistan, Vietnam, Yemen
note - the following countries have signed, but not yet ratified the
convention: Bolivia, Ethiopia, Holy See, Iceland, Iran, Iraq, Lebanon,
Liberia, Luxembourg, Morocco, Nicaragua, Portugal, Sierra Leone, Syria,
Turkey, Uganda, Zaire
-----
Convention on Wetlands of International Importance Especially As
Waterfowl Habitat (Ramsar)
note - abbreviated as Wetlands
date opened for signature - 1971
objective - to stem the progressive encroachment on and loss of
wetlands now and in the future, recognizing the fundamental ecological
functions of wetlands and their economic, cultural, scientific, and
recreational value
parties - (65) Algeria, Australia, Austria, Belgium, Bolivia, Bulgaria,
Burkina, Canada, Chad, Chile, Costa Rica, Czech Republic, Denmark,
Ecuador, Egypt, Finland, France, Gabon, Germany, Ghana, Greece,
Guatemala, Guinea-Bissau, Hungary, Iceland, India, Iran, Ireland,
Italy, Japan, Jordan, Kenya, Lesotho, Liechtenstein, Mali, Malta,
Mauritania, Mexico, Morocco, Netherlands, New Zealand, Niger, Norway,
Pakistan, Panama, Poland, Portugal, Romania, Russia, Senegal, South
Africa, Spain, Sri Lanka, Suriname, Sweden, Switzerland, Tunisia,
Uganda, United Kingdom, United States, Uruguay, Venezuela, Vietnam,
former Yugoslavia, Zambia
-----
Endangered Species
see Convention on the International Trade in Endangered Species of Wild
Flora and Fauna (CITES)
-----
Environmental Modification
see Convention on the Prohibition of Military or Any Other Hostile Use
of Environmental Modification Techniques
-----
Hazardous Wastes
see Basel Convention on the Control of Transboundary Movements of
Hazardous Wastes and Their Disposal
-----
International Convention for the Prevention of Pollution From Ships
(MARPOL)
note - abbreviated as Ship Pollution
date opened for signature - 1973/78
objective - to preserve the marine environment by achieving the
complete elimination of pollution by oil and other harmful substances
and the minimization of accidental discharge of such substances
parties - (83) Algeria, Antigua and Barbuda, Argentina, Australia,
Austria, The Bahamas, Belgium, Brazil, Brunei, Bulgaria, Burma, Canada,
China, Colombia, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic,
Denmark, Djibouti, Ecuador, Egypt, Estonia, Finland, France, Gabon,
Gambia, Germany, Ghana, Greece, Hungary, Iceland, India, Indonesia,
Israel, Italy, Jamaica, Japan, Kenya, North Korea, South Korea, Latvia,
Lebanon, Liberia, Lithuania, Luxembourg, Malta, Marshall Islands,
Mexico, Monaco, Morocco, Netherlands, Norway, Oman, Panama, Papua New
Guinea, Peru, Poland, Portugal, Romania, Russia, Saint Vincent and the
Grenadines, Seychelles, Singapore, Slovenia, South Africa, Spain,
Suriname, Sweden, Switzerland, Syria, Togo, Tunisia, Turkey, Tuvalu,
Ukraine, United Kingdom, United States, Uruguay, Vanuatu, Vietnam,
former Yugoslavia
-----
International Convention for the Regulation of Whaling
note - abbreviated as Whaling
date opened for signature - 1946
objective - to protect all species of whales from overfishing and
safeguard for future generations the great natural resources
represented by whale stocks; to establish a system of international
regulation for the whale fisheries to ensure proper conservation and
development of whale stocks
parties - (39) Antigua and Barbuda, Argentina, Australia, Belize,
Brazil, Chile, China, Costa Rica, Denmark, Egypt, Finland, France,
Germany, India, Ireland, Japan, Kenya, South Korea, Mauritius, Mexico,
Monaco, Netherlands, Netherlands Antilles, New Zealand, Norway, Oman,
Peru, Philippines, Saint Lucia, Saint Vincent and the Grenadines,
Senegal, Seychelles, Solomon Islands, South Africa, Spain, Sweden,
Switzerland, United Kingdom, United States
-----
International Tropical Timber Agreement
note - abbreviated as Tropical Timber
date opened for signature - 1983; a new agreement was opened for
signature in 1994, but is not yet in force
objective - to provide an effective framework for cooperation between
tropical timber producers and consumers and to encourage the
development of national policies aimed at sustainable utilization and
conservation of tropical forests and their genetic resources
parties - (45) Australia, Austria, Belgium, Burma, Cameroon, Canada,
China, Colombia, Congo, Denmark, Ecuador, Egypt, Finland, France,
Gabon, Germany, Ghana, Greece, Guyana, India, Indonesia, Ireland,
Italy, Japan, South Korea, Liberia, Luxembourg, Malaysia, Nepal,
Netherlands, New Zealand, Norway, Panama, Papua New Guinea, Portugal,
Russia, Spain, Sweden, Switzerland, Thailand, Togo, Trinidad and
Tobago, United Kingdom, United States, Zaire
note - the following countries have signed, but not yet ratified the
agreement: Bolivia, Brazil, Cote d''Ivoire, European Union, Honduras,
Peru, Philippines
-----
Law of the Sea
see United Nations Convention on the Law of the Sea (LOS)
-----
Marine Dumping
see Convention on the Prevention of Marine Pollution by Dumping Wastes
and Other Matter (London Convention)
-----
Marine Life Conservation
see Convention on Fishing and Conservation of Living Resources of the
High Seas
-----
Montreal Protocol on Substances That Deplete the Ozone Layer
note - abbreviated as Ozone Layer Protection
date opened for signature - 1987
objective - to protect the ozone layer by taking precautionary measures
to control emissions of substances that deplete it
parties - (136) Algeria, Antigua and Barbuda, Argentina, Australia,
Austria, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium,
Benin, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria,
Burkina, Burma, Cameroon, Canada, Central African Republic, Chile,
China, Colombia, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus,
Czech Republic, Denmark, Dominica, Dominican Republic, Ecuador, Egypt,
El Salvador, European Union, Fiji, Finland, France, Gabon, The Gambia,
Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guyana, Honduras,
Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kenya, Kiribati, South Korea, Kuwait, Lebanon,
Lesotho, Libya, Liechtenstein, Luxembourg, Macau, Malawi, Malaysia,
Maldives, Malta, Marshall Islands, Mauritius, Mexico, Monaco, Namibia,
Netherlands, New Zealand, Nicaragua, Niger, Nigeria, Norway, Panama,
Papua New Guinea, Peru, Philippines, Poland, Portugal, Romania, Russia,
Saint Kitts and Nevis, Saint Lucia, Saudi Arabia, Senegal, Seychelles,
Singapore, Slovakia, Slovenia, Solomon Islands, South Africa, Spain,
Sri Lanka, Sudan, Sweden, Switzerland, Syria, Tanzania, Thailand, The
Former Yugoslav Republic of Macedonia, Togo, Trinidad and Tobago,
Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, United Arab
Emirates, United Kingdom, United States, Uruguay, Uzbekistan,
Venezuela, Vietnam, Zambia
note - the following countries have signed, but not yet ratified the
protocol: Congo, Morocco
-----
Nuclear Test Ban
see Treaty Banning Nuclear Weapons Tests in the Atmosphere, in Outer
Space, and Under Water
-----
Ozone Layer Protection
see Montreal Protocol on Substances that Deplete the Ozone Layer
-----
Protocol on Environmental Protection to the Antarctic Treaty
note - abbreviated as Antarctic-Environmental Protocol
date opened for signature - 1991, but not yet in force
objective - to enhance the protection of the Antarctic environment and
dependent and associated ecosystems
parties - (9) Argentina, Australia, Ecuador, France, Netherlands,
Norway, Peru, Spain, Sweden
note - the following countries have signed, but not yet ratified the
protocol: Austria, Belgium, Brazil, Bulgaria, Canada, Chile, China,
Colombia, Cuba, Czech Republic, Denmark, Finland, Germany, Greece,
Guatemala, Hungary, India, Italy, Japan, North Korea, South Korea, New
Zealand, Papua New Guinea, Poland, Romania, Russia, Slovakia, South
Africa, Switzerland, United Kingdom, United States, Uruguay
-----
Ship Pollution
see International Convention for the Prevention of Pollution From Ships
(MARPOL)
-----
Treaty Banning Nuclear Weapon Tests in the Atmosphere, in Outer Space,
and Under Water
note - abbreviated as Nuclear Test Ban
date opened for signature - 1963
objective - to obtain an agreement on general and complete disarmament
under strict international control in accordance with the objectives of
the United Nations; to put an end to the armaments race and eliminate
incentives for the production and testing of all kinds of weapons,
including nuclear weapons
parties - (112) Afghanistan, Argentina, Australia, Austria, Bangladesh,
Belgium, Benin, Bhutan, Bolivia, Botswana, Brazil, Bulgaria, Burma,
Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Denmark,
Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Fiji, Finland, Gabon, The Gambia, Germany, Ghana, Greece, Guatemala,
Guinea-Bissau, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, South
Korea, Kuwait, Laos, Lebanon, Liberia, Libya, Luxembourg, Madagascar,
Malawi, Malaysia, Malta, Mauritania, Mauritius, Mexico, Mongolia,
Morocco, Nepal, Netherlands, New Zealand, Nicaragua, Niger, Nigeria,
Norway, Pakistan, Panama, Papua New Guinea, Peru, Philippines, Poland,
Romania, Rwanda, Senegal, Sierra Leone, Singapore, Slovakia, Slovenia,
South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden,
Switzerland, Syria, Tanzania, Thailand, Togo, Trinidad and Tobago,
Tunisia, Turkey, Uganda, United Kingdom, United States, Uruguay,
Venezuela, former Yugoslavia, Zaire, Zambia
note - the following countries have signed, but not yet ratified the
treaty: Algeria, Burkina, Burundi, Cameroon, Ethiopia, Haiti, Mali,
Paraguay, Portugal, Somalia, Vietnam
-----
Tropical Timber
see International Tropical Timber Agreement
-----
United Nations Convention on the Law of the Sea (LOS)
note - abbreviated as Law of the Sea
date opened for signature - 1982, but not yet in force
objective - to set up a comprehensive new legal regime for the sea and
oceans and, as far as environmental provisions are concerned, to
establish material rules concerning environmental standards as well as
enforcement provisions dealing with pollution of the marine environment
parties - (60) Angola, Antigua and Barbuda, The Bahamas, Bahrain,
Barbados, Belize, Botswana, Brazil, Cameroon, Cape Verde, Costa Rica,
Cote d''Ivoire, Cuba, Cyprus, Czech Republic, Djibouti, Dominica, Egypt,
Fiji, The Gambia, Ghana, Grenada, Guinea, Guinea-Bissau, Guyana,
Honduras, Iceland, Indonesia, Iraq, Jamaica, Kenya, Kuwait, Mali,
Malta, Marshall Islands, Mexico, Federated States of Micronesia,
Namibia, Nigeria, Oman, Paraguay, Philippines, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and Principe,
Senegal, Seychelles, Slovakia, Somalia, Sudan, Tanzania, Togo, Trinidad
and Tobago, Tunisia, Uganda, Yemen, former Yugoslavia, Zaire, Zambia,
note - the following countries have signed, but not yet ratified the
convention: Afghanistan, Algeria, Argentina, Australia, Austria,
Bangladesh, Belarus, Belgium, Benin, Bhutan, Bolivia, Brunei, Bulgaria,
Burkina, Burma, Burundi, Cambodia, Canada, Central African Republic,
Chad, Chile, China, Colombia, Comoros, Congo, Cook Islands, Denmark,
Dominican Republic, El Salvador, Equatorial Guinea, Ethiopia, European
Union, Finland, France, Gabon, Greece, Guatemala, Haiti, Hungary,
India, Iran, Ireland, Italy, Japan, North Korea, South Korea, Laos,
Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Luxembourg,
Madagascar, Malawi, Malaysia, Maldives, Mauritania, Mauritius, Monaco,
Mongolia, Morocco, Mozambique, Nauru, Nepal, Netherlands, New Zealand,
Nicaragua, Niger, Niue, Norway, Pakistan, Panama, Papua New Guinea,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saudi Arabia, Sierra
Leone, Singapore, Solomon Islands, South Africa, Spain, Sri Lanka,
Suriname, Swaziland, Sweden, Switzerland, Thailand, Tuvalu, Ukraine,
United Arab Emirates, Uruguay, Vanuatu, Vietnam, Western Samoa
-----
United Nations Framework Convention on Climate Change
note - abbreviated as Climate Change
date opened for signature - 1992
objective-to achieve stabilization of greenhouse gas concentrations in
the atmosphere at a low enough level to prevent dangerous anthropogenic
interference with the climate system
parties - (64) Algeria, Antigua and Barbuda, Argentina, Armenia,
Australia, Austria, The Bahamas, Barbados, Botswana, Brazil, Burkina,
Canada, China, Cook Islands, Cuba, Czech Republic, Denmark, Dominica,
Ecuador, European Union, Fiji, France, Germany, Guinea, Hungary,
Iceland, India, Japan, Jordan, South Korea, Maldives, Malta, Marshall
Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia,
Monaco, Mongolia, Nauru, Netherlands, New Zealand, Norway, Papua New
Guinea, Paraguay, Peru, Portugal, Saint Kitts and Nevis, Saint Lucia,
Seychelles, Spain, Sri Lanka, Sudan, Sweden, Switzerland, Tunisia,
Tuvulu, Uganda, United Kingdom, United States, Uzbekistan, Vanuatu,
Zambia, Zimbabwe
note - the following countries have signed, but not yet ratified the
convention: Afghanistan, Angola, Azerbaijan, Bahrain, Bangladesh,
Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Bulgaria, Burma,
Burundi, Cameroon, Cape Verde, Central African Republic, Chad, Chile,
Colombia, Comoros, Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus,
Djibouti, Dominican Republic, Egypt, El Salvador, Estonia, Ethiopia,
Finland, Gabon, The Gambia, Ghana, Greece, Grenada, Guatemala, Guinea-
Bissau, Guyana, Haiti, Honduras, Indonesia, Iran, Ireland, Israel,
Italy, Jamaica, Kazakhstan, Kenya, Kiribati, North Korea, Latvia,
Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg,
Madagascar, Malawi, Malaysia, Mali, Moldova, Morocco, Mozambique,
Namibia, Nepal, Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama,
Philippines, Poland, Romania, Russia, Rwanda, San Marino, Sao Tome and
Principe, Senegal, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon
Islands, South Africa, Suriname, Swaziland, Tanzania, Thailand, Togo,
Trinidad and Tobago, Ukraine, Uruguay, Venezuela, Vietnam, Western
Samoa, Yemen, former Yugoslavia, Zaire
-----
Wetlands
see Convention on Wetlands of International Importance Especially As
Waterfowl Habitat (Ramsar)
-----
Whaling
see International Convention for the Regulation of Whaling
Appendix F: Weights and Measures
Mathematical Notation
Mathematical Power Name
10^18 or 1,000,000,000,000,000,000 one quintillion
10^15 or 1,000,000,000,000,000 one quadrillion
10^12 or 1,000,000,000,000 one trillion
10^9 or 1,000,000,000 one billion
10^6 or 1,000,000 one million
10^3 or 1,000 one thousand
10^2 or 100 one hundred
10^1 or 10 ten
10^0 or 1 one
10-^1 or 0.1 one-tenth
10-^2 or 0.01 one-hundredth
10-^3 or 0.001 one-thousandth
10-^6 or 0.000 001 one-millionth
10-^9 or 0.000 000 001 one-billionth
10-^12 or 0.000 000 000 001 one-trillionth
10-^15 or 0.000 000 000 000 001 one-quadrillionth
10-^18 or 0.000 000 000 000 000 00 one-quintillionth
Metric Interrelationships
Conversions from a multiple or submultiple to the basic units of meters,
liters, or grams can be done using the table. For example, to convert from
kilometers to meters, multiply by 1,000 (9.26 kilometers equals 9,260
meters) or to convert from meters to kilometers, multiply by 0.001 (9,260
meters equals 9.26 kilometers).
Prefix Symbol Length, weight,
or capacity Area Volume
exa E 10^18 10^36 10^54
peta P 10^15 10^30 10^45
tera T 10^12 10^24 10^36
giga G 10^9 10^18 10^27
mega M 10^6 10^12 10^18
hectokilo hk 10^5 10^10 10^15
myria ma 10^4 10^8 10^12
kilo k 10^3 10^6 10^9
hecto h 10^2 10^4 10^6
basic unit - 1 meter, 1 meter^2 1 meter^3
1 gram,
1 liter
deci d 10-^1 10-^2 10-^3
centi c 10-^2 10-^4 10-^6
milli m 10-^3 10-^6 10-^9
decimilli dm 10-^4 10-^8 10-^12
centimilli cm 10-^5 10-^10 10-^15
micro u 10-^6 10-^12 10-^18
nano n 10-^9 10-^18 10-^27
pico p 10-^12 10-^24 10-^36
femto f 10-^15 10-^30 10-^45
atto a 10-^18 10-^36 10-^54
Equivalents
Units Metric Equivalent US Equivalent
acre 0.404 685 64 hectares 43,560 feet^2
acre 4,046,856 4 meters^2 4,840 yards^2
acre 0.004 046 856 4 0.001 562 5 miles^2,
kilometers^2 statute
are 100 meters^2 119.599 yards^2
barrel
(petroleum, US) 158.987 29 liters 42 gallons
(proof spirits, US) 151.416 47 liters 40 gallons
(beer, US) 117.347 77 liters 31 gallons
bushel 35.239 07 liters 4 pecks
cable 219.456 meters 120 fathoms
chain (surveyor''s) 20.116 8 meters 66 feet
cord (wood) 3.624 556 meters^3 128 feet^3
cup 0.236 588 2 liters 8 ounces, liquid (US)
degrees, Celsius (water boils at 100 multiply by 1.8 and add 32
degrees C, freezes at to obtain degrees F
0 degrees C)
degrees, Fahrenheit subtract 32 and divide water boils at 212 degrees
by 1.8 to obtain F, freezes at 32 degrees F)
degrees C
dram, avdp. 1.771 845 2 grams 0.0625 5 ounces, avdp.
dram, troy 3.887 934 6 grams 0.125 ounces, troy
dram, liquid (US) 3.696 69 milliliters 0.125 ounces, liquid
fathom 1.828 8 meters 6 feet
foot 30.48 centimeters 12 inches
foot 0.304 8 meters 0.333 333 3 yards
foot 0.000 304 8 kilometers 0.000 189 39 miles, statute
foot^2 929.030 4 centimeters^2 144 inches^2
foot^2 0.092 903 04 meters^2 0.111 111 1 yards^2
foot^3 28.316 846 592 liters 7.480 519 gallons
foot^3 0.028 316 847 meters^3 1,728 inches^3
furlong 201.168 meters 220 yards
gallon, liquid (US) 3.785 411 784 liters 4 quarts, liquid
gill (US) 118.294 118 milliliters 4 ounces, liquid
grain 64.798 91 milligrams 0.002 285 71 ounces, advp.
gram 1,000 milligrams 0.035 273 96 ounces, advp.
hand (height of horse) 10.16 centimeters 4 inches
hectare 10,000 meters^2 2.471 053 8 acres
hundredweight, long 50.802 345 kilograms 112 pounds, avdp.
hundredweight, short 45.359 237 kilograms 100 pounds, avdp.
inch 2.54 centimeters 0.083 333 33 feet
inch^2 6.451 6 centimeters^2 0.006 944 44 feet^2
inch^3 16.387 064 centimeters^3 0.000 578 7 feet^3
inch^3 16.387 064 milliliters 0.029 761 6 pints, dry
inch^3 16.387 064 milliliters 0.034 632 0 pints, liquid
kilogram 0.001 tons, metric 2.204 623 pounds, avdp.
kilometer 1,000 meters 0.621 371 19 miles, statute
kilometer^2 100 hectares 247.105 38 acres
kilometer^2 1,000,000 meters^2 0.386 102 16 miles^2,
statute
knot (1 nautical
mi/hr) 1.852 kilometers/hour 1.151 statute miles/hour
league, nautical 5.559 552 kilometers 3 miles, nautical
league, statute 4.828.032 kilometers 3 miles, statute
link (surveyor''s) 20.116 8 centimeters 7.92 inches
liter 0.001 meters^3 61.023 74 inches^3
liter 0.1 dekaliter 0.908 083 quarts, dry
liter 1,000 milliliters 1.056 688 quarts, liquid
meter 100 centimeters 1.093 613 yards
meter^2 10,000 centimeters^2 1.195 990 yards^2
meter^3 1,000 liters 1.307 951 yards^3
micron 0.000 001 meter 0.000 039 4 inches
mil 0.025 4 millimeters 0.001 inch
mile, nautical 1.852 kilometers 1.150 779 4 miles, statute
mile^2, nautical 3.429 904 kilometers^2 1.325 miles^2, statute
mile, statute 1.609 344 kilometers 5,280 feet or 8 furlongs
mile^2, statute 258.998 811 hectares 640 acres or 1 section
mile^2, statute 2.589 988 11
kilometers^2 0.755 miles^2, nautical
minim (US) 0.061 611 52 milliliters 0.002 083 33 ounces, liquid
or one-sixtieth of a dram
ounce, avdp. 28.349 523 125 grams 437.5 grains
ounce, liquid (US) 29.573 53 milliliters 0.062 5 pints, liquid
ounce, troy 31.103 476 8 grams 480 grains
pace 76.2 centimeters 30 inches
peck 8.809 767 5 liters 8 quarts, dry
pennyweight 1.555 173 84 grams 24 grains
pint, dry (US) 0.550 610 47 liters 0.5 quarts, dry
pint, liquid (US) 0.473 176 473 liters 0.5 quarts, liquid
point (typographical) 0.351 459 8 millimeters 0.013 837 inches
pound, avdp 453.592 37 grams 16 ounces, avdp
pound, troy 373.241 721 6 grams 12 ounces, troy
quart, dry (US) 1.101 221 liters 2 pints, dry
quart, liquid (US) 0.946 352 946 liters 2 pints, liquid
quintal 100 kilograms 220.462 26 pounds, avdp.
rod 5.029 2 meters 5.5 yards
scruple 1.295 978 2 grams 20 grains
section (US) 2.589 988 1 kilometers^2 1 mile^2, statute
or 640 acres
span 22.86 centimeters 9 inches
stere 1 meter^3 1.307 95 yards^3
tablespoon 14.786 76 milliliters 3 teaspoons
teaspoon 4.928 922 milliliters 0.333 333 tablespoons
ton, long or
deadweight 1,016.046 909 kilograms 2,240 pounds, avdp.
ton, metric 1,000 kilograms 2,204.623 pounds, avdp.
ton, metric 1,000 kilograms 32,150.75 ounces, troy
ton, register 2.831 684 7 meters^3 100 feet^3
ton, short 907.184 74 kilograms 2,000 pounds, avdp.
township (US) 93.239 572 kilometers^2 36 miles^2, statute
yard 0.914 4 meters 3 feet
yard^2 0.836 127 36 meters^2 9 feet^2
yard^3 0.764 554 86 meters^3 27 feet^3
yard^3 764.554 857 984 liters 201.974 gallons
Appendix G: Cross-Reference List of Geographic Names
This list indicates where various names, including all United States
Foreign Service Posts, alternate names, former names, and political or
geographical portions of larger entities, can be found in The World Fact-
book. Spellings are not necessarily those approved by the United States
Board on Geographic Names (BGN). Alternate names are included in
parentheses; additional information is included in brackets.
Name Entry in The World Factbook
A
Abidjan [US Embassy] Cote d''Ivoire
Abu Dhabi [US Embassy] United Arab Emirates
Abuja [US Embassy Branch Office] Nigeria
Acapulco [US Consular Agency] Mexico
Accra [US Embassy] Ghana
Adamstown Pitcairn Islands
Adana [US Consulate] Turkey
Addis Ababa [US Embassy] Ethiopia
Adelie Land (Terre Adelie) Antarctica
[claimed by France]
Aden Yemen
Aden, Gulf of Indian Ocean
Admiralty Islands Papua New Guinea
Adriatic Sea Atlantic Ocean
Aegean Islands Greece
Aegean Sea Atlantic Ocean
Afars and Issas, French Territory Djibouti
of the (F.T.A.I.)
Agalega Islands Mauritius
Agana Guam
Aland Islands Finland
Alaska United States
Alaska, Gulf of Pacific Ocean
Aldabra Islands Seychelles
Alderney Guernsey
Aleutian Islands United States
Alexander Island Antarctica
Alexandria [US Consulate General Egypt
closed in September 1993]
Algiers [US Embassy] Algeria
Alhucemas, Penon de Spain
Alma-Ata (see Almaty) Kazakhstan
Almaty (Alma-Ata) [US Embassy] Kazakhstan
Alofi Niue
Alphonse Island Seychelles
Amami Strait Pacific Ocean
Amindivi Islands India
Amirante Isles Seychelles
Amman [US Embassy] Jordan
Amsterdam [US Consulate Gen','1f0c5cec3e7836af5fbe1854847f66c3c3380ed32a3deaf837efabe158592771','internet-archive','theciaworldfactb00180gut','txt','b76993377cfa6bdd51979833301976cfc440911ee1fe0b90c117008758860b3f','https://archive.org/download/theciaworldfactb00180gut/180.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d2352d3044680dcfa93963f14d6e7e6303b402f187edbc9df891524ef9ece26',1994,'ZW','Zimbabwe','energy',236,'eral] Netherlands
Amsterdam Island (Ile Amsterdam) French Southern and Antarctic Lands
Amundsen Sea Pacific Ocean
Amur China; Russia
Andaman Islands India
Andaman Sea Indian Ocean
Andorra la Vella Andorra
Anegada Passage Atlantic Ocean
Anglo-Egyptian Sudan Sudan
Anjouan Comoros
Ankara [US Embassy] Turkey
Annobon Equatorial Guinea
Antananarivo [US Embassy] Madagascar
Antipodes Islands New Zealand
Antwerp [European Logistical Belgium
Support Office]
Aozou Strip Chad
Apia [US Embassy] Western Samoa
Aqaba, Gulf of Indian Ocean
Arabian Sea Indian Ocean
Arafura Sea Pacific Ocean
Argun China; Russia
Ascension Island Saint Helena
Ashgabat [US Embassy] Turkmenistan
Ashkhabad (see Ashgabat) Turkmenistan
Asmara [US Embassy] Eritrea
Asmera (see Asmara) Eritrea
Assumption Island Seychelles
Asuncion [US Embassy] Paraguay
Asuncion Island Northern Mariana Islands
Atacama Chile
Athens [US Embassy] Greece
Attu United States
Auckland [US Consulate General] New Zealand
Auckland Islands New Zealand
Australes Iles (Iles Tubuai) French Polynesia
Avarua Cook Islands
Axel Heiberg Island Canada
Azores Portugal
Azov, Sea of Atlantic Ocean
B
Bab el Mandeb Indian Ocean
Babuyan Channel Pacific Ocean
Babuyan Islands Philippines
Baffin Bay Arctic Ocean
Baffin Island Canada
Baghdad [US Embassy temporarily Iraq
suspended; US Interests Section
located in Poland''s embassy in
Baghdad]
Baku [US Embassy] Azerbaijan
Baky (Baku) Azerbaijan
Balabac Strait Pacific Ocean
Balearic Islands Spain
Balearic Sea (Iberian Sea) Atlantic Ocean
Bali Sea Indian Ocean
Balintang Channel Pacific Ocean
Balintang Islands Philippines
Balleny Islands Antarctica
Balochistan Pakistan
Baltic Sea Atlantic Ocean
Bamako [US Embassy] Mali
Banaba (Ocean Island) Kiribati
Bandar Seri Begawan [US Embassy] Brunei
Banda Sea Pacific Ocean
Bangkok [US Embassy] Thailand
Bangui [US Embassy] Central African Republic
Banjul [US Embassy] Gambia, The
Banks Island Canada
Banks Islands (Iles Banks) Vanuatu
Barcelona [US Consulate General] Spain
Barents Sea Arctic Ocean
Barranquilla [US Consulate] Colombia
Bashi Channel Pacific Ocean
Basilan Strait Pacific Ocean
Bass Strait Pacific Ocean
Basse-Terre Guadeloupe
Basseterre Saint Kitts and Nevis
Batan Islands Philippines
Basutoland Lesotho
Bavaria (Bayern) Germany
Beagle Channel Atlantic Ocean
Bear Island (Bjornoya) Svalbard
Beaufort Sea Arctic Ocean
Bechuanaland Botswana
Beijing [US Embassy] China
Beirut [US Embassy] Lebanon
Belau (see Palu) Pacific Islands,
Trust Territory of the
Belem [US Consular Agency] Brazil
Belep Islands (Iles Belep) New Caledonia
Belfast [US Consulate General] United Kingdom
Belgian Congo Zaire
Belgrade [US Embassy; US does not Serbia and Montenegro
maintain full diplomatic relations
with Serbia and Montenegro]
Belize City [US Embassy] Belize
Belle Isle, Strait of Atlantic Ocean
Bellingshausen Sea Pacific Ocean
Belmopan Belize
Belorussia Belarus
Bengal, Bay of Indian Ocean
Bering Sea Pacific Ocean
Bering Strait Pacific Ocean
Berkner Island Antarctica
Berlin [US Branch Office] Germany
Berlin, East Germany
Berlin, West Germany
Bern [US Embassy] Switzerland
Bessarabia Romania; Moldova
Bijagos, Arquipelago dos Guinea-Bissau
Bikini Atoll Marshall Islands
Bilbao [US Consulate] Spain
Bioko Equatorial Guinea
Biscay, Bay of Atlantic Ocean
Bishkek [US Embassy] Kyrgyzstan
Bishop Rock United Kingdom
Bismarck Archipelago Papua New Guinea
Bismarck Sea Pacific Ocean
Bissau [US Embassy] Guinea-Bissau
Bjornoya (Bear Island) Svalbard
Black Rock Falkland Islands (Islas Malvinas)
Black Sea Atlantic Ocean
Bloemfontein South Africa
Boa Vista Cape Verde
Bogota [US Embassy] Colombia
Bombay [US Consulate General] India
Bonaire Netherlands Antilles
Bonifacio, Strait of Atlantic Ocean
Bonin Islands Japan
Bonn [US Embassy] Germany
Bophuthatswana South Africa
Bora-Bora French Polynesia
Bordeaux [US Consulate General] France
Borneo Brunei; Indonesia; Malaysia
Bornholm Denmark
Bosporus Atlantic Ocean
Bothnia, Gulf of Atlantic Ocean
Bougainville Island Papua New Guinea
Bougainville Strait Pacific Ocean
Bounty Islands New Zealand
Brasilia [US Embassy] Brazil
Bratislava [US Embassy] Slovakia
Brazzaville [US Embassy] Congo
Bridgetown [US Embassy] Barbados
Brisbane [US Consulate] Australia
British East Africa Kenya
British Guiana Guyana
British Honduras Belize
British Solomon Islands Solomon Islands
British Somaliland Somalia
Brussels [US Embassy, US Mission Belgium
to European Union, US Mission to
the North Atlantic Treaty
Organization (USNATO)]
Bucharest [US Embassy] Romania
Budapest [US Embassy] Hungary
Buenos Aires [US Embassy] Argentina
Bujumbura [US Embassy] Burundi
Burnt Pine Norfolk Island
Byelorussia Belarus
C
Cabinda Angola
Cabot Strait Atlantic Ocean
Caicos Islands Turks and Caicos Islands
Cairo [US Embassy] Egypt
Calcutta [US Consulate General] India
Calgary [US Consulate General] Canada
California, Gulf of Pacific Ocean
Campbell Island New Zealand
Canal Zone Panama
Canary Islands Spain
Canberra [US Embassy] Australia
Canton (Guangzhou) China
Canton Island Kiribati
Cape Town [US Consulate General] South Africa
Caracas [US Embassy] Venezuela
Cargados Carajos Shoals Mauritius
Caroline Islands Micronesia, Federated States of;
Pacific Islands, Trust Territory
of the
Caribbean Sea Atlantic Ocean
Carpentaria, Gulf of Pacific Ocean
Casablanca [US Consulate General] Morocco
Castries Saint Lucia
Cato Island Australia
Cayenne French Guiana
Cebu [US Consulate General] Philippines
Celebes Indonesia
Celebes Sea Pacific Ocean
Celtic Sea Atlantic Ocean
Central African Empire Central African Republic
Ceuta Spain
Ceylon Sri Lanka
Chafarinas, Islas Spain
Chagos Archipelago (Oil Islands) British Indian Ocean Territory
Channel Islands Guernsey; Jersey
Charlotte Amalie Virgin Islands
Chatham Islands New Zealand
Cheju-do Korea, South
Cheju Strait Pacific Ocean
Chengdu [US Consulate General] China
Chesterfield Islands New Caledonia
(Iles Chesterfield)
Chiang Mai [US Consulate General] Thailand
Chihli, Gulf of (see Bo Hai) Pacific Ocean
China, People''s Republic of China
China, Republic of Taiwan
Chisinau [US Embassy] Moldova
Choiseul Solomon Islands
Christmas Island [Indian Ocean] Australia
Christmas Island [Pacific Ocean] Kiribati
(Kiritimati)
Chukchi Sea Arctic Ocean
Ciskei South Africa
Ciudad Juarez [US Consulate General] Mexico
Coco, Isla del Costa Rica
Cocos Islands Cocos (Keeling) Islands
Colombo [US Embassy] Sri Lanka
Colon, Archipielago de Ecuador
(Galapagos Islands)
Commander Islands Russia
(Komandorskiye Ostrova)
Conakry [US Embassy] Guinea
Congo (Brazzaville) Congo
Congo (Kinshasa) Zaire
Congo (Leopoldville) Zaire
Con Son Islands Vietnam
Cook Strait Pacific Ocean
Copenhagen [US Embassy] Denmark
Coral Sea Pacific Ocean
Corn Islands (Islas del Maiz) Nicaragua
Corsica France
Cosmoledo Group Seychelles
Cotonou [US Embassy] Benin
Crete Greece
Crooked Island Passage Atlantic Ocean
Crozet Islands (Iles Crozet) French Southern and Antarctic Lands
Curacao [US Consulate General] Netherlands Antilles
Czechoslovakia Czech Republic; Slovakia
D
Dahomey Benin
Daito Islands Japan
Dakar [US Embassy] Senegal
Daman (Damao) India
Damascus [US Embassy] Syria
Danger Atoll Cook Islands
Danish Straits Atlantic Ocean
Danzig (Gdansk) Poland
Dao Bach Long Vi Vietnam
Dardanelles Atlantic Ocean
Dar es Salaam [US Embassy] Tanzania
Davis Strait Atlantic Ocean
Deception Island Antarctica
Denmark Strait Atlantic Ocean
D''Entrecasteaux Islands Papua New Guinea
Devon Island Canada
Dhahran [US Consulate General] Saudi Arabia
Dhaka [US Embassy] Bangladesh
Diego Garcia British Indian Ocean Territory
Diego Ramirez Chile
Diomede Islands Russia [Big Diomede]; United States
[Little Diomede]
Diu India
Djibouti [US Embassy] Djibouti
Dodecanese Greece
Dodoma Tanzania
Doha [US Embassy] Qatar
Douala [US Consulate closed in Cameroon
September 1993]
Douglas Man, Isle of
Dover, Strait of Atlantic Ocean
Drake Passage Atlantic Ocean
Dubai (see Dubayy) United Arab Emirates
Dubayy [US Consulate General] United Arab Emirates
Dublin [US Embassy] Ireland
Durban [US Consulate General] South Africa
Dushanbe [Embassy] Tajikistan
Dutch East Indies Indonesia
Dutch Guiana Suriname
E
East China Sea Pacific Ocean
Easter Island (Isla de Pascua) Chile
Eastern Channel (East Korea Strait Pacific Ocean
or Tsushima Strait)
East Germany (German Democratic Germany
Republic)
East Korea Strait (Eastern Channel Pacific Ocean
or Tsushima Strait)
East Pakistan Bangladesh
East Siberian Sea Arctic Ocean
East Timor (Portuguese Timor) Indonesia
Edinburgh [US Consulate General] United Kingdom
Elba Italy
Ellef Ringnes Island Canada
Ellesmere Island Canada
Ellice Islands Tuvalu
Elobey, Islas de Equatorial Guinea
Enderbury Island Kiribati
Enewetak Atoll (Eniwetok Atoll) Marshall Islands
England United Kingdom
English Channel Atlantic Ocean
Eniwetok Atoll Marshall Islands
Epirus, Northern Albania; Greece
Essequibo [claimed by Venezuela] Guyana
Etorofu Russia [de facto]
F
Farquhar Group Seychelles
Fernando de Noronha Brazil
Fernando Po (Bioko) Equatorial Guinea
Finland, Gulf of Atlantic Ocean
Florence [US Consulate General] Italy
Florida, Straits of Atlantic Ocean
Formosa Taiwan
Formosa Strait (Taiwan Strait) Pacific Ocean
Fortaleza [US Consular Agency] Brazil
Fort-de-France [US Consulate General] Martinique
Frankfurt am Main [US Germany
Consulate General]
Franz Josef Land Russia
Freetown [US Embassy] Sierra Leone
French Cameroon Cameroon
French Indochina Cambodia; Laos; Vietnam
French Guinea Guinea
French Sudan Mali
French Territory of the Afars Djibouti
and Issas (F.T.A.I.)
French Togo Togo
Friendly Islands Tonga
Frunze (Bishkek) Kyrgyzstan
Fukuoka [US Consulate] Japan
Funafuti Tuvalu
Fundy, Bay of Atlantic Ocean
Futuna Islands (Hoorn Islands) Wallis and Futuna
G
Gaborone [US Embassy] Botswana
Galapagos Islands (Archipielago Ecuador
de Colon)
Galleons Passage Atlantic Ocean
Gambier Islands (Iles Gambier) French Polynesia
Gaspar Strait Pacific Ocean
Geneva [Branch Office of the Switzerland
US Embassy, US Mission to European
Office of the UN and Other
International Organizations]
Genoa [US Consulate General closed Italy
in June 1993]
George Town [US Consular Agency] Cayman Islands
Georgetown [US Embassy] Guyana
German Democratic Republic Germany
(East Germany)
German Federal Republic of Germany
(West Germany)
Gibraltar, Strait of Atlantic Ocean
Gilbert Islands Kiribati
Goa India
Gold Coast Ghana
Golan Heights Syria
Good Hope, Cape of South Africa
Goteborg Sweden
Gotland Sweden
Gough Island Saint Helena
Grand Banks Atlantic Ocean
Grand Cayman Cayman Islands
Grand Turk [US Consular Agency] Turks and Caicos Islands
Great Australian Bight Indian Ocean
Great Belt (Store Baelt) Atlantic Ocean
Great Britain United Kingdom
Great Channel Indian Ocean
Greater Sunda Islands Brunei; Indonesia; Malaysia
Green Islands Papua New Guinea
Greenland Sea Arctic Ocean
Grenadines, Northern Saint Vincent and the Grenadines
Grenadines, Southern Grenada
Grytviken Georgia
Guadalajara [US Consulate General] Mexico
Guadalcanal Solomon Islands
Guadalupe, Isla de Mexico
Guangzhou [US Consulate General] China
Guantanamo Bay [US Naval Base] Cuba
Guatemala [US Embassy] Guatemala
Gubal, Strait of Indian Ocean
Guinea, Gulf of Atlantic Ocean
Guayaquil [US Consulate General] Ecuador
H
Ha''apai Group Tonga
Habomai Islands Russia [de facto]
Hague, The [US Embassy] Netherlands
Hainan Dao China
Halifax [US Consulate General] Canada
Halmahera Indonesia
Hamburg [US Consulate General] Germany
Hamilton [US Consulate General] Bermuda
Hanoi Vietnam
Harare [US Embassy] Zimbabwe
Hatay Turkey
Havana [US post not maintained; Cuba
representation by US Interests
Section (USINT) of the Swiss
Embassy]
Hawaii United States
Heard Island Heard Island and McDonald Islands
Helsinki [US Embassy] Finland
Hermosillo [US Consulate] Mexico
Hispaniola Dominican Republic; Haiti
Hokkaido Japan
Hong Kong [US Consulate General] Hong Kong
Honiara [US Consulate] Solomon Islands
Honshu Japan
Hormuz, Strait of Indian Ocean
Horn, Cape (Cabo de Hornos) Chile
Horne, Iles de Wallis and Futuna
Horn of Africa Ethiopia; Somalia
Hudson Bay Arctic Ocean
Hudson Strait Arctic Ocean
I
Inaccessible Island Saint Helena
Indochina Cambodia; Laos; Vietnam
Inner Mongolia (Nei Mongol) China
Ionian Islands Greece
Ionian Sea Atlantic Ocean
Irian Jaya Indonesia
Irish Sea Atlantic Ocean
Islamabad [US Embassy] Pakistan
Islas Malvinas Falkland Islands (Islas Malvinas)
Istanbul [US Consulate General] Turkey
Italian Somaliland Somalia
Ivory Coast Cote d''Ivoire
Iwo Jima Japan
J
Jakarta [US Embassy] Indonesia
Jamestown Saint Helena
Japan, Sea of Pacific Ocean
Java Indonesia
Java Sea Pacific Ocean
Jeddah (see Jiddah) Saudi Arabia
Jerusalem [US Consulate General] Israel; West Bank
Jiddah [US Consulate General] Saudi Arabia
Johannesburg [US Consulate General] South Africa
Juan de Fuca, Strait of Pacific Ocean
Juan Fernandez, Isla de Chile
Juventud, Isla de la (Isle of Youth) Cuba
K
Kabul [US Embassy now closed] Afghanistan
Kaduna [US Consulate General] Nigeria
Kalimantan Indonesia
Kamchatka Peninsula Russia
(Poluostrov Kamchatka)
Kampala [US Embassy] Uganda
Kampuchea Cambodia
Karachi [US Consulate General] Pakistan
Kara Sea Arctic Ocean
Karimata Strait Pacific Ocean
Kathmandu [US Embassy] Nepal
Kattegat Atlantic Ocean
Kauai Channel Pacific Ocean
Keeling Islands Cocos (Keeling) Islands
Kerguelen, Iles French Southern and Antarctic Lands
Kermadec Islands New Zealand
Khabarovsk Russia
Khartoum [US Embassy] Sudan
Khmer Republic Cambodia
Khuriya Muriya Islands (Kuria Oman
Muria Islands)
Khyber Pass Pakistan
Kiel Canal (Nord-Ostsee Kanal) Atlantic Ocean
Kiev [US Embassy] Ukraine
Kigali [US Embassy closed Rwanda
indefinitely]
Kingston [US Embassy] Jamaica
Kingston Norfolk Island
Kingstown Saint Vincent and the Grenadines
Kinshasa [US Embassy] Zaire
Kirghiziya Kyrgyzstan
Kiritimati (Christmas Island) Kiribati
Kishinev (Chisinau) Moldova
Kithira Strait Atlantic Ocean
Kodiak Island United States
Kola Peninsula (Kol''skiy Poluostrov) Russia
Kolonia [US Embassy] Micronesia, Federated States of
Korea Bay Pacific Ocean
Korea, Democratic People''s Korea, North
Republic of
Korea, Republic of Korea, South
Korea Strait Pacific Ocean
Koror [US Liaison Office] Pacific Islands, Trust Territory of
Kosovo Serbia and Montenegro
Kowloon Hong Kong
Krakow [US Consulate General] Poland
Kuala Lumpur [US Embassy] Malaysia
Kunashiri (Kunashir) Russia [de facto]
Kuril Islands Russia [de facto]
Kuwait [US Embassy] Kuwait
Kwajalein Atoll Marshall Islands
Kyushu Japan
Kyyiv (Kiev) Ukraine
L
Labrador Canada
Laccadive Islands India
Laccadive Sea Indian Ocean
Lagos [US Embassy] Nigeria
Lahore [US Consulate General] Pakistan
Lakshadweep India
La Paz [US Embassy] Bolivia
La Perouse Strait Pacific Ocean
Laptev Sea Arctic Ocean
Las Palmas [US Consular Agency] Spain
Lau Group Fiji
Leipzig [US Consulate General] Germany
Leningrad (see Saint Petersburg) Russia
Lesser Sunda Islands Indonesia
Leyte Philippines
Liancourt Rocks [claimed by Japan] Korea, South
Libreville [US Embassy] Gabon
Ligurian Sea Atlantic Ocean
Lilongwe [US Embassy] Malawi
Lima [US Embassy] Peru
Lincoln Sea Arctic Ocean
Line Islands Kiribati; Palmyra Atoll
Lisbon [US Embassy] Portugal
Ljubljana [US Embassy] Slovenia
Lobamba Swaziland
Lombok Strait Indian Ocean
Lome [US Embassy] Togo
London [US Embassy] United Kingdom
Longyearbyen Svalbard
Lord Howe Island Australia
Louisiade Archipelago Papua New Guinea
Loyalty Islands (Iles Loyaute) New Caledonia
Luanda [US Embassy] Angola
Lusaka [US Embassy] Zambia
Luxembourg [US Embassy] Luxembourg
Luzon Philippines
Luzon Strait Pacific Ocean
M
Macao Macau
Macedonia The Former Yugoslav Republic
of Macedonia
Macquarie Island Australia
Madeira Islands Portugal
Madras [US Consulate General] India
Madrid [US Embassy] Spain
Magellan, Strait of Atlantic Ocean
Maghreb Algeria, Libya, Mauritania, Morocco,','657e7a6831f70f980a6edc3d7ffaa0fc7128fcb66fa7e9ee33fc06cfa4028173','internet-archive','theciaworldfactb00180gut','txt','b76993377cfa6bdd51979833301976cfc440911ee1fe0b90c117008758860b3f','https://archive.org/download/theciaworldfactb00180gut/180.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f8689f28939b13a4c7fa3529ee6051c63ad749776ad767036b4bbf33b4034cb',1994,'TG','Togo','energy',237,'-----
West African Economic Community (CEAO)
note - acronym from Communaute Economique de l''Afrique de l''Ouest
established - 3 June 1972
aim - to promote regional economic development
members - (7) Benin, Burkina, Cote d''Ivoire, Mali, Mauritania, Niger,','a61d2c7f59f5aca69d3493166bbce4c269fc95cecfb8f374da43f4f15b4a6b45','internet-archive','theciaworldfactb00180gut','txt','b76993377cfa6bdd51979833301976cfc440911ee1fe0b90c117008758860b3f','https://archive.org/download/theciaworldfactb00180gut/180.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37a407e96d88f57e17d35516b1bb07937f0edcf60b78146f9c2c95e0e00b439d',1994,'SN','Senegal','energy',238,'observers - (2) Guinea, Togo
-----
Western European Union (WEU)
established - 23 October 1954
effective - 6 May 1955
aim - mutual defense and progressive political unification
members - (9) Belgium, France, Germany, Italy, Luxembourg, Netherlands,
Portugal, Spain, UK
associate members - (4) Greece, Iceland, Norway, Turkey
observers - (2) Denmark, Ireland
-----
World Bank
see International Bank for Reconstruction and Development (IBRD)
-----
World Bank Group
includes International Bank for Reconstruction and Development (IBRD),
International Development Association (IDA), and International Finance
Corporation (IFC)
-----
World Confederation of Labor (WCL)
established - 19 June 1920 as the International Federation of Christian
Trade Unions (IFCTU), renamed 4 October 1968
aim - to promote the trade union movement
members - (99 national organizations) Algeria, Angola, Antigua and Barbuda,
Argentina, Aruba, Austria, Bangladesh, Belgium, Belize, Benin, Bolivia,
Bonaire Island, Botswana, Brazil, Burkina, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, Colombia, Costa Rica, Cote d''Ivoire,
Cuba, Curacao, Cyprus, Dominica, Dominican Republic, Ecuador, El Salvador,
France, French Guiana, Gabon, The Gambia, Ghana, Grenada, Guadeloupe,
Guatemala, Guinea, Guyana, Haiti, Honduras, Hong Kong, Indonesia, Iran,
Italy, Jamaica, Kenya, Lesotho, Liberia, Liechtenstein, Luxembourg,
Madagascar, Malaysia, Mali, Malta, Martinique, Mauritius, Mexico,
Montserrat, Namibia, Netherlands, Nicaragua, Niger, Nigeria, Pakistan,
Panama, Paraguay, Peru, Philippines, Poland, Portugal, Puerto Rico,
Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Martin, Saint
Vincent and the Grenadines, Senegal, Seychelles, Sierra Leone, Spain, Sri
Lanka, Suriname, Switzerland, Taiwan, Tanzania, Thailand, Togo, UK, US,
Uruguay, Venezuela, Vietnam, Zaire, Zambia, Zimbabwe
-----
World Court
see International Court of Justice (ICJ)
-----
World Federation of Trade Unions (WFTU)
established - 3 October 1945
aim - to promote the trade union movement
members - (86) Afghanistan, Albania, Angola, Argentina, Australia, Austria,
Bahrain, Bangladesh, Benin, Bolivia, Brazil, Bulgaria, Burkina, Cambodia,
Chile, Colombia, Congo, Costa Rica, Cuba, Cyprus, Czech Republic, Denmark,
Dominican Republic, Ecuador, El Salvador, Ethiopia, Finland, France, The
Gambia, Greece, Guadeloupe, Guatemala, Guinea-Bissau, Guyana, Haiti,
Honduras, Hungary, India, Indonesia, Iran, Iraq, Jamaica, Japan, Jordan,
North Korea, Kuwait, Laos, Lebanon, Madagascar, Martinique, Mauritius,
Mexico, Mongolia, Namibia, Nepal, New Caledonia, Nicaragua, Oman, Pakistan,
Panama, Papua New Guinea, Peru, Philippines, Poland, Puerto Rico, Reunion,
Romania, Saint Pierre and Miquelon, Saint Vincent and the Grenadines, Saudi
Arabia, Senegal, Slovakia, Solomon Islands, South Africa, Sri Lanka, Sudan,
Sweden, Syria, Thailand, Trinidad and Tobago, Turkey, Uruguay, Venezuela,
Vietnam, Yemen, Zaire
-----
World Food Council (WFC)
established - 17 December 1974
aim - ECOSOC organization that studies world food problems and recommends
solutions
members - (36) selected on a rotating basis from all regions
-----
World Food Program (WFP)
established - 24 November 1961
aim - ECOSOC organization that provides food aid to assist in development
or disaster relief
members - (42) selected on a rotating basis from all regions
-----
World Health Organization (WHO)
established - 22 July 1946
effective - 7 April 1948
aim - UN specialized agency concerned with health matters
members - (186) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina, Burma,
Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic,
Chad, Chile, China, Colombia, Comoros, Congo, Cook Islands, Costa Rica,
Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau,
Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya,
Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia,
Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay,
Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, San Marino,
Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa,
Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, The Former Yugoslav Republic of Macedonia,
Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu,
Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela,
Vietnam, Western Samoa, Yemen, Yugoslavia (suspended), Zaire, Zambia,','a6db58c47f47fb839f9a854d5b997e54976a1c9183207bbc7b43fb623e036d98','internet-archive','theciaworldfactb00180gut','txt','b76993377cfa6bdd51979833301976cfc440911ee1fe0b90c117008758860b3f','https://archive.org/download/theciaworldfactb00180gut/180.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4bb7202f88afb4a99d1457a9beff91134fef8976cf09334ccd0ce7cabd1d04e0',1994,'TN','Tunisia','energy',239,'Mahe Island Seychelles
Maiz, Islas del (Corn Islands) Nicaragua
Majorca (Mallorca) Spain
Majuro [US Embassy] Marshall Islands
Makassar Strait Pacific Ocean
Malabo [US Embassy] Equatorial Guinea
Malacca, Strait of Indian Ocean
Malagasy Republic Madagascar
Male [US Consular Agency] Maldives
Mallorca (Majorca) Spain
Malpelo, Isla de Colombia
Malta Channel Atlantic Ocean
Malvinas, Islas Falkland Islands (Islas Malvinas)
Mamoutzou Mayotte
Managua [US Embassy] Nicaragua
Manama [US Embassy] Bahrain
Manaus [US Consular Agency] Brazil
Manchukuo China
Manchuria China
Manila [US Embassy] Philippines
Manipa Strait Pacific Ocean
Mannar, Gulf of Indian Ocean
Manua Islands American Samoa
Maputo [US Embassy] Mozambique
Marcus Island (Minami-tori-shima) Japan
Mariana Islands Guam; Northern Mariana Islands
Marion Island South Africa
Marmara, Sea of Atlantic Ocean
Marquesas Islands (Iles Marquises) French Polynesia
Marseille [US Consulate General] France
Martin Vaz, Ilhas Brazil
Mas a Tierra (Robinson Crusoe Chile
Island)
Mascarene Islands Mauritius; Reunion
Maseru [US Embassy] Lesotho
Matamoros [US Consulate] Mexico
Mata-Utu Wallis and Futuna
Mazatlan [US Consulate closed Mexico
May 1993]
Mbabane [US Embassy] Swaziland
McDonald Islands Heard Island and McDonald Islands
Medan [US Consulate] Indonesia
Mediterranean Sea Atlantic Ocean
Melbourne [US Consulate General] Australia
Melilla Spain
Merida [US Consulate Mexico
Messina, Strait of Atlantic Ocean
Mexico [US Embassy] Mexico
Mexico, Gulf of Atlantic Ocean
Milan [US Consulate General] Italy
Minami-tori-shima Japan
Mindanao Philippines
Mindoro Strait Pacific Ocean
Minicoy Island India
Minsk [US Embassy] Belarus
Mogadishu [US Liaison Office] Somalia
Moldavia Moldova
Mombasa [US Consulate closed Kenya
May 1993]
Mona Passage Atlantic Ocean
Monrovia [US Embassy] Liberia
Montenegro Serbia and Montenegro
Monterrey [US Consulate General] Mexico
Montevideo [US Embassy] Uruguay
Montreal [US Consulate General, US Canada
Mission to the International Civil
Aviation Organization (ICAO)]
Moravian Gate Czech Republic
Moroni [US Embassy] Comoros
Mortlock Islands Micronesia, Federated States of
Moscow [US Embassy] Russia
Mozambique Channel Indian Ocean
Munich [US Consulate General] Germany
Musandam Peninsula Oman; United Arab Emirates
Muscat [US Embassy] Oman
Muscat and Oman Oman
Myanma, Myanmar Burma
N
Naha [US Consulate General] Japan
Nairobi [US Embassy] Kenya
Nampo-shoto Japan
Naples [US Consulate General] Italy
Nassau [US Embassy] Bahamas, The
Natuna Besar Islands Indonesia
N''Djamena [US Embassy] Chad
Netherlands East Indies Indonesia
Netherlands Guiana Suriname
Nevis Saint Kitts and Nevis
New Delhi [US Embassy] India
Newfoundland Canada
New Guinea Indonesia; Papua New Guinea
New Hebrides Vanuatu
New Siberian Islands Russia
New Territories Hong Kong
New York, New York [US Mission to United States
the United Nations (USUN)]
Niamey [US Embassy] Niger
Nicobar Islands India
Nicosia [US Embassy] Cyprus
Nightingale Island Saint Helena
North Atlantic Ocean Atlantic Ocean
North Channel Atlantic Ocean
Northeast Providence Channel Atlantic Ocean
Northern Epirus Albania; Greece
Northern Grenadines Saint Vincent and the Grenadines
Northern Ireland United Kingdom
Northern Rhodesia Zambia
North Island New Zealand
North Korea Korea, North
North Pacific Ocean Pacific Ocean
North Sea Atlantic Ocean
North Vietnam Vietnam
Northwest Passages Arctic Ocean
North Yemen (Yemen Arab Republic) Yemen
Norwegian Sea Atlantic Ocean
Nouakchott [US Embassy] Mauritania
Noumea New Caledonia
Novaya Zemlya Russia
Nuku''alofa Tonga
Nuevo Laredo [US Consulate] Mexico
Nuuk (Godthab) Greenland
Nyasaland Malawi
O
Oahu United States
Ocean Island (Banaba) Kiribati
Ocean Island (Kure Island) United States
Ogaden Ethiopia; Somalia
Oil Islands (Chagos Archipelago) British Indian Ocean Territory
Okhotsk, Sea of Pacific Ocean
Okinawa Japan
Oman, Gulf of Indian Ocean
Ombai Strait Pacific Ocean
Oran [US Consulate] Algeria
Oranjestad Aruba
Oresund (The Sound) Atlantic Ocean
Orkney Islands United Kingdom
Osaka-Kobe [US Consulate General] Japan
Oslo [US Embassy] Norway
Otranto, Strait of Atlantic Ocean
Ottawa [US Embassy] Canada
Ouagadougou [US Embassy] Burkina
Outer Mongolia Mongolia
P
Pagan Northern Mariana Islands
Pago Pago American Samoa
Palau Pacific Islands, Trust Territory
of the
Palawan Philippines
Palermo [US Consulate General] Italy
Palk Strait Indian Ocean
Pamirs China; Tajikistan
Panama [US Embassy] Panama
Panama Canal Panama
Panama, Gulf of Pacific Ocean
Papeete French Polynesia
Paramaribo [US Embassy] Suriname
Parece Vela Japan
Paris [US Embassy, US Mission to the France
Organization for Economic
Cooperation and Development (OECD),
US Observer Mission at the UN
Educational, Scientific, and
Cultural Organization (UNESCO)]
Pascua, Isla de (Easter Island) Chile
Passion, Ile de la Clipperton Island
Pashtunistan Afghanistan; Pakistan
Peking (Beijing) China
Pemba Island Tanzania
Pentland Firth Atlantic Ocean
Perim Yemen
Perouse Strait, La Pacific Ocean
Persian Gulf Indian Ocean
Perth [US Consulate General] Australia
Pescadores Taiwan
Peshawar [US Consulate] Pakistan
Peter I Island Antarctica
Philip Island Norfolk Island
Philippine Sea Pacific Ocean
Phnom Penh [US Embassy] Cambodia
Phoenix Islands Kiribati
Pines, Isle of (Isla de la Juventud) Cuba
Pleasant Island Nauru
Plymouth Montserrat
Ponape (Pohnpei) Micronesia
Ponta Delgada [US Consulate] Portugal
Port-au-Prince [US Embassy] Haiti
Port Louis [US Embassy] Mauritius
Port Moresby [US Embassy] Papua New Guinea
Porto Alegre [US Consulate] Brazil
Port-of-Spain [US Embassy] Trinidad and Tobago
Porto-Novo Benin
Portuguese Guinea Guinea-Bissau
Portuguese Timor (East Timor) Indonesia
Port-Vila Vanuatu
Poznan [US Consulate General] Poland
Prague [US Embassy] Czech Republic
Praia [US Embassy] Cape Verde
Pretoria [US Embassy] South Africa
Pribilof Islands United States
Prince Edward Island Canada
Prince Edward Islands South Africa
Prince Patrick Island Canada
Principe Sao Tome and Principe
Pusan [US Consulate] Korea, South
P''yongyang Korea, North
Q
Quebec [US Consulate General] Canada
Queen Charlotte Islands Canada
Queen Elizabeth Islands Canada
Queen Maud Land [claimed by Norway] Antarctica
Quito [US Embassy] Ecuador
R
Rabat [US Embassy] Morocco
Ralik Chain Marshall Islands
Rangoon [US Embassy] Burma
Ratak Chain Marshall Islands
Recife [US Consulate] Brazil
Redonda Antigua and Barbuda
Red Sea Indian Ocean
Revillagigedo Island United States
Revillagigedo Islands Mexico
Reykjavik [US Embassy] Iceland
Rhodes Greece
Rhodesia Zimbabwe
Rhodesia, Northern Zambia
Rhodesia, Southern Zimbabwe
Riga [US Embassy] Latvia
Rio de Janeiro [US Consulate Brazil
General]
Rio de Oro Western Sahara
Rio Muni Equatorial Guinea
Riyadh [US Embassy] Saudi Arabia
Road Town British Virgin Islands
Robinson Crusoe Island (Mas Chile
a Tierra)
Rocas, Atol das Brazil
Rockall [disputed] United Kingdom
Rodrigues Mauritius
Rome [US Embassy, US Mission to the Italy
UN Agencies for Food and
Agriculture (FODAG)]
Roncador Cay Colombia
Roosevelt Island Antarctica
Roseau Dominica
Ross Dependency [claimed by Antarctica
New Zealand]
Ross Island Antarctica
Ross Sea Antarctica
Rota Northern Mariana Islands
Rotuma Fiji
Ryukyu Islands Japan
S
Saba Netherlands Antilles
Sabah Malaysia
Sable Island Canada
Sahel Burkina, Cape Verde, Chad,
The Gambia, Guinea-Bissau, Mali,
Mauritania, Niger, Senegal
Saigon (Ho Chi Minh City) Vietnam
Saint Brandon Mauritius
Saint Christopher and Nevis Saint Kitts and Nevis
Saint-Denis Reunion
Saint George''s [US Embassy] Grenada
Saint George''s Channel Atlantic Ocean
Saint Helier Jersey
Saint John''s [US Embassy] Antigua and Barbuda
Saint Lawrence, Gulf of Atlantic Ocean
Saint Lawrence Island United States
Saint Lawrence Seaway Atlantic Ocean
Saint Martin Guadeloupe
Saint Martin (Sint Maarten) Netherlands Antilles
Saint Paul Island Canada
Saint Paul Island United States
Saint Paul Island (Ile Saint-Paul) French Southern and Antarctic Lands
Saint Peter and Saint Paul Rocks Brazil
(Penedos de Sao Pedro e Sao Paulo)
Saint Peter Port Guernsey
Saint Petersburg [US Consulate] Russia
Saint-Pierre Saint Pierre and Miquelon
Saint Vincent Passage Atlantic Ocean
Saipan Northern Mariana Islands
Sakhalin Island (Ostrov Sakhalin) Russia
Sala y Gomez, Isla Chile
Salisbury (Harare) Zimbabwe
Salvador de Bahia [US Consular Brazil
Agency]
Salzburg [US Consulate General] Austria
Sanaa [US Embassy] Yemen
San Ambrosio Chile
San Andres y Providencia, Colombia
Archipielago
San Bernardino Strait Pacific Ocean
San Felix, Isla Chile
San Jose [US Embassy] Costa Rica
San Juan Puerto Rico
San Luis Potosi [US Consular Agency] Mexico
San Marino San Marino
San Salvador [US Embassy] El Salvador
Santa Cruz [US Consular Agency] Bolivia
Santa Cruz Islands Solomon Islands
Santiago [US Embassy] Chile
Santo Domingo [US Embassy] Dominican Republic
Sao Paulo [US Consulate General] Brazil
Sao Pedro e Sao Paulo, Penedos de Brazil
Sao Tome Sao Tome and Principe
Sapporo [US Consulate General] Japan
Sapudi Strait Pacific Ocean
Sarajevo [US Embassy] Bosnia and Herzegovina
Sarawak Malaysia
Sardinia Italy
Sargasso Sea Atlantic Ocean
Sark Guernsey
Scotia Sea Atlantic Ocean
Scotland United Kingdom
Scott Island Antarctica
Senyavin Islands Micronesia, Federated States of
Seoul [US Embassy] Korea, South
Serbia Serbia and Montenegro
Serrana Bank Colombia
Serranilla Bank Colombia
Settlement, The Christmas Island
Severnaya Zemlya (Northland) Russia
Shag Island Heard Island and McDonald Islands
Shag Rocks Falkland Islands (Islas Malvinas)
Shanghai [US Consulate General] China
Shenyang [US Consulate General] China
Shetland Islands United Kingdom
Shikoku Japan
Shikotan (Shikotan-to) Japan
Siam Thailand
Sibutu Passage Pacific Ocean
Sicily Italy
Sicily, Strait of Atlantic Ocean
Sikkim India
Sinai Egypt
Singapore [US Embassy] Singapore
Singapore Strait Pacific Ocean
Sinkiang (Xinjiang) China
Sint Eustatius Netherlands Antilles
Sint Maarten (Saint Martin) Netherlands Antilles
Skagerrak Atlantic Ocean
Skopje The Former Yugoslav Republic of
Macedonia
Society Islands (Iles de la Societe) French Polynesia
Socotra Yemen
Sofia [US Embassy] Bulgaria
Solomon Islands, northern Papua New Guinea
Solomon Islands, southern Solomon Islands
Solomon Sea Pacific Ocean
Songkhla [US Consulate] Thailand
Sound, The (Oresund) Atlantic Ocean
South Atlantic Ocean Atlantic Ocean
South China Sea Pacific Ocean
Southern Grenadines Grenada
Southern Rhodesia Zimbabwe
South Georgia South Georgia and the South Sandwich
Islands
South Island New Zealand
South Korea Korea, South
South Orkney Islands Antarctica
South Pacific Ocean Pacific Ocean
South Sandwich Islands South Georgia and the South Sandwich
Islands
South Shetland Islands Antarctica
South Tyrol Italy
South Vietnam Vietnam
South-West Africa Namibia
South Yemen (People''s Democratic Yemen
Republic of Yemen)
Soviet Union Armenia, Azerbaijan, Belarus,
Estonia, Georgia, Kazakhstan,
Kyrgyzstan, Latvia, Lithuania,
Moldova, Russia, Tajikistan,
Turkmenistan, Ukraine, Uzbekistan
Spanish Guinea Equatorial Guinea
Spanish Sahara Western Sahara
Spitsbergen Svalbard
Stanley Falkland Islands (Islas Malvinas)
Stockholm [US Embassy] Sweden
Strasbourg [US Consulate General] France
Stuttgart [US Consulate General] Germany
Suez, Gulf of Indian Ocean
Sulu Archipelago Philippines
Sulu Sea Pacific Ocean
Sumatra Indonesia
Sumba Indonesia
Sunda Islands (Soenda Isles) Indonesia; Malaysia
Sunda Strait Indian Ocean
Surabaya [US Consulate] Indonesia
Surigao Strait Pacific Ocean
Surinam Suriname
Suva [US Embassy] Fiji
Swains Island American Samoa
Swan Islands Honduras
Sydney [US Consulate General] Australia
T
Tahiti French Polynesia
Taipei Taiwan
Taiwan Strait Pacific Ocean
Tallinn [US Embassy] Estonia
Tanganyika Tanzania
Tangier Morocco
Tarawa Kiribati
Tartar Strait Pacific Ocean
Tashkent [US Embassy] Uzbekistan
Tasmania Australia
Tasman Sea Pacific Ocean
Taymyr Peninsula (Poluostrov Taymyra) Russia
T''bilisi [US Embassy] Georgia
Tegucigalpa [US Embassy] Honduras
Tehran [US post not maintained; Iran
representation by Swiss Embassy]
Tel Aviv [US Embassy] Israel
Terre Adelie (Adelie Land) Antarctica
[claimed by France]
Thailand, Gulf of Pacific Ocean
Thessaloniki [US Consulate General] Greece
Thimphu Bhutan
Thurston Island Antarctica
Tibet (Xizang) China
Tibilisi (see T''bilisi) Georgia
Tierra del Fuego Argentina; Chile
Tijuana [US Consulate General] Mexico
Timor Indonesia
Timor Sea Pacific Ocean
Tinian Northern Mariana Islands
Tiran, Strait of Indian Ocean
Tirane [US Embassy] Albania
Tobago Trinidad and Tobago
Tokyo [US Embassy] Japan
Tonkin, Gulf of Pacific Ocean
Toronto [US Consulate General] Canada
Torres Strait Pacific Ocean
Torshavn Faroe Islands
Toshkent (Tashkent) Uzbekistan
Transjordan Jordan
Transkei South Africa
Transylvania Romania
Trindade, Ilha de Brazil
Tripoli [US post not maintained; Libya
representation by Belgian Embassy]
Tristan da Cunha Group Saint Helena
Trobriand Islands Papua New Guinea
Trucial States United Arab Emirates
Truk Islands Micronesia
Tsugaru Strait Pacific Ocean
Tuamotu Islands (Iles Tuamotu) French Polynesia
Tubuai Islands (Iles Tubuai) French Polynesia
Tunis [US Embassy] Tunisia
Turin Italy
Turkish Straits Atlantic Ocean
Turkmeniya Turkmenistan
Turks Island Passage Atlantic Ocean
Tyrol, South Italy
Tyrrhenian Sea Atlantic Ocean
U
Udorn (Udon Thani) [US Consulate] Thailand
Ulaanbaatar [US Embassy] Mongolia
Ullung-do Korea, South
Unimak Pass [strait] Pacific Ocean
Union of Soviet Socialist Republics Armenia, Azerbaijan, Belarus,
Estonia, Georgia, Kazakhstan,
Kyrgyzstan, Latvia, Lithuania,
Moldova, Russia, Tajikistan,
Turkmenistan, Ukraine, Uzbekistan
United Arab Republic Egypt; Syria
Upper Volta Burkina
USSR Armenia, Azerbaijan, Belarus,
Estonia, Georgia, Kazakhstan,
Kyrgyzstan, Latvia, Lithuania,
Moldova, Russia, Tajikistan,
Turkmenistan, Ukraine, Uzbekistan
V
Vaduz [US post not maintained; Liechtenstein
representation from Zurich,
Switzerland]
Vakhan (Wakhan Corridor) Afghanistan
Valletta [US Embassy] Malta
Valley, The Anguilla
Vancouver [US Consulate General] Canada
Vancouver Island Canada
Van Diemen Strait Pacific Ocean
Vatican City [US Embassy] Holy See
Velez de la Gomera, Penon de Spain
Venda South Africa
Verde Island Passage Pacific Ocean
Victoria Hong Kong
Victoria [US Embassy] Seychelles
Vienna [US Embassy, US Mission to Austria
International Organizations in
Vienna (UNVIE)]
Vientiane [US Embassy] Laos
Vilnius [US Embassy] Lithuania
Vladivostok [US Consulate] Russia
Volcano Islands Japan
Vostok Island Kiribati
Vrangelya, Ostrov (Wrangel Island) Russia
W
Wakhan Corridor (now Vakhan) Afghanistan
Wales United Kingdom
Walvis Bay Namibia
Warsaw [US Embassy] Poland
Washington, DC [The Permanent Mission United States
of the US to the Organization of
American States (OAS)]
Weddell Sea Atlantic Ocean
Wellington [US Embassy] New Zealand
Western Channel (West Korea Strait) Pacific Ocean
West Germany (Federal Republic of Germany
Germany)
West Island Cocos (Keeling) Islands
West Korea Strait (Western Channel) Pacific Ocean
West Pakistan Pakistan
Wetar Strait Pacific Ocean
White Sea Arctic Ocean
Willemstad Netherlands Antilles
Windhoek [US Embassy] Namibia
Windward Passage Atlantic Ocean
Wrangel Island (Ostrov Vrangelya) Russia [de facto]
Y
Yamoussoukro Cote d''Ivoire
Yaounde [US Embassy] Cameroon
Yap Islands Micronesia
Yaren Nauru
Yellow Sea Pacific Ocean
Yemen (Aden) [People''s Democratic Yemen
Republic of Yemen]
Yemen Arab Republic Yemen
Yemen, North [Yemen Arab Republic] Yemen
Yemen (Sanaa) [Yemen Arab Republic] Yemen
Yemen, People''s Democratic Yemen
Republic of
Yemen, South [People''s Democratic Yemen
Republic of Yemen]
Yerevan [US Embassy] Armenia
Youth, Isle of (Isla de la Juventud) Cuba
Yucatan Channel Atlantic Ocean
Yugoslavia Bosnia and Herzegovina, Croatia,
Serbia and Montenegro, Slovenia,
The Former Yugoslav Republic of
Macedonia
Z
Zagreb [US Embassy] Croatia
Zanzibar Tanzania
Zurich [US Consulate General] Switzerland
End of the Project Gutenberg EBook of The 1994 CIA World Factbook, by
United States Central Intelligence Agency
*** END OF THIS PROJECT GUTENBERG EBOOK THE 1994 CIA WORLD FACTBOOK ***
***** This file should be named 180.txt or 180.zip *****
This and all associated files of various formats will be found in:
http://www.gutenberg.org/1/8/180/
Updated editions will replace the previous one--the old editions
will be renamed.
Creating the works from public domain print editions means that no
one owns a United States copyright in these works, so the Foundation
(and you!) can copy and distribute it in the United States without
permission and without paying copyright royalties. Special rules,
set forth in the General Terms of Use part of this license, apply to
copying and distributing Project Gutenberg-tm electronic works to
protect the PROJECT GUTENBERG-tm concept and trademark. Project
Gutenberg is a registered trademark, and may not be used if you
charge for the eBooks, unless you receive specific permission. If you
do not charge anything for copies of this eBook, complying with the
rules is very easy. You may use this eBook for nearly any purpose
such as creation of derivative works, reports, performances and
research. They may be modified and printed and given away--you may do
practically ANYTHING with public domain eBooks. Redistribution is
subject to the trademark license, especially commercial
redistribution.
*** START: FULL LICENSE ***
THE FULL PROJECT GUTENBERG LICENSE
PLEASE READ THIS BEFORE YOU DISTRIBUTE OR USE THIS WORK
To protect the Project Gutenberg-tm mission of promoting the free
distribution of electronic works, by using or distributing this work
(or any other work associated in any way with the phrase "Project
Gutenberg"), you agree to comply with all the terms of the Full Project
Gutenberg-tm License (available with this file or online at
http://gutenberg.net/license).
Section 1. General Terms of Use and Redistributing Project Gutenberg-tm
electronic works
1.A. By reading or using any part of this Project Gutenberg-tm
electronic work, you indicate that you have read, understand, agree to
and accept all the terms of this license and intellectual property
(trademark/copyright) agreement. If you do not agree to abide by all
the terms of this agreement, you must cease using and return or destroy
all copies of Project Gutenberg-tm electronic works in your possession.
If you paid a fee for obtaining a copy of or access to a Project
Gutenberg-tm electronic work and you do not agree to be bound by the
terms of this agreement, you may obtain a refund from the person or
entity to whom you paid the fee as set forth in paragraph 1.E.8.
1.B. "Project Gutenberg" is a registered trademark. It may only be
used on or associated in any way with an electronic work by people who
agree to be bound by the terms of this agreement. There are a few
things that you can do with most Project Gutenberg-tm electronic works
even without complying with the full terms of this agreement. See
paragraph 1.C below. There are a lot of things you can do with Project
Gutenberg-tm electronic works if you follow the terms of this agreement
and help preserve free future access to Project Gutenberg-tm electronic
works. See paragraph 1.E below.
1.C. The Project Gutenberg Literary Archive Foundation ("the Foundation"
or PGLAF), owns a compilation copyright in the collection of Project
Gutenberg-tm electronic works. Nearly all the individual works in the
collection are in the public domain in the United States. If an
individual work is in the public domain in the United States and you are
located in the United States, we do not claim a right to prevent you from
copying, distributing, performing, displaying or creating derivative
works based on the work as long as all references to Project Gutenberg
are removed. Of course, we hope that you will support the Project
Gutenberg-tm mission of promoting free access to electronic works by
freely sharing Project Gutenberg-tm works in compliance with the terms of
this agreement for keeping the Project Gutenberg-tm name associated with
the work. You can easily comply with the terms of this agreement by
keeping this work in the same format with its attached full Project
Gutenberg-tm License when you share it without charge with others.
1.D. The copyright laws of the place where you are located also govern
what you can do with this work. Copyright laws in most countries are in
a constant state of change. If you are outside the United States, check
the laws of your country in addition to the terms of this agreement
before downloading, copying, displaying, performing, distributing or
creating derivative works based on this work or any other Project
Gutenberg-tm work. The Foundation makes no representations concerning
the copyright status of any work in any country outside the United
States.
1.E. Unless you have removed all references to Project Gutenberg:
1.E.1. The following sentence, with active links to, or other immediate
access to, the full Project Gutenberg-tm License must appear prominently
whenever any copy of a Project Gutenberg-tm work (any work on which the
phrase "Project Gutenberg" appears, or with which the phrase "Project
Gutenberg" is associated) is accessed, displayed, performed, viewed,
copied or distributed:
This eBook is for the use of anyone anywhere at no cost and with
almost no restrictions whatsoever. You may copy it, give it away or
re-use it under the terms of the Project Gutenberg License included
with this eBook or online at www.gutenberg.net
1.E.2. If an individual Project Gutenberg-tm electronic work is derived
from the public domain (does not contain a notice indicating that it is
posted with permission of the copyright holder), the work can be copied
and distributed to anyone in the United States without paying any fees
or charges. If you are redistributing or providing access to a work
with the phrase "Project Gutenberg" associated with or appearing on the
work, you must comply either with the requirements of paragraphs 1.E.1
through 1.E.7 or obtain permission for the use of the work and the
Project Gutenberg-tm trademark as set forth in paragraphs 1.E.8 or
1.E.9.
1.E.3. If an individual Project Gutenberg-tm electronic work is posted
with the permission of the copyright holder, your use and distribution
must comply with both paragraphs 1.E.1 through 1.E.7 and any additional
terms imposed by the copyright holder. Additional terms will be linked
to the Project Gutenberg-tm License for all works posted with the
permission of the copyright holder found at the beginning of this work.
1.E.4. Do not unlink or detach or remove the full Project Gutenberg-tm
License terms from this work, or any files containing a part of this
work or any other work associated with Project Gutenberg-tm.
1.E.5. Do not copy, display, perform, distribute or redistribute this
electronic work, or any part of this electronic work, without
prominently displaying the sentence set forth in paragraph 1.E.1 with
active links or immediate access to the full terms of the Project
Gutenberg-tm License.
1.E.6. You may convert to and distribute this work in any binary,
compressed, marked up, nonproprietary or proprietary form, including any
word processing or hypertext form. However, if you provide access to or
distribute copies of a Project Gutenberg-tm work in a format other than
"Plain Vanilla ASCII" or other format used in the official version
posted on the official Project Gutenberg-tm web site (www.gutenberg.net),
you must, at no additional cost, fee or expense to the user, provide a
copy, a means of exporting a copy, or a means of obtaining a copy upon
request, of the work in its original "Plain Vanilla ASCII" or other
form. Any alternate format must include the full Project Gutenberg-tm
License as specified in paragraph 1.E.1.
1.E.7. Do not charge a fee for access to, viewing, displaying,
performing, copying or distributing any Project Gutenberg-tm works
unless y','91f3d9ee1a606f390a06720edc37fbe30c4ed4f8c1abd0a4b6aae91c884e4acc','internet-archive','theciaworldfactb00180gut','txt','b76993377cfa6bdd51979833301976cfc440911ee1fe0b90c117008758860b3f','https://archive.org/download/theciaworldfactb00180gut/180.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53a1b6ed33c3413585fa171f1545888dd103441e89cd11975e9b4b734782b9ae',1994,'TN','Tunisia','energy',240,'ou comply with paragraph 1.E.8 or 1.E.9.
1.E.8. You may charge a reasonable fee for copies of or providing
access to or distributing Project Gutenberg-tm electronic works provided
that
- You pay a royalty fee of 20% of the gross profits you derive from
the use of Project Gutenberg-tm works calculated using the method
you already use to calculate your applicable taxes. The fee is
owed to the owner of the Project Gutenberg-tm trademark, but he
has agreed to donate royalties under this paragraph to the
Project Gutenberg Literary Archive Foundation. Royalty payments
must be paid within 60 days following each date on which you
prepare (or are legally required to prepare) your periodic tax
returns. Royalty payments should be clearly marked as such and
sent to the Project Gutenberg Literary Archive Foundation at the
address specified in Section 4, "Information about donations to
the Project Gutenberg Literary Archive Foundation."
- You provide a full refund of any money paid by a user who notifies
you in writing (or by e-mail) within 30 days of receipt that s/he
does not agree to the terms of the full Project Gutenberg-tm
License. You must require such a user to return or
destroy all copies of the works possessed in a physical medium
and discontinue all use of and all access to other copies of
Project Gutenberg-tm works.
- You provide, in accordance with paragraph 1.F.3, a full refund of any
money paid for a work or a replacement copy, if a defect in the
electronic work is discovered and reported to you within 90 days
of receipt of the work.
- You comply with all other terms of this agreement for free
distribution of Project Gutenberg-tm works.
1.E.9. If you wish to charge a fee or distribute a Project Gutenberg-tm
electronic work or group of works on different terms than are set
forth in this agreement, you must obtain permission in writing from
both the Project Gutenberg Literary Archive Foundation and Michael
Hart, the owner of the Project Gutenberg-tm trademark. Contact the
Foundation as set forth in Section 3 below.
1.F.
1.F.1. Project Gutenberg volunteers and employees expend considerable
effort to identify, do copyright research on, transcribe and proofread
public domain works in creating the Project Gutenberg-tm
collection. Despite these efforts, Project Gutenberg-tm electronic
works, and the medium on which they may be stored, may contain
"Defects," such as, but not limited to, incomplete, inaccurate or
corrupt data, transcription errors, a copyright or other intellectual
property infringement, a defective or damaged disk or other medium, a
computer virus, or computer codes that damage or cannot be read by
your equipment.
1.F.2. LIMITED WARRANTY, DISCLAIMER OF DAMAGES - Except for the "Right
of Replacement or Refund" described in paragraph 1.F.3, the Project
Gutenberg Literary Archive Foundation, the owner of the Project
Gutenberg-tm trademark, and any other party distributing a Project
Gutenberg-tm electronic work under this agreement, disclaim all
liability to you for damages, costs and expenses, including legal
fees. YOU AGREE THAT YOU HAVE NO REMEDIES FOR NEGLIGENCE, STRICT
LIABILITY, BREACH OF WARRANTY OR BREACH OF CONTRACT EXCEPT THOSE
PROVIDED IN PARAGRAPH F3. YOU AGREE THAT THE FOUNDATION, THE
TRADEMARK OWNER, AND ANY DISTRIBUTOR UNDER THIS AGREEMENT WILL NOT BE
LIABLE TO YOU FOR ACTUAL, DIRECT, INDIRECT, CONSEQUENTIAL, PUNITIVE OR
INCIDENTAL DAMAGES EVEN IF YOU GIVE NOTICE OF THE POSSIBILITY OF SUCH
DAMAGE.
1.F.3. LIMITED RIGHT OF REPLACEMENT OR REFUND - If you discover a
defect in this electronic work within 90 days of receiving it, you can
receive a refund of the money (if any) you paid for it by sending a
written explanation to the person you received the work from. If you
received the work on a physical medium, you must return the medium with
your written explanation. The person or entity that provided you with
the defective work may elect to provide a replacement copy in lieu of a
refund. If you received the work electronically, the person or entity
providing it to you may choose to give you a second opportunity to
receive the work electronically in lieu of a refund. If the second copy
is also defective, you may demand a refund in writing without further
opportunities to fix the problem.
1.F.4. Except for the limited right of replacement or refund set forth
in paragraph 1.F.3, this work is provided to you ''AS-IS'' WITH NO OTHER
WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
WARRANTIES OF MERCHANTIBILITY OR FITNESS FOR ANY PURPOSE.
1.F.5. Some states do not allow disclaimers of certain implied
warranties or the exclusion or limitation of certain types of damages.
If any disclaimer or limitation set forth in this agreement violates the
law of the state applicable to this agreement, the agreement shall be
interpreted to make the maximum disclaimer or limitation permitted by
the applicable state law. The invalidity or unenforceability of any
provision of this agreement shall not void the remaining provisions.
1.F.6. INDEMNITY - You agree to indemnify and hold the Foundation, the
trademark owner, any agent or employee of the Foundation, anyone
providing copies of Project Gutenberg-tm electronic works in accordance
with this agreement, and any volunteers associated with the production,
promotion and distribution of Project Gutenberg-tm electronic works,
harmless from all liability, costs and expenses, including legal fees,
that arise directly or indirectly from any of the following which you do
or cause to occur: (a) distribution of this or any Project Gutenberg-tm
work, (b) alteration, modification, or additions or deletions to any
Project Gutenberg-tm work, and (c) any Defect you cause.
Section 2. Information about the Mission of Project Gutenberg-tm
Project Gutenberg-tm is synonymous with the free distribution of
electronic works in formats readable by the widest variety of computers
including obsolete, old, middle-aged and new computers. It exists
because of the efforts of hundreds of volunteers and donations from
people in all walks of life.
Volunteers and financial support to provide volunteers with the
assistance they need, is critical to reaching Project Gutenberg-tm''s
goals and ensuring that the Project Gutenberg-tm collection will
remain freely available for generations to come. In 2001, the Project
Gutenberg Literary Archive Foundation was created to provide a secure
and permanent future for Project Gutenberg-tm and future generations.
To learn more about the Project Gutenberg Literary Archive Foundation
and how your efforts and donations can help, see Sections 3 and 4
and the Foundation web page at http://www.pglaf.org.
Section 3. Information about the Project Gutenberg Literary Archive
Foundation
The Project Gutenberg Literary Archive Foundation is a non profit
501(c)(3) educational corporation organized under the laws of the
state of Mississippi and granted tax exempt status by the Internal
Revenue Service. The Foundation''s EIN or federal tax identification
number is 64-6221541. Its 501(c)(3) letter is posted at
http://pglaf.org/fundraising. Contributions to the Project Gutenberg
Literary Archive Foundation are tax deductible to the full extent
permitted by U.S. federal laws and your state''s laws.
The Foundation''s principal office is located at 4557 Melan Dr. S.
Fairbanks, AK, 99712., but its volunteers and employees are scattered
throughout numerous locations. Its business office is located at
809 North 1500 West, Salt Lake City, UT 84116, (801) 596-1887, email
business@pglaf.org. Email contact links and up to date contact
information can be found at the Foundation''s web site and official
page at http://pglaf.org
For additional contact information:
Dr. Gregory B. Newby
Chief Executive and Director
gbnewby@pglaf.org
Section 4. Information about Donations to the Project Gutenberg
Literary Archive Foundation
Project Gutenberg-tm depends upon and cannot survive without wide
spread public support and donations to carry out its mission of
increasing the number of public domain and licensed works that can be
freely distributed in machine readable form accessible by the widest
array of equipment including outdated equipment. Many small donations
($1 to $5,000) are particularly important to maintaining tax exempt
status with the IRS.
The Foundation is committed to complying with the laws regulating
charities and charitable donations in all 50 states of the United
States. Compliance requirements are not uniform and it takes a
considerable effort, much paperwork and many fees to meet and keep up
with these requirements. We do not solicit donations in locations
where we have not received written confirmation of compliance. To
SEND DONATIONS or determine the status of compliance for any
particular state visit http://pglaf.org
While we cannot and do not solicit contributions from states where we
have not met the solicitation requirements, we know of no prohibition
against accepting unsolicited donations from donors in such states who
approach us with offers to donate.
International donations are gratefully accepted, but we cannot make
any statements concerning tax treatment of donations received from
outside the United States. U.S. laws alone swamp our small staff.
Please check the Project Gutenberg Web pages for current donation
methods and addresses. Donations are accepted in a number of other
ways including including checks, online payments and credit card
donations. To donate, please visit: http://pglaf.org/donate
Section 5. General Information About Project Gutenberg-tm electronic
works.
Professor Michael S. Hart is the originator of the Project Gutenberg-tm
concept of a library of electronic works that could be freely shared
with anyone. For thirty years, he produced and distributed Project
Gutenberg-tm eBooks with only a loose network of volunteer support.
Project Gutenberg-tm eBooks are often created from several printed
editions, all of which are confirmed as Public Domain in the U.S.
unless a copyright notice is included. Thus, we do not necessarily
keep eBooks in compliance with any particular paper edition.
Most people start at our Web site which has the main PG search facility:
http://www.gutenberg.net
This Web site includes information about Project Gutenberg-tm,
including how to make donations to the Project Gutenberg Literary
Archive Foundation, how to help produce our new eBooks, and how to
subscribe to our email newsletter to hear about new eBooks.','37744b2791d7b2f8dc88e2a092eab141a1995ecada791b3d536229e8975783d0','internet-archive','theciaworldfactb00180gut','txt','b76993377cfa6bdd51979833301976cfc440911ee1fe0b90c117008758860b3f','https://archive.org/download/theciaworldfactb00180gut/180.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

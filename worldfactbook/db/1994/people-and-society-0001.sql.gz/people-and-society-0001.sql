SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4dfa4c8a6659de2d65c1dadb9c062a3a26e2ce2f15030534c466dc22510c0b86',1994,'PK','Pakistan','people-and-society',9,'Population: l6.90.5,4(M)(July 1994 est.)
Population growth rate: 2.4.5^ (1994 est.)
Birth rate: 4,5.46 births/1.000 population
(1994 est.)
Death rate: 1 8.9-1 death.s/ 1 ,(X)0 population
(1994 est.)
Net migration rate: 0 migranUs)/ 1 .()(K)
population ( 1 994 est. )
Infant mortality rate: 1 55.8 deaths/ 1 ,(X)0
live births (1994 cst.)
Life expectancy at birth:
total poindation: 44.89 years
male: 45.5.5 years
female: 44.21 years ( 1994 est.)
Total fertility rate: 6.27 children
brrm/woman ( 1994 cst.)
Nationality:
noun: Afghun(s)
adjective: Afghan
Ethnic divisions: Pashtun .58*4, Tajik 25''4.
Uzbek 6</r, Hazara 19*4. minor ethnic gnmps
(Chahar Aimaks, Turkmen, BakK''h. and
others)
Religions: Sunni Muslim 84*4. Shi''u Muslim
15‘4. other t9i
Languages: Pashtu .55''4. Afghan Persitin
(Dari) 50*4, Turkic languages (primarily
Uzbek andTurkuKn) 1 1 50 minor languages
(primarily BaliKhi and Pashui)4''''''(, much
bilingualism
Literacy: age 1 5 and over can read and write
(1990cit,)
total population: 29*4
male: 4455
female: I4*7r
Labor force: 4.98 million
hr occu/Httion: agriculture and animal
husbandry 67.8*4. industry 10.2*4.
construction 6.5*4. commerce 5.0*4. services
and other 10.7*4 (1980 cst.)
Population: 3,374,085 (July 1994 est.)
note; IMF, working with Albanian government
figures estimates the population at 3, 1 20,000 in
1993 and that the population has fallen since
1990
Population growth rate: 1.19% (1994 est.)
Birth rate: 22.46 births/I ,000 population
(1994 est.)
Death rate: 5.32 deaths/ 1 ,000 population
(1994 est.)
Net migration rale: -5.27 migrant(s)/l,000
population (1994 est.)
Infant mortality rate; 30 deaths/ 1, 000 live
births (1994 e.st.)
Life expectancy at birth:
total population; 73.4 years
male: 70.42 years
female: 76.61 years (1994 est.)
Total fertility rate: 2.78 children
bom/woman ( 1994 est.)
Nationality:
noun: Albanian(s)
adjective: Albanian
Ethnic divisions: Albanian 95%. Greeks 3%,
other 2% (Vlachs, Gypsies, Serbs, and
Bulgarians) (1989 est.)
Religions: Muslim 70%, Greek Orthodox
20%, Roman Catholic 10%
note; all mosques and churches were closed in
1967 and religious observances prohibited: in
November 1990, Albania began allowing
private religious practice
Languages: Albanian (Tosk is the official
dialect), Greek
Literacy: age 9 and over can read and write
(1955)
total population; 72%
male: 80%
female: 63%
Labor force: 1 .5 million ( 1 987)
by occupation: agriculture 60%, industry and
commerce 40% ( 1 986)','074f2b3571358401abbded2bbf1ae310b36804c81e31d63655aaf5438c841f06','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab795c483a6754256c0eae5182cb3fe52b35ded2f7c12bdd7c5cb0714a762eb7',1994,'TN','Tunisia','people-and-society',17,'Papulation: 27,895,068 (July 1994 est.)
Population growth rate: 2.29% (1994 est.)
Birth rate: 29.71 births/1,000 population
(1994 est.)
Death rate: 6.22 death.s/1,000 population
(1994 est.)
Net migration rate: -0.58 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 52. 1 deaths/ 1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 67.68 years
male: 66.63 years
female: 68.77 years (i994 est.)
Total fertility rate: 3.83 children
bom/woman (1994 est.)
Nationality:
noun: Algerian(s)
adjective: Algerian
Ethnic divisions: Arab-Berber 99%.
European less than 1%
Reli^ons: Sunni Muslim (state religion)
99%, Christian and Jewish 1%
Languages: Arabic (official), French, Berber
dialects
Literacy; age IS and over can read and write
(1990 est.)
total population: 57%
male: 70%
female: 46%
Labor force: 6.2 million (1992 est.)
by occupation: government 29.5%, agriculture
22%, construction and public works 16.2%.
industry 13.6%, commerce and services
13,5%. transportation and communication
5.2% (1989)','24447c317eb702a6978d6d4d3cc330ffb0079f1280d4a1b344c4a881bbb580ed','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95fb37b02aa85a06d7e7806fcc37dd185044c4771d7f1286b00c757074f1a377',1994,'NZ','New Zealand','people-and-society',25,'Population: 55.223 (July 1994 est.)
Population growth rate: 3.86% (1994 est.)
Birth rate: 36.63 births/l.flOO population
(1994 est.)
Death rate; 4.01 deaths/1,000 population
(1994 est.)
Net migration rate: 6 migrant! s)/ 1, 000
population ( 1994 est.)
Infant mortality rate: 1 8. 78 deaths/ 1 .000
live births (1994 est.)
Life expectancy at birth:
total population: 72.91 years
male: 7 1 .03 years
female; 74.85 years ( 1994 est.)
Total fertility rate: 4..36 children
bom/woman (1994 est.)
Nationality:
noun: American Samoan(s)
adjective: American Samoan
Ethnic divisions: Samoan (Polynesian) 89%,
Caucasian 2%, Tongan 4%. other 5%
Religions: Christian Congregationalist 50%.
Roman Catholic 20%, Protestant
denominations and other 30%
Languages: Samoan (closely related to
Hawaiian and other Polynesian languages).
English; most people are bilingual
Literacy: age 15 and over can read and write
(1980)
total population; 97%
male; 97%
female: 97%
Labor force: 14.400(1990)
by occupation; government 33%. tuna
canneries .34%, other 33% (1990)
Population: 3,388,737 (July 1994 est.)
Population growth rate: 0.57% (1994 est.)
Birth rate: 15.52 births/I ,000 population
(1994 est.)
Death rate: 8.06 deaths/I .000 population
(1994 est.)
Net migration rate: - 1 .78 migrant(s)/ 1 .000
population ( 1994 est.)
Infant mortality rate: 8.9 deaths/ 1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 76.38 years
male: 72.76 years
female: 80. 1 8 years ( 1994 est.)
Total fertility rate: 2.03 children bom/
woman (1994 est.)
Nationality:
noun: New Zealander) s)
adjective: New Zealand
Ethnic divtaions: European 88%. Maori
8.9%, Pacific islander 2.9%. other 0.2%
ReUgioM: Anglican 24%, Presbyterian 18%.
Roman Catholic 15%. Methodist 5%, Baptist
2%. other Prote.stant 3%, unspecified or none
9% (1986)
Languages: English (official), Maori
Literacy: age 15 and over can read and write
(1 980 est.)
total populatimi: 99%
male: NA%
female: NA%
Labor Ihrce: l.60.3,.500 (June 1991)
by occupation: services 67.4%, manufacturing
19.8%. primary production 9.3% ( 1987)
Population: I..323 (July 1994 est.)
Population growth rate: -1.3394 (1994 est.)
Nationality:
noun; Tokelauan(s)
adjective; Tokelauan
Ethnic divisions: Polynesian
Religions: Congregational Christian Church
7094. Roman Catholic 2894, other 294
note; on Atafu, all Congregational Christian
394
Tongi
Church of Samou; on Nukunonu, all Roman
Catholic; on Fakaofo, both denominations,
with the Congregational Christian Church
predominant
Laa|Mt**t Tokelauan (a Polynesian
language), English
LUeracy:
total pofmhrton: NA%
male; NA%
female: NA%
LabortMTcc: NA
Population: 104,778 (July 1994 est.)
Population growth rate: 0.79% ( 1994 est.)
395
Tonga hnnliniu’d)
Birth nlr: 24.7(i birihs/l.lNM) poptiluiiim
k jlh rale: f).75 ileiith\\/I.O(M) population
(IWoM.I
Nrl migratloii rale: H). 14 migrunt(N)/l.lMX)
population t IW esi.i
Infant moHallly rale: 2(1. 7<) Ooiiihs/ 1 .(MX)
live binhst 19*44 esi.)
i.m expectancy at hirth;
lohil ^7.97 years
nitilc: f)5.(v4 years
itnuiU'': 70.4.^ years 1 19*14 esi.)
Tntal fertility rate: .V(>2 ehilUren bom/
woman ( 1994 est.)
Nationality:
noiw: Tongaiusi
Ton^an
Kthnic divisions: Polynesian. Huropeuns
about .MX)
Kellglons: Christian ti ree Wesleyan Chureh
claims over .Ml.tXX) adherents''
Languages: Ton^an, Hnglish
Literacy: tige I .s and over can mad and vs rite
simple message in Tongan or Lngli.sh ( I97())
rutii/
mule: bO''i
frmtih'': bO''v
laibor force: NA
hy mriiiHiiiim: agriculture 7()</i , mining ((i(X)
engaged in mining)
(tovernment
Names:
(vnvfiiiiomil Iona form: Kingdom ol Tonga
amyentiomil xlum form: Tonga
loivuT Friendiv Islands
Digraph: TN ''
Type: hereditary constitutional monarchy
Capital; Nuku''alot''a
Administrative divisions; three island
groups; Ha''apai. Tongatapu. Vava''u
Independence: 4 June I970)livmi I''K)
National holiday: Bmuncipation Dav. 4 June
(1970)
Constitution: 4 November I X7.S. revised I
January I9(>7
I.egai system: based on English lavs
.Suffrage: all literate, tax-paying males and all
literate females over 21
Executive branch:
chief of sMte: King Taufa''ahau TliPOl) IV
(since 16 December 196.^)
head of aoverniiieiii: Prime Minister Baron
VAEA (.since 22 August 1991 1: IX''puty Prime
Minister .S. Langi KAVALIKD (since 22
August I *491)
cohiiiei: Cabinet; appointed by the king
Privy Council: consists of the king and the
cabinet
Legislative branch: unicameral
h''aislotive Assemhiy (Pule Aleot: elections
last held 14-1.5 February 1*490 (next to be held
NA February 1*493); results — percent of vote
NA; seats— (29 total. 9 elected) 6 proreform,
3 traditionalist
Judicial brunch: Supreme Coun
Polillcal parties and ieuders: DemiK-raiic
Reform Movement. ‘.Akilisi POFIIVA;
Christian Dcnnvrutic Panv. leader NA
Member of: ACP. AsDb''. C. ESC''AP. F AO.
(i 77. IBRD. ICAO. ICFTli. IDA. IFAD, IFC.
IMF''. INTELSAT tnonsignatorv user).
INTERPOl IOC, ITU. I.ORCS. SPARTECA.
SPC, SPF. UNCTAD, UNEStXJ. UNIDO.
UPU. WHO
Diphunatk representation In US;
.Ambassador .Sione KITE, msides in London
coHxHloteist aeiierul: San Francisco
U.S diptomatlc represenlatton; the US has
no offices in 1''onga; the ambu.ssador to Fiji is
accredited to Tonga and makes peritxlic visits
Hug: md with a bold red entss on a white
rectangle in the upper hoist-side comer
KcoiMuny
tJvervlew: Theecon«tmy''sbuseis.igriculture.
w hich employs about 70''* of the labor force
and contributes 41)''* to CiDP. CiKonuts.
bananas, and vanilla beans am the main entps
and make up two-thirds of exprvrts. The
country must i>np«»n a high proportion of its
fcKxl. mainly fmm New /ealand. The
manulticturing sector accrrunts for only 1 1 of
GDP. Tourism is the primary source of hard
currency earnings, hut the island remains
dependent on sizable external aid and
remittances to offset its trade deficit. The
economy continued to grow in 1993 largely
because of a rise in squash exports, incmased
aid flow s, and several large ctmstruction
projects. The government is now turning its
attention to further dcvelopnH''nt of the private
sector and the redtK’tion of the budget deficit.
National pimluct: GDP— purchasing power
equivalent -S2(X) million ( 1*493 est.)
National product real growth rale: 4''*
(1*493 est.)
National product per capita; $2.(XX) ( 1 9*43
est )
Inflation rate (consumer prices): 9''*
(FY92)
Unemployment rale; NA'' *
Budget;
rr’vcmic.v. $.36.4 million
exiH''iuliiurex: $68. 1 million, including capital
expenditures of $.33.2 million ( I99| est.)
Exports; $18.8 million (f.o.b.. FY''42 est.)
comnuHliiies: vanilla, fish, root crops, ciK''onut
oil, squash
purtnerv: Japan , 34''*-. US 17''/;. .Australia 13''*,
NZ 1.3** (FY91)
imports; $68.3 million (c.i.f.. FY92 est.)
comiiiiuliiirx: fixtd prtxiucts, machinery and
transport equipment, manufactures, fuels,
chemicals
IHiriiiers: NZ 33** . Australia 22''.*, US 8''* .
Japan 8''.* (FY9I)
External debt: $47..s million (FY''91 )
Industrial production: gmwth rate I
|FY92); accounts for 1 1''* of GDP
EIcctrldly:
capiH''ity: 6.(XX) kW
imulutiion: 8 million kWh
consumplitm percupiM: 80 kWh ( 1990)
litdttsltrin: tourism, fishing
Agriculture: accmints for 40** of GDP;
dominated by ciKonut, copra, and banana
productioti: vanilla K''ans. cwira. coffee,
ginger, black pepper
Economic aid:
recipient: US commitments, including Ex-lm
(FY70-89), $16 millhvn; Western (ihw-US)
countries. ODA and OOF bilateral
commitnamts ( 1970-89). $2.58 million
Currency: I pa''anga (T$) = 100 seniti
Exchange rates: pa''anga (T$) per US$1 —
L. 39.34 (November 1993). 1.3471 (1992),
1.2961 (1991). 1.2809(1990). 1.2637(1989),
Fiscal year; I July-.30Junc
Crrmmunlcatlons
Highways:
lonil: ,3M> km
IHivcd: 272 knt (198 km on Tongatapu: 74 km
on Vava''u)
tm/Hived: 94 knt (usable only in dry weather)
Port.s: Nuku''alot''a. Neiafu. Pangai
Merchant mariite; 3 ships t L(XK) GRT or
over) tittaling 6,761 GRT/I().597 DWT. cargo
1. roll-on/n>ll-olf cargo 1. liquefied gas I
Airports:
loiol: 6
iisiihle: 6
w ith iH’nmmem-xiirfdce runwoyx: I
with rmiwtiyx over .3.6,39 m: 0
w ith runwiiyx 2.-J4(4-.(,6,39»m.'' I
w ith runw oyx /, 22(4-2. 9.39 »i.'' 1
Telecommunicallons: .3..$29 telephones;
66.tXX) radios: no TV sets; broadcast stations —
I AM, no FM. no TV; I Pacific Ocean
INTEL.SAT earth station
Defense Forces
Branches; Tonga Defense Services, Maritinte
Divisitm. Royal Tongan Marines, Tongan
Royal Guards. Pitliec
Defense expenditures; exchange rate
conversion — $NA, NA‘* t)f GDP
396
Population: 204.447 (July 1994 est.)
Population growth rate: 2.38% (1994 est.)
Birthrate: 32.41 birth.s/ 1, 000 population
(1994 est.)
Death rate: 6.02 deaths/ 1 .0(8) piupulution
( 1994 est.)
4.33
Western Samoa (continued)
Net migration rate; -2.63 migrant(s)/ 1,000
population (1994 est.)
Infant mortality rate: 37 deaths/1,000 live
births (1994 est.)
Life expectancy at birth:
total population: 67.97 years
male; 65.59 years
female: 70.48 years (1994 est.)
Total fertility rate: 4. 16 children bom/
woman (1994 est.)
Nationality:
noun: Western Samoan(s)
adjective; Western Samoan
Ethnic divisions: Samoan 92.6%,
Euronesians 7% (persons of European and
Polynesian blood), Europeans 0.4%
Religions; Christian 99.7% (about half of
population associated with the London
Missionary Society; includes Congregational,
Roman Catholic, Methodist, Latter Day Saints,
Seventh-Day Adventist)
Languages: Samoan (Polynesian), English
Literacy: age 15 and over can read and write
(1971)
total population: 97%
male: 97%
female: 97%
Labor force: 38,000
by occupation; agriculture 22,000 (1987 est.)
Population: 3,643,289,771 (July 1994 est.)
Population growth rate: 1 .5% ( 1 994 est.)
Birth rate; 25 births) 1 .000 population ( 1 994
est.)
Death rate: 9 deaths/1.000 population (1994
est.)
Infant mortality rate: 63 deaths/) .0(X) live
binhs ( 1 994 est.)
Life expectancy at birth:
total population: 62 years
male: 61 years
female: 64 years (1994 est.)
Total fertility rate: 3. 1 children bom/wuman
(1994 est.)
Literacy: age 13 and over can read and write
(1 990 est.);
total population; 82%
male; 68%
female: 75%
Labor force: 2.24 billion (1992)
by occupation: NA','7fa383bb5e497e4882c38668edeaccb0d2f2f6b3cbfb66c0ad948a6728402c75','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df3d0501975cc03839c5a2d9f8d91513d9c85dd41be609f694f2bc6cbac2ddf5',1994,'AD','Andorra','people-and-society',31,'Population: 63,930 (July 1994 est.)
Population growth rate; 2.99% (1994 est.)
Birth rate: 1 3.34 births/I .''WO population
(1994 est.)
Death rate: 7. 1 2 deaths/I ,000 population
(1994 est.)
Net migration rate: 23.65 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 7.9 deaths/ 1 ,000 live
births (1994e.sl.)
Life expectancy at birth:
total population: 78.37 years
male: 75.5 years
female: 81.5 years ( 1 994 est.)
Total fertility rate: 1.73 children
bom/woman ( 1 994 est. )
Nationality:
noun: Andorran(s)
adjective: Andorran
Ethnic divisions: Spanish 61%, Andorran
30%, French 6%, other 3%
Religions; Roman Catholic (predominant)
Languages: Catalan (official ). French.
Castilian
Literacy:
total population; NA%
male: NA%
female: NA%
Labor force: NA','0742dea46c64761c29247e216ea24e6da6df2126d1bde9248d0e285f1401d9b9','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d04f9b5d6e247923032b76f010bdd8c985e541182aec6a1f869e3e00f41920d',1994,'AO','Angola','people-and-society',38,'Populalion: 9.803.576 iJuly I994esi.)
Popuiaiion growth rale: 2.675f < 1 994 est. )
Birth rale: 45.43 births/ 1. (XX) population
(1994 est.)
Death rate: 1 8.55 deuihs/l .(X)0 population
(1994 est.)
Net migration rate: -0. 1 5 migrani(s)/l .(XX)
populalion ( 1994 est.)
Infant mortality rate: 1 45.4 deaths/ 1 .(XX)
live births (1994 est.)
Life expectancy at birth:
total population; 45.77 years
male: 43.72 years
female: 47.92 years (1994 est.)
Total fertility rate: 6.48 children
bom/woman (1994 est.)
Nationality:
noun: Angolan) s)
adjective: Angolan
Ethnic divisions: Ovimbundu 37<>,
Kimbundu 25<''/f'', Bakongo I3?f. mc.stico
(mixed European and Native African)
European I other 225f
Reli^ons: indigenous beliefs 479f. Roman
Catholic 38?f. Protestant I59f (est.)
Languages: Portuguese (official), Bantu and
other African languages
Literacy: age 1 5 and over can read and write
(1990 est.)
total population; 42%
male: 56rf
female; 28%
Labor force: 2.783 million economically
active
hv occupation; agriculture 85%. industry 1 5%
(1985 est.)','fb0eff89aecbb5145344f7cce65a1aee18eb17eb94b7833f4bdb26ec02c3bb8a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d2dff781f05f5e99e6f18e2088044aa06ddeba3a60a14598b286696cb3e8777',1994,'AQ','Antarctica','people-and-society',48,'Population: no indigenous inhabitants;
note — there are seasonally staffed research
stations
Summer (January) population: over 4, 1 15
total: Argentina 207. Australia 268, Belgium
13. Brazil 80, Chile 256, China NA, Ecuador
NA, Finland 1 1 . France 78. Gennany 32.
Greenpeace 12. India 60. Italy 210, Japan 59.
South Korea 14, Netherlands 10, NZ 264,
Norway 23, Peru .39, Poland NA. South Africa
79, Spain 43, Sweden 10. UK 1 16, Uruguay
NA, US 1,666. former USSR 565 (1989-90)
Winter (July) {Hipulation: over 1 .046 total;
Argentina 1.50. Australia 71. Braz.il 12, Chile
73. China NA. France 3,3, Germany 19,
Greenpeace 5, India I, Japan 38, South Korea
14. NZ 1 1. Poland NA. South Africa 1 2. UK
69. Uruguay N A, US 225. former USSR .3 1 .3
(1989-90)
year-round stations: 42 total; Argentina 6.
Australia 3. Brazil I , Chile 3, China 2, Finland
I . France I . Germany I . India I . Japan 2. South
Korea l.NZ I. Poland l.South Africa.3. UK5.
Uruguay I . US .3, former USSR 6 ( 1 990-9 1 )
Summer only slatums: over 38 total: Argentina
7. Australia .3. Chile 5, Germany 3. India 1 .
Italy I . Japan 4, NZ 2, Norway I , Peru I , South
Africa I. Spain 1, Sweden 2. UK I, US
numerous, former USSR 5 ( 1989-90): note —
the disintegration of the former USSR has
placed the status and future of its Antarctic
facilities in doubt; stations may be subject to
closings at any time because of ongoing
economic difficulties
Papulation: 33,912.994 (July 1994 est.)
Population growth rate: 1 . 1 2% ( 1 994 est.)
Birth rate: 19.62 binhs/l.(X)0 population
(1 994 est.)
Death rate: 8.63 deaths/I, 000 population
(1994 est.)
Net migration rate: 0.21 migrant(s)/1.000
population ( 1994 est.)
Infant mortality rate: 29.4 deaths/ 1, 000 live
births (1994 est.)
Life expectancy at birth:
total population: 71.35 years
male; 68.06 years
female; 74.81 years (1994 est.)
Total fertility rate: 2.68 children
born/ woman (1994 est.)
Nationality:
noun: Argenline(s)
adjective: Argentine
Ethnic divisions: white 85%. mestizo.
Indian, or other nonwhite groups 1 5%
Religions: nominally Roman Catholic 90%
(less than 20% practicing), Protestant 2%.
Jewish 2%. other 6%
Languages: Spanish (official). English,
Italian. German. French
Literacy; age 15 and over can read and write
(1990 e.st.)
total population: 95%
male: 96%
female: 95%
Labor force: 1 0.9 million
by occupation: agriculture 1 2%. industry 3 1 %,
services 57% (1985 e.st.)','830ea6fef93e2c9667b26ec8359a57cbd48184380c7c6ddac17d7faa4fb50822','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8812381c329150f04b3892dfc2f4fffbae6550fb08d3c61f9aeb16f6bf9af2ea',1994,'AG','Antigua and Barbuda','people-and-society',54,'Population: 64.762 (July 1994 esi.)
14
Population growth rate: 0.949^ ( l<)*M esi.)
Birth rate: 1 7.3 1 birihs/l .000 population
(1994 esi.)
Death rate; .3.44 denths/l .(XX) population
(l994ost.)
Net migration rate: -.3.9.^ migrant(.s)/l,0(X)
population ( 1994 est.)
Inflint mortality rate; 1 8.5 deaths/ 1 .(XX) live
births (1994 est.)
Life expectancy at birth;
total ixipiikition: 73. 1 1 years
male.- 71.07 years
female: 75,26 years (1994 est.)
Total fertility rate: 1 .67 children
bom/woman (1994 est.)
Nationality;
noun: Anliguan(s). Barbudan(s)
adjectiee: Antiguan. Barbudan
Ethnic divisions; black African. British.
Portuguese. Lebanese. Syrian
Religions: Anglican (predominant), other
Prtxestant sects, some Roman Catholic
Languages: English (official). liKal dialects
Literacy: age 15 and over having completed 5
or more years of schooling ( 1960)
total population: 899f
male: 9()9(-
889f
Labor force: 30.(XX)
by mru/hition: commerce and services 82‘X'',
agriculture 1 19}-. industry 79f (1983)','584c00e110471c39ef6422384d3cd9762321546ffecab309dccf3edbc449a720','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ef923f1cd270df29aaea3559fa3592d8160799209680a73a73f521f997d57fa',1994,'AM','Armenia','people-and-society',63,'Populatiois: 3.521,517 (July 1994 est.)
Population growth rate: 1 .08% ( 1 994 est.)
Birthrate: 24.21 births/ 1, 000 population
(1994 est.)
Death rate: 6.72 dealhs/l,(X)0 population
(1994 est.)
Net migration rate: -6.72 migrant(s)/l ,000
population ( 1 994 est.)
Infant mortality rate: 27. 1 deaths/ 1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 72.07 years
male: 68.65 years
female: 15.65 years (1994 est.)
Total fertility rate: 3. 19 children
bom/woman (1994 est.)
Nationality:
noun: Armenian(s)
adjective: Armenian
Ethnic divisions: Armenian 93%, Azeri 3%,
Russian 2%, other 2%
Religions: Armenian Orthodox 94%
Languages: Armenian 96%, Rassian 2%,
other 2%
Literacy: age 9-49 can read and write ( 1 970)
total population: 100%
male: 100%
female: 100%
Labor force: 1 .578 million
by occupation: industry and construction 34%,
agriculture and forestry 31%. other 35% ( 1992)','313b86f107fbffc111fe58ca154ce25e900f6b9d77582f34b9f98d27721b2445','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b90370bf90f82fe2464aa6aa033bf06a57944d3f7ee219fd35d40dc021dae2e0',1994,'AW','Aruba','people-and-society',70,'Population: 65,545 (July 1994 est.)
Population growth rate: 0.65% ( 1 994 est.)
Birth rate: 14.95 births/I .000 population
(1994 est.)
Death rate: 6. 1 2 deaths/I ,000 population
(1994 est.)
Net migration rate: -2.3 migrant(s)/l,(X)0
population (1994 est.)
Infant mortality rate: 8.4 death.s/l ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 76.43 years
male: 72.77 years
female: 80.27 years (1994 est.)
Total fertility rate: 1 .82 children
bom/woman ( 1994 est.)
Nationality:
noun: Aruban(s)
adjective: Aruban
Ethnic divisions: mixed European/Caribbean
Indian 80%
Religions: Roman Catholic 82%, Protestant
8%, Hindu, Muslim, Confucian, Jewish
Languages: Dutch (official), Papiamento (a
Spanish, Portuguese, Dutch, English dialect),
English (widely spoken). Spanish
Literacy:
total population: NA%
male: NA%
female: NA%
Labor force: NA
by occupation: most employment is in the
tourist industry (1986)','4c63c211efae179baee445b10f770642b50a73730437c77d88b5ecf28f26c40f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b2bf1d5ebe903ce3ea39b5d5bef000532a13c3045d3c7275550a078059a8b92',1994,'AU','Australia','people-and-society',79,'Population: no indigenous inhabitants;
note — there are only seasonal caretakers
Atlantic Ocean
Population: 18.077.419 (July 1994 est.)
Population growth rate: 1 .38% ( 1 994 est.)
Birth rate: 1 4.29 births/ 1 ,000 population
(1994 est.)
Death rate: 7.38 deaths/I, (HX) population
(1994 est.)
Net migration rate: 6.91 migrarit(s)/ 1,000
population (1994 est.)
Infant mortality rate: 7.3 deaths/ 1 ,0(X) live
births (1994 est.)
Life expectancy at birth:
total population: 77.57 years
male; 74.45 years
female: 80.84 years ( 1994 est.)
Total fertility rate: 1.83 children
born/woman ( 1994 est.)
Nationality;
noun: Australian(s)
adjective: Australian
Ethnic divisions: Caucasian 95%, Asian 4%.
aboriginal and other 1%
Religions; Anglican 26. 1%. Roman Catholic
26%, other Christian 24.3%
Languages: English, native languages
Literacy: age 1 5 and over can read and write
(1980 est.)
total population: 100%
male: 100%
female: 100%
Labor force: 8.63 million (September 1991 )
by occupation: finance and services 33.8%.
public and community services 22.3%,
wholesale and retail trade 20.1%.
manufacturing and industry 16.2%. agriculture
6.1% (1987)
Population; no indigenous inhabitants:
note — there are 3 meteorologists
95
Population; 821 (July 1994 esi.)
Population growth rate: 1.15% (1994 esi.)
Birth rate; NA
Death rate: NA
Net migration rate: NA
Infant mortality rate: NA
Life expectancy at birth; NA
Total fertility rate: NA
Nationality:
noun: none
adjective: none
Ethnic divisions: Italians, Swiss
Religions: Roman Catholic
Languages: Italian, Latin, various other
languages
Literacy:
total population: NA%
male: NA%
female: NA%
Labor force: NA
by occupation: dignitaries, priests, nuns,
guards, and 3,000 lay workers who live outside
the Vatican','1549007dae829c02a648b64d74ad978c9c400282bf9a8bb644eda11a5b2ab160','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af82d077b54f7ef31641a4862636b70ce34651fccf8a5ac0f5d4fc7be617c446',1994,'AT','Austria','people-and-society',84,'Population: 7,%4,974 (July 1994 est.)
Population growth rate: ().4.‘i9f ( 1994 est.)
Birth rate: 1 1 ..^8 births/I .000 population
( 1994 est.)
Death rate: I0..^4 deaths/1,000 population
(1994 est.)
Net migration rate: .^.46 migr:int(s)/l.000
population ( 1994 est.)
Infant mortality rate: 7.1 deaths/1.0(X)live
births (1994 est.)
Life expectancy at birth:
total 00/1 ilation: 76.65 years
niuie: 7,). 44 years
feinaie: 80.03 years ( 1994 est.)
1 otal fertility rate: 1 .48 children
bom/woman (1994 est.)
Nationality:
noun: Austrian(s)
adjective: Austrian
Ethnic divisions: Gemtan 99,4<‘/f . Croatian
0.3'':?-. Slovene 0,29!-. other 0, 1 If
Religions: Roman Catholic SS''T. Protestant
bCf-, other 9<;«-
Languages; German
Literacy: age 15 and over can read and write
(1974 est.)
total po/ndation: 997c
male: NAIf
female: NA9i-
Labor force: .3.47 million (1989)
hy occupation: services 56.4''lf. industry and
crafts 3.‘).49f, agriculture and forestry 8.1%
note: an estimated 200.000 Austrians are
employed in other European countries; foreign
laborers in Austria number 177.840, about 6%
of labor force ( 1988)','91c89f5139c4cdd274165897464b5ef830d3a316ea3a3fbb261210a193f2007f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f09b72259f3195bc4337fc6f272dba4e456a1cb1281fd570899a5cf23ffa665',1994,'AZ','Azerbaijan','people-and-society',90,'Population: 7,684,456 (July 1994 est.)
Population growth rate: 1.41% (1994 est.)
Birthrate: 23.04 births/ 1, (X)0 population
(1994 est.)
Death rate: 6.58 deaths/ 1,000 population
(1994 est.)
Net migration rate: -2.38 migrant(s)/ 1.000
population (1994 est.)
Infant mortality rate: 34.8 deaths/ 1 ,000 live
births ( 1994 est.)
Life expectancy at birth:
total population; 70.85 years
male; 67.08 years
female; 74.8 years ( 1994 est.)
Total fertility rate; 2.7 children bom/woman
(I994e.st.)
Nationality:
noun; Azerbaijani(s)
adjective; Azerbaijani
Ethnic divisions; Azeri 82.7%, Russian
5.6%, Armenian 5.6%, Dagestani 3.2%, other
2.9% (1989)
note; Armenian share is now approximately
0.3% because most Armenians have fled the
ethnic violence since 1989 census; Russian
percentage is probably half what it was for the
same reason
Reiigions; Muslim 87%, Russian Orthodox
5.6%, Armenian Orthodox 5.6%, other 1 .8%
Languages: Azeri 82%, Russian 7%,
Armenian 5%, other 6%
Literacy: age 9-49 can read and write (1970)
total fjopulution: 100%
male; 100%
female; 100%
Labor force: 2.789 million
by occupation; agriculture and forestry 32%.
industry and construction 26%, other 42%
(1990)
Population: 273,055 (July 1994 esi.)
Population growth rate: 1 .57% ( 1 994 est.)
Birthrate; 18.86 births/1,000 population
(1994 est.)
Death rate: 5.38 deaths/1,000 population
(1994 est.)
Net migration rate: 2.24 migrant( 1 .000
population (1994 est.)
Infant mortality rate: 33.5 deaths/1,000 live
births (1994 est.)
Life expectancy at birth:
total population: 7 1 .52 years
male: 67.66 years
female: 75.49 years (1994 est.)
Total fertility rate: 1.88 children
bom/woman (1994 est.)
Nationality:
noun: Bahamian(s)
adjective: Bahamian
Ethnic divisions: black 85%. white 15%
Religions: Baptist 32%, Anglican 20%,
Roman Catholic 19%, Methodist 6%, Church
of God 6%, other Protestant 12%, none or
unknown 3%, other 2%
Languages: English, Creole, among Haitian
immigrants
Literacy: age 15 and over but definition of
literacy not available (1963 est.)
total population: 90%
male: 90%
female: 89%
Labor force: I27,4(X)
by occupation: government 30%. hotels and
restaurants 25%, business services 10%,
agriculture 5% (1989)','daadefe33344b2520753bffb501a166efa5f2fac94cc2832161ea205390c9acd','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3916521597345ec97450818a6490be2f1a8798fd1222fa807564f560c2d7b199',1994,'BH','Bahrain','people-and-society',97,'Population: 585.683 (July 1994 est.)
Population growth rate: 2.96% (1994 est.)
Birth rate: 26.59 births/1,000 population
(1994 est.)
Death rate: 3.83 deaths/ 1 ,(X)0 population
(1994 est.)
Net migration rate: 6.83 migrant(s)/ 1,000
population (1994 est.)
Infant mortality rate: l9deaths/l,0(X) live
births (1994 est.)
Life expectancy at birth:
total population: 73.51 years
male: 71.1 years
female: 76.05 years (1994 est.)
Total fertility rale: 3.96 children
bom/woman (1994 est.)
Nationality:
noun: Bahraini(s)
adjective: Bahraini
Ethnic divisions: Bahraini 63%. Asian 1 3%,
other Arab 10%, Iranian 8%, other 6%
Religions; Shi''a Muslim 70%. Sunni Muslim
30%
Languages: Arabic, English, Farsi, Urdu
Literacy; age 15 and over can read and write
(1990 est.)
total population: 77%
male: 82%
female: 69%
Labor force: 140.000
by occupation: industry and commerce 85%.
agriculture 5%, services 5%, government 3%
(1982)
note: 42% of labor force is Bahraini
Population: uninhabited; note — American
civilians evacuated in 1942 after Japanese air
and naval attacks during World War II;
occupied by US military during World War II,
but abandoned after the war; public enuy is by
special-use permit only and generally restricted
to scientists and educators; a cemetery and
cemetery ruins are located near the middle of
the west coast','b672703686c679747fdbd8ed0821bdde6e32e21b33e2b84e1549979e7f0b93cd','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a03cd7d505d5f0792adf01a7e16faf7919b1e89e75d3deae85e672af161fff09',1994,'BD','Bangladesh','people-and-society',101,'Population: 125,149,469 (July 1994 est.)
Population growth rate: 2.33% (1994 est.)
Birth rate: 35.02 births/1,000 population
(1994 est.)
Death rate: 1 1 .68 deaths/i ,000 population
(1994 est.)
Net migration rate: 0 migrant(s)/l ,000
population ( 1994 est.)
Infant mortality rate: 1 06.9 deaths/ 1 ,000
live births (1994e.st.)
Life expectancy at birth:
total population: 55.08 years
male: 55.35 years
female: 54.8 years (1994 est.)
Total fertility rate: 4.47 children
bom/woman ( 1994 est.)
Nationality:
noun: Banglade.shi(s)
adjective: Bangladesh
Ethnic divisions: Bengali 98%, Biharis
250,000, tribals less than I million
Religions: Muslim 83%, Hindu 16%,
Buddhist, Christian, other
Languages: Bangla (official), English
Literacy: age 1 5 and over can read and write
(1990 est.)
total population: 35%
male: 47%
female: 22%
Labor force: .50. 1 million
hy occupation: agriculture 65%, services 21%,
industry and mining 14% (1989)
note: extensive export of labor to Saudi
Arabia, UAE, and Oman (1991)','b606a579393440285b8a42a7313d08d11b26a58e79c6394f8eba6b823e152980','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2aee9062895c3c5b38f08a9fce7422cdb5ec8810ecd5c1df22143d9161124dd9',1994,'BB','Barbados','people-and-society',107,'Population: 255.827 (July 1994 est.)
Population growth rate: 0.2 1 % ( 1 994 est.)
Birth rate: 1 5.63 births/l .000 population
(1994 est.)
Death rate: 8.4 deaths/ 1.000 population
(1994 est.)
Net migration rate: -5.l6migrjnt(s)/l.(X)0
population (1994 est.)
Infant mortality rate: 20.3 deaths/1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 73.83 years
male: 71.11 years
female; 76.76 years (1994 est.)
Total fertility rate: 1.78 children
bom/woman (1994 est.)
Nationality:
noun: Barbadian(s)
adjective: Barbadian
Ethnic divisions: African 8055-. mixed I6?f.
European 4%
Reli^ons: Protestant bl% (Anglican 40*^,
Pentecostal i,%, Methodist 1%. other 12%).
Roman Catholic 4%, none 17%. unknown .3%.
other 9% (1980)
Languages: English
Literacy: age IS and over having ever
attended school (1970)
total population: 99%
male: 99%
female: 99%
Labor force: 120,900(1991)
by occupation: services and government 37%,
commerce 22%. manufacturing and
construction 22%, transportation, storage,
communications, and financial institutions 9%,
agriculture 8%, utilities 2% ( 1985 est.)','6435bbf4a0070a122e3d4bf1138a4bfb6df38a65cf11d053dfa69f54a1e786c1','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d43eda2c6f062721c0b069d96d60446822a91733aaf4b75835b4508d133cd25',1994,'BY','Belarus','people-and-society',119,'Population: 10,404,862 (July 1994 est.)
Population growth rate: 0.32% (1994 est.)
Birthrate: 13.12 births/ 1, 000 population
(1994 est.)
Death rate: 1 1.16 deaths/ 1, 000 population
(1994 est.)
Net migration rate: 1 .27 migrant(s)/ 1 ,000
population ( 1 994 est.)
Infant mortality rate: 1 8.9 deaths/1 ,000 live
births ( 1994 est.)
Life expectancy at birth:
total population; 70.88 years
male; 66.2 years
female; 75.79 years (1994 est.)
Total fertility rate: 1 .88 children
bom/woman (1994 est.)
Nationality:
noun; Belarusian(s)
adjective; Belanisian
Ethnic divisions: Byelorussian 77.9%,
Russian 13.2%, Polish 4.1%, Ukrainian 2.9%,
other 1.9%
Religions: Eastern Orthodox, other
Languages; Byelorussian, Russian, other
Literacy: age 9-49 can read and write (1979)
total population; 100%
male; 100%
female; 100%
Labor force: 4.887 million
by occupation; industry and construction 40%.
agriculture and forestry 2 1 %, other 39% (1992)','aab133747671a9351a3efdfda465a0fc15f12efe1d97e6b0aaad047dbc871420','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('470df04b2d6fdb1346935d5178d62d9b2c240a3f1776a77180012f4116eef3ba',1994,'NL','Netherlands','people-and-society',121,'Population; 10,062.8.36 (July 1994 est.)
Population growth rate: 0.2% (1994 est.)
Birthrate: 11.71 births/ 1,000 population
(1994 est.)
Death rate: 1 0.26 deaths/ 1 ,000 population
(1994 est.)
Net migration rate: 0.6 migrant(.s)/l,000
population (1994 est.)
Infant mortality rate: 7.2 deaths/ 1, (X)0 live
births (1994 est.)
Life expectancy at birth:
total population: 76.96 years
male: 73.67 years
female: 80.44 years (1994 est.)
Total fertility rate: 1 .62 children
bom/woman (1994 est.)
Nationality:
noun: Bclgian(s)
adjective: Belgian
Ethnic divisions: Fleming 55%. Walloon
33%, mixed or other 12%
Religions: Roman Catholic 75%, Protestant
or other 25%
Languages; Dutch 56%, French 32%,
German 1%, legally bilingual 1 1% divided
along ethnic lines
Literacy: age 1 5 and over can read and write
(1980 est.)
total population: 99%
male: NA%
female: NA%
Labor force: 4. 1 26 million
h\\ occuimtion: services 63.6%. industry 28%,
construction 6.1%, agriculture 2..3% (1988)
Population: 15,367.928 (July 1994 est.)
Population growth rate: 0.589f ( 1 994 est.)
Birth rate: 12.62 births/ 1, 000 population
(1994 est.)
Death rate: 8.5 deaths/I. 0(X) population
(1994 est.)
Net migration rate: 1.68 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 6.1 deaths/I. 0(K) live
births (1994 est.)
Life expectancy at birth;
total population: 77.75 years
male: 74.69 years
female: 80.97 years (1994 est.)
Total fertility rate: 1 .58 children
bom/woman (1994 est.)
Nationality:
noun: Dutchman! men), Dutchwoman! women)
adjective: Dutch
Ethnic divisions: Dutch 96%. Moroccans.
Turks, and other 4% ( 1988)
Religions: Roman Catholic 34%. Protestant
25%. Muslim 3%. other 2%. unaffiliated 36%
(1991)
Languages; Dutch
Literacy: age 15 and over can read and write
(1979 est.)
total population: 99%
male: NA%
female: NA%
Labor force: 6.7 million (1991)
by occupation: services 50. 1 %, manufacturing
and construction 28.2%, government 15.9%,
agriculture 5.8% (1986)
Population; 185,790 (July 1994 est.)
Population growth rate: 0.47% (1994 est.)
Birth rate: 1 6.62 births/ 1 .000 population
(1994 est.)
Death rate: 5.5 deaths/1,000 population
(1994 est.)
Net migration rate: -6.46 migrant(s)/I.O(X)
population (1994 est.)
Infant mortality rate: 9.6 deaths/ 1 ,0(X) live
births (1994 est.)
Life expectancy at birth:
total population: 76.32 years
male: 74. 1 years
female: 78.66 years ( 1994 est.)
Total fertility rate: 1 .96 children bom/
woman (1994 est.)
Nationality:
noun: Netherlands Antillean(s)
adjective: Netherlands Antillean
Ethnic divisions: mixed African 85%. Carib
Indian, European. Latin. Oriental
Religions: Roman Catholic. Protestant.
Jewish. Seventh-Day Adventist
Languages: Dutch (official). Papiamento a
Spanish-Portuguese-Dutch-English dialect
predominates. English widely spoken. Spanish
Literacy; age 15 and over can read and write
(1981)
total population: 94%
male: 94%
female: 9yi
Ubor force; 89.000
by occupation: government 65% . industry and
commerce 28% ( 1983)','212c40faa20db020909242c82d8847c0a2500769f7a6fc332f4d1d9477739bed','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bef705d930ccd62e6208785abcb7655e925d5ec426b9d77b817af819ade8848',1994,'BZ','Belize','people-and-society',124,'Population: 208,949 (July 1994 est.)
Population growth rate: 2.42% (19^ est.)
Birth rate: 34.74 births/ 1 ,000 population
(1994 est.)
Death rate: 6 death.s/ 1 ,000 population ( 1 994
est.)
Net migration rate: -4.56 migrant(s)/l,000
population ( 1994 est.)
Infant moritality rate: 35 .6 deaths/ 1 ,000 live
births (1994 est.)
LIfie expectancy at birth:
total population: 68.08 years
male; 66.14 years
femoie: 70.12 years (1994 est.)
Total fertility rate: 4.39 children
bom/woman (1994 est.)
Nationality:
noun: Beiizean(s)
adjective; Belizean
Ethnic divisions: me.stizo 44%. Creole 30%,
Maya 1 1%, Garifuna 7%, other 8%
Religions; Roman Catholic 62%, Protestant
.30% (Anglican 12%, Methodist 6%,
Mennonite 4%. Seventh-Day Adventist 3%,
Pentecostal 2%, Jehovah''s Witnesses 1%.
other 2%), none 2%, other 6% (1980)
Languages; English (official), Spanish.
Maya, Garifuna (Curib)
Literacy: age 15 and over having ever
attended school (1970)
total population: 91%
male: 9 1 %
female: 91%
Labor force; 51,500
by occupation: agriculture 30%, services 16%,
government 15.4%, commerce 1 1.2%,
manufacturing 10.3%
note: shortage of skilled labor and all types of
technical personnel (1983)','d18e83fb1d37e1442153406fc6a9d4ac341fc17f7bc82846e09473dfe21bca30','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2769b8ff3051a62c35f199ce088e886cd2297cc18d361eae86d6e9545422619',1994,'TG','Togo','people-and-society',131,'Population: 5,341,710 (July 1994 est.)
Papulation growth rate: 3.33% (1994 est.)
Birthrate: 47.67 births/ 1, 000 population
(1994 est.)
Death rate: 14.36 deaths/1,000 population
(1 994 est.)
Net migration rate: 0 migrant(s)/l,0(X)
population (1994 est.)
Infant mortality rate: 1 10. 1 deaths/1.000
live births (1994 est.)
Life expectancy at birth:
total population: 51.77 years
male: 49.92 years
female: 53.68 years ( 1 994 est.)
Total fertility rate: 6.79 children
bom/woman (1994 est.)
Nationality:
noun: Beninese (singular and plural)
adjective: Beninese
Ethnic divisions: African 99% (42 ethnic
groups, most important being Eon, Adja,
Yoruba. bariba), Europeans 5,500
Religions: indigenous beliefs 70%, Muslim
15%, Christian 15%
Languages: French (official), Fon and
Yoruba (most common vernaculars in south),
tribal languages (at least six major ones in
north)
Literacy: age 15 and over can read and write
(1 990 est.)
total population: 23%
male: 32%
female: 16%
Labor force; 1 .9 million ( 1987)
by occupation: agricultui’e 60%, transport,
comineae, and public services 38%, industry
less than 2%
note: 49% of population of working age ( 1 985 )','e7728d65be75d3512a38ba08ac4ee107f4c00bee6a9d9c05fdebd6da031d3429','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac25a9449ac67c4bc9c85968fc8a9595eeb0286b7b978208566e782abb53c7cd',1994,'BM','Bermuda','people-and-society',137,'Population: 61,158 (July 1994 est.)
Population growth rate: 0.77% ( 1 994 est.)
Birth rate: 15.14 births/l .000 population
(1994 est, )
Death rate: 7.3 deaths/I, OCX) population
(1 994 est.)
Net migration rate: -0. 1 3 migrant(s)/ 1 .000
population (1994 est.)
Infant mortality rate: 13.16 deaths/1,000
live births (1994 est.)
Life expectancy at birth:
total population: 75.03 years
male: 73.36 years
female: 76.97 years (1994 est.)
Total fertility rate: 1.81 children
bom/woman (1994 est.)
Nationality:
noun: Bermudian(s)
adjective: Bermudian
Ethnic divisions: black 61%, white and other
39%
Religions: Anglican 37%, Roman Catholic
14%, African Methodist Episcopal (Zion)
10%, Methodist 6%, Seventh-Day Adventist
5%. other 28%
Languages: English
Literacy: age 15 and over can read and write
(1970)
total population: 98%
male: 98%
female: 99%
Labor force: 32,000
by occupation: clerical 25%. services 22%.
laborers 21%. professional and technical 13%,
administrative and managerial 10%, sales 7%,
agriculture and fishing 2% (1984)','5ad934b0a2980d063ebe1eef1417b757e3dc32b2d17b5d8b9afe648fb5151cf3','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f42d738ced665c01521d4398caac49e7f85d8612cb774a2fef58303800a461a',1994,'BT','Bhutan','people-and-society',142,'76 km
Population: 7,719,445 (July 1994 est.)
Population growth rate: 2.28% (1994 est.)
Birth rate: 32.22 births/1,000 population
(1994 est.)
Death rate: 8.37 deaihs/1,000 population
(1994 est.)
Net migration rate: - 1 .04 migrant(s)/l .000
population (1994 est.)
Infant mortality rate: 73.7 deaths/1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 63.3 1 years
male: 60.86 years
female: 65.88 years (1994 est.)
Totai fertility rate: 4.21 children
bom/woman (1994 e.st.)
Nationality:
noun: Bolivian(s)
adjective; Bolivian
Ethnic divisions: Quechua 30%, Aymara
25%, mestizo 25%-30%, European 5%-15%
Religions; Roman Catholic 95%, Protestant
(Evangelical Methodist)
Languages: Spanish (official), Quechua
(official), Aymara (official)
Literacy: age 15 and over can read and write
(1990 est.)
total population: 78%
male; 85%
female: 7 1 %
Labor force: 3.54 million
by occupation: agriculture NA, services and
utilities 20%, manufacturing, mining and
construction 7% (1993)','582c190d5a39c2e7d4466a1dd433bc39e8750043d2c9ae369725975cd1db51b1','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efca74c122c769e0b3ede6b8e359369f924f0628a017c346c957fedb322dd9f6',1994,'BA','Bosnia and Herzegovina','people-and-society',149,'Population: 4,651,485 (July 1994 est.)
note: all data dealing with population is subject
to considerable error because of the
dislocations caused by military action and
ethnic cleansing
Population growth rale: 0.69% (1994 est.)
Birth rate: 1 3.33 births/ 1 .(KM) population
(1994 est.)
Death rate: 6.39 deaths/l.fKX) population
(1994 est.)
Net migration rate: 0 migrunt(s)/l,(XX)
population ( 1994 est.)
Infant mortality rate; 1 2.7 deaths/ 1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 75, 1 3 years
male: 72,43 years
female: 78.02 years ( 1994 est.)
Total fertility rate; 1.61 children
bom/woman (1994 est.)
Nationality:
noun: Bosnian(s), Herzegovinian(s)
adjective: Bosnian, Herzegovinian
Ethnic divisions: Muslim 44%. Serb 31%.
Croat 1 7%, other 8%
Religions: Muslim 40%, Orthodox 31%,
Catholic 15%. Protestant 4%, other 10%
Languages; Serbo-Croatian 99%
Literacy:
total population: NA%
male: NA%
female: NA%
Labor force: 1,026,254
by occupation: agriculture 2%, industry,
mining 45% (1991 est.)','88f30b1dc95da8f15635fa225b363998e1e2b45934d4c79d82b6812029ce70c5','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1978a954ef318785e6258452377a1449c404578f3c23aade71675a9bfcccaf1',1994,'BW','Botswana','people-and-society',154,'Population: 1 ,359,.352 (July 1994 est.)
Population growth rate: 2.45% ( 1 994 est.)
Birth rate; 32.19 births/1 ,0(X) population
(1994 est.)
Death rate: 7.72 deaths/ 1,000 population
(1994 est.)
Net migration rate: 0 migrant(s)/l .000
population (1994 est.)
Infant mortality rate: 39.3 deaths/I ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 63.05 years
male: 60.03 years
female: 66. 1 6 years ( 1 994 est. )
Total fertility rate: 4.06 children
born/woman (1994 est.)
Nationality:
noun: Motswana (singular), Batswana (plural)
adjective: Motswana (singular), Batswana
(plural)
Ethnic divisions: Batswana 95%, Kalanga,
Basarwa, and Kgalagadi 4%, white I %
Religions: indigenous beliefs 50%. Christian
.50*^^
Languages; English (official), Setswana
Literacy: age 15 and over able to read and
write simple sentences ; 1 990 est.)
total population: 23%
male; 32%
female: 16%
Labor force: 428,000 (1992)
by occupation: 220.0(X) formal sector
employees, most others are engaged in cattle
raising and subsistence agriculture (1992 e.st.);
1 4,300 are employed in various mines in South
Africa (March 1992)
Population: uninhabited','218ec7d00ce4cebcabc06425ccd2d87f463b51a9798e2d2c6773105725340c7f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92afc28c41b989b75d983bfdbd0d3d5124f39a328a8a5f175efc09fff2ed84a4',1994,'NO','Norway','people-and-society',160,'Population: 158,739,257 (July 1994 est.)
Population growth rate: 1 . 38% ( 1 994 est,)
Birth rate; 2 1 .48 births/ 1 ,000 population
(1994 est.)
Death rate: 8.63 deaths/ 1.000 population
(1994 est.)
Net migration rate: 0 migrant(s)/l,0(X)
population (1994 est.)
Infant mortality rate: 59.5 deaths/I ,000 live
births (1994 est.)
Life expectancy at birth:
total population; 62.25 years
male; 57.4 1 years
female; 67.32 years (1994 est.)
Total fertility rate: 2.44 children
bom/woman (1994 est.)
Nationality:
noun; Brazilian(.s)
adjective; Brazilian
Ethnic divisions: Portuguese, Italian,
German, Japanese, Amerindian, black 6%,
white 55%, mixed 38%, other I %
Religions: Roman Catholic (nominal) 70%
Languages: Portuguese (official), Spanish,
English, French
Literacy: age 15 and over can read and write
(1990 est.)
total population; 81%
male; 82%
female; 80%
Labor force: 57 million (1989 est.)
hy occupation: services 42%. agriculture 31%,
industry 27%
Population: 57,040 (July 1994 est.)
Population growth rate: 0.94% (1994 est.)
Birthrate: 18,6 birth.s/1, 000 population
(1994 est.)
Death rate: 7.43 deaths/ 1 ,000 population
(1994 est.)
Net migration rate: - 1 .75 migrant(s)/l ,000
population (1994 est.)
Infant mortality rate: 26.7 deuths/l ,000 live
births (1 994 est.)
Life expectancy at birth:
total population; 66.9 1 years
male; 62.55 years
female; 7 1 .28 years ( 1 994 est.)
Totai fertiiity rate: 2.29 children born/
woman (1994 est.)
Nationality:
noun; Greenlander(s)
adjective; Greenlandic
Ethnic divisions: Greenlander 86% (Eskimos
and Creenland-bom Caucasians), Danish 14%
Religions: Evangelical Lutheran
Languages: Eskimo dialects, Danish
Literacy:
total population; NA%
male; NA%
female; NA%
Labor force: 22.800
hy occupation; largely engaged in fishing.
hunting, sheep breeding','2263ad1d40fc814ad574867d327cc44fd2ff9399a1a002e9c7afa2535d545815','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ddc4ad408e858a06cc1959990419856e4d28da29e1be3f2c3f2334d818817b6',1994,'IO','British Indian Ocean Territory','people-and-society',167,'Papulation: no indigenous inhabitants
note: there are UK-US military personnel;
civilian inhabitants, known as the Hois,
evacuated to Mauritius before construction of
UK-US military facilities
Population: 12,864 (July 1994 est.)
Population growth rate: 1.24% (1994 est.)
Birthrate: 20.31 births/ 1,000 population
(1994 est.)
Death rate: 6.09 deaths/ 1, 000 population
( 1994 est.)
Net migration rate: - 1 .8 migrant(s)/l ,000
population (1994 est.)
Infant mortality rate: 19.5 1 deaths/I ,000
live births (1994 est.)
Life expectancy at birth:
total population: 72.67 years
male: 70.83 years
female: 74.65 years (1994 est.)
Total fertility rate: 2.27 children
bom/woman (1994 est.)
Nationality:
noun: British Virgin Islander(s)
adjective: British Virgin Islander
Ethnic divisions: black 90%, white, Asian
Religions: Protestant 86% (Methodist 45%,
Anglican 21%, Church of God 7%, Seventh-
Day Adventist 5%, Baptist 4%, Jehovah’s
Witnesses 2%, other 2%), Roman Catholic 6%,
none 2%, other 6% (1981)
Languages: English (official)
Literacy: age 15 and over can read and write
(1970)
total population: 98%
male: 98%
female: 98%
Labor force: 4,911 (1980)
by occupation: NA
Population: 284,653 (July 1994 est.)
Population growth rate: 2.7% (1994 est.)
Birthrate: 26.18 births/ l.(K)0 population
(1994 est.)
Death rate: 5.04 dealhs/1,000 population
(1994 est.)
Net migration rate: 5.81 migrant(.s)/l.000
population (1994 est.)
Infant mortality rate: 25.2 deaths/1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 71.1 years
male: 69.46 years
female: 72.78 years (1994 est.)
Total fertility rate; 3.43 children
bom/woman (1994 est.)
Nationality:
noun: Bruneian(s)
adjective: Bruneian
Ethnic divisions: Malay 64%. Chinese 20%.
other 16%
Religions: Muslim (official) 63%. Buddhism
14%, Christian 8%. indigenous beliefs and
other 15% (1981)
Languages: Malay (official), English.
Chinese
Literacy; age 1 5 and over can read and write
(1981)
total population: 77%
male: 85%
female: 69%
Labor force: 89,0(X) (includes members of
(he Army)
by occupation: government 47.5%, production
of oil. natural gas. services, and construction
41.9%. agriculture, forestry, and fishing 3.8%
(1986)
note: 33% of labor force is foreign (1988)','b99aa1ffc99d92f0bd20afcdf11d3b932bb30f2a25f8e9fd5e13844f59f43d1b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bafe277385fb4dedfc60367f0490dfb736e47d8bb79b60bf3a2aa710651af30',1994,'BG','Bulgaria','people-and-society',173,'Population: 8,799,986 (July 1994 est.)
Population growth rate: -0.52% ( 1 994 est.)
Birth rate: 11.71 births/I ,000 population
(1994 est.)
Death rate: 1 1 .58 deuths/l .000 population
( 1994 est.)
Net migration rate: -5.49 migrant(s)/l,(X)0
population (1994 est.)
Infant mortality rate: 1 2 deaths/ 1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 75.24 years
male: 69.99 years
female: 76.67 years (1994 est.)
Total fertility rate: 1.71 children
bom/woman ( 1994 est.)
Nationality:
noun: Bulgarian(s)
adjective: Bulgarian
Ethnic divisions; Bulgarian 85.5%, Turk
8.5%. Gypsy 2.6%. Macedonian 2.5%.
Armenian 0.5%, Russian 0.2%, other 0.6%
Religions: Bulgarian Orthodox 85%. Muslim
15%, Jewish 0.8%, Roman Catholic 0.5%,
Uniate Catholic 0.2%, Protestant, Gregorian-
Armenian, and other 0.5%
Languages: Bulgarian: .secondary languages
closely corresptmd to ethnic breakdown
Literacy: age 15 and over can read and write
(1970 est.)
total population: 95%
male: NA%
female: NA%
Labor force: 4.5 million
b\\ oceuptuitm: industry 55%. agriculture 20%,
other 47% (1987)
Population: 10,1,34.661 (July 1994 e.st.)
Population growth rate: 2.8 1 ''T ( 1 994 est.)
Birth rate: 48.42 births/ 1. OCX) population
(1994 est.)
Death rate: 18.2 deaths/l .OCX) population
(1994 est.)
Net migration rate: -2.08 migrant(s)/l.(X)0
population (1994 est.)
Infant mortality rate: 118.3 deaths/ 1 ,(X)0
live births (1994 est.)
Life expectancy at birth:
ratal papulation: 47.03 years
male: 46, 1 8 years
female: 47.9 years ( 1994 est.)
Total fertility rate: 6.94 children
bom/woman (1994 est.)
Nationality:
naun: Burkinabe (singular and plural)
adjeetiee: Burkinabe
Ethnic divisions: Mossi (about 2.5 million).
Gurunsi, Senufo, Lobi, Bobo. Mandc, Fulani
Religions: indigenous beliefs 409e, Muslim
50ff, Christian (mainly Roman Catholic) lO^f
Languages: French (official), tribal
languages belong to Sudanic family, spoken by
90''/) of the population
Literacy: age 15 and over can read and write
(1990 est.)
total population: 18T
male: 289;
female: 9<:f-
Labor force: NA (most adults arc employed
in subsisiancc agriculture; 52T of population
is 1 5 years of age or older)
by aeeiipatian: agriculture 80%, industry 15''''''{-.
commerce, scn ices. and government 5‘7r
note: 2()9f of male labor force migrates
annually to neighboring countries for seasonal
employment ( 19841','c7d04d7319effc2c69eb1d2eff80e60abdf04db9a450c69b083f9d53250d7c89','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90d39b3224d7e37df23af880400e6e14b7de141f175fe25fe156f0167724685e',1994,'TH','Thailand','people-and-society',180,'Population: 44,277,014 (July 1994 est.)
Population growth rate; 1 .86% ( 1 994 est.)
Birth rate: 28.45 births/ 1, 000 population
(1994 est.)
Death rate: 9.84 deaths/ 1 ,000 population
(1994 est.)
Net migration rate: 0 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 63.7 deaths/1,000 live
births (1994 est.)
Life expectancy at birth:
total population: 59.98 years
male: 57,94 years
female: 62, 15 years (1994 est.)
Total fertility rate: 3.64 children
bom/woman (1994 est.)
Nationality:
noun: Burmese (singular and plural)
adjective: Burmese
Ethnic divisions: Burman 68%, Shan 9%,
Karen 7%, Rakhine 4%, Chinese 3%, Mon 2%,
Indian 2%, other 5%
Religions: Buddhist 89%, Christian 4%
(Baptist 3%, Roman Catholic 1%), Muslim
4%, animist beliefs 1%, other 2%
Languages: Burmese; minority ethnic groups
have their own languages
Literacy: age 1 5 and over can read and write
(1990 est.)
total population: 81%
male: 89%
female: 72%
Labor force: 16.007 million (1992)
hy occupation: agriculture 65.2%, industry
14.3%, trade 10.1%, government 6.3%, other
4.1%(FY89 est.)','30419d235e2b20678362d79ea5abec8fba6f27fa96117afd1385d17a7f3c3c1b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('504ba317638259eabdae0f5dfb1705feba01e979f7fd6c9682106ee1c728dce1',1994,'BI','Burundi','people-and-society',189,'Population: 6,124,747 (July 1994 est.)
Population growth rate: 2.26% (1994 est.)
Birth rate: 44.02 births/ 1, 000 population
(1994 est.)
67
Burundi (continued)
Death rate; 21.38 deaths/1,000 population
(1994 est.)
Net migration rate: 0 inigrant(s)/l,000
population ( 1 994 est.)
Infhnt mortality rate: 1 13.7 death.s/1,000
live births (1994 est.)
Life expectancy at birth:
total population: 40.3 years
niale: 38.31 years
female: 42.35 years (1994 est.)
Total fertility rate: 6.69 children
bom/woman (1994 est.)
Nationality:
noun: Bunindiun(.s)
adjective: Burundi
Ethnic divisions:
Africans: Hutu (Bantu) 85%, Tutsi (Hamitic)
1 4%, Twa (Pygmy) I % (other Africans include
about 70.000 refugees, mostly Rwandans and
Zairians)
non-Africans: Europeans 3,000, South Asians
2,000
Religions: Christian 67% (Roman Catholic
62%, Protestant 5%), indigenous beliefs 32%,
Muslim 1%
Languages: Kirundi (official), French
(ofTicial). Swahili (along Lake Tanganyika and
in the Bujumbura area)
Literacy: age 15 and over can read and write
(1990 est.)
total population: 50%
male: 61%
female: 40%
I.abor force; 1.9 million (1983 est.)
hy occuiHition: agriculture 93.0%. government
4.0%, industry and commerce 1 .5%, .services
1.5%
note: 52% of population of working age (1985)','27de3cce59fc4c10b8f0221a282ab176ff86d557dad11e3e9ec6025846c0331f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f2fbf3b7aa58525aa0e0a72e54cae9fd36d0039a547db4badc393a8d8691132',1994,'KH','Cambodia','people-and-society',195,'Popuktion; 10,264,628 (July 1994 est.)
Population growth rate: 2.87% (1994 est.)
Birth rate: 45.09 births/ 1 ,000 population
(1994 est.)
Death rate: 16.36 deaths/1,000 population
(1994 est.)
Net migration rate; 0 migrant(s)/ 1,000
population (1994 est.)
Infant mortality rate: 1 10.6 deaths/1,000
live births (1994 est.)
Life expectancy at birth:
total population: 49.26 years
male: 47.8 years
female: 50.8 years (1994 est.)
Total fertility rale: 5.81 children
bom/woman (1994 est.)
Nationality:
noun: Cambodian(s)
adjective: Cambodian
Ethnic divisions: Khmer 90%, Vietnamese
5%, Chinese 1 %, other 4%
Religions: Theravada Buddhism 95%, other
5%
Languages: Khmer (official), French
Literacy: age 15 and over can read and write
(1990 est.)
total population: 35%
male: 48%
female: 22%
Labor force: 2,500,000 to 3,000,000
by occupation: agriculture 80% (1988 est.)
Population: 59,510,471 (July 1994 est.)
Population growth rate: 1 .3% ( 1 994 est.)
Birth rate: 1 9.43 births/ 1 ,000 population
(1994 est.)
Death rate: 6.41 death.s/I.OOO population
(1994 est.)
Net migration rate: 0 migrant(s)/l,0(X)
population (1994 est.)
Infant mortality rate: 37. 1 deaths/1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 68.35 years
male; 64.99 years
female: 7 1 .87 years ( 1994 est.)
Total fertility rate: 2. 1 children bom/woman
(1994 est.)
Nationality:
noun: Thai (singular and plural)
adjective; Thai
Ethnic divisions: Thai 75%, Chinese 14%.
other 1 1%
Religions: Buddhism 95%, Muslim 3.8%,
Christianity 0.5%, Hinduism 0.1%, other 0.6%
(1991)
Languages: Thai. English the secondary
language of the elite, ethnic and regional
dialects
Literacy: age 1 5 and over can read and write
(1990 est.)
total population: 93%
male: 96%
female: 90%
Labor force: 30.87 million
by occupation: agriculture 62%. industry 1 3%.
commerce 11%, services (including
government) 14% (1989 est.)
Population: 2,213.785 (July 1994 est.)
Population growth rate: 0.89% ( 1994 est.)
Birth rate: 1 5.59 births/I ,000 population
(1994 est.)
Death rate: 6.72 deaths/l,(X)0 population
(1 994 est.)
Net migration rate: 0 migrant(s)/l .000
population (1994 est.)
Infant mortality rate: 27.8 deaths/1.000 live
births ( 1994 est.)
Life expectancy at birth:
total population: 73.59 years
male: 71.51 years
female: 75.85 years (1994 est.)
Total fertility rate: 1.98 children
bom/woman (1994 est.)
Nationality:
noun: Macedonian(s)
adjective: Macedonian
Ethnic divisions: Macedonian 65%.
Albanian 22%, Turkish 4%/. Serb 2%, Gypsies
3%, other 4%
Religions: Eastern Orthodox 67%, Muslim
30%, other 3%
Languages: Macedonian 70%. Albanian
21%. Turkish .3%. Serbo-Croatian .3%, other
3%
Literacy;
total population: N A%
male: NA%
female: NA%
Labor force; 507.324
by occupation: agriculture 8%. manufacturing
and mining 40% ( 1990)','8b6475c9cc8c1f08ebe2548feadfab0addaa202cabcc5fbfadb60430d8fc1a60','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e4ab754785dc6bea6fd501fc3ef90e4adc432dca06a410a142c9179e8114a4c',1994,'CM','Cameroon','people-and-society',199,'Population: 13132,191 (July 1994 esi.)
Papulation growth rate: 2.9 1 % ( 1 994 est. )
Birth rate: 40.53 births/1. 000 population
(1994 est.)
Death rate: 1 1 .4 1 deaths/ 1 .000 population
(1994 est.)
Net migration rale: 0 migrants)/ 1 ,000
population (1994 est.)
Infant mortality rate: 77.1 deaths/1.000 live
births (1994 est.)
Life expectancy at birth:
total population: 57.07 years
male: 55.03 years
female: 59. 1 7 years ( 1994 est.)
Total fertility rate: 5.84 children
bom/woman ( 1 994 est.)
Nationality:
noun: Cameroonian(s)
adjective: Cameroonian
Ethnic divisions: Cameroon Highlanders
3 1 Equatorial Bantu I95(''. Kirdi 11%. Fulani
10%, Northwestern Bantu 8%, Eastern Nigritic
7%, other African 13%, non-African less than
1%
Religions: indigenous beliefs 51%. Christian
33%, Muslim 16%
Languages; 24 major African language
groups, English (official). French (official)
Literacy: age 15 and over can read and write
(1990)
total population: 55%
male: 66%
female: 45%
Labor force; NA
by occupation: agriculture 74.4%, industry
and transport 1 1,4%, other services 14.2%
(1983)
note: 50% of population of working age ( 1 5-64
years) (1985)
Population: 98,091,097 (July 1994 est.)
Population growth rate: 3. 1 5% ( 1 994 est.)
Birth rate: 43.52 births/ 1, 000 population
(1994 est.)
Death rate: 1 2.43 deaths/ 1 ,000 population
(1994 est.)
Net migration rate: 0..36 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 75 deaths/I ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 55.33 years
male: 54. 1 1 years
female; 56.59 years (1994 est.)
Total fertility rate: 6.37 children bom/
woman (1994 est.)
Nationality;
noun: Nigerian(s)
adjective: Nigerian
Ethnic divisions;
north: Hausa and Fulani
southwest: Yoruba
southeast: Ibos
non-Africans 27,000
note: Hausa and Fulani. Yoruba. and Ibos
together make up 65% of population
Religions: Muslim 50%. Christian 40%.
indigenous beliefs 10%
Languages: English (official). Hausa.
Yoruba. Ibo, Fulani
Literacy: age 15 and over can read and write
(1990 est.)
total population: 51%
male: 62%
female: 40%
Labor force: 42.844 million
by occupation: agriculture 54%, industry,
commerce, and services 19%, government
15%
note: 49% of population of working age ( 1 985)','4d95c902800cfa98fd99cde202728c877a7e4e4b5bc46b01614e0f723ea60f6f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac5b59b82da51975715e6d3e6960b3123448e6c78e42e21ac916ecb5bbff714d',1994,'CA','Canada','people-and-society',204,'Population: 28,1 1.7,997 (July 1994 est.)
Population growth rate: 1.18% ( 1994 e.st.)
Birth rate: 1 4. 1 biiihs/l .000 population
(1994 est.)
Death rate: 7,39 deaths/I, (XX) population
(1994 est.)
Net migration rate: 5.1 1 migrant(s)/l,(X)0
population (1994 est.)
Infant mortality rate: 6.9 deaths/ 1 .(X)0 live
births (1994 est.)
Life expectancy at birth:
total population: 78. 1 3 years
male: 74.73 years
female: 8 1 .7 1 years (1994 est.)
Total fertility rate: 1 .84 children
born/woman (1994 e.st.)
Nationality;
noun: Canadian(s)
adjective; Canadian
Ethnic divisions; British Isles origin 40%.
French origin 27%, other European 20%,
indigenous Indian and Eskimo 1.5%
Religions: Roman Catholic 46%, United
Church 16%, Anglican 10%, other 28%
Languages: English (official). French
(official)
Literacy: age 15 and over can read and write
(1986)
total population: '')T7r
male: NA%
female: NA%
Labor force: 1 3.38 million
by occupation: services 75%, manufacturing
14%, agriculture 4%. construction 3%. other
47r(19K8)
Population: 423,120 (July 1994est.)
Population growth rate: 3.0 1 % (1 994 est.)
Birth rate: 46.23 births/1,000 population
(1994 est.)
Death rate: 9.04 deaths/I. 000 population
(1994 est.)
Net migration rate: -7.09 migrant(s)/1 .000
population ( 1 994 est.)
Infant mortality rate; 57.7 deaths/ 1 ,000 live
births (1994 e-st.)
Life expectancy at birth:
total population: 62.59 years
maic: 60.7 years
femaie: 64.58 years (1994 esi.)
Total fertility rate: 6.32 children
bom/woman ( 1 994 est.)
Nationality:
noun: Cape Verdean(s)
adjective: Cape Verdean
Ethnic divisions: Creole (mulatto) 71%,
African 28%, European 1%
Religions: Roman Catholicism fused with
indigenous beliefs
Languages: Portuguese, Crioulo, a blend of
Portuguese and West African words
Literacy: age 15 and over can read and write
(1989)
total population: 66%
male: NA%
female: NA%
Labor force; I02.(XX) ( 1985 est.)
by occupation: agriculture (mostly
subsistence) 57%, services 29%. industry 14%
(1981)
note: 5 1 % of population of working age ( 1 985)','3165be0754ce7dbb9be138e26473ac303a1e874052173203b74e85026cce6f87','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9fdea98d9416841aaa0bf5dfe44af518306107231b9f9aa4de0fbbd84eb0f89b',1994,'KY','Cayman Islands','people-and-society',213,'Population: 31,790 (July 1994 est.)
Population growth rate: 4.33% (1994 est.)
Birth rate: 1 5.06 births/I ,000 population
(1994 est.)
Death rate: 4.98 deaths/1,000 population
(1994 est.)
i
Net migration rate; 33.2 migrant(s)/ 1.000
population (1994 est.)
Infant mortaiity rate: 8.4 deaths/I, (XX) live
births (1994 est.)
Life expectancy at birth:
touil population: 11. \\ years
male: 75.37 years
female: 78.81 years (1994 est.)
Totai fertiiity rate: 1 .46 children
bom/woman (1994 est.)
Nationality:
noun: Caymanian(s)
adjective: Caymanian
Ethnic divisions: mixed 40%, white 20%.
black 20%, expatriates of various ethnic groups
20%
Religions: United Church (Presbyterian and
Congregational). Anglican. Baptist. Roman
Catholic, Church of Grxi. other Protestant
denominations
Languages: English
Literacy: age 1.5 and over having ever
attended school ( 1 970)
total population: 98%
male: 98%
female: 98%
Labor force: 8,061
hy occii/wtion: service workers 18.7%, clerical
18.6%. construction 12.5%, finance and
investment 6.7%. directors and business
managers 5.9% (1979)','50ea40c5aaabff835950a47d865d116f0f511a7fe7813de4067a43c241a538a8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d07880c34f4ee1ffc19ff19ac21093b038707aa112c10ac96cb2c0691761b069',1994,'CF','Central African Republic','people-and-society',217,'Population: .1.142,182 (July 1994 est.)
Population growth rate: 2.169^ ( 1994 est.)
Birth rate: 42.3 births/1,000 population
(1994 est.)
Death rate: 20.69 deaths/ 1, 000 population
(1994 est.)
Net migration rate: 0migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 1 37.2 deaths/ 1 ,000
live births (1994 est.)
Life expectancy at birth:
total population: 42.54 years
male: 4 1 .07 years
female: 44.06 years ( 1994 est.)
Total fertility rate: 5.42 children
bom/woman (1994 est.)
Nationality:
noun: Central African(s)
adjective: Central African
Ethnic divisions: Baya 34%, Banda 27%.
Sara 10%, Mandjia2l%, Mboum4%. M''Bakn
4%. Europeans 6,500 (including 3.600 French)
Religions: indigenous beliefs 24%, Protestant
25%, Roman Catholic 25%, Muslim 15%.
other 1 1 %•
note: animistic beliefs and practices strongly
influence the Christian majority
Languages: French (official), Sangho (lingua
franca and national language). Arabic. Hunsa.
Swahili
Literacy: age 1 5 and over can read and write
(1990 e.st.)
total population: 27%
male: 33%
female: 15%
Labor force: 775,413 (1986 e.st.)
by occupation: agriculture 85%. commerce
and services 9%, industry 3%. government 3%
note: about 64.(X)0 salaried workers; 55% of
population of working age (1985)','1474fe522ad73808911b116ac0399d655d39d440c239b94cbf983ec45312b8a7','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1bb20cef329b140fcb4aea388d165eb507e84a883fb02a9d0d4d0f8f458caa0c',1994,'NG','Nigeria','people-and-society',225,'Population: 5.466.771 (July 1994 est.)
Population growth rate: 2. 1 5% ( i 994 est.)
Birth rate: 42.12 births/1.000 population
(1994 est.)
Death rate: 20.59 deaths/1.000 population
(1994 est.)
Net migration rate: 0 migrant(s)/l.000
population (1994 est.)
Infant mortality rate: - 1.1 1 .8 deaths/ 1 .000
live births (1994 est.)
Life expectancy at birth:
total population: 40.79 years
male: 39.7 years
female: 4 1 .94 years ( 1 994 est. )
Total fertility rate: 5.33 children
born/woman (1994 est.)
Nationality:
noun: Chadian(s)
adjective: Chadian
Ethnic divisions:
north and center: Muslims (Arabs, Toubou,
Hadjerai, Fulbe, Kotoko, Kanembou,
Baguirmi. Buulala, Zaghawa, and Maba)
south: non-Muslims (Sara, Ngambaye. Mbaye.
Goulaye, Moundang, Moussei, Massa)
nonindigenous I50,(XK), of whom LCXlOare
French
Religions: Muslim 509f. Christian 25%,
indigenous beliefs, animism 25%
Languages: French (official), Arabic
(official), Sara (in south), Sango (in south),
more than l(X) differetit languages and dialects
are spoken
Literacy: age 15 and over can read and write
French or Arabic ( 1990 est.)
total population: 30%
male: 42%
female: 18%
Labor force: NA
hy iK ciipaiion: agriculture 85% (engaged in
unpaid subsistence farming, herding, and
fishing)
Population; 729,425 (July 1994 est,)
Population growth rate: -0.75% ( 1 994 est.)
Birth rate: 19.95 births/1 ,(X)0 population
(1994 est.)
Death rate: 7.36 deaths/ 1 ,000 population
(1994 est.)
Net migration rate: -20.03 migrant(s)/l,CXK)
population (1994 est.)
Infant mortality rate; 48.5 deaths/I ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 64.9 years
male: 6 1 .66 years
female: 68.3 years (1994 est.)
Total fertility rate: 2.29 children born/
woman (1 994 est.)
Nationality:
noun: Guyanese (singular and plural)
adjective: Guyanese
Ethnic divisions: East Indian 5 1 %, black and
mixed 43%, Amerindian 4%. European and
Chine.se 2%
Religions: Christian 57%, Hindu 33%,
Muslim 9%, other 1 %
Languages: English. Amerindian dialects
Literacy: age 15 and over having ever
attended school (1990 est.)
total population: 95%
male: 98%
female: 96%
Labor force: 268,000
by occupation: industry and commerce 44.5%,
agriculture 33.8%. services 21.7%
note: public-sector employment amounts to
60-80% of the total labor force (1985)','d98c9b745ca8b5d3e145b9b2c949cca063de1d1fd383fd440a69e043e12c28f5','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64ca1caf9e302c9c32958b3cc741856ae9a3be0ae220c1ba3e33af88450708d3',1994,'CL','Chile','people-and-society',232,'Population: 13,9.50.557 (July 1994 est.)
Population growth rate: 1 .5 1 % ( 1994 est.)
Birth rate: 20.59 births/ 1 .000 population
(1994 est.)
Death rate: 5.49 deaths/ 1 ,000 population
(1994 est.)
Net migration rate; 0 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 1 5. 1 deaths/I .000 live
births (1994 est.)
Life expectancy at birth:
total population: 74.5 1 years
male: 7 1 .52 years
female: 77.65 years ( 1994 est.)
Total fertility rate: 2.5 children bom/woman
(1994 est.)
Nationality:
noun: Chilean(s)
adjective: Chilean
Ethnic divisions: European and
Europeun-Indian 95%, Indian 3%, other 2%
Religions: Roman Catholic 89%. Protestant
1 1%. Jewish
Languages; Spanish
Literacy; age 15 and over can read and write
(1990 e,si.)
total population: 93%
male: 94%
female: 93%
Labor force: 4.728 million
by occupation: services 38.3% (includes
government 12%), industry and commerce
33.89! , agriculture, forestry, and fishing
1 9.2%, mining 2,3%, construction 6,4% (1990)','39825aa11befe8bc52773e7928c5f79aad33d6a997e7a678248083c7f48acb01','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('252f0ab51e2c110529da38dd3a7ee38b606c6d859f9d50a3f50421eae8c03432',1994,'MN','Mongolia','people-and-society',237,'Population: 1,190,431,106 (July 1994 est.)
Population growth rate: 1 .08% ( 1 994 est.)
Birth rate; 18. 1 biiths/l .000 population
(1994 est.)
Death rate: 7.35 deaths/I.OOO population
(1994 est.)
Net migration rate: 0 migrunt(s)/ 1,000
population (1994 est.)
Infant mortality rate; 52.1 deaths/I.OOO live
births (1994 est.)
Life expectancy at birth;
total population: 67,91 years
male: 66.93 years
female: 68,99 years (1994 est.)
Total fertility rate: 1 .84 children
bom/woman ( 1 994 est.)
Nationality:
noun: Chinese (singular and plural)
adjective: Chinese
Ethnic divisions: Han Chinese 91 .9%,
Zhuang, Uygur, Hui, Yi. Tibetan, Miao.
Manchu, Mongol, Buyi, Korean, an ’ other
nationalities 8.1%
Religions: Daoism (Taoism), Buddhism,
Muslim 2-3%, Christian 1% (est.)
note: officially atheist, but traditionally
pragmatic and eclectic
Languages: Standard Chinese or Mandarin
(Putonghua, based on the Beijing dialect). Y ue
(Cantone.se), Wu (Shanghainese). Minbei
83
China (continued)
(Fuzhou), Minnan (Hokkien-Taiwanese),
Xiang, Gan, Hakka dialects, minority
languages (see Ethnic divisions entry)
Literacy: age IS and over can read and write
(1990)
total population: 78%
male: 87%
female: 68%
Labor force: 567.4 million
hy occupation: agriculture and forestry 60%,
industry and commerce 25%. construction and
mining 5%. social services 5%, other 5% ( 1 990
est.)
Population: 2,429,762 (July 1994 est.)
Population growth rate: 2.61% (1994 est.)
Birth rate: 33.04 births/1,000 population
(1994 est.)
Death rate: 6.99 deaths/1,000 population
(1994 est.)
Net migration rate: 0migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 43.4 deaths/I ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 66.16 years
male: 63.9 years
female: 68.52 years (1994 est.)
Total fertility rate: 4.33 children bom/
woman (1994 est.)
Nationality:
noun: Mongolian(s)
adjective: Mongolian
Ethnic divisions: Mongol 90%, Kazakh 4%,
Chinese 2%, Russian 2%. other 2%
Religions: predominantly Tibetan Buddhist.
Muslim 4%
note: previously limited religious activity
because of Communist regime
Languages: Khalkha Mongol 90%. Turkic,
Russian, Chinese
Literacy:
total population: NA%
male: NA%
female: NA%
Labor force: NA
by occupation: primarily hcrding/agricultural
note: over half the adult population is in the
labor force, including a large percentage of
women; shortage of .skilled labor','11cd03c983adfa0d665d02cb63797dff534dbbb48964b6fa2ca79fcf08bb5a83','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c667875c366078e85a3dbd30802de8234fc83429b81995c8957f83d32d893867',1994,'CX','Christmas Island','people-and-society',244,'Population; 973 (July 1994 est.)
Population growth rate: -9% (1994 est.)
Birth rate: NA
Death rate: NA
Net migration rate: NA
Infant mortality rate: NA
Lite expectancy at birth:
total population; NA
85
Christmas Island (continued)
male: NA
female: NA
Total fertility rate: NA
Nationality:
noun: Christmas Islanders)
adjective: Christmas Island
Ethnic divisions: Chinese 61%, Malay 25%,
European 1 1 %, other 3%, no indigenous
population
Religions: Buddhist 36. 1 %, Muslim 25.4%,
Christian 17.7% (Roman Catholic 8.2%,
Church of England 3.2%, Presbyterian 0.9%,
Uniting Church 0.4%, Methodist 0.2%, Baptist
0.1%, and other 4.7%), none 12.7%, unknown
4.6%, other 3.5% (1981)
Languages: English
Literacy:
total population: NA%
mate: NA%
female: NA%
Labor force: NA
by occupation: all workers are employees of
the Phosphate Mining Company of Christmas
Island, Ltd.
Population: uninhabited','65465de1b065ed23ea0e8e339ee2fbf306a188c11ff68aa2db1be09d57c673b6','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76db986f81a7c4955eb72a4fb7e6042bbc693d0a277240895ad9ee4233e4c56f',1994,'CC','Cocos (Keeling) Islands','people-and-society',253,'Population: 598 (July 1994 est.)
Population growth rate: 0.98% (1994 est.)
Nationality;
noun: Cocos Islandeifs)
adjective: Cocos Islander
Ethnic divisions:
West Island: Europeans
Home Island: Cocos Malays
Religions: .Sunni Muslims
Languages; English
Literacy:
total population: NA%
male: NA%
female: NA%
Labor force: NA','f8fe1798ba9436b8f51df34d2ca573f433720e93d4979e47b49ffcdc42ea330b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a37d200b3e7c357ab5cfd7f27eba2077f158347d00a53ec9b673d265c6e1e93',1994,'CO','Colombia','people-and-society',259,'Population: 35,577,556 (July 1994 est.)
Population growth rate: 1 .77% ( 1 994 est.)
Birth rate; 22.64 births/ 1,000 population
(1994 est.)
Death rate: 4.75 deaths/ 1,000 population
(1994 est.)
Net migration rate: -0.21 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 28.3 deaths/ 1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 72. 1 years
male: 69.33 years
female: 74.95 years (1994 est.)
Total fertility rate: 2.47 children
bom/woman (1994 est.)
Nationality:
noun: Colombian(s)
adjective: Colombian
Ethnic divisions: mestizo 58%, white 2U%,
mulatto 14%, black 4%, mixed black-Indian
3%, Indian 1 %
Religions: Roman Catholic 95%
Languages: Spanish
Literacy: age 15 and over can read and write
(1990 est,)
total population: 87%
male: 88%
female: 86%
Laborforce: 12 million (1990)
by occupation: services 46%, agriculture 30%,
industry 24% (1990)','cf075266e9917b29b1ca5c0bee484e71092af8bc6ef9f437892fa937119a4db8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e287fd7b1353204a0f9ea9ca13fff7285ce9c128bc2e5678d0f81d474b30c329',1994,'KM','Comoros','people-and-society',266,'Population: 5.3().l.36(July t994est.)
Population growth rate: 3.55*3 ( 1994 est. )
Birth rate: 46.48 births/ 1 ,000 population
(1994 est.)
Death rate: 1 0.95 deaths/ 1 ,000 population
(1994 est.)
Net migration rate: 0 migrunt(s)/l,0(X)
population ( 1994 est.)
Infant mortality rate: 79.6 deaths/ 1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 57.81 years
male: 55.63 years
female: 60.06 years (1994 est.)
Total fertility rate: 6.79 children
bom/woman ( 1994 est.)
Nationality:
noun: Comoran(s)
adjective: Comoran
Ethnic divisions: Antalote, Cafre, Makoa,
Oimatsaha. Sakalava
Religions: Sunni Muslim 86%, Roman
Catholic 14*3
Languages: Arabic (official). French
(official), Comoran (a blend of Swahili and
Arabic)
Literacy: age 15 and over can read and write
(1980)
total population: 48%
male: 56%
female: 40%
Labor force: 140.000(1982)
bv ttccupation: agriculture 80%, government
3%
note: 5 1 <3 of population of working age ( 1985)','86c47952e8990a2cd5f30c359a2556798d30333bc3c0dc3496473a8b99d6dc90','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('008e76b910e276339d52cc96b3d9e91b6a489143adbf1d77fcec70a7c078057b',1994,'CG','Congo','people-and-society',270,'Population: 2.446.902 (July 1994 esi.)
Population growth rate: (1994 est.)
Birthrate: 40.27 binhs/l. 000 population
(1994 est.)
Death rate: 16.49 Jeaths/1, 000 population
(1994 est.)
Net migration rate: 0migrant(s)/l.000
population ( 1994 est.)
Infant mortality rate: 1 1 1 deaths/1.000 live
births (1994 est.)
Life expectancy at Mrth:
total population: 47.56 years
male: 45.76 years
female: 49.41 years ( 1994 est.)
Total fertility rate: 5..J children bom/w oman
) 1994 est.)
Nationality:
noiai: Congolese (singular and plural)
adjeetive: Congolese or Congo
Ethnic divisions:
south: Kongo
north: .Sangha 20‘r, M''Bochi l2''''-f
center: Tekc 17‘t. Europeans 8.,M)()( mostly
French)
Religions: Christian .5()''r.animist4b''7.
Muslim 2'''';
laanguages: French (official). African
languages ( l.ingala and Kikongo are the most
widely used)
Literacy : age 1 5 and over can read UihI write
(1990 est.)
total population: 57*7
nitile: 70* ;
lenuile 44‘''i
I jibor fort e: 79. l oo w age earners
h\\ ik cuikfi’ ii: agriculture lyi, comnKTCc.
industry . and gov emment 25*'';
note: 5 1 1 of pvipulation of working age; 40'''';
of population economically active ( 1985)
(iovemment
Names;
conceniional loni; form: Republic of the
concentional short fortn: Congo
liH iil loiifi form: Republique Populairedu
lot al short fonn: Congo
former: Congo/Bra/zaville
Digraph: CF
Type; republic
Capital: Brazzaville
.Administrative divisions; 9 regions i regions,
singular — region) and 1 commune*; Bouen/a.
Biazzavillc*. Cuvette. Kouilou. Lekoumou.
t.ikouala. Niari. Plateaux. Pixd. .Sangha
Independence: 15 August I960 (from
France)
National holiday: Congolese National Day.
15 August (1 960)
Constitution: new constitution approved by
referendum March 1992
Legal system: based on French civil law
.system and customary law
Suffrage: 18 years of age: universal
Executive branch:
chief of state: President Pascal LISSOUBA
(since August 1992): election last held 2-16
August 1992 (next to be held August 1997);
results — President Pascal LISSOUBA won
with 61‘X- of the vote
head of government: Prime Minister Jacques
Joachim YHOMBl-OPANGO (since 2.^ June
1995)
cabinet: Council of Ministers; named by the
president
Lcgislatlvr branch: bicameral
National Assembly ( Assembler Nationale):
election last held 5 October 199.5; results —
percentage vote by party NA; seats — (125
total) UPADS 64, URD/PCT 58. others 5
Senate: election last held 26 July 1992 (next to
be held July 1998); results — pereeniage vote
bv partv NA: seats — (60 total) UPADS 25.
MCDDI 14. RDD 8. RDPS 5, PCT 2. others 8
Judicial branch: Supreme Ctvurt (Cour
Supreme )
PoHtkai pantos and Icadm: Congolese
Lab;>r Party (PCT). Denis SASSOU-
NGUh.SSi). president; Pan-AIncan Union for
SiK''ial Development (UPADS). Pascal
LISSOUB.A. leader; AssiKialion for
DcmvK-racy and Development (RDD).
Joachim Yhombi OPANGO, president;
Congolese Movement for Denavracy and
Integral Development i MCDDI). Bernard
KOLEL.AS, leader; .Assvx''iation for
DenHX-racy and .Svx''ial Progress (RDPS).
Jean-Pierre Thystere TCHICAYA, president;
Union of Dcmivratic Forces ) UFD). Dav id
Charles OAN.AO. leader; Union for
Development and Svx''ial Progress (UDPS),
JcanMichael BOKAMBA-YANGOUMA.
leader
note: Congo has many political parties of
w hich these are among the most important
Cither poiiricai or prenure grmipa; Union
of Civngolese Svx-ialist Youth (UJSC);
Congolese Trade Union Congress (CSC);
Revolutionary L’nion of Congolese Women
(URFC); General Union of Congolese Pupils
and Stuiients (UGEEC’)
Member of: .ACCT ACP. AiDB. BDEAC.
CCC. CEKAC. EC A, FAO. FZ. G 77. GATT.
IBRD. ICAO. IDA. IFAD. IFC, ILO. IMF.
IMO. INTEL.SAT. INTERPOL. I(X-. ITU.
LORCS. NAM. OAU. UDE.AC. UN.
UNAVEM II. UNCTAD. UNESCO. UNIDO.
CPU. WFTU. WHO. W IPO. WMO. WTO
Diploimilto repmenUilloii in US:
chief of mission: .Ambassador Pierre Damien
BOUSSOUKOU-BOUMBA
chancery: 4891 Colorado Avenue NW,
Washington, DC 2001 1
telephone: (202) 726-5500 or 5501
LIS diplomatic representation:
chief of mission: Ambassador William
RAMSEY
embassy'': Avenue Amilcar Cabral. Brazzaville
mailing address: B. P. 1015, Brazzaville
telephone: (242) 83-20-70
FAX: 1242] 83-63-38
Flag: led, divided diagonally from the lower
hoist side by a yellow band: the upper triangle
(hoist side) is green and the lower triangle is
red: uses the popular pan-African colors of','4fba204b0d9e97709bc1aedd85dc543f9c6b4f987d1e7e45b041b6fc8b3258e8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60b61f162d7bebbfc3831e6f955d8352e261edb30459f03744ad8231f8037e24',1994,'CK','Cook Islands','people-and-society',276,'Population: 19.l24(July l9*Mest.)
Population growth rate: 1.1.3% (Idd4est.)
Birth rate: 23.22 births/ 1 .(XX) population
(IW4est.)
Death rate; .3.2 deaths/I .(XX) population
(I''West.)
Net migration rate: -6.4Q migrant(s)/l,000
population (1994 est.)
Infhnt mortality rate: 24.7 deaths/ 1 .(XK) live
births (1994 est.)
Life expectancy at birth:
total population: 71.14 years
male: 69.2 years
female: 73,1 years (1994 est.)
Total fbrtility rate; 3.3 children bom/woman
(1994 est.)
Nationality:
noun: Cook Islandeits)
adjective: Cook islander
Ethnic divisions: Polynesian (full blood)
81.3%, Polynesian and European 7.7%.
Polynesian and other 7.7%, European 2,4%,
other 0,9%
Religions; Christian (majority of populace
members of Cook Islands Christian Church)
Languages: English (official). Maori
Literacy:
total population: NA%
male: NA%
female: NA%
Labor force: S.8I0
by occupation: agriculture 29%. government
27%, services 25%, industry 15%. other 4%
(1981)','32bb6442bb1c36c2f0611b916f84b916030f62e9bf8205c066632fe9917e397b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f3b45fbab3338ca51f52d4af4aa1a1e5aaa800f50462053f71006625fbc2a9b',1994,'CR','Costa Rica','people-and-society',281,'Population: .3.342.154 (July 1994 est.)
Population growth rate: 2.3 1 % ( 1 994 est. )
Birth rate: 25.48 births/I.OOO population
(1994 est.)
Death rate: 3.52 deaths/l. 000 population
(1994 est.)
Net migration rate: 1 . 14 migrant(s)/t ,000
population (1994 est.)
Infant mortality rate: 1 1 deaths/1,000 live
births (1994 est.)
Life expectancy at birth:
total population: 77.8 years
male: 75,88 years
female: 79.8 1 years ( 1994 est.)
Total fertility rate: 3.06 children bom/
woman (1994 est.)
Nationality;
noiin; Costa Rican(s)
adjective: Costa Rican
Ethnic divisions: white (including mestizo)
96%. black 2%. Indian 1%. Chinese 1%
Religions: Roman Catholic 95%
Languages: Spanish (ofTicial). English;
spoken around Puerto Limon
Literacy; age 15 and over can read and write
(1990 est.)
total population: 93%
male: 93%
female: 93%
Labor force: 868,300
by (xrupation: industry and commerce 35. 1 %,
government and services 33%. agriculture
27%. other 4.9% (1985 est.)
Population; 14,295,501 (July 1994 est.)
Population growth rate: 3.44% (1994 est.)
Birthrate: 46.52 births/1,000 population
(1994 est.)
Death rate: 1 5.0 1 deaths/ 1 ,0(X) population
(1994 est.)
Net migration rate: 2.86 migrant(s)/ 1,000
population (1994 est.)
Infant mortality rate; 95 deaths/1,000 live
births (1994 est.)
Life expectancy at birth:
total population: 48.92 years
male: 46.75 years
female: 51.16 years ( 1 994 est.)
Total fertility rate; 6.67 children
bom/woman (1994 est.)
Nationality:
noun: Ivorian(s)
adjective: Ivorian
Ethnic divisions: Baoule 23%, Bete 18%,
Senoufou 15%, Malinke 11%, Agni, foreign
Africans (mostly Burkinabe and Malians,
about 3 million), non-Africans 130,000 to
330,0(X) (French 30,000 and Lebanese 100,000
to 300,000)
Religions; indigenous 25%, Muslim 60%,
Christian 12%
Languages: French (official), 60 native
dialects Dioula is the most widely spoken
Literacy: age 15 and over can read and write
(1990 est.)
total population: 54%
male: 67%
female: 40%
Labor force: 5.718 million
by occupation: over 85% of population
engaged in agriculture, forestry, livestock
raising; about 1 1% of labor force are wage
earners, nearly half in agriculture and the
remainder in government, industry, commerce,
and professions
note: 54% of population of working age ( 1 985)','b5c5be20eb8b8f535c817d4f2856a0db30036944809fb3555d7809069f977560','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a5b0bee38a74376e318dafb36c19372780e946dc05b02732893d0a3662c24ed',1994,'HR','Croatia','people-and-society',289,'Population: 4.697.614 (July 1994 est.)
Population growth rale: 0.07% ( 1994 est.)
Birth rate: 1 1 .27 births/ 1 .000 population
(1994 est.)
Death rate: 1 0.54 deaths/1 .000 population
(1994 est.)
Net migration rate: 0 migrant(.s)/l ,0(K)
population (1994 est.)
Infant mortality rate: 8.7 deaths/1,000 live
births (1994 est.)
Life expectancy at birth:
total population: 73.6 years
male: 70,14 years
female: 11.26 years (1994 est.)
Total fertility rate: 1 .65 children born/
woman (1994 est.)
Nationality:
noun: Croat(s)
adjective: Croatian
Ethnic divisions: Croat 78%. Serb 1 2%.
Muslim 0.9%, Hungarian 0.5%. Slovenian
0,5%, others 8.1%
Religions: Catholic 76.5%, Orthodox 11.1%.
Slavic Muslim 1.2%. Protestant 0.4%. others
and unknown 10.8%-
Languages: Serbo-Croatian 96%r. other 4%
Literacy:
total population: NA%
male: NA%
female: NA%
Labor force: I.. 509 .489
hy occupation: industry and mining 37%.
agriculture 16% ( 1981 est.). government
NA%. other','dd2bc7db54117f25472aee8c4dec3172de330ae15643203896e36861bebf53a5','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4cdd7a0c9a8909c095c994568101ff573b9dbd3ac1d935b770f774566704e5e',1994,'CU','Cuba','people-and-society',294,'Population: 1 1,064,344 (July 1994 est.)
Population growth rate: 0.95% (1994 est.)
Birth rate: 1 6.59 births/ 1 ,000 population
(1994 est.)
Death rate: 6.52 deaths/1,000 population
(1994 est.)
Net migration rate: -0.54 migrant(s)/l ,000
population (1994 est.)
Infant mortality rate: 10.3 deaths/1,000 live
births (1994 est.)
Life expectancy at birth:
total population: 76.89 years
male: 74.72 years
female: 79. 1 8 years ( 1994 est.)
Total fertility rate: 1 .83 children bom/
woman (1994 est.)
Nationality:
noun: Cuban(s)
adjective: Cuban
Ethnic divisions: mulatto 51%, white 37%,
black 11%, Chinese 1%
Religions: nominally Roman Catholic 85%
prior to Castro assuming power
Languages: Spanish
Literacy: age 15 and over can read and write
(1 990 est.)
total population: 94%
male: 95%
female: 93%
Labor force: 4,620,800 economically active
population (1988): 3,578,800 in state sector
by occupation: services and government 30%,
industry 22%. agriculture 20%, commerce
1 1%, construction 10%, transportation and
communications 7% (June 1990)','19eb92acba1d280dba391b6f2650081d55ddd32d7bf87637b88725f615303aee','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7eaa81319db3bf3c140a48141fd34c708b968183264284fdd1ef845b94aa3daf',1994,'CY','Cyprus','people-and-society',300,'Population: 7.^0.084 (July 1994 est.)
Population growth rate: 0.9 1 (1994 est. l
Birth rate: 1 6.69 births/ 1 .(XX) population
(1994 est.)
Death rale: 7.61 deaths/1.000 population
(1994 est.)
Net migration rate: 0 migrant! s)/ 1, 000
population ( 1994 est.)
Infant mortality rate: 9 deaths/I .000 live
births (1994 est.)
Life expectancy at birth:
total population: 76.22 years
male: 7.^.97 years
female: 78.58 years ( 1994 est.)
Total fertility rate: 2.32 children bom/
woman (1994 est.)
Nationality:
noun: Cypriot(s)
adjective: Cypriot
Ethnic divisions: Greek 78%, Turkish 1 8%,
other 4%
Religions: Greek Orthodox 78%. Muslim
18%. Maronite. Armenian, Apostolic, and
other 4%
Languages: Greek. Turkish. English
Literacy: age 15 and over can read and write
(1987 est.)
total population: 94%
male: 98%
female: 91%
Labor force:
Greek area: 285,500
hy occupation: services 57%, industry 29%,
agriculture 14% (1992)
Turkish area: 75,000
by occupation: services 52%. industry 22%,
agriculture 26% (1992)
Populatlrm: 1 0.408,280 (July 1 994 est. )
Populafion growth rate: 0.21^ ( 1994 est.)
Birthrate: 1.4.25 hirths/I.OOO population
(1994 est.)
Death rate: 1 1.14 deaths/ 1, 000 population
(1994 est.)
Net migration rate: 0migrant(s)/l.000
population ( 1994 est.)
Infant mortality rate: 9.3 death.s/l. 000 live
births (1994 est.)
Life expectancy at Mrth:
total population: 73.08 years
male: 69.38 years
female: 76.99 years ( 1994 est.)
Total fertility rate: 1.84 children bom/
woman (1994 est.)
Nationality:
noun: Czeeh(s)
adjective: Czech
Ethnic divisions: Czech 94.4%, Slovak 3%.
Polish 0.6%, German 0.5%, Gypsy 0.3%’,
Hungarian 0.2%'', other 1%
Religions: atheist 39.8%. Roman Catholic
39.2%. Protestant 4.6%, Orthtxlox 3%, other
13.4%
l4inguages; Czech. Slovak
Literacy:
total population: NA%
male: NA%
female: NA%
Labor force: 5..389 million
by occupation: industry 37.9%. agriculture
8.1%. construction 8.8%. communications and
other 45.2% (1990)','5771a2825ee469050fad16682a2087da4a4e55bf3947c828af103901bdf7a4e6','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eaca6e13f093f2cf9ecc2dab079661a978bc1dcda0535455c4af2843baad7eb4',1994,'GL','Greenland','people-and-society',307,'Population; 5.I87.K2I (July I994es(.l
Population growth rale: (l.2.39f 1 1994 est.)
Birth rate: 1 2.4.^ births/l .000 population
(1994 est.)
Death rate: 1 1 .28 deaths/I.IXX) population
(U)94est.)
Net migration rate: I . I migrant; s )/ 1 .(XX)
population ( 1994 est.)
Infant mortality rale: 6.9 deaths/ 1. (XX) live
births ( 1994 est.)
Life expectancy at Mrlh:
total population: 7.5.81 years
male: 72.9.3 years
female: 78.86 years ( 1994 est.)
Total fertility rate: 1 .68 children berm/
woman ( 1994 est.)
NatloiwIUy;
noun: Dune(s)
adjective: Danish
Ethnic divisions; Scandinavian. Eskiim).
Fartx''se. German
Religions; Evangelical Lutheran 9|''''f. other
Protestant and Roman Catholic 29), raher 7''t
(1988)
Languages; Danish. Faroese. Greenlandic ( an
Eskimo dialect). German (small minority)
Literacy: age I and over can read and write
(1980 est.)
total /nipiilation: 999f
male: NAC*
female: NA9i-
Labor force: 2.5.S3,9(X)
h\\ iH cupaiion: private services 37. 1 9(-.
government services .30.49). manufacturing
and mining 2091 . construction 6.39).
agriculiua*. forestry, and fishing 5.69).
electricity/gas/water 0.69) 1 1991 1','be4aa8aceb58867c022561f44337af4b1e1bc9cc79b8abd8f7479a6a61d7d35c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fc4786809cabe8c79414aa956e1c55481d9d869d1fea05efc509965bfef979a',1994,'DJ','Djibouti','people-and-society',313,'Population: 412,599 (July 1994 est.)
Population growth rate: 2.71% (1994 est.)
Birthrate: 42.94 births/ 1, 000 population
(1 994 est.)
Death rate; 1 5.8 deaths/ 1 .000 population
(1994 est.)
Net migration rate: 0 migrant(s)/l,000
population (1994 est.)
Infant naortality rate; 1 1 1 deuths/l ,(XX) live
births ( 1994 est.)
Life expectancy at birth:
total population: 49.23 years
male: 47.42 years
female: 51.1 years ( 1994 est.)
Total fertility rate: 6.2 1 children bom/
woman ( 1994 est.)
Nationality:
noun: Djiboutian(s)
adjective: Djiboutian
Ethnic divisions: Somali 60%, Afar 35%,
French. Arab. Ethiopian, and Italian 5%
Religions; Muslim 94%, Christian 6%
Languages: French (official). Arabic
(official), Somali. Afar
Literacy: age IS and over can read and write
(1990 est.)
total population: 48%
male: 63%
female: 34%
Labor force: NA
hy occupation: a small number of semiskilled
laborers at the port and 3,000 railway workers
note: 52% of population of working age (1983)','4015ad8bad7313ea0c681bafae15da601e9b1641da3141d3aa9a5910af4a7077','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a88900e0a4c0dba449c64a8bc6cbed42392e2f74ea795130a5c06d9630cacf0b',1994,'TT','Trinidad and Tobago','people-and-society',320,'Population: 87,696 (July 1994 est.)
Population growth rate: 1.32% (1994 est.)
Birth rate: 20.46 births/ 1 ,000 population
(1994 est.)
Death rate: 4.98 deaths/ 1, (X)0 population
(1994 est.)
in
Dominica (continued)
Net migration rate: -2.23 migrant(s)/ 1,000
population ( 1994 est.)
Inftint mortality rate: 1 0 3 deaths/ 1 ,000 live
births (1994 est.)
Life expectancy at birth:
total impiilation: 76.96 years
male: 74. 1 2 years
female: 79.95 years ( i994 est.)
Total fertility rate: 1 .99 children born/
woman (1994 est.)
Nationality:
noun: Dominican(s)
adjective: Dominican
Ethnic divisions: black, Carib Indians
Religions: Roman Catholic 77%, Protestant
15% (Methodist 5%, Pentecostal 3%,
Seventh-Day Adventist 3%, Baptist 2%, other
2%), none 2%, unknown I %, other 5%
Languages; English (official). Pionch patois
Literacy: age 15 and over having ever
attended school (1970)
total population: 94%
male: 94%
female: 94%
Labor force: 25,000
hy occupation: agriculture 40%, industry and
commerce 32%, services 28% (1984)
Population: 1.328.282 (July 1994 est.)
Population growth rate: I.l%(l994est.)
Birthrate: 19.6 births/1,000 population
{I994est.)
Death rate: 6.28 deaths/1,000 population
( 1994 est.)
Net migration rate: -2.33 migrant(s)/l.000
population (1994 est.)
Infhnt mortality rate: I6.S deaths/ 1 ,000 live
births (1 994 est.)
Life expectancy at birth:
total population: 70.73 years
male: 68.09 years
female; 73.43 years (1994 est.)
Total fertility rale: 2.32 children born/
woman (1994 est.)
Nationality:
noun; Trinidadian(s), Tobagonian(s)
adjective: Trinidadian. Tobagonian
Ethnic divisions: black 43%, East Indian
40%, mixed 14%. white 1%. Chinese 1 %, other
1%
Religions: Roman Catholic 32.2%. Hindu
24.3%, Anglican 14.4%. other Protestant 14%.
Muslim 6%, none or unknown 9. 1 %
Languages: English (official). Hindi, French,
Spanish
Literacy: age IS and over can read and write
(1980)
total (topulation: 95%
male: 97%
female; 93%
Labor force: 463.900
by occupation: construction and utilities
18.1%. manufacturing, mining, and quarrying
14,8%, agriculture I0.9'';( . other 56.2% (1985
est.)
Population: uninhabited','e93cbe81d15813c43724094ef263be53d4936afc5a74fb2cc0dc84318ff7c87a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69046bf3e9feb9352e351fe574779d9745cbac20a954c41834f3a010e4c88cec',1994,'EC','Ecuador','people-and-society',331,'Population: 10,677,067 (July 1994 est.)
Population growth rate: 2.0 1 % ( 1 994 est.)
Birth rate: 25.82 births/1,000 population
( 1994 est.)
Death rate: 5.67 deaths/ 1,000 population
(1994 est.)
Net migration rate: 0 migrant(s)/l,000
population (1994 est.)
Infant mortality rate; 39.3 deaths/I ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 69.98 years
male: 67.46 years
female: 72.62 years v 1994 est.)
Total fertility rate: 3.08 children
born/woman (1994 est.)
Nationality;
noun: Ecuadorian(s)
adjective: Ecuadorian
Ethnic divisions: mestizo (mixed Indian and
Spanish) 55%, Indian 25%, Spanish 10%,
black 10%
Religions: Roman Catholic 95%
Languages: Spanish (official), Indian
languages (especially Qucchua)
Literacy: age IS and over can read and write
(1990)
total population: 88%
male: 90%
female: 86%
Labor force: 2.8 million
by occupation: agriculture 35%,
manufacturing 21%. commerce 16%. services
and other activities 28% (1982)
Population; 23,650,671 (July 1994 est.)
Population growth rate: 1.86% (1994 est.)
Birth rate: 25.5.5 births/ 1, 000 population
(1 994 est.)
Death rate: 7 deaths/ 1, 000 population (1994
est.)
Net migration rate: 0 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 54.2 deaths/I .(XX) live
births (1994 est.)
Life expectancy at birth:
total population: 65.62 years
male: 63.44 years
female: 67.9 years (1994 est.)
Total fertility rate: 3. 1 1 children
bom/woman (1994 est.)
Nationality:
noun: Peruvian(s)
adjective: Peruvian
Ethnic divisions: Indian 45%. mestizo
(mixed Indian and European ancestry) 37%,
white 1 5%, black, Japanese, Chinese, and other
3%
Religions: Roman Catholic
Languages: Spanish (official), Quechua
(official), Aymara
Literacy: age 1 5 and over can read and write
(1990 est.)
total population: 85%
male: 92%
female: 29%
Labor force: 8 million (1992)
by occupation: government and other services
44%. agriculture 37%, industry 19% (1988
est.)','08e4ba99f133c88b35b2dc04072c820cbb01996a878d67617cb4c99f76d2c29b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c8f8d09fe663e66f00f4fa62daa43885f17ce2a9bb1ff1771980f690bde0a08',1994,'EG','Egypt','people-and-society',338,'Population: 60,765,028 (July 1994 est.)
Population growth rate: 1.95% (1994 est.)
Birthrate: 28.69 births/1,000 population
(1994 est.)
Death rate: 8.87 deaths/ 1.000 population
(1 994 est.)
Net migration rate: -0.35 migrant(s)/l ,000
population (1994 est.)
Infant mortality rate: 76.4 deaths/I .000 live
binhs(l994est.)
Life expectancy at birth:
total population: 60.79 years
male: 58.9 1 years
female: 62 J6 years (1994 est.)
Total fertility rate: 3.77 children
bom/woman (1994 est.)
Nationality:
noun: Egyptian($)
adjective: Egyptian
Ethnic divisions: Eastern Hamitic stock
(Egyptians, Bedouins, and Berbers) 99%,
Greek, Nubian, Armenian, other European
(primarily Italian and French) 1%
Religions: Muslim (mostly Sunni) 94%
(official estimate), Coptic Christian and other
6% (official estimate)
Languages: Arabic (official). English and
French widely understood by educated classes
Literacy: age 15 and over can read and write
(1990 est.)
total population: 48%
male: 63%
female: 34%
Labor force: 15 million (1992 est.)
by occupation: government, public sector
enterprises, and armed forces 36%, agriculture
34%, privately owned service and
manufacturing enterprises 20% (1984)
note: shortage of skilled labor; 2.500.000
Egyptians work abroad, mostly in Saudi Arabia
and the Gulf Arab states (1993 est.)','0830602aee6e8bff55418761d6b723bfda8f34798cc006bb0fe9d9f0c04adb14','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('217e9b94e551c52943296d57c7af131163989a0a9cb878f08f74feb75e14e997',1994,'HN','Honduras','people-and-society',345,'Population: 5,752,511 (July 1 994 est.)
Population growth rate; 2.04% (1994 est.)
Birth rate: 32.81 births/I, 0(X) population
(1994 est.)
Death rate: 6.36 deaths/ 1 ,000 population
(1994 est.)
Net migration rate: -6.08 migrant(s)/l.(X)0
population (1994 e.st.)
Infant mortality rate: 40.9 deaths/1 ,(X)0 live
births (1994 e.st.)
Life expectancy at birth;
total population; 66.99 years
male; 64.41 years
female; 69.7 1 years ( 1 994 est.)
Total fertility rate: 3.78 children
born/woman ( 1994 est.)
Nationality;
noun; Salvadoran(s)
aeljective; Salvadoran
Ethnic divisions: mestizo 94%. Indian 5%.
white 1 %
Religions: Roman Catholic 75%
note; Roman Catholic about 75%; there is
extensive activity by Protestant groups
throughout the country; by the end of 1992,
there were an estimated 1 million Protestant
evangelicals in El Salvador
Languages: Spanish, Nahua (among some
Indians)
Literacy: age 15 and over can read and write
(1990 est.)
total population; 73%
male; 76%
female; 70%
Labor force: 1 .7 million ( 1982 est.)
by occupation; agriculture 40%, commerce
16%, manufacturing 15%, government 13%,
financial services 9%. transportation 6%, other
1%
note; shortage of skilled labor and a large pool
of unskilled labor, but manpower training
programs improving situation (1984 est.)
Population: 5,314.794 (July I994est.)
Population growth rate: 2.73% (1994 est.)
Birth rate: 34.97 birth.s/1 ,000 population
(1994e.st.)
Death rate: 6.22 deaths,'' I, (XX) population
(1 994 est.)
Net migration rate: - 1 .5 inigrant(s)/l ,000
population (1994 est.)
Infant mortality rate: 45.3 deaths/1,000 live
births (1 994 est.)
Life expectancy at birth;
total population: 67.6 years
male: 65.23 years
female: 70.08 years (1994 est.)
Total fertility rate: 4.71 children bom/
woman (1994 est.)
Nationality:
noun: Honduran(s)
adjective: Hondunin
Ethnic divisions: mestizo (mixed Indian and
European) 90%, Indian 7%. black 2%, white
)%
Religions: Roman Catholic 97%, Protestant
minority
Languages: Spanish, Indian dialects
Literacy: age IS and over cun read and write
(1990 est.)
total population: Ti%
male: 76%
female: 7 1 %
Labor force: 1 .3 million
by occupation: agriculture 62%. services 20%,
manufacturing 9%. construction 3%, other 6%
(1985)','83010dd73d75eb4d20c0485d3d514ce4e5b6e81a4672ef5fc7b10bf6ec0e23d5','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f5c574a9ddaeec25334c79f5cea3c2971d1728431ce4ff4cda2de699c841e5c',1994,'GQ','Equatorial Guinea','people-and-society',352,'Population: 409.550 (July 1994 est.)
Population growth rate: 2.59% (1994 est.)
Birth rate: 40.65 births/ 1, 000 population
(1994 est.)
Death rate: 14.73 deaths/1.000 population
(1994 est.)
Net migration rate: 0 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 1 02.6 deaths/ 1 ,000
live births ( 1994 est.)
Life expectancy at birth:
total population: 52.09 years
male: 49.97 years
female: 54.27 years ( 1994 est.)
Total fertility rate: 5.28 children
bom/woman (1994 est.)
Nationality:
noun: Equatorial Guinean(s) or
Equatoguinean(s)
adjective: Equatorial Guinean or
Equatoguinean
EAnic divisions: Bioko (primarily Bubi,
some Femandinos). Rio Muni (primarily
Fang), Europeans less than 1 ,0()0. mostly
Spanish
Religions: nominally Christian and
predominantly Roman Catholic, pagan
practices
Languages: Spanish (official), pidgin
English, Fang. Bubi. Ibo
Literacy: age 1 5 and over can read and write
(1990 est.)
total population: 50%
male: 64%
female: 37%
Labor force: 172,000 (1986 est.)
hv occupation: agriculture 66%, services 23%,
industry 11% (1980)
note: labor shortages on plantations; 58% of
population of working age (1985)','d62db783dc371a9f4271d0dc335fb0e20db17e349d3ff4d73556d9033170b07e','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac92f6220d7296406e5dff18c164afd9fe58ba30220a12f3dd15a7affcd935ed',1994,'ER','Eritrea','people-and-society',357,'Population: 3,782,543 (July 1994 est.)
Population growth rate: 3.4 1 % ( 1 994 est.)
Nationality:
noun: Eritrean(s)
adjective: Eritrean
Ethnic divisions: ethnic Tigrays 50%, Tigre
and Kunama 40%, Afar 4%, Saho (Red Sea
coast dwellers) 3%
Religions: Muslim, Coptic Christian. Roman
Catholic, Protestant
Languages: Tigre and Kunama, Cushitic
dialects, Tigre, Nora Sana, Arabic
Literacy:
total population; NA%
male: NA%
female: NA%
Labor force: NA','aa73219bc271ea7c1b627cdad82166abcbdd3c037c0889b74b284f5068b7b41c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee7bcbb29c42737f9db3cd7232cf068f8e89aa13dec82296464285d951f8d763',1994,'EE','Estonia','people-and-society',363,'Population: 1,616.882 (July 1994 est.)
Population growth rate: 0.52% ( 1994 est.)
Birth rate: 1 3.98 births/ 1 ,(X)0 population
(1 994 est.)
Death rate: 1 2 .04 deaths/ 1 ,000 population
(1994 est.)
Net migration rate: 3.29 migrant(s)/l ,000
population ( 1 994 est.)
Infant mortality rate: 1 9. 1 deaths/ 1 .000 live
births ( 1994 est.)
Life expectancy at birth:
total population; 69.96 years
mate; 64.98 years
female; 75.19 years (1994 .st.)
Total fertility rate: 2 children bom/woman
(1994 est.)
Nationality:
noun; Estonian(s)
adjective; Estonian
Ethnic divisions: Estonian 61.5%, Russian
30.3%. Ukrainian 3.17%, Bvelorussian 1.8%,
Finn 1.1%. other 2. 1,3% (1989)
Religions: Lutheran
Languages: Estonian (official), Latvian,
Lithuanian. Russian, other
Literacy: age 9-49 can read and write (1989)
total population; 100%
male; 100%
female; 100%
Labor force; 7,50.000(1992)
by occupation; industry and construction 42%,
agriculture and forestry 20%. other 38% (1990)','a3630e2bb7e48d6480a3d67722a6a4e4c6c0ab407b23321691c62b169f00d6c0','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bef5b380f41b1029a3bb988677f7338e1321df78e4b72717735e6ae44dbc1f96',1994,'MG','Madagascar','people-and-society',371,'Population: uninhabited
Population: uninhabited
Population: 10,564.630 (July 1994 est.)
Population growth rate: 0.84% (1994 est.)
Birth rate; 10.5 births/1 ,000 population
(1994 est.)
Death rate: 9.32 deaths/ 1, 000 population
(1994 e.st.)
Net migration rate; 7.21 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 8.6 deaths/ 1 ,000 live
births (1994 est.)
Life expectancy at birth:
wuil population: 77.71 years
male: 75.2 years
female: 80.35 years (1994 est.)
Total fertility rate: 1.45 children bom/
woman (1994 est.)
Nationality:
noun: Greck(s)
adjective: Greek
Ethnic divisions: Greek 98%, other 2%
note: the Greek Government states there are no
ethnic divisions in Greece
Religions: Greek Orthodox 98%. Muslim
1.3%, other 0.7%
Languages; Greek (official), English, French
Literacy: age 15 and over can read and write
(1990 est.)
total population: 93%
male: 98%
female: 89%
Labor force: 4.083 million
hy occupation: services 48%, agriculture 24%.
industry 28% (1993)
Population: uninhabited
Population: 1 7,267,554 (July 1994 esi.)
Population growth rate: O.M''/r (1994 est.)
Birth rate: 19.4 births/I ,(XX) population
(1994 est.)
Death rate: 7.9.^ deaths/I, OCX) population
(1994 est.)
Net migration rate: -5.09 migrant(s)/l.00fl
population (1994 est.)
Infant mortality rate: 40.9 dculhs/l.(KK) live
births (1994 est.)
Life expectancy at birth:
lolal iwpidalion: 68.04 years
mule: 6.V.^9 years
female: 72.9.1 years (1994 est.)
Total fertility rate: 2.44 children born/
woman (1994 est.)
Nationality:
mnm: Kazukh.stani(s)
adjective: Kazakhstani
Pthnic divisions: Kazakh (Qazaq) 4 1 .9%.
Russian ^T7c, Ukrainian ^.2^/r. German 4.7‘/(''.
Uzbek 2. 1 Vr . Tatar 2%. other 7. T/i. ( 1 99 1
official data)
Religions: Muslim 47%. Russian Orthodox
44%, Protestant 2%. other 7%-
Languages: Kazakh (Qazaqz) official
language spoken by over 4()9( of population,
Russian (language of interethnic
communication) spoken by two-thirds of
population and u.scd in everyday business
Literacy: age 9-49 can read and write (1970)
total population: I (X)%
male: i(X)%
female: lOO''/r
Labor force: 7. ,1.56 million
In occupation: industry and construction 1 1 ''/<■,
agriculture and forestry 26''1 , other 41% ( 1 992 )
Population; 13,427,758 (July I994est.)
Population growth rale: 3.19% (1994 est.)
Birth rate: 45.22 birth.s/l,(){X] population
(1994 est.)
Death rate: 1 3.35 deaths/I ,000 population
(1994 est.)
Net migration rate: 0 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 89 deaths/I .000 live
births (1994 e.st.)
Life expectancy at birth:
total population: 53.98 years
male: 52.06 years
female: 55.96 years (1994 est.)
Total fertility rate: 6.6S children born/
woman (1 994 est.)
Nationality:
noun: Malagasy (singular and plural)
adjective: Malagasy
Ethnic divisions: Malayo-Indonesian
(Merina and related Betsileo), Cotiers (mixed
African. Malayo-Indonesian, and Arab
ancestry — Betsimisaraka. Tsimihety,
Antaisaka, .Sakalava), French. Indian, Creole,
Comoran
Religions: indigenous beliefs 52%, Christian
41%, Muslim 7%
Languages: French (ofricial), Malagasy
(ofricial)
Literacy; age 15 and over can read and write
(1990 est.)
total population: 80%
male: 88%
female: 73%
Labor force: 4.9 million 90% nonsalaried
family workers engaged in subsistence
agriculture: 1 75,0()0 wage earners
by occupation: agriculture 26%. domestic
service 17%, industry 15%, commerce 14%.
construction 1 1 %, services 9%. transportation
6%, other 2%
note: 5 1 % of population of working age ( 1 985)
Population: 1 7..746,280 (July 1994 est.)
Population growth rate: 5.87% (1994 est.)
Birth rate: 44.97 birth.s/I.OOO population
(1 994 est.)
Death rate: 16.3.7 deaths/I .OBO population
(1994 est.)
Net migration rate: .70.1 migrant(s)/t.0fX)
population (1994 est.)
Infant mortality rate: 1 28.7 death.s/ 1 .000
live births (1994 est.)
Life expectancy at birth:
total impiilation: 48.49 years
male: 46.6.7 years
female; .50.4 1 years ( 1994 e.st.)
Total fertility rate: 6.25 children
bom/woman (1994 est.)
Nationality:
noun: Muzambican(s)
adjective: Mozambican
Ethnic divisions: indigenous tribal groups,
Europeans about 10,000. Euro-Africans
35.000. Indians 15.000
Religions; indigenous beliefs 60%, Christian
.70%, Mdslim 10%
Languages: Portugue.se (ofllcial). indigenous
dialects
Literacy; age 15 and over can read and write
(1990 est.)
total population: 33%
male: 45%
female; 2 1 %
Labor force: NA
hy occupation: 90% engaged in agriculture','fdecb00de159a0f7ade48417e2f4201e97b4023f0f69c9435248af963e5dcab3','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e7f28fa4f0f0855a8db4067c0eb5e85c8a739ea5bbae433817d28f36b0f4aa2',1994,'AR','Argentina','people-and-society',373,'Population: 2,261 (July 1994 est.)
128
Population growth rate; 2.43% (1994 est.)
Birth rate: NA
Death rate: NA
Net migration rate: NA
Infant mortality rate: NA
Life expectancy at birth: NA
Total fertility rate: NA
Nationality:
noun: Falkland Islander(s)
adjective: Falkland Island
Ethnic divisions: British
Religions: primarily Anglican, Roman
Catholic. United Free Church, Evangelist
Church, Jehovah’s Witnesses, Lutheran,
Seventh-Day Adventist
Languages: English
Literacy:
total population: NA%
male: NA%
female: NA%
Labor force; l,l(X)(est.)
hy occupation: agriculture 95% (mostly
sheepherding)','930433f493a2eacb97042a38a1b239912b3350cab0a8a363215fb51f9afe3ffe','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52ac20b47df4b0a4ef833c9a086e083c96c86ccccf86457181beb36fcd135276',1994,'FO','Faroe Islands','people-and-society',378,'Population: 48,427 (July 1994 est.)
Population growth rate: 0.83% (1994 est.)
Birth rate: 1 7.97 births/ 1 ,000 population
(1994 est.)
Death rate: 7.56 deaths/ 1 ,000 population
(1994 est.)
Net migration rate: -2.09 migrant(s)/ 1,000
population (1994 est.)
Infant mortality rate: 8.1 deaths/1,000 live
births (1994 est.)
Life expectancy at birth:
total population: 78.1 years
male: 74.7 1 years
female: 8 1 .62 years ( 1 994 est.)
Total fertility rate: 2.47 children bom/
woman (1994 est.)
Nationality:
noun: Faroese (singular and plural)
adjective: Faroese
Ethnic divisions: Scandinavian
Religions: Evangelical Lutheran
Languages: Faroese (derived from Old
Norse), Danish
Literacy:
total population: NA%
male: NA%
female: NA%
Labor force: 17,585
by occupation: largely engaged in fishing,
manufacturing, transportation, and commerce','fcbe0a4b15d8d8db2f94f9ecaf625dc161d5f004961de2f1b8043b395c2e7cc1','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83805ed4ff919991ec513b8990136e2285ad84ee66807101b9f6467ce2e9a05d',1994,'JE','Jersey','people-and-society',385,'Population: 764,382 (July 1994 est.)
131
FUi (continued)
Population growth rate; 1 .05% ( 1 994 est.)
Birth rate; 24. 1 8 births/ 1 ,000 population
(1994 est.)
Death rate: 6.5 deaths/ 1, 0(X) population
(1994 est.)
Net migration rate: -7. IS migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 18.1 deaths/I ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 65. 14 years
male: 62.88 years
female: 67.51 years (1994 est.)
Total fertility rate: 2.92 children bom/
woman (1994 est.)
Nationality;
noun: Fijian(s)
adjective: Fijian
Ethnic divisions: Fijian 49%, Indian 46%.
European, other Pacific Islanders, overseas
Chinese, and other 5%
Religions; Christian 52% (Methodist 37%,
Roman Catholic 9%), Hindu 38%, Muslim 8%,
other 2%
note: Fijians are mainly Christian, Indians are
Hindu, and there is a Muslim minority ( 1986)
Languages: English (official). Fijian.
Hindustani
Literacy: age 15 and over can read and write
(1985 est.)
total population: 86%
male: 90%
female: 8 1 %
Labor force: 235,000
by occupation: subsistence agriculture 67%,
wage earners 18%, salary earners 15% (1987)
Population; 86,048 (July 1994 est.)
Population growth rate: 0.7*^ ( 1 994 est. )
Birthrate: 12.81 births/ 1, (XK) population
(1994 est.)
Death rate; 1 0. 1 deaths/ 1 .(XX) population
(1994 est.)
Net migration rate: 4.25 migrant(s)/l.000
population ( 1 994 est.)
Infant mortality rate; 4.7 deaths/l,0(X) live
births (1994 e.st.)
Life expectancy at birth:
total population; 76,64 years
male; 73.54 years
female; 80.09 years (1994 est.)
Total fertility rate: 1 .43 children bom/
woman (1 994 est,)
Nationality;
noun; Channel Islanderfs)
adjective; Channel Islander
Ethnic divisions: UK and Norman-French
descent
Religions: Anglican, Roman Catholic.
Baptist, Congregational New Church,
Methodist, Presbyterian
Languages: English (official), French
(ufTicial). Norman-French dialect spoken in
country districts
Literacy:
total population; NAOt
male; NA^
female; NA9(''
Labor force; NA
Population! 327 (July l'')94cst.)
Population: 1,819,322 (July 1994 e.si.)
Population growth rate: 5.24<;f (1994 est.)
note: this rate reflects the continued ptist-Gulf
crisis return of nationals and expatriates
Birth rate: 29.43 biith.s/1 ,000 population
(1994 est.)
Death rate: 2.37 deaths/ 1.000 population
(1994 e.si.)
Net migration rate: 25.35 migrant(s)/l.0(X)
population ( 1994 est.)
Infant mortality rate: 1 2.5 deaths/I ,000 live
births ( 1994 est.)
Life expectancy at birth:
total population: 74.99 years
male: 72.83 years
female: 77.25 years (1994 est.)
Total fertility rate: 4 children bom/woman
(1994 est.)
Nationality;
noun: Kuwaili(s)
(uijective: Kuwaiti
Ethnic divisions: Kuwaiti 45%. other Arab
35%’, South Asian 9%, Iranian 4%, other 7%
Reiigions: Muslim 85% (Shi’a .30%, Sunni
45%, other 10%), Christian. Hindu. Pursi, and
other 15%
Languages; Arabic (official). English widely
spviken
Literacy: age 1 5 and over cun read and write
(1990 est.)
total iwpulation: 73%
male: 77%
female: 67%
Labor force: ,566.(X)0(1986)
by <Hru/kition: .services 45.0%. construction
20.0%, trade 12,0%, manufacturing 8.6%.
finance and real estate 2.6%, agriculture 1 ,9%,
power and water 1.7%, mining and quarrying
1.4%
note: 70%- of laKir force non- Kuwaiti ( 1986)
Popnlaliun: IHI..f00(July lv*J4cst.)
Population growth rale: I ( 1404 est. i
Birth rale: 22. .14 hirths/I.OIM) population
(1494 est. I
Death rate: 4.% deaths/ 1 .(NX) population
(1494 est.)
Net migration rate: 0.44 migrant(s)/l.(XN)
population ( 1494 est. )
Infant mortality rate: 15. 1 deaths/I.IXX) live
births (1994 est.)
Life expectancy at birth:
total population: 73.62 years
male: 70.32 years
female; 77.09 years (1994 est.)
Total fertility rate: 2.62 children
bom/woman (1994 est.)
Nationality:
noun: New Caledonian(s)
adjective; New Caledonian
Ethnic divisions; Melanesian 42.5%,
European .37.1%, Wallisian 8.4%, Polynesian
3.8%, Indonesian 3.6%, Vietnamese 1.6%,
other 3%
Religions: Roman Catholic 60%, Protestant
.30%. other 10%
Languages: French. 28 Melane.sian-
Polynesian dialects
Literacy: age 15 and over can read and write
(1476)
total population: 9 1 %
m«/e. 91%
female: 90%
Ijibor force: .50.469 foreign workers for
plantations and mines from Wallis and Futuna.
Vanuatu, and French Polynesia (1480 est.)
hy occupation; NA
Population: 1,972,227 (July 1994 est.)
Population growth rate: 0.23% (1994 est.)
Birth rate: 1 1 .8 1 births/I ,000 population
(1994 est.)
Death rate: 9.5 deaths/1,000 population
(1994 est.)
Net migration rate: 0 migrant(s)/l,000
population (1994 est.)
Inllint mortality rate: 8.1 deaths/ 1, 0(X) live
births ( 1 994 est.)
Life expectancy at birth:
total population; 74.36 years
male; 70.49 years
female; 78.44 years (1994 est.)
Total fertility rate: 1 .67 children bcm/
woman (1994 est.)
Nationality:
noun: Slovene(s)
adjective; Slovenian
Ethnic divisions; Slovene 91 %. Croat 3%.
Serb 2%, Muslim 1%. other 3%
Religions; Roman Catholic 96% (including
2% Uniate). Muslim I %. other 3%
Languages: Slovenian 91%. Serbo-Croatian
7%. other 2%
Literacy;
total population; N.A%
male; NA%
female; NA%
Labor force: 786,036
by occupation; agriculture 2%, manufacturing
and mining 46%
Population: 936.369 (July 1994 est.)
Population growth rate: 3.2 1% (1994 est.)
Birth rate: 43. 1 4 birth.s/l ,000 population
(1994 est.)
Death rate: 1 1 .07 deaths/ 1 ,0(X) population
(1994 est.)
Net migration rate: 0 niigrant(s)/l ,000
population (1994 est.)
Intent mortality rate: 93.2 deaths/ 1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 56.39 years
male: 52.4 years
female: 60.5 years (1994 est.)
Total fertility rate: 6. 1 3 children
bom/woman (1994 est.)
Nationality:
noun: Swazi(s)
adjective: Swazi
Ethnic divisions: African 97%, European 3%
Religions: Christian 60%, indigenous beliefs
40%
Languages: English (official; government
business conducted in English). siSwati
(official)
Literacy: age 15 and over can read and write
(1986)
total population; 67%
male; 10%
female: 65%
Labor force: probably less than 100,(X)0 are
wage earners
hy occupation: about 65% in the private sector
and 35% in the public sector','8ce643cafa1c38d43928c8d077e6b11f09e3cf05da276820bc2eec0139e4f047','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07e762140ad10102759573f046136dc66a05ffe7c034fc714c660a7d24e4bf64',1994,'FI','Finland','people-and-society',392,'Population: 5,068,931 (July 1994 e.st.)
Population growth rate: 0.34% (1994 est.)
Birthrate: 12.41 births/l,0(X) population
(1994 e.st.)
Death rate: 9.84 deaths/I ,0(X) population
(1994 est.)
Net migration rate: 0.81 migrant(s)/l,(XX)
population (1994 est.)
Infant mortality rate: 5.3 deaths/ 1. (XX) live
binhs (1994 est, )
Life expectancy at birth:
total population: 75.93 years
male: 72, 18 years
female: 79.86 years (1994 est.)
Total fertility rate: 1 .79 children born/
woman (1994 est.)
Nationality:
noun: Finn(s)
adjective: Finnish
Ethnic divisions; Finn, Swede, Lapp. Gypsy.
Tatar
Religions: Evangelical Lutheran 89%, Greek
Orthtnlox 1%, none 9%, other 1%
Languages: Finnish 93.5% (official),
Swedish 6.3% (official), small Lapp- and
Russian-speaking minorities
Literacy: age IS and over can read and write
(1980 est.)
total population: 100%
male: NA%
female: NA%
Labor force; 2.533 million
by occupation: public services 30.4%, industry
20.9%. commerce 15.0%, finance, insurance,
and business services 10.2%, agriculture and
forestry 8.6%. transport and communications
7.7%. construction 7.2%
.378
Capital! Stockholm
Administrative divisions: 24 provinces (Ian,
singular and plural); AIvsborgs Lan. Blekinge
Lan, Gavleborgs Lan, Goteborgs och Bohus
Lan, Gotlands Lan, Hallands Lan, Jamtiands
Lan, Jonkopings Lan, Kalmar Lan,
Kopparbergs Lan, Kristianstads Lan,
Kronobergs Lan, Malmohus Lan, Norrbottens
Lan, Orebro Lan, Ostergotlands Lan,
Skaraborgs Lan, Sodermanlands Lan,
Stockholms Lan, Uppsala Lan, Varmlands
Lan, Vasterbottens Lan, Vastemoniands Lan,
Vastmanlands Lan
Independence: 6 June 1809 (constitutional
monarchy established)
National holiday: Day of the Swedish Flag. 6
June
Constitution: I Januaiy I97S
Legal system; civil law system influenced by
customary law; accepts compulsory ICJ
jurisdiction, with reservations
Suffrage: 1 8 years of age; universal
Executive branch:
chief of suite: King CARL XVI GUSTAF
(since 19 September 197.^); Heir Apparent
Princess VICTORIA Ingrid Alice Desiree,
daughterof the King (him 14 July 1977)
he<i<l of Kovernmeni: Prime Minister Curl
BILDl'' (since October 1991 ); Deputy PrinK
Minister Bengt WESTERBERG (since NA»
cahinet: Cabinet; appointed by the prime
minister
Leidslative branch: unicameral
IHtrliament (Hiksdaiif- elections last held 15
September 1991 (next to be held NA
September 1994); results — Swial Democratic
Party .t7.b‘‘/f. Moderate Party (conservative)
2 1 .W . Liberal People''s Party 9. 1 ''r. Center
Party 8.59i-, Christian DenuK''rats 7.l‘''4. New
Derntx''racy 6.7*;^. Left Party (Communist)
4.5*^. Green Party .^.4C(. other 1.2''^^; seats —
(.149 total) .StK''ial DemiK’ratic 1.18. MtHlenite
Pany (conservative) 80. Liberal People''s Party
.1.1. Center Party .11. Christian DemiKrais 2b.
New DctiKKTUcy 25. Left Party (Communist)
16; note— the Green Party has no seats in the
Riksdag because it received less than the
required 4‘''/f of the vote
Judirial brunch: Supreme Court tHogstu
Domsiolen)
Polllical purlfes and lenders: ruling four-
party coalition consists of Moderate Party
(conservative), Carl BILDT; Liberal People''s
Party, Bengt WESTERBERG; Center Party.
Olof JOHANSSON; and the Christian
OemtKTatic Party. Alf SVENSSON; SiKial
DenuKTatic Party. IngvarCARLSSON; New-
IX''nKK-racy Party. Harriet COLLIANDER;
Ix’ft Party (VP; Communist). Gudrun
SCHYMAN; Communist Workers'' Party. Rolf
HAGEL; Green Party, no formal leader
Member of: AfDB. AG tttbserver). AsDB.
Australian Grtnip. BIS. CBSS, CCC. CE.
CERN.CfX-OM (cotqteratingl.C''SCE. EBRD.
ECE. EFTA. ESA. F.AO. G-6, G-8. G-9, G- 10.
GATT, lADB. IAEA. IBRD. ICAO. ICC.
ICFTU, IDA, lEA, IFAD, IFC, ILO, IMF,
IMO, INMARSAT, INTERPOL, INTELSAT,
IOC, lOM. ISO, ITU, LORCS, MTRC, NAM
(guest), NC, NEA, NIB, NSG. OECD,
ONUSAL, PCA, UN, UNAVEM II,
UNCTAD. UNESCO. UNFICYP. UNHCR.
UNIDO, UNIFIL. UNIKOM. UNMOGIP,
UNOMIG. UNOMOZ. UNOSOM.
UNPROFOR. UNTAC. UNTSO. UPU.
WFTU, WHO, WIPO. WMO. ZC
Diplomatic representation in US:
chief of missitm: Ambassador Carl Henrik
LIUEGREN
chancery; Suites 1200 and 715, 600 New
Hampshire Avenue NW, Washington, DC
2(KI37
telephone; (202) 944-5600
MX.- (202) .142-1.119
consulute(s) general; Los Angeles and New
York
US diplomatic repreaentulion:
chief of mission: Ambassador Thomas
SIEBERT
embassy; Strandvagen 101 . S-l 15 89
Stockholm
nuiiling address: use embassy street address
telephone; (461 (8) 78.1-5.100
M,Y. (461(8)661-1964
Flag: blue with a yellow cross that extends to
the edges of the flag; the vertical putt of the
crxtss is shifted to the hoist side in the style of
the Dannebrog (Danish flag)
Population: 7,040,1 19 (July 1994 est.)
Population growth rate: 0.7% ( 1994 est.)
Birth rate: 1 2.2.7 births/I .0(K) population
(1994 est.)
Death rate: 9.2 deaths/ L(XN) population
(1994 est.)
Net migration rate: .7.97 migrants)/ 1, (XX)
population (1994 est.)
Infant mortality rate: b..*! deaths/ 1 ,(XK) live
births (1994 est.)
I Jfe expectancy at birth:
lohil ih>imUiiwn: 7X. 1 7 years
rmi/i*; 74.8 years
J''rmilf: 81.71 years ( 1994 es|.)
Total fertility rate: 1 .0 children bom/womun
(1994 est. I
Nationality:
noun: .Swiss (singular and plural)
Swiss
Kthnic dlvMaiK:
urn! ptipuluiitm: (lerman h.S%, French 18''* .
Italian in''* . Kotnansch I . other b<*
Swiss nuiiomils: Cicmian 74''*''. French 20**.
Italian 4''.*. Koniiinsch I**, mlrer l‘*
ReHgionx; Konian (''utholic 47.6''* , Pnxesiunt
44 .V*. other 8. 1''* (19801
loHiguages: (iemian 6.t''* , Freiwh 18** .
Italian 1 2''* . Romansch I''* . «Hher 4''*
niilr: figure''s for .Swiss nationals only -
(iemian 74‘* . Fivnch 20** . Italian 4** .
Koniansch I ''* . other I ''*
Literacy; age 1.7 ami over can read and write
(|9Kt)est )
liHiil iMtimlmiim: 99**
nuilr: NA‘*
ft''HMif NA''i
Ijibor force; .7..'' I million (904.095 foreign
workers, imistl) Italian i
hs iHvuihiiuHi: services .''O''* , industry and
crafts .7.7''* , govemiiK''iit lOS . agriculture and
forestry 6''» . other I''i 1 1989)
(■ovemment
Names:
I iim-ftiliimiil /ling lonn: Swiss (''onfedcration
l omriitiimal shurt form: Switzerland
liH fil liHiK /firm: Schwci/erische
l-idgenosseiischuft ((iemian) Confederation
Suisse (FreiK-h){ \\>iifedera/.ioiie Svi/zera
(lialiuti)
/iH iil short /omi: Schweiz ((ieniiaiil Suisse
(French) Svizzera (Italian)
Digraph: SZ
Type: federal republic
Capital: Bern
Administrative divisions: 26 cantons
(contons, singular — canton in French; cuntoni.
singular — cantone in Italian; kantonc,
singular — kanton in Gemian); Aargau. Ausser-
Rhoden, Basel-Landschaft. Busel-Stadt, Bern,
Fribourg. Geneve, Glarus, Gruubunden. Inner-
Rhoden, Jura. Luzern. Ncuchatcl. Nidwulden.
Obwalden, Sunki Gullen. Schaffhuu.sen,
Schwyz, Sniothum. Thurgau. Ticino. Uri.
Valais, Vaud, Zug, Zurich
Independence: I August 1291
National holiday: Anniversary of the
Founding of the Swiss Confederation, I
August (1291)
Constitution: 29 May 1 874
latgai system: civil law system intluenced by
customary law; Judicial review of legislative
acts, except with respc''ci to lederal decrees of
general obligatory character; accepts
compulsory ICJ jurisdiction, w ith les'' rvations
SufTFagr: 1 8 years of age; universal
Kxccutive branch:
i hU-f of slaw ami head of itovenimvni:
President Otto STICH ( i994 calendar year;
presidency rotates annually); Vice President
Kaspjir VILLICiER (term runs concurrently
with that of president)
aihiwi: Federal Council (Gemtan—
Runde.smt. French— Cense: I Federal,
Italian— (''mtsiglio Federulei; elected by the
Fetierul Assembly Iroin ow i, nH’mhers
latgishrtive branch: bicameral Federal
Assembly (Gemtan — Bundesversainmlung.
French — Assemhiee Federale, Italian- -
Asscmbleii Federale)
Coutifil tf Staffs: (( iemian -Stunderat.
French — Conseil des l-tuts. Italian— Consigho
degli Siati) eicctums Iasi held ibmughoui 1991
(m''xt toK'' held NA 1 995); results— percent of
vtUc l>\\ (xirtv NA. scats (46 total) FI>P 18.
CVP 16. SVP4. SPS .7. UI*S .7. Ldl'' I. Ticino
League I
S''aiiotuil Comn il: (Gemian - Nuiumalrat.
French— (''onseil National. Italian (''onsiglio
Nazioiiale) elections lust held 2()(Vtoher 1991
(next to he held NA (Xtober 1995 1; results-
percent of vole by jiartv N A; seats - ( 2(X) uual )
F1>P 44. SPS 42. CVP 77. SVP 25. GPS 14.
I.PS 10. AP 8. Ldl'' 6, Sl> 5. 1 VP 7. IMA 2.
Ticino l4.‘ague 2. other 2
Judlrial branch: Federal Suprenw'' Coun
PuMical partlm and Icadm: Fret''
IViiMK''rutic Party (l''T)P). Bnino lU''NZIKER,
presiileni; Social iX''nHKTUtic Party (SPS).
Helmut Hl''HA(''HliR. chairman; Christian
IX''m<K-ratic Peopkr''s Parts (CVP), l-va
SEGMliLI.ER WFBF.R.''chainnan; Swiss
IVople s Party (SVP). Hans I''HLMANN.
president; Green Party (GPS). IVter SCHMID,
president'' Automobile Party ( AP). DREYER;
Alli;im-e of Independents'' Party (lalC), IX.
Franz J.AEGER. president; Swiss Demivrutic
Party (SDi. NA; Evangelical People’s Party
(EVP), Max DUNKI. president; Workers''
Party (PdA; Communist). Jean SPIELMANN,
general secretary: Ticino League, leader NA;
Liberal Party (LPS). Gilbert COUTAU.
president
Member of: AfDB, AG (observer), AsDB.
Australian Group. BIS. CCC. CE. CERN.
COCOM (cotipcraling), CSCE. EBRD. ECE.
EFTA. ESA. FAO. G-8. G-IO. GATT. lADB.
IAEA. IBRD. ICAO. ICC. ICFTU, IDA. lEA.
IFAD. IFC. ILO. IMF. IMO. INMARSAT.
INTELSAT, INTERPOL, KX?. lOM. ISO,
ITU. LORCS. MINURSO. MTRC. NAM
(guest). NEA, NSG, OAS (observer). OECD.
PCA, UN (observer). UNCTAD. UNESCO.
UNHCR, UNIDO. UNOMIG. UNPROFOR,
UNTSO, UPU. WCL. WHO, WIPO. WMO.
WTO. ZC
Diplomatic reprcsentalitm in US:
chief of mission: Ambassador Carlo
JA(jMETTl
chancery; 29(X) Cathedral Avenue NW.
Washington. IX'' 2(XX)8
tf if phone: (202) 74.5- 79(X)
FAX: (202). 787-2.564
< tmsalatfisi fteneral: Atlanta. Chicago,
Houston. Los Angeles, New York, and Sun
Francisco
US diptomatic reprenentalion:
chief tf mission: ( vucuiit); Charge d'' Affaires
Michael C. P(JLT
emhassy: Jubilacumstrassc 9.7, .7(X).5 Bern
maih''tif; adihvss: use embussv street address
telephone: |4 1 ) (71 ) .757-7011
M.V.'' |4I I (71 ). 7.57-7,744
hrimeh ofliee: OeiK''va
consulaiti v) neneral: Zurich
Flag: led square w iih u bold, equilateral w hile
cross ill the center that does not extend to the
edges of the Hag
Kconomy
(Kerview: Switzerlaml''s economy — one of
the imist preisperiHis and stable in the world —
is mmetheless undergoing a painful adjustment
after biuh the innuiittnury btHUn of the
Iate-I98(K and the electorate''s rejection **f
iiK''nibcrship in tin.'' European Economic Area
in 1992. The Swiss finally emergc''d from a
three-year rvcessiim in mid- 1 997 and posted a
-AYtt''i GDP grow th for the year. After u three-
year stmgglc w ith inllaiion, the Sw iss central
bank''s tight monetary policies have begun to
pay off. liiHation slowed to 7.7''* in 1997 frenn
about 4''* in I ‘W2 and is expected to slow ikiwn
funherio 1.5''* in 1994, linemploynicnt.
however, w ill continue to be a problem over
(be near tenn. Swiss unemployment reached
5.1''* in 1997 and will likely remain at that
level through 1994 before declining in 1995,
The voters'' rejection of a referendum on
nx’mbership in the EEA. which was supported
by most political, business, and financial
leaders has raised doubts that (be country cun
Switierland (amiinuedi
Syria
maintain its preeminent prosperity and
leadership in commercial hanking in the
twenty-first century. Despite these problems,
Swiss per capita output, general living
standards, education and science, health care,
and diet rentain unsurpassed in Eurttpe. The
country has tew natural resources except for
the scenic natural beauty that has made it a
world leader in tourism. Management-labtir
relations remain generally harmonious.
National product: GDP — purchasing power
equivalent — $149.1 billion (199^)
National product real growth rate: -0.6<''/l''
(199.1)
National pr^iict per capita: $21. .100
(1903)
Inflation rate (consumer prices): l.lOf
(1993 est.)
Lnemployment rate: S.l^ (1993 est.)
Budget:
revemivs; $23.7 billion
exiwndiiurrs: $26.9 billion, including capital
expenditures of $NA (1993 est.)
Exports: $63 billion (f.o.b,, 1993)
commttdiiies: machinery and equipment,
precision instruments, metal products.
tVyrdstuffs. textiles and clothing
/wrmcr.w Western Europe 6.1. 191 (EC
countries ,‘i69i-, other 7.1%), US 8,8%. Japan
.1.4%
Imports: $<>0.7 billion (c.i.f., 1993)
amiimxlities: agricultural products, machinery
and transportation equipment, chemicals,
tc.xtilcs. construction materials
IHirmers; Western Europe 79,2% (EC
countries 72.3%. other 6.9%), US 6.4%
Externa) debt: SNA
Industrial production; growth rate 0.0%
( 1993 est.)
Elect ricitv:
catwdry.- 17.7l().(XK)kW
pnHliu tiim: .S6 billion kWh
anisiimptioii per capita: 8.200 kWh ( 1992)
Industries: machinery, chemicals, watches,
textiles, precision instruments
Agriculture: dairy farming predominates;
less than .S()% self-sufficient in food; must
import fish, refined sugar, fats and oils (other
than butter), grains, eggs, fruits, vegetables,
meat
Illicit drugs: money-laundering center
Economic aid:
donor: ODA and OOF commitments ( |97(F
89), SI,.*! billion
Currency: 1 Swiss franc, franken, or franco
(SwF)= l(K) centimes, rappen. or centesimi
Exchange rates: Swiss francs, franken. or
franchi (SwF) per U.SSI — I.7I.S (January
1994). 1.4776(199,1). 1.4062(1992). 1.4.140
(1991). I..1892(|99()), 1.6.1.‘i9 ( 1989)
Fiscal year: calendar year','c4c955bf2339a100fcddbee5e0a71cb9768becde67e7d537398187f19acbc43b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cecb7e8bbf5823b32977dd12cda9c25c9aa9c57db8568ef31ed5dd4702d681f',1994,'DE','Germany','people-and-society',399,'Population: 57.840,445 (July I9‘:4est.)
Population growth rate; 0.47% (1994 est.)
Birth i''.rte: 13.13 b’lhs/l.OOO population
(1474 est.)
Dea''h rate: 9.3 deaths/ 1,000 population
(1994 est.)
Net migration rate; 0.86 migrant(s)/l ,0(X)
population (1994 est.)
Infant mortality rate: 6.6 deaths/I ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 78.19 years
male: 74.27 years
female: 82.3 years (1994 est.)
Total fertility rate: 1 .8 children born/woman
(1994 est.)
Nationality:
noun: Frenchman(men),
Frenchwoman(women)
adjective: French
Ethnic divisions; Celtic and Latin with
Teutonic, Slavic, North African, Indochinese,
Basque minorities
Religions: Roman Catholic 90%. Protestant
2%, Jewish 1%, Muslim (North African
workers) 1%, unaffiliated 6%
Languages: French 1(X)%. rapidly declining
regional dialects and languages (Provencal,
Breton. Alsatian, Corsican, Catalan. Basque,
Flemish)
Literacy: age 15 and over can read and write
(I980e.st.)
total population: 99%
male: NA%
female: NA%
Labor force: 24.17 million
by occupation: services 61.5%. industry
,31,3%, agriculture 7.2% (1987)
1.35
France (continued)
Population: 81,087.506 (July I994est.)
Population growth rate: 0.36% (1994 est.)
Birth rate: 1 1 .04 births/I .(XK) population
(1994 est.)
Death rate: 10.89 deaths/1,000 population
(1994 est.)
Net migration rate: 3.39 migrant(s)/l,00()
population (1994 est.)
Infant mortality rate: 6.5 deaths/ 1 .000 live
births (1994 est.)
Life expectancy at birth;
total population: 76.34 years
male: 73.22 years
female: 79.64 years (1994 est.)
Totai fertility rate: 1 .47 children bom/
woman (1994 est.)
Nationality:
noun: German(s)
adjective: German
Ethnic divisions: German 95.1%, Turkish
2.3%, Italians 0.7%, Greeks 0.4%, Poles 0.4%,
other 1.1% (made up largely of people fleeing
the war in the former Yugoslavia)
Religions; Protestant 45%. Roman Catholic
37%, unaffiliated or other 18%
Languages; German
Literacy: age 15 and over can read and write
(1977 est.)
total population: 99%
male: NA%
female: NA%
Labor force: 36.75 million
by occupation: industry 41%, agriculture 6%,
other 53% (1987)','08c6327df8701d74696b73060dccf14308437eff8f76e32ce53ffd72f7fb0f85','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef4e1ce833afd67e9ed041514f07cf0da1f2850edc474ffd08e792f93abaa8b1',1994,'GF','French Guiana','people-and-society',404,'Population: 139,299 (July 1994 est.)
Papulation growth rale: 4.27% ( 1 9^ est.)
Birth rate; 25.83 births/ 1 ,000 population
(1994 est.)
Death rate: 4.67 deaths/I, 0(X) population
(1994 est.)
137
French Guiana (continued)
Net migration rate; 2 1 .54 migrani(s)/ 1 ,000
population (1 994 esi.)
inta :;t mortality rate; I S.9 deaths/ 1 .000 live
birth- (I994est.)
Life expectancy at birth;
total population: 75.2 years
male: 71.93 years
female: 78.63 years (1994 est.)
Total fertility rate; 3.5 children bom/woman
(1994 est.)
Nationality;
noun: French Guianese (singular and plural)
adjective: French Guianese
Ethnic divisions; black or mulatto 66%,
Caucasian 12%, East Indian, Chine.se.
Amerindian 12%, other 10%
Religions: Roman Catholic
Languages: French
Literacy: age IS and over can read and write
(1982)
total population: 82%
male: 81%
female: 83%
Labor force: 23,265
by occupation: services, government, and
commerce 60.6%. industry 21.2%. agriculture
18.2% (1980)','2f2676d7cf788e2ecc32157997d325ec7295da5b6bd9c34ac8510e79a9194bc5','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e4b77bf3920b74c7fa52a1f89cdf7eec84ad1af3c49736b0802f837ec6b8972',1994,'PF','French Polynesia','people-and-society',409,'Population: 215,129 (July 1994 est.)
Population growth rate: 2.25% ( 19^ est.)
Birth rate: 27.75 births/ 1,000 population
(1994 est.,
Death rate: S.27 deaths/ 1, 000 population
(I994e.st.)
Net migration rate: 0 migrant(s)/l,000
population (1994 est.)
Inflint mortality rate: 1 4.8 deaths/ 1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 70.54 years
malt: 68.14 years
female: 73.06 years ( 1 994 est.)
Total fertility rate: 3.31 children bom/
woman ( 1994 est.)
Nationality:
noun: French Polynesian(s)
adjective: French Polynesian
Ethnic divisions: Polynesian 78%, Chinese
12%, local French 6%, metropolitan French
4%
Religions: Protestant 54%, Roman Catholic
30%. other 16%
Languages: French (ofTicial), Tahitian
(official)
Literacy: age 14 and over but definition of
literacy not available (1977)
total population: 98%
male: 98%
female: 98%
Labor force: 76.630 employed ( 1 988)
Population: no indigenous inhabitants;
note — there are researchere whose numbers
vary from 150 in winter (July) to 200 in
summer (January)','38f81c7933d722cf3639049d9c371caca8d69a238f1777ad31a9448081bd5f34','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97fcde2540daf8f13515c2b393da91e5a9bdfed8253d1014b7c184838fc48fad',1994,'GA','Gabon','people-and-society',414,'Population: 1 , 1 39,006 (July 1994 est.)
Population growth rate: 1 .46% ( 1 994 est. )
Birth rate: 28.46 births/1,000 population
(1994 est.)
Death rate: 13.9 deaths/ 1 ,(KX) population
(1994 est.)
Net migration rate; 0 migrant(s)/l,(XX)
population (1994 est.)
Infant mortality rate: 94.8 death.s/1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 54.67 years
male: 5 1 .88 years
female: 57.53 years (1994 est.)
Total fertility rate: 3.97 children bom/
woman (1994 est.)
Nationality:
noun: Gabonese (singular and plural)
adjective: Gabonese
Ethnic divisions: Bantu tribes including four
major tribal groupings (Fang, Eshira,
Bapounou. Bateke). Africans and Europeans
lOO.OtX), including 27,000 French
Religions: Christian 55-75%, Muslim less
than 1%. animist
Languages; French (official). Fang. Myene,
Bateke, Bapounou/Eschira, Bandjabi
Literacy: age 15 and over can read and write
(1990 est.)
total population: 6 1 %
male: 74%
female: 48%
Labor force: 1 20.0(X) salaried
by occupation: agriculture 65.0%. industry
and commerce .30.0%. services 2.5%.
government 2.5%
note; 58% of population of worki ng age (1983)
Population: 959,3(X) (July 1994 est.)
Population growth rate: 3.08% ( i 994 est.)
Birth rate: 46.39 births/1,000 population
(1994 est.)
Death rate: 13.64 deaths/1 ,000 population
(i 994 est.)
Net migration rate: 0 migrant(s)/l ,000
population (1994 est.)
Infant mortality rate: 123.3 deaths/ 1 ,000
live births (1994 est.)
Life expectancy at birth:
total population: 30.08 years
mate: 47.83 years
female: 52.39 years (1 994 est.)
Total fertility rate: 6.29 children bom/
woman (1994 est.)
Nationality:
noun: Oambian(s)
adjective: Gambian
Ethnic divisions: African 99% (Mandinka
42%, Fula 18%, Wolof 16%, Jola 10%.
Serahuli 9%, other 4%), r m-Gambian 1 %
Religions: Muslim 90%, Christian 9%,
indigenous beliefs 1%
Languages: English (official), Mandinka,
Wolof, Fula, other indigenous vernaculars
Literacy: age 1 3 and over can read and write
(1990 est,)
total p:>pi:tation: 27%
male: 39%
female: 16%
Labor force: 400.000 ( 1 986 est.)
by occupation: agriculture 75.0%, industry,
commerce, and services 18.9%, government
6.1%
note: 55% population of working age ( I y83)','2840524acf1de30031fd881d2752830ff28b9bca6099f1f83633c3280ef7f106','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97f9328bf93fa53352651207f5a7a8f502fc9f01a74e4306c7cdd417e7a4f564',1994,'GM','Gambia','people-and-society',421,'Population: 731,296 (July 1994 est.)
note: in addition, there are 4,500 Jewish
settlers in the Gaza Strip (1994 est.)
Population growth rate: 3.53% (1994 est.)
Birthrate; 45.01 births/1,000 population
(1994 est.)
Death rate: 5.45 deaths/ 1, 0(X) population
(1994 est.)
Net migration rate: -4.29 migrant(s)/l ,000
population (1994 est.)
Infant mortality rate: 36.9 deaths/ 1, 000 live
births (1994 est.)
Life expectancy at birth:
total population: 67.78 years
male; 66.47 years
female; 69. 1 6 years ( 1 994 est.)
Total fertility rate: 7.39 children
born/woman (1994 est.)
Nationality:
noun; NA
adjrctive; NA
Ethnic divisions: Palestinian Arab and other
99.8%, Jewish 0.2%
Religions: Muslim (predominantly Sunni)
99%. Christian 0.7%, Jewish 0.3%
Languages: Arabic, Hebrew (spoken by
Israeli settlers), English (widely understood)
Literacy:
total population; NA%
male; NA%
female; NA%
Labor force: NA
hy occupation; construction 33.4%,
agriculture 20.0%, commerce, restaurants, and
hotels 14.9%, industry 10.0%, other services
21.7% (1991)
note; excluding Jewish settlers','ce5219fccd30f17c75363d4f91bc0833b3fa211d5b70e80b29a3ea5f6e36de2f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50443b8b5779bb5b631c31013c8e66f4a3fad17349ef561da237effd8808ac28',1994,'GE','Georgia','people-and-society',425,'Population: 3,681.025 (July 1994 est.)
Population growth rate: 0.81 % ( 1994 est.)
Birth rate: 1 6. 1 1 births/ 1 ,000 population
(1994 est.)
Death rate: 8.69 deaths/1,000 population
(1994 est.)
Net migration rate: 0.65 migrant(s)/l,000
population ( 1994 est.)
Infant mortality rate: 23.4 deaths/ 1, 000 live
births (1994 est.)
Life expectancy at birth:
total population; 72.84 years
male: 69.16 years
female; 76.7 years (1994 est.)
Total fertility rate: 2.18 children bom/
woman (1994 est.)
Nationality:
noun: Georgian(s)
adjective: Georgian
Ethnic divisions: Georgian 70. 1 %, Armenian
8.1%, Russian 6.3%, Azeri 5.7%, Ossetian 3%,
Abkhaz 1 .8%, other 5%
Religions; Georgian Orthodox 65%, Russian
Orthodox 10%, Muslim 1 1%, Armenian
Orthodox 8%, unknown 6%
Languages; Armenian 7%. Azeri 6%.
Georgian 7 1 % (official), Russian 9%. other 7%
Literacy: age 9-49 can read and write (1970)
total population: 100%
male: 100%
female: 100%
Labor force: 2.763 million
by occupation: industry and construction 3 1 %,
agriculture and forestry 25%, other 44% ( 1 990)
Population: no indigenous population; there
is a small military garrison on South Georgia,
and the British Antarctic Survey has a
biological station on Bird Island; the South
Sandwich Islands are uninhabited','dc597c5ba22fef3765ad4c9967c028d5a779237e57e67cdb3d76af8e685bdc36','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f9d7d2eaa3457b5ef988daec9a2f0bbfc77dc36761823affc8e9390e4d506ea',1994,'GH','Ghana','people-and-society',430,'Population: 17,225,185 (July 1994 est.)
Population growth rate: 3.09% (1994 est.)
Birth rate: 44. 13 biiths/I.OOO population
(1994 est.)
Death rate: 1 2.27 deaths) 1 ,000 population
(1994 est.)
Net migration rate: -0.97 migrant(s)/l,0(X)
population (1994 est.)
Infant mortality rate: 83.1 deaths/1.000 live
births (1994 est.)
Life expectancy at birth:
total population: 55.52 years
male: 53.58 years
female: 57.52 years ( 1994 est.)
Total fertility rate: 6. 1 5 children bom/
woman (1994 est.)
Nationality:
noun: Ghanaian(s)
adjective: Ghanaian
Ethnic divisions: black African 99.8%
(major tribes — Akan 44%. Moshi-Dagomba
16%, Ewe 13%, Ga 8%). European and other
0.2%
Religions: indigenous beliefs 38%. Muslim
30%, Christian 24%, other 8%
Languages: Engli.sh (official). African
languages (including Akan, Moshi-Dagomba,
Ewe, and Ga)
Literacy: age 1 5 and over can read and write
(1990 est.)
total population: 60%
male: 70%
female: 5 1 %
Labor force: 3.7 million
by occupation: agriculture and fishing 54.7%.
indu.stry 18.7%, sales and clerical 15.2%,
services, transportation, and communications
7,7%, professional 3.7%
note: 48% of population of working age ( 1 983 )
Population; 31,684 (July 1994 est.)
Population growth rate: 0.58% (1994 est.)
Birth rate; 1 5.37 births/1 .000 population
(1994 est.)
(1991), 326,33 (1990), 270.00 (1989)
Fiscal year: calendar year','963b2b4947943b581e5f3da71053398d06797cfc294f39d8fb2e58e46ff31a81','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53af947cb3abd0aee2391ffd2a295d4be399d1667fb4b1075aa16b75a4cb0338',1994,'GD','Grenada','people-and-society',438,'Population: 94.109 (July 1994 est.)
Population growth rate: 0.35% ( 1994 est.)
Birth rate: 30.28 births/ 1, (XX) population
(1994 est.)
Death rate: 6.19 deaths/ 1 ,000 population
(1994 est.)
Net migration rate; -20.6 migran''(s)/l ,000
population (1994 est.)
Infant mortality rate: 1 2.4 deaths/1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 70.4 years
male: 68 years
female: 72.85 years (1994 est.)
Total fertility rate; 3.93 children bom/
woman (1994 est.)
Nationality:
noun: Grenadian(s)
adjective: Grenadian
Ethnic divisions: black African
Religions: Roman Catholic, Anglican, other
Protestant sects
Languages: English (official), French patois
Literacy: age 1 5 and over having ever
attended school ( 1 970)
total population: 98%
male: 98%
female: 98%
Labor force: 36,000
hy occupation: services 3 1 %, agriculture 24%,
construction 8%, manufacturing 5%, other
32% (1985)','067a05a7c23e43b281af3e1b75ca3e9e9f685fc2fdb4bf6a490dbbbdf734b3ca','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2da6eaefa13d2d7bad6ffb7d68f5d14cc4d0da5fdb46c8f04b32e6a855e908a',1994,'GP','Guadeloupe','people-and-society',443,'Population: 428,947 (July 1994 est.)
Population growth rate: I .S.^% ( 1 994 est.)
Birth rate: 1 7.68 births/ 1 .0(K) population
(1994 est.)
Death rate; 5.94 deaths/ 1 ,000 population
(1994 est.)
Net migration rate: 3.73 migrant(s)/l.000
population (1994 est.)
Infant mortality rate: 8.9 deaths/ 1, 000 live
births (1994 est.)
Life expectancy at birth:
total population: 76.97 years
male; 73.91 years
female: 80. 1 4 years ( 1 994 est.)
Total fertility rate: 2.04 children
born/woman (1994 est.)
Nationality:
noun: Guadeloupian(s)
adjective: Guadeloupe
Ethnic divisions: black or mulatto 90%,
white 5%, East Indian, Lebanese, Chinese less
than 5%
Religions: Roman Catholic 95%, Hindu and
pagan African 5%
Languages: French, creole patois
Literacy: age 15 and over can read and write
(1982)
total population: 90%
male: 90%
female: 91%
Labor force: 1 20,000
by occupation: services, government, and
commerce 53.0%, industry 25.8%, agriculture
21.2%','985665785d753d60ce364d8e27c27ba510eecb1fe7f9bb49850fbdeb7a531bc4','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a02ebbdc15425687932d40109f4e7f9822f9426a6e7107be62f53de1c63ce99',1994,'GU','Guam','people-and-society',450,'Population; 149,620 (July 1994 est.)
Population growth rate: 2,48% (1994 est.)
Birth rate: 25.66 births/1 .000 population
(1994 es(.)
Death rate; .^.86 deaths/ 1 ,0(X) population
(1994 est.)
Net migration rate: migrant(sV1.000
population (1994 es(.)
Infant mortality rate: I . 1 7 deaths/ 1 ,000
live births (1994 est.)
Life expectancy at birth:
total population; 74.29 years
male: 72.42 years
female; 76. 1 years (1994 est.)
Total fertility rate: 2.39 children bom/
woman (1994 est.)
Nationality:
noun; Guamaniun(s)
atljeeiive; Guamanian
Ethnic divisions; Chamorro 47%. Filipino
2.5%, Caucasian 10%. Chinese, Japanese,
Korean, and other 18%
Religions: Roman Catholic 98%, other 2%
Languages: English. Chamorro. Japanese
Literacy: age 15 and over can read and write
(1980)
total populaiion: 96%
male; 96%
female; 96%
Labor force: 46.930 ( 1 990)
hy oecupaiion; federal and terri(orial
goveniment 40%, priva(e 60% (trade 18%,
services 15.6%, construction 13.8%, other
12.6%) (1990)','1cf863be681c9d92e9a394e4e1c9edf9ffb281b0af2f3f0de9db6d7f47fa4f9c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9cc960f7fddec9704d30d106c144925e400b96302702d8d6e9ae860029f5a2b',1994,'GT','Guatemala','people-and-society',454,'Population: 1 0,72 1 .387 (July 1 994 est. )
Population growth rate: 2.58% (1994 est.)
Birth rate: 35.42 births/I. (XX) population
(1994 est.)
Death rale: 7..53 deaths/ 1.000 population
(1994 est.)
Net migration rate: -2.1 1 niigrant(s)/ 1,000
population (1994 est.)
Infant mortality rate: 53.. Jeath.s/I.OOOlive
births (1994 est.)
Life expectancy at birth:
total population: 64.42 years
male: 6 1 .86 years
female: 67. 1 years ( 1994 est.)
Total fertility rate: 4.76 children bom/
woman (1994 esi.)
Nationality;
noun: Guatemalan(s)
adjective: Guatemalan
Ethnic divisions: Ladino 56% (mestizo —
mixed Indian and European ancestry), Indian
44%
Religions: Roman Catholic, Protestant,
traditional Mayan
Languages: Spanish 60%, Indian language
40% ( 1 8 Indian dialects, including Quiche,
Cakchiquel, Kekchi)
Literacy: age 15 and over can read and write
(1990 est.)
total population: 55%
male: 63%
female: 47%
Labor force: 2.5 million
by occupation: agriculture 60%, services 13%,
manufacturing 1 2%, commerce 7%,
construction 4%, transport 3%. utilities 0.7%,
mining 0,3% (1985)','3521bd9f70cb5bebe1680624005fda074ad4cdcf86de9038a96c5df20e09a89f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2691804a377951b7dbce2fbadc0151a5e3773f88fb551e583b4619c7d11fc5d',1994,'GG','Guernsey','people-and-society',459,'Population: 63,719 (July 1994 est.)
Population growth rate: 1.01% (1994 est.)
Birthrate: 13.21 births/1,000 population
(1994 est.)
Death rate: 9,97 deaths/ 1.000 population
(1994 est.)
Net migration rate: 6.81 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 6.6 deaths/ 1 .000 live
births (1994 est.)
Life expectancy at birth:
total population: 78.15 yeais
male: 75.45 years
female; 80.88 years (1994 est.)
Total fertility rate: 1 .68 children bom/
woman (1994 est.)
Nationality:
noun: Channel Islander(s)
adjective: Channel Islander
Ethnic divisions: UK and Nomtan-French
descent
Religions: Anglican. Roman Catholic.
Presbyterian, Baptist, Congregational,
Meth^ist
Languages: English, French; Norman-French
dialect spoken in country districts
Literacy:
total population: NA%
male: NA%
female: NA%
Labor force: NA','1a21e12bd2dd78f2c291b97640df21e7107641e0c34272d4a2d5591d1503ddf0','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9bce6b006aa4f49824a566af356d351a8bc1d957fb8cd1870f31c22675cdd9c',1994,'GN','Guinea','people-and-society',465,'Papulation: 6,391,536 (July 1994 est.)
Papulation growth rate: 2.45% (1994 est.)
Birth rate: 44.08 births/1,000 population
(1994 est.)
Death rate: 19.6 deaths/1,000 population
(1994 est.)
Net migration rate: 0 migrant(s)/t ,000
population (1994 est.)
Infant mortality rate; 1 39.2 deaths/ 1 ,000
live births (1994 est.)
Life expectancy at birth:
total population: 44.13 years
male; 41.9 years
female; 46.43 years (1994 est.)
Total fertility rate: 5.85 children bom/
woman (1994 est.)
Nationality:
noun; GuineBn(s)
adjective: Guinean
Ethnic divisions; Peuhl 40%. Malinke 30%,
Soussou 20%, indigenous tribes 10%
Religions: Muslim 85%, Christian 8%,
indigenous beliefs 7%
Languages: French (official); each tribe has
its own language
Literacy: age 15 and over can read and write
(1990 est.)
total population: 24%
male: 35%
female: 13%
Labor force: 2.4 million (1983)
by occupation: agriculture 82.0%, industry
and commerce 1 1.0%, services 5.4%
note: 88,1 12 civil servants (1987); 52% of
population of working age (1985)','14ffdfc1fa654431b4b0bfbf2d91ea76f18d5da78470549c5410c7137fdfa912','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7172b2ae3fadec854b311afb9a2d6c3bbbc823808f5b3e3b0ece5bce09fc937d',1994,'SN','Senegal','people-and-society',469,'Population: 1,098,231 (July 1994 est.)
Population growth rate: 2.37% (1994 est.)
Birth rate: 40.75 bitths/1,000 population
(1994 e.st.)
Death rate: 17.03 deaths/I ,(X)0 population
(1994 est.)
Net migration rate: 0 migrant(.s)/l,06o
population ( 1 994 est.)
Infant mortality rate: 1 20 deaf is/ i ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 47.44 years
male: 45.79 years
female: 49. 15 years ( 1994 est.)
Total fertility rate: 5.51 children bom/
woman (1994 est.)
Nationality:
noun: Guinea-Bissauan(s)
adjective: Guinea-Bissauan
Ethnic divisions: African 99% (Balanta 30%,
Fula 20%, Manjaca 14%, Mandinga 13%,
Papel 7%), European and mulatto less than 1 %
Religions: indige.:ous beliefs 65%, Muslim
30%, Christian 5%
Languages: Portuguese (official), Criolo,
African languages
Literacy: age 15 and over can read and write
(1 990 est.)
total population: 36%
male: 50%
female: 24%
l.abor force: 403.000 (est.)
by occupation: agriculture 90%, industry,
services, and commerce 5%, government 5%
note: population of working age 53% ( 1 983)
Population; 2,192,777 (July 1994 est.)
Population growth rate; 3. 1 6% ( 1 994 est.)
Birth rate: 47.65 births/ 1,000 population
(1994 est.)
Death rate: 1 6.09 deaths/ 1 ,000 population
( 1994 est.)
Net migration rate: 0 migrant(s)/l ,000
population ( 1994 est.)
Infant mortality rate; 85.3 deaths/l,0(X) live
births (1994 est.)
Life expectancy at birth:
total population: 48.06 years
male: 45.23 years
female: 51.01 years (1994 est.)
Total fertility rate: 6.99 children born/
woman (1994 est.)
Nationality:
noun: Mauritanian(s)
adjective: Mauritanian
Ethnic divisions: mixed Maur/black 40%,
Maur 30%. black 30%
Religions; Muslim 100%
Languages: Hasaniya Arabic (official), Pular,
Soninke. Wolof (official)
Literacy: age 10 and over can read and write
(1990 est.)
total population: 34%
male: 47%
female: 21%
Labor force: 465.000(1981 est.); 45,000
wage earners (1980)
by occupation: agriculture 47%. services 29%,
industry and commerce 14%, government 10%
note: 53% of population of working age ( 1 985)
Population: 8,730,508 (July 1994 est.)
Population growth rate: 3.1 1% (1994 est.)
Birth rate: 43. IS births/I ,000 population
(1994 est.)
Death rate: 12.01 deaths/ 1,000 population
(1994 est.)
Net migration rate: 0 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 75.7 deaths/ 1,000 live
births (1994 est.)
Life expectancy at birth:
total population: 56.58 years
male: 55.12 years
female: 58.09 years (1994 est.)
Total fertility rate: 6.09 children
bom/woman (1994 est.)
Nationality:
nowi: Senegalese (singular and plural)
adjective: Senegalese
Ethnic divisions: Wolof 36%, Fulani 17%,
Serer 17%, Toucouleur 9%, Diola 9%,
Mandingo 9%, European and Lebanese 1%,
other 2%
Religions: Muslim 92%, indigenous beliefs
6%, Christian 2% (mostly Roman Catholic)
Languages: French (official), Wolof, Pulaar,
Diola, Mandingo
Literacy: age 15 and over can read and write
(1990 est.)
total population: 38%
male: 52%
female: 25%
Labor force: 2.509 million (77% are engaged
in subsistence farming; 1 75,(X)0 wage earners)
by occupation: private sector 40%,
government and parapublic 60%
note: 52% of population of working age (1985)
Population:
total: 10,759,897 (July I994e.st.)
Montenegro; 666,583 (July 1994 est.)
Serbia; 10.093.314 (July 1994 est.)
Population growth rate:
Montenegro; 0.79% (1994 est.)
Serbia; 0.54% ( 1994 est.)
Birth rate:
Montenegro; 13.72 births/l.0(K) population
(1994 est.)
Serbia: 14.35 births/ 1, (X)0 population (1994
est.)
Death rate;
Montenegro: 5.84 deaths/ 1,0(X) population
(1 994 est.)
Serbia: 8.94 deaths/1,000 population (1994
est.)
Net migration rate:
Montenegro: 0 migrant(s)/l.000 population
(1994 est.)
Serbia: 0 migrant(s)/ 1,000 papulation (1994
est,)
Infant mortality rate:
Montenegro: 10.8 deaths/I, (K)0 live births
(1994 est.)
Serbia; 2 1 .4 deaths/l .000 live births ( 1994
est.)
Life expectancy at birth:
Montenegro;
total population; 79.44 years
male: 76.57 years
female; 82,5 years (1 994 est.)
Serbia:
total population: 73.39 years
male: 70.9 years
female; 76.07 years ( 1 994 est.)
Total fertility rate:
Montenegro; 1 .74 children bom/woman ( 1 994
est.)
Serbia: 2.06 children bom/woman ( 1 994 est.)
Nationality:
noun: Serb(s) and Montenegrin(s)
adjective: Serbian and Montenegrin
Ethnic divisions: Serbs 63%, Albanians 14%.
Montenegrins 6%, Hungarians 4%, other 13%
Religions: Orthodox 65%, Muslim 19%,
Roman Catholic 4%, Protestant 1%, other 1 1%
Languages: Serbo-Croatian 95%. Albanian
5%
Literacy:
total population: NA%
male: NA%
female; NA%
Labor force: 2.640,909
by occupation; industry, mining 40%.
agriculture 5% (1990)','13324a5d3d54a9b29a08bc0631e2c8fc1a85547f0640f133ad89eb609380172a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6728ab419797351e08c03ab8a0070fe3b2d48b93426bc7b7230c9ffe0508de8',1994,'HT','Haiti','people-and-society',477,'Population: 6,491,450 (July 1994 cst.)
Population growth rate: L63‘5''f (1994 est.)
Birth rate: 39.72 births/l ,(XX) population
(1 994 est.)
Death rate: 18,78 deaths/1,000 population
(1994 est.)
Net migration rate: -4.67 tnigrant(s)/l,(X)0
population (1994 cst.)
Infant mortality rale: 1 08.5 deaths/ 1 ,(XX)
live births (1994 est.)
Life expectancy at birth:
total population: 45. 1 1 years
male: 43.45 years
female: 46.85 years (1994 est.)
Total fertility rate: 5.94 children horn/
woman (1 994 est.)
Nationality;
noun: Haitian(s)
adjeetive: Haitian
Ethnic divisions; black 95''X . mulatto and
European SCF
Religions: Roman Catholic 80% (of which an
overwhelming majority also practice Voodoo).
Protestant 16% (Bapti.st 10%. Pentecostal 4%.
Adventist 17r. other 1%). none 1 %. other 3%
(1982)
Languages: French (official) 109i. Creole
Literacy: age 15 and over can read i.nd write
(1990 est.)
total population: 5.39(
male: 59%
female: 47%
Labor force: 2.3 million
hy oeeupation: agriculture 66%, services 25Vf ,
industry 9%-
note: shortage of skilled labor, unskilled labor
abundant ( 1982)
Population: uninhabited','d8fa1e7e9c6270a261decebc36ed56fdc58dbb696e1843ffce369d2a6d2c4b91','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('353b4d9e220037655ded3b0e10ea73ccff4ab10108a5d6adfa80f03fddfeab1a',1994,'HK','Hong Kong','people-and-society',485,'Population: 5,548,754 (July 1994 est.)
Popii .ition growth rate: -().()99f (1994 est.)
Birth rate: 12. 16 births/ 1,(KK) population
(1994 est.)
Death rate: 5.85 deaths/l.(XX) population
(1 994 est.)
Net migration rate: -7.21 migrdnt(s)/l.(XX)
population (1994 est.)
Infant mortality rate: 5.8 death.s/l ,0(X) live
births (1994 est.)
Life expectancy at birth:
total population: 80.09 years
male: 76.67 years
female: 83.71 years (1994 est.)
Total fertility rate: 1.37 children bom/
woman (1994 est.)
Nationality:
noun: Chinese
adjective: Chinese
Ethnic divisions: Chinese 95%, other 5%
Religions; eclectic mixture of local religions
90%. Christian 10%
Languages: Chinese (Cantonese), English
Literacy: age 15 and over having ever
attended school (1971)
total population: 77%
male: 90%
female: 64%
Labor force: 2.8 inillinn (1990)
by occupation: manufacturing 28.5%.
wholesale and retail trade, restaurants, and.,
hotels 27.9%, services 17.7%, financing,
insurance, and real e.state 9.2%. transport and
communications 4.5%, construction 2.5%,
other 9.7%. (1989)
Population: uninhabited; note — American
civilians evacuated in 1942 after Japanese air
and naval attacks during World War II;
occupied by US military during World War 11,
but abandoned after the war; public entry is by
special-use permit only and generally restricted
to scientists and educators','523372b367ac93ebeb5517db34cf15d86949b1434cae30d14511bd457ae91b93','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('19b5802f687215b80fd7a8feb2524aa2511c6b9a31eace21a413984936ce20d8',1994,'HU','Hungary','people-and-society',489,'Population: 10,3 19.1 L3 (July 1994 c.st.)
Population growth rate: -0.039b ( 1 994 est. )
Birth rate: 1 2.46 births/I .000 population
(1994 est,)
Death rate: 1 2.72 dcaths/l ,0(X) population
(1994 est.)
Net migration rate: 0 migrant(s)/l.(X)0
population (1994 est.)
Infant mortality rate: 1 2.5 deaths/ 1 .(X)0 live
births (1994 est.)
Life expectancy at birth:
total papulation: 71.37 years
male: 67.37 years
female: 75.58 years (1994 est.)
Total fertility rate: 1 .83 children born/
woman (1994 e.st.)
Nationality:
noun: Hungarian(s)
adjective: Hungarian
Ethnic divisions; Hungarian 89.99b. Gvpsy
49b. German 2,69b. Serb 29? , Slovak 0,89b.
Romanian 0.79b
Religions: Roman Catholic 67..37(. Calvinist
209b, Lutheran 59<'', atheist and other 7. .39b
Language.s: Hungarian 98.29b. other 1.89b
Literacy; age 15 and over can read and write
(1980)
total iMipulation; 999b
male: 999b
female: 989b
Labor force: 5.4 million
hy occupation; services, trade, government.
and other 44.89b, industry Vi.Wc. agriculture
16, 1 9b. construction ■^.09b ( 1991 )','8d78cc85f2efef0568f76d8189003d99aab6384a81771c52dfdc30f387e1acfa','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d96b231c6da73456462b4f7137fde3f93f04a111ea5a8915ac78f81397b1ee80',1994,'IS','Iceland','people-and-society',494,'Population: 263,599 (July 1994 est.)
note: population data estimates based on
average growth rate may differ slightly from
official population data because of volatile
migration rates
Population growth rate; 0.9% ( 1 994 est.)
Birthrate; 16.41 births/1,000 population
(1994 est.)
Death rate: 6.72 deaths/I.OOO population
(1994 est.)
Net migration rate: -0.73 migrant(s)/L000
population (1994 est.)
Infant mortality rate: 4 deaths/I ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 78.83 years
male: 76.57 years
female: 81.21 years (1994 est.)
Totai fertility rate: 2. 1 1 children
born/woman ( 1994 est.)
Nationality:
noun: Icelander(s)
adjective: Icelandic
Ethnic divisions; homogeneous mixture of
descendants of Norwegians and Celts
Religions; Evangelical Lutheran 96%. other
Protestant and Roman Catholic 3%, none 1%
(1988)
Languages: Icelandic
Literacy; age IS and over can read and write
(1976 est.)
total populatitm: 100%
male: NA%
female: NA%
Labor force: 1 27,900
by occupation: commerce, transportation, and
services 60.0%. manufacturing 12.5%. fishing
and fish prtKessing 1 1.8%, construction
10.8%, agriculture 4.0% (1990)','69e28c623a53cbed08dc56cf46f6fb0ebeeb836d838c45132ba1ba78e87d52c9','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6828e4c41691cef99a3c0da6bef102b1f281741a6a6090e5958642dca451ddc2',1994,'IN','India','people-and-society',499,'Population: 9 19,903,056 (July 1994 est.)
Population growth rate: 1 .82*^ ( 1 994 est.)
Birth rate: 28.45 births/1.000 population
(I994e.st.)
Death rate: 1 0.29 deaihs/l .000 population
(1994 est.)
Net migration rate: 0 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 78.4 deaths/I .000 live
births (1994 est.)
Life expectancy at birth;
total population: 58.58 years
male: SS.OO years
female: 59.09 years (1994 est.)
Total fertility rate: 3.48 children born/
woman ( 1994 est.)
Nationality:
noun: Indian(s)
adjective: Indian
Ethnic divisions: Indo-Arya.i 12%.
Dravidian 25%, Mongoloid and other 3%
Religions: Hindu 807r, Muslim 147r.
Christian 2.4%. Sikh 2%. Buddhist 0.7%, Jains
0.5%. other 0.4%
Languages: English enjoys associate status
but is the most important language for national,
political, and commercial communication,
Hindi the national language and primary
tongue of 30% of the people, Bengali (official).
Telugu (official). Marathi (official), Tamil
(official), Urdu (official). Gujarati (official).
Malayulam (official). Kannada (official).
Oriya (official). Punjabi (official). Assamese
(official). Kashmiri (official). Sindhi (official),
Sanskrit (official), Hindustani a popular
variant of Hindu/Urdu, is spoken widely
throughout northern India
note: 24 languages each spoken by a million or
more persons: numerous other languages and
dialects, for the most part mutually
unintelligible
Literacy: age 7 and over can read and write
(1991 est.)
total population: 52. 1 1 %
male: 63.86%
female: 39.42%
Labor force: 314,751 million (1990)
hy occupation: agriculture 65% (1993 est.)
Population: 252.077 (July 1994 e.st.)
Population growth rate: 5.6 1 % ( 1 994 est. )
Birthrate: 43.59 births/I, (XX) population
(I994est.)
Death rate: 7.45 deaths/ 1, (X)0 population
(1994est.)
Net migration rate: 0 migrant(s)/I.O(X)
population (1994 est.)
Infant mortality rate: 53. S deaths/ 1 .000 live
births (1994 est.)
Life expectancy at birth:
total population; 64.67 years
male; 63.24 years
female: 66. 1 7 years ( 1 994 est.)
Total fertility rate: 6.26 children born/
woman (1994 est.)
Nationality:
noun; Maldivian(s)
adjective: Maldivian
Ethnic divisions: Sinhalese. Dravidian. Arab.
African
Religions: Sunni Muslim
Languages: Divehi (dialect of Sinhala; script
derived from Arabic), English spoken by most
government officials
Literacy: age 15 and over can read and write
(1985)
total impulation; 92%
male; 92%
female; 92%
Labor force: 66,(XK)(est.)
by occupation; fishing industry 25%
Population; 1 28.855.965 (July 1 994 est.)
Population growth rate: 2.86% (1994 est.)
Birthrate: 42.22 births/ 1.000 population
(1994 est.)
Death rate: 1 2.38 deaths/I ,000 population
(1994 est.)
Net migration rate: -1.21 migrant(s)/ 1,000
population (1994 est.)
Infnnt mortality rate: lOi.9 deaths/I ,000
live births (1994 est.)
LlfX expectancy at birth;
total population: 57.41 years
male: 56.79 years
female: 58.06 years ( 1994 est.)
Total fertility rate: 6.43 children
hom/woman ( 1994 e.st.)
Nationality:
noun: Paki.stani(s)
adjective: Pakistani
Ethnic divisions; Punjabi, Sindhi. Pashtun
(Pathon), Baloch, Muhajir (immigrants from
Indio and their dcscendents)
Religions: Muslim 97% (Sunni 77%. Shi''a
20%), Christian, Hindu, and other 3%
Languages; Urdu (offlcial). English (official;
lingua franca of Pakistani elite and most
government ministries), Punjabi 64%, Sindhi
1 2%. Pashtu 8%, Urdu 7%, Balochi and other
9%
Literacy: age 15 and over can rend and write
(1990 est.)
total population; 35%
nude: 47%
female: 2 1 %
Labor force: 28.9 million
h\\ (UTupatian: agriculture 54%. mining and
manufacturing 13%. services 33%, extensive
export of labor ( 1 987 est. )','9f7bc8bd7043ee1c9d98136e62fc421fa27b9fb257a6810bd3e1cb412553868a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6163906ecc5d955508a22b83470e7ca6f2be007b631a5448bf73050a7dbce415',1994,'ID','Indonesia','people-and-society',505,'Population: 2(X).409.74I (July 1994 esi.)
Population growth rate; 1 .59^ ( 1 994 est. )
Birth rate: 24.4.1 births/1.000 population
(1994 est.)
Death rate: 8.6 deaths/I.OflO population
(1994 est.)
Net migration rate: 0 migrani(s)/l.(XX)
population ( 1994 est.)
Infant mortality rate: 67..) deaths/ 1 .(XX) live
births (1994 est.)
Life expectancy at birth:
toud inipulaiian: 60.74 years
male: 58.7 years
female: 62.88 years 1 1994 est.)
Total fertility rate: 2.8 children bom/woman
(1994 est.)
NattonaHty:
noun: Indoncsiants)
adjeeiive: Indonesian
Ethnic divistom: Javanese 45*) . Sundanese
1 4<,t . Madurese 7.5'';( . coastal Malay s 7.5''i ,
other 260i
RdigioiM: Muslim 87''''f.Pnacstani6''(.
Rotnan Catholic .t**. Hindu 2*''/* . Buddhist I <A .
other l‘-r 1 1985)
l.amguageii; Bahasa Indonesia tnuxiitied
form of Malay ; official). English. Dutch. Uwal
dialects the most widely spoken of which is
Javanese
Literary: age 15 and over cun mad and write
(1 990 est.)
lalal ihi/Hdaiiim; 77*<
nude: 84''''4
female: bgr.*
Ijibor force; 67 million
h\\ iH euiHiliim: agriculture 55'' r.
manufacturing 10''^ . cvmstructKm 4''i .
transport and communications .f* < 1985 est.)
xtovemmeni
Nameti:
eiinveniiimal Imiff lorm; Republic of I nvkmesia
eanveniimud slum Umn: Indonesia
Un a! long form: Republik Indonesia
Itu al short larm: Indonesia
lonner name: Netherlands liast Indies. Dutch
East Indies
Digraph: ID
Type: republic
Capital: Jakarta
AdminMratlve dlvblanN; 24 pros inces
(propinsi-pixipinsi. singular -propinsii. 2
special regions* tdaerah-dacrah isiinK''wa.
singular daerah istimewa). and I special
capital city district ** (daerah khusus ibukota);
Aceh*. Ball. Bengkulu. Inan Java. Jakarta
Raya**. Jambi. Jawa Barat, Jawa Tengah.
Jawa Timur, Kalimantan Baiat, Kalimantan
Selatan. Kalimantan Tengah, Kalimantan
Timur. Lampung. Maluku. Nusa Tenggara
Barat. Nusa Tenggara Timur. Riau. Sulawesi
Selatan, Sulawesi Tengah, Sulawesi Tenggara,
Sulawesi Utara, Sumatera Barat, Sumatera
Selatan, Sumatera Utara, Timor Timur.
Yogyakarta*
Independence: 1 7 August 1945 (pnviaimed
independence: on 27 December 1949.
Indonesia heca''.ne legally independent from the
Netherlands)
National holiday: independence Day. 17
August (1945)
Constitution: .August 1945, abrogated by
Federal Constitution of 1949 and Provisional
Constitutivm of 1950. restored 5 July 1959
l.«gal ayxtem; based on Roman-Dutch law .
substantially nKHlitled by indigenous concepts
and by new criminal priveduivs cixie; has not
accepted compulsory ICJ jurisdiction
Nufhnge: 1 7 years of age; universal and
maiTied persons regardless of age
Executive branch:
ehiel of slate and head offiovennuenl:
Pasident Gen (Ret ) SOEHARTO (since 27
March 1968); V''^ce President Gen. (Ret.) Try
SUTRISNO (since II Match 199.t)
eahinel: Cabinet
Letifadallve branch: unicameral
ffoiise of Hepresentatiees: (Dewanperwakilan
Raky at or DPR ) electi>>i)s last Iteld on 8 Juiw
1992 (next to be held NA 1997); results -
CiOi.KAR 68''i . PPP 17<^( . PDl I5>i ; seats
i.MX)t(8ul. -MX) elected. IIX) military
representatives appointed) GOLKAR 282. PPP
62, PDl 56
note: the People’s Consultative Assembly
iMajelis Pennusy aw aratun Rakyat or MlHo
incluvK’s the DPR plus .MX) indirectly cK''cted
riK''inbers who iiKvt every five years tv>elect the
president and vice president and. ilreoreiically .
to determine national pviliev
Judictal branch: SupreiiK'' Court tMahkamah
Agungi
PoHlical pnrtirs and leaders: GOI.KAR
Iquasi-official party based on funcmmal
grvHips). 1-1. Cicn (Ret.) HARMOKO. general
chairman; Indonesia IVmivracy Party (PDl
federation of lonirer Nationalist and Christian
Parties). Megawati SUKARNOPUIRI.
chainn.in; Development I''nily Party (PPP.
feilerativm of fontK''r Islamic parties). Ismail
Hasan METAREUM. chainiian
Member of: APEC. AsDB. A.SEAN.CH .
CP. ESCAP. EAO. (i 15. Cl 19. G 77. GATT,
IAEA. IBRD, K AO. K C, K ITU. IDA IDB.
II AD. II ( . II.O. IMF. IMO. INMAR.SAT.
INTEI .SAT, INTERK)!.. I(X , lOM
umserveri. ISO. ITU, l.ORCS. NAM. OIC.
()PI;C. I''N. UNCTAD. UNESCO. UNIDO,
UNIKOM. UNOSOM. UNT.AC. I''PU. WCE.
WITU. W HO. W IPO. W MO. W TO
INplomalic reprcseniaiion in I''S:
I Inel ol mission: Aiiihassadoi Arilin
SIRIOAR
Indonesia (continued)
cluim ery: 2020 Massachusetls Avenue NW,
Washington. DC 20036
telephone; (202) 77.3-5200
FAX; (202) 775-5.365
consiilaie(s) fteneral; Chicago. Houston. New
York, and Los Angeles
coimlatet\\); San Francisco
US diplomatic representation:
chief of mission; Ambassador Robert L.
BARRY
emhasss; Medan Merdeka Seluian 5. Box 1.
Jakarta
mailin/f address; APO AP %520
telephone; |62| (21 ) .360- .360
FAX; |62 1 (21). 386-22.59
considatets); Medan. Surabaya
Flag: iwo equal horizontal hands of red (top)
and white; similar to the flag of Monaco, which
is shorter: also similar to the flag of Poland,
which IS white (top) and red
Kconomy
Overview: Indonesia is a mixed economy
with some sivialist institutions and central
planning but » ith a recent emphasis on
deregulation and prisate enierprise. Indonesia
has exiensise natural wealth, yet, w ith a large
and rapidlv increasing population, it remains a
ptxir countrj . Real GDP gttiwth in 1985-9.3
averaged about . quite impmssive. hut m>l
suirtcieni to both slash unden.''mplov nK''nt aitd
absorb the 2..3 million .corkers annually
entering the labor force. Agricultiin.''. including
forestry and fishing, is an important scvtitr.
acctmniing for 2 1 of GDP and over 5()''''i of
the laKw force. The staple crop is l ice. Once
the world''s largest rice importer. Indonesia is
now nearly self-sufficient. Plantation crops -
rubber and palm oil and textiles and plywixid
are being ciwtHiragcd for both expi''rt and ,jt»h
generation. Industrial output now accounts for
almost 4(i''< of GDP and i'' based on a supply of
diverse natural rCsiHirces. including cnide oil.
natural gas. limber. iiK''ials. and coal. Foa''ign
investment has also IvMisied manufacturing
oiilpul and exports in recent years. Indeed, the
economy ''s growth is highly dependent on the
continuing expansion of nonoil exports. Japan
remains Inihinesia''s imisi iniponani cusionwr
and supplier of aid. Rapid grow ih in the money
supply in 1 989-‘8) prompted Jakarta to
impIciiK''ni a tight monetary policy in 1991.
foa''ing the private sector to go to foreign hanks
for invcstiiK''itt financing. Real interest talcs
remaiiK’U above lO''i and ofl shvirc
comiiK''rcial debt grew . The grow ih in off-shore
debt prompted Jakarta to limn loaugn
borrowing K''gmning in laic I99|. Ix-spne the
continued problems in moving toward a more
open financial sy stem and the |>ersisience of a
fairly light cmdii situation. GDP gnrwih in
I9*)2 and l‘)9,3 has mulched the govcrnnK’nl
target oils'' t Ti annual growth.
Nafioiiiil pntducl: GDP purchasing power
equivalent — $571 billion (1993 est.)
National pioduct real growth rate: 6.5%
(199.3 est.)
National product per capita: $2,900 (199.3
est.)
Inflation rate (consumer prices): 10%
(1993 est.)
Unemployment rate: .3% official rate;
underemployment 45% (1993 est.)
Budget:
revenues; $.32.8 billion
exi>enditures; $32.8 billion, including capital
expenditures of $12.9 bilTon (FY95)
Exports: $.38.2 billion (f.o.b.. 199.3 est.)
conumxhiies; petroleum and gas 28%. clothing
and fabrics 1 5% . pivwoud 1 1 %. footwear 4%
(1992)
Iktimers; Japan 32%. US 13%. .Singapore 9%.
.South Korea 6% (1992)
Imports: $28.3 billion (f.o.b.. 199.3 est.)
coniniodiiies; machinery 37%. semi-rinished
giKKls 16%. chemicals 14%. raw materials
10%. Iransptvrl equipment 7%, fiHvdsiuffs 6% ,
petroleum products 4%, consumer goods 3%
(1992)
fhiriners; Japan 22'' t. L''S 14'',4.Gemiany 8'';t.
South Korea 7%. Singapore 6%. Australia 5%.
Taiwan 5*3 ( 1992)
External debt: $ltX) billion ( 1994 est. )
IndiMtrial production: grow th rate 1 1 .6%
( 1989 est.): accounts ,35% of GDP
Elcetricit.v:
caikicits : 1 1 .6()0.(8I() kW
pohluciion: 38 billion kWh
consumption />er capita; 2(8) kWh ( 1990)
Industries: petroleum and natural gas.
textiles, mini'' g. cement, chemical fenili/ers.
plywood, food. lUbbcr
Agriculture: accvHints for 21% of GDP;
suftsistence fiMid production; small-holder and
plantation production I''vir export; main
prxtducts are nee, cassava, peanuts, rubber,
ctwoa. coftc*e. palm oil. copra, mher tropical
pnKiucts. poultry , beef, pork, eggs
lllicil drugs: illicit prodiK-er «>f cannabis for
the international drug trade, but ran a major
player; government actively eradicating
plantings and prosecuting traflickers
Ecnnomlc aid;
recipient; l^S commilmems. including Ex-lm
IFY70-89), S4.4 billion; Western (non-l''Si
cmintnes. ODA and (H)l'' bilateral
commitiiH.*nts 1 1970-89). S25 9 billion; OPFX''
bilateral aid (1979-89). $213 million;
(''ommunisi countries 1 1970-89). $175 million
furrenej: I Indorwsian rupiah iKpi = 1(8)
sen ( sen no hmger used i
Exchange rales; Indonesian nipiahs i Rp ) per
I''SSl -2.llb,9tJanuarv 1994), 2.087 1
1 1991). 2,029.9 ( 1992). 1.9.50 3 t tO*)! ),
1,842 8 1 1990). 1.770 I |I989|
Fiscal year: I April 3 1 March
( ''ommunicathms
Railroads: 6.*)64 km total; 6..389 km 1.067-
meter gauge. 497 km 0.750-me(er gauge, 78
km 0.600-meier gauge; 21 1 km double track;
101 km electrified: all government owned
Highways:
total; 1 19,5(X) km
paved; NA
unikived; NA
undifferentiated; provincial 34.180 km;
district 7.3,.508 km; slate 1 1.812 km
Inland waterways: 2 1 .579 km total; Sumatra
^ 47 1 km, Java and Madura 820 km,
Kalimantan 10,460 km. Sulawesi 241 km, Irian
Jaya 4,587 km
Pipelines: crude oil 2,505 km; petroleum
pr^ucts 456 km: natural gas 1 ,70,3 km (1989)
Ports: Cilacap. Cirebon. Jakarta, Kupang.
Palembang. Ujungpandang. Semarang,
Surabaya
Merchant marine: 4.30 ships 1 1 .(88) GRT or
over) totaling 1 .893.8.30 GRT/2.768.294
DWT. short-sea passenger 7. passenger-cargo
1 3, cargo 256. container 1 1 . roll-on/roll-off
cargo 5. vehicle carrier 4. oil tanker 83,
chemical tanker 7. liquefied gas 6, specialized
tanker 7. livcsiix-k carrier I, bulk 26.
passenger 4
.Airports:
total; 444
usable; 414
with penmincnt-surface runwavs; 122
with rumvavs over .f.6.5V m; I
svilh nutsvavs 2, -J-JO- .3.6.59 m; 1 1
with runsvavs l,^y)-2.4t''^ m; 68
TetocommunicatitNis: intcrislund
microwave system and HF police net; domestic
service fair, international service gwxl;
radiobroadcast coverage gotxl. 763.(88)
lelephoiK''s ( 1986); broadcast stations — 61 8
AM. 38 FM, 9 TV ; satellite earth stations— 1
Indian Ocean INTELSAT earth station and I
Pacific Ocean INTELSAT earth station; and I
vlomesiic satellite communications system
Defeme Eorccs
Brunches: Army. Navy. Air Force. National
Police
Munpower uvailablUty: males age 15-49
54,5 1 8.490; fit f.w military scrv ice 32. 1 75.853;
reach militarv age ( 18) annuallv 2.201.295
(1994 est.)
Defense expenditures: exchange rate
conversion $2. 1 billion. 1.5% of GNP
iFY9.3/94esi )
188
Iran
Ctftf MtiMt
of','6d552c577ca446b5eaef37e3974ba15a1239c81b818a2eb4b70bcb1aceb8c0ac','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1737eab6a511a4913b6cd261a4ca97bd8ccf7deda8a42580dd0161e03bfa38f4',1994,'SA','Saudi Arabia','people-and-society',512,'Population: 19,889.666 (July 1994 est.)
Population growth rate; 3.7.39}- ( 1 994 est.)
Birth rate: 44. 1 1 birth.s/l,(KX) population
(1994 est.)
Death rale: 7.26 dealh,s/l.(KK) population
(1994 est.)
Net migration rate: 0.4 migrant(s)/l,(XX)
population (1994 est.)
Infant mortality rale: 67.1 dcaih.s/l,(XX) live
births (1994 est.)
Life expectancy at birth:
total population: 65,74 years
male: 64,87 years
female: 66.66 years (1994 est.)
Total fertility rate: 6.71 children born/
woman (1 994 est.)
Nationality:
noun: Iruqi(s)
adjective: Iraqi
Ethnic divisions; Arab 75-809} . Kurdish
1 5-209? . Turkoman. Assyrian or other 59f
Religions: Mu.slim 979? (Shi''a 60-659}-,
Sunni 32-379} ). Christian or other 39}
Languages; Arabic. Kurdish (official in
Kurdish regions). Assyrian. Armenian
Literacy: age 15 and over can read and write
(1990 est.)
total impulation: 6()9(
mate: 7()9(
female: 499(
Labor force: 4.4 million ( 1989)
hv iH''cuiHttion: .services 48*?-, agriculture .3091’.
industry 229}
note: severe labor shortage: expatriate labttr
force was about 1 ,600.(X)0 (July 1990); since
then, it has declined substantially
Population: .3.961.194 (July 1994 est.)
Population growth rate: .3.591- ( 1994 est.)
Birth rate: .38.77 births/I .(HX) population
(1994 est.)
Death rate; 4.22 deaths/I.OtX) population
(1994 est.)
Net migration rale; 0.47 migrant(s)/l.(XX)
population ( 1994 est.)
Inflint mortality rate: .32..3 deaths/ 1, 000 live
births (1994 est.)
Life expectancy at birth:
total population: 7 1 .85 years
male: 70.04 years
female: li.TI years ( 1994 est,)
Total fertility rate: 5.64 children
hom/woman ( 1994 est.)
Nationality:
noun: Jordunian(s)
adjective: Jordanian
Ethnic divisions; Arab 98(3-, Circassian l(r,
Armenian 193
Religions: Sunni Muslim 9293. Christian 893
Languages: Arabic (ofTtcial). English widely
understotxi among upper and middle classes
Literacy: age 15 and over can read and write
(1 990 est.)
total /Hipulation: 8093
male: 8993
female: 7093
Labor force: 6(X).0IM) (1992)
by iHrit/Hition: industry 1 1.493. commerce,
restaurants, and hotels 10.593, construction
10.093 , transport and communications 8.793,
agriculture 7.493, other services 52.093 ( 1992)
Population; 5 1 2,779 (July 1994 est.)
Population growth rate: 2.56% ( 1 994 est.)
Birth rate: 1 8.83 births/I ,000 population
(1994 est.)
Death rate: 3.53 deaths/1,000 population
(1994 est.)
Net migration rate: 10.31 migrant(s)/l,000
population ( 1 994 est.)
infant mortality rate: 21.6 death.s/ 1 ,(X)0 live
births (1994 est.)
Life expectancy at birth:
total population: 72.64 years
male: 70.08 years
female: 75.09 years (1994 est.)
Total fertility rate: 3.74 children
bom/woman ( 1 994 est.)
Nationality:
noun: Qatari(s)
adjective: Qatari
Ethnic divisions: Arab 40%. Pakistani 18%.
Indian 18%. Iranian 10%i, other 14%
Religion.s: Muslim 95%
Languages: Arabic (official). English
commonly used as a second language
Literacy: age 15 and over can read and write
(1986)
total population: 76%
male: 77%
female: 72%
Labor force: 1 04,000 (85% non-Qatari in
private sector) ( 1983)
Population: 18,196,783 (July 1994 est.)
note: the population ftgure is consistent with a
3,24% growth rate: a 1992 census gives the
number of Saudi citizens as 1 2,304,835 and the
number of residents who are not citizens as
4.624,459
Population growth rate: 3.24% (1994 est.)
Birth rate: 38.25 births/ 1 .(XX) population
(1994 est.)
Death rate: 5.83 deaths/ 1 .(XX) population
(1994 est.)
Net migration rate: Omigrant(s)/l,ono
population ( 1994 est.)
Infiint mortality rate; 52. 1 deaths/l,(XX) live
births (1994 e.st.)
Life expectancy at birth:
total population: 67.91 years
male: 66.25 years
female: 69.65 years (1994 est.)
Total fertility rate: 6.67 children born/
woman (1994 e.st.)
Nationality:
noun: Saudi(s)
a^fei''iise: Saudi or Saudi Arabian
Ethnic divisions: Arab 90%, Afrtt-Asian
lO-^i
Religions: Muslim l(X)%
Languages: Arabic
Literacy: age IS and over can read and write
(1990 est,)
total population: 62%
male: 73%
female: 48%
Labor force: 5 million-6 million
by (Kvupation: government 34%, industry and
oil 28%, services 22%, agriculture 16%.','254a8c57dcd0acb80802630e2322b2cda77b2012b90489789bdb29ad03d4e447','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('856b0e1d95641ff11a8417f8ea88d6c84e1b3744ac3e2252d972379a610952b5',1994,'IE','Ireland','people-and-society',518,'Populatioii; .''..5.''9.296 (July 1994 est )
Population growth rate: 0..''*4 ( 1994 est.)
Birthrate: 14.21 binh.s/ 1, (KM population
(1994 est.)
Death rate: 8.59 deaths/l,(XX) population
(1994 est.)
Net migration rate: -2.67 migrant(s)/l.(XX>
population (I *''94 est.)
Infant mortality rate: 7.4 deaths/ 1 .IX)0 live
births ( 1994 est.)
Life expectancy at birth:
total /K)/>u/ation: 75.68 years
male: 72.85 years
female: 78.68 years (1994 est.)
Total fertility rate: 1 .99 children bom/
woman ( 1994 est.)
Nationality:
noun: Irishman! men). Irishwoman(men). Irish
(collective plural)
adjective: Irish
Ethnic divisions; Critic, English
Religions: Roman Catholic 9.''*4, Anglican
.''*4. none 1*4, unknown 25i . other l*r (1981)
Languages; Irish (Gaelic), spoken mainly in
areas liK''ated along the western seaboard,
English is the language general’y used
Literacy: age 1 5 and over can read and write
(1981 est.)
total inipulation: 98*4
nude: NA*''f
female: NA*^!-
Labor force; I ..''7 million
hy occupation: services 57.0*4 , manufacturing
and construction 28*4. agriculture, forestry.
and fishing l.''.5f^f. energv and mining l.5*>f
(1992)','ff2181f2e389db9505584da3ddc20680bcb4f39899cc3561b443c8e5f9659a82','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1b4956f3eb1f593eff802b95a0e89c323e3c16957820d30669fbc5cd322cd00',1994,'JO','Jordan','people-and-society',527,'Population: 5,050,850 (July 1994 est.)
note: includes 1 10,500 Jewish settlers in the
West Bank, 14,000 in the Israeli-occupied
Golan Heights, 4.500 in the Gaza Strip, and
144,100 in East Jerusalem (1994 est.)
Population growth rate: 2.22% (1994 est.)
Birthrate: 20.55 births/1,000 population
(1 994 est.)
Death rate: 6.43 deaths/ 1,000 population
(1994 est.)
Net migration rate: 8.04 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 8.6 deaths/I ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 77,96 years
male: 75.86 years
female: 80. 1 6 years ( 1 994 est.)
Total fertility rate: 2.83 children bom/
woman (1994 est.)
Nationality:
noun: Israeli(s)
adjective: Israeli
Ethnic divisions: Jewish 83%, non-Jewish
17% (mo.stly Arab)
Religions: Judaism 82%, Islam 14% (mostly
Sunni Muslim), Christian 2%, Druze and other
2%
Languages: Hebrew (official), Arabic used
officially for Arab minority, English most
commonly used foreign language
195
Israel (continued)
Literacy: age IS and over can read and write
(1983)
total population: 92%
male: 95%
female: 89%
Laborforce: 1.9 million (1992)
hv occupation: public .services 29.3%, industry
22. 1 %, commerce 1 3.9%, flnance and business
10.4%, personal and other services 7.4%.
construction 6.5%, transport, storage, and
communications 6.3%, agriculture, forestry,
and fishing 3.5%, other 0.6% (1992)','49472be061e698554e9d0b79c1de03453d88b78b61a745dae672d88703d73af2','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2115cd844e4761a4d17b63ef4ff05a16041148112a00cb101594a8be61b47d1',1994,'IT','Italy','people-and-society',532,'Population: 58,138,394 (July 1994 est.)
Population growth rate: 0.2 1 % ( 1 994 est.)
Birth rate: 1 0.79 births/ 1 ,000 piopulation
(1994 est.)
Death rate: 9.71 deaths/ 1,0(X) population
(1994 est.)
Net migration rate: 1 .03 migrant(s)/ 1 ,000
population ( 1994 est.)
Infant mortality rate: 7.6 deaths/I, 0(X) live
births (1994 est.)
Life expectancy at birth:
total population: 11. (A years
male: 74.44 years
female: 81 .04 years (1994 est.)
Total fertility rate: 1 .39 children bom/
woman (1994 est,)
Nationality:
noun: Italian{s)
adjective: Italian
Ethnic divisions: Italian (includes small
clusters of German-, French-, and Slovene-
Italians in the north and Albanian-ltalians and
Greek-ltalians in the south), Sicilians,
Sardinians
Religions: Roman Catholic 98%, other 2%
Languages: Italian, German (parts of
Trentino-Alto Adige region are predominantly
German speaking), French (small French-
speaking minority in Valle d'' Aosta region),
Slovene (Slovene-speaking minority in the
Triesle-Gorizia area)
Literacy: age IS and over can read and write
(1990 est.)
total population: 97%
male: 98%
female: 96%
Labor force: 23.988 million
by occupation: services 58%, industry 32.2%,
agriculture 9.8% (1988)','fae053aa40d5860278398473eb562dcbdd8598e2acdebfb3c73c7c7dadb27368','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a3fc7bfd2aacbe9c0894460a89ef0bf6c3d4c13fd9beb7a31ccc21a0ad2d0fb',1994,'JM','Jamaica','people-and-society',535,'Population: 2,555,064 (July 1994 est.)
Population prowth rate: 1 .0291 1 1994 est. )
Birth rate: 2 1 .69 births/ 1 .(MX) population
1 1994 est.)
Death rale: 5.62 deaths/l .OtN) ptspulaiion
(1994 est.)
Net miftration rate: -5.9migrant(s)/LnO()
population 1 1994 est.)
Infant mortality rate: 1 6.8 deaths/ 1 ,0tl0 live
births ( 1994 est.)
Life expectancy at birth:
total iHtpulatum: 74. .16 years
mde: 72. 16 years
female: 76.68 years ( 1994 est.)
Total iertlHty rate: 2.41 children bom/
woman (1994 est.)
NationaHty:
noun: Jamaican) s)
adjective: Jamaican
Ethnk divisions: African 76..l9f, Afitv
European 15. IT, East Indian and Afro-East
Indian .IT. white .1.2T. Chine.se and Afnv
Chinese I.2T. other I.2T-
Religions: Protestant 55.9T (Church of Cnxi
I8.4T, Baptist lOT. Anglican 7. IT. Seventh-
Day Adventist 6.9T. Pentecostal 5.2T.
Methodist .1. IT. United Church 2.7T. other
2.5T). Roman Catholic .5T. other, including
some spiritual cults .19.IT ( 1982)
Languages: English. Creole
Literacy: age 15 and over having ever
attended school ( 19*^ est.)
total population: 9.. .f
male: 98T
female: 99T
Labor force: 1.062.100
by occuiKition: services 4 1 T . agriculture
22. 5T. industry 19T, unemployed I7..5T
(1989)','0db23220528351d77c2297a9cf1d6f146ca0b2a5ab9f47dbabc6b898ac003264','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42e05fff590fc9d670c8e540a0c50a94122bd3b182b3e4e8e51bbf383663000e',1994,'JP','Japan','people-and-society',538,'Pttpvlatfon: mi permanent inhahitanls;
nme — there arc personnel who man the
LORAN C base and the weather uml coastal
services radio station
Govcmmeiit
Names:
ronvfnlionnl limy form: none
i-om-fniiomil siwn form: Jan Mayen
Digraph: JN
Type: territory of Norway
Capital: none: administered from Oslo.
Norway, through a governor tsysselmann)
resident in Longyearhyen (Svalbard)
Indcpetidcncc: none (territory of Norway)
Popvfaitioii; 125.106.9.^7 (July 1994 cst.)
PofMlalkm growth rate: 0..^2‘^ 1 1994 est.)
Birth rate: 1 0.49 births/ 1 ,000 population
(1994 est.)
Death rate: 7..t| deaths/ 1, (XX) population
( 1994 est.)
Net migration rate: 0 migran((s)/l.0(X)
population ( 1994 est.)
Infant mortality rale: 4..^ deaths/ 1. (XX) live
births (1994 est.)
Life expectancy at Urth:
total population: 79..^ I years
male: IbAl years
female: 82.28 years (1994 est.)
Total fertility rate: 1 .55 children bom/
woman ( I9''>4 est.)
Nationality:
noun: Japanese (singular and plural)
adjective: Japanese
Ethnic divisions; Japanese 99.49f . other
0.6% (mostly Korean)
Religions: observe both Shinto and Buddhist
84%, other 16% (including 0.7% Christian)
Languages: Japanese
Literacy: age 15 and over can read and write
(1970 est.)
total population: 999(
male: NA%
female: NA%
Labor force: 6.''). .1.1 million
by (H''cu/tation: trade and services 54%,
manufacturing, mining, and construction .1.1%,
agriculture, forestry, and tlshing 7%.
government .1% (1988)
Population; 45,082,880 (July 1994 est.)
Population gmwtb rate; 1 .04''^ ( 1 994 e.st.)
Rirtb rate: 15.7 birth.s/ 1 .(X8) population
( 1994 est.)
Death rate; 6. 1 7 deaths/ 1 ,000 population
(1994 est.)
Net migration rate: 0.91 migranl(s)/l.(XX)
population ( 1994 est.)
Infant mortality rate: 21.7 deaths/I .000 live
births (1994 est.)
Life expectancy at birth:
total /loindiition: 70.59 years
male; 67,. 19 years
female: 7.1.98 years (1994 est.)
Total fertility rate; 1 .65 children birm/
woman ( 1994 est.)
Nationality:
noun: Korean! s)
adjective: Korean
Ethnic divisions; homogeneous (except for
about 20.tX)0 Chinese)
Religions: Christianity Buddhism
47,4''T, Confucianism .I''X-, pervasive foik
religion (shamanism), Chondogyo (Religion of
the Heavenly Way) 0.2%
Languages: Korean. English widely taught in
high schiml
Literacy: age 15 and over cun read and write
(1990 est.)
total popiiiation: 96''S
male; 99‘(-
female; 99%
Labor force: 20 million
hy occuiHition; services and other 52%. mining
and manufacturing 27% , agriculture, fishing,
fore.stry 21% (1991)
Population; 6,741 (July 1994 est.)
Population growth rate: 0.3 1 % ( 1 994 est.)
Birth rate: 9.64 binlis/t,0(X) population
(1994 est.)
Death rate: 6.55 deaths/ 1 ,(X)0 population
(1994 est.)
Net migration rate: 0migrant(s)/l,0(X)
population (1994 est.)
Infant mortality rate: 37,24 deaths/1,000
live births (1994 est.)
Life expectancy at birth:
total population; 74.75 years
male: 72.68 years
female; 76.58 years (1994 est.)
Total fertility rate: 1.14 children bom/
woman (1994 est.)
Nationality:
noun: Saint Helenian(s)
adjective; Saint Helenian
Ethnic divisions: NA
Religions: Anglican (majority). Baptist,
Seventh-Day Adventist, Roman Catholic
Languages: English
Literacy: age 15 and over can read and write
(1987)
total population: 98%
male; 97%
female; 98%
Labor force: 2,516
by occupation; proiessional. technical, and
related workers 8.7%, managerial,
administrative, and clerical 12,8% .sales
people 8,1%, farmer, fishermen, etc. 5.4%.
craftspersons, production process workers
14,7%, others 50.3% (1 987)
Population: 40.671 (July I994est.)
Population growth rate: 0.72% ( 1 994 est. )
Birth rate: 2.1.7 births/1.000 population
(1994 est.)
Death rate: 9.98 deaths/ 1 .(XK) population
(I994e.st.)
Net migration rate: -6.S2 migrant(s)/l,000
population ( 1994 est.)
Infant mortality rate: 1 9.9 deaths/ 1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 66.1 1 years
mn/e.'' 63. 14 years
female: 69.27 years (1994 est.)
Total fertility rate: 2.6children bom/woman
(1994 est.)
Nationality:
noun: Kittsian(s), Nevisian(s)
adjective: Kittsian. Nevisian
Ethnic divisions: black African
Religions: Anglican, other Protestant sects,
Roman Catholic
Languages: English
Literacy: age I S and over having ever
attended school (1970)
total population: 98%
male: 98%
female: 98%
Labor force: 20,000(1981)','f0aaef0d1c0f8b54f1a57931b426831804648fb799d15a7c00518f4f0a952598','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('508972f9396982ac6a9d0a208867714af1618d4ca9a4f936b8687d87da83c6c1',1994,'KE','Kenya','people-and-society',548,'Population: 28,240.658 (July 1994 est.)
Population growth rate: .5.07% ( 1 994 est.)
Birthrate: 42.44 births/1,000 population
(1994 est.)
Death rate: 1 1 .74 deaths/I .0(X) population
(1994 est.)
Net migration rate; 0 migrant(s)/I,(X)0
population (1994 est.)
Infant mortality rate: 74. 1 deaths/I .000 live
births (1994 est.)
Life expectancy at birth:
total population: 55.23 years
male: 5 1 .48 years
female: 55.03 years (1994 est.)
Total fertility rate: 5.91 children born/
woman (1994 est.)
Nationality:
noun: Kenyan(s)
tuljective: Kenyan
Ethnic divisions: Kikuyu 22%. Luhya 14%,
Luo 13%, Kalenjin 12%. Kamba 1 1%. Kisii
6%, Meru 6%, Asian, European, and Arab I %.
other 15%
Religions: Roman Catholic 28%. Protestant
(including Anglican) 26%, indigenous beliefs
18%, Muslim 6%
Languages; English (official). Swahili
(official), numerous indigenous languages
Literacy; age 15 and over can read and write
(I990e.sl.)
total population: 69%
male: 80%
female: 58%
Labor force; 9.2 million (includes
unemployed); the total employed is l.,57(),0(X)
(14.8% of the labor force)
hy occupation: agriculture 75-80% ( 1 993 est.).
non-agriculture 20-25% ( 1993 est.)','27984bac60260fc0e62d824c59db7a0264fab3680b82f582174676dbc753a503','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77a2f068fccb472ff8077990905cfaaa6719290dbd47ec11360ba80a06c68a17',1994,'AS','American Samoa','people-and-society',556,'Population: uninhabited
Population; 77,853 (July 1994 est.)
Population growth rate: 1 .99% (1994 est.)
Birth rate; 3 1 .64 births/ i ,000 population
(1994 est.)
Death rate; 1 2.3 1 deaths/! ,000 population
(1994 est.)
Net migration rate; 0.56 migrant(s)/ 1 .(XX)
population (1994 est.)
Infant mortality rate: 98.4 deaths/ 1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 5‘^. 16 years
male: 52.56 years
female: 55.78 years (1994 est.)
Total fertility rate; 3.77 children bom/
woman (1994 est.)
Nationality:
noun: i-Kiribati (singular and plural)
adjective: 1-Kiribati
Ethnic divisions; Micronesian
Religions; Roman Catholic 52.6%, Protestant
(Congregational) 40.9%, Seventh-Day
Adventist, Baha''i, Church of God, Mormon
6% (1985)
Lang''- es: English (ofricial), Gilbertese
Literacy;
total population: NA%
nifl/e: NA%
female: NA%
Labor force: 7,870 economically active, not
including subsistence farmers (1985 est.)
Population: 23,066,573 (July 1994 est.)
Population growth rate; 1 .83% ( 1 994 est.)
Birth rate: 23.75 births/ 1 ,000 population
(1994 est.)
Death rate: 5.5 deaths/i.OOO population
(1994 est.)
Net migration rate: 0 migrant(s)/l,000
population ( 1994 est.)
Infant mortality rate: 27.7 deaths/I .0(K) live
births (1994 est.)
Life expectancy at birth:
total population: 69.78 years
male: 66.69 years
female: 73.02 years (1994 est.)
Total fertility rule: 2.37 children bom/
woman (1994 est.)
Nationality;
noun: Korean(s)
adjective: Korean
Ethnic divisions: racially homogeneous
Religions: Buddhism and Confucianism,
some Christianity and syncretic Chondogyo
note: autonomous religious activities now
almost nonexistent; government-sponsored
religious groups exist to provide illusion of
religious freedom
Languages: Korean
Literacy: age 1 5 and over can read and write
(1990 est.)
total population: 99%
male: 99%
female: 99%
Labor force: 9.615 million
by occupation: agricultural 36%,
nonagricultural 64%
note: shortage of skilled and unskilled labor
(mid- 1987 est.)
Population: uninhabited
305
Palmyra Atoll (continued)','64c5cdd8d43213114f6ea76daac81b4450baa71d9468cb0590317970b897dbfc','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a55040b88c75e6d7567fd5c3c8555c9aa0f72792fa8139569c48102480578e00',1994,'KZ','Kazakhstan','people-and-society',562,'Population: 4,698,108 (July 1994 est.)
Populi tion growth rate: 1 .53% ( 1 994 est.)
Birthrate: 26.33 births/I, 0(X) population
(1994 ist.)
Dead'', rate; 7.36 deaths/1,000 population
(1994 tst.)
Net mi>jration rate: -3.64 migrant(s)/l ,000
population ( 1 994 est.)
Infant mortality rate: 46.8 deaths/ 1 ,000 live
births (1 994 est.)
Life expectancy at birth:
total population: 67.92 years
male: 63.69 years
female: 72.35 years ( 1994 est.)
Total fertility rate: 3.35 children bom/
woman (1994 est.)
Nationality:
noun: Kyrgyz(s)
adjective: Kyrgyz
Ethnic divisions: Kirghiz 52.4%, Russian
21.5%, Uzbek 12.9%, Ukrainian 2.5%,
German 2.4%, other 8.3%
Religions: Muslim 70%, Russian Orthodox
NA%
Languages: Kirghiz (Kyrgyz) — official
language, Russian widely used
Literacy; age 9-49 can read and write (1970)
total population: 100%
male: 100%
female: 100%
Labor force: 1 .836 million
by occupation: agriculture and forestry 38%,
industry and construction 21%, other 41 %
(1990)
Population: 4,701,654 (July 1994 est.)
Population growth rate: 2.85% ( 1994 est.)
Birth rate: 43.23 births/l.(X)() population
(1994 est.)
Death rate: 1 4.74 deaths/I ,000 population
(1 994 est.)
Net migration rate: 0 migrant(s)/l,(X)0
population ( 1 994 est.)
Infant mortality rate: 1 0 1 .8 deaths/ 1 ,000
live births (1994 est.)
Life expectancy at birth:
total population: 5 1 .68 years
male: 50. 1 6 years
female: 53.28 years (1994 est.)
Total fertility rate: 6.07 children born/
woman (1994 est.)
Nationality:
noun: Lao(s) or Laotian(.s)
adjective: Lao or Laotian
Ethnic divisions: Lao 50%, Phoutheung
(Kha) 15%, tribal Thai 20%. Meo. Hmong,
Yao, and other 15%
Religions; Buddhist 85%, animist and other
15%
Languages: Lao (ofricial). French, English
Literacy: age l5-45canreadand write(l993)
total population: 64%
male: NA%
female: NA%
Labor force: I million- 1.5 million
by occupation: agriculture 85-90% (est.)','92e91de9f87a5418755031b37a01625cfdab1b50124881b2e38b32dcaab91933','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('863bb790cc25deb2c75082159b9bffe2fb4e024dd7fc31708fa8241c0ad43158',1994,'LV','Latvia','people-and-society',567,'Population: 2,749,211 (July 1994 est.)
225
Latvia (continued)
Population growth rate: 0.5% (1994 est.)
Birth rate: 1 3.84 births/ 1 ,000 population
(1994 est.)
Death rate: 1 2.6 1 deaths/ 1 ,000 population
(1 994 est.)
Net migration rate: 3.74 migrant(s)/l,(XX)
population (1994 est.)
Infant mortality rate: 2 1 .5 deaths/ 1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 69.44 years
male: 64.37 years
female: 74.75 years (1994 est.)
Total fertility rate: 1 .98 children born/
woman (1 994 est.)
Nationality:
noun: Latvian(s)
adjective: Latvian
Ethnic divisions: Latvian 5 1 .8%, Russian
.33.8%. Byelorussian 4.5%, Ukrainian 3.4%,
Polish 2.3%, other 4.2%
Religions: Lutheran, Roman Catholic.
Russian Orthodox
Languages: Lettish (ofTicial), Lithuanian,
Russian, other
LIteraey: age 9-49 can read and write (1970)
total population: 100%
male: 100%
female: 100%
Labor force: 1 .407 million
by occupation: industry and construction 41%,
agriculture and forestry 1 6%, other 43% ( 1 990)','7900e8e645e9472710de465a360c58caae2fec2bec185eb5d7fbd30801ea4656','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4f43f1965921413aa2a0c6612b546bb762c957a15ebc1bfa653de89e414e56b',1994,'LB','Lebanon','people-and-society',572,'Population: 3,620,395 (July 1994 est.)
Population growth rate: 1 .98% (1994 est.)
Birth rate: 27.89 births/1.000 population
(1994 est.)
Death rate: 6.55 deaths/I. 000 population
(1994 est.)
Net migration rate: - 1 .52 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 39.5 deaths/I ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 69.35 years
male: 66.92 years
female: 7 1 .9 years ( 1994 est.)
Total fertility rate: 3.39 children bom/
woman (1994 est.)
Nationality;
noun; Lebanese (singular and plural)
adjective: Lebanese
227
Lebanon (amtinued)
Ethnic divisions: Arab 95%, Armenian 4%,
other 1%
Religions: Islam 70% (5 legally recognized
Islamic groups — Alawile or Nusayri, Druze,
Isma''ilite, Shi''a, Sunni), Christian 509^ ( 1 1
legally recognized Christian groups — 4
Orthodox Christian. 6 Catholic, I Protestant).
Judaism NEGL%
Languages: Arabic (official), French
(official), Armenian, English
Literacy: age 1 5 and over can read and write
(1990esl.)
total population: 80%
male: 88%
female: 73%
Labor force: 650,(X)()
hy occuimtion: industry, commea''e, and
services 79%, agriculture 1 1 %, government
10% (1985)
Population: 14,886,672 riuly 1994 est.)
note: in addition, there are .''(),5(X) people
living in the Israeli-occupied Oolan Heights-
16,500 Arabs ( 15,(MX) Druze and 1 ,5(K)
Alawiies) and I4,(KX) Jewish settlers (1994
esi.)
Population growth rate: 5.74^ ( 1994 est.)
Birth rate: 43.65 births/1,000 population
(1994 est.)
Death rate: 6.25 dcaths/l,(X)0 population
(1994 est.)
Net migration rate: 0 migrun((s)/l,(X)0
population ( 1994 est.)
Inftint mortality rate: 42,5 deaths/ 1 .(XXI live
births ( 1994 est.)
Life expectancy at birth:
loitil fHtpuUitlon; 66,46 years
»i«/e.‘ 65.37 years
female: 67.61 years ( 1994 est.)
Total fertility rate; 6.65 children bimt/
woman (1994 est.)
Nationality:
noun: Syrian(s)
udjective: Syrian
Ethnic divisions; Arab 9().3(;f, Kurds,
Armenians, and other 9.7'';f
Religions; Sunni Muslim 749f, Alawite,
Druze, and other Muslim sects I6*;f , Christian
(various sects) lO''Jf, Jewish (tiny communities
in Damascus. Al Qamishli, and Aleppt^)
Languages; Arabic (official). Kurdish,
Armenian, Aramaic. Circassian. French widely
understood
Literacy: age 1 5 and over cun read and write
(1990)
total population: 64 9}-
male: 78*^
female: 5 1 (T
Labor force: 2.951 million (1989)
hy <H-cuiHition: miscellaneous and government
serx ices 36%. agriculture 32%, industry and
construction 32%; note — shortage of skilled
lutKW(l984)
Population: 5,99.5,469 (July 1994 est.)
Population growth rate: 2.67''if( 1994 est.)
Birth rale: .34.79 birlhs/t .(X)0 population
( 1994 est.)
Death rate: 6.71 deaths/I, (X)0 population
(1994 est.)
Net migration rate: - 1 .4.3 migrant! sV 1 ,000
population ( 1994 est.)
Infbnt mortality rate: 62 deaths/I ,0(X) live
births ( 1994 est.)
Lift expectancy at birth:
total population; 68.76 years
male: 65.88 years
female; ^ 1 .79 years ( 1994 est.)
Total Itrtility rate: 4.62 children
bom/woman ( 1994 est.)
''.Nationality''.
noun: Tajik(s)
adjeetive: Tajik
Ethnic divisions: Tajik 64.99t. Uzbek 25%.
Russian .3.5% (declining because of
emigration), other 6.6%
Religions; Sunni Muslim 80%. Shi''a Muslim
5%
Languages: Tajik (ofTicial). Russian widely
used in government and business
Literacy: age 9.49 can read and write ( 1 970)
total population: 100%
nude: l()0%
female: 99%
Labor force; 1 .95 million ( 1 992)
hy mrupatum; agriculture and forestry 4,3%,
government and services 24%, industry 14%.
trade and communications 11%, construction
8% (1990)','dbd82859fc4f89cb864d7bd32a46ff1c0c2ff1453a74b2cb133497dbd6ac0896','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9074e9507ef369b1f7f9218917ef8aa92afee66a3d3bf3242411342e9a0beb15',1994,'ZA','South Africa','people-and-society',577,'Population: 1,944,493 (July 1994 est.)
Population growth rate: 2.48% (1994 est.)
Birth rate: 34 births/ 1 ,0(X) population ( 1 994
est.)
Death rate: 9.19 deaths/ 1 ,000 population
(1994 est.)
Net migration rate; 0 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 69.5 deaths/I, (KK) live
births (1994 est.)
Life expectancy at birth:
total population: 62.14 years
male: 60.32 years
female: 64.01 years (1994 e.st.)
Total fertility rate: 4.5 children bom/woman
(1994 est.)
Nationality:
noun: Mosotho (singular), Basotho (plural)
adjective: Basotho
Ethnic divisions; Sotho 99.7%, Europeans
1 ,600, Asians 800
Religions: Christian 80%, rest indigenous
beliefs
Languages: Sesotho (southern Sotho),
English (official), Zulu, Xhosa
Literacy; age 1 5 and over can read and write
(1966)
total population: 59%
male; 44%
female: 68%
Labor force: 689,000 eeonomically active
by occupation: 86.2% of resident population
engaged in subsistence agriculture; roughly
60% of active male labor force works in South
Africa
Population; 1,595,567 (July 1994 est.)
Population growth rate: 3.45% (1994 est.)
Birthrate: 43.4 births/I.OOO population
(1994 est.)
Death rate: 8.87 deaths/ 1, (X)0 population
(1994 est.)
Net migration rate; 0 migrant(s)/l,0()0
population (1994 est.)
Infant mortality rate: 61.8 deaths''!, 000 live
births (I994e.st.)
Life expectancy at birth:
total population: 6 1 .65 years
male: 58.97 years
female: 64.4 years (1994 est.)
Total fertility rate: 6.4 children born/woman
(1994 e.st.)
Nationality:
noun: Namibian(s)
adjective: Namibian
Ethnic divisions: black 86%, white 6.6%,
mixed 7.4%
note; about 50% of the population belong to
the Ovambo tribe and 9% to the Kavangos tribe
Religions; Christian
Languages: English 7% (official), Afrikaans
common language of most of the population
and about 60% of the white population,
German 32%, indigenous languages
Literacy: age 15 and over can read and write
(1960)
total population; 38%
male: 45%
female: 3 1 %
Labor force; 500,000
hv occupation: agriculture 60%, industry and
commerce 19%, services 8%, government 7%,
mining 6% (1981 est.)
Population; 43.930,631 (July 1994 est.)
Population growth rate: 2.6297 (1994 est.)
Birth rate: 33.58 births/1.000 population
(1994 est.)
Death rate: 7.53 deaths/1,000 population
(1994 est.)
Net migration rate: 0. 1 6 migrant(s)/l ,000
population (1994 est.)
Infant mortality rate: 47.1 deaths/ l.0(X) live
births (1994 est.)
Life expectancy at birth:
total population: 65.11 years
male: 62.37 years
female: 67.94 years ( 1994 est.)
Total fertility rale: 4.37 children bom/
woman (1994 est.)
Nationality;
noun: South African(s)
adjective: South African
Ethnic divisions: black 75.297. white 13.697,
Colored 8.697, Indian 2.697
Religions; Christian (most whites and
Coloreds and about 6097 of blacks), Hindu
(6097 of Indians), Muslim 297
Languages: eleven official languages.
including Afrikaans. English. Ndebele. Pedi,
Sotho. Swati. Tsonga, Tswana. Venda. Xhosa.
Zulu
Literacy: age 15 and over can read and write
(1980) ‘
total population: 7697
male: 789i
female: 7597
Labor force: 1 3,4 million economically
active (1 990)
by occupation: services 3597. agriculture 3097.
industry 20%. mining 997. other 697
363
South Africa (continued)','08cf5aa242fa2ad847c79da52e3c5e4903984072529f09c56362498edb94a60b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f20504b00c42b16beb320cd2efc0d88ca69c8854df5e4d43fa3e394e211b4d8',1994,'LR','Liberia','people-and-society',583,'Population; 2,972,766 (July 1994 est.)
Population growth rate: 3.33% ( 1 994 est.)
Birthrate: 43.48 births/ 1, 000 population
(1994 est.)
Death rate: 1 2.34 deaths/I .000 population
(1994e.st.)
Net migration rate; 2. 1 6 migrant(s)/l ,000
population ( 1994 est.)
Inftmt mortality rate: 1 1 3.3 deaths/ 1 ,000
live births (1994 est.)
Life expectancy at birth:
total population: 57.73 years
male: 55.27 years
female: 60.25 years (1994 est.)
Total fertility rate: 6.36 children bom/
woman (1994 est.)
Nationality:
noun: Liberian(s)
adjective: Liberian
Ethnic divisions; indigenous African tribes
95% (including Kpelle, Bassa, Gio, Kru,
Grebo, Mano, Krahn. Gola, Gbandi, Loma,
Kissi, Vai, and Bella), Americo-Liberians 5%
(descendants of repatriated slaves)
Religions: traditional 70%, Muslim 20%,
Christian 10%
Languages: English 20% (official), Niger-
Congo language group about 20 local
languages come from this group
Literacy: age 15 and over can read and write
(1 990 est,)
total population: 40%
male: 50%
female: 29%
Labor force: 510,000 including 220,000 in
the monetary economy
by occupation: agriculture 70.5%, services
10.8%, industry and commerce 4.5%, other
14.2%
note: non-African foreigners hold about 95%
of the top-level management and engineering
jobs: 52% of population of working age
Population: 4,630,037 (July I994est.)
Population growth rate: 2.62% ( 1 994 est.)
Birthrate: 45.06 births/1,000 population
(1994 est.)
Death rate: 18.87 deaths/1,000 population
(1994 est.)
Net migration rate: 0 migrant(s)/l,0(X)
population (1994 est.)
Infant mortality rate: 1 4 1 .9 deaths/I ,000
live births (1994 est.)
Life expectancy at birth:
total population: 46.4 years
male; 43.58 years
female: 49.3 years (1994 est.)
Total fertility rate: 5.96 children
born/woman (1994 est.)
Nationality:
noun: Sierra Leonean(s)
adjective: Sierra Leonean
Ethnic divisions: 13 native African tribes
99% (Temne .30%. Mende 30%, other 39%),
Creole, European, Lebanese, and Asian 1%
Religions: Muslim 60%, indigenous beliefs
30%, Christian 10%
Languages; English (ofncial: regular use
limited to literate minority), Mende principal
vernacular in the south, Temne principal
vernacular in the north, Krio the language of
the re-.settled ex-slave population of the
Freetown area and is lingua franca
Literacy: age 15 and over can read and write
English, Merde. Temne, or Arabic ( 1 990 est.)
total population; 2 1 %
male: 3 1 %
female: 1 1 %
Labor force: 1 .369 million (1981 est.)
hy occupatioit: agriculture 65%. industry 19%,
services 16% (1981 est.)
note: only about 65.000 wage earners (1985);
55% of population of working age','b978f2a7dfff21d1bfd28a720341a4932b2c6b2be55037b45836c5d0e6b53cf7','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20ef73a4cec0e32d85544fe2d1a715e61e615f193c8f019b958a7e9eff627873',1994,'LY','Libya','people-and-society',589,'Population: 5,057.592 (July 1994 est.)
Population growth rate: 5.72% ( 1994 est.)
Birth rate: 45.29 biiths/l.flOO population
(1994 est.)
Death rate: 8.14 deaths/l,0(X) population
(1994 est.)
Net migration rate: 0 migrant(s)/1.000
population ( 1 994 est.)
Infant mortality rate: 65.4death,s/l ,(XX) live
births (1994 est.)
Life expectancy at birth:
total population: 65,88 years
male: 61.75 years
female; 66, 1 5 years ( 1994 e.st.)
Total fertility rate: 6.58 children
born/woman (1994 e.st.)
Nationality:
noun; Libyan(s)
uc(jective: Libyan
Ethnic divisions: Berber and Arab 97%,
Greeks. Maltese. Italian.s. Egyptians.
Pakistanis. Turks, Indians, Tunisians
Religions; Sunni Muslim 97%
Languages; Arabic, Italian, English, all are
widely understood in the major cities
Literacy: age IS and over can read and write
(1990 est.)
total population; 64%
male: 75%
female: 50%
Labor force: I million (include.s about
280,000 resident foreigners)
h\\ occupation; industry 51%, services 27%,
government 24%. agriculture 1 8%-
PopulalhMi: 8.726,.562 (July 1994 est.)
Population growth rate: l.76'')(''( 1994 est.)
Birth rate: 23.4 binhs/1,000 population
1 1994 est.)
Death rate: 4,95 deaths/ 1 ,0tX) population
(1994 est.)
Net migration rale: -0.85 mlgrani(s)/l,000
population (1994 est.)
Inflint moniality rate: 34. 1 deaths/ 1 ,000 live
births (1994 est.)
Life expectancy at birth:
nml population; 72.89 years
male; 70.85 years
female: 75.03 yeois ( i 994 est. )
Total fertility rate: 2.88 children bom/
woman ( 1994 est.)
Nationality:
Tunisiuii(s)
luffective; Tunisian
Ethnic divisions: Arab-Berber 98^.
European I*!!. Jewish le.ssthan 1^
Religions: Muslim989f, Christian 191.
JewLsh 1%
Languages: Arabic (official and one of the
languages of commerce), French (commerce)
Literacy: age 15 and over cun read and write
(1990 est.)
total pttpulaiion: 659(''
male; 74**''
feimile; 56%
I.aibor force: 2.25 million
hy tK''cupation; agriculture 32%
note; shortage of skilled labor
Population: 62,153,898 (July 1994 est.)
Population growth rate: 2.02% (1994 est.)
Birth rate: 25.98 bitths/1,000 population
(1994 est.)
Death rate: 5.8 deaths/1,000 population
(1994 est.)
Net migration rate: 0 migrant(s)/1 ,000
population (1994 est.)
Infant mortality rate: 48.8 deaths/I ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 70.94 years
male: 68.61 years
female: 73.38 years (1994 est.)
Total fertility rate: 3.21 children bom/
woman (1994 est.)
Nationality:
noun: Turk(s)
adjective: Turkish
Ethnic divisions: Turkish 80%, Kurdish 20%
Religions: Muslim 99.8% (mostly Sunni),
other 0.2% (Christian and Jews)
Languages: Turkish (official), Kurdish.
Arabic
Literacy: age 15 and over can read and write
(1990 est.)
total population: 8 1 %
male: 90%
female: 7 1 %
Labor force: 20.8 million
by occupation: agriculture 48%. services 32%,
industry 20%
note: about 1 ,800,000 Turks work abroad
(1993)','13b42bac5e96768fda35b0f0f5e818935432fc9eee3de03880ca795363d3694a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be714e76c514ea9b0733d158d77ea89dc097d55bafdb23cdd914a158e81a61a6',1994,'LI','Liechtenstein','people-and-society',595,'Population: 3(),28l(July 1994 esi.)
Population growth rate: 1 . ( 1 994 cst. )
Birth rate: 1 3.08 births/ 1 ,000 pupulaOon
(I994est.)
Death rate: b.6 deaths/I ,(XX) pupulution
(I994est.)
Net migration rate: b.ll migrum(s)/l.(XX)
population ( 1994 esi.)
Infknt nnortallty rate: .3.3 deaths/ 1. (XX) live
births ( 1994 est.)
Life expectancy at birth:
toutl fHtpuUitmu 77.46 years
mule; 73.76 years
feniule; 8 1 .03 years ( 1 994 est.)
Total fertility rate: 1 .46 children
bom/womun ( 1 994 est. )
Nationality:
noun; Liechtensteinerts)
lutjeciive; Liechtenstein
Ethnic divisions: Alemannic 95%, Italian
and other 5%
Religions: Roman Catholic 87.3%, Protestant
8.3%, unknown 1 .6%, other 2.8% (1988)
Languages: German (official). Alcmannic
dialect
Literaev; age 10 and over cun read and write
(1981) ■
total iHtpulatlon; 100%
male; 100%
female; KX)*.;)-
Labor force: 19,90.5 of which 1 1,933 are
foreigners: 6,885 commute from Austria and
Switzerland to work each day
by inruixition; industry, trade, and building
53.2%, services 45%, agriculture, fishing,
forestry, and horticulture 1 .8% (1990)','171d821c6abb707336091209247a16b555bf9436dd31e148acdf23d40295d403','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94cba1601616887d880cdaadbd189db1f4f510fcba7928bde666b18fdf81b042',1994,'LU','Luxembourg','people-and-society',606,'Population; 401,900 (July I994e.st.)
Population growth rate: 0.8% ( 1 994 est.)
Biilh rate: 1 2.8 1 births/I ,000 population
(1994 est.)
Death rate: 9.47 death.s/1,000 population
(1994 est.)
Net migration rate: 4.7 migrant(s)/l ,000
population (1994 est.)
Infant mortality rate: 6.8 deaths/1,000 live
births (1994 est.)
Life expectancy at birth:
total population: 76.69 years
male: 73.01 years
female: 80.52 years (1994 est.)
Total fertility rate: 1 .64 children bom/
woman (1994 est.)
Nationality:
noun: Luxembourger(s)
adjective: Luxemburg
Ethnic divisions: Celtic base (with French
and German blend), Portuguese. Italian, and
European (guest and worker residents)
Religions: Roman Catholic 97%, Protestant
and Jewish 3%
Languages: Luxembourgisch. German,
French, English
Literacy: age 1 5 and over can read and write
(1980 est.)
total population: 100%
male; 100%
female; 100%
Labor force: l77.3tX) (one-third of labor
force is foreign workers, mostly from Portugal,
Italy, France, Belgium, and Germany)
h\\ occupation: services 65%, industry 3 1 .6%.
agriculture 3.4% (1988)','bd9b6d4c97b3804b41a9b48e365c15bce68b49bd6621895112e2ee9117bb00b2','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b8379d70acff7034336f27d141a7154b6cccb0b2797cb315e218a601888d5c3',1994,'FR','France','people-and-society',609,'Population: 484,557 (July 1994 est.)
Population growth rate: 1.35% (1994 est.)
Birth rate: 14.78 births/I ,000 population
(1994 est.)
Death rate: 4. 1 2 deaths/I ,000 population
(1994 est.)
Net migration rate: 2.83 migrant(s)/l,000
population ( 1 994 est.)
239
Mac;>U (continued)
Infant mortality rate; S.5 deaths/ 1 ,000 live
births (1994 est.)
Life expectancy at birth;
total population: 79.75 years
male: 77.33 years
female: 8?.3 years (i994 est.)
Total fertility rate; i .46 children
born/woman (1994 est.)
Nationality;
noun: Macanese (singular and plural)
adjective: Macau
Ethnic divisions: Chinese 95%. Portuguese
3%, other 2%
Religions: Buddhist 45%, Roman Catholic
7%, Prote.stant I %. none 45.8%, other i .2%
(1981)
Languages: Portuguese (official), Cantonese
is the language of commerce
Literacy: age 15 and over can read and write
(1981)
total population: 90%
male: 93%
female: 86%
Labor force: 1 80,000 (1986)
hy occupation: NA
Population: 39.302,665 (July 1994 e.st.)
Population growth rate: 0.25% ( 1 994 est.)
Birth rate: 1 1 .05 births/ 1 .000 population
(1994 est.)
Death rate: 8.82 deaths/ 1, 0(K) population
(1994 est, )
Net migration rate: 0.27 migrant(s)/ 1 ,000
population (1994 est.)
Infant mortality rate; 6.9 deaths/1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 77.71 years
male: 74.45 years
female: 8 1 .2 1 years ( 1 994 est.)
Total fertility rate: 1 ,4 children bom/woman
(1994 est.)
Nationality:
noun: Spaniard(s)
adjective: Spani.sh
Ethnic divisions; composite of
Mediterranean and Nordic types
Religions: Roman Catholic 99%, other sects
1%
Languages: Castilian Spanish, Catalan 1 7%.
Galician 7%. Ba.sque 2%
Literacy: age 15 and over can read and write
(1990 est.)
total population: 95%
male: 97%
female: 93%
Labor force: 14.621 million
hy occupation: services 53% . industry 24%,
agriculture 14%, construction 9% (1988)','a564fbe1fd7e34b6e4f6570fab481dfce9413cb80c8337e997f4e165c85aa3f3','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e38b4f0ef7f54920babfa1585afd83c6d13de8271dfef9a544969d587d8fe1b',1994,'MW','Malawi','people-and-society',612,'Population; 9,732,409 (July 1994 est.)
Population growth rate; - 1 .09% ( 1 994 est. )
Birth rate: 50.42 births/ 1, 000 population
(1994 est.)
Death rate: 23. 1 9 deaths/ 1 ,000 population
(1994 est.)
Net migration rate: -38.1 migrant(.s)/l,000
population (1994 est.)
Infant mortality rate: 1 4 1 . 1 deaths/ 1 ,000
live births (1994 est.)
Life expectancy at birth:
total population: 39.73 years
male: 38.93 years
female: 40.55 years (1994 est.)
Total fertility rate: 7.43 children
born/woman ( 1 994 est.)
Nationality:
noun: Malawian(s)
adjective: Malawian
Ethnic divisions: Chewa, Nyanja, Tumbuko,
Yao, Lomwe, Sena, Tonga, Ngoni, Ngonde,
Asian, European
Religions: Protestant 55%, Roman Catholic
20%, Muslim 20%, traditional indigenous
beliefs
Languages: English (official), Chichewa
(official), other languages important regionally
Literacy: age IS and over can read and write
(1966)
total population: 22%
male: 34%
female: 12%
Labor force: 428.000 wage earners
by occupation; agriculture 43%,
manufacturing 16%, personal services 15%.
commerce 9%, construction 7%,
miscellaneous services 4%, other permanently
employed 6% ( 1 986)','ca9bf79a261d3f33ecf987cb8d0b2e33e53876540c95d1f833146cddb30b0eb3','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a05475ccb097a3e29bb5ee38456d0b24217f1c937f9688d9dbc251bbd0ca1d10',1994,'MX','Mexico','people-and-society',620,'Population: 19,283,157 (July 1994 est.)
Population growth rate: 2,28% ( 1994 est.)
Birth rate: 28.45 births/1 .000 population
(1994 est.)
Death rate: 5.67 deaths/ L0(X) population
(1994 est.)
Net migration rate: 0 migrant(s)/l.000
population (1994 est.)
Infant mortality rate: 25.6 deaths/ 1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 69. 15 years
wale: 66.26 years
female: 72.18 years (1994 est.)
Total fertility rate: 3.5 1 children bom/
woman (1 994 est.)
Nationality:
noun: Malaysian(s)
adjective: Malaysian
Ethnic divisions; Malay and otherindigenous
59%. Chinese 32%, Indian 9%
Religions:
Peninsular Malaysia: Muslim (Malays),
Buddhist (Chinese). Hindu (Indians)
Sahali: Muslim 38%,
Christian 1 7%, other 45%
Sarawak: tribal religion 35%,
Buddhist and Confucianist 24%, Muslim 20%,
Christian 16%-. other 5%
Languages:
Peninsular Malaysia: Malay (official).
English. Chinese dialects. Tamil
Sahah: English, Malay, numerous tribal
dialects, Chinese (Mandarin and Hakku
dialects predominate)
Sarawak: English, Malay, Mandarin,
numerous tribal languages.
Literacy: age 15 and over can read and write
(1990 est.)
total population: 78%
male: 86%
female: 70%
Labor force: 7.258 million (1991 e.st.)
Papulation: 92,202,199 (July 1994 est.)
Population growth rate: 1 .94% (1994 est.)
Birthrate: 27.17 births/1,000 population
(1994 est.)
Death rate: 4.73 deaths/1,000 population
(1994 est.)
Net migration rate: -3.09 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 27.4 deaths/1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 72.94 years
male: 69.36 years
female: 76.7 years (1994 est.)
Total fertility rate: 3.17 children
born/woman (1994 est.)
Nationality:
noun: Mexican(s)
adjective: Mexican
Ethnic divisions: mestizo (Indian-Spanish)
60%, Amerindian or predominantly
Amerindian 30%. Caucasian or predominantly
Caucasian 9%, other 1 %
Religions: nominally Roman Catholic 89%,
Protestant 6%
Languages: Spanish, various Mayan dialects
Literacy: age 15 and over can read and write
(1990)
total population: 87%
male: 90%
female: 85%
Labor force: 26.2 million (1990)
by occuiHition: services 31.7%, agriculture,
forestry, hunting, and fishing 287r. commerce
14.6%, manufacturing 11.1%. construction
8.4%, transportation 4.7%, mining and
quarrying 1.5%
Population: 4,3 14,604 (July 1994 est.)
Populalion growth rate: 0.39% (1994 est.)
Birth rate: 1 3.32 binhs/l .000 population
(1994 est.)
Death rate: 10.44 deaths/1,000 population
(1994 est.)
Net migration rale: I.OI migrant(s)/l,000
populalion ( 1994 est.)
Infant mortality rale: 6.3 dealhs/1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 11 M years
male: 74.02 years
female; 80.94 years ( 1994 est.)
Total fertility rate: 1.81 children
om/woman (1994 est.)
Nationality:
noun: Norwegian(s)
adjective: Norwegian
Ethnic divisions: Germanic (Nordic, Alpine.
Baltic). Lapps (Sami) 20.(XX)
Religions: Evangelical Lutheran 87.8% (state
church), other Protestant and Roman Catholic
3.8%. none 3.2%. unknown 5.2% (1980)
Languages: Norwegian (official)
note; small Lapp- and Finnish-speaking
minorities
Literacy; age IS and over can read and write
(1976 est.)
total populalion: 99%
male; NA%
female; NA%
Labor force: 2.004 million (1 992)
by occupation; services 39.1%, commerce
17.6%, mining, oil. and manufacturing 16.0%,
banking and financial services 7.6%,
transportation and communications 7.8%,
construction 6. 1 %, agriculture, forestry, and
fishing .5,5% (1989)
Population: 38,654,561 (July 1994 est.)
Population growth rate: 0.35% (1994 est.)
Birth rate: 1 3.44 births/l ,000 population
(1994 est.)
Death rate: 9.4 deaths/ 1 ,000 population
(1 994 est.)
Net migration rate: -0.52 migrant(s)/ 1 ,000
population (1994 est.)
Infant mortality rate: 13.1 deaths/ 1,000 live
births (1994 est.)
Life expectancy at birth:
total population: 72.66 years
male: 68.64 years
female: 76.91 years (1994 est.)
Total fertility rate: 1 .94 children bom/
woman (1994 est.)
Nationality:
noun: Pole(s)
adjective: Polish
Ethnic divisions: Polish 97.6%, German
1 .3%, Ukrainian 0.6%, Byelorussian 0.5%
(1990 est.)
Religions; Roman Catholic 95% (about 75%
practicing). Eastern Orthodox. Protestant, and
other 5%
Languages: Polish
Literacy: age IS and over can read and write
(1978)
total population: 98%
male: 99%
female: 98%
Labor force: 1 7.329 million
by occupation: industry and construction
32.0%, agriculture 27.6%, trade, transport, and
communications 14.7%, government and other
24.6% (1992)
Papulation: 73.103,898 (July 1994 e.si.)
Population growth rate: 1 .78% ( 1 994 esi. )
Birthrate: 27. 13 births/1.000 population
(1994 est.)
Death rate; 7.76 death.s/1 ,000 population
(1994 est.)
Net migration rate: -1.53 migrant! s VI, 000
population (1994 est.)
Infant mortality rate: 45.5 death.s/1 .000 live
births (1994 est.)
Life expectancy at birth:
total population: 65.41 years
male: 63.37 years
female: 67.58 years (1994 est.)
Total fertility rate: 3.33 children bom/
woman (1994 est.)
Nationality:
noun: Vietnamese (singular and plural)
adjective: Vietnamese
Ethnic divisions: Vietnamese 85-90%,
Chinese 3%, Muong, Thai, Meo. Khmer, Man,
Cham
Religions; Buddhist. Taoist. Roman Catholic,
indigenous beliefs, Islamic. Protestant
Languages: Vietnamese (official). French.
Chinese, English, Khmer, tribal languages
(Mon-Khmer and Malayo-Polynesian)
Literacy: age 15 and over can read and write
(1990)
total population: 88%
male: 93%
female: 83%
Labor force: 32.7 million
by occupation: agricultural 65%. industrial
and service .35% ( 1 990 est.)
Population: 97,564 (July 1994 est.)
Population growth rate: -0.52% (1994 est.)
Birthrate: 19.41 binhs/ 1,000 population
(1994 est.)
Death rate: 5.2 deaths/1,000 population
(1994 est.)
Net migration rate: -19.41 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 12.54 deaths/1,000
live births (1994 est.)
Life expectancy at birth:
total population; 75.29 years
male: 73.6 years
female: 77.2 years (1994 est.)
Total fertility rate: 2.53 children bom/
woman (1994 est.)
Nationality:
noun: Virgin Islander(s)
adjective: Virgin Islander
Ethnic divisions: West Indian (45% born in
the Virgin Islands and 29% bom elsewhere in
the West Indies) 74%, US mainland 1 3%,
Puerto Rican 5%, other 8%: black 80%, white
15%, other 5%; Hispanic origin 14%
Religions: Baptist 42%, Roman Catholic
34%, Episcopalian 17%, other 7%
Languages: English (official), Spanish,
Creole
Literacy:
total population: NA%
male: NA%
female; NA%
Labor force: 45.500(1988)
hy occupation: tourism 70%','a243eb810a6fe14b789fbd7fe26b34549a3cbe68b2f176a9cda0de6dbaf5fafa','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9d60155a83bce79f23ab2cd7207af1e5e6abea423123c6765b07d5bc3847bb0',1994,'ML','Mali','people-and-society',627,'Population: 9,1 1 2,950 (July 1994 e.st.)
Population growth rate: 2.78% (1994 est.)
Birth rate: 5 1 .79 births/ 1 ,000 population
(1994 est.)
Death rate: 20.36 deaths/1,000 pirpulalion
(1994 est.)
Net migration rate: -3.66 migrant(s)/l,000
population (1994 e.st.)
InDint mortality rate: 1 06.2 deaths/ 1 .000
live births (1994 est.)
Life expectancy at birth;
total jfopulation: 45.91 years
male: 44.29 years
female: 47.57 years ( 1 994 est.)
Total fertility rate; 7.33 children born/
woman (1994 e.st.)
Nationality:
noun: Mulian(s)
adjective: Malian
Ethnic divisions: Mande 50% (Bambara.
Malinke, Sarakole). PeuI 17%. Voltaic 12%.
Songhai 6%, Tuareg and Mtwr 10%, other 5%
Religions: Muslim 90%. indigenous beliefs
9%, Christian I %
Languages: French (official), Bambara 80%,
numerous African languages
Literacy; age 1 5 and over can read and write
(1990)
total population: 17%
male: 26%
female: 9%
Labor force; 2.666 million (1986 est.)
by occupation: agriculture 80%. services 1 9%.
industry and commerce I % ( 198 1 )
note: 50% of population of working age ( 1 985)','2986ab59584c2308bedec3a577a4ada1627178d52f3947c2e612f58893758870','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e48569f1fae162cedca16c736b71adbe0be5549494cecbd6ddf854a7adb36ff0',1994,'MT','Malta','people-and-society',633,'Population: 366,767 (July 1994 est.)
Population growth rate; 0.79% ( 1 994 est.)
Birth rate: 1 3.56 births/ 1 ,000 population
(1994 est.)
Death rate: 7.43 dealhs/1,000 population
(1994 est.)
Net migration rate: I .o-t migrant(s)/l ,000
population (1994 est.)
Infant mortality rate: 7.9 deaths/I .000 live
births (1994 e.st.)
Life expectancy at birth:
total population: 76.77 years
male: 74.53 years
female: 79. 1 8 years ( 1 994 est.)
Total fertility rate: 1 .94 children
born/woman (1994 e.st.)
Nationality:
noun: Maltese (singular and plural)
adjective: Maltese
Ethnic divisions: Arab, Sicilian, Not man,
Spanish, Italian, English
Religions; Roman Catholic 98%
Languages: Maltese (official), English
(official)
Literacy; age 15 and over can read and write
(1985)
total population: 84%
male: 86%
female: 82%
Labor force: 127,200
hy occupation: government (excluding Job
corps) 37%, services 26%, manufacturing
22%. training programs 9%. construction 4%,
agriculture 2% ( 1990)
Population: 72,017 (July 1994 esl.)
Population growth rale: 1 .04% ( 1 994 esl.)
Birth rate: 1 3.69 births/ 1 .000 population
(1994 CM.)
Death rate: 1 2.58 deaths/I ,(XX) population
(I994est.)
Net migration rale: 9.25 migrani(s)/l,(K)0
population (1994 esl.)
Infant mortality rate: 8.3 deaths/ 1.000 live
births (1994 esi.)
Life expectancy at birth:
total population: 76.25 years
male: 73.51 years
female: 79.2 years (1994 est.)
Total fertility rate: 1 .8 children born/woman
(1994 est.)
Nationality:
noun: Manxman, Manxwoman
adjective: Manx
Ethnic divisions: Manx (Norse-Celtic
descent), Briton
Religions: Anglican, Roman Catholic,
Methodist, Baptist, Presbyterian. Society of
Friends
Languages: English, Manx Gaelic
Literacy:
total population: NA%
male: NA%
female: NA%
Labor force: 25.864(1981)
by occupation: NA','bb0d2036124cd496819286ff0f485a5401ab3cd6e7e3e02e5981ba3ae555ec2e','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ca382b9cff8328e2443ccf510a9c198f1ba0b81e84234e360bfa8b6930d8be0',1994,'MQ','Martinique','people-and-society',642,'Population: 392,362 (July 1994 est.)
Population growth rate: 1 .2% ( 1 994 est. )
Birth rate: 17.96 births(l.0(X) population
(1 994 est.)
Death rate: .6.9.6 deaths/ 1,(M)() population
(1994 est.)
Net migration rate: 0 migrant(s)/l.0()()
population ( 1 994 est.)
Infant mortality rate: 1 0.4 deaths/ 1 ,000 live
births (1 994 est.)
Life expectancy at birth:
totai population: 78.01 years
male: 74.88 years
female: 81.2 years ( 1 994 est.)
Total fertility rate: 1 .92 children bom/
woman ( 1 994 est.)
Nationality:
noun: Martiniquais (singular and plural)
adjective: Martiniquais
Ethnic divisions: African and African-
Caucasian-Indian mixture 90%, Caucasian 6%,
East Indian, Lebanese, Chinese less than 6%
Religions: Roman Catholic 96%, Hindu and
pagan African 5%
Languages: French, Creole patois
Literacy: age IS and over can read and write
(1982)
total population: 93%
male: 92%
female: 93%
Labor force: 100,000
by occupation: service industry 3 1 .7%,
construction and public works 29.4%,
agriculture 13. 1%. industry 7.3%, fisheries
2.2%, other 16.3%','9664edd77a3d4cedc77765609f6ac2819d93f230aa29a50d21e4f68880860b64','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bcffc2b458827052fad0da945296a79dd25ffe043529e544601dec8c08f853fd',1994,'MU','Mauritius','people-and-society',654,'Population: 1,1 16,923 (July 1994 est.)
Population growth rate: 0.92% (1994 est.)
Birth rate: 1 9.28 births/I ,000 population
(1994 est.)
Death rate: 6.41 deaths/) ,000 population
(1994 est.)
Net migration rate: -3.67 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 18.4 deaths/ 1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 70.54 years
male; 66.62 years
female: 74.63 years (1994 est.)
Total fertility rate: 2.22 children
bom/woman (1994 est.)
Nationality:
noun; Mauritian(s''''
adjective: Mauritii.
Ethnic divisions: Inuo-Mauritian 68%,
Creole 27%, Sino-Mauritian 3%, Franco-
Mauritian 2%
Religions: Hindu 52%, Christian 28.3%
(Roman Catholic 26%, Protestant 2.3%),
Muslim 16.6%, other 3.1%
Languages: English (official). Creole.
French, Hindi, Urdu, Hakka, Bojpoori
Literacy: >■ and over can read and write
(1990)
total popi
male: 85%
female: 75%
Labor force: 335,000
by occupation: government services 29%,
agriculture and fishing 27%. manufacturing
22%, other 22%
note: 43% of population of working age (1985)','aa632a94d0427d3f3bd5515342d787ef0a58f1360e23cabc3865f6b4df5fa2e5','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65e623b036d417c94250aa926a1da06bbbb07354607226264a6c96b3f0c53b7e',1994,'YT','Mayotte','people-and-society',658,'Papulation; 93,468 (July 1994 est.)
Population growth rate: 3.8% (1994 est.)
Birth rate: 48.84 births/I ,0(X) population
(1994 est.)
Death rate; 10.84 deaths/1,000 population
(1 994 est.)
Net migration rate: 0 migrant(s)/l,0(X)
population (1994 est.)
Inftint mortality rate: 79.6 deaths/ 1,000 live
births (1994 est.)
Life expectancy at birth:
toted population: 57.81 years
male: 55.63 years
female: 60.06 years (1994 est.)
Total fertility rate: 6.77 children bom/
woman (1994 est.)
Nationality:
noun: Mahorais (singular and plural)
adjective: Mahonin
Ethnic divisions: NA
Religions: Muslim 99%. Christian (mostly
Roman Catholic)
Languages: Mahorian (a Swahili dialect),
French
Literacy:
total population: NA%
male: NA%
female: NA%
Labor force: NA','3e50abe82ff97900706b56ad936e2d88d0f2378a1167afb2213a5f2bf8027684','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fec2b680ed395eaad8df98560374a3ead35a6da282740811c7766a86d60d962',1994,'FM','Micronesia, Federated States of','people-and-society',665,'Population: 120,347 (July 1994 esi.)
Population growth rate: 3.36% (1994 est.)
Blilh rate: 28.3 births/ 1, 0(X) population
( 1 994 est. )
Death rate: 6.38 death.s/1,000 population
(I994e,st.)
Net migration rate: 1 1 .63 migrant(s)/l .000
population (1994 est.)
Infant mortality rate; 37.24 deaths/ 1 ,000
live births (19'')4 est.)
Life expectancy at birth:
total population: 67,63 years
male: 65.67 years
female: 69 62 years ( 1 994 est.)
Total fertility rate: 4.01 c! iMren bom/
woman ( I‘;''j4 est.)
Nationality;
noun: Micronesian(s)
ailjei''live: Micri.inesian; Kosrae(s),
Pohnpcian(s), Trukese. Yapese
Ethnic divisions; nine ethnic Microncsian
and Polynesian groups
Religions: Christian (divided between Roman
Catholic and Protestant; other churches in.Jude
Assembly of God. Jehovah''s Witnesses.
Seventh-Day Adventist, Latter-Day Saints, and
the Baha''i Faith)
Languages: English (official and common
language). Trukese, Pohnpeian. Yapese.
Kosrean
Literacy: age 1.5 and over can read and write
(1980)
total population: 90%
male: 90%
female: 85%
Labor force: NA
hy occupation: two-thirds are government
employees
note: 45,000 people are between the ages of 15
and 65
Population: no indigenous inhabitar.is:
note — there are 453 L)S military personnel
Population: 4,473,033 (July 1994 est.)
Population growth rate: 0.38% (1994 est.)
Birth rate: 16.02 births/l ,000 population
(1994 est.)
Death rate: ! 0.02 deaths/l ,000 population
(I994e.st.)
Net migration rate: -2.2 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 30.3 deaths/ 1 ,000 live
births (1994 est.)
Life expectancy at birth;
total population: 68.07 years
male: 64.65 years
female: 1 1 .67 years ( 1 994 est.)
Total fertility rate; 2. 1 8 children
born/woman (1994 est.)
Nationality:
noun: Moldovan(s)
adjective. Moldovan
Ethnic divisions: Moldavian/Rontanian
64.5%, Ukrainian 13.8%, Russian 13%,
Gagauz 3.5%, Jewish 1.5%, Bulgarian 2%,
other 1.7% (1989 figures)
note: internal disputes with ethnic Russians
and Ukrainians in the Dniester region and
Gagauz Turks in the south
Religions; Eastern Orthodox 98.5%, Jewish
1.5%, Baptist (only about 1,000 members)
(1991)
note: the large majority of churchgoers are
ethnic Moldavian
Languages: Moldovan tofficial; virtually the
same as the Romanian language), Russian,
Gagauz (a Turkish dialect)
Literacy; age 9-49 can read and write ( 1970)
total population: 1 00%
male: 100%
female: 99%
Labor force; 2.05 million (1992)
hy occupation: agriculture 34.4%, industry
20.1%, other 45,5% ( 1985 figures)','ea2738ebd41cced837330fecd126afa3d49fe1ff6ff14ce225b19b444e8b58ba','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94303be028e1fc840e641700e5b7b6c561d7cebbdb71c19a5d1f46b4090a8e72',1994,'MC','Monaco','people-and-society',672,'Population: 31,278 (July 1994 est.)
Population growth rate: 0.8 1 % ( 1 994 est. )
Birthrate: 10.71 births/ 1,(X)0 population
(1994e.st.)
Death rate: 12.21 deaths/ 1, 000 population
(1994 est.)
266
Net migration rate: 9.59 migrant(s)/1.000
population (1994 est.)
Infant mortality rate: 7.2 deaths/1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 77.69 years
male: 73.94 years
female: 81.64 years (1994 est.)
Total fertility rate: 1 .7 ciiildren bom/woman
(1994 est.)
Nationality:
noun: Monacan(s) or Monegasque(s)
adjective: Monacan or Monegasque
Ethnic divisions: French 47%, Monegasque
16%, Italian 16%, other 21 %
Religions: Roman Catholic 95%
Languages: French (official), English,
Italian, Monegasque
Literacy:
total population: NA%
male: N.A%
female: NA%
Labor force: NA','6a32fd4ecf41cdf1f281d447a37bc74572538c7f14ce51629c26bd968de5facd','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a44a977d26120b3b86d7bd2c043e768dada788cdca397f24905168d1e51f520',1994,'MS','Montserrat','people-and-society',679,'Population: 12,701 (July 1 994 est.)
Population growth rate: 0.33% (1994 est.)
Birth rate: 1 5.93 birth.s/l ,000 population
(1994 est.)
Death rate: 9.79 deaths/1,000 population
(1994 est.)
Net migration rate: -2.83 migrant(s)/l .000
population ( 1994 est.)
269
Montserrat {continued)
Infant mortality rate: 1 1 .6 deaths/ 1 ,000 live
births (1904 est.)
Life expectancy at birth:
total population; 75.73 years
imile: 73.96 years
female; 77.53 years (1994 est.)
Totai fertiiity rate; 2.05 children bom/
woman (1994 est.)
Nationality:
noun; Montscrratian(s)
adjective; Montserratian
Ethnic divisions: black. Europeans
Religions: Anglican, Methodist, Rotnan
Catholic, Pentecostal, Seventh-Day Adventist.
other Christian denominations
Languages: English
Literacy; age 15 and over having ever
attended school (1970)
total poptdation;
male; 979r
female; 97%
Labor force: 5,I(K)
by occupation; community, social, and
personal services 40.5%, construction 13.5%.
trade, restaurants, and hotels 12.3%,
manufacturing 10.5%, agriculture, forestry,
and fishing 8.8%, other 14.4% (1983 est.)','b0cda03b2a8c38304caa124ea4190bcd2b9461e86db916b3f8ffd24d4c4c6225','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5ffc38e1c08ce6d5ffd190d604e46a38b1113ae4bd49d207d24f603b114a1e5',1994,'GI','Gibraltar','people-and-society',685,'Population: 28,558,63.5 (July 1994 est.)
Population growth rate: 2. 1 2''!'' ( i 994 est. )
Birth rate: 28.59 births/I.OOO population
(1994 est.)
Death rate: 6.26 deaths/ 1 ,000 population
(1994 est.)
Net migration rate: -1.16 migrant(.s )/ 1 ,000
population (1994 est.)
Infant mortality rate: 49.6 deaths/ 1, 000 live
births (1994 est.)
Life expectancy at birth:
total population: 68.23 years
male: 66.36 years
female: 70.2 years (1994 est.)
Total fertility rate: 3.83 children born/
woman (1994 est.)
Nationality:
noun: Moroccan(s)
adjective: Moroccan
Ethnic divisions: Arab-Berber 99. 1 , other
0,7<7r, Jewish 0.2%
Religions: Muslim 98.7%, Christian 1.1%-,
Jewish 0.2%
Languages: Arabic (official), Berber dialects.
French often the language of business,
government, and diplomacy
Literacy; age 1 5 and over can read and write
(1990 est.)
total population: 50%
male; 61%
female: 38%
Labor force: 7.4 million
by occupation: agriculture 50%. services 26%.
industry 15%, other 9% (1985)','a9e899fabad4ab15dfca96050923c9ee93ce209bc237350f430b62a4dc3381f3','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29098af6ce650496cda133d7f999757e7c411e5c78e0fe9fd503b738a16003f8',1994,'NR','Nauru','people-and-society',699,'Population: 10,019 (July 1994 est.)
Population growth rale: 1 .33^1'' ( 1 994 est. )
Birth rate: 1 8,03 births/ 1 ,000 population
(1994 est.)
Death rate; 5.1 deaths/ 1, 000 population
(1994 est.)
Net migration rate: 0,4 migrant(s)/1.00()
population ( 1994 est.)
Infant mortality rate; 40.6 deaths/ 1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population; 66.68 years
male; 64.3 years
female; 69. 1 8 years ( 1 994 est.)
Total fertility rate: 2.08 children born/
woman (1994 est.)
Nationality;
noun: Nauruan(s)
adjective: Nauruan
Ethnic divisions: Nauruan 58%, other Pacific
Islander 26%, Chine.se 8%, European 8%
Religions: Christian (two-thirds Protestant,
one-third Roman Catholic)
Languages: Nauruan (official: a distinct
Pacific Island language). English widely
understood, spoken, and used for most
government and commercial purposes
Literacy:
total population; N.A%
male: NA%
female: NA''/r
Labor force;
by occupation: NA
Population: uninhabited; note — transient
Navassa Island (continued)','978877c24ae846bb949ee717cf8bce24d19d860eb51331977136a1990cfe3b6a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56761967cc57504173507a447463327babf0ad72b3ee06630e8f94e8a0f14fdf',1994,'NP','Nepal','people-and-society',702,'Haitian fishermen and others camp on the
island
Goverament
Names:
conventional long form: none
conventional short form: Navassa Island
Digraph: BQ
Type: unincorporated territory of the US
administered by the US Coast Guard
Capital: none; administered from
Washington, DC
Population: 21,041,527 (July 1994 est,)
Population growth rate: 2.44% (1994 est.)
Birthrate: 37.63 births/ 1,000 population
(1994 est.)
Death rate; 13.28 deaths/t,000 population
(1994 est.)
Net migration rate: 0 migrant(s)/ 1,000
population (1994 est.)
Infant mortality rate: 83.5 deaths/I ,(X)0 live
births (1994 est.)
Life expectancy at birth:
total population: 52.53 years
male: 52.35 years
female: 52.73 years (1994 est.)
Total fertility rate: 5.24 children
borr,/woman (1994 est.)
Nationality:
noun: Nepalese (singular and plural)
adjective: Nepalese
Ethnic divisions: Newars, Indians, Tibetans,
Gurungs, Magars, Tamangs, Bhotias, Rais,
Limbus, Sherpas
Religions: Hindu 90%, Buddhist 5%, Muslim
3%. other 2% (1981)
note: only official Hindu slate in world,
although no sharp distinction between many
Hindu and Buddhist groups
Languages: Nepali (official), 20 languages
divided into numerous dialects
Literacy: age 15 and over can read and write
(1990 est.)
total population: 26%
male: 38%
female: 13%
Labor force: 8.5 million (1991 est.)
by occupation: agriculture 93%, services 5%.
industry 2%
note: severe lac'' of skilled labor','5fd7bf5fed06664630671ec56949033be821c319eddb82aa13f9aa91c4399a61','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('996cc0b023f4ade180e93a8e2bf7cec7fb8fea64dc8ebdeb07e0607ca452b3b1',1994,'NI','Nicaragua','people-and-society',716,'Population: 4,096,689 (July 1994 est.)
Population growth rate: 2.68% ( 1994 est. )
Birthrate: 34.66 births/ 1, OCX) population
(1994 est.)
Death rate; 6.69 deaths/ 1.000 population
(1994 est.)
Net migration rate: -1.22 migrant) s)/ 1, 000
population ( 1994 est.)
Infant mortality rate: 52.5 deuths/l .000 live
births (1994 est.)
Life expectancy at birth:
total population; 64.02 years
male; 61.18 years
female; 66.96 years ( 1 994 est.)
Total fertility rate: 4.33 children
born/woman ( 1994 est.)
Nationality:
noun; Nicaraguan(s)
adjective; Nicaraguan
Ethnic divisions; mestizo 69%, white 17%,
black 9%, Indian 5%
Religions: Roman Catholic 95%, Protestant
5%
Languages: Spanish (official)
note; English- and Indian-speaking minorities
on Atlantic coast
Literacy: age 15 and over can read and write
(1971)
total population; 57%
male; 57%
female; 57%''
Labor force: 1 .086 million
by <K-cupation; services 43%, agriculture 44%,
industry 13% (1986)','7e12001332d54c443f675428e5ffadde1a3cbdf19c4c8b4419c6cd062567500c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('508ef81067eef4df053e609a862757d95fb93d71cfcc3dad459f1875a9e60d8d',1994,'NE','Niger','people-and-society',721,'Population; 8.971.60.$ (July 1994 est.)
Population growth rate; .4,.4b'';r (1994 est.)
Blrtb rate; 54,9,$ births/l.(XX) population
1 1994 est.)
Death rate; 2 1 ..42 deaths/ 1 ,tXK4 population
11994 est.)
Net migration rate; ()migrant(s)/l.(XX)
population ( 1994 est.)
Infant nnortality rate: 1 1 1 deaths/ 1, IXK) live
binhs ( 1994 est.)
Life expectancy at birth:
total lyoinilation: 44,61 years
imilv: 4.4.t)l years
h''lmilf: 46.26 years (1994 est.)
Total fertility rate: 7. .4.$ children bom/
woman 1 1994 est.)
Nationality:
noiiii: Nigerien(s)
iiilivt iivf: Kigericn
Ethnic divisions: Hausu .$6''''i, Djermu 22*^''.
Fulu 8.5''?i . Tuareg 8*^. Beri Beri (Kanouri)
4..4'')r. .Arab. Toubou, and Gourmantche 1 ,2‘''T,
about 4,(XX) French expturiates
Religions: Muslim 80''''t . rentainder
indigenous beliefs and Chrisiians
Languages; French tofficial). Hausa. Djernta
Literary; age 15 and over can read and write
(1990 est.)
total [><>i>iilation: 28''''i
tniilf: 40''t
I''rmali'': 17''''»
Labor force: 2.5 million w age earners (1982)
/»v ot’i''ii/Hiiioii: agriculture 9()''’-; , industry and
commerce 6<4 , government 4''''i
aotr: .$ I ''-i of population of working age ( 1 985 )
(iovetnmeni
Names:
iimvfiitiomil long form: Republic of Niger
i imvi''iitioniil short fonii: Niger
liH''al long lorm: Repuhlique du Niger
local short form: Niger
Digraph; NG
Type: republic
t''apital: Niamey
Administrative divisions; 7 departments
tdepttnentems, singular — departement );
■Agadez. Diffa. IXisso. Maradi. Niamey.
Tahoua. Z.inder
Independence: .4 August 1960 (from France)
National holiday: Republic Day. 18
December 1 19.$8)
Constitution; approved hy national
referendum lb December l''-*92; promulgated
January 199.4
289
Niger (continued)
Legal system; based on French civil law
system and customary law; has not accepted
compulsory ICJ jurisdiction
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: President Mahamane
OUSMANE (since 16 April 1993)
head of government: Prime Minister
Mahamadou ISSOUFOU (since 17 April 1993)
cabinet: Cabinet; appointed by the president
on recommendation of the prime minister
Legislative branch: unicameral
National Assembly: elected by proportional
representation for S year terms; elections last
held 14 February 1993 (next election NA
1998); seats— (83 total) MNSD 29. CDS 22,
PNDS 1 3, ANDP-Z 1 1 , UPDP 2, PPN/RDA 2.
UDFP2, PSDN I, UDPS I
Judicial branch: State Court (Cour d''Etat),
Court of Appeal (Cour d''Apel)
Political parties and leaders: National
Movement of the Development Society
(MNSD-NASSARA). Kada LABO, General
Secretary; Democratic and Social
Convention — Rahama (CDS- Rahama),
Mahamane OUSMANE; Nigerien Party for
Democracy and Socialism (PNDS),
Mahamadou ISSOUFOU; Nigerien Alliance
for Democracy and Progress-Zamanlahia
(ANDP-Z), Moumouni Adamou
DJERMAKOYE; Union of Patriots.
Democrats, and Progressives (UPDP). Andre
SALIFOU; Niger Progressive Party-African
Democratic Rally (PPN-RDA), Harou
KOUKA; Niger Social Democrat Parly
(PADN), Malam Adji WAZIRl; Union for
Democracy and Social Progress (UDPS),
Akoli DAOUEL
Member of: ACCT, ACP, AfDB, CCC,
CEAO, ECA, ECOWAS, Entente, FAO, FZ,
G-77, GATT, IAEA. IBRD. ICAO, IDA. IDB,
IFAD. IFC. ILO. IMF. INTELSAT.
INTERPOL. IOC, ITU. LORCS, NAM. OAU.
OIC, UN, UNCTAD. UNESCO. UNIDO.
UPU. WADB. WCL. WHO. WIPO. WMO.
WTO
Diplomatic representation in US:
chief of mission: Ambassador Adamou
SEYDOU
chancers'': 2204 R Street NW. Washington, DC
20008
telephone: (202) 483-4224 through 4227
US diplomatic representation:
chief of mission: Antbassador John DAVISON
embassy: Rue Des Ambassades, Niamey
mailing address: B. P. 1 1201. Niamey
telephone: [227] 72-26-6! through 64
FAX: 1227) 73-31-67
Flag: three equal horizontal bands of orange
(top ). white, and green with a small orange disk
(representing the sun) centered in the white
band; similar to the flag of India, which has a
blue spoked wheel centered in the white band','c8798f4139045299a02c38bded7acdf46c3109c4aa3f53f727a0f1f640ca4f13','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d5b901126540205c36bcde34d2741675f9570f65b4aaf3ffeea18bdcc7fc342',1994,'NU','Niue','people-and-society',725,'Population: 1,906 (July 1994 est.)
Population growth rate: 3.66% (1994 est.)
Nationality:
noun: Niuean(s)
adjective: Niuean
Ethnic divisions: Polynesian (with some 200
Europeans, Samoans, and Tongans)
Religions: Ekalesia Nieue (Niuean Church)
75% — a Protestant church closely related to
the London Missionary Society, Mormon 10%,
other 15% (mostly Roman Catholic, Jehovah’s
Witnesses, Seventh-Day Adventist)
Languages; Polynesian closely related to
Tongan and Samoan, English
Literacy:
total population: NA%
male: NA%
female: NA%
Labor force: 1 ,000 ( 1 98 1 est. )
by occupation: most work on family
plantations; paid work exists only in
government service, small industry, and the
Niue Development Board','568c06052735e2fbe2b94427ec1c97660f422124c2b9123b0fb47562f3308d76','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3136c6378beab24e4ff1e20d2f63e5c27b4986516896d50b990132f790d0a87e',1994,'NF','Norfolk Island','people-and-society',732,'Population: 2.710 (July 1994 esi.)
Population growth rate: 1 .7% ( 1 994 est.)
Nationality:
noun: Norfolk lslander(s)
adjective: N;)rfolk Islander(s)
Ethnic divisions: descendants of the Bounty
mutineers, Australian. New Zealander
Religions: Anglican 39%, Roman Catholic
1 1.7%, Uniting Church in Australia I6.4%i,
Seventh-Day Adventist 4.4%. none 9.2%,
unknown 16.9%. other 2.4% (1986)
Languages: English (official), Norfolk a
mixture of 18th century English and ancient
Tahitian
Literacy:
total population: NA%
male: NA%
female: NA%
Labor ^>rce: NA','1cb4aec593386fe4d3b60929d26d9fd904c632b5b2d2a160610db3ad27310b9a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('feb8129b9fd5b5f86b2d81b2c9e9b154c63255d95c0b6503c5273aa4cb4f30ec',1994,'MP','Northern Mariana Islands','people-and-society',737,'Population: 49,799 (July 1994 cst.)
Population growth rate: 3.04% ( 1994 est.)
Birth rale; .35.05 births/ 1 ,(K)0 population
(1994 est.)
Death rate: 4.61 deaths/ 1.000 population
(1994 est.)
Net migration rate: 0 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 37.96 deaths/1,000
live births (1 994 est.)
Life expectancy at birth:
total population: 67.43 years
male: 65.5.3 years
female: 69.48 years (1994 est.)
Total fertility rate: 2.69 children bom/
woman (I994e.st.)
Nationality:
noun: NA
adjective: NA
Ethnic divisions: Chamorro, Carolinians and
other Micronesians, Caucasian. Japanese.
Chinese, Korean
Religions; Christian (Roman Catholic
majority, although traditional beliefs and
tabtxis may stili be found)
Languages: English. Chamorro. Carolinian
note: 86% of population speaks a language
other than English at home
Literacy: age 15 and over can read and write
(1980)
total population: 97%
male: 97%
female: %%
Labor force: 7,476 total indigenous labor
force, 2,699 unemployed; 2 1 . 1 88 foreign
workers (1990)
by occupation: NA','15091dc7448d6d7fbbc3e42fc8829f388d45051d19374fd54a4ded19697cd5ce','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed55a1f356dc58319dbc6bd0796ed153b5eeb9166560bd23ab2ff3882474bfdd',1994,'OM','Oman','people-and-society',741,'Population: 1.701. 470 (July 1994 est.)
note: Oman''s first census was concluded in
December 1993; preliminary figures give a
population of 2.000,000, of whom about
.500.000 are expatriate workers: final
evaluative figures are not yet available
Population growth rale: .3.465f (1994 est.)
Birthrate: 40..38binhs/l.0(X) population
(1994 est.)
Death rate: .5.77 deaths/I, (XX) population
( 1994 est.)
Net migrathMi rale: Omigrant(s)/ 1.000
population ( 1994 est.)
infant mortality rale: .36.7 deaths/I.IXX) live
births (1994 est.)
Life expectancy at birth:
total population: 67.79 years
male: 65.9 years
female: 69.77 years ( 1994 est.)
Total fertility rate; 6.5.3 children bom/
woman ( 1994 est.)
Nationality:
noun; Omani(s)
adjective; Omani
Elhnk divisions: Arab. Baluchi. South Asian
(Indian. Pakistani. Sri Lankan. Bangladeshi)
Religions; lhadhi Muslim 759f. Sunni
Muslim. Shi''a Muslim. Hindu
Languages; Arabic (official). English.
Baluchi. Urdu, Indian dialects
Literacy:
total population: NA‘''4-
nude: NA''''4
female: NA*^
Labor force; 4.30,(XX) test. )
hv mcuiHition; agriculture 40W (est.)','c85ede032dada65fd3f2d7d6850a57ad82a261004da64aa1ab5528bdf594af9b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a19bad844430ec4130da8e64b010288684447c17f0c926d7a8139874209275da',1994,'PH','Philippines','people-and-society',745,'Population: 1 6,366 (July 1994 est.)
Population growth rate: 1.81% (1994 est.)
Birth rate: 22.54 births/I ,(X)0 population
(1994 est.)
Death rate: 6.61 deaths/ 1, 000 population
(1994 est.)
Net migration rate: 2.12 migrani(s)/ 1 ,000
popuiation (1994 est.)
Inhint mortality rate: 25.07 deaths/ 1 ,000
iivc births (i994 est.j
Life expectancy at birth:
total population; 71.01 years
male; 69. 14 years
female; 73.02 years (1994 est.)
Total fertility rate: 2.91 chiidren
bom/woman ( 1 994 est.)
Nationality:
noun; Palauan(s)
adjective; Palauan
Ethnic divisions: Palauans are a composite of
Polynesian, Malayan, and Melanesian races
Religions; Christian (Catholics, Seventh-Day
Adventists, Jehovah''s Witnesses, the
Assembly of God, the Liebenzell Mission, and
Latter-Day Saints). Modekngei religion (one-
third of the population observes this religion
which is indigenous to Palau)
Languages: English (official in all of Palau''s
16 states). Sonsorole.se (official in the state of
Sonsoral), Angaur and Japanese (in the state of
Anguar), Tobi (in the .state of Tobi), Palauan
(in the other 13 states)
Literacy: age 15 and over can read and write
(1980)
total population; 92%
male; 93%
female; 9 1 %
Labor force: NA
hy tH’cupation; NA
Population: no indigenous inhabitants;
note — there are scattered Chinese garrisons
Population: 5,213,772 (July 1994 e.st.)
Population growth rate: 2.76% (1994 est.)
Birth rate: 32.03 births/ 1,0(X) population
(1994 est.)
Death rate: 4.48 deaths/ 1, 000 population
(1994 est.)
Net migration rate: 0migrant(s)/l,000
population (1994 est.)
Infant mortality rate; 25.2 deaths/) ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 73.28 years
male: 71.74 years
female: 74.9 years (1994 est.)
Total fertility rate: 4.29 children bom/
woman ( 1994 est.)
Nationality:
noun: Paraguayan(s)
adjective: Paraguayan
Ethnic divisions: mestizo (Spanish and
Indian) 95%, white and Indian 5%
Rel- ns; Roman Catholic 90%, Mennonite
and utiier Protestant denominations
Languages: Spanish (official). Guarani
Literacy: age 15 and over can read and write
(1990 est.)
total population: 90%
male: 92%
female: 88%
Labor force: 1 .692 million (1993 est.)
by occupation: .igriculture, industry and
commerce, services, government (1986)
Cover" r. ■
Names:
convention :g form: Republic of Paraguay
conventional Mtort form: Paraguay
local long form: Republica del Paraguay
local short form: Paraguay
Digraph: PA
Type: republic
Capital: Ason -ion
Admlnistrati’. : or. isions: 1 9 departments
(departamentos, singular — departamento);
Alto Paraguay, Alto Parana, Amambay,
Boqueron, Caaguazu, Caazapa, Canindeyu,
Central, Chaco, Concepcion, Cordillera,
Guaira, Itapua, Misiones, Neembucu, Nueva
Asuncion, Paraguari. Presidente Hayes, San
Pedro
Independence: 14 May 1811 (from Spain)
National holiday: Independence Days. 14-15
May (1811)
Constitution: 25 August 1967; Constituent
A.ssembly rewrote the Constitution that was
promulgated on 20 June 1992
Legal system; based on Argentine eodes,
Roman law, and French codes; judicial review
of legislative acts in Supreme Court of Justice;
does not accept compulsory ICJ Jurisdiction
Sufflrage: 1 8 years of age; universal and
compulsory up to age 60
Executive branch:
chief of state and head of government:
President Juan Carlos WASMOSY (since 15
August 1993); Vice President Roberto Angel
SEIFART (since 15 August 1993); election last
held 9 May 1993 (next to be held May 1998);
results — Juan Carlos WASMOSY 40.09%,
Domingo LAINO 32.06%, Guillermo
CABALLERO VARGAS 23.04%
cabinet: Council of Ministers; nominated by
the president
Legislative branch: bicameral Congress
(Congreso)
Chamber of Senators ( Camara de Senadores):
elections last held 9 May 1993 (next to be held
May 1998); results — percent of vote by party
NA; seats — (45 total) Colorado Patty 20,
PLRA 17,EN8
Chamber of Deputies ( Camara de Diputados):
elections last held on 9 May 1993 (next to be
held by May 1 998); results — percent of vote by
party NA; seats — (80 total) Colorado Party 38,
PLRA 33,EN9
Judicial branch: Supreme Court of Justice
(Corte Supreme de Justicia)
Political parties and leaders: Colorado
Party, Eugenio SANABRIA CANTERO,
president; Authentic Radical Liberal Party
(PLRA), Domingo LAINO; National
Encounter (EN), Guillermo CABALLERO
VARGAS (the EN party includes the following
minor parties: Christian Democratic Party
(PDC), Jose Angel BURRO; Febrerista
Revolutionary Party (PRF). Euclides
ACEVEDO; Popular Democratic Party (PDP),
Hugo RICHER)
Other political or pressure groups:
Confederation of Workers (CUT); Roman
Catholic Church
Member of: AG (observer), CCC, ECLAC,
FAO, G-77, GATT, lADB, IAEA, IBRD.
ICAO. ICFTU, IDA. IFAD, IFC, ILO, IMF,
IMO, INTELSAT. INTERPOL. IOC, lOM.
ITU. LAES, LAIA, LORCS, MERCOSUR.
OAS, OPANAL, PCA. RG, UN, UNCTAD,
UNESCO, UNIDO, UPU, WCL, WHO,
WlPO, WMO, WTO
Diplomatic representation in US:
chief of mission: Ambassador Juan Esteban
AGUIRRE Martinez
chancery: 2400 Massachusetts Avenue NW,
Washington, DC 20008
telephone: (202) 483-6960 through 6962
MX.- (202) 234-4508
consulate(s) general: New Orleans and New
York
consulate(s): Miami
US diplomatic representation:
chief of mission: (vacant); Charge D’Affaires
Gerald McCOLl.OCH
embassy: 1776 Avenida Mariscal Lopez,
Asuncion
mailing address: C. P. 402, Asuncion, or APO
A A 34036-0001
telephone: [595] (21)213-715
FAX: [595] (21)213-728
Flag: three equal, horizontal bands of red
(top), white, and blue with an emblem centered
in the white band; unusual flag in that the
emblem is different on each side; the obverse
(hoist side at the left) bears the national coat of
arms (a yellow five-pointed star within a green
wreath capped by the words REPUBLICA
DEL PARAGUAY, all within two circles); the
reverse (hoist side at the right) bears the seal of
the treasury (a yellow lion below a red Cap of
Liberty and the words Paz y Justicia (Peace and
Justice) capped by the words REPUBLICA
DEL PARAGUAY, all within two circles)
Population: 69,808,930 (July 1994 est.)
Population growth rate: 1 .92% ( 1 994 est.)
Birthrate; 27.34 births/1,000 population
(1994 est.)
Death rate: 6.94 deaths/ 1, 000 population
(1994 est.)
Net migration rate: -1.18 migrant(s)/ 1 ,000
population ( 1994 est.)
Infant mortality rate: 50.8 deaths/1,000 live
births (1994 est.)
Life expectancy at birth:
total population; 65.39 years
male: 62.88 years
female: 68.02 years (1994 est.)
Total fertility rate: 3.35 children bom/
woman (1994 est.)
Nationality:
noun; Filipino(s)
adjective; Philippine
Ethnic divisions: Christian Malay 91 .5%.
Muslim Malay 4%, Chinese 1 ,5%, other 3%
Religions: Roman Catholic 83%, Protestant
9%, Muslim 5%, Buddhist and other 3%
Languages: Filipino (official; based on
Tagalog), English (official)
Literacy: age 15 and over can read and write
(1990 est.)
total population; 90%
male: 90%
female; 90%
Labor force: 24. 1 2 million
by occupation; agriculture 46%, industry and
commerce 16%, .services 18.5%, government
i0%. other 9.5% (1989)
Population: 71 (July 1994 est.)
Population growth rate; 2.9^% (1994 est.)
Birthrate: NA
Death rate: NA
Net migration rate: NA
Infant mortality rate; NA
Life expectancy at birth: NA
Total fertility rate: NA
Nationality:
noun: Pitcairn Islanderts)
adjective: Pitcairn islander
Ethnic divisions; descendants of the Bounty
mutineers
Religions: Seventh-Day Adventist 100%
Languages: English (official), Tahitian/
English dialect
Literacy:
total population: NA%
male: NA%
female: NA%
Labor force: NA
by occupation: no business community in the
usual sense; some public works: subsistence
farming and fishing
Population: no indigenous inhabitants;
note — there are scattered garrisons
Population: 18. 1 29.850 (July 1994 est.)
note; since the outbreak of hostilities between
the government and armed Tamil separatists in
the mid- 1980s, .several hundred thousand
Tamil civilians have fled the island; as of late
1992, nearly 1 15,0(XI were housed in refugee
camps in south India, another 95,000 lived
outside the Indian camps, and more than
200, (KX) Tamils have sought political a.sy lum in
the West
Population growth rate; 1.18% (1994 est.)
Birth rate: 18.51 births/ 1 ,000 population
(1994 est.)
Death rate: 5.77 dcaths/1,000 population
(1994 est.)
Net migration rate: -0.91 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 2 1 .9 deaths/ 1 .000 live
births (1994 est.)
Life expectancy at birth:
total population: 7 1 .9 years
male: 69., ^7 years
female; 74.55 years (1994 est.)
Total fertility rate; 2. 12 children born/
woman (1994 est.)
Nationality:
noun: Sri Lankan(s)
adjective: Sri Lankan
Ethnic divisions: Sinhalese 74%, Tamil 18%.
Moor 7%, Burgher, Malay, and Vedda 1%
Religions: Buddhist 69%, Hindu 15%.
Christian 8%, Muslim 8%
Languages: Sinhala (official and national
language) 74%, Tamil (national language)
18%
note: English is commonly used in government
and is spoken by about 10% of the population
Literacy: age 15 and over can read and write
(1990 est.)
total population: 88%
male; 93%
female; 84%
Labor force: 6.6 million
by occupation: agriculture 45.9%. mining and
manufacturing 13.3%, trade and transport
12.4%, services and other 28.4% (1985 est.)
Map references: Asia, Oceania, Southeast
Asia
Area:
total area; 35.980 sq km
land area: 32,260 sq km
comparative area; slightly larger than
Maryland and Delaware combined
note; includes the Pescadores. Matsu, and
Quemoy
Land boundaries; 0 km
Coastline; 1.448 km
Maritime claims;
exclusive economic zone; 200 nm
territorial sea: 1 2 nm
International disputes: involved in complex
dispute over the Spratly Islands with China,
Malaysia. Philippines, Vietnam, and possibly
Brunei; Paracel Islands occupied by China, but
claimed by Vietnam and Taiwan; Japanese-
administered Senkaku-shoto (Senkaku Islands/
Diaoyu Tai) claimed by China and Taiwan
Climate: tropical; marine; rainy season
during .southwest mon.soon (June to August);
cloudiness is persistent and extensive all year
Terrain: eastern two-thirds mostly rugged
mountains; flat to gently rolling plains in west
Natural resources: small deposits of coal,
natural gas. limestone, marble, and asbestos
Land use:
arable land: 24%
permanent crops; 1 %
meadows and pastures; 5%
forest and woodland; 55%
other; 15%
Irrigated land: NA sq km','fcbcbee544809d3f04c7e6b0fdfa43c807539678275c5aa2671efa8a20e33a9e','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7769acbd623e8b8cb46f9567fa8832e9fdf93c5939ccdc5eb1b2b721bb9e4e4b',1994,'PA','Panama','people-and-society',754,'Population: 2.6.7 million (July 1994 est.)
Population growth rate: 1 .94% ( 1 994 est. )
Birthrate: 24.61 births/ 1. (XX) population
(1994 est.)
Death rate: 4.87 deaths/ 1, 000 population
(1994 est.)
Net migration rate; -0.37 migrant(s)/l,000
population (1994 e.si.)
Inf^ant mortality rate: 16.5 deaths/ 1 , (XX) live
births (1994 est.)
Life expectancy at birth:
total population: 74.88 years
male: 72.28 years
female: 77.62 years (1994 est.)
Total fertility rate: 2.85 children horn/
woman ( 1994 est.)
Nationality:
noun: Panamaniun(s)
adjective: Panamanian
Ethnic divisions: mestizo (mixed Indian and
European ancestry) 70%. West Indian 14%.
white 10%. Indian 6%
Religions: Roman Catholic 85%, Protestant
1.5%
Languages: Spanish (official). English 14%
note: many Panamanians bilingual
literacy: age 15 and over can read and write
(1990 est.)
total population: 88%
male: 88%
female: 88%
I .abor force: 92 1 .(XX) ( 1 992 est . )
by occupation: government and community
services 31.8%, agriculture, hunting, and
fishing 26.8%, commerce, restaurants, and
hotels 16.4%, manufacturing and mining 9.4%,
construction 3.2%, transportation and
communications 6.2%. finance, insurance, and
real estate 4.3%
note: shortage of skilled labor, but an
oversupply of unskilled labor','c3bdbb2405ed7b79f5a1029746700daa55cb078a81effe5a5b18dfa534b1aefc','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5037475e2f0eb3ebe68d6c1c60183ea279a7fbf6eae27d1cbeba1a98f1c22bc',1994,'PG','Papua New Guinea','people-and-society',760,'Population; 4,196,806 (July 1994 est.)
Population growth rate: 2.3 1 % ( 1 994 est.)
Birthrate: 33.5 births/1,000 population
(1994 est.)
Death rate: 10.38 deaihs/l ,0(X) population
(1994 est.)
Net migration rate: 0 migrant(s)/l ,000
population (1994 est.)
infant mortality rate: 63.3 deaths/I ,000 live
births (1 994 est.)
Life expectancy at birth:
total population: 56.43 ) s
male: 55.6 years
female: 57.31 years (1994 est.)
Total fertility rate: 4.65 children bom/
woman (1994 est.)
Nationality:
noun: Papua New Guinean(s)
adjective: Papua New Guinean
Ethnic divisions: Melanesian, Papuan,
Negrito, Micronesian, Polynesian
Religions; Roman Catholic 22%, Lutheran
16%, Presbyterian/Methodist/London
Missionary Society 8%. Anglican 5%.
Evangelical Alliance 4%, Seventh-Day
Adventist I %, other Protestant sects 10%,
indigenous beliefs 34%
Languages: English spoken by 1-2%, pidgin
English widespread, Motu spoken in Papua
region
note: 715 indigenous languages
Literacy: age 15 and over can read and write
(1990 est.)
total population: 52%
male: 65%
female: 38%
Labor force: NA','e343d0aa3e81a97e09b4ef10ed9e39eee02442d8865afc17ec465dfd096abcbe','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85776dbf1348a421c5926250f4581dca97937360cfd4ee359c0b5e018ac23c65',1994,'PT','Portugal','people-and-society',770,'Population: 1 0,524,2 1 0 (July 1 994 est.)
Population growth rate: 0.36% (1994 est,)
Birth rate: 1 1 ,66 births/I ,000 population
(1994 est.)
Death rate: 9.7 deaths/ 1, 000 population
(1994 est.)
Net migration rate: 1.67 migrant(s)/l, 000
population (1994 est.)
Infant mortality rate: 9.5 deaths/1,000 live
births (1994 est.)
Life expectancy at birth:
total population; 15.2 years
male: 7 1 .77 years
female; 78.86 years (1994 est.)
Total fertility rate: 1.46 children
bom/woman ( 1 994 est. )
Nationality;
noun: Portuguese (singular and plural)
adjective: Portuguese
Ethnic divisions: homogeneous
Mediterranean stock in mainland, Azores,
Madeira islands; citizens of black African
descent who immigrated to mainland during
decolonization number less than 100,000
Religions: Roman Catholic 97%, Protestant
denominations 1%, other 2%
Languages: Portuguese
Literacy: age 15 and over can read and write
(1990 est.)
total papulation: 85%
male; 89%
female; 82%
Labor force: 4,605,700
by occupation; .services 45%, industry 35%,
agriculture 20% (1988)','1803dd310724826163a7237d45e52948334ad2e0845664b401382d28b65c0da8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7935fc021fea6d4a05a0b575240fa8bd3c360443935bc13585c339db2d4cfeb8',1994,'PR','Puerto Rico','people-and-society',776,'Population: 3,801,977 (July 1994 est.)
Population growth rate: 0. 1 3% ( 1 994 est.)
Birth rate: 16.5 births/ 1,000 population
(1994 est.)
Death rate: 7.93 deaths/ 1, 000 population
(1994 est.)
Net migration rate: -7.29 niigrant(s)/l,000
population (1994 est.)
Infant mortality rate: 13.8 deaths/1,000 live
births (1994 est.)
Life expectancy at birth:
total population: 73.95 years
male: 70.42 years
female: 77.65 years (1994 est.)
Total fertility rate: 2.04 children bom/
woman (1994 est.)
Nationality:
noun: Puerto Rican(s)
adjective: Puerto Rican
Ethnic divisions: Hispanic
Religions: Roman Catholic 85%, Protestant
denominations and other 15%
Languages: Spanish (official), English
widely understood
Literacy: age 15 and over can read and write
(1980)
total population: 89%
male: 90%
female: 88%
Labor force: 1 . 1 7 million ( 1 992)
by occupation: government 20%,
manufacturing 14%, trade 17%, construction
5%, communications and transportation 5%,
other 39% (1992)','c0e73400b5ae209abc14475441bade47281d1eef563b5918fadb00bc2684011e','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64d32049de5f13b9c77ea0145c8fe902b8f874cbb419ebd1b0da67b3207d8942',1994,'UA','Ukraine','people-and-society',785,'Population: 23.181,415 (July 1994 est.)
note: the Romanian census of January 1992
gives the population for that date as 22.749
million; the government estimates that
population declined in 1993 by 0.3%
Population growth rate: 0.06% (1994 est.)
Birth rau: 13.66 birthVl.OOO population
(1994 esi)
Death rcte: 1 0.02 deaths/ i ,000 population
(1994 est.)
Net migration rate: -3.07 migrant(s)/ 1,000
population (1994 est.)
Infant mortality rate: 1 9.9 deaths/ 1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population; 71 .74 years
male: 68.81 years
female: 74.84 years (1994 est.)
Total fertility rate: 1.82 children bom/
woman (1994 est.)
Nationality:
noun; Romanian(s)
adjective; Romanian
Ethnic divisions; Romanian 89. 1 %,
Hungarian 8.9%, German 0.4%, Ukrainian,
Serb. Croat, Russian, Turk, and Gypsy 1.6%
Religions: Romanian Orthodox 70%, Roman
Catholic 6% (of which 3% are Uniate),
Protestant 6%, unaffiliated 18%
Languages; Romanian, Hungarian, Gennan
Literacy: age 15 and over can read and write
(1978 est.)
total population; 98%
male: NA%
female: NA%
Labor force: 10,945,700
by occupation; industry 38%. agriculture 28%.
other 34% (1989)
327
Romania (continued)
Papulation: 149,608.953 (July 1994 e.st.)
Population growth rate: 0.2% (1994 est.)
Birth rate: 12.67 births/ 1, 000 population
(1994 est.)
Death rate: 1 1 .34 deaths/ 1 ,000 population
(1994 est.)
Net migration rate: 0.7 migrant(s)/ 1,000
population (1994 est.)
Infant mortality rate: 27 deaths/1,000 live
births (1994 est.)
Life expectancy at birth:
total population: 68.89 years
329
Russia (continued)
Male: 63.85 years
female: 74.2 years (1994 est.)
Total frrtility rate: 1 .83 children bom/
woman ■: 1994 est.)
Nationality:
noun: Russian(s)
adjective: Russian
Ethnic divisions: Russian 8 1 .5%, Tatar 3.8%,
Ukrainian 3%, Chuvash 1 .2%, Bashkir 0.9%,
Byelorussian 0.8%. Moldavian 0.7%, other
8.1%
Religions: Russian Orthodox, Muslim, other
Languages: Russian, other
Liter’tcy: age 9-49 can read and write (1970)
total population: 100%
male: 100%
female: 100%
Labor force: 75 million (1993 est.)
by occupation: production and economic
services 83.9%, government 16.1%
PopulaUon: 51.846.958 (July 1994 est.)
Population growth rate: 0.05% ( 1994 est.)
Birth rate. 1 2.34 births/I ,000 population
(1994 est.)
Death rate: 1 2.6 deaths/ 1 ,000 population
(1994 est.)
Net migration rate: 0.71 migrant(s)/l,000
population (1994 est.)
Infant mortality rate; 20.7 dealhs/1,000 live
births (1994 est.)
Life expectancy at birth:
total population: 69.99 years
male: 65.45 years
female: 74.76 years (1994 est.)
Total fertility rate; 1 .82 children born/
woman (1 994 est.)
Nationality:
noun: Ukrainian(s)
adjective: Ukrainian
Ethnic divisions: Ukrainian 73%, Russian
22%, Jewish 1 %, other 4%
Religions: Ukrainian Orthodox — Moscow
Patriarchate. Ukrainian Orthodox— Kiev
Patriarchate, Ukrainian Autocephalous
Orthodox, Ukrainian Catholic (Uniate),
Protestant. Jewish
Languages: Ukrainian. Russian, Rumanian,
Polish, Hungarian
Literacy: ape 9-49 can read and write ( 1 979)
total popiiUtiion: 100%
male: 100%
female: 100%
Labor force: 23.985 million
hy occupation: industry and construction 33%,
agriculture and forestry 2 1 %, health,
education, and culture 16%. trade and
distribution 7%. transport and communication
7%, other 16% (1992)','9f9ebeee46d5a98f0989503bdac7553d3cafa824fd07e519e0fc271152738108','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5527351748c95dd87252e6e413745a3ade4ba5b48b5a7ecc5bc3db788b19089',1994,'RW','Rwanda','people-and-society',792,'Population: 8,373,963 (July 1994 est.)
note: the demographic estimates were prepared
332
before civil strife, starting in April 1994, set in
motion substantial and continuing population
changes
Population growth rate: 2.78% (1994 est.)
Birth rate: 49. 17 births/ 1,0(X) population
(1994 est.)
Death rate; 2 1 .35 deaths/ 1 ,000 population
( 1994 est.)
Net migration rate: 0 migrant(s)/ 1,000
population (1994 est.)
Infant mortality rate: 1 18.7 deaths/1 ,000
live births (1994 est.)
Life expectancy at birth:
total population: 40.25 years
male; 39.33 years
female: 41.21 years ( 1 994 est.)
Total fertility rate; 8.19 children bom/
woman (1994 est.)
Nationality:
noun; Rwandan(s)
adjective: Rwandan
Ethnic divisions: Hutu 90%, Tutsi 9%, Twa
(Pygmoid) 1%
Religions: Roman Catholic 65%, Protestant
9%, Muslim 1%, indigenous beliefs and other
25%
Languages: Kinyarwanda (official), French
(official), Kiswahili used in commercial
centers
Literacy: age 15 and over can read and write
(1990 est.)
total population; 50%
male; 64%
female; 37%
Labor force: 3.6 million
hy occupation; agriculture 93%, government
and services 5%, industry and commerce 2%
note: 49% of population of working age ( 1 985)','c9da85f538ede38656dc2f79feba2ba61854c87895ffd2d3a6ce897547b329a6','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5c8297ff6a01f5e05ab0c2bd3cdb90fc3892b33a2175207aa439c9e710720cb',1994,'LC','Saint Lucia','people-and-society',798,'Population: 145,090 (July 1994 est.)
Population growth rate: 0.52% (1994 est.)
Birth rate: 23. 1 2 bitths/l ,000 population
(1994 est.)
Death rate: 5.84 deaths/I ,000 population
(1994 est.)
Net migration rate: -12.05 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 18.5 deaths/ 1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 69.36 years
maie: 67.06 years
female: 1 1 .83 years ( 1994 est.)
Total fertility rate: 2.5 children bom/woman
(1994 est.)
Nationality:
noun: Saint Lucian(s)
adjective: Saint Lucian
Ethnic divisions: African descent 90.3%,
mixed 5.5%, East Indian 3.2%, Caucasian
0.8%
Religions: Roman Catholic 90%, Protestant
7%, Anglican 3%
Languages; English (official), French patois
Literacy: age 15 and over having ever
attended school ( 1 980)
total population: 67%
male: 65%
female: 69%
Labor force: 43,800
by occupation: agriculture 43.4%, services
.38.9%, industry and commerce 17.7% (1983
est.)','e6c94d5f98efc0e2c6cb95d096d00e9ae105202b251f649e2fc490dac3d1de88','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('505c3ab0b620a34080aacf7cede3026420baa31a0919852b809e5c878a9734c4',1994,'PM','Saint Pierre and Miquelon','people-and-society',803,'Population: 6,704 (July 1994 est.)
Population growth rate: 0.78% (1994 est.)
Birth rate: 13.23 births/1,000 population
(1994 est.)
Death rate: 5.98 deaths/I ,000 population
(1994 est.)
Net migration rate: 0.59 migrant(s)/l,000
population ( 1994 est.)
Infant mortality rate: 1 1 .72 deaths/ 1 ,000
live births (1994 est.)
Life expectancy at birth:
total population: 75.6 years
male: 73.99 years
female: 77.55 years (1994 est.)
Total fertility rate: 1 .7 children bom/woman
(1994 est.)
Nationality:
noun: Frenchman(men),
Frenchwoman/ women)
adjective: French
Ethnic divisions: Basques and Bretons
(French fishermen)
Religions: Roman Catholic 98%
Languages: French
Literacy: age 15 and over can read and write
(1982)
total population: 99%
male: 99%
female: 99%
Labor force: 2,850(1988)
by occupation: NA','10bf734f34ef498f4a1499d318074d5420229559e79f7edf9c3a03ff5fb35f62','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b029030075e5d36d3bce088957379ef8bfe7e36e770260b3a0c0d736ce611827',1994,'VC','Saint Vincent and the Grenadines','people-and-society',809,'Population: 1 15,437 (July 1 994 est.)
Population growth rate: 0.77% (1994 est.)
Birthrate: 20.27 births/ 1, 000 population
(1 994 est.)
Death rate: 5.2 deaths/l ,000 population
(1994 est.)
Net migration rale: -7.4 migrant(s)/l,0(K)
population (1994 est.)
Inflant mortality rate: 1 7.2 deaths/1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 72.28 years
male: 70.77 years
female: 73.84 years (1994 est.)
Total fertility rate: 2.08 children
bom/woman (1994 est.)
Nationality:
noun: Saint Vincentian(s) or Vincentian(s)
adjective: Saint Vincentian or Vincentian
Ethnic divisions: black African descent,
white. East Indian, Carib Indian
Religions: Anglican, Methodist, Roman
Catholic. Seventh-Day Adventist
Languages: English, French patois
Literacy: age 15 and over having ever
attended school (1970)
total population: 96%
male: 96%
female: 96%
Labor force: 67.000 ( 1984 est.)
by occupation: NA','f80d2c01a388c558cff8ce1703630a7565fb8470c6c3c15b2d21635683b2e32e','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fe9588217082af6d7aa0472a90f8707764d5d87e7f375ae4b5984deb00d2b3a',1994,'SM','San Marino','people-and-society',814,'Population; 24,091 (July 1994 est.)
Population growth rate: 0.96% ( 1994 est.)
Birth rate: 1 1 . 1 7 births/ 1 ,000 population
(1994 est.)
Death rate: 7.39 deaths/1 ,000 population
(1994 est.)
Net migration rate: S.77 migrant(s)/l ,000
population (1994 est.)
Infant mortality rate: S.6 deaths/1.000 live
births (1994 est.)
Life expectancy at birth:
total population: 81.23 years
male: 77,17 years
female: 85,28 years (1994 est.)
Total fertility rate: 1 .53 children bom/
woman (1994 est.)
Nationality:
noun: Sammarinese (singular and plural)
adjective; Sammarinese
Ethnic divisions: Sammarinese, Italian
Religions: Roman Catholic
Languages: Italian
Literacy: age 14 and over can read and write
(1976)
total population; 96%
male: 96%
female: 95%
Labor force: 4,300 (est.)
by occupation: NA','d998283cddd16b9c3f2b4cbe60e81e786289c07dfd06ac22a8150ac3ae9e9473','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e702a568da56b18933de294723ee807db0c6c853b7bfce78f558c46f1eebc36',1994,'ST','Sao Tome and Principe','people-and-society',821,'Population: 136,780 (July 1994 est.)
Population growth rate: 2.63% (1994 est.)
Birthrate: 35.2 births/1,000 population
(1994 est.)
Death rate: 8.88 deaths/ 1 .000 population
(1994 e.st.)
Net migration rate: Omigrant(s)/ 1,000
population (1994 est.)
Infant mortality rate: 63.5 deaths/1,000 live
births (1994 est.)
Life expectancy at birth:
total population: 63.33 years
male: 6 1 .48 years
female: 65.24 years (1994 est.)
Total fertility rate: 4.52 children
bom/woman ( 1994 est.)
Nationality:
noun: Sao Tomean(s)
adjective; Sao Tomean
Ethnic divisions; mestico, angolares
(descendents of Angolan slaves), forros
(descendents of freed slaves), servicais
(contract laborers from Angola, Mozambique,
and Cape Verde), tongas (children of servicais
bom on the islands), Europeans (primarily
Portuguese)
Religions: Roman Catholic, Evangelical
Protestant, Seventh-Day Adventist
Languages; Portuguese (official)
Literacy: age 15 and over can read and write
(1981)
total population: 57%
male: 73%
female: 42%
Labor force: 2 1 ,096 (1981); most of
population engaged in subsistence agriculture
and fishing; labor shortages on plantations and
of skilled workers; 56% of population of
working age (1983)','37a2cb4d102d804fb6e4072401c7e449f4d25e4c6b1a5b8c25951035b86cb77a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3d0ea29d7e55b7cd1ac0be63dcc434a7fbdd803122f76ff0d1f827afd11eb5c',1994,'SC','Seychelles','people-and-society',831,'Population: 72,1 13 (July 1994 est.)
Population growth rate: 0.84% (1994 est.)
Birthrate: 21.88 births/1,000 population
(1994 est.)
Death rate: 6.93 death$/l,000 population
(1994 est.)
Net migration rate: -6.S2 migrant(s)/t,000
population (1994 est.)
Infant mortality rate: 11.7 deaths/ 1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 69.67 years
male: 66.05 years
female: 73.39 years (1994 est.)
Total fertility rate: 2.23 children bom/
woman (1994 est.)
Nationality:
noun: Seychellois (singular and plural)
adjective: Seychelles
Ethnic divisions: Seychellois (mixture of
Asians, Africans, Europeans)
Religions: Roman Catholic 90%, Anglican
8%, other 2%
Languages: English (official), French
(official). Creole
Literacy: age 15 and over can read and write
(1971)
total population; 58%
male: 56%
female: 60%
Labor force: 27,700(1985)
by occupation; industry and commerce 31%,
services 2 1 %, government 20%, agriculture,
forestry, and fishing 12%, other 16% (1985)
note; 57% of population of working age ( 1 983)','2ceca1ad808b59b9cf475412ff7513d175f4ae5a11fa688148e81ec222393a47','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91ed6e7e3a946b4cd01f0f13cc6cec7a6c9d134cf54de2ffff6afb38a73c1b69',1994,'SG','Singapore','people-and-society',839,'Population: 2,859,142 (July 1994 est.)
Population growth rate: 1.12% (1 994 est.)
Birth rate; 1 6.52 births/ 1 ,(XX) population
(1994 est.)
Death rate: 5.3 deaths/1, (XX) population
(1994 est.)
Net migration rate: 0 migrant(s)/l ,000
population (1994 est.)
Infhnt mortality rate: 5.7 deaths/1 ,000 live
births (1994 est.)
Lifb expectancy at birth:
total population: 75.95 years
male: 73.17 years
female: 78.94 years (1994 est.)
Total fertility rate: 1 .88 children
bom/woman (1994 est.)
Nationality;
noun: Singaporean(s)
adjective: Singapore
Ethnic divisions: Chinese 76.4%, Malay
14.9%, Indian 6.4%, other 2.3%
Religions: Buddhist (Chinese), Muslim
(Malays), Christian, Hindu, Sikh, Taoist,
Confucianist
Languages: Chinese (official), Malay
(official and national), Tamil (official), English
(official)
Literacy: age IS and over can read and write
(1990 est.)
total population: 88%
male: 93%
female: 84%
Labor force; 1,485,800
by occupation: financial, business, and other
services 30.2%. manufacturing 28.4%,
commerce 22.0%, construction 9.0%, other
10.4% (1990)','0e889607f5de4abaf1a206f9248ed14a2d88a70a1de617b4e8a854c058f50f13','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8751c546812ce1412090d3678ef466923bafc86af16a9458add1e1f5de05a4c5',1994,'SK','Slovakia','people-and-society',844,'Population: 5,403,505 (July 1994 est.)
Population growth rate: 0.53% (1994 est.)
Birth rate: 1 4.55 births/ 1 ,000 population
(1994 est.)
Death rate; 9.28 deaths/I.OOO piopulation
(1994 est.)
Net migration rate: 0 migranUs)/! ,000
population ( 1994 e.st.)
Infant mortality rale: 10.4 deaths/I.OOO live
births (1994 est.)
Life expectancy at birth:
total population: 72.8 1 years
male: 68.66 years
female: 77.2 years ( 1994 est.)
Total fertility rate: 1 .96 children born/
woman (1994 est.)
Nationality:
noun: Slovak(s)
adjective: Slovak
Ethnic divisions: Slovak 85.6%, Hungarian
10.8%, Gypsy 1.5% (the 1992 census figures
underreport the Gypsy/Romany community,
which could reach 500.000 or more). Czech
1.1%, Ruthenian 15,000, Ukrainian 13,000,
Moravian 6,000, German 5,000, Polish 3,000
Religions: Roman Catholic 60.3%, atheist
9.7%, Protestant 8.4%, Orthodox 4.1%, other
17.5%
Languages: Slovak (official). Hungarian
Literacy:
total population: NA%
male; NA%
female: NA%
Labor force: 2.484 million
by occupation: industry 33.2%, agriculture
12.2%, construction 10.3%, communication
and other 44.3% ( 1990)','c89b42156a4fbe9f535f7a024a27a87b8a09e67320b692210da9a1914d0259c0','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd3dbb5c2a2d2fc82e87cc64f3af49731c9fd85010191d5479195efce99b2e0a',1994,'SB','Solomon Islands','people-and-society',851,'Population: 385,811 (July 1994 est.)
Population growth rate: 3.43% (1994 est.)
Birth rate: 38.93 births/1,000 population
(1994 est.)
Death rate: 4.63 deaths/1,000 population
(1994 est.)
Net migration rate: 0 migi''ant(s)/l,000
population (1994 e.st.)
Infant mortality rate: 27.8 deaths/ 1 ,JOO live
births (1994 est.)
Life expectancy at birth:
total population: 70.48 years
male: 68.05 years
female: 73.03 years (1994 est.)
Total fertility rate: 5.73 children
born/woman (1994 est.)
Nationality:
noun: Solomon Islander(s)
adjective: Solomon Islander
Ethnic divisions: Melanesian 93%,
Polynesian 4%, Micronesian 1 .5%, European
0.8%, Chinese 0.3%, other 0.4%
Religions: Anglican 34%. Roman Catholic
19%, Baptist 17%, United (Methodist/
Presbyterian) 1 1%, Seventh-Day Adventist
10%, other Protestant 5%
Languages: Melanesian pidgin in much of the
country is lingua franca, English spoken by
l%-2% of population
note: 120 indigenous languages
Literacy:
total population: NA%
male: NA%
female: NA%
Labor force: 23,448 economically active
by occupation: agriculture, forestry, and
fishing 32.4%, services 25%, construction,
manufacturing, and mining 7.0%, commerce,
transport, and finance 4.7% (1984)','ab803bdbe4e4d68f40220370c55f2ba8a2d4dca26ac00f3921bf3032f3155eaa','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81c4023f6699cb2e50619105b08f2b507859aec1d93acebb55ed092fe25ebd40',1994,'SO','Somalia','people-and-society',858,'Population: 6,666,873 (July 1994 est.)
Population growth rate: 3.24‘X'' ( 1 994 est,)
Birth rate: 45.97 birth,s/l.(K)0 population
(1994 est.)
Death rate: 13.53 deaths/1, (KX) population
(1994 est.)
Net migration rate: 0 migrant(s)/l .(XX)
population (1994 est.)
Infant mortality rate: 125.8 deaths/I .000
live births (1994 est.)
Life expectancy at birth:
total population: 54.75 years
male: 54.49 years
female: 55.01 years (1994 est.)
Total fertility rate: 7.25 children born/
woman (1994 est.)
Nationality:
noim: Somali(s)
adjective: Somali
Ethnic divisions; Somali 85%. Bantu. Arabs
30.(XX). Europeans 3.000, Asians 800
Religions; Sunni Muslim
Languages: Somali (ofUciul). Arabic. Italian,
English
Literacy: age 15 and over can read and write
(1990 est.)
total population: 24%
male: 36%
female: 14%
Labor force: 2.2 million (very few are skilled
laborers)
hy occupation: pastoral nomad 7()%i,
agriculture, government, trading, fishing,
handicrafts, and other 30%
note: 53% of population of working age ( 1 985 )','ce589c1ce3854e91f0bdb8d7f34e3962e85be528780bbaf1ab59d66d78f38c56','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2da625f8be2f3935eb496849a763fb5fca4a06742302c539b85e276486bfa127',1994,'SD','Sudan','people-and-society',865,'Population: 29,419,798 (July 1994 est.)
Population growth rate: 2.36% (1994 est.)
Birth rate: 4 1 .93 binhs; 1 ,000 population
(1994 est.)
Death rate: 1 2.09 deaths/I ,000 population
(1994 est.)
Net migration rate: -6.2S migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 79.S deaths/ 1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population; 54.27 years
male: 53.4 years
female; 55. 19 years (1994 est.)
Total fertility rate: 6.09 children
bom/woman (1994 est.)
Nationality:
noun; Sudanese (singular and plural)
adjective: Sudanese
Ethnic divisions: black 52%. Arab 39%. Beja
6%. foreigners 2%, other 1%
Religions: Sunni Muslim 70% (in north),
indigenous beliefs 25%, Christian 5% (mostly
in south and Khartoum)
Languages; Arabic (official), Nubian, Ta
Bedawie, diverse dialects of Nilotic, Nilo-
Hamitic, Sudanic languag -s, English
note: program of Arabization in process
Literacy: age 15 and over can read and write
(1990 est.)
total population: 27%
male; 43%
female: 12%
Labor force: 6.5 million
hy occupation: agriculture 80%. industry and
commerce 10%. government 6%
note: labor shortages for almost all categories
of skilled employment (1983 est.); 52% of
population of working age (1985)','7823684a56211fe8ed82f8e51e02ef8d657ce3d597c0c940f5a745d18c3fc443','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('466d3b2cc289d5eabf28b157e410ea5bb488d0b2a5686f9a7387f81c2afcffb0',1994,'SR','Suriname','people-and-society',871,'Population: 422,840 (July 1994 est.)
Population growth rate: 1 .57% ( 1 994 est.)
Birthrate: 25.31 births/1,000 population
(1994 est.)
Death rate: 6 deaths/ 1 ,000 population ( 1 994
e.st.)
Net migration rate: -3.66 inigrant(s)/1 ,000
population (1994 est.)
Infant mortality rate: 3 1 .3 death.s/1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population: 69.45 years
male: 66.94 years
female: 72.08 years (1 994 est.)
Total fertility rate: 2.79 children bom/
woman (1994 est.)
Nationality:
noun: Surinamerfs)
adjective: Surinamese
Ethnic divisions: Hindustani (East Indian)
37%. Creole (black and mixed) 3 1 %, Javanese
15.3%, Bush black 10.3%, Amerindian 2.6%,
Chinese 1.7%, Europeans 1%, other 1.1%
Religions: Hindu 27.4%, Muslim 19.6%,
Roman Catholic 22.8%, Protestant 25.2%
(predominantly Moravian), indigenous beliefs
5%
Languages: Dutch (official), English widely
spoken, Sranan Tongo (Surinamese,
sometimes called Taki-Taki) is native language
of Creoles and much of the younger population
and is lingua franca among others, Hindi
Suriname Hindustani (a variant of Bhoqpuri),
Javanese
Literacy: age 15 and over can read and write
(1990 est.)
total population: 95%
male: 95%
female: 95%
Labor force: 104,000(1984)
hy occupation: NA
Population: 3,018 (July 1994 est.)
Population growth rate: -3.5% (1994 est.)
Birthrate: NA
Death rate: NA
Net migration rate: NA
Infant mortality rate: NA
Life expectancy at birth: NA
Total fertility rate: NA
Ethnic divisions: Russian 64%, Norwegian
35%, other 1%(1981)
Languages: Russian, Norwegian
Literacy:
total population: NA%
male: NA%
female: NA%
Labor force: NA','f65503eef217958444364db596d3d2d6d767463bba8cd3b3545418e309882cc0','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5d86e77fb5a90096f6d2042b44360827f1b0f05a42ede3d5001eb0e8365b868',1994,'MZ','Mozambique','people-and-society',878,'Population: 27,985,660 (July 1994 est.)
Population growth rate: 2.5% (1994 est.)
Birth rate: 45.48 births/1.000 population
(1994 e.st.)
Death rate: 1 9.42 deaths/ 1 ,000 population
(1994 est.)
Net migration rate: - 1 .03 migrant(s)/1 ,000
population (1994 est.)
Infant mortality rate: 109.7 deaths/ 1 ,000
live births (1994 est.)
Life expectancy at birth:
total population: 43.25 years
male: 4 1 .52 years
female: 45.03 years (1994 est.)
Total fertility rate: 6.2 children bom/woman
(1 994 est. >
Nationality:
noun: Tanzaniari(s)
adjective: Tanzanian
Ethnic divisions:
mainland: native African 99% (consisting of
well over 100 tribes)
Asian. European, and Arab 1%
Zanzibar: NA
Religions:
mainland: Christian 45%, Muslim 35%.
indigenous beliefs 20%
Zanzibar: Muslim 99% plus
Languages; Swahili (official: widely
understood and generally used for
communication between ethnic groups and is
used in primary education), English (official;
primary language of commerce,
administration, and higher education)
note: first language of most people is one of the
local languages
Literacy; age 15 and over can read and write
(1978)
total population: 46%
male: 62%
female: 31%
Labor force: 732,200 wage earners
by occupation: agriculture 90%. industry and
commerce 10% (1986 est.)','946a6eccbe517afab2d7a7a8f1214573f30fcc9abb63fd7e329ac67ae23d8603','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('add10230694db2c7ac748a7354343c996f90fd8016266c2b2bdafe2c11bda47b',1994,'TM','Turkmenistan','people-and-society',884,'Population: 3,995, 1 22 (July 1994 est.)
Population growth rate: 2.01% (I994est.)
Birthrate: 30.42 biiths/ 1, 000 population
(1994 est.)
Death rate: 7.44 deaths/LOCX) population
(1 994 est.)
Net migration rate: -2.89 migrant(s)/l ,000
population (1994 est.)
Infant mortality rate; 69.9 deaths/I ,000 live
births ( 1994 est.)
Life expectancy at birth;
total population: 65.14 years
maie: 61.63 years
female: 68.82 years (1994 est.)
Total fertility rate: 3.77 children bom/
woman (1994 e.st.)
Nationality:
noun: Turkmen(s)
adjective: Turkmen
Ethnic divisions: Turkmen 73.3%, Russian
9.8%. Uzbek 9%, Kazakh 2%, other 5.9%
Religions: Muslim 87%, Eastern Orthodox
1 1 %, unknown 2%
Languages: Turkmen 72%, Russian 12%,
Uzbek 9%, other 7%
Literacy: age 9-49 can read and write (1970)
total population: 100%
male: 100%
female: 100%
Labor force; 1 .573 million
by occupation: agriculture and forestry 44%,
industry and construction 20%, other 36%
(1992)','601b5f9e238636b54110dce2988a91f05b983a5fd1bd4590d244b1365ca90f00','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('808c8d46766b7faa034766459ea4ea8a9a98d28257a34a3e54dcd861449a69c1',1994,'BS','Bahamas','people-and-society',889,'Population: 13,552 (July 1994 est.)
Population growth rate: 2.69% (1994 est.)
Birthrate; 14. 14 births/1.000 population
(1994 est.)
Death rate: 5.17 deaths/I .(X)0 population
(1994 est.)
Net migration rate: 1 7.92 migrant(s)/l ,000
population (1994 est.)
Infant mortality rate: 12.7 deaths/ 1 ,000 live
births (1994 est.)
Life expectaiKy at birth:
total population: 75.34 years
male: 73.41 years
female; 77.02 years (1994 est.)
Total fertility rate: 2.05 children bom/
woman (1994 est.)
Nationality:
noun: none
adjective: none
Ethnic divisions: African
Religions: Baptist 41.2%. Methodist 18.9%,
Anglican 1 8.3%, Seventh-Day Adventist
1.7%, other 19.9% (1980)
Languages: English (official)
Literacy: age 15 and over who have ever
attended school (1970)
total population: 98%
male: 99%
female: 98%
Labor force: NA
by occupation: majority engaged in fishing
and tourist industries; some subsistence
agriculture','b53cfde066be1c1cb4b59ca41aa8e505acfb7145605aec02c668f29d0c396ea7','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4d6ff7bc27805c67ea64ae5992395d2f2a73b531df2384502867f6df6c63390',1994,'TV','Tuvalu','people-and-society',895,'Population: 9,831 (July 1994 est.)
406
Population growth rate: 1 .66% ( 1 994 esi.)
Birthrate: 25.73 births/1,000 population
(1994 est.)
Death rate: 9. 1 5 deaths/1 ,000 population
(1994 est.)
Net migration rate: 0migrant(s)/l,(X)0
population (1994 est.)
Inftint mortality rate; 27.3 deaths/1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population; 63.03 years
male; 61.57 years
female; 64.08 years (1994 est.)
Total fertility rate: 3.) I children bom/
woman (1994 est.)
Nationality:
noun; Tuvaluans(s)
adjective; Tuvaluan
Ethnic divisions: Polynesian 96%
Religions: Church of Tuvalu
(Congregationalism 97%, Seventh-Day
Adventist 1.4%, Baha''i 1%, other 0.6%
Languages: Tuvaluan, English
Literacy:
total population; NA%
male; NA%
female; N-'' %
Labor foiv.; NA
by occupation; NA','ff4f00787050b971b87ad4c8bca35d6d0d13df4aa8029afba85f66c88b119cf3','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1beb31fb9e919400741420fc955b443461fee414faf3e5c0416e0194ac6837e',1994,'UG','Uganda','people-and-society',899,'Population: 19,121,934 (July 1994 est.)
Population growth rate: 2.42% ( 1 994 est.)
Birthrate: 48.8 bitths/l,0(X) population
(1994 est.)
Death rate: 23.68 deaths/ 1, (X)0 population
(1994 est.)
Net migration rate: -0.9 migrant(s)/ 1,000
population (1994 est.)
Infant mortality rate: 1 1 2.2 deaths/ 1 ,000
live births (1994 est.)
Life expectancy at hirth:
total population: 37.46 years
male: 37.15 years
female: 37.79 years (1994 est.)
Total fertility rate: 6.77 children
bom/woman (1994 est.)
Nationality:
noun: Ugandan(s)
adjective; Ugandan
Ethnic divisions: Baganda 17%. Karamojong
1 2%, Basogo 8%, iteso 8%, Langi 6%,
Rwanda 6%, Bagisu 5%, Acholi 4%, Lugbara
4%, Bunyoro 3%, Batobo .3%, European.
Asian, Arab 1%, other 23%
Religions: Roman Catholic 33%, Protestant
33%, Muslim 16%, indigenous beliefs 18%
Languages: English (official), Luganda.
Swahili, Bantu language.s, Nilotic languages
Literacy: age IS and over can read and write
(1990 est.)
total population: 48%
male: 62%
female; 35%
Labor force: 4.5 million (est.)
by occupation: agriculture over 80%
note; 50% of population of working age (1983)','866f664b46809fe08d62eeddd2d0f52f5cdcd0284a4d146487b8eca06f1604c8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27dad15a0243b21de6ab4f7318f04f5e762839c77b83b2b379bb349c41672a66',1994,'AE','United Arab Emirates','people-and-society',905,'Population: 2,791,141 (July 1994 est.)
Population growth rate: 4.79% ( 1994 est.)
Birthrate: 27,68 births/1.000 population
(1994 est.)
Death rale: 3.05 death.s/l,(X)0 population
(1994 est.)
Net migration rate: 23.31 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 2 1 .7 deaths/I ,000 live
births (1994 est.)
Life expectancy at birth:
total iHtpuUition; 72,26 years
tnale; 70. 16 years
female; 74.46 years (1994 est.)
Total fertility rate; 4.6 children bom/woman
(1994 est.)
Nationality:
noun; Emirian(s)
adjective; Emirian
Ethnic divisions: Emirian 19%, other Arab
23%, South Asian 50%, other expatriates
(includes Westerners and East Asians) 8%
(1982)
note; less than 20% are UAE citizens (1982)
Religions: Muslim 96% (Shi''a 16%),
Christian, Hindu, and other 4%
Languages: Arabic (official). Persian,
English, Hindi, Urdu
Literacy: age 10 and over but definition of
literacy not available (1980)
total population; 68%
male; 70%
female: 63%
Labor force: 580,0(X)( 1986 est.)
by occuixition; industry and commerce 85%,
agriculture 5%. services 5%. government 5%
note; 80% of labor force is foreign (est.)
Population: 58,135,1 10 (July 1994 est.)
Population growth rate: 0.28% (1994 est.)
Birth rate; 1 3.39 births/1 ,000 population
(1994 est.)
Death rate: 1 0.76 deaths/ 1 ,000 population
(1994 est.)
Net migration rate: 0, 1 7 migrant(s)/l ,000
population (1994 est.)
Infant mortality rate: 7.2 deaths/1, (X)0 live
births (1 994 est.)
Life expectancy at birth:
total population: 76.75 years
male: 73.94 years
female: 79.69 years (1994 est.)
Total fertility rate: 1 .83 children horn/
woman (1994 est.)
Nationality;
noun: BritDn(s), British (collective pi.)
adjective: British
Ethnic divisions: English 8 1 .5%. Scottish
9.6%, Irish 2,4%, Welsh 1.9%. Ulster 1.8%.
West Indian, Indian, Pakistani, and other 2.8%''
Religions: Anglican 27 million, Roman
Catholic 9 million, Muslim I million,
Presbyterian 800,000, Methodist 760.(X)0, Sikh
400,000, Hindu 350,000, Jewish 300,000
(1991 est.)
note: the UK does not include a question on
religion in its cen.sus
Languages: English, Welsh (about 26% of
the population of Wales), Scottish form of
Gaelic (about 60,000 in Scotland)
Literacy: age 15 and over can read and write
(1978 est.)
total population: 99%
male: NA%
female: NA%
Labor force: 28.048 million
by occupation: services 62.8%, manufacturing
and construction 25.0%, government 9.1%,
energy 1.9%, agriculture 1.2% (June 1992)','3fee8014fb23312797f295ab6387522b0044cde472661be88d7fc27fcf7ae71c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5088a94eac5a92f2c32c4508c146e1a4e688aa435a96ec85c4421af2340f4b21',1994,'US','United States','people-and-society',911,'416
but to date the Compact process has not been
completed in Palau, which continues to be
administered by the US as the Trust Territory
of the Pacific Islands; the Federated States of
Micronesia signed a Compact of Free
Association with the US (effective 3
November 1986); the Republic of the Marshall
Islands signed a Compact of Free Association
with the US (effective 21 October 1986)
Independence: 4 July 1 776 (from England)
National holiday: Independence Day, 4 July
(1776)
Constitution: 1 7 September 1 787, effective 4
March 1789
Legal system: based on English common law;
judicial review of legislative acts; accepts
compulsory ICJ Juri.sdiction, with reservations
Suffrage: 1 8 years of age; universal
Executive branch:
chief of shite anil head of ftovemment:
President William Jefferson CLINTON (since
20 January 1993); Vice President Albert
GORE, Jr. (since 20 January 1993); election
last held 3 November 1992 (next to be held
November 1996); results — William Jefferson
CLINTON (Democratic Party) 43.2%, George
BUSH (Republican Party) 37.7%, Ross
PEROT (Independent) 19.0%, other 0.1%
cabinet: Cabinet; appointed by the president
with Senate approval
Legislative branch: bicameral Congress
Senate: elections last held 3 November 1992
(next to be held 8 November 1994); results —
Democratic Party .83%. Republican Party 47%,
other NEGL%; seats — ( icio total) Democratic
Party 57, Republican Party 43
House of Representatives: elections last held 3
November 1992 (next to be held 8 November
1994); results — Democratic Party 52%,
Republican Party 46%, other 2%; seats— (435
total) Democratic Party 258, Republican Party
1 76, Independent I
Judicial branch; Supreme Court
Political parties and leaders; Republican
Party. Haley BARBOUR, national committee
chairman; Jcunic AUSTIN, co-chairman;
DcnuKratic Party. David C. WILHELM,
national committee chairman; several other
groups or parties of minor political
significance
Member of: AfDB. AO (ob.server). ANZUS.
APEC. AsDB. Australian Group. BIS. CCC,
COCOM, CP. CSCE. EBRD. ECE, ECLAC,
FAO, ESCAP. G-2. G-5, G-7, G-8. G-IO.
GATT. lADB, IAEA, IBRD. ICAO, ICC,
ICFTU. IDA. lEA, IFAD. IFC. ILO. IMF.
IMO. INMARSAT, INTELSAT. INTERPOL.
IOC, lOM, ISO, ITU, LORCS. MINURSO,
MTCR, NACC. NATO, NEA. NSG, OAS,
OECD, PCA, SPC, UN, UNCTAD, UNHCR.
UNIDO, UNIKOM, UNOSOM. UNRWA. UN
Security Council, UNTAC, UN Trustecsiiip
Council, UNTSO, UPU, WCL, WHO. WIPO,
WMO, WTO. ZC
Flag: thirteen equal hori/.ontal stripes of red
(lop and bottom) alternating with white; there
is a blue rectangle in the upper hoist-side
corner bearing 50 small white five-pointed
stars arranged in nine offset horizontal rows of
six stars (top and bottom) alternating with rows
of five stars; the 50 stars represent the 50 states,
the 13 stripes represent the i3 original
colonies; known as Old Glory; the design and
colors have been the basis fora number of
other flags including Chile, Liberia, Malaysia,
and Puerto Rico','7dc78c0cd9ab351f97e3ca155310a037a3294e211958c0ff044b4cd4a01702e4','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00e9d89a9db9f7ec894ad65400786fa8cae225ae6ec8ab9a82beba93d2e3b09c',1994,'UY','Uruguay','people-and-society',916,'Population: 3,198,910 (July 1994 est.)
Population growth rate; 0.75% (1994 est.)
Birthrate: 17.7 births/1,000 population
(1994 est.)
Death rate: 9.39 deaths/1,000 population
(1994 est.)
Net migration rate; -0.84 migrant(s)/1.000
population (1994 est.)
Infant mortality rate: 1 7. 1 deaths/1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population; 74.09 years
male: 70.88 years
female; 77.47 years (1994 est.)
Total fertility rate: 2.44 children bom/
woman ( 1994 est.)
Nationality:
noun: Uruguayan(s)
adjective: Uruguayan
Ettnic divisions: white 88%, mestizo 8%,
black 4%
Religions: Roman Catholic 66% (less than
half adult population attends church regularly),
Protestant 2%, Jewish 2%, nenprofessing or
other 30%
Languages: Spanish, Brazilero (Portuguese-
Spanish mix on the Brazilian frontier)
Literacy; age 1 5 and over can read and write
(1990 est.)
total population: 96%
male: 97%
female; 96%
Labor force: I.35S million (1991 est.)
by occupation; government 25%,
manufacturing 19%, agriculture 11%,
commerce 12%. utilities, construction,
transport, and communications 12%, other
services 21% (1988 est.)','9694c4728b45b10ef4cbdf695169a102e3256e775e59294c5c4ece3f51ddee87','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42461660a7f1e3cbea45ba0880af2b33ee28ee108e04a0c64695fe871c4b515c',1994,'UZ','Uzbekistan','people-and-society',922,'Population: 22,60k,866 (July 1994 est.)
Population growth rate: 2. 1 3% (1994 est.)
Birth rate: 30.01 births/1,000 population
(1994 est.)
Death rate: 6.51 deaths/1,000 population
(1994 est.)
Net migration rate: -2.22 migrant(s)/l, 000
population (1994 est.)
Infant mortality rate: 53.2 deaths/l,0(X) live
births (1994 est.)
Life expectancy at birth:
total population; 68.38 years
male: 65.28 years
female: 72.04 years (1994 est.)
Total fertility rate: 3.73 children bom/
woman (1994 est.)
Nationality:
noun: Uzbek(s)
adjective; Uzbek
Ettnic divisions: Uzbek 71.4%, Russian
8.3%. Tajik 4.7%, Kazakh 4. 1 %, Tatar 2.4%.
Karakalfuk 2.1%, other 7%
Religions: Muslim 88% (mostly Sunnis),
Eastern Orthodox 9%, other 3%
Languages: Uzbek 74.3%, Russian 14.2%,
Tajik 4.4%, other 7.1%
Literacy: age 9-49 can read and write (1970)
total population; 100%
male; 100%
female: 1(X)%
Labor force: 8.234 million
by occupation: agriculture and forestry 43%,
industry and construction 22%, other 35%
(1992)','1b600b09ab9e23317838533424fc66fbe64ff599c8e7d5eb3efa8ede90ab909a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2bd204276a0f8ccfc11ada6d3948491a4748943a077c30bb1962dc269f5bc885',1994,'VU','Vanuatu','people-and-society',928,'Population: 169,776 (July 1994 est.)
Population growth rate: 2.29% (19^ est.)
Birthrate: 32.21 births/1 ,0(X) population
(1994 est.)
Death rate: 9.31 deaths/1 ,CKX) population
(1994 est.)
Net migration rate: 0 migrants)/ 1, (X)0
population (1994 est.)
Infant mortality rate: 68.1 deaths/I, 000 live
births (1994 est.)
Life expectancy at birth:
total population: 59.25 years
male: 57.51 years
female: 61.09 years (1994 est.)
Total fertility rate: 4.31 children bom/
woman (1994 est.)
Nationality:
noun: Ni-Vanuatu (singular and plural)
adjective: Ni-Vanuatu
Ethnic divisions: indigenous Melanesian
94%, French 4%, Vietnamese, Chinese, Pacific
Islanders
Religions: Presbyterian 36.7%, Anglican
15%, Catholic 15%, indigenous beliefs 7.6%,
Seventh-Day Adventist 6.2%, Church of Christ
3.8%, other 15.7%
Languages: English (official), French
(official), pidgin (known as Bislama or
Bichelama)
Literacy: age 15 and over can read and write
(1979)
total population: 53%
male: 57%
female: 48%
Labor force: NA
by occupation: NA
Papulation; 20,562.405 (July 1994 est.)
Population growth rate: 2. 1 6% ( 1 994 est.)
Birthrate; 25.74 births/1.000 population
(1994 est.)
Death rate: 4.63 deaths/1.000 population
(1994 est.)
Net migration rate: 0.47 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 27.7 deaths/ 1 .000 live
births (1994 est.)
Life expectancy at birth:
total population: 73 years
male; 70,12 years
female; 76.03 years (1994 est.)
Total fertility rate; 3.05 children bom/
woman (1994 est.)
Nationality:
noun: Venezuelan(s)
adjective: Venezuelan
Ethnic divisions; mestizo 67%, white 21 %.
black 10%, Indian 2%
Religions: nominally Roman Catholic 96%.
Protestant 2%
Languages: Spanish (official), Indian dialects
spoken by about 200,000 Amerindians in the
remote interior
Literacy; age 1 5 and over can read and write
(1990 est.)
total population: 889f>
male: 87%
female: 90%
Labor force: 5.8 million
by occupation; services 56%. industry 28%,
agriculture 16% (198.5)','ac4edb4b1189b06d2f555a2287269d90b9a7a78af8fbc4eb1e93b178f5d7566d','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e72547ae0757d2afcf4c7b0e85bd452e75162e8c41e7ac6b2661ea20cc19d7b9',1994,'WF','Wallis and Futuna','people-and-society',934,'Population: 302 (July 1994 esi.)
Population: 14,338 (July 1994 esi.)
Population growth rate; 1 . 1 3% ( 1994 est.)
Birth rate: 25.74 births/1.000 population
(I994e.st.)
Death rate: 5.26 deaths/ 1, 000 population
(1994 est.)
Net migration rate: -9. 1 8 migrant(s)/l .000
population (1994 est.)
Wallis and Futuna (continued)
Infant mortality rate: 26.26 deaths/1,000
live births (1994 est.)
Life expectancy at birth;
total population; 71.72 years
male; 71.08 years
female; 11 A years (1994 est.)
Total fertility rate: 3.23 children bom/
woman (1994 est.)
Nationality:
noun; Wallisian(s), Futunan(s), or Wallis and
Futuna Islanders
adjective; Wallisian. Futunan, or Wallis and
Futuna Islander
Ethnic divisions: Polynesian
Religions: Roman Catholic
Languages: French. Wallisian (indigenous
Polynesian language)
Literacy: all ages can read and write ( 1 969)
total population; 50%
male; 50%
female; 5 1 %
Labor force; NA
by occupation; agriculture, livestock, and
fishing 80%, government 4% (est.)','20f23e2317b75c733577f27e5f409feb141e3a91127d3e5b51be4abd854e12f0','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2201ca07e3d9b55aa24ae28fb910bc36884e2c4511747d01a172887e93eb853a',1994,'IL','Israel','people-and-society',938,'Population: 1 ,443,790 (July 1994 cst.)
note: in addition, there are 1 10,500 Jewish
settlers in the West Bank and 144,100 in East
Jerusalem (1994 est.)
Population growth rate: 2.68% ( 1 994 est.)
Birthrate: 32.48 births/ 1, 000 population
(1994 est.)
Death rate: 5.1 1 dealhs/1,000 population
(1994 est.)
Net migration rate: -0.59 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 33.8 deaths/ 1 ,000 live
births (1994 est.)
Life expectancy at birth:
total population; 70.39 years
male: 68.88 years
female: 7 1 .98 years (1994 est.)
Total fertility rate: 4.2 children born/woman
(1994 est.)
Nationality:
noun; NA
adjective: NA
Ethnic divisions: Palestinian Arab and other
88%, Jewish 1 2%
ReligionB: Muslim 80% (predominantly
Sunni), Jewish 12%, Christian and other 8%
Languages: Arabic, Hebrew spoken by Israeli
settlers, English widely understood
Literacy:
total papulation: NA%
male; NA%
female; NA%
Labor force: NA
by occupation; construction 28.2%,
agriculture 2 1 .8%, industry 14,5%, commerce,
restaurants, and hotels 12.6%, other services
22.9% (1991)
note: excluding Jewish settlers','f857a65951ad7c312f3ae524acd99a913c4486a141839c248fb8c3c3577e6909','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be1ffd48588db44c1253218d470ab9f56f20a6c0570ab4e218b8a6bf9caa9058',1994,'EH','Western Sahara','people-and-society',945,'Population; 21 1,877 (July 1994 est.)
Population growth rate: 2.5% (1994 est.)
Birth rate: 47.22 births/1,000 population
(1994 est.)
Death rate: 19.04 deaths/1,000 population
(1994 est.)
Net migration rate; -3.21 migrant(s)/ 1,000
population (1994 est.)
Infant mortality rate; 1 52.2 deaths/ 1 ,000
live births (1994 est.)
Life expectancy at birth:
total population: 45.59 years
male: 44.66 years
female: 46.83 years ( 1 994 est.)
Total fertility rate: 6.96 children bom/
woman (1994 est.)
Nationality:
noun; Sahrawi(s), Sahraoui(s)
adjective: Sahrawian, Sahraouian
Ethnic divisions: Arab, Berber
Religions: Muslim
Languages: Hassaniya Arabic, Moroccan
Arabic
Literacy:
total population: NA%
male: NA%
female: NA%
Labor force: 12,000
by occupation: animal husbandry and
subsistence farming 50%','67834f7f19e76bb1a776d2cccc6524f34cf54ed0a4a490125b68016404a10359','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1818c58826bcd90697b4f30c6ed3b099528dfc7709dc18e9fecf74ba6ce9a2b',1994,'YE','Yemen','people-and-society',950,'Population: 11,1 05,202 (July 1 994 est.)
Population growth rate: 3.34% ( 1 994 est.)
Birthrate: 50.72 births/ 1,000 population
(1994 est.)
Death rate; 1 4.94 deaths/I ,000 population
(1994 est.)
Net migration rate: -2.44 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 1 1 2.8 deaths/ 1 ,000
live births (1994 est.)
Life expectancy at birth:
total population: 5 1 .47 years
male: 50.34 years
female: 52.65 years (1994 est.)
Total fertility rate: 7.2 children bom/woman
(1994 est.)
Nationality:
noun: Yemeni(s)
adjective: Yemeni
Ethnic divisions; predominantly Arab; Afro-
Arab concentrations in coastal locations; South
Asians in southern regions; small European
communities in major meiropolitan areas;
60,000 (est.) Somali refugees encamped near
Aden
Religions; Muslim including Sha''fi (Sunni)
and Zaydi (Shi ''a), Jewish, Christian, Hindu
Languages; Arabic
Literacy: age 15 and over can read and write
(1990 est.)
total population: 38%
male: 53%.
female: 26%
Labor force: no reliable estimates exist, most
people are employed in agriculture and herding
or as expatriate laborers; services,
construction, industry, and commerce account
for less than half of the labor force','b0770cb6909529e123b772fbade80e306affc73f52bc8f725b0fe08e2f565d0c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f9f8d56e39ab91a7f51962dcf6da6efa9799b2fd0606205178d7c6f1e203b90',1994,'ZM','Zambia','people-and-society',955,'Population: 42,684,091 (July 1994 est.)
Population growth rate: 3. 1 7% ( 1 994 est.)
Birth rate: 48.39 births/l,0(X) population
(1994 est.)
Death rate: 16.74 deaths/I ,000 population
(1994 est.)
Net migration rate: 0.03 migrant(s)/l,000
population (1994 est.)
Infant mortality rate: 1 1 0.9 deaths/ 1 ,000
live births (1994 est.)
Life expectancy at birth:
total population: 47.4 years
male: 45.57 years
female: 49.29 years (1994 est.)
Total fertility rate: 6.7 children bom/woman
(1994 est.)
Nationality;
noun: Zairian(s)
adjective; Zairian
Ethnic divisions: over 200 African ethnic
groups, the majority are Bantu: four largest
tribes — Mongo. Luba. Kongo (all Bantu), and
the Mangbetu-Azande (Hamitic) make up
about 45% of the population
Religions; Roman Catholic 50%, Protestant
20%, Kimbanguist 10%, Muslim 10%. other
syncretic sects and traditional beliefs 10%
Languages: French, Lingata, Swahili,
Kingwana, Kikongo, Tshiluba
Literacy: age IS and over can read and write
(1990 est.)
total population: 72%
male; 84%
female: 61%
Labor force: 1 5 million ( 1 3% of the labor
force is wage earners; 5 1 % of the population is
of working age)
by occupation: agriculture 75%, industry 13%,
services 12% (1985)','42f9d67dd9742e37cef7fa635c374901b82be56d00a5c856d46eb519b2fbeb11','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a305f71f43b32fd72edf364af8384664dc2e8325f87db5ed59af9c62519c65c',1994,'ZW','Zimbabwe','people-and-society',960,'Population: 9,l88,l90(Jul> 1994 est.)
Population growth rate: 2.83% (1994 est.)
Birthrate: 4S.99 births/1,000 population
(1994 est.)
Death rate: 1 7.6S deaths/ 1 ,000 population
(1994 est.)
Net migration rate: -O.OS migrant(s)/ 1,000
population (1994 est.)
Inftanl mortality rate: 85 deaths/1,000 live
births (1994 est.)
Life expectancy at Mrth:
total population: 44. 1 8 years
male: 43.82 years
female: 44.54 years (1994 est.)
Total fertility rate: 6.68 children bom/
woman (1994 est.)
Nationality:
noun: Zambian(s)
adjective: Zambian
E^nic divisions: African 98.7%, European
1.1%, other 0,2%
Religioiu: Christian 50-75%, Muslim and
Hindu 24-49%, indigenous beliefs 1%
Languages: English (ofTicial)
lote: about 70 indigenous languages
Literacy: age 15 and over can read and write
(1990 est.)
total population: 73%
male: 81%
female: 65%
Labor force: 2.455 million
by occupation: agriculture 85%, mining,
manufacturing, and construction 6%. transport
and services 9%
Location: Eastern Asia, off the southeastern
coast of China, between Japan and the','8f72413503927419bb3516a8ef4c990dcc56a7cb8e2aa6544f37d07c3b60c70e','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

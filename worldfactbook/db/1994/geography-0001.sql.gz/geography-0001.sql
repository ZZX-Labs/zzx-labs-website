SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ef8d988575eff41debf8f8cd17c9a123d73603c03505297e0d1b0be6f65a34f',1994,'DZ','Algeria','geography',14,'Location: Northern Africa, along the
Mediterranean Sea, between Morocco and
Location: Central Africa, between the Central
African Republic and Libya
Map references: Africa, Standard Time
Zones of the World
Area:
total area; 1 .284 million sq km
land area: 1 ,259,2CX) sq km
comparative area; slightly more than three
times the size of California
Land boundaries: total 5,968 km, Cameroon
1 .094 km. Central African Republic 1 , 1 97 km,
Libya 1,055 km, Niger 1,175 km, Nigeria 87
km, Sudan 1 .360 km
Coastline: 0 km (landlocked)
Maritime claims: none; landlocked
Interrutional disputes: the International
Court of Justice (ICJ) ruled in February 1994
that the 100,000 sq km Aozou Strip between
Chad and Libya belongs to Chad, and that
Libya must withdraw from it by 31 May 1994;
Libya had withdrawn its forces in response to
the ICJ ruling, but as of June 1994 still
maintained an airfield in the disputed area;
demarcation of international boundaries in
Lake Chad, the lack of which has led to border
incidents in the past, is completed and awaiting
ratification by Cameroon, Chad, Niger, and','246beb94f8b00f5a1c2783185271faf97f07da40e168c9f22c561a52aea79034','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0ed62f55ec5c5d428013108994cae2e166fc32c3ac2d55e12726df040f7c9b8',1994,'TN','Tunisia','geography',15,'Map references: Africa, Europe
Area:
total area: 2,38 1 ,740 sq km
land area: 2,38 1 ,740 sq km
conf- mtive area: slightly less than 3.5 times
the size of Texas
Land boundaries: total 6,343 km, Libya 982
km, Mali 1,376 km, Mauritania 463 km,
Morocco 1 ,559 km, Niger 956 km, Tunisia 965
km. Western Sahara 42 km
Coastline: 998 km
Maritime claims:
territorial sea: 12 nm
International disputes: Libya claims part of
southeastern Algeria; land boundary dispute
with Tunisia settled in 1993
Climate: arid to semiarid; mild, wet winters
with hot, dry summers along coast; drier with
cold winters and hot summers on high plateau;
sirocco is a hot, dust/sand-laden wind
especially common in summer
Terrain: mostly high plateau and desert;
some mountains; narrow, discontinuous
coastal plain
Natural resources: petroleum, natural gas,
iron ore. phosphates, uranium, lead, zinc
Land use:
arable land: 3%
permanent crops: 0%
meadows and pastures: 13%
forest and woodland: 1%
other: 82%
Irrigated land: 3,360 sq km ( 1 989 est.)
Location: Northern Africa, 144 km from Italy
across the Strait of Sicily, between Algeria and','4940d6d3592e08c0074405a1abeec131ec889827fc8745cf1077f29f6510dbc6','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf2613147daf5cde85dee96bb30f1f9efdf895d8e79f630a7890587928dcaf18',1994,'AS','American Samoa','geography',22,'Location: Oceania. Polynesia, in the South
Pacific Ocean. 3,700 km south-southwest of
Honolulu, about halfway between Hawaii and
Map references: Oceania
Area;
total area: I sq km
land area: I sq km
comparative area: about 1,7 times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 3 km
Maritime claims;
contiguous zone: 24 nm
continental shelf: 200-m depth or to depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical, but moderated by
prevailing winds
Terrain; low and nearly level with a
maximum elevation of about I meter
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Irrigated land: 0 sq km
Location: Oceania, Micronesia, straddling
the equator in the Pacific Ocean, about halfway
between Hawaii and Australia
Map references: Oceania
Area:
total area: 717 sq km
land area: 7 1 7 sq km
comparative area: slightiy more than four
times the size of Washington, DC
note: includes three island groups — Gilbert
Islands, Line Islands, Phoenix Islands
Land boundaries: 0 km
Coastline: 1,143 km
Maritime claims:
exclusive economic zone; 200 nm
territorial sea: 1 2 nm
International disputes: none
Climate; tropical; marine, hot and humid,
moderated by trade winds
Terrain: mostly low-lying coral atolls
surrounded by extensive reefs
Natural resources: phosphate (production
discontinued in 1979)
Land use:
arable land: 0%
permanent crops: 5 1 %
meadows and pastures; 0%
forest and woodland: 3%
other: 46%
Irrigated land: NA sq km
Location: Eastern Asia, between China and
South Korea
Map references: Asia, Standard Time Zones
of the World
Area:
total area: 1 20,540 sq km
land area: 1 20,4 1 0 sq km
comparative area: slightly smaller than
Mississippi
Land boundaries: total 1,673 km, China
1,416 km. South Korea 238 km, Russia 19 km
Coastline: 2,495 km
Maritime claims:
territorial sea: 1 2 nm
exclusive economic zone: 200 nm
military’ boundary line: 50 nm in the Sea of
Japan and the exclusive economic zone limit in
the Yellow Sea where all foreign vessels and
aircraft without permission are banned
International disputes: short section of
boundary with China is indefinite;
Demarcation Line with South Korea
Climate; temperate with rainfall concentrated
in summer
Terrain; mostly hills and mountains
separated by deep, narrow valleys; coastal
plains wide in west, discontinuous in east
Natural resources; coal, lead, tungsten, zinc,
graphite, magnesite, iron ore. copper, gold,
pyrites, salt, fluorspar, hydrc^wer
Land use:
arable land: 18%
permanent crops: 1%
meadows and pastures: 0%
forest and woodland: 74%
other; 7%
Irrigated land: 14,000 sq km (1989)
Map references: Oceania
Area:
total area: 11.9sqkm
land area: 1 1 .9 sq km
comparative area: about 20 times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 14,5 km
Maritime claims:
contiguous zone: 12 nm
continental shelf: 200-m depth or to depth of
exploitation
exclusive economic zone; 200 nm
territorial sea; 12 nm
International disputes: none
Climate: equatorial, hot, and very rainy
Terrain: low, with maximum elevations of
about 2 meters
Natural resources: none
Land use:
arable land; 0%
permanent crops: 0%
meadows and pastures; 0%
forest and woodland: 100%
other: 0%
Irrigated land: Osqkm','aafeee253ad60987fc5bfe402f407cabed8147437f353f3b72ee4d6123b793fa','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9cf606b134cf766858a90cb3ecdc12b43b60aad077c528fa643e463a6203bd3',1994,'NZ','New Zealand','geography',23,'Map references: Oceania
Area;
total area; I99sqkm
land area: 199 sq km
comparative area; slightly larger than
Washington. DC
note: includes Rose Island and Swains Island
Land boundaries: 0 km
Coastline: 1 16 km
Maritime claims:
contiguous zone; 24 nm
continentai shelf; 200-m depth or to depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
International disputes; none
Climate: tropical marine, moderated by
southeast trade winds; annual rainfall averages
1 24 inches; rainy season from November to
April, dry season from May to October; little
seasonal temperature variation
Terrain: five volcanic islands with nigged
peaks and limited coastal plains, two coral
atolls (Rose Island. Swains Island)
Natural resources: pumice, pumicite
Land use:
arable land: 10%
permanent crops: 5%
meadows and pastures: 0%
forest and woodland: 75%
other: 10%
Irrigated land: NA sq km
Location: Oceania, Polynesia, 2,250 km
north-northwest of New Zealand, about two-
thirds of the way between Hawaii and New
Zealand
Map rcfcrcAces: Oceania. Standard Time
Zones of the World
Area:
total area; 748 sq km
land area: 7 1 8 sq km
comparative area: slightly more than four
times the size of Washington, DC
Land boundaries: 0 km
CoastHne: 419 km
MarilteM dabns:
continental shelf: not specified
exclusive economic zone; 200 nm
territorial sea: 12 nm
Intemadoiml disputes: none
Climate: tropical; modified by trade winds;
warm season (December to May), cool season
(May to December)
Tcr^n: most islands have limestone base
formed from uplifted coral formation; others
have limestone overlying volcanic base
Natural resources: fish, fertile soil
Land use:
arable land: 25%
permanent crops: 55%
meadows and pastures: 6%
forest and woodland: 12%
other; 2%
Irrigated land: NAsqkm
Map references: Oceania, Standard Time
Zones of the World
Area:
total area: 2,860 .sq km
land area; 2.850 sq km
comparative area; slightly smaller than Rhode
Island
Land boundaries: 0 km
Coastline: 403 km
Maritime claims:
exclusive economic zone; 200 nm
territorial sea; 1 2 nm
International disputes: none
Climate: tropical: rainy season (October to
March), dry .season (May to October)
Terrain: narrow coastal plain with volcanic,
rocky, rugged mountains in interior
Natural resources: hardwood forests, fish
Land use:
arable land; 19%
permanent crops: 24%
meadows and pastures: 0%
forest and woodland: 41%
other: 10%
Irrigated land: NA .sq km
Map references: Standard Time Zones of the
World
Area:
total area: 5 10.072 million sq km
land area: 148.94 million sq km
water area: 361.132 million sq km
comparative area: land area about 1 6 times the
size of the US
note; 70.8% of the world is water, 29.2% is
land
Land boundaries: the land boundaries in the
world total 230,883.64 km (nut counting
shared boundaries twice)
Coastline: 336,000 km
Maritime claims:
contiguous zone: 24 nm claimed by most but
can vary
continental shelf: 200-m depth claimed by
most or to depth of exploitation, others claim
200 nm or to the edge of the continental margin
exclusive fishing zone: 200 nm claimed by
most but can vary
exclusive economic zone: 200 nm claimed by
most but can vary
territorial sea; 1 2 nm claimed by most but can
vary
note: boundary situations with neighboring
states prevent many countries from extending
their fishing or economic zones to a full 200
nm; 42 nations and other areas that are
landlocked include Afghanistan, Andorra,
Armenia, Austria, Azerbaijan, Belarus,
Bhutan, Bolivia, Botswana, Burkina, Burundi,
Central African Republic, Chad, Czech
Republic, Ethiopia, Holy See (Vatican City),
Hungary, Kazakhstan, Kyrgyzstan, Laos,
Lesotho, Liechtenstein, Luxembourg, Malawi,
Mali, Moldova, Mongolia, Nepal, Niger,
Paraguay, Rwanda, San Marino. Slovakia,
Swaziland, Switzerland, Tajikistan, The
Former Yugoslav Republic of Macedonia,
Turkmenistan, Uganda, Uzbekistan, West
Bank, Zambia, Zimbabwe
Climate: two large areas of polar climates
separated by two rather narrow temperate
zones from a wide equatorial band of tropical
to subtropical climates
Terrain: highest elevation is Mt. Everest at
8,848 meters and lowest depression is the Dead
Sea at 392 meters below sea level; greatest
ocean depth is the Marianas Trench at 10,924
meters
Natural resources: the rapid using up of
nonrenewable mineral resources, the depletion
of forest areas and wetlands, the extinction of
animal and plant species, and the deterioration
in air and water quality (especially in Eastern
Europe and the former USSR) pose serious
long-term problems that governments and
peoples are only beginning to address
Land use:
arable land; 10%
permanent crops; 1%
meadows and pastures: 24%
forest and woodland: 31%
other: 34%
Irrigated land: NAsqkm','2edf6acf129ecfa161385069cf7d6f231ff9aa06fa59b2e4fca097d933d470e3','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6f3b78229a0653faa866ed88530d4689fbff15c06e7ca116666e306a9f7741b',1994,'AD','Andorra','geography',29,'Location: Southwestern Europe, between
France and Spain
Map references: Eurc^. Standard Time
Zones of the World
Area:
total area: 4.50 sq km
land area: 4.50 sq km
comparative area: slightly more than 2.5 times
the size of Washington, DC
Land boundaries: total 125 km. France 60
km, Spain 65 km
Coastline; fl km (landlocked)
Maritime claims: none: landlocked
International disputes: none
Climate: temperate; snowy, cold winters and
cool, dry summers
Terrain; rugged mountains dissected by
narrow valleys
Natural resources: hydropower, mineral
water, timber, iron ore, lead
Land use:
arable land: 29f
permanent crops: 0%
meadows and pastures: 56%
forest and woinlland: 22%
other: 20%
Irrigated land: NA sq km','00cd760e55dd8e24dcbe1f27e5665caae579a5f0c0440670ff9f308eed45b8b8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22d4f4c7f5d61b1ff10de1144554d5c109d1c0983a3d30850e832f0f3d001566',1994,'AO','Angola','geography',36,'Location: Southern Africa, bordering the
South Atlantic Ocean between Namibia and
Zaire
Map references: Africa. Standard Time
Zones of the World
Area:
total area: 1,246,700 sq km
land area: 1,246,700 sq km
comparative area: slightly less than twice the
siie of Texas
Land boundaries: total 5.198 km. Congo 201
km, Namibia 1.376 km, Zaire 2,51 1 km,
Zambia 1.1 10 km
Coastline: 1,600 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 20 nm
International disputes: none
Climate: semiarid in south and along coast to
Luanda: north has cool, dry season (May to
October) and hot. rainy season (November to
April)
Terrain: narrow coastal plain rises abruptly to
vast interior plateau
Natural resources: petroleum, diamonds.
iron ore. phosphates, copper, feldspar, gold.
bauxite, uranium
Land i >:
arable land: 2%
permanent crops: 0%
meadows and pastures: 23%
forest and woodland: 43%
other: 32%
Irrigated land: NA sq km','02d9f4defbf1b725f213cf3e81837855eff3bb594ccf0b68c68037467071032d','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('809b9972ce9164a19be32ea30b338d5149da065596dc0f11e538a47d789b81c1',1994,'AI','Anguilla','geography',41,'Location: Caribbean, in the eastern Caribbean
Sea. about 270 km east of Puerto Rico
Map references: Central America and the
Caribbean
Arsa:
total area: 91 sqkm
land area: 91 sq km
comparative area: about half the size of
Washington. DC
Land bonndatlcs: 0 km
Coastline: 61 km
Maritime dahns:
eM ''''rsivefishiny zone: 200 nm
territorial sea: 3 nm
tatcrnailooal dlspntcs: none
CUmate: tropical; moderated by northeast
trade winds
Terrain: flat and low-lying island of coral and
lintestone
Natural resources: negligibi'';; salt, fish,
lobster
I ■it uae:
arable land: NA%
permanent crops: NA%
meadows and pastures: NA%
forest and woodland: NA%
other: NA% (mostly rock with sparse scrub
oak. few trees, some commercial salt ponds)
Irr%atcd land: NAsqkm','a10af062831a1592ce7781485fc73cfdde87c21f0c833c04c70a42371a12affe','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f59528644c5adbef9c5c1e822b0053decd80042227ce5eb19b57c8a01e8b4a1',1994,'AQ','Antarctica','geography',46,'Location: continent mostly south of the
Antarctic Circle
Map references; Antarctic Region
Area:
total area: 14 million sq km test.)
laiularea: 14 million sq km (est.)
coni/xiratiw area: slightly less than 1 .5 times
the size of the US
note: second-smallest continent (after
Australia)
Land boundaries: none, but see entry on
International disputes
Coastline: 17,968 km
Maritime claims: none, hut see entry on
International Disputes
International disputes: Antarctic Treaty
defers claims (see Antarctic Treaty Summary
below); sections (some overlapping) claimed
by Argentina. Australia. Chile, France (Adelie
Land), New Zealand (Ross Dependency),
Norway (Queen Maud Land), and UK: the US
and most other nations do not recognize the
territorial claims of other nations and have
made no claims themselves (the US reserves
the right to do so); no formal claims have been
made in the sector between 90 degrees west
and 1 50 degrees west
Climate: severe low temperatures vary with
latitude, elevation, and distance from the
ocean; East Antarctica is colder than West
Antarctica because of its higher elevation:
Antarctic Peninsula has the most moderate
climate; higher temperatures occur in January
along the coast and average slightly below
freezing
Terrain; about 98*^ thick continental ice
sheet and 2''^c barren rix:k. with average
elevations between 2.000 and 4.0(X) meters;
mountain ranges up to 4,897 meters high; ice-
free coastal areas include parts of southern
Victoria Land. Wilkes Land, the Antarctic
Peninsula area, and parts of Ross Island on
McMurdo Sound: glaciers form ice shelves
along about half of the coastline, and floating
ice shelves constitute 1 1''Jf of the area of the
continent
Natural resources: none presently exploited;
iron ore. chromium, copper, gold, nickel.
platinum and other minerals, and coal and
hydrocarbons have been found in small.
uncommercial quantities
Land use:
arable land: Olf
/tennaiienr crops: 0‘3f
nieadom ami pastures: O''!}-
forest and w mHiland: Olf
other: lOO*)! (ice 9851-. barren rock 2^)
Irrigated land: Osqkm
Climate: mostly temperate: arid in southeast;
subantarctic in southwest
Terrain; rich plains of the Pampas in northern
half, flat to rolling plateau of Patagonia in
south, rugged Andes along western border
Natural resources: fertile plains of the
pampas, lead, zinc. tin. copper, iron ore,
manganese, petroleum, uranium
Land use:
arable land: 9%
permanent crops: 4%
meadows and pastures: 52%
forest and woodland: 22%
other; 1.5%
Irrigated land: 1 7,600 sq km ( 1 989 est.)','8132b2fc7652619a415fa07d6987ce3205e3b06e37d22b24cbd38ed59d341dfa','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a399b96d0a6bb99b36a4019764dfa1c3295b493bd94bcd595abd63aac415691',1994,'AG','Antigua and Barbuda','geography',55,'Location; body of water mostly north of the
Arctic Circle
Map references: Arctic Region, Asia, North
America, Standard Time Zones of the World
Area:
total area: 14.056 million sq km
comparative area: slightly more than 1 .5 times
the size of the US; smallest of the world’s four
oceans (after Pacific Ocean, Atlantic Ocean,
and Indian Ocean)
note: include,s Baffin Bay, Barents Sea,
Beaufort Sea, Chukchi Sea, East Siberian Sea,
Greenland Sea, Hudson Bay, Hudson Strait,
Kara Sea, Laptev Sea, Northwest Passage, and
other tributary water bodies
Coastline: 45,389 km
Intemationai disputes: some maritime
disputes (see littoral states); Svalbard is the
focus of a maritime boundary dispute between
Norway and Russia
Climate: polar climate characterized by
persistent cold and relatively narrow annual
temperature ranges; winters characterized by
continuous darkness, cold and stable weather
conditions, and clear skies; summers
characterized by continuous daylight, damp
and foggy weather, and weak cyclones with
rain or snow
Terrain: central surface covered by a
perennial drifting polar icepack that averages
about 3 meters in thickness, although pressure
ridges may be three times that size; clockwise
drift pattern in the Beaufort Gyral Stream, but
nearly straight line movement from the New
Siberian Islands (Russia) to Denmark Strait
(between Greenland and Iceland); the ice pack
is surrounded by open seas during the summer,
but more than doubles in size during the winter
and extends to the encircling land masses; the
ocean floor is about 50% continental shelf
(highest percentage of any ocean) with the
remainder a central basin interrupted by three
submarine ridges (Alpha Cordillera, Nansen
Cordillera, and Lomonsov Ridge); maximum
depth is 4,665 meters in the Fram Basin
Natural resources: sand and gravel
aggregates, placer deposits, polymetallic
nodules, oil and gas fields, fish, marine
mammals (seals and whales)','9b8be3f5f14bc97af255a0a06f10d724dcfd57d8e064875364431cff55321386','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37f3b4bae5001a7e285a5f09309ed3a81170ac8a0b5cb6e1ac6dffe76b3507eb',1994,'AR','Argentina','geography',57,'Location; Southern South America,
bordering the South Atlantic Ocean between
Chile and Uruguay
Map references: South America, Standard
Time Zones of the World
Area:
total area: 2,766,890 sq km
land area: 2,756,690 sq km
comparative area: slightly less thr.n three-
tenths the size of the US
Land boundaries: total 9,665 km, Bolivia
832 km, Brazil 1 ,224 km. Chile 5. 1 50 km,
Paraguay 1 .880 km. Uruguay 579 km
Coastline: 4,989 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to depth of
exploitation
exclusive economic zone: not specified
territorial sea: 200 nm: overflight and
navigation permitted beyond 12 nm
International disputes: short section of the
boundary with Uruguay is in dispute: short
section of the boundary with Chile is
indefinite: claims British-administered
Falkland Islands (Islas Malvinas''^: claims
British-administered South Georgia and the
South Sandwich Islands: territorial claim in
Map references: Antarctic Region, South
America
Area:
total area: 12, 1 70 sq km
land area: 12,170 sq km
comparative area: slightly smaller than
Connecticut
note; includes the two main islands of East and
West Falkland and about 2(X) small islands
Land boundaries: 0 km
Coastline: 1,288 km
Maritime claims:
continental shelf: 100-m depth
exclusive fishing zone: 200 nm
territorial sea; 12 nm
International disputes: administered by the
UK, claimed by Argentina
Climate: cold marine; strong westerly winds,
cloudy, humid; rain occurs on more than half of
days in year; occasional snow all year, except
in January and February, but does not
accumulate
Terrain; rocky, hilly, mountainous with some
boggy, undulating plains
Natural resources: fish, wildlife
Land use:
arable land; 0%
permanent crops; 0%
meadows and pastures: 99%
forest and woodland: 0%
other; 1%
Irrigated land; NA sq km
Location: Caribbean, in the western North
Atlantic Ocean, 190 km north of the
Dominican Republic and southeast of The','035af62e748819fdd25fb36ffadc383a271e4ef3412df1b701b5a33db9a6fe32','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a4af350ee07d9add19e84113e637b919b71d489b56611bad37bc022d980bd01',1994,'AM','Armenia','geography',61,'Location; Southwestern As a. between
Turkey and Azerbaijan
Map references: Africa, Asia.
Commonwealth of Independent States —
European States, Middle East, Standard Time
Zones of the World
Area:
total area: 29,800 sq km
land area: 28.400 sq km
comparative area: slightly larger than
Maryland
Land boundaries: total 1. 2.^4 km. Azerbaijan
(cast) 566 km. Azerbaijan (south) 221 km.
Georgia 164 km. Iran .T5 km. Turkey 268 km
Coastline: 0 km (landlocked)
Maritime claims: none; landlocked
International disputes: violent and
longstanding dispute with Azerbaijan over
ethnically Armenian exclave of Nagorno-
Karabakh; traditional demands on former
Armenian lands in Turkey have greatly
subsided
Climate: highland continental, hot summers,
cold winters
Terrain: high Armenian Plateau with
mountains; little forest land; fast flowing
rivers; good soil in Aras River valley
Natural resources: small deposits of gold.
copper, molybdenum, zinc, alumina
Land use:
arable land: 1 79J-
pennanent crops: 3(?-
nieadows and iHistnres: 20%
forest and woodland: 0%
other: 60%
Irrigated land: .3,050 sq km ( 1990)','4fe072593dc5e103cc091e21b3d52febbafb688e1d399771dee671282462496d','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5cc92fafb75e4761e8a04af88c541790e2b5f7f182e5d7fbed173323d2d5ba2',1994,'AW','Aruba','geography',68,'Location; Caribbean, in the southern
Caribbean Sea, 28 km north of Venezuela and
1 25 km east of Colombia
Map references; Central America and the
Caribbean
Area;
total area: 193 sq km
land area: 1 93 sq km
comparative area: slightly larger than
Washington, DC
Land boundaries; 0 km
Coastline: 68.3 km
Maritime claims:
exclusive fishing zone: 1 2 nm
territorial sea: 1 2 nm
International disputes: none
Climate: tropical marine: little seasonal
temperature variation
Terrain: flat with a few hills; scant vegetation
Natural resources; negligible; white sandy
beaches
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Irrigated land: NA sq km','23b8321316a23642b287374938cc04d40b9e3ba6a1a9759369456d85605dafe7','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('364775f7803936a35fecaa57470a9bca29472dcd95a01602d0ef3ad5ce8554fb',1994,'NL','Netherlands','geography',73,'Location: Southeastern Asia, in the Indian
Ocean, 320 km off the northwest coast of
Australia, between Australia and Indonesia
Map references; Oceania, Southeast Asia
Area:
total area: 5 sq km
land area: 5 sq km
comparative area: about 8.5 times the size of
The Mall in Washington, DC
note: includes Ashmore Reef (West, Middle,
and East Islets) and Cartier Island
Land houndaries: 0 km
Coastline: 74.1 km
Maritime claims:
contiguous zone: 1 2 nm
continental .shelf: 200-m depth or to depth of
exploration
e.xclusive fishing zone: 2(X) nm
territorial .sea: 3 nm
International disputes: none
Climate: tropical
Terrain: low with sand and coral
Natural resources: Fish
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100% (all grass and sand)
Irrigated land: 0 sq km
Map references: Arctic Region. Europe.
Standard Time Zones of the World
Area:
total area: 30.510 sq km
land area: 30,230 sq km
comparative area: slightly larger than
Maryland
Land boundaries: total 1 .385 km. France
620 km, Germany 167 km, Luxembourg 148
kill. Netherlands 450 km
Coastline: 64 km
Maritime claims:
continental shelf: equidistant line with
neighbors
exclusive fishing zone: equidistant line with
neighbors (extends about 68 km from coast)
territorial sea: 1 2 nm
International disputes: none
Climate; temperate; mild winters, cool
summers; rainy, humid, cloudy
Terrain: flat coastal plains in nonhwesi,
central rolling hills, rugged mountains of
Ardennes Forest in southeast
Natural resources: coal, natural gas
Land use:
arable land: 24%
permanent crops: I %
meadows and pastures: 20%
forest and woodland: 2 1 %
other: 24%
Irrigated land: 10 sq km (1989 est.)
Location: Caribbean, two island groups—
Curacao and Bonaire in the southern Caribbean
Sea arc about 70 km north of Venezuela near
Aruba and the rest of the country is about 800
km to the northeast about one-third of the way
between Antigua and Barbuda and Puerto Rico
Map references: Central America and the
Caribbean
Area:
total urea: 960 s<) km
land area: 960 sq km
amifHiraiive area: slightly less than 5.5 times
the size of Washington. DC
note: includes Bonaire. Curacao. .Saba. Sint
Eustatius. and Sint Maarten (Dutch part of the
island of Saint Mailini
Land boundaries: 0 km
CoaatHne; .364 km
Maritime daims:
exclusive fishinp zone: 12 nm
territorial sea: 1 2 nm
International disputes: mme
Climate: tropical; ameliorated by nonheust
trade winds
Terrain: generally hilly, volcanic interiors
Natural resources: phosphates (Curacao
only), salt (Bonair; only)
Land use:
arable lami: 8‘‘/f
permanent crops: O^f
meadows and fHistiires: 0''3
forest and womllaiul: (Vi
other: 92‘i
Irrigated land: NAsqkm','5d0a4d8c6e33be2c4077f9e7f3368698ab81bd9e1d9e2e1713e7a79f6c89fd85','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f53d2a5830e4f5b87eb8d86afb70a97c7b1e09640c662e5b6af6e32a721903a3',1994,'AU','Australia','geography',80,'Location: body of water between the Western
Hemisphere and Europe/Africa
Map references: Africa, Antarctic Region,
Aictic Region, Central America and the
Caribbean, Europe, North America, South
America, Standanl Time Zones of the World
Area:
total area: 82.217 million sq km
comparative area: slightly less than nine times
the size of the US; second-largest of the
world’s four oceans (after the Pacific (Jcean,
but larger than Indian Ocean or Arctic Ocean)
note: includes Baltic Sea, Black Sea,
Caribbean Sea. Davis Strait. Denmark Strait,
Drake Passage, Gulf of Mexico, Mediterranean
Sea, North Sea, Norwegian Sea, Scotia Sea,
Weddell Sea. and other tributary water bodies
Coastline: 1 1 1,866 km
Intematianal disputes: some maritime
disputes (see littoral states)
''Climate: tropical cyclones (hurricanes)
''evelop off the coast of Africa near Cape
orde and move westward into the Caribbean
Sea: hurricanes can occur from May to
December, but are most frequent from August
to N ''.ember
Te-. in; surface usually covered with sea ice
in Labrador Sea, Denmark Sriait. and Baltic
''■ ''''em October to June; clockwise warm
wuicr gyre (broad, circular system of currents)
in the nonh Atlantic, counterclockwise warm
water gyre in the south Atlantic; the ocean floor
is dominated by the Mid-Atlantic Ridge, a
rugged north-south centerline for the entire
Atlantic basin; maximum depth is 8,605 meters
in the Puerto Rico Trench
Natural resources: oil and gas fields, fish,
marine mammals (seals and whales), sand and
gravel aggregates, placer deposits,
polymetallic nodules, precious stones
Location; Southwestern Oceania, between
Indonesia and New Zealand
Map references: Southeast Asia, Oceania.
Antarctic Region, Standard Time Zones of the
World
Area:
total area; 7,68(1.850 sq km
land area: 7,617,930 sq km
coniiKirative area: slightly smaller than the US
note; includes Macquarie Island
Land boundaries: 0 km
Coastline: 25.760 km
Maritime claims:
contiguous zone: 1 2 nni
continental shelf: 200-m depth or to depth of
exploitation
exclusive fishing zone; 200 nm
territorial sea: 1 2 nni
International disputes; territorial claim in
Antarctica (Australian Antarctic Territory)
Climate: generally arid to semiarid:
temperate in south and east; tropical in north
Terrain: mostly low plateau with deserts:
fertile plain in southeast
Natural resources: bauxite, coal, iron ore,
copper, tin, silver, uranium, nickel, tungsten,
mineral sands, lead, zinc, diamonds, natural
gas, petroleum
Land use:
arable land; 6%
permanent crops: 0%
meadows and pastures:
forest and woodland: 1 49''r
odter: 12%
Irrigated land: 1 8,800 sq km ( 1 989 est.)
Location: Southern Europe, an enclave of
Rome — central Italy
Map references: Europe
Area:
total area: 0.44 sq km
land area: 0.44 sq km
comparative area: about 0.7 times the size of
The Mall in Washington, DC
Land boundaries: total 3.2 km, Italy 3.2 kin
Coastline; 0 km (landlocked)
Maritime claims; none: landlocked
International disputes; none
Climate; temperate; mild, rainy winters
(September to mid-May) with hot. dry
summers (May to September)
Terrain: low hill
Natural resources: none
Land use:
arable land: Q%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Irrigated land; 0 sq km','2d0fb285c08f7b0dc032d0e436559771ac87a2fbcc397b6db7769d91aa188f16','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c40021b161618fd097dfb3cc49333b1fee788097bc2e22cb7cca987d40bb7abd',1994,'AT','Austria','geography',83,'Location: Central Europe, between Germany
and Hungary
Map refennces; Africa. Arctic Region.
Europe. Standard Time Zones of the World
Area:
lotiil area: 8.^.850 sq kill
land ami: 82,7.W sq km
comt>arotive ami: slightly smaller than Maine
Land boundaries: total 2.4% km. Czech
Republic .%2 km. Germany 784 km. Hungary
.166 km. Italy 4,10 km, Liechtenstein .17 km.
SlovakiaQl km, ,Slovenia 262 km, Switzerland
164 km
Coastline: 0 km (landkicked)
Maritime claims: none; landlocked
International disputes: none
Climate: temperate; continental, cloudy; cold
winters with frequent rain in lowlands and
snow in mountains; cwil summers with
occasional showers
Terrain; in the west and south mostly
mountains (Alps); along the eastern and
northern margins mostly flat or gently sloping
Natural resources: iron ore. pctroleunt.
timber, magnesite, aluminum, lead. coal.
lignite, copper, hydropower
Land uie:
arable land: 1 7"r
pennaneni crops: 1 9f
meadow s and pastures: 249r
foresi and wiHxllund: .199}-
other: 199f
Irrigated land: 40 sq km ( 1080)
F.ni ironment:
eiirrent issues: some forest degradation caused
by air and soil pollution; soil pollution results
from the use of agricultural chemicals; air
pollution results from emissions by coal- and
oil-fired power stations and industrial plants
natural hazards: NA
international agreements: party to — Air
Pollution, Air Pollution-Nitrogen Oxides. Air
Pollution-Sulphur. Antarctic Treaty. Climate
Change, Endangered Species. Environmental
Modification, Hazardous Wastes, NuclcarTest
Bun. Ozone Layer Protection. Ship Pollution.
Tropical Timber. Wetlands: signed, but not
ratified — Air Pollution-Volatile Organic
Compounds. Antarctic-Environmental
Protocol. Biodiversity, Law of the .Sea
Note: landlocked; strategic location at the
crossroads of central Europe with many easily
traversable Alpine passes and valleys: major
river is the Danube: population is concentrated
on eastern low lands because of steep slopes,
poor soils, and low temperatures elsewhere','964830ae930308f4f479d58f7d0512126c4cc680938147348f3474dc33c490d2','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5b11dd02b1a7d6ed435d484c343ea9fd1874e6f569a1819ed63262e0c563a06',1994,'AZ','Azerbaijan','geography',88,'Location; Southwestern Asia, between
Armenia and Turkmenistan, bordering the
Caspian Sea
Map references; Africa, Asia.
Commonwealth of Independent States —
Central Asian States, Commonwealth of
Independent States — European States. Middle
East, Standard Time Zones of the World
Area:
total area; 86,600 sq km
land area; 86. 1 00 sq km
vomparalive area; slightly larger than Maine
note; includes the Nakhichevan Autonomous
Republic and the Nagorno-Karabakh regions:
regions'' autonomy was abolished by
Azerbaijani Supreme Soviet on 26 November
1991
Land boundaries: total 2,013 km, Armenia
(west) 566 km, Armenia (southwest) 221 km,
Georgia 322 km. Iran (south) 432 km. Iran
(southwest) 179 km. Russia 284 km. Turkey 9
km
Coastline: 0 km (landlocked)
note; Azerbaijan borders the Caspian Sea (800
km, est.)
Maritime claims: NA
note; Azerbaijani claims in Caspian Sea
unknown; lO-nm fishing zone provided for in
1940 treaty regarding trade and navigation
between Soviet Union and Iran
International disputes: violent and
longstanding dispute with ethnic Armenians of
Nagorno-Karabakh over its status, lesser
dispute concerns Nakhichevan; some
Azerbaijanis desire absorption of and/or
unification with the ethnic Azeri portion of Iran
Climate: dry, semiiuid steppe
Terrain: large, flat Kur-Araz Lowland (much
of it below sea level) with Great Caucasus
Mountains to the north. Qarabag (Karabakh)
Upland in west; Baku lies on Abseron
(Apsheron) Peninsula that juts into Caspian
Sea
Natural resources: petroleum, natural gas,
iron ore. nonferrous metals, alumina
Land use:
arable land; 1 8%
permanent crops; 4%
meadows and pastures; 25%
forest and woodland; 0%
other; 53%
Irrigated land: 14,010 sq km (1990)
Location: Caribbean, in the western North
Atlantic Ocean, southeast of Florida and
northwest of Cuba
Map references: Central America and the
Caribbean, North America, Standard Time
Zones of the World
Area:
total area: 13,940 sq km
land area: 10,070 sq km
comparative area: slightly larger than
Connecticut
Land boundaries: 0 km
Coastline: 3.S42 km
Maritime claims:
continental shelf: 200-m depth or to depth of
exploitation
exclusive fishing zone: 200 nm
territorial sea: 3 nm
International disputes: none
Climate: tropical marine; moderated by warm
waters of Gulf Stream
Terrain: long, flat coral formations with
some low rounded hills
Natural resources: salt, aragonite, timber
Land use:
arable land: 1%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 32%
other: 67%
Irrigated land: NAsqkm','2e1490cb89b95b478f452f9861a641e316e5235f97a5e658ba452db54545a87a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('effa7ba29d3dbf57d07cbb8a1a45505824a5615c3963482ba6fc10e485a2d522',1994,'BH','Bahrain','geography',96,'31
Bahrain (continued)
Ozone Layer Protection; signed, but not
ratified — Biodiversity, Climate Change
Note: close to primary Middle Eastern
petroleum sources; strategic location in Persian
Gulf through which much of Western world’s
petroleum must transit to reach open ocean
Location: Oceania, Micronesia, in the North
Pacific Ocean, just north of the Equator, 2,575
km southwest of Honolulu, about halfway
between Hawaii and Australia
Map references: Oceania
Area:
total area: 1 .4 sq km
land area: 1 .4 sq km
comparative area: about 2.3 times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 4.8 km
Maritime claims;
contiguous zone: 12 nm
continental shelf: 200-m depth or to depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
International disputes; none
Climate: equatorial: scant rainfall, constant
wind, burning sun
Terrain; low, nearly level coral island
surrounded by a narrow fringing reef
Natural resources: guano (deposits worked
until 1891)
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland; 0%
other: 100%
Irrigated land: 0 sq km','ea48f878591a863a08b278699a3145ad100003569b3d6ea03a34b948a204014b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b992589a40f12a20d09197fac1621f1418f6a4c2daffd89e948829fdf96a372e',1994,'BD','Bangladesh','geography',99,'Location: Southern Asia, at the head of the
Bay of Bengal, almost completely surrounded
by India
Map references: Asia, Standard Time Zones
of the World
Area;
total area: 144,000 sq km
land area: 133.910 sq km
comparative area: slightly smaller than
Wisconsin
I^and boundaries: total 4,246 km. Burma
193 km. India 4,053 km
Coastline: 580 km
Maritime claims:
contiguous zone: 1 8 nm
continental shelf: up to outer limits of
continental margin
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
International disputes: a portion of the
boundary with India is in dispute: water-
sharing problems with upstream riparian India
over the Ganges
Climate: tropical; cool, dry winter (October
to March); hot, humid summer (March to
June): cool, rainy monsoon (June to October)
Terrain; mostly flat alluvial plain; hilly in
southeast
Natural resources: natural gas, arable land,
timber
Land use:
arable land: 6T/r
permanent crops: 2Vc
meadows and pastures: 4%
forest and woodland: 1 6%
other: 1 1%
Irrigated land; 27,380 sq km (1989)','c17ae87290d1cc0a2b9f12a752a9f89883c3dd0c8e0c1531e84a59546cad1b78','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65dd5a3b6b6951bfbdd53310fb20672b5749398267d449763f84c32d55d2950a',1994,'BB','Barbados','geography',105,'Location: Caribbean, in the extreme eastern
Caribbean Sea, about .^75 km northeast of
Venezuela
Map references: Central America and the
Caribbean, South America. Standard Time
Zones of the World
Area:
touil area: 430 sq km
land area: 430 sq km
comparative area: slightly less than 2.5 times
the size of Washington, DC
Land boundaries: 0 km
Coastline: 97 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
International disputes: none
Climate: tropical: rainy season (June to
October)
Terrain: relatively flat: rises gently to central
highland region
Natural resources: petroleum, fishing,
natural gas
Land use:
arable land: llVc
permanent crops: OVr
meadows and pastures: 9%
forest and woodland: 0%
other; 14%
Irrigated land: NA sq km
Location: Southern Africa, in the southern
Mozambique Channel about halfway between
Madagascar and Mozambique
Map references: Africa
Area:
total area: NA km2
land area: NA km2
comparative area: NA
Land boundaries: 0 km
Coastline: 35.2 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes; claimed by','501975d0cf49864f53bfa5b0a03aebf0467dcbe85a6386d2714245350b746259','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dab5c2bd8eb309e49ff7533ecc4ad336a7ef686cd88600c4af4c5778cd502cdf',1994,'MG','Madagascar','geography',110,'Climate: tropical
Terrain; a volcanic rock 2.4 meters high
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100% (all rock)
Irrigated land: Osqkm
Climate: tropical
Terrain: NA
Natural resources: negligible
Land use:
arable land: NA%
permanent crops: NA%
meadows and pastures: NA%
forest and woodland: NA%
other; NA% (heavily wooded)
Irrigated land: Osqkm
Location: Southern South America, in the
South Atlantic Ocean, off the southern coast of
Climate: tropical
Terrain: NA
Natural resources: guano, coconuts
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100% (all lush vegetation and coconut
palms)
Irrigated land: 0 sq km
Location: Balkan State, Southern Europe,
bordering the Mediterranean Sea between
Turkey and Bulgaria
Map references: Africa, Europe, Standard
Time Zones of the World
Area:
total area: 1 3 1 ,940 sq km
land area: 1 30,800 sq km
comparative area: slightly smaller than
Alabama
Land boundaries: total 1,210 km, Albania
282 km, Bulgaria 494 km, Turkey 206 km. The
Former Yugoslav Republic of Macedonia 228
km
Coastline: 1 3,676 km
Maritime claims;
continental shelf: 200-m depth or to depth of
exploitation
territorial sea: 6 nm, but Greece has
threatened to claim 12 nm
International disputes: air, continental shelf,
and territorial water disputes with Turkey in
Aegean Sea; Cyprus question; dispute with
The Former Yugoslav Republic of Macedonia
over name and symbol implying territorial
claim
Climate: temperate; mild, wet winters; hot,
dry summers
Terrain: mostly mountains with ranges
extendir^g into sea as peninsulas or chains of
islands
Natural resources: bauxite, lignite,
magnesite, petroleum, marble
Land use:
arable land: 23%
permanent crops: 8%
meadows and pastures: 40%
forest and woodland: 20%
other: 9%
Irrigated land: 1 1,900 sq km (1989 est.)
Climate: tropical
Terrain: NA
Natural resources: guano deposits and other
fertilizers
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 90%
other: 10%
Irrigated land: 0 sq km
Location: Central Asia, between Russia and
Uzbekistan, bordering on the Caspian Sea and
the Aral Sea
Map references: Asia, Commonwealth of
Independent States — Central Asian States,
Standard Time Zones of the World
Area:
total area: 2,717,300 sq km
land area: 2,569,800 sq km
comparative area: slightly less than four times
the size of Texas
Land boundaries: total 12,012 km, China
1,533 km, Kyrgyzstan 1,051 km, Russia 6,846
km, Turkmenistan 379 km, Uzbekistan 2,203
km
Coastline: 0 km
note; Kazakhstan borders the Aral Sea (1,015
km''^ and the Caspian Sea ( 1 ,894 km)
Maritime claims: landlocked, but borders
with Russia, Azerbaijan, and Turkmenistan in
the Caspian Sea are under negotiation at
present
International disputes: Russia may dispute
current de facto maritime border to midpoint of
Caspian Sea from shore
Climate: continental, cold winters and hot
summers, arid and semiand
Terrain: extends from the Volga to the Altai
Mountains and from the plains in western
Siberia to oasis and desert in Central Asia
Natural resources: major deposits of
petroleum, coal, iron ore, manganese, chrome
ore, nickel, cobalt, copper, molybdenum, lead,
zinc, bauxite, gold, uranium
Land use:
arable land; 1 5%
permanent crops: NEGL%
meadows and pastures: 57%
forest and woodland: 4%
other: 24%
Irrigated land: 23,080 sq km (1 990)
Location; Southern Africa, in the wes''ern
Indian Ocean, 430 km east of Mozambique
Map references: Africa, Standard Time
Zones of the World
Area:
total area: 587,040 sq km
land area: 581,540 sq km
comparative area: slightly less than twice the
size of Arizona
Land boundaries: 0 km
Coastline; 4,828 km
Maritime claims:
exclusive ectmomic zone: 200 nm
territorial sea: 1 2 nm
International disputes; claims Bassas da
India. Europa Island, Glorioso Islands, Juan de
Nova Island, and Tromelin Island (all
administered by France)
Climate; tropical along coast, temperate
inland, arid in south
Terrain: narrow coastal plain, high plateau
and mountains in center
Natural resources: graphite, chromite, coal.
bauxite, salt, quartz, tar sands, semiprecious
stones, mica, fish
Land use:
arable lauJ: 4%
permanent crops: I %
meadows and imslures: 58%
forest and woodland: 26%
other: 1 1 %
Irrigated land; 9.0(K) sq km (1989 cst.)
Map references: Africa. Standard Time
Zones of the World
Area:
tnuit ami: SOI ,590 sq km
land ami; 784,090 sq km
vomparaiive ami: slightly less than twice the
size of California
l.and boundaries: total 4,57 1 km, Malawi
I.. 569 km. South Africa 49 1 km, Swaziland
105 km. Tanzania 756 km. Zambia 419 km.
Zimbabwe 1.2.71 km
Coastline: 2.470 km
Maritime claims;
i’.\\clii.m''e economic :.<me; 200 nm
territorial sea: 1 2 nm
International disputes: none
Climate; tropical lu subtropical
Terrain; mostly coastal lowlands, uplands in
center, high plateaus in northwest, mountains
in west
Natural resources: coal, titanium
Land use:
arable land; 4%
pennanent civps: iWr
meadows and pastures: 56%
forest and woodland: 20%
other: 20%
Irrigated land: 1 , 1 50 sq km ( 1 989 est. )','a45e2555f85e5fc92112f35831f81e27888e61518511578e31b5f14b78ec5402','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70ed6d7f153abd7807fe8ef1cf0985187b4d9309117fc4eb1ff51881931e6046',1994,'BY','Belarus','geography',117,'Location: Eastern Europe, between Poland
and Russia
Map references; Asia. Commonwealth of
Independent States — European Stales, Europe,
Standard Time Zones of the World
Area:
total area; 207,600 sq km
land area; 207,600 sq km
comparative area; slightly smaller than
Kansas
Land boundaries: total 3.098 km, Latvia 1 4 1
km, Lithuania 502 km. Poland 605 km. Russia
959 km, Ukraine 891 km
Coastline: 0 km (landlocked)
Maritime claims; none; landlocked
International disputes; none
Climate: cold winters, cool and moist
summers: transitional between continental and
maritime
Terrain; generally flat and contains much
marshland
Natural resources: forest land, peal deposits
Land use;
arable land; 29%
permanent crops; 1%
meadows and pastures; 15%
forest and woodland; 0%
other; 55%
Irrigated land; 1.490 sq km (1990)','352f4b486da4e596a42cb1d07a0aca1f157ac448c81b3c732743fb6000addbde','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('816c4c535ec0a1a27e51127f0502afcde5f98109d1cc4b6c035bf6b00a3b785c',1994,'BJ','Benin','geography',128,'Location: Western Africa, bordering the
North Atlantic Ocean between Nigeria and','401261306019e5a7802cf698b175017db1e178d42a56bc29ef44d3fddfefc08e','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cec106fd8a8f654f38e7fa55c32ef2d04e39cbeb32cf2cf822d8646a56632fc5',1994,'TG','Togo','geography',129,'Map references; Africa, Standard Time
Zones of the World
Area:
total area: 1 1 2,620 sq km
land area: 1 10,620 sq km
comparative area: slightly smaller than
Pennsylvania
Land boundaries: total 1 ,989 km, Burkina
306 km, Niger 266 km, Nigeria 773 km, Togo
644 km
Coastline: 121 km
Maritime claims:
territorial sea: 200 nm
International disputes: none
Climate: tropical; hot, humid in south;
semiarid in north
Terrain; mostly flat to undulating plain; .some
hills and low mountains
Natural resources; small offshore oil
deposits, limestone, marble, timber
Land use:
arable land: 1 2%
permanent crops: 47i''
meadows and pastures: 4%
forest and woodland: 35%
other: 45%
Irrigated land: 60 sq km (1989 est.)
Intention: Western Africa, bordering the
North Atlantic Ocean beween Benin and','24ab551c09e7d89432e6e8416538b0392dceb932077a62de1de5f2d5a4f73adc','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb0e6e7f6ac48a442f15e4360cd18352874f2034ca0b5e2681eeb5f042bd0b6d',1994,'BM','Bermuda','geography',135,'Location; Nonhem Nonh America, in the
western North Atiantic Ocean, 1 ,050 km east
of North Carolina
Map references: Nonh America
Area:
total area: 50 sq km
land area: 50 sq km
comparative area: about 0.3 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 103 km
Maritime claims;
exclusive fisltinx zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate; subtropical: mild, humid; gales,
strong winds common in winter
Terrain; low hills separated by fertile
depressions
Natural resources; lime.stone. pleasant
climate fostering tourism
Land use;
arable land: 0%
permanent crops: C\\%
meadows and pastures: 0%
forest and woodland: 20%
other: 80%
Irrigated land; NA sq km','4342243783e04ce133a82121e9f805526f2ec4555e556e3f799b181fcb8126c7','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15158ccfce6356eba9adcfaaae0fc10bd2d322f8d82c1ca0ed5db8a988151ff3',1994,'BT','Bhutan','geography',143,'Location: Southern Asia, in the Himalayas,
between China and India
Map references: Asia. Standard Time Zones
of the World
Area:
total area: 47,000 sq km
land area; 47,000 sq km
comparative area: slightly more than half the
size of Indiana
Land boundaries: total 1,075 km, China 470
km, India 605 km
Coastline: 0 km (landlocked)
Maritime claims: none: landlocked
International disputes: none
Climate: varies; tropical in southern plains;
cool winters and hot summers in central
valleys; severe winters and cool summers in
Himalayas
Terrain: mostly mountainous with some
fertile valleys and savanna
Natural resources: timber, hydropower.
gypsum, calcium carbide
Land use:
arable land; 2%
permanent crops: 0%
meadows and pastures: 5%
forest and woodland: 70%
other: 23%
Irrigated land: 340 sq km (1989 est.)
Location: Central Sc -th America, between
Brazil and Chile
Map references; South America, Standard
Time Zones of the World
Area:
lotal area: 1,098,580 sq km
land area: 1,084,390 sq km
comparative area; slightly less than three
times the size of Montana
Land boundaries: U''tal 6,743 km, Argentina
832 km, Brazil 3,400 km, Chile 861 km,
Paraguay 750 km, Peru 900 km
Coastline: 0 km (landlocked)
Maritime claims: none; landlocked
International disputes: has wanted a
sovereign corridor to the South Pacific Ocean
since the Atacama area was lost to Chile in
1 884; dispute with Chile over Rio Lauca water
rights
Climate: varies with altitude; humid and
tropical to cold and semiarid
Terrain: rugged Andes Mountains with a
highland plateau (Altiplano), hills, lowland
plains of the Amazon Basin
Natural resources: tin, natural gas,
petroleum, zinc, tungsten, antimony, silver,
iron ore, lead, gold, timber
Land use:
arable land: 3%
permanent craps: 0%
meadows and pastures: 25%
forest and woodland: 52%
other: 20%
Irrigated land: 1 ,650 sq km (1989 est.)','fa3d7b1eae29a13558a6afe0b4b1afe5296c16592b39ac7e76f03ee877e5580a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca39a06b259a5c55b249bae0f87aa94edda58139da763d202446ccf7ab66457d',1994,'BA','Bosnia and Herzegovina','geography',147,'Location: Balkan Slate. Southeastern Europe,
on the Balkan Peninsula, between Croatia and
Serbia and Montenegro
Map references: Africa, Arctic Region.
Ethnic Groups in Eastern Europe, Europe,
Standard rime Zones of the World
Area:
total area: 5 1 ,2.t3 sq km
land area: .^1,2S3 sq km
eomparative area: slightly larger than
Tennessee
Land boundaries: total 1 .4.S9 km, Croatia
9.^2 km, Serbia and Montenegro f>21 km (312
km with Serbia; 21,3 km with Montenegro)
Coastline: 20 km
Maritime claims:
continental shelf: 200-m depth
exclasive economic zone: 12 nm
exclusive fishing zone: 12 nm
territorial sea: 1 2 nm
International disputes: as of May 1994,
members of the Bosnian Serb armed factions,
desirous of establishing a .separate state linked
with neighboring Serbia, occupied 70% of
Bosnia after having killed or driven out non-
Serb inhabitants; the Bosnian Croats, occupied
and declared an independent state in an
additional 10% of Bosnia in 1993, but in March
1 994, this faction and the Bosnian Government
settled their dispute and entered into a
bicommunal Federation: a Bosnian
Government army commander who opposes
the leadership of Bosnian President
IZETBEGOVIC is leading an insurrection in
the government-held enclave of Bihac
Climate: hot summers and cold winters: areas
of high elevation have short, cool summers and
long, severe winters; mild, rainy winters along
coast
Terrain; mountains and valleys
Natural resources: coal, iron, bauxite,
manganese, timber, wood products, copper,
chromium, lead, zinc
Land use:
arable land: 20%
pennanent crops: 2%
meadows and pastures: 25%
forest and woodland: 36%
other: 17%
Irrigated land: NA sq km','17a435c6285d171c0c679a8b067a39b1c69071180420e3c4495c26b8f88a6a50','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8122b5979036336489b4665c71f779d9093088189464eae07de0e28aeac6869c',1994,'BW','Botswana','geography',157,'Location: Southern Africa, in the South
Atlantic Ocean, 2,575 km south-southwest of
the Cape of Good Hope (Socth Africa)
Map references: Antarctic Region
Area:
loud area: 58 sq km
land area: 58 sq km
comparative area: about 0.3 times the size of
Washington. DC
Land boundaries: 0 km
Coastline: 29.6 km
Maritime claims:
territorial sea: 4 nm
International disputes: none
Climate: antarctic
Terrain: volcanic; maximum elevation about
800 meters; coast is mostly inaccessible
Natural resources; none
Land use:
arable land: O^r
permanent crops: 0%
nieadows and pastures: 09r
forest and woodland: 09}-
other: 100''%- (all ice)
Irrigated land; 0 sq km','ef719463a96d483ffca8c1cb27e009993e7ec0695b1052ddd8eefa2df9af5834','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17be1a0d1528e6f9c374f9c50253b23ac294b3348e773b40981624ed41a80d58',1994,'NO','Norway','geography',158,'Location: Eastern South America, bordering
the Atlantic Ocean
Map references; South America. Standard
Time Zones of the World
Area:
total area: 8.5 1 1 .965 sq km
land area: 8.456.5 10 sq km
comparative area: slightly smaller than the US
note: includes Arquipelago de Fernando de
Noronha. Atol das Rocas. llha da Trindade.
Ilhas Martin Vaz, and Penedos de Sao Pedro e
Sao Paulo
Land boundaries: total 14,691 km,
Argentina 1 .224 km. Bolivia 3,400 km.
Colombia 1 .643 km. French Guiana 673 km.
Guyana 1.119 km, Paraguay 1,290 km. Peru
1,560 km, Suriname 597 km, Uruguay 985 km,
Venezuela 2.200 km
Coastline: 7,491 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
international disputes: shon section of the
boundary with Paraguay, just west of Salto das
Sete Quedas (Guaira Falls) on the Rio Parana,
is in dispute; two short sections of boundary
with Uruguay are in dispute — Arroio
Invemada (Arroyo de la Invemada) area of the
Rio Quarai (Rio Cuareim) and the islands at the
confluence of the Rio Quarai and the Uruguay
River
Climate: mostly tropical, but temperate in
south
Terrain: mostly flat to rolling lowlands in
north; some plains, hills, mountains, and
narrow coastal belt
Natural resources: iron ore, manganese,
bauxite, nickel, uranium, phosphates, tin,
hydropower, gold, platinum, petroleum, timber
Land use:
arable land: 79?''
permanent crops: 19f
55
Brazil (continued)
meadows and pastures: 19%
forest and woodland; 67%
other; 6%
Irrigated land: 27,000 sq km (1989 est.)
Map references: Arctic Region, North
America, Standard Time Zones of the World
Area:
total area: 2.1 75,600 sq km
land area: 383,600 sq km (ice free)
comparative area: slightly more than three
times the size of Texas
Land boundaries: 0 km
Coastline: 44,087 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial .sea: 3 nm
International disputes: dispute betwen
Denmark and Norway over maritime boundary
in Arctic Ocean between Greenland and Jan
Mayen has been settled by the International
Court of Justice (ICJ)
Climate: arctic to subarctic; cool summers,
cold winters
Terrain: flat to gradually sloping icecap
covers all but a narrow, mountainous, barren,
rocky coast
Natural resources: zinc, lead, iron ore, coal,
molybdenum, cryolite, uranium, fish
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 1 %
forest and woodland: 0%
other: 99%
Irrigated land: NA sq km
Lodrtion: Nordic State, Northern Europe,
bordering the North Atlantic Ocean, west of','27ea10f1841cccfe47f635cbda21243ef26529ded11209f5e8b2ad087a2a71ea','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d87d571f66e3979dc51135b161beac415d77bcd1982addea87ef9be06eddb4fc',1994,'IO','British Indian Ocean Territory','geography',165,'Location: Southern Asia, in the Indian Ocean,
south of India about halfway between Africa
and Indonesia
Map references: Standard Time Zones of the
World
Area:
total area: 60 sq km
land area; 60 sq km
comparative area: about 0.3 times the size of
Washington. DC
note: includes the island of Diego Garcia
Land boundaries: 0 km
Coastline: 698 km
Maritime claims:
e.xcluiiive fislung zone; 200 nm
territorial sea: 3 nm
International disputes: the entire Chagos
Archipelago is claimed by Mauritius
Climate: tropical marine; hot. humid,
moderated by trade winds
Terrain; flat and low (up to 4 meters in
elevation)
Natural resources: coconuts, fish
Land use:
arable land: 09c
permanent crops: 0''’!-
meadows and pastures: 09r
forest and woodland: 0%
other: 100%
Irrigated land: 0 sq km
Location: Caribbean, in the eastern Caribbean
Sea, about 1 10 km east of Puerto Rico
Map references: Central America and the
Caribbean
Area:
total area: 150 sq km
land area; 1 50 sq km
comparative area: about 0.8 times the size of
Washington, DC
note: includes the island of Anegada
Land boundaries: 0 km
Coastline: 80 km
Maritime claims:
exclusive fishing zone; 200 nm
territorial sea: 3 nm
International disputes: none
Climate: subtropical; humid; temperatures
moderated by trade winds
Terrain: coral islands relatively flat; volcanic
islands steep, hilly
Natural resources: negligible
Land use:
arable land: 20%
permanent crops: 1%
meadows- and pastures; 33%
forest and woodland: 7%
other: 33%
Irrigated land: NA sq km
Location: Southeastern Asia, on the northern
coast of Borneo almost completely surrounded
by Malaysia
Map references: Asia. Oceania, Southeast
Asia, Standard Time Zones of the World
Area:
total area: 5.770 sq km
land area: 5,270 sq km
comparative area: slightly larger than
Delaware
Land boundaries: total 381 km, Malysia 381
km
Coastline: 161 km
Maritime claims;
exciusive fishing zone: 200 nm
terriwriai sea: 1 2 nm
International disputes: may wish to
purchase the Malaysian salient that divides the
country: all of the Spratly islands are claimed
by China, Taiwan, and Vietnam: parts of them
are claimed by Malaysia and the Philippines: in
1984, Brunei established an exclusive fishing
zone that encompasses Louisa Reef, but has
not publicly claimed the island
Climate: tropical: hot. humid, rainy
Terrain: flat coastal plain rises to mountains
in east; hilly lowland in west
Natural resources: petroleum, natural gas,
timber
Land use:
urahie land: 1 %
pc mument crops: 1%
meadows and pastures: 1
forest and woodland: 79%
other: \\S%
Irrigated land; lOsq km(l989est.)','231f2a7af662dcc4aaaa3993b03562ea6004222c13b743a268b03ae925cc29d5','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b408937a4f259a316bb843a17a53463c5e170191bd69141d16f8b61381b339b',1994,'BG','Bulgaria','geography',171,'Location: Balkan State, Southeastern Europe,
bordering the Black Sea, between Romania and
Turkey
Map references; Africa, Arctic Region.
Ethnic Groups in Eastern Europe, Europe,
Middle East. Standard Time Zones of the
World
Area:
total area: 1 1 0,9 1 0 sq km
lanJ area: 1 10.550 sq km
comparative area: slightly larger than
Tennessee
Land boundarie.s: total I. SOS km. Greece
494 km. The Former Yugoslav Republic of
Macedonia 148 km, Romania 608 km, Serbia
and Montenegro .518 km (all with Serbia).
Turkey 240 km
Coastline: .554 km
Maritime claims:
contiguoux zone: 24 nm
eM''lusive economic zone: 200 nm
territorial .sea: 12 nm
International disputes; none
Climate: temperate; cold, damp winters; hot,
dry summers
Terrain: mostly mountains with lowlands in
north and south
Natural resources: bauxite, copper, lead,
zinc, coal, timber, arable land
Land use:
arable land: 54''7r
permanent crops: y/c
meadows and pastures: IS''Jf''
forest and woodland: 55%
other: 10%
Irrigated land: 1 0 sq km ( 1 989 est.)
Location: Western Africa, between Ghana
and Mali
Map references: Africa, Standard Time
Zones of the World
,\\rea:
toial ami: 274,200 sq km
land ami: 273, 8(X) sq km
amiparativc ami: slightly larger than
Colorado
Land boundaries; total 3, 102 km, Benin 306
km. Ghana .348 km, Cote d''Ivoire 584 km.
Mali l.(XX) km. Niger 628 km. Togo 126 km
Coastline: 0 km (lundkKkedl
Maritime claims: none: lundkKked
International disputes; the disputed
international boundary between Burkina and
Mali was submitted to the International Court
of Justice (ICJ) in October 1983 and the ICJ
issued its final ruling in December 1 986. which
both sides agreed to accept; Burkina and Mali
are prix:eeding with boundary demarcation,
including the tripoint with Niger
Climate: tropical: warm, dry winters; hot, wet
summers
Terrain: mostly Hat to dissected, undulating
plains: hills in west and southeast
Natural resources: mang.incse. limestone.
marble: small deposits of gold, antimony.
copper, nickel, bauxite, lead, phosphates, zinc.
silvei
Land use:
arable land: lOfr
pennunent craps: Ofi
iitcadoa s and pastures: ^1%
fares! and waadland: 26'' f
allier: ll’r
Irrigated land; 160 sq km (1989 est.)
Knvironment:
eitrrent issues: recent droughts and
desertification severely affecting agricultural
activities, population distribution, and the
economy; overgrazing; soil degradation;
deforestation
natural hazards: recurring droughts
internatianal ufireements: party to —
Biodiversity, Climate Change. Endangered
Species. Marine Life Conservation. Ozone
Layer Protection, Wetlands: signed, but not
ratified — Law of the Sea. Nuclear Test Ban
Note: landlocked','27ecbc1cbf2aebb6a06bd362f6ce08eb47787adfe0c923f3916bf9682378c79b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fefa2fa38bd80f1b24b7f9be9d4f8cb720058f121dcb8c4459ec7f77a678f637',1994,'ET','Ethiopia','geography',177,'Location: Southeastern Asia, bordering the
Bay of Bengal, between Bangladesh and
Location: Eastern Africa, between Somalia
and Sudan
Map references: Africa, Standard Time
Zones of the World
Area:
total area: i , 1 2 7, 1 27 .sq km
land area: 1,11 9,683 sq km
comparative area: slightly less than twice the
size of Texas
Land boundaries: total 5,31 1 km, Djibouti
337 km, Eritrea 912 km, Kenya 830 km,
Somalia 1,626 km, Sudan 1,606 km
Coastline; 0 km (landlocked)
Maritime claims: none: landlocked
International disputes; southern half of the
boundary with Somalia is a Provisional
Administrative Line; territorial dispute with
Somalia over the Ogaden
Climate: tropical monsoon with wide
topographic-induced variation
Terrain: high plateau with central mountain
range divided by Great Rift Valley
Natural resources; small reserves of gold,
platinum, copper, potash
Land use:
arable land: 1 2%
permanent crops: 1%
meadows and pastures: 41%
forest and w oodland: 24%
other: 22%
Irrigated land; 1 .620 sq km ( 1 989 est.)
Location: Southern Africa, in the southern
Mozambique Channel about halfway between
Madagascar and Mozambique
Map references: Africa
Area:
total area: 28 sq km
land area: 28 sq km
comparative area: about 0.2 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 22.2 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
International disputes: claimed by','b2bf4ae013432ccfdccf7dc67378d5c083827d08404bc2c321601a996eb13a25','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('565db0fbb6b6daba6b7e4fb715f1a4071ba82308ce07340ef7039aafbdd89ef3',1994,'TH','Thailand','geography',178,'Map references: Asia, Southeast Asia,
Standard Time Zones of the World
Ar^a:
wu t • ■ 678,500 sq km
land a.ta; 657,740 sq km
comparative area; slightly smaller than Texas
Land boundaries: total 5,876 km,
Bangladesh 193 km, China 2,185 km, India
1,463 km, Laos 235 km. Thailand 1.800 km
Coastline: 1,930 km
Maritime claims:
contiguous zone; 24 nm
•itinental shelf: 200 nm or to the edge of
ler'' il Tiargin
• i:‘ omic zone; 200 nm
1 2 nm
Overview: One of the poorest countries in the
world, Burkina has a high population density,
few natural resources, and relatively infertile
soil. Economic development is hindered by a
poor communications network within a
landlocked country. Agriculture provides
about 40% of GDP and is entirely of a
subsistence nature. Industry, dominated by
unprofitable government-controlled
corporations, accounts for about 15% of GDP.
National product: GDP — purchasing power
equivalent-— $7 billion (1993 est.)
National product real growth rate: 0.7%
(1992)
National product per capita: $700(1993
est.)
Inflation rate (consumer prices): -0.8%
(1992)
Unemployment rate: NA%
Budget:
revenues; $483 million
expenditures; $548 million, including capital
expenditures of $189 million (1992)
Exports: $300 million (f.o.b., 1992)
commodities: cotton, gold, animal products
partners; EC 42%, Cote d’Ivoire 1 1%, Taiwan
15%,
Imports: $685 million (f.o.b., 1992)
commodities; machinery, food products,
petroleum
partners; EC 49%, Africa 24%, Japan 6%
External debt: $865 million (December 1991
est.)
Industrial production: growth rate 6.7%
(1992), accounts for about 15% of GDP
Electricity:
capacity; 120,0(X)kW
production; 320 million kWh
consumption per capita; 40 kWh (1991)
Industries: cotton lint, beverages,
agricultural processing, soap, cigarettes,
textiles, gold mining and extraction
Agriculture: accounts for about 40% of G DP;
cash crops — peanuts, shea nuts, sesame,
cotton: food crops — sorghum, millet, com,
rice; livestock; not self-sufficient in food
grains
Economic aid:
recipient; US commitnients, including Ex-lm
(FY70-89), $294 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $2.9 billion:
Communist countries (1970-89), $113 million
Currency: 1 CFA franc (CFAF) = 100
centimes
Exchange rates: CFA francs (CFAF) per
USSl— 592.05 (January 1994), 283.16(1993).
264.69 (1992). 282.1 1 (1991), 272.26 (1990),
319.01 (1989)
note: beginning 12 January 1994 the CFA
franc was devalued to CFAF 100 per French
franc from CFAF 50 at which it had been fixed
since 1948
Fiscal year: calendar year
111 .(..-autlriial disputes: none
Climate: tropical monsoon; cloudy, rainy,
hot, humid summers (southwest monsoon.
June to September); less cloudy, scant rainfall,
mild temperatures, lower humidity during
winter (northeast monsoon. December to
April)
Terrain; central lowlands ringed by steep,
rugged highlands
Natural resources: petroleum, timher, tin,
antimony, zinc, copper, tungsten, lead, coal,
some marble, limestone, precious stones,
natural gas
Land use:
arable land: 15%
permanent crops: 1%
meadows and pastures: 1%
forest and woodland: 49%
other; 34%
Irrigated land: 10,180 sq km (1989)
Location: Southeastern Asia, bordering the
Gulf of Thailand, between Burma and','cf42ad300970e990c62a784a8ef70385e6cf079101e1558060dc2dd909f47b47','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21bcc976569ced592dd31fc618d46cdd908c4b5ac3b9c5a9065def29349ff3ce',1994,'BI','Burundi','geography',187,'Location: Central Africa, between Tanzania
and Zaire
Map references; Africa, Standard Time
Zones of the World
Area:
total area; 27,830 sq km
land area; 25,650 sq km
comparative area; slightly larger than
Maryland
Land boundaries: total 974 km, Rwanda 290
km, Tanzania 451 km. Zaire 233 km
Coastline: 0 km (landlocked)
Maritime claims: none; landlocked
International disputes; none
Climate: temperate; warm; occasional frost in
uplands
Terrain; mostly rolling to hilly highland;
some plains
Natural resources: nickel, uranium, rare
earth oxide, peat, cobalt, copper, platinum (not
yet exploited), vanadium
Land use;
arable land; 43%
permanent crop.s; 8%
meadows and pttstures; 35%
forest and woodland; 2%
other; 12%
Irrigated land; 720 sq km (1989 est.)','497c88912bdf9bda4eccd73e26188164b319cac0fb886bc8eda0038463de320a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2cea40e7c0fd0ef2e2f7f24dd9a5ee0ff3e100c1a2b524d7bb6a72d62b9abe8',1994,'KH','Cambodia','geography',193,'Location: Southeastern Asia, bordering the
Gulf of Thailand, between Thailand and
Vietnam
Map references: Asia, Southeast Asia,
Standard Time Zones of the World
Area:
total area: 181 ,040 sq km
land area: 176,520 sq km
compare, five area: slightly smaller than
Oklahoma
Land boundaries: total 2,572 km, Laos 541
km, Thailand 803 km, Vietnam 1,228 km
Coastline: 443 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: offshore islands and
sections of the boundary with Vietnam are in
dispute; maritime boundary with Vietnam not
defined; parts of border with Thailand in
dispute; maritime boundary with Thailand not
clearly defined
Climate: tropical; rainy, monsoon season
(May to October); dry season (December to
March); little seasonal temperature variation
Terrain; mostly low, flat plains; mountains in
southwest and north
Natural resources: timber, gemstones, some
iron ore, manganese, phosphates, hydropower
potential
Land use:
arable land: 16%
permanent crops: 1%
meadows and pastures: 3%
forest and woodland: 76%
other: 4%
Irrigated land: 920sqkm(l989e.st.)
Map references: Asia, Southeast Asia,
Standard Time Zones of the World
Area:
total area; 5 14,000 sq km
land area: 51 1,770 sq kiii
comparative area; slightly more than twice the
size of Wyoming
Land boundaries: total 4,863 km, Burma
1,800 km, Cambodia 803 km, Laos 1,754 km,
Malaysia 506 km
Coastline: 3,219 km
Maritime claims:
exclusive economic zone; 200 nm
territorial sea; 12 nm
International disputes: boundary dispute
with Laos: unresoU ed maritime boundary with
Vietnam; parts of border with Thailand in
dispute; maritime boundary with Thailand not
clearly defined
Climate: tropical: rainy, warm, cloudy
southwest monsoon (mid-May to September);
dry, cool northeast monsoon (November to
mid-March); southern isthmus always hot and
humid
Terrain: central plain; Khorat plateau in the
east; mountains elsewhere
Natural resources: tin, rubber, natural gas,
tungsten, tantalum, timber, lead, fish, gypsum,
lignite, fluorite
Land use:
arable land; 34%
permanent crops: 4%
meadows and pastures; 1 %
forest and woodland; 30%
other; 3 1 %
Irrigated land: 42,300 sq km (1989 est.)
Location: Balkan State, Southeastern Europe,
between Serbia and Montenegro and Greece
Map references: Ethnic Groups in Eastern
Europe, Europe, Standard Time Zones of the
World
Area:
total area: 25.333 sq km
land area: 24,856 sq km
comparative area: slightly larger than
Vermont
Land boundaries: total 748 km, Albania 1 5 1
km. Bulgaria 148 km. Greece 228 km. Serbia
and Montenegro 221 km (all with Serbia)
Coastline; 0 km (landlocked)
Maritime claims: none; landlocked
International disputes; Greece claims
republic''s name implies territorial claims
against Aegean Macedonia
Climate: hot, dry summers and autumns and
relatively cold winters with heavy snowfall
Terrain: mountainous territory covered with
deep basins and valleys; there are three large
lakes, each divided by a frontier line
Natural resources: chromium, lead. zinc.
mangane.se, tungsten, nickel, low-grade iron
ore. asbestos, sulphur, timber
Land use:
arable land: 5%
permanent crops: 5%
meadows and pastures: 20%
forest and woodland: 30%
other: 40%
Irrigated land: NA sq km','8f01c81d00d07da59bdb688fcb683c94a15a77057f93fddb1de6dd08fccb2908','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8212b5bde38bc68229c9878e8bec30645d6314ca84ebb567c73e2eb05eff9a98',1994,'CM','Cameroon','geography',197,'Location: Western Africa, bordering the
North Atlantic Ocean between Equatorial
Guinea and Nigeria
Map references; Africa, ''''''tandard Time
Zones of the World
Area:
iDUil urea: 475.440 sq kin
land area: 469.440 sq kin
comparative area: slightly larger than
California
Land boundaries: total 4,591 km. Central
African Republic 797 km, Chad 1 ,094 km.
Congo 523 km. Equatorial Guinea 1 89 km,
Gabon 298 km, Nigeria 1,690 km
Coastline; 402 km
Maritime claims:
territorial sea: 50 nm
Intemationai disputes: demarcation of
iniemaiional boundaries in Lake Chad, the lack
of which has led to border incidents in the past,
is completed and awaiting ratification by
Cameroon, Chad, Niger, and Nigeria;
boundary commission, created with Nigeria to
discuss unresolved land and maritime
boundaries in the vicinity of the Bakasi
Peninsuiu, has not yet convened, but a
commission was formed in January 1994 to
study a flare-up of the dispute
Climate: varies with terrain from tropical
along coast to semiarid and hot in north
Terrain: diverse, with coastal plain in
southwest, dissected plateau in center,
mountains in west, plains in north
Natural resources; petroleum, bauxite, iron
ore, limber, hydropower ptitential
Land use;
arable land: 1 39f
permanent crops: IVr
meadows and pastures: 1 8%
forest and woodland: 549f''
other: I39f
Irrigated land: 280 sq km (1989 esi.)
Map references: Africa. Standard Time
Zones of the World
Area:
total area: 923,n0 sq km
land area: 910.770 sq km
comparative area: slightly more than twice the
siie of California
Land boundaries: total 4,047 km, Benin 773
km. Cameroon 1 ,690 km, Chad 87 km, Niger
1,497 km
Coastline: 853 km
Maritime claims:
continental shelf: 200-m depth or to depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 30 nm
International disputes: demarcation of
international boundaries in Lake Chad, the lack
of which has led to border incidents in the past,
is completed and awaiting ratification by
Cameroon. Chad, Niger, and Nigeria;
boundary commission, created with Cameroon
to discuss unresolved land and maritime
boundaries, has not yet convened, but a
commission was formed January 1 994 to study
a flare-up of the dispute
Climate: varies; equatorial in south, tropical
in center, arid in north
Terrain: southern lowlands merge into
central hills and plateaus; mountains in
southeast, plains in north
Natural resources: petroleum, tin.
columbite, iron ore, coal, limestone, lead, zinc.
natural gas
Land use:
arable land: 3 1 %
permanent crops: 3%
meadows and jxistures: 239f
forest and woodland: 1 59^
other: 28%
Irrigated land: 8.650 sq km (1989 est.)','436805e014d7aa4fdd21d831ee7935cafc364b064dcb9f4242fd1782088ca5bc','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d7578d9b665c20be246d703ec0bd0c02d97795d0117668fb8c755c2d3fe4735',1994,'CA','Canada','geography',207,'Location: Western Africa, in the southeastern
North Atlantic Ocean. 50() km west of Senegal
in Western Africa
Map references: Africa, Standard Time
Zones of the World
Area:
loitil ami: 4,030 sq km
land area: 4,030 sq kin
coinimrative area: slightly larger than Rhode
Island
Land boundaries: 0 km
Coastline; 965 km
Maritime claims: measured from claimed
archipelagic baselines
exclusive economic zone: 200 nm
leiriiorial sea: 1 2 nm
International disputes: none
Climate: temperate: warm. dry. summer.
precipitation very erratic
Terrain; steep, rugged, rocky, volcanic
Natural resources; salt, basalt rock.
po/zolana, limestone, kaolin. Osh
Land use:
arahle land: 9‘7c
permanent crops: 09r
meadows and pastures: bVc
forest and woodland: OT
other: 859f
Irrigated land; 20 sq km (1989 est.)','c8d029ecc0c55a4b6f0534b67bbad22a4709921c8c0c930f91a221c20666c21a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cecb1139bf4f0615a59de387bd8ac4b00a96c11a7041fab3de4a9b07e804bd15',1994,'KY','Cayman Islands','geography',211,'Location: Caribbean, in the northwestern
Caribbean Sea, nearly halfway between Cuba
and Honduras
Map references: Central America and the
Caribbean
Area:
total area: 260 sq km
land area: 260 sq km
comparative area: slightly less than 1 .5 times
the size of Washington, DC
Land boundaries: 0 km
Coastline; 160 km
Maritime claims:
exclusive fishing zone; 200 nm
territorial sea: 3 nm
International disputes: none
Climate: tropical marine; warm, rainy
summers (May to October) and cool, relatively
dry winters (November to April)
Terrain: low-lying limestone base
surrounded by coral reefs
Natural resources: fish, climate and beaches
that foster tourism
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 8%
forest and woodland: 23%
other; 69%
Irrigated land: NA sq km','1b552d3b95c4019cf0125bfd2811f9377dc832dbedd2fdb96a61a6208095b842','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ca7fb896f9fbe180973f94b4a01bfec3c1e4cc8708eac78c8cd2d5d8e57ffae',1994,'CF','Central African Republic','geography',215,'Location: Centrul Africa, between Chad and
Zaire
Map reference.s; Africa, Standard Time
Zones of the World
Area:
towl area: 622,980 sq km
land area: 622,980 sq km
comparative area; slightly smaller than Texas
Land boundaries: total 5,203 knt. Cameroon
797 km. Chad 1 . 197 km, Congo 467 km, Sudan
1,165 km. Zaire 1.577 km
Coastline: 0 km (landlocked)
Maritime claims: none; landlocked
International disputes: none
Climate: tropical; hot, dry winters; mild to
hot. wet summers
Terrain: vast. Hat to rolling, monotonous
plateau: scattered hills in northeast and
southwest
Natural resources: diamonds, uranium,
timber, gold, oil
Land use:
arable land:
permanent crops: O''/!
meadows and pastures: 5''jl-
forest and woodland: (A''i
other: 28''yb
Irrigated land: NA sq km','307076e2d2d6f2a6ffa357a2df3cf54dc1bdfa88c5aba8bc6d0df705b48520a6','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa008b7fbb5b99520aecb42254ab76236650d8605506990c7c3a4bb179ae5c53',1994,'NG','Nigeria','geography',223,'Climate: tropical in south, desert in north
Terrain: broad, arid plains in center, desert in
north, mountains in northwest, lowlands in
south
Natural resources; petroleum (unexploited
but exploration under way), uranium, natron,
kaolin, fish (Lake Chad)
Land use:
arable land; 2%
permanent crops: 0%
meadows and pastures: 36%
forest and woodland: 11%
other; 51%
Irrigated land; 100 sq km (1989 est.)
Location: Northern South America,
bordering the North Atlantic Ocean between
Suriname and Venezuela
Map references: South America, Standard
Time Zones of the World
Area:
totai area: 214,970 sq km
land area: 196,850 sq km
comparative area: slightly smaller than Idaho
Land boundaries: total 2,462 km, Brazil
1,119 km, Suriname 600 km, Venezuela 743
km
Coastline; 459 km
Maritime claims:
continental shelf: 2(X) nm or the outer edge of
continental margin
exclusive fishing zone: 200 nm
territorial sea: 1 2 nm
International disputes: all of the area west of
the Essequibo River claimed by Venezuela;
Suriname claims area between New (Upper
Couranty ne) and Courantyne/Kutari Rivers (all
headwaters of the Courantyne)
Climate: tropical; hut, humid, moderated by
northeast trade winds; two rainy seasons (May
to mid-August, mid-November to mid-
January)
Terrain: mostly rolling highlands; low
coastal plain; savanna in south
Natural resources; bauxite, gold, diamonds,
hardwood timber, .hrimp. fish
Land use;
arable land: 3%
permanent crops: 0%
meadows and pastures: 6%
forest and woodland: 83%
other: 8%
Irrigated land: 1 ,300 sq km ( 1989 est.)
Location: Western Africa, bordering the
North Atlantic Ocean between Benin and','54cc977260ed43f4d4f78784a58ad759c4ec484af1e19758b09a4d9e63ac7c72','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be974911c2dfbc1ced8bb05328136d7bda7ba6a476f1ac1fbae480310eb4a7c7',1994,'CL','Chile','geography',230,'Location: Southern South America,
bordering the South Pacific Ocean between
Argentina and Peru
Map references: South America. Standard
Time Zones of the World
Area:
total area: 756,950 sq km
land area: 748,800 sq km
comparative area: slightly smaller than twice
the size of Montana
note: includes Isla de Pascua (Easter Island)
and Isla Sala y Gomez
Land boundaries: total 6,171 km, Argentina
5.150 km. Bolivia 861 km, Peru 160 km
Coastline; 6,435 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm
e.\\clu.sive economic zone: 200 nm
territorial . tea: 12 nm
International disputes; short section of the
southern boundary with Argentina is
indefinite; Bolivia has wanted a sovereign
corridor to the South Pacific Ocean since the
Atacama area w.is lost to Chile in 1 884: dispute
with Bolivia over Rio Laiica water rights;
teaitoriul claim in Antarctica (Chilean
Antarctic Tenitory) partially overlaps
Argentine and British claims
Climate: temperate: de.sert in north; cool and
damp in south
Terrain; low coastal mountains; fertile
central valley; rugged Andes in east
Natural resources: copper, timoer, iron ore.
nitrates, precious metals, molybdenum
Land use:
arable land: 1%
permanent crops: Odf
meadows and pa.stures: 1 69(-
fore. St and woodland: 21%
olher: 56%
irrigated land; 12.650 sq km (1989 est.)','6834235d91b49d52ea66d4e135f7019da898b6a3b52844e0b53047dde26c8986','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cef0dcc8247426994f0e04404f8e330ebd8b62040e57ad12edaeaf02140d2304',1994,'MN','Mongolia','geography',235,'Map references: Asia, Southeast Asta,
Standard Time Zones of the World
Area:
total area: 9.596,960 sq km
land area: 9,326,4 10 sq km
comparative area: slightly larger than the US
Land boundaries: total 22.143.34 km,
Afghanistan 76 km, Bhutan 470 km, Burma
2, 1 85 km, Hong Kong 30 km, India 3.380 km.
Kazakhstan 1,533 km. North Korea 1,416 km,
Kyrgyzstan 858 km. Laos 423 km. Macau 0.34
km, Mongolia 4.673 km. Nepal 1 ,236 km,
Pakistan 523 km. Russia (northeast) 3,605 km,
Russia (northwest) 40 km, Tajikistan 414 km,
Vietnam 1,281 km
Coastline: 14.500 km
Maritime claims;
continental shelf: claim to shallow areas of
East China Sea and Yellow Sea
territorial .sea: 12 nm
International disputes; boundary with India:
bilateral negotiations are under way to resob
disputed sections of the boundary with Russia:
boundary with Tajikistan in dispute; a short
section of the boundary with North Korea is
indefinite; involved in a complex dispute over
the Spratly Islands with Malaysia. Philippines,
Taiwan. Vietnam, and possibly Brunei;
maritime boundary dispute with Vietnam in the
Gulf of Tonkin; Paracel Islands occupied by
China, but claimed by Vietnam and Taiwan;
claims Japanese-admini-stered Senkaku-shoto
(Senkaku Islands/Diaoyu Tail, as does Taiwan
Climate: extremely diverse; tropical in south
ic: subarctic in north
Terrain; mostly mountains, high plateaus,
deserts in west; plaircs. deltas, and hills in east
Naiural resources: coal, iron ore, petroleum,
mercury, tin, tungsten, antimony, manganese,
molybdenum. \\ .tnadium, magnetite,
aluminum, lead, zinc, uranium, hydropower
potential (world’s largest)
Land use;
arable land: 10%
permanent crops: 0%
meadows and pastures: 3 1 %
forest and woodland: 14%
other: 45%
Irrigated land: 478.220 sq km ( 1991 —
Chinese statistic)
Location: Northern Asia, between China and
Russia
Map references: Asia. Standard Time Zones
of the World
Area:
total area: 1.565 million sq km
land area: 1.565 million sq km
comparative area: slightly larger than Alaska
Land boundaries: total 8,1 14 km. China
4,673 km. Russia 3,441 km
Coastline: 0 km (landlocked)
Maritime claims: none: landlocked
International disputes: none
Climate: desert; continental (large daily and
seasonal temperature ranges)
Terrain: vast semidesert and desert plains:
mountains in west and southwest; Gobi Desert
in southea.st
Natural resources: oil, coal, copper,
molybdenum, tungsten, phosphates, tin. nickel,
zinc, wolfram, fluorspar, gold
Land use:
arable land: 1 %
permanent crops: 0%
meadows and pastures: 19%
forest and woodland: 10%
other: 10%
Irrigated land: 770 sq km (1989)','76ddc126c2d956092149088f68bb9ae8b8a3dc2358f5b521f8315fa67f9fef90','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2806cecf8c696a86be4c5edf3269d820dccf19a0057f7f08d2140d921df0b133',1994,'CX','Christmas Island','geography',242,'Location; Southeastern Asia, in the Indian
Ocean, between Australia and Indonesia
Map references: Southeast Asia
Area:
total area; 1 35 sq km
land area; 135 sq km
comparative area; about 0.8 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 138.9 km
Maritime claims;
contiguous zone; 12 nm
e.xclusive fishing zone; 200 nm
territorial sea; 3 nm
International disputes; none
Climate; tropical; heat and humidity
moderated by trade winds
Terrain: steep cliffs along coast rise abruptly
to central plateau
Natural resources: phosphate
Land use;
arable land; 0%
permanent crops; 0%
meadows and pastures; 0%
forest and woodland; 0%
other: 100%
Irrigated land: NA sq km
Location: Middle America, in the North
Pacific Ocean, 1 , 1 20 km southwest of Mexico
Map references: World
Area;
total area: 7 sq km
land area: 7 sq km
comparative area: about 12 times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: ii.lkm
Maritime claims;
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: claimed by Mexico
Climate: tropical
Terrain: coral atoll
Natural resources; none
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100% (all coral)
Irrigated land: Osqkm','240c205dd88cb94cb987cfb6a9fe62926339bc5c0c3b4416de4142e502ad86ae','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6bfb8af28a9fb4ed207d3b9c0e0b7b8675cbef5f9c46cfe28cd92a3729a12ea',1994,'CC','Cocos (Keeling) Islands','geography',251,'Location: Southeastern Asia, in the Indian
Ocean, 1 ,070 km southwest of Indonesia, about
halfway between Australia and Sri Lanka
Map references: Southeast Asia
Area:
total area: 14 sq km
land area: 14 sq km
comparative area: about 24 times the size of
The Mall in Washington, DC
note: includes the two main islands of West
Island and Home Island
Land boundaries: 0 km
Coastline: 2.6 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
International disputes: none
Climate: pleasant, modified by the southeast
trade wind for about nine months of the year;
moderate rain fall
Terrain; flat, low-lying coral atolls
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Irrigated land: NA sq km','d9b83b2dfbcbc6c25cc04d27bcb231219ec2efb31783849197fb555658241c62','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57cc3d3dbf07d4999136c31692357adffaa0bf53b6269be3bdcfca2573fcc853',1994,'CO','Colombia','geography',257,'Location: Northern South America, between
Panama and Venezuela
Map references: Central America and the
Caribbean, South America, Standard Time
Zones of the World
Area:
total area: 1 , 1 38,9 1 0 sq km
land area: 1 ,038,700 sq km
comparative area: slightly less than three
times the size of Montana
note: includes Islade Malpelo, RoncadorCay,
Serrana Bank, and Serranilla Bank
Land boundaries: total 7,408 km, Brazil
1 ,643 km, Ecuador 590 km, Panama 225 km,
Peru 2,9(X) km, Venezuela 2,050 km
Coastline: 3,208 km (Caribbean Sea 1,760
km. North Pacific Ocean 1 ,448 km)
Maritime claims:
continental shelf: not specified
e.sclusive economic zone: 200 nm
territorial .sea: 12 nm
International disputes: maritime boundary
dispute with Venezuela in the Gulf of
Venezuela; territorial dispute with Nicaragua
over Archipelago de San Andres y Providencia
and Quita Sueno Bank
Climate: tropical along coast and eastern
plains; cooler in highlands
Terrain: flat coastal lowlands, central
highlands, high Andes Mountains, eastern
lowland plains
Natural resources; petroleum, natural gas,
coal, iron ore, nickel, gold, copper, emeralds
Land use;
arable land: 4%
permanent crops: 2%
meadows and pastures: 29%
forest and woodland: 49%
other: 169b
Irrigated land: 5, 1 50 sq km ( 1 989 est.)','bb9227799134a1e53e3a106c4830711ad3941b7f1fc3a9d7e890c05763d6d42f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2728ecad7db45ba5d980971f15c5d9242b00a7d15750555d0d8f246e0ece479',1994,'KM','Comoros','geography',264,'Location: Southeastern Africa, in the extreme
northern Mozambique Channel, about two-
thirds of the way between northern
Madaga.scar and northern Mozambique
Map references: Africa. Standard Time
Zones of the World
Area:
total urea: 2. 1 70 sq km
land area: 2. 1 70 sq km
comparaiive area: slightly more than 12 times
the size of Washington. DC
Land boundaries: fikm
Coastline; .340 km
Maritime ciaims:
exclusive economic :tme: 200 nm
territorial .sea: 1 2 nm
international disputes: claims
French-administered Mayotte
Climate: tropical marine: rainy season
(November to May)
Terrain: volcanic islands, interiors vary from
steep mountains to low hills
Natural resources; negligible
Land use;
arable land: 35*3
permanent crops: 8*3
meadows and pa.slures: 753
forest and wruulland: 16*3
other: .34*3
Irrigated land: NAsqkm','05151806039c9768d63b2bf48c162cc333cad517f69a5476927140bc3568712a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9af6b0f0e60a17bac57ef8ea2c7ea6ec788e874d6d04bf58cbc4bef3448a904d',1994,'CK','Cook Islands','geography',274,'Location; Oceania. Polynesia, 4,SOO km
south of Hawaii in the South Pacific Ocean,
about halfway between Hawaii and New
Zealand
Map references: Oceania
Area:
total area: 240 .sq km
land area: 240 sq km
amtparaiive area: slightly less than 1 ,3 timt''s
the size of Washington. DC
Land boundaries: 0 km
Coasdinc: 120 km
Maritinw claims:
etmtinenial shelf: 200 nm or the edge of
continental margin
exclusive economic :one: 200 nm
terriioriai sea: 1 2 nm
International disputes; none
Climate: tropical; moderated by trade winds
Terrain: low coral atolls in nonh: volcanic.
hilly islands in south
Natural resources: negligible
Land use;
anihle land: 4%
permanent crops: 22%
meadows and pastures: 0^
forest and woodland: 0%
other: 74%
Irrigated land; NA sq km
Location: Southwestern Oceania, just off the
northeast coast of Australia in the (Toral Sea
Map references: Oceania
Area:
total area; less than 3 sq km
land area; less than 3 sq km
comparative area; NA
note: includes numerous small islands and
reefs scattered over a sea area of about I
million sq km, with Willis Islets the most
important
liSnd boundaries: 0 km
Coastline: 3,095 km
Maritime claims:
e.xclusivi fishing zone; 200 nm
territorial sea; 3 nm
International disputes: none
Climate; tropical
Terrain: sand and coral reefs and islands (or
cays)
Natural resources; negligible
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other; 100% (mostly grass or scrub cover)
Irrigated land: Osqkm','085d6ebe043df23aa80a1e0128c0adbd7e0ce0626dc783a3a27ff12b03d49d02','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d29ef3a590dd99aa28bc914d43991fc34d1a948395a9d1dd5f8b509652efac69',1994,'CR','Costa Rica','geography',279,'Location; Middle America, between
Nicaragua and Panama
Map references: Central America and the
Caribbean. South America
Area:
tdtal oreo.- 5 1 . 1 00 sq km
/and area: 50,660 sq km
comparative area: slightly smaller than West
Virginia
note: includes Isla del Coco
Land boundaries: total 6.^9 km. Nicaragua
.^09 km. Panama .^.^0 km
Coastline: 1.290 km
Maritime claims;
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
International disputes: none
Climate; tropical; dry season (December to
April): rainy season (May to November)
Terrain: coastal plains separated by rugged
mountains
Natural resources: hydropower potential
Land use:
arable land: b**-
permanent crops: 1%
meadons and pastures: 459(’
forest and woodland: 34%
other: 8%
Irrigated land: 1.180 sq km ( 1989 est.)
Location; Western Africa, bordering the
North Atlantic Ocean between Ghana and
Lilieria
Map references: Africa. Standard Time
Zones of the World
Area:
total area: 322,460 sq km
land area: 3 1 8,000 sq km
anniHirative area: slightly larger than New
Mexitxx
Land boundaries: total 3,1 10 km. Burkina
584 km. Ghana 668 km. Guinea 610 km.
Liberia 716 km. Mali 532 km
Coastline: 515 km
Maritime claims;
continental shelf: 20O-m depth
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
International disputes: none
Climate: tropical along coast, semiarid in far
north; three seasons — warm and dry
(November to March), hot and dry (March to
May), hot and wet (June to October)
Terrain; mostly flat to undulating plains;
mountains in northwest
Natural resources; petroleum, diamonds,
manganese, iron ore, cofalt. bauxite, copper
Land use;
arable land: 9'';?-
permanent crops: 4''3-
meadows and pastures: 99?-
forest and womlland: 26''''''i''
other; 52'';?-
Irrigated land: 620 sq km (1989 est.)','18f6c5c33ab43804795b3c8f7f57bb2f108a40d5afce5578be9d745c7ef3cb8f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e2bb1d5510c553e4d0cfed7833cc9ea30ea9d921c84832336750ff3be5a0f1d',1994,'HR','Croatia','geography',287,'Location: Balkan State, Southeastern Europe,
on the Balkan Peninsula, bordering the
Adriatic Sea. between Slovenia and Bosnia and
Herzegovina
Map references: Africa, Ethnic Groups in
Eastern Europe, Europe, Standard Time Z^nes
of the World
Area:
total area: 56,538 sq km
land area: 56,410 sq km
comparative area: slightly smaller than West
Virginia
Land boundaries: total 2,028 km, Bosnia
and Herzegovina 932 km, Hungary 329 km,
Serbia and Montenegro 266 km (241 km with
Serbia; 25 km with Montenego), Slo''''enia 501
km
Coastline; 5,790 km (mainland 1,778 km,
islands 4,012 km)
Maritime claims:
continental shelf: 200-m depth or to depth of
exploitation
exclusive economic zone: 12 nm
exclusive fishing zone: 1 2 nm
territorial sea: 1 2 nm
International disputes: Serbs have occupied
UN protected areas in eastern Croatia and
along the western Bosnia and Herzegovinian
border; dispute with Slovenia over fishing
rights in Adriatic
Climate: Mediterranean and continental;
continental climate predominant with hot
summers and cold winters; mild winters, dry
summers along coast
Terrain: geographically diverse; flat plains
along Hungarian border, low mountains and
highlands near Adriatic coast, coastline, and
islands
Natural resources: oil, some coal, bauxite,
low-grade iron ire, calcium, natural asphalt,
silica, mica, clays, salt
Land use:
arable land: 32%
permanent crops: 20%
meadows and pastures: 1 8%
99
Croatia (continued)
forest and woodland: 15%
other: 15%
Irrigated land; NA sq km','c604a84bfd26750e7ffc8af082e5256e96d5cba51d7a793a471f58590ff97ae9','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87a259d2b1f505887c64f54452601377869736bd9334e1e4776b855c5a4d043f',1994,'CU','Cuba','geography',292,'Location: Caribbean, in the northern
Caribbean Sea, 145 km south of Key West
(Florida)
Map references: Central America and the
Caribbean, North America. Standard Time
Zones of the World
Area:
total area: 1 10,860 sq km
land area: 1 10,860 sq km
comparative area: slightly smaller than
Pennsylvania
Land boundaries: total 29 km. US Naval
Base at Guantanamo Bay 29 km
note: Guantanamo is lea.sed and as such
remains part of Cuba
Coastline; 3,735 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes; US Naval Base at
Guantanamo Bay is leased to US and only
mutual agreemeni or US abandonment of the
area can terminr.e the lease
Climate: bopical; moderated by trade winds;
dry season (November to April); rainy season
(May to October)
Terrain: mostly flat to rolling plains with
rugged hills and mountains in the southeast
Natural resources: cobalt, nickel, iron ore,
copper, manganese, salt, timber, silica,
petroleum
Land use:
arable land: 23%
permanent crops: 6%
meadows and pastures: 23%
forest and woodland: 17%
other; 3 1 %
Irrigated land: 8,960 sq km ( 1989)','731820d3511f25973d64113da1a1aea6c62e9a25cd62d8617c7632867773b227','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e05c4109101e82fae76b0cb0e020898fd729da34ce099081c4cc98e5c58b4702',1994,'CY','Cyprus','geography',298,'Location: Middle East, in the eastern
Mediterreanean Sea, 97 km west of Syria and
64 km west of Turkey
Map references: Africa, Middle East,
Standard Time Zones of the World
Area:
total area: 9,250 sq km
land area: 9,240 sq km
comparative area: about 0.7 times the size of
Connecticut
Land boundaries: 0 km
Coastline: 648 km
Marilinic claims:
continental shelf: 200-m depth or to depth of
exploitation
territorial sea: 12 nm
International disputes: 1974 hostilities
divided the island into two de facto
autonomous areas, a Greek area controlled by
the Cypriot Government (60% of the island''s
land area) and a Turkish-Cypriot area (35% of
the island), that are separated by a narrow UN
buffer zone; in addition, there are two UK
sovereign base areas (about 5% of the island''s
land area)
Climate: temperate, Mediterranean with hot,
dry summers and cool, wet winters
Terrain: central plain with mountains to north
and south
Natural resources: copper, pyrites, asbestos,
gypsum, timber, salt, ma^le, clay earth
pigment
Land use:
arable land: 40%
permanent crops: 7%
meadows and pastures: 10%
forest and woodland: 1 8%
other: 25%
Irrigated land: 350 sq km (1989)
Locotioii: Central Europe, between Germany
and Slovakia
Map references: Ethnic Groups in Eastern
Europe. Europe. Standard Time Zones of the
World
Area:
total area: 78. 70.^ sq km
land area: 78,645 sq km
comparative area: slightly smaller than South
Carolina
Land boundaries: total 1 ,880 km. Austria
.^62 km, Germany 646 km, Poland 658 km.
Slovakia 214 km
Coastline: 0 km (landlocked)
Maritime claims; none; landlocked
International disputes: Liechtenstein claims
1 .606 sq km of Czech territory confiscated
from its royal family in 191 8; Sudeten German
claims for restitution of property confiscated in
connection with their expulsion after World
War II versus the Czech Republic claims that
restitution does not proceed before February
1948 when the Communists seized power;
unresolved property is.sues with Slovakia over
redistribution of property of the former
Czechoslovak federal government
Cllnute: temperate; cool summers; cold,
cloudy, humid winters
Terrain: two main regions: Bohemia in the
west, consisting of rolling plains, hills, and
plateaus surrounded by low mountains; and
Moravia in the east, consisting of very hilly
country
Natural resources: hard coal, soft coal,
kaolin, clay, graphite
Land use:
arable land: NA%
permanent crops: NA%
meadows and pastures:
forest and woodland: NA*)!-
other: NA%
Irrigated iand: NA sq km','5883ea76382f0b99cfd18a824eed417af7e6e699622400c3daa2b28b6dd2bcee','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d85d876a3837bf69ab15461c9fbb878cb392808a40572d6e444d7314742ef0b',1994,'DJ','Djibouti','geography',311,'Location: Eastern Africa, at the entrance to
the Red Sea between Eritrea and Somalia
Mcp references: Africa, Middle East,
Standard Time Zones of the World
Area:
toial area: 22,000 sq km
land area: 2 1 ,980 sq km
comiwative area: slightly larger than
Massachusetts
Land boundaries: total .S08 km, Eritrea 1 13
km, Ethiopia 337 km, Somalia 58 km
Coastline: 314 km
Maritime ciairos:
vontisHous zone: 24 nm
e.xclusiw economic zone: 200 nm
territorial xea: 1 2 nm
international disputes: none
Ciimate: desert: torrid, dry
Terrain: coastal plain and plateau separated
by central mountains
Natural resources: geothermal areas
Land use:
artihle land: OCj-
permanent crops: 0%
meadows and pastures: 9%
forest and woodland: 0%
other:
Irrigated land: NA sq km
Location: Central Africa, between Congo and','ad39060aff4b99f57865a9b2eb1255940aee9d3fb496212fd530d90630c312cf','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b08cefc35fbbd91f7cd89a77d5ebc71da01e63fb790c402aa5d6a22e7c3f21cf',1994,'DO','Dominican Republic','geography',324,'Location; Caribbean, in the northern
Caribbean Sea. about halfway between Cuba
and Puerto Rico
Map references: Central America and the
Caribbean, Standard Time Zones of the World
Area:
total area: 48,730 .sq km
land area: 48,380 sq km
comparative area: slightly more than twice the
size of New Hampshire
Land boundaries: total 215 km. Haiti 275 km
Coastline; 1,288 km
Maritime claims:
contiituous zone: 24 nm
continental shelf: 200 nm or the outer edge of
continental margin
exclusive economic zone: 200 nm
territorial sea: 6 nm
International disputes: none
Climate: tropical maritime; little seasonal
temperature variation; seasonal variation in
rainfall
Terrain: rugged highlands and mountains
with fertile valleys interspersed
Natural resources: nickel, bauxite, gold.
silver
Land use:
arable land: 23%
permanent crops: 1%
meadows and pastures: 43%
forest and woodland: 13%
other: 14%
Irrigated land: 2,250 sq km (1989)','e04029aa93479d78e14b2b33177b4379bf037ba2fb422dba2cf798945f0d5564','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('adb55341a1a5ddba8cae58678004c3788e4ac2820990518da4c0d93df0b12738',1994,'EC','Ecuador','geography',329,'Location: Western South America, .^ordering
the Pacific Ocean at the Equator between
Colombia and Peru
Map references: South America, Standard
Time Zones of the World
Area:
total area: 283, .S60 sq km
land area: 276,840 sq km
comparative area: slightly smaller than
Nevada
note: includes Galapagos Islands
Land boundaries: total 2.010 km, Colombia
590 km. Peru 1 ,420 km
Coastline: 2,237 km
Maritime claims:
continental shelf; claims continental shelf
between mainland and Galapagos Islands
lerriiorial sea: 200 nm
International disputes: three sections of the
boundary with Peru are in dispute
Climate: tropical along coast becoming
cooler inland
Terrain: coastal plain (costa), intcr-Andean
central highlands (sierra), and flat to rolling
eastern jungle (oriente)
Natural resources: petroleum, fish, timber
Land use:
arable land: 69)
permanent crops: 39)
meadows and pastures; 17%
forest and woodland: 5 1 %
other: 239)
Irrigated land: 5.500 sq km (1989 est.)
312
Note: shares control of Lago Titicaca, world''s
highest navigable lake, with Bolivia','7811e1bc1fafbc71e02a1bdc6a8960924d5c3be3c83b7beb0a1ca11928fa0860','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0826a4ba508745c89bc33eb4c7419ff27fc2b39fb7962ab9fed253b4c8fef09f',1994,'EG','Egypt','geography',336,'Location: Northern Africa, bordering the
Mediterranean Sea and the Red Sea, between
Sudan and Libya
Map references: Africa, Middle East,
Standard Time Zones of the World
Area:
total area: 1 ,00 1 ,450 sq km
land area: 995,450 sq km
comparative area: slightly more than three
times the size of New Mexico
Land boundaries: total 2,689 km. Gaza Strip
1 1 km, Israel 255 km, Libya 1,150 km, Sudan
1.273 km
Coastline: 2,450 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to depth of
exploitation
exclusive economic zone: not specified
territorial sea: 1 2 nm
International disputes: administrative
boundary with Sudan does not coincide with
international boundary creating the "Hala''ib
Triangle," a barren area of 20,580 sq km; the
dispute over this area escalated in 1993, this
area continues to be in dispute
Climate: desert: hot, dry summers with
moderate winters
Terrain: vast desert plateau interrupted by
Nile valley and delta
Natural resources: petroleum, natural gas,
iron ore, phosphates, manganese, limestone,
gypsum, talc, asbestos, lead, zinc
Land use:
arable land: i%
permanent crops: 2%
meadows and pastures: 0%
forest and woodland: 0%
other: 95%
Irrigated land: 25,850 sq km (1989 esi.)','f1949db0310b7b48c668202ac1f10304418024189c171312e718e5565a242e5c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e28a4429a5b320c5c8bcc9113d8a2282bbb1d81a861ac73217c4802d74964e16',1994,'SV','El Salvador','geography',342,'Location: Middle America, bordering the
North Pacific Ocean between Guatemala and','27acd8e2c5fcce21395797fede4107ab98fa7b3d09af4d7ad6d8004ba611fa29','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58c5b26f7093d1bfe9d5d1e033568203dcaa0cb6c3193d6bfbc3b93207e283b0',1994,'HN','Honduras','geography',343,'Map references: Central America and the
Caribbean, North America, Standard Time
Zones of the World
Area:
total area; 21,040 sq km
land area; 20,720 sq km
comparative area; slightly smaller than
Massachusetts
Land boundaries: total 545 km, Guatemala
203 km, Honduras 342 km
Coastline: 307 km
Maritime claims:
territorial sea; 200 nm; overflight and
navigation permitted beyond 1 2 nm
International disputes; land boundary
dispute with Honduras mostly resolved by 1 1
September 1992 International Court of Justice
(ICJ) decision: ICJ referred the maritime
boundary in the Golfo de Fonseca to an earlier
agreement in this century and advised that
some tripartite resolution among El Salvador,
Honduras and Nicaragua likely would be
required
Climate; tropical; rainy season (May to
October); dry season (November to April)
Terrain: mostly mountains with narrow
coastal belt and central plateau
Natural resources; hydropower, geothermal
power, petroleum
Land use:
arable land; 27%
permanent crops; 8%
meadows and pastures; 29%
forest and woodland; 6%
other; 30%
Irrigated land: 1 .200 sq km ( 1 989)
Location; Middle America, between
Guatemala and Nicaragua
Map references: Central America and the
Caribbean, North America, Standard Time
Zones of the World
Area:
total area: 1 1 2,090 sq km
land area: 1 1 1 .890 sq km
comparative area; slightly larger than
Tennessee
Land boundaries: total 1.520 km. Guatemala
256 km. El Salvador 342 km. Nicaragua 922
km
Coastline; 820 km
Maritime claims:
contiguous zone: 24 nm
continental shelf; 200-m depth or to depth of
exploitation
exclusive economic zone; 2(X) nm
territorial sea; 1 2 nm
International disputes: land boundary
dispute with El Salvador mostly resolved by 1 1
September 1992 International Court of Justice
(ICJ) decision; ICJ referred the maritime
boundary in the Golfo de Fonseca to an earlier
agreement in this century and advised that
some tripartite resolution among El Salvador.
Honduras and Nicaragua likely would be
required
Climate: subtropical in lowlands, temperate
in mountains
Terrain: mostly mountains in interior, naaow
coastal plains
Natural resources: timber, gold, silver,
copper, lead, zinc, iron ore. antimony, coal,
fish
Land use:
arable land; 14%
permanent crops; 2%
meadows and [xistures: .5t)%
forest and woodland: 34%
other: 20%
Irrigated land: 9(X) sq km 1 1989 est.)','3cf5d28df2957a355736cb71adc43aefb0e03be0b8bb2b8ec3517d8a2548d9b8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7be6267328ce4f1ac730d6ed90103d436bb991557c3c603ad0baaa53a98dfaee',1994,'GQ','Equatorial Guinea','geography',350,'Location: Western Africa, bordering the
N.vrth Atlantic Ocean between Cameroon and
Gaoon
Map references: Africa, Standard Time
Zones of the World
Area:
total area: 28.050 sq km
land area: 28,050 sq km
comparative area: slightly larger than
Maryland
Land boundaries: total 539 km. Cameroon
1 89 km, Gabon 350 km
Coastline: 296 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: maritime boundary
dispute with Gabon because of disputed
sovereignty over islands in Corisco Bay
Climate; tropical; always hot. humid
Terrain; coastal plains rise to interior hills;
islands are volcanic
Natural resources; timber, petroleum, small
unexploited deposits of gold, manganese.
uranium
Land use:
arable land: 8%
permanent craps: 4%
meadows and pastures: 4%
forest and woodland: 5 1 %
other: 33%
Irrigated land: NA sq km','c9ac4e5b27248454d2ca1440ea167a1b942ae9fca856b6cbfa4955ed73053577','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c531dcb0e7440f1d4db584f64c830c51936e5ebb689f314a9936aa1f16944dff',1994,'ER','Eritrea','geography',355,'Location: Eastern Africa, bordering the Red
Sea between Djibouti and Sudan
Map references: Africa, Standard Time
Zones of the World
Area:
total area: 1 2 1 ,320 sq km
land area: 1 2 1 ,320 sq km
comparative area: slightly larger than
Pennsylvania
Land boundaries: total 1.630 km, Djibouti
1 13 km, Ethiopia 912 km, Sudan 60S km
Coastline: 1.15! km (land and Island
coastline is 2,234 km)
Maritime claims:
territorial sea: 12 nm
International disputes: none
Climate: hot, dry desert strip along Red Sea
coast: cooler and wetter in the central
highlands (up to 61 cm of rainfall annually);
semiarid in western hills and lowlands; rainfall
heaviest during June-September except on
coast desert
Terrain: dominated by extension of
Ethiopian north-south trending highlands,
descending on the east to a coastal desert plan,
on the northwest to hilly terrain and on the
southwest to flat-to-rolling plains
Natural resources; gold, potash, zinc.
copper, salt, probably oil, fish
Land use:
arable land: 3%
permanent crops: 2% (coffee)
meadows and pastures: 40%
forest and woodland: 5%
other: 50%
Irrigated land: NA sq km','aaa78a9e696e780b596f5af165b671f2c16da94331757d37eb7b760919127480','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac037740fbe3adadf6875e68e00cfdf1bfe8e2f46cc689a3dc5f648c32ca398a',1994,'EE','Estonia','geography',361,'Location: Eastern Europe, bordering the
Baltic Sea. between Sweden and Russia
Map references; Arctic Region, Asia.
Europe, Standard Time Zones of the World
Area:
total area; 45. 1(X) sq km
land area; 43.200 .sq km
comparative area; slightly larger than New
Hampshire and Vermont combined
note; includes 1.520 islands in the Baltic Sea
Land boundaries: total 557 km. Latvia 267
km, Russia 290 km
Coastline: 1,393 km
Maritime claims:
territorial sea; 12 nm
International disputes: none
Climate: maritime, wet, moderate winters,
cool summers
Terrain: marshy, lowlands
Natural resources: shale oil. peat,
phosphorite, amber
Land use;
arable land; 22^
permanent crops; 0%
meadows atui pastures; 1 1^?-
forest and wotrdland; 3 1 Cf
other; 36%
Irrigated land: 1 10 sq km ( 1990)','dcb12e75b5e8cdce66b41e5b57f9900c01d2399129bcf3c25f399e601216138c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bac70d52b681d0cfeee21c6d1f00f51b686140fcfe6e761b08718d207fb30f12',1994,'FO','Faroe Islands','geography',376,'Location: Nordic States, Northern Europe in
the north Atlantic Ocean, located half way
between Norway and Iceland
Map references: Arctic Region
Area:
total area: 1 ,400 sq km
land area: 1 ,400 sq km
comparative area: slightly less than eight
times the size of Washington, EXT
Land boundaries: 0 km
Coastiine: 764 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
International disputes; none
Climate: mild winters, cool summers; usually
overcast; foggy, windy
Terrain: rugged, rocky, some low peaks;
cliffs along most of coast
Natural resources: fish
Land use:
arable land: 2%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 98%
Irrigated land: NA sq km','961270de38c6648847262dfd04cc609333a2b50cf4967954b8b3b1561f291b64','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09c3b413ea24658fe4f531783dba11bf5b6c65d6963f8d46ceac0eff4e425d69',1994,'DK','Denmark','geography',381,'National product real growth rate: 3%
(1989 est.)
National product per capita: $I4,0(X)(1989
est.)
Inflation rate (consumer prices): 2% ( 1 988)
Unemployment rate: 2.5% (1993 est)
Budget:
revenues: $425 million
expenditures; $480 million, including capital
expenditures of SNA (1991 est.)
Exports: $386 million (f.o.b., 1990 est.)
commodities: fish and fish prcxlucts 88%,
animal feedstuffs, transport equipment (ships)
(1989)
partners: Denmark 20%. Germany 1 8.3%, UK
14.2%, France 1 1 .2%, Spain 7.9%, US 4.5%
Imports: $322 million (c.i.f., 1990 est.)
commodities; machinery and transport
equipment 24.4%, manufactures 24%, food
and livestock 19%, fuels 12%, chemicals 6.5%
partners; Denmark 43.8%, Norway 19.8%,
Sweden 4.9%, Germany 4.2%, US 1 .3%
External debt: $1.3 billion (1991)
Industrial production: growth rate NA%
Electricity:
capacity: 80,(K)0 kW
production; 280 million kWh
consumption per capita; 5,760 kWh (1992)
Industries: fishing, shipbuilding, handicrafts
Agriculture: accounts for 27% of GDP and
employs 27% of labor force; principal crops —
potatoes and vegetables; livestock — sheep;
annual fish catch about 360,000 metric tons
Economic aid:
recipient; receives an annual subsidy from
Denmark of about $130 million
Currency: 1 Danish krone (DKr) = 100 oere
Exchange rates: Danish kroner (DKr) per
US$1— 6.771 (January 1994), 6.484 (1993),
6.036 (1992). 6.396 (1991), 6.189 (1990),
7.310(1989)
Fiscal year: 1 April — 3 1 March','af3302a1d8feb419e007750130ef24c8c18f53616f034087e324ed10ec7f92fa','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed0ae934baa1985cce05cdfb485c6cd186a5cbf6fe3ea2b961f80a65172b7016',1994,'FI','Finland','geography',390,'Location: Nordic State, Northern Europe,
bordering the Baltic Sea between Sweden and
Russia
Map references: Arctic Region. Europe,
Standard Time Zones of the World
Area:
total area: 337,030 sq km
land area: 305,470 sq km
comparative area: slightly smaller than
Montana
Land boundaries: total 2.628 km, Norway
729 km. Sweden 586 km. Russia 1,313 km
Coastline: 1 , 1 26 km (excludes islands and
coastal indentations)
Maritime claims:
contiguou.''i zone: 6 nm
continental .shelf: 2(X)-m depth or to depth of
exploitation
exclusive fi.shing zone: 1 2 nm
territorial sea: 4 nm
International disputes: none
Climate: cold temperate; potentially
subarctic, but comparatively mild because of
nvxlerating influence of the North Atlantic
Current. Baltic Sea, and more than 60,(KX)
lakes
Terrain: mostly low. flat to rolling plains
interspersed with lakes and low hills
Natural resources: timber, copper, ^inc, iron
ore, silver
Land use:
arable land: 8%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 16%
other: 16%
Irrigated land: 620 sq km (1989 est.)
Location: Middle East, along the
Mediterranean Sea, between Turkey and','289a9b6aa9369846bcec38b98ce079787a242483ef6a3023093f4b224e58be86','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ca04373821ac90a094417cf465848f3e0abbd60339b2a56cb6e86cc17be069e',1994,'FR','France','geography',396,'Location: Western Europe, bordering the
North Atlantic Ocean between Spain and
Location: Eastern Asia, 27 km
west-southwest of Hong Kong on the southeast
coast of China bordering the South China Sea
Map references: Asia, Oceania, Southeast
Asia, Standard Time Zones of the World
Area:
total area: 16 sq km
land area: 16sq km
comparative area: about 0.1 times the size of
Washington, DC
Land boundaries: total 0.34 km, China 0.34
km
Coastline: 40 km
Maritime claims: not specified
International disputes: none
Climate: subtropical; marine with cool
winters, warm summers
Terrain: generally flat
Natural resources: negligible
Land use:
arable lend: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Inigated land: NA sq km
.166
meadows and pastures: 2 1 %
forest and woodland: 3 1 %
other: 7%
Irrigated land: 33,600 sq km (1989 est.)','072aa8f4f569d2ab3c0ff0c7074749314f72967866946ef9f68aa815883fc513','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d43ee1723ef80882918a17f7dec61c5e7cb15c439d5d956f414eacced80b71c5',1994,'DE','Germany','geography',397,'Map references: Europe, Standard Time
Zones of the World
Area:
total area: 547,030 sq km
land area: 545,630 sq km
comparative area: slightly more than twice the
size of Colorado
note: includes Corsica and the rest of
metropolitan France, but excludes the overseas
administrative divisions
Land boundaries: total 2,892.4 km. Andorra
60 km, Belgium 620 km, Germany 45 1 km.
Italy 488 km. Luxembourg 73 km. Monaco 4.4
km, Spain 623 km, Switzerland 573 km
Coastline: 3.427 km (mainland 2,783 km,
Corsica 644 km)
Maritime claims:
contiguous zone: 12-24 nm
exclusive economic zone: 200 nm
territorial .sea: 1 2 nm
International disputes: Madagascar claims
Bassas da India, Europe Island. Glorioso
Islands. Juan de Nova Island, and Tromelin
Island; Comoros claims Mayotte; Mauri''ius
claims Tromelin Island; Seychelles claims
Tromelin Island; Suriname claims part of
French Guiana; Mexico claims Clipperton
Island; territorial claim in Antarctica (Adelie
Land); Saint Pierre and Miquelon is focus of
maritime boundary dispute between Canada
and France
Climate; generally cool winters and mild
summers, but mild winters and hot summers
along the Mediten anean
Terrain: mostly flat plains or gently rolling
hills in north and we.st; remainder is
mountainous, e.specially Pyrenees in south,
Alps in east
Natural resources: coal, iron ore. bauxite,
fish, timber, zinc. pota,sh
Land use;
arable land: .32%
permanent crops: 2%
meadows and pastures: 23%
forest and woodland: 21%
other: 16%
Irrigated land: 1 1,600 sq km (1989 est.)
Location: Central Europe, bordering the
North Sea between France and Poland
Map references: Arctic Region, Europe,
Standard Time Zones of the World
Area:
total area: 356,910 sq km
land area: 349,520 sq km
comparative area: slightly smaller than
Montana
note: includes the formerly separate Federal
Republic of Germany, the German Democratic
Republic, and Berlin following formal
unification on 3 October 1990
Land boundaries: total 3,621 km, Austria
784 km, Belgium 1 67 km, Czech Republic 646
km. Denmark 68 km. France 45 1 km,
Luxembourg 138 km, Netherlands 577 km,
Poland 456 km, Switzerland 334 km
Coastline: 2,389 km
Maritime claims:
continental shelf: 200-m depth or to depth of
exploitation
exclusive fishing zone: 200 nm
territorial sea: 3 nm in North Sea and
Schleswig-Holstein coast of Baltic Sea
(extends, at one point, to 16 nm in the
Helgolander Bucht): 12 nm in remainder of
Baltic Sea
International disputes: none
Climate: temperate and marine: cool, cloudy,
wet winters and summers; occasional warm,
tropical foehn wind; high relative humidity
Terrain: lowlands in north, uplands in center.
Bavarian Alps in south
Natural resources: iron ore, coal, potash,
timber, lignite, uranium, copper, natural gas.
salt, nickel
Land use:
arable land: 3455''
permanent crops: I %
meadows and pastures: 16%
forest and woodland: 30%
other: 19%
Irrigated land: 4.800 sq km (1989 est.)
148','1d1a482a609f378813a5a99917a7fe3f98b17f0af019afe56db9b9983eb466fd','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5271c9f6d2cfb8d53eeba9d6d1995758964a2455ffb49465aa5eb75a7da02b6',1994,'GF','French Guiana','geography',402,'Location: Northern South America.
bordering on the North Atlantic Ocean
between Suriname and Brazil
Map references: South America, Standard
Time Zones of the World
Area:
total area: 91 ,000 sq km
land area: 89,150 sq km
comparative area: slightly smaller than
Indiana
Land boundaries: total 1,183 km, Brazil 673
km, Suriname 510 km
Coastline: 378 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: Suriname claims
area between Riviere Litani and Riviere
Marouini (both headwaters of the Laws)
Climate: tropical; hot, humid; little seasonal
temperature variation
Terrain: low-lying coastal plains rising to
hills and small mountains
Natural resources: bauxite, timber, gold
(widely scattered), cinnabar, kaolin, fish
Land use:
arable land: 0%
permanent crops; 0%
meadows and pastures: 0%
ftrest -ind woodland: 82%
Cher; 18%
Irrigated land: NAsqkm','c731910021988fe491a1e233eded719b3ead8bf54285f4c3938155c872665e68','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6922679be12afbb12f5feeb767c195e611c1625bee84994ce344cebfb988af8',1994,'PF','French Polynesia','geography',407,'Location: Oceania. Polynesia halfway
between Australia and South America
Map reff fences: Oceania
Area:
total area: 3,941 sq km
land area: 3,660 sq km
comparative area: slightly less than one-third
the size of Connecticut
Land boundaries: 0 km
Coastline: 2.S2Skm
Maritime claims:
exclusive economic yme: 200 nm
territorial sea: 12 nm
International disputes: none
Climate; tropical, but moderate
Terrain: mixture of nigged high islands and
low islands with reefs
Natural resources; limber, fish, cobalt
Land use:
arable land: 1%
permanent crops: 19%
meadows and pastures: 5%
forest and woodland: 31%
other: 44%
Irrigated land: NAsqkm
Location: Southern Africa, in the southern
Indian Ocean, about equidistant between
Africa, Antarctica, and Australia
Map references: Antarctic Region. Standard
Time Zones of the World
Area:
total area: 7,781 sq km
land area: 7,781 sq km
comparative area; slightly less than 1 .5 times
the size of Delaware
note: includes He Amsterdam, lie Saint-Paul,
lies Kerguelen, and lies Crozet: excludes Terre
Adelie claim of about 500,000 sq km in
Antarctica that is not recognized by the US
Land boundaries: 0 km
Coastline: 1,232 km
Maritime claims:
exclusive economic zone; 200 nm from lies
Kerguelen only
territorial sea: 1 2 nm
International disputes; Terre Adelieclaim in
Antarctica is not recognized by the US
Climate: antarctic
Terrain: volcanic
Natural resources: fish, crayfish
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Irrigated land: 0 sq km','0475634238711c5c090455a7a030d9479deff3c19eb4a83f22291be798a5dd1f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb2f5fa94e090a576fd10a8ce914a44a08debf0a947e42fab3aac43d0089ca38',1994,'GA','Gabon','geography',412,'Location: Western Africa, bordering the
Atlantic Ocean at the Equator between the
Congo and Equatorial Guinea
Map references: Africa. Standard Time
Zones of the World
Area:
total area: 267,670 sq km
land area: 257,670 sq km
comparative area: slightly smaller than
Colorado
Land boundaries: total 2,55 1 km. Cameroon
298 km. Congo 1,903 km. Equatorial Guinea
350 km
Coastline: 885 km
Maritime claims;
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 1 2 nni
International disputes: maritime boundary
dispute with Equatorial Guinea because of
disputed sovereignty over islands in Corisco
Bay
Climate; tropical: always hot. humid
Terrain: narrow coastal plain; hilly interior:
savanna in east and south
Natural resources: petroleum, manganese.
uranium, gold, timber, iron ore
Land use:
arable land: I %
permanent crops: Wc
meadows and pastures: 1 8%
forest and woodland: 78‘ii
other: 2%
Irrigated land: NA sq km
Location: Western Africa, bordering the
North Atlantic Ocean almost completely
surrounded by Senegal
Map references: Africa, Standard Time
Zones of tbe World
Area:
lohil area: 1 1,300 sq km
land area: 10,000 sq km
comparative area: slightly more than twice the
size of Delaware
Land boundaries: total 740 km, Senegal 740
km
Coastline: 80 km
Maritime claims:
contiguous zone: 18 nm
continental shelf: not specified
exclusive fishing zone: 200 nm
territorial sea: 1 2 nm
International disputes: short section of
boundary with Senegal is indefinite
Climate; tropical; hot, rainy season (June to
November); cooler, dry season (November to
May)
Terrain: flood plain of the Gambia River
flunked by some low hills
Natural resources: fish
Land use:
arable land: \\6%
permanent crops: 0%
meadows and pastures: 9%
fiirest and woodland: 20%
other: 55%
Irrigated land: i 20 sq km ( 1 989 est.)','7c3a8b0a69e507d456e46535dfbfe682300afe01b0348e947413198fdbe834c7','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('172bbb010d9b2f52d4b51eb70057ba472030c0e4997d5c1f5b764f1ed4d03e03',1994,'GE','Georgia','geography',423,'Location: Southwestern Asia, bordering the
Black Sea. between Turkey and Russia
Map references: Africa, Asia.
Commonwealth of Independent States —
European States, Middle East, Standard Time
Zones of the World
Area:
total area; 69.700 sq km
land area: 69,700 sq km
comparative area: slightly larger than South
Carolina
Land boundaries: total 1 ,46 1 km, Armenia
164 km, Azerbaijan 322 km, Russia 723 km,
Turkey 252 km
Coastline: 310 km
Maritime claims;
note: 12 nm in 1973 USSR-Turkish Protocol
concerning the sea boundary between the two
states in the Black Sea; Georgia claims the
coastline along the Black Sea as its
international waters, although it cannot control
this area and the Russian navy and commercial
.ships transit freely
International disputes; none
Climate: warm and pleasant; Mediterranean¬
like on Black Sea coast
Terrain: largely mountainous with Great
Caucasus Mountains in the north and Lesser
Caucasus Mountains in the south; Kolkhida
Lowland opens to the Black Sea in the west;
Mtkvari River Basin in the east; good soils in
river valley flood plains, foothills of Kolkhida
Lowland
Natural resources: forest lands, hydropower,
manganese deposits, iron ores, copper, minor
coal and oil deposits; coastal climate and soils
allow for important tea and citrus growth
Land use;
arable land: NA%
permanent crops: NA%
meadows and pastures: NA%
forest and woodland: NA%
other; NA%
Irrigated land: 4,660 sq km (1990)
Location; Southern South America, in the
South Atlantic Ocean, off the south Argentine
coast, southeast of the Falkland Islands
Map references: Antarctic Region
Area:
total area: 4,066 sq km
land area: 4,066 sq km
comparative area: slightly larger than Rhode
Island
note: includes Shag Rocks, Clerke Rock.s, Bird
Island
Land boundaries: 0 km
Coastline: NA km
Maritime claims:
territorial sea: 1 2 nm
International disputes: administered by the
UK. claimed by Argentina
Climate: variable, with mostly westerly
winds throughout the year, interspersed with
periods of calm; nearly all precipitation falls as
snow
Terrain: most of the islands, rising steeply
from the sea. are rugged and mountainous;
South Georgia is largely barren and has steep,
glacier-covered mountains; the South
Sandwich Islands are of volcanic origin with
some active volcantws
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 09f’
other: 1 00% ( largely covered by permanent ice
and snow with .some sparse vegetation
consisting of grass, moss, and lichen)
Irrigated land: 0 sq km','5c29ab041b7a337b0494fdf6a8eb85b356348761203732261eec360de8e6697c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54461bf5b9bdaafba4aec71c8de68f7515dc73f19b67a86088280ab4e71c1063',1994,'GH','Ghana','geography',428,'Location: Western Africa, bordering the
North Atlantic Ocean between Cote d’Ivoire
and Togo
Map references: Africa. Standard Time
Zones of the World
Area:
total area: 238.540 sq km
land area: 230,020 sq km
comparative area: slightly smaller than
Oregon
Land boundaries: total 2,093 km, Burkina
548 km. Cole d''Ivoire 668 km, Togo 877 km
Coastline: 5,39 km
Maritime claims:
contigumis zone: 24 nm
continental shelf: 200 nm
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
International disputes: none
Climate; tropical: warm and comparatively
dry along southeast coast; hot and humid in
southwest: hot and dry in north
Terrain: mostly low plains with dissected
plateau in south-central area
Natural resources: gold, timber, industrial
diamonds, bauxite, manganese, fish, rubber
Land use:
arable land: 5%
permanent crops: 7%
meadows and pastures: 1 591-
forestand woodland: 37“^
other: 36*!}^
Irrigated land: 80 sq km (1989)
Location: Southwestern Europe, bordering
the Strait of Gibraltar, which links the North
Atlantic Ocean and the Mediterranean Sea. on
the southern coast of Spain
Map references: Africa, Europe
Area:
total area: 6.5 sq km
land area: 6.5 sq km
comparative area: about 1 1 times the size of
The Mall in Washington. DC
Land boundaries: total 1 .2 km, Spain 1 .2 km
Coastline: 12 km
Maritini''e claims:
exclusive fishing zone: 3 nm
territorial sea: 3 nm
IntemationaS disputes: source of occasional
friction between Spain and the UK
Climate: Mediterranean with mild winters
and warm summers
Terrain: a narre w coastal lowland borders
The Rock
Natural resources: negligible
Land use:
arable land; 0%
permanent crops: 0%
meadows and pastures; 0%
forest and woodland: 0%
other: 100%
Irrigated land: NAsqkm
Location: Southern Africa, in the Indian
Ocean just north of Madagascar
Map references: .Africa
Area:
total area: 5 sq km
land area: 5 sq km
comparative area: about 8.5 times the size of
The Mall in Washington. DC
role: includes lie Glorieuse, He riu Lys, Verte
Rocks, Wreck Rock, and South Rock
Land boundaries: 0 km
Coastline: 35.2 km
Maritime claims:
contiguous zone: 1 2 nm
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
International disputes: claimed by
Map rcfbranccK Africa, Standard Time
Zoiies of the World
Am:
total area: 56,790 sq km
land area: 54,390 sq km
comparative area: slightly smaller than West
Virginia
Land houndarics: toUl 1,647 km. Benin 644
km, Burkina 126 km, Ghana 877 km
CoMtlbw: 56 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 30 nm
International lilsputcs: none
Climate: tropical; hot, humid in south:
seniarid in north
Terrain: gently rolling savanna in north;
central hills; southern plateau; low coastal
plain with extensive lagoons end ma.''shes
Natural resources: phosphates, limestone,
marble
Land use:
arable land: 25%
permanent crops: 1%
meadows and pastures: 4%
forest and woodland: 28%
other: 42%
Irrigated Itmd: 70 sq km (1989 est.)','b40897db4dc8873a4e0d5c0a6d660e187a3e7d1eb0b9b225d5cacad85f3d6700','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e6247867efc08ec774fc4c44e3dff11906db8c685e7f9b3fe3e03a871331932',1994,'GL','Greenland','geography',434,'Location: Northern North America, in the
North Atlantic Ocean, between Canada and','316310563afd12b6748018f7ca658db9527566568ac49d291a5fd98710ee08cb','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b9f25e5026edac1b91ba4164ec367623fee876bfd7f3192cff8d7ef1865ffefe',1994,'GD','Grenada','geography',436,'Location: Caribbean, in the eastern Caribbean
Sea, about 150 im north of Trinidad and
Tobago
Map references: Central America and the
Caribbean, South America, Standard Time
2^nes of the World
Area:
toial area: 340 sq km
land area: 340 sq km
comparative area: slightly less than twice the
size of Washington, DC
Land boundaries: 0 km
Coastline: 121 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; tempered by northeast
trade winds
Terrain; volcanic in origin with central
mountains
Natural resources; timber, tropical fruit,
deepwater harbors
Land use:
arable land: 1 5%
permanent crops: 26%
meadows and pastures: 3%
forest and woodland: 9%
other: 47%
Irrigated land: NA sq km','4ba38caeeb029d85afa78b1e2da48e442dc1d7ac2cda08a6782d0bbf02d9c573','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27f8335fdfc63fc2749555b452c8424fe363ce9c93bbb0694df78c7c38fc867a',1994,'GP','Guadeloupe','geography',441,'Location: Caribbean, in the Caribbean Sea,
.SOO km southeast of Puerto Rico
Map references: Central America and the
Caribbean
Area:
total area: 1 ,780 sq km
land area: 1 ,760 ,sq km
comparative area: 10 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 306 km
Maritime claims;
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
International disputes; none
Climate: subtropical tempered by trade
winds: relatively high humidity
Terrain: Basse-Terre is volcanic in origin
with interior mountains; Grand-Terre is low
limestone formation
Natural resources: cultivable land, beaches
and climate that foster tourism
Land use:
arable land: 1 8%
permanent crops: 5%
meadows and pastures: \\3%
forest and woodland: 40%
other: 24%
Irrigated land: 30 sq km (1989 est.)','4ecfdf7b8f758814ee393eed66640e1d0832d07065e2e010cfa251ff351f63ec','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7983c24fa7c5c26e47975622e420e0d9975c3bee57bd1ebc5da0438fb83f0561',1994,'GU','Guam','geography',448,'Location: Oceania, Micronesia, in the North
Pacific Ocean, 5,955 km west-southwest of
Honolulu, about three-quarters of the way
between Hawaii and the Philippines
Map references: Oceania
Area:
total area: 5‘t ‘ m
land area; 54 1 .3 sq km
comparative area: slightly more than three
times the size of Washington, DC
Land boundaries: 0 km
Coastline: 125.5 km
Maritime claims:
contiguous zone; 24 nm
continet''to! ’theij; 2(X)-m depth or to depth of
exploi''
exc> ’''■''200nm
tern '' •.
Intern,.'' . '' > '' - none
Climate: tropical marine; generally warm and
humid, moderated by northeast trade winds;
dry season from January to June, rainy season
from July to December; little seasonal
temperature variation
Terrain: volcanic origin, surrounded by coral
reefs; relatively flat coraline limestone plateau
(source of most fresh water) with steep coastal
cliffs and narrow coastal plains in north, low-
rising hills in center, mountains in south
Natural resources: fishing (largely
undeveloped), tourism (especially from Japan)
Land use:
arable land: 1 1 %
permanent crops: 1 1%
meadows and pastures: 15%
forest and woodland; 1 8%
other: 45%
Irrigated land: NA sq km','ee18809de6c481d57e3c7a84fe80239a110bf77b7ab7fa46cac22eb8d3b7471b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c40f9c6409d98411bf61c8f6683594ce0da11b855330b0943b0d185bbbefb6dc',1994,'GT','Guatemala','geography',452,'Location: Middle America, between
Honduras and Mexico
Map references: Central America and the
Caiibbean, North America, Standard Time
Zones of the World
Area:
total area: 108,890 sq km
laod area: 108,430 sq km
comparative area: slightly smaller than
Tennessee
Land boundaries: total 1 ,687 km. Belize 266
km, El Salvador 20.3 km, Honduras 256 km,
Mexico 962 km
Coastline: 400 km
Maritime claims:
continental shelf: the outer edge of the
continental shelf
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: maritime border with
Belize in dispute; desultory negotiations to
re.solve the dispute have begun
Climate: tropical; hot. humid in lowlands;
cooler in highlands
Terrain: mostly mountains with narrow
coastal plains and rolling limestone plateau
(Peien)
Natural resources: petroleum, nickel, rare
woods, fish, chicle
Land use:
arable land: \\2Vr
permanent crops: 49f
ineadows and pastures: \\2%
forest and woodland: 40%
other: 32%
Irrigated land: 780 sq km (1989 est.)','c9aa2066883e331c95d1945720451630d9cce8a10e18b5c730f47ecf0a74e87c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4562bda1e6fe8ca853287eb83356a84c060c9f18471042a5945cd7270185c85',1994,'GG','Guernsey','geography',457,'Location: Western Europe, in the English
Channel, 52 kin west of France between UK
and France
Map references: Europe
Area:
total area: 1 94 sq km
land area: 1 94 sq km
comparative area: slightly larger than
Washington, C)C
note: includes Alderney, Guernsey, Herm,
Sark, and some other smaller islands
Land boundaries: 0 km
Coastline: 50 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 3 nm
International disputes: none
Climate: temperate with mild winters and
cool .''ummers; about 50% of days are overcast
Terrain: mostly level with low hills in
southwest
Natural resources: cropland
Land use:
arable land: NA%
permanent crops: NA%
meadows and pastures: NA%
forest and woodland: NA%
other: NA%
Irrigated land: NA sq km','c8f1e043014ab9862adf57b41261e98f16dc6d8b2448df22fb966c2de9f4e703','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6a16597f7dbf1dbf332002c611b540d8bd8a63f569bc4f632f02cdd02a0bc24',1994,'GN','Guinea','geography',463,'Location: Western Africa, bordering the
North Atlantic Ocean between Guinea-Bissau
and Sierra Leone
Map references: Africa, Standard Time
Zones of the World
Area:
total area: 245,860 sq km
land area: 245.860 sq km
comparative area; slightly smaller than
Oregon
Land houndaries: total 3.399 km, Guinea-
Bissau 386 km. Cote d’Ivoire 610 km. Liberia
563 km. Mali 858 km. Senegal 330 km. Sierra
Leone 652 km
Coastline; 320 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea; 12 nm
International disputes: none
Climate: generally hot and humid;
mon.soonal-type rainy season (June to
November) with southwesterly winds; dry
season (December to May) with northeasterly
harmattan winds
Terrain: generally flat coastal plain, hilly to
mountainous interior
Natural resources; bauxite, iron ore.
diamonds, gold, uranium, hydropower, fish
Land use;
arable land: 6%
permanent crops: 0%
meadows and pastures: 12%
forest and woodland: 42%
other: 40%
Irrigated land: 240 sq km (1989 e.st.)
Location: Western Africa, bordering the
North Atlantic Ocean between Guinea and','9d75501cd90eb0c2b5869b1cfebfa3496f94289d3ec9436c28b5afe849f46d52','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c3ee273b7ddc02be5b5eb07eef374cf9af0e32e6b63ad5bd126235d7fa7d7df',1994,'SN','Senegal','geography',468,'Map references: Africa, Standard Time
Zones of the World
Area:
total area: 36, 1 20 sq km
land area: 28,000 sq km
comparative area: slightly less than three
times the size of Connecticut
Land boundaries: total 724 km, Guitieu 386
km. Senegal 338 km
Coastline: 350 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes; Guinea-Bissau and
Senegal signed tin agreement resolving their
maritime boundary in 1993
Climate; tropical; generally hot and humid;
mr nsoonal-type rainy season (June to
November) with southwesterly winds; dry
season (December to May) with northeasterly
harmattan winds
Terrain: mostly low coastal plain rising to
savanna in east
Natural resources: unexploited deposits of
petroleum, bauxite, phosphates, fish, timber
Land use:
arable land: 1 1 %
permanent crops: 1 %
meadows and pastures: 43%
forest and woodland: 38%
other: 7%
Irrigated land: NA sq km
Fnvironment:
current issues: aeforcstalion; soil erosion;
overgrazing
naturai hazards: hot. dry, dusty harmattan
haze may reduce visibility during dry .season;
brush fires
international agreements: party to —
findangered Species. Law of the Sea. Nuclear
T''st Ban, Wetlands; signed, but tan ratii''ed —
Biodiversity. Climate Change
Map references: Africa, Standard Time
Zones of the World
Area:
total area: 1,030,700 sq km
land area: 1 .030,400 sq km
comparative area: slightly larger than three
times the size of New Mexico
Land boundaries: total 5,074 km, Algeria
463 km, Mali 2.237 km, Senegal 813 km,
Western Sahara 1,561 km
Coastline: 754 km
Maritime claims;
contiguous zone: 24 nm
continental shelf: 200 nm or the edge of
continental margin
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
International disputes; boundary with
Climate; desert; constantly hot, dry, dusty
Terrain: mostly barren, flat plains of the
Sahara; some central hills
Natural resources: iron ore, gyp.sum, fish,
copper, phosphate
Land use:
arable land: 1 %
permanent crops: 0%
meadows and pa.stures: 38%
forest and woodland: 5%
other: 56%
irrigated land: 120 sq km (1989 est.)
Defense Forces
346
international agreements: party to —
Endangered Species, Hazardous Wastes, Law
of the Sea, Marine Life Conservation, Nuclear
Test Ban, Ozone Layer Protection, Wetlands,
Whaling; signed, but not ratified —
Biodiversity, Climate Change, Marine
Dumping
Note: The Gambia is almost an enclave
Location: Balkan State, Southeastern Europe,
bordering the Adriatic Sea, between Bosnia
and Herzegovina and Bulgaria
Map references: Ethnic Groups in Eastern
Europe. Europe, Standard Time Zones of the
World
Area;
total area: 102,350 sq km
land area: 102,1 36 sq km
comparative area: slightly larger than
Kentucky
note: Serbia has a total area and a land area of
88,412 sq km making it slightly larger than
Maine; Montenegro has a total area of 13,938
sq km and a land area of 1 3,724 sq km making
it slightly larger than Connecticut
Land boundaries: total 2,246 km, Albania
287 km (1 14 km with Serbia; 173 km with
Motenegro), Bosnia and Herzegovina 527 km
(312 km with Serbia; 215 km with
Montenegro), Bulgaria 3 1 8 km, Croatia (north)
241 km, Croatia (south) 25 km, Hungary 151
km. The Former Yugoslav Republic of
Macedonia 221 km, Romania 476 km
note: the internal boundary between
Montenegro and Serbia is 21 1 km
Coastline: 199 km (Montenegro 199 km,
Serbia 0 km)
Maritime claims;
territorial sea: 1 2 nm
International disputes: Sandzak region
bordering northern Montenegro and
southeastern Serbia — Muslims seeking
autonomy; disputes with Bosnia and
Herzegovina and Croatia over Serbian
populated areas; Albanian majority in Kosovo
seeks independence from Serbian Republic
348
Climate: in the north, continental climate
(cold winter and hot, humid summers with well
distributed rainfall); central portion,
continental and Mediterranean climate: to the
south, Adriatic climate along the coast, hot, dry
summers and autumns and relatively cold
winters with heavy snowfall inland
Terrain: extremely varied; to the north, rich
fertile plains; to the east, limestone ranges and
basins; to the southeast, ancient mountain and
hills; to the southwest, extremely high
shoreline with no islands off the coast; home of
largest lake in former Y ugoslavia. Lake Scutari
Natural resources: oil, gas. coal, antimony,
copper, lead, zinc, nickel, gold, pyrite, chrome
Land use:
arable land; .10%
permanent crops: 5%
meadows and pastures: 20%
forest and woodland: 25%
other: 20%
Irrigated land: NA sq km','824ae0d0eb266113083de4107d40298264a6aeb24cd4ccc77313a0ca51f5be5c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f917cd5419e6bafd4f8185f141f4c65141d13208f2bccabae9a057ae61b41630',1994,'HT','Haiti','geography',475,'Location; Caribbean, in the northern
Caribbean .Sea, about 90 km southeast of Cuba
Map references: Central America and the
Caribbean, Standard Time Zones of the World
Area:
loud area: 27.750 sq km
land area: 27,.560 sq km
eoinparative area: slightly larger than
Maryland
Land boundaries; total 275 km. Dominican
Republic 275 km
Coastline: 1.771 km
Maritime claims:
eontiKuous zone: 24 nm
eontinenlal .shelf: to depth of exploitation
e.xelusive eeoiuimie zone: 2(X) nm
territorial .sea: 12 nm
International disputes: claims US-
administered Navassa Island
Climate: tropical; semiarid witere mountains
in east cut off trade winds
Terrain: mostly rough tind mountainous
Natural resources: bauxite
Land u.se:
aral’le land: ZiYH
permanent erops: 1 3''/f
meadows and iia.stiires: 1 8''^
forest and woodland: 49(-
other: dS''iJ
Irrigated land; 7.50 sq km ( 1989 cst.)
Location: Southern Africa, in the Indian
Ocean, 4,100 km southwest of Australia
Map references: Antarctic Region
Area:
total area: 412 sq km
land area: 412 sq km
comparative area: slightly less than 2.5 times
the size of Washington, E)C
Land boundaries: 0 km
Coastline: 10], 9 km
Maritime claims:
eselusive fishing zone: 200 nm
territorial sea: 3 nm
International disputes: none
Climate: antarctic
Terrain: Heard island — bleak and
mountainous, with an quiescent volcano;
McDonald Islands — small and rocky
Natural resources; none
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and womlland: 0%
other: 100%
Irrigated land: 0 sq km','37563e0e7c35fee7c52bd98a6676ab41fa364dec11f2bdad8227c9eade9f5670','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6628a84d5f7cfc23b79575290eeabb353c25228eb391f9f6647ca4f52b11828b',1994,'HK','Hong Kong','geography',483,'Location: Eastern Asia, on the southeast coast
of China bordering the South China Sea
Map references: Asia, Southeast Asia,
Standard Time Zones of the World
Area:
total area: 1 .040 sq km
/and area: 990 sq km
comparative area: slightly less than six times
the size of Washington, CX;
Land boundaries: total 30 km. China 30 km
Coastline: 733 km
Maritime claims:
e.vclti.''iive f .tiling zone: 3 nin
territorial .tea: 3 nm
International disputes: none
Climate: tropical monsoon; cool and humid in
winter, hot and rainy from spring through
summer, warm and sunny in full
Terrain; hilly to mountainous with steep
slopes; lowlands in north
Natural resources: outstanding deepwater
harbor, feldspar
Land use:
arable land: 7%
permanent crop.t: 1 %
ineadow.t and pa-tture.t: 1 %
fore.tt and woodland: 1 29}-
other: 79%
Irrigated land; 20 sq km (1989)','04185d6ef3d58d0b553f8692d9f197313efa0f700c43a2134aca1e17f6233929','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ce1fbfad41afa1b5f79f7b75d05ea23249dc656fe47ed49aa7543ef3942513a',1994,'HU','Hungary','geography',487,'Location: Central Europe, between Slovakia
and Romania
Map references: Ethnic Groups in Eastern
Europe, Europe
Area:
ittlal area: <}?,03() sq kni
land area: 92,340 sq km
fonipaniiive area; slightly smaller than
Indiana
Land boundaries: total 1,989 km, Austria
,366 km. Croatia .329 km, Romania 44.3 km,
.Serbia and Montenegro 1,3 1 km (all with
Serbia). Slovakia 31,3 km. Slovenia 82 km,
Ukraine 10,3 km
Coastline: U km (landltK-ked)
Maritime claims: none: landlocked
International disputes: Gubcikovo Dam
dispute with Slovakia
Climate: temperate: t dd, cloudy, humid
w''inters: warm summers
Terrain: mostly flat to rolling plains
Natural resources: bauxite, coal, natural gas.
fertile soils
Land use:
arable land: 50.7‘7r
permanent civps: 6.19f
meadows and pastures: 1 2,69b
forest and woodland: 1 8. .39b
other: 12..39b
Irrigated land: 1 .7.30 sq km (1989)','2aa85b7198b7b17a2fa0c5aff5151d3abf46a1c975ce657d18747002462da6e4','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6445f15ed2fe3be38b825ef4c78080075b8337ff721617ff3fd0580b8f1146c9',1994,'IS','Iceland','geography',492,'Location: Nordic State. Northern Europe, in
the North Atlantic Ocean, between Greenland
and Norway
Map references: Arctic Region, Europe,
North America, Standard Time Zones of the
World
Area:
total area: 1 03.000 sq km
land area: 100,250 sq km
comparative area: slightly smaller than
Kentucky
Land boundaries: 0 km
Coastiine: 4,988 km
Maritime ciaims:
continental shelf: 200 nm or the edge of
continental margin
exclusive economic zone: 2v30 nm
territorial sea: 1 2 nm
International disputes: Rockall continental
shelf dispute involving Denmark. Ireland, and
the UK (Ireland and the UK have signed a
boundary agreement in the Rockall area)
Climate: temperate: moderated by North
Atlantic Current: mild, windy winters: damp,
cool summers
Terrain: mostly plateau interspersed with
mountain peaks, icefields: coast deeply
indented by bays and fiords
Natural resources: fish, hydropower,
geothermal power, diatomite
Land use:
arable land: 1 9c
permanent crops: 0%
meadows and pastures: 209''f
forest and woodland: 1 9o
other: 78%
Irrigated land: NA sq km','473420dfed886665912db71cc12089240769d07c243f9681b3bf9abc27bee4a2','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9aee0c7fa45da03187c124548949df227ee5497a33e495d39ac8a9e5be92eb6b',1994,'IN','India','geography',497,'Location: Southern Asia, bordering the
Arabian Sea and the Bay of Bengal, between
Bangladesh and Pakistan
Map references: Asia, Standard Time Zones
of the World
Area:
wtal area: 3,287,590 km2
land area: 2.973,190 km2
comparative area: slightly more than one-
third the size of the US
Land boundaries: total 14,103 km,
Bangladesh 4.053 km. Bhutan 605 km. Burma
1.463 km. China 3.380 km. Nepal 1,690 km.
Pakistan 2.912 km
Coastline: 7,000 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200 nm or the edge of
continental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: boundaries with
Bangladesh and China: status of Kashmir with
Pakistan: water-sharing problems with
downstream riparians, Bangladesh over the
Ganges and Pakistan over the Indus
Climate: varies from tropical monsoon in
south to temperate in north
Terrain: upland plain (Deccan Plateau) in
south, flat to rolling plain along the Ganges.
deserts in west. Himalayas in north
Natural resources: coal (fourth-largest
reserves in the world), iron ore, manganese.
mica, bauxite, titanium ore. chromite, natural
gas. diamonds, petroleum, limestone
Land use:
arahle land: 55''X''
permanent crops: I %
meadows and pastures: 4Vr
forest and woodland: 23‘7r
other: I79f
Irrigated land: 430..39() sq km (1989)
territorial sen; 12 nm
International disputes: none
Climate: tropical; hot, humid; dry, northeast
monsoon (November to March); rainy,
southwest monsoon (June to August)
Terrain: flat with elevations only as high as
2.5 meters
Natural resources: fish
Land use:
arable land: 10%
permanent crops; 0%
meadows and pastures; 3%
forest and woodland; 3%
other; 84%
Irrigated land: NA sq km
Climate; mostly hot. dry desen; temperate in
northwest; arctic in north
Terrain: flat Indus plain in cost; mountains in
north and northwest; Balochistun plateou in
west
Natural resources; land, extensive naturol
gas reserves, limited petroleum, poor quality
coal, iion ore, copper, suit, limestone
Land use:
arable land: 26%
permanent crops: lYX-
meadows and pastures: 6%
forest and winxlland: 4%
other: 64%
Irrigated land: l62,2(X)sqkni(l989)','e8d4f6c26b5d874193acae1bc1ed5efca6e3a8da905ca5b501d1518dbccaa39a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80a2771f594d5caacba198359727991c9ffe462b0a600e3d7777e10046cc4555',1994,'ID','Indonesia','geography',503,'Location: Southeastern Asia, between
Malaysia and Australia
Map references: Oceania, Southeast Asia.
.Standard Time Zones of the World
Area:
louil ait''ti: 1. 91*^.440 sq km
land area: 1 ,8^6,440 sq km
ciiin/Hiraiiiv timi: slightly less than three
times the si/.e of Texas
Land boundaries: total 2.602 km. Malaysia
1 .782 km. Papua New Guinea 820 km
Coastline: .S4.7l6kni
Maritime claims: measured from claimed
archipelagic baselines
CM lusivc iroiuuiiii :onc: 2(K) nm
urriiorial sea: 1 2 nm
international disputes; sovereignly us er
Timor Timur (East Timor Provincei disputed
with Portugal and not rccogni/ed by the LN:
two islands in dispute w ith Malaysia
Climate: tropical; hm. humid; more moderate
in highlands
Terrain: mostly coastal lowlands; larger
islands have inicror mountains
Natural resources: petroleum, tin. natural
gas. nickel, timber, bauxite, copper, fertile
soils, coal. gold, silver
laind use:
ciriddi’ land; 8‘<
fn’miancnt cro/tv.- yi
nwadau * and /xi.vfarr.v.- 7''''t
fiiri''M and iviHxUand: bl''''i
alhfr: l.''ff
Irrigated land: 7.s..siNisqkmtl989csi i
Map references; Asia, Oceania, Southeast
Asia, Standard Time Zones of the World
Area:
total area; 329,750 sq km
land area: 328,550 sq km
comparative area: slightly larger than New','9b12c30422d5ba2ef985629a1d57506156d24b195868b8e342e4a4ced4cd4f60','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8246f5640bb6275f1534f161f8bca89af73184d369f5dcc498c20d1f941631b',1994,'OM','Oman','geography',506,'LacatkHi: Middle Easi, between the Persian
Gulf and the Caspian Sea
Map references: Asia, Middle East. Standard
Time Zones of the World
Area:
louil urea: I .NtK million sq km
lamt area: 1 ,6.f6 million sq km
carntMiraiive area: slightly larger than Alaska
laimi bouiNlarics: usal S.440 km.
Afghanistan km. Armenia km.
Arethaijan (nonh) 4.^2 km. Azerbaijan
( northwest) 1 74 km. Iraq I.4S8 km. Pakistan
ODD km. Turkey 444 km. Turkmenistan 442 km
CowtHne; 2.440 km
note: Iran also borders the Caspian Sea t740
km I
Marilime cialms:
rantinenial \\he(f: not specified
e.» iushr thhinfi :ane: .M) nm in the Golf of
Oman: continental shelf limit, cimtinemal shelf
boundaries, or nKdian lines in the Persian Gulf
lerrilarial .%ea: 1 2 nm
inlcmaHonal dispvICK: Iran and Iraq
restored diplomatic relations in 1440 but are
still try ing to work t«ut written agreements
settling (Hitstaniling disputes tn>m their eight-
year war concerning border demarcation,
prisoiwrs-of-war, anti freedom of nasiguiiim
and stivereignty oser the Shait al Arab
waterway: Iran tK''cupies two islands in the
Persian Gulf claimed by the I''AE: Tunb as
Sughra I Arabic!. Ja/ireb-ye Tonb-e Kuchek
I Persian) or Ix''sser Tunb. and Tunb al Kubra
I Arabic I. Ja/ireh-ye Tonb-e Bo/org (Persian)
or Greater Tunb: it jointly administers w iih the
I''AE an island in the Persian Gulf clainRd by
the L'' AH. Abu Musa ( Arabic i ih Ja/ireh-ye
Abu Musa (Persian): in 1442 the dispute oser
Abu Musa and the Tunb islands becantc mtire
acute when Iran unilaterally tried to control the
entry of third ctHiniry nationals into the CAE
portion of Abu Musa island. Tehran
subsequently hacked off in the face of
significant diplomatic support for the GAE in
the region: pi''iiixlic disputes w ith Afghanistan
over Heliiiand water rights
Climate: mostly arid or semiarid, subtropical
along Caspian coast
Terrain: rugged, mountainous rim; high.
central basin with deserts, mountains: small.
discontinuous plains along both coasts
Natural resources: petroleum, natural gas,
coal, chromium, copper, iron ore. lead.
mangane.se, zinc, sulfur
Land use:
arable land: 8%
permanent crops: 0%
meadows and pastures: 27%
forest and woodland: 1 1%
other: 54%
Irrigated land: 57,.500sqkm(l984est.)
Location: Middle East, along the Arabian
Sea. between Yemen and the United Arab
Emirates
Map references; Middle East. Standard Time
Zones of the World
Area:
IomI urea: 2 1 2.460 sq km
Uimi urea: 2 1 2.460 sq km
eompurtitive area; slightly smaller than
Kansas
l..and bonndaries: total I.. ^74 km. Saudi
Arabia 676 km. UAE 410 km, Yemen 288 km
Coastline: 2.092 km
Maritime claims:
coiitiguimy zone: 24 nm
eontineiital shelf: to be defined
exclusive economic zone: 2(K) nm
terriiorial sea: 1 2 nm
International disputes: no defined boundary
with most of UAf.'', Administrative Line with
UAE in fur north; a treaty with Yemen defining
the Omanl-Ycmeni boundary was ratified in
December 1992
Climate: dry desen; hot. humid along coast:
hot. dry interior; strong southwest summer
monstxrn {May to September) in fur south
Terrain: vast central desen plain, rugged
mountains in nonh and south
Natural resources: petroleum, copper,
asbestos, some marble, limestone, chromium,
gypsum, natural gas
laind use:
arahle land: less than 29f
pemmnem crops: iVH
meadows and fhistures:
forest and wtHHiland: (.V/c
other; 9.^%
Irrigated land: 410 sq km (I989est.)
Location: Oceania, Micronesia, in the North
Pacific Ocean. 830 km southeast of the','43b333f38eec261ca5754d9c6db74b75e6e8e6288050f91a59bfaefebfc98c66','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5dd8b9bca55bb01c771dcce1a830efeb3d5c51ec8f3a9cf7dc78ef3316663fbe',1994,'IE','Ireland','geography',516,'Location: Western Eumpe. in the North
Atlantic tX''ean. across the Irish Sea from Great
Britain
Map references: Euittpe. Siandard Time
Zones of (he World
Area:
tiihil iirva: 70.280 .sq km
Unul iimi. 68.890 sq km
awiiHiruth e umi: slightly larger than West
Virginia
Land boundaries: tmal .''60 km. UK .''60 km
Coastline: 1.448 km
Maritime claims:
continental shelf: not specified
exclusive fishinii zotw; 2(X) nm
territorial sea: 1 2 nm
International disputes: Northern Ireland
question with the UK: RtKkall continental
shelf dispute involving Denmark. Iceland, and
the UK (Ireland and the UK have signed a
htrundary agreement in the RtKkall urea)
Climate: temperate maritime; modified by
North Atlantic Current; mild winters. ctx>l
summers; consistently humid; overcast about
half the time
Terrain; mostly level to rolling interior plain
surrounded by rugged hills and low mountains;
sea cliffs on west coast
Natural resources: zinc. lead, natural gas.
petroleum, barite, copper, gypsum, linwstone.
dolomite, peat, silver
l..and use:
arahle lami: 14''''-
permanent crops: Oef
ineailiovs ami imstures: 7 1
forest and woodland: 5*14
other: 10*4
Irrigated land: NA sq km','c3174dacd5f2624c9740edda85a4865396cc7fac8099cc45141b9c387240d8e0','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2befd0a1d3e0ab86f555a242a019d3821fd91f9338a6cd403ff206773aee2a8d',1994,'IL','Israel','geography',522,'Location: Middle East, bordering the eastern
Mediterranean Sea, between Egypt and
Map references: Middle East
Area:
total area; 5,860 sq km
land area: 5,640 sq km
comparative area: slightly larger than
Delaware
note: includes West Bank, East Jerusalem,
Latrun Salient, Jerusalem No Man''s Land, and
the northwest quarter of the Dead Sea, but
excluoes Mt. Scopus
Land boundaries: total 404 km, Israel 307
km, Jordan 97 km
Coastline: 0 km (landlocked)
Maritime claims: none; landlocked
International disputes: West Bank and Gaza
Strip are Israeli occupied with interim status
subject to Israeli/Palestinian negotiations —
final status to be determined
Climate: temperate, temperature and
precipitation vary with altitude, warm to hot
summers, cool to mild winters
Terrain: mostly rugged dissected upland,
some vegetation in west, but barren in east
Natural resources: negligible
Land use:
arable land: 27%
permanent crops: 0%
meadows and pastures; 32%
forest and woodland: 1%
other; 40%
Irrigated land: NAsqkm','c9de2288d75862930919a9822484d7c9d3d6b6c0472a21380f93fde95827d3c2','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8527dfb98e17e96dd6e3c14c481eb99ed9e7739d605658b42f446c25a1c457c',1994,'LB','Lebanon','geography',523,'Map references: Africa, Middle East,
Standard Time Zones of the World
Area:
total area: 20,770 sq km
land area; 20,330 sq km
comparative area: slightly larger than New
Location: Middle East, in the eastern
Mediterranean Sea, between Israel and Syria
Map references: Africa, Middle Ea.st,
Standard Time Zones of the World
Area:
total area: 10,400 sq km
land area: 10,230 sq km
comparative area: about 0.8 times the size of
Connecticut
Land boundaries: total 454 km, Israel 79 km,
Syria 375 km
Coastline: 225 km
Maritime claims:
territorial sea: 1 2 nm
International disputes: separated from Israel
by the 1949 Armistice Line; Israeli troops in
southern Lebanon since June 1982; Syrian
troops in northern, central, and eastern
Lebanon since October 1976
Climate: Mediterranean; mild to cool, wet
winters with hot, dry summers; Lebanon
mountains experience heavy winter snows
Terrain: narrow coastal plain; AI Biqa''
(Bekaa Valley) separates Lebanon and Anti-
Lebanon Mountains
Natural resources: limestone, iron ore, salt,
water-surplus state in a water-deficit region
Land use:
arable land: 2 1 %
permanent crops: 9%
meadows and pastures: 1%
forest and woodland; 8%
other: 61%
Irrigated land: 860 sq km ( 1989 est.)
Map references: Africa. Middle East.
Standard Time Zones of the World
.Area:
total area: 1 85. 1 80 sq km
land area: 1 84.050 sq km
coinpartuive area: slightly larger than North
Dakota
note: includes 1.295 sq km of Israeli-occupied
territory
Land boundaries; total 2.25.1 km, Iraq 605
km. Israel 76 km. Jordan 375 km. Lebanon .175
km. Turkey 822 km
Coastline: 193 km
Maritime claims:
contiguous zone: 4 1 nm
territorial sea: ,15 nm
International disputes; separated from Israel
by the 1949 Armistice Line; Golan Heights is
Israeli occupied; Hatuy question with Turkey:
periixlic disputes with Iraq over Euphrates
water rights; ongoing dispute over water
development plans by Turkey for the Tigris
and Euphrates Rivers; Syrian troops in
northern Lebanon since October 1976
Climate: mostly desert; hot, dry. sunny
summers (June to August) and mild, rainy
winters (December to February) along coast
Terrain; primarily semiarid and desert
plateau: narrow coastal plain; mountains in
west
Natural resources: petroleum, phosphates.
chrome and manganese ores, asphalt, iron ore,
riick salt, marble, gypsum
Land use:
arable land: 28%
pemuinent crops: 3%
meadows and luistures: 46%
forest and wiHxlland: 3%
other: 20%
Irrigated land: 6.7(X) sq km ( 1989)
382
Location; Ceniral Asia, between Uzbekistan
and Cliinu
Map references: Asia. Cunnttonweulth of
Independent States — Central Asian States,
Standard TirriC Zones of the World
Area:
loml area: 1 43, 1 (K) sq km
fain/ area: 142,7(X)sqkm
amiiHtntiive area: slightly smaller than
Wisconsin
Land boundaries: total .3,65 1 km,
Afghanistan 1,206 km, China 414 km,
Kyrgyzstan K70 km, Uzbekistan l,lol km
Coastline: Okm(landUKked)
Maritime claims; none: landkx’ked
Intemationai disputes: boundary with China
in dispute: territorial dispute with Kyrgyzstan
on northern Umndary in Isfara Valley area;
Afghanistan''s and other foreign support to
Tajik rebels based in northern Afghanistan
Climate: midlatitudc continental, hot
summers, mild winters; semiarid to polar in
Pamir Mountains
Terrain: Pamir and Aluy Mountains
dominate landscape: w''cstem Fergana Valley in
north, Kofamihon and Vakhsh Valleys in
southwest
Natural resources: significant hydropower
potential, some petroleum, uranium. mcKury,
brown co»»l. lead, zinc, antimony, tungsten
Land use:
artihle land: 6?{-
/tertnanenl cropx: (KF
meatlows and pastures: 23''1-
forest ant'' nvodlanil: iVi
other: 71''!''
Irrigated land; 6,940 sq km (1990)','b8f41a23bf34a7623a387950d63b42a3138f1047ba0b22db7b27a208ea8708d8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82a8266fda715612834d77ab0dac79c0cc765df58f73d880ed4cecf5e77dc4ce',1994,'JE','Jersey','geography',524,'Land boundaries: total 1 ,006 km, Egypt 255
km, Gaza Strip 5 1 km, Jordan 238 km,
Lebanon 79 km, Syria 76 km. West Bank 307
km
Coastline: 273 km
Maritime claims:
continental shelf: to depth of exploitation
territorial sea: 12 nm
International disputes: separated from
Lebanon, Syria, and the West Bank by the 1949
Armistice Line; differences with Jordan over
the location of the 1949 Armistice Line that
separates the two countries; the Gaza Strip and
Jericho, formerly occupied by Israel, are now
administered by the Palestinian Authority;
other areas of the West Bank outside Jericho
are Israeli occupied; Golan Heights is Israeli
occupied; Israeli troops in southern Lebanon
since June 1982; water-sharing issues with
Location: Western Europe, 27 km from
France in the English Channel
Map references; Europe
Area:
total area; 1 17 sq km
land area; 1 17 sq km
comparative area; about 0.7 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 70 km
Maritime claims:
exclusive fishing zone; 200 nm
territorial sea; 3 nm
International disputes: none
Climate: temperate; mild winters and cool
summers
Terrain: gently rolling plain with low. rugged
hills along nonh coast
Natural resources: agricultural land
Land use:
arable land; 57^
permanent crops; NA9I-
meadows and fiastures; NA*^
forestand wtuHlIend; NA*^
other; NA%
Irrigated land: NA sq km
Location: Oceania. Polynesia, in the North
Pacific Ocean, 1,430 km west-southwest of
Honolulu, about one-third of the way between
Hawaii and the Marshall Islands
Map references: Oceania
Area:
total area: 2.8 sq km
land area: 2.8 sq km
comparative area: about 4.7 times the size of
The Mall in Washington. DC
Land boundaries: 0 km
Coastline: 10 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to depth of
exploitation
exclusive economic zone: 200 nni
territorial sea: 12 nm
Inlernadonai disputes: none
Climate: tropical, but generally dry;
consistent northeast trade winds with little
seasonal temperature varation
Terrain; mostly flat with a maximum
elevation of 4 meters
Natural resources: guano (deposits worked
until about 1890)
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0^.
other: 100%
Irrigated land: Osqkm
Land boundaries: total 464 km. Iraq 242 km,
Saudi Arabia 222 km
Coastline: 499 km
Maritime claims:
continenuil she{f: not specified
territorial xea: 1 2 nm
International disputes: in April 1991 Iraq
officially accepted UN Security Council
Resolution 687, which demands ihol Iraq
accept the inviolability of the boundary set
forth in its 1963 agreement with Kuwait,
ending earlier claims to Bubiyan and Warbah
islands, or to all of Kuwait; the 20 May 1993
final report of the UN Iraq/Kuwait Boundary
Demarcation Commission was welcomed by
the Security Council in Resolution 833 of 27
May 1993. which also reaffirmed that the
decisions of the ctrmmission on the boundary
were final, bringing to a completion the official
demarcation of the Iraq-Kuwait boundary;
Iraqi officials still refuse to unconditionally
recognize Kuwaiti sovereignty of the
inviolability of the UN demarcated tnnder;
ownership of Qaruh and Umm ul Maradim
islands disputed by Saudi Arabia
Climate: dry desert; intensely hot summers;
short, cool winters
Terrain: flat to slightly undulating desert
plain
Natural resources: petroleum, fish, shrimp,
natural gas
Land use:
arable land: 09f-
permanent crops:
meadows and itastures: g*?-
forest and woodland: 0%
other: 92*^
Irrigated land: 20 sq km (1989 est.)
Land boundarks: Okm
Coastline: 2.2.54 km
MarMnw cWms;
exclusive econoinic tone; 200 nm
territorial tea; 1 2 nm
International dhputes: none
Climate: tropical; modirietl hy southeast trade
winds; hot, humid
Terrain: coastal plains with interior
nusuntains
Natnral reMNirces; nickel, chntme, imn,
cnhall. manganese, silver, gold, lead, copper
LandiMe:
artihle lami; tFr
/lerniaiiriit crops; (Kf
iiie<ulo\\i t aiul pastures; I4C(
forest and wtHHiland; 5 1
other; .f.Srj
Irrigated land: NA sq km
Land boundaries: total 1 ,04S km, Austria
262 km, Croatia SOI km, Italy 199 km,
Hungary 83 km
Coastline: 32 km
Maritime claims;
continental shelf; 200-m depth or to depth of
exploitation
territorial sea; 1 2 nm
International disputes: dispute with Croatia
over fishing rights in the Adriatic and over
some border areas; the Ixirder issue is currently
under negotiation
Climate; Mediterranean climate on the coast,
continental climate with mild to hot summers
and cold winters in the plateaus and valleys to
the east
Terrain: a short coastal strip on the Adriatic,
an alpine mountain region adjacent to Italy,
mixed mountain and valleys with numerous
rivers to the east
Natural resources: lignite coal, lead, zinc,
mercury, uranium, silver
Land use:
arable land; 10%
permanent crops; 2%
meadows and pastures; 20%
forest and woodland; 45%
other: 23%
Irrigated land; NA sq km
Land boundaries: total 535 km,
Mozambique 105 km. South Africa 430 km
Coastline: 0 km (landlocked)
Maritime claims: none; landlocked
International disputes; Swaziland wants to
reincorporate territory along the South African
border; Mbabane has asked South Africa to
open negotiations on border adjustments
Climate: varies from tropical to near
temperate
Terrain; mostly mountains and hills; some
moderately sloping plains
Natural resources: asbestos, coal, clay,
cassiterite, hydropower, forests, small gold and
diamond deposits, quarry stone, and talc
Land use:
arable land; 8%
permanent crops; NA%
meadows and pastures; 67%
forest and woodland: 6%
other; NA%
Irrigated land: 620 sq km (1989 est.)','af91168f2e52ea170ded0d7428dbefe5a1c63e8546a85d7e355200ee701235a6','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1ce6452a0855e2390adc93398aae079b73c8c1c7125e39b24b8bb4a010bfef0',1994,'JO','Jordan','geography',525,'Climate: temperate; hot and dry in southern
and eastern desert areas
Terrain: Negev desert in the south; low
coastal plain; central mountains; Jordan Rift
Valley
Natural resources; copper, phosphates,
bromide, potash, clay, sand, sulfur, asphalt,
manganese, small amounts of natural gas and
crude oil
Land use:
arable land: 17%
permanent crops: 5%
meadows and pastures: 40%
forest and woodland: 6%
other; 32%
Irrigated land: 2, 1 40 sq km ( 1 989)
l..ocation: Middle East, between Israel and','086b574be78614b145f5db1c11908e1460f3735cbdd5aafc0f5e667a0f1fe4e5','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aeaeda55ed5eff66052ddc02094dfa9267f56a3f1d3095a13e4500e6a6c96f62',1994,'IT','Italy','geography',530,'Location: Southern Europe, a peninsula
extending into the central Mediterranean Sea
Map references: Africa, Europe, Standard
Time Zones of the World
Area:
total area: 301 ,230 sq km
land area: 294,020 sq km
comparative area: slightly larger than Arizona
note: includes Sardinia and Sicily
Land boundaries: total 1 ,899.2 km, Austria
430 km, France 488 km. Holy See (Vatican
City) 3.2 km, San Marino 39 km, Slovenia 199
km, Switzerland 740 km
Coastline: 4,996 km
Maritime claims:
continental shelf: 200-m depth or to depth of
exploitation
territorial sea: 1 2 nm
International disputes: none
Climate; predominantly Mediterranean;
Alpine in far north; hot, dry in south
Terrain; mostly rugged and mountainous;
some plains, coastal lowlands
Natural resources: mercury, potash, marble,
sulfur, dwindling natural gas and crude oil
reserves, fish, coal
Land use:
arable land: 32%
permanent crops: 10%
meadows and pastures: 17%
forest and woodland: 22%
other: 19%
Irrigated land: 31,000 sq km (1989 est.)','635e0b7c31fdc15c2b41f82c8385460491f9283aff38ed18b6e7ef881ddcaab3','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5d017215a26f0cb2b69ae76061c3058553dfcdaabe4441217bcfc94932b28a2',1994,'SA','Saudi Arabia','geography',541,'Map references: Africa. Mid He East.
Standard Time Zones of the World
Area:
total area: 89.2 1 sq km
lanti area: 88,884 sq km
conifHtrative area: slightly smaller than
Indiana
Land houndaries: total 1,619 km, Iraq 181
km. Israel 2.38 km, Saudi Arabia 728 km. Syria
.37.5 km. West Bank 97 km
Coastline; 26 km
Maritime claims:
territorial sea: ,3 nm
International disputes: differences with
Israel over the kKation of the 1949 Armistice
Line that separates the two countries; water-
sharing issues with Israel
Climate: mostly arid desert: rainy sea.son in
west (November to April)
Terrain: mostly desert plateau in east,
highland area in west; Great Rift Valley
separates East and West Bunks of the Jordan
River
Natural resources; phosphate.s, potash, shale
oil
Land use;
arable land: a''Jf
/temianent crops: ().,59f
meadows and pastures: !''/(■
forest and wiHHilaiid:
other: 94Cf
Irrigated land: .570 sq km ( 1989 est.)
Map references: Middle East, Standard Time
Zones of the World
Area:
total area: 1 1 ,(XX) sq km
land area: 1 1 ,000 sq km
comparative area: slightly smaller than
Connecticut
Land boundaries: total 60 km. Saudi Arabia
60 km
Coastline; 563 km
Maritime claims:
continental shelf: not specified
exclusive economic zone: 200 nm
territorial .veo; 1 2 nm
International disputes: territorial dispute
with Bahrain over the Hawar Islands; maritime
boundary with Bahrain
Climate: desert; hot, dry; humid and sultry in
summer
Terrain; mostly flat and barren desert
covered with loose sand and gravel
Natural resources: petroleum, natural gas.
fish
Land use;
arable land: 0%
permanent crops: 09f
meadows and pastures: 5%
forest and woodland: 0%
other: 95%
Irrigated land; NA sq km
IxKalion: Southern Africu. in the western
Indian Ocean, 750 km cast of Madagascar
Map references; World
Area:
total area: 2,5 10 sq km
land area: 2,5(K) sq km
comparative area: slightly smaller than Rhode
Island
l,<Bnd boundaries: 0 km
Coastline: 201 km
Maritime claims:
exclusive economic zone: 2(X) nm
territorial sea: 1 2 nm
International disputes: none
Climate: tropical, hut moderates with
elevation; ctxil and dry from May to
November, hot and rainy from November to
April
Terrain; mostly rugged and mountainous;
fertile lowlands along coast
Natural resources; fish, arable land
Land use;
arahle land: 20%
permanent crops: 2%
meadows and pastures: 4%
forest and woodland: 55%
other: 50%
Irrigated land; 60 sq km (I989cst.)
Location: Middle East, between the Red Sea
and the Persian Gulf
Map references: Africa, Middle East,
Standard Time Zones of the V/orld
Area:
total area: 1,960,582 sq km
land area: 1,960.582 sq km
comparative area: .''.lightly less than one-
fburth the size of the US
Land boundaries: total 4,415 km, Iraq 814
km, Jordan 728 km, Kuwait 222 km. Oman 676
km, Qatar 60 km, UAE 457 km, Yemen 1 ,458
km
Coastline: 2,640 km
Maritime claims;
contiguous zone: 18 nm
continental shelf: not specified
territorial sea: 12 nm
International disputes: large section of
boundary with Yemen not defined; status of
boundary with UAE not final; Kuwaiti
ownership of Qaruh and Umm al Maradim
islands is disputed by Saudi Arabia
Climate; harsh, dry desert with great
extremes of temperature
Terrain: mostly uninhabited, sandy desert
Natural resources: petroleum, natural gas.
iron ore, gold, copper
Land use:
arable land: I %
permanent crops: 0%
meadows and pastures: 399f-
forest and wooill/nid: 1 ''7r
other: 59%
Irrigated land: 4,350 sq km (1989 est.)','1683766011c0ad76f2763a01240e45631064fd3efeb4ffef322a0f61827855f9','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c457f390bb1ed667ca2fd6609b2ee950e00d8ff4b2acefb8dc71012ccc582b88',1994,'KZ','Kazakhstan','geography',543,'Location: Southern Africa, in the central
Mozambique Channel about one-third of the
way between Madagascar and Mozambique
Map references: Africa
Area:
total area: 4.4 sq km
land area: 4.4 sq km
comparative area: about 7.5 times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 24.1 km
Maritime claims:
contiguous zone: 1 2 nm
continental shelf: 200-m depth or to depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: claimed by
Map references: Asia, Commonwealth of
Independent States — Central Asian States,
Standard Time Zones of me World
Area:
total area: 198,500 sq km
land area: 1 9 1 ,300 sq km
comparative area: slightly smaller than South
Dakota
Land boundaries: total 3,878 km, China 858
km, Kazakhstan 1 ,05 1 km, Tajikistan 870 km,
Uzbekistan 1 ,099 km
Coastline: 0 km (landlocked)
Maritime claims: none; landlocked
Internationa! disputes: territorial dispute
with Tajikistan on southwestern boundary in
Isfara Valley area
Climate: dry continental to polar in high Tien
Shan; subtropical in southwest (Fergana
Valley); temperate in northern foothill zone
Terrain: peaks of Tien Shan rise to 7,000
meters, and associated valleys and basins
encompass entire nation
Natural resources: small amounts of coal
abundant hydroelectric potential; significant
deposits of gold and rare earth metals; locally
exploitable coal, oil and natural gas; other
deposits of nepheline, mercury, bismuth, lead,
and zinc, natural gas, oil, nepheline, rare earth
metals, mercury, bismuth, gold, lead, zinc,
hydroelectric power
Land use:
arable land: 7%
permanent crops: NEGL%
meadows and pastures: 42%
forest and woodland: 0%
other: 51%
Irrigated land: 10,320 sq km (1990)
Location: Southeastern Asia, between
Vietnam and Thailand
Map references: Southeast Asia, Standard
Time Zones of the World
Area:
total area: 236,800 sq km
land area: 230,800 sq km
comparative area: slightly larger than Utah
Land boundaries: total 3,083 km, Burma
235 km, Cambodia 541 km, China 423 km,
Thailand 1,754 km, Vietnam 2,130 km
Coastline: 0 km (landlocked)
Maritime claims: none: landlocked
International disputes: boundary dispute
with Thailand
Climate: tropical monsoon: rainy season
(May to November): dry season (December to
April)
Terrain: mostly rugged mountains; some
plains and plateaus
Natural resources: timber, hydropower,
gypsum, tin, gold, gemstones
Land use:
arable land: 4%
permanent crops: 0%
meadows and pastures: 3%
forest and woodland: 58%
other: 35%
Irrigated land: 1 ,2(K) sq km ( 1989 est.)','cc1af6274366188e6e22491c281ae43ed3f21073029951a6f73a180edf713939','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7494c7bef931a3403f1616d920d8c8bfc7dec83d9042d9ad3746d472a726bc4',1994,'KE','Kenya','geography',546,'Location: Eastern Africa, bordering the
northwestern India Ocean between Tanzania
and Somalia
Map references: Africa. Standard Time
Zones of the World
Area:
lolal area: 582,650 sq km
land area: 569.250 sq km
comparative area: slightly more than twice the
size of Nevada
Land boundaries: total .L446 km. Ethiopia
8.50 km, Somalia 682 km, Sudan 2,52 km.
Tanzania 769 km, Uganda 9.5.5 km
Coastline: 5.56 km
Maritime ciaims:
e.xcliii-ive economic tone: 200 nm
territorial sea: 1 2 nm
International disputes: administrative
boundary with Sudan does not coincide with
international boundary; possible claim by
Somalia based on unification of ethnic Somalis
Climate: varies from tropical along coast to
arid in interior
Terrain: low plains rise to central highlands
bisected by Great Rift Valley; fertile phtteau in
west
Natural resources: gold, limestone, soda ash.
salt barytes, rubies, lluorspar, garnets, wildlife
I.and use:
arable land:
permanent crops: I ''f
meadows and pastures: T7c
forest and woodland: We
other: 859{
Irrigated land: 520 sq km (1989)','aaaca3d1cf26eb2a633d8a8025b4f681b901b0f202f26c817078c6fb41e42fb7','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c768f0817f57cc2ec4b5582ccfe50adea1f69ab0ce27675d17256a96b680ed7',1994,'KI','Kiribati','geography',554,'Location: Oceania, Micronesia, in the North
Pacific Ocean, 1 ,600 km south-southwesl of
Honolulu, about halfway between Hawaii and','57b15891b63648237154fcfe64017142d815874244ccd6be49b1ac3a48979d99','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('773b0cc6c089238483d0eb953b723e70ea82dce5608fecbcf063e4fcfb116709',1994,'KW','Kuwait','geography',560,'Location: Middle East, at the head of the
Persian Gulf, between Iraq and Saudi Arabia
Map references: Africa, Middle East.
Standard Time Zones of the World
Area:
total area: 1 7,820 sq km
land area: 1 7.820 sq km
comiHirutive area: slightly smaller than New','9beb93ed43c95b04b1b7ce8d533729ecbf782c772000634d143b4bfec75d3a68','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03a569b372c736b8d6d24adc2946877a9d0432c289fab633c8961a9fe110c747',1994,'LV','Latvia','geography',565,'Location: Eastern Europe, bordering on the
Baltic Sea, between Sweden and Russia
Map references: Arctic Region, Asia,
Europe, Standard Time Zones of the World
Area;
total area: 64. 1 00 sq km
land area: 64. 1 00 sq km
comparative area: slightly larger than West
Virginia
Land boundaries: total 1 ,078 km, Belarus
141 km, Estonia 267 km, Lithuania 453 km,
Russia 217 km
Coastline: 531 km
Maritime claims;
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: the Abrene section of
border ceded by the Latvian Soviet Socialist
Republic to Russia in 1944
Climate: maritime; wet, moderate winters
Terrain: low plain
Natural resources: minimal; amber, peat,
limestone, dolomite
Land use:
arable land: 27%
permanent crops: 0%
meadows and pastures: 1 3%
forest and woodland: 39%
other: 21%
Irrigated land: 1 60 sq km ( 1990)','993f563cd2e689b06da403ccd3e8fc7540ceafafff66ea11359e5080bf848779','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d89541946179d240c20fe465d8654e7d7301a3eda7acad1e504b4ab3bbdc24a4',1994,'ZA','South Africa','geography',575,'Map references; Africa, Standard Time
Zones of the World
Area:
total area: 30,350 sq km
land area: 30,350 sq km
comparative area: slightly larger than
Maryland
Land boundaries: total 909 km. South Africa
909 km
Coastline: 0 km (landlocked)
Maritime claims: none; landlocked
International disputes: none
Climate: temperate; cool to cold, dry winters;
hot. wet summers
Terrain: mostly highland with some plateaus,
hills, and mountains
Natural resources: water, agricultural and
grazing land, some diamonds and other
minerals
Land use;
arable land; 10%
permanent crops: 0%
meadows and pastures: 66%
forest and woodland; 0%
other: 24%
Irrigated land; NA .sq km
Map references; Africa, Standard Time
Zones of the World
Area:
total area: 825,418 sq km
land area: 825,418 sq km
comparative area; slightly more than half the
size of Alaska
Land boundaries: total 3,824 km, Angola
1 ,376 km, Botswana 1 ,360 km. South Africa
855 km, Zambia 233 km
Coastline: 1,572 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea; 1 2 nm
International disputes: short section of
boundary with Botswana is indefinite;
quadripoint with Botswana, Zambia, and
Zimbabwe is in disagreement; dispute with
South Africa over Walvis Bay and 1 2 offshore
islands has been resolved and these territories
were transferred to Namibian sovereignty on 1
March 1994
Climate: desert; hot, dry; rainfall sparse and
erratic
Terrain: mostly high plateau; Namib Desert
along coast; Kalahari Desert in east
Natural resources: diamonds, copper,
uranium, gold, lead, tin, lithium, cadmium,
zinc, salt, vanadium, natural gas. fish;
su..pected deposits of oil, natural gas, coal, iron
ore
Land use:
arable land: 1 %
permanent crops: 0%
meadows and pastures: 64%
forest and woodland: 22%
other: 13%
Irrigated land: 40 sq km ( 1989 est.)
Location: Southern Africa, at the extreme
southern tip of the continent
Map references; Africa. Standard Time
Zones of the World
Area:
total area: 1.21 9.9 1 2 sq km
land area: 1 .2 1 9.9 1 2 ,sq km
comparative area: slightly less than twice the
size of Texas
note: includes Prince Edward Islands (Marion
Island and Prince Edward Island)
Land boundaries; total 4.7.50 km. Botsu ana
1 ,840 km, Lesotho 909 km. Mozambique 491
km, Namibia 855 km, Swaziland 430 km,
Zimbabwe 225 km
Coastline: 2.798 km
Maritime claims:
continental shelf: 200-m depth or to depth of
exploitation
exclusive fishing zone: 200 nm
territorial .sea: 1 2 nm
International disputes: the dispute with
Namibia over Walvis Bay and 12 offshore
islands has been resolved and these territories
were transferred to Namibian sovereignly on 1
March 1994; Swaziland has asked South
Africa to open negotiations on reincorporating
some nearby South African territories that are
populated by ethnic Swazis or that were long
ago part of the Swazi Kingdom
Climate; mo,stly semiarid; subtropical along
coast; sunny days, cool nights
Terrain; vast interior plateau rimmed by
rugged hills and narrow coastal plain
Natural resources: gold, chromium.
antimony, coal, iron ore. manganese, nickel,
phosphates, tin. uranium, gem diamonds.
platinum, copper, vanadium, salt, natural gas
Land use:
arable land: 1097
/terinanenr crops: 1 97
meadows and pastures: 6597
forest and woodland: 397
other: 2 1 97
Irrigated land: 1 1 ,280 sq km ( 1 989 est.)','5415ece123394ed2d47a0b154fe5c03f2954d07a9b84ae0c8f38e5de13ab9471','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ea12b2ccbe1ae37bc1ceaef90c11811f2e946e27e152c735e0f0af4ec7494d6',1994,'LR','Liberia','geography',581,'Location: Western Africa, bordering the
North Pacific Ocean between Cote d’Ivoire
and Sierra Leone
Map references: Africa, Standard Time
Zones of the World
Area:
total area: 1 1 1 ,370 sq km
land area: 96,320 sq km
comparative area: slightly larger than
Tennessee
Land boundaries: total 1,585 km, Guinea
563 km, Cote d’Ivoire 716 km. Sierra Leone
306 km
Coastline: 579 km
Maritime claims:
continental shelf: 200-m depth or to depth of
exploitation
territorial sea: 200 nm
International disputes: none
Climate: tropical; hot, humid; dry winters
with hot days and cool to cold nights; wet.
cloudy summers with frequent heavy showers
Terrain: mostly flat to rolling coastal plains
rising to rolling plateau and low mountains in
northeast
Natural resources: iron ore. timber,
diamonds, gold
Land use:
arable land: 1 %
permanent crops: 3%
meadows and pastures: 2%
forest and woodland: 39%
other: 55%
Irrigated land: 20 sq km (1989 est.)','e9bb37556a652a00a89b257518b5c581756a74a92bd29b061368abd4427b2eb8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcd78972faf947e6db8eee657c9248bbd42eac1aa7052a867ea7c18a93397d8f',1994,'LY','Libya','geography',587,'Location: Northern Africa, on the southern
coast of the Mediterranean Sea, between Egypt
and Tunisia
Map references: Africa, Standard Time
Zones of the World
Area:
total ami: 1 ,759,.‘i40 sq km
lantl area: 1 ,759,540 sq km
comparative area: slightly larger than Alaska
Land boundaries; total 4..583 km, Algeria
982 km, Chad 1,055 km, Egypt 1 ,150 km,
Niger ,554 km. Sudan .58.5 km, Tunisia 459 km
Coastline: 1.770 km
Maritime claims;
territorial sea: 1 2 mn
Gulf of Sidra closiiin line; 52 degrees 50
minutes north
International disputes; the International
Court of Justice (ICJ) ruled in February 1994
that the 100,000 sq km Aozou Strip between
Chad and Libya belongs to Chad, and that
Libya mu.st withdraw from it by 51 May 1994:
Libya had withdrawn its forces in response to
the ICJ ruling, but as of June 1994 still
maintained an airfield in the disputed area:
maritime boundary dispute with Tunisia;
claims part of northern Niger and part of
southeastern Algeria
Climate; Mediterranean along coast; dry,
extreme desert interior
Terrain: mostly barren, flat to undulating
plains, plateaus, depressions
Natural resources; petroleum, natural gas,
gypsum
Land use:
anihic land: 2%
permanent crops: 09f
meadows and fHistiires: 89i-
forest and woodland: O*^
other: 909f
Irrigated land: 2,420 sq km (1989 est.)
Map references: Africa, Standard Time
Zones of the World
Area:
total area: 163,610 sq km
latularea; I53,.360sqkm
amiHtraih''e area: slightly larger than Georgia
Land boundaries: total 1,424 km, Algeria
965 km. Libya 459 km
Coastline: 1.148 km
Maritime claims:
territorial sea; 12 nm
International disputes; maritime boundary
dispute with Libya; land boundary di.spute with
Algeria settled in 1993
Climate: temperate in north with mild, rainy
winters and hot, dry summers: desert in south
Terrain: mountains in north: hot. dry central
plain; semiarid south merges into the Sahara
Natural resources: petroleum, phosphates.
iron ore. lead, ’.inc, salt
Land use:
arable land; 20''?-
peisminent crops: lOri-
meadows and /Mistures: 19C(
forest and woodland: 4'';i-
other: 47rf
Irrigated land: 2.750 sq km (1989)
Location: Southwestern Asia (that part west
of the Bosporus is sometimes included with
Europe), bordering the Mediterranean Sea and
Black Sea, between Bulgaria and Iran
Map references: Africa, Europe, Middle
East, Standard Time Zones of the World
Area;
total area: 780,580 sq km
land area: 770,760 sq km
comparative area: slightly larger than Texas
Land boundaries: total 2,627 km, Armenia
268 km, Azerbaijan 9 km, Bulgaria 240 km,
Georgia 252 km, Greece 206 km, Iran 499 km,
Iraq 33 1 km. Syria 822 km
Coastline: 7,200 km
Maritime claims:
exclusive economic zone: in Black Sea only —
to the maritime boundary agreed upon with the
former USSR
territorial sea: 6 nm in the Aegean Sea.
12 nm in the Black Sea and in the
Mediterranean Sea
International disputes: complex maritime
and air (but not territorial) disputes with
Greece in Aegean Sea; Cyprus question; Hatay
question with Syria; ongoing dispute with
downstream riparians (Syria and Iraq) over
water development plans for the Tigris and
Euphrates Rivers
Climate: temperate: hot. dry summers with
mild, wet winters: harsher in interior
Terrain: mostly mountains; narrow coastal
plain; high central plateau (Anatolia''
Natural resources: antimony, coal,
chromium, mercury, copper, borate, sulphur,
iion ore
Land use:
arable land: 30%
permanent crops: 4%
meadows and pastures: 1 2%
forest and woodland: 26%
other: 28%
Irrigated land: 22.200 sq km (1989 est.)','3a6d72032826cc29ccd1302ff0840a9eb850b8fd63c05386f4ca72c10bd3ed87','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94ea2204c7c8c08e116d0105a818ae34eff642f8889985af72ef7eecefd2d3c3',1994,'LI','Liechtenstein','geography',593,'Location: Central Europe, between Austria
and Switzerland
Map references: Euro|>e, Standard Time
Zones of the World
Area:
total area: I60sqkm
land area: I60sqkm
comparative area: about 0.9 times the size of
Washington. DC
Land boundaries: total 78 km, Austria 37
km, Switzerland 41 km
Coastline: 0 km (landlocked)
Maritime claims: none; landlocked
International disputes: claims 620 square
miles of Czech territory confiscated from its
royal family in 1918; the Czech Republic
insists that restitution does not go back before
February 1948, when the Communists seii''ed
power
Clinrate: continental; cold, cloudy winters
with frequent snow or rain; cool to moderately
warm, cloudy, humid summers
Terrain; mostly mountainous (Alps) with
Rhine Valley in western third
Natural resources: hydroelectric potential
Land use:
arable land: 25%
permanent crops: 0%
meadows and pastures: 38%
forest and woodland: 19%
other: 18%
Irrigated land: NAsqkm','0c063037e4e38025cfef64a1babd15bf19b7f5feb9d9346d12c7ee9295105a4c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0dc5c41346cac617e5a444aca595677c266bef561b73ebc3c56d80347e82dc67',1994,'LT','Lithuania','geography',600,'Location; Eastern Europe, bordering the
Bultie Sea. between Sweden and Russia
Map relerence.s: Asia, Europe. Standard
Time Zones of the World
Area;
total area: b.S.StH) sq km
land ami: 65.200 sq km
comimmiive area: slightly larger than West
Virginia
Land boundaries: total 1 ,27.5 km. Relariis
502 km, Latvia 45.5 ktn. Poland 9 1 km, Russia
(Kaliningrad) 227 km
Coastline: 1 08 km
Maritime claims;
territorial , lea: 12 nm
International disputes: dispute with Russia
(Kaliningrad Oblast) over the position of the
Nemunas (Neinen) River border presently
located on the Lithuanian hank and not in
midriver as by international standards
Climate: maritime; wet. moderate winters and
summers
Terrain: lowland, many scattered small lakes,
fertile soil
Natural resources: peat
Land use:
arable land:
perimiiieiit cro/i v- 0''7r
meadows and iHistiires: 22.2''/c
forest and woodlattd: l6..5''/(
other: 12,4''/}
Irrigated land: 4.50 sq km ( 1990)','30f3042824c36ceeefd7da14de88ceea0565750be0cce0f97bc50fb832e50577','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f182c36e399fc6f8c69a55eb1fc30934fa8794746b226429036e9d182e9722b6',1994,'LU','Luxembourg','geography',604,'Location: Western Europe, between Belgium
and Germany
Map references: Europe. Standard Time
Zones of the World
Area:
total area; 2,586 sq kiti
land area: 2,.586 sq km
comparative area; slightly smaller than Rhode
I.sland
Land boundaries: total 359 km. Belgium 148
km, France 73 km, Germany 138 km
Coastline: 0 km (landlocked)
Maritime claims: none; landlocked
International disputes: none
Climate: modified continental with mild
winters, cool summers
Terrain: mostly gently rolling uplands w''ith
broad, shallow valleys; uplands to slightly
mountainous in the north; steep slope down to
Moselle floodplain in the southeast
Natural resources: iron ore (no longer
exploited)
Land use:
arable land; 24%
permanent crops; 1 %
meadows and pastures; 20%
forest and woodland: 2 1 %
other; 34%
Irrigated land: NA sq km','fae7980fb547ccdd1865628148636eff339a6055c090ec976aeb484ed44689ef','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0ef403532e60711bdddfc00fb7c3630cef745e44b5aeb5f6945cea4f4eab2a5',1994,'MW','Malawi','geography',610,'Location: Southern Africa, between
Mozambique and Zambia
Map references: Africa, Standard Time
Zones of the World
Area:
total area: 1 1 8,480 sq km
land area: 94,080 sq km
comparative area: slightly larger than
Pennsylvania
Land boundaries: total 2,881 km,
Mozambique 1,569 km, Tanzania 475 km,
Zambia 837 km
Coastline: 0 km (landlocked)
Maritime claims: none; landlocked
International disputes: dispute with
Tanzania over the boundary in Lake Nyasa
(Lake Malawi)
Climate: tropical: rainy season (November to
May); dry season (May to November)
Terrain; narrow elongated plateau with
rolling plains, rounded hills, some mountains
Natural resources: limestone, unexploited
deposits of uranium, coal, and bauxite
Land use:
arable land: 25%
permanent crops: 0%
meadow s and pastures: 20%
forest and woodland: 50%
other: 5%
Irrigated land: 200 sq km (1989 est.)','4701aa15c81381acefad653d2862f4eb7a06722ccd0df543e4b86ce8ece305d8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b0d62b9ace03ba41c88a1f399466d416cf2f3feb525f42e0a9f0ffe29747a09',1994,'ZW','Zimbabwe','geography',617,'Location: Southeastern Asia, bordering the
South China Sea, between Vietnam and
Map references: Africa, Standard Time
Zones of the World
Area:
total area: 752,610 sq km
land area; 740,720 sq km
comparative area: slightly larger than Texas
Land boundaries: total 5,664 km. Angola
1,110 km, Malawi 837 km, Mozambique 419
km, Namibia 233 km. Tanzania 338 km. Zaire
1 ,930 km, Zimbabwe 797 km
Coastline: 0 km (landlocked)
Maritime claims: none; landlocked
International disputes: quadripoint with
Botswana. Namibia, and Zimbabwe is in
disagreement; Tanzania-Zaite-Zambia tripoint
in Lake Tanganyika may no longer be
indefinite since it is report ''d that the indefinite
section of the Zaire-Zambia boundary has been
settled
Climate: tropical; modified by altitude; rainy
season (October to April)
Terrain: mostly high plateau with some hills
and mountains
Natural resources: copper, cobalt, zinc, lead,
coal, emeralds, gold, silver, uranium,
hydropower potential
Land use:
arable land: 7%
permanent crops; 0%
meadows and pastures: 47%
forest and woodland; 27%
other; 19%
Irrigated land: 320 sq km (1989 est.)
Location: Southern Africa, between South
Africa and Zambia
Map references: Africa, Standard Time
Zones of the World
Area:
total area: 390,580 sq km
land area: 386,670 sq km
comparative area: slightly larger than
Montana
Land boundaries: total 3,066 km, Botswana
813 km, Mozambique 1,231 km. South Africa
225 km, Zambia 797 km
Coastline: 0 km (landlocked)
Maritime claims; none; landlocked
Internationa! disputes: quadripoint with
Botswana. Namibia, and Zambia is in
disagreement
Climate: tropical; moderated by altitude;
rainy season (November to March)
Terrain: mostly high plateau with higher
central plateau (high veld); mountains in east
Natural resources: coal, chromium ore,
asbestos, gold, nickel, copper, iron ore,
vanadium, lithium, tin. platinum group metals
Land use:
arable land: 7%
permanent crops: NA% (cof''op a permanent
crop)
meadows and pastures: 12%
forest and woodland: 62%
other: NA%
Irrigated land: 2,200 sq Km (1989 est.)','94333e23c93f813bbabe0595895357cd056098564aa36ece9e97db38458dd4fb','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a4d70c80757788ca07580b9213ddb90391d1725fdb4eb83245593a8d7a25ccb',1994,'MX','Mexico','geography',618,'Land boundaries: total 2,669 km, Brunei
381 km, Indonesia 1,782 km, Thailand 506 km
Coastline: 4,675 km (Peninsular Malaysia
2,068 km. East Malaysia 2,607 km)
Maritime claims:
continental shelf: 200-m depth or to depth of
exploitation; specified boundary in the South
China Sea
exclusive fishing zone: 200 n.n
exclusive economic zone; 200 nm
territorial sea: 1 2 nm
International disputes: involved in a
complex dispute over the Spratly Islands with
China. Philippines, Taiwan, Vietnam, and
possibly Brunei; State of Sabah claimed by tbe
Philippines; Brunei may wish to purchase the
Malaysian salient that divides Brunei into two
parts; two islands in dispute with Singapore;
two islands in dispute with Indonesia
Climate: tropical; annual southwest (April to
October) and northeast (October to February)
monsoons
Terrain: coastal plains rising to hills and
mountains
Natural resources: tin, petroleum, timber,
copper, iron ore. natural gas. bauxite
Land use:
arable land; 3%
permanent crops: 1 0%
meadows and pastures: 0%
forest and woodland: 63%
other: 24%
Irrigated land; 3,420 sq km (1989 est.)
Location: Middle America, between
Guatemala and the US
Map references: North America, Standard
Time Zones of the World
Area;
total area: 1,972,550 sq km
land area: 1 .923.040 sq km
comparative area: slightly less than three
times the size of Texas
Land boundaries; total 4,538 km, Belize 250
km, Guatemala 962 km, US 3,326 km
Coastline: 9,330 km
Maritime claims:
contiguous Z(»ie: 24 nm
continental shelf: 200 nm or the natural
prolongation of continental margin
exclusive economic zone: 200 nm
territorial .sea: 1 2 nm
International disputes: claims Clipperton
Island (French possession)
Climate: varies from tropical to de.sert
Terrain; high, rugged mountains, low coastal
plains, high plateaus, and de.sert
Natural resources: petroleum, silver, copper,
gold, lead, zinc, natural gas. timber
Land use:
arable land: 1 29F
permanent crops: I %
meadows and pastures: 39%
forest and woodland: 24%
other: 24%
Irrigated land: 5 1,500 sq km (1989 est.)
Land boundaries: total 2,515 km, Finland
729 km, Sweden 1.619 km. Russia 167 km
Coastline: 21.925 km (includes mainland
3.419 km, large islands 2,413 km, long fjords,
numerous small islands, and minor
indentations 16.093 km)
Maritime claims:
contiguous cone: 10 nm
continental shelf; to depth of exploitation
exclusive economic zone: 200 nm
territorial sea: 4 nm
International disputes: territorial claim in
Antarctica ((Jueen Maud Land): dispute
between Denmark and Norway over maritime
boundary in Arctic Ocean between Greenland
and Jan Mayen has been settled by the
International Coun of Justice: maritime
boundary dispute with Russia over portion of
Barents Sea
Climate: temperate along coast, modified by
North Atlantic Current: colder interior: rainy
year-round on west coast
Terrain: glaciated: mostly high plateaus and
rugged mountains broken by fertile valleys:
small, scattered plains: coastline deeply
indented by fjords: arctic tundra in noith
Natural resources: petroleum, copper,
natural gas, pyrites, nickel, iron ore, zinc, lead,
fish, timber, hydropower
Land use;
arable land; 3%
permanent crops: 0%
meadows and pastures; 0%
forest and woodland: 27%
other: 70%
296
IrrHiatcd land: 9S0 sq km (1989)
Land boundaries: total 3,1 14 km, Belarus
605 km, Czech Republic 658 km, Germany
456 km, Lithuania 91 km, Russia (Kaliningrad
Oblast) 432 km, Slovakia 444 km, Ukraine 428
km
Coastline: 491 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
International disputes: none
Climate: temperate with cold, cloudy,
moderately severe winters with frequent
precipitation; mild summers with frequent
showers and thundershowers
Terrain: mostly flat plain; mountains along
southern border
Natural resources; coal, sulfur, copper,
natural gas, silver, lead, salt
Land use;
arable land: 46%
permanent crops: 1%
meadows and pastures: 13%
forest and woodland: 28%
otier: 12%
Irrigated land: 1 .000 sq km ( 1 989 est.)
Location: Caribbean, in the eastern Caribbean
Sea, about 1 10 km east and southeast of Puerto
Rico
Map rtfercncea: Central America and the
Caribbean
Area:
total area: 352 sq km
landarett: 349 sq km
comparative area: slightly less than twice the
size of Washington. DC
Land boundaries: 0km
Coastline: 188 km
MarldiiK dalms:
contiguous zone: 24 nm
continental shelf: 200-m depth or to depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 12 nm
International diepiitas: none
CHmate: subtropical, tempered by easterly
tradewinds, relatively low humidity, little
seasonal temperature variation; rainy season
May to November
Terrain: mostly hilly to rugged and
mountainous with little level land
Natural resoukces: sun, sand, sea, surf
Land use:
arable land: 15%
permanent crops: 6%
meadows and pastures: 26%
forest and woodland: 6%
other; 47%
Irrigated land: NAsqkm','21e14ddef98b760aa2848688c2f900ba266bd48fe31276907d1ea80bfb61a830','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53301ead576a16caaf4ad4081b4e108d2649aff413c58a18d130baa93c3d8e75',1994,'MV','Maldives','geography',624,'Location: Southern Asia, in the Indian Ocean
off the southwest coast of India
Map references: Asia, Standard Time Zones
of the World
Area:
total area: 300sqkm
land area; 300 sq km
comparative area; slightly more than 1 .5 times
the size of Washington, I>C
Land boundaries: 0 km
Coastline: 644 km
Maritime claims:
exclusive economic zo. t; 35-310 nm as
defined by geographic coordinates; segment of
zone coincides with maritime boundary with','e13faea0de34e938963ca299461d8a49cb090794e9a0fdfd8745ff0a3709102e','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4247dacbfe5be6a420b36d33c9c05e4da20ed8bb008291368afce51a93fc9fb9',1994,'ML','Mali','geography',625,'Location: Western Africa, between
Mauritania and Niger
Map references: Africa, Standard Time
Zones of the World
Area:
mmI area: 1.24 million sq km
land area: 1.22 million sq km
comparative area: slightly less than twice the
size of Texas
Land boundaries: total 7,243 km, Algeria
1,376 km, Burkina 1,000 km, Guinea 838 km,
Cote d''Ivoire 532 km, Mauritania 2,237 km,
Niger 821 km, Senegal 419 km
Coastline; 0 km (landlocked)
Maritime claims: none; landlocked
International disputes: the disputed
international boundary between Burkina and
Mali was submitted to the International Court
of Justice (ICJ) in October 1983 and the ICJ
issued its final ruling in December 1986, which
both sides agreed to accept: Burkina and Mali
are proceeding with boundary demarcation,
including the tripoint with Niger
Climate: subtropical to arid; hot and dry
February to June; rainy, humid, and mild June
to November; cool and dry November to
February
Terrain: mostly flat to rolling northern plains
covered by .sand; savanna in south, rugged hills
in northeast
Natural resources; gold, phosphates, kaolin.
salt, limestone, uranium, bauxite, iron ore.
manganese, tin. and copper deposits are known
but not exploited
Land use:
arable land: 2%
permanent crops: Off
meadows and pastures: 25Vc
forest and woodland: 79f
other: 66ff
Irrigated land: 50 sq km ( 1 989 est.)','c9eed912b65d6e74d05f95d9762c708eddb9b3c09b14f94e1083814b1a33c6e8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42e025b224ad775bb8c3fb30a5ef4be9936eb07b637fead5abb528b7953195e4',1994,'MT','Malta','geography',631,'Locution: Southern Europe, in the central
Mediterranean Sea, 9.3 km south of Sicily
(Italy). 290 km north of Libya
Map references: Europe. Standard Time
Zones of the World
Area:
total area; .320 sq km
/ami area; -320 sq km
comparative area; slightly less than twice the
size of Washington, DC
Land boundaries; 0 km
Coastline: 140 km
Maritime claim.3;
rontiftuoii.s cone; 24 nm
continental .shelf; 2(X)-m depth or to depth of
exploitation
e.\\clu.sive fi.shin)} cone; 2.3 nm
territorial .sea; 1 2 nm
International disputes: none
Climate: Mediterranean with mild, rainy
winters and hot. dry summers
Terrain: mostly low. r»Kky. flat to dissected
plains; many coastal cliffs
Natural resources: limestone, salt
I.and use:
arahle laiul; .38%
pennanent crop.s; .3%
ineatlows and /uistures; 0%
fore.st and woiHlIand; 0%
other; .39%-
Irrigated land: 10 sq km (1989)
Location: Western Europe, in the Irish Sea,
between Ireland and Great Britain
Map references: Europe
Area:
total area: 588 sq km
land area: 588 sq km
comparative area: nearly 3.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 1 1 3 km
Maritime claims;
e.xclusive fishing zone: 200 nm
territorial sea: 3 nm
Internationai disputes: none
Climate: cool summers and mild winters:
humid; overcast about half the lime
Terrain: hills in north and .south bi.secled by
central valley
Natural resources: lead, iron ore
Land use:
arable land: NA%
permanent crops: NA%
meadows and pastures: NA%
forest and woodland: NA%
other: NA9f (extensive arable land and forests)
Irrigated land: NA sq km','c800fcb1aa117f024f1c396b07968649ebe1450f671a9b0cb4dc3786645445be','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('728703cc6317654b3965a67aa812b832b1b07364660e2d5a47519d19a38e6054',1994,'MH','Marshall Islands','geography',638,'Note: defense is the responsibility of the UK
Location: Oceania. Micronesia, in the North
Pacific Ocean, about two-thirds of the way
between Hawaii and Papua New Guinea
Map references: Oceania, Standard Time
Zones of Ihe World
Area:
total area: 1 8 1 ,3 sq km
land area: 181,3 sq km
comparative area: slightly larger than
Washington. DC
note: includes Ihe atolls of Bikini. Eniwetak,
and Kwajalcin
Land boundaries: Okm
Coastline: 370.4 km
Maritime claims;
contiguous zone: 24 nm
e.xclu.sive economic zone: 2(X) nm
territorial sea: 1 2 nm
International disputes: claims US territory
of Wake Island
Climate: wet season May to November: hot
and humid; islands bolder typhoon belt
Terrain; low coral limestone and sand islands
Natural resources; phosphate deposits,
marine products, deep seabed minerals
Land use:
arable land: 0%
permanent crops: 60%
meadows and pastures: ()''/(
forest and woodland: 0%
other: 40%r
Irrigated land: NA sq km','8ec678e6bff399d48d68804da699a6b49c310bd87b3ad7f7e9bd0df2e231a96f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b078b54badc3e5d750bb76130662a1e79c829be237be836936ebb2d824ea2551',1994,'MQ','Martinique','geography',640,'Location: Caribbean, in the Caribbean Sea,
off the coast of Venezuela
Map references: Central America and the
Caribbean, South America
Area:
total area: 1 , 1 00 sq km
land area: 1 ,060 sq km
comparative area: slightly more than six times
the size of Washington, DC
Land boundaries: 0 km
Coastline: 290 km
Maritime ciaims:
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
Internationai disputes: none
Climate: tropical; moderated by trade winds;
rainy season (June to October)
Terrain: mountainous with indented
coastline: dormant volcano
Natural resources; coastal scenery and
beaches, cultivable land
Land use:
arable land: 1 09f-
permanent crops: 8%
meadows and pastures: i0%
forest and woodland: 26%
other: 26%
Irrigated land: 60 sq km (1989 est.)','a4e0da4f14f6c7357e1bd80e660784d935a3795bbd84035cc4d9e94a715d96f1','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60dc50dfc5bb80a70c578830a0e0ff2491f6be26f77460e7c0d34c992a6e3efa',1994,'MR','Mauritania','geography',647,'Location: Northern Africa, along the North
Atlantic Ocean, between Western Sahara and','6bf277f0e1a3ce9ed5419a298db91da5b31a95663692e3ed9550b82ef7f2336d','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc67355b3fdaf74db5a417b6c87d635719b60d467413b434851c4d7743ad4318',1994,'MU','Mauritius','geography',653,'Location: Southern Africa, in the western
Indian Ocean, 900 km east of Madagascar
Map references: Africa, Standard Time
Zones of the World
Area:
total area: 1 ,860 sq km
land area: 1,850 sq km
comparative area; slightly less than 10.5 times
the size of Washington, DC
note; includes Agalega Islands, Cargados
Carajos Shoals (Saint Brandon), and Rodrigues
Land boundaries; 0 km
Coastline: 1 77 km
Maritime claims:
contiguous zone; 24 nm
continental shelf; 200 nm or the edge of
continental margin
exclu.sive economic zone; 200 nm
territorial sea; 1 2 nm
International disputes: claims UK-
administered Chagos Archipelago, which
includes the island of Diego Garcia in UK-
administered British Indian Ocean Territory;
claims French-administered Tromelin Island
Climate: tropical modified by southeast trade
winds; warm, dry winter (May to November);
hot, wet, humid summer (November to May)
Terrain: small coastal plain rising to
discontinuous mountains encircling central
plateau
Natural resources: arable land, fish
Land use:
arable land; 54%
permanent crops; 4%
meadows and pastures: 4%
forest and woodland; 3 1 %
other; 7%
Irrigated land: 1 70 sq km ( 1 989 est.)
F.nvironment:
current issues; water pollution
natural hazards; subject to cyclones
(November to April); almost completely
surrounded by reefs
international agreements; party to —
Biodiversity, Climate Change, Endangered
Species, Environmental Modification,
Hazardous Wastes, Marine Life Conservation,
Nuclear Test Ban, Ozone Layer Protection,
Whaling; signed, but not ratified — Law of the
Sea','4ea1b7b30186e13d30237be5dca60579f42068fdde89978265c0c2c09d53dcc3','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('952371c616b0dd0b7fa24cb9e793a23daec1cfb45ee2fa77a39eab0bed5683f8',1994,'YT','Mayotte','geography',656,'Location: Southern Africa, in the northern
Mozambique Channel about halfway between
Madagascar and Mozambique
Map references: Africa
Area:
total area: ilS sq km
Imul area: 375 sq km
comiMrative area: slightly more than twice the
size of Washington, DC
Land boundaries: 0 km
Coastline: 185.2 km
Maritime claims;
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: claimed by Comoros
Climate: tropical; marine; hot, humid, rainy
season during northeastern monsoon
(November to May); dry sea,son is cooler (May
to November)
Terrain: generally undulating with ancient
volcanic peaks, deep ravines
Natural resources: negligible
Land use:
araMe land: NA%
permanent crops: NA*^
meadows and pastures: NA^
forest and woodland: NA''Jf
other: NA%
Irrigated land: NA sq km','73f5b9d0476fb71d289aaa0d010f3024a5c88f4aa9bf4ac07564c2e7bdb0af25','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('176c07a1c9aeb689879d686e146a2e2ed4e1475611317aaa45a7294b936c8444',1994,'FM','Micronesia, Federated States of','geography',663,'Location: Oceania, Micronesia, in the North
Pacific Ocean, about three-quarters of the way
between Hawaii and Indonesia
Map references: (Oceania, Southeast Asia,
Standard Time Zones of the World
Area:
total area: 702 sq km
land area: 702 sq km
comparative area: slightly less than four times
the size of Washington, DC
note: includes Pohnpei (Ponape), Truk
(Chuuk). Yap. and Kosrae
Land boundaries: 0 km
Coastline: 6,1 12 km
Maritime claims;
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; heavy year-round rainfall,
especially in the eastern islands; located on
southern edge of the typhoon belt with
occasional severe damage
Terrain: islands vary geologically from high
mountainous islands to low, coral atolls;
volcanic outcroppings on Pohnpei, Kosrae, and
Truk
Natural resources: fore.sts, marine products,
deep-seabed minerals
Land use;
arable land: NA%
permanent crops: NA%
meadows and pastures: NA%
forest and woodland: NA%
other: NA%
Irrigated land: NA sq km
Location: Oceania, Polynesia, in the North
Pacific Ocean, 2„350 km west-northwest of
Honolulu, about one-third of the way between
Honolulu and Tokyo
Map references: Oceania
Area:
total area: 5.2 sq km
land area: 5.2 sq km
comparative area: about 9 times the size of
The Mall in Washington. DC
note: includes Eastern Island and Sand Island
Land boundaries: 0 km
Coastline: I S km
Maritime claims:
coniijiuoa.i zone: 24 nm
continental shelf: 200-m depth or to depth of
exploitation
e.xclusive economic zone: 200 nm
territorial sea: 1 2 nm
International disputes: none
Climate: trO|iical, but moderated by
prevailing easterly winds
Terrain: low, nearly lev''*!
Natural resources: fish, wildlife
Land use:
arable land: 0%
permanent crops. 0v!~
meadows and pa.mire.s: t)%
forest and woodland: 0%
other: 100%
Irrigated land; 0 sq km
I^.nvironinent;
ciirrenl i.ssues: NA
natural hazards: NA
international agreements: NA
Note: a coral atoll; closed to the public
Location: Eastern Europe, between Ukraine
and Romania
Map references: Asia, Europe, Standard
Time Zones of the World
Area:
total area: 33,700 sq km
land area: 33,700 sq km
comparative area: slightly more than twice the
.size of Hawaii
Land boundaries; total 1 ,389 km, Romania
450 km, Ukraine 939 km
Coastline: 0 km (landlocked)
Maritime claims: none: landlocked
International disputes: no official territorial
claims by either Moldova or Romania, but
nationalists in Romania seek the merger of
Moldova into Romania; potential future
dispute by Moldova and Romania against
Ukraine over former southern and northern
Bessarabian areas and Northern Bukovina
ceded to Ukraine upon Moldova''s
incorporation into USSR
Climate: moderate winters, warm summers
Terrain: rolling steppe, gradual slope south lo
Black Sea
Natural resources: lignite, phosphorites,
gypsum
Land use:
arable land: 50%
permanent crops: 13%
meadows and pastures: 9%
forest and woodland: 0%
other: 28%
Irrigated land: 2,920 sq km (1990)','054059fe4efa97d6745496941430312bab8af6ea5ab1c3f586962bcaedae5832','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b58da49c701c527e1203dfaeb7ad44c72b00d0edc8dfc3d01fcf91507be485a7',1994,'MC','Monaco','geography',670,'Location: Western Europe, bordering the
Mediterranean Sea, in southern France near the
border with Italy
Map references: Europe, Standard Time
Zones of the World
Area:
total area: 1 .9 sq km
land area: 1 .9 sq km
comparative area: about three times the size of
The Mall in Washington, DC
Land boundaries: total 4.4 km. France 4.4
km
Coastline: 4. 1 km
Maritime claims:
territorial sea; 1 2 nm
International disputes: none
Climate: Mediterranean with mild, wet
winters and hot, dry summers
Terrain: hilly, rugged, rocky
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 100%
Irrigated land: NA sq km','a939ff7de428dbb3258f6418f0a8b535b89f1f3ee3270fce17ca874a1bf0f325','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31ad1ed04368c57ce92de49b9c4c0e97320bcbf5cdb6f5d8c16194037e3a1e43',1994,'MS','Montserrat','geography',677,'Location; Caribbean, in the eastern Caribbean
Sea, about 400 km southeast of Puerto Rico
Map references: Central America and the
Caribbean
Area:
total area: 100 sq km
land area: lOOsqkm
comparative area: about 0.6 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 40 km
Maritime claims:
exclu,sive feshing tone; 200 nm
territorial sea; 3 nm
International disputes; none
Climate: tropical; little daily or seasonal
temperature variation
Terrain; volcanic islands, mostly
mountainous, with small coastal lowland
Natural resources; negligible
Land use:
arable land: 20%
permanent crops: 0%
meadows and pastures: 10%
forest and woodland: 40%
other; 30%
Irrigated land; NA sq km','094107b11db2087c7df92958bbd1d543407a859c65688ccc62c844da07540651','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cfefc6186930c2cf59aaab61b32f726e5fde5175b02affa621ccf5fc525f42c4',1994,'MA','Morocco','geography',683,'Location: Northern Africa, bordering the
Atlantic Ocean and the Mediterranean Sea.
between Algeria and ''Western Sahara
Map references: Africa, Standard Time
Zones of the World
Area:
total area; 446.,S.S0 sq km
land area: 446.300 sq km
comparative area; slightly larger than
California
I.and boundaries; total 2.002 km. Algeria
1,559 km. Western Sahara 443 km
Coastline: 1,835 km
Maritime claims:
contigimi.i zone; 24 nm
continental shelf: 200-m depth or to depth of
exploitation
exclusive economic zone; 200 nm
territorial sea: 1 2 nm
International disputes: claims and
administers Western Sahara, but sovereignty is
unresolved; the UN is attempting to hold a
referendum; the UN-administered cease-fire
has been currently in effect since September
1991; Spain controls five places of sovereignty
(plazas de soberania) on and off the coast of
Morocco — the coastal enclaves of Ceuta and
Mclilla which Morocco contests as well as the
islands of Penon de AIhucemas, Penon de
Velez de la Gomera, and Islas Chafarinas
Climate: Mediterranean, becoming more
extreme in the interior
Terrain: mostly mountains with rich coa.stal
plains
Natural resources; phosphates, iron ore.
manganese, lead, zinc, fish, salt
Land use:
arable land: I Sff
permanent crops: 1 Vr
meadows and pastures: 28ff-
forest and woodland: 1 2%
other; 4 1 91-
Irrigated land: 1 2,6.50 sq km ( 1 989 est. )','ee31d924b4ff7b8fb8a190d8a6e551bf86b9d4b9b894c8d4838845aaccf6a698','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50b2e0126665ebe79d1ae536d51c00622891bedd87bb77044f232606639dd991',1994,'MZ','Mozambique','geography',689,'Location; Southern Africa, bordering the
Mozambique Channel between South Africa
and Tanzania opposite the island of','2f2b06e982d1d1db1fb6b6a3ddb8d12685c0023a14d3440ef6b539f07225556f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d86d02aaed819dce9ea5d5f96c51efd36a8a3e2321b5ccc71c83bdffcf3118be',1994,'JP','Japan','geography',693,'Location: Southern Africa, bordering the
South Atlantic Ocean between Angola and
Location: Southern Africa, in the South
Atlantic Ocean, 1,920 km west of Angola,
about two-thirds of the way between South
America and Africa
Map references; Africa
Area;
total area: 410 sq km
land area: 410 $q km
comparative area: slightly more than 2,3 times
the size of Washington, DC
note: includes Ascension, Gough Island,
Inaccessible island. Nightingale Island, and
Trisun da Cunha
Land boundaries; 0 km
Coastline; 60 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 12 nin
International disputes: none
Climate; tropical; marine; mild, tempered by
Uade winds
Terrain: rugged, volcanic; small scattered
plateaus and plains
Natural resources: fish; Ascension is a
breeding ground for sea turtles and sooty terns,
no minerals
Land use:
arable land: 7%
permanent crops: 0%
meadows and pa.stures: 7%
forest and woodland: 3%
other: 83%
Irrigated land: NAsqkm','e4ba89bbe363736489dc1d6ab77b0f57b822c7fa3d10928383641bec9b2ded13','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6932b710927656eb8a56a3238cfd763cb7eaf5c089ba6ce6a636e58df36968fa',1994,'NR','Nauru','geography',697,'Location; Oceania. Micronesia, ,5(X) km
north-northeast of Papua New Guinea
Map references: Oceania. Standard Time
Zones of the World
Area:
total area; 21 sq km
land area: 21 sq km
comparative area: about one-tenth the size of
Washington. DC
Land boundaries: 0 km
Coastline; .30 km
Maritime claims:
e.vciu.''iive fi.diinf! ztnie; 2(K) nm
territorial .sea: 12 nm
International disputes: none
Climate: tropical; monsoonal; rainy .season
tNovember to February)
Terrain: sandy beach rises to fertile ring
around raised coral reefs with phosphate
plateau in center
Natural resources; phosphates
Land use:
arable land: 0%
permanent crop.s: tWr
meadows and /ui.stiires; O^?-
fore.st and wiHHiland; 0%
other: I009(
Irrigated land: NA sq km
Location: Caribbean, in the Caribbean Sea,
160 km .south of the US Naval base at
Guantanamo Bay (Cuba), between Cuba, Haiti,
and Jamaica
Map references: Central America a^.d the
Caribbean
Area:
totui area; 5.2 sq km
land area; 5.2 sq km
comparative area: about nine times the size of
Tltc Mall in Washington. DC
Loud boundaries: 0 km
Coastline; 8 km
Maritime claims:
contiguous zone: 24 nm
continental shelf; 200-m depth or to depth of
exploitation
exclusive economic zone; 200 nm
territorial sea: 1 2 nm
International disputes; claimed by Haiti
Climate; marine, tmpical
Terrain; raised coral and limestone plateau.
flat to undulating; ringed by vertical white
cliffs (9 to 15 meters high)
Natural resources: guano
Land use:
arable land; 0%
permanent crops: 0%
meadows and pastures; 10%
forest and woodland: 0%
other: 90%
Irrigated land: 0 sq km','de6aed2ae84d7f9e26590cb13e931d30302c64b4fb8b0b1a2dbbb9bd05f8eb76','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb25a49f7675639ade23a0335cb7a15564be96e9ba0f301381aaf1275014eaae',1994,'NP','Nepal','geography',705,'Location: Southern Asia, in the Himalayas,
between China and India
Map references: Asia, Standard Time Zones
of the World
Area:
total area: 1 40,800 sq km
land area: 1 36,800 sq km
comparative area: slightly larger than
Arkansas
Land boundaries: total 2,926 km, China
1,236 km, India 1,690 km
Coastline: 0 km (landlocked)
Maritime claims: none; landlocked
International disputes: none
Climate: varies from cool summers and
severe winters in north to subtropical summers
and mild winters in south
Terrain: Terai or flat river plain of the
Ganges in south, central hill region, rugged
Himalayas in north
Natural resources: quartz, water, timber,
hydroelectric potential, scenic beauty, small
deposits of lignite, copper, cobalt, iron ore
Land use:
arable land: 17%
permanent crops: 0%
meadows and pastures: 13%
forest and woodland: 33%
other: 37%
Irrigated land: 9,430 sq km (1989)','e1a7d3a0fd8b60b9c26722414dc20d55c27353c6a1a881828da09dc5a84b7eae','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7edb2c5a2142834cc4b3b8241bcd52c809b85d36801e6b14b635dc07dbe1517f',1994,'NC','New Caledonia','geography',709,'lAtndon: Oceania. Melanesia, in the South
Pacific Ocean. 1,750 km east of Australia
Map references: Oceania
Area:
total area; lO.OftO sq km
lamiarea: 18,760 sq km
vontiHirative area; slightly smaller than New','c2553ac78d4313c4778b0f007acd7d070788dcaaceb4e1476eb66c40396f3667','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4ee3da96443107ab8450970f5de2ed6b5248391e15854430f27c8bad3832a21',1994,'NI','Nicaragua','geography',714,'Location: Middle America, between Costa
Rica and Honduras
Map references; Central America and the
Caribbean, South America
Area:
total area; 1 29,494 sq km
land area; 1 20,254 sq km
comparative area: slightly larger than New
York State
Land boundaries: total 1,231 km. Costa Rica
.309 km, Honduras 922 km
Coastline: 910 km
Maritime claims:
contiguous zone; 25-nm .security zone (status
of claim uncertain)
continental shelf; not specified
territorial sea; 200 nm
International disputes: territorial disputes
with Colombia over the Archipelago de San
Andres y Providencia and Quita Sueno Bank;
International Court of Justice (ICJ) referred the
maritime boundary question in the Golfo de
Fonseca to an earlier agreement in this century
and advi.sed that some tripartite resolution
among El Salvador, Honduras, and Nicaragua
likely would be required
Climate: tropical in lowlands, cooler in
highlands
Terrain: extensive Atlantic coastal plains
rising to central interior mountains: narrow
Pacific coastal plain interrupted by volcanoes
Natural resources: gold, silver, copper.
tungsten, lead, zinc, timber, fish
Land use:
arable land: 9‘;}-
permanent crops; 1 9!-
meadows and pastures; 43%
forest and woodland; 35%
other; 12%
Irrigated land: 850 sq km ( 1 989 est.)','909c6d790001700a055992337c343014f619a01f24b653d42009d2f71f09ba9a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05139d82658154a1471fd4b8b622f126544dc43ffec13edb56d79a24760b6ddb',1994,'NE','Niger','geography',720,'lawation: Western Africa, between Algeria
and Nigeria
Map references: Africa. Standard Time
Zones of the World
Area;
total itmi: 1 ,2b7 million sq km
laiiil amt: l.2bb.7(X)sq km
amipanitiff ami: slightly less than twice the
si/.e of Texas
Land boundaries; total .$.607 km. Algeria
o.Sb km, Benin 26b km, Burkina 628 knt. Chad
1 . 1 7.4 km, l.ihv a .4.$4 km. Mali 82 1 km. Nigeria
1.407 km
Coastline; (IkmdanJItK''ked)
Maritime claims; none; landltKked
International disputes: l.ihy a claims about
|0,4(X) sq km in noithem Niger; demarcation
of international btnmdaries in Lake Chad, the
lack of which has led to hxnxler incidents in the
past, is completed and awaiting ratification by
CametxKin, Chad. Niger, ;md Nigeria; Burkina
and Mali are pixK''eeding w ith bwindary
demarcation, including Ihe lri(H)ini with Niger
Climate; desert; mostly hot. dry. dusty;
tropical in extreme south
Terrain: predominately d. sert plains and
sand dunes; Hut to rolling plains in south; hills
in north
Natural resources; uranium, coal, iron ore,
tin. phosphates
l.and use;
artihlf ItiilJ: .4'' <
/wniiani’iit i-ro/fx: t)*7
mcatlowx ami fkixtiirrx: 7* i
loriwt anil winnilanil: 2'' i
atiwr: 88ri
irrigated land; .420 sq km 1 1^89 est.i
Knviranment:
fiirmit i.v.viie.v. overgrazing; soil erosion;
deforestation; deseitification; wildlife
populations (such as elephant, hippopotamus,
and lion) threatened because of pouching and
habitat destniciion
naliiral lia:aril.\\: recuirent dnnights
iiiifmiitiomil «g»wwenrv,‘ party to —
Endangered Species, EnvinmmentuI
Moilificution. Nuclear Test Bun. Ozone Layer
Proieeiion, Wetlands; signed, but m>t ratified—
Bitxlivcrsiiy. Climate Change, Law of the Sea
Note; landltK''ked','b19026cbc06350613432e7bf7a19c39c4f6a60d9795cc3a56bf64596eaaf9a73','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d974fb355c0823c9a6807cf9cafb4527b782f59834e179868044022fc351ad7e',1994,'NF','Norfolk Island','geography',730,'Location: Southwestern Oceania. 1 ,575 km
east of Australia in the South Pacific Ocean
Map references: Oceania
Area:
total area: 34.6 sq km
land area: 34.6 sq km
comparative area: about 0.2 times the size of
Wa.shington. DC
Land boundaries: 0 km
Coastline: 32 km
Maritime claims:
exclusive fi.shing zone: 2tX) nin
territorial sea: 3 nm
International disputes: none
Climate: subtropical, mild, little seasonal
temperature variation
Terrain: volcanic formation with mostly
rolling plains
Natural resources: fish
l^nd use:
arable land: 09f
permanent crops: ()9t''
meadows and pastures: 25%
forest and woodland: 0%
other: 75%
Irrigated land: NA sq km','96dcf6886fdc3c1d263b76f10df4c478ee4926f4da571d7814fcf3b8222204db','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb0bf1e7eb1fe372f4f6bf703ef510b27b46a570d95255583d7fb65d7e5064ef',1994,'MP','Northern Mariana Islands','geography',735,'Location: Oceania. Micronesia, in the North
Pacific Ocean, 5,635 km west-southwest of
Honolulu, about three-quaiters of the way
between Hawaii and the Philippines
Map references: Oceania
Area:
total area: 477 sq km
land area: 477 sq km
comparative area: slightly more than 2.5 times
the size of Washington, DC
note: includes 14 islands including Saipan.
Rota, and Tinian
Land boundaries: 0 km
Coastline: 1.482 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 200-m depth or to depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
International disputes; none
Climate: tropical marine; moderated by
northeast trade winds, little seasonal
temperature variation; dry sea.son December to
June, rainy season July to October
Terrain; southern islands are limestone with
level terraces and fringing coral reefs: northern
islands are volcanic: highest elevation is 47 1
meters (Mt. Okso* Takpochao on Saipan)
Natural resources: arable land, fish
Land use:
arable land: 5% on Saipan
permanent crops: NA%
meadows and pastures: 19%
forest and woodland: NA%
other: NA%
Irrigated land: NA sq km','24253d5dad25247fb34c8b841974ab4ee74860114058123051ddb5aef725836e','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e47bed6988f778f5fd8dee49545211d5eaa2667d98de408c29e05d53f0ec1a14',1994,'SE','Sweden','geography',740,'Map references: Arctic Region. Europe,
Standard Time Zones of the World
Area:
total area; 324.220 sq km
land area; .307,860 sq km
comparative area: slightly larger than New','297f7b13a9f2f736e0c99fa6d3543ba1606612fc9170f85142d9b3bb9876e676','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89f300e301e58e66b970c4c93bd5278a7db801d14e232922eb528041e9d1730c',1994,'PH','Philippines','geography',743,'Map rcfbrencca: Oceania
Area:
total area: 438 sq km
land area: 458 sq km
comparative area: slightly more than 2.3 times
the size of Washington. DC
Land boundaries: 0 km
CoattUne: 1,319 km
Maritime dalnn:
contiguous zone: 24 nm
continental shelf: 200-m depth or to depth of
exploitation
exclusive fishing zone: 200 nm
territorial sea: 1 2 nm
Intemalioiial diapntes: none
Climate: wet sea.son May to November: hot
and humid
Terrain: about 200 islands varying
geologically from the high, mountainous main
island of Babcithuap to low, coral islands
usually fringed by large barrier reefs
Natund resources: forests, minerals
(especially gold), marine products, deep-
seabed minerals
Land use:
arable land: NA%
permanent crops: NA%
meadows and pastures: NA%
forest and woodland: NA%
other: NA%
Irrigated land: NA sq km
Location: bixly of water between the Western
Hemisphere, Asia, and Australia
Map references: Asia, North America,
Oceania. South Americ:i, Standard Time Zones
of the World
Area:
total amt: I AS. .384 million sq km
com/Hiratiw ami: ahtiut IK times the size of
the US; the largest iKcan (followed by the
Atlantic Ocean, the Indian Ocean, and the
Arctic Ocean): covers about one-third of the
global surface; larger than the total land area of
the world
note: includes Bali Sea. Bellingshausen Sea.
Bering Sea. Bering Strait. Coral Sea. East
China Sea, Gulf of Alaska. Gulf of Tonkin,
Java Sea. Philippine Sea, Ross Sea. Savu Sea,
Sea of Japan, Sea ofOkhot.sk. South China Sea,
Tasman Sea. Timor Sea. and wher tributary
water bodies
Coastline; 1 3,'''',6b.3 km
International disputes; sonK maritime
disputes (sec littoral states)
Climate: the western Pacific is inonstHmal — a
rainy seasvm ttccurs during the summer
months, when moisture-laden winds blow from
the (K''ean over the land, and a dry .season
during the winter months, when dry winds
blow from the Asian land mass back to the
ocean
Terrain; surface cuirenis in the northern
Pacific arc dominated by a ckK''kwisc. warm-
water gyre (broad circular system of currents)
and in the southern Pacific by a
counterckK''kwise, cixrl-water gyre; in the
northern Pacific sea ice forms in the Bering Sea
and Sea of Okhotsk in winter; in the .southern
Pacific sea ice from Antarctica reaches its
northernmost extent in October; the iK-ean
fiixtr in the eastern Pacific is dominated by the
East Pacific Rise, while the western Pacific is
dissected by deep trenches, including the
world''s deepest, the 10,924 meter Marianas
Trench
Natural resources: oil and gas fields.
ptdymetallic nodules, sand and gravel
aggregates, placer depttsits, fish
Location: Southeastern Asia, between
Indonesia and China
Map references: Asia, Oceania, Southeast
Asia, Standard Time Zones of the World
Area:
total area; 300,000 sq km
land area; 298,170 sq km
comparative area; slightly larger than Arizona
Land boundaries: 0 km
Coastiine: 36.289 km
Maritime claims: measured from claimed
archipelagic baselines
continental shelf; to depth of exploitation
exclusive economic zone; 200 nm
territorial sea; irregular polygon extending up
to 100 nm from coastline as defined by 1898
treaty: since late 1970s has also claimed
polygonal-shaped area in .South China Sea up
to 285 nm in breadth
International disputes: involved in a
complex dispute over the Spratly Islands with
China, Malaysia, Taiwan, Vietnam, and
possibly Brunei; claims Malaysian state of
Sabah
Climate: tropical marine; northeast monsoon
(November to April): southwest monsoon
(May to October)
Terrain; mostly mountains with narrow to
extensive coastal lowlands
Natural resources: timber, petroleum,
nickel, cobalt, silver, gold, salt, copper
Land use:
arable land; 26%
permanent crops: 1 \\ %
meadows and pastures: A%
forest and woodland; 40%
other: 19%
Irrigated land: 1 6,200 sq km ( 1 989 est.)
Location: Oceania, Polynesia in the South
Pacific Ocean, about halfway between Peru
and New Zealand
Map references: Oceania
Area:
total area: 47 sq km
land area: 47 sq km
comparative area: about 0.3 limes the size of
Washington, DC
Land boundaries: 0 km
Coastline: SI km
Maritime claims;
exclusive fishing zone: 200 nm
territorial sea: 3 nm
International disputes: none
Climate: tropical, hot. humid, modified by
.southeast trade winds: rainy season (November
to March)
Terrain; rugged volcanic formation; rocky
coastline with cliffs
Natural resources: miro trees (used for
handicrafts), fish
Land use:
arable land: NA9f>
permanent craps; NA%
meadows and pastures: NA^f
forest and woodland: NA%
other: NA''jt
Irrigated land: NAsqkm
Map references: Asia, Southeast Asia
Area:
total area; NA sq km but less than 5 sq km
land area; less than 5 sq km
comparative area; NA
note; includes 100 or so islets, coral reefs, and
sea mounts scattered over the South China Sea
Land boundaries: 0 km
Coastline; 926 km
Maritime claims: NA
International disputes: all of the Spratly
Islands are claimed by China, Taiwan, and
Vietnam; parts of them are claimed by
Malaysia and the Philippines; in 1984, Brunei
established an exclusive economic zone, which
encompasses Louisa Reef, but has not publicly
claimed the island
Climate: tropical
Terrain: flat
Natural resources: fish, guano.
undetermined oil and natural gas potential
Land use:
arable land; 0%
permanent cropx; 0%
meadows and pastures; 0%
forest and woodland; 0%
other: 100%
Irrigated land: 0 sq km
Location: Southern Asia. 29 km southeast of
India across the Palk Strait in the Indian Ocean
Map references: Asia, Standard Time Zones
of the World
Area:
total area; 65,610 sq km
land area; 64,740 sq km
comparative area; slightly larger than West
Virginia
Land boundaries: 0 km
Coastline: 1,340 km
Maritime claims:
contiguous zone; 24 nm
continental shelf; 200 nm or the edge of
continental margin
exclusive economic zone; 200 nm
territorial sea; 12 nm
International disputes: none
Climate: tropical monsoon: northeast
monsoon (December to March); southwest
monsoon (June to October)
Terrain: mostly low, flat to rolling plain;
mountains in south-central interior
Natural resources: limestone, graphite,
mineral sands, gems, phosphates, clay
Land use:
arable land; 16%
permanent crops; 17%
meadows and pastures; 7%
forest and woodland; 37%
other; 23%
Irrigated land: 5,600 sq km ( 1 989 est.)','3961f5c35312c8a794c51d93b3b0c771339d576f14d4588143aec53b5a3df412','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d61bb016fb5a5305fa925592aa62215f93c576477341b1384855e5acd765f16',1994,'PK','Pakistan','geography',750,'Location: Southern Asia, along the Arabian
Sea, between India and Afghanistan
Map references; Asia, Standard Time Zones
of the World
Area;
total ami: 80.1.<)40 sq km
land area: 778,720 sq km
comparative urea: sligh„y less than twice the
size of California
Land boundaries: total 6,774 km.
Afghanistan 2,430 km. China 523 km, India
2.912 km. Iran 909 km
Coastline: 1.046 km
Maritime claims:
continuous zone: 24 nm
continental shelf: 200 nm or the edge of
continental margin
exclusive ecimomk zime: 200 nm
territorial sea: 12 nm
International disputes; status of Kashmir
with India; border question with Afghanistan
(Dumnd Line); water-sharing problems (Wular
Barrage '' over the Indus with upstream riparian
Location: Oceania, Polynesia, in the North
Pacific Ocean, 1,600 km south-southwest of
Honolulu, almost halfway between Hawaii and','7db18bbf7692d0ce45041d54d9e2385d802495ef19250090e72732ab9199c8bc','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e30f0e7b86af20aa37fdf4cd6cfb56ccc1ed3973ded718abe131ab62e07a0728',1994,'PA','Panama','geography',752,'Location: Middle America, between
Colombia and Co.stu Rica
Map references: Central America and the
Caribbean, South America. Standard Time
Zones of the World
Area:
total area: 78,200 sq km
land area: sq km
comparative area: slightly smaller than South
Carolina
Land boundaries: total 5.S,5 km. Colombia
225 km, Costa Rica .^30 km
Coastline: 2.490 km
Maritime claims:
territorial .sea: 200 nm
International disputes: none
Climate: tropical; hot. humid, cloudy;
prolonged rainy season (May to January ), short
dry season (January to May)
Terrain: interior mostly steep, rugged
mountains and dissected, upland plains; coastal
areas largely plains and rolling hills
Natural resources: copper, mahogany
forests, shrimp
Land use:
arable land: b''Jf
permanent crops: 2%
meadows and pastures: I59i-
forest and woodland: 54%
other: 25%
Irrigated land: .720 sq km ( 1989 est.)','f1d676a645c2eadae28a8355ff7d7ede82346b5e60fd5a50d6b26c1e68ceb601','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5939f33059a9265e4562f8fb9b9613f7172d7ed109795c17875299fd23d9596',1994,'PG','Papua New Guinea','geography',758,'Location: Southeastern Asia, just north of
Australia, between Indonesia and the Solomon
Islands
Map references: Oceania, Southeast Asia,
Standard Time Zones of the World
Area:
total area: 461 ,690 sq km
land area: 45 1 ,7 10 sq km
comparative area: slightly larger than
California
Land boundaries: total 820 km, Indonesia
820 km
Coastline: 5,152 km
Maritime claims: measured from claimed
archipelagic baselines
continental shelf: 200-m depth or to depth of
exploitation
e.xclu,sive fishing zone: 200 nm
territorial sea: 1 2 nm
International disputes; none
Climate: tropical; northwest monsoon
(December to March), southeast monsoon
(May to October): slight seasonal temperature
variation
Terrain: mostly mountains with coa.stal
lowlands and roiling foothills
Natural resources: gold, copper, silver,
natural gas, timber, oil potential
Land use:
arable land: 0%
permanent crops: 1 %
meadows and pastures: 0%
forest and woodland: 7 1 %
other: 28%
Irrigated land: NA sq km','79be647390910ff799811899d976ede0041ea6691098878a460108149fc5ca0c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eccc5dbca7aedcaa81f564ab6eae5784556ce0adc49ea1d60e7c45d5c2370ef1',1994,'PL','Poland','geography',766,'Location: Central Europe, between Germany
and Belarus
Map references: Asia, Ethnic Groups in
Eastern Europe. Europe, Standard Time Zones
of the World
Area:
total area: 31 2.680 sq km
land area: 304,5 10 sq km
comparative area: slightly smaller than New','99d4921e854c9c6a40a51815238d8a4fa64e63969345b36b6afaef958d0b2e24','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bbee83ba1a26649060030fed0bcf66401451e7b0290d97e0d500a6d2f13bc7ee',1994,'PT','Portugal','geography',768,'Location: Southwestern Europe, bordering
the North Atlantic Ocean west of Spain
Map references: Africa, Europe, Standard
Time Zones of the World
Area:
total area: 92,080 sq km
land area; 9 1 ,640 sq km
comparative area; slightly smaller than
Indiana
note: includes Azores and Madeira Islands
Land boundaries: total 1,214 km, Spain
1,214 km
Coastline: 1,793 km
Maritime claims:
continental shelf; 200-m depth or to depth of
exploitation
exclusive economic zone; 200 nm
territorial sea; 12 nm
International disputes: sovereignty over
Timor Timur (East Timor Province) disputed
with Indonesia
Climate: maritime temperate; cool and rainy
in north, warmer and drier in south
Terrain; mountainous north of the Tagus,
rolling plains in south
Natural resources; fish, forests (cork),
tungsten, iron ore, uranium ore, marble
Land use:
arable land; 32%
permanent crops: 6%
meadows and pastures; 6%
forest and woodland; 40%
other: 16%
Irrigated land: 6,340 sq km (1989 est.)','f341a074f9f4c545d070a01f93fd9762a4bf04d11cfd880908aad56c4281d55b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24fea76b9c5ba799f55672751bcca7001ba9be78ef4659925b610e4c714ba9a1',1994,'PR','Puerto Rico','geography',774,'Location: Caribbean, in the North Caribbean
Sea, between the Dominican Republic and the
Virgin Islands group
Map references: (Central America and the
Caribbean
Area:
total area: 9,104 sq km
land area: 8,959 sq km
comparative area: slightly less than three
times the size of Rhode Island
Land boundaries: 0 km
Coastline: SOI km
Maritime claims;
contiguous zone; 24 nm
continental shelf: 200-m depth or to depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
International disputes; none
Climate: tropical marine, mild, little seasonal
temperature variation
Terrain: mostly mountains with coastal plain
belt in north; mountains precipitous to sea on
west coast; sandy beaches along most coastal
areas
Natural resources; some copper and nickel.
potential for onshore and offshore crude oil
Land use;
arable land: 8%
permanent crops: 9%
meadows and pastures: 41%
forest and woodland: 20%
other: 22%
Irrigated land: 390 sq km (1989 est.)','3153ab5f5d0150e50aef1715d03fe3c2a79ea9dba542157a9721dbf58c1fd294','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e5475fbc409924f142772f83417014f2cfd85fae726f59407804228c961d7f1',1994,'QA','Qatar','geography',779,'Location: Middle Eiast, peninsula jutting into
the central Persian Gulf, between Iran and','ce4cd37aa3b5e78ffa7bb8b5b3c66eecf84861799614e5280264683efc93cebb','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77ae791d8d3dfcba1c798b7a1d72230c63e1011d959c99d63bde316ba0582635',1994,'RO','Romania','geography',782,'Location: Balkan State, Southeastern Europe,
bordering the Black Sea between Bulgaria and','12b9762ea9a02e9ddf1d65ebba32f0113b2712ca820dafce159f3325c4f25e6c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99665fcaeda8a07dd955c76bbc52b8b1f5d0cf838ab31e097953d713418920b3',1994,'UA','Ukraine','geography',783,'Map references: Ethnic Groups in Eastern
Europe, Europe, Standard Time Zones of the
World
Area:
total area; 237,500 sq km
land area; 230,340 sq km
comparative area; slightly smaller than
Oregon
Land boundaries; total 2,508 km, Bulgaria
608 km, Hungary 443 km, Moldova 450 km,
Serbia and Montenegro 476 km (all with
Serbia), Ukraine (north) 362 km, Ukraine
(south) 169 km
Coastline: 225 km
Maritime claims:
contiguous zone; 24 nm
continental shelf; 2(X)-m depth or to depth of
exploitation
exclusive economic zone; 200 nm
territorial .sea; 12 nm
International disputes: no official territorial
claim by either Moldova or Romania, but
nationalists in Romania seek the merger of
Moldova with Romania; potential future
dispute by Moldova and Romania against
Ukraine over former southern and northern
Bessarabian areas
Climate; temperate; cold, cloudy winters with
frequent snow and fog; sunny summers with
frequent showers and thunderstorms
Terrain: central Transylvanian Basin is
separated from the Plain of Moldavia on the
east by the Carpathian Mountains and
separated from the Walachian Plain on the
south by the Transylvanian Alps
Natural resources: petroleum (reserves
declining), timber, natural gas, coal, iron ore.
salt
Land use:
arable land: 43%
permanent crops; 3%
meadows and pastures: 19%
forest and woodland; 28%
other; 7%
Irrigated land: 34,S(X)sq km(1989est.)
Location: Northern Asia (that part west of the
Urals is sometimes included with Europe),
between Europe and the North Pacific Ocean
Map references: Asia, Commonwealth of
Independent States — Central Asian States,
Commonwealth of Independent States —
European States, Standard Time Zones of the
World
Area:
total area: 1 7,075,200 sq km
land area: 1 6,995,800 sq km
comparative area: slightly more than 1 .8 times
the size of the US
Land boundaries; total 20,139 km,
Azerbaijan 284 km, Belarus 959 km, China
(southeast) 3.605 km. China (south) 40 km,
Estonia 290 km, Finland 1,313 km, Georgia
723 km, Kazakhstan 6,846 km. North Korea 19
km, Latvia 217 km, Lithuania (Kaliningrad
Oblast) 227 km, Mongolia 3,441 km. Norway
167 km, Poland (Kaliningrad Oblast) 432 km,
Ukraine 1 ,576 km
Coastline: 37,653 km
Maritime claims:
continental .shelf: 200-m depth or to depth of
exploitation
e.sclusive economic zone: 200 nm
territorial .sea: 1 2 nm
International disputes: inherited disputes
from former USSR including; .sections of the
boundary with China; islands of Etorofu,
Kunashiri, and Shikotan and the Habomai
group occupied by the Soviet Union in 1945,
administered by Russia, claimed by Japan;
maritime dispute with Norway over portion of
the Barents Sea; Russia may dispute current de
facto maritime border of midpoint of Caspian
Sea from shore; potential dispute with Ukraine
over Crimea: has made no territorial claim in
Antarctica (but has reserved the < ight to do so)
and does not recognize the claims of any other
nation
Climate; ranges from .steppes in the south
through humid continental in much of
European Russia: subarctic in Siberia to tundra
climate in the polar north; winters vary from
cool along Black Sea coast to frigid in Siberia;
summers vary from warm in the steppes to cool
along Arctic coast
Terrain: broad plain with low hills west of
Urals; vast coniferous forest and tundra in
Siberia; uplands and mountains along southern
border regions
Natural resources: wide natural resource
base including major deposits of oil, natural
gas, coal, and many strategic minerals, timber
note: formidable obstacles of climate, terrain,
and distance hinder exploitation of natural
resources
Land use:
arable land: 8%
permanent crops: NA%
meadows and pastures: N A%
forest and woodland: NA%
other: NA%
note: agricultural land accounts for 1 3% of the
total land area
Irrigated land: 56,000 .sq km (1992)
Location: Eastern Europe, bordering the
Black Sea, between Poland and Russia
Map references: Asia, Commonwealth of
Independent States — European States, Europe,
Standard Time Zones of the World
Area:
total area: 603.700 sq km
land area: 603,700 .sq km
comparative area: slightly smaller than Texas
Land boundaries; total 4,558 km, Belarus
891 km. Hungary 103 km, Moldova 939 km,
Poland 428 km, Rumania (southwest) 169 km,
Romania (west) 362 km, Russia 1,576 km,
Slovakia 90 km
CoastUne: 2,782 km
Maritime claims; NA
International disputes: potential future
border disputes with Moldova and Romania in
Northern Bukovina and southern Odes’ka
Oblast''; potential dispute with Moldova over
former southern Bessarabian area; potential
dispute with Russia over Crimea; has made no
territorial claim in Antarctica (but has reserved
the right to do so) and does not recognize the
claims of any other nation
Climate: temperate continental; subtropical
only on the southern Crimean coast;
precipitation disproportionately distributed,
highest in west and north, lesser in east and
.southeast; winters vary from cool along the
Black Sea to cold farther inland; summers are
warm across the greater part of the country, hot
in the south
Terrain: most of Ukraine consists of fertile
plains (steppes) and plateaux, mountains being
found only in the west (the Carpathians), and in
the Crimean Peninsula in the extreme south
Natural resources: iron ore, coal,
manganese, natural gas, oil, salt, sulphur,
graphite, titanium, magnesium, kaolin, nickel,
mercury, timber
Land use;
arable land: 56%
permanent crops: 2%
meadows and pastures: 1 2%
409
Ukraine (continued)
forest and woodland: 0%
other: 30%
Irrigated land: 26,000 sq km ( 1990)','bf71bf312ad319f094e4af305fad3349188f1e6870b5794f5c38bf61eb90564c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0cd1c87a6af49d497110caef4763fc6bd9707a18318d459e1cdb9dba967a60af',1994,'RW','Rwanda','geography',790,'Location: Central Africa, between Tanzania
and Zaire
Map references: Africa, Standard Time
Zones of the World
Area:
total area: 26.340 sq km
land area: 24,950 sq km
comparative area; slightly smaller than
Maryland ,
Land boundaries: total 893 km, Burundi 290
km, Tanzania 217 km, Uganda 169 km, Zaire
217 km
Coastline: 0 km (landlocked)
Maritime claims: none; landlocked
International disputes: none
Climate: temperate; two rainy seasons
(February to April, November to January);
mild in mountains with frost and snow possible
Terrain: mostly grassy uplands and hills;
mountains in west
Natural resources: gold, cassiterite (tin ore),
wolframite (tungsten ore), natural gas,
hydropower
Land use:
arable land: 29%
permanent crops: 11%
meadows and pastures: 1 8%
forest and woodland: 10%
other; 32%
Irrigated land: 40 sq km ( 1989 est.)','5880cb1b63a2e35cff97498c78df4e884f23d9abec52b30a4cc12a78c7d77fc7','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4adf2d26440ed2e0198a4ed0c8cd7582d089eaa3d72b136576ed2f9ff2465106',1994,'LC','Saint Lucia','geography',796,'Location: Caribbean, in the eastern Caribbean
Sea. about two-thirds of the way between
Puerto Rico and Trinidad and Tobago
Map references: Central America and the
Caribbean, South America, Standard Time
Zones of the World
Area:
total area: 620 sq km
lartd area: 610 sq km
comparative area: slightly less than 3.5 times
the size of Washington, E>C
Land boundaries: 0 km
Coastline; 158 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial .sea: 12 nm
International disputes: none
Climate: tropical, moderated by northeast
trade winds; dry season from January to April,
rainy .season from May to August
Terrain: volcanic and mountainous with
.some broad, fertile valleys
Natural resources: forests, sandy beaches,
minerals (pumice), mineral springs,
geothennal potential
Land use:
arable land: 8%
permanent crops: 20%
meadows and pastures: 5%
forestand woodland: 13%
other: 54%
Irrigated land; 1 0 sq km ( 1 989 est.)','d827c8a955acb0bed87a2d9a79af0a422b7c0526ad38fa984de8f4096bcc4535','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a81c5f96867756105bf586d64053cb7a5f5404e9d0f5fe7fa9faaed6874505b',1994,'PM','Saint Pierre and Miquelon','geography',801,'Location: Northern North America, in the
North Atiantic Ocean, 25 km south of
Newfoundland (Canada)
Map references: North America
Area:
total area: 242 sq km
land area: 242 sq km
comparative area: slightly less than 1 .5 times
the size of Washington, DC
note: includes eight small islands in the Saint
Pierre and the Miquelon groups
Land boundaries: 0 km
Coastline: 120 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
International disputes: focus of maritime
boundary dispute between Canada and France
Climate; cold and wet. with much mist and
fog; spring and autumn are windy
Terrain: mostly barren rock
Natural resources: fish, deepwater ports
Land use:
arable land: 13%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 4%
other: 83%
Irrigated land: NA sq km','a297b4fdc928971003a6d7840ccbf4567f1e03b4252fc9ec115b15dc9a114554','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a8d89fbd01c9a5b0be48173f0ab7b6996f36a3bad55fd2ab7d59c1cc108b42d7',1994,'VC','Saint Vincent and the Grenadines','geography',807,'Location: Caribbean, in the eastern Caribbean
Sea about three-fourths of the way between
Puerto Rico and Trinidad and Tobago
Map references: Central America and the
Caribbean, South America, Standard Time
Zones of the World
Area:
total area: 340 sq km
land area: 340 sq km
comparative area: slightly less than twice the
size of Washington, DC
Land boundaries: 0 km
Coastline; 84 km
Maritime claims;
contiguous zone: 24 nm
e.xclusive economic zone: 200 nm
territorial sea: 1 2 nm
International disputes: none
Climate: tropical; little seasonal temperature
variation; rainy season (May to November)
Terrain: volcanic, mountainous; Soufriere
volcano on the island of Saint Vincent
Natural resources; negligible
Land use:
arable land: 38%
permanent crops: 12%
meadows and pastures: 6%
forest and woodland: 41%
other: 3%
Irrigated land: 10 sq km (1989 est.)','d1d25b2302e55a97e685482a7181b94f13651dd5bebadbbc3ea04dda3d6c1a2a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aaa97fce0cc687cb736ce7d2552a8cced5d1aa2de54ce3f0ca2ed3cb5019e8eb',1994,'SM','San Marino','geography',812,'Location: Southern Europe, an enclave in
central Italy
Map references: Europe, Standard Time
Zones of the World
Area:
total area: 60 sq km
land area; 60 sq km
comparative area: about 0.3 times the size of
Washington, DC
Land boundaries: total 39 km, Italy 39 km
Coastline: 0 km (landlocked)
Maritime claims: none; landlocked
International disputes: none
Climate: Mediterranean; mild to cool winters;
warm, sunny summers
Terrain: rugged mountains
Natural resources: building stone
Land use:
arable land: \\1%
permanent crops; 0%
meadows and pastures: 0%
forest and woodland: 0%
other; 83%
Irrigated land: NAsqkm','77124e9b8bdff9f423e6a1acd8500f36a78954e8d7c77b209e2e13ce9c64dba1','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23c4a1749fc04748ec81cd5924f44812f6287ba9dc9ae44c610c515667bb1ecd',1994,'ST','Sao Tome and Principe','geography',819,'Location; Western Africa, in the Atlantic
Ocean, 340 km off the coast of Gabon
straddling the equator
Map references: Africa, Standard Time
Zones of the World
Area:
total area: 960 sq km
land area: 960 sq km
comparative area: slightly less than 5.5 times
the size of Washington, E)C
Land boundaries: 0 km
Coastline: 209 km
Maritime claims: measured from claimed
archipelagic baselines
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
International disputes: none
Climate: tropical; hot, humid; one rainy
season (October to May)
Terrain: volcanic, mountainous
Natural resources: fish
Land use:
arable land: 1 %
permanent crops: 20%
meadows and pastures: 1 %
forest and woodland: 75%
other: 3%
Irrigated land: NA sq km','4422b80b35aee11bcbcfd19582bdb3851b6168ba985f2ae6da82540c57aaa1f1','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a16c795218e26be5a1712adfddaa4bcba2bee3f734059a611d02745749d00d5',1994,'SC','Seychelles','geography',829,'Location: Eastern Africa in the western
Indian Ocean northeast of Madagascar
Map references: Africa, Standard Time
Zones of the World
Area:
total area: 455 sq km
land area; 455 sq km
comparative area: slightly more than 2.5 limes
the size of Washington, E)C
Land boundaries: 0 km
Coastline: 491 km
Maritime claims:
continental shelf: 200 nm or the edge of
continental margin
exclusive economic zone: 200 nm
territorial sea; 1 2 nm
International disputes: claims Tromelin
Island
Climate: tropical marine; humid; cooler
season during southeast monsoon (late May to
September); warmer season during northwest
monsoon (March to May)
Terrain: Mahe Group is granitic, narrow
coastal strip, rocky, hilly; others are coral, flat,
elevated reefs
Natural resources: fish, copra, cinnamon
trees
Land use:
arable land: 4%
permanent crops: 18%
meadows and pastures: 0%
forest and woodland: 1 8%
other; 60%
Irrigated land: NA sq km','b437ffb475531304e5e54dc7c2740733b59e27812687fc68b7421255b03ba57f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('adcb33343def316aa6764bdd0eada81233ca4014bb369e9ee1f8c25e3d3603f0',1994,'SG','Singapore','geography',837,'Location: Southeastern Asia, between
Malaysia and Indonesia
Map references: Asia, Southeast Asia,
Standard Time Zones of the World
Area:
total area: 632.6 sq km
land area: 622.6 sq km
comparative area: slightly less than 3.5 times
the size of Washington, I3C
Land boundaries: 0 km
Coastline: 193 km
Maritime claims:
exclusive Jishing zone: 12 nm
territorial .sea: 3 nm
International disputes: two islands in
dispute with Malaysia
Climate: tropical; hot, humid, rainy; no
pronounced rainy or dry seasons;
thunderstorms occur on 40% of all days (67%
of days in April)
Terrain: lowland; gently undulating central
plateau contains water catchment area and
nature preserve
Natural resources; fish, deepwater pons
Land use:
arable land: 4%
permanent crops: 7%
meadows and pastures: 0%
forest and woodland: 5%
other: 84%
Irrigated land; NA sq km','c249e6b50af7077e8701c01108019f3f34809f2bf4658b186775466d82b1b9ee','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9fd68f1ec3f324d9da7ca831040301018aea3cd28d10afade504fbe68ec13e44',1994,'SK','Slovakia','geography',842,'Location: Central Europe, between Hungary
and Poland
Map references: Ethnic Groups in Eastern
Europe, Europe, Standard Time Zones of the
World
Area:
total area: 48,845 sq km
land area: 48.800 sq km
comparative area: about twice the size of New
Hampshire
Land boundaries: total l,35S km. Austria 91
km. Czech Republic 2 1 ,5 km, Hungary 5 1 5 km,
Poland 444 km, Ukraine 90 km
Coastline: 0 km (landlocked)
Maritime claims: none; landlocked
International disputes: Gabcikovo Dam
dispute with Hungary; unresolved property
issues with Czech Republic over redistribution
of former Czechoslovak federal property
Climate: temperate; cool summers; cold,
cloudy, humid winters
Terrain: rugged mountains in the central and
northern part and lowlands in the south
Natural resources: brown coal and lignite;
small amounts of iron ore, copper and
manganese ore; salt
Land use:
arable land: NA%
permanent crops: NA9f
meadows and pastures; NA%
forest and woodland: NA%
other: NA9f-
Irrigated land: NA sq km','230dc33ca43faf98c87b683e935cbfb306d028fbb851359dbab0cad5f6fbddbf','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c84c0347e245ac3db26eabd4e4974135a91b9d4fac12d90668b78164c8c6f00',1994,'SI','Slovenia','geography',847,'Location: Balkan State. Southeastern Europe,
bordering the Adriatic Sea. between Austria
and Croatia
Map references: Ethnic Groups in Eastern
Europe, Europe, Standard Time Zones of the
World
Area:
total area; 20,296 sq km
land area; 20,296 sq km
comparative area; slightly larger than New','5ecf8a90ee4bce2c4757cfdb8bf583c7eaf39f328f779ccf3c89cac01ae01909','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3b86e868cc2864af91321a2d05436a5d82170f881efa73809663a4c49251ee2',1994,'SB','Solomon Islands','geography',849,'Location: Oceania, Melanesia, just east of
Papua New Guinea in the South Pacific Ocean
Map references: Oceania, Standard Time
Zones of the World
Area:
loial area: 28,450 sq km
land area: 27,540 sq km
comparative area; slightly larger than
Maryland
Land boundaries: 0 km
Coastline: 5.313 km
Maritime claims; measured from claimed
archipelagic baselines
exclusive economic zone; 200 nm
territorial sea: 1 2 nm
International disputes: none
Climate: tropical monsoon; few extremes of
temperature and weather
Terraiii: mostly rugged mountains with .some
low coral atolls
Natura. resources: fish, forests, gold,
bauxite, phosphates, lead, zinc, nickel
Land use:
arable land; 1 %
permanent crops: 1 9c
meadows and pastures: 1 %
forest and v. o iJIand: 93%
other: 4%
Irrigated land: NA sq km','05688011cd2daaad83241bb8f4accad4c5dce704fc72f7b5f6bb0270d04ce289','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04289411bee7c246d9bb16d0c7a10eda848dfac2a7b88509c7f117b19308b099',1994,'SO','Somalia','geography',856,'Location: Eastern Africa, bordering the
northwestern Indian Ocean, south of the
Arabian Peninsula
Map references: Africa, Standard Time
Zones of the World
Area:
total area: 637,660 sq km
land area: 627,340 sq km
comparative area: slightly smaller than Texas
Land boundaries: total 2,366 km, Djibouti
58 km, Ethiopia 1,626 km, Kenya 682 km
Coastline; 3,025 km
Maritime claims;
territorial sea: 200 nm
International disputes: southern half of
boundary with Ethiopia is a Provisional
Administrative Line; territorial dispute with
Ethiopia over the Ogaden
Climate: desert; northeast monsoon
(December to February), cooler southwest
monsoon (May to October); irregular rainfall;
hot, humid periods (tangambili) between
monsoons
Terrain: mostly flat to undulating plateau
rising to hills in north
Natural resources; uranium and largely
unexploited reserves of iron ore, tin, gypsum,
bauxite, copper, salt
Land use;
arable land: 2%
permanent crops: 0%
meadows and pasture.s: 46%
forest and woodland: 14%
other: 38%
Irrigated land: 1 ,600 sq km ( 1989 est,)','ec41d3d2ef2168e4eb45c1fb8b6d68c32bdd9051529aa0076bbb68e0e1b9ea9a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0b4500dd254617193c1cfcbdaea9e3252aa24fa69dfe69d2558e784e7f850aa',1994,'SR','Suriname','geography',869,'Location: Northern South America,
bordering the North Atlantic Ocean between
French Guiana and Guyana
Map references: South America, Standard
Time Zones of the World
Area:
total area: 163,270 sq km
land area: 161,470 sq km
comparative area: slightly larger than Georgia
Land boundaries: total 1 ,707 km, Brazil 597
km. French Guiana 510 km. Guyana 600 km
Coastline; 386 km
Maritime claims:
exclusive economic zone: 200 nni
territorial sea: 12 nm
International disputes: claims area in French
Guiana between Liloni Rivier and Riviere
Marouini (both headwaters of the Lawn
Rivier); claims area in Guyana between New
(Upper Couraniyne) and Courantyne/Koetari
Rivers (all headwaters of the Courantync)
Climate; tropical; moderated by trade winds
Terrain: mostly rolling hills; narrow coastal
plain with swamps
Natural resources: timber, hydropower
potential, fish, shrimp, bauxite, iron ore. and
small amounts of nickel, copper, platinum,
gold
Land use;
arable land: 0%
permanent crops: 0%
meadows and pastures: 0%
forestand woodland: 97%
other: 3%''
Irrigated land: 590 sq km (1989 est.)
Location: Nordic State, Northern Europe in
the Arctic Ocean where the Arctic Ocean,
Barents Sea, Greenland Sea, and Norwegian
Sea meet, 445 km north of Norway
Map references: Arctic Region, Asia,
Standard Time Zones of the World
Area:
total area; 62,049 sq km
land area: 62,049 sq km
comparative area: slightly smaller than West
Virginia
note: includes Spitsbergen and Bjomoya (Bear
Island)
Land boundaries: 0 km
Coastline: 3,587 km
Maritime claims:
exclusive fishing tone: 200 nm unilaterally
claimed by Norway but not recognized by
Russia
territorial sea: 4 nm
international disputes: focus of maritime
boundary dispute in the Barents Sea between
Norway and Russia
Climate: arctic, tempered by warm North
Atlantic Current, cool summers, cold winters;
North Atlantic Cuiient flows along west and
north coasts of Spitsbergen, keeping water
open and navigable most of the year
Terrain: wild, rugged mountains; much of
high land ice covered; west coast clear of ice
about half the year; Ijords along west and north
coasts
Natural resources: coal, copper, iron ore,
phosphate, zinc, wildlife, fish
Land use:
arable land; 0%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland; 0%
other: 100% (no trees and the only bushes are
crowberry and cloudberty)
Irrigated land: NA sq km
Location: Southern Africa, between
Mozambique and South Africa
Map references: Africa, Standard Time
Zones of the World
Area:
tiiiid area: 17,360 sq km
land area: 17,200 sq km
comparative area; slightly smaller than New','7d223b943b88011a983b5d47f638d35fb1c17914e87f419d4f58268915ca4a5b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bdecf51d8b72a5fc484f793c1ed5461c44f1cef1fa71a275239d3c2755ef328',1994,'TT','Trinidad and Tobago','geography',880,'Location: Caribbean, in the extreme
southeastern Caribbean Sea. II km ofT the
coast of Venezuela
Map raferenccs: Central America and the
Caribbean. South America. Standard Time
Zones of the World
Area:
total area: S. 1 30 sg km
land area; .3.1,30 sq km
comparath''e area: slightly smaller than
Delaware
Ijind houmiarics: 0 km
Coastline: 362 km
Maritime claims:
contiguous ztme: 24 nm
continental shelf: 200 nm or the outer edge of
continental margin
exclusive economic zone; 200 nm
territorial sea: 1 2 nm
International disputes: none
Climate: tropical: rainy season (June to
December)
Terrain: mostly plains with some hills and
low mountains
Natural resources: petroleum, natural gas.
asphalt
Land us>
arable land: \\4%
permanent crops: \\1%
meadows and pastures: 2%
forest and woiHlIand: 44%
other; 23%
Irrigated land: 220sq km (I9g9est.)
Location; Southern Africa, in the western
Indian Ocean, 3.50 km east of Madagascar and
600 km north of Reunion
Map references: World
Area:
total area: I sq km
land area: I sq km
comparative area: about 1 .7 times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 3.7 km
Maritime claims;
cotitiguous zone: 1 2 nm
mntinental she(f; 200-m depth or to depth of
exploitation
exclusive economic zrme: 200 nm
territorial sea: 1 2 nm
International disputes; claimed by
Madagascar. Mauritius, and Seychelles
Oinmte; tropical
Terrain: sandy
Natural resources; fish
Land use:
arable haul: 0%
permanent iwps: 0%
meadows and pastures: 0%
forest and w(MHllund; 0%
other: 100% (scattered bushes)
Irrigated land: Osqkm','969aa745d7328d3a1f210e2cd46ed5ce77a3e57832a8c1d0d0414eb1cfb35042','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed0eedaf1e261c6ac22af036f23dd5e657f190067301a1acf8a2e84dda009e46',1994,'TM','Turkmenistan','geography',882,'Location: Central Asia, bordering the
Caspian Sea, between Iran and Uzbekistan
Map references: Asia, Commonwealth of
Independent States — Central Asian States,
Standard Time Zones of the World
Area:
lolal area: 488, 100 sq km
land area: 488,100 sq km
comparative area: slightly larger than
California
Land boundaries: total 3,736 km,
Afghanistan 744 km, Iran 992 km, Kazakhstan
379 km, Uzbekistan 1,621 km
Coastline: 0 km
note: Turkmenistan borders the Caspian Sea
(1,768 km)
Maritime claims: landlocked, but boundaries
in the Caspian Sea with Azerbaijan,
Kazakhstan, and Iran are under negotiations
International disputes: Russia may dispute
current de facto maritime border to midpoint of
Caspian Sea from shore
Climate; subtropical desen
Terrain; flat-to-rolling sandy de.sen with
dunes rising to mountains in the south; low
mountains along border with Iran; borders
Caspian Sea in west
Natural resources; petroleum, natural gas,
coal, sulphur, salt
l..and use;
arable land: 3%
permanent crops: 0%
meadows and pastures: 69%
forest and woodland: 0%
other: 28%
Irrigated land: 1 2,450 sq km ( 1990)','8db57e94263d1f4288d02e35d2d04f213bbf62a98d9fdf681134c6677566085e','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45b7164a310a9a740399438d78fa6924e452db8ebd35c4d9a9e4eeb8cfa4b040',1994,'BS','Bahamas','geography',887,'Map references: Central America and the
Caribbean
Area:
total area: 430 sq km
land area: 430 sq km
comparative area: slightly less than 2.5 times
the size of Washington. DC
Land boundaries: 0 km
Coastline: 389 km
Maritime claims:
exclusive fishing zone: 200 nm
territorial sea: 1 2 nm
International disputes; none
Climate: tropical: marine: moderated by trade
winds: sunny and relatively dry
Terrain; low, flat limestone; extensive
marshes and mangrove swamps
Natural resources: spiny lobster, conch
Land use:
arable land: 2%
permanent crops: 0%
meadows and pastures: 0%
forest and woodland: 0%
other: 98%
Irrigated land: NA sq km','ab2a24714007c0b638add2320e4942eb25438a8d28d6b7f44f719808b8ab05aa','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ed1587b7c9e88ce74a9cfcc866a4a202245b6e453ce1a847bcf2fd7faed5081',1994,'TV','Tuvalu','geography',894,'Location: O .jiia, Polynesia, 3,000 km east
of Papua New Guinea in the South Pacific
Ocean
Map references: Oceania, Standard Time
Zones of the World
Area:
total area: 26 sq km
land area; 26 sq km
comparative area: about 0. 1 times tlie size of
Washington, DC
Land boundaries: 0 km
Coastline; 24 km
Maritime claims:
contiguous zone; 24 nm
exclusive economic zone; 200 nm
territorial sea; 12 nm
Intematiorud disputes: none
Climate: tropical; moderated by easterly trade
winds (March to November); westerly gales
and heavy rain (November to March)
Terrain: very low-lying and narrow coral
atolls
Natural resources: fish
Land use;
arable land: 0%
permanent crops; 0%
meadows and pastures; 0%
forest and woodland: 0%
other; 100%
Irrigated land: NAsqkm
Elnvlronmcnt;
current issues; since there are no streams or
rivers and groundwater is not potable, ail water
needs must be met by catchment systems with
storage facilities
natural hazards: severe tropical storms ate
rare
international agreements; party to — Climate
Change, Ozone Layer Protection, Ship
Pollution; signed, but not ratified —
Biodiversity, Law of the Sea','7c5e42d5d40cb490260dae1804b2563f853a783860dae10d619e9fd288289caa','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('caa732b2a538b28e7a2b84a33eaba921fbb98f47f7f8a5a8f843b4e872009fc0',1994,'UG','Uganda','geography',897,'Location: Eastern Africa, between Kenya and
Zaire
Map references; Africa, Standard Time
Zones of the World
Area:
total area: 236,040 sq km
land area: 1 99,7 1 0 sq km
comparative area: slightly smaller than
Oregon
Land boundaries: total 2,698 km, Kenya 933
km, Rwanda 169 km, Sudan 435 km, Tanzania
396 km, Zaire 765 km
Coastline: 0 km (landlocked)
Maritime claims; none; landlocked
International disputes: none
Climate: tropical; generally rainy with two
dry seasons (December to February, June to
August); semiarid in northeast
Terrain: mostly plateau with rim of
mountains
Natural resources: copper, cobalt, limestone,
salt
Land use:
arable land: 23%
permanent crops; 9%
meadows and pastures: 25%
forest and woodland: 30%
other: 13%
Irrigated land: 90 sq km ( 1989 est.)','8e2541b52bfc93971458a6c5a40bb40e238d74fa9cdd54fdf270d8b18807fd08','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13e70a0ef067a6fac0cd2d7d9228c1b4c70e3e295f43825e4f9426db22a655e7',1994,'AE','United Arab Emirates','geography',903,'Location: Middle Bust, along the Persian
Gulf, between Oman and Saudi Arabia
Map references: Middle East, Standard Time
Zones of the World
Area:
total area: 75,581 sq km
land area; 75,581 sq km
comparative area; slightly smaller than Maine
Land boundaries: total 867 km, Oman 410
km, Saudi Arabia 457 km
Coastline: 1,3 1 g km
Maritime claims:
continental xhelf; defined by bilateral
boundaries or equidistant line
exclusive economic zone; 200 nm
territorial sea; 3 nm assumed for most of
country; 12 nm for Ash Shariqah (Sharjah)
International disputes: location and status of
boundary with Saudi Arabia is not final: no
defined boundary with most of Oman, but
Administrative Line in far nonh: claims two
islands in the Persian Gulf occupied by Iran
(Jazirch-ye Tonb-e Bozorg or Greater Tunb,
and Jazireh-yc Tonb-e Kuchek or Lesser
Tunb); claims island in the Persian Gulf jointly
administered with Iran (Jazireh-ye Abu Musa
or Abu Musa); in 1992, the dispute over Abu
Musa and the Tunb islands became more acute
when Iran unilaterally tried to control the entry
of third country nationals into the U AE portion
of Abu Musa island, Tehran sub.sequently
bucked off in the face of significant diplomatic
support for the UAE in the region
Climate; desert: cooler in eastern mountains
Terrain: flat, barr :n coastal plain merging
into rolling sand dunes of vast desert
wasteland; mountains in east
Natural resources: petroleum, natural gas
Land use:
arable land: {)%
permanent crops; ()9f
meadows and pastures: 2%
forest and woiHlIaiul; OCf
other; 98''7r
Irrigated land; 50 sq km (1989 est.)
Location: Western Europe, bordering on the
North Atlantic Ocean and the North Sea,
between Ireland and France
Map reltoences: Europe, Standard Time
Zones of the World
Area:
total area; 244,820 sq km
land area; 24 1 ,590 sq km
comparath’e area; slightly smaller than
Oregon
note; includes Rockall and Shetland Lslands
Land houndaries: total 360 km. Ireland 360
kill
Coastline: 12,429 km
Maritime daims:
continental shelf; as defined in continental
shelf orders or in accordance with agreed upon
boundaries
exclushw fishing zone; 200 nm
territorial sea; 1 2 nm
International riitputes: Northern Ireland
question with Ireland; Gibraltar question with
Spain; Argentina claims Falkland Islands (Islas
Malvinas); Argentina claims South Georgia
and the South Sandwich Islands; Mauritius
claims isiand of Diego Garcia in British Indian
Ocean Territory; Rockall continental shelf
dispute involving Denmark, Iceland, and
Ireland (Ireland and the UK have signed a
bounrlaty agreement in the Rockall area);
territorial claim in Antarctica (British Antarctic
Territory)
Climate: temperate; moderated by prevailing
southwest winds over the North Atlantic
Current; mote than half of the days are overcast
Terrain: mostly rugged hills and low
mountains; level to rolling plains in east and
southeast
Natural rcaourcca: coal, petroleum, natural
gas. tin. limestone, iron ore. salt. clay, chalk.
gypsum, lead, silica
Landuae:
arable land; 29%
permanent crops; 0%
metxiows and pastures; 48%
413
United Kingdom (coitimed)
forest and woodland: 9%
other; 14%
Irrigated land; 1 ,370 sq km ( 1 989)','204d3be12d0e4b38d7548d49452879ec1b81c1ef3f722c3ec1b88cbe9009ea43','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78009a4fdc12de0a600ab81819e2e27ef348abae95b5df384f8e65cbbec1128a',1994,'US','United States','geography',909,'Location: North America, between Canada
and Mexico
Map references: North America, Standard
Time Zones of the World
Area:
total area: 9,372,610 sq km
land area: 9, 166,600 sq km
comparative area: about half the size of
Russia: about three-tenths the size of Africa;
about one-half the size of South America (or
slightly larger than Brazil); slightly smaller
than China; about two and one-half times the
size of Western Europe
note: includes only the SO states and District of
Columbia
Land boundaries: total 12,248 km, Canada
8.893 km (including 2,477 km with Alaska),
Cuba 29 km (US Naval Base at Guantanamo
Bay). Mexico 3,326 km
Coastline: 19.924 km
Maritime claims;
contiguous lone: 24 nm depth
continental shelf: 200-m depth or to depth of
exploitation
exclusive economic zone: 2(X) nm
territorial sea: 1 2 nm
International disputes: maritime boundary
disputes with Canada (Dixon Entrance,
Beaufort Sea, Strait of Juan de Fuca); US
Naval Base at Guantanamo Bay is leased from
Cuba and only mutual agreement or US
abandonment of the area can terminate the
lease; Haiti claims Navassa Island; US has
made no territorial claim in Antarctica (but has
reserved the right to do so) and does not
recognize the claims of any other nation:
Republic of Marshall Islands claims Wake
Island
Climate: mostly temperate, but tropical in
Hawaii and Florida and arctic in Alaska,
semiarid in the great plains west of the
Mississippi River and arid in the Great Basin of
the southwest; low winter temperatures In the
northwest arc ameliorated occasionally in
January and February by warm chiiook winds
from the eastern slopes of the Rocky
Mountains
Terrain: vast central plain, mountains in
west, hills and low mountains in east; nigged
mountains and broad river valleys in Alaska;
rugged, volcanic topography in Hawaii
Natural resources: coal, copper, lend,
molybdenum, phosphates, uranium, bauxite,
gold, iron, mercury, nickel, potash, silver,
tungsten, zinc, petroleum, natural gas, timber
Land use:
arable land: 20%
permanent crops: 0%
meadows and pastures: 26%
forest and woodland: 29%
other: 25%
Irrigated land: 181,020 sq km (1989 e.sl.)','45ec3d85edb58666c5eee9ce8c43b1714326f102255d6daa8dff1103cd09a184','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9cd64c58a2a04e575d914d0b4ab82aff8e4e5b955f543c03c422408cbc470ae',1994,'UY','Uruguay','geography',914,'Location: Southern South America,
bordering the South Atlantic Ocean between
Argentina and Brazil
Map references: South America, Standard
Time Zones of the World
Area:
total area: 176,220 sq km
larul area: 173,620 sq km
comparative area: slightly smaller than
Washington State
Land boundaries: total 1,564 km, Argentina
579 km. Brazil 985 km
Coastline: 660 km
Maritime claims:
continental shelf; 200-m depth or to depth of
exploitation
territorial sea: 200 nro; overflight and
navigation permitted beyond 12 nm
International disputes: short section of
boundary with Argentina is in dispute; two
short sections of the boundary with Brazil are
in dispute — Arroyo de la Invemada (Atroio
Invemada) area of the Rio (Juarai and the
islands at the confluence of the Rio Cluareim
(Rio Quarai) and the Uruguay River
Climate: warm temperate; fteezing
temperatures almost unknown
Terrain; mostly roiling plains and low hills;
fertile coastal lowland
Natural resources: soil, hydropower
potential, minor minerals
Land use:
arable larul; 8%
permanent crops; 0%
meadows and pastures: 78%
forest and woodlarui: 4%
other: 10%
Irrigated land: 1,100 sq km (1989 eit.)','7d2e4a4b14d66e944b88fe3dfdd8847e91d8595f357f32a8baf8d534552257dc','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e97ded17e98f4454a80630b86453a63785e858a9d96f45becbf89f7d219fbe6',1994,'UZ','Uzbekistan','geography',920,'Location: Central Asia, bordering the Aral
Sea, between Kazakhstan and Turkmenistan
Map references: Asia, Commonwealth of
Independent States — Central Asian States,
Standard Time Zones of the World
Area:
total area; 447,400 sq km
land area: 425,400 sq km
comparative area; slightly larger than
California
Land boundaries: total 6,221 km,
Afghanistan 137 km, Kazakhstan 2,203 km,
Kyrgyzstan i .099 km, Tajikistan 1,161 km,
Turkmenistan 1,621 km
Coastline: 0 km
note; Uzbekistan borders the Aral Sea (420
km)
Maritime claims; none; landlocked
International disputes: Russia may dispute
current de facto maritime border to midpoint of
Caspian Sea from shore
Climate: mostly midlatitude desert, long, hot
summers, mild winters; semiarid grassland in
east
Terrain: mostly flat-to-rolling sandy desert
with dunes; broad, flat intensely irrigated river
valleys along course of Amu Darya and
Sirdaryo Rivers; Fergana Valley in east
surrounded by mountainous Tajikistan and
Kyrgyzstan; shrinking Aral Sea in west
Natural resources: natural gas, petroleum,
coal, gold, uranium, silver, copper, lead and
zinc, tungsten, molybdenum
Land use:
arable land: 10%
permanent crops; 1%
meadows and pastures; 47%
forest and woodland: 0%
other: 42%
Irrigated land: 41,550 .sq km (1990)','900931ef847e4f11e00adcea8e49734ef21facf4da509ef208e14e71c58c6c3f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e24e2ee87329f1bdb2e1bed0afc85f646db798ececf80c1f5aa8181581b95443',1994,'VU','Vanuatu','geography',926,'Location: Oceania, Melanesia, 5,750 km
southwest of Honolulu in the South Pacific
Ocean, about three-quarters of the way
between Hawaii and Australia
Map references: Oceania, Standard Time
Zones of the World
Area:
total area: 14,760 sq km
land area: 14,760 sq km
comparative area: slightly larger than
Connecticut
note: includes more than 80 islands
Land boundaries: 0 km
Coastline; 2,528 km
Maritime claims: measured from claimed
archip.lagic baselines
contiguous zone: 24 nm
continental shelf: 200 nm or the edge of
continental margin
exclusive economic zone: 2(X) nm
territorial sea: 12 nm
IntemaUonal disputes: none
Climate: tropical; moderated by southeast
trade winds
Terrain; mostly mountains of volcanic
origin; narrow coastal plains
Natural resources: manganese, hardwood
forests, fish
Land use:
arable land: 1 %
permanent crops: 5%
meadows and pastures: 2%
forest and woodland: \\%
other: 91%
Irrigated land: NA sq km
Location: Northern South America,
bordering the Caribbean Sea between
Colombia and Guyana
Map references; South America, Standard
Time Zones of the World
Area:
total area; 9 1 2,050 sq km
land area: 882,050 sq km
comparative area: slightly more than twice the
size of California
Land boundaries: total 4,993 km, Brazil
2,200 km, Colombia 2,050 km, Guyana 743
km
Coastline: 2,800 km
Maritime claims;
contiguous zone: 1 5 nm
continental shelf; 200-m depth or to depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
International disputes: claims all of Guyana
west of the Essequibo River: maritime
boundary dispute with Colombia in the Gulf of
Venezuela
Climate; tropical: hot. humid: more moderate
in highlands
Terrain; Andes Mountains and Maracaibo
Lowlands in northwest: central plains (llanos):
Guiana Highlands in southeast
Natural resources: petroleum, natural gas.
iron ore, gold, bauxite, other minerals.
hydropower, diamonds
Land use:
arable land:
permanent crops: I %
meadows and pastures: 20Vr
forest and woodland: 3991-
oiher: 21%
Irrigated land: 2,640 sq km (1989 est.)','f1bc9885bb18ff13a4160a59196e1d98d2222d510bdbc4fe64287bbd9dd9fe80','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5968101623ddc9783c9d151565f48ff20eaf997cc3498c8a39389b30f97c2444',1994,'WF','Wallis and Futuna','geography',932,'Location: Oceania. Micronesia, in the North
Pacific Ocean. 3,700 km west of Honolulu,
about two-thiids of the way between Hawaii
and the Northern Mariana Islands
Map references: Oceania
Area:
total area; 6.S sq km
land area: 6.5 sq km
comparative area: about 1 1 times the size of
The Mall in Washington. DC
Land boundaries: (i km
Coastline: 19.3 km
Maritime claims:
contiguous zone: 24 nm
continental shelf; 200-m depth or to depth of
exploitation
exclusive economic zone: 200 nm
territorial .sea; 1 2 nm
International disputes: claimed by the
Republic of the Marshall Islands
Climate: tropical
Terrain: atoll of three coral islands built up
on an underwater volcano: central lagoon is
former crater, islands arc part of the rim;
average elevation less than 4 meters
Natural resources: none
Land use:
arable land: 0%
permanent crops: Q%
meadows and pastures; (F/r
forest and woodland: 0%
other: 100%
Irrigated land: 0 sq km
Location: Oceania. Polynesia in the South
Pacific Ocean. 4,6(X) km southwest of
Honolulu, about two-thirds of the way from
Hawaii to New Zealand
Map references: Oceania
Area:
total area; 274 sq km
land area; 274 sq km
comparative area; slightly larger than
Washington, DC
note; includes He Uvea (Wallis Island). He
Futuna (Futuna Island), He Alofi, and 20 islets
Land boundaries: 0 km
Coastline: 129 km
Maritime claims:
e.xclusive economic zone; 200 nm
territorial sea: 12 nm
International disputes: none
Climate: tropical; hot, rainy season
(November to April); cool, dry season (May to
October)
Terrain: volcanic origin; low hills
Natural resources: negligible
Land use:
arable land; 5%
permanent crops: 20%
meadows and pastures: 0%
forest and woodland: 0%
other; 75%
Irrigated land: NA sq km
l.«cation: Middle East, between Jordan and','0da68c072e3363dad100bdb7453832275c26b7abbc7bdb191dae5e06ffcb09ad','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c08d820d0f8f48592985fc09b5c333784c7ce13a85c01ea33c3f6029c0972162',1994,'EH','Western Sahara','geography',943,'Location: Northern Africa, along the Atlantic
Ocean, between Morocco and Mauritania
Map references: Africa, Standard Tinie
Zones of the World
Area:
total area; 266,000 sq km
land area; 266,000 aq km
comparative area: slightly smaller than
Colorado
Land boundaries: total 2,046 km. Algeria 42
km, Mauritania 1,561 km, Morocco 443 km
Coastline; 1,1 10 km
Maritime claims; contingent upon re.solution
of sovereignty issue
International disputes; claimed and
administered by Morocco, but sovereignty is
unresolved and the UN is attempting to hold a
referendum on the issue; the UN-administered
cease-fire has been currently in effect since
September 1991
Climate; hot. dry desert; rain is rare; cold
offshore air currents produce fog and heavy
dew
Terrain: mostly low, flat desert with large
areas of rocky or sandy surfaces rising to small
mountains in south and northeast
Natural resources: phosphates, iron ore
Land use:
arable land; 0%
permanent crops: 0%
meadows and pa.sture.s: 1 9%
forest and woodland: 0%
other; 8 1 %
Irrigated land: NA sq km
Location: Oceania, Polynesia, 4,300 km
southwest of Honolulu in the South Pacific
Ocean, about halfway between Hawaii and','dec23eee895217d8fd731866a0d9bc0bd62cae1284af6d238ca40aee96cd0a56','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4e597c436763f672a808b693a4f1e7dd21a086212a6164856ad98e11efeff39',1994,'YE','Yemen','geography',948,'Location: Middle East, along the Red Sea and
the Arabian Sea, south of Saudi Arabia
Map references: Africa. Middle East,
Standard Time Zones of the World
Area:
total area: 527,970 sq km
land area; 527,970 sq km
comparative area; slightly larger than twice
the size of Wyoming
note: includes Perim, Socotra, the former
Yemen Arab Republic (YAR or North
Yemen), and the former People''s Democratic
Republic of Yemen (PDRY or South Yemen)
Land boundaries: total 1 .746 km, Oman 288
km, Saudi Arabia 1,458 km
Coastline: 1.906 km
Maritime claims:
contiguous zone: 1 8 nm in the North; 24 nm in
the South
continental shelf: 200-m depth in the North:
200 nm in the South or to the edge of the
continental margin
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
International disputes: undefined section of
boundary with Saudi Arabia; a treaty with
Oman defining the Yemeni-Omani boundary
was ratified in December 1992
Climate: mostly desert; hot and humid along
west coast; temperate in western mountains
affected by seasonal monsoon; extraordinarily
hot, dry, harsh desert in east
Terrain: narrow coastal plain backed by flat-
topped hills and rugged mountains: dissected
upland desert plains in center slope into the
desert interior of the Arabian Peninsula
Natural resources: petroleum, fish, rock salt,
marble, small deposits of coal, gold, lead,
nickel, and copper, fertile soil in west
Land use:
arable land: 6%
permanent crops: 0%
meadows and pastures: 30%
forest and woodland; 7%
other; 57%
436
Irrigated land: 3, 1 00 sq km ( 1 989 est.)','a608f99584a19760117b194d770c6acd1f84e9b9a9e6d3126f7323e8fabc003f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7aca85983e9701a78d092bc5604b6d13dcdc152174fd7d94c083d212f88dd8dc',1994,'ZM','Zambia','geography',953,'Map references: Africa, Standard Time
Zones of the World
Area:
total area: 2,345,410 sq km
land area: 2,267,600 sq km
comparative area: slightly more than one-
quarter the size of US
Land boundaries: total 10,271 km, Angola
2,51 1 km, Burundi 233 km. Central African
Republic 1,577 km. ^ongo 2,410 km, Rwanda
217 km, Sudan 628 kiti, Uganda 765 km,
Zambia 1,930 km
Coastline: 37 km
Maritime claims:
exclusive fishing zotu: 200 nm
territorial sea: 12 nm
International disputes: Tanzania-Zaire-
Zambia tripoint in Lake Tanganyika may no
longer be indefinite since it is reported that the
indefinite section of the Zaire-^mbia
boundary has been settled; long section with
Congo along the Congo River is indefinite (no
division of the river or its islands has been
made)
Clinute: tropical ; hot and humid in equatorial
river basin; cooler and drier in southern
highlands; cooler and wetter in eastern
highlands; north of Equator — wet season April
to October, dry season December to February;
south of Equator— wet season November to
March, dry season April to October
Terrain: vast central basin is a low-lying
plateau; mountains in east
Natural resources: cobalt, copper, cadmium,
petroleum, industrial and gem diamonds, gold,
silver, zinc, manganese, tin, germanium,
uranium, radium, bauxite, iron ore. coal,
hydropower potential
Land use:
arable land: 3%
permanent crops; 0%
meadows and pastures; 4%
forestand woodland: 78%
other; 15%
438
Irrigated land: 100 sq km ( 1989 est.)
Location: Southern Africa, between Zaire and','17093b85f0095c655e3206f6901329d2ff168edcd11316409ae8c1bf41b80441','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68385e733b4fae89ff1171e26cc01108c0fa5de816becd263913873223c7e604',1994,'PK','Pakistan','communications',11,'Railroads: 9.6 km (single track) 1.524-meter
gauge from Gushgy (formerly Kushka)
(Turkmenistan) to Towraghondi and 15.0 km
from Termiz (Uzbekistan) to Kheyrabad
transshipment point on south bank of Amu
Darya
Highways:
total: 21,000 km
paved: 2,800 km
unpaved: gravel 1 ,650 km; earth 16,550 km
(1984)
Inland waterways: total navigability 1,200
km; chiefly Amu Darya, which handles vessels
up to about 500 metric tons
npelines: petroleum products — Uzbekistan
to Bagram and Turkmenistan to Shindand;
natural gas 1 80 km
Ports; Shir Khan and Kheyrabad (river ports)
Airports:
total: 42
usable: 35
with permanent-suiface runways: 9
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 10
with runways 1,220-2,439 m: 17
Telecommunications: limited telephone,
telegraph, and radiobroadcast services;
television introduced in 1980; 31.200
telephones; numerous cellular telephones;
broadcast stations — 5 AM, no FM, 1 TV; 1
satellite earth station
Defense Forces
Branches: the military still does not yet exist
on a national scale; some elements of the
former Army, Air and Air Defense Forces,
National Guard, Border Guard Forces.
National Police Force (Sarandoi), and tribal
militias remain intact but are factionalized
among the various mujahedin and former
regime leaders
Manpower availability: males age 15-49
4,188,036; fit for military service 2,245,196;
reach military age (22)annually 158,335 (1994
est.)
Defense expenditures: the new government
has not yet adopted a defense budget
2
[ Albania
I
Location: Balkan State, Southeastern Europe.
on the Balkan Peninsula between Serbia and
Montenegro and Greece
Map references: Africa, Ethnic Groups in
Eastern Europe, Europe, Standard Time Zones
of the World
Area:
total area: 28,750 sq km
land area; 27.400 sq km
comparative area; slightly larger than
Maryland
Land boundaries: total 720 km. Greece 282
km. The Former Yugoslav Republic of
Macedonia IS I km. Serbia and Montenegro
287 km (1 14 km with Serbia, 173 km with
Montenegro)
Coastline: 362 km
Maritime claims:
continental shelf; not specified
territorial sea: 12 nm
International disputes: Albanian majority in
Kosovo seeks independence from Serbia and
Montenegro, and the Albanian Government
supports the Kosovo position politically
Climate: mild temperate; cool, cloudy, wet
winters; hot, clear, dry summers; interior is
cooler and wetter
Terrain: mostly mountains and hills; small
plains along coast
Natural resources: petroleum, natural gas,
coal, chromium, copper, timber, nickel
Land use:
arable land; 2 1 %
permanent crops: 4%
meadows and pastures; 15%
forest and woodland; 38%
other; 22%
Irrigated land: 4,230 sq km (1989)
Ports; Bangkok (Thailand), Hong Kong. Las
Angeles (US), Manila (Philippines), Pusan
(South Koiea), San Francisco (US), Seattle
(US), Shanghai (Chino), Singapore. Sydney
(Australia), Vladivostok (Russia), Wellington
(NZ), Yokohama (Japan)
Telecommunications: several submarine
cables with network nodal points on Guam and
Hawaii
Railroads: 8,773 km total; 7,7*0 km broad
gauge, 445 km 1 -meter gauge and 6 1 0 km less
than I -meter gauge: 1,037 kri broad-gauge
double track; 286 km electrified: all
government owned ( 1 9S5)
Highways:
total: 1 10,677 km
paved: 58,677 km
unpaved: gravel 23,(XK) km; improved earth
29,000 km (1988)
Pipelines: crude oil 250 km; natural gas 4,044
km; petroleum products 885 km (1987)
Ports: Gwadar, Karachi, Port Muhammad bin
Qasim
Merchant marine: 30 ships ( 1 ,000 GRT or
over) totaling 352,189 GRT/532,782 DWT,
passenger-cargo 3, cargo 25, oil tanker 1, bulk
1
Airports:
total; 1 10
usable; 104
with permanent-surface runways; 75
with runways over 3,659 m: 1
with runways 2,440-3,659 m; 30
with runways 1,220-2,439 m: 43
Telecommunications: the domestic
telephone system is poor, adequate only for
government and business use; about 7
telephones per I, OCX) persons; the system for
international traffic is better and employs both
microwave radio relay and satellites; satellite
ground stations — 1 Atlantic Ocean
INTELSAT and 2 Indian Ocean DrTELSAT:
broadcast stations — 19 AM, 8 FM, 29 TV
Defense Forces
Branches: Army, Navy, Air Force, Civil
Armed Forces, National Guard,
paramilitary/security forces
Manpower availability: males age 15-49
29,548,746; fit for military service 18,1 34,0 1 3;
reach military age (17) annually 1,391,258
(1994 est.)
Defense expenditures: exchange rate
conversion — $3.2 billion, 6% of GNP
(FY91/92)
Ocean','0e92596114f1502db5394fbbdd75da51c0fb5e6751d6d1a3a1c0d85df77f110f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('972521d8d5b2e86b5c0bbff7081328b5005c2f244d875653b6bac0d12ce7646e',1994,'HU','Hungary','communications',13,'Railroads: 543 km total; 509 km 1 .435-meter
standard gauge, single track and 34 km narrow
gauge, single track (1990); line connecting
Titograd (Serbia and Montenegro) and
Shkoder (Albania) completed August 1986
Highways:
total: 16,700 km
paved: 6,700 km
unpaved: earth 10,000 km (1990)
Inland waterways: 43 km plus Albanian
sections of Lake Scutari. Lake Ohrid, and Lake
Prespa (1990)
Pipelines; crude oil 145 km; petroleum
products 55 km; natural gas 64 km (1991 )
Ports: Durres, Sarande, VIore
Merchant marine: 1 1 cargo ships ( 1 .000
CRT or over) totaling 52.967 GRT/76,887
DWT
Airports:
total: 12
usable: 10
with permanent-surface runways; 3
with runways over 3.659 m: 0
with runways 2,440-3,659 m: 6
with runways 1 ,220-2,439 m: 4
Telecommunications: inadequate service;
15,000 telephones; broadca.st stations — 13
AM. I TV; 5 14,000 radios, 255,000 TVs (1987
est.)
Defense Forces
Branches: Army, Navy. Air and Air Defense
Forces, Interior Ministry Troops
Manpower availability: males age 15-49
906.938: fit for military service 746.945; reach
military age (19) annually 33,184 (1994 est.)
Defense expenditures: 215 million leke,
NA% of GNP ( 1993 est.); note — conversion of
defense expenditures into US dollars using the
current exchange rate could produce
misleading results
4
''26 Km
Railroads; 7,765 km total; 7,.5()8 km 1.435-
meter standard gauge. 222 km narrow gauge
''mostly 0.760-meler). 35 km 1.520-meter
broad gauge; 1 .2.36 km double track, 2,249 km
electrified; all government owned (1990)
Highways:
total: 130,224 km
paved: 61.948 km
unpaved: 68.276 km (1988)
Inland waterways; 1.622 km ( 1988)
Pipelines; crude oil 1 ,204 km; natural gas
4,.387 km (1991)
Ports: Budapest and Dunaujvaros are river
ports on the Danube; coastal outlets are
RosttKk (Germany), Gdansk (Poland), Gdynia
(Poland), Szczecin (Poland), Galati (Rumania),
and Braila (Romania)
Merchant marine: 10 cargo ships ( 1 ,0(X)
GRT or over) and 1 bulk totaling 46.121 GRT/
61,613 DWT
Airports:
total: 126
usable; 65
with permanent-surface runways; 1 2
with runways over 3,659 m: I
with runways 2,440-3,659 ni; 18
with runways 1.060-2,439 m: 3 1
note; a C-130 can land on a 1,060-m airstrip
Telecommunications; automatic telephone
network based on microwave radio relay
system; 1 . 1 28,8(X) phones (1991); telephone
density is at 19.4 per 100 inhabitants; 49% of
all phones are in Budapest; 608.(KX) telephones
on order (1991); 12-15 year wait for a phone;
14,2 1 3 telex lines (1991); broadcast stations —
32 AM. 15FM.41 TV (8 Soviet TV repeaters);
4.2 million TVs (1990); 1 satellite ground
station using INTELSAT and Inlersputnik
Defense Forces
Branches: Ground Forces. Air and Air
Defense Forces. Border Guard, Territorial
Defense
Manpower availability: males age 15-49
2.636,888; fit for military service 2,105,628;
reach military age (18) annually 90,134 (1994
est.)
Defense expenditures; 66.5 billion forints,
NA9; of GNP (1993 e.st,); note— conversion of
defense expenditures into US dollars using the
current exchange rale could prixluce
misleading results
181
/','78a3636c76062df22e86b4501ca26f75d897ec935302afc77300bd0b6ffee92c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae65c138fb094f309dcc1a121576fbcb868b3f55470d889b1ddce08579fb8595',1994,'TN','Tunisia','communications',20,'Railroads: 4,060 km total; 2,616 km standard
gauge ( 1 .435 m), 1 , 1 88 km 1 .055-meter gauge,
256 km 1 .0(X)-meter gauge; 300 km electrified;
2 1 5 km double track
Highways;
total: 90,03 1 km
paved: concrete, bituminous 58,868 km
unpaved: gravel, crushed stone, earth 31.163
km (1990)
Pipelines; crude oil 6.612 km; petroleum
products 298 km; natural gas 2,948 km
Ports: Algiers. Annaba, Arzew. Bejaia,
DJendjene, Ghazaouet, Jijel, Mers el Kebir,
Mostaganem, Oran. Skikda
Merchant marine: 75 ships ( 1 ,000 GRT or
over) totaling 903,179 GRT/1,064,21 1 DWT,
short-sea passenger 5, cargo 27, roll-on/rol l-off
cargo 1 2. oil tanker 5. liquefied gas 9. chemical
tanker 7, bulk 9, specialized tanker 1
Airports:
total: 140
usahle: 124
with permanent-surface n«m''av.v.- 53
with runways over 3,659 m: 2
with runways 2,440-3,659 m: 32
with runways 1,220-7,439 m: 65
Telecommunications: excellent domestic
and international .service in the north, sparse in
the .south; 822,0(K) telephones; broadcast
stations— 26 AM. no FM. 1 8 TV; 1 .600.000
TV sets; 5,200,000 radios; 5 submarine cables;
microwave radio relay to Italy. France, Spain,
Morocco, and Tunisia; coaxial cable to
Morocco and Tunisia; satellite earth stations —
1 Atlantic Ocean INTELSAT, 1 Indian Ocean
INTELSAT. 1 Intersputnik, 1 ARABSAT. and
12 domestic; 20 additional satellite earth
stations are planned
Defense Forces
Branches: National Popular Army, Navy, Air
Force, Territorial Air Defense
Manpower availability; males age 15-49
6,863.378; fit for military service 4,215,767;
reach military age ( 1 9) annually 30 1 ,945 ( 1994
est.)
Defense expenditures: exchange rale
conversion — $1.36 billion, 2.5% of GDP
(1993 est.)
6','64134e322d5a5455632d0a0c3274758a4abedd14a58b60bb7cadff12d04a7402','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6419174d8eeb6311c189ffc2e22ce5f408412ddd0fcdfe42805fdaa9dfbb5cd8',1994,'AS','American Samoa','communications',21,'(icrrilory of the US)
* Isitnd
South
Pacific
Ocean
Tutuila o/u
^AQO MQO
pioS»9»
*r»‘u
ffoa*
Isttnd
Ports: none; offshore anchorage only
Airports: lagoon was used as a halfway
station between Hawaii and American Samoa
by Pan American Airways for flying boats in
1937 and 1938
Defense Forces
Note: defense is the responsibility of the US
214
Highways;
total: 640 km
paved: NA
unpaved: NA
Inland waterways: small network of canals,
totaling 5 km, in Line Islands
Ports; Banaba and Betio (Tarawa)
Merchant marine: 1 passenger-cargo ship
(1.000 CRT or over) totaling 1,291 GRT/1,295
DWT
Airports:
total: 2 1
usable: 20
with pennanent-suiface runways: 4
with runways over J, 659 m: 0
with runways 2,440-3,659 m: 0
with runways 1,220-2,439 m: 5
215
Kiribati (continued)
Korea, North
Telecommunications: 1 ,400 telephones;
broadcast stations — 1 AM, no FM, no TV; I
Pacific Ocean INTELSAT earth station
Defense Forces
Branches: Police Force (carries out law
enforcement functions and paramilitary duties;
there are small police posts on all islands); no
military force is maintained
Defense expenditures: SNA, NA% of GDP
Railroads: 4.915 km total; 4.250 km 1.435-
meter standard gauge, 665 km 0.762-meter
narrow gauge; 159 km double track; 3,084 km
electrified; government owned (1989)
Highways;
total: 30,000 km
paved: 1,440 km
unpaved: gravel, crushed stone, earth 28,560
km(l99l)
Inland waterways: 2,253 km; mostly
navigable by small craft only
Pipelines: crude oil 37 km
Ports: primary — Ch''ongjin, Hungnam
(Hamhung), Najin. Namp’o, Wonsan;
secondary — Haeju, Kimch’aek, Kosong,
Sinuiju, Songnim, Sonbong (formerly Unggi),
Ungsang
Merchant marine; 83 ships ( 1 ,000 GRT and
over) totaling 706,497 GRT/1 ,1 14,827 DWT,
passenger 1, short-sea passenger I. passenger-
cargo 2, cargo 67, oil tanker 2, bulk 9,
combination bulk 1
Airports:
total: 55
usable: 55 (est.)
with permanent-surface runways: about 30
with runways over 3.659 m: fewer than 5
with runways 2,440-3,659 m: 20
with runways 1,220-2.439 m: 30
Telecommunications; broadcast stations —
1 8 AM, no FM, 1 1 TV; 300,000 TV sets
(1989); 3,500,000 radio receivers; 1 Indian
Ocean INTELSAT earth station
217
Korea, North uontinued)
Korea, South
Defense Forces
Branches: Korean People''s Army (including
the Army. Navy. Air Force t. Civil Security
Forces
Manpower availabtlity: males age 15-49
6.658.529; fit for military service 4.044,.^55;
reach military age ( 1 8) annually I %,76.1 ( 1 994
est.)
Defense expenditures: exchange rate
conversion — abemt $5 billion, 20''K--25(f'' of
GNP ( 1991 est. I; note — the officially
announced but suspect figure is $2.2 billion
(1994), ab:iut 1 2% of total spending
_ tooBMivtaaraiahtMton II
not nacaiMrUy aylhontitiy*
Gcopraphy
Location: Eastern Asia, between North Korea
and Japan
Map references: Asia. Standard Time Zones
of the World
Area:
tniol I''d. 98,480 sq km
tnnti (II c(i: 98, 1 90 ,sq km
at ''iiuiraiivf circa.'' slightly larger than Indiana
Land boundaries: total 2.18 knt. North Korea
2,18 km
Coastline: 2.41.1km
Maritime claims:
coiiiiiwnial .ihelt'': not .specified
tcrriuirial sea: 1 2 nm; ,1 nm in the Korea Strait
International disputes: Demarcation Line
with North Korea; Liancoun RiK’ks claimed by
Ports: the main harbor is West Lagoon, which
is entered by a channel on the southwest side of
the atoll; both the channel and harbor will
accommodate vessels drawing 6 meters of
water; much of the road and many causeways
built during the war arc unserviceable and
overgrown
Airports:
total: 1
usable: I
with pernument-surface runways: 1
with runways over .t,(55d m: 0
with runways 2.440-X659 in: 0
with runways 1. 220-2, 4.19 m; 1
Deren.se Forces
Note: defense is the responsibility of the US','8168e0c7fcf0f5da928aa88ddaf37fe2f612f9853b202cadf36be973c28859c2','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07ebe318ef58d42a007b953568bcf83373f92ec1de3e986ce9d4c73bd4a17773',1994,'NZ','New Zealand','communications',28,'Railroads: none
Highways:
total: 3.30 km
paved: 150 km
unpaved: 200 km
Ports: Pago Pago, Ta''u, Ofu. Auasi. Aanu''u
(new construction). Faleosao
Airports:
total: 4
usahle: 4
with permanent-surface runways: 2
with runways over .3.6,59 m: 0
with runways 2.440 to .3,6.59 in: I
(international airport at Tafuna)
with runways 1,200 to 2,4.39 in: 0
note: small airstrips on Fituita and Ofu
Telecommunications: 8,399 telephones:
broadcast stations — 1 AM. I FM, I TV; good
telex, telegraph, and facsimile services; I
Pacific Ocean INTELSAT earth station. I
COMSAT earth station
Defense Forces
Note: defense is the responsibility of the US
Map raHtrciKCs: Oceania
Arcat
total area; lOsqkm
land area; lOsqkm
comparative area; about 17 times the size of
The Mall in Washington. DC
Landbouadarlat: Qkm
Coastline: 101 km
Maritime ctaims:
exclusive eamomic zone; 200 nm
territorial sea; 12 nm
IntcraatlMial disputes: none
CUawte: tropical; nmderated by trade winds
(April to November)
Terrain: coral atolls enclosing large lagoons
Natural resources: negligible
Land use:
arable land: 0%
permanent crops; 094
meadows and pastures: 094
forest and woodland: 094
other; 10094
Irrigated land: NAsqkm
Highways:
total; NA
paved; NA
unpaved; NA
Ports: none: offshore anchorage only
Airports: none: lagoon landings by
amphibious aircraft from Western Samoa
Telecommunicatioiis: radiotelephone service
between islands and to Western Samoa
Defense Focms
Note: defense is the responsibility of New
Zealand
mqsib
South
Oteen
y*w‘w.
OrviV •* j''.y
if^uau''AiorA
Ormm
MiABrvf not thotern
Highways:
total: 2,042 km
paved: 375 km
unpaved: gravel, crushed stone, earth 1 ,667 km
Ports: Apia
Merchant marine: I roll on/roll off cargo
ship ( 1 ,000 GRT or over) totaling 3,838 GRT/
5,536 DWT
Airports:
total; 3
usable; 3
with permanent-suiface runways: 1
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 1
with runways 1,220-2,439 m: 0
Telecommunications: 7,500 telephones;
70,000 radios; broadcast stations — 1 AM, no
FM, no TV; 1 Pacific Ocean INTELSAT
ground station
Defense Forces
Branches: Department of Police and Prisons
Defense expenditures: exchange rate
conversion — SNA, NA% of GDP
434
World','770e4380b01505c00fe0862513a4702de08e3b7b80d67bf11bd31e578ff2151f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c96b9a3721c3bcd7943b8b90e308ca83f661b72f79c1c5b3c6ec5c942cb91eb',1994,'AO','Angola','communications',35,'Highways:
total: 96 km
paved: NA
unpaved; NA
Telecommunications: international digital
microwave network; international landline
circuits to France and Spain; broadcast
stations — 1 AM, no FM, no TV; 17,700
telephones
Defense Forces
Note: defense is the responsibility of France
and Spain
Highways:
total: 300 km
pawd: 200 km
unpaved: 100 km
note; roads on Principe are mostly unpaved
and in need of repair
Ports: Sao Tome, Santo Antonio
Merchant marine: I cargo ship ( 1 ,000 GRT
or over) totaling 1,096 GRT/ 1,1 05 DWT
Airports:
total: 2
usable; 2
with permanent-surface runways; 2
with runways over J,6S9 m: 0
with runways 2,44i^-3,659 m; 0
with runways 1,220-2,439 m; 2
Telecommunications: minima'' system;
broadcast stations — I AM, 2 FM, no TV; I
Atlantic Ocean INTELSAT earth station
Defense Forces
Branches: Army, Navy, National Police
Manpower availability: males age 1 5-49
.32,5(40; fit for military service 17,136
Defense expenditures: exchange rate
conversion — SNA, NA% of GDP
344','1aa5f78b9091611b9b0d6354af8098d93b02626d4c2ff3827d14157f5ad1aefd','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26a30cacc927aa58971cf8a871991b52f2e0cea2541e393239389eb5da05980b',1994,'AI','Anguilla','communications',44,'Highways:
total; NA
paved: 60 km
unpitved; NA
Ports: Road Bay. Blowing Point
12
Airports:
total; 5
usable; 2
with permanent-sutface runways; I ( 1 .000 m
at Wallblake Airport)
with runways over .t,6.59 m; 0
with runways 2.440~3.65V m; 0
with rtinways 1,220-2,439 m; 0
Telccanimunications: modem internal
telephone system; 890 telephones; broadcast
stations — 5 AM, I FM, no TV; radio relay
microwave link to island of Saint Martin
Defense Forces
Note: defense is the responsibility of the UK','f450bd9782c9e22c6eb26733f5dc785cf72b5e0ee43ecee9a0d10157a686e7e8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20c63b42a5357b1a302cb6317f8ba19c2eece2391a5c9daf7db6b89f96130c1e',1994,'AQ','Antarctica','communications',45,'>000
S(7ul^ Atl0n(‘C Oc«an
0c»«/i
Railroads; 7,766 km total; 3.974 km
1 ,676-meter gauge, 150 km L435-mcter
standard gauge, .3,642 km 1. 000-meter gauge;
1 ,865 km 1 .676-meter gauge and 80 km
1 .0(X)-meter gauge electrified
82
Railroads: French National Railways
(SNCF) operates 34,322 km 1,435-mm
standard gauge: 1 2,4.34 km electritied, 15,132
km double or multiple track; 99 km of various
gauges ( 1 ,000-mm), privately owned and
operated
Highways:
total: 1,510,750 km
paved: 747,750 km (including 7,450 km of
controlled access divided highway)
unpaved: 763,000 km
Inland waterways: 14,932 km; 6,969 km
heavily traveled
Pipelines: crude oil 3,059 km; petroleum
piquets 4,487 km; natural gas 24,746 km
Ports: coastal — Bordeaux, Boulogne, Brest,
Cherbourg, Dunkerque, Fos-Sur-Mer. Le
Havre. Marseille, Nantes. Sete, Toulon:','014ec9cc5d0537ae17e23ea262ce2e588e831ec662283af3c5295ff5d02c5660','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('946594335de0d2ceed85dc92db553181a75bda874ff1819c425aed563ca1330f',1994,'AG','Antigua and Barbuda','communications',52,'Ports: none; offshore anchorage only at most
coastal stations
Airports: 42 landing facilities at different
locations operated by IS national governments
patty to the Treaty; one additional air facility
operated by commercial (nongovernmental)
tourist organization: helicopter pads at 28 of
these locations; runways at 10 locations are
gravel, sea ice, glacier ice, or compacted snow
surface suitable for wheeled fixed-wing
aircraft: no paved runways; 16 locations have
snow-surface skiways limited to use by ski-
equipped planes — 1 1 runway s/ski ways 1,000
to 3,000 m, 3 runways/skiways less than 1 ,000
m, 5 lunways/skiways greater thrn 3,000 r,
and 7 of unspecified or variable length: airports
generally subject to severe restrictions and
limitations resulting from extreme seasonal
and geographic conditions; airports do not
meet ICAO standards; advance approval from
the respective governmental or non¬
governmental operating organization required
for landing
Defense Forces
Note: the Antarctic Treaty prohibits any
measures of a military nature, such as the
establishment of military bases and
fortifications, the carrying out of military
maneuvers, or the testing of any type of
weapon; it permits the use of miiitary
personnel or equipment for scientific research
or for any other peaceful purposes
Loentloa: Caribbean, in the eastern Caribbean
Sea. about 420 km east-southeast of Puerto
Rico
Map references: Central America and the
Caribbean. Standard Time Zones of the World
Area:
total area: 440 sq km
land area: 440 sq km
comparative area: slightly less than 2.5 times
the size of Washington. DC
note: includes Redonda
Land boundaries: 0 km
Coastline: 153 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 200 nm
territorial sea; 12 nm
Intcmavional disputes; none
Climate: tropical marine: little seasonal
temperature variation
Terrain: mostly low-lying limestone and
coral islands with some higher volcanic areas
Natural resources: negligible; pleasant
climate fosters tourism
Land use:
arable land: 18%
permanent crops; 0%
meadow and pastures: 7%
forest and woodland: 16%
orfier: 59%
Irrigated land: NAsqkm
Railroads; 64 km ().760-metcr narrow gauge
and 1.3 km ().6l()-meter gauge used almost
exclusively for handling sugareane
Highways:
total: 240 km
paved: NA
uniMived: NA
Ports: Saint John''s
Merchant marine: 227 ships ( I .(XX) GRT or
over) totaling 849.699 GRT/1 ,2 1 8.492 DWT,
cargo 156. refrigerated cargo 4. container 37.
ix)ll-on/roll-off cargo I l.oil tanker 2, chemical
tanker I ! , liquified gas 2. bulk 4
note: a fiag of convenience registry
Airports:
total: 3
usable: 3
15
Antigua and Barbuda (continued)
Arctic Ocean
with permanent-surface runways: 2
with runways 3,659 m: 0
with runways 2,440-3 659 m: I
with runways 1,220-2,439 in: 0
Telecommunications: good automatic
telephone system; 6,700 telephones;
tropospheric scatter links with Saba and
Guadeloupe; broadcast stations — 4 AM, 2 FM,
2 TV, 2 shortwave; 1 coaxial submarine cable;
I Atlantic Ocean INTELSAT eanh station
Defense Forces
Branches; Royal Antigua and Barbuda
Defense Force, Royal Antigua and Barbuda
Police Force (including the Coast Guard)
Defense expenditures: exchange rate
conversion — $ 1 .4 million, I % of GDP (FY90/
91)
Ports: Churchill (Canada), Murmansk
(Russia), Prudhoe Bay (US)
Telecommunications: no submarine cables
Note: sparse network of air, ocean, river, and
land routes, the Northwest Passage (North
America) and Northern Sea Route (Eurasia)
are important seasonal waterways
16','363e814313d119d7ad2e45738f112ead26db59cd426d574c4712dc3c3e405d2d','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3e093c01201c46ab1f7eb64d0ae8324c90ede3d103d50dfbf6d144d03064312',1994,'AR','Argentina','communications',56,'UtKuata^^^ not noctitaniy tunioriiat)**
Highways:
total: 510 km
paved: 30 km
unpaved: gravel 80 km; unimproved earth 400
km
Ports: Stanley
Airports:
total: 5
usable: 5
with permanent-suiface runways: 2
with runways over 3,659 m: 0
with runways 2,440-3,659 m: i
with runways 1,220-2,439 m: 0
Telecommunications: government-operated
radiotelephone and private VHF/CB radio
networks provide effective service to almost all
points on both islands; 590 telephones;
broadcast stations — 2 AM. 3 FM, no TV; I
Atlantic Ocean INTELSAT earth station with
links through London to other countries
Defense Forces
Branches; British Forces Falkland Islands
(including Army, Royal Air Force, Royal
Navy, and Royal Marines). Police Force
Note; defense is the responsibility of the UK
129
Railroads: 2,120 km; does not include
industrial lines (1990)
Highways:
total; 23,000 km
paved and gravel; 1 8,300 km
unpaved; earth 4,700 km (1990)
Pipelines: crude oil 250 km. natural gas 4,400
km
Ports: inland — Krasnowodsk (Caspian Sea)
Airports;
total; 7
usable; 7
with permanent-surface runways; 4
with runways over 3,659 m; 0
with runways 2,440-3,659 m; 0
with runways 1,220-2,439 m; 4
Telecommunications: poorly developed;
only 7.5 telephone circuits per 100 persons
( 1991 ); linked by cable and microwave to other
CIS republics and to other countries by leased
connections to the Moscow international
gateway switch; a new telephone link from
Ashgabat to Iran has been established; a new
exchange in Ashgabat switches international
traffic through Turkey via INTELSAT;
satellite earth stations — i Orbitaand I
INTELSAT
404
Defense Forces
Branches: National Guard, Republic Security
Forces (internal and border troops). Joint
Command Turkmenistan/Russia (Ground,
Navy or Caspian Sea Flotilla, Air, and Air
Defense)
Manpower availability: males age IS-49
962,987; Fit for military service 787,99 1 ; reach
military age (18) annually 40,079 (1994 est.)
Defense expenditures; exchange rate
conversion — SNA, NA% of GDP','2906cae4c43c95609d11fba1af1be72970eb860db367628b9e077ce224775170','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8e69dfc6c74f3f66e554680cc6e2669d25e919a2d293807d47ff27e136aad9f',1994,'NL','Netherlands','communications',60,'Railroads: 34,172 km total (includes 209 km
electrified); includes a mixture of 1 .435-meter
standard gauge. 1 .676-meter broad gauge,
1,000-meter narrow gauge, and 0,750-meter
narrow gauge
Highways:
total: 208,350 km
paved: 57,000 km
unpaved: gravel 39,500 km; improved/
unimproved earth 1 1 1 ,850 km
Inland waterways: 1 1,000 km navigable
Pipelines: crude oil 4.090 km; petroleum
products 2,900 km; natural gas 9,918 km
Ports: Bahia Blanca, Buenos Aires,
Comodoro Rivadavia, La Plata, Rosario, Santa
Fe
Merchant marine: 57 ships ( i ,000 CRT or
over) totaling 656,289 GRT/ 1,008.792 DWT,
cargo 29. refrigerated cargo 5, container 4,
railcar carrier 1. oil tanker 14, bulk 3, roll-on/
roll-off cargo 1
Airports:
total: 1.649
usable: 1.394
H’ilh permanent-surface runways: 139
with runways over 3,659 m: 0
with runways 2.440-3,659 m: 31
with runways 1,220-2.439 m: 332
Telecommunications: extensive modem
system but many families do not have
telephones; 2,650,000 telephones (12,000
public telephones); telephone density 78 per
10(X) persons; microwave widely used;
broadcast stations — 171 AM. no FM, 231 TV.
1 3 shortwave; 2 Atlantic Ocean INTELSAT
earth stations; domestic satellite network has
40 earth stations
Defense Forces
Branches: Argentine Army, Navy of the
Argentine Republic, Argentine Air Force,
National Gendarmerie. Argentine Naval
Prefecture (Coast Guard only). National
Aeronautical Police Force
Manpower availability: males age 15-49
8,417.880; fit for military service 6,825,795;
reach military age (20) annually 292,725 (1994
est.)
Defense expenditures: exchange rate
conversion — SNA, NA% of GDP
18
Ashmore and Cartier Islands
(territory of Australia)
20lim
Ashmore f^eet
Indian Ocean
C»nm Istandgy
Railroads: Belgian National Railways
(SNCB) operates 3.568 km L435-meier
Belgium (continued}
Railroads; 1 .0.30 km; docs nut include
industrial lines (1990)
Highways:
total; .30,300 km
paved or grtivelled; 29,200 km
unpaved; earth 1 , 1 00 km ( 1 990)
Inland waterways: 500 km perennially
navigable
Pipelines: natural gas 420 km (1992)
Ports: coastal — Tallinn, Novotullin. Pamu;
inland — Narva
Merchant marine; 69 ships (1,000 GRT or
over) totaling 406.405 GR’r/537.016 DWT.
cargo 50. roll-on/roll-off cargo 6. short-seu
passenger 4, bulk 6, container 2, oil tanker I
Airports:
total; 29
usable: 18
with ftemument-surface runways; 1 1
with nmways over. 1,65^ m; 0
with runways 2.440..t,659 m; 10
with runways 1,060-2.439 m; 8
note; a C- 1 30 can land on a 1 .()6()-m airstrip
Telecommunications: Estonia’s telephone
system is antiquated and supports about
400.(KXJ domestic telephone circuits, i.e. 25
telephones for each 100 persons;
improvements are being made piecemeal, with
emphasis on business needs and international
connections; there ore still about I50,0(X)
unfulfilled requests for telephone service:
broadcast stations — 3 TV (provide Estonian
programs as well Moscow Ostenkino''s first
and second programs); international traffic is
125
Estonia (continued)
carried to the other former USSR republics by
land line or microwave and to other countries
partly by leased connection to the Moscow
international gateway switch, and partly by a
new Tallinn-Helsinki fiber optic submarine
cable which gives Estonia access to
international circuits everywhere; substantial
investment has been made in cellular systems
which are operational throughout Estonia and
also Latvia and which have access to the
international packet switched digital network
via Helsinki
Defense Forces
Branches: Giound Forces. Maritime Border
Guard, National Guard (Kaitseliit), Security
Forces (internal and border troops), Coast
Guard
Manpower availability: males age 15-49
392, 135; fit for military service 308,95 1 ; reach
military age (18) annually 1 1,789 (1994 est.)
Defense expenditures: 124.4 million kroons,
NA% of GDP (forecast for 1993); note —
conversion of the military budget into US
dollars using the current exchange rate could
produce misleading results
AM.noFM, 1 TV; 1 Indian Ocean INTELSAT
eanh station
Defense Forces
Branches: Royal Nepalese Army, Royal
Nepalese Army Air Service. Nepalese Police
Force
Manpower availability: males age IS-49
5,003.661; fit for military service 2.598..S07;
reach military age (17) annually 24 1 .405 ( 1 994
est.)
Defense expenditures: exchange rate
conversion — $34 million, 2% of GDP (FY91/
92)
Location: Western Europe, bordering the
North Sea. between Belgium and Germany
Map references: Europe. Standard Time
Zones of the World
Area:
total area: 37.330 sq km
land area: 33.920 sq km
comparative area: slightly less than twice the
si/e of New Jersey
Land boundaries: total 1.027 km. Belgium
450 km, Germany 577 km
Coastline: 451 km
Maritime claims:
continental shelf: not specified
exclusive fishing zone: 200 nm
territorial sea: 12 nm
International disputes; none
Climate: temperate; marine; cool summers
and mild winters
Terrain: mostly coastal lowland and
reclaimed land (polders); some hills in
southeast
Natural resources; natural ga.s. petroleum,
fertile soil
Land use:
arable land: 2f>9r
permanent crops: 1 9c
meadows and pastures: 3295-
forest and woodland: 99c
other: ^29r
Irrigated land; 5.500 .sq km ( 1989 e* t.)
Railroads: 2.828 km 1 .4.3.5-meier standard
gauge operated by Netherlands Railways (NS)
(includes 1.957 km eketrified and 1,800 km
double track)
Highways:
total: 104.590 km
paved: 92,525 km (including 2,185 km of
expre.ssway)
anptived: gravel, crushed stone 12.065 km
(1990)
Inland waterways; 6..340 km. of which 35%
is usable by craft of L0(K) metric ton capacity
or larger
Pipelines: crude oil 418 km; petroleum
products 965 km; natural gas 10,2.30 km
Porte: coastal — Amsterdam, DcIfzijI. Den
Helder. Dordrecht. Eemshaven, Ijmuiden.
Rotterdam. Scheveningen, Temeuzen.
Vlissingen: inland— 29 ports
Merchant marine: 324 ships ( I .(XX) GRT or
over) totaling 2..507,l 12 GRT/3.208.8.38
DWT, short-sea passenger 3. cargo 1 80.
refrigerated cargo 20, container .32.
281
Netherlands (continued)
roll-on/roll-off cargo 15, livestock carrier 1,
multifunction large-load carrier 4, oil tanker
27, chemical tanker 21, liquefled gas 12,
specialized tanker 2, bulk 3, combination bulk
3, railcar carrier 1
note: many Dutch-owned ships are also
registered on the captive Netherlands Antilles
register
Airports:
total: 28
usable: 28
with pennanent-surface runways: 19
with runways oeer 3,659 m: 0
with runways 2,440-3,659 m: 10
with runways 1 ,220-2,439 m: 7
Telecommunications: highly developed,
well maintained, and integrated; extensive
redundant .system of multiconductor cables,
supplemented by microwave radio relay
microwave links; 9,41 8,000 telephones;
broadcast stations — 3 (3 relays) AM, 12 (.39
repealers) FM. 8 (7 repeaters) TV ; 5 submarine
cables; I communication satellite earth station
operating in INTELSAT ( I Indian Ocean and 2
Atlantic Ocean antenna) and EUTELSAT
systems; nationwide mobile phone system
Defense Forces
Branches; Royal Netherlands Army. Royal
Netherlands Navy (including Naval Air
Service and Marine Corps). Royal Netherlands
Air Force, Royal Constabulary
Manpower a vailaMlity: males age 15-49
4. 1 80,745; fit for military serv ice 3.fi67.2 1 2;
reach military age (20) annually 98.479 (1994
est.i
Defense cxpemlltures: exchange rate
conversion — $7.8 billion. 3‘> of GDP ( 1992)
Netherlands Antilles
(part of the Dutch realm)
S9liir
Caribbean Sea
fihmas nui afwMn m tititi
getiynifihica* posititu}
I
jtr/ir EuSWiUS,
u_
WILIEMSTAO
* Bonaire
Highways:
total; 950 km
IHived: 300 km
uniktved; gravel, earth 650 km
Ports: Willemstad, Philipsburg, Kralendijk
Merchant marine: 1 1 3 ships ( 1 .000 GRT or
over) totaling 966.797 GRT/1,251,871 DWT.
passenger 4. cargo 43. refrigerated cargo 23,
container 3. it>ll-on/mll-off cargo 7,
multifunction large-load carrier 1 8. chemical
tanker 7, liquefied gas 5, bulk I. oil tanker I .
combination ore/oil I
note: all but a few are foreign owned, mostly in
the Netherlands
Airports:
total: 5
usahle: 4
with fwmitment-surface runways; 4
with runways over J.fiSV in; 0
with runways 2. 440- .t. 659 w. I
with runways 1. 220-1!, 4.hi in: 3
Tekcoromunicatlons: generally adequate
facilities; extensive interisland microwave
radio relay links; broadcast stations — 9 AM, 4
FM. I TV; 2 submarine cables; 2 Atlantic
Ocean INTELSAT earth stations
DcCmhc Forces
Branches; Royal Netherlands Navy. Marine
Corps. Royal Netherlands Air Force, National
Guard, Police Force
Manpower availabilHy: tnales age 1 5-49
48,866; fit for military service 27.42 1 ; reach
military age (20) annually I ..595 ( 1 994 est. )
Note; defense is responsibility of ila''
283','189abf659b0cd52f2dd1f94963a67c32750c8183bbf8e4c79fbba73333ad2824','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0e772ac8aac0c7d3356121d9d140ce85a2ca4b5643e26cf75f3c21be360f534',1994,'AM','Armenia','communications',66,'Railroads: 840 km; doe.s not include
industrial lines ( 1990)
Highways:
lotai: 1 1 .300 km
paved: 10,500 km
unpaved: earth 800 km (1990)
Inland waterways: NA km
Pipelines: natural gas 900 km (1991)
Ports: none; landlocked
Airports:
totai: 12
usable: 10
with permanent-surface runways: 6
with runways aver 3,659 m: I
with runways 2,440-3.659 m: 3
with runways 1 ,060-2.439 m: 2
note: a C-130 can land on a 1.060-m airstrip
Telecommunications: progress on
installation of fiber optic cable and
con.struction of facilities for mobile cellular
phone service remains in the negotiation phase
for joint venture agreement; Armenia has about
65().000 telephones; average telephone density
is 17.7 per 100 persons: international
connections to other former republics of the
USSR are by landline or microwave and to
other countries by satellite and by leased
connection through the Moscow international
gateway switch; broadcast stations — 100% of
population receives Armenian and Russian TV
programs; satellite earth station — INTELSAT
Defense Forces
Branches: Army, Air Force. National Guard,
Security Forces (internal and border troops)
Manpower availability: males age 15-49
862,92 1 ; fit for military service 690, 113; reach
military age (18) annually 28,458 (1994 est.)
Defense expenditures: 250 million rubles,
NA% of GDP ( 1 992 est.); note — conversion of
the military budget into US dollars using the
current exchange rate could produce
misleading results
20','b96d595ef0c788f9cb33cb9b752cb9fefacde12d6fdcf3adaaf0d0b9206fabd3','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b34282314a72733764025b7aac5250d868baf44da24c811671ff66abbed2803e',1994,'AW','Aruba','communications',67,'(part of the Dutch realm)
Nieolaaa
10 km
Highways:
total: NA
paved: NA
unpaved: NA
Ports: Oranjestad, Sint Nicolaas
Airports:
total: 2
usable: 2
with permanent-surface runways: 2
with runways over J,6S9 m: 0
with runways 2,440-3,659 m: I
with runways 1,220-2,439 m: 0
note: government-owned airport east of
Oranjestad accepts transatlantic flights
Telecommunications: more than adequate;
telephone density — 1 , 1 00 telephones per I ,(X)0
persons; extensive interisland microwave radio
relay links; 72,168 telephones; broadcast
stations — 4 AM, 4 FM, 1 TV; 1 submarine
cable to Sint Maarten
Defense Forces
Note: defense is the responsibility of the','91e9d2b7b375d03f525d5c8b43fbeb2fd73c8796269f3dc94d5c7d6782e9f27a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a627cf1e0863234653ec73bf45ebe09d9f614688f30beae3998577ad2a33d71e',1994,'AU','Australia','communications',78,'Ports: none; offshore anchorage only
Defense Forces
Note: defense is the responsibility of
Australia; periodic visits by the Royal
Australian Navy and Royal Australian Air
Force
Ports: Alexandria (Egypt). Algiers (Algeria),
Antwerp (Belgium), Barcelona (Spain),
Buenos Aires (Argentina), Casablanca
(Morocco), Colon (Panama), Copenhagen
(Denmark), Dakar (Senegal), Gdansk (Poland),
Hamburg (Germany). Helsinki (Finland), Las
Palmas (Canary Islands, Spain). Le Havre
(France). Lisbon (Portugal), London (UK),
Marseille (France), Montevideo (Uruguay),
Montreal (Canada), Naples (Italy), New
Orleans (US), New York (US), ()ran (Algeria),
Oslo (Norway). Piraeus (Greece), Rio de
Janeiro (Brazil), Rotterdam (Netherlands),
Saint Petersburg (formerly Leningrad: Russia),
Stockholm (Sweden)
Telecommunications: numerous submarine
cables with most between continental Europe
and the UK, North America and the UK, and in
the Mediterranean; numerous direct links
across Atlantic via INTELSAT satellite
network
Note: Kiel Canal and Saint Lawrence Seaway
are two important waterways
23
r/mor 5»a
1000 km
Railroads; 40,478 km total; 7.970 km 1.600-
metcr gauge, 16,201 km L435-meler standard
gauge, 16,.307 km 1.067 -meter gauge; 183 km
dual gauge; 1 . 1 30 km electrified; government
owned (except for a few hundred kilometers of
privately owned track) (1985)
Highways;
total; 837,872 km
pared; 243,750 kni
unpaved; gravel, crushed stone, stabilized
earth 228,396 km; unimproved earth 365.726
km
Inland waterways: 8.368 km; mainly by
small, shallow-drafi craft
Pipelines; crude oil 2,5(X) km; petroleum
pr^ucts 500 km; natural gas 5,600 km
Ports: Adelaide, Brisbane, Cairns. Darwin,
Devonport, Fremantle, Geelong, Hobart,
Launceston, Mackay, Melbourne, Sydney.
Townsville
Merchant marine: 83 ships (1,000 CRT or
over) totaling 2.517,538 GRT/3,71 1,549
DWT, .short-sea pa.ssenger 2. cargo 8. roll-on/
roll-off cargo 7, vehicle carrier I . oil tanker 1 8.
chemical tanker 3, liquefied gas 5, bulk 30,
combination bulk 2. container 7
Airports:
total; 48 1
usable; 440
with iiennanent-suiface runways; 24 1
with runways over 3.659 m; I
with runways 2,440-f,659 m; 20
with runways 1.220-2.439 m; 268
Telecommunications: good international and
domestic service; 8.7 million telephones;
broadcast stations — 258 AM. 67 FM. 134 TV;
submarine cables to New Zealand, Papua New
Guinea, and Indonesia; domestic satellite
service; satellite stations — 4 Indian Ocean
INTELSAT. 6 Pacific Ocean INTELSAT earth
stations
Defense Forces
Branches: Australian Army. Royal
Australian Navy. Royal Australian Air Force
Manpower availability: mules age 15-49
4,885,574; fit for military service 4,2.39,459;
reach military age ( 1 7) annually 1 33,337 ( 1994
est.)
Defense expenditures: exchange rate
conversion — $7. 1 billion, 2.45?- of GDP
(FY92/93)
2.5
Ports; none; offshore anchorages only
Defense Forces
Note: dcfcn.se is the responsibil ty of
Australia: visited regularly by the Royal
Australian Navy; Australia has control over the
activities of visitors
Ports: none; offshore anchorage only
Defense Forces
Note: defense is the responsibility of Australia
173
Holy See (Vatican City)
250 matfi
Highways:
total: 80 km
paved: 53 km
unpaved: earth, coral 27 km
Ports: none; loading jetties at Kingston and
Cascade
Airports:
total: I
usable: 1
ivith permanent-surface runways: 1
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 0
with runways 1,220-2,439 m: 1
Telecommunications: 1 ,500 radio receivers
(1982): radio link .service with -Sydney; 987
telephones (1983); broadcast stations — I AM,
no FM, no TV
Defense Forces
N.jte: defense is the responsibility of Australia','2e720f6477394f5a59f8bb336da8be5a174d319db814c625fda15e2418e2b261','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6ebcb7cce367a4ec41228be7e9017f8da67f96325b6113621e236a4a9d96290',1994,'AT','Austria','communications',82,'tSQ Km
Railroads: 5.749 km total; 5,652 km
government owned and 97 km privately owned
(0.760-, 1.435- and l.(X)0-meter gauge); 5.394
km 1 .435-meter standard gauge of which 3, 1 54
km is electrified and 1,520 km is double
tracked; 339 km 0.760-meter narrow gauge of
which 84 km is electrified
Highways:
total: 95,412 km
paved; 21,812 km (including 1,012 km of
autobahn)
unpaved: mostly gravel and earth 73,600 km
Inland waterways: 446 km
Pipelines: crude oil 554 km; natural gas 2,6 1 1
km; petroleum products 171 km
Ports: Vienna, Linz (Danube river ports)
Merchant marine: 29 ships ( 1 .000 GRT or
over) totaling 158.724 GRT/259,594 DWT,
cargo 2.3, refrigerated cargo 2, oil tanker I,
bulks
Airports:
total; 55
usahle: 55
with permanent-surface runways: 20
with runways over 3.659 m: 0
with runways 2,440-3.659 m: 6
with runways 1.220-2,439 m: 4
Telecommunications; highly developed and
efficient; 4,014.000 telephones; broadcast
stations — 6 AM, 2 1 (545 repeaters) FM. 47
(870 repeaters) TV; satellite ground stations
for Atlantic Ocean INTELSAT. Indian Oce^in
INTELSA"^, and EUTELSAT systems
Defense Forces
Branches: Army (including Flying Division;
Manpower availability: males age 15-49
2.018,954; fit for military service 1 .693,341 ;
reach military age (19) annually 48,7 10 ( 1994
est.)
Defense expenditures; exchange rate
conversion — $1.7 billion. 0.9% of GDP (1993
est.)
27
Railroads: 23,350 km ( I.S24-mm gauge):
8,600 km electrified
Highways;
total: 273,700 km
IHtved and gravel: 236.400 km
unpaved: earth 37,300 km
Inland waterways; 1.672 km perennially
navigable (Pryp"yat'' and Dnipro Rivers)
Pipelines: crude oil 2.010 km. petroleum
piquets 1,920 km. natural gas 7,800 km
(1992)
Ports: coastal — Berdyuns''k. Illichivs''k,
Kerch, Kherson, Mariupol''. Mykolayiv.
Odesa, Sevastopol’, Pivdenne; inland— Kiev
(Kyyiv)
Merchant marine: 390 ships ( 1 ,000 GRT or
over) totaling 3,932,009 GRT/5.236.134
DWT, cargo 231, container 18, barge carriers
7. bulk cargo 55, oil tanker 10, chemical tanker
2, liquefied gas I, passenger 12, passenger
cargo 5, short-sea passenger 8, roll-on/roll-off
cargo 33, railcar carrier 2, multi-function-
large-load-carrier 1, refrigerated cargo 5
Airports:
total: 694
usable; 199
with permanent-suiface runways: 1 1 1
with runways over 3,659 m: 3
with runways 2.440-3,659 m: 81
with runways 1,060-2.439 m: 78
note: a C-130 can land on a 1 ,060-m airstrip
Telecommunications: the telephone system
is inadequate both for business and for personal
use; about 7,886,0(X) telephone circuits serve
52,056,000 people (1991): telephone density is
15 1 .4 telephone circuits per 1 ,000 persons
(1991); 3..56 million applications for
telephones had not been satisfied as of January
1 99 1 ; calls to other CIS countries are carried by
land line or microwave; other international
calls to 1 67 countries are carried by satellite or
by the 150 leased lines through the Moscow
gateway switch: an NMT-450 analog cellular
telephone network operates in Kiev (Kyyiv)
and allows direct dialing of international calls
through Kiev''s EWSD digital exchange;
electronic mail services have been established
in Kiev, Odessa, and Lugansk by Sprint:
satellite earth stations employ INTELSAT,
INMARSAT, and Intersputnik
Defense Forces
Branches: Army, Navy, Air and Air Defense
Forces, Republic Security Forces (internal and
border troops). National Guard
Manpower availability: males age 15-49
12.191.984: fit for military service 9,591,276:
reach military age ( 1 8) annually 364.676 ( 1994
est.)
Defense expenditures: 544.256 million
karbovantsi. NA% of GDP (forecast for 1993):
note — conversion of the military budget into
US dollars using the current exchange rate
could produce misleading results
411','8ad8ede7b90714fa41e68609b57560653dc58a72efc1019d6bffc152ff9356b5','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47c891c0a0ee4873ec94905f8cdabb79c1643c9d4d23654cc4ab4ae61d96170d',1994,'AZ','Azerbaijan','communications',87,'ISO km
Railroads: 2,090 km; does not include
industrial lines (1990)
Highways:
total: 36,700 km
paved or graveled: 31,800 km
unptived: earth 4.900 km (1990)
Pipelines: crxideoil 1, 1.30 km. petroleum
pnxlucts 630 km. natural gas 1 ,240 km
Ports: inland — Buku(Buky)
Airports:
total: 65
usable: 33
with pemtanent-sutface runways: 26
with runways oier .1,659 m: 0
with nmways 2,440-3.659 m: 8
with rumsxiys 1,220-2,4.19 m: 23
Telecommunications; domestic telephone
service is of poor quality and inadequate;
710.000 domestic telephone lines (density — 9
lines per 100 persons ( 1991 )), 202.000 persons
waiting for telephone installations (January
1991); connections to other former USSR
republics by cable and microwave and to other
countries via the Moscow international
gateway switch: INTELSAT earth station
installed in late 1992 in Baku with Turkish
financial assistance with access to 200
countries through Turkey: since August 1993
an eanh station near Baku has provided direct
communications with New York through
Russia''s Stutionur-I I .satellite; a joint venture
to establish a cellular telephone system
(Bakcel) in the Baku area is supposed to
become operational in 1994; domestic and
Russian TV programs are received locally and
Turkish and Iranian TV is received from an
INTELSAT satellite through a receive-only
earth station
Defense Forces
Branches: Army. Air Force. Navy. Maritime
Border Guard, National Guard, Security Forces
(internal and border inwps)
Manpower avallabilily; males age 15-49
1.884,458; fit for military serv''ice 1 ,525,123;
reach military age (18) annually 68,192 (1994
est.)
Defense cxpendilurcs: 2.848 million rubles,
N A5?'' of GDP ( 1 992 e.st,): note — conversion of
the military budget into US dollars using the
current exchange rate could produce
misleading results
29
The Bahemas
Andw''
''» Isitna
Cr««r //ta^ua','5cd49677068318009945abbba59aba178828097dd0aa091fe363d7ba57c910ae','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6479e1e4ff26ddbbe2180206b3e9aa6c153f703e80a96c6b2240d3f1144a56a',1994,'BH','Bahrain','communications',94,'Highways:
total- 2,400 km
paved: 1,350 km
unpaved: gravel 1,050 km
Ports: Freeport, Nassau
Merchant marine: 879 ships ( 1 ,000 CRT or
over) totaling 20,424,439 GRT/33,330,160
DWT, passenger 54, short-sea passenger 1 6,
cargo 148, roll-on/roll-off cargo 41, container
48, vehicle carrier 7, oil tanker 177, liquefied
gas 1 8, combination ore/oil 20, chemical
tanker 43, bulk 167, combination bulk 8,
refrigerated cargo 132
note: a flag of convenience registry
Airports:
total: 60
usable: 55
with permanent-surface runways; 31
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 3
with runways 1,220-2,439 m: 26
Teleconununications: highly developed;
99,000 telephones in totally automatic system;
tropospheric scatter and submarine cable links
to Florida; broadcast stations — 3 AM, 2 FM, 1
TV; 3 coaxial submarine cables; 1 Atlantic
Ocean INTELSAT earth station
Defense Forces
Branches: Royal Bahamas Defense Force
(Coast Guard only). Royal Bahamas Police
Force
Defense expenditures: exchange rate
conversion — $65 million. 2.7% of GDP (1990)
Location: Middle East, in the central Persian
Gulf, between Saudi Arabia and Qatar
Map references: Africa, Middle East,
Standard Time Zones of the World
Area:
total area: 620 sq km
land area: 620 sq km
comparative area: slightly less than 3.5 times
the size of Washington, DC
Land boundaries: 0 km
Coastline: 161 km
Maritime ciaims:
contiguous zone; 24 nm
continental shelf; not specified
territorial sea: 12 nm
International disputes: territorial dispute
with Qatar over the Hawar Islands; maritime
boundary with Qatar
Climate: arid; mild, pleasant winters; very
hot, humid summers
Terrain; mostly low desert plain rising gently
to low central escarpment
Natural resources: oil, associated and
nonassociated natural gas, fish
Land use:
arable land: 2%
permanent crops: 2%
meadows and pastures: 6%
forest and woodland: 0%
other: 90%
Irrigated land: 10 sq km (1989 est.)
Highways:
total: NA
paved: bituminous 200 km
unpaved: NA
Pipelines; crude oil 56 km; petroleum
products 16 km; natural gas 32 km
Ports: Mina'' Salman. Manama, Sitrah
Merchant marine: 6ships(I,0(X)GRTor
over) totaling 101,844 GRT/ 143,997 DWT,
cargo 4, container 1 . bulk 1
Airports:
total: 3
usable: 3
32
with permanent-surface runways: 2
with runways over 3,659 m: 2
with runways 2,440-3,659 m: 0
with runways 1,220-2,439 m: 1
Telecommunications: modem system; good
domestic services; 98,000 telephones ( 1 for
every 6 persons); excellent international
connections: tropospheric scatter to Qatar,
UAE: microwave radio relay to Saudi Arabia;
submarine cable to Qatar, UAE, and Saudi
Arabia; satellite earth stations — 1 Atlantic
Ocean INTELSAT, I Indian Ocean
INTELSAT, I ARABSAT; broadcast
stations — 2 AM. 3 FM, 2 TV
Defense Forces
Branches: Army, Navy. Air Force, Air
Defense, Police Force
Manpower availability: males age 15-49
198,414; fit for military service 109,43 1 ; reach
military age (15) annually 5,093 (1994 est.)
Defense expenditures; exchange rate
conversion — $245 million, 6% of GDP (1990)
Baker Island
(territory of the US)
North Pacific Ocaan
Ports: none; offshore anchorage only, one
boat landing area along the middle of the west
coast
Airports: I abandoned World War II runway
of 1 ,665 m
Note: there is a day beacon near the middle of
the west coast
Defense Forces
Note: defense is the responsibility of the US;
visited annually by the US Coast Guard
33','c999f127686b41f75c94450950161017cdc26fa0088a649b95c75ad4f7a799b6','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b76404a5c1fa6aa9475ff617b8cda08a9e43cad9f87722f07ce58ba2d16158ca',1994,'BD','Bangladesh','communications',104,'Railroads: 2,892 km total (1986); 1,914 km
1 .000-meter gauge, 978 km 1 .676-meter broad
gauge
Highways:
totai: 7,240 km
paved: 3,840 km
unpaved: 3,400 kin (1985)
Inland waterways: 5,150-8,046 km
navigable waterways (includes 2,575-3,058
km main cargo routes)
Pipelines: natural gas 1 ,220 km
Ports: Chittagong, Chalna
Merchant marine; 41 ships (L(X)0GRT or
over) totaling 3 1 2. 1 72 GRT/458, 1 3 1 DWT,
cargo 33, oil tanker 2, refrigerated cargo 3,
bulk 3
Airports:
total: 16
usable: 12
with permanent-surface runways: 1 2
with runways over 3.659 m: 0
with runways 2,440-3,659 m: 4
with runways 1,220-2.439 m: 6
Telecommunications: adequate international
radio communications and landline service;
poor domestic telephone service; 241.250
telephones — only one telephone for each 522
persons; fair broadcast service; broadcast
stations — 9 AM, 6 FM, 1 1 TV; 2 Indian Ocean
INTELSAT satellite earth stations
Defense Forces
Branches; Army, Navy, Air Force
paramilitary forces: Bangladesh Rifles,
Bangladesh Ansars, Armed Police Reserve,
Defense Parties, National Cadet Corps
Manpower availability; males age 15-49
31,955,948: fit for military service 18,967,602
Defense expenditures: exchange rate
conversion — $355 million, 1 .5% of GDP
(FY92/93)
35','86ecd1fe94c8fcfb18c3183b456ef909f95974faa06f35d7758545419f6bdc1b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b89ae65a8ed137167be1f86f429bd62233e99c204eb8c2a11a639d99b076c0ce',1994,'MG','Madagascar','communications',112,'Population: uninhabited
Highways:
total: 1 ,570 km
paved: 1,475 km
u. \\paved: gravel, earth 95 km
Ports: none; offshore anchorage only
Airports:
total: 1
usable: I
with permanent-surface runways: 0
with runways over 3,659 m: 0
with runways 2,439-3,659 m; 0
with runways 1,220-2,439 m; 1
Telecommunications: I meteorological
station
Defense Forces
Note: defense is the responsibility of France
Ports: none; offshore anchorage only
Airports:
total: I
usable: 1
with permanent-surface runways: 0
with runsways over 3,6S9 m: 0
with runways 2,440-3,659 m: 0
with runways 1,220-2,439 m: I
Defense Forces
Note: defense is the responsibility of France
Railroads: 2,479 km total; 1,565 km 1.435-
mm standard gauge, of which 36 km electrified
and 100 km double track; 892 km 1,000-mm
gauge; 22 km 750-mm narrow gauge; all
government owned
Highways:
total: 38,938 km
paved: 1 6,090 km
unpaved: crushed stone, gravel 13,676 km;
improved earth 5,632 km; unimproved earth
3,540 km
Inland waterways: 80 km; system consists of
three coastal canals; including the Corinth
Canal (6 km) which crosses the Isthmus of
Corinth connecting the Gulf of Corinth with
the Saronic Gulf and shortens the sea voyage
from the Adriatic to Piraievs (Piraeus) by 325
km; and three unconnected rivers
Pipelines: crude oil 26 km; petroleum
products 547 km
Ports: Piraievs (Piraeus). Thessaloniki
Merchant marine: 1 ,059 ships ( 1 ,000 GRT
or over) totaling 29,343,367 GRT/54.249.294
DWT, passenger 15, short-sea passenger 65,
passenger-cargo 2, cargo 1 17. container 36,
roll-oii/roll-off cargo 17, refrigerated cargo 11,
vehicle carrier I, oil tanker 251, chemical
tanker 20, liquefied gas 6, combination ore/oil
38, specialized tanker 3, bulk 453, combination
bulk 23, livestock carrier I
note: ethnic Greeks also own large numbers of
ships under the registry of Liberia. Panama.
Cyprus, Malta, and The Bahamas
Airports:
total: 78
usable: 77
with permanent-surface runways: 63
with runways over 3.659 m: 0
with runways 2,440-3,659 m: 20
with runways 1,220-2,439 m: 24
Telecommunications: adequate, modern
networks reach all areas; 4,080,000 telephones;
microwave radio relay carries most traffic;
extensive open-wire network; submarine
cables to off-shore islands: broadcast
stations — 29 AM, 17 (20 repeaters'' FM. 361
TV; tropospheric links, 8 submarine cables; I
satellite earth station operating in INTELSAT
( I Atlantic Ocean and I Indian Ocean
antenna), and EUTELSAT .systems
Defense Forces
Branches: Hellenic Army, Hellenic Navy.
Hellenic Air Force, National Guard, Police
Manpower availability: males age 1 5-49
2,645.859; fit for military .service 2,025.212:
reach military age (21) annually 74,484 (1994
est.)
Defense expenditures: exchange rate
conversion — $4.2 billion, 5. 1 % of GDP ( 1 992)
Railroads: short line going to a jetty
Ports: none; offshore anchorage only
Airports:
total: I
usable: 1
with permanent-sutface runways: 0
with runways over 3,659 m: 0
with runways 2,439-3,659 m; 0
with runways 1,220-2,439 m: 1
Defense Forces
Note: defense is the responsibility of France
*00 ton
Railroads: 1 ,020 km 1 .000-meter gauge
Highways:
total: 40.000 km
paved: 4,694 km
unpaved: gravel, crushed stone, stabilized
earth 8 1 1 km; other earth 34.495 km (est.)
Inland waterways; of local importance only;
isolated streams and small portions of Canal
des Pangalanes
Ports: Toamusina. Antsiranana, Mahajanga.
Toliara
Merchant marine: 10 ships ( 1.000 GRT or
over) totaling 23,620 GRT/33. 1 73 DWT, cargo
5. roll-on/roll-off cargo 2, oil tanker 1 .
chemical tanker I, liquefied gas I
Airports;
total: 140
usable: 105
with pennanent-surface runuays: 30
with runways over 3.659 m: 0
with runways 2,440-3,659 m: 3
with runways 1 ,220-2,439 m: 37
Telecommunications; above average system
includes open-wire lines, coaxial cables, radio
relay, and troposcatter links; submarine cable
to Bahrain; satellite earth .stations — I Indian
Ocean INTELSAT and broadcast stations — 1 7
AM. 3 FM. 1 (36 repealers) TV
Defense Forces
Branches; Popular Armed Forces (including
Intervention Forces, Development Forces,
Aeronaval Forces — including Navy and Air
Force), Gendarmerie, Presidential Security
Regiment
Manpower availability: males age 15-49
2,924,829; fit for military service 1,739,830;
reach military age (20) annually 124,652(1994
est.)
Defense expenditures: exchange rate
conversion — $37 million, 2.2% of GDP (1991
est.)','d7f750a4a071c238939228e3ae546670ac011cec3fb5c3db242e91aa629f1fe8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81bb8f6a76d0076002f601002df0c934ac41f7876032e147f75e1e3e4d09a284',1994,'BY','Belarus','communications',116,'Ports: none; offshore anchorage only
Defense Forces
Note: defense is the responsibility of France
Railroads: 5,570 km, dues not include
industrial lines k 1990)
Highways:
total: 98.2(X) km
paved: 66,10(1 km
unnaved: eanh 32,100 km (1990)
Inland waterways: ,NA km
Pipelines: crude oil 1,470 km, refined
products 1,100 km, natural gas 1,980 km
(1992)
Ports: none; landlocked
Merchant marine: claims 5% of former
Soviet fleet
Airports:
total: 124
usable: 55
with pennanent-suiface runways: 3 1
with runways over 3,659 m: 1
with runways 2,440-3,659 m: 28
with runways 1,060-2.439 m: 20
note: a C- 1 30 can land on a 1,060-m airstrip
Telecommunications: telephone service in
Belarus is inadequate for the purposes of either
business or the population; total number of
telephones 1,849,000(31 December 1991);
telephone density — 18 for each 100 persons:
about 70% of the telephones are in homes; over
750,000 applications from households for
telephones remain unsatisfied (1992): new
investment centers on international
connections and business needs; the new
BelCel NMT 450 cellular system (a joint
venture) is now operating in Minsk but
progress has been slower in establishing an
INTELSAT earth station: international traffic
still relies on the Moscow international
39
Belarus (continued)','a7f437cdff3ee781342f01a0f93e8a780cb23391e2b444c1b5377b2adebffa99','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1509f9713f209573afd1296bc5b4b8a665eeddeff4eaca3f0d2e2db9fdf0f25',1994,'BE','Belgium','communications',120,'gateway switch: broadcast receivers —
television 3,538,000. radio 3,140.000, radio
receivers with multiple speaker systems for
program diffusion 5.6 1 5,000
Defense Forces
Branches: Army, Air Forces, Air Defense
Forces. Security Forces (internal and border
troops)
Manpower availability: males age 15-49
2,520,487: fit for military service 1,981,749;
reach military age ( 1 8) annually 7 1 ,922 ( 1 994
est.)
Defense expenditures: 56.5 billion rubles.
NA% of GDP ( 1 993 est.); note — conversion of
the military budget into US dollars using the
current exchange rate could produce
misleading results','1a39808fe8bf0e8a96558887ad1463017c38daa9ca30ba32e109ce42ea047e32','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('452481f1164b887678127d80d606a7dacdd0a2a131e4d4c487e44b3755f9e60b',1994,'BZ','Belize','communications',122,'standard gauge, government owned; 2,563 km
double track; 2,207 km electrified
Highways:
iDtal: 1 37,876 km
paved: 129.603 km (including 1,631 km of
limited access divided highway)
impaved: 8,273 km (1989)
Inland waterways: 2,043 km ( 1 ,528 km in
regular commercial use)
Pipelines: petroleum products 1,167 km;
crude oil 161 km; natural gas 3,300 km
Ports: Antwerp, Brugge, Gent, Oostende,
Zeebrugge
Merchant marine: 2 1 ships ( 1 ,000 CRT or
over) totaling 36,200 GRT/52,039 DWT, cargo
9, oil tanker 5, liquefied gas I , chemical tanker
5, bulk I
Airports:
total; 42
usable; 42
with permanents trface rMnwav.t.'' 24
with runways over 3,659 m; 0
with runways 2,440-3,659 m; 15
with runways 1,220-2,439 ni; 3
Telecommunications: highly developed,
technologically advanced, and completely
automated domestic and international
telephone and telegraph facilities; extensive
cable network; limited microwave radio relay
network; 4,720,000 telephones; broadcast
stations— 3 AM, 39 FM, 32 TV; 5 submarine
cables; 2 satellite earth stations — Atlantic
Ocean INTELSAT and EUTELSAT systems;
nationwide mobile phone system
Defense Forces
Branches: Army, Navy, Air Force, National
Gendarmerie
Manpower availability: males age 15-49
2,558,109; fit for military service 2,130,172;
reach military age (19) annually 61,710 (1994
est.)
Defense expenditures: exchange rate
conversion — $4 billion. 2% of GDP (1992)
Location; Middle America, bordering the
Caribbean Sea between Guatemala and Mexico
Map references: Central America and the
Caribbean, Ncrth America, Standard Time
Zones of the World
Area:
total area; 22,960 sq km
land area; 22,8(X) sq km
comparative area; slightly larger than
Massachusetts
Land boundaries: total 516 km, Guatemala
266 km, Mexico 250 km
Coastline: 386 km
Maritime claims;
territorial sea: 1 2 nm in the north, 3 nm in the
south
note: from the mouth of the Sarstoon River to
Ranguana Cay, Belize''s territorial sea is 3
miles; according to Belize''s Maritime Areas
Act, 1992, the purpose o: this limitation is to
provide a framework for the negotiation of a
definitive agreement on territorial differences
with Guatemala
International disputes: border with
Guatemala in dispute; negoiiti.ions to resolve
the dispute have begun
Climate: tropical; very hot and humid; rainy
season (May to February)
Terrain; flat, swampy coastal plain; low
mountains in south
Natural resources: arable l^nd potential,
timber, fish
Land use;
arable land: 2%
permanent crops: 0%
meadows and pastures: 2%
forest and woodland: 44%
other; 52%
Irrigated land; 20 sq km (1989 est.)
Highways;
total: 2,710 km
paved: 500 km
unpaved: gravel 1 ,600 km; improved earth 300
km; unimproved earth 3 10 km
Inland waterways; 825 km river network
used by shallow-draft craft; seasonally
navigable
Ports: Belize City; additional pons for
shallow draught craft include Coiozol. Punta
Gorda, Big Creek
Merchant marine; 25 ships ( 1 ,000 GRT or
over) totaling 5.3,509 GRT/80,345 DWT, cargo
1 1 , roll-on/roll-off cargo 3, bulk 6, container 2,
refrigerated cargo 2, oil tanker I
Airports:
total; 47
usable: 38
with permanent-surface runways: 3
with runways over 3,659 m: 0
With runways 2,440-3,659 m: I
with runways 1,229-2,439 m: 3
Telecommunications: 8.650 telephones;
above-average system based on microwave
radio relay; broadcast stalion.s — 6 AM, 5 FM. 1
TV. I shortwave; I Atlantic Ocean INTELSAT
earth station
Defense Forces
Branches; British Forces Belize withdrawn
by the end of 1993 except for a small training
detachment. Belize Defense Force (including
Army, Navy, Air Force, and Volunteer Guard),
Belize National Police
Manpower availability: males age 15-49
48.789; fit for military service 29,040; reach
military age (18) annually 2,175 (1994 est.)
Defense expenditures: exchange rate
conversion — $5.4 million, 2% of GDP ( 1992)
43','5bddc16f9742a4709ba040dabe1ae37a615046cdeda105b83456fcf3515e7656','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da3bbd17be0d29443fb7f8a5defa865bacf6c168ba05e48026cc307d0e361ae7',1994,'BJ','Benin','communications',127,'Bight of Benin
Railroads: 578 km. all l.(X)0- meter gauge.
single track
Highways:
total: 8,435 km
paved: 1 .038 km
unpaved: crushed stone 2.600 km; improved
earth 1 ,530 km; unimproved earth 3,267 km
Inland waterways: navigable along small
sections, important only locally
Ports; Cotonou
.Airports:
total: 7
usable: 6
with permanent-sutfaev runways: 2
with runways over 3,659 in: 0
with runways 2,440-3,659 m: 1
with runways 1,220-2,439 in: .3
Telecommunications: fair system of open
wire, submarine cable, and radio relay
microwave; broadcast stations — 2 AM. 2 FM,
2 TV; 1 Atlantic Ocean INTELSAT earth
station
Defense Farces
Branches: Armed Forces (including Army,
Navy, Air Force), National Gendarmerie
Manpower availability: males age 15-49
1 ,209,226; females age 1 5-49 1 , 1 20, 1 05 ; males
fit for military service 61 1 ,257; females fit for
military service 573,775; males reach military
age (18) annually 58,293 (1994 est.);
femalesreach military age ( 1 8) annually 56,735
( 1994 est.); both sexes are liable for miltary
service
Defense expenditures: exchange rate
conversion — $29 million. 1 .7% of GDP (1988
est.)
45','069635e6b5fafddea0a714291227d0421dd4a68960a912c3e00b20499e727a5c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76d4903137ef5733b2a1f29cc02fb8d71e237d4b745569e135ddc4ba8ee6f81e',1994,'BT','Bhutan','communications',141,'Highways:
total: 210 km
paved: 210 km
note; in addition, there are 400 km of paved
and unpaved roads that are privately owned
Ports: b''reeport, Hamilton. Saint George
Merchant marine: 67 ships ( 1 ,000 CRT or
over) totaling 3,407,518 GRT/5.775.281
DWT, cargo 4. refrigerated cargo 4, container
3, roll-on/roll-off cargo 7, oil tanker 20,
liquefied gas 14. bulk 15
note; a flag of convenience registry
Airports:
total; I
usable: I
with permaneni-siiiface runways: 1
with runways over 3,659 m; 0
with runways 2,440-3.659 in: I
with runways 1.220-2,439 m: 0
Telecommunications: modem with fully
automatic telephone system; 52.670
telephones; broadcast stations — 5 AM. 3 FM, 2
TV; 3 submarine cables; 2 Atlantic Ocean
INTELSAT earth stations
Defense Forces
Branches: Bermuda Regiment. Bermuda
Police Force. Bermuda Reserve Constabulary
Note: defense is the responsibility of the UK
Highways:
total: 2,165 km
paved: NA
unpaved: gravel 1,703 km
undifferentiated: 462 km
Airports:
total: 2
usable: 2
with permanent-surface runways: 1
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 0
with runways 1,220-2,439 m: 2
Telecommunications: domestic telephone
service is very poor with very few telephones
in use; international telephone and telegraph
service is by land line through India; a satellite
earth station was planned (1990); broadcast
stations — 1 AM, I FM. no TV (1990)
Defense Forces
Branches: Royal Bhutan Army, Palace
Guard, Militia
Manpower availability: males age 15-49
424,558; fit for military service 226,85 1 ; reach
military age ( 1 8) annually 1 7,3 10 ( 1 994 est.)
Defense expenditures: exchange rate
conversion — $NA, NA% of GDP
48
Bolivia
Railroads; 3,684 km total, all narrow gauge;
3,652 km 1 .000-meter gauge and 32 km 0.760-
meter gauge, all government owned, single
track
Highways:
total: 42,800 km
paved: 1,865 km
unpaved: gravel 12,000 km; improved/
unimproved earth 28,950 km
Inland waterways: 1 0,000 km of
commercially navigable waterways
Pipelines: crude oil 1 .800 km; petroleum
products 580 km; natural gas 1.495 km
Ports: none; maritime outlets are Arica and
.Antofagasta in Chile, Matarani and Ilo in Peru
Merchant marine: I cargo ship (1,(X)0 GRT
or over) totaling 4,2 14 GRT/6,390 DWT
Airports:
total: 1,395
usable: 1,188
with permanent-surface runways: 9
with runways over 3,659 m: 2
with runways 2,440-3,659 m: 7
with runways 1 ,220-2,439 m: 165
Telecommunications: very poor telephone
service for the general population; 144,300
telephones — 18.7 telephones per 1,000
persons; microwave radio relay system being
expanded; improved international services;
broadcast stations — 129 AM, no FM, 43 TV,
68 shortwave; 1 Atlantic Ocean INTELSAT
earth station
Defense Forces
Branches: Army (Ejercito Boliviano), Navy
includes Marines (La Fuerza Naval Boliviana),
Air Force (Fuerza Aerea Boliviana), National
Police Force ( Policia Nacional de Bolivia)
Manpower availability: males age 15-49
1,835.661; fit for military service 1,194,077;
reach military age ( 1 9) annually 79,580 ( 1 994
est.)
Defense expenditures: exchange rate
conversion — $130.48 million; NA% of GDP
(1994 est.)
50','238d726e79709f81e230225718fe89ca3c3bd9d17861227ab3f5d709d83ab169','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e60e93c788d004a6e0be29b2141af51210272842e8d10a990b9d8bdbcec9385',1994,'BA','Bosnia and Herzegovina','communications',146,'too km
Note: Bosnia and Herzegovina is suffering
from interethnic civil strife which began in
March 1992 after the Government of Bosnia
and Herzegovina held a referendum on
independence. Bosnia''s Serbs — supported by
neighboring Serbia — responded with armed
resistance aimed at partitioning the republic
along ethnic lines and joining Serb-held areas
to a "greater Serbia," Since the onset of the
conflict, which has driven approximately half
of the pre-war population of 4.4 million from
their homes, both the Bosnian Serbs and the
Bosnian Croats have asserted control of more
than three-quarters of the territory formerly
under the control of the Government of Bosnia
and Herzegovina. The UN and the EU are
continuing to try to mediate a plan for peace. In
March 1994 Bosnian Muslims and Bosnian
Croats signed an agreement in Washington,
DC, creating a Federation of Bosnia and
Herzegovina, which is to include territories in
which Muslims or Croats predominated,
according to the 1991 census. Bosnian Serbs
refused to become a part of this Federation.
Railroads: NA km
Highways;
total: 21.168 km
paved: 1 1 ,436 km
unpaved: gravel 8,146 km; earth 1,586 km
(1991)
Inland waterways: NA km
Pipelines; crude oil 174 km, natural gas 90
km (1992); note — pipelines now disrupted
Ports; coastal — none; inland — Bosanski Brod
on the Sava River
Airports:
total: 28
usable: 24
with permanent-suiface runways: 5
with runways over J6S9: 0
with runways 2440-36S9 m: 3
with runways 1220-2439 m: 6
Telecommunications: telephone and
telegraph network Is in need of modernization
and expansion, many urban areas being below
average compared with services in other
former Yugoslav republics; 727,000
telephones: broadcast stations — 9 AM, 2 FM, 6
TV; 840.000 radios: 1 .0 1 2,094 TVs; satellite
ground stations — none
52','e46473cf253a32c8696b2deef6bfcdffed2c58ff84a4c8f8957520495bd3b907','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b720252e004052e95770158bcdd46f682586332189f559a93fbb4537b1fef588',1994,'BW','Botswana','communications',152,'Defense Forces
Branches: Army
Manpower availability: males age IS-49
1.298,102; fit for military service 1,054,068;
reach military age (19) annually .^8,28.5 ( 1994
esi.)
Defense expenditures: SNA. NA% of GDP
Location: Southern Africa, north of South
Africa
Map references: Africa, Standard Time
Zones of the World
Area:
total area: 600,.'')70 sq km
land area: 585,.170 sq km
comparative area: slightly smaller than Texas
Land boundaries: total 4,0l.f km. Namibia
1 .360 km. South Africa 1 ,840 km. Zimbabwe
813 km
Coastline: 0 km (landlocked)
Maritime claims: none; landlocked
International disputes: short section of
boundary with Namibia is indefinite;
quadripoint with Namibia, Zambia, and
Zimbabwe is in disagreement; recent dispute
with Namibia over uninhabited Kusikili
(Sidudu) Island in Linyanti (Chobe) River
Climate: semiarid; warm winters and hot
summers
Terrain: predominateiy flat to gently rolling
tableland; Kalahari Desert in southwest
Natural resources; diamonds. copper, nickel.
salt, soda ash, potash, coal, iron ore. silver
Land use;
arable land: 2%
permanent crops: 0%
meadows and pastures: 75%
forest and womlland: 2%
other: 21%
Irrigated land: 20 sq km ( 1989 est.)
Railroads: 712 km 1.067-meter gauge
Highways:
total: 11.514 km
paved: 1 .600 km
unpaved: crushed stone, gravel 1,700 km;
improved earth 5,177 km; unimproved earth
3,037 km
Airports:
total: 101
usable: 90
with permanent-surface runways: 9
with runways over 3,659 m; 0
with runways 2,440-3,659 m: I
with runways 1,220-2,439 m: 30
Telecommunications: the small system is a
combination of open-wire lines, microwave
radio relay links, and a few radio¬
communications stations; 26,000 telephones;
broadcast stations — 7 AM. 13 FM, no TV; 1
Indian Ocean INTELSAT earth station
Defense Forces
Branches: Botswana Defense Force
(including Army and Air Wing), Botswana
National Police
Manpower availability; males age 15-49
294.603; fit for military service 154,997; reach
military age (18) annually 15,156 (1994 est.)
Defense expenditures: exchange rate
conversion — $196 million, 4.9% of GDP
(FY93/94)
54
Bouvet Island Brazil
(territory ofNorwm’)
? km
Independence: none (territory of Norway)
Ports: none: offshore anchorage only
Telecommunications: automatic
meteorological station
Defense Forces
Note: defense is the responsibility of Norway','9106c872538f7dad12e298050ddbbbbf1d2964cbcfdf85debe17d7ce338a47a5','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f96b8def5b1fe1bf7fc081e2d0c3c1b662ae4a8e2a52ed84e2896ba179f00734',1994,'NO','Norway','communications',163,'Raiirtiads; .30. 1.33 km total: 24,690 km l.(X)0-
meter gauge, 5, 1 20 km 1 .600-meter gauge. 3 1 0
km mixed 1 .600- 1 .000-meter gauge, 13 km
0.760-meter gauge; 2,150 km electrified
Highways:
total: 1 670,148 km
paved: 1 61, .503 km
iinptived: gravel/eatth 1.508.645 km (1990)
Inland waterways: 50,000 km navigable
Pipelines: crude oil 2,000 km: petroleum
products 3,804 km; natural gas 1,095 km
Ports: Belem, Fortaleza. Ilheus. Manaus.
Paranagua. Porto Alegre, Recife. Rio de
Janeiro. Rio Grande, Salvador, Santos
Merchant marine: 220 ships (1.000 GRT or
over) totaling 5,139,176 GRT/8.695,682
DWT, passenger-cargo 5, cargo 40,
refrigerated cargo 1. container II. roll-on/roll¬
off cargo 1 1 , oil tanker 62, chemical tanker 1 4.
combination oie/oil 1 2, liquilled gas 1 1 , bulk
53
note; in addition. I naval tanker is sometimes
used commemially
Airports:
total; 3,581
usable: 3,024
with perinanent-stitftice nmway.s: 436
with runways over 3.659 m: 2
with runways 2.440-3.659 m: 22
with runways 1.220-2,439 m: .598
Telecommunications: good system;
extensive microwave radio relay facilities;
9.86 million telephones; broadcast .stations —
1.22,3 AM, no FM, 1 12 TV, 151 shortwave; 3
coaxial submarine cables. 3 Atlantic Ocean
INTELSAT earth stations and 64 domestic
satellite earth stations
Defense Forces
Branches; Brazilian Army, Navy of Brazil
(including Marines), Brazilian Air Force,
Military Police (paramilitary)
Manpower availability: males age 15-49
43.489,704; fit for military service 29,286,530;
reach military age ( 1 8) annually 1 ,674,9,30
(1994 est.)
Defense expenditures; exchange rate
conversion — $ 1 . 1 billion, 3% of GDP ( 1990)
57
Highways;
total; 1 50 km
paved; 60 km
unpaved; 90 km
Ports: Kangerluarsoruseq (Facringchavn),
Paamiut (Frederik.shaab). Nuuk (Godthaab).
Sisimiut (Holsteinsborg), Julianehaab.
Maarmorilik, North Star Bay
Airports:
total; 1 1
usable; 8
with permanent-surface runways; 5
with runways over .1,659 m: 0
with runways 2,440-3.659 m; 1
with runways 1,220-2.4.19 in; 2
Telecommunications: adequate domestic and
international service provided by cables and
157
Greenland (continued)','ea52e8df478afe0660fcd5a46c4a4e0ee30dd2d144801fec56f1ecedc8773489','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ae48c5e5381e7b6e9190ed1aca0f6a0799e3e7fd656cb279a928a6f0f147424',1994,'IO','British Indian Ocean Territory','communications',164,'(dependent territory of the UK)
2U1I1.
Parot Banhoi''
Salomon lafanda
Chagos
Archipelago
Bagla iibnJi-
Bgmont lalanda
Indian Ocean
%
Otago Garcia
Highways:
total: NA
paved: short stretch of paved road between
port and airfield on Diego Garcia
:i.tpa\\ed: NA
Ports: Diego Carciu
British Virgin Islands
(dependent territory of the UK)
North
AVarttic
Ocean
Caribbean Sea
Highways:
total: 106 km (1983)
paved: NA
unpaved: NA
Ports: Road Town
Airports:
total: 3
usable: 3
with permanent-surface runways: 2
with runways over 3,659 m: 0
with runways 2,440-3,659 in: 0
with runways 1,220-2,439 m: 0
Telecommunications: 3,000 telephones;
worldwide external telephone service:
submarine cable communication links to
Bermuda; broadcast stations — 1 AM.noFM. I
TV
Defense Forces
Note: defense is the responsibility of the UK
2Sliir
Railroads: 1 3 km 0.6 lO-meler narrow-gauge
private line
Highways:
total: 1 ,090 km
paved: bituminous 370 km (with another 52
km under construction)
unpaved: gravel or earth 720 km
Inland waterways; 209 km; navigable by
cruft drawing less than 1.2 meters
Pipelines: crude oil 1.35 km; petroleum
products 4 1 8 km; natural gas 920 km
Ports: Kuala Belait. Muara
Merchant marine: 7 liquefied gas carrier
( 1 ,000 GRT or over) totaling 348,476
GRT/340,635 DWT
Airports:
total: 2
usable: 2
with permanent-surface runways: I
with runway over 3,659 m: 1
with runway 2,440-3,659 m: 0
with runway 1,220-2,439 m: 1
Telecommunications: service throughout
country is adequate for present needs;
international service good to adjacent
Malaysia; radiobroadcast coverage good;
3.3,0(jo telephones (1987); broadcast stations —
4 AM/FM, 1 TV; 74,000 radio receivers
( 1987); satellite earth stations — I Indian Ocean
INTELSAT and 1 Pacific Ocean INTELSAT
Defense Forces
Branches; Land Force. Navy, Air Force,
Royal Brunei Police
Manpower availability: males age 15-49
79,486; fit for military service 46,258; reach
military age ( 1 8) annually 2.756 (1994 est.)
Defense expenditures: exchange rate
conversion — $300 million, 9% of GDP (1990)
61','26ea1e78cf1f648a82526a5eb22db3ec8901c2b3b4bbc213ffe50f508cee2602','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f71e27351f41dcd76db2553d5ce8bb54e988cb8ff9a637c9506dbc3e153a5b6',1994,'BG','Bulgaria','communications',170,'125 urn
Railroads: 4,300 km total, all government
owned ( 1987); 4,055 km 1 .435-meter standard
gauge, 245 km narrow gauge; 917 km double
track; 2.640 km electrified
Highways:
total: 36,930 km
paved: 33,902 km (including 276 km
expressways)
unpaved: earth 3,028 km ( 1 99 1 )
Inland waterways: 470 km (1987)
Pipelines: crude oil 193 km; petroleum
products 525 km; natural gas 1,400 km (1992)
Ports: coastal — Burgas, Varna, Varna West;
inland — Ruse. Vidin. and Lorn on the Danube
Merchant marine: 1 1 1 ships ( 1 ,000 GRT
and over) totaling 1 ,225,996 GRT/1 ,829,642
DWT, short-sea passenger 2, cargo 30,
container 2, passenger-cargo 1, roll-on/roll-off
cargo 6. oil tanker 16. chemical carrier 4.
railcar carrier 2, bulk 48
note: Bulgaria owns 1 ship ( 1 ,000 GRT or
over) totaling 8.717 DWT operating under
Liberian registry
Airports:
total: 487
usable: 85
with permanent-surface runways: 32
with runways over 3659 m: 0
with runways 2,440-3,659 m: 21
with runways 1,060-2,439 m: 36
note: a C-r30 can land on a 1 .060-m airstrip
Telecommunications: extensive but
antiquated transmission system of coaxial
cable and microwave radio relay; 2.6 million
telephones; direct dialing to 36 countries:
phone density is 29 phones per 100 persons
(1992); almost two-thirds of the lines are
residential; 67% of Sofia households have
phones (November 1988): telephone servir-'' is
available in most villages: broadcast statii
20 AM. 15 FM, and 29 TV, with 1 Soviet f V
repeater in Sofia; 2. 1 million TV sets (1990);
92% of country receives No. I television
program (May 1990); 1 satellite ground station
using Intersputnik; INTELSAT is used through
a Greek earth station
Defense Forces
Branches: Army, Navy. Air and Air Defense
Forces, Frontier Troops. Internal Troops
Manpower availability; males age 1 5-49
2,175,921; fit for military service 1.816.484;
reach military age (19) annually 70.306 (1994
est.)
Defense expenditures: 5.77 billion leva.
NA% of GDP (1993 est.): note — conversion of
defense expenditures into US dollars using the
current exchange rate could produce
misleading results
63
Burkina
200kn^
not n»c«i*«n(y aultioritativ*','5ae9933c615a4ac12c1bac4e47b0445fc6e99e01ad18ed3fd5e3011f944b4edc','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df5006977c02fc1927ca3139627c5c8416055bd8b2de21cd2c7ca8d9a8a3d64d',1994,'BI','Burundi','communications',186,'Railroads: 3.99 1 km total, all government
owned; 3,878 km 1 .000-meter gauge, 1 13 km
narrow-gauge industrial lines; 362 km double
track
Highways:
total; 27,000 km
paved; bituminous 3,2(X) km
unpaved; gravel, improved earth 17,7(X) km;
unimproved earth 6, 1 (K) km
Inland waterways: 1 2,800 km; 3,200 km
navigable by large commercial vessels
Pipelines: crude oil 1 ,343 km; natural gas 330
km
Ports: Rangoon. Moulmein, Bassein
Merchant marine: 47 ships (1.0(X)GRT or
over) totaling 665,628 GRT/94 1 .5 1 2 DWT.
passenger-cargo 3, cargo 1 5, refrigerated cargo
5, vehicle carrier 2, container 2, oil tanker 2.
chemical I, combination ore/oil l.bulk 15,
combination bulk I
Airports:
total; 83
usable: 78
with permanent-surjdce runways; 24
with runways over 3,65''^ in; 0
with runways 2.440-3.659 ni: 3
with runways 1.220-2.439 in: 38
Telecommunications: meets minimum
requirements for local and intercity service for
business and government: international service
is good; 53,000 telephones (1986):
radiobroadcast coverage is limited to the most
populous areas; broadcast station.s — 2 AM, I
FM. I TV (1985): 1 Indian Ocean INTELSAT
earth station
Defense Forces
Branches: Army, Navy, Air Force
Manpower availability: males age 15-49
1 1 . 1 99,53 1 ; females age 1 5-49 1 1 .273.643;
males fit for military service 5,979,7 10;
females fit for military service 6,034,810;
males reach military age ( 1 8) annually 445,933
(1994 est.); females reach military age ( 1 8)
annually 430.738 (1994 e.st.); both .sexes liable
for military service
Defense expenditures; exchange rate
conversion — $NA, NA% of GDP','d6766e7937449755ff90c777f584ed55dc0cf7509da349d0b7fd5fd25b5bae31','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77fbbd8fd6fd8f6892147f4184181a2ce255ff69ba7facc6ae77915f4a9d79bd',1994,'KH','Cambodia','communications',192,'Highways:
total: 6,285 km
paved: 1,099 km
unpaved: gravel, crushed stone 2,500 km;
improved, unimproved earth 2,686 km (1990)
Inland waterways: Lake Tanganyika
Ports: Bujumbura (lake port) connects to
transportation systems of Tanzania and Zaire
Airports:
total: 5
usable: 3
with permanent-surface runways: 1
with runways overS.6S9 m: 0
with runways 2,440-3,659 m: 1
with runways 1,220-2,439 m: 0
Teiecommunications: sparse system of wire,
radiocommunications, and low-capacity
microwave radio relay links; 8,000 telephones;
broadcast stations — 2 AM, 2 FM, 1 TV; 1
Indian Ocean INTELSAT earth station
Defense Forces
Branches: Army (includes naval and air
units), paramilitary Gendarmerie
Manpower availability: males age 15-49
1,315,660; fit for military service 687,474;
reach military age (16) annually 67,949 (1994
est.)
Defense expenditures: exchange rate
conversion — $28 million, 3.7% of GDP ( 1 989)
418 tin
Railroads: 612 km 1. 000-meter gauge,
government owned
Highways:
total; 13,351 km (some roads in serious
disrepair)
paved: bituminous 2,622 km
unpaved; crushed stone, gravel, or improved
earth 7,105 km; unimproved earth 3,624 km
Inland waterways: .3.700 km navigable all
year to craft drawing 0.6 meters; 282 km
navigable to craft drawing 1.8 meters
Ports: Kampong Saom, Phnom Penh
Airports:
total; 20
usahle; 13
with permanent-surface runways; 6
with runways over J, 659 rn; 0
with runways 2.440-3,659 m; 2
with ruttways 1.220-2,439 m; 8
Telecommunications: service barely
adequate for government requirements and
virtually nonexistent for general public:
international service limited to Vietnam and
other adjacent countries; broadcast stations — 1
AM, no FM. 1 TV
Defense Forces
Branches:
Khmer Royal Armed Force.s (KRAF); created
in 1993 by the merger of the Cambodian
People''s Armed Forces and the two
iion-Communist resistance armies: note — the
KRAF is also known as the Royal Cambodian
Armed Forces (RCAF)
Resistance force.\\; National Army of
Democratic Kampuchea (Khmer Rouge)
Manpower availability: males age 1 5-49
2,182.912; fit for military service 1.217..357;
reach military age (18) annually 67.463 (1994
est.)
Defense expenditures: exchange rate
conversion — $NA, NA9f- of GDP
70','4ebf42f230a16275d60d2e2ef0e4527cdd5cb5364672e579eef6b5c3b49b0775','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c176b685d0c02cdaffc631ec2c3cf7c11d93fc1ece66187dc3d80a575772498',1994,'CM','Cameroon','communications',202,'Railroads: 1 ,003 km total; 858 km
1 .000-meter gauge, 145 km 0.600-meter gauge
Highways:
total: 65,000 km
paved: 2,682 km
unpaved: gravel, improved earth 32,318 km:
unimproved earth 30.000 km
Inland waterways: 2.090 km; of decreasing
importance
Ports; Douala
Merchant marine: 2 cargo ships ( 1 .000 GRT
or over) totaling 24,122 GRT/3.3,509 DWT
Airports:
total: 61
usable: 49
with permanent-surface runways: 1 1
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 6
with runways 1 ,220-2,439 m: 2 1
Telecommunications: good system of open
wire, cable, ttoposcatter, and microwave radio
relay; 26,0(K) telephones, 2 telephones per
1,000 persons, available only to business and
government; broadcast stations — 1 1 AM, 1 1
FM. 1 TV; 2 Atlantic Ocean INTELSAT earth
stations
Defense Forces
Branches: Army. Navy (including Naval
Infantry). Air Force. Nadonal Gendarmerie.
Presidential Guard
Manpower availability; males age 15-49
2,939,761; fit for military service 1,481,750;
reach military age ( 1 8) annually 1 37,020 ( 1 994
est.)
Defense expenditures; exchange rate
conversion — $2 19 million, less than 2% of
GDP (1990 est.)','bee01d3d7d6c912f5b6a1bf93d7417255bf4b0a2a548b4f350d595151638c596','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61541ca6ef0ab342f6589c30bd01ccfb2d906e101a1474f309db29e8e07dbede',1994,'CA','Canada','communications',203,'1200 km
Geo^ aphy
Location: Northern North America,
hordering the North Atlantic Ocean and North
Pacific Ocean north of the US
Map references: Arctic Region, North
America. Standard Time Zones of the World
Area:
loUil (ireti: 9,97fi, 140 sq km
/««(/ ami: 9,220.970 sq km
comparatiw ami; slightly larger than US
Land boundaries: total 8,89.7 km, US 8,89.7
km (includes 2,477 km with Alaska)
Coastline: 243,791 km
Maritime claims;
fimtiiieiital shelf; 2(K)-m depth or to depth of
exploitation
exclusive fisliiiij; zone: 200 nm
teiriiorial sea: 1 2 nm
International disputes: maritime boundary
disputes with the US; Saint Pierre and
Miquelon is focus of maritime boundary
dispute between Canada and France
Climate: varies from temperate in south to
subarctic and arctic m north
Terrain: mostly plains with mountains in
west and lowlands in southeast
Natural resfturccs: nickel, /.inc, copper, gold.
lead, molybdenum, potash, silver, fish, timber,
wildlife, coal, petroleum, natural gas
I>and use:
arable land: 5‘''/i
pcrmanenl crops: ()‘/f
nicadon s and pastures:
foresi and woodland: 35''4
other: 579;
Irrigated land: 8.400 sq km ( 1989 est.)
Knvirunment:
current issues: iicid rain severely affecting
lakes and damaging forests; metal smelting,
coal-burning utilities, and vehicle emissions
impacting on agricultural and forest
productivity; ocean waters becoming
contaminated due to agricultural, industrial,
mining, and forestry activities
natural hazards: conlinuous permafrost in
north is a serious obstacle to development
international agreements: party to — Air
Pollution, Air Pollution-Nitrogen Oxide.s, Air
Pollution-Sulphur, Antarctic Treaty.
Biodiversity, Climate Change, Endangered
Species. Environmental Modification,
Hazardous Wastes. Marine Dumping, Nuclear
Test Ban, Ozone Layer Protection, Ship
Pollution, Tropical Timber. Wetlands; signed,
but not ratified — Air Pollution-Volatile
Organic Compound.s, Antarctic-
Environmental Protocol, Law of the Sea
Note: second-largest country in world (after
Russia); strategic location between Russia and
US via north polar route; nearly 90% of the
population is concentrated in the region near
the us/Canada border
Kailroads: 146.444 km total; two major
transcontinental freight railw''ay systems —
Canadian National (government owned) and
Caiiailian Pacific Railway; passetigcr
service — VIA (government operated); 158 km
is electrified
Highways:
total: 88*4.272 kin
paved: 25(1.023 km
unpaved: gravel 462,913 km; earth 1 71,336
km
Inland waterways: I.OOOkm. including Saint
Lawrence .Seaway
Pipelines: crude and rcllned oil 23.5()4 km:
natural gas 74,980 km
Ports: Halifax, Montreal, Quebec, Saint John
(New Brunswick). Saint John’s
(Newfoundland), Toronto, Vancouver
Merchant marine: 59 ships ( l.tXX) GRT nr
over) totaling 448.357 GRT/639,319 DWT,
passenger 1 . short-sea passenger 3.
passenger-cargo 1 , cargo 8, railcar carrier 2,
roll-on/roll-off cargo 6, container I, oil tanker
22, chemical tanker 4, specialized tanker 2,
bulk 9
note: docs not include ships used exclusively
in the Great Lukes
Airports:
total: 1 ,356
u. sable: 1,107
with permanent-surface runways: 458
with runways over .?,659 ni: 4
with runways 2,44l)-.i,f>59 m: 29
with runways l.22()-2.4d9 m: 326
Telecommunications: excellent service
provided by modem media; 1 8.0 million
telephones; broadcast stations — 9(K) AM, 29
FM. 53 ( 1.4(X) repeaters) TV; 5 coaxial
submarine cables; over 3(X) earth stations
operating in INTELSAT (including 4 Atlantic
Ocean and I Pacific Ocean) and domestic
systems
Defcn.se Forces
Branches: Canadian Armed Forces
(including Lund F''orees Command. Maritime
Command, Air Command, Communications
Command, Training Command), Royal
Canadian Mounted Police (RCMP)
Manpower availability: males age 1 5-49
7,.5t)8..59t); fit for military service 6,482,267;
reach military age (17) annually 1 9 1 .850 ( 1 994
est.)
Defense expenditures: exchange rate
conversion — $1 1 .3 billion. 2% of GDP
(FY92/93)
74
Cape Verde
^S^nto Antie
7S fcm
Sli
Vic^nf •
^ sio
Nicoltu
’">ro
\\
North Atlantic Ocean
JO Sot*''''*''’''® „
llh**''^* ^
hfopo
Brtva ^
Sio Titgo','7ca00824f7bdce7f75c0c0b018b4681714004ad5744f84639841d202f0eda35c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('404b6d7710cd8ff5095dd2decdaaa9954cb3a4845bbf0fcde89a2fe4112a11ea',1994,'KY','Cayman Islands','communications',210,'Highways:
total: NA
paved: NA
unpaved: NA
Ports: Mindelo, Praia
Merchant marine: 7 cargo ships ( 1 ,000 GRT
or over) totaling 1 1,717 GRT/19,000 DWT
Airports:
total: 6
usable: 6
with permanent-surface runways: 6
with runways over J,6S9 m: 0
with runways 2,440-3,659 m: I
with runways 1,220-2,439 m: 2
Telecommunications: interisland
microwave radio relay system, high-frequency
radio to Senegal and Guinea-Bissau; over
1,700 telephones; broadcast stations — I AM, 6
FM. 1 TV; 2 coaxial submarine cables; 1
Atlantic Ocean INTELSAT eaith station
Defense Forces
Branches: People''s Revolutionary Armed
Forces (FARP) (including Army and Navy),
Security Service
Manpower availability: males age 15-49
78,153: fit for military service 45,804
Defense expenditures: exchange rate
conversion — SNA, NA% of GDP
Caribbean Saa
Grand Cayman
OEOaOE TOWN
Caribbean Sea
Highways:
total: 160 km (main roads)
paved: NA
unpaved: NA
Ports: George Town, Cayman Brae
Merchant marine: 30 ships ( 1 ,000 GRT or
over) totaling 368.037 GRT/58 1,060 DWT,
passenger-cargo 1, cargo 8, roll-on/roll-off
cargo 7. oil tanker 3, chemical tanker 2, bulk 9
note: a flag of convenience registry
Airports:
total: 3
u.sahle: 3
with permanent-surface runways: 2
with runways over 3.659 m: 0
with runways 2.440-3.659 m: 0
with runways 1.220-2.439 m: 2
Telecommunications: 35,000 telephones;
telephone system uses 1 s''lhmarine coaxial
cable and I Atlantic Ocean INTELSAT earth
station to link islands and access international
services: broadcast stations — 2 AM, 1 FM, no
TV
Defense Forces
Branches: Royal Cayman Islands Police
Force (RCIPF)
Note; defense is the responsibility of the UK
77','751355c3898350ca71edd09b0cc5796712bc8dde3e105a8888e46994dd1ff236','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b46b3c7b65bac95211d97351da5faa176f0b3767de110c3100a619705dd6af98',1994,'DZ','Algeria','communications',222,'Highways:
total; 22,000 km
paved: bituminous 458 km
unpaved: improved earth 10.542 km;
unimproved earth 1 1,000 km
Inland waterways: 800 km; traditional trade
carried on by means of shallow-draft dugouts;
Oubangui is the most important river
Airports;
total; 65
usable; 5 1
with permanent-surface runways: 3
with runways over 3.659 m: 0
with runways 2,440-3,659 m; 2
with runways 1,220-2.439 m: 20
Telecommunications: fair system; network
relies primarily on radio relay links, with
low-capacity, low-powered
radiocommunicaiion also used; broadcast
stations — 1 AM, I FM, I TV; I Atlantic Ocean
INTELSAT earth station
Defense Forces
Branches: Central African Army (including
Republican Guard). Air Force. National
Gendarmerie, Police Force
Manpower availability: males age 15-49
701 ,728; fit for military service 367,264
Defense expenditures; exchange rate
conversion — $23 million, 1.8% of GDP(1989
est.)','3f25d53a6be1d988bf84fa50b12f80bcac4485d6368df63f024289bf51bd376a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('986e82e61ab6efad5c0ab5c037ffabb52b3d006e12ededfabd48da76b0f4da1c',1994,'CL','Chile','communications',229,'Highways:
/oto/,''31.322 km
paved: bituminous 32 km
unpaved: gravel, crushed stone 7,3(X) km;
earth 23,990 km
Inland waterways; 2.(KX) km navigable
Airports;
total: 68
usable: 58
with permanent-surface runways: 5
with runways over .1,659 in: 1
with runways 2.440-3,659 in: 3
with runways 1.220-2.4.19 in: 27
Telecommunications: fair system of
radiocoinmunication stations for intercity
links; broadcast stations — 6 AM, I FM, limited
TV service; many facilities are inoperative; 1
Atlantic Ocean INTELSAT earth station
Defense Forces
Branches: Army (include.^ Ground Forces,
Air Force, and Gendarmerie). Republican
Guard
Manpower availability: mules age 15-49
1.276.167; fit for military service 663,326;
reach military age (20) annually 54.07.7 (1994
est.)
Defense expenditures: exchange rate
conversion — $58 million. 5.69f of GDP 1 1 989)','d1ea75fe83d6cd2fe1b5f93cd4f4120c7e5531157058bb7eafa1dc96521fba63','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7105061b8fb6fbee6ecea2a0a190472fa57ab7b231d27f44e644e5358f2e2ef9',1994,'CN','China','communications',234,'(also see separate Taiwan entry)
Highways;
total: 79.593 km
ixived: 10,984 km
unpaved: gravel or earth 68,615 km (1990)
Inland waterways: 725 km
Pipelines: crude oil 755 km; petroleum
products 785 km; natural gas 320 km
Ports: Antofagasta, Iquique. Puerto Montt,
Punta Arenas, Valparaiso, San Antonio,
Talcahuano, Arica
Merchant marine: 31 ships ( 1,000 GRT or
over) totaling 449,253 GRT/755,821 DWT,
cargo 7, roll-on/roll-off cargo 3, oil tanker 2.
chemical tanker 3, liqueried gas tanker 3,
combination ore/oil 3. bulk 10
note: in addition, 1 naval tanker and I military
transport are sometimes used commercially
Airports:
total: 392
usable: 349
with permanent-surface runways: 47
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 13
with runways 1.220-2,439 ni: 58
Telecommunications: modem telephone
system based on extensive microwave radio
relay facilities; 768,000 telephones; broadcast
stations — 1.59 AM, no FM, 131 TV, 1 1
shortwave; satellite ground stations — 2
Atlantic Ocean INTELSAT and 3 domestic
Defense Forces
Branches: Army of the Nation, National
Navy (including Naval Air, Coast Guard, and
Marines), Air Force of the Nation, Carabineros
of Chile (National Police), Investigative Police
Manpower availability; males age 15-49
3,705,321; fit for military service 2,759,130:
reach military age ( 19) annually 1 20,5 1 2 ( 1994
est.)
Defense expenditures; exchange rate
conversion — Si billion, 3.4% of GDP (1991
est.)
laatm,
Railroads: tot il about 64.000 km; 54,000 km
of common carrier lines, of which 53,400 km
are 1 .435-meter gauge (standard) and 600 km
are 1 .000-meter gauge (nanow); 1 1 ,200 km of
standard gauge common carrier route are
double tracked and 6,900 km are electrified
(1990); an additional 10000 km of varying
gauges (0.762 to 1 .067-meter) are dedicated
industrial lines
Highways:
total; 1.029 million km
paved; 170,000 km
unpaved; gravel/improved earth 648.000 km;
unimproved earth 2 1 1 ,000 km ( 1 990)
Inland waterway:,; 1 38,600 km; about
109,800 km navigable
Pipelines; crude oil 9,700 km (1990);
petroleum products 1,100 km; natural gas
6,200 km
Ports; Dalian, Guangzhou, Huangpu.
Qingdao. Qinhuangdao. Shanghai. Xingang,
Zhanjiang, Ningbo. Xiamen. Tanggu. Shantou
Merchant marine: 1 ,54 1 ships ( 1 ,000 GRT
or over) totaling 14,884,756 GRT/22.475.985
DWT, passenger 24, short-.sea passenger 43.
passenger-cargo 25, cargo 819. refrigerated
cargo 17, container 85, roll-on/roll-off cargo
21, multifunction/barge carrier 1, oil tanker
192. chemical tanker 13, bulk 285. liquefied
gas 4, vehicle carrier 2, combination bulk 9,
barge carrier I
note; China beneficially owns an additional
227 ships ( 1 ,000 GRT or over) totaling
approximately 6,187.1 17 DWT that operate
under Panamanian, British, Hong Kong.
Maltese, Liberian, Vanuatu, Cypriot. Saint
Vincent. Bahamian, and Romanian registry
Airports:
total; 330
usable; 330
with permanent-surface runways; 260
with runways over 3,659 m; fewer than 10
with runways 2,440-3.659 m: 90
with runways 1.220-2,439 m; 200
Telecommunications: domestic and
international services are increasingly
available for private use; unevenly distributed
internal system serves principal cities,
industrial centers, and most townships:
1 1,000,000 telephones (December 1989);
broadcast stations — 274 AM. unknown FM.
202 (2.050 repeaters) TV; more than 215
million radio receivers; 75 million TVs;
satellite earth stations — 4 Pacific Ocean
INTELSAT. 1 Indian Ocean INTELSAT. 1
INMARSAT, and 55 domestic
Defense Forces
Branches: People’s Liberation Army (PLA),
PLA Navy (including Marines). PLA Air
Force. Second Artillery Corps (the strategic
missle force). People’s Armed Police (internal
security troops, nominally subordinate to
Ministry of ihiblic Security, but included by
the Chinese as part of the "armed forces" and
considered to be an adjunct to the PLA in war
time)
Manpower nvailability; males age 1 5-49
347,458,052: fit for military service
192,546.413; reach military age (18) annually
10,2,56.181 (1994 est.)
Defense expenditures: defense budget —
52.04 billion yuan. NA% of GUP ( 1 994 est.);
note - conversion o'', the defense budget into US
dollars using the current exchange rate could
produce misleading results','e56a6e0361ec61a013e43c64964e5168096f7cee28cf7a13cacf55c2f3099453','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c14521bf5c7f4ec42ad5c3d09db3575d447f3aa5608c440f94170272f27901e9',1994,'CX','Christmas Island','communications',241,'(territory of Australia)
Highways:
total: NA
paved: NA
unpavtd: NA
Ports: Flying Fish Cove
Airports;
total: 1
usable: 1
with permanent-surface runways: 1
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 0
with runways 1,220-2,439 m: I
Telecommunications: broadcasting
stations — 1 AM, 1 TV
Defense Forces
Note: defense is the responsibility of Australia
Clipperton Island
(possession of France)','7c83ec8a1e3dc0009df74edad65c2099b530a4df6e12e150e484fde5c9a20ae6','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3885ccad77000a69c18ddbd682770b8ab2fd6f410e89b3a8040235170a8cebff',1994,'PF','French Polynesia','communications',249,'Ports: none; offshore anchorage only
Defense Forces
Note: defense is the responsibility of France
(overseas territory of France)
flit ••
South PocHic Oeton
*>
Society
Islends
TthiH
'' Archipel des
Tuemotu
lies •
Tubuai''
Highways:
total: 600 km (1982)
paved: NA
unpaved: NA
Ports: Papeete, Bora-bora
Merchant marine: 3 ships ( 1 ,000 CRT or
over) totaling 4,127 GRT''‘>,7 10 DWT,
passenger-cargo 2, refrigerated cargo I
note: a captive subset of the French register
Airports:
total: 43
usable: 4 1
with permanent-surface runways: 23
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 2
with runwaws 1,220-2,439 m: 12
Telecommunications: 33,200 telephones;
84,000 radio receivers; 26.400 TV sets;
broadcast stations — 5 AM, 2 FM, 6 TV; 1
Pacific Ocean INTELSAT earth station
Defense Forces
Branches: French forces (including Army,
Navy, Air Force), Gendarmerie
Note: defense is responsibility of France
French Southern and Antarctic
Lands
(overseas territory of France)
700 km
Indian
Ocean
f/e Amiterdam^
ih Saint-Paui**
^ Jtes Cr^iet
^les Kerguelen','fa712451d650464204a5340d694c1a03e004e869a940b9c17aa7fa3a49b8ac0a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85e6ec9b7e3823a85bc9c650176c85a4565be268db93e2d742a2b885ec117baa',1994,'CC','Cocos (Keeling) Islands','communications',250,'(territory of Australia)
10 km * North KooUrtg
* isiana
Indian
Ocean
South
Keeling
talenda
Hat$au*eh
tsiina
Highways:
total: NA
paved: NA
unpaved: NA
Ports: none; lagoon anchorage only
Airports;
total: 1
usable; I
with permanent-surface runways: I
with runways over J,6S9 m: 0
with runways 2, 440-3.659 m: 0
with runways 1,220-2.439 m: 1
Telecommunications: 250 radios (1985);
linked by telephone, telex, and facsimile
communications via satellite with Australia;
broadcast stations — 1 AM, no FM, no TV
Defense Forces
Note: defense is the responsibility of Australia','ee9497ead0480f70a15bcf0435f5749c5442e8ae8e8552118ad22d111264a12b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb396a013c60d0561659f3b6ae5e88a5930c5730a2bce4cc7724a9410b73fd46',1994,'CO','Colombia','communications',256,'Cthhbttn
aim — to provide a forum for largest debtor
nations in Latin America
members — ( 1 1 ) Argentina, Bolivia, Brazil, Chile, Colombia, Dominican Republic. Ecuador,
Mexico, Peru, Uruguay. Venezuela
463
Group of 15 (G-15) members — (IS) Algeria, Argentina, Brazil, Egypt, India, Indonesia, Jamaica, Malaysia, Mexico,
Nigeria, Peru, Senegal, Venezuela, Yugoslavia, Zimbabwe
note— byproduct of the Non-Aligned
Movement
established — September 1989
aim — to promote economic cooperation
among developing nations; to act as the
main political organ for the Non-Aligned
Movement
Group of 19 (G-a>)
established — NA October 1975
aim — to represent the interests of the less
developed countries (LDCs) that participated
in the Conference on International Economic
Cooperation (CISC) held in several sessions
between NA December 1975 and 3 June
1977 _
Group of 24 (G-24)
established — NA January 1972
aim — to promote the interests of developing
counuies in Africa, Asia, and Latin America
within the IMF
Group of 30 (G-30) members — (30) informal group of 30 leading international bankers, economists, financial
experts, and businessmen organized by Johannes Witteveen (former managing director of the
established — NA 1979 IMF)
aim — to discuss and propose solutions to the
world’s economic problems _
Group of 33 (G-33) members — (33) leading economists from 13 countries
established— HA 1987
members — (24) Algeria, Argentina, Brazil, Colombia, Cote d''Ivoire, Egypt, Ethiopia, Gabon,
Ghana, Guatemala, India, Iran, Lebanon, Mexico, Nigeria, Pakistan, Peru, Philippines, Sri
Lanka, Syria, Trinidad arid Tobago, Venezuela, Yugoslavia, Zaire
members — (19) Algeria, Argentina, Brazil, Cameroon, E»pt, India, Indonesia, Iran, Itug,
Jamaica, Mexico, Nigeria, Pakistan, Peru, Saudi Arabia, Venezuela, Yugoslavia, Zaire, Zwbia
aim — to promote solutions to international
economic problems _
Group of 77 (6-77)
established — NA October 1967
aim — to promote economic cooperation
among developing countries; name persists
in spite of increased membership
members — (127 plus the Palestine Liberation Organization) Afghanistan, Algeria, Angola,
Antigua and Barbuda, Argentina, The Bahamas, Bahrain, Bangladesh, Barbados, Belize, Benin,
Bhutan, Bolivia. Botswana, Brazil, Brunei, Burkina, Burma, Burundi, Cambodia, Cameroon,
Cape Verde, Central African Republic, Chad, Chile, Colombia, Comoros, Congo, Costa Rica,
Cote d''Ivoire, Cuba, Cyprus, Djibouti, Dominica, Dominican Republic, ^uador, Egypt, El
Salvador, Equatorial Guinea. Ethiopia. Fiji, Gabon, The Gambia, Ghana, Grenada, Guatemala,
Guinea. Guinea-Bissau, Guyana, Haiti, Honduras. India. Indonesia, Iran, Iraq, Jamaica, Jordan,
Kenya, North Korea, South Korea, Kuwait, Laos, Lebanon, Lesotho. Liberia, Libya,
Madagascar, Malawi, Malaysia. Maldives, Mali, Malta, Mauritania, Mauritius, Mexico,
Mongolia, Morocco, Mozambique, Namibia, Nepal, Nicaragua, Niger, Nigeria, Oman. Pakistan,
Panama, Papua New Guinea, Paraguay, Peru. Philippines, Qatar, Romania, Rwanda, Saint Kitts
and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and Principe, Saudi
Arabia, Senegal, Seychelles. Sierra Leone, Singapore, Solomon Islands, Somalia, Sri Lanka,
Sudan, Suriname, Swaziland, Syria, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago,
Tunisia, Uganda, UAE, Uruguay, Vanuatu, Venezuela, Vietnam, Western Samoa. Yemen,
Yugoslavia, Zaire, Zambia, Zimbabwe, Palestine Liberation Organization
Gulf Cooperation Council (GCC)
note — also known as !he Cooperation
Council for the Arab States of the Gulf
established — 25 May 1981
aim — to promote regional cooperation in
economic, social, political, and military
affairs
members — (6) Bahrain, Kuwait, Oman, Qatar, Saudi Arabia, UAE
Habitat
see Commission on Human Settlements
Hexagonal Group
see Central European Initiative (CEI)
high-inconie countries
another term for the industrialized countries with high per capita GNPs/GDPs; see developed
countries (DCs)
464
Industrial countries
another term for the developed countries; see developed countries (DCs)
Intcr^American Development Bank
(lADB)
note — also known as Banco Interamericano
de Desarrollo (BID)
established — 8 April 19S9
effective — 30 December 1959
members — (44) Argentina, Austria, The Bahamas, Barbados, Belgium, Belize, Bolivia, Brazil,
Canada, Chile, Colombia. Costa Rica, Denmark, Dominican Republic, Ecuador, El Salvador,
Finland, France, Germany, Guatemala, Guyana, Haiti. Honduras, Israel, Italy, Jamaica, Japan,
Mexico, Netherlands, Nicaragua. Norway. Panama, Paraguay, Peru, Portugal, Spain, Suriname,
Sweden, Switzerland, Trinidad and Tbbago, UK, US, Uruguay, Venezuela
aim — to promote economic and social
development in Latin America
lnter>Governmental Authority on Drought
and Development (IGADD)
members — (6) Djibouti, Ethiopia, Kenya, Somalia, Sudan, Uganda
'' established — 15-16 January 1986
, aim — to promote cooperation on
drought-related matters
International Atomic Energy Agency
(IAEA)
established — 26 October 1956
effective — 29 July 1957
aim — to promote peaceful uses of atomic','8c93c28cd9e548b54ed41d8d7eb8e9f1a98440baa201d6f022b12e00821886f9','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c585a63d875793ffbd0e7d9e531a99dd91fad0fe6a99267d1a69b0ea669500ee',1994,'KM','Comoros','communications',263,'Railroads: 3,386 km; 3,236 km 0.9 1 4-meter
gauge, single track (2.61 1 km in use). 150 km
1 .435-meter gauge
Highways:
total: 128.1 17 km (1989)
paved: IU..3.30km
unpaved: gravel/earth 1 18.387 km
Inland waterways: I4..300 km. na\\ igable by
rive'' boats
Pipelines: crude oil 3,585 km; petroleum
pr^ucts 1 ,3.50 km; natural ga.s 830 km: natural
gas liquids 1 25 km
Ports: Barranquilla, Buenaventura.
Cartagena. Covenas, San Andres. Santa Maria,
Tumaco
Merchant marine: 27 ships ( 1 .000 GRT or
over) totaling 21 1,777 GRT/.3.35,763 DWT.
cargo 1 1 . oil tanker 3. bulk 7. container 6
Airports:
total: 1,-369
usable: 1.156
with permanent-surface runways: 73
with runways over J,li59 m: 1
with runways 2.440-2.639 m: 9
with rtatways 1.220-2.4.19 m: 205
Telecommunications: nationwide radio relay
system; 1 ,890.000 telephones: broadcast
stations — 413 AM. no FM. 33 TV. 28
shortwave: 2 Atlantic Ocean INTELSAT earth
stations and 1 1 domestic satellite earth stations
Defense Forces
Branches: Army (Ejercito Nacional). Navy
(Armada Nacional. including Marines). Air
Force (Fuerza Aerea Colombiana). National
Police (Policia Nacional)
Manpower availability: males age 1 5-49
9.639.080: fit for military service 6.507.935;
reach military age (18) annually 354.944 ( 1994
est.)
Defense expenditures; exchange rate
conversion— $ 1 ,2 billion (1992 est.)
jgjun.
Moumbiqu*
Chqnnti
Highways:
total: 750 km
/xtved: bituminous 210 km
unpaved: crushed stone, gravel .540 km
Ports: Mutsamudu. Monmi
Airports:
total: 4
usable: 4
with /h''nnanent-suiydce runways: 4
with runways over .Lft,5V m: 0
with runways 2,44f)-.).6.5V m: I
with runways ! .22()-2A.I''i m: 3
Telecommunicatians: sparse system of radio
relay and high-frequency radio communication
stations for intcrislund and external
communications to Madagascar and Reunion;
over 1 ,8(X) telephones; broadcast stations — 2
AM. I FM. no TV
Dercnae Forces
BraiKhcs: Comoran Defense Force (FDC)
Manpower availability: males age 15-49
1 12.918: fit for military service 67.522
DefenM expenditures: $NA. NA% of GDP
91','93c4d5f30643fec716b7a35152c146ab26f08294ec98e3e46b6418025a889659','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('261ec503e663163423712f9d1a7dee18b9af0b1f21527495d0c4265c2e6f7593',1994,'CG','Congo','communications',268,'GcoRraphy
Loralioii: Wesiem At''ricu. burdering the
South Atlantic CVean between Gabon and
Zaire
Map references: Africa. Standard Time
Zones of the World
Area:
total area: .Ul.tXlO sq km
land area: .''4 1 .JIK) sq km
I''omparative area: slightly smaller than
Montana
Land boundaries: total .^..^04 km. Angola
201 km, Cametwn ^2.^ km. Central African
Republic 4b7 km. Gabon I .''Xl.''i km. Zaire
2.410 km
CtMslIine: IbOkm
Maritime claims:
territorial \\ea: 2(K) nm
Inlemalional dbpuics: long segment of
boundary w ith Zaim along the Congo River is
mdcrinite ( no division of the river or its islands
has been made )
C''iimale: tropical; rainy season i March to
June): dry season iJune to tVioberi; constantly
high lemperaiurcs and humidity ; panicularly
enervating climate astride the Equator
Terrain: coastal plain, soutliem basin, central
plateau, northern basin
Natural resources: petroleum, umber.
potash, lead. /me. uranium, copper.
phosphates, natural gas
IjiimI use:
aruhle land: 2'' •
pemianent i rop.\\: O''r
ineadou w and iki\\liire\\: 2‘>‘''i
/(•ri''v/ and ivootlland: 62'''';
other: l‘ i
Irrigated land: 41) sq km i IOM4i','0d28fe4d1d0a2bf3c08ff0713f832cb115948ca64eb72aa701a7e3cf9a384a22','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c50a449a189aa280c508adfe2b80685956b01f04637b311253e9c2319a1d1a59',1994,'ET','Ethiopia','communications',272,'Railroads; 797 km. 1.067-meier gauge, single
track (includes 285 km that are privately
owned)
Highways:
total: 1 1 .960 km
paved: .560 km
itniHived: gravel or crushed stone 8.50 km,
improved earth 5.3.50 km; unimproved earth
5.2(X) km
inland waterways; the Congo and Ubangi
(Gubangui ) Rivers provide 1 . 1 20 km of
commercially navigable water transport: tlx*
rest are used for Ux''al traffic (*nl>
Pipelines: crude oil 25 km
PiHls: t5)inle-Nmre Kx''can port). Brazzaville
(nver port)
Airports;
total: 4 1
usable: 37
u ith permanent- surfiuv runnuys: 5
n ith rumvays over .(,6.5V m: 0
ti lth rumvays 2.-/4r)-.(.5,5Vm.- I
ivith rumvays l.22(>-2.-tJVm: 16
Triecommunkalions; services adequate for
government use; primary network is composed
of radio relay routes and coaxial cables: key
centers are Brazzaville. Poinie-Noire. and
Lixtbomo; 1 8, 1 (K) telephones: bnxidcasi
stations — 4 AM. I FM,4TV; I Atlantic Ocean
satellite earth statimt
Defense Forces
Branches: Army, Navy (including Marine.s),
Air Force, National Police
Manpower availability : males age 15-49
55 1 , 1 5 1 ; fit for military service 280,372: reach
military age (20) annually 24.441 (1994 est.)
Defense expenditures: exchange rate
conversion — SNA. NA% of GDP
Highways;
total: 24. 1 27 km
paved: 3,289 km
unpaved: gtavel 6,664 km; improved earth
1 ,652 km; unimproved earth 1 2,522 km ( 1993)
Ports; none; landlocked
Merchant marine: 1 2 ships ( 1 ,000 GRT or
over) totaling 62,627 GRT/88,909 DWT, cargo
8, roll on/roll off cargo 1 , livestock carrier 1 , oil
tanker 2
Airports:
total: 120
usable: 84
with permanent-surface runways: 10
with runways over 3.659 m: 1
with runways 2,440-3,659 tn: 15
with rimways 1,220-2,439 tn: 83
Telecommunications: open-wire and radio
relay system adequate for government use;
open-wire to Sudan and Djibouti; microwave
radio relay to Kenya and Djibouti; broadcast
stations— 4 AM, no FM, 1 TV; 100,000 TV
sets; 9,000,000 radius; satellite earth stations —
1 Atlantic Ocean INTELSAT and 2 Pacific
Ocean INTELSAT
Defense Forces
Branches: Ethiopian People''s Revolutionary
Democratic Front (EPRDF)
Manpower availability; males age 15-49
13,229,078; fit for military service 6,867.582;
reach military age (18) annually 596,69 1 ( 1 994
est.)
Defense expenditures: exchange rate
conversion — SNA, NA% of GDP
Europe Island
(possession of France)
Falkland Islands
(Islas Malvinas)
(dependent territory of the UK)','4e613ff4fac0a7688b6da8eedab192d048fc1d3adeca0827f06a49ad7845285c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b5a9dc20e0178568de5154bd6b610a35b3a7331af8b827e70fee5dcc086a741',1994,'CK','Cook Islands','communications',273,'(free association with New Zealand)
Suwttpw
South Pteitie Ocoon
e^hrmHan
ra*vfM''
MtrttfM
i^arofoof#
aAVAHUA
Highways:
total: 187 km
paved: 35 km
unpaved; gravel 35 km; improved earth 84 km;
unimproved earth 33 km (1980)
Ports: Avatiu
Merchant marine: 1 cargo ship ( 1 ,000 or
over) totaling 1,464 GRT/2,181 DWT
Airports:
total: 7
usable: 7
with permanent-surface runways: I
With runways over 3,659 m: 0
with runways 2,440-3,659 m: 0
with runways 1,220-2,439 m; 5
Telecommunications: broadcast stations — 1
AM, 1 FM, 1 TV; 1 1 ,000 radio receivers:
1 7,000 TV receivers (1989); 2,052 telephones;
1 PaciHc Ocean INTELSAT earth station
Defense Forces
Note: defense is the responsibility of New
Zealand
O
iSgjLBL
• httf ^ /tttw
^ a
Cannt* .
Jtms
Cor«/ S09
Wrtc* AmT..
C*fp Island^','da1909a0e8e2f301ecc73f3899123ef5b0f92dabc0b789b28050d6b6323daaa0','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31cb4c8530c188204dfc9aa0dd1233df67392a04282f424742675f0ddd7598b9',1994,'CR','Costa Rica','communications',283,'Railroads: 950 km total, all 1.067-mete.
gauge; 260 km electrified
Highways:
total: 35,536 km
luived: 5.600 km
uniwved: gravel and earth 29.936 km (1991)
Inland waterways; about 7.30 km. seasonally
navigable
Pipeiines; petroleum products 176 km
Ports: Puerto Limon. Caldera. Golfito, Moin,
Puntarenas
Merchant marine: I cargo ship ( 1 .000 CRT
or over) totaling 2.878 GRT/4.,S06 DWT
Airports:
total: 184
usable: 165
with /lermanent-surfoce runways: 27
with rMwu''ov.t over 3,6.59 m: 0
with runways 2J40-X6S9 m; 2
with rMtm''rtv.s l.220-2.4.l9tn: 9
Telecommunications; very giwxl domestic
telephone service: 292,0(X) telephones;
connation into Central American Microwaxe
System; broadcast stations — 71 AM. no FM.
1 8 TV, 1 3 shortwave; I Atlantic Ocean
INTELSAT earth station
Defense Forces
Branches; Civil Guard. Rural Assistance
Guard
note: constitution prohibits armed forces
Manpower availability: males age 15-49
873,987; fit for military service 588.223; reach
military age (18) annually 32„308 (1994 est.)
Defense expenditures: ex hangerute
conversion — $22 million, 0.59?'' of GDP ( 1 989)
Cote d’Ivoire
(also known ax Ivoiy Ctmst)','e58d061d298c5dac339a1909255005e111c4bf74d560a8ee91a4c7c321ecd5ec','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46cc0ead4b99223dfdd3bb6b4d4b70cf79276784ff51a89bfdf6f8143c2a256a',1994,'HR','Croatia','communications',286,'Railroads: 660 km (Burkina border to
Abidjan, 1 .00-meter gauge, single track, except
25 km Abidjan-Anyama section is double
track)
Highways:
total: 46,600 km
paved: 3,600 km
unpaved: gravel, crushed stone, improved
earth 32,000 km; unimproved earth 1 1 ,000 km
Inland waterways: 980 km navigable rivers,
canals, and numerous coastal lagoons
Ports: Abidjan, San-Pedro
Merchant marine: 8 ships ( 1 ,000 GRT or
over) totaling 92,828 GRT/ 1 34,606 DWT. oil
tanker I , chemical tanker 1 , container 2, bulk 1 ,
roll-on/roll-off cargo 3
Airports:
total: 4 1
usable: 37
with permanent-surface runways: 1
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 3
with runways 1 ,220-2,439 m: 15
Telecommunications: well-developed by
African standards but operating well below
capacity; consists of open-wire lines and radio
relay microwave links; 87,700 telephones;
broadcast stations — 3 AM, 17 FM, 13 TV, I
Atlantic Ocean and I Indian Ocean
INTELSAT earth station; 2 coaxial submarine
cables
Defense Forces
Branches: Army, Navy, Air Force,
paramilitary Gendarmerie, Republican Guard,
Military Fite Group
Manpower availabUity; males age 15-49
3,224,673; fit for military service 1,674,127;
reach military age (18) annually 149,991 (19^
est.)
Defense expenditures: exchange rate
conversion — $200 million, 2.3% of GDP
(1988)
100 ton','dba94566c8ad57434d6571c20a5a0209544e0d57868e6d86594e6c24e92f00c4','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87930417706c062189be48d73c1fe6ba244ed9b1ef5ad1bcea85421c58ff28a3',1994,'CY','Cyprus','communications',297,'Railroads: 1 2,795 km total; Cuban National
Railways operates 5,053 km of 1.435-meter
gauge track, including 151.7 km electrified;
7,742 km of sugar plantation lines of 0.914-m
and 1 .435-m gauge
Highways:
totai: 26,477 km
paved: 14,477 km
unpaved: gravel or earth 12,000 km (1989)
Inland waterways: 240 km
Ports: Cienfuegos, La Habana, Mariel,
Matanzas. Santiago de Cuba; 7 secondary, 35
minor
Merchant mariiK: 64 ships (1,000 CRT or
over) totaling 444,038 GRT/627,741 DWT.
cargo 36, refrigerated cargo 10, passenger
cargo I. oil tanker 10, chemical tanker I,
liquefied gas 4, bulk 2
note: Cuba beneficially owns an additional 34
ships (1,000 GRT and over) totaling 529,090
under the registry of Panama, Cyprus,
and Malta
Airports:
total: 187
usable: 167
with permanent-surface runways: 73
with runways over 3,659 m: 3
with runways 2,440-3,659 m: 12
with runways 1,220-2,439 m: 19
Telecommunications: among the world''s
least developed telephone systems; 229,000
telephones; telephone density — 20.7 per 1 ,000
persons; broadcast stations — 150 AM, 5 f^,
58 TV; 1.530,000 TVs; 2,140,000 radios; I
Atlantic Ocean INTELSAT earth station
DefcnM Forces
Branches: Revolutionary Armed Forces
(FAR) — including ground forces.
Revolutionary Navy (MGR), Air and Air
Defense Force (DAAFAR), Territorial Militia
Troops (MTT), Youth Labor Army (EJT), and
Interior Ministry Border Guard Troops
Manpower availability: males age 15-49
3,064,898; females age 1 5-49 3,088,8 1 0; males
fit for military service 1,907.396; females fit
for military service 1 ,927,306; males reach
military age ( 1 7) annually 8 1 .536 ( 1 994 est.);
females reach military age ( 1 7) annually
78,612 (1994 est.)
Defense expenditures: exchange rate
conversion — approx. $600 million, 4% of GSP
(gross social product) in 1993 was for defense
Note: Moscow, for decades the key military
supporter and supplier of Cuba, cut off military
aid by 1993
Med/ternneun See
Highways:
total: 10.780 km
paved: 5,170 km
unpaved: gravel, crushed stone, earth 5,6 10 km
Ports: Famagusta, Kyrenia. Lamaca,
Limassol, Paphos
Merchant marine; 1 ,399 ships ( 1 .000 CRT
or over) totaling 22.743.484 GRT/39.874,985
DWT. short-sea passenger 1 2, passenger-cargo
2, cargo 496, refrigerated cargo 67, roll-on/
roll-off cargo 24, container 82, multifunction
large load carrier 4, oil tanker 1 22, specialized
tanker 5, liquefied gas 3, chemical tanker 27.
combination ore/oil 32, bulk 469, vehicle
carrier 5, combination bulk 48, railcar carrier I ,
passenger 4
note: a flag of convenience registry; Cuba
owns 26 of these ships, Russia owns 6 1 , Latvia
owns 7, Croatia owns 2, and Romania owns 4
Airports:
total: 14
usable: 14
with permanent-surface runways: 1 1
with runways over 3,659 m: 0
with runways 2,440-X6S9 m: 7
with runways 1,220-2,439 m; 2
Teiccommunicatioiis: excellent in both the
area controlled by the Cypriot Government
(Greek area), and in the Turkish-Cypriot
administered area; 210,000 telephones; largely
open-wire and microwave radio relay;
broadcast stations — 1 1 AM, 8 FM. I (34
repeaters) TV in Greek sector and 2 AM, 6 FM
and I TV in Turkish sector; international
service by tropospheric scatter, 3 submarine
cables, and satellite earth stations — 1 Atlantic
Ocean INTELSAT, I Indian Ocean
INTELSAT and EUTELSAT earth stations
Defense Forces
Branches:
Greek area: Greek Cypriot National Guard
(GCNG; including air and naval elements),
Greek Cypriot Police
Turkish area: Turkish Cypriot Security Force
Manpower avnilability: males age 15-49
1 86.807: fit for military service 1 28.444: reach
military age (18) annually 5,233 (1994 est.)
Defense expenditures: exchange rate
conversion — $407 million. 6.5% of GDP
(1993)
105
Czech Republic
IMlw','fea73f888862ec565645bb4cfc7c24e4bf8dc94c1a4c0bd6da88e1e86ad85122','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79121ae33e9b982988c98c252d9cab504424557c46a348dee8e254065b375fe6',1994,'SE','Sweden','communications',310,'Railroads: 2.770 km; Danish State Railways
(DSB) operate 2, 1 20 km ( 1 .999 km rail line
and 121 km rail ferry services); 188 km
electrified, 730 km double tracked; 650 km of
standard-gauge lines are privately owned and
operated
Highways;
total; 66,482 km
paved; concrete, asphalt, stone block 64,551
km
unpaved: gravel, crushed stone, improved
earth 1.931 km
Inland waterways: 417 km
Pipelines: crude oil 1 10 km; petroleum
pr^ucts 578 km; natural gas 700 km
Ports: Alborg, Arhus, Copenhagen, Esbjerg.
Fredericia; numerous secondary and minor
ports
Merchant marine: 347 ships ( 1 .000 GRT or
over) totaling 4,974.494 GRT/6,820,067
DWT. short-sea passenger 12, cargo 1 10,
refrigerated cargo 21. container 51. roll-on/
roll-off cargo 39, railcar carrier I . oil tanker 33,
chemical tanker 24. liquefied gas 36, livestock
carrier 4. bulk 1 5. combination bulk I
note: Denmark has created its own internal
register, called the Danish International Ship
register (DIS); DIS ships do not have to meet
Danish manning regulations, and they amount
to a flag of convenience within the Danish
register: by the end of 1 990, 308 of the Danish-
Hag ships belonged to the DIS
Airports:
total; 118
usable; 109
H’ith permanent-surface runways; 28
with ru.''iways over 3,659 m: 0
with runways 2.440-3,659 m; 9
with runways 1.220-2.4,19 m; 7
Telecommunications: excellent telephone,
telegraph, and broadcast services; 4,509,0(X)
telephones: buried and submarine cables and
microwave radio relay support trunk network;
broadcast stations — 3 AM. 2 FM, 50 TV: 19
submarine coaxial cables: 7 earth stations
operating in INTELSAT, EUTELSAT, and
INMARSAT
Defense Forces
Branches: Royal Danish Army. Royal Danish
Navy. Royal Danish Air Force, Home Guard
Manpower availability; males age 15-49
1,360,050; fit for military service 1,168,940;
reach military age (20) annually 36,800 (1994
e.st.)
Defense expenditures: exchange rate
conversion — $2.8 billion, 2% of GDP (1992)
109
I.ocation: rUirdic State. Northern Europe,
bordering the Baltic Sea. between Noiway and','652ad9ff4fa588c611f0fcb5444163a48d72871f9126406e88a8d13e8a60adff','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b96b02b6597365657790a813f5463b47c23dc530fda87fc004c5f81de2c2169f',1994,'TT','Trinidad and Tobago','communications',318,'Raiiroads: the Ethiopian-DJibouti railroad
extends for 97 km thrwgh Djibouti
Highways:
total: 2,900 km
paved: 280 km
unpaved: improved, unimproved earth 2,620
km (1982)
Ports: Djibouti
Merchant marine: 1 cargo ship ( 1 ,000 GRT
or over) totaling 1,369 GRT/3.030 DWT
Airports:
total: 13
usable: 1 1
with permanent-surface runways: 2
with runways over 3,659 tn: 0
with runways 2,440-3,659 m; 2
total area: 750 sq km
land area: 750 sq km
comparative area: slightly more than four
times the size of Washington, DC
Land boundaries: 0 km
Coastline: 148 km
Maritime claims:
contiguous zone: 24 nm
exclusive economic zone: 2(X) nm
territorial sea: 1 2 nm
International disputes: none
Climate: tropical; moderated by northeast
trade winds; heavy rainfall
Terrain: rugged mountains of volcanic origin
Natural resources: timber
Land use:
arable land: 9%
permanent crops: 13%
meadows and pastures: 3%
forest and woodland: 41%
other; 34%
Irrigated land; NAsqkm','1bd38aaf300d51cd74958d16e4e7b8fe0cbc8ce81f936977f4bdd1f24767dd91','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ada1b77a08057b9915e5fbfaf92d8d95db88ad020a80145eb1ed6b251261a25',1994,'DM','Dominica','communications',323,'Highways:
total: 750 km
paved: 370 kn)
tmpaved: gravel or earth 380 km
Ports: Roseau, Portsmouth
Airports:
total: 2
usable: 2
with pel manent-sutf ace runways: 2
with runways over J, 659 m: 0
with runways 2.440-3.659 m: 0
with runways 1 ,220-2,439 m: 1
Telecommunications; 4,600 telephones in
fully automatic network; VHF and UHF link to
Saint Lucia; new SHF links to Martinique and
Guadeloupe; broadcast stations — 3 AM, 2 FM,
I cable TV
Defense Forces
Branches: Commonwealth of Dominica
Police Force
Defense expenditures: exchange rate
conversion — SNA. N.A% of GDP
!I2','a62d70cb290b3d7f4812e694b79e75579334a7e42fa780839675e8300748f084','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1608bcad5a34d19f6f1ac5e2f1a82fab7e2b5460149534f4a1a4a50d5fbda1d9',1994,'DO','Dominican Republic','communications',328,'Railroads: 1,655 km total in numerous
segments; 4 different gauges from 0.558 m to
1 .435 m
Highways:
total: 12,000 km
paved: 5,800 km
unpaved: gravel or improved earth 5,600 km;
unimproved earth 600 km
Pipelines: crude oil 96 km; petroleum
products 8 km
Ports; Santo Domingo, Haina, San Pedro de
Macoris, Puerto Plata
Merchant marine: I cargo ship ( 1 .000 CRT
or over) totaling 1,587 GRT/ 1, 165 DWT
Airports:
total: 36
usable: 31
with permanent-surface runways: 12
with runways over 3,659 m: 0
with runways 2,440-3,659 m; 4
with runways 1,220-2,439 m: 8
Telecommunications: relatively efficient
domestic system based on islandwide
microwave relay network; 190,000 telephones;
broadcast stations — 120 AM, no FM, 1 8 TV, 6
shortwave; I coaxial submarine cable; I
Atlantic Ocean INTELSAT earth station
Defense Forces
Branches: Army, Navy, Air Force, National
Police
Manpower availability: males age 15-49
2.1 14,606; fit for military service 1,333,049;
reach military age (18) annually 81,919 (1994
est.)
Defense expenditures: exchange rate
conversion — $1 10 million, 0.7% of GDP
(1993 est.)
114','9c3db8dee91eb484d560e531585f034bcda4014fa721db63f99aa9a74c604d15','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de2f5cd71e4f42119420baf4fdba46b698194b9c3d180103c99b3efb756852e5',1994,'EC','Ecuador','communications',334,'Railroads: 965 km total; all 1. 067-meter-
gauge single track
Highways:
total: 28.(KX) km
paved: 3,600 km
unpaved: gravel or improved earth 17.400 km;
unimproved earth 7,000 km
Inland waterways: 1 ,500 km
Pipelines: crude oil 800 km: petroleum
products 1 ,358 km
Ports: Guayaquil, Manta, Puerto Bolivar,
Esmeraldas
Merchant marine: 40 ships (1.000 GRT or
over) totaling 263,752 GRT/.378,675 DWT.
passenger 3. cargo 3, refrigerated cargo 15,
container 2, roll-on/roll-off cargo 1. oil tanker
14, liquefied gas I, bulk I
Airports:
total: 2 1 1
usable: 208
with permanent-surface runways: 56
with runway over 3,659 m: 1
with runways 2,440-3,659 in: 7
with runways 1,220-2,439 m: 2 1
Telecommunications: domestic facilities
generally adequate; 3I8,0(X) telephones;
telephone density — 30 per 1,000 persons;
broadcast stations — 272 AM, no FM, 33 TV,
39 shortwave; 1 Atlantic Ocean INTELSAT
earth station
Defense Forces
Branches: Army (Ejercito Ecuatoriano),
Navy (Armada Ecuatoriana), Air Force
(Fuerza Aerea Ecuato''i .na), National Police
Manpower availabitity; males age 15-49
2,734.988; fit for military service 1,850,989;
reach military age (20) annually 1 1 1 .707 ( 1 994
est.)
Defense expenditures: exchange rate
conversion — $NA, NA% of GDP
116
Railroads: 1,801 km total; 1,501 km
.435-meter gauge, 300 km 0.914-meter gauge
Highways:
total; 69,942 km
paved: 7,459 km
unpaved; improved earth 13,538 km:
unimproved earth 48,945 km
Inland waterways: 8,600 km of navigable
tributaries of Amazon system and 208 km Lago
Titicaca
Pipelines: crude oil 8(X) km, natural gas and
natural gas liquids 64 km
Ports: Callao, Ilo, Iquitos, Matarani, Talara
Merchant marine: 17 ships (1,000 GRT or
over) totaling 142,425 GRT/229.746 DWT,
cargo 10, refrigerated cargo I. roll-on/roll-off
cargo I , oil tanker 2, bulk 3
note; in addition, 6 naval tankers and 1 naval
cargo are sometimes used commercially
Airports;
total; 252
usable; 222
with peimanent''surface runways; 37
with runways over3,6J9 m; 2
with runways 2.440-3,659 m; 24
with runways 1 .220-2,439 m; 54
Telecommunications; fairly adequate for
most requirements; nationwide microwave
system; 544,000 telephones; broadcast
stations — 273 AM, no FM. 140 TV, 144
.•hortwave; satellite earth stations — 2 Atlantic
Ocean INTELSAT, 1 2 domestic
Defense Forces
Branches: Army (Ejercito Peruano), Navy
(Marinade Guerra del Peru), Air Force (Fuerza
Aerea del Peru). National Police
Manpower availability: males age 15-49
6,199,785; fit for military service 4,188,706:
reach military age (20) annually 246,427 ( 1 994
est.)
Defense expendlturMi exchange rate
conversion — $500 million, about 2% of ODP
(1991)
314','cc777c571da5bdeaf88dd45d919504cbae051a777f3fc4fd7f3111ee18b96416','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d91d45a0da1bec9e6e634502eda46704aca6da2ac40dea6c6ef8708423da882a',1994,'EG','Egypt','communications',335,'Mediterranaan 9onkm
foundiry r«pr«iant>tloA U
not fitetiMriiy tuthoritatN*.
Railroads: 5,1 10 km total; 4,763 km 1.435-
meter standard gauge, 347 km 0.750-meter
gauge; 951 km double track; 25 km electrified
Highways:
total: 45,500 km
paved: 18,3(X)km
unpaved: gravel 12,503 km; earth 14,697 km
Inland waterways: 3,500 km (including the
Nile, Lake Nasser, Alexandria-Cairo
Waterway, and numerous smaller canals in the
delta); Suez Canal, 193.5 km long (including
approaches), used by oceangoing vessels
drawing up to 16. 1 meters of water
Pipelines: crude oil 1. 1 71 km; petroleum
products 596 km; natural gas 460 km
Ports: Alexandria, Port Said, Suez, Bur
Safajah, Damietta
Merchant marine: 1 7 1 ships ( 1 ,0(X) GRT or
over) totaling 1 ,08.208 GRT/1 .6 1 7,890 DWT,
passenger 27, short-sea passenger 7. cargo 88,
118','3cffd025c3ee4878f9fa5b556f3f35ac7738512a922a52166cf670085d5d9c1f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3defa9c8f5392c39dbed34234278ec069f94649f8e26f130a4f924895eda5db7',1994,'SV','El Salvador','communications',341,'refrigerated cargo 3, roll-on/roll-off cargo 15,
oil tanker 14, bulk 16, container I
Airports:
total; 92
usable; 82
with permanent-surface runways; 66
with runways over 3,659 m; 2
with runways 2,440-3,659 m; 45
with runways 1,220-2,439 m; 23
Telecommunications: large system by Third
World standards but inadequate for present
requirements and undergoing extensive
upgrading; 600,000 telephones (est.) — 1 1
telephones per 1 ,000 persons; principal centers
at Alexandria. Cairo, A1 Mansurah, Ismailia
Suez, and Tanta are connected by coaxial cable
and microwave radio relay; international traffic
is carried by satellite — one earth station for
each of Atlantic Ocean INTELSAT. Indian
Ocean INTELSAT, ARABSAT and
INMARSAT; by 5 coaxial submarine cables,
microwave troposcatter (to Sudan), and
microwave radio relay (to Libya, Israel, and
Jordan); broadcast stations — 39 AM. 6 FM,
and 41 TV
''ense Forces
Branches: Army, Navy, Air Force, Air
Defense Command
Manpower availability: males age 15-49
15,3.35.889; fit for military service 9,961,128;
reach military age (20) annually 625,748 (1994
est.)
Defense expenditures: exchange rate
conversion — $2, 1 5 billion, 6% of GDP (FY92/
93)
Boundary rapratentatten it — zaioi.
not nacaaurlly aulhorilaiiva','868d2b16a0a3eeb3e28f737345e148ea75d9adfb799021f2259e2465f8fbd77b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0973adaddaa8e3daa5fbb42773e09b86b9e321844eb56a4e76d2d933c81f4227',1994,'DE','Germany','communications',348,'Railroads; 602 km 0.9 14-meter gauge, single
track; some sections abandoned, unusable, or
operating at reduced capacity
Highways:
total: 10.000 km
paved: 1 ,500 km
unpaved: gravel 4,1(X) km; improved,
unimproved earth 4.400 km
Inland waterways: Rio Lempa partially
navigable
Ports: Acajutla. Cutuco
Airports:
total: 107
usable: 76
with permanent-surface runways: 5
120
Railroads:
western: 31,443 km total; 27,421 km
government owned, 1 .435-meter standard
gauge (12,491 km double track, 1 1,501 km
electrified); 4,022 km nongovernment owned,
including 3,598 km 1 .435-meter standard
gauge (214 km electrified) and 424 km I .(KX)-
meter gauge ( 1 86 km electrified)
eastern: 14,025 km total; 13,750 km 1.435-
meter standard gauge, 2''’5 km 1 .000-meter or
other narrow gauge; 3,830 (est.) km 1.435-
meter standard gauge double-track; 3,475 km
overhead electrified (1988)
Highways;
total: 625,600 km (1991 est.); western —
501,(KX) km (1990 est.); eastern — 124,6(X) km
(1988 est.)
paved: 543,200 km, including 10,814 km of
expressways; western — 495,9(X) km, including
8,959 km of expressways; eastern — 47,300
km, including 1,855 km of expressways
unpaved: 82,400 km; western — 5,000 km
earth; eastern — 77,400 km gravel and earth
Inland waterways:
western: 5,222 km, of which almost 70% are
usable by craft of 1,000-mctric-ton capacity or
larger; major rivers include the Rhine and Elbe;
Kiel Canal is an important connection between
the Baltic Sea and North Sea
eastern: 2,319 km (1988)
Pipelines: crude oil 3,644 km; petroleum
piquets 3,946 km; natural gas 97,564 km
(1988)
Ports: coastal — Bremerhaven, Brunsbuttel,
Cuxhaven, Emden, Bremen, Hamburg, Kiel,
Lubeck, Wilhelmshaven, Rostock, Wismar,
Stralsund, Sassnitz; inland — 31 major on
Rhine and Elbe rivers
Merchant marine; 485 ships ( 1 ,000 GRT or
over) totaling 4,541,441 GRT/5,835,51 1
DWT, short-sea passenger 5, passenger 3,
cargo 241, refrigerated cargo 7, container 132,
roll-on/roll-off cargo 20, railcar carrier 5, barge
carrier 7, oil tanker 7, chemical tanker 20,
liquefied gas tanker 16, combination bulk 6,
bulk 11, combination ore/oii 5
nore. the German register includes ships of the
former East and West Germany
Airports:
total: 590
usable: 583
with permanent-surface runways: 308
with runways over 3,659 m: 5
with runways 2,440-3,659 m: 85
with runways 1,220-2,439 m: 97
Telecommunications;
western: highly developed, modem
telecommunication service to all parts of the
country; fully adequate in ail respects;
40,300,0(X) telephones; intensively developed,
highly redundant cable and microwave radio
relay networks, all completely automatic;
broadcast stations — 80 AM, 470 FM, 225
(6,000 repeaters) TV; 6 submarine coaxial
cables; satellite earth stations — 12 Atlantic
Ocean INTELSAT antennas, 2 Indian Ocean
INTELSAT antennas, EUTELSAT, and
domestic systems; 2 HF radiocommunication
centers; tropospheric links
eastern: badly needs modernization; 3,970,000
telephones; broadcast stations — 23 AM, 17
FM, 21 TV (15 Soviet TV repeaters);
6, 18 1,860 TVs; 6,700.000 radios; 1 satellite
earth station operating in INTELSAT and
Intersputnik systems
Defense Forces
Branches: Army. Navy, Air Force
Manpower availability: males age 1 5-49
20,253,482; fit for military service 1 7,506,468;
reach military age ( 1 8) annually 4 1 8, 1 24 ( 1994
est.)
Defense expenditures: exchange rate
conversion — $42.4 billion, 2.2% of GDP
(1992)
150','b7f736f0877a47156b37a491f583df17edc3513fef36aa344610fb1483b225af','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d82907000783937cdca61f543fed771125bd838f30aab720a6e32264d1322eac',1994,'GQ','Equatorial Guinea','communications',349,'with runways over 3,659 m: 0
with runways 2,440-3,659 m: 1
with runways 1,220-2,439 m: 6
Telecommunications: nationwi(!e tnink
microwave radio relay system: connection into
Central American Microwave System; 1 16,000
telephones (21 telephones per I, OCX) persons);
broadcast stations — 77 AM, no FM, 5 TV, 2
shortwave; I Atlantic Ocean INTELSAT earth
station
Defense Forces
Branches; Army, Navy, Air Force
Manpower availability: males age IS-49
1 ,35 1 .641 ; fit for military service 866,010;
reach military age (18) annually 74,181 (1994
est.)
Defense expenditures: exchange rate
conversion — $104 million, 1.1^?- of GDP
(1994 est.)
Highways:
total: 2.760 km (2.460 km on Rio Muni and
300 km on Bioko)
paved: NA
iiniMved: NA
Ports: Malabo. Bata
Merchant marine: 2 ships ( 1 ,0(X) CRT or
over) totaling 6,4 1 2 GRT/6,699 DWT, cargo I ,
passenger-cargo I
Airports:
total: 3
usable: 3
with permanent-suifave riom-HV.''; 2
with runways over ,J,6.59 ni: 0
with runways 2,d40-.t,659 m: I
with runways 1 ,220-2.4.19 in: I
Telecommunications: poor system with
adequate government services; international
communications from Bata and Malabo to
African and European countries; 2,(XX)
telephones; broadcast stations — 2 AM. no FM.
I TV; I Indian Ocean INTELSAT earth station
Defense Forces
Branches: Army. Navy, Air Force. National
Guard. National Police
Manpower availability: males age 15-49
86,957; fit for military service 44,174
Defense expenditures: exchange rale
conversion — SNA, NA9(- of GDP
122','f5ca7149e2ebd52d102fdcedce1b27222384ee28a3c7202b4dcb7e2661369f9b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('47a1a24b6bbb543c4ea9f282d268b59d348b61543e93d2c24f09a1168727687c',1994,'EE','Estonia','communications',360,'Railroads: 307 km total: 307 km 1 ,000-meter
gauge: 307 km 0.950-meter gauge
(nonoperational) linking Ak''oidat and Asmara
(formerly Asmera) with the pon of Massawa
(formerly Mits''iwa; 1993 est.)
Highways;
total; 3,845 km
paved; 807 km
unpaved; gravel 840 km: improved earth 402
km; unimproved earth 1.796 km
Ports; Assab (formerly A.seb). Mas.sawa
(formerly Mits''iwa)
Merchant marine: none
Airports:
total; 5
usable; 5
with permanent-surface runways; 2
with runways over 3,659 rn; 0
with runways 2.440-3.659 m; 2
with runways 1 .220-2.439 m; 2
Telecommunications: NA
Defense Forces
Branches: Eritrean People''s Liberation Front
(EPLF)
Defense expenditures: exchange rate
conversion — SNA, NA''3- of GDP
IWbn
QutfofFintsrxt','6bb8361169a3c6c28cee7cec1e11c1dbace9e72f5b329b1e0e291c8a737a5568','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('921d3e8e8ce4501204b0baf8116e6e5a47abf64b96caed131c3291c23d7437e7',1994,'JP','Japan','communications',369,'Railroads: 781 km total; 781 km 1.000-meter
gauge; 307 km 0.950-meter gauge linking
Addis Ababa (Ethiopia) to Djibouti: control of
railroad is shared between Djibouti and
Highways:
total : NA
paved: NA
utifKived: NA
Ports: none: offshore anchorage only
Airports:
total: I
tixable: I
with permanent-surface runways: 0
with runways over J,659 m: 0
with runways 2,440-3,6!iV m: 0
with runways 1,220-2.4314 m: I
Telecommunications; radio and
meteorological station
Defense Forces
Note: defen.se is the responsibility of Norway
FthHppiM
S—
Imcatkm: Eastern Asia, off the southeast
coast of Russia and east of the Korean
peninsula
Map references: Asia. Standard Time Zones
of the World
Area:
total area: .^77.8.f5 sq km
land area: .^74.74 1 sq km
comparative area: slightly smaller than
California
note: includes Bonin Islands
(Ogasawura-gunto). Daiio-shoio.
Minatni-jiniu. Okinutori-.shima. Ryukyu
Islands (Nansci-shoto). and Volcano Islands
(Kaaan-retto)
Land boundaries: 0 km
Coastline: 29.751 km
Maritime claims:
exclusive fishinK zone: 200 nm
territorial sea: 1 2 nni; .1 nm in the
international straits — La Petouse or .Soya.
Tsugaru. Osumi. and Eastern and Western
Channels of the Korea or Tsushima Strait
International disputes: islands of Etorufu.
Kunashiri. Shikotau. and (he Habomai gmup
occupied by the Soviet Union in 1945. now
administered by Russia, claimed by Japan:
Liancourt Rocks disputed with South Korea:
Senkaku-shoto (Senkaku Islands) claimed by
China and Taiwan
Climate; varies from tropical in .south to cwil
temperate in north
Terrain: mostly rugged and mountainous
Natural resources: negligible mineral
resources, fish
Land use:
arable land: I.^T
permanent crops: I9f
meadows and inistures: \\%
forest and woodland: 679f
other: I S'')}:
Irrigated land: 28.680 sq km ( 1 989)
Ports: none; offshore anchorage only — one
boat landing area in the middle of the west
coast and another near the southwest comer of
the island
Note; there is a day beacon near the middle of
the west coast
Defense Forces
Note: defense is the responsibility of the US:
visited annually by the US Ciwst Guard
Climate: temperate, with rainfall heavier in
summer than winter
Terrain: mostly hills and mountains; wide
coastal plains in west and south
Natural resources; coal, tungsten, graphite,
molybdenum, lead, hydroptrwer
Land use:
aruhic land: 2 1 "/r
iwrimmcnl cni/is:
mcadim s and iHisiiircs: I
forest and woodland: 67*^
other; I ()''><■
Irrigated land: 1 .1,5.10 sq km ( 1 989 )
Railroads; 3,091 km total (1991); 3.044 km
1.435 meter standard gauge. 47 km 0.6 IO¬
meter narrow gauge, 847 km double track; 525
km electrified, government owned
Highways:
total: 6.3.201 km
(Hived: expressways 1 .55 1 km
unpaved: NA
undifferentiated; national highway 1 2, 1 90 km;
provincial, local roads 49.460 km ( 1991 )
Inland waterways; 1.609 km: use restricted
to small native craft
Pipelines; petroleum products 455 km
Ports: Pu.san, Inch''on, Kunsan. Mokp''o,
Ulsan
Merchant marine: 417 ships (1,000 GRT or
over) totaling 6.425,920 CRT/ 1 0,535.850
DWT. short-sea passenger I. cargo 132,
container 60. refrigerated cargo 1 1 , vehicle
carrier 9, oil tanker 47. chemical tanker 16.
liquefied gas 1.3, combination ore/oil 2, hulk
1 23. combination bulk 2. multifunction large-
load carrier 1
Airports:
total: 104
usable: 95
with permanent-surface runways: 6 1
with runways over .3,659 m: 0
with runways 2,440-3.659 m; 23
with runways 1,220-2.439 in: 18
Telecommunications: excellent domestic
and international services; 1.3.276.449
telephone subscribers; broadcast stations — 79
AM, 46 FM, 256 TV (57 of I kW or greater);
satellite earth stations — 2 Pacific Ocean
INTELSAT and I Indian Ocean INTELSAT
219
Korea, South {continued)
Railroads: 3.288 km total; 3,140 km 1 .067-
meter gauge; 148 km 0,762-meter nanow
gauge; Malawi-Nacala, Malawi-Beira, and
Zimbabwe-Muputo lines are subject to closure
because of insurgency
Highways:
toiai: 26,498 km
paved: 4,593 km
unpaved; gravel, crushed stone, stabilized
earth 829 km; unimproved earth 2 1 ,076 km
Inland waterways: about 3,750 km of
navigable routes
Pipelines: crude oil (not operating) 306 km:
petroleum products 289 km
Ports: Maputo, Beira, Nacala
Merchant marine: 4 cargo ships ( 1 ,000 GRT
or over) totaling 5,686 GRT/9,742 DWT
Airports:
total: 194
usable; 134
with permanent-surface runways: 24
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 5
with runways 1,220-2,439 m; 28
Telecommunications: fair system of
troposcatter, open-wire lines, and radio relay;
broadcast station.s — 29 AM, 4 FM, 1 TV; earth
stations — 2 Atlantic Ocean INTELSAT and 3
domestic Indian Ocean INTELSAT
Defense Forces
Branches: Army, Naval Command, Air and
Air Defense Forces, Militia
note: as of early 1994, Mozambique was
demobilizing and reorganizing its defence
forces
Manpower availability: males age 15-49
3,890,532; fit for military service 2,233,824
Defense expenditures: exchange rate
conversion — $l 1 8 million, 8% of GDP ( 1993
est.)
Highways:
total: 4,885 km
paved: 460 km
unpaved: gravel, improved eanh 1,725 km;
unimproved earth 2,700 km
Inland waterways: Lac Kivu navigable by
shallow-draft barges and native craft
Airports:
total: 8
usable: 7
with permanent-surface runways: 3
with runways over J,6S9 m: 0
with runways 2,440-3,659 m: 1
with runways 1,220-2,439 m: 2
Telecommunications: telephone system does
not provide service to the general public but is
intended for business and government use; the
capital, Kigali, is connected to the centers of
the prefectures by microwave radio relay; the
remainder of the network depends on wire and
high frequency radio; international
connections employ microwave radio relay to
neighboring countries and satellite
communications to more distant countries;
satellite earth stations — I Indian Ocean
INTELSAT and 1 SYMPHONIE station in
Kigali (includes telex and telefax service);
broadcast stations — 1 AM, 1 FM, 1 TV
Defense Forces
Branches: Army (including Air Wing),
Gendarmerie
note: Rwanda plans to demobilize and
reorganize with RPF elements during 1994
Manpower availability: males age 15-49
1,733,246; fit for military service 883,291
Defense expenditures: exchange rate conver¬
sion — $37 million, 1.6% of GDP ( 1988 est.)
AJU3.
Highways:
total; NA (mainland 107 km. Ascension NA,
Tristan da Cunha NA)
paved: 169.7 km (mainland 87 km. Ascension
80 km, Tristan da Cunha 2.70 km)
unpaved; NA (mainland 20 km earth roads.
Ascension NA, Tristan da Cunha NA)
Ports: Jamestown (Saint Helena),
Georgetown (Ascension)
Airports:
total: 1
usable; I
with permanent-surface runways: I
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 1
with runways 1,220-2,439 m: 0
Telecommunications: 1 ,500 radio receivers;
broadcast stations — 1 AM, no FM, no TV; 550
telephones in automatic network; HF radio
links to Ascension, then into worldwide
submarine cable and satellite networks; major
coaxial submarine cable relay point between
South .Africa, Portugal, and UK at Ascension:
2 Atlantic Ocean INTELSAT earth stations
Defense Forces
Note; defense is the responsibility of the UK
S^int Kitts and Nevis
Geograph}’
Location: Caribbean, in the eastern Caribbean
Sea. about one-third of the way between Puerto
Rico and Trinidad and Tobago
Map references: Central America and the
Caribbean, Standard Time Zones of the World
Area:
lolcil area: 269 sq km
land area: 269 sq km
comparative area: slightly more than 1 .5 times
the size of Washington. DC
Land boundaries: 0 km
Coastline: 1 .15 km
Maritime claims:
conligtwus zone: 24 nm
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes: none
Climate: subtropical tempered by constant
sea breezes: little .seasonal temperature
variation; rainy season (May to November)
Terrain: volcanic with mountainous interiors
Natural resources: negligible
Land use:
arable land: 22%
permanent crops: {1%
meadows and pastures: 2%
forest and woodland: 17%
other: 4 1 %
Irrigated land: NA sq km','0ce457aad56d3ed75ad75368bf3802dc06bf92d0cc8a9ad4d59291f5b975f498','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20e5f8097bac5ffcd71bea05fbe32fd804b311eef1d4f11c928cedf11c477d90',1994,'DK','Denmark','communications',382,'Highways:
total; 200 km
paved: NA
unpaved: NA
Ports: Torshavn, Tvoroyri
Merchant marine: 7 ships ( 1 ,0(X} GRT or
over) totaling 19,943 GRT/18,399 DWT,
short-sea passenger I, cargo 5, roll-on/roll-off
cargo I
note; a subset of the Danish register
Airports;
total: 1
usable; 1
with permanent-surface runways; 1
with runways over 3,659 m: 0
with runways 2,440-3,659 m; 0
with runways 1,220-2,439 m; 1
Telecommunications: good international
communications; fair domestic facilities;
21.900 telephones; broadcast stations — I AM,
Location: Oceania, Melanesia, 2,500 km
north of New Zealand in the South Pacifle
Ocean
Map references: Oceania, Standard Time
Zones of the World
Area:
total area; 18,270 sq km
land area: 1 8,270 sq km
comparative area: slightly smaller than New','109bd9433471cbc8c17c01fd678aa8599f1f1eec5382031f1aaeb7e5b9accef7','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76e9bbab867a2e847f0522c842495400f6915e0222214f9bd71953a431cc5d1a',1994,'JE','Jersey','communications',383,'Land boundaries: 0 km
Coastline: 1,129 km
Maritime claims: measured from claimed
archipelagic baselines
continental shelf; 2Cl0-m depth or to depth of
exploitation; rectilinear shelf claim added
exclusive economic zone; 200 nm
territorial sea: 12 nm
International disputes: none
Clhnate: tropical marine; only slight seasonal
temperature variation
Terrain: mostly mountains of volcanic origin
Natural resources; timber, fish, gold, copper,
offshore oil potential
Land use:
arable land; 8%
permanent crops: 5%
meadows and pastures: 3%
forest and woodland; 65%
other; 19%
Irrigated land: 10 sq kin (1989 est.)
(British crown dependency)
lia _
Ingtish Channel
Highways:
lohil: NA
IHiVftI: NA
impavetl: NA
Airports;
total: I
usable: I
ii''i''Wi pemianent-sutfaee runways: I
with runways over 3.6.50 tn: 0
with runways 2A40-Xh5y in: I with TACAN
and beacon
with runways l.220-2.4J*i tn: 0
Telecommunications; excellent system
including 60-chunnel submarine cable.
AukxIin/SRT terminal, digital telephone
switch. Military Affiliated Radio System
(MARS station), commercial satellite
television system, and UHFA''HF air-ground
radio
Defense Forces
Note: defense is the responsibility of the US
Railroads: 1 .2(X> km, 1 .435 m gauge (1991)
Highways:
total; 1 4,553 km
IHived; 10,525 knt
unpuved: gravel 4,028 km
Inland waterways: NA
Pipelines; crude oil 290 km. natural gas 305
km
Ports: coastal — Koper
Merchant marine: 1 9 ships ( 1 ,000 ORT or
over) totaling .309,502 GRT/52 1.997 DWT
cciitrolled by Slovenian owners, bulk 13,
cargo 6
note; most under the flag of Saint Vincent ''"id
the Grenadines; no ships remain under the
Slovenian flag
Airports:
total; 14
usable: 13
with ftermanent suiface runways; 6
with runways over 3,659 m: 0
with runways 2,440-3,659 m; 2
with runways 1,220-2,439 m: 2
Telecommunications; I30,0(M) telephones;
broadcast stations — 6 AM. 5 FM, 7 TV;
370.000 radios; 330,000 TVs
Defense Forces
Branches: Slovene Defen.se Forces
Manpower availability: males age 15-49
5 1 3,885: fit for military service 4 1 1 ,6 1 9; reach
military age (19) ennually 15,157 (1994 est.)
Defense expenditures: 13.5 billion tolars,
4.5% of GDP (1993); note — conversion of the
military budget into US dollars using the
current exchange rate could produce
misleading results
.359
Railroads: 297 km (plus 7 1 km disused).
1.067-meter gauge, single track
Highways:
total: 2.853 km
/Hived: 510 km
unpttved: crushed stone, gravel, stabilized
earth 1,2.30 km; improved earth 1. 1 13 km
Airports:
total: 23
usable; 2 1
.377
Swaziland {continued}
with permanent-suiface nimvays: 1
with runwayj over J,6S9 m; 0
with runways 2,440-3.659 m; 1
with runways 1,220-2.439 m: 1
Telecommunicattons: system consists of
carrier-equipped open-wire lines and low-
capacity microwave links; 17,000 telephones;
broadcast stations — 7 AM. 6 FM, 10 TV; I
Atlantic Ocean INTELSAT earth station
Defense Forces
Branches; Umbutfo Swaziland Defense
Force, Royal Swaziland Police Force
Manpower availability: males age IS-49
204,608; fit for military service 1 1 8„^80
Defense expend''lures: exchange rate
conversion — $2.; million. NAC?- of GDP
(FY93/94)','c307385de03b8d3290a3c142932dded290c52c74ef1fd1490164e472ab5b00c3','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('358fdb5fe067e36445fe20b01faa49375a481617f478349b5bf1b2ab37883d1c',1994,'FI','Finland','communications',389,'Railroads: 644 km 0.6 1 0-meter narrow
gauge, belonging to the government-owned
Fiji Sugar Corporation
Highways:
total: 3.300 km
paved: 1 ,590 km
impaved: gravel, crushed stone, stabili/.ed
earth 1 .290 km: unimproved earth 420 km
(1984)
Inland waterways: 203 km; 1 22 km
navigable by motori?:ed cruft and 200-mctric-
ton barges
Ports: Labasa, Luutoku, Savusuvu. Suva
Merchant marine: 8 ships ( I ,(XX) GRT or
over) totaling 44,91 1 GRT/.54.490 DWT, roll-
on/roll- >ff cargo 2, container 2, oil tanker I,
chemical tanker 2, cargo I
Airports;
total: 25
usable: 22
with permunem-surface runways: 3
with runways over 3,659 in:
with runways 2,440-3.659 ri, l
with runways 1,220-2.439 m: 2
Telecommunications; modern UkuI.
interisland, and international (wire/radio
integrated) public and special-purpose
telephone, telegraph, and teleprinter facilities;
regional radio center; important COMPAC
cable link between US-Cunuda and
NZ-Australia; 53,228 telephones (71
telephones per I.IXH) persons); broadcast
stations — 7 AM. I FM.noTV; I Pacific Ocean
INTELSAT earth station
Defense Forces
Branches: Republic of Fiji Military Forces
(RFMF; including a naval division, police)
Manpower availability; males age 15-49
197.767; fit for military .service 109,026; reat''
military age (18) annually 8,154 (I99h est.
Defense expenditures; exchange rate
ctmversion — $22.4 million, about 29i- of GDP
(FY9I/92)
Map references; Arctic Region, Asia.
Europe. Standard Time Zones of the World
Area:
total area: 449.964 sq km
land area: 410.928 sq km
eomiHirative area: slightly smaller than
California
Land boundaries: tmal 2.205 km. Finland
586 km. Norway 1.619 km
Coasliine: .^.218 km
Maritime claims;
continental shelf: 2(XFm depth or to depth of
exploitation
exclusive fishinii ;(»««''.• 2tl0nni
territorial sea: 12 nm
International disputes: none
Climate: temperate in south w ith cold, cloudy
winters and ctxil, partly cloudy summers;
subarctic in north
Terrain; mostly Hat or gently mlling
low lands; mountains in west
Natural resources; zinc, iixm onr. lead.
copper, silver, timber, uranium, hydropower
potential
laind use:
arable land: 7*4
pennanent crops: 0*4
meadows and fHistures: 2*4
forest and woodland: 64*4
other: 27*4
Irrigated land; I.l20sq km(l989est.)
Railroads; 4.418 km total; 3,07.1 km are
government owned and I..145 km ore
nongovernment owned: the government
network atnsisis of 2.999 km 1 ,4.15-meler
standard gauge and 74 km l.(X)0-meter nam>w
gauge track; 1,432 km double track. 99%
electrified; the nongovernment network
consists of $ 1 0 km 1 .4.11-meier standard
gauge, and 835 km l.(KX)-meter gauge. 100%
electrified
Highways:
total: 71,106 km
paved: 71,106 km (including 1,502 km of
expressways)
Inland waterways: 65 km; Rhine (Basel to
Rheinfelden, Schaffhausen to Bodensee); 12
navigable lakes
Pipelines: crude oil .114 km, natural gas I, .506
km
Ports: Basel (river ptsrt)
Merchant marine: 23 ships ( 1 ,000 CRT or
over) totaling 337.455 GRT/.592.2I.1 DWT,
cargo 4. roll-on/roll-off cargo 2, chemical
tanker 5. specialized tanker I. bulk 10. oil
tanker I
Airports:
total: 70
usable: 69
with permanent-suiface runways: 42
with runways over 3,659 m: 3
with runways 2,440''3,659 ni: 4
with runways 1,220-2,439 ni: 18
Telecommunications: excellent domestic,
international, and broadcast sendees;
5,890,000 telephones; extensive cable and
microwave networks; broadcast station.s— 7
AM, 265 FM, 18 (1.322 repeaters) TV:
communications satellite earth station
operating in the INTELSAT (Atlantic Ocean
and Indian Ocean) system
Defense Forces
Branches: Army (Air Force is part of the
Army), Fix>ntier Guards, Fortification Guards
Manpower availability: males age 15-49
1.853.075; fit for military service 1.589.288;
reach military age (20) annually 43.005 ( 1994
est.)
Defense expenditures: c.\\chunge rate
conv ersion — $3.5 billion. 1 .7% of GDP ( 1993
e.st.)','eb974b21053bd31c7b3110512344605e1f8b194317427fff5cbdcc505cc6277d','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49a9503d2606f00c6107f8d379b48d050af228f75857926725e932d29f19d71a',1994,'FR','France','communications',395,'Railroads: 5,924 km total; Finnish State
Railways (VR) operate a total of 5,863 km
1,524-mm gauge, of which 480 km are
multiple track and 1,710 km are electrified
Highways;
total; 76,631 km (1991)
paved: bituminous concrete, bituminous
treated soil 46,745 km
unfmved: gravel 29,886 km
Inland waterways: 6.675 km total (Including
Saimaa Canal); 3,700 km suitable for steamers
Pipelines: natural gas 580 km
Ports; Helsinki. Oulu, Pori, Rauma, Turku
Merchant marine: 93 ships ( 1 .000 CRT or
over) totaling 1,040,905 GRT/1.143,276
DWT, passenger 3. short-sea passenger 9,
cargo 20, refrigerated cargo I, roll-on/roll-off
cargo 30, oil tanker 1 5, chemical tanker 5,
liquefied gas 3. bulk 7
Airports;
total: 160
usable: 157
with permanent-surface runways: 66
with runways over 3,659 m: 0
with runways 2,440-3,659 in: 26
with runways 1 .220-2,439 m: 20
Telecommunications: good service from
cable and microwave radio relay network;
3,140,000 telephones; broadcast stations — 6
AM, 105 FM, 235 TV; 1 submarine cable;
INTELSAT satellite transmission service via
Swedish earth station and a receive-only
INTELSAT earth station near Helsinki
Defense Forces
Branches: Army. Navy, Air Force, Frontier
Guard (including Coast Guard)
Manpower availability: males age 15-49
I.. 323,322; fit for military service l,089.3(X);
reach military age (17) annually .33,594 (1994
est.)
Defense expenditures; exchange rate
conversion — $1.93 billion, about 27p of GDP
(1992)
infk''ih Ctffwf
BMVOf
SQQJffTi
Corsica^
Saa
Highways:
total; NA
paved: NA
unpaved: NA
Ports: none; offshore anchorage only
Merchant marine; 21 ships ( l,(X)0 GRT or
over) totaling 44 1 ,962 GRT/8 1 3,779 DWT,
cargo 2, refrigerated cargo 4, roll-on/roll-off
cargo 4. oil tanker 4, bulk 3, multifunction
large loud carrier I, chemical tanker I , liquified
gas 2
140
Railroads: Luxembourg National Railways
(CFL) operates 272 km 1,435-mm standard
gauge; 178 km double track; 1 97 km electrified
Highways:
total: 5,108 km
paved: 4,995 km (including 80 km of limited
access divided highway)
unpaved: gravel 57 km; earth 56 km
Inland waterways: 37 km; Moselle River
Pipelines: petroleum products 48 km
Ports: Mertert (river port)
Merchant marine: 50 ships (1 ,(X)0 GRT or
over) totaling 1 ,477,998 GRT/2,424,594
DWT, cargo 2, container 4, roll-on/roll-off
cargo 4, oil tanker 5, chemical tanker 4,
combination ore/oil 2. liquefied gas 9,
passenger 2, bulk 8, combination bulk 6,
refrigerated cargo 4
Airports:
total: 2
usable: 2
with permanent-surface runways: 1
with runways over 3,659 m: 1
with runways 2,440-3,659 m: 0
with runways 1,220-2,439 m: 0
Telecommutiictttions: highly developed,
completely automated and efficient system,
mainly buried cables; 230,000 telephones;
broadcast stations — 2 AM, 3 FM, 3 TV; 3
channels leased on TAT''6 coaxial submarine
cable; I direct-broadcast satellite earth station;
nationwide mobile phone system
Defense Forces
Branches; Army, National Gendarmerie
Manpower availability: males age 15-49
103,872; fit for military service 86,026; reach
militaiy age (19) annually 2,235 (1994 est.)
Defense expenditures: exchange rate
conversion — $100 million, 1.2% of GDP
(1992)
Macau
(overseas territory of Portugal)
Map references: Africa, Europe, Standard
Time Zones of the World
Area:
total area: 504,750 sq km
land area: 499,400 sq km
comparative area: slightly more than twice the
size of Oregon
note: includes Balearic Islands. Canary
Islands, and five places of sovereignty (plazas
de soberania) on and off the coast of
Morocco — Ceuta. Mellila, Islas Chafarinas,
Penon de Alhucemas, and Penon de Velez de la
Gomera
Land boundaries; total 1 .903.2 km, Andorra
65 km, France 623 km. Gibraltar 1.2 km,
Portugal 1.2 14 km
Coastline: 4.964 km
Maritime claims;
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
International disputes: Gibraltar question
with UK; Spain controls five places of
sovereignly (plazas de soberania) on and off
the coast of Morocco — the coastal enclaves of
Ceuta and Melilla, which Morocco contests, as
well as the islands of Penon de Alhucemas.
Penon de Velez de la Gomera, and Islas
Chafarinas
Climate: temperate; clear, hot summers in
interior, more moderate and cloudy along
coast; cloudy, cold winters in interior, partly
cloudy and cool along coast
Terrain: large, flat to dissected plateau
surrounded by rugged hills; Pyrenees in north
Natural resources; coal, lignite, iron ore.
uranium, mercury, pyrites, fluorspar, gypsum,
zinc, lead, tungsten, copper, kaolin, potash,
hydropower
Land use:
arable land: 3 1 %
permanent crops: 10%
Railroads: 1 5,430 km total; Spanish National
Railways (RENFE) operates 12,691 km (all
1 ,668-mm gauge. 6, 1 84 km electrified, and
2,295 km double track): FEVE (government-
owned narrow-gauge railways) operates 1 .82 1
km (predominantly 1,000-mm gauge, 441 km
electrified); privately owned railways operate
918 km (predominantly 1,000-mm gauge, 512
km electrified, and ,56 km double track)
Highways:
tow/,- 318,022 km (1988)
paved: 178,092 km (including 2.142 km of
expressways)
unpaved; 139,930 km
Inland waterways: 1,045 km, but of minor
economic importance
Pipelines: crude oil 265 km. petroleum
prtxlucts 1.794 km. natural gas 1,666 km
Ports; Algeciras, Alicante, Almeria,
Barcelona, Bilbao. Cadiz. Cartagena, Castellon
de la Plana, Ceuta, El Ferrol del Caudillo.
Puerto de Gijon, Huelva, La Coruna, Las
Palmas (Canary Islands), Mahon, Malaga,
Melilla, Rota, Santa Cruz de Tenerife.
Sagunto, Tarragona. Valencia, Vigo, and 175
minor ports
Merchant marine; 1 92 ships ( I .(XX) CRT or
over) totaling 1.328.7,30 GRT/2,2 1 3,671
DWT, passenger 2, short-sea passenger 6.
cargo 55, refrigerated cargo 12. container 1 1,
roll-on/roll-off cargo 33, vehicle carrier 1, oil
tanker 29. chemical tanker 14. liquefied gas 5,
specialized tanker 3. bulk 21
Airports:
total: 105
usahle: 99
with permanent-surface runways: 60
with runways over ,3,659 m: ''♦
with runways 2,440-3,659 m: 22
with runways 1,220-2,439 m: 26
Telecommunications: generally adequate,
modem facilities; 15,350,464 telephones;
broadcast stations — 190 AM, 406 (134
repeatets) FM, 100 ( 1 ,297 repeaters) TV; 22
coaxial submarine cables; 2 communications
satellite earth stations operating in INTELSAT
(Atlantic Ocean and Indian Ocean); MARECS,
INMARSAT, and EUTELSAT systems:
tropospheric links
Defense Forces
Branches: Army. Navy, Air Force, Marines,
Civil Guard, National Police, Coastal Civil
Guard
Manpower availability: males age 15-49
10,377,990; fit for military service 8,396,405;
reach military age (20) annually 337,764 ( 1994
est.)
Defense expenditures: exchange rate
conversion — $5,8 billion, 1 .26% of GDP
(1994)
Spratly Islands','6efc67f43bc78d4d6d191c889c34e9dc25e8668cd15b035db2a36b158685b3aa','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e38035c4b264e12b60eaf8405bd594c3d665304bd316ce665009605052dcceb0',1994,'GF','French Guiana','communications',401,'(overseas department of France)
net nasf eMniy auih«iitgit««.
Highways:
total: 680 km
paved: 510 km
unpaved: improved, unimproved earth 170 km
Inland waterways: 460 km. navigable by
small oceangoing vessels and river and coastal
steamers; 3,300 km navigable by native craft
Ports: Cayenne
Airports:
total: 10
usable: 10
with permanent-surface runways: 4
with runways over J,659 m: 0
with runways 2,440-3,659 m; I
with runways 1,220-2,439 m: I
Telecommunications: fair open-wire and
microwave radio relay system; 18,100
telephones; broadcast stations — 5 AM. 7 FM, 9
TV; I Atlantic Ocean INTELSAT earth station
Defense Forces
Branches: French Forces, Gendarmerie
Manpower availability; males age 15-49
40,5()6; fit for military service 26,394
Dcfmse expenditures: SNA. NA% of GDP
Note defense is the responsibility of France
1.38','58b38a6c62e958340c4d6e03a2b8453af423adbf39f4d4a168c6cf0d3b49d347','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8e9888d757ebff9a73082139d45111cfe8a6493b784543cabfee255c53a65e2',1994,'GA','Gabon','communications',411,'iwre: a captive subset of the Prench register
Telecommunications: NA
Defense Forces
Note: defense is the responsibility of France
Railroads; 649 km 1 .437-meter standard-
gauge single track (Transgabonese Railroad)
Highways:
total: 7,5(W km
paved: 560 km
unpaved: crushed stone 960 km; earth 5,980
km
Inland waterways: 1.600 km perennially
navigable
Pipelines: crude oil 270 km; petroleum
products 14 km
Ports: Owendo. Port-Gentil, Libreville
Merchant marine: 2 cargo ships ( 1 ,000 CRT
or over) totaling 1 8,562 GRT/25.330 DWT
Airports:
total: 70
usable: 59
with permanent-surface runways: 10
with runways over 3,659 m: 0
with runways 2,M0-3,659 m: 2
with runways 1 .220-2,439 m: 22
Telecommunications: adequate system of
cable, radio relay, tropospheric scatter links
and radiocommunication stations; 15,000
telephones; broadcast stations — 6 AM, 6 FM. 3
(5 repeaters) TV; satellite earth stations — 3
Atlantic Ocean INTELSAT and 1 2 domestic
satellite
Defense Forces
Branches: Army, Navy, Air Fo''ce,
Presidential Guard, National Gendarmerie,
National Police
Manpower availability: males age 1 5-49
270,501 ; fit for military .service 1 36,995; reach
military age (20) annually 10,107 (1994 est.)
Defense expenditures; exchange rate
conversion — $102 million, 3.2% of GDP
(1990 est.)
142
The Gambia
2fiJUIL.
Bdundaty raprcMniition i«
not roceiMnly authoriiattve.','38a62a9f9a7e9ae40af2b09e996085090e3d85e2c13fa8c292b0e7e38565053f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('262f3ea2a906e3115199243016d73b71c12e4f5289a810dcca0c386cc2301f2d',1994,'GM','Gambia','communications',419,'liberalized trade policy, has fostered a
respectable 4% rate of growth in recent years.
Re-export trade constitutes one-third of
economic activity; however, border closures
associated with Senegal’s monetary crisis in
late 1993 led to a 50% decline in re-export
trade, reducing government revenues in turn.
Devaluation of the CFA franc in January 1994
has made Senegalese goods more competitive,
and is likely to prompt a relaxation of
Senegalese controls, paving the way for a
comeback in re-exports.
National product: GDP— purchasing power
equivalent — $740 million (1993 est.)
National product real growth rate; 4.3%
(FY92 est)
National product per capita: $800(1993
est.)
Inflation rate (consumer prices): 5% (FY
92 est.)
Unemployment rate: NA%
Budget:
revenues; $94 million
expenditures; $80 million, including capital
expenditures of $25 million (FY9I est.)
Exports: $164 million (f.o.b., FY92 est.)
commodities; peanuts and peanut products,
fish, cotton lint, palm kernels
partners; Japan 60%, Europe 29%, Africa 5%,
US 1%, other 5% (1989)
Imports: $214 million (f.o.b., FY92 est.)
commodities; foodstuffs, manufactures, raw
materials, fuel, machinery and transport
equipment
partners; Europe 57%, Asia 25%. USSR and
Eastern Europe 9%, US 6%, other 3% ( 1989)
External debt: $336 million (December 1 990
est.)
Industrial production: growth rate 6.7%;
accounts for 5.8% of GDP (FY90)
Electricity:
capacity; 30,000 kW
production; 65 million kWh
consumption per capita; 75 kWh (1991)
Industries: peanut processing, tourism,
beverages, agricultural machinery assembly,
woodworking, metalworking, clothing
Agriculture: accounts for 30% of GDP and
employs about 75% of the population; imports
one-third of food requirements; major export
crop is peanuts; other principal crops — millet,
sorghum, rice, com, cassava, palm kernels;
livestock — cattle, sheep, goats; forestry and
fishing resources not fully exploited
Economic aid:
recipient; US commitments, including Ex-Im
(FY70-89). $93 million; Western (non-US)
countries, ODA and OOF bilateral
commitments ( 1 970-89), $535 million;
Communist countries (1970-89), $39 million
Currency: I dalasi (D)= 100 butut
Exchange rates: dalasi (D) per US$1 — 9.440
(November 1 993). 8.888 ( 1 992), 8.803 (1991),
7.883 (1990), 7.5846 (1989), 6.7086 (1 988j
Fiscal year: I July — 30 June
Highways;
total; 3,083 km
paved; 431 km
unpaved; gravel, cmshed stone 501 km;
unimproved earth 2,151 km
Inland waterways: 400 km
Ports: Banjul
Merchant marine: I bulk ship ( 1 ,000 GRT or
over) touling 1 1,194 GRT/19,394 DWT
Airports:
total; 1
usable; 1
with permanent-surface runways; 1
with runways over 3,659 m; 0
with runways 2,440-3,659 m; I
with runways 1,220-2,439 m; 0
Telecommunications: adequate network of
radio relay and wire; 3,500 telephones;
broadcast stations — 3 AM, 2 FM; I Atlantic
Ocean INTELSAT earth station
Branches: Army, Navy, National
Gendarmerie, National Police
Manpower availability: males age 15-49
207,754; fit for military service 105,100
Defense expenditures: exchange rate
conversion — SNA, NA% of GDP
Syria, and Jordan in June 1967 ended with
Israel in control of the West Bank, East
Jerusalem, the Gaza Strip, the Sinai Peninsula,
and the Golan Heights. Israel withdrew from
the Sinai Peninsula pursuant to a 1979 peace
treaty with Egypt. The Israeli-PLO Declaration
of Principles on Interim Self-Government
Arrangements ("the DOP"), signed in
Washington on 13 September 1993 provides
for a transitional period not exceeding five
years of Palestinian interim self-government in
the Gaza Strip and the West Bank. Under the
DOP, final status negotiations are to begin no
later than the beginning of the third year of the
transitional period.
Location: Middle East, bordering the eastern
Mediterranean Sea, between Egypt and Israel
Map references: Middle East
Area:
total area; 360 sq km
land area; 360 sq km
comparative area; slightly more than twice the
size of Washington, DC
Land boundaries: total 62 km, Egypt 1 1 km,
Israel 51 km
Coastline: 40 km
Maritime claims: Israeli occupied with status
to be determined
International disputes: West Bank and Gaza
Strip are Israeli occupied with interim status
subject to Israeli/Palestinian negotiations —
final status to be determined
Climate: temperate, mild winters, dry and
war.Ti to hot summers
Tei rain: flat to rolling, sand- and dune-
covered coastal plain
Natural resources: negligible
Lattd use:
arable land; 13%
permanent crops; 32%
mi''adows and pastures; 0%
forest and woodland; 0%
other; 55%
Raiiroads: one line, abandoned and in
disrepair, some trackage remains
Highways:
total; NA
paved; NA
unpaved; NA
note: small, poorly developed road network
Ports: facilities for .small boats to service the
city of Gaza
Airports:
total: 1
usable: 1
with permanent-surface runways: 0
with runways over 3,659 m; 0
with runways 2,440-3,659 m; 0
with runways 1,220-2,439 m: 0
Telecommunications: broadcast stations —
no AM, no FM, no TV
Defense Forces
Branches: NA
Defense expenditures: exchange rate
conversion — SNA, NA% of GDP
145','92e4fb24960b0353f33656776171c778ec4d3b86a8a1f0b0a3df2aa440c817ce','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfc61a56a4b5280eebe81badad68b4dcdb7481193de5dd10040724aa87ec162c',1994,'GE','Georgia','communications',422,'IGObn
Note: Georgia is currently besieged by
interethnic strife in its Abkhazian and South
Ossetian enclaves.
Railroads: 1,570 km, does not include
industrial lines (1990)
Highways:
total: 33,900 km
paved and gravelled: 29.500 km
unpaved: earth 4.400 km (1990)
Pipelines: cmde oil 370 km, refined products
300 km, natural gas 440 km ( 1992)
Ports: coastal — Bat''umi. P''ot''i, Sokhumi
Merchant marine: 41 ships (1,000 GRT or
over) totaling 575,823 GRT/882,1 10 DWT,
bulk cargo 14. oil tanker 27
Airports:
total: 37
usable: 27
with permanent-surface runways: 14
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 10
with runways 1,060-2,439 m: 4
note: a C-130 can land on a 1,060-m airstrip
Telecommunications: poor telephone
service; as of mid- 1993, 672,000 telephone
lines providing 14 lines per 100 persons;
339,Cj00 unsatisfied applications for telephones
(31 December 1990); international links via
landline to CIS members and Turkey; low
capacity satellite earth station and leased
international connections via the Moscow
international gateway switch with other
countries: international electronic mail and
telex service available
Note; transportation network is disrupted by
ethnic conflict, criminal activities, and fuel
shortages
Defense Forces
Branches: Army, Air Force. Navy, Interior
Ministry Troops, Border Guards
Manpower availability; males age 15-49
1,362,818; fit for military service 1,081,624;
reach military age (18) annually 42,881 (1994
est.)
Defense expenditures: $NA, NA% of GNP
Note: Georgian forces are poorly organized
and not fully under the government''s control
147
Railroads: 20,638 km route distance total;
20,324 km of 1 .067-meter gauge trackage
(counts double and multiple tracking as single
track); 3 14 km of 610 mm gauge; substantial
electrification of 1 .067 meter gauge
Highways:
total: 1 88,309 km
paved: 54,013 km
mpaved: crushed stone, gravel, improved
earth 1 34.296 km
Pipelines: crude oil 93 1 km, petroleum
products 1 ,748 km, natural gas 322 km
Ports: Durban, Cape Town, Port Elizabeth,
Richards Bay, Saldanha, Mosselbaai
Merchant marine: 5 ships ( I ,(X)0 GRT or
over) totaling 213,273 GRT/20 1,043 DWT,
container 4, vehicle carrier I
Airports:
total: 886
usable: 7 1 8
with permaneni-suifaee runways: 140
with runways over .1.659 ni: 5
with runways 2.440-3.659 m; 10
with runways 1.220-2.439 ni: 2 1 3
Telecommunications: the system is the best
developed, most modern, and has the highest
capacity in Africa; it consists of carrier-
equipped open-wire lines, coaxial cables, radio
relay links, fiber optic cable, and
radiocommunication stations; key centers arc
Bloemfontein, Cape Town. Durban,
Johannesburg, Port Elizabeth, and Pretoria;
over 4.5(X),0(X) telephones; broadcast
stations— 14 AM, 286 FM, 67 TV; 1
submarine cable; satellite earth stations — I
Indian Ocean INTELSAT and 2 Atlantic
Ocean INTELSAT
Defense Forces
Branches; the South African National
Defence Force (SANDF) includes Army,
Navy. Air Force, and Medical Services of the
former South Africa, the anned forces of the
former homelands, and the ANC and PAC
military components; the initial strength of the
SANDF has been set at about l(X),()(X) active
duty members with plans to reduce it to about
40, (XK) by 1997; it is manned mostly by
nonwhites, but the higher officer grades are
held by whites; the South African Police (SAP)
have incorporated the ptilice forces of the
former homelands since the electiens of 1994;
A National Peacekeeping Force (NPKF) to
ensure peaceful proceeilures during the 1994
elections was established briefiy from the
military components of the principal political
factions, but was dis.soivcd on 2 June 1994,
following the elections
. TiMrssy
• IdmndM
South
Sci,i„ Stnamch
Seundefs
ts tends
tfJofttngu
Admtnibttrttf by U.K..
*
cltlmtd by ArgBntina
Bristol
Highways:
total: NA
paved: NA
unpaved: NA
Ports; Grytviken on South Georgia
Airports;
total: 5
usable: 5
with permanent-surface runways: 2
with runways over 3,659 m: 0
with runways 2,440-3.659 m: 1
with runways 1,220-2,439 m: 0
Telecommunications: coastal radio station at
Grytviken; no broadcast stations
Defense Forces
Note: defense is the responsibility of the UK
300 km
Bby of Biscay
Ocatn Strait of
Cibrahar Cantry islands. Cauia.
and Manila are noi mown.
Location: Southwestern Europe, bordering
the North Atlantic Ocean and the
Mediterranean Sea, between Portugal and','99d27ce4b32fefc6382d7a9895e5efda7b7e0ccf2188a32b9780e57c160ab949','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64c80eccc828a64779b587ff80a17cd0482859a9076b6b4f44536a25ebc0277f',1994,'GH','Ghana','communications',433,'Railroads: 953 km, all 1.067-meter gauge; 32
km double track; railroads undergoing major
renovation^
Highways:
total: 32,250 km
paved: concrete, bituminous 6,084 km
unpaved: gravel, crushed stone, impro'' ^d
earth 26,166 km
Inland waterways: Volta, Ankobra, and
Tano Rivers provide 168 km of perennial
navigation for launches and lighters; Lake
Volta provides 1,125 km of arterial and feeder
waterways
Pipelines: none
Ports: Tema, Takoradi
Merchant marine: 5 ships ( 1,000 GRT or
over) totaling 46,289 GRT/61 ,606 DWT, cargo
4, refrigerated cargo 1
Airports:
total: 11
usable: II
with permanent-sutface runways; 6
with runways over 3,659 m: 0
with runways 2.440-3,659 m: 3
with runways 1,220-2,439 m: 6
Telecommunlcathms: poor to fair system
handled primarily by microwave radio relay
links; 42,300ielephones; broadcast stations — 4
AM, 1 FM, 4 (8 translators) TV; 1 Atlantic
Ocean INTELSAT earth station
Defense Forces
Branches: Army, Navy, Air Force, Police
Force, Civil Defense
Manpower availability: males age 15-49
3.867,183; fit for military service 2.159,769;
reach military age ( 1 8) annually 1 70,283 ( 1 994
est.)
Defense expenditures: exchange rate
conversion — $30 million, less than 1% of GDP
(1989 est.)
152
Death rate: !<.K7 dcuths/l ,(KX) population
( IW osi.)
Net migration rate: -0.73 ini(!runt(s)/l,(XX)
population t IW4 cst.)
Infant mortality rate; 8.1 dcuths/l. tXX) live
births ( IW4 cst.)
Life expeetaiK'') at birth:
loliil poimliilion: 7(i..3.3 years
tiuiU’: 7."'', 44 years
ffnuilc: 70.10 years ( 1004 cst.)
Total fertility rate: 2. .3.3 children bom/
wotnan (1004 est.)
Nationality:
noun: Gihrullurian(s)
iitijfctivc: Gibraltar
Kthnic diviNionti: ;:.diun. English. Maltese.
Portuguese. Spanish
Keligioas: Roman Catholic 74''5i . Pnrtestant
1 1 ''.3 (Church of Hnglund 8''a . other .3''4'').
Mrrslem X'';{ . Jewish 2C} . none or other .S''.f
(1081)
Languages: littglish (used iit schimls and for
official purposes). .Spanish. Italian.
Portuguese. Russian
Literacy:
total population: NA''.f
nialf: NA''3
fvinalc: NA''^i
Labor force: 1 4.8(X) (including non-Gibraltar
laborers)
note: liK inililury establishments and civil
government employ nearly .3()''/i of the labor
force
(•overnment
Names;
conventional lonit Jonn: none
conventional xhort foem; Gibniitar
Digraph: Gl
Type: deiK-ndent tenitory of the UK
Capital: Gilbraltar
Administrative divisions: none (deix''iulent
territory of the UK)
Independence: mine (dependent territory of
the UK)
National holiday: Commonwealth D:iy
tsecoiic'' nVindtiy of March)
Constitution: 3() May 19hy
Legal .system: littglish l:iw''
Suffrage: 1 .8 years of age; universal, plus
other L''K subjects resident six months or more
Kxecu''.ive branch;
chief'' of stat‘ Queen HLI/ABliTH II (since (i
l•ebruary ld.''''2). represented by Governor and
Commande.'' in Chief (ien. Sir John Cl lAPPl.K
tsince NA March 1993)
liea<l ol''i^overniiieni: Chief Minister Jw
BOS.SANO (since 2.3 March 1988)
(lihraltar Council: advises the governor
cabinet: Counci'' of Ministers; appointed from
the elected members of the Assembly by (he
governor in consultation w ith the chief
minister
Legislative brunch: unicameral
House of Assetnhiy: elections last held on 1ft
January 1992 (next to K'' held January I99ft:i
results — SL 7.3..3'';i ; seats — (18 total. 1.3
elected) ttumher of scats by party NA
Judicial branch: Supreme Court. Court of
Appeal
Political parties and leaders: Gibraltar
SiK''iulisi Labor Party (SL). Jew BOSSANO:
Gibraltar Labor Party/Ass, iciation for the
Advancement of Civil R''ghts (GCL/AACR).
leader NA; Gibraltar Srxial IXmiwrats. Peter
CARUANA; Gibraltar National Party, Jix;
GARCIA
Other political or pres.surc groups:
Housewives Asscx''iution; Chamber of
Commerce: Gibraltar Representatives
Organi/ation
Member of: INTERPOL (subbureau)
Diplomatic representation in US: none
(dependent territory of the UK)
US diplomatic representation: none
(dependent territory of the UK)
Flag: two horizontal biinds of white (top,
double width) and red with a three-towered red
castle in the center of the white band; hanging
from the castle gate is a gold key centered in
the red band
Railroads: I .(XX)-metcr-guugc system in
dockyard area only
Highwiays:
total: 30 km
luived; 50 ktn
Pipelines: none
Ports; Gibraltar
Merchant marine: 29 ships ( I ,(XX) GRT or
over) totaling 49ft, 898 GRT/857.140 DWT.
cargo 4, bulk 3. refrigerated cargo 1 , container
1. oil tanker I ft, chemical tanker 2
note: a flag of convenience registry
Airports;
total: I
usable: 1
with permanent sioface runways: 1
with runways over 3,ft.3y m: 0
with runways 2.44f>-.3,6.39 m: 0
with runways 1.220-2,4^*1 in: 1
Telecommunications: adequate, aut- tnatic
domestic system and adequate international
radirx''ommunicution and microwave facilities;
9,4(X) telepliones; broadcast stations — I AM, ft
FM. 4 TV; I Atlantic Ocean INTELSAT earth
station
Dcfcn.se Forces
Branches; British Anny, Royal Navy, Royal
Air Force
Note: defense is the responsibility of the UK
\\
Glorioso Islands Greece
(possession of France)
3 km
Wnck
Railroads: 370 km 1 .000-meter gauge, single
track
Highways:
total: 6,462 km
paved: 1 ,762 km
unpaved: unimproved earth 4,700 km
Inland waterways: 30 icm Mono River
Ports: Lome, Kpeme (phosphate poii)
Merchant marine: 2 roll-on/roll-off cargo
ships ( 1 ,000 GRT or over) totaling 11,118
GRT/20.529DWT
Airports:
total: 9
usable: 9
with permanent-surface runways: 2
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 2
with runways 1,220-2,439 m: 0
Telecommunications: fair system based on
network of radio relay routes supplemented by
open wire lines; broadcast stations — 2 AM. no
FM, 3 (2 relays) TV ; satellite earth stations — 1
Atlantic Ocean INTELSAT and I
SYMPHONIE
Loenthm: Oceania, Polynesia, 3,730 km
southwest of Honolulu in the South Pacific
Ocean, about halfway between Hawaii and','540902d1bf87106e37fc5f675c4b86d1ef4614c77dfe607462f4d961cbe2a99e','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f6049fd3c317ecae4330feb5a9699a4f8fe447da0f0958339cdf7cb32014e3e',1994,'GD','Grenada','communications',435,'microwave radio relay; 17,900 telephones;
broadcast stations — 5 AM, 7 (35 repeaters)
FM, 4 (9 repeaters) TV; 2 coaxial submarine
cables; 1 Atlantic Ocean INTELSAT earth
station
Defense Forces
Note; defense is responsibility of Denmark
Highways:
total: 1 .000 km
paved: 600 km
unpaved: otherwise improved 300 km;
unimproved earth 100 km
Ports: Saint George''s
Airports:
total: 3
usable: )
with permanent-surface runways: 2
with runways over 3,6.59 m: 0
with runways 2.440-JI.6F9 m: I
with runways 1 .220-2,439 m: I
Telecommunications: automatic, islandwide
telephone system with 5,650 telephones: new
SHF radio links to the islands of Trinidad.
Tobago and Saint Vincent; VHF and UHF
radio links to the islands of Trinidad and
Carriacou; broadcast stations — 1 AM, no FM,
1 TV
Defense Forces
Branches: Royal Grenada Police Force, Coast
Guard
Defense expenditures: SNA, NA% of GDP','56f0c9c90d05c32502acf35e0f3920d4707d1dbcf1dacc1f07e9e55eb32139af','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b47afca3e6eb8461180d2647f91e1a044f0375cc542eccabc8d1e04b292692af',1994,'GU','Guam','communications',447,'Railroads: privately owned, narrow-gauge
plantation lines
Highways:
total; 1 ,940 km
paved: l,6(X)km
unpaved: gravel, earth 340 km
Ports; Pointe-a-Pitre, Basse-Terre
Airports;
total: 9
usable: 9
with permanent-surface runways: 8
with runways over 3.659 m: 0
with runways 2,440-3.659 m; I
with runways ! ,220-2,439 m; 1
Telecommunications: domestic facilities
inadequate; 57.3(X) telephones; interisland
microwave radio relay to Antigua and
Barbuda, Dominica, and Martinique; broadcast
stations — 2 AM, 8 FM (30 private stations
licensed to broadcast FM), 9 TV; 1 Atlantic
Ocean INTELSAT ground station
Defense Forces
Branches: French Forces, Gendarmerie
Note: defense is responsibility of France
Highways:
total: 674 km (all-weather roads)
IHtved: NA
unpaved: NA
Ports: Apra Harbor
Airports:
total: 5
usable: 4
with itennanenl-stttface runways; 3
with runways over JXi59 m: 0
with runways 2.440-3,659 in: 3
with runways I.200-2.439 m: 0
Teiecommunications; 26.317 telephones
(1989); broadcast stations — 3 AM. 3 FM. 3
TV; 2 Pacific Ocean INTELSAT ground
stations
Defense Forces
Note: defense is the resp»msibility of the US','b43c7d7789c53057ba9e914318d90f76e55d40dca1e86bfeadb093093f335ad9','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d204c36d719068175f8940d20a0e622d7da3d3045e2a979bf2276d31f21bf47',1994,'GG','Guernsey','communications',461,'Highways:
total: NA
paved: NA
unpaved: NA
Ports: Saint Peter Port, Saint Sampson
Airports:
total: 2
usable: 2
165
Guernsey (continued)','758389510f5bca68c420c333ef046fa9873039d460e77aa7ee9680b255e2b0e0','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8c0501ceff9827c1f1dd488da779cf734745fe959d4c63979eeb8a919b58aba',1994,'GN','Guinea','communications',462,'with permanent-surface runways: 2
with runways over 3,659 m: 0
with runways 2,440-3.659 m: 0
with runways 1,220-2,439 m; 1
Telecommunications: broadcast stations — I
AM, no FM, 1 TV; 41,900 telephones; I
submarine cable
Defense Forces
Note: defense is the responsibility of the UK
Railroads: 1 ,045 km; 806 km 1 .000-meter
gauge, 239 km 1.435-meter standard gauge
Highways:
total; 30.100 km
paved; 1. 145 km
unpaved; gravel, crushed stone 12,955 km (of
which barely 4,500 are currently all-weather
roads); unimproved earth le.ooio km ( 1987)
Inland waterways: 1,295 km navigable by
shallow-draf) native craft
Ports: Conakry, Kamsar
Airports:
total; 15
usable: 15
with permanent-surface runways; 4
with runways over J, 659 in; 0
with runways 2,440-3,659 m; 3
with runways ! ,220-2,439 m: 10
Telecommunications: poor to fair system of
open-wire lines, small radiocommunication
stations, and new radio relay system: 15.000
telephones; broadcast stations — 3 AM I FM, 1
TV;65.(XX)TV sets. 200,000 radio receivers: 1
Atlantic Ocean INTELSAT earth station
Defense Forces
Branches: Army. Navy (acts primarily as a
coast guatd). Air Force. Presidential Guard.
Republican Guard, paramilitary National
Gendarmerie, National Police Force
Manpower availability: males age 15-49
1,440,297; fit for military service 726.543
Defense expenditures; exchange rate
conversion — $29 million, 1 .2% of GDP ( 1 988)
167
Guinea-Bissan
100 km
dos BijagSs
North Atlantic Ocean','0959106ef0ab5d6a292fd13945e6516d5e2735ebab85482cbf27cd9407fc745f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6582913d1ded4f96b76199eea1d7b14a2eab545871ac8d2ee2d7d4fcc1b44e8',1994,'NG','Nigeria','communications',472,'Highways:
total: 3,218 km
paved: bituminous 2,698 km
unpaved: earth 520 km
Inland waterways: scattered stretches are
important to coastal commerce
Ports: Bissau
Airports:
totai: 32
usabie: 16
with permanent-suiface runways: 4
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 1
with runways 1.220-2,439 m: 5
Telecommunications: poor system of radio
relay, open-wire tines, and
radiocommunications; 3,000 telephones;
broadcast stations — 2 AM, 3 FM, 1 TV
Defense Forces
Branches: People’s Revolutionary Armed
Force (FARP; including Army, Navy, Air
Force), pvamilitary force
Manpower availability: males age 1 5-49
243,715; fit for military service 139,161
Defense expenditures: exchange rate
conversion — $9,3 million, 5%-6% of GDP
(1987)
— 3S!U9-
Gulf of Gjinoo
Railroads: 3,505 km 1.067-meter gauge
Highways:
total: 107,990 km
paved: mostly bituminous-surface treatment
30.019 km
unpaved; gravel, crushed stone, improved
earth 25,4 1 1 km; unimproved earth 52,560 km
Inland waterways: 8.575 km consisting of
Niger and Benue Rivers and smaller rivers and
creeks
Pipelines: crude oil 2,042 km; natural gas 500
km: petroleum products 3.000 km
Ports: Lagos. Port Harcouit, Calabar, Warri,
Onne, Sapele
Merchant marine: 33 ships ( 1 ,000 GRT or
over) totaling 432,704 GRT/686,718 DWT,
cargo 18, roll-on/roll-off cargo I. oil tanker9,
chemical tanker 3, bulk I, liquified gas I
Airports;
total: 80
usable: 67
with permanent-sutface runways: 34
with runways over 3,659 m; I
with runways 2,440-3,659 m; 15
with runways 1,220-2,439 m: 21
Telecommunications: above-average system
limited by poor maintenance: major expansion
in progress: radio relay microwave and cable
routes: broadcast stations — 35 AM, 17 FM, 28
TV; satellite earth stations — 2 Atlantic Ocean
INTELSAT. I Indian Ocean INTELSAT. 20
domestic stations; I coaxial .submarine cable
Defense Forces
Branches: Army. Navy, Air Force.
paramilitary Police Force
Manpower availability: males age 15-49
22,468,803; fit for military service 12,840,029;
reach military age ( 1 8) annually 986,5 1 8 (1994
est.)
Defense expenditures: exchange rate
conversion— $172 million, about 1% of GDP
(1992)
292
Railroads; 84 km I .()67-meter narrow-gauge
mineral line is used on a limited basis because
the mine at Marampa is closed
Highways:
total: 7,400 km
paved: 1,150 km
unpaved: crushed stone, gravel ■ ,
improved earth 5,760 km
353
Sierra Leone (continued)','cee78af214d3090499d7e82b3f0c6c81b06157df26ebf0ccfe42e88fb1035fd4','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef91231e7623745f8070294add96498c6375dc36629525143aa65f0db718e33e',1994,'HT','Haiti','communications',474,'Railroads: no public railroads; about 100 km
of narrow gauge industrial railroads to
transport minerals, including bauxite
Highways:
total: 7,665 km
paved; 550 km
unpaved, gravel 5,(XX) km: eanli 2.1 15 km
inland waterways: 6,()(K) km total of
navigable waterways; Berbice. Demerara. and
Essequibtt Rivers arc navigable by oceangoing
vessels for 150 km, l(X) km, and 80 km.
respectively
Ports; Georgetown. New Amsterdam
Merchant marine: I cargo ship ( I .(MX) CRT
or over) totaling 1,317 GRT/2.558 DWT
Airports:
total: 53
u.sahle: 48
with pemanem-siaiaee runway.<i: 5
with nuiway.f over .1,6.19 m: 0
with runways 2.440-.i.619 in: 0
with runways 1, 220-2, 4 J9 in: 12
Telecommunications: fair system with radio
relay network; over 27,0(X) telephones;
tropospheric scatter link to Trinidad; broadcast
stations — I AM. 3 FM. no TV. I shortwave; I
Atlantic Ocean INTELSAT earth station
Defense Forces
Branches; Guyana Defense Force (GDF;
including the Ground Forces, Coast Guard and
Air Corps). Guyana People’s Militia (GPM),
Guyana National Service (GNS)
Manpower availability: mules .ige 1 5-49
197,802; tit for military service 150.072
Defense expenditures: SNA. NA''/i of GDP
7Mm
North At/antic Ocean
lie de le Torture*
Caribbean Sea
Railroad.s: 40 km 0.760-meter narrow gauge,
single-track, privately owned industrial line
Highways:
total: 4,000 km
paved: 950 km
unpaved: otherwise improved 900 km;
unimproved earth 2, 1 50 km
Inland waterways: negligible; less than I (X)
km navigable
Ports: Port-au-Prince. Cap-Haitien; six minor
ports
Airports:
total: 14
usable: 1 1
with permanent-surface runways: ,3
with runways over 3,6.59 m: 0
with runways 2.440-3,659 m; 1
with runways 1 ,220-2.439 m: 3
Telecommunications: domestic facilities
barely adequate, international facilities slightly
better; 36.()00 telephones; broadcast stations —
172
Heard Island and
McDonald Islands
(territory of Australia)
33 AM, no FM, 4 TV, 2 shortwave; 1 Atlantic
Ocean INTELSAT earth station
Defense Forces
Branches: Army (including Police), Navy,
Air Force
Manpower availability: males age 1 5-49
1,313,265; fit for military service 709,712;
reach military age (18) annually 62,488 (1994
est.)
Defense expenditures: exchange rale
conversion — $34 million, 1 .5% of GDP (1988
est.)
McDonald
Islands
/ia\\ Island
^McDonald Island
Indian
Ocean
.Shag Island
Heard Island','ec989b528596a9ce974b538c495aa5193ba8fed890a74b27c546a537b529ac1e','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('680148fbb5ad52478b5cf21afaba15eda73845c818f031a91bba11d805c9ace5',1994,'IT','Italy','communications',480,'Railroads: 850 m, 750-mm gauge (links with
Italian network near the Rome station of Saint
Peter''s)
Highways: none; all city streets
Telecommunications: broadcast stations — 3
AM, 4 FM, no TV; 2.(X)0-line automatic
telephone exchange; no communications
satellite systems
174
Railroads: 600km l.435-me:er gauge, single
track: diesel operated
Highways;
total: 13,300 km
paved: 1 3,300 km
Pipelines: crude oil 708 km; petroleum
products 290 km; natural gas 89 km
Ports: Ashdod. Haifa
Merchant marine: 33 ships ( 1 ,000 CRT or
over) totaling 637,097 GRT/737,762 DWT.
cargo 8, container 22, refrigerated cargo 2, roll¬
on/roll-off cargo I
note: Israel also maintains a significant flag of
convenience fleet, which is normally at least as
large as the Israeli flag fleet; the Israeli flag of
convenience fleet typically includes all of its
oil tankers
Airports:
total: 55
usable: 48
with permaneiu-suiface runways: 30
with runways over 3,659 m; 1
with runways 2,440-3,659 m: 6
with runways 1,220-2,439 m: 13
Telecommunications: most highly developed
in the Middle East although not the largest;
good system of coaxial cable and microwave
radio relay; l,800,0(X) telephones: broadcast
stations — 14 AM, 21 FM, 20 TV; 3 submarine
cables; satellite earth stations — 2 Atlantic
Ocean INTELSAT and I Indian Ocean
INTELSAT
Defense Forces
Branches: Israel Defense Forces (including
ground, naval, and air components)
note: historically, there have been no separate
Israeli military services
Manpower availability ; males age 15-49
1 ,257,345; females age 1 5-49 1 ,280,899; males
fit for military service 1,026,699: females fit
for military service 1,049,998; males reach
military age (18) annually 47,297 (1994 est.);
females reach military age (18) annually
45,214 (1994 est.); both sexes are liable for
military service
Defense expenditures; exchange rate
conversion — $6.5 billion, 10% of GDP (1993
est.)
Railroads: 20,01 1 km total: 16.066 km 1 .435-
meter government-owned standard gauge
(8,999 km electrified): 3.945 km privately
owned — 2, 1 00 km 1 .435-meter standard gauge
( 1,155 km electrified) and 1.845 km 0.950-
meter narrow gauge (380 km electrified)
Highways:
total: 298,000 km
paved: 270,(X)0 km (including nearly 7,000 km
of expressways)
unpaved: gravel, crushed stone 23,000 km;
earth 5,000 km
Inland waterways: 2.400 km for various
types of commercial traffic, although of limited
overall value
Pipelines: crude oil 1.703 km; petroleum
products 2.148 km: natural gas 19.400 km
Ports: Cagliari (Sardinia). Genoa. La Spezia.
Livorno. Naples. Palermo (Sicily). Taranto.
Trieste, Venice
Merchant marine: 474 ships ( 1 .000 GRT or
over) totaling 6,055.779 GRT/8.924.779
DWT, passenger 8. short-sea passenger 34.
cargo 72. refrigerated cargo 2. container 20.
roll-on/roll-off cargo 62, vehicle carrier 7.
multifunction large-load carrier I. oil tanker
1 29, chemical tanker 34, liquefied gas 39.
specialized tanker 10. combination ore/oil 5.
bulk 50, combination bulk I
Airports:
total: 137
usable: 132
with permanent-surface runways: 92
with runways over 3,659 m: 2
with runways 2,440-3.659 m: 36
with runways 1,220-2,439 tn: 39
Telecommunications: modem, well-
developed, fast; 25.600.0(X) telephones: fully
automated telephone, telex, and data services:
high-capacity cable and microwave radio relay
trunks; broadcast stations — 1 35 AM. 28 ( 1 ,840
repeaters) FM, 83 ( 1 ,000 repeaters) TV;
international service by 2 1 submarine cables, 3
satellite earth stations operating in INTELSAT
with 3 Atlantic Ocean antennas and 2 Indian
Ocean antennas: also participates in
INMARSAT and EUTELSAT systems
Defense Forces
Branches; Army, Navy, Air Force.
Carabinieri
Manpower availability: males age 15-49
14,921,41 1; fit for military service 12,982,445:
reach military age (18) annually 403,0 17(1 994
est.)
Defense expenditures: exchange rate
conversion — $24.5 billion, 2% of GDP (1992)
199','dabe9a980a38a047e0167896ff1d14208cfb8a79eef781de2ef58747fb702a61','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da562f77f73a140fac468d74a545682e0cadca9c5fa77b729e59d3796963c40c',1994,'HN','Honduras','communications',481,'Defense Forces
Note: defense is the responsibility of Italy;
Swiss Papal Guards are posted at entrances to
the Vatican City
Caribbean Saa
Railroads; 785 km total; 508 km 1 .()67-meter
gauge, 277 km 0.914-meter gauge
Higi;ways:
total; 8.950 km
paved: 1 ,700 km
unpaved: otherwise improved 5,(XX) km;
unimproved earth 2,250 km
Inland waterways: 465 km navigable by
small craft
Ports: Puerto Castilla. Puerto Cortes. Sun
Lorenzo
176
Merchant marine: 270 ships ( 1 ,000 CRT or
over) totaling 83 1 ,856 GRT/1 .248. 1 86 DWT.
passenger-cargo 2. cargo 177, refrigerated
cargo 20. container 7. roll-on/roll-off cargo 6.
oil tanker 22, chemical tanker 2. specialized
tanker 2, bulk 25. passenger 2, short-sea
piissenger 2, vehicle carrier I , liquiried gas I ,
combination bulk I
iii''te: a flag of convenience registry; Russia
ovi''ns 14 ships under the Honduran flag
Airports:
tola/: 160
HSti/y/e: 133
w/rli penmmeithsurface rmmvys: 1 1
wii/i ninways over 3,659 m: 0
ivitli rwiway.s 2,440-3,659 m: 4
with runway,''! 1,220-2,439 m; 14
Telecommunications: inadequate system
with only 7 telephones per 1,000 persons;
international services provided by 2 Atlantic
Ocean INTELSAT earth stations and the
Central American microwave radio relay
system; broadcast stations — 1 76 AM, no FM, 7
SW,. 28 TV
Defimse Forces
Branches: Army. Navy (including Marines),
Air Force, Public Security Forces (FUSEP)
Manpower a . ailabiUty: males age 15-49
1,229,777; fit for military service 732,866;
reach military age (18) annually 60,445 (1994
est.)
Defense expenditures: exchange rate
conversion — $42.8 million, about 1,3% of
GDP (1993 est.)','39b31bf993e54f8d9b9b2d925a42493c229dab68cbaf0474cbf3cae03c920f75','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e53a1cb2bcd37e6547ba8a12b9d06063163dd990d19005bb1ff75e9070039c1',1994,'HK','Hong Kong','communications',482,'(dependent territory of the UK)
jUm,
Railroads; 35 km 1 .435-meter standard
gauge, government owned
Highways:
total: l,l(X)km
paved; 794 km
unpaved: gravel, crushed stone, earth 306 km
Ports: Hong Kong
Merchant marine; 201 ships (l.tXX) CRT or
over), totaling 6,972.233 GRT/1 1 ,965,809
DWT, short-sea passenger 1 . cargo 23.
refrigerated cargo 7, container 29, vehicle
carrier 2, oil tanker 16, chemical tanker 3.
combination ore/oil 6, liquefied gas 7, bulk
105. combination bulk 2
note: a flag of convenience registry; ships
registered in Hong Kong fly the UK flag, and
an estimated 500 Hong Kong-owned ships are
registered elsewhere
Airports:
total: 2
usable: 2
with ;iermanent-siitface runways; 2
with rwmt''fiv.v over 3.659 m; 0
with nom nv.v 2.440-3.659 in: 1
with rwtu nv.v 1.220-2.439 in; 0
Telecommunications: modem facilities
provide excellent domestic and international
services; 3,(XX),(XX) telephones; microwave
transmission links and extensive optical fiber
transmission network; broadcast station.s — 6
AM, 6 FM, 4 TV; 1 British Broadcasting
Corporation (BBC) repeater station and 1
British Forces Broadcasting Service repeater
station; 2,50(),(XX) radio receivers: l.312,(XX)
TV sets ( 1 ,224,(XK) color TV sets); satellite
earth stations — I Pacific Ocean INTELSAT
and 2 Indian Ocean INTELSAT; coaxial cable
to Guang/hou, China; links to 5 international
submarine cables providing access to ASEAN
178
member nations, Japan, Taiwan, Australia,
Middle East, and Western Europe
Defense Forces
Branches: Headquarters of British Forces,
Royal Navy. Royal Air Force, Royal Hong
Kong Auxiliary Air Force, Royal Hong Kong
Police Force
Manpower availability: males age 15-49
1 ,636,397; fit for military service 1 ,25 1 ,901 ;
reach military age ( 1 8) annually 42,044 (1994
est.)
Defense expenditures: exchange rate
conversion — $300 million, 0.5% of GDP
(1989 esi.); this represents one-fourth of the
total cost of defending itsc''f. the remainder
being paid by the UK
Note: defense is the responsibility of the UK
Howland Island
(territory of the US)
Location: Oceania. Polynesia, in the North
Pacific Ocean, 2,575 km southwest of
Honolulu, just north of the Equator, about
halfway between Hawaii and Australia
Map references: Oceania
Area:
louil area: 1 .6 sq km
Umd area: 1 .6 sq km
comparatWe area: about 2.7 limes the size of
The Mall in Washington. DC
IvMiid boundaries: 0 km
Coastline: 6.4 km
Maritime claims:
contiguous zone: 24 nm
continental shelf: 2()0-m depth or to depth of
exploitation
exclusive economic zone: 200 nm
territorial sen: 1 2 nm
International disputes: none
Climate: equatorial; scant rainfall, constant
wind, burning sun
Terrain: low-lying, nearly level, .sandy, coral
island surrounded l>y a narrow fringing reef;
depressed central area
Natural resources: guano (deposits worked
until iate 1 8(X)s)
Land use:
arable land: 0%
l>ernwnent crops: 0%
meadows and pastures: 0%
forest and woodland: 5%
other: 95%
Irrigated land: 0 sq km
Ports; none; offshore anchorage only, one
boat landing area along the middle of the west
coast
Airports: airstrip constructed in 1937 for
scheduled refueling stop on the round-the-
world flight of Amelia Earhart and Fred
Noonan — they left Lae, New Guinea, for
Howland Island, but were never seen again; the
airstrip is no longer serviceable
Note: Earhart Light is a day beacon near the
middle of the west coast that was partially
destroyed during World War II, but has since
been rebuilt in memory of famed aviatrix
Amelia Earhart
Defense Forces
Note: defense is the responsibility of the US;
visited annually by the US Coast Guard
179
Highways:
total: 42 km
paved: 42 km
Ports: Macau
Airports: none usable. 1 under construction;
I seaplane station
Telecommunications: fairly modern
communication facilities maintained for
domestic and international services; 52.0(X)
telephones; broadcast stations— 4 AM. 3 FM.
no TV (TV programs received from Hong
Kong); 1 15.(X)0 radio receivers (est.);
international high-frequency radio
communication facility; access to international
communications carriers provided via Hong
Kong and China; 1 Indian Ocean INTELSAT
earth station
Defense Forces
Manpower availability: males age 15-49
139,499; fit for military service 77,887
Note: defense is responsibility of Portugal
240','fef5b7d3387581fb02017976106bbe7ca58f99da3ac9fa110d0f4d0a31559d60','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cb23eb8dc31ef6c7df19733bbe01d84c911886422943f4e895c531ec6845cea',1994,'IS','Iceland','communications',491,'North AVarttic Ocean
Highways:
total: 1 2,537 km
paved: 2,690 km
unpaved: gravel, earth 9.847 km
Ports: Reykjavik, Akureyri, Hafnarfjordhur,
Keflavik, Seydhisfjordhur, Siglufjordhur,
Vestmaiinaeyjar
Merchant marine: 8 ships ( 1 ,000 GRT or
over) totaling 33,2 1 2 GRT/47,359 DWT. cargo
2. refrigerated cargo 2. roll-on/roll-off cargo 2,
oil tanker 1, chemical tanker I
Airports:
total: 90
usable: 84
with permanent-surface runways: 9
with runways over d.6S9 m: 0
with runways 2,440- J.659 m: I
with runways 1 ,220-2.439 m: 12
Telecommunications: adequate domestic
service; coaxial and fiber-optical cables and
microwave radio relay for trunk network;
140,000 telephones; broadcast stations — 5
AM, 147 (tran.smitters and repeaters) FM, 202
(transmitters and repeaters) TV; 2 submarine
cables; I Atlantic Ocean INTELSAT earth
station carries all international traffic; a .second
INTELSAT earth station is scheduled to be
operational in 1993
Defense Forces
Branches; Police, Coast Guard
note: no armed forces, Iceland’s defense is
provided by the US-manned Icelandic Defense
Force (IDF) headquartered at Keflavik
Manpower availability: males age 15-49
70,074; fit for military service 62,197
Defense expenditures: none
183','ba27b35c7823bc74908eb000570f36f2d3fe77c3b15244e618475ca7c804d4fc','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3e7792a3cb05adf1d7791991fb71f17612b8fcd4b7afd4f99ea94789a621571',1994,'IN','India','communications',502,'Railroads: 61.850 km total (1986); 33..S53
km 1 .676-tneier bniad gauge, 24.05 1 km
1 .0IK)-meter gauge. 4.246 km namiw gauge
(0.762 meter and 0.610 meter); 12.617 km is
double Hack; 6..5()() km is electrified
Highways:
total: 1.97 million km
IHived: 96(>.0IX) km
un/Mwd: gravel, crushed stone, earth 1.0 1
million km 1 1989)
Inland waterways: 1 6, 1 80 km; 3.63 1 km
navigable by large vessels
Pipelines: crude oil 3.497 km; petroleum
pniducts 1.70.3 km; natural gas 902 km ( 1989)
Port.s: Bombay. Calcutta. CtK-hin. Kandla.
Madras. New Mangalore. Port Blair (Andaman
Islands)
Merchant marine: 297 ships ( I .(NX) GRT or
over) totaling 6,236.902 GRT/I()..369.948
DWT. short sea passenger I. passenger-cargo
6. cargo 8 1 , roll-on/roll-off cargo I . container
7. till tanker 66. chemical tanker 9.
combination ore/oil 7. bulk III. combination
bulk 2, liquefied gas 6
Airports:
total: 337
usahle: 288
with permanent-surface runv ays: 208
with runways over -f.6.59 m: 2
with runways 2. 440- .3.659 m: 59
with runways /. 220- 2. 4.39 m.- 92
Telecommunications: domestic telephone
system is ptHir providing only one telephone
for about 2(X) persons on average; long
distance telephoning has been impnived by a
domestic satellite system which also carries
TV; iniernational service is provided by 3
Indian (Vean INTELSAT earth stations and by
185
India (continued)
Indian Ocean
submarine cables to Malaysia and the United
Arab Emirates; broadcast stations — 96 AM, 4
FM, 274 TV (government controlled)
Defense Forces
Branches: Army, Navy, Air Force, .Security
or Paramilitary Forces (including Border
Security Force, Assam Rifles, and Coast
Guard)
Manpower availability; males age l.‘(-49
247,948,906; fit for military service
145,881,705; reach military age (17) annually
9,408.586 ( 1994 est.)
Defense expenditures; exchange rate
conversion — S5.8 billion, 2.49( of GDP
(FY9.^/94)
Location: brxly of water between Africa.
Asia, Australia, and Antarctica
Map references: Southeast Asia. Standard
Time Zones of the World
Area:
louil iireo: 75.6 million sq km
i tmtiHiniinr iirtv: slightly less than eight
times the si/e of the liS; third-largest ocean
(after the Pacific Ocean and Atlantic Ocean,
bitt larger than the Arctic (Vean)
iiofe: includes Arabian Sea. Bay of Bengal.
Persian Gulf. Red Sea. Strait of Malacca. Great
Australian Bight. Gulf >4'' Oman. Mo/unihii|ue
(''haniicl. and other tributary water bodies
Cowtllne; 66.526 km
Inlemiiliowil disputes: some maritime
disputes (see littoral states:
Climate; luirtheasi iiMinsiMin t Dcceinher to
April), southwest mons«M>n (June to (X;loK''r);
tropical cyclones «K''cur during MayVJuiw and
October/Novembei in the mirth Indian Ocean
and Jamiary/l-ebruaty in the south Indian
(K''ean
Terrain: surface doininatc''d by
counterckvkw ise gyre (broad, circular system
of currents I in (he south Indian (Venn: unique
reiersal of surface currents in the north Indian
Ocean, low atmospheric pressua'' over
southwest Asia front hot. rising, summer air
results in the southwest iminsoon and
siMithwest-to-northea.st winds and cuirenls.
while high pressure over minhern Asia from
cold, falling, winter air results in the northeast
monsoon and northeast-to-smithwest winds
and cuaents; ocean floor is ikiininated by the
Mid-Indian (Kean Ridge and subdiMiled by
the Southeast Indian Ocean Kidge. .Southwest
Indian (Kean Kidge. and Ninety Flast Kidge;
maxiitiimt depth is 7.258 meters in the Java
Trench
Nalunil mourcM: oil and gas ticlds. fish,
shrimp, sand and gravel aggregates, placer
deposits, polymetallic nodules
Fnvlnmmrnf;
I iir ri iii i.v.vMi-i - endangered marine species
include the dugong, seals, turtles, and whales;
oil pollution in the Arabian Sea. Persian Gulf,
and Red Sea
natural hazards: N A
international agreements: NA
Note: major chokepoints include Bab el
Mandeb. Strait of Hormuz, Strait of Malacca,
southern access to the Suez Canal, and the
Lombok Strait; ships subject to superstructure
icing in extreme south near Antarctica from
May to (October
Highways;
total; NA
paved: NA
unpaved: NA (Male has 9.6 km of coral
highways within the city)
Ports: Male. Gan
Merchant marine: 1 4 ships ( 1 ,000 GRT or
over) totaling 38,848 GRT/,58,496 DWT. cargo
12. container I, oil tanker I
Airports:
total; 2
usable: 2
with permanent-surface runways; 2
with runways over d, 659 m; 0
with runways 2,440-5,659 m: 2
with runways 1,220-2,439 m: 0
Telecommunications: minimal domestic and
international facilities: 2.804 telephones;
broadcast stations — 2 AM, I FM, 1 TV; 1
Indian Ocean INTELSAT earth station
Defense Forces
Branches: National Security Service
(paramilitary police force)
Manpower availability: males age 15-49
55.369; fit for military service 30.919
Defense expenditures; exchange rate
conversion — $NA. NA% of GDP
247','9c95d46d9b8753266e3809176ccd754c2ffc8e8bc70cb9d2b2fcb64b12bcebab','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0030f307e3926fefbb31127a7d65ca11f0bea8d3209402262e66ea2dcbd1d321',1994,'SA','Saudi Arabia','communications',514,'Railroads: 2.457 km 1 .435-meier standard
gauge
Highways:
totiil: 34.7(X) km
IHived: l7.5(X)km
mifHived: improved earth 5.5(X) km;
unimproved eanh I L7(X) km
Inland waterways; 1 ,0 1 5 km; Shall al Arab is
usually navigable by maritime traffic for about
1 30 km; channel has been dredged to .4 meters
and is in use; Tigris and Euphrates Rivers have
navigable sections for shallow -draft
wulea''rat''l; Shalt al Basrah canal was navigable
by shallow-draft craft before closing in 1991
because of the Persian Gulf war
Pipelines: crude oil 4.3.50 km; petroleum
pixxlucts 725 km; natural gas I .,460 km
Ports; Umm Qasr reopened in November
1993; Khawr az. Zubayr and Al Basrah have
been closed since 1980
Merchant marine: 37 ships ( 1 .0(X) GRT or
over) totaling 805.205 GRT/ 1.444.8 10 DWT.
passenger I, passenger-cargo I, cargo 15,
refrigerated cargo I, roll-on/roll-off cargo 3,
oil tanker 16
note: none of the Iraqi flag merchant fleet was
lr;iding intemaiionully as of I January 199.4
Airports;
lolol: 1 1 8
Miihle: 105
M idi permonent-siiifiice niiiH oys: 76
M ith noiMvys ocer .t,6,59 »i.'' 1 0
Midi riiiiMiiys m: 51
M idi ruiiM ays l.230-2.4J''4 m: 17
Telecommunications: reconstitution of
damaged lelecommunicaiion facilities began
after Desert Storm, most damaged facilities
have been rebuilt; the network consists of
coaxial cables and microwave radio relay
links; 6.42,(XX) telephones; broadca.st stations —
16 AM, 1 FM. 1.4 TV; satellite earth stations —
1 Atlantic Ocean INTELSAT. 1 Indian Ocean
INTELSAT, I Atlantic Ocean GORIZONT in
the Intersputnik system and I ARABSAT;
coaxial c;)ble and microwave radio relay to
Jordan, Kuwait, Syria, and Turkey. Kuwait line
is probably non-operational
192
Railroads: 789 km 1 .050-meter gauge, single
track
Highways:
total: 7,500 km
paved: asphalt 5,500 km
unpaved: gravel, crushed stone 2,000 km
Pipelines: crude oil 209 km
Ports: A! ''Aqabah
Merchant marine: 3 ships (1,000 GRT or
over) totaling 71.566 GRT/1 29,351 DWT.
cargo 1, bulk I, oil tanker I
Airports:
total: 16
usable: 14
with permanenl-suiface runways: 13
with runways over 3,659 m: I
with runways 2, 440-3.659 m: 1 2
with runways 1.220-2,439 m: 0
Telecommunica''ions: adequate telephone
system of microwave, cable, and radio links;
81,500 telephones; broadcast .stations — 5 AM,
7 FM. 8 TV; satellite earth stations — 1 Atlantic
Ocean INTELSAT. I Indian Ocean
INTELSAT. 1 ARABSAT, 1 dome.stic TV
receive-only; coaxial cable and microwave to
Iraq. Saudi Arabia, and Syria; microwave link
to Lebanon is inactive; participant in
MEDARABTEL, a microwave radio relay
network linking Syria, Jordan, Egypt. Libya,
Tunisia, Algeria, and Morocco
Defense Forces
Branches;
Jordanian Armed Forces (JAF) — Royal
Jordanian Land Force, Royal Jordanian Air
Force. Royal Naval Force; note — the Public
Security Force normally under Ministry of
Interior, but falls under JAF authority in
wartime or crisis situations
Manpower availability: males age 1 5-49
966,420; fit For military service 685, 112; reach
military age (18) annually 42,776 (1994 est.)
Defense expenditures: exchange rate
conversion — $.340 million, 6.5% of GDP
(1 993 est.)
208
Juan de Nova Island
(possession of France)
Highways:
total; 1,500 km
paved: 1.000 km
unpaved: gravel, natural surface 500 km (est.)
Pipelines: crude oil 235 km, natural gas 400
km
Ports: Doha, Umm Sa’id, Halul Island
Merchant marine: 1 8 ships ( 1 ,000 CRT or
over) totaling 373,491 GRT/567,294 DWT,
cargo 1 1 . container 4, oil tanker 2, refrigerated
cargo I
Airports:
total: 5
usable; 4
with permanent-surface runways; 1
with runways over 3,659 m: I
with runways 2,440-3,659 m: 0
with runways 1,220-2,439 m; 2
Telecommunications: modem system
centered in Doha; 1 10,000 telephones;
tropospheric scatter to Bahrain; microwave
radio relay to Saudi Arabia and UAE;
submarine cable to Bahrain and UAE; satellite
earth stations — I Atlantic Ocean INTCLSAT,
I Indian Ocean INTELSAT, I ARABSAT;
broadcast stations — 2 AM. 3 FM, 3 TV
''* <fense Forces
Branches: Army, Navy, Air Force, Public
Security
Manpower availability: males age 15-49
2 1 7,538; fit for military service 1 14,468; reach
military age (18) annually 3,737 (1994 est.)
Defense expenditures: exchange rate
conversion — $NA, NA%, of GDP
325
Reunion
(overseas department of France)
UOkm
SowKUrt f«pr*t«nUhon i»
hot hfmunty MtnoriUt''rt','4dd8ccb7b3eaa12f7a4c8e9be3f8771e5403506abba5f9ea5af0b1ad4521783f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f79f4726e63d93df8bf7fb8b24d1972aa0b578bbf23460dc95e36eb126d348b',1994,'IE','Ireland','communications',515,'Defense Forces
Branches: Anny and Republican Guard.
Na\\y. Air Force. Air Defense Force. Border
Guard Force. Internal Security Forees
Manpower availability: males age l.^-44
4.428.19.''; fit for military service 2.487..^ 1 9;
reach military age ( 1 8) annually 219.641 (1994
esi.)
Defense expenditures: exchange rate
conversion — SNA. NA''S- of GNP
Railroads: Irish National Railways (CIE)
operates 1 .947 km 1 .602-meter gauge.
government owned; 485 km double track; 37
km electrified
Highways:
total: 92,294 km
paved: 87,422 km
unpaved: gravel, crushed stone 4,872 km
Inland waterways: limited for commercial
traffic
Pipelines: natural gas 725 km
Ports: Cork, Dublin, Waterford
Merchant marine: 53 ships ( 1 ,000 CRT or
over) totaling 139,278 GRT/173,325 DWT.
short-sen passenger 3, cargo 32. refrigerated
cargo 2, container 4, oil tanker .3. specialized
tanker 3. chemical tanker 2. bulk 4
Airports:
total: 44
usable: 42
with permanent-suiface runways: 14
with runways over 3,659 m: 0
with ninwuys 2.440-3,659 m: 2
with runways t .220-2.439 m: 7
Telecommunications: modern system using
cable and digital microwave circuits; 900,000
telephones; broadcast stations — 9 AM, 45 FM,
86 TV; 2 coaxial submarine cables; I Atlantic
Ocean INTELSAT earth station
Defense Forces
Branches: Army (including Naval Service
194
and Air Corps), National Police (Garda
Siochana)
Manpower availability: males age 15-49
914,052; fit for military service 739,288; reach
military age (17) annually 33,809 (1994 est.)
Defense expenditures: exchange rate
conversion — $569 million, l%-2% of GDP
(1993 est.)','1b839925891f99604552ecd0743e650cf96f8320cbec0ded24abdd6189c22ef3','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2160bafc6e22352e93b47f70bfd583fde39bc1f0219e049500ea9d30544de2f5',1994,'IL','Israel','communications',521,'(also see separate Gaza Strip and West
Bank entries)
Note: The territories occupied by Israel since
the 1967 war are not included in the data
below. In keeping with the framework
established at the Madrid Conference in
October 1991, bilateral negotiations are being
conducted between Israel and Palestinian
representatives, Syria, and Jordan to determine
the final status of (he occupied territories. On
25 April 1982, Israel withdrew from the Sinai
pursuant to the 1979 Israel-Egypt Peace treaty.','f3ac5ba6511bda016c292c5712a140facd9ab0b84ac5289528d0f27694a1a420','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a046e96d8241f8741544509aabed564718ac20d6f8a4d8054ea354ea744db4a',1994,'JM','Jamaica','communications',533,'CtribbMn Sm
Gfoiniphy
Location: Caribbean, in the nonhern
Caribbean Sea. about I Ml kin south of Cuba
Map references: Central America and the
Caribbean. Nonh America. Standard Time
Zones of the World
Area:
lohil urea: 1 0.990 sq km
land area: 1 0.8.10 sq km
coniparaihv area: slightly smaller than
Connecticut
Land boundaries: 0 km
Coastiine; 1 .022 km
Maritime eiaims:
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
Inlenwtionai disputes: none
Climate: tropical; hot. humid; temperate
interior
Terrain: mostly mountains with narrow.
discontinuous coastal plain
Natural resources: bauxite, gypsum.
limestone
Land use:
arable land: \\^''''/c
permanent crops:
meadows and iwstures: 1 8‘X-
forest and womlland: 28‘X-
other: 299}
Irripated land: .I.SO sq km ( 1989 est.)
Railroads: 370 km, all 1 .43S-meter standard
gauge, single track
Highways:
total: 1 8,200 km
paved: 12,600 km
unpaved: gravel 3,200 km; improved earth
2,400 km
Coastline; 124.1 km
Maritime dalms:
contiguous zone: 10 nm
continental shelf: 20O-m depth or to depth of
exploitation
exclusive economic zone: 200 nm
territorial sea: 4 nm
InlemathMial disputes: dispute between
Denmark and Norway over maritime boundary
in Arctic Ocean between Greenland and Jan
Mayen has been settled by the International
Court of Justice
Clinutc: arctic maritime with frequent storms
and persistent fog
Terrain; volcanic island, partly covered by
glaciers; Beerenberg is e highest peak, with
an elevation of 2,277 meters
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
meadows and pasture.^: 0%
forest and woodland: 0%
other: 100%
Irrigated land: Osqkm','bf4394c845ef6bcb3b195c1d29808d519ec9f414ee2b7fed862bf5db3871274a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0345ae5946c2f7b515da4794495def55136d2240db40df327f54b095151b24de',1994,'KZ','Kazakhstan','communications',542,'3 km
Railroads: 14,460 km (all I.S20-meter
gauge); does not include industrial lines ( 1 990)
Highways:
total: 1 89,000 km
paved and graveled: 1 08. 1 00 km
unpaved: earth 80,900 km (1990)
Inland waterways: Syrdariya River. Ertis
River
Pipelines: crude oil 2,850 km, refined
products 1 ,500 km, natural gas 3,480 km
(1992)
Ports: inland — Atyrau (formerly Gur''yev; on
Caspian Sea)
Airports:
total: 365
usable: 152
with permanent-surface runways: 49
with runways over 3,6S9 tn: 8
with runways 2,440-3.659 m: 38
with runways 1.220-2.439 m: 71
Telecommunications; telephone service is
poor, with only about 17 telephones for each
1 00 persons in urban areas and 7.6 telephones
per 100 persons in rural areas; of the
approximately 2.2 million telephones. Almaty
has 1 84,000; broadcast receivers — TVs
4,750,000, radios 4,088,000, radio receiver
systems with multiple speakers for program
diffusion 6,082.(K)0; international traffic with
other former USSR republics and China
carried by landline and microwave, and with
other countries by satellite and through 8
international telecommunications circuits at
the Moscow international gateway switch;
satellite earth .stations— INTELSAT and
Orbita (TV receive only); new satellite ground
station established at Almaty with Turkish
financial help (December 1992) with 2500
channel band width
Defense Forces
Branches: Army, National Guard, Security
Forces (internal and border troops)
Manpower availability: males age 1 5-49
4,432,716; fit for military service 3,554,209;
reach military age ( 1 8) annually 1 54,989 ( 1 994
est.)
Defense expenditures: 69,326 million rubles,
NA% of GDP (forecast for 1993); note —
conversion of the military budget into US
dollars using the current exchange rate could
produce misleading results
Railroads: 370 km; does not include
industrial lines ( 1990)
Highways;
total: 30,300 km
paved and graveled: 22,600 km
unpaved: earth 7,7(X) km (1990)
Pipelines: natural gas 200 km
Ports; none; landlocked
Airports:
total: 52
usable: 27
with permanent-surface runways: 1 2
with runways over 3,659 m: 1
with runways 2,440-3,659 m: 4
with runways t ,060-2,439 m: 13
note: a C- 1 30 can land on a 1 ,060-m airstrip
Telecommunications: poorly developed;
342,000 telephones in 1991 (also about
100.000 unsatisfied applications for hou.sehold
telephones): 76 telephones per 1 .(X)0 persons
(31 December 1991 ); microwave radio relay is
principal means of intercity telephone links:
connections with other CIS countries by
landline or microwave and with other countries
by leased connections with Moscow
international gateway switch and by satellite: 2
satellite earth stations — 1 GORIZONT and I
IN TELSAT (links through Ankara to 200 other
countries and receives Turkish broadcasts):
broadcast receivers — radios 825.000, TVs
875,000, radio receiver systems with multiple
speakers for program diffusion 748,000
Defense Forces
Branches: National Guard, Security Forces
(internal and border troops). Civil Defense
Manpower avaiiability: males age 15-49
1 , 1 23,959: fit for military service 9 1 2,5 1 6;
reach military age (18) annually 44,528 (1994
est.)
Defense expenditures: $NA, NA% of GDP
223
Laos','7a05ebdd8b97c5d4e87200e7804288e1076895d4d3fc2b5c5aee13111d5bff4b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0f1cd03fe75818db7b7217fbeed72e565fbc5c5b76a3469657fb3760df09ad9',1994,'KE','Kenya','communications',551,'Railroads; 2,040 km 1 .000-meter gauge
Highways;
total: 64,590 km
paved: 7,000 km
unpaved: gravel 4,150 km; improved earth
53,440 km
Inland waterways: part of Lake Victoria
system is within boundaries of Kenya
npellnes: petroleum products 483 km
Ports: coastal — Mombasa, Lamu; inland —
Kisumu
Merchant marine: 2 ships ( 1 .000 CRT or
over) totaling 4,883 GRT/6,255 DWT, oil
tanker ship I , barge carrier I
Airports:
total: 248
usable: 2 1 3
with permanent-surface runways: 28
with runways over 3,659 m: 2
with runways 2,440-3,659 m: 3
with runways 1,220-2,439 m: 44
Telecommunications; in top group of
African systems; consists primarily of radio
relay links; over 260,000 telephones; broadcast
stations — 16 AM; 4 FM, 6 TV; satellite earth
stations — I Atlantic Ocean INTELSAT and 1
Indian Ocean INTELSAT
Defense Forces
Branches: Army, Navy, Air Force,
paramilitary General Service Unit of the Police
Manpower availability: males age 15-49
6,144,891; fit for military service 3,799,202
Defense expenditures: exchange rate
conversion — $294 million, 4.9% of GDP
(FY88/89 est.)
213
Kingman Reef
(territory of the US)','d8f547ac8dcd2986d3a7bdc006e892d1d959ab9cdaca093f921f62da2e8e247d','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef19c038fdf3870c362fa99064998f7b4caf963ec5a7fbaf0e161689bceea502',1994,'KI','Kiribati','communications',552,'1 km
Goverament
Names;
conventional long form: none
conventional short form: Kingman Reef
Digraph: KQ
Type: unincoqnrated territory of the US
administered by the US Navy, however it is
awash the majority of the time, so it is not
usable and uninhabited.
Capital: none: administered from
Washington, DC','f175d2382328ea704945449235539199cbf8d49d22709830666adbe92bb8f27a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('493f9bf5ec252f520d96ea7997bd85610d3c1ec8a6e9a98f1c6ce4eee4ff5ff2',1994,'KW','Kuwait','communications',559,'Dcftnse Form
Branches: Army, Navy, Marine Corps, Air
Force
Manpower availability: males age 15-49
13,435,598: fit for military service 8,623,325;
reach military age ( 1 8) annually 4 1 7,055 ( 1 994
est.)
Defense expenditures: exchange rate
conversion — $12.2 billion, 3.6?i- of GNP
(1993 est.)','4c66f4a4fa71f8adefc642ee40259554e35c889afeb471eb32dc657618e5e07b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d56a8b88e5071e045caed321b5da1b64c4cc1f145cb8e0eb3c2de2e15d0a858a',1994,'LV','Latvia','communications',564,'Railroads: none
Highways;
total: 27.527 km
paved: bituminous 1 .856 km
unpaved: gravel, crushed stone, improved
earth 7,451 km: unimproved earth 18,220 km
(often impassable during rainy season
ISOtm','d82931859f1e7312e26ea7750fd534599f4cf6c6df1b745bb152e22d5fe571a0','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62ba13bcd4b212694491439d6da3d9d2a70a98a51901f4584c1ae6152ecbd7bf',1994,'LB','Lebanon','communications',570,'Railroads: 2,400 km ( I ,S24-mm gauge); 270
km electrified
Highways:
total; 59,500 km
paved and graveled: 33,000 km
unpaved: earth 26,500 km (1990)
Inland waterways; 300 km perennially
navigable
Pipelines: crude oil 750 km, refined products
780 km, natural gas 560 km (1992)
Ports: coastal — Riga, Ventspils, Liepaja;
inland — Daugavpils
Merchant marine: 93 ships ( 1 ,000 CRT or
over) totaling 850,840 CRT/ 1,1 07,403 DWT,
cargo 15, refrigerated cargo 27, container 2,
roll-on/roll-off cargo 8, oil tanker 4 1
Airports;
total; 50
usable; 15
with permanent-surface runways; 1 1
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 7
with runways 1,060-2,439 m; 1
note: a C- 1 30 can land on a 1 ,060-m airstrip
Telecommunications: Latvia is better
provided with telephone service than most of
the other former Soviet republics: subscriber
circuits 660,000; subscriber density 240 per
1,000 persons (1993); an NMT-450 analog
cellular telephone network covers 75% of
Latvia''s population; international traffic
carried by leased connection to the Moscow
international gateway switch and through the
new Erics.son AXE local/transit digital
telephone exchange in Riga and through the
Finnish cellular net: electronic mail capability
by Sprint data network; broadcasting services
NA
Defense Forces
Branches: Ground Forces, Navy, Air Force,
Security Forces (internal and border troops).
Border Guard, Home Guard (Zemessardze)
Manpower availability: males age 1 5^49
652,444; fit for military service 5 14,055; reach
military age (18) annually 18,803 (1994 est.)
Defense expenditures: 176 million rubles,
3%-5% of GDP; note — conversion of the
military budget into US dollars using the
prevailing exchange rate could produce
misleading results
Note: Lebanon has made progress toward
rebuilding its political institutions and
regaining its national sovereignty since the end
of the devastating 16-year civil war in October
1990. Under the Ta’if accord — the blueprint
for national reconciliation — the Lebanese have
established a more equitable political system,
particularly by giving Muslims a greater say in
the political process. Since December 1990,
the Lebanese have formed three cabinets and
conducted the first legislative election in 20
years. Most of the militias have been weakened
or disbanded. The Lebanese Armed Forces
(LAP) has seized vast quantities of weapons
used by the militias during the war and
extended central government authority over
about one-half of the country. Hizballah, the
radical Sh'' ia party, retains most of its weapons.
Foreign forces still occupy areas of Lebanon.
Israel maintains troops in southern Lebanon
and continues to support a proxy militia. The
Army of South Lebanon (ASL), a''ong a narrow
stretch of territory contiguous to its border. The
ASL''s enclave encompasses this self-declared
security zone and about 20 kilometers north to
the strategic town of Jazzine. As of December
1993, Syria maintained about 30,000-35,000
troops in Lebanon. These troops are based
mainly in Beirut, North Lebanon, and the
Bekaa Valley. Syria’s deployment was
legitimized by the Arab League early in
Lebanon’s civil war and in the Ta’if accord.
Citing the continued weakness of the LAF,
Beirut’s requests, and failure of the Lebanese
Government to implement all of the
constitutional reforms in the Ta’if accord,
Damascus has so far refused to withdraw its
troops from Beirut.','e396f8a112b1446f044b1835b2fc34b7ce34f1d8c2cfce77060ef80772fc5198','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed7806ea8d7e7d70392c5fe9135d2db918fe04e0152f19bdd77192138d9df67e',1994,'LS','Lesotho','communications',580,'Railroads: 2.6 km; owned, operated by, and
included in the statistics of South Africa
Highways:
total; 7,215 km
paved; 572 km
unpaved; gravel, stabilized earth 2.337 km;
improved earth 1 ,806 km; unimproved earth
2,500 km (1988)
Airports:
total; 28
usable; 28
with permanent-surface runways; 3
with runways over 3,659 m; 0
with runways 2,440-3,659 m; 1
with runways 1,220-2,439 m; 2
Telecommunications: rudimentary system
consisting of a few landlines, a small
microwave system, and minor radio
communications stations; 5,920 telephones;
broadcast stations — 3 AM, 2 FM, 1 TV; 1
Atlantic Ocean INTELSAT earth station
Defense Forces
Branches: Royal Lesotho Defense Force
(RLDF; including Army, Air Wing), Royal
Lesotho Mounted Police
Manpower availability: males age 15-49
438,096; fit for military service 236,324
Defense expenditures: exchange rate
conversion — $55 million, 13% of GDP (1990
est.)
2.30','e11a3bba57f7042f4454ae92c21a4bac6e2ca94995efe85fa415e9fbe2687d6c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcf5851bbb73c1d9aa03e57803652abd4bf532a53b362d448a7e04b759f1aa9c',1994,'LR','Liberia','communications',586,'Railroads: 480 km total; 328 km 1.435-meter
standard gauge, 152 km 1.067-meter narrow
gauge; all lines single track; rail systems
owned and operated by foreign steel and
financial interests in conjunction with Liberian
Map references: Africa, Standard Time
Zones of the World
Area:
total area: 7 1 ,740 sq km
land area: 7 1 ,620 sq km
comparative area: slightly smaller than South
Carolina
Land boundaries: total 958 km, Guinea 652
km, Liberia 306 km
Coastline: 402 km
Maritime claims:
territorial sea; 200 nm
International disputes; none
Climate; tropical; hot. humid; summer rainy
season (May to December); winter dry season
(December to April)
Terrain; coastal belt of mangrove swamps,
wooded hill country, upland plateau,
mountains in east
Natural resources; diamonds, titanium ore,
bauxite, iron ore. gold, chromite
Land use:
arable land; 25%
permanent crops; 2%
meadows and pastures: 31%
fore.u and woodland; 29%
other; 13%
Irrigated land: 340 sq km (1989 est.)','a3e83b75d2a426c0574231c3667449dfb90d73d2e41ba89199d00be53c7f7b9b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f0f3c3fdc4b67f2c94efe9d86a0f5d8bb2fc86d4afc7449a894ff6895cc2b1b',1994,'LY','Libya','communications',592,'Railroads: Libya has had no railroad in
operation since 1965, all previous systems
having been dismantled; current plans are to
construct a standard gauge (1.435 m) line from
the Tunisian frontier to Tripoli and Misratah,
then inland to Sabha, center of a mineral rich
area, but there has been no progress; other
plans made Jointly with Egypt would establish
a rail line from As Sallum, ^ypt to Tobruk
with completion set fbrmid-l9M. progress
unknown
Highways:
total: l9,3(X)km
paved.'' bituminous 10,800 km
unpaved: gravel, earth 8,500 km
Inland waterways: none
Pipelines: crude oil 4,383 km; natural gas
1,947 km; petroleum pntxlucts 443 km
(includes liquified petroleum gas 256 km)
Ports: Tobruk, Tripoli. Benghazi, Misratah,
Marsa al Burayqah, Ra’s Lanuf, Ra''s al Unif
Merchant marine: 31 ships (1,000 CRT or
over) totaling 690.703 GRT/1 ,2 1 1 . 1 84 DWT,
short-sea passenger 4, cargo 10, roll-on/roll-off
cargo 4, oil tanker 10, chemical tanker I.
liquefied gas 2
Airports:
total: 145
usable: 132
with permanent-surface runways; 57
with runways over J,659 m: 8
with runways Zs" tO-S,6S9 m: 28
with runways 1 ,220-2,439 m: 52
Teleconununicadons: modem
telecommunications system using radio relay,
coaxial cable, tropospheric scatter, and
domestic satellite stations; 370,000 telephones;
broadcast stations — 17 AM, 3 FM, 12 TV,
satellite earth stations — I Atlantic Ocean
INTELSAT, 1 Indnm Oce.m INTELSAT, and
14 domestic; submarine cables to France and
Italy; radio relay to Tunisia and Egypt;
tropospheric scatter to Greece; planned
ARABSAT and Intersputnik satellite stations
Defense Forces
Branches; Armed Peoples of the Libyan Arab
Jamahiriyah (including Army, Navy, Air and
Air Defense Command)
Manpower availability: males age 15-49
1 ,094.052; fit for military service 649,976;
reach military age (17) annually 52,723 (1994
est.)
Defense expendltnres: exchange rate
conversion — $3.3 billion. 15% of GDP (1989
est.)
Railroads: 2,1 15 km total; 465 km 1.435-
meter (standard) gauge: 1 ,650 km 1 .(KX)-meter
gauge
Highways:
total: 17,700 km
paved: bituminous 9,100 km
unpaved: improved, unimproved earth 8,600
km
Pipelines: crude oil 797 km, petroleum
products 86 km. natural gas 742 km
Ports: Bizerte. Gabes, Sfax, Sousse, Tunis, La
Goulette. Zarzis
Merchant marine: 23 ships ( 1 .000 GRT or
over) totaling 152,683 GRT/199,273 DWT,
short-sea passenger 1 . cargo 6, roll-on/roll-off
cargo 2, oil tanker 1 , chemical tanker 6,
liquefied gas I. bulk 6
Airports:
total: 31
unable: 27
with permanent-surface runways: 14
with runways over .?,659 m: 0
with runways 2,440- .1,6119 m: 9
with runways 1,220-2,4.19 m: 5
note: a new airport opened 6 May 1993, length
and type of surface NA
Telecommunications: the system is above
the African average; facilities consist of open-
wire lines, coaxial cable, and microwave radio
relay; key centers are .Sfax. Sousse. Bizerte,
and Tunis: 233.()(X) telephones (28 telephones
per 1.0(X) person- ); broadcast stations — 7 AM,
8 FM. 19 TV; 5 submarine cables; satellite
earth stations — I Atlantic Ocean INTELSAT
and I ARABSAT with back-up control station:
coaxial cable and microwave radio relay to
Algeria and Libya
Defense Forces
Branches; Army. Navy, Air Force,
paramilitary forces. National Guard
Manpower availability; males age 1 5-49
2.229,.362; fit for military service I.28I.OI5;
reach military age (20) annually 91,941 (1994
est.)
Defense expenditures: exchange rate
conversion — $618 million. 3.7% of GDP
(1993 est.)
400
Turkey
400 >m
Black Sea
Mediterranean
Sea''
Railroads: 8,429 km 1 .435-meter gauge
(including 795 km electrified)
Highways:
total: 320,61 1 km
paved: 27.0(X) km (including 138 km of
expressways)
unpaved: gravel 1 8,500 km; earth 275,1 1 1 km
(1988)
Inland waterways: about 1 ,200 km
Pipelines: crude oil 1,738 km, petroleum
products 2,32 1 km, natural gas 708 km
Ports: Iskenderun, Istanbul, Mersin, Izmir
Merchant marine: 390 ships ( 1 ,000 GRT or
over) totaling 4,664,205 GRT/8. 163,379
DWT, short-sea passenger 7, passenger-cargo
1 . cargo 195, container 2, roll-on/roll-off cargo
5, refrigerated cargo 2, livestock carrier I , oii
tanker 41, chemical tanker 10, liquefied gas 4,
combination ore/oil 1 2, specialized tanker 2,
bulk 103, combination bulk 5
Airports:
total: 1 1 3
usable: 105
with permanent-surface runways: 69
with runways over 3,659 m: 3
with runways 2,440-3.659 m: 32
with runways 1,220-2,439 m: Tl
Telecommunications: fair domestic and
international systems; trunk radio relay
microwave network; limited open wire
network; 3,400,0(X) telephones; broadcast
stations— 15 AM; 94 FM; .357 TV; I satellite
ground station operating in the INTELSAT (2
Atlantic Ocean antennas) and EUTELSAT
systems; I submarine cable
402','6ffcfef2c01a6348677e4383c5e2b68b932ff905c02385de063db32b64df09ff','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe381aac622581ce028a2617093b23e7912b47ebbbabcf8b31cd7d83da09aad2',1994,'LI','Liechtenstein','communications',598,'Railroads: 18.5 km l.4.35-n)elcr standard
gauge, electrified; owned, operated, and
included in statistics of Austrian Federal
Railways
Highways:
total; ,322.93 km
IHivetl; 322,93 km
Airports; none
Telecommunications; limited, but sufficient
automatic telephone system; 25.4(XI
telephones; linked to Swiss networks by cable
und radio relay for intcmutionul telephone,
radio, and TV services
Defense Forces
Note: defense is responsibility of Switzerland
235','d695ed49391f52830c9530bc72acc608f20f3d23346318914855c43050b8fa23','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c332ac6521ab639e5a6c02cf5d6bf9366e9f94bc36da9dee94b91869e091967b',1994,'LT','Lithuania','communications',599,'150 km
Railroads: 2,000 km ( 1, 524-mm gauge); 120
km electrified
Highways;
total: 44.200 km
paved: 35,500 km
unpaved: earth 8.700 km ( 1990)
Inland waterways: 600 km perennially
navigable
Pipelines: crude oil 105 km, natural gas 760
km (1992)
Ports: coastal — Klaipeda; inland — Kaunas
Merchant marine: 44 ships ( 1 .000 GRT or
over) totaling 276,265 GRT/323,505 DWT,
cargo 29. railcar carrier 3. roll-on/roll-off cargo
1. combination bulk II
Airports:
total: 96
usable: 18
with permanent-surface runways: 1 2
with runways over 3,659 m: 0
with ruttways 2,440-3,659 m: 5
with runways 1,060-2,439 m: 1 1
note: a C-130 can land on a 1,060-m airstrip
Telecommunications: Lithuania ranks
among the most modem of the former Soviet
republics in respect to its telecommunications
system; telephone subscriber circuits 900,000;
subscriber de;isity 240 per 1,000 persons; land
lines or microwave to former USSR republics;
international connections no longer depend on
the Moscow gateway switch, but are
established by satellite through Oslo from
Vilnius and through Copenhagen from Kaunas;
2 satellite earth stations — 1 EUTELSAT and 1
INTELSAT; an NMT-450 analog cellular
network operates in Vilnius and other cities
and is linked internationally through
Copenhagen by EUTELSAT: international
electronic mail is available;
broadcast stations — 13 AM, 26 FM, 1 SW, 1
LW, 3 TV
Defense Forces
Branches; Ground Forces, Navy, Air Force.
Security Forces (internal and border troops).
National Guard (Skat)
Manpower availability; males age 15-49
941 .273: fit for military service 744.867; reach
military age (18) annually 27,375 (1994 est.)
Defense expenditures: exchange rate
conversion — SNA, 5,5% of GDP (1993 est.)
237','1679afd1a67522279f5111ce731de47cf2f86d1436e5b74d2299b00c1ef8f906','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8009fc193319f851e968b5bc6f13dd3298e1a3f53890b8a6cfb424e21b17793',1994,'ZW','Zimbabwe','communications',615,'Railroads: 789 km 1.067-meter gauge
Highways:
total: 13,135 km
paved: 2,364 km
unpaved: gravel, crushed stone, stabilized
earth 25 1 km; earth, improved earth 10,520 km
Inland waterways: L^e Nyasa (Lake
Malawi); Shire River. 144 km
Ports: Chipoka, Monkey Bay, Nkhata Bay,
and Nkotakota — all on Lake Nyasa (Lake
Malawi)
Airports:
total: 47
usable; 41
with permanent-surface runways; 6
with runways over .3.659 m; 0
with runways 2,440-3,659 m: 1
with runways 1,220-2,439 m: 10
Telecommunications: fair system of open-
wire lines, radio relay links, and radio
communications stations: 42,250 telephones;
broadcast stations — 10 AM, 17 FM, no TV;
satellite earth stations — 1 Indian Ocean
INTELSAT and 1 Atlantic Ocean INTELSAT
Note: a majority of exports would normally
go through Mozambique on the Beira, Nucala,
and Limgogo railroads, but now most go
through South Africa because of insurgent
activity and damage to rail lines
Defense Forces
Branches: Army (including Air Wing end
Naval Detachment), Police (including
paramilitary Mobile Force Unit),
Manpower availability: males age 15-49
2,046,413; fit for military service 1,043,674
Defense expenditures; exchange rate
conversion — $22 million, 1 .6% of GDP ( 1 989
est.)
Railroads: 1 ,266 km, all 1 .067-meter gauge:
1 3 km double track
Highways:
total: 36.370 km
IHtved: 6,500 km
unpaved: crushed stone, gravel, stabilized
earth 7,000 km; improved, unimproved earth
22.870 km
Inland waterways: 2,250 km, including
Zambezi and Luapula Rivers. Lake
Tanganyika
Pipelines: crude oil 1.724 km
Ports; Mpulungu (lake port)
441
Zambia (continued)
Airports:
total: 113
usable: 103
with permanent-surface runways: 1 3
with runways over 3,659 m: 1
with runways 2,440-3,659 m: 4
with runways 1,220-2,439 m: 22
Telecommunications: facilities are among
the best in Sub-Saharan Africa; high-capacity
microwave connects most larger towns and
cities; broadcast stations — 1 1 AM, 5 FM, 9
TV; satellite earth stations — 1 Indian Ocean
INTELSAT and I Atlantic Ocean INTELSAT
Defense Forces
Branches: Army. Air Force, Police
Manpower availability: males age I S-49
1,882,053; fit for military service 988,913
Defense expenditures: exchange rate
conversion — $45 million, 1% of GDP (1992
esi.)
200 km
Railronds: 2,745 km 1.067 -meter gauge
(including 42 km double track, 355 km
electrified)
Highways:
total; 85,237 km
paved: 15,800 km
unpaved; cnished stone, gravel, stabilized
earth 39,090 km; improved earth 23,097 km;
unimproved earth 7,250 km
Inland waterways: Lake Kariba is a potential
line of communication
Pipelines: petroleum products 212 km
Airports:
total: 477
usable: 401
with permanent-sutface runways: 22
with runways over 3,6S9 m: 2
with runways 2,440-3,659 m: 3
with runways 1,220-2,439 m: 28
Telecommunications: system was once one
of the best in Africa, but now suffers from poor
maintenance; consists of microwave links,
open-wire lines, and radio communications
stations; 247,0(X) telephones; broadcast
stations — 8 AM, 1 8 F^, 8 TV; 1 Atlantic
Ocean INTELSAT earth station
Defense Forces
Branches: Zimbabwe National Army, Air
Force of Zimbabwe. Zimbabwe Republic
Police (including Police Support Unit,
Paramilitary Police)
Manpower availability: males 15-49
2,371,186; fit for military service 1,472,603
(1994 est.)
Defense expenditures: exchange rale
conversion— $4 12.4 million, about 6% of GDP
(FY91 est.)
443
Taiwan
special members — (2) Nauru, Tuvalu
Commonwealth of Independent States
(CIS)
members — (12) Armenia, Azerbaijan, Belarus, Georgia, Kazakhstan, Kyrgyzstan, Moldova,
Russia, Tajikistan, Turkmenistan. Ukraine, Uzbekistan
established — 8 December 1991
effective — 21 December 1991
aim — to coordinate intercommonwealth
relations and to provide a mechanism for the
orderly dissolution of the USSR
Communaute Economlque de I’AMque de
I’Ouest (CEAO)
see West African Economic Community (CEAO)
Communaute Economlque des Etats de
I’Afrique Centrale (CEEAC)
see Economic Community of Central African States (CEEAC)
Communaute Economlque des Pays des
Grands Lacs (CEPGL)
see Economic Community of the Great Lakes Countries (CEPGL)
Communist countries
traditionally the Marxist-Leninisi states with authoritarian governments and command economies
based on the Soviet model; most of the successor states are no longer Communist; see centrally
planned economies
Conference on Security and Cooperation
ill Europe (CSCE)
established — 3 July 1973
aim — discusses issues of mutual concern and
reviews implementation of the Helsinki
Agreement
members — (53) Albania. Armenia, Austria. Azerbaijan, Belarus. Belgium, Bosnia and
Herzegovina, Bulgaria. Canada, Croatia, Cyprus, Czech Republic. Denmark, Estonia, Finland,
France, Georgia, Germany. Greece, Holy See, Hungary, Iceland, Ireland, Italy, Kazakhstan,
Kyrgyzstan. Latvia, Liechtenstein, Lithuania. Luxembourg, Malta. Moldova, Monaco.
Netherlands, Norway. Poland. Portugal, Romania, Russia. San Marino. Slovakia, Slovenia.
Spain. Sweden, Switzerland. Tajikistan. Turkey. Turkmenistan. Ukraine. UK. US, Uzbekistan.
Yugoslavia (suspended)
obsen''er—( 1 ) The Former Yugoslav Republic of Macedonia
Conseil Europeen pour la Recherche
Nucleaire (CERN)
sec European Organization for Nuclear Research (CERN)
Contadora Group (CG)
was established 5 January 1983 (on the Panamanian island of Contadora) to reduce tensions and
contlicts in Central America but evolved into the Rio Group (RG); members included Colombia,
Mexico. Panama. Venezuela
Cooperation Council for the Arab States
of the Gulf
see Gulf Cooperation Council (GCC)
Coordinating Committee on Export
Controls (COCOIV1)
members — (17) Australia. Belgium, Canada, Denmark, France. Germany, Greece, Italy, Japan,
Luxembourg, Netherlands, Norway. Portugal, Spain. Turkey, UK, US
note — was abolished 31 March 1994;
COCOM members are working on u new
organization with expanded membership
which ftK''uses on nonproliferation export
controls as opposed to East-West controls of
advanced technology
cooperating countries — (14) Austria, Czech Republic, Finland, Hong Kong, Hungary, Ireland,
South Korea. NZ. Poland. Singapore. Slovakia. Sweden. Switzerland, Taiwan
established — NA 1949
aim — to control the export of strategic
products and technical data from member
countries to proscribed destinations
Council for Mutual Economic Assistance
(CEMA) also known as CMEA or
Comecon,
was established 25 January 1949 to promote the development of socialist economies and was
abolished 1 Jumiarv 1‘WI; members included Afghanistan (observer). Albania (hud not
participated ■•incc 1961 break with USSR), Angola (observer), Bulgaria. Cuba. Czechoslovakia,
Ethiopia (observer), (il)R. Hungary, Laos (observer), Mongolia. Mozambique (observer),
Nicaragua (observer). Poland. Romania, USSR, Vietnam, Yetnen (observer). Yugoslavia
(associate)
Council of Arab Economic Unity (CAEU)
established — 3 June 1957
effective — 30 May 1964
members — (11 plus the Palestine Liberation Organization) Egypt, Iraq, Jordan, Kuwait, Libya,
Mauritania, Somalia, Sudan, Syria, UAE, Yemen, Palestine Liberation Organization
aim — to promote economic integration
among Arab nations
Council of Europe (CE)
established — 5 May 1949
effective — 3 August 1949
aim — to promote increased unity and quality
of life in Europe
members — (32) Austria, Belgium, Bulgaria, Cyprus, Czech Republic, Denmark, Estonia,
Finland, France. Germany, Greece, Hungary, Iceland, Ireland, Italy, Liechtenstein, Lithuania,
Luxemlxturg, Malta, Netherlands, Norway, Poland, Portugal, Romania, San Marino, Slovakia,
Slovenia, Spain, Sweden, Switzerland, Turkey, UK
guests — (8) Albania, Belarus, Croatia, Latvia, Moldova, Russia, The Former Yugoslav Republic
of Macedonia, Ukraine
observers — (2) Holy See, Israel
Council of the Baltic Sea States (CBSS)
established — 5 March 1992
aim — to promote cooperation among the
Baltic Sea states in the areas of aid to new
democratic institutions, economic
development, humanitarian aid, energy and
the environment, cultural programs and
education, and transportation and
communication
members — (10) Denmark, Estonia, Finland, Germany, Latvia, Lithuania. Norway, Poland,
Russia, Sweden
observers — (2) Belarus, Ukraine
Council of the Entente (Entente)
members — (5) Benin, Burkina, Cote d’Ivoire, Niger, Togo
established — 29 May 1959
aim — to promote economic, social, and
political coordination
Customs Cooperation Council (CCC)
established — 15 December 1950
aim — to promote international cooperation in
customs matters
members — (126) Albania, Algeria, Angola, Argentina, Armenia, Australia, Austria. Azerbaijan.
The Bahamas, Bangladesh, Belgium, Bermuda, Botswana, Brazil, Bulgaria, Burkina. Burma,
Burundi, Cameroon, Canada, Cape Verde, Central African Republic, Chile, China, Congo, Cote
d''Ivoire, Cuba, Cyprus, Czech Republic, Denmark, Egypt, Estonia, Ethiopia, Finland, France,
Gabon, The Gambia, Germany, Ghana, Greece, Guatemala, Guinea, Guyana, Haiti, Hong Kong,
Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, South Korea, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania.
Luxembourg, Madagascar, Malawi, Malaysia, Mali. Malta, Mauritania, Mauritius, Mexico,
Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Niger, Nigeria, Norway,
Pakistan, Paraguay. Peru. Philippines. Poland, Portugal, Qatar, Romania, Russia, Rwanda. Saudi
Arabia, Senegal, Sierra Leone, Singapore, Slovakia, Slovenia, South Africa, Spain. Sri Lanka,
Sudan, Swaziland, Sweden, Switzerland, Syria, Tanzania, Thailand, Togo, Trinidad and Tobago,
Tunisia, Turkey. Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Yugoslavia, Zaire,
Zambia, Zimbabwe
developed countries (DCs)
the top group in the comprehensive but mutually exclusive hierarchy of developed countries
(DCs), former USSR/Eastem Europe (former USSR7EE), and less developed countries (LDCs);
includes the market-oriented economies of the mainly democratic nations in the Organization for
Economic Cooperation and Development (OECD), Bermuda, Israel, South Africa, and ine
European ministates; also known as the First World, high-income countries, the North, industrial
countries; generally have a per capita GNF/GDP in excess of SlO.tXX) although four OECD
countries and South Africa have figures well under $10,000 and two of the excluded OPEC
countries have Figures of more than $10,000; the 35 DCs are: Andorra, Australia, Austria.
Belgium, Bermuda. Canada, Denmark, Faroe Islands, Finland, France. Germany, Greece, Holy
See, Iceland, Ireland, Israel, Italy, Japan, Liechtenstein, Luxembourg, Malta, Mexico. Monaco,
Netherlands, NZ, Norway. Portugal, San Marino, South Africa, Spain, Sweden, Switzerland,
Turkey. UK, US
developing countries
an imprecise term for the less developed countries n .th growing economies; see less developed
countries (LDCs)
East African Development Bank (EADB)
members— [3) Kenya, Tanzania, Uganda
established — 6 June 1967
effective — 1 December 1967
aim — to promote economic development
458
Economic and Social Commission for Asia members — (48) Afghanistan, Australia, Azerbaijan, Bangladesh, Bhutan, Brunei, Burma,
and the Pacific (ESCAP) Cambodia, China, Fiji, France, India, Indonesia, Iran, Japan, Kazakhstan, Kiribati, North Korea,
South Korea, Kyrgyzstan, Laos, Malaysia, Maldives, Marshall Islands, Federated States of
established — 28 March 1947 as Economic Micronesia, Mongolia, Nauru, Nepal, Netherlands, NZ, Pakistan, Papua New Guinea,
Commission for Asia and the Far East Philippines, Russia, Singapore, Solomon Islands, Sri Lanka, Tajikistan, Thailand, Tonga,
(ECAFE) Turkmenistan, Tuvalu, OK, US, Uzbekistan, Vanuatu, Vietnam, Western Samoa
aim — to carryout the commitment of the associate members— (10) American Samoa, Cook Islands, French Polynesia, Guam, Hong Kong,
Economic and Social Council of the UN to Macau, New Caledonia, Niue, Northern Mariana Islands, Trust Territory of the Pacific Islands
promote economic development (Palau)
Economic and Social Commission for members — (12 plus the Palestine Liberation Organization) Bahrain, Egypt, Iraq, Jordan, Kuwait,
Western Asia (ESCWA) Lebanon, Oman, Qatar, Saudi Arabia, Syria, UAE, Yemen, Palestine Literation Organization
established — 9 August 1973 as Economic
Commission for Western Asia (ECWA)
aim — to promote economic development as
a regional commission for the UN’s
Economic and Social Council _
Economic and Social Council (ECOSOC) members — (54) selected on a rotating basis from all regions
established — 26 June 1945
effective — 24 October 1945
aim — to coordinate the economic and social
work of the UN; includes five regional
commissions (see Economic Commission for
Africa, Economic Commission for Eurofie,
Economic Commission for Latin America
and the Caribbean, Economic and Social
Commission for Asia and the Pacific,
Economic and Social Commission for
Western Asia) and six functional
commissions (see Commission for Social
Development, Commission on Human
Rights, Commission on Narcotic Drugs,
Commission on the Status of Women,
Population Commission, Statistical
Commission, Commission on Science and
Technology for Development, Commission
on Sustainable Development, Commission
on Crime Prevention and Criminal Justice,
and Commission on Transnational
Corporations) _
Economic Commission for Africa (ECA)
established — 29 April 1958
aim — to promote economic development as
a regional commission of the UN’s
Economic and Social Council
associate members — (2) France, UK
Economic Commission for Asia and the see Economic and Social Commission for Asia and the Pacific (ESCAP)
Far East (ECAFE) _
Economic Commission for Europe (ECE) members — (54) Albania. Andorra, Armenia, Austria, Azerbaijan. Belarus, Belgium, Bosnia and
Herzegovina, Bulgaria. Canada. Croatia. Cyprus, Czech Republic, Denmark, Estonia, Finland,
established —2^ March 1947 France. Georgia, Germany, Greece. Hungary, Iceland, Ireland, Israel, Italy, Kazakhstan,
Kyrgyzstan, Latvia, Liechtenstein, Lithuania, Luxembourg, Malta, Moldova, Monaco,
aim — to promote economic development as Netherlands, Norway. Poland. Portugal. Romania. Russia. San Marino. Slovakia. Slovenia,
a regional commission of the UN’s Spain, Sweden, Switzerland. The Former Yugo.slav Republic of Macedonia, Turkey,
Economic and Social Council Turkmenistan, Ukraine, UK. US, Uzbekistan, Yugoslavia
Economic Commiiision for Latin .America see Economic Commission for Latin America and the Caribbean (ECLAC)
(ECLA)
members — (53) Algeria, Angola, Benin, Botswana, Burkina, Burundi, Cameroon, Cape Verde,
Central African Republic, Chad. Comoros, Congo, Cote d’Ivoire, Djibouti, Egypt, Equatorial
Guinea. Eritrea, Ethiopia. Gabon. The Gambia. Ghana. Guinea. Guinea-Bissau, Kenya. Le.sotho,
Liberia, Libya, Madagascar, Malawi, Mali. Mauritania, Mauritius, Morocco, Mozambique,
Namibia, Niger, Nigeria, Rwanda, Sao Tome and Principe, Senegal, Seychelles, Sierra Leone,
Somalia, South Africa (suspended), Sudan, Swaziland. Tanzania, Togo, Tunisia, Uganda, Zaire,
Zambia, Zimbabwe
Economic Commission for Latin America
and the Caribbean (ECLAC)
established — 25 February 1948 as Economic
Commission for Latin America (ECLA)
aim — to promote economic development as
a regional commission of the UN’s
Economic and Social Council _
Economic Commission for Western Asia
(ECWA) _
Economic Community of Central African
States (CEEAC)-acronym from
Communaute Economique des Etats de
I’Afrique Centrale
established — 18 October 1983
aim — to promote regional economic
cooperation and establish a Central African
Common Market
Economic Community of the Great Lakes
Countries (CEPGL)
note — acronym from Communaute
Economique des Pays des Grands Lacs
established — 26 September 1976
aim — to promote regional economic
cooperation and integration
Economic Community of West African
Slates (ECOWAS)
established— May 1975
aim — to promote regional economic
cooperation _
Economic Cooperation Organization
(ECO)
established — NA 1985
aim — to promote regional cooperation in
trade, transportation, communications,
tourism, cultural affairs, and economic
development
European Bank for Reconstruction and
Development (EBRD)
established — 15 April 1991
aim — to facilitate the transition of seven
centrally planned economies in Europe
(Bulgaria, former Czechoslovakia, Hungary,
Poland. Romania, former USSR, and former
Yugoslavia) to market economies by
committing 60% of its loans to privatization
European Community (or Europep”
Communities, EC)
members — (41) Antigua and Barbuda, Argentina, The Bahamas, Barbados, Belize, Bolivia,
Brazil. Canada, Chile, Colombia, Costa Rica, Cuba, Dominica, Dominican Republic, Ecuador,
El Salvador, France, Grenada, Guatemala, Guyana, Haiti, Honduras, Italy, Jamaica, Mexico,
Netherlands, Nicaragua, Panama, Paraguay, Peru, Portugal, Saint Kitts and Nevis, Saint Lucia,
Saint Vincent and the Grenadines, Spain, Suriname, Trinidad and Tobago, UK, US, Uruguay,
Venezuela
associate members — (6) Amba, British Virgin Islands, Montserrat, Netherlands Antilles, Puerto
Rico, Virgin islands
see Economic and Social Commission for Western Asia (ESCWA)
members — (10) Burundi, Cameroon, Central African Republic, Chad, Congo, Equatorial Guinea,
Gabon, Rwanda, Sao Tome and Principe, Zaire
obsen''er — (1) Angola
members — (3) Burundi, Rwanda, Zaire
members — (16) Benin, Burkina, Capo Verde, Cote d’Ivoire, The Gambia, Ghana, Guinea,
Guinea-Bissau, Liberia, Mali, Mauritania, Niger, Nigeria, Senegal, Sierra Leone, Togo
members — (II) Afghanistan, Azerbaijan, Iran, Kazakhstan, Kyrgyzstan, Pakistan, Tajikistan,
Turkey, “Turkish Republic of Northern Cyprus,’’ Turkmenistan, Uzbekistan
members — (58) Albania, Armenia, Australia, Austria, Azerbaijan. Belgium, Bulgaria, Canada,
Cyprus, Czech Republic, Denmark, Egypt, European Community (EC), European Investment
Bank (EIB), Estonia, Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Ireland,
Israel, Italy, Japan, Kazakhstan, South Korea, Kyrgyzstan, Latvia, Liechtenstein, Lithuania,
Luxembourg, Malta, Mexico, Moldova, Morocco, Netherlands, NZ, Norway, Poland, Portugal,
Russia, Romania, Slovakia, Slovenia, Spain, Sweden. Switzerland, Tajikistan, The Former
Yugoslav Republic of Macedonia, Turkey, Turkmenistan, Ukraine, UK, US, Uzbekistan,
Yugoslavia; note — includes all 25 members of the OECD; also includes the EC as a single
entity
was established 8 April 1965 to integrate the European Atomic Energy Community (Euratom),
the European Coal and Steel Community (ESC), the Euroean Economic Community (EEC or
Common Market), and to establish a completely integrated common market and an eventual
federation of Europe; merged into the European Union (EU) on 7 February 1992; member states
at the time of merger were Belgium, Denmark, France, Germany, Greece, Ireland, Italy,
Luxembourg, Netherlands, Portugal, Spain, UK _
460
European Free ''Trade Association (EFTA) members — (7) Austria, Finland, Iceland, Liechtenstein, Norway, Sweden, Switzerland
established — 4 January I960
effective — 3 May 1960
aim — to promote expansion of free trade
European Investment Bank (EIB)
established — 25 March 1957
members — (12) Belgium, Denmark, France, (jermany, Greece, Ireland, Italy, Luxembourg,
Netherlands, Portugal, Spain, UK
effective — 1 January 1958
aim — to promote economic development of
the EU
European Organization for Nuclear
Research (CERN)
note — acronym retained from the
predecessor organization Conseil European
pour la Recherche Nucleaire
members — (19) Austria, Belgium, Czech Republic, Denmark, Finland, France, Germany, Greece,
Hungary, Italy, Netherlands, Norway, Poland, Portugal, Slovakia, Spain, Sweden, Switzerland,
UK
observers — (6) EC, Israel, Russia, ''Turkey, United Nations Educational, Scientific, and Cultural
Organization (UNESCO), Yugoslavia
established — 1 July 1953
effective — 29 September 1954
aim — to foster nuclear research for peaceful
purposes only
European Space Agency (ESA)
established — 31 July 1973
effective — 1 May 1975
aim — to promote peaceful cooperation in
space research and technology _
European Union (EU)
note— evolved from the European
Community (EC)
members — (13) Austria, Belgium, Denmark, France, Germany, Ireland, Italy, Netherlands,
Norway, Spain, Sweden, Switzerland, UK
associate member — (I) Finland
cooperating state — ( 1 ) Canada
members — (12) Belgium, Denmark, France, Germany, Greece, Ireland, Italy, Luxembourg,
Netherlands, Portugal, Spain, UK
established — 7 February 1992
effective — I November 1993
aim — to coordinate policy among the 12
members in three fields: economics, building
on the European Economic Community''s
(EEC) efforts to establish a common market
and eventually a common currency; defense,
within the concept of a Common Foreign
and Security Policy (CFSP); and justice and
home affairs, including immigration, drugs,
terrorism, and improved living and working
conditions
First World another term for countries with advanced, industrialized economies; this term is fading from
use; see developed countries (DCs)
461
Food and Agriculture Organization (FAO)
established — 16 October 1945
a/m— UN specialized agency to raise living
standards and increase availability of
agricultural products
Former USSR/Eastern Europe (former
USSR/EE)
Four Dragons
Four Tigers _
Franc Zone (FZ)
established — NA
aim— to form a monetary union among
countries whose currencies are linked to the
French franc _
Front Line States (FLS)
established — NA
aim — to achieve black majority rule in South
Africa
General Agreement on Tariffs and TVade
(GATT)
established — 30 October 1947
effective — 1 January 1948
aim — to promote the expansion of
international trade on a nondiscriminatory
basis
Group of 2 (G-2)
established — informal term that came into
use about 1986
members — (162) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina,
Australia, Austria, The Bahamas, Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin,
Bhutan, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina, Burma, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic. Chad, Chile. China, Colombia,
Comoros, Congo, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Estonia,
Ethiopia, EC, Fiji, Finland, France, Gabon. The Gambia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, North Korea, South
Korea. Kuwait, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico,
Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria,
Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra bsone, Slovakia,
Solomon Islands, Somalia. Spain, Sri Lanka. Sudan, Suriname, Swaziland, Sweden, Switzerland,
Syria, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey. Uganda, UAE,
UK. US, Uruguay, Vanuatu, Venezuela, Vietnam. Western Samoa, Yemen, Yugoslavia
(suspended), Zaire, Zambia, Zimbabwe
associate member — ( I ) Puerto Rico
the middle group in the comprehensive but mutually exclusive hierarchy of developed countries
(DCs), former USSR/Eastem Europe (former USSR/EE), and less developed countries (LDCs);
these countries are in political and economic transition and may well be grouped differently in
the near future: this group of 27 countries consists of Albania. Armenia. Azerbaijan, Belarus,
Bosnia and Herzegovina, Bulgaria. Croatia, Czech Republic, Estonia, Georgia. Hungary,
Kazakhstan, Kyrgyzstan. Latvia. Lithuania, Moldova. Poland, Romania. Russia. Serbia and
Montenegro, Slovakia. Slovenia, Tajik','89b7a3a4b57825d3b19436971a610b1b4031139cb7464076c4b73f33add9a767','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2de0bc1612b61909c6eff1c62b36571ad23825070060c47992c52a4a53fbf450',1994,'ZW','Zimbabwe','communications',616,'istan, The Former Yugoslav Republic of Macedonia,
Turkmenistan, Ukraine, Uzbekistan
the four small Asian less developed countries (LDCs) that have experienced unusually rapid
economic growth; also known as the Four Tigers; this group includes Hong Kong, South Korea.
Singapore, Taiwan
another term for the Four Dragons; see Four Dragons
members— {\\S) Benin. Burkina. Cameroon, Central African Republic, Chad, Comoros. Congo.
Cote d''Ivoire, Equatorial Guinea. France. Gabon. Mali, Niger, Senegal. Togo: note — France
includes metropolitan France, the four overseas departments of France (French Guiana,
Guadeloupe, Martinique, Reunion), the two territorial collectivities of France (Mayotte, Saint
Pierre and Miquelon), and the three overseas territories of France (French Polynesia. New
Caledonia, Wallis and Futuna)
members— (7) Angola, Botswana. Mozambique. Namibia, Tanzania, Zambia, Zimbabwe
me/Mberv— (1 17) Antigua and Barbuda. Argentina. Australia, Austria, Bahrain. Bangladesh,
Barbados, Belgium, Belize. Benin, Bolivia, Botswana, Brazil. Brunei. Burkina, Burma, Bumndi,
Cameroon. Canada. Central African Republic. Chad, Chile, Colombia, Congo, Costa Rica. Cote
d’Ivoire, Cuba, Cyprus, Czech Republic. Denmark. Dominica, Dominican Republic, Egypt, El
Salvador, Fiji. Finland, France. Gabon, The Gambia, Germany, Ghana. Greece, Grenada,
Guatemala, Guyana. Haiti, Hong Kong. Hungary. Iceland. India, Indonesia, Ireland. Israel, Italy,
Jamaica, Japan, Kenya. South Korea, Kuwait, Lesotho, Luxembourg. Macau, Madagascar,
Malawi, Malaysia, Maldives, Mali. Malta, Mauritania, Mauritius, Mexico, Morocco,
Mozambique. Namibia. Netherlands. NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan,
Paraguay, Peru, Philippines. Poland, Portugal. Romania, Rwanda, Saint Lucia. Saint Vincent and
the Grenadines, Senegal, Sierra Leone. Singapore, Slovakia. South Africa. Spain, Sri Lanka,
Suriname. Swaziland, Sweden, Switzerland, Tanzania. Thailand, Togo, Trinidad and Tobago,
Tunisia, Turkey, Uganda. UAE. UK. US. Uruguay, Venezuela, Yugoslavia (suspended), Zaire,
Zambia. Zimbabwe
members — (2) Japan. US
aim — bilateral economic cooperation
between the two most powerful economic
giants
Group of 3 (G*3)
established — NA October 1990
aim — mechanism for policy coordination
members — (3) Colombia, Mexico, Venezuela
Group of S (G-S)
established — 22 September I98S
aim — to coordinate the economic policies of
the five major non-Communist economic
powers
members — (5) France, Germany, Japan, UK, US
Group of 6 (G-6)
note — also known as Groupe des Six Sur le
Desarmement not to be confused with the
Big Six
established — 22 May 1984
members — (6) Argentina, Greece, India, Mexico, Sweden, Tanzania
aim — to achieve nuciear disarmament
Group of 7 (G>7)
note — membership is the same as the Big
Seven
established — 22 September 1985
aim — to facilitate economic cooperation
among the seven major non-Communist
economic powers
members — (7) Group of 5 (France, Germany, Japan, UK, US) plus Canada and Italy
Group of 8 (G-8)
established — NA October 1975
aim — to facilitate economic cooperation
among the developed countries (DCs) that
participated in the Conference on
International Economic Cooperation (CIEC),
held in severai sessions between NA
December 1975 and 3 June 1977
members — (8) Australia, Canada, EU (as one member), Japan, Spain, Sweden, Switzerland, US
Group of 9 (G-9)
established — NA
aim — informal group that meets occasionally
on matters of mutual interest
members — (9) Austria, Belgium. Bulgaria. Denmark, Finland. Hungary, Romania. Sweden.
Yugoslavia
Group of 10 (G-10)
note — also known as the Paris Club,
wealthiest members of the IMF who provide
most of the mone^ to be loaned and act as
the informal steenng committee; name
persists in spite of the addition of
Switzerland on NA April 1984
established — NA October 1962
members — (11) Belgium, Canada, France, Germany, Italy, Japan, Netherlands, Sweden,
Switzerland, UK, US
aim — to make credit policy
Group of 11 (G-11)
note — also known as the Cartagena Group
established — 22 June 1984, in Cartagena,','fea530faf9adb5f2e60a20bdaf2aa2ce081e99f36e7e16b46aa160d202ef06c2','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd32bbc8bf27008afbfc749a5bbed293ebca3445d53b64e7ce939dd04b9bd713',1994,'MT','Malta','communications',634,'Highways:
total: 1.291 km
paved: asphalt 1 . 1 79 km
unpaved: gravel, crushed stone 77 km; earth 35
km
Ports: Valletta. Marsaxlokk
Merchant marine: 897 ships ( 1 ,000 GRT or
over) totaling 13.959,195 GRT/24,038.587
250
DWT, passenger 6, short-sea passenger 19,
cargo 296, container 26, passenger-cargo 3,
roll-on/roll-off cargo 20, vehicle carrier 9,
barge carrier 3, refrigerated cargo 1 7, chemical
tanker 2S, combination ore/oil 18, specialized
tanker 5, liquefied gas 2, oil tanker 157, bulk
259, combination bulk 28, multifunction large
load carrier 3, railcar carrier 1
note: a flag of convenience registry; China
owns 1 1 ships, Russia owns 42 ships, Cuba
owns 10, Vietnam owns 6, Croatia owns 63,
Romania owns 4
Airports:
total: I
usable: I
with permanent-surface runways: I
with runways over 3,659 m: 0
with runways 2.440-3.659 m: 1
with runways 1,220-2,439 m: 0
Telecommunications: automatic system
satisfies normal requirements; 153,000
telephones; excellent service by broadcast
stations — 8 AM, 4 FM, and 2 TV; submarine
cable and microwave radio relay between
islands; international service by I submarine
cable and I Atlantic Ocean INTELSAT earth
station
Defense Forces
Branches: Armed Forces, Maltese Police
Force
Manpower availability: males age 15-49
98,241; fit for military service 78,071
Defense expenditures: exchange rate
conversion — $2 1 .9 million, 1 .3% of GDP
(I989cst.)
Man, Isle of
(British crowtt dependency)','48c136f2ab120384801acb3bca8f14e049a2fc1677bd9d873ea0cb33d4be42a1','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49b4f142885811e0979f2c765aa1994c60e4ffd3a7557ff1d885638e86b7d680',1994,'MH','Marshall Islands','communications',637,'Railroads: 60 km; 46 ktn electric track. 24 km
steam truck
Highways:
total: 640 km
paved: NA
unpovvd: NA
Ports: Douglas, Ramsey. Peel
Merchant marine: 67 ships (l,0(X) GRT or
over) totaling 1,3.59.95 1 GRT/2..4 1 6.628
DWT, cargo 10, container 5, roll-on/roll-off
cargo 9, oil tanker 17, chemical tanker 5.
liquefied gas 7, bulk II. vehicle currier 3
note: a captive register of the United Kingdom,
although not all ships on Ihe register are British
owned
Airports:
total: 1
usable: I
with permanent-surface runways: I
with runways over J,6SV m: 0
wil/i runways 2,440-3,659 m: 0
with runways 1,220-2,4.^9 m: 1
Telecommunications: 24.435 telephones;
broadcast stations — 1 AM. 4 FM. 4 TV
300 km
North Pacific Ocaan
Enewtiak Bikmi ,
Taongi
^ikar
o
Malang
ifi • '' Taki''
^ongefp
K wataiem^ l
Nami^
MAJUnO^
^Ma/ura
Jaluit
^ban
Defense Forces
Highways:
total: NA
note: paved roads on major islands (Majuro,
Kwajalcin), otherwise stone-, coral-, or
laterite-surfaced roads and tracks
Ports: Majuro
Merchant marine: 40 ships ( 1 ,000 CRT or
over) totaling 2,255.348 GRT/4,35 1 ,997
DWT, cargo 2, container I, oil tanker 13, bulk
carrier 23, combination ore/oil I
note: a flag of convenience registry
Airports:
total: 16
usable: 16
with permanent-surface runways: 4
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 0
with runways 1,220-2,439 m: 8
Telecommunications: telephone network —
570 lines (Majuro) and 186 (Ebeye); telex
services; islands interconnected by shortwave
radio (used mostly for government purposes);
broadcast stations — I AM. 2 FM, I TV, 1
shortwave; 2 Pacific Ocean INTELSAT earth
stations; US Government satellite
communications .system on Kvvajalein
Defense Forces
Note: defense is the responsibility of the US
253','4705055ada3fd6f2a4fa8c22feecbb94ef8b7a9b3f1bac0910b79e4a4c371a65','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7432e5671f7cc80af08544549b6c83d068ed83af2037b5b50bbb5ea4d76f2342',1994,'MR','Mauritania','communications',646,'Highways:
total: 1 ,680 km
paved: 1,300 km
unpaved: gravel, earth 380 km
Ports: Fort-de-France
Airports:
total: 2
usable: 2
with permanent-surface runways: 1
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 1
with runways 1,220-2,439 in: 0
Telecommunications: domestic facilities are
adequate; 68,900 telephones: interisland
microwave radio relay links to Guadeloupe.
Dominica, and Saint Lucia; broadcast
stations — I AM, 6 FM, 10 TV; 2 Atlantic
Ocean INTELSAT earth stations
Defense Forces
Branches: French Forces. Gendarmerie
Note: defense is the responsibility of France
jgsim.
tVortfi
Att»nti‘
Oc0»n','d687c44ee19c65225f8b4381624d5cb7a863a60965ba6a139934b65df5787e80','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cabcb487572ba6bee55325e1ef1b715c8460d971e18e6f4db17e500b66fa4970',1994,'MU','Mauritius','communications',652,'Railroads: 690 km 1 .435-meter (standard)
gauge, single track, owned and operated by
government mining company
Highways:
total; 7,525 km
paved: 1 ,685 km
unpaved; gravel, crushed stone, otherwise
improved 1,040 km; unimproved earth 4,800
km (roads, trails, tracks)
Inland waterways: mostly ferry traffic on the
Senegal River
Ports: Nouadhibou, Nouakchott
Merchant marine: I cargo ship ( 1 ,000 CRT
or over) totaling 1,290 GRT/1,840 DWT
Airports:
total: 28
usable; 28
with pemanem-sutface runways: 9
with runways over 3,659 in; 0
with runways 2.440-3,659 m; 5
with runways 1,220-2,439 m; 17
Telecommunications: poor ,system of cable
and open-wire lines, minor microwave radio
relay links, and radio communications stations
(improvements being made); broadcast
stations — 2 AM, no FM, I TV; satellite earth
stations — I Atlantic Ocean INTELSAT and 2
ARABSAT, with six planned
Defense Forces
Branches: Army, Navy, Air Force, National
Gendarmerie, National Guard, National Police,
Presidential Guard
Manpower availability: males age 15-49
467,677; fit for military service 228,385
Defense expenditures: exchange rate
conversion — $40 million, 4.2% of GDP ( 1 989)
inditn
Oe««n
Indian
Ocman
IfifcflL
Apaitfl* (ilMdt, Cifga. ''-a
CttajQg SboiJs. and
RotfrifluM at* nol mown
Highways:
total: 1.800 km
paved: 1,640 km
unpaved; earth 160 km
Ports: Port Louis
Merchant marine: 1 4 ships ( 1 ,000 GRT or
over) totaling 162.387 GRT/260,552 DWT,
cargo 7, liquefied gas I, bulk 6
Airports;
total; 5
usable: 4
with permanent-surface runways; 2
with runways over 3,659 m: 0
with runways 2,440-3.659 m: 1
with runways 1,220-2,439 m: 0
Telecommunications: small system with
good service utilizing primarily microwave
radio relay; new microwave link to Reunion;
high-frequency radio links to several countries;
over 48,000 telephones: broadcast stations — 2
AM.noFM,4TV; 1 Indian Ocean INTELSAT
earth station
Defense Forces
Branches: National Police Force, including
the paramilitary Special Mobile Force (SMF),
Special Support Units (SSU), and National
Coast Guard
Manpower availability; males age 15-49
316,975; fit for military service 161,634
Defense expenditures; exchange rate
conversion — $5 million, 0.2% of GDP (FY89)
258','ff305edd7f568d768a6a223cd9e82ea4ea85dce5d1ee3b68000926d53a30b7c0','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('791f661d9c92d615b6167c06f590b7d08494eaeb3e65cc09bf52f20411432912',1994,'MX','Mexico','communications',661,'Highways:
total: 42 km
paved: bituminous 18 km
unpaved: 24 km
Ports: Dzaoudzi
Airports:
total: I
usable: I
with permanent-surface runways: 1
with runways over },659 m: 0
with runways 2,440-.^,659 m: 0
with runways 1,220-2,439 m: 1
Telecommunications: small system
administered by French Department of Posts
and Telecommunications; includes radio relay
and high-frequency radio communications for
links to Comoros and international
communications: 450 telephones; broadcast
stations — 1 AM, no FM, no TV
Defense Forces
Note; defen.se is the responsibility of France
OCMf)
Land boundaries: total 3,8 1 8 km, Cambodia
982 km, China 1,281 km, Laos 1,555 km
Coustliiie: 3,444 km (excludes islands)
Marldme claims;
contiguous zone: 24 nm
continental shelf: 200 nm or the edge of
coctinental margin
exclusive economic zone: 200 nm
territorial sea: 12 nm
International disputes; maritime boundary
with Cambodia not defined; involved in a
complex dispute over the Spratly Islands with
China, Malaysia, Philippines, Taiwan, and
possibly Brunei; unresolved maritime
boundary with Thailand; maritime boundary
dispute with China in the Gulf of Tonkin;
r.., Paracel Islands occupied by China but claimed
by Vietnam and Taiwan
Climate; tropical in south: monsoonal in
north with hot, rainy season (mid-May to mid-
September) and warm, dry season (mid-
October to mid-March)
Terrain; low. flat delta in south and north;
central highlands; hilly, mountainous in far
north and northwest
Natural resources; phosphates, coal,
manganese, bauxite, chromate, offshore oil
deposits, forests
Land use;
arable land: 22%
permanent crops: 2%
meadows and pastures: I %
forest and woodland: 40%
other: 35%
Irrigated land: 18,300 sq km (1989 esi.)
Highways;
total: 856 km
pctved; NA
unpaved: NA
Ports: Saint Croix— Christiansted,
Frederiksted; Saint Thomas — ''Long Bay,
Crown Bay. Red Hook; Saint John — Cruz Bay
Airports;
total: 2
usable: 2
with permanent-surface runways : 2
with runways over 3,659 m: 0
with runways 2.440-3,659 in; 0
with runways 1,220-2,439 m: 2
note: international airports on Saint Thomas
and Saint Croix
Telecommunications: modem telephone
system usnii’ fiber-optic cable, submarine
cable, microwave radio, and satellite facilities;
58,93 1 telephones; 98,000 radios; 63,000 TV
sets in use; broadcast stations — 4 AM, 8 FM, 4
TV (1988)
Defense Forces
Note: defense is the responsibility of the US
428
Wake Island
(territory of the US)','0f9f00f27ed4a6986acba8ea4fd14f96c273d49b65d34f25d51b7d91d45dbbfe','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f88ace0cd3afe8587e845f5374b557130ca1f2a21832c356b4e9bb59e7d2c416',1994,'FM','Micronesia, Federated States of','communications',667,'Highways;
total: 226 km
/nived: 39 km (on major islands)
uiifuived: stone, coral, luteriie 187 km
Ports; Colonia (Yap). Truk. Okat and l4:lu
t Kosrae)
Airports;
total: 6
usable: 5
with permanent-surface runways: 4
with runways over .t,6.59 m: 0
with runways m: 0
with runways l.220-2.4J*4 m: 4
Telecommunicutions: telephone network—
960 telephone lines total at Kolonia and Truk;
islands interconnected by shortwave radio
(used mostly for government purposes);
16, (XX) radio receivers, 1,125 TV sets (est.
l987);broadcaststations— 5 AM, 1 FM,6TV.
1 shortwave: 4 Pacific Ocean INTELSAT earth
stations
Defense Forres
Note: defense is the responsibility of the US
Midway Islands
(Icrritofy nf the US)
3 km
Highways:
total: 32 km
paved: NA
Pipelines: 7.8 km
Ports: Sand Island
Airports:
total: 3
u.sable: 2
with permanent-surface runways: 1
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 0
with runways 1,220-2,439 m: I
Defense Forces
Note: defense is the responsibility of the US
Moldova','e5e09daea7dec0aa60e2a62ada4679d3f05d211c629e54aa586b0ce3c508fa69','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bcf54ac706af3e77175325181f1c9da95f278c63ef4204d1f272ded93031d151',1994,'MC','Monaco','communications',669,'Railroads; 1 , 1 30 km; does not include
industrial lines (1990)
Highways:
total; 20,000 km
paved or gravelied: 1 3,900 km
unpaved; earth6,IOOkm(l 990)
Pipelines: natural gas 3 10 km ( 1 992)
Ports: none; landlocked
Airports:
total: 26
usabie; 15
with permanent-sutface runways: 6
with runways over 3.659 m: 0
with runways 2,440-3,659 m: 5
with runways 1,060-2,439 m: 8
note: a C- 1 30 can land on a l,060-m airstrip
Telecommunications: The
telecommunication system of Moldova is not
well developed; number of telephone
sub.scribers 577,000 (1991 ); number of
subscribers per 1 ,0(X) persons 1 34 ( 1 99 1 );
number of unsuccessful requests for telephone
service 215,000(1991); international
connections to the other former Soviet
republics by land line and microwave radio
relay through Ukraine, and to other countries
by leased connections to the Mo.scow
international gateway switch; 2 satellite earth
stations— I EUTELSATand 1 INTELSAT;
broadcast services NA
Defense Forces
Branches: Ground Forces, Air and Air
Defence Force, Security Forces (internal and
border troops)
Manpower availability: males age 13-49
1,098,156; fit for military service 869,866;
reach military age (18) annually 35,814 (1994
est.)
Defense expenditures: exchange rate
conversion — SNA, NA% of GDP
Railroads: 1.6 km 1.435-meter gauge
Highways: none; city streets
Ports: Monaco
Merchant marine: I oil tanker ( 1 ,000 GRT
or over) totaling 3,268 GRT/4,959 DWT
Airports: I usable airfield with permanent-
surface runways
Telecommunications: served by cable into
the French communications system; automatic
telephone system; 38,200 telephones;
broadcast stations — 3 AM, 4 FM, 5 TV; no
communication satellite earth stations
Defense Forces
Note: defense is the responsibility of France
267','323dbce31fcfe7a4c7b972eb10c444db557f83329c4a9d7b156283a1449d4478','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a17af2085cac2571724cac615143ca8402a72f330144050d20b363776afd501f',1994,'MN','Mongolia','communications',674,'tww.
Railroads: 1,750 km 1. 524-meter broad
gauge (1988)
Highways:
total; 46,700 km
paved: 1,000 km
unpaved; 45,7(X) km (1988)
Inland waterways: 397 km of principal
routes (1988)
Ports; none; landlocked
Airports;
total: 8 1
usable: 3 1
with permanent-surface runways: 1 1
with runways over J,659 m: fewer than 5
with runways 2,440-3,659 fewer than 20
with runways i ,220-2,439 m: 12
Telecommunications: 63,000 telephones
(1989); broadcast .stations — 12 AM. 1 FM. I
TV (with 18 provincial repeaters); repeat of
Russian TV; 120,000 TVs; 220,000 radios; at
least I earth station
Defense Forces
Branches: Mongolian People''s Army
(includes Internal Security Forces and Frontier
Guards), Air Force
Manpower availability: males age 15-49
587, 1 1 3; fit for military service 382,633: reach
military age (1 8) annually 2.5,261 (1994 est.)
Defense expenditures; exchange rate
conversion— $22.8 million of GDP, 1% of
GDP (1992)','0a53be79ff2808b823e3734e418df824e6da50c3d5e02dcf29e52878e301ac48','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14fcce33a43db82a436ace6b6d7ee506d27eae7232d586d91db56f7d9eaa4108',1994,'MS','Montserrat','communications',676,'(dependent territory of the UK)
Highways:
total; 280 km
paved; 200 km
unpaved; gravel, earth 80 km
Ports: Plymouth
Airports:
total; 1
usable; 1
with permanent-surface runways; I
with runways over 3,639 m; 0
n irh runways 2,440-3,659 m; 0
with runways 1,220-2,439 m; 0
Telecommunications: 3.000 telephones;
broadcast stations — 8 AM. 4 FM, 1 TV
Defense Forces
Branches: Police Force
Note: defen.se is the responsibility of the UK
270','51c46d8918947afff0ebc67b43d5c1baddf56321493e9a9181605bf703ec81bd','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c46fe3f767abf429c61608f9dc48b039ca5f25a05cfd06c9b1ab735024f8c90c',1994,'MA','Morocco','communications',682,'desenification (soil erosion resulting from
farming of marginal areas, overgrazing,
destruction of vegetation); water supplies
300 Mtdncrrunenn','299a1c9403296db6d86c9b93c28b49f7de43196503d7873258dcbcbe5d3152fe','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('883cb1c96262d7811865aa2341f0acaa724664d95ad8484381f41ecacc687e04',1994,'GI','Gibraltar','communications',688,'Railroads: 1 ,893 km 1 .435-me''er standard
gauge (246 km double track, 974 km
electrified)
Highways:
total: .59,198 km
paved: 27,740 km
unpaved: gravel, crushed stone, improved
earth, unimproved earth 31,458 km
Pipelines: crude oil 362 km; petroleum
piquets (abandoned) 491 km; natural gas 241
km
Ports: Agadir, Casablanca, El Jorf Lasfar,
Keniira, Mohammedia, Nador, Safi, Tangier;
also Spanish-controlled Ceuta and Melilla
Merchant marine: 47 ships ( 1 ,000 GRT or
over) totaling 226,369 GRT/335,089 DWT,
cargo 9, container 3, refrigerated cargo 1 2, toll-
on/roll-off cargo 6, oil tanker 4, chemical
tanker 1 1. short sea passenger 2
Airports:
total: 73
usahle: 64
with permanent-surface runways: 26
with runways over 3,659 m: 2
with runways 2,440-3,659 m: 13
with runways 1,220-2,439 m: 25
Telecommunications: good system
composed of wire lines, cables, and microwave
radio relay links; principal centers are
Casablanca and Rabat; secondary centers are
Fes. Marrakech, Oujda. Tangier, and Tetouan;
280.000 telephones ( 1 0.5 telephones per 1 .000
persons); broadcast stations — 20 AM. 7 FM.
26 TV and 26 repeaters; 5 submarine cables;
.satellite earth stations— 2 Atlantic Ocean
INTELSAT and I .ARABSAT; microwave
radio relay to Gibraltar. Spain, and Western
Sahara; coaxial cable and microwave to
Algeria; microwave radio relay network
linking Syria, Jordan, Egypt. Libya, Tunisia,
Algeria, and Morocco
Defense Forces
Branches: Royal Moroccan Army, Royal
Moroccan Navy, Royal Moroccan Air Force,
Royal Gendarmerie. Auxiliary Forces
Manpower availability: males age 15-49
7,076,261; fit for military service 4,494,64 1 ;
reach military age ( 1 8) annually 3 1 7,093 ( 1 994
est.)
Defense expenditures; exchange rate
conversion — $1,1 billion. 3.8% of GDP (1993
budget)
272','8cf93b6cdb9308cff6f4b543dad15b7a8c51254f5f62d424190e340445d1c490','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f8a3cccbad8316eac623f380a38dddd875fc7bc630aa7f3c4619ae805a3d992',1994,'NR','Nauru','communications',701,'Railroads: 3.9 km; u.sed to haul phosphates
from the center of the island to processing
facilities on the .southwest coast
Highways:
wiat; 27 km
paved; 2 1 km
unpaved; improved earth 6 km
Ports: Nauru
Merchant marine: I bulk .ship ( 1 ,000 CRT or
over) totaling 4.426 GRT/5,750 D3VT
Airports;
total'' I
usable; 1
with permanent-surface ntnwavs; 1
with runways over .i,6S9 m: 0
with runways 2.440-3,659 in; 0
with runways 1 ,220-2.439 m; 1
Telecommunications: adequate local and
international radio ccmmunications provided
via Australian facilities; 1.600 telephones;
4,000 radios; broadcast stations — I AM. no
FM, no TV; I Pacific Ocean INTELSAT earth
station
Defense Forces
Branches: Directorate of the Nauru Police
Force
note: no regular armed forces
Defense expenditures: SNA — no formal
defense structure
Ikai','b0fd4dde8270af16918d52363c3888ff23b193631afdd8e82cccde6bf51df107','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f20d27d5dab8ed112fbb56ec7b5032e73eb3c8e3af1314f7ba307ee180afa9f1',1994,'NP','Nepal','communications',704,'Ports: none; offshore anchorage only
Defense Forces
Note: defense is the responsibility of the US
Railroads: 52 km (1990), all 0.762-meter
narrow gauge; all in Terai close to Indian
border; 10 km from Raxaul to Birganj is
government owned
Highways:
total: 7,080 km
paved: 2,898 km
unpaved: gravel, crushed stone 1,660 km;
seasonally motorable tracks 2,522 km (1990)
Airports:
total: 37
usable: 37
with permanent-surface runways: 5
with runways over 3,659 m: 0
with runways 2,440-3,659 m: I
with runways 1,220-2,439 rn: 8
Telecommunications: poor telephone and
telegraph service; fair radio communication
and broadcast service; international radio
communication service is poor; 50,(X)0
telephones (1990); broadcast stations — 88
279
Nepal (continued)','59293b5553f553250732b2e3d1c4fcc4b9b256ec1c607f88a3ffcf9cb2847ced','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef36b0b1279e0bfc16c7067bb6a2827c08c657010e4ec29bba85d7ed001e57da',1994,'NC','New Caledonia','communications',708,'(overseas territory of France}
.USiin
Cora/ Saa
ttiandt of Huon and
CKattarliald ara not aKown.','ffa09515ad4ea129214cf6d88a167a278bc5280aec6c379ec44ef987565c54c2','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('638fae9117a55e60a21f329e8951d438fa7384404c424d4405c9d765ab220c2b',1994,'TK','Tokelau','communications',712,'Railroads: 4.716 km total; all 1.067-meter
gauge; 274 km double track; 1 1 3 km
electrified; over 99% government owned
Highways:
total; 92,648 km
/Hived; 49,547 km
impaved; gravel, crushed stone 43.101 km
Inland waterways: 1 .609 km; of little
importance to transportation
286','425ca9f417981b1997306f13bce2729ce8f666b521e707ae8618f8e972d9fadb','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63c7d3618f282591d46b5f4f3db79398ddfd55beca6a5c486b5b1a0b898b6226',1994,'NI','Nicaragua','communications',713,'Pipelines: natural gas 1 ,000 km: petroleum
pr^ucts 160 km; condensate (liquiried
petroleum gas — LPG) 150 km
Ports: Auckland. Christchurch, Dunedin,
Wellington, Tauranga
Merchant marine: 1 8 ships (1 ,000 CRT or
over) totaling 165.514 GRT/218,699 DWT,
cargo 1. roll-on/roll-ofT cargo 5, railcar carrier
I , oil tanker 3. liqueHed gas I . bulk 6
Airports:
total; 108
usable; 108
with ftermanetit-surface runways; 39
with runways over 3,659 m; I
with runways 2,440-3,659 m; 2
with runways 1,220-2,439 m; 39
Telecommunications: excellent
international and domestic systems; 2. 1 10,000
telephones; broadcast stations — 64 AM. 2 FM,
14 TV; submarine cables extend to Australia
and Fiji; 2 Pacific Ocean INTELSAT earth
stations
Defense Forces
Branches: New Zealand Army, Royal New
Zealand Navy, Royal New Zealand Air Force
Manpower availability: males age 15-49
880,576; fit for military service 741,629; reach
military age (20) annually 28,242 (1994 est.)
Defense expenditures: exchange rate
conversion — S792 million, 2% of GDP (FY90/
91)
Kailroads: ,J7.Jkm I.()b7-meicr narrow
gauge, gov ernment owned; maiority of system
not opeiating; .J km l.4.k^-meu. .auge line at
Puerto C''abe/as (does not connect with
mainlinel
Highways:
louil: I.s.d.to km
/Hiwtl: 4.tXX) km
unimctl: gravel, crushed stone ’.HO knt;
graded earth ,s,42.^ km; unitnproveu earth
l4.,Vt5 km
Pm-Anu-rHwt htg/nctiv.'' knt (not in
total I
Inland waterways: 2,^20 knt. including 2
large lakes
Pipelines: entde oil .^b km
Ports; Corinto, El Bluff. Puerto C''abe/as,
Puerto Sandino. Rama
Merchant marine: 2 cargo ships 1 1 .tXXI CRT
or oven totaling 2. lb I GRT/2,.‘''(XI DWT
Airports:
until: 208
ii.stihli'': 140
H illi /u•r^u(llu^llr■\\llr|ill•^■ ninu tisw: 1 1
nimuiys ovt-r in: 0
with riinii iiy.t 2.-l-IO-.i.6yV m; 2
>1,./. inwtiyx I.220-2.4JV ni: 14
Teli''ciimmunicatlons: low-cupacity radio
rel.iy and wire system being expanded;
connection into Central Atnerican Microwave
System; bO.tXX) telephones; broadcast
stations — t.S .AM, no I''M, 7 TV, .1 shortwave;
earth stations — 1 Intersputnik and I .Atlantic
CVean INTEl.SAT
Defense Forces
Branches: Ground Forces. Navy. Air Force
Manpower availability: males age l.^-40
04b. 1 77; fit for military service .482.bbO; reach
military age (18) annually 4.S..45.4 1 1004 est.)
Defense expenditures: exchange rate
conversion- S.4b..4 million, 2.7''f of GDP
(PW4 budget)','568dd17fcb800c9af87c72ec2dcfa6aa42095eed9b2e942d2e2df2a030a1d2b4','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('228088d0202f9a01e5f557f3c9221d4b9bd8c7e6b105d0e8b86b7783bfb2b7d9',1994,'NE','Niger','communications',719,'SQC _ _
Highways:
total: 39,970 km
paved: bituminous 3.170 km
unpaved: gravel, latcrite 10.330 km; earth
3,470 km; tracks 23,000 km
Inland waterways: Niger River is navigable
300 km from Niamey to Gaya on the Benin
frontier from mid-December through March
Airports;
total: 30
usable: 28
with permanent-surface runways: 9
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 2
with runways 1,220-2,439 m: 14
Telecommunications: small system of wire,
radiocommunications, and radio relay links
concentrated in southwestern area; 14,260
telephones: broadcast stations — 15 AM, 5 FM,
18 TV; satellite earth stations — I Atlantic
Ocean INTELSAT, I Indian Ocean
INTELSAT, and 3 domestic, with I planned
Defense Forces
Branches: Army, Air Force, Gendarmerie.
National Police, Republican Guard
Manpower availability: males age 1 5-49
1.845.374; ftt for military service 994.683:
reach military age ( 18) annually 91,595 ( 1994
est.)
Defense expenditures: exchange rale
conversion — $27 million. 1 .3% of GDP ( 1 989'')
290','cfa70066da93e4d95efcd937f817e10ab40a5eedf9b27bdfad4f94dd5e8cac95','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('576ba909703badccf4333e937852ca714c8832448d0f0d3ce502696102d7f1b4',1994,'NU','Niue','communications',723,'(free association with New Zealand)
Location: Oceania, Polynesia, 460 km east of
Tonga in the South Pacific Ocean
Map references: Oceania
Area:
total area: 260 sq km
land area: 260 sq km
comparative area: slightly less than 1 .5 times
the size of Washington, EJC
Land boundaries: 0 km
Coastline: 64 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
international dispute: none
Climate: tropical; modified by southeast trade
winds
Terrain: steep lime'':tone cliffs along coast,
central plateau
Natural resources: fish, arable land
Land use:
arable land: 6 1 %
permanent crops: 4%
meadows and pastures: 4%
forest and woodland: 19%
other: 12%
Irrigated land: NA sq km','f1642d60b9fe50d93aae764cdbfcf3712d863495da10e284fcdeb264f0dfd1a1','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11a7ed6d1caef05d7fe3f84d18f6351703ed077fea42241e2f44395f988599a7',1994,'NF','Norfolk Island','communications',729,'Highways:
total: 229 km
wifKived: all-wealher 1 23 km; plantation
access 106 km
Ports: none: offshore anchorage only
Airports:
total: 1
usable: I
with pennanent-surface runways: 1
with runways over .1,659 m: 0
with runways 2,440-3.659 m: 0
with runways 1 ,220-2,4.19 m: I
Telecommunications: single-line telephone
system connects all villages on island: 383
telephones; 1,0(X) radio receivers (1987 est.);
broadcast stations — 1 AM, I FM. no TV
Defense Forces
Branches: Police Force
Note: defense is the responsibility of New
Zealand
Scoih
Paeifie
Ocean','0f273d18ac13af256032fbbb84f2689e5218839688c746fe027f5b1aac7c1adf','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0e0d3aa75fc54c7814813c6737a4ff2c659d141cd1a892d29eafc58f0fcf300',1994,'MP','Northern Mariana Islands','communications',734,'(commonwealth in political union with the
US)
iOOkm
Fsttffan
Islands
''Asuncion Island
Philippine
Sea
•Aghhan
Fagand
^uguan
Sangan
North
Pacific
Ocean
Anatahan
*fatmllon da
^^^SAIPAN
* Tinian
aAsta
Railroads: none
Highways:
total; 381.5 W.n
paved: NA
unpaved: ’-''A
undifferentiated: primary 1.34.5 km: secondary
55 km. local 192 km ( 1991 )
Inland waterways: none
Ports; Saipan, Tinian
Airports;
total: 6
usable: 5
with permanent-surface runways: 3
with runways over 3,659 m; 0
with runways 2,440-3,659 m: 2
with runways ! .220-2,439 m: 2
Telecommunications: broadcast stations — 2
AM. 1 FM ( 1984). I TV. 2 cable TV stations:
2 Pacific Ocean INTELSAT earth stations
Defense Forces
Note: defense is the responsibility of the US','d4ef41ab524275d9cb2440a39b6f092a440805278ce5aeaa1dcd093af070de8a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0c825a1073f7267df09e6c3b09ed16b765b35f810d01fca487f6350697de6e7',1994,'OM','Oman','communications',742,'Highways:
total: 26,000 km
paved: 6,000 km
unpaved: motorable track 20,0(X) km
Pipelines: crude oil 1,300 km; natural gas
1,030 km
Ports: Mina'' Qabus, Mina’ Raysut. Mina'' al
Fahl
Merchant marine: I passenger ship ( 1 .000
GRT or over) totaling 4.442 GRT/ 1 .320 DWT
Airports:
total: 138
usable: 130
with permanetu-suifitce runways: 6
with runways over 3.659 m: I
with runways 2.440-3,659 m: 9
with runways 1,220-2,439 m: 74
TeiacoanmMkoliaMt modern system
consisting of open-wire, microwave, and radio
communications stations: limited coaxial
cable: 30,000 telephones: broadcast stations —
2 AM. 3 FM. 7 TV; satellite earth Ualions — 2
Indian Ocean INTELSAT. I ARABSAT. and 8
domestic
Dcfcnae Forc^
Branches: Army. Navy, Air Force, Royal
Oman Police
Manpower availaMlity: males age 13-49
382,793: fit for military service 21 7.753: reach
military age (14) annually 22,1 18 ( 1994 cst.)
Defense expenditures: exchange rate
conversion — $1.6 billion, 16% of GDP ( 1993
est.)
Phihppirw IVorth
See Pecrtic
Ocean
iSanaotoi Mtrdt
Anna
^Helan Reaf','08e46b8852f78a4f3b2a5a465b968a45d929eeaf7d32415e18a118ca337d31f6','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe60b2d682bbcd1855f28f5b1e1b372926497e126ed6a97f52780bb47a3fa011',1994,'PH','Philippines','communications',748,'Highways:
total; 61 km
paved; 36 km
unpaved; gravel 25 km
Ports: Koror
Airports:
total; 3
usable: 3
with permanent-surface runways; 1
with runways over 3,659 m; 0
301
Pacific Islands (Palau), Trust
Territory of the ( con tinned )
with nmways 2.440-X65V m; 0
with nimniys l,220-2,4.iVm: 3
Tetecommunicallons: broadcast stations— I
AM. I FM. 2 TV; I Pacilic Ocean INTELSAT
earth station
Defense Forces
Note: defense is the responsibility of the US
and that will not change when the UN
trusteeship terminates if the Compact of Free
AsstKiation with the US goes into effect
Pacific Ocean
Map references: Asia
Area:
total area; NA sq km
land area; NA sq km
comparative area; NA
Land boundaries: 0 km
Coastline: 518 km
Maritime claims: NA
International disputes: occupied by China,
but claimed by Taiwan and Vietnam
Climate: tropical
Terrain: NA
Natural resources: none
Land use:
arable land; 0%
permanent crops: 0%
meadows and pastures: 0%
forest and wtwdland: 0%
other: 1009h
Irrigated land: 0 sq km
Railroads; 178 km operable on Luzon, 14%
government owned (1982)
Highways:
total: 157,450 km
paved: 22,400 km
unptiwd: gravel, crushed stone, stabilized
earth 85.050 km: unimproved e-''rth 50,000 km
(1988)
Inland waterways: 1,219 km; limited to
shallow-draft (less than 1.5 m) vessels
Pipelines: petroleum products 157 km
Ports; Cagayan dc Oro, Cebu, Davao.
Guimaras, Iloilo, Legaspi, Manila. Subic Bay
Merchant marine: 551 ships ( 1 ,0(X) GRT or
over) totaling 8.451.047 GRT/ 11.9.14,255
DWT, passenger 1. short-sea passenger 12.
passenger-cargo 13, cargo 145, refrigerated
cargo 27. vehicle carrier 35, livestock carrier 9,
roll-on/roll-off cargo 14, container 8. oil tanker
33. chemical tanker I. liquefted gas 1.
combination ote/oil 1, bulk 241, combination
bulk 10
note: many Philippine flag ships are foreign
owned and are on the register for the purpose of
long-term bare-boat charter back to their
original owners who are principally in Japan
and Germany
Airports:
total: 270
usahle: 218
with pertminent-suiface runways: 74
with runways over m: 0
with runways 2,440-J,659 m: 9
with runways 1,220-2,4.^9 m: 57
Telecommunications: good international
radio and submarine cable services; domestic
and interisland service adequate; 872,900
telephones; broadcast stations — 267 AM
(including 6 US). 55 FM, 13 TV (including 4
US); submarine cables extended to Hong
Kong. Guam, Singapore, Taiwan, and Japan:
satellite earth stations — I Indian Ocean
INTELSAT. 2 Pacific Ocean INTELSAT, and
1 1 domestic
Defense Forces
Branches: Army, Navy (including Coast
Guard and Marine Corps), Air Force
Manpower availability: males age 1 5-49
17,668,781; fit for military service 12.479,112;
reach military age (20) annually 711,880 ( 1994
est.)
Defense expenditures: exchange rate
conversion — $915 million. l.9%of GNP
(1991)
Pitcairn Islands
(dependent territory of the UK)
jsm.
Htntvnn
f
...*adawstown
Pitewn
South Pttifie Oeoon
Railroads: none
Highways:
total: 6.4 km
unpaved: earth 6.4 km
Ports: Bounty Bay
Airports: none
Telecoitununicatioiis: 24 telephones: party
line telephone service on the island; broadcast
317
Pitcairn Islands (continued)
Ports: no natural harbors
Airports;
total; 4
usable; 4
with permanent-suiface runways; 1
with runways over 3,659 m; 0
with runways 2,440~3,6S9 m; 0
with runways 1,220-2.439 m; 0
Defense Forces
Note: about SO small islands or reefs are
occupied by China, Malaysia, the Philippines,
Taiwan, and Vietnam
Map references: Asia, Southeast Asia,
Standard Time Zones of the World
Area:
total area: 329,560 sq km
land area: 325,360 sq km
comparative area: slightly larger than New
Railroads: about 4,600 km total track with
1 ,075 km common carrier lines and 3,525 km
industrial lines; common carrier lines consist
of the 1 .067-meter gauge 708 km West Line
and the 367 km East Line; a 98.25 km South
Link Line connection was completed in late
1991 ; common carrier lines owned by the
government and operated by the Railway
Administration under Ministry of
Communications; industrial lines owned and
operated by government enterprises
Highways:
total: 20,041 km
paved: bituminous, concrete pavement 17,095
km
unpaved: crushed stone, gravel 2,37 1 km;
graded earth 575 km
Pipelines: petroleum products 615 km,
natural gas 97 km
Ports: Kao-hsiung, Chi-lung (Keelung), Hua-
lien. Su-ao. T’ai-tung
Merchant marine: 2 1 2 ships ( 1 ,000 CRT or
over) totaling 5.910,453 GRT/9.098.3 1 5
DWT, passenger-cargo I , cargo 38.
refrigerated cargo 1 1 , container 85. oil tanker
1 7, combination ore/oil 2. bulk 54. roll-on/roll¬
off cargo 1 , combination bulk 2, chemical
tanker I
Airports:
loud: 40
usable: 38
with permanent-surface runways: 36
with runways over 3,659 m: 3
with runways 2.440-3,659 m: 16
with runways 1,220-2,439 m: 7
Telecommunications; best developed system
in Asia outside of Japan; 7,8(X),000 telephones;
extensive microwave radio relay links on ea,st
and west coasts; broadcast stations — 91 AM,
23 FM. 15TV (13 repeaters); 8,620.000 radios;
6.386.000 TVs (5,680.000 color. 706.000
monochrome); satellite earth stations — I
Pacific Ocean INTELSAT and 1 Indian Ocean
INTELSAT; submarine cable links to Japan
(Okinawa), Philippines, Guam, Singapore.
Hong Kong, Indonesia, Australia, Middle East,
and Western Europe
Defense Forces
Branches: General Staff, Ministry of National
Defense, Army, Navy (including Marines), ,\\ir
Force. Coastal Patrol and Defense Command.
Armed Forces Reserve Command, Military
Police Command
Manpower availability; males age 1 5-49
6.205.707; fit for military service 4,806.456;
reach military age ( 1 9) annually 1 92,083 ( 1 994
est.)
Defense expenditures: exchange rate
conversion — $10.9 billion. 5.4% of GNP
(FY93/94 est.)
445
Appendix A:
The United Nations System
Main coinmIRan
Standing and procadural
commlllaaa
Other aubsldlaiy organa
« UNAVEM II
UNSCOM
UN Compenaatlon
Commlsalon
Iraq/Kuwall Border
Demareatlon
Commlsalon
TiuiwWiip i ^
Milltaiy Stall Committee
UNRWA
UNCTAD
UNICEF
UNHCR
WFP
UNITAR
UNDP
UNEP
UNU
Habitat
UNFPA
UN Special Fund
WFC
••
mtamaUonal Cowt
of Jimbm
SacfMiM -
eoortomie and! ^ ''
SodafCounoH
• Regional Commissions
h— • Functional Commissions
— • Standing Committees
'' — • Expert Bodies
□ Principal organs of tne United Nations
• Other United Nations organs
□ Specialized agencies and other
autonomous organizations
within the system
IAEA
GATT
ILO
FAO
UNESCO
WHO
IMF
IDA
IBRD
IFC
ICAO
UPU
ITU
WMO
IMO
WlPO
IFAD
UNIDA
Based on chart from tha UN Chronldt
446
Appendix B
Abbreviations for International
Organizations and Groups
A
ABEDA
Arab Bank for Economic Development in Africa
ACC
Arab Cooperation Council
ACCT
Agence de Cooperation Culturelle et Technique; see Agency
for Cultural and Technical Cooperation
ACP
African, Caribbean, and Pacific Countries
AfDB
African Development Bank
AFESD
Arab Fund for Economic and Social Development
AG
Andean Group
AL
Arab League
ALADI
Asociacion Latinoamericana de Integracion; see Latin
American Integration Association (LAIA)
AMF
Arab Monetary Fund
AMU
Arab Maghreb Union
ANZUS
Australia-New Zealand-United States Security Treaty
APEC
Asia Pacific Economic Cooperation
AsDB
Asian Development Bank
ASEAN
Association of Southeast Asian Nations
B
BAD
Banque Africaine de Developpement; see African Development Bank
(AfDB)
BADEA
Banque Arabe de Developpement Economique en Afrique; see
Arab Bank for Economic Development in Africa (ABEDA)
BCIE
Banco Centroamericano de Integracion Economico; see Central
American Bank for Economic Integration (BCIE)
BDEAC
Banque de Developpment des Etats de 1'' Afrique Centrale; see Central
Amcan States Development Bank (BDEAC)
Benelux
Benelux Economic Union
BID
Banco Interamericano de Desarrollo; see Inter-American Development
Bank (lADB)
BIS
Bank for International Settlements
BOAD
Banque Ouest-Africaine de Developpement; see West African
Development Bank (WADB)
BSEC
Black Sea Economic Cooperation Zone
C
C
Commonwealth
CACM
Central American Common Market
CAEII
Council of Arab Economic Unity
CARICOM
Caribbean Community and Common Market
CBSS
Council of the Baltic Sea Stales
CCC
Customs Cooperation Council
CDB
Caribbean Development Bank
CE
Council of Europe
CEAO
Communaute Economique de I’Afrique de I’Ouest; see West
African Economic Community (CEAO)
CEEAC
Communaute Economique des Etats de 1’ Afrique Centrale; see
Economic Community of Central African States (CEEAC)
CEI
Central European Initiative
CEMA
Council for Mutual Economic Assistance; also known as CMEA or
Comecon; abolished 1 January 1991
447
CEPGL
Communaute Economique des Pays des Grands Lacs; see Economic
Community of the Great Lakes Countries (CEPGL)
CERN
Conseil Europeen pour la Recherche Nucleaire; see European
Organization for Nuclear Research (CERN)
CG
Contadora Group
CIS
Commonwealth of Independent States
CMEA
Council for Mutual Economic Assistance (CEMA); also known as
Comecon; abolished 1 January 1991
COCOM
Coordinating Committee on Export Controls
Comecon
Council for Mutual Economic Assistance (CEMA); also known as
CMEA; abolished 1 January 1991
CP
Colombo Plan
CSCE
Conference on Security and Cooperation in Europe
D
DC
developed country
E
EADB
East African Development Bank
EBRD
European Bank for Reconstruction and Development
EC
European Community; see European Union (EU)
ECA
Economic Commission for Africa
ECAFE
Economic Commission for Asia and the Far East; see Economic and
Social Commission for Asia and the Pacific (ESCAP)
ECE
Economic Commission for Europe
ECLA
Economic Commission for Latin America; see Economic Commission
for Latin America and the Caribbean (ECLAC)
ECLAC
Economic Commission for Latin America and the Caribbean
ECO
Economic Cooperation Organization
ECOSOC
Economic and Social Council
ECOWAS
Economic Community of West African States
ECSC
European Coal and Steel Community
ECWA
Economic Commission for Western Asia; see Economic and Social
Commission for Western Asia (ESCWA)
EEC
European Economic Community
EFTA
European Free Trade Association
EIB
European Investment Bank
Entente
Council of the Entente
ESA
European Space Agency
ESCAP
Economic and Social Commission for Asia and the Pacific
ESCWA
Economic and Social Commission for Western Asia
EU
European Union
Euratom
European Atomic Energy Community
F
FAO
Food and Agriculture Organization
FLS
Front Line States
FZ
Franc Zone
G
G-2
Group of 2
G-3
Group of 3
G-5
Group of 5
G-6
Group of 6 (not to be confused with the Big Six)
G-7
Group of 7
G-8
Group of 8
G-9
Group of 9
G-10
Group of 10
G-11
Group of 1 1
448
5
?
Group of 15
Group of 19
G-24
Group of 24
Group of 30
G-33
Group of 33
G-77
Group of 77
GATT
General Agreement on Tariffs and Trade
GCC
Gulf Cooperation Council
H
Habitat
Commission on Human Settlements
1
lADB
Inter-American Development Bank
IAEA
International Atomic Energy Agency
IBEC
International Bank for Economic Cooperation
IBRD
International Bank for Reconstruction and Development
ICAO
International Civil Aviation Organization
ICC
International Chamber of Commerce
ICEM
Intergovernmental Committee for European Migration; see
International Organization for Migration (lOM)
ICFTU
International Confederation of Free Trade Unions
ICJ
International Court of Justice
ICM
Intergovernmental Committee for Migration; see International
O^anization for Migration (lOM)
ICRC
International Committee of the Red Cross
IDA
International Development Association
IDB
Islamic Development Bank
lEA
International Energy Agency
IFAD
International Fund for Agricultural Development
IFC
International Finance Corporation
IFCTU
International Federation of Christian T- -ons
IGADD
Inter-Governmental Authority on Dro ; .i ent
IIB
International Investment Bank
ILO
International Labor Organization
IMCO
Intergovernmental Maritime Consultative Organization; see
International Maritime Organization (IMO)
IMF
International Monetary Fund
IMO
International Maritime Organization
INMARSAT
International Maritime Satellite Organization
INTELSAT
International Telecommunications Satellite Organization
INTERPOL
International Criminal Police Organization
IOC
International Olympic Committee
lOM
International Organization for Migration
ISO
International Organization for Standardization
ITU
International Telecommunication Union
L
LAES
Latin American Economic System
LAIA
Latin American Integration Association
LAS
League of Arab States: see Arab League (AL)
LDC
less developed country
LLDC least developed country
LORCS League of Red Cross and Red Crescent Swieties
19
M
MERCOSUR
Mercado Comun del Cono Sur; see Southern Cone Common Market
MINURSO
United Nations Mission for the Referendum in Western Sahara
MTCR
Missile liichnology Control Regime
N
NACC
North Atlantic Cooperation Council
NAM
Nonaligned Movement
NATO
North Atlantic IVeaty Organization
NC
Nordic Council
NEA
Nuclear Energy Agency
NIB
Nordic Investment Bank
NIC
newly industrializing country; see newly industrializing economy
(NIE)
NIE
newly industrializing economy
NSG
Nuclear Suppliers Group
0
OAPEC
Organization of Arab Petroleum Exporting Countries
OAS
Organization of American States
OAU
Organization of African Unity
OECD
Organization for Economic Cooperation and Development
OECS
Organization of Eastern Caribbean States
OIC
Organization of the Islamic Conference
ONUSAL
United Nations Observer Mission in El Salvador
OPANAL
Organismo para la Proscripcion de las Armas Nucleates en la America
Latina y el Catibe; see Agency for the Prohibition of Nuclear
Weapons in Latin America and the Caribbean
OPEC
Organization of Petroleum Exporting Countries
P
PCA
Permanent Court of Arbitration
R
RG
Rio Group
S
SAARC
South Asian Association for Regional Cooperation
SACU
Southern African Customs Union
SADC
Southern African Development Community
SADCC
Southern African Development Coordination Conference
SELA
Sistema Economico Latinoamericana; see Latin American Economic
System (LABS)
SPARTECA
South Pacific Regional Trace and Economic Cooperation Agreement
SPC
South Pacific Commission
SPF
South Pacific Forum
u
UDEAC
Union Douaniere et Economique de I''Afrique Centrale; see Central
African Customs and Economic Union (UDEAC)
UN
United Nations
UNAVEM II
United Nations Angola Verification Mission
UNCTAD
United Nations Conference on Trade and Development
UNDOF
United Nations Disengagement Observer Force
UNDP
United Nations Development Program
UNEP
United Nations Environment Program
UNESCO
United Nations Educational, Scientific, and Cultural Organization
UNFICYP
United Nations Force in Cyprus
UNFPA
United Nations Fund for Population Activities; see UN Population
Fund (UNFPA)
UNHCR
United Nations Office of the High Commissioner for Refugees
UNICEF
United Nations Children’s Fund
UNIDO
United Nations Industrial Development Organization
450
UNIFIL
United Nations Interim Force in Lebanon
UNIKOM
United Nations Iraq-Kuwait Observation Mission
UNMOGIP
United Nations Military Observer Group in India and Pakistan
UNOMIG
United Nations Observer Mission in Georgia
UNOMOZ
United Nations Operation in Mozambique
UNOMUR
United Nations Observer Mission Uganda-Rwanda
UNOSOM
United Nations Operation in Somalia
UNPROFOR
United Nations Protection Force
UNRWA
United Nations Relief and Works Agency for Palestine Refugees in
the Near East
UNTAC
United Nations Transitional Authority in Cambodia
UNTSO
United Nations Truce Supervision Organization
UPU
Universal Postal Union
1
USSR/EE
USSR/Eastem Europe
w
WADB
West African Development Bank
WCL
World Confederation of Labor
WEU
Western European Union
WFC
World Food Council
WFP
World Food Program
WFTU
World Federation of Trade Unions
WHO
Worid Health Organization
WlPO
World Intellbviual Property Organization
WMO
World Meteorological Organization
WP
Warsaw Pact (members met 1 July 1991 to dissolve the alliance)
WTO
Worid Tourism Organization
z
zc
Zangger Committee
Note: Not all international organizations and groups have abbreviations
Appendix C:
International Organizations
and Groups
advanced developing countries another term for those less developed countries (LDCs) with particularly rapid industrial
development; see newly indusuializing economies (NlEs)
African, CariLbean, and Pacific Countries
(ACP)
established — 1 /ipril 1976
aim — members have a preferential economic
and aid relationship with the EU
members — (70) Angola. Antigua and Barbuda. The Bahamas. Barbados, Belize, Benin,
Botswana. Burkina, Burundi. Cameroon, Cape Verde. Central African Republic, Chad. Comoros.
Coiigo. Cote d’Ivoire, Djibouti, Dominica, Dominican Republic, Equatorial Guinea, Eritrea,
Ethiopia, Fiji, Gabon, The Gambia, Ghana, Grenada, Guinea, Guinea-Bissau, Guyana, Haiti,
Jamaica, Kenya, Kiribati, Lesotho. Liberia. Madagascar, Malawi, Mali, Mauritania, Mauritius,
Mozambique, Namibia, Niger, Nigeria, Papua New Guinea, Rwanda, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Sao Tbme and Principe, Senegal, Seychelles,
Sierra Leone, Solomon Islands, Somalia, Sudan, Suriname, Swaziland, Tanzania, Togo, Tonga,
Trinidad and Tobago. TUvalu. Uganda. Vanuatu. Western Samoa, Zaire, Zambia, Zimbabwe
African Development Bank (AfDB), also
known as Banque Africalne de
Devcioppement (BAD)
established — 4 August 1963
aim— to promote economic and social
development
regional members— (S3) Algeria, Angola. Benin, Botswana, Burkina, Burundi. Cameroon, Cape
Verde, Central African Republic, Chad. Comoros, Congo. Cote d’Ivoire, Djibouti, Egypt.
Equatorial Guinea. Eritrea. Ethiopia, Gabon. The Gambia, Ghana. Guinea, Guinea-Bissau,
Kenya, Lesotho, Liberia, Libya, Madagascar, Malawi, Mali. Mauritania. Mauritius, Morocco,
Mozambique, Namibia. Niger, Nigeria, Rwanda. Sahrawi Arab Democratic Republic, Sao Tome
and Principe, Senegal, Seychelles, Sierra Leone. Somalia, Sudan. Swaziland, Tanzania. Togo,
Tunisia, Uganda, Zaire. Zambia, Zimbabwe
nonregional members— (26) Argentina, Austria. Belgium. Brazil. Canada, China, Denmark,
Finland, France, Germany, India. Italy, Japan. South Korea, Kuwait. Netherlands, Norway.
Portugal, Saudi Arabia, Spain. Sweden. Switzerland, Turkey. UK. US, Yugoslavia
Agence de Cooperation Culturelle et
TKhnique (ACCT)
Agency for Cultural and Technical Cooperation (ACCT)
Agency for Cultural and Itehnical
Cooperation (ACCT)
note— acronym ftxim Agence de Cooperation
Culturelle et Technique
established— 2\\ March 1970
aim — to promote cultural and technical
cooperation among French-speaking
countries
members— (34) Belgium. Benin, Burkina, Burundi, Cameroon, Canada. Central African
Republic, Chad, Comoros, Congo, Cote d''Ivoire. Djibouti. Dominica, Equatorial Guinea,
France, Gabon, Guinea, Haiti. Laos, Lebanon, Luxembourg, Madagascar, Mali. Mauritius,
Monaco, Niger, Rwanda, Senegal. Seychelles. Togo. Tunisia, Vanuatu, Vietnam. Zaire
associate members— (5) Egypt, Guinea-Bissau, Mauritania. Morocco. Saint Lucia
participating governments — (2) New Brunswick (Canada), Quebec (Canada)
obseners—(3) Bulgaria. Cambodia, Romania
Agency for the Prohibition of Nuclear
Weapons in Latin America and the
Caribbean (OPANAL)
note — acronym from Organismo para la
Proscripcion de las Armas Nucleares en la
America Latina y el Caribe (OPANAL)
members— (26) Antigua and Barbuda, The Bahamas, Barbados, Bolivia, Brazil. Chile,
Colombia, Costa Rica. Dominican Republic, Ecuador, El Salvador. Grenada. Guatemala, Haiti,
Honduras. Jamaica. Mexico, Nicaragua. Panama. Paraguay. Peru. Saint Vincent and the
Grenadines, Suriname. Trinidad and Tobago, Uruguay, Venezuela
established — 14 February 1967
aim — to encourage the peaceful uses of
atomic energy and prohibit nuclear weapons
Andean Group (AG)
members — (5) Bolivia, Colombia, Ecuador. Peru, Venezuela
established — 26 May 1969
associate member — (1) Panama
effective — 16 October 1969
aim — to promote harmonious development
through economic integration
ohsert''ers— (26) Argentina, Australia. Austria, Belgium, Brazil. Canada, Costa Rica, Denmark,
Egypt, Finland, France. Germany, India, Israel, Italy, Japan, Mexico, Netherlands. Paraguay,
Spain, Sweden, Switzerland. UK, US. Uruguay, Yugoslavia
Note: The Socialist Federal Republic of Yugoslavia (SFRY) has dissolved, and ceases to exist. None of the successor states of the former
Yugoslavia, including Serbia and Montenegro, have been permitted to participate solely on the basis of the membership of the former
Yugoslavia in the United Nations General Assembly and Economic and Social Council and their subsidiary bodies and in various United
Nations Specialized Agencies. The United Nations, however, permits the seat and nameplate of the SFRY to remain, permits the SFRY
mission to continue to function, and continues to fly the flag ot the former Yugoslavia. For a variety of reasons, a number of other
organizations have not yet taken action with regard to the membership of the former Yugoslavia. The World Facthook therefore continues to
list Yugoslavia under international organizations where the SFRY scat remains or where no action has yet been taken.
Arab Bank fbr Economic Development In
Aflrka (ABEDA)
note — also known as Banque Arabe de
Developpement Economique en Afrique
(BADEA)
established — 18 February 1974
effective — 16 September 1974
aim— to promote economic development
Arab Cooperation Council (ACC) members — (4) Egypt, Iraq, Jordan, Yemen
established — 16 February 1989
aim — to promote economic cooperation and
integration, possibly leading to an Arab
Common Market _
Arab Fund tor Economic and Social members— {20 plus the Palestine Liberation Organization) Algeria, Bahrain, Djibouti, Egypt
Development (AFESD) (suspended from 1979 to 1988), Iraq, Jordan, Kuwait, Lebanon, Libya, Mauritania. Morocco,
Oman, Qatar, Saudi Arabia, Somalia, Sudan, Syria, Tunisia, DAE, Yemen, Palestine Liberation
established — 16 May 1968 Organization
aim — to promote economic and social
development _
Arab League (AL) mem^rs — (20 plus the Palestine Liberation Organization) Algeria, Bahrain, Djibouti, Egypt,
Iraq, Jordan, Kuwait, Lebanon, Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia,
note — also known as League of Arab States Somalia, Sudan, Syria, Tunisia, UAE, Yemen, Palestine Liberation Organization
(LAS)
established— 22 March 1945
aim — to promote economic, social, political,
and military cooperation _
Arab Maghreb Union (AMU) members— {5) Algeria, Libya, Mauritania, Morocco, Tunisia
established — 17 February 1989
aim — to promote cooperation and integration
among the Arab states of northern Africa
Arab Monetary Fund (AMF)
established — 27 April 1976
effective — 2 February 1977
aim — to promote Arab cooperation,
development, and integration in monetary
and economic affairs _
Asia Paclflc Economic Cooperation
(APEC)
established — 7 November 1989
aim — to promote uade and investment in the
Pacific basin
members — (16) all ASEAN members (Brunei, Indonesia, Malaysia, Philippines, Singapore,
Thailand) plus Australia, Canada, China, Hong Kong, Japan, South Korea, NZ, Papua New
Guinea, Taiwan, US
members — (19 plus the Palestine Liberation Organization) Algeria, Bahrain, Egypt, Iraq, Jordan,
Kuwait, Lebanon, Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan,
Syria, Tunisia, UAE, Yemen, Palestine Liberation Organization
members— (17 plus the Palestine Liberation Organization) Algeria, Bahrain, EgW, Iraq, Jordan,
Kuwait, Lebanon, Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Sudan, Syna,
Tunisia, UAE, Palestine Liberation (Jrganization; note— these are all the members of the Arab
League except Djibouti, Somalia, and Yemen
Asian Development Bank (AsDB) regional members — (37) Afghanistan, Australia, Bangladesh, Bhutan, Burma, Cambodia, China,
Cook Islands, Fiji, Hong Kong, India. Indonesia, Japan, Kiribati, South Korea. Laos, Malaysia,
established — 19 December 1966 Maldives, Marshall Islands, Federated States of Micronesia, Mongolia, Nauru, Nepal, NZ,
Pakistan, Papua New Guinea, Philippines, Singapore. Solomon Islands, Sri Lanka, Diiwan,
aim — to promote regional economic Thailand, Tonga, Tuvalu. Vanuatu, Vietnam, Western Samoa
cooperation
nonregianal members — (16) AusUria. Belgium, Canada, Denmark, Finland, Franc','b7869c59fc3451a293ff897266d812c0f5ea762eb5f5d7327a6884122331605d','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ba85d82ab58ef63be8111d6b59bfcfed161a4c7b1284c90c21e42a0f10b687d',1994,'PH','Philippines','communications',749,'e, Germany,
_ Italy, Netherlands, Norway, Spain. Sweden, Swjuerland, Turkey. UK, US _
Asociacion Latinoamericaita de see Latin American Integration Association (LAIA)
Integraclon (ALADl) _
453
Association of Southeast Asian Nations
(ASEAN)
established— 9 August 1967
members — (6) Bmnei, Indonesia, Malaysia, Philippines, Singapore, Thailand
observers — (3) Laos, Papua New Guinea, Vietnam
aim — to encourage regional economic,
social, and cultural cooperation among the
non-Communist countries of Southeast Asia
Australia Group
established — 1984
members — (25) Argentina, Australia. Austria, Belgium, Canada, Denmark, Finland, France,
Germany. Greece, Hungary, Iceland, Ireland, Italy, Japan, Luxembourg, Netherlands, NZ,
Norway, Ponugal, Spain, Sweden, Switzerland, UK. US
aim — to consult on and coordinate export
controls related to chemical and biological
weapons
observer — (1) Singapore
Australia— New Zealand — United States .
Security Deaty (ANZUS)
members — (3) Australia, N2, US i
j
established — 1 September 1951
1
1
effective — 29 April 1952
1
aim — to implement a trilateral mutual
security agreement, although the US
suspended security obligations to NZ on 11
August 1986
1
1
Banco Centroamericano dc Intcgracion
Economico (BCIE)
see Central American Bank for Economic Integration (BCIE)
Banco Intcramericano de Desarrollo (BID)
see Inter-American Development Bank (lADB)
Bank for International Settlements (BIS)
established— 20 Jmuary 1930
effective — 17 March 1930
members — (33) Australia, Austria, Belgium, Bulgaria, Canada, Czech Republic, Denmark,
Estonia, Finland, France. Germany, Greece, Hunga^, Iceland, Ireland, Italy, Japan, Latvia,
Lithuania. Netherlands, Norway, Poland, Portugal. Romania, Slovakia, South Africa, Spain,
Sweden, Switzerland, Ttirkey, UK, US, Yugoslavia
aim — to promote cooperation among central
banks in international financial settlements
Banque AArlcalne de Developpement
(BAD)
see African Development Bank (AfDB)
Banque Arabe de Developpement
Economique en AfHque (BADEA)
see Arab Bank for Economic Development in Afnca (ABEDA)
Banque de Developpement des Etats de
I’Afinque Centrale (BDEAC)
see Central African States Development Bank (BDEAC)
Banque Ouest-AfHcalne de
Developpement (BOAD)
see West African Development Bank (WADB)
Benelux Economic Union (Benelux)
members — (3) Belgium. Luxembourg, Netherlands
note — acronym from Belgium, Netherlands,
and Luxembourg
1
established — 3 February 1958
effective — 1 November 1960
aim — to develop closer economic
cooperation and integration
Big Seven
members — (7) Big Six (Canada, France, Germany, Italy, Japan, UK) plus the US
note — membership is the same as the
Croup of 7
established — NA 1975
aim — to discuss and coordinate major
economic policies
454
Big six
mtmbtn — (6) Canada, France, Germany, Italy, Japan, UK
nott — not to be confused with the
Group of 6
NA 1967
aim— to foster economic cooperation
Cartagena Group _ see Group of 1 1 _
Central African Customs and Economic members — (6) Cameroon, Central African Republic, Chad, Congo. Equatorial Guinea, Gabon
Union (UDEAC)
note— acronym from Union Doucniere et
Economique de I''Afrique Centrale
established — 8 December 1964
eilective — 1 January 1966
aim — to promote the establishment of a
Central African Common Market _
Central Afrrican States Development Bank members — (9) Cameroon, Central African Republic, Chad, Congo, Equatorial Guinea, France,
(BDEAC) Gabon, Germany, Kuwait
note — acronym from Banque de
Developpement des Etats de I''Afrique
Centrale
established—^ December 1975
aim — to provide loans for economic
development _
Central American Bank for Economic members — (5) Costa Rica, El Salvador, Guatemala. Honduras, Nicaragua
Integration i.BCIE)
nonregionul members — (4) Argentina, Mexico, Taiwan, Venezuela
note — acrony.m from Banco
Ccntroamericano de Integracion Economico
established— December 1960
aim — to promote economic integration and
development
155
Centtal American Cumroun Market
(CACM)
established — 13 December 1960
effective — 3 June 1961
aim — to promote establishment of a Central
American Common Market
members — (5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua
Central European Initiative (CEI)
note — evolved from the Hexagonal Group
members — (10) Austria, Bosnia and Herzegovina, Croatia, Czech Republic, Hungary, Italy,
Poland, Slovalda, Slovenia, Yugoslavia
participating non-members — (6) Baden- Wurtemburg, Bavaria, Belarus, Bulgaria, Romania,
established — 27 July 1991
aim — to form an economic and political
cooperation group for the region between the
Adriatic and the Baltic Seas','5260db4c1acf3669943970ad979c85b4933118b37260603a71d31be61482bb5e','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1428b49cce1b2aab5f40a52e16038aa29d012237579094ae7f3c6fb9999b7b6c',1994,'PA','Panama','communications',751,'Caribbean Sea
North Pacific Ocean
Railroads: 238 km total; 78 km I .S24-meter
gauge, 160 km 0.914-meter gauge
Highways:
total: 8,530 km
paved: 2,745 km
unpaved: gravel, crushed stone 3,270 km;
improved, unimproved earth 2,515 km
Inland waterways: 800 km navigable by
shallow draft vessels; 82 km Panama Canal
Pipelines: crude oil 1 30 km
Ports: Cristobal, Balboa, Colon
Merchant marine: 3,405 ships ( 1 ,0(X) CRT
or over) totaling 56,01 1,824 GRT/89,5 16,566
DWT, passenger 22, short-sea passenger 30,
passenger-cargo 3, cargo 1,110, refrigerated
cargo 287, container 215, roll-on/roll-off cargo
67, vehicle carrier 129, livestock carrier 9.
multifunction large-load carrier 5, oil tanker
437, chemical tanker 181, combination ore/oil
24, liquefied gas 127, specialized tanker 10,
bulk 717, combination bulk 31, barge carrier I
note: all but 30 are foreign owned and
operated; the top 4 foreign owners are Japan
34%, Greece 8%, Hong Kong 7%, and Taiwan
5%; other foreign owners include China at least
144 ships, Vietnam 3, Croatia 6, Cuba 4,
Cyprus 4, and Russia 41
Airports;
total: 118
usable: 109
with permanent-surface runways: 38
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 2
with runways 1 ,220-2,439 m: 15
Telecommunications: domestic and
international facilities well developed;
connection into Central American Microwave
System; 220,000 telephones; broadcast
stations — 91 AM, no FM, 23 TV; 1 coaxial
submarine cable; satellite ground stations — 2
Atlantic Ocean INTELSAT
Defense Forces
Branches: Panamanian Public Forces (PPF)
includes the National Police, Maritime Service,
National Air Service. Institutional Protective
Service: Judicial Technical Police operate
under the control of Panama''s judicial branch
Manpower availability: males age 15-49
686,479; fit for military service 471,780
Defense expenditures: expenditures for the
Panamanian security forces amounted to
$138.5 million, 1 ,0% of GDP (1993 est.)','8293300ddc1d3bd34cec2435c44b269be80974565072cdfa72e92f8bc297b4a3','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('590246391116f41833ff7cdb3e3dfd7df108efda7b30e8b1922694f6d65f7503',1994,'PG','Papua New Guinea','communications',757,'600 kff
South Pocific Ocean
Cora! Sea
Railroads: none
Highways:
total: 19,200 km
paved: 640 km
unpaved: gravel, crushed stone, stabilized
earth 10,960 km: unimproved earth 7,600 km
Inland waterways: 10,940 km
Ports: Anewa Bay, Lae, Madang, Port
Moresby, Rabaul
Merchant marine: 1 1 ships ( 1 ,000 GRT or
over) totaling 2 1 ,337 GRT/25,669 DWT, cargo
3, combination ore/oil 5, bulk 2, container I
Airports:
total: 504
usable; 462
with permanent-surface runways: 18
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 1
with runways 1,220-2,439 m: 39
Telecommunications: services aic adequate
and being improved; facilities provide
radiobroadcast, radiotelephone and telegraph,
coastal radio, aeronautical radio, and
international radiocommunication services;
submarine cables extend to Australia and
Guam; more than 70,000 telephones (1987);
broadcast stations — 31 AM, 2 FM, 2 TV
(1987): 1 Pacific Ocean INTELSAT earth
station
Defense Forces
Branches; Papua New Guinea Defense Force
(including Army, Navy, Air Force)
Manpower availability: males age 15-49
1 ,080.3 1 6; fit for military service 601 ,369
Defense expenditures: exchange rate
conversion — $55 million, 1 .8% of GDP (1993
est.)
309
Paracel Islands','e319d5c7ec5edbec5a98e900037df08c19c55a0264e65d1872950b3f9bc168a7','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3659da8723f22c82bed56f910498e8b0404acf1a088809f37c2e2c6feca51809',1994,'PY','Paraguay','communications',763,'SO fcm
^lorth Ratf
''''"T>
m.Amph>trit9
ft'' Group
®kM»Crty
cry
Crescent
Group
South China Sea
Ports: small Chinese port facilities on Woody
Island and Duncan Island curremly under
expansion
Airports: I on Woody Island
Defense Forces
Note: occupied by China
Geography Geography
Location: Southeastern Asia, 400 km east of
Vietnam in the South China Sea, about one-
third of the way between Vietnam and the','4911d1d86d1afc00948e0993397d884e55d2d914f0b7a8bd18c312049807a9ed','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8173e04a638cb94a1f1836c62387b6a664420d568920264c4e4c76090da9a351',1994,'PL','Poland','communications',765,'stations — 1 AM, no FM, no TV; diesel
generator provides electricity
Defense Forces
Note: defense is the responsibility of the UK
Boundary rapraiantaiion ii
not nacaaianly authoitlaiwa','853d1eb95feabad86abc7b93aeaaf0ae8036aeba4441351b82212e3b88f7088e','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03de8eb7b0c46a9fdac17de970e07facd2098ebb4aba2db418a80c00e08e75a7',1994,'PR','Puerto Rico','communications',773,'Railroads: 3,625 km total: state-owned
Portuguese Railroad Co. (CP) r perates 2,858
km 1 .665-meter gauge (434 km electrified and
426 km double track), 755 km 1 .000-meter
gauge; 1 2 km ( 1 .43S-meter gauge) electrified,
double track, privately owned
Highways:
total: 73.661 km
paved and gravel: 6 1 ,599 km (including 453
km of expressways)
unpaved: earth 12,062 km
Inland waterways: 820 km navigable;
relatively unimportant to national economy,
used by shallow-drafi craft limited to 300-
metric-ton cargo capacity
Pipelines: crude oil 1 1 km; petroleum
products 58 km
Ports: Leixoes, Lisbon. Porto. Ponta Delgada
(Azores), Velas (Azores), Setubal, Sines
Merchant marine: 61 ships (1,000 GRT or
over) totaling 962,293 GRT/1, 779,855 DWT,
short-sea passenger 2, cargo 25, refrigerated
cargo 3, container 3, roll-on/roll-off cargo I ,
oil tanker 18, chemical tanker 4, bulk 3,
liquified gas 2
note: Portugal has created a captive register on
Madeira (MAR) for Portuguese-owned ships
that will have the taxation and crewing benefits
of a flag of convenience; although only one
ship currently is known to fly the Ponuguese
flag on the MAR register, it is likely that a
majority of Portuguese flag ships will transfer
to this subregister in a few years
Airports:
total; 65
usable: 63
with permanent-surface runways: 37
with runways over 3,659 m: 2
with runways 2,440-3,659 m: 10
with runways 1,220-2,439 m: 1 1
Telecommunications: generally adequate
integrated network of coaxial cables, open wire
and microwave radio relay: 2,690,000
telephones; broadcast stations — 57 AM, 66 (22
repeaters) FM, 66 (23 repeaters) TV; 6
submarine cables; 3 INTELSAT earth stations
(2 Atlantic Ocean, I Indian Ocean),
EUTELSAT, domestic satellite systems
(mainland and Azores); tropospheric link to
Azores
Defense Forces
Branches: Army, Navy (including Marines).
Air Force. National Republican Guard, Fiscal
Guard, Public Security Police
Manpower availability: males age 15-49
2,723.987; fit for military service 2,207,637;
reach military age (20) annually 89,380 (1994
est.)
Defense expenditures; exchange rate
conversion — $2.4 billion, 2.9% of GDP ( 1 992)
North AHantic Ocean
Isia da
ViBQuas
Carittaan Sea
0«Mch*o and
Itla Mona aft net ahewn.
Railroads: 96 km rural narrow-gauge system
for hauling sugarcane; no passenger railroads
Highways:
total: 1 3,762 km
paved: 13,762 km (1982)
Ports: San Juan. Ponce, Mayaguez, Arecibo
Airports:
total: 30
usable: 23
with permanent-surface runways: 19
with runways over 3,659 m: 0
323
Puerto Rico (continued)','20280d0cc5d54c96ebc696ba4ecc9aa1353e8238106454e5c09dd653aeaa3dd8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a586e869a370a8b95e6e35858da57c0570d0f835a84da05bc7d720a22981d88',1994,'QA','Qatar','communications',778,'with runways 2,440-3,659 in: 3
with runway.s 1 ,220-2,439 m: 5
Telecommunications: modern system,
integrated with that of the US by high capacity
submarine cable and INTELSAT with
high-speed data capability; digital telephone
system with about I million lines; cellular
telephone service; broadcast stations — 50 AM.
63 FM, 9 TV; cable television available with
US programs (1990)
Defense Forces
Branches: paramilitary National Guard,
Police Force
Note: defense is the responsibility of the US','d1d0a2faa9dc30e8010e927462aed2a7847ed22c7157b9f18665d702ff720a0e','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d67d0e6af2094097780510d53095341ef0fe0008a7428fca71820b116c38b7ca',1994,'RO','Romania','communications',781,'Highways:
total; 2,800 km
paved; 2,200 km
unpaved: gravel, crushed stone, stabilized
earth 600 km
Ports: Pointe des Galets
Airports:
total: 2
usable; 2
with permanent-surface runways; 2
with runways over 3,659 m; 0
with runways 2,440-3,659 m; I
with runways 1,220-2.439 m: 1
Telecommunications: adequate system;
modem open-wire and microwave network;
principal center Saint-Denis;
radiocommunication to Comoros, France,
Madagascar; new microwave route to
Mauritius; 85,900 telephones; broadcast
stations — 3 AM, 1 3 FM, 1(18 repeaters) TV; 1
Indian Ocean INTELSAT earth station
Defense Forces
Branches: French Forces (including Army,
Navy, Air Force, Gendarmerie)
Manpower availability: males age 15-49
170,810; fit for military service 88,108; reach
military age (18) annually 5,867 (1994est.)
Note: defense is the responsibility of France
aQOI-m','aa9a257e314a726c5e6654090a0cd06567b5f5d82a6ed9cd2a518c7558dd0456','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b64afde91a6e3142c72fdd36cf41de0655f493069da7a9d2ae8450fda85b67ba',1994,'UA','Ukraine','communications',787,'Railroads: 1 1 ,275 km total; 10,860 km 1 ,435-
meter gauge. 370 km narrow gauge, 45 km
broad gauge; 3,41 1 km electrified, 3,060 km
double track; government owned (1987)
Highways;
loial: 72,799 km
paved: 35,970 km
unpaved: gravel, crushed stone, stabilized
earth 27,729 km: unsurfaced earth 9,100 km
(1985)
Inland waterways: 1 ,724 km ( 1 984)
Pipelines: crude oil 2,800 km, petroleum
pr^ucts 1 ,429 km, natural gas 6,4(X) km
(1992)
Ports: Constanta, Galati, Braila, Mangalia;
inland ports are Giurgiu, Drobeta-Tumu
Severin, Orsova
Merchant marine: 24 1 ships ( 1 ,0(X) GRT or
over) totaling 2,626,421 GRT/4,0 17,380
DWT, passenger-cargo 1 , cargo 1 67, container
2, rail-car carrier 1, roll-on/roll-off cargo 7, oil
tanker 14, bulk 49
Airports:
total: 234
usable: 74
with pennanent-suiface runways: 26
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 2 1
with runways 1,060-2,439 m: 24
note: a C-130 can land on a 1.060-m airstrip
Telecommunications: poorservice; about 2.3
million telephone customers; 89% of phone
network is automatic: cable and open wire;
trunk network is microwave; present phone
density is 9.85 per 1 00 residents; roughly 3,300
villages with no service (February 1990); new
digital international direct dial exchanges are
in Bucharest (1993); broadcast stations — 12
AM, 5 FM, 13 TV (1990); I satellite ground
station using INTELSAT
Defense Forces
Branches: Army, Navy, Air and Air Defense
Forces, Paramilitary Forces, Civil Defense
Manpower availability: males age 1 5-49
5,888,452; fit for military service 4,972,834;
reach military age (20) annually 193,901 (1994
est.)
Defense expenditures: 137 billion lei, 3% of
GDP (1993); note — conversion of defense
expenditures into US dollars using the current
exchange rate could produce misleading results
2000 km
Raiiroads: 1,300 km, 1.000-meter-gauge
single track
Highways;
total: 26,200 km
paved: 1,970 km
unpaved: gravel, emshed stone 5,849 km;
earth, tracks 1 8,38 1 km
Inland waterways: Lake Victoria, Lake
Albert, Lake Kyoga, Lake George, Lake
Edward; Victoria Nile, Albert Nile; principal
inland water ports are at Jinja and Port Bell,
both on Lake Victoria
Merchant marine: 3 roll-on/roll-off cargo
ships ( 1 ,(X)0 GRT or over) totaling 5.09 1 GRT/
NADWT
Airports:
total: 3 1
usable: 23
with permanent-surface runways: 5
with runways over 3,659 m: 1
with runways 2,440-3,659 m: 3
with runways 1,220-2,439 m: 1 1
Telecommunications: fair system with
microwave and radio communications stations:
broadcast stations — 10 AM, no FM, 9 TV;
satellite communications ground stations — I
Atlantic Ocean INTELSAT
Defense Forres
Branches: National Resistance Army (NRA):
includes Air Force and Navy, Local Defense
Units (LDU)
Manpower availability: males age 15-49
4,138,087; fit for military service 2,248,232
Defense expenditures: exchange rate
conversion— $NA, 15% of budget (FY89/90)
aoBtSM
centrally planned economies
a term applied mainly to the baditionally Communist states that looked to the former USSR for
leadership; most are now evolving toward more democratic and market-oriented systems; also
known formerly as the Second World or as the Communist countries; through the 1980s, this
group included Albania, Bulgaria, Cambodia, China, Cuba, Czechoslovakia, GDR, Hungary,
North Korea, Laos, Mongolia, Poland, Romania, USSR, Vietnam, Yugoslavia
Colombo Plan (CP)
members — (24) Afghanistan, Australia, Bangladesh, Bhutan, Burma, Cambodia, Fiji, India,
Indonesia, Iran, Japan, South Korea, Laos, Malaysia, Maldives, Nepal, NZ, Pakistan, Papua
established — 1 July 1951
aim — to promote economic and social
development in Asia and the Pacific
New Guinea, Philippines, Singapore, Sri Lanka, Thailand, US
Commission for Social Development
established — 21 June 1946 as the Social
Commission, renamed 29 July 1966
aim — Economic and Social Council
organization dealing with social development
programs of UN
members — (32) selected on a rotating basis from all regions
Commission on Human Rights
established — 18 February 1946
aim — Economic and Social Council
organization dealing with human rights
programs of UN
members — (53) selected on a rotating basis from all regions
Commission on Human Settlements
(Habitat)
established — 12 October 1978
aim — Economic and Social Council
organization assisting in solving human
settlement problems of UN
members — (58) selected on a rotating basis from all regions
Commission on Narcotic Drugs
established — 16 February 1946
nim — Economic and Social Council
organization dealing with illicit drugs
programs of UN
members — (53) selected on a rotating basis from all regions with emphasis on producing and
processing countries
Commission on the Status of Women
eriablished — 21 June 1946
aim — Economic and Social Council
organization dealing with women''s rights
goals of UN
members — (32) selected on a rotating basis from all regions
456
Commonwealth (C)
established — 31 December 1931
aim — voluntary association that evolved
from the British Empire and that seeks to
foster multinational cooperation and
assistance
members — (48) Antigua and Barbuda, Australia, The Bahamas, Bangladesh, Barbados, Belize,
Botswana, Brunei. Canada, Cyprus, Dominica, The Gambia, Ghana, Grenada, Guyana, India,
Jamaica, Kenya, Kiribati, Lesotho, Malawi, Malaysia, Maldives, Malta, Mauritius, Namibia, NZ,
Nigeria, Pakistan, Papua New Guinea, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Seychelles, Sierra Leone, Singapore, Solomon Islands, Sri Lanka, Swaziland,
Tanzania, Tonga, Trinidad and Tobago, Uganda, UK, Vanuatu, Western Samoa, Zambia,','0841b0f7a45f3333a3cafd8905b73d0e929ce6bb5d07dba55ca58a51c03e21e7','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ae0c5aee387995efa8b2b6b917813980519b9edece89dc35e9a19f35919a325',1994,'RW','Rwanda','communications',789,'Railroads: 158,100kmall 1.520-meter broad
gauge; 86,800 km in common carrier service,
of which 48,900 km are diesel traction and
37.900 km are electric traction; 71,300 km
serves specific industry and is not available for
common carrier use (30 June 1993)
Highways:
total: 893,000 km
paved and gravel; 677,000 km
unpaved: 216,000 km
Inland waterways: total navigable routes in
general use 100,0i00 km; routes with navigation
guides serving the Russian River Fleet 95,900
km; of which routes with night navigational
aids 60,400 km; man-made navigable routes
16.900 km (30 June 1993)
Pipelines: crude oil 48,000 km, petroleum
products 15,000 km, natural gas 140,000 km
(30 June 1993)
Ports: coastal — St. Petersburg, Kaliningrad,
Murmansk, Petropavlovsk, Arkhangel''sk,
Novorossiysk, Vladivostok. Nakhodka.
Kholmsk, Korsakov, Magadan, Tiksi, Tuapse,
Vanino, Vostochnyy, Vyborg; inland —
Astrakhan'', Nizhniy Novgorod, Kazan’,
Khabarovsk, Krasnoyarsk, Samara, Moscow,
Rostov, Volgograd
Merchant marine: 867 shipc (1,000 CRT or
over) totaling 8.084,988 GRT/1 1 , 1 24,929
DWT, cargo 454, container 82, multi-function
large load carrier 3, barge carrier 2. roll-on/
roll-off cargo 74, oil tanker 1 25, bulk cargo 26,
chemical tanker 9, specialized (anker 2,
combination ore/oil 1 6. passenger cargo 5,
short-sea passenger 18, passenger 6.
combination bulk 28, refrigerated cargo 17
Airports:
total; 2,550
usable: 964
with permanent-surface runways; 565
with runways over 3,659 m; 19
with runways 2,440-3,659 m: 275
with runways 1,220-2,439 m: 426
Telecommunications: Russia is enlisting
foreign help, by means of joint ventuies, to
speed up the modernization of its
telecommunications system; NMT-450 analog
cellular telephone networks are operational and
growing in Moscow and St. Petersburg;
expanded access to international E-mail
service available via Sprint network; intercity
fiberoptic cable installation remains limited;
the inadequacy of Russian telecommunications
is a severe handicap to the economy, especially
with respect to international connections; total
installed telephones 24,400,000, of which in
urban areas 20,9(X),000 and in rural areas
3,500,000; of these, total installed in homes
15,400,000; total pay phones for long distant
calls 34,100; telephone density is about 164
telephones per 1,000 persons (in 1992, only
661,000 new telephones were installed
compared with 8S5,(X)0 in 1991 and in 1992
the number of unsatisfied a{^lications for
telephones reached 1 1,000,000); international
traffic is handled by an inadequate system of
satellites, land lines, microwave radio relay
and outdated submarine cables; this traffic
passes through the international gateway
switch in Moscow which carries most of the
international traffic for the other countries of
the Commonwealth of Indqiendent States; a
new Russian Raduga satellite will link
Moscow and St. Petersburg with Rome from
whence calls will be relayed to destinations in
Europe and overseas; satellite ground
stations — INTELSAT, Intersputnik, Eutelsat
(Moscow), INMARSAT, Orbita; broadcast
stations — 1,050 AM/FM/SW (reach 98.6% of
population), 7, 1 83 TV; receiving sets —
54,200,000 TVs, 48,8(jo,000 radio receivers,
74,300,0(X) radio receivers with multiple
speaker systems for program diffusion
Defense Forces
Branches: Ground Forces. Navy. Air Forces,
Air Defense Forces, Strategic Rocket Forces,
Command and General Support, Security
Forces
Manpower availability: males age 15-49
37,7()6,825; fit for military service 29,623,429;
reach military age (18) annually 1,098,307
(1994 est.)
Defense expenditures: SNA, NA% of GDP
SB km','0b6ed2ce82b1f396edd1379ee4f188d42221ecbb0e6b1790964b5dc6af57b4c0','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('969aa3421151481bf03eade0327ebf149a8a2f948a93268c664b059534dbc478',1994,'LC','Saint Lucia','communications',795,'Railroads; 58 km 0.760-meter gauge on Saint
Kitts for sugarcane
Highways:
total: 3()0 km
paved: 1 25 km
unpaved: otherwise improved 125 km;
unimproved earth 50 km
Ports: Basseterre (Saint Kitts), Charlestown
(Nevis)
Airports:
total: 2
usable: 2
with permanent-surface runways: 2
with runways over 3,659 tn: 0
with runways 2,440-3,659 rn: 1
with runways 1,220-2,439 ni: 0
Telecommunications: good interisland VHF/
UHF/SHF radio connections and international
link via Antigua and Barbuda and Saint Martin;
2,400 telephones; broadcast stations — 2 AM,
no FM, 4 TV
Defense Forces
Branches: Royal Saint Kitts and Nevis Police
Force, Ciiast Guard
Defense expenditures: exchange rate
conversion — SNA, NA% of GDP
Highways:
total: 760 km
paved: 500 km
unpaved; otherwise improved 260 km
Ports: Castries, Vieux Fort
Airports:
total: 3
usable; 3
with permanent-surface runways; 3
with runways over 3,659 m: 0
with runways 2,440-3,659 m: I
with runways t ,220-2,439 m: I
Telecommunications: fully automatic
telephone system; 9,500 telephones; direct
microwave link with Martinique and Saint
Vincent and the Grenadines; interisland
troposcatter link to Barbados; broadcast
stations — 4 AM, 1 FM, I TV (cable)
Defense Forces
Branches: Royal Saint Lucia Police Force,
Coast Guard
Defense expenditures: exchange rate
conversion — SNA, NA% of GDP
338','3184b3b527225ec85c1b816563379e6bb05ee1c6235320aa3bd46dd9d146de08','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05dd8a339db164d710cf24b85e1d601dcc1873f86a37c1257abe7c3c03441569',1994,'PM','Saint Pierre and Miquelon','communications',800,'(territorial collectivity of France)
Highways:
lotai: 120 km
paved: 60 km
unixived: earth 60 km (1985)
Ports: Saint Pierre
Airports:
total: 2
usable: 2
with permanent-surface runways: 2
with runways overJ,659 in: 0
with runways 2,440-3,659 in: 0
with runways 1,220-2,439 m: 1
Teiecommunications: 3,601 telephones;
broadcast stations — 1 AM, 3 FM, no TV; radio
communication with most countries in the
world; 1 earth station in French domestic
satellite system
Defense Forces
Note: defense is the responsibility of France','fffb1a88f73d8eac89a1994d3911177a252546626cebaee46ef982ae752ea7fa','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9137aa1b5c5981d319da25136148414f200214621cb2e101ca35df913e0384f',1994,'VC','Saint Vincent and the Grenadines','communications',806,'Caribbean z ''
Sea A
A
CaMtmn
Highways:
loud; 1,000 km
paved; 3(X) km
un/tawd; improved earth 400 km: unimproved
earth 300 km
Ports; Kingstown
Merchant marine: 555 ships ( 1 ,000 CRT or
over) totaling 5,575,652 GRT/9, 262,250
DWT, passenger 2, short-sea passenger 2,
passenger-cargo 5, cargo 280, container 3 1 ,
roll-on/roll-off cargo 26, refrigerated cargo 19,
oil tanker 56, chemical tanker 1 3, liquefied gas
7, bulk 96, combination bulk 1 2, vehicle currier
I, livestock carrier I , .specialized tanker I,
combination ore/oil 2, multi-function large
loud carrier I
note; China owns 5 ships, Croatia owns 58,
Russia owns 16: a flag of convenience registry
Airports:
total; 6
usable; 6
with permanent-surface runways; 5
with runways over J,659 in; 0
with runways 2,440-3,659 in; 0
with runways 1,220-2,439 in; 1
Telecommunications: islandwide fully
automatic telephone system; 6,500 telephones:
VHF/UHF interisland links from Saint Vincent
to the other islands of the Grenadines and
Barbados: new SHF links to Grenada and Saint
Lucia: broadcast stations — 2 AM. noFM, 1 TV
(cable)
Defense Forces
Branches: Royal Saint Vincent and the
Grenadines Police Force, Coast Guard
Defense expenditures: exchange rate
conversion — $NA, NA% of GDP
341','e65c8b8eabce75ef1313f8694b74a7c37b09f704c643c4cce80e8615566cfee6','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cf229e7bd6cdaefbb9221b17ecceabd17a67311c1a2e7ac604eeedfc640b74e',1994,'ST','Sao Tome and Principe','communications',818,'Highways:
total: 104 km
paved: NA
unpaved: NA
Telecommunications: automatic telephone
system completely integrated into Italian
system; 1 1 ,700 telephones; broadcast services
from Italy; microwave and cable links into
Italian networks; no communication satellite
facilities
Defense Forces
Branches: public security or police force
Defense expenditures: $3.7 million ( 1 992
est.), 1% of GDP
JOJun.,
//*• do ,
rrinctpe''
4
TinhoMa PaguanB^
Wfidu i
l*nte Antonio
*liMu
*Tinhos9 Gr9r>d»
Gulf
of
Guinoa
w
f/hdw C*6r*a
Nnl<^|K TOuf
Ifha do
Sao Tomd.-—,
mtu
0 Cotfitnna ^','97f1a2019a996f568d5c9be0a4eed812fe28c3421472189f03bafc212b14b0b9','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d162445269ba189ffc11de07f376c3552bf5ef1b7d63fd428c0b843263c7bffb',1994,'SN','Senegal','communications',823,'and almost all export earnings. Saudi Arabia
has the largest reserves of petroleum in the
world, ranks as the largest exporter of
petroleum, and plays a leading role in OPEC.
For the 1990s the government intends to bring
its budget, which has been in deficit since
1983, back into balance, and to encourage
private economic activity. Roughly four
million foreign workers play an important role
in the Saudi economy, for example, in the oil
and banking sectors. For about a decade, Saudi
Arabia’s domestic and international outlays
have outstripped its income, and the
government has cut its foreign assistance and is
beginning to rein in domestic programs.
National product: GDP — purchasing power
equivalent — $194 billion (1993 est.)
National product real growth rate: 1 %
(1993 est.)
National product per capita: $11,000(1993
est.)
InflaUon rate (consumer prices): 1% (1993
est.)
Unemployment rate: 6.5% (1992 est.)
Budget:
revenues; $39 billion
expenditures: $50 billion, including capital
expenditures of $7.5 billion (1993 est.)
Expo''-ts: $42.3 billion (f.o.b., 1993 est.)
commodities: petroleum and petroleum
products 92%
partners: US 2 1 %, Japan 1 8%, Singapore 6%,
France 6%. Korea 5%
Imports: $26 billion (f.o.b., 1993 est.)
commodities: machinery and equipment,
chemicals, foodstuffs, motor vehicles, textiles
partners: US 1 8%, UK 12%, Japan 10%,
Germany 5%, France 5%
External debt: $18.9 billion (December 1989
est., includes short-term trade credits)
Industrial production: growth rate 20.0%
(!99l est.): accounts for 46% of GDP,
including petroleum
Electricity:
capacity: 28,554,000 kW
production; 63 billion kWh
consumption per capita: 3,690 kWh ( 1 992)
Industries: crude oil production, petroleum
refining, basic petrochemicals, cetnent, two
small steel-rolling mills, construction,
fertilizer, plastics
Agriculture: accounts for about 10% of GDP,
16% of labor force; subsidized by government;
products — wheat, barley, tomatoes, melons,
dates, citrus fruit, mutton, chickens, eggs, milk;
approaching self-sufficiency in food
Illicit drugs: death penalty for traffickers;
increasing consumption of heroin and cocaine
Economic aid:
donor; pledged bilateral aid (1979-89), $64.7
billion; pledged $100 million in 1993 to fund
reconstruction of Lebanon
Currency: 1 Saudi riyal (SR) = l(X) halalah
Exchange rates: Saudi riyals (SR) per
US$1 — 3.7450 (fixed rate since late 1986),
3.7033(1986)
Fiscal year: calendar year
Railroads: 1390 km 1. 43S-meter standard
gauge; 448 km are double tracked
Highways:
total: 74,000 km
paved: 35,000 km
unpaved: gravel, improved earth 39,000 km
Pipelines: crude oil 6,400 km, petroleum
products 150 km, natural gas 2,200 km,
includes natural gas liquids 1,600 km
Ports: Jiddah, Ad Dammam, Ras Tanura,
Jizan, Al Jubayl, Yanbu’ al Bahr, Yanbu’ al
Sinaiyah
Merchant marine: 74 ships ( 1 ,000 GRT or
over) totaling 865,343 GRT/1 ,240,874 DWT,
passenger 1, short-sea passenger 7, cargo 11.
roll-on/roll-off cargo 1 1, container 3,
refrigerated cargo 6, livestock carrier 5, oil
tanker 23, chemical tanker 4, liquefied gas 1 ,
specialized tanker 1, bulk 1
Airports:
total: 215
usable: 195
with permanent-surface runways: 7 1
with runways over 3,659 m: 14
with runways 2,440-3,659 m: 38
with runways 1,220-2,439 in: 105
Telecommunications: modem system with
extensive microwav'' and coaxial and fiber
optic cable systems; 1 ,624,(X)0 telephones:
broadcast stations— 43 AM, 13 FM. 80 TV;
microwave radio relay to Bahrain, Jordan,
Kuwait, Qatar, UAE, Yemen, and Sudan;
coaxial cable to Kuwait and Jordan; submarine
cable to Djibouti, Egypt and Bahrain; earth
stations — 3 Atlantic Ocean INTELSAT, 2
Indian Ocean INTELSAT, I ARABSAT, 1
INMARSAT
Branches: Land Force (Army), Navy, Air
Force, Air Defense Force, National Guard.
Coast Guard, Frontier Forces, Special Security
Force, Public Security Force
Manpower availability: males age 1 5-49
5.682,036; fit for military service 3,140,464;
reach military age (17) annually 147,420(1994
est.)
Defense expenditures; exchange rate
conversion — $ 1 6.5 billion, 1 3% of GDP ( 1 993
budget)
ISOtm
Beundary r«p>»fthl«llBn ig
nal nacttiirHy ■ulhoriUilvt.
Location; Western Africa, bordering the
North Atlantic Ocean between Guinea-Bissau
and Mauritania
Map references: Africa, Standard Time
Zones of the World
Area:
total area: 196,190 sq km
land area: 1 92,000 sq km
comparative area; slightly smaller than South
Dakota
Land boundaries; total 2,640 km. The
Gambia 740 km, Guinea 330 km, Guinea-
Bissau 338 km, Mali 419 km, Mauritania 813
km
Coastline: 531 km
Maritime claims;
contiguous zone: 24 nm
continental shelf: 200 nm or the edge of
continental margin
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
International disputes: short section of the
boundary with The Gambia is indefinite;
Senegal and Guinea-Bissau signed an
agreement resolving their maritime boundary
in 1993; boundary with Mauritania
Climate; tropical; hot, humid; rainy season
(December to April) has strong southeast
winds; dry season (May to November)
dominated by hot, dry harmattan wind
Terrain: generally low, rolling, plains rising
to foothills in southeast
Natural resources: fish, phosphates, iron ore
Land use:
arable land: 27%
permanent crops: 0%
meadows and pastures: 30%
forest and woodland: 31%
other: 12%
Irrigated land: 1 ,800 sq ( 1 989 est.)
Railroads: 1 .034 km 1 .000-meter gauge; all
single track except 70 km double track Dakar
to Thies
Highways;
total: 14,(X)7 km
paved: 3,777 km
unpaved: crushed stone, improved earth
10,230 km
Inland waterways; 897 km total; 785 km on
the Senegal, 1 12 km on the Saloum
Ports: Dakar, Kaolack, Foundiougne,
Ziguinchor
Merchant marine: 1 bulk ship ( 1 ,000 CRT
and over) totaling 1,995 ORT/3,775 DWT
Airports:
total: 26
usable: 20
with permanent-surface runways: 10
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 1
with runways 1 ,220-2,439 m: 16
Telecommunications: above-average urban
system, using microwave and cable; broadcast
stations — 8 AM, no FM, I TV; 3 submarine
cables; I Atlantic Ocean INTELSAT earth
station
Defense Forces
Branches: Army, Navy, Air Force,
Gendarmerie, National Police
Manpower availability: males age 15-49
1,951,370; fit for military service 1,018,802;
reach military age (18) annually 94,973 (1994
est.)
Defense expenditures: exchange rate
conversion — $100 million, 2% of GDP (1989
est.)
MiVM » I lMll|r
UrfWIMv.
Note: Serbia and Montenegro have asserted
the formation of a joint independent state, but
this entity has not been formally recognized as
a state by the US; the US view is that the
Socialist Federal Republic of Yugoslavia
(SFRY) has dissolved and that none of the
successor republics represents its continuation','b47f97c8de639d9f7b4b34074d26a5ba5fe67c2eeff25b2ce907f852d1e9f56d','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34b0c0a5022287cf989c9dc3bf057ca41ff6815b7a69c2f386f4141f148980e0',1994,'ME','Montenegro','communications',827,'Raiiroads; NA
Highways:
total: 46,019 km
paved: 26.949 km
unpaved: gravel 10.373 km; earth 8,697 km
(1990)
Inland waterways; NAkm
Pipelines: crude oil 415 km, petroleum
products 1 30 km, natural gas 2.110 km
Ports: coastal — Bar; inland — Belgrade
Merchant marine:
Montenegro: 42 ships (1,000 GRT or over)
totaling 804. 1 56 GRT/ 1.368,8 1 3 DWT
(controlled by Montenegrin beneficial owners)
cargo 16. containers, bulk 19. passenger ship
I . combination ore/oil I
note: most under Maltese flag
Serbia: total 3 ( 1 ,000 GRT or over) totaling
246.63 1 GRT/45 1 .843 DWT (controlled by
Serbian benetlcial owners)
bulk 2, conbination tanker/ore carrier I
note: all under the flag of Saint Vincent and the
Grenadines; no .ships remain under Yugoslav
Hag
Airports:
total; 55
usable; 5 1
with permanent-surface runways: 1 8
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 1
with runways 1,220-2,439 m: 1 1
Telecommunications; 700,000 telephones;
broadcast stations — 26 AM, 9 FM, 18 TV;
2,015,000 radios; 1,000,000 TVs; satellite
ground stations — I Atlantic Ocean
INTELSAT
Defense Forces
Branches: People’s Army — Ground Forces
(internal and border troops). Naval Forces, Air
and Air Defense Forces, Frontier Guard,
Territorial Defense Force, Civil Defense
Manpower availability:
Montenegro: male.s age 15-49 179,868; fit for
military service 146,158; reach military age
(19) annually 5,399 (1994 est.)
Serbia: males age 15-49 2,546,717; fit for
military service 2.048,92 1 ; reach military age
(19) annually 80,937 (1994 est.)
Defense expenditures; 245 billion dinars,
4%>-6% of GDP (1992 est.); note — conversion
of defense expenditures into US dollars using
the prevailing exchange rate could produce
misleading results','8f2f38f719eb7b9ed4c212ad6cc59e494cb265b77934e40ca511f749b9b71789','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e4106f4c30a5c3ddb22d23bbe1503a0d497bed7227b0abab264cedf49d38936',1994,'SC','Seychelles','communications',828,'mas.
VICTORIA*^^ ''o
J Mahe
Les Amirantas''^
indi^n Ocean
Groupe
d’ Aldabra
y
Atoll de
■ Cosmoledo
'' Atoll de
Farquhiir','35bba4524ec86b60947eabe31675ef7d8c7460de168bec60d17817a77240f1e9','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9885f9238aa18ab218a8d9a5a53c1d74b0c8d0aea0470d63f8f534d95e08c40',1994,'SL','Sierra Leone','communications',835,'Highways;
total: 260 km
paved; 1 60 km
unpaved: crushed stone, earth 100 km
Ports: Victoria
Merchant marine: I refrigerated cargo (over
1 ,000 GRT) totaling 1 ,827 GRT/2, 1 70 DWT
Airports:
total; 14
usable; 14
with pennanent-surface runways: 8
with runways over 3,659 m; 0
with runways 2,440-3,659 m; I
with runways 1,220-2,439 m; 0
Telecommunications: direct radio
communications with adjacent islands and
African coastal countries; 13,000 telephones;
broadcast stations — 2 AM, no FM, 2 TV; 1
Indian Ocean INTELSAT earth station; USAF
tracking station
Defense Forces
Branches: Army, National Guard, Marines,
Coast Guard, Presidential Protection Unit.
Police Force
Manpower availability: males age 15-49
19,399; fit for military se.vice 9.900
Defense expenditures: exchange rate
conversion — $12 million, 4% of GDP (1990
est.)
Location: Western Africa, bordering the
North Atlantic Ocean between Guinea and','c0427480e1928153c014218a90755ab1a9e14e38dd7d73a47ee051779e886fa8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('530e17b3bce69bc86b30a3256a59b10c47c28b749f4f2f0616a2058e741ae9de',1994,'SG','Singapore','communications',836,'Inland waterways: 800 km; 600 km
navigable year round
Ports: Freetown, Pepel, Bonthe
Merchant marine: 1 cargo ship (over 1 ,000
CRT) totaling 5,592 GRT/9,107 DWT
Airports:
total: 1 1
usable: 7
with permanent-surface runways: 3
with runways over 3,659 m: 0
with runways 2,440-3,659 m: I
with runways 1,220-2,439 m: 3
Telecommunications: marginal telephone
and telegraph service; national microwave
radio relay system unserviceable at present;
23,650 telephones; broadcast stations — 1 AM,
1 FM, I TV; 1 Atlantic Ocean INTELSAT
earth station
Defense Forces
Branches: Army, Navy, Police, Security
Forces
Manpower availability; males age 15-49
1,006,280; fit for military service 487,158
Defense expenditures: exchange rate
conversion — $6 million, 0.7% of GDP (1988
est.)
Put§u
Railraad.s: 38 km of I .IXX)-meter gauge
Highways:
total; 2,644 km (1985)
/uived; NA
unpaved; NA
Ports: Singapore
Merchant marine: 533 ships ( 1 .0(K) GRT or
over) totaling 10,656,067 GRT/1 7,009,400
DWT, passenger-cargo 1 , cargo 1 25, container
80, roll-on/roll-off cargo 6, refrigerated cargo
3. vehicle carrier 20, livestock carrier 1 , oil
tanker 179, chemical tanker 14, combination
ore/oil 8, specialized tanker 2, liquefied gas 4,
bulk 87, combination bulk 3
note; many Singapore flag ships are foreign
owned
Airports:
total; 10
usable; 10
with pennanent-sutface runways; 10
with runways over 3,659 m; 2
with runways 2,440-3,659 in; 4
with runways 1,220-2,439 m; 3
Telecommunications: good domestic
facilities; giKxl international service; good
radio and television broadcast coverage;
1,11 0,0(K) telephones: broadcast stations — 1 3
AM. 4 FM, 2 TV; submarine cables extend to
Malaysia (Sabah and Peninsular Malaysia),
Indonesia, and the Philippines; satellite earth
.stations — I Indian Ocean INTELSAT and 1
Pacific Ocean INTELSAT
Defense Forces
Branches: Army. Navy, Air Force, People’s
Defense Force, Police Force
Manpower availability: males age 15-49
857,824; fit for military service 630,055
Defense expenditures: exchange rate
conversion — $2.7 billion. 6% of GDP(1993
est.)','6a3cafc9ad72874f7993578c9c7e5663e8c6a0a297727644d6253b1d504d919f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd431a050bbbd19aa54373064d8594aa82dbba0a9b7b3b353770045fddfb0be9',1994,'SB','Solomon Islands','communications',848,'400 km
South
Pacific
Ocean
o *•
Gizo
Choiseu!
Isite/
''•0^ ^ ^
Honiara
Guadalcanal
^S#n
'' * Cristobal
Santa
ip Crus
Islands
Coral Sea','dfe37e6f8411c6043e71e9d277da89442a6c5708c31ac5bf90eadf0dc30c06e9','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a12f118263e2ccbfa54ab9289424c957be2b1694850e9be718c77481c93eb12a',1994,'SO','Somalia','communications',855,'Highways:
total: 1,3(K) km
paved: 30 km
impaved: gravel 290 km; earth 980 km
note: in addition, there are 800 km of private
logging and plantation roads of varied
construction (1982)
Ports: Honiara, Ringi Cove
Airports:
total: 31
usable: 30
with permanent-surface runways: 2
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 0
with runways 1,220-2,439 m: 4
Telecommunications; 3,000 telephones;
broadcast stations — 4 AM, no FM, no TV; 1
Pacific Ocean INTELSAT earth station
Defense Forces
Branches: Police Force
Defense expenditures: exchange rate
conversion — SNA, NA% of GDP','e453d0e1ad489fcf0f2f5522857023f42f924d26b26d0418c769d4379a86c3ba','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d62d7164e9beee2b192df545721a67b2029dc0c6faeaa3e14c1244ec955c9fd',1994,'ZA','South Africa','communications',860,'Highways:
lomi: 22.500 km
paved: 2.700 km
unpaved: gravel 3.000 km; improved,
stabilized earth 16,800 km (1992)
Pipelines: crude oil 15 km
Ports: Mogadishu. Berbera. Chisimayu
(Kismaayo), Bender Cassim (Boosaaso)
Merchant marine; 2 ships ( 1 .000 CRT or
over) totaling 5.554 GRT/6,892 DWT. cargo 1 ,
refrigerated cargo 1
Airports:
total: 76
usable: 59
with pemanent-suiface runways: 8
with runways over 3,659 m: 2
with runways 2.440-3,659 m: 6
with runways 1.220-2,439 ni: 24
Telecommunications: the public
telecommunications system was completely
destroyed or dismantled by the civil war
factions; all relief organizations depend on
their own private systems (199.3)
Defense Forces
Branches: NA
Manpower availability: males age 15-49
1,630.864; fit for military service 915.368
Defense expenditures: exchange rate
conversion — SNA. NA% of GDP
400 km','90fb185f5e8619f7ab506553ae4057fb85ed46b990ac25d8b80fd31dccad0fa6','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('93e3c7201d565976d4e5c4da8060dc7cb983d5d2aa32926f42f750b859b30425',1994,'LK','Sri Lanka','communications',861,'South China Saa
^Notth99$i Car
Southwest
j Wffii York
rhitu tslaf)d . * ♦ /s4nd
*■ -tan*/tfrMC«y f{a#
4 a ^sfitnti fsterKh ,
* Namyit /stand
Sm Cowe /stand ^ ^
%
^ftery Cross »
aSoratty /stand
s»4Wso/)
ftaaf
^Amboyna Cay','c5083e4d4cc90879221da7913faa8c8dc7767e0ee2afd5bae5ab6be7cd3096b7','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9174fbdf1b818601c2a3abfc002858d90942fa0b51e30dfae96f2ecefe1a196e',1994,'SD','Sudan','communications',863,'Railroads: 1,948 km total (1990); all 1.868-
meter broad gauge; 102 km double truck; no
electrification; government owned
Highways:
total; 75.263 km
paved: mostly bituminous treated 27,637 km
unpaved; crushed stone, gravel 32,887 km;
improved, unimproved earth 14,739 km
Inland waterways: 430 km; navigable by
shallow-draft craft
Pipelines: crude oil and petroleum products
62 km (1987)
Ports: Colombo, Trincomalee
Merchant marine: 26 ships ( 1 ,000 GRT or
over) totaling 289,1 15 GRT/453.609 DWT,
cargo 12, refrigerated cargo 8, container I, oil
tanker 3, bulk 2
Airports:
totai; 14
usable; 13
with permanenhsuiface runways; 12
with runways over 3,659 m; 0
with runways 2,440-3,659 m; I
with runways 1,220-2,439 in: 8
Telecommunications: very inadequate
domestic service, good international service;
1 14,000 telephones (1982); broadcast
station.s — 12 AM, 5 FM, 5 TV; submarine
cables extend to Indonesia and Djibouti; 2
Indian Ocean INTELSAT earth stations
Defense Forces
Branches: Army, Navy, Air Force, Police
Force
Manpower availability: males age 15-49
4,906,666; fit for military service 3.825,774;
reach military age ( 1 8) annually 1 78,2 1 3 ( 1 994
est.)
Defense expenditures; exchange rate
conversion— $365 million. 4.7% of GDP
(1992)
Location: Northern Africa, along the Red
Sea, between Egypt and Eritrea
Map references: Africa. Standard Time
Zones of the World
Area:
totai area; 2,505.810 sq km
land area; 2.376 million sq km
comparative area; slightly more than
one-quarter the size of the US
Land boundaries: total 7,687 km. Central
African Republic 1,165 km. Chad 1,360 km,
Egypt 1 ,273 km, Eritrea 605 km, Ethiopia
1 .606 km, Kenya 232 km, Libya 383 km,
Uganda 435 km. Zaire 628 km
Coastline: 853 km
Maritime claims;
continuous zone; 1 8 nm
continental shelf; 200-m depth or to depth of
exploitation
territorial sea: 12 nm
International disputes: administrative
boundary with Kenya does not coincide with
international boundary; administrative
boundary with Egypt does not coincide with
international boundary creating the "Hala’ib
Triangle." a barren area of 20,580 sq km, the
dispute over this area escalated in 1993, this
area continues to be in dispute
Climate: tropical in south; arid desert in
north; rainy season (April to October)
Terrain: generally flat, featureless plain;
mountains in east and west
Natural resources: small reserves of
petroleum, iron ore. copper, chromium ore.
zinc, tungsten, mica, silver
Land use:
arable land; 5%
permanent crops: 0%
meadows and pastures; 24%
forest and woodland: 20%
other: 5 1 %
Irrigated land: 18.900 sq km (1989 est.)','eca9a19019009228484ab7b84eac816c50debcdcd57d3a59b2ac3ef8abacc918','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f62c27ca4d8f7dd522f74dc36eebe62d6fbb5373486dac2f9be965d605dff4f8',1994,'SR','Suriname','communications',868,'Railroads: 5,5 16 km total: 4.800 km
1.067-meter gauge, 716 km 1.6096- meter-
gauge plantation line
Highways:
total: 20.703 km
North Atlontic
Railroads: 166 km total; 86 km 1.000-meter
gauge, government owned, and 80 km 1 .435-
meter standard gauge; all single track
Highways:
total; 8,300 km
paved; 500 km
unpaved; bauxite, gravel, crushed stone,
improved earth 5,400 km; sand, clay 2,400 km
Inland waterways: 1,200 km; most
important means of transport; oceangoing
vessels with drafts ranging up to 7 m can
navigate many of the principal waterways
Ports: Paramaribr Moengo, Nieuw Nickerie
Merchant marine. 3 ships (1,000 GRT or
over) totaling 6,472 GRT/8,9 1 4 DWT, cargo 2,
container I
Airports:
total: 46
usable; 38
with permanent-surface runways; 5
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 1
with runways 1,220-2,439 m; 3
Telecommunications: international facilities
good: domestic microwave system; 27,500
telephones; broadcast stations — 5 AM, 14 FM,
6 TV, 1 shortwave; 2 Atlantic Ocean
INTELSAT earth stations
Defense Forces
Branches: National Army (including Navy
which is company-size, small Air Force
element). Civil Police
Manpower availability: males age 15-49
1 1 3,963; fit for military service 67,648
Defense expenditures: exchange rate
conversion — SNA, NA% of GDP
Highways:
total; NA
paved: NA
unpaved: NA
Ports: limited facilities — Ny-Alesund,
Advent Bay
Airports:
total; 4
usable; 4
with permanent-surface runways: 1
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 0
with runways J, 220-2,439 m: 1
Telecommunications: 5 meteorological/
radio stations; local telephone service;
broadcast stations — 1 AM, 1 (2 repeaters) FM,
1 TV, satellite communication with Norwegian
mainland
Defense Forces
Note: demilitarized by treaty (9 February
1920)','7b5801e7a70e41cfc76742ed17dabfb06f71584a781e29b8f063b7493fe85c6d','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e9098d7465c8470c7ef561b831297d92f0bd830066a7a16595fc2dd6a93dc73',1994,'TJ','Tajikistan','communications',875,'Railroads: 480 km; does not include
industrial lines (1990)
Highways;
total: 29,900 km
paved: 21.400 km
unpaved: earth 8,500 km (1990)
Pipelines: natural gas 400 km ( 1 992)
Ports; none; landlocked
Airports:
total: 58
usable: 30
with permanetm-surface runways: 1 2
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 4
with runways 1,060-2,439 m: 1 3
note: a C- 1 30 can land on a 1 .060-m airstrip
Telecommunications: poorly developed and
not well maintained; many towns are not
reached by the national network; 303,000
telephone circuits (December 1991), telephone
density about 55 per 1000 persons! 1 95 1 );
linked by cable and microwave to other CIS
republics, and by leased connections to the
Moscow international gateway switch:
Du-shanbe linked by INTELSAT to
international gateway switch in Ankara;
satellite earth stations — I Orbita and 2
INTELSAT (one INTELSAT earth station
provides TV receive-only service from
Turkey)
Defense Forces
Branches: Army (being formed). National
Guard. Security Forces (internal and border
troops)
Manpower availability: males age 15-49
1,361,143; fit for military service 1,1 16,246;
reach military age (18) annually 57,681 (1994
est.)
Defense expenditures: SNA, NA% of GDP
386
Tanzania
Ltll9
Location: Easte^ n Africa, bordering the
Indian Ocean between Kenya and','f436774f82e6f87145d6e1a8bfbb3babed5abcdd5f54fa3b5d35131a085a708d','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b575f2cfa111c9c8847f6ac7a6496af348863475b23dc2ee645a8514318851dc',1994,'MZ','Mozambique','communications',876,'Map references: Africa, Standard Time
Zones of the World
Area:
loltil area: 945,090 sq km
land area: 886,040 sq km
comparative area: slightly larger than twice
the size of California
note: includes the islands of Mafia, Pemba, and
Zanzibar
Land boundaries: total 3,402 km. Burundi
451 km, Kenya 769 km, Malawi 475 km.
Mozambique 756 km. Rwanda 2 1 7 km,
Uganda 396 km. Zambia 338 km
Coastline: 1 .434 km
Maritime claims:
exclusive economic zone: 200 nm
territorial sea: 1 2 nm
International disputes: boundary dispute
with Malawi in Lake Nyasa: Tanzania-Zaire-
Zambia tripoint in Lake Tanganyika may no
longer be inderinite since it is reported that the
indefinite section of the Zaire-Zambia
boundary has been settled
Climate: varies from tropical along coast to
temperate in highlands
Terrain: plains along coast: central plateau;
highlands in north, south
Natural resources: hydropower potential,
tin. phosphates, iron ore. coal, diamonds.
gemstones, gold, natural gas. nickel
Land use:
arable kind: 5%
permanent crops: 1 9h
meadows and pastures: 409?-
forest and woodland: 479''c
other: 1%
Irrigated land: 1 .530 sq km ( 1 989 e.st.)
Railroads: 969 km total: all of 1 .067-meter
gauge: connects with Zambia railroad at
Tazara
Highways:
total: 8 1 .900 km
paved: 3.600 km
unpaved: gravel, crushed .stone 5.600 km;
improved, unimproved earth 72,700 km
Inland waterways: Lake Tanganyika. Lake
Victoria. Lake Nyasa
Pipelines: crude oil 982 km
Ports: Dar cs Salaam. Mtwara. Tanga, and
Zanzibar are ocean ports: Mwanza on Lake
Victoria and Kigoma on Lake Tanganyika are
inland ports
Merchant marine: 7 ships ( 1 .000 CRT or
over) totaling 29,145 GRT/.39.I86 DWT.
passenger-cargo 2. cargo 3. roll-on/roll-off
cargo I. oil tanker I
Airports:
total: 109
usable: 100
with permanent-surface runways: 12
with runways over 3,659 m: 0
with runways 2.440-3,659 m: 4
with runways 1,220-2,439 m: 40
Telecommunications; fair system operating
below capacity; open wire, radio relay, and
troposcatter; 103,800 telephones; broadcast
stations — 1 2 AM, 4 FM, 2 TV; 1 Indian Ocean
and I Atlantic Ocean INTELSAT earth .station
Defense Forces
Branches: Tanzanian People’s Defense Force
(TPDF; including Army, Navy, and Air Force),
paramilitary Police Field Force Unit, Militia
Manpower availability: males age 15-49
6,01 1 ,564; fit for military service 3,480, 179
Defense expenditures; exchange rate
conversion — SNA, NA% of GDP
388','b4571d42b5fa0c825e1a1cb6d4e810227b47988f2542830f19b22380caa886b7','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('301c64bb3c041d5e1129b6f0e830006da55a6bbbe37c4d79ec9de034bdd6ca99',1994,'TM','Turkmenistan','communications',881,'Defense Forces
Branches: Land Forces, Navy (including
Naval Air and Naval Infantry), Air Force,
Coast Guard, Gendarmerie
Manpower availability: males age 15-49
16,1 12,783; fit for military service 9,828,853:
reach military age (20) annually 614,252 (1994
e.st.)
Defense expenditures: exchange rate
conversion — $14 billion, 5.6% of GDP (1994)
SCO mi','3b3a01740f139a7d99e8156ec1e97b5d05c3c95f5a79566653224fc96038c192','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c36cb5adadc6d429245224a036ed6adf2d19fcdeb1359c6782c50b7a8a964fa3',1994,'AE','United Arab Emirates','communications',902,'tas hm
Boundm is
n>( rwc«ss«ril> lulhonlati^*
Railroads: UK, 16,914 km total; Great
Britain''s British Railways (BR) operates
16,584 km l,43S-inm (standard) gauge
(including 4,545 km electrified and 12,591 km
double or multiple track), several additional
small standard-gauge and narrow-gauge lines
are privately owned and operated; Northern
Ireland Railways (NIR) operates 330 km
1,600-mm gauge (including 190 km double
track)
Highways:
total: 362,982 km (Great Britian 339,483 km;
Northern Ireland 23,499 km)
paved: 362,390 km (Great Britian 339,483 km,
including 2,573 km limited access divided
highway; Northern Ireland 22,907 km)
unpaved: gravel 592 km (in Northern Ireland)
Inland waterways: 2,291 total; British
Waterways Board, 606 km; Port Authorities,
706 km; other, 979 km
Pipelines: crude oil (almost all insignificant)
933 km. petroleum products 2,993 km. natural
gas 1 2,800 km
Ports: London, Liverpool, Felixstowe, Tees
and Hartlepool, Dover, Sullom Voe,
Southampton
Merchant marine: 1 80 ships ( 1 .000 GRT or
over) totaling 3.428,571 GRT/4, 297,489
DWT, passenger 7. short-sea passenger 14.
cargo 35, container 24, roll-on/roll-off cargo
1 3. refrigerated cargo I , oil tanker 59, chemical
tanker 2, liquefied gas 5, specialized tanker I,
bulk 17. combination bulk I , passenger cargo I
Airports:
total: 497
usable: 388
with permanent-surface runways: 25 1
with runways over 3,659 m: I
with runways 2,440-3,659 m: 37
wi ’’ -’wways 1,220-2,439 m: 133
Teiv''communicatlons: technologically
advanced domestic and international system;
30,200.0(X) telephones; equal mix of buried
cables, microwave and optical-fiber systems;
excellent counuywide broadcast systems;
broadcast stations — 225 AM, 525 (mostly
repeaters) FM, 207 (3,210 repeaters) TV; 40
coaxial submarine cables; 5 satellite ground
stations operating in INTELSAT (7 Atlantic
Ocean and 3 Indian Ocean), INMARSAT, and
EUTELSAT systems; at least 8 large
international switching centers
Defense Forces
Branches: Army, Royal Navy (including
Royal Marines), Royal Air Force
Manpower availability: males age 15-49
14,432,081; fit for military service 12,056,828
Defense expenditures: exchange rate
conversion — $42.5 billion, 3.8% of GDP
IFY92/93)
415','a84740c4592255428dc9e8f980a378f25cdbb22919575ff6c0e4c3d7f8a0259e','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4e5ac0c6f9283f5061e900e1e1daf66981315cfc2070cee1e996365ea3bde5f',1994,'US','United States','communications',908,'aOOOlim
Railroads: 240,(HH) km of mainline routes, all
standard 1 .4.35 meter track, no government
ownership (1989)
Highways:
total: 6.243,16.3 km
paved: 3.6.3.3.520 km (including 84,865 km of
417
United States (continued)','a54115d706e66065cb4d36b0bd393fd430551bb22240877468051c1d31914cce','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0b7facfcb67094a899735476dc44c31ae57e3c0bddedf702dc7801b4e94dfa8',1994,'UY','Uruguay','communications',913,'expressways)
unpaved: 2,609,643 km (1990)
Inland waterways: 41,009 km of navigable
inland channels, exclusive of the Great Lakes
(est,)
Pipelines: petroleum 276,000 km ( 1 99 1 ),
natural gas 331,000 km 0991)
Ports: Anchorage. Baltimore, Beaumont,
Boston, Charlesto,., Chicago, Cleveland,
Duluth, Freeport, Galveston, Hampton Roads,
Honolulu, Houston, Jacksonville, Long Beach,
Los Angeles, Milwaukee, Mobile, New
Orleans, New York, Philadelphia, Portland
(Oregon), Richmond (California), San
Francisco, Savannah, Seattle, Tampa,
Wilmington
Merchant marine: 385 ships (1,(X)0 GRT or
over) totaling 1 2,567,000 GRT/19,5 1 1 ,000
DWT, passenger-cargo 3, cargo 36, bulk 23,
tanker 169, tanker tug-barge 13, liquefied gas
13, intermodal 128
note; in addition, there are 219 government-
owned vessels
Airports:
total; 14,177
usable; 12,417
with permanent-surface runways; 4,820
with runways over 3,659 m; 63
with runways 2,440-3,659 m; 325
with runways 1,220-2,439 m: 2,524
Telecommunications: 126,000,000
telephone access lines; 7,557,(XX) cellular
phone subscribers; broadcast stations — 4,987
AM, 4,932 FM, 1 ,092 TV; about 9,000 TV
cable systems; 530,(XX),000 radio sets and
1 93,000,000 TV sets in use; 1 6 satellites and 24
ocean cabie systems in use; satellite ground
stations — 45 Atlantic Ocean INTELSAT and
16 Pacific Ocean INTELSAT (1990)
Defense Forces
Branches; Department of the Army,
Department of the Navy (including Marine
Corps), Department of the Air Force
Defense expenditures: exchange rate
conversion — $315.5 billion. 5.3% of GDP
(1992)
Railroads: 3,000 km, all 1 .435-meter
(standard) gauge and government owned
Highways:
total; 49,900 km
paved: 6,700 km
unpaved: gravel 3,000 km; earth 40,200 km
Inland waterways; 1 ,600 km; used by coastal
and shallow-draft river craft
Ports: Montevideo, Punta del Este, Colonia
Merchant marine: 4 ships ( 1 ,000 GRT or
over) totaling 84,797 GRT/132,296 DWT,
cargo I, container 2, oil tanker 1
Airports;
total: 87
usable: 80
with permanent-suiface runways: 16
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 2
with runways 1,220-2,439 m: l4
Telecommunications: most modem facilities
concentrated in Montevideo; new nationwide
microwave network; 337,000 telephones;
broadcast stations — 99 AM, no FM, 26 TV, 9
shortwave; 2 Atlantic Ocean INTELSAT earth
stations
Defense Forces
Branches: Army, Navy (including Naval Air
Arm, Coast Guard, Marines), Air Force,
Grenadier Guards, Police
Manpower availability: males age 15-49
765,490; fit for military service 621,629
419
Uruguay (continued)','4aecf85a0147c1929436e371ec5fa729868125cecf2cc43b5998d24b15be2c02','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46a4fb29096bdd919bf46480d46da9ff67a72f7921881a1e34d802a03a8c7015',1994,'UZ','Uzbekistan','communications',919,'Defense expenditures: exchange rate
conversion — $216 million, 2.3% of GDP
(1991 est.)
300 km
Railroads: 3.460 km; does not include
industrial lines (1990)
Highways:
total: 78,400 km
paved and gras’el: 67,000 km
unpaved: earth 1 1 ,400 km (1990)
Pipelines: crude oil 250 km, petroleum
products 40 km, natural gas 810 km ( 1992)
Ports: none; landlocked
Airports:
total: 265
usable: 74
with permanent-surface runways: 30
with runways over 3,659 m: 2
with runways 2,440-3,659 m: 20
with runways 1,060-2,439 m: 19
note: a C-130 can land oti a 1.060-m airstrip
Telecommunications: poorly developed;
1 ,458,000 telephone circuits with 68.75
circuits per 1 000 persons (1991): linked by
landline or microwave with CIS member states
and by leased connection via the Moscow
international gateway switch to other
countries; new INTELSAT links to Tokyo and
Ankara give Uzbekistan international access
421
Uzbekistan (continued)','1f311402280d27906896f09112d121c0e17077885662b881d288911ff3fe838d','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b04e9593e9a91c654e02bca93a442fa57e49831fd448f1adacdbffb18828b63',1994,'VU','Vanuatu','communications',925,'independent of Russian facilities; satellite earth
stations — Orbita and INTELSAT; NMT-450
analog cellular network established in
Tashkent
Defense Forces
Branches: Army, National Guard, Republic
Security Forces (internal and border troops)
Manpower availability: males age IS''49
5,388,456; fit for military service 4,403,497;
reach military age ( 1 8) annually 222,405 (1994
est.)
Defense expenditures; er.change rate
conversion — SNA, NA% of GDP
iOOlim
tt .
S»nto
South
i * Pecifie Ocean
CorMf 5m
FORT
^£rrom»nto
•Anwem
Railroads: none
Highways:
total; 1 ,027 km
paved; 240 km
unpaved; 787 km
Ports: Port-Vila, Luganville, Palikoulo
Merchant marine; 1 3 1 ships ( 1 ,000 GRT or
over) totaling 1,992,201 GRT/2,909.38 1
DWT, cargo 23, refrigerated cargo 19,
container 5, vehicle carrier 1 1 , livestock carrier
I, oil tanker 8, chemical tanker 2, liquefied gas
3, bulk 57, combination bulk I, passenger I
note; a flag of convenience registry
Airports;
total; 3 1
usable; 31
with permanent-surface runways; 2
with runways over 3,659 m: 0
with runways 2,440-3,659 m; 1
with runways 1,220-2,439 m; 2
Telecommunications: broadcast stations — 2
AM, no FM. no TV; 3,000 telephones; 1
Pacific Ocean INTELSAT ground station
Defense Forces
Branches: Vanuatu Police Force (VPF),
paramilitary Vanuatu Mobile Force (VMF)
note; no military forces
Defense expenditures: exchange rate
conversion — SNA, NA% of GDP
423
Venezuela
<00 Km
Caribbtn Sta
Railroads: 542 km total; 363 km 1 .435-meter
standard gauge all single track, government
owned; 1 79 km 1 ,435-meter gauge, privately
owned
Highways:
total: 81,000 km
paved; 3 1 .200 km
unpaved; gravel 24,800 km; earth and
unimproved earth 25,000 km
Inland waterways: 7, 1 00 km: Rio Orinoco
and Lago de Maracaibo accept oceangoing
vessels
Pipelines: crude oil 6,370 km; petroleum
pr^ucts 480 km; natural gas 4,010 km
Ports: Amuay Bay. Bajc Grande, El Tablazo,
La Guaira, Puerto Cabello, Puerto Ordaz
Merchant marine: 47 ships (1,000 GRT or
over) totaling 741,688 GRT/1, 204,233 DWT,
short-sea passenger I , passenger cargo I , cargo
1 6, container I , roll-on/roll-off cargo 4, oil
tanker 17, liquefied gas 2, bulk 4, combination
bulk I
Airports;
total; 425
usable; 392
with permanent-surface runways; 139
with runways over 3,659 m; 0
with runways 2,440-3,659 m; 15
with runways 1,220-2,439 m: 92
Telecommunications: modem and
expanding: 1 .440,000 telephones; broadcast
stations — 181 AM, no FM, 59 TV, 26
shortwave; 3 submarine coaxial cables;
satellite ground stations — I Atlantic Ocean
INTELSAT and 3 domestic
Defense Forces
Branches: National Armed Forces (Puerzas
Armadas Nacionales, FAN) includes — Ground
Forces or Army (Fuerzas Terrestres or
Ejercito), Naval Forces (Fuerzas Navales or
Armada), Air Forces (Fuerzas Aereas or
Aviacion), Armed Forces of Cooperation or
National Guard (Fuerzas Armadas de
Cooperation or Guardia Nacional)
Manpower availability: males age 15-49
5,341,855: fit for military service 3,875.523:
reach military age ( 1 8) annually 224.550 ( 1 994
est.)
Defense expenditures: exchange rate
conversion — $ 1 ,95 billion, 4% of GDP ( 1 99 1 )
425
Vietnam
Location: Southeastern Asia, bordering the
South China Sea, between Laos and the','4eb5f83f469a2a2b1844ea4678887ba9f110e58d66fa72137a59ac4854894233','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e83ceee97ef239374183c1a8fc1de66e17426d1ef9c76a0c6cb0f2f6ad1430b',1994,'WF','Wallis and Futuna','communications',931,'(overseas territory of France)
Ports: none; because of the reefs, there are
only two offshore anchorages for large ships
Airports:
total: I
usable; I
with permanent-surface runway.s: 1
with runways over j.659 m; 0
with runways 2,440-3,659 m; 1
with runways 1 ,220-2,439 in: 0
Telecommunications: satellite
communications; I Autovon circuit off the
Overseas Telephone System (OTS): Armed
Forces RadioTTelevision Service (AFRTS)
radio and television service provided by
satellite; broadcast station — closed early 1992.
Note: formerly an important commercial
aviation base, now used by US military, some
commercial cargo planes, as well as the US
Army Space and Strategic Defense Command
for missile launches
Defense Forces
Note: defense is the responsibility of the US
MATA-UTU^
h UtrSX
South Poeilie Ocean
/t$ rutunt
''V
AM
Highways:
total: 120 km (He Uvea 100 km. He Futuna
20km)
paved: 16 km (on H Uvea)
unpaved; 104 km (He Uvea 84 km. lie Futuna
20 km)
Inland waterways: none
Ports: Mata-Utu, Leava
Airports:
total; 2
usable; 2
with permanent-surface runways: 1
with runways over 3.659 m; 0
with runways 2,440-3,659 m; 0
with runways 1,220-2.439 m; 1
Telecommunications; 225 telephones;
broadcast stations — I AM, no FM, no TV
Defense Forces
Note; defense is the responsibility of France
West Bank
60 km oocii(pi»l»i»linWm«*ji
nek necMUflly aumornM.
Note: The war between Israel and Egypt,
Syria, and Jordan in June 1907 ended with
Israel in control of the West Bank, East
Jerusalem, the Gaza Strip, the Sinai Peninsula,
and the Golan Heights. Israel withdrew from
the Sinai Peninsula pursuant to a 1979 peace
treaty with Egypt. The Israeli-PLO Declaration
of Principles on Interim Self-Government
Arrangements ("the DOP"), signed in
Washington on 13 September, 1 993 . provides
for a transitional peri^ not exceeding five
years of Palestinian interim self-government in
the Gaza Strip and the We.rt Bank. Under the
DOP, final status negotiations are to begin no
later than the beginning of the third year of the
transitional period.','4676b4bca27f616ad5842a9fb32f01011e37ba63a56bc9a7a09d18af888dff44','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd2a407f20396b94ab584f8c186f2b89a73d87dfbf2f01d720c2f9df62725d98',1994,'EH','Western Sahara','communications',942,'Highways:
total: NA
paved: NA
unpaved: NA
note; small road network, Israelis developing
east-west axial highways to service new
settlements
Airports:
total; 2
usable; 2
with permanent-surface runu ays: 2
with runways over 3.659 m: 0
with runways 2,440-3.659 rn: 0
with runways 1,220-2,439 tn; 1
Telecommunications: open-wire telephone
system currently being upgraded; broadcast
stations — no AM. no FM, no TV
Defense Forces
Branches; NA
Defense expenditures: exchange rate
conversion — $NA, NA% of GDP
Highways:
total: 6,200 km
unpaved: gravel 1,450 km; improved,
unimproved earth, tracks 4,750 km
Ports: El Aaiun. Ad Dakhia
Airports:
total: 14
usable; 14
with permanent-surface runways: 3
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 3
with runways 1,220-2,439 m; 5
Telecommunications: sparse and limited
system; tied into Morocco''s system by
microwave radio relay, troposcatter. and 2
Atlantic Ocean INTELSAT earth stations
linked to Rabat, Morocco; 2,000 telephones;
broadcast stations — 2 AM, no FM, 2 TV
Defense Forces
Branches: NA
Defense expenditures: exchange rate
conversion — $NA, NA% of GDP
60 Inn
South Pacific Ocean','f3aacb775fefe67c1118c591c85edf1c7dde6868595bac0fbc2016b3c8dabec5','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50b1fa372d3c66387d2d891898aa48074ca41f680825a46a0c52889f60938548',1994,'YE','Yemen','communications',947,'Railroads: 239,430 km of narrow gauge
track; 710,754 km of standard gauge track;
251,153 km of broad gauge track; includes
about 190,000 to 195,000 km of electrified
routes of which 147,760 km are in Europe,
24,509 km in the Far East, 1 1 ,050 km in Africa,
4,223 km in South America, and only 4, 1 60 km
in North America; fastest speed in daily service
is 300 km/hr attained by France''s SNCF TGV-
Atlantique line
Highways:
total; NA
paved: NA
unpaved; NA
Ports: Mina’ al Ahmadi (Kuwait), Chiba,
Houston, Kawasaki, Kobe, Marseille, New
Orleans, New York, Rotterdam, Yokohama
Merchant marine: 23,943 ships ( 1 ,000 GRT
or over) totaling 397,225,000 GRT/
652,025,000 DWT. passenger-cargo 347,
freighter 12,581, bulk carrier 5,473, tanker
5,542 (all data as of January 1992)
Defense Forces
Branches: ground, maritime, and air forces at
all levels of technology
Defense expenditures; somewhat less than
$1.0 trillion, 3% of total world output; decline
of5%-10%(1993 est.)
300 km
Boundary topiwntalgn li
not neccuaiily aulhonUtive
Highways:
total: 15,500 km
paved: 4,000 km
unpaved: natural surface 1 1,500 km
Pipelines: crude oil 644 km, petroleum
piquets 32 km
Porta: Aden, Al Hudaydah, Al Khalf, Ai
Mukalla, Mocha, Nishtun, Ra''s Kathib, Salif
Merchant marine: 3 ships (1,000 ORT or
over) totaling 4,309 ORT/6,5''68 DWT, cargo 2,
oil tanker I
Airports:
total: 46
usable: 40
with permanent-surface runways: 10
with runways over 3,659 m: 0
with runways 2,440-3,659 m: 18
with runways 1,220-2,439 m: 1 1
Tetecommunkattons: since unification in
1990, efforts are still being made to create a
national domestic civil telecommunications
network; the network consists of microwave
radio relay, cable and troposcatter; 65,000
telephones (est.); broadcast stations— 4 AM, 1
FM, 10 TV; satellite earth sutions — 2 Indian
Ocean INTELSAT, I Atlantic Ocean
INTELSAT, 1 Intersputnik, 2 ARABSAT;
microwave radio relay to Saudi Arabia, and','54e511300d383e855a00dc61875726155fcd266d83bb8d6d22cd0a70b149dd23','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca3a0d7366d842ae0f6a675dad5ea43618af9e190f56c4f6fe228d81643f0199',1994,'DJ','Djibouti','communications',952,'Defense Forces
Branches: Army, Navy, Air Force, Police
Manpower availability: males age 15-49
2,142,519; fit for militaiy service 1,219,985;
reach military age (14) annually 137,497 (19M
est.)
Defense expenditures: exchange rate
conversion^762 million, 10% of GDP
(1992)
Zaire','2319e160bf0ad8976ab6fe768adf04ed3ea5f8ab9f32482fcfa272d224cc3571','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0b76ba72a318c38ceaadc2b54dd8570b197fe2aacfd3b8d1c780da01883223c',1994,'ZM','Zambia','communications',958,'Railroads; 5,254 km total; 3,968 km 1.067-
meter gauge (85 1 km electrified); 125 km
1. 000-meter gauge; 136 km 0.615-meter
gauge; 1.025 km 0.600-meter gauge; limited
trackage in use because of civil strife
Highways:
total: 146.500 km
paved: 2,800 km
unpaved; gravel, improved earth 46,200 km;
unimproved earth 97,500 km
Inlaiid waterways; 15,000 km including the
Congo, its tributaries, and unconnected lakes
Pipelines: petroleum products 390 km
Ports: Matadi, Boma, Banana
Merchant marine: I passenger cargo ship
( 1 ,000 CRT or over) totaling 1 5,489 GRT/
13,481 DWT
Airports:
total; 278
usable; 233
with permanent-surface runways; 25
with runways over 3,659 m; 1
with runways 2,440-3,659 m; 6
with runways 1,220-2,439 m; 72
Telecommunications: barely adequate wire
and microwave service; broadcast stations —
10 AM, 4 FM, 1 8 TV; satellite earth stations —
I Atlantic Ocean INTELSAT, 14 domestic
Defense Forces
Branches: Army, Navy, Air Force,
paramilitary National cjendarmerie, Civil
Guard, Special Presidential Division
Manpower availability: males age 15-49
9,178,659; fit for military service 4,674,819
Defense expenditures: exchange rate
conversion — $49 million, 0,8% of GDP (1988)','d8884af5a67e35be922082621642f4574d382a27a4802541029816dc8f9a06e5','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

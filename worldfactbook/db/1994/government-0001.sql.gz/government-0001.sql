SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a13c5aba4c44fac16af6e796be9bcb55d3882aa8d3e0c0af4baeb39d39283c17',1994,'EH','Western Sahara','government',6,'Notes, Deflnitlons,
and Abbreviations (continued)
IrrigatMi land: The figure refers to the land area that i*'' artificialty
supplied with water.
Land uae: Human use of the ''and surface is ''‘ategorized as arable land—
land cultivated for crops that are replanted after each harvest (wheat,
maize, rice): permanent crops — land cultivated for crops that are not
replanted after each harvest (citRis, coffee, rubber); meadows and
pastures — land permanently used for herbaceous forage crops-, forest and
woodland — under dense or open stands of trees; and other — any land type
not specifically mentioned atove (urban areas, roads, desert).
Leaders: The chief of state is the titular leader of the country who
represents the state at official and ceremonial functions but is not involved
with the day-to-day activities of the government. The head of government
is the administrative leader who manages the day-to-day activities of the
government. In the UK, the monarch is the chief of state, and the Prime
Minister is the head of government. In the US, the President is both the
chief of state and the head of government.
Life expectancy at birth; The average number of years to be lived by a
group of people all boro in the same year, if mortality at each age remains
constant in the future.
Literacy; There are no universal definitions and standards of literacy.
Unless otherwise noted, all rales are based on the most common
definition — the ability to read and write at a specified age. Detailing the
standards that individual countries use to assess the ability to read and
write is beyond the scope of this publication.
Maritime claims: The proximity of neighboring states may prevent some
national claims from being extended the full distance.
Merclmnt marine: All ships engaged in the carriage of goods. All
commercial vessels (as opposed to all nonmilitary ships), which excludes
tugs, fishing vessels, offshore oil rigs, etc.; also, a grouping of merchant
ships by nationality or register.
Captive register — A register of ships maintained by a territory,
possession, or colony primarily or exclusively for the use of ships owned
in the parent country; also referred to as an offshore register, the offshore
equivalent of an internal register. Ships on a captive register will fly the
same flag as the parent country, or a local variant of it. but will be subject
to the maritime laws and taxation rules of the offshore territory. Although
the nature of a captive register makes it especially desirable for ships
owned in the parent country, just as in the internal register, the ships may
also be owned abroad. The captive register then acts as a flag of
convenience register, except that it is not the register of an independent
state.
Flag of convenience register — A national register offering registration
to a .nerchant ship not owned in the flag state. The major flags of
convenience (FOC) attract ships to their register by virtue of low fees, low
or nonexistent taxation of profits, and liberal manning requirements. True
FOC registers are characterized by having relatively few of the ships
registered actually owned in the flag state. Thus, while virtually any flag
can be used for ships under a given set of circumstances, an FOC register
is one where the majority of the merchant fleet is owned abroad. It is also
referred to as an open register.
Flag state — The nation in which a ship is registered and which holds
legal jurisdiction over operation of the ship, whether at home or abroad.
Differences in flag state maritime legislation determine how a ship is
manned and taxed and whether a foreign-owned ship may be placed on the
register.
xii
Notes, Deflnitions,
and Abbreviations (continued)
Internal register — A register of ships maintained as a subset of a
national register. Ships on the internal register fly the national flag and
have that nationality but are subject to a separate set of maritime rules
from those on the main national register. These differences usually include
lower taxation of profits, manning by foreign nationals, and. usually,
ownership outside the flag state (when it functions as an POC register).
The Norwegian International Ship Register and Danish International Ship
Register are the most notable examples of an internal register. Both have
been instrumental in stemming flight from the national flag to flags of
convenience and in attracting foreign owned ships to the Norwegian and
Danish flags.
Merchant ship — A vessel that carries goods against payment of freight:
commonly used to denote any nonmilitary ship but accurately restricted to
commercial vessels only.
Register— The record of a ship''s ownenhip and nationality as listed
with the maritime authorities of a country; also, the compendium of such
individual ships'' registrations. Registration of a ship provides it with a
nationality and makes it subject to the laws of the country in which
registered (the flag state) regardless of the nationality of the ship''s ultimate
owner.
Money figures: All money figures are expressed in contemporaneous US
dollars unless otherwise indicated.
National product: The total output of goods and services in a country in
a given year. See Gross domestic product (GDP), Gross national product
(GNP). and GNPAjDP methodology.
Net migration rate: The balance between the number of persons entering
and leaving a country during the year per 1 ,0(X) persons (based on midyear
population). An excess of persons entering the country is referred to us net
immigration (3.56 migrants/ 1.000 population); an excess of persons
leaving the country as net emigration (-9.26 migrants/ 1 .000 population).
Population: Figures are estimates from the Bureau of the Census based
on .statistics from population censu.ses. vital statistics registration systems,
or sample surveys pertaining to the recent past, and on ass ;mptions about
future trends. Starting with the 1993 Factoook. demographic estimates for
some countries (mostly African) have taken into account the effects of the
growing incidence of AIDS infections; in 1993 these countries were
Burkina. Burundi. Central African Republic. Congo. Cote d’Ivoire, Haiti.
Kenya, Malawi. Rwanda. Tanzania. Uganda. Zaire. Zambia. Zimbabwe.
Thailand, and Biazil.
Total fertility rate: The average number of children that would be bom
per woman if all women lived to the end of their childbearing years and
bore children according to a given fertility rate at each age.
Years: All year references are for the calendar year (CY) unless indicated
as fiscal year (FY).
Note: Information for the US and US dependencies was compiled from
material in the public domain and does not represent Intelligence
Community estimates. The Handbook of Intemaiional Economic
Staiisiics. published annually in September by the Central Intelligence
Agency, contains detailed economic information for the Organization for
Economic Cooperation and Development (OECD) countries. Eastern
Europe, the newly independent republics of the former nations of
Yugoslavia and the Soviet Union, and .selected other countries. The
Handbook can be obtained wherever The World Facibook is available.
Names:
conventional long form: none
conventional short form; Western Sahara
Digraph: WI
Type; legal status of territory and question of
sovereignty unresolved; territory contested by
Morocco and Polisario Front (Popular Front
for the Liberation of the Saguia el Hamra and
Rio de Oro), which in February 1976 formally
proclaimed a government in exile of the
Sahrawi Arab Democratic Republic (SADR);
territory partitioned between Morocco and
Mauritania in April 1 976, with Morocco
acquiring tiorthera two-thirds; Mauritania,
under pressure from Polisario guerrillas,
abandoned all claims to its portion in August
1979; Morocco moved to occupy that sector
shortly thereafter and has since asserted
administrative control; the Polisario''s
govemmert in exile was seated as an OAU
member in 1984; guerrilla activities continued
sporadically, until a UN-monitored cease-fire
was implemented 6 September 1991
Capital: none
Administrative divisions; none (under de
facto control cf Morocco)
Executive branch; none
Member of: none
Diplomatic representation in US: none
US diplomatic representation: none
432
Western Samoa','c27271e47f62ecd399c732de288faf03847267568936b4f66d98486c0257a532','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('496b5a107851d54576f2a95ab87f15cec927ede746403ae737431805860aba14',1994,'PK','Pakistan','government',7,'Map references; Asia, Middle East, Standard
Time Zones of the World
Area:
loiol area: 647, .SOO sq km
area: 647,500 sq km
(vm/uinithr ami.- slightly smaller than Texas
Land boundaries: total .5,520 km, China 76
km, Iran 93fi km, Pakistan 2.4.50 km. Tajikistan
I,2tl6 km. Turkmenistan 744 km, Uzbekistan
1.57 km
Coastline: 0 km t landlocked)
Maritime claims: none; landlocked
International disputes: periodic disputes
with Iran over Helmand water rights; Iratt
supports clients in country, private Pakistani
and Saudi sources akso are active; power
struggles among various groups for control of
Kabul, regional rivalries among emerging
warlords, traditional tribal disputes ''xmtinue;
support to Islamic fighters in Tajikistan''s civil
war; bordei dispute with Pakistan (Durand
Line); support to Islamic tniliiants worldwide
by some factions
Climate: arid to semiarid; cold winters and
hot summers
Terrain: mostly rugged mountains; plains in
north and southwest
Natural resources: natural gas, petroleum.
coal, copper, talc, barites, sulphur, lead. zinc.
iron ore, salt, precious and semiprecious stones
Land use:
anihle Uiiul: 1 29c
pcmHini''nl cropx: 0''"''}
nwtulowx wul piixri''/ex: 46*^
/hmi and wiMiilkituI: 39r
other: 3991
Irrigated land: 26,6(X) sq km ( I98t> cst.)
Names:
conventional loiift form: Islamic Slate of
.Afghanistan
conventional slum form: Afghanistan
former: Republic of Afghanistan
Digraph: AF
Type: transitional government
Capital: Kabul
Administrative divisions: 50 provinces
Ivclayat. singular — velayat); Badakhshan,
Badghis, Baghlun. Baikh, Bamian. Parah.
Faryab. Ghazni. Ghowr. Helmand, Herat,
Jowzjan. Kabul. Kandahar. Kapisa. Kon.tr.
Kondoz, Laghman, Lowgar, Nangarhar,
Nimruz. Oruzgan. Paktia. Paktika, Par van.
Samangan. Sar-e Pol, Takhar. Vardak, Zabol
note: there may be a new province of Nurestan
(Nuristan)
Independence: 1 9 August 1 9 1 9 ( '' rom U K)
National holiday: Victory of the Muslim
Nation, 28 April: Remembrance Day for
Martyrs and Disabled, 4 May; k (dependence
Day, 19 August
Constitution: none
Legal system: a new legal svstem has not
been adopted but the transit! .mal government
has declared it will follow I damic law
(.Shari a)
Suffrage: undeiermined: previously
universal, male ages 15-50
Executive branch:
chief of state: President Burhanuddin
RABBANl (Interim President July —
December 1992; President since 2 January
1995): First Vice President Muhammad NABI
Mtvhammadi (since NA): First Vice President
Moltammad SHAH Fazli (since NA); election
last held NA December 1992 (next to be held
NA December 1994): results — Burhanuddin
RABBANl was elected to a two-year tenn by a
nulionul shura. laiei amended by miiUi-puny
agreement to 18 months,
headofftavernmem: Prime Minister
Gulbuddin HIKMATYAR (since 17 Mareh
1995); First Deputy P, ime Minister Qutbuddin
HELAL (since 17 Maah 1995); Deputy Prime
Minister Arsala RAHMANl (since 17 March
1995)
cabinet: Council of Ministers
Legislative branch; a unicuincral parliament
consisting of 205 members was chosen by the
shura in January 1995; non-functioning as of
June 1995
Judicial branch: an interim Chief Justice of
the Supreme Court has been upp^hnted. but a
new court system has not yei been organized
Political parties and leaders: current
political organizations include Jamiat-i-lslami
(Islamic SiKieiyi, Burhanuddin RABBANl,
Ahmad Shah MASOOD; Hizbi Islami-
Gulhuddin (Islamic Party). Gulbuddin
HIKMATYAR faction; Hizbi Islami-Khalis
(Islamic Party) Yunis KHALIS faction;
Ittihud-i-lslami Barai Azadi Afghanistan
(Islamic Union for the Liberation of
Afghanistan). Abdul Rasul SAYYAF;
Harakat-Inqilab-i-Islami (Islamic
Revolutionary Movement). Mohammad Nabi
MOHAMMADI: Jabha-i-NaJat-i-Milli
Afghanistan (Afghanistan National Liberation
Fmni), Sihghutullah MOJADDEDl: Mahaz-i-
Milli-lslami (National Islamic Front). Sayed
Ahamtid GAILANI; Hizbi Wahdat (Islamic
Unity Party). Abdul Ali MAZARI;
1
Afghanistan (continued)
Harakat-i-Islami (Islamic Movement),
Mohammed Asif MOHSENI; Jumbesh-i-Milli
Islami (National Islamic Movement), Rashid
DOSTUM
note: the former ruling Watan Party has been
disbanded
Other political or pressure groups: the
former resistance commanders are the major
power brokers in the countryside: shuras
(counciis) of commanders are now
administering most cities outside Kabul; ulema
(religious scholars); tribal elders
Member of: AsDB. CP, ECO. ESCAP, FAO,
0-77, IAEA, IBRD, ICAO, IDA, IDB, IFAD,
IFC, ILO, IMF, INTELSAT, KX), ITU,
LORCS, NAM, OIC, UN. UNCTAD.
UNESCO, UNIDO, UPU, WFTU, WHO,
WMO.WTO
Diplomatic representation in US:
chief of mission: (vacant); Charge d’ Affaires
Abdul RAHIM
chancery: 2341 Wyoming Avenue NW,
Washington, DC 2(X)08
telephone: (202) 234-3770 or 3771
FAX- (202) 328-35 16
US diplomatic representation: none;
embassy was closed in January 1989
Flag: three equal horizontal bands of green
(top), white, and black, with the national coat
of arms superimposed in the middle of the
white band and large Islamic lettering
superimposed over the green and white bands
Names:
conventional long form; Republic of Albania
conventional short form; Albania
local long form; Republika e Shqiperise
local short form; Shqiperia
former: People’s Socialist Republic of Albania
Digraph: AL
Type: nascent democracy
Capital: Tirane
Administrative divisions: 26 districts
(rrethe, singular — rreth); Berat, Dibre, Durres,
Elbasan, Fier, Gjirokaster. Gramsh, Kolonje,
Korce, Kruje, Kukes, Lezhc, Librazhd,
Lushnje, Mat, Mirdite, Permet. Pogradec.
Puke. Sarande, Shkoder, Skrapar, Tepelene,
Tirane, Tropoje, VIore
Independence: 28 November 1912 (from
Ottoman Empire)
National holiday: Liberation Day, 28
November (1944; changed by decree on 12
November 1993)
Constitution: an interim basic law was
approved by the People’s Assembly on 29
April 1991 ; a new constitution was to be
drafted for adoption in 1992, but is still in
process
Legal system: has not accepted compulsory
ICJ jurisdiction
SufTkvge; 1 8 years of age, universal and
compulsory
Executive branch:
chief of state: President of the Republic Sali
BERISHA (since 9 April 1992)
head of government: Prime Minister of the
Council of Ministers Aleksander Gabriel
MEKSI (since 10 April 1992)
cabinet: Council of Ministers; appointed by
the president
Legislative branch: unicameral
People ''s Assembly ( Kuvendi Popullor):
elections last held 22 March 1992; results — DP
62.29%, ASP 25.57%, SDP 4.33%, RP 3.15%.
UHP 2.92%, other 1 .74%; seats — ( 140 total)
DP 92, ASP 38. SDP 7. RP 1 , UHP 2
Judicial branch: Supreme Court
Political parties and leaders: there are at
least 18 political parties: most prominent are
the Albanian Socialist Party (ASP: formerly
the Albania Workers Party), Fatos NANO, first
secretary; Democratic Party (DP). Eduard
SELAMI, chairman; Albanian Republican
Party (RP), Sabri GODO; Omonia (Greek
minority party), leader NA (ran in 1992
election as Unity for Human Rights Party
(UHP)); Social Democratic Party (SDP),
SkenderGJINUSHI: Democratic Alliance
Party (DAP), Spartak NGJELA, chairman
Member of: BSEC. CCC. CE (guest), CSCE.
EBRD. ECE, FAO, IAEA, IBRD. ICAO. IDA,
IDB, IFAD, IFC, ILO, IMF, IMO, INTELSAT
(nonsignatory user), INTERPOL, IOC. lOM
(observer), ISO, ITU, LORCS, NACC. OIC,
UN, UNCTAD, UNESCO, UNIDO, UPU.
WFTU, WHO, WIPO, WMO
Diplomatic representation in US:
chief of mission; Ambassador Lublin Hasan
DIUA
chancery; Suite 1010, 1511 K Street NW.
Washington, DC 2(X)05
telephone; (202) 223-4942, 8187
FAX: (202) 628-7342
US diplomatic representation:
chief of mission; Ambassador William E.
RYERSON
embassy: Rruga E. Elbansanit 103. Tirane
mailing address; PSC 59, Box 100 (A), APO
AE 09624
telephone; 355-42-32875, 33520
FAX; 355-42-32222
3
Albania (continued)
Flag: red with a black two-headed eagle in the
center
con veil tioned short form: Pakistan
former: West Pakistan
Digraph: PK
Type; republic
Capltal: Islamabad
303
Pakistan (continued)
Administrative divisions: 4 provinces, I
territory*, and 1 capital territory**;
Balochistan, Federally Administered Tribal
Areas*, Islamabad Capital Territory**, North-
West Frontier, Punjab, Sindh
note: the Pakistani-administered portion of the
disputed Jammu and Kashmii region includes
Azad Kashmir and the Northern Areas
Independence: 14 August 1947 (from UK)
National holiday: Pakistan Day, 23 March
( 1956) (proclamation of the republic)
Constitution: 10 April 1973, suspended 5
July 1977 restored with amendments, 30
December I9S5
Legal system: based on English common law
with provisions to accommodate Pakistan''s
stature as an Islamic state; accepts compulsory
FCJ jurisdiction, with reservations
Suffrage: 21 years ofage; universal, separate
electorates and reserved parliamentary seats
for non-Muslims
Executive branch;
chief of stale; President Sardar Farooq
LEGHARI election last held on 13 November
1993 (next to be held no later than 14 October
1998); results — LEGHARI was elected by
Parliament and the four provincial assemblies
head of government; Prime Minister Benazir
BHUTTO
cabinet; Cabinet
Legislative branch: bicameral Parliament
(Majlis-e-Shoora)
Senate; elections last held NA March 1994
(next t,n be held NA March 1997); seats — (87
total) Pakistan People''s Party (PPP) 22.
Pakistan Muslim League, Nawaz Sharif faction
(PML/N) 17; Tribal Area Representatives
(nonparty) 8, Awami National Party (ANP) 6,
Pakistan Muslim League, Junejo faction
(PML/J) 5, Jamhoori Watan Party (JWP) 5,
Mohajir Quami Movement, Altaf faction
(MQM/A) 5, Jamiat Ulema-i-Islam. Fazlur
Rehman group (JUI/F) 2. Pakhtun Khwa Milli
Awami Party (FKMAP) 2. Jamaat-i-Islami (Jl)
2, National People''s Party (NPP) 2,
Balochistan National Movement, Hayee Group
(BNM/H) I. Balochistan National Movement,
Mengal Group (BNM/M) I, Jamiat Ulema-i-
Pakistan, Niazi faction (JUP/Nl) I, Jamiat
Ulema-i-Pakistan. Noorani faction (JUP/NO)
1 . Jamiat-al-Hadith (JAH) I, Jamiat Ulema-i-
Islam. Sami-ul-Haq faction (JUI/S) I. Pakistan
Muslim League. Functional Group (PMiyF) 1 ,
Pakistan National Party (PNP) I , Independents
2, vacant 1
National Assembly; elections last held 6
October 1993 (next to be held by October
1998): seats — (217 total); Pakistan People''s
Parly (PPP) 92; Pakistan Muslim League,
Nawaz Sharif faction (PML/N) 75; Pakistan
Muslim League. Junejo faction (PML/J) 6:
Islami-Jamhoori-Mahaz (IJM-Islamic
Democratic Front) 4; Awami National Party
(ANP) 3: Pakhtun Khwa Milli Awami Party
(PKMAP) 4; Pakistan Islamic Front (PIF) 3;
Jamhoori Watan Party (JWP) 2; Mutaheda
Deeni Mahaz (MDM) 2; Balochistan National
Movement, Hayee Group (BNM/H) 1;
Balochistan National Movement. Mengal
Group (BNM/M) 1; National Democratic
Alliance (NDA) I; National People''s Party
(NPP) 1; Pakhtun Quami Party (PKQP) 1;
Religious minorities 10 reserved .seats;
independents, 9; results pending. 2
Judicial branch: Supreme Coutt, Federal
Islamic (Shari''at) Coutt
Political parties and leaders:
government; Pakistan People''s Party (PPP),
Benazir BHUTTO; Pakistan Muslim League,
Junejo faction (PML/J). Hamid Nasir
CHATTHA; National People’s Party (NPP),
Ghulam Mustapha JATOI; Pakhtun Khwa
Milli Awami Party (PKMAP), Mahmood Khan
ACHAKZAI; Balochistan National
Movement, Hayee Group (BNM/H), Dr.
HAYEE Baluch; National Democratic
Alliance (NDA). Maulana Kausar NIAZI;
Pakhtun Quami Party (PKQP). Mohammed
AFZAL Khan; Jamhoori Watan Patty (JWP),
Akbar Khan BUGTI
opposition; Pakistan Muslim League, Nawaz
Sharif faction (PML/N), Nawaz SHARIF;
Awami National Party (ANP), Khan Abdul
WALI KHAN: Paki.stan Islamic Front (PIF),
Qazi Hussain AHMED; Balochistan National
Movement, Mengal Group (BNM/M), Sardar
Akhtar MENGAL: Mohajir Quami Movement,
Altaf faction (MQM/A); Jamaat-i-lslami (JI);
Jamiat-al-Hadith (JAH)
frequently shifting; Mutaheda Deeni Mahaz
(MDM), Maulana Sami-ul-HAQ, the MDM
includes Jamiat Ulema-i-.’^kistan, Niazi
faction (JUP/NI)and Anjuman Sepah-i-Sahaba
Pakistan (ASSP); Islami-Jamhoori-Mahaz
(IJM-lslaiiiic Democratic Party), the IJM
includes Jami.at Ulema-i-lslami, Fazlur
Rehman group (JUI/F); Jamiat Ulema-i-
Pakistan, Noorani faction (JUP/NO); Jamiat
Ulema-i-Islam. Sami-ul-Haq faction (JUI/S);
Pakistan Muslim League, Functional Group
<PML/F); Pakistan National Party (PNP)
note; most Pakistani political groups are
motivated primarily by opportunism and
political alliances can shift frequently
Other political or pressure groups:
military remains important political force;
ulema (clergy), landowners, industrialists, and
small merchants also influential
Member of; AsDB. C. CCC. CP. ECO.
ESCAP. FAO, G- 19. G-24. G-77. GATT,
IAEA. IBRD, ICAO. ICC. ICFTU. IDA, IDB,
IFAD. IFC. ILO. IMF. IMO, INMARSAT,
INTELSAT, INTERPOL. IOC, lOM, ISO,
ITU. LORCS. MINURSO. NAM. OAS
(observer). OIC. PCA. SAARC. UN,
UNCTAD. UNESCO. UNHCR. UNIDO,
UNIKOM. UNOSOM. UNTAC, UPU, WCL.
WFTU. WHO. WIPO. WMO. WTO
Diplomatic representation in US:
chief of mission; Ambassador Maleeha
LODHl
chancere; 2315 Massachusetts Avenue NW,
Washington. DC 20008
telephone; (202) 939-6205
FAX; (202) 387-0484
consulate(s} general; Los Angeles and New
York
US diplomatic representation:
chief of mission; Ambassador John MONJO
embassy; Diplomatic Enclave. Ramna 5,
Islamabad
mailing address; P. O. Box 1048, PSC 1212,
Box 2000, Unit 6220, Islamabad or APO AE
09812-2000
telephone; [92J (51) 826161 through 79
FAX; |92] (51) 214222
consulate(s) general; Karachi, Lahore
consulate(s); Peshawar
Flag: green with a vertical white band
(symbolizing the role of religious minorities)
on the hoist side; a large white crescent and star
are centered in the green Held; the crescent,
star, and color green are traditional symbols of
Islam','cc99b621421502027075459825f6974f3c1b1eeb413bf3f0768f7d267765bef5','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c7d6128c3633b7d4fa09ecc41f05d26b62598e047e26782b4e39a73740d8d4b',1994,'TN','Tunisia','government',18,'Names:
conventional long form: Democratic and
Popular Republic of Algeria
conventional short form: Algeria
local long form: A1 Jumhuriyah al Jaza''iriyah
ad Oimuqratiyah ash Shabiyah
local short form: Al Jaza’ir
Digraph; AG
Type: republic
Capital: Algiers
Administrative divisions: 48 provinces
(wilayast. singular — wilaya); Adrar, Ain
Defla, Ain Temouchent, Alger. Annaba, Batna,
Bechar. Bejaia, Biskra, Blida, Bordj Bou
ArreridJ, Bouira, Boumerdes, Chief.
Constantine, Djelfa, El Bayadh, El Oued, El
Tarf, Ghardaia, Guelma, Illizi, Jijel,
Khenchela, Laghouat, Mascara. Medea, Mila,
Mostaganem, M''Sila, Naama, Oran, Ouargla,
Oum el Bouaghi, Relizane. Saida, Setif, Sidi
Bel Abbes, Skikda, Souk Ahras,
Tamanghasset, Tebessa, Tiaret, Tindouf,
Tipaza, Tissemsilt, Tizi Ouzou, TIemcen
Independence: 5 July 1962 (from France)
National holiday: Anniversary of the
Revolution, I November (1 954)
Constitution: 19 November 1976, effective
22 November 1976; revised 3 November 1988
and 23 February 1989
Legal system: socialist, based on French and
Islamic law; Judicial review of legislative acts
in ad hoc Constitutional Council composed of
various public officials, including several
Supreme Court Justices; has not accepted
compulsory ICJ Jurisdiction
Suf^ge: 18 years of age; universal
Executive branch:
chief of state: President Lamine ZEROUAL
(since 31 January 1994); next election to be
held after a three-year transition period, which
began on 31 January 1994
head of government: Prime Minister Mokdad
SlFl (since 1 1 April 1994)
cabinet: Council of Ministers; appointed by
the prime minister
Le^slatlve branch: unicameral
National People''s Assembly (Al-Majlis Ech-
Chaabi Al-Watani): elections first round held
on 26 December 1991 (second round canceled
by the military after President BENDJEDID
resigned II January 1992. effectively
suspending the Assembly); results — percent of
vote by party NA; seats — (281 total); the
fundamentalist RS won 188 of the 231 seats
contested in the first round; note — elections
(municipal and wilaya) were held in June 1990,
the first in Algerian history; results — FIS 55%,
FLN 27.5%, other 17,5%, with 65% of the
voters participating
Judicial branch: Supreme Court (Cour
Supreme)
Political parties and leaders: Islamic
Salvation Front (RS, outlawed April 1992),
Ali BELHADJ, Dr. Abassi MADANI,
Abdelkader HACHANI (all under arrest).
Rabeh KEBIR (self-exile in Germany);
National Liberation Front (FLN), Abdelhamid
MEHRI, Secretary General; Socialist Forces
Front (FFS). Hocine Ait AHMED, Secretary
General
note: the government established a multiparty
system in September 1989 and, as of 31
December 1990, over 50 legal parties existed
Member of: ABEDA, AfDB, AFESD, AL,
AMF, AMU. CCC, ECA. FAO. G-15. G-19.
G-24. G 77, IAEA, IBRD. ICAO, IDA. IDB,
IFAD, IFC, ILO, IMF, IMO, INMARSAT,
INTELSAT, INTERPOL. IOC, ISO. ITU.
LORCS, NAM. OAPEC, OAS (observer).
5
Algeria fcontinued)
OAU. OIC, OPEC, UN. UNAVEM 11.
UNCTAD. UNESCO. UNHCR. UNIDO,
UNTAC. UPU, WCL. WHO. WlPO, WMO,
WTO
Diplomatic representation in US:
chief ofmixxiitn: Ambassador Nouircdine
Yazid ZERHOUNI
cha/icen'': 2118 Kalorama Road NW,
Washington, DC 20008
telephone: (202) 265-2800
US diplomatic representation:
chief of inixxion: Ambassador Mary Ann
CASEY
emhaxxy: 4 Chemin Cheikh Bachir El-
Ihrahimi. Algiers
mailing titidrexs: B. P. Box 549, Alger-Qare,
1 6000 Algiers
telephone: (21.^1 (2) 601-425, 255. 186
12131(2)603979
conxulateix): Oran
Flag: two equal vertical bands of green (hoist
side) and while with a red five-pointed star
within a red crescent; the crescent, star, and
color green are traditional symbols of Islam
(the state religion)
amventiimol short form; Trumeltn Island
Im-al Itmgfiirm; none
hmtl short fttrm; lie Tmmelin
Dlsniph: TE
Type: French possession administered by
Commissioner of the Republic, resident in
Reunion
Ctpitali none; administered by Prance from
Reunion
Independence: none (possession of France)','9764d7da2a530f115353976ec6858d7fdc32b20311abc74e0779d0fa0e086db0','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc637206ff9ee4735081f72ca220ddfdfc142fc6c2f539ce096dfd7fc138cf1c',1994,'NZ','New Zealand','government',26,'Names:
conventional long form: Territory of
•American Samoa
conventional short form; American Samoa
Abbreviation; AS
Digraph; AQ
Type: unincorporated and unorganized
territory of the US; administered by the US
Department of Interior. Office of Territorial
and International Affairs
Capital: Pago Pago
Administrative divisions: none (territory of
the US)
Independence: none (territory of the US)
National holiday: Territorial Flag Day, 17
April (1900)
Constitution: ratified 1966, in effect 1967
Legal system: NA
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state; President William Jefferson
CLINTON (since 20 January 1993); Vice
President Albert GORE, Jr. (since 20 January
1993)
head of government: Governor A. P. LUTALI
(since 3 January 1993); Lieutenant Governor
Taue.se P. SUNIA (since 3 January 1993);
election last held 3 November 1992 (next to be
held NA November 1996); results — A. P.
LUTALI (Democrat) 53%, Peter Tali
COLEMAN (Republican) .36%
Legislative branch: bicameral Legislative
Assembly (Fono)
House of Representatives: elections last held 3
November 1992 (next to be held NA
November 1994); results — representatives
popularly elected from 1 7 house districts;
seats — (2 1 total, 20 elected, and I nonvoting
delegate from Swains Island)
Senate: elections last held 3 November 1 992
(next to be held NA November 1996);
results — senators elected by village chiefs
from 12 senate districts; seats — (18 total)
number of seats by party NA
US House of Representatives: elections last
held .3 November 1992 (next to be held NA
November 1994); results — Eni R. F, H.
FALEOMAVAEG.A reelected as delegate
Judicial branch: High Court
Political parties and leaders: NA
Member of: ESCAP (associate), IN TERPOL
(subbureau). KX^, SPC
Diplomatic representation in US: none
(territory of the US)
US diplomatic representation: none
(territory of the US)
Flag: blue with white triangle edged in red
that is based on the fly side and extends to the
hoist side; a brown and white American bald
eagle flying toward the hoist side is carrying
two traditional Samoan symboir of authority, a
staff and a war club
Names;
conventional long form: none
conventional short form: New Zealand
Abbreviation: NZ
Digraph: NZ
Type: parliamentary denuKracy
Capital: Wellington
Administrative divisions: 93 counties. 9
districts*, and 3 town districts**; Akanva.
Amuri. Ashburton. Bay of Islands, Bruce.
Bullcr. Chatham Islands. Cheviot. Clifton.
Clutha, Cix)k. Dannevirke. Egmont.
Eketahuna. Ellesmere. Eltham. Eyre.
Featherston. Franklin, Golden Bay. Great
Barrier Island. Grey. Hauraki Plains. Hawera*.
Hawke''s Bay, Heathcotc. Hikurangi**.
Hobson. Hokianga, Hon''whcnua. Hurunui.
Hutt. Inangahua. Inglewixxi. Kaikoura.
Kairanga. Kiwitea. Lake. Mackenzie. Malvern.
285
New Zealand {continued >
Manaia**, Manawatu. Mangonui. Maniototo.
Marlborough. Masierton, Matamata, Mount
Herbert. Ohinemuri. Opoiiki. Orouu.
Otamaiea. Otorohanga*. Oxford, Pahiatua,
Papaiiia, Patea, Pinko, Pohangina, Raglan,
Rangiora*, Rangitikei. Rodney, Rotorua"'',
Runanga, Saint Kilda, Silverpeaks. Southland.
Stewart Island, Stratford, Strathallan,
Taranaki. Taumarunui, Taupo. Tauranga.
Thames-Coromandel'''', Tuapeka, Vincent,
Waiapu. Waiheke, Waihemo, Waikato.
Waikohu. Waimairi. Waimarino, Waimate.
Waimate West. Waimea. Waipa, Waipawa*.
Waipukurau*. Wairarapa South, Wairewa,
Wairoa. Waitaki, Waitomo''*, Waitotara,
Wallace, Wanganui, Waverley''*"'', Westland,
Whakatane"'', Whangarei, Whangaroa,
Woodville
Dependent areas: Cook Islands, Niue.
Namci:
conventional long fom; none
conventional short form: Tokelau
Mgraph: TL
Type: territory of New Zealand
Capital: none; each atoll has its own
administrative center
Administrative tUvWoas: none (territory of
New Zealand)
Independence: none (territory of New
Zealand)
National boUday; Waitangi Day, 6 February
( 1 840) (Treaty of Waitangi established British
sovereignty over New Zealand)
Cooatitulto: administered under the
Tokelau Islands Act of 1948. as amended in
1970
Legal system: British and local statutes
Snfltagc: NA
Executive branch:
Chief of State; Queen ELIZABETH II (since 6
February 1952)
Head of Government; Administrator Graham
ANSELL (since NA 1990; appointed by (he
Minister of Foreign Affairs in New Zedand);
Official Secretary Casimilo J. PEREZ (siiKe
NA). Office of Tokelau Affairs; Tokelau''s
governing Council will elect its first head of
Legislative branch: unicameral Council of
Elders (Taupulega) on each atoll
Judicial branch: High Court in Niue.
Supreme Court in New Zealand
Political parties and leaders: NA
Member of: SPC. WHO (associate)
Diplomatic representadoa In l)S: none
(territory of New Zealand)
IJS dlphimatlc representation: none
(territory of New Zealand)
Flag: the flag of New Zealand is used
Ecoimmy
Overview: Tokelau''s small size, isolation,
and lack of resources greatly restrain economic
development and conftne agriculture to the
subsistence level. The people must rely on aid
from New Zealand to maintain public services,
annual aid being substantially greater than
GDP. The principal sources of revenue come
from sales of copra, postage stamps, .souvenir
coins, and handicrafts. Money is also remitted
to families from relatives In New Zealand.
Natlmwl product: GDP— exchange rate
conversion — $1.4 million ( I )88 est.)
Natimml product reui growth rote: NA%
Natioiml product per ^ta: $800(1988
est.)
lBflotionralo(cousuuwrprlCM): NA%
Unemploymmt rate: NA%
Budget:
revenues: $430,830
expenditures; $2.8 billion, including capital
expenditures of $37,300 ( 1987 est.)
Exporti: $98,000 (f.o.b.. 1983)
commodities: stamps, copra, handicrafts
partners: NZ
Imports: S323.4(X) (c.i.f.. 1983)
commodities: foodstuffs, building materials,
fuel
partners; NZ
Extemaldebt: $0
Industrial producthm: growth rate NA%
Electricity:
capacity: 200 kW
production; 300,000 kWh
consumption per capita: 1 80 kWh ( 1 990)
Imlustrtcs: small-scale enterprises for copra
production, wood work, plait^ craft goods;
stamps, coins: fishing
Agriculture: coconuts, copra; basic
subsistence crops — breadfruit, papaya,
bananas; pigs, poultry, goats
Economic aid:
recipient: Western (non-DS) countries. ODA
and OOF bilateral commitments (1970-89),
$24 million
Currency: I New Zealand dollar (NZ$)s |00
cents
Exchange rates: New Zealand dollars (NZ$)
per US$1— 1.7771 (January 1994). 1.8495
(1993). ! 8584(1992), 1.7265(1991), 1.6750
(1990), 1.6708(1989)
Fiscal yciu'': I April — 31 March
Names:
conventional long form; Independent State of
Western Samoa
conventional short form; Western Samoa
Digraph: WS
Type: constitutional monarchy under native
chief
Capital: Apia
Administrative divisions: 1 1 districts;
A''ana, Aiga-i-le-Tai, Atua, Fa’asaleleaga,
Gaga''emauga, Gagaifomauga, Palauli,
Satupa''itea, Tuamasaga, Va’a-o-Fonoti,
Vaisigano
Independence: I January 1962 (from UN
trusteeship administered by New 2^aland)
National holiday: National Day. I June
(1962)
Constitution: I January 1962
Legal system: based on English common law
and local customs; judicial review of
legislative acts with respect to fundamental
rights of the citizen; has not accepted
compulsory ICJ jurisdiction
Suffrage: 21 years of age; universal, but only
matai (head of family) are able to run for the
Legislative Assembly
Executive branch:
chief of state: Chief Susuga Malietoa
TANUMAFlLl II (Co-Chief of State from 1
January 1962 until becoming sole Chief of
State on 5 April 1963)
head of government; Prime Minister
TOFILAU Eti Alesana (since 7 April 1 988)
cabinet; Cabinet; appointed by the head of
state with the prime minister''s advice
Legislative branch: unicameral
Legislative Assembly (Fono): elections last
held 5 April 1991 (next to be held by NA
1996); results — percent of vote by party NA;
seats— (47 total) HRPP 28, SNDP 18,
independents I
Judicial branch: Supreme Court, Court of
Appeal
Political parties and leaders: Human Rights
Protection Party (HRPP), TOFILAU Eti
Alesana, chairman; Samoan National
Development Party (SNDP), TAPUA
Tamasese Efi, chairman
Member of: ACP, AsDB, C, ESCAP, FAO,
G-77, IBRD, ICFTU, IDA, IFAD, IFC, IMF,
INTELSAT (nonsignatory user), IOC, ITU,
LORCS, SPARTECA, SPC, SPF, UN.
UNCTAD, UNESCO. UPU, WHO
Diplomatic representation in US;
chief of mission; Ambassador Neron; SLADE
chancery: 820 Second Avenue, Suite 800,
New York, NY 10017
telephone; (212) 599-6196 or6l97
FAX; (212) 972-3970
US diplomatic representation:
chief of mission; the ambassador to New
Zealand is accredited to Western Samoa
embassy: 5th floor. Beach Road, Apia
mailing address: P.O. Box 3430, Apia
telephone; (685) 21-631
FAX; (685) 22-030
Flag: red with a blue rectangle in the upper
hoist-side quadrant bearing five white five-
pointed stars representing the Southern Cross
constellation
Digraph: XX
Administrative divisions: 263 sovereign
nations, dependent areas, other, and
miscellaneous entries
Legal system: varies by individual country;
182 are parties to the United Nations
International Court of Justice (ICJ or World
Court)','22502a0a8b9ac1b2387c2804b77c68fa21348f8a2894f287cc81295fab58bd57','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('acc4190d9c388bdbe9aa6e2c30b9913dbd8a4c6018b4f233e8c9ae15fb310037',1994,'AD','Andorra','government',32,'Names;
conventional long form: Principality of
conventional short form: Andorra
local hmg form: Principal d'' Andorra
local short form: Andorra
Digraph: AN
Type: parliamentary democracy (since March
1^3) that retains as its heads of state a co¬
principality; the two princes are the president
of France and Spanish bishop of Seo de Urgel.
who are represented locally by officials called
veguers
Capital: Andorra la Vella
Administrative divisions: 7 parishes
(parroquies, singular — parroquia); Andorra,
Canillo. Encamp. La Massana, Les Escaides,
Ordino. Sant Julia de Loria
Independence: 1278
National holiday: Mare de Deu de Meritxell,
8 September
Constitution: Andorra''s first written
constitution was drafted in 1991 ; adopted 14
March 1993
Legal system: based on French and Spanish
civil codes: no judicial review of legislative
acts; has not accepted compulsory ICJ
jurisdiction
SuffCage; 1 8 years of age, universal
Executive branch:
chiefs of .state: French Co-Prince Francois
MITTERRAND (since 21 May 1981),
represented by Veguer de Franca Jean Pierre
COURTOIS (since NA): Spanish Episcopal
Co-Prince Mgr. Juan MARTI Alanis (since 31
January 1971 ), represented by Veguer
Episcopal Francesc BADIA Bala — two co¬
princes (President Francois MITTERRAND of
France, since 21 May 1981. and Bishop of Seo
de Urgel Juan MARTI Alanis in Spain, since
3 1 January 1971), two designated
representatives (France — Veguer de Franca
8','69bd38472162412f4b77efe6ae9010b50104896bcd2845a5a17db602d6b44ee7','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35f1c6c14b9ae2b8be5f5477dbb03e7b8562f64670cecd1db1893b27e3b29a86',1994,'AO','Angola','government',33,'Jean Piene COURTOIS. since NA, and
Spain — Veguer Episcopal Prancesc BADIA
Bata, since NA), two permanent delegates
(French Prefect Pierre STEINMETZ for the
department of Pyrenees-Orientales, since NA,
and Spanish Vicar General Nemesi
MARQUES Oste for the Seo de Urgel diocese,
since NA)
head of government: Executive Council
President Oscar RIBAS Reig (since 10
December 1993) elected by Parliament
cabinet: Executive Council: designated by the
executive council president
Lci^atlvc branch: unicameral
General Council of the Valleys: (Consell
General de las Vails); elections last held 1 2
December 1993 (next to be held NA); yielded
no clear winner; results — percent of vote by
pany NA; seats — (28 total) number of seats by
party NA
Judicial branch; Supreme Court of Andorra
at Perpignan (France) for civil cases, the
Ecclesiastical Court of the bishop of Seo de
Urgel (Spain) for civil cases. Tribunal of the
Courts (Tribunal des Cortes) for criminal cases
Politkai parties and leaders: National
Democratic Group (AND), Oscar RIBAS Reig
and Jordi FARRAS; Liberal Union (UL),
Francesc CERQUEDA; New Democracy
(ND), Jaume BARTOMEU; Andorran
National Coalition (CNA), Antoni
CERQUEDA; National Democratic Initiative
(IDN), Vincenc MATEU: Liberal Union (UL),
Francesc CERQUEDA
note: there are two other small parties
Member of: ECE, INTERPOL, IOC, UN
Dlptomatic representation in US: Andorra
has no mission in the US
US diplotnatic representation; Andorra is
included within the Barcelona (Spain)
Consular District, and the US Consul General
visits Andorra periodically
Flag: three equal vertical bands of blue (hoist
side), yellow, and ted with the national coat of
arms centered in the yellow band; the coat of
arms features a quartered shield: similar to the
flags of Chad and Romania that do not have a
national coat of arms in the center
Note: Civil war has been the norm since
independence on 1 1 November 1975; a cease¬
fire lasted from 31 May 1991 until October
1992 when the insurgent National Union for
the Total Independence of Angola (UNITA)
refused to accept its defeat in internationally
monitored elections; fighting has since
resumed throughout much of the countryside.
Nevertheless, the two sides are negotiating the
details for holding the second round of
presidential elections.
Names:
conventional long form: Republic of Angola
conventional short form: Angola
local long form: Republica de Angola
local short form: Angola
former; People''s Republic of Angola
Digraph: AO
Type: transitional government nominally a
multipany demiKracy with a stixmg
presidential system
Capital: Luanda
Administrative divtslora: 1 8 provinces
(provincias, singular — pmvincia): Bengo.
Benguela. Bie. Cabinda. Cuando Cubango.
Cuan/a Norte. Cuanra Sul. Cunene. Huambs>.
Huila. Luanda. Lunda Norte. Lunda Sul.
Malanje, Moxico, Namihc. Uige. Zaire
Independence: 1 1 November 1975 (from
Portugal)
National holiday: Independence Day. 1 1
November ( 1975)
Constitution: 1 1 November 1975; revi.sed 7
January 1978. 1 1 August 1980.6 March 1991.
and 26 August 1992
Legal system: based on Portuguese civil law
system and customary law; recently mixlified
to accommodate political pluralism and
increased use of free markets
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: President Jose Eduardo DOS
SANTOS (since 21 SefUember 1979)
head of government; Prime Minister
Marcolino Jose Carlos MfXTO (since 2
December 1992)
cabinet: Couneil of Ministers; appointed by
(he president
Legislative branch: unicameral
National Assembly (Assemhleia Nacibnal):
first nationwide, multiparty elections were held
29-.30 September 1992 with disputed results;
further elections are being discussed
Judicial branch: SupremcCourt(Tribunalda
Relacao)
Political parties and leaders; Popular
Movement for the Liberation of Angola
(MPLA), led by Jose Eduardo DOS SANTOS,
is the ruling party and has been in power since
1975; National Union for the Total
Independence of Angola (UNITA). led by
Jonas SAVIMBI. remains a legal party despite
its return to armed resistance to the
government; five minor parties have small
numbers of seats in the National Assembly
Other political or pressure groups;
Cabindan State Liberation Front (FLEC),
N''ZITA Tiago. leader of largest faction
(FLEC-FAC)
note; FLEC is waging a small-scale, highly
factionalized. armed struggle fur the
independence of Cabinda Province
Member of: ACP. AfDB, CCC. CEEAC
(observer). ECA. FAO, FLS, G-77. IBRD,
ICAO. IDA. IFAD, IFC. ILO. IMF. IMO,
INTELS AT. INTERPOL, IOC. lOM. ITU.
LORCS. NAM, OAS (observer). OAU.
SADC. UN. UNCTAD, UNESCO, UNIDO,
UPU, WCL. WFTU, WHO. WIPO. WMO.
WTO
Diplomatic representation in US:
chief of mission: Ambassador Jose PATRICIO
embassy; 1 899 L Street NW. 5th floor.
Washington. DC ?(X)38
telephone: (202) 785- 1 156
FAX: (202) 785-12.58
US diplomallc rtpregeiUathm;
chief of mission; /Ambassador Edmund
DEJARNETTE
embassy: Miramar, Luanda
mailing atidress; CP6484, Luanda, Angola
(mail international); US Embassy. Luanda,
Department of State. Washington, D.C. 20521-
25.50 (pouch)
telephone; |244| (2) 39-24-98
MJf.- 1244) (2) 39-05-15
Hag: two equal horizontal bands of red (top)
and black with a centered yellow emblem
consisting of a ftve-pointed star within half a
cogwheel crossed by a machete (in the style of
a hammer and sickle)','3e3267d55bed40ac79201e625cbf3b5c63e0f5f96799404223fa1ae53ec3db1c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f3d18c778598e90c2a413becf45d37f7a8708e106aa56571cedf6fa3c0d9870',1994,'AI','Anguilla','government',43,'Names:
conventional Umu fom: none
conventional short fonn: Anguilla
Digraph: AV
Type: dependent territory of the UK
Capital: The Valley
Administrative divisions: none (dependent
territory of the UK)
Independence: none (dependent territory of
the UK)
National holiday; Anguilla Day. 50 May
Constitution: Anguilla Constitutional Orders
1 April 1982; and amended 1990
Legal system: based on English common law
Sufhvge: 1 8 years of age: universal
Executive branch:
chiej of state; Queen ELIZABETH II (since 6
February 1952). represented by Governor Alan
W. SHAVE (since 14 August 1992)
head of government; Chief Minister Hubert
HUGHES (since 16 March 1994)
cabinet; Executive Council; appointed by the
governor from the elected members of the
House of Assembly
Legislative hranch: unicameral
House of Assembly; elections last held 16
March 1994 (next to be held March 1999);
results — percent of vote by party NA; seats —
( 1 1 total. 7 elected) ANA 2. AUP 2. ADP 2,
independent I
Judicial branch: High Court
Political parties and leaders: Anguilla
National Alliance (ANA): Anguilla United
Party (AUP). Hubert HUGHES; Anguilla
Democratic Party (ADI''), Victor BANKS
Member of: CARICOM (observer). CDB,
INTERPOL (subbureau)
Diplomatic representation in US; none
(dependent territory of the UK)
US dipiomatic representation: none
tdependent territory of the UK)
nag: two horirtontul bands of white (lop.
almost triple width) and light blue with three
orange dolphins in an interlocking circular
design centered in the white band: a new flag
may have been in use since 50 May 1990','b9ad9857cf51fa6c8141b436996e87596302c562879a83be3dd15b1b48fd43b5','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77084ba04d8b766ea9866f39245f020607dd2d0ff2a9805e49fc7e608008a1f4',1994,'AQ','Antarctica','government',49,'Names:
conventional long form: none
conventional short form: Antarctica
Digraph: AY
Type:
Antarctic Treaty Sumintiry: The Antarctic
Treaty, signed on I De^’cmber 1959 and
enter^ into force on 23 June 1961, establishes
the legal framework for the manageinent of
Antarctica. Administration is carried out
through consultative member meetings — the
1 8th Antarctic Treaty Consultative Meeting
was in Japan in April 1993. Currently, there are
42 treaty member nations: 26 consultative and
16 acceding. Consultative (voting) members
include the seven nations that claim portions of
Antarctica as national territory (some claims
overlap) and 19 ncnclaimant nations. The US
and some other nations that have made no
claims have reserved the right to do so. The US
does not recognize the claims of others. The
year in parenthe.ses indicates when an acceding
nation was voted to full consultative (voting)
status, while no date indicates the country was
an original 1959 treaty signatory. Claimant
nations are — Argentina, Australia. Chile.
France, New Zealand. Norway, and the UK.
Nonclaimant consultative nations are —
Belgium, Brazil (1983), China (1985), Ecuador
( 1 990). Finland ( 1 989). Germany (1981). India
( 1983), Italy (1987). Japan, South Korea
(1989). Netherlands (1990). Peru (1989).
Poland (1977). .South Africa. Spain ( 1988).
Sweden ( 1988). Uruguay (1985). the US, and
Russia. Acceding (nonvoting) members, with
year of accession in parentheses, are — Austria
( 1 987). Bulgaria (1978). Canada ( 1988),
Colombia (1988). Cuba (1984). Czech
Republic ( 1993), Denmark ( 1965), Greece
(1987), Guatemala (1991). Hungary (1984).
North Korea (1987). Papua New Guinea
(1981), Romania (1 971). Slovakia (1993),
Switzerland (1990), and Ukraine (1992).
Article I: area to be used for peaceful purposes
only; military activity, such as weapons
testing, is prohibited, but military personnel
and equipment may be used for scientific
research or any other peaceful purpose
Article 2: freedom of scientific investigation
and cooperation shall continue
Article J: free exchange of infomiation and
personnel in cooperation with the UN and other
international agencies
Article 4: does not recognize, dispute, or
establish territorial claims and no new claims
shall he asserted while the treaty is in force
Names;
conventional long form: Argentine Republic
conventional short form: Argentina
local long form: Republica Argentina
local short form: Argentina
Digraph: AR
Type: republic
Capital: Buenos Aires
Administrative divisions: 23 provinces
(provincias, singular — provincia), and 1
federal district* (distrito federal); Buenos
Aires; Catamarca; Chaco; Chubut; Cordoba;
Corrientes; Distrito Federal*; Entre Rios;
Formosa; Jujuy; La Pampa; La Rioja:
Mendoza; Misiones; Neuquen; Rio Negro;
Salta; San Juan; San Luis; Santa Cmz; Santa
Fe; Santiago del Estero; Tieira del Fuego,
Antartida e Islas del Atlantico Sur; Tucuman
note: the US does not recognize any claims to
Antarctica or Argentina''s claims to the
Falkland Islands
Independence; 9 July 1816 (from Spain)
National holiday: Revolution Day. 25 May
(1810)
Constitution: 1 May 1853
Legal system: mixture of US and West
European legal systems; has not accepted
compulsory ICJ jurisdiction
Suffrage: 1 8 years of age: universal
Executive branch:
chief of state and head of government:
President Carlos Saul MENEM (since 8 July
1989); ''Vice President (position vacant):
election last held 14 May 1989 (next to be held
summer 1995); results — Carlos Saul MENEM
was elected
cabinet: Cabinet; appointed by the president
Legislative branch: bicameral National
Congress (Congreso Nacional)
Senate: elections last held May 1989, but
provincial elections in late 1991 set the stage
for indirect elections by provincial senators for
one-third of 48 seats in the national senate in
May 1992; seats (48 total) — PJ 30, UCR 1 1.
others 7
Chamber of Deputies: last election — October
1993 ( next — October 1995); elections arc held
every two years and half of the total
membership is elected each lime for four year
terms: .seats— (257 total) PJ 1 28. UCR 81,
MODIN 7. UCD 5. other 36
Judicial branch: Supreme Court (Cone
Suprema)
Political parties and leaders: Justicialist
Party (PJ), Carlos Saul MENEM. Peronist
umbrella political organization; Radical Civic
Union (UCR),Raul ALFONSIN. moderately
left-of-center party: Union of the Democratic
Center (UCD), Jorge AGUADO, conservative
party; Intransigent Party (PI). Dr. Oscar
ALENDE, leftist party: Dignity and
Independence Political Party (MODIN). Aldo
RICO, right-wing party; Grand Front (Frenie
17
Argentina (continued)
Grande), Carlos ALVAREZ, center-left
coalition; several provincial parties
Other political or pressure groups;
Peronist-dominated labor movement; General
Confederation of Labor (CGT; Peronist-
leaning umbrella labor organization);
Argentine Industrial Union (manufacturers''
association); Argentine Rural Society (large
landowners'' association); business
organizations; students; the Roman Catholic
Church; the Armed Forces
Member of: AG (observer), Australia Group,
BCIE. CCC, ECLAC, FAO, G-6, G-l 1, G-15,
G-19, G-24, AfDB, G-77, GATT, lADB,
IAEA, IBRD, ICAO, ICC, ICFTU, IDA,
IFAD, IFC, ILO, IMF, IMO, INMARSAT,
INTELSAT, INTERPOL, IOC, lOM, ISO,
ITU, LAES, LAIA, LORCS, MERCOSUR,
MINURSO, MTCR, OAS, PCA, RG, UN,
UNAVEM II, UNCTAD, UNESCO, UNHCR,
UNIDO, UNIKOM, UNOMOZ. UNOSOM,
UNPROFOR, UNTAC, UNTSO, UPU, WCL,
WFTU, WHO, WIPO, WMO, WTO
Diplomatic representation in US:
chief of mission: Ambassador Raul Enrique
GRANILLO OCAMPO
chancery: 1600 New Hampshire Avenue NW,
Washington, DC 2(KX)9
telephone: (202) 939-6400 through 6403
consulate(s) general: Atlanta, Chicago,
Houston, Los Angeles, Miami, New Orleans,
New York, San Francisco, and San Juan
(Puerto Rico)
US diplomatic representation:
chief of mission: Ambassador James CHEEK
(since 28 May 1993)
embassy: 4300 Colombia, 1425 Buenos Aires
mailing address; APO AA 34034
telephone: [54] (1) 774-761 1, 881 1, 991 1
FAX; [541 (1)775-4205
Flag: three equal horizontal bands of light
blue (top), white, and light blue; centered in the
white band is a radiant yellow sun with a
human face known as the Sun of May
Independence: 1 8 September 1810 (from
Spain)
National holiday: Independence Day, 1 8
September (1810)
Constitution: II September 1980, effective
1 1 March 1981; amended 30 July 1989
Legal system: based on Code of 1 857 derived
from Spanish law and subsequent codes
influenced by French and Austrian law;
judicial review of legislative acts in the
Supreme Court: has not accepted compulsory
ICJ Jurisdiction
Suffrage: 18 years of age; universal and
compulsory
Executive branch:
chief of state and head of government:
President Eduardo FREI Ruiz-Tagle (since 1 1
March 1994) election last held 1 1 December
1993 (next to be held December 1999);
results — Eduardo FREI Ruiz-Tagle (PDC)
58%, Arturo ALESSANDRI 24.4%, other
17,6%
cabinet: Cabinet; appointed by the president
Legislative branch: bicameral National
Congress (Congreso Nacional)
Senate (Senado): election last held 1 1
December 1993 (next to be held December
1997); results — percent of vote by party NA:
seats — (46 total. 38 elected) Concertation of
Parties for Democracy 21 (PDC 13, PS 4, PPD
3, PR 1), Union for the Progress of Chile 15
(RN 1 1. UDI 3. UCC 1). right-wing
independents 10
Chainherof Deputies (Camara de Dipatados):
election last held 1 1 December 1993 (next to be
held December 1997); results — Concertation
of Parties for Democracy 53.95% (PDC
27.16%, PS 12,01%. PPD 1 1.82%, PR
2.96%,); Union for the Progress of Chile
.30.57% (RN 15.25%, UDI 12.1.3%, UCC
3.19%); seats — (120 total) Concertation of
Parties for Democracy 70 (PDC 37. PPD 15,
PR 2. PS 15. left-wing independent 1). Union
for the Progress of Chile 47 (RN 30, UDI 15.
UCC 2). right-wing independents 3
Judicial branch: Supreme Court (Cone
Suprema)
Political parties and leaders: Concertation
of Parties for Democracy consists m.ainly of
four parties; Christian Democratic Party
(PDC), Cuitenberg MARTINEZ; Socialist
Party (PS), Camilo ESCALONA; Party for
Democracy (PPD), Victor Manuel
REBOLLEDO; Radical Party (PR), Carlos
GONZALEZ Marquez; Union for the Progress
of Chile consists mainly of three parties;
National Renewal (RN), Andres
ALLAMAND; Independent Democratic
Union (UDI), Jovino NOVOA; Center Center
Union (UCC), Francisco Javier ERRAZURIZ
Other political or pressure groups;
revitalized university student federations at all
major universities; labor — United Labor
Central (CUT) includes trade unionists from
the country''s five largest labor confederations;
Roman Catholic Church
Member of: CCC, ECLAC, FAO, G-1 1 ,
G-77, GATT. lADB, IAEA. IBRD, ICAO,
ICFTU, IDA, IFAD, IFC, ILO, IMF. IMO,
INMARSAT, INTELSAT, INTERPOL. IOC,
lOM, ISO. ITU, LAES, LAIA, LORCS, NAM.
OAS. ONUSAL. OPANAL. PCA, RG. UN.
UNCTAD, UNESCO, UNIDO, UNMOGIP,
UNTAC, UNTSO. UPU, WCL, WFTU, WHO,
WIPO, WMO, WTO
Diplomatic representation in US:
chief of missiott: Ambassador John BIEHL del
Rio
chancery: 1732 Massachusetts Avenue NW,
Washington, DC 20036
telephone: (202) 785-1746
FAX: (202) 887-5579
consalate(s) general: Houston, Los Angeles.
Miami, New York. Philadelphia, San
Francisco, and San Juan (Puerto Rico)
US diplomatic representation:
chief of mission: Ambassador Curtis W.
KAMMAN
embassy: Codina Building, 1 343 Agustinas,
Santiago
mailing address: Unit 4127, Santiago; APO
AA 34033
rWep/iwie,'' [561 (2)671-0133
FAX: [56] (2)699-1141
Flag: two equal horizontal bands of white
(top) and red: there is a blue square the same
height as the white band at the hoist-side end of
the white band; the square bears a white
five-pointed star in the center; design was
based on the US flag
Independence; 486 (unified by Clovis)
National holiday; National Day. Taking of
the Bastille, 14 July (1789)
Constitution: 28 September 1958, amended
concerning election of president in 1962,
amended to comply with provisions of EC
Maastricht Treaty in 1992; amended to tighten
immigration laws 1993
Legal system: civil law sy.stem with
indigenous concepts; review of administrative
but not legislative acts
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Francois
MITTERRAND (since 2 1 May 1 981); election
last held 8 May 1988 (next to be held by May
1995): results — Second Ballot Francois
MITTERRAND 54%. Jacques CHIRAC 46%
head of government: Prime Minister Edouard
BALLADUR (since 29 March 1993)
cabinet: Council of Ministers; appointed by
the president on the suggestion of the prime
minister
Legislative branch: bicameral Parliament
(Parlement)
Senate (Senat): elections last held 27
September 1992 (next to be held September
1995 — nine-year tenn, elected by thirds every
three years); results — percent of vole by party
NA; scats — (321 total; 296 metropolitan
France, 13 for overseas departments and
territories, and 12 for French nationals abroad)
RPR 9 1 . UDF 142 (UREI 5 1 . UC 68, RDE 23).
PS 66, FCF 16, independents 2, other 4
National Assembly (Assemhiee Nationale):
elections last held 2 1 and 28 March 1 993 (next
to be held NA 1998); results - percent of vole
by party NA; seats — (577 total) RPR 247, UDF
213, PS 67, PCF 24, independents 26
Judicial branch: Constitutional Court (Cour
Constitutionnelle)
Political parties and leaders: Rally for the
Republic (RPR). Jacques CHIRAC; Union for
French Democracy (UDF, federation of UREI,
UC, RDE). Valery Giscard d’ESTAlNG;
Republican Party (PR), Gerard LONGUET;
Center for Social Democrats (CDS), Pierre
MEHAIGNERIE; Radical (RAD). Yves
GALLAND; Socialist Party (PS), Michel
ROCARD; Left Radical Movement (MRG),
Jean-Francois HORY ; Communist Party
(PCF), Robert HUE; National Front (FN),
Jean-Marie LE PEN: Union of Republican and
Independents (UREI); Centrist Union (UC):
DemcKratic Assembly (RDE); The Greens,
Antoine WAECHTER. Jean-Louis VIDAL.
Guy CAMBOT; Generation Ecology (GE),
Brice LALONDE
Other political or pressure groups;
Communist-controlled labor union
(Confederation Generale du Travail — CGT)
nearly 2.4 million members (claimed):
Socialist-leaning labor union (Confederation
Ftaticaise Democratique du Travail or CFDT)
about 8(X),000 members (est.): independent
labor union (Force Ouvriere) I million
members (est,); independent white-collar
union (Confederation Generale des Cadres)
340,(XX) members (claimed); National Council
of French Employers (Conseil National du
Patronat Ftancai.s — CNPF or Patronat)
Member of; ACCT, AfDB, AG (observer),
AsDB, Australia Group, BDEAC, BIS. CCC.
CDB (non-regional), CE. CERN, COCOM.
CSCE, EBRD, EC. ECA (asswiate). ECE.
ECLAC. EIB, ESA, ESCAP. FAO. FZ. GATT.
G-5, G-7. G-IO, lADB. IAEA. IBRD. ICAO,
ICC, ICFTU, IDA. lEA. IFAD, IFC. ILO. IMF.
IMO, INMARSAT. INTELSAT. INTERPOL.
IOC. lOM, ISO. ITU. LORCS. MINURSO.
MTCR, NACC, NATO. NEA. NSG, OAS
(observer), OECD. ONUSAL. PCA. SPC. UN,
UNCTAD, UNESCO, UNHCR. UNIDO,
UNIFIL, UNIKOM, UNOSOM. UNPROFOR,
UNRWA, UN Security Council, UNTAC. UN
Tmsteeship Council, UNTSO. UPU. WCL.
WEU, WFTU. WHO, WIPO. WMO, WTO.
zc
Diplomatic representation in US:
chief of mission: Ambassador Jacques
ANDREANI
chant ers'': 4101 Reservoir Road NW,
Washington. DC 2(XX)7
telephone: (202) 944-6(XX)
consulatefsl general: Atlanta. Boston,
Ch-cago, Honolulu. Houston, Los Angeles,
Miami. New Orleans, New York. San
Francisco, and San Juan (Puerto Rico)
US diplomatic representation:
chief of mission: Ambassador Pamela C.
HARRIMAN
embassx: 2 Avenue Gabriel, 75382 Paris
Cedex ()8
mailing address: Unit 2 1 55 1 , Paris; APO AE
09777
telephone: 1331(1) 42%- 1 2-02 or 42-6 1 -80-75
FAY.- 1.33] (1)4266-9783
consulale(s) general: Bordeaux, Marseille,
Strasbourg
Flag: three equal vertical bands of blue (hoist
side), white, and red; known as the French
Tricouleur (Tricolor): the design and colors are
similar to a number of other flags, including
those of Belgium, Chad, Ireland, Cote d'' I voire,
and Luxembourg; the official flag for all
French dependent areas','f5addf85300833a5b7ea34f6067409f03a746f5b800551ec34613cfe5c4d28f1','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38b82f4f9da61e0c7b0e5a32d054834fad310b09a670588443a127e3acafc593',1994,'AG','Antigua and Barbuda','government',50,'Barbudt
CatMaanSaa
%
iHm ^
lAINT JOHN''S.
ap[^
Antigua
G«o|r«phy
Antarctica (continued)
Article 5; prohibits nuclear explosions or
disposal of radioacti'' '' wastes
Ankle 6: Includes under the treaty all land and
ice shelves south of 60 degrees 00 minutes
south
Ankle 7; treaty-state observers have free
access, including aerial observation, to any
area and may inspect all stations, installations,
and equipment: advance notice of all activities
and of the introduction of military personnel
must be given
Ankle 8; allows for jurisdiction over
observers and scientists by their own states
Ankle 9; frequent consultative meetings take
place among member nations
Ankle 10; treaty states will discourage
activities by any country in Antarctica that are
conuary to the treaty
Ankle 11: disputes to be settled peacefully by
the parties concerned or, ultimately, by the ICJ
Article 12, 13, 14; deal with upholding,
interpreting, and amending the treaty among
involved nations
Other agreements; more than 170
recommendations adopted at treaty
consultative meetings and ratified by
governments include — Agreed Measures for
the Conservation of Antarctic Fauna and Flora
(1964): Convention for the Conservation of
/Antarctic Seals (1972); Convention on the
Conservation of Antarctic Marine Living
Resources ( 1980): a mineral resources
agreement was signed in 1988 but was
subsequently rejected: in 1991 the Protocol on
Environmenul Protection to the Antarctic
Treaty was signed and awaits ratification: this
agreement provides for the protection of the
Antarctic environment through five specific
annexes on marine pollution, fauna, and flora,
environmental impact assessments, waste
management, and protected areas; it also
prohibits all activities relating to mineral
resources except scientific research; nine
parties have ratified Protocoi as of April 1994
Legal system: US law, including certain
criminal offenses by or against US nationals,
such as murder, may apply to areas not under
jurisdiction of other countries. Some US iaws
directly apply to Antarctica. For example, the
Antarctic Conservation Act, 16 U.S.C. section
2401 et seq., provides civil and criminal
penalties for the following activities, unless
authorized by regulation of statute: The taking
of native mammals or birds; the introduction of
nonindigenous plants and animals; entry into
specially protected or scientific areas; the
discharge or disposal of pollutants; and the
importation into the US of certain items from
Antarctica. Vioiation of the Antarctic
Conservation Act carries penalties of up to
$10,000 in fines and 1 year in prison. The
Departments of Treasury, Commerce,
Transportation, and Interior share enforcement
responsibilities. Public Law 9S-S4I, the US
Antarctic Conservation Act of 1978, requires
expeditions from the US to Antarctica to
notify, in advance, the Office of Oceans and
Polar Affairs, Room 5801, Department of
State, Washington, DC 20520, which reports
such plans to otlmr nations as required by the
Antarctic Treaty. For more information contact
Permit Office, Office of Polar Programs,
National Science Foundation, Arlington,
Virginia 22230(703-306-1031).
Names;
eonventional lonK forni: none
eonventianal .short fonn: Antigua and Barbuda
Digraph: AC
Type: parliamentary demsKracy
Capital: Saint John''s
Administrative divisions; 6 parishes and 2
uependencies*; Barbuda*. Redt>nda*. Saint
George, Saint John. Saint Mary. Saint Paul.
Saint Peter. Saint Philip
Independence: I November 1981 (frem UK)
National holiday: Independence Day. I
November (1 981)
Constitution; I November 1981
Legal system: bused on English common law
Suftlrage: 1 8 years of age; universal
Executive branch;
chief of .state: Queen ELIZABETH II (since 6
February 1952). represented by Governor
General James B. C ARLISLE (since NA 1 993)
heatlofaneernment: Prime Minister Lester
Bryant BIRD (since 8 March 1994)
cabinet: Council of Ministers; appointed by
the governor general on the advice of the prime
minister
Legislative branch: bicameral Parliament
Senate: 1 7 member body appointed by the
governor general
House of Repre.sentatiyes: elections last held 8
March 1994 (next to be held NA 1999); results
— percent of vote by party NA; seats — (17
total) ALP 1 1 . liPP 5. independent I
Judicial branch: Eastern Caribbean Supreme
Court
Political parties and leaders: Antigua
Labor Party (ALP). Lester Bryant BIRD;
United Progressive Partv (UPP). Baldwin
SPENCER
Other political or pressure groups: United
Progressive Party (UPP). headed by Baldwin
.SPENCER, a couli(ion of three opposition
ptviiticul parties — the United National
Democratic Party (UNDP): the Antigua
Caribbean Liberation Movement ( ACLM ); and
the Progressive Labor Movement (PLM);
Antigua Trades and Labor Union (ATLU).
headed by Noel THOMAS
Member of: ACP.C.CARiCOM.CDB.
ECLAC. FAO. G-77. GATT. IBRD. ICAO.
ICFTU. IFAD. IFC. ILO. IMF. IMO.
INTELSAT (nonsignatory user). INTERPOL.
IOC. ITU. LORCS. NAM (observer). OAS.
OECS. OPANAL. UN. UNCTAD. UNESCO.
WCL. WHO. WMO
Diplomatic representation in US:
chUfof''mi.s.sion: Ambassador Patrick Albert
LEWIS
chancers-: Suite 4M. 34(X) International Drive
NW. Washington. DC 20008
telephone: (202) 362-521 1 or 5 1 66. 5122
FAX: (202) 362-5225
consulatel.sl ftenertti: Miami
US diplomatic representation:
chief of mi.s.sion: the US Ambas.sador to
Barbados is accredited to Antigua and
Barbuda, and, in his absence, the Embassy is
headed by Charge d'' Affaires Bryant J.
SALTER
embsmy: Queen Elizabeth Highway, Saint
John''s
mailing addre.ss: FFO AA 34054-(X)0l
telephone: (809) 462-3505 or 3506
FAX: (809)462 .3516
Elag: red with an inverted isosceles triangle
based on the top edge of (he flag; the triangle
contains three horizontal bands of black (top),
light blue, and white with a yellow'' rising sun in
the black band
Digraph: XQ','85f919c18691f9f25fa5c8b64dd7aa34a29c3ba2d2052737cecc25db69a5be2f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e2434d10c80416a647c89d88c71b8ee5589c8cc7a3c339979f39f964a8ca6f8',1994,'AM','Armenia','government',64,'Names:
conventional long form: Republic of Armenia
conventional .short form: Armenia
local long form: Hayastani Hanrapetut''yun
local short form: Hayastan
former: Armenian Soviet Socialist Republic;
Armenian Republic
Digraph: AM
Type: republic
Capital: Yerevan
Administrative divisions: none (all rayons
arc under direct republic jurisdiction)
Independence: 28 May 1918 (First Armenian
Republic); 23 September 1991 (from Soviet
Union)
National holiday: Referendum Day, 21
September
Constitution: adopted NA April 1978; post-
Soviet constitution not yet adopted
Legal system: based on civil law system
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: President Levon Akopovich
TER-PETROSYAN (since IbOctober 1991),
Vice President Gagik ARUTYUNYAN (since
1 6 October 1991); election last held 1 6 October
1991 (next to be held NA); results — Levon
Akopovich TER-PETROSYAN 86%; radical
nationalists about 7%; note — Levon
Akopovich TER-PETROSYAN was elected
Chairman of the Armenian Supreme Soviet 4
August 1990 before becoming president
head of government: Prime Minister Hrant
BAGRATY AN (since 16February 1993); First
Deputy Prime Minister Vigen CHITECHYAN
(since 16 February 1993)
cabinet: Council of Ministers; appointed by
the president
Legislative branch: unicameral
Supreme Soviet: elections last held 20 May
1990 (next to be held NA); results — percent of
vote by party NA; seats — (260 total) non-
aligned 125, ANM 52. DPA 23, Democratic
Liberal Party 17, ARF 17, NDU 9, Christian
Democratic Party 1 , Constitutional Rights
Union 1, UNSD I, Republican Party I,
Nagorno-Karabakh representatives 13
Judicial branch: Supreme Court
Political parties and leaders: Armenian
National Movement (ANM), fer-Husik
LAZAR YAN. chairman; National Democratic
Union (NDU), David VARTANYAN,
chairman; Armenian Revolutionary Federation
(ARF, Dashnakisutyun), Arutyun
ALISTAKESYAN, chairman; Democratic
Party of Armenia (DPA; Communist Party),
Aram SARKISYAN, chairman; Christian
Democratic Party, Azat ARSHAKYAN.
chairman; Greens Parly, Hakob
SANASARIAN, chairman; Democratic
Liberal Party, Rouben MIRZAKHANYAN.
chairman; Republican Party, Ashot
NAVARSARDYAN. chairman; Union for
Self-Determination (UNSD), Paruir
AIRIKYAN, chairman
Member of: BSEC, CCC, CIS, CSCE.
EBRD. ECE, IAEA, IBRD, ICAO. IDA,
IFAD, ILO, IMF, INTELSAT, INTERPOL.
IOC, ITU. NACC. NAM (observer), UN,
UNCTAD. UNESCO. UNIDO, UPU. WHO.
WIPO. WMO
Diplomatic representation in US:
chief of mission: Ambassador Rouben Robert
SHUGARIAN
chancery: Suite 210. 1660 L Street NW,
Washington, DC 2(X)36
telephone: (202) 628-5766
US diplomatic representation:
chief of mission: Ambassador Harry J.
GILMORE
embassy: 18 Gen Bagramian, Yerevan
mailing address: use embassy street address
telephone: 7-8852-151-144 or 8852-524-661
FAX; 7-8852-151-138
Flag: three equal horizontal bands of red
(top), blue, and gold
19
Armenia (continued)','235809d0b045b89a4846b64e4aef7c4305a67648dfa1d252ace40cd421076dc5','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('285a12b7468b16bd2f8c96c98bf2458ac9519fad53893fdcf8d97576e66f82b4',1994,'AW','Aruba','government',71,'Names:
conventional long form: none
conventional short form: Aruba
Digraph: AA
Type: part of the Dutch realm; full autonomy
in internal affairs obtained in 1986 upon
separation from the Netherlands Antilles
Capital; Oranjestad
Administrative divisions: none (self-
governing part of the Netherlands)
Independence: none (part of the Dutch realm;
in 1990, Aruba requested and received from
the Netherlands cancellation of the agreement
to automatically give independence to the
island in 1996)
National holiday: Flag Day. 1 8 March
Constitution: I January 1986
Legal system: based on Dutch civil law
system, with some English common law
influence
Suffrage: 1 8 years of age; universal
Executive branch:
chief of Slate: Queen BEATRIX Wilhelmina
Armgard (since 30 April 1980), represented by
Governor General Olindo KOOLMAN (since
I January 1992)
head of government: Prime Minister Nelson
ODUBER (since 6 February 1989)
cabinet: Council of Ministers; appointed with
the advice and approval of the legislature
Legislative branch: unicameral
Legislature (Staten): elections last held 8
January 1993 (next to be held by NA January
1997); results — percent of vote by party NA;
seats— (2 1 total) MEP 9, AVP 8, ADN I . PPA
1. OLA 1, other 1
Judicial branch: Joint High Court of Justice
Political parties and leaders: Electoral
Movement Party (MEP), Nelson ODUBER;
Aruban People''s Party (AVP), Henny EMAN;
National Democratic Action (ADN). Pedro
ChaiTO KELLY; New Patriotic Party (PPN),
Eddy WERLEMEN; Aruban Paulotic Pany
(PPA), Benny NISBET; Aruban Democratic
Party (PDA), Leo BERLINSKI; Democratic
Action ''86 (AD ’86), Arturo ODUBER;
Organization for Aruban Liberty (OLA),
Gleribert CROES
note: governing coalition includes the MEP,
PPA, and ADN
Member of: ECLAC (associate),
INTERPOL, IOC, UNESCO (associate),
WCL, WTO (associate)
Diplomatic representation in US: none
(self-governing part of the Netherlands)
US diplomatic representation; none (self-
governing part of the Netherlands)
Flag: blue with two narrow horizontal yellow
stripes across the lower portion and a red, four-
pointed star outlined in white in the upper
hoist-side comer','d5d7b4741836fcc3fdd275a09ecd94ee339d790cf573848725693aa8a99e4aa0','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71d946705bc189352a8d38b29e65e01baf15d63f90a5b12180f51504bc5ec30d',1994,'NL','Netherlands','government',75,'Names:
conventional long form: Territory of Ashmore
and Cartier Islands
conventional short form: Ashmore and Cartier
Islands
Digraph: AT
Type: territory of Australia administered by
the Australian MinisUr for the Environment,
Sport, and Territories
Capital: none; administered from Canberra,
Names;
conventional long form: Kingdom of Belgium
conventional short form: Belgium
local long form: Royaume de Belgique
local short form: Belgique
Digraph: BE
Type: constitutional monarchy
Capital: Brussels
Administrative divisions: 9 provinces
(French: provinces, singular — province:
Flemish: provincien, singular — provincie);
Antwerpen, Brabant. Hainaut. Liege. Limburg.
Luxembourg, Namur, Oost-Vlaanderen, West-
Vlaanderen
40
Independence: 4 October 1830 (from the
Netherlands)
National holiday: National Day. 21 July
(ascension of King Leopold to the throne in
1831)
Constitution; 7 February 1831, last revised
14 July 1993; parliament approved a
constitutional package creating a federal state
Legal system: civil law system influenced by
English constitutional theory; judicial review
of legislative acts; accepts compulsory ICJ
Jurisdiction, with reservations
Suffrage: 1 8 years of age, universal and
compulsory
Executive branch:
chief of state: King ALBERT II (since NA
August 1993)
head of yoverimicat: Prime Minister Jean-Luc
DEHAENE (since 6 March 1992)
cabinet: Cabinet; the king appoints the
ministers who are chosen by the legislature
Legislative branch: bicameral Parliament
Senate: (Flemish — Senaat, French — Senat);
elections last held 24 November 1991 (next to
be held by November 1996); results — percent
of vote by party NA; seats — ( 1 84 total; of
which 106 are directly elected) CVP 20, SP 14,
PVV (now VLD) 1 3, VU 5, AGALEV 5, VB 5,
ROSSEN 1, P,S 18, PRL 9, PSC 9, ECOLO 6,
FDF I
Chamber of Representatives: (Flemish —
Kamer van Volksvertegenwoordigers,
French — Chambre des Representants);
elections lust held 24 November 1991 (next to
be held by November 1996); results — CVP
16,7%, PS 1 3.6%, SP 1 2,0%. PVV (now VLD)
1 1 .9%, PRL 8.2%, PSC 7.8%, VB 6.6%, VU
5.9%, ECOLO ,<i.l%. AGALEV 4,9%, FDF
2.6%, ROSSEM 3.2%, FN 1.5%: seats— (212
total) CVP ,39, PS 35, SP 28, PVV (now VLD)
26, PRL 20. PSC 18, FB 12, VU 10, ECOLO
10. AGALEV 7. FDF 3, ROSSEM 3, FN I
Judicial branch: Supreme Court of Justice
(Flemish — Hof van Cassatie. French — Cour de
Cassation)
Political parties and leaders; Flemish Social
Christian (CVP). Johan van HECKE.
president; Francophone SiK''ial Christian
(PSC), Melchior WATHELET, president;
Flemish Socialist (SP). Frank
VANDENBROUCKE. president;
Francophone Socialist (PS). Philippe
BUSQUIN; Flemish Liberals and Democrats
(VLD), Guy VERHOFSTADT, president;
Francophone Liberal (PRL), Jean GOL,
president; Francophone Democratic Front
(FDF), Georges CLERFAYT, president;
Volksunie (VU), Bert ANCIAUX, president;
Communist Patty (PCB), Louis VAN GEYT,
president; Vlaams Blok (VB). Karel DILLEN,
chairman; ROSSEM. Jean Pierre VAN
ROSSEM; National Front (FN), Werner van
STEEN; AGALEV (Flemish Greens), no
president: ECOLO (Francophone Ecologists),
no president: other minor parties
Other political or pressure groups:
Christian and Socialist Trade Unions;
Federation of Belgian Industries; numerous
other associations representing bankers,
manufacturers, middle-class artisans, and the
legal and medical professions; various
organizations represent the cultural interests of
Flanders and Wallonia; various peace groups
such as the Flemish Action Committee Against
Nuclear Weapons and Pax Christi
Member of: AG (observer), ACCT. AfDB.
AsDB, Australian Group, Benelux, BIS, CCC.
CE, CERN, COCOM. CSCE. EBRD. EC.
ECE, ElB, ESA, FAO, G-9. G-IO. GATT.
lADB. IAEA. IBRD. ICAO, ICC. ICFTU.
IDA. lEA, IFAD, IFC, ILO. IMF. IMO.
INMARSAT, INTELSAT. INTERPOL. IOC,
lOM, ISO, ITU, LORCS. MINURSO. MTCR,
NACC, NATO, NEA, NSG. OAS (observer).
OECD. PCA, UN. UNCTAD. UNESCO.
UNHCR. UNIDO. UNMOGIP. UNOSOM.
UNPROFOR. UNRWA, UNTAC, UNTSO.
UPU, WCL. WEU. WHO, WIPO, WMO,
WTO, ZC
Diplomatic representation in US:
chief of mission; Ambassador Juan
CASSIERS
chancerv: 33.30 Garfield Street NW,
Washington, DC 20008
telephone; (202) 333-6900
FAX: (202) 333-3079
consulate(s) general: Atlanta, Chicago. Los
Angeles, and New York
US diplomatic representation;
chief of mission: Ambassador Alan J.
BLINKEN
embassy; 27 Boulevard du Regent. Brussels
mailing address: B-1000 Brussels. APO AE
09724
telephone: [32] (2) 513-3830
FAX: 1321 (2) 51 1-2725
Flag: three equal vertical bands of black (hoist
side), yellow, and red; the design was based on
the flag of France
Names;
conventional long form: Kingdom of the
conventional short form: Netherlands
local long form: Koninkrijk dc Ncdcrlanden
local short form: Nederland
Digraph: NL
Type: constitutional monarchy
Capital: Amsterdam: The Hague is the seat of
Administrative divisions: 1 2 provinces
(provincien, singular — provincie); Drenthe,
Flevoland, Friesland. Gelderland. Groningen,
Limburg, Ntxird-Brabant. Noord-Holland,
Overijssel. Utrecht, Zeeland. Zuid-Holland
Dependent areas; Aruba, Netherlands
Antilles
Independence; 1579 (from Spain)
National holiday; Queen''s Day, 30 April
(1938)
Constitution; 17 February 1983
Legal system; civil law system incorporating
French ptenal theory: judicial review in the
Supreme Court of legislation of lower order
rather than Acts of the States General; accepts
compulsory ICJ jurisdiction, with reservations
Suffrage; 18 years of age; universal
Executive branch:
chief of state: Queen BEATRIX Wilhelmina
Armgard (since 30 April 1980); Heir Apparent
WILLEM-ALEXANDER, Prince of Orange,
son of Queen Beatrix (born 27 April 1967)
head of government: Prime Minister
RUDOLPHUS (Ruud) F. M. LUBBERS (since
4 November 1982); Vice Prime Minister
Willem (Wim) KOK (since 2 November
1 989) — resigned after 3 May 1 994
parliamentary elections; no new government
has been formed to date
cabinet: Ministry of General Affairs:
appointed by the prime minister
Legislative branch: bicameral legislature
(Staten Generaal)
First Chamber (Eerste Kamer): elections last
held on 9 June 1991 (next to be held 9 June
1995); results — elected by the country''s 12
provincial councils; seats — (75 total ) percent
of seats by party NA
Second Chamber (Tweede Kamer): elections
last held on 3 May 1 994 ( next to be held in May
1999); results— PvdA 24.3^r, CDA 22.3‘7f,
VVD 20.4%. D''66 16.5%. other 16.5%;
seals— ( 150 total) PvdA 37. CDA .34. VVD 3 1 .
D''66 24. other 24
Judicial branch: Supreme Court (De Hoge
Raad)
Political parties and leaders: Christian
Democratic Appteal (CDA). Elco
BRINKMAN; Labor (PvdA). Wim KOK;
Liberal (VVD). Frits BOLKESTEIN;
Democrats ''66 (D''66). Hans van MIERLO; a
host of minor parties
Other political or pressure groups: large
multinational Firms; Federation of Netherlands
Trade Union Movement (comprising Socialist
and Catholic trade unions) and a Protestant
trade union; Federation of Catholic and
Protestant Employers Associations; the
nondenominational Federation of Netherlands
Enterprises; and Interchurch Peace Council
(IKV)
Member of: AfDB. AG (observer), AsDB,
Australia Group. Benelux. BIS, CCC. CE,
CERN. COCOM. CSCE. EBRD, EC. ECE.
ECLAC. EIB. ESA. ESCAP, FAQ. G-10.
GATT, lADB. IAEA. IBRD. ICAO, ICC,
ICFTU. IDA. lEA. IFAD, IFC. ILO. IMF.
IMO. INMARSAT. INTELSAT. INTERPOL.
IOC. lOM. ISO. ITU. LORCS. MTCR. NACC.
NAM (guest). NATO. NEA. NSG. OAS
(observer). OECD. PCA. UN, UNAVEM II,
UNCTAD, UNESCO, UNHCR, UNIDO.
UNOMUR, UNPROFOR, UNTAC, UNTSO,
UPU, WCL, WEU, WHO, WIPO, WMO,
WTO. ZC
Diplomatic representation in US:
chief of mission: Ambassador Adriaan Pieter
Roetert JACOBOVITS DE SZEGED
chancery: 4200 Linnean Avenue NW,
Washington, DC 20008
telephone: (202) 244-53(X)
FAX: (202) 362-3430
considatels) general: Chicago, Houston, Los
Angeles, Manila (Trust Territories of the
PaciFic Islands), New York
US diplomatic representation:
chief of mission: Ambassador Kirk Terry
DORNBUSH
embassy: Lange Voorhout 102, 2514 EJ The
Hague
mailing address: PSC 71, Box I COO, the
Hague; APO AE 09715
telephone: [31 1 (70) 310-9209
FAX.- (31) (70)361-4688
consulate(s) general: Amsterdam
Flag: three equal horizontal bands of red
(top), white, and blue: similar to the flag of
Luxembourg, which uses a lighter blue and is
longer
Names;
( onventional loan form: none
conventional short form: Netherlands Antilles
local lonK jdrm: m''ue
Im al short form. Nederlandse Antillen
Digraph: NA
Type: part •! the Dutch realm; full autonomy-
in internal affairs granted in 1954
Capital: Willemstad
Administralive divisions: mme (part of the
Dutch realm)
Independence: none (part of the Dutch realm)
Nattonal holiday: Queen’s Day. .30 April
(19.38)
Constitution: 29 December 1954. Statute of
the Realm of the Netherlands, as amended
Legal system: based on Dutch civil law
system, with some English common law
influence
Suffrage: 1 8 years of age; universal
Executive branch:
chief of .slate: Queen BEATRIX Wilhelmina
Armgard (since .30 April 1 980), represented by
Governor General Jaime SALEH (since NA
fXtoher 1989)
head of yovernmeni: Printe Minister Miguel
282
T
r
POURIER (since 25 February 1994)
cahhu’i: Council of Ministers; appointed with
the advice and approval of the unicameral
legislature
Legislative branch; unicameral
Staien: elections last held on 25 February 1994
(next to be held March 1998); results — percent
of vote by party NA; seats — (23 total) PAR 8,
PNP 3, SPA 2, PDB 2, UPB I, MAN 2. DP 1.
WIPM I, DP-St. E 1, DP-St. M I. No:i Patria 1
note: the government of Miguel POURIER is a
coalition of several parties
Judicial branch: Joint High Court of Justice
Political parties and leaders: political
parties are indigenous to each island
Bonaire: Patriotic Union of Bonaire (UPB).
Rudy ELLIS; Democratic Party of Bonaire
(PDB). Franklin CRESTIAN
Curacao; Antillean Restructuring Party
(PAR). Miguel POURIER; National People''s
Pany tPNP). Maria LIBERIA-PETERS; New
Antilles Movement (MAN). Domenico Felip
Don MARTINA; Workers'' Liberation Front
(FOL). Wilson (Papa) GODETT; SiK''ialisl
Independent (SI). George HUECK and Nelson
MONTE; Democratic Party of Curacao (DP).
Augustin DIAZ; Nos Patria. Chin BEHILIA
Saha; Windward Islands People''s Movement
(WIPM Saha). Will JOHNSON; Saba
Democratic Labor Movement. Vernon
HASSELL; Saha Unity Party. Carmen
SIMMONDS
Sint Hustatius: Dcrnwraiic Party of Sint
Eustaiius (DP-.St.E). K. V;in PUTTEN;
Windward Islands People''s Movement
(WIPM); St. Eustatius Alliance (SEA). Ralph
BERKEL
Sint Maarten; DemiK-ratic Party of Sint
Maarten (DP-St.M). Claude WATHEY;
Patriotic Movement of Sint Maarten (SPA).
Vance JAMES
Member of: CARICOM (observer). ECL.3C
(assiK-iate). ICFTU. INTERPOL. IOC.
UNESCO (assiK-iale). UPU, W.MO. WTO
(associate)
Diplomatic representation in US: none
(self-governing part of the Netherlands)
US diplomatic representation:
chief ol''ini.y\\ion; Consul General Bernard J
WOERZ
conxuUite \\;eneral: Saint Anna Boulevard 19.
Willemstad. Curacao
mailinfi atUlresx: P. O, Box 158. Willemstad.
Curacao
rWiydinm. 1.5991)9)61.3066
F. tX.- 1.5991 (9) 616489
Hag: while with a horizontal blue stripe in the
center superimposed on a vertical red band also
centered; fue white five-pointed stars are
arranged in an oval pattern in the center of the
blue band; the live stars represent the five main
islands of Bonaire. Curacao. Saha. Sint
Eusiatiu.s. and Sint Maarten','c6bca665f747a9095c27729cdb79cca992477c8a1d61a3073760e3864c108542','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7fad7f5bade53709af53952178ce617ad4ea6de9b838676ffed24172df9b2934',1994,'AU','Australia','government',76,'Administrative divisions: none (territory of
Australia)
Independence: none (territory of Australia)
Legal system: relevant laws of the Northern
Territory of Australia
Diplomatic representation in US: none
(territory of Australia)
US diplomatic representation: none
(territory of Australia)
Digraph: ZH
Names:
conventional long form: Commonwealth of
conventional short form: Australia
Digraph: AS
Type: federal parliamentary state
Capital: Canberra
Administrative divisions: 6 states and 2
territories*; Australian Capital Territory*,
New South Wales, Northern Territory*,
Queensland, South Australia, Tasmania,
Victoria, Western Australia
Dependent areas: Ashmore and Cartier
Islands, Christmas Island. Cocos (Keeling)
Islands, Coral Sea Islands, Heard Island and
McDonald Islands. Norfolk Island
Independence; I January 1901 (federation of
UK colonies)
National holiday: Australia Day, 26 January
(1788)
Constitution: 9 July 1 900, effective I January
1901
Legal system: based on English common law;
accepts compulsory ICJ jurisdiction, with
reservations
Sufh^ge: 18 years of age; universal and
compulsory
Executive branch:
chief of state; Queen ELIZABETH II (since 6
Febmary 1952). represented by Governor
General William George HAYDEN (since 16
February 1989)
head of government: Prime Minister Paul John
KEA''flNG (since 20 December 1991 ); Deputy
Prime Minister Brian HOWE (since 4 June
1991)
cabinet: Cabinet; prime minister selects his
cabinet from members of the House and Senate
Legislative branch: bicameral Federal
Parliament
Senate: elections last held 13 March 1993
(next lobe held by NA 1996); results — percent
of vote by party NA; seats — (76 total) Liberal-
National 36. Labor 30. Australian Democrats
7. Greens 2, independents 1
House of Representatives; elections last held
13 March 1993 (next to be held by NA 1996);
results- -percent of vote by party NA; seats —
( 147 total) Labor 80, Liberal-National 65,
independent 2
Judicial branch: High Court
Political parties and leaders:
government: Australian Labor Party, Paul John
KEATING
opposition; Liberal Party, John HEWSON;
National Party, Timothy FISCHER; Australian
Democratic Party. Cheryl KERNOT; Green
Party, leader NA
Other political or pressure groups;
Australian Democratic Labor Party (anti¬
communist Labor Party splinter group); Peace
and Nuclear Disarmament Action (Nuclear
Disarmament Party splinter group)
Member of: AfDB, AG (observer). ANZUS,
APEC, AsDB, Australia Group, BIS, C, CCC,
COCOM, CP. EBRD. ESCAP, FAO. GATT.
G-8. IAEA. IBRD, ICAO. ICC. ICFTU. IDA.
lEA. IFAD. IFC. ILO. IMF. IMO.
INMARSAT, INTELSAT, INTERPOL, IOC,
lOM, ISO. ITU. LORCS. MINURSO, MTCR,
24
NAM (guest), NEA. NSG. OECD. PCA.
SPARTECA, SPC, SPF, UN, UNCTAD,
UNESCO, UNFICYP, UNHCR. UNIDO.
UNOSOM. UNPROFOR. UNTAC, UNTSO,
UPU, WFTU, WHO WIPO, WMO, ZC
Diplomatic representation in US:
chief of mission; Ambassador Donald
RUSSELL
clumceri-; 1601 Massachusetts Avenue NW,
Washington, DC 20036
telephone; (202) 797-3000
FAX; (202) 797-3168
consulateisi jteneral; Chicago. Honolulu.
Houston. Los Angeles, New York. Pago Pago
(American Samoa), and San Francisco
US diplomatic representation:
chief of mission; Ambassador Edward
PERKINS
embassy; Moonah Place, Yarralumla.
Canberra. Australian Capital Territory 2600
mailing address; APO AP 96549
telephone; (611(6) 270-5000
FAX.- [6 11(6) 270-5970
consulatefs) general; Melbourne, Penh, and
Sydney
consulateisi; Brisbane
Flag: blue with the flag of the UK in the upper
hoist-side quadrant and a large seven-pointed
star in the lower hoist-side quadrant; the
remaining half is a representation of the
Southern Cross constellation in white with one
small five-pointed star and four, larger, seven-
pointed stars
Independence: none (territory of Australia)
Flag: the flag of Australia is used
Independence; none (territory of Australia)
Names:
conventional long form: The Holy See (State
of the Vatican City)
conventional short form: Holy See (Vatican
City)
local long form: Santa Sede (Stato della Citta
del Vaticano)
local short form: Santa Sede (Citta del
Vaticano)
Digraph: VT
Type: monarchical-sacerdotal state
Capital: Vatican City
Independence: 1 1 February 1929 (from Italy)
National holiday: Installation Day of the
Pope, 22 October (1978) (John Paul II)
note: Pope John Paul II was elected on 16
October 1978
Constitution: Apostolic Constitution of 1967
(effective 1 March 1968)
Legal system: NA
Suffrage; limited to cardinals less than 80
years old
Executive branch;
chief of slate: Pope JOHN PAUL II (Karol
WOJTYLA: since 16 October 1978); election
ia.st held 16 October 1978 (next to be held after
the death of the current pope); results — Karol
WOJTYLA was elected for life by the College
of Cardinals
head of government: Secretary of State
Archbishop Angelo Cardinal SODANO (since
NA 1991)
cabinet: Pontifical Commission; appointed by
Pope
Legislative branch: unicameral Pontifical
Commission
Judicial branch: none; normally handled by
head of government: Assembly President
David Ernest BUFFETT (since NA May 1992)
cabinet: Executive Council
Legislative branch: unicameral
Legislative As.sembly: elections last held 1989
(held every three years); results— percent of
vote by party NA; seats — (9 total) percent of
seats by party NA
Judicial branch: Supreme Court
Political parties and leaders: NA
Member of: none
Diplomatic representation in US: none
(territory of Australia)
US diplomatic representation: none
(territory of Australia)
Flag: three vertical bands of green (hoist
side), white, and green with a large green
Norfolk Island pine tree centered in the slightly
wider white band','2cbf860a7d17f1f877ef752b674d641a994eef47d185579444d7950d667e5bd8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61af8d2c454689b780304aca70edbab7c5b022aea6e39c67bd8e7f2f87c036cc',1994,'AT','Austria','government',85,'Names:
conventional loiiftfonn: Republic of Austria
conventional short form: Austria
hx al loitfi form: Republik Ocstcrreich
lix''ul short form: Oestcrreich
Digraph: AU
Type: federal republic
Capital: Vienna
Administrative divisions: 9 states
(bundeslander, singuhu- — bundesland);
Burgenland. Kamten. Niederoesterreich.
Oberoesterreich, Salzburg. Steiermark. Tirol.
Vorarlberg. Wien
Independence; 1 2 November 1 9 1 8 ( from
Austro-Hungarian Empire)
National holiday: National Day. 26 October
(1955)
Constitution; 1920; revised 1929 (reinstated
1 May 1945)
Legal system: civil law system with Roman
law origin; judicial review of legislative acts by
a Constitutional Court; separate administrative
and civil/penal supreme courts; has not
accepted compulsory ICJ jurisdiction
Suffrage: 19 years of age. universal:
compulsory for presidential elections
Executive branch:
chief of state: President Thomas KLESTIL
(since 8 July 1992); election last held 24 May
1992 (next to be held 1996); results of second
ballot— Thomas KLESTIL 57%. Rudolf
STREICHER 43%
head of itovemment: Chancellor Franz
VRANITZKY (since 16 June 1986); Vice
Chancellor Erhard BUSEK (since 2 July 1991 )
cabinet: Council of Ministers; chosen by the
president on the advice of the chancellor
Legislative branch: bicameral Federal
Assembly (Bundesversammlung)
Federal Council iSiindesrat): consists of 63
members representing each of the provinces on
the basis of population, but with each province
having at least 3 representatives
National Council I National rat): elections last
held 7 October 199() (next to be held October
1994); results— SPOE 43%. OEVP .32.1%.
FPOE 16.6%. CAL 4.5% . KPOE 0.7%. other
3. 1 %: seats— ( 1 83 total) SPOE 80. OEVP 60.
FPOE 3.3. GAl. 10
Judicial branch: Supreme Judicial Court
(Oberster Gerichtshof) for civil and criminal
cases. Administrative Court
(VerwaltungsgerichtshoO for bureaucratic
cases. Constitutional Court
( Verlassungsgerichtshof) for constitutional
cases
Political parties and leaders: Social
DemiK-ratic Party of Austria (SPOE). Franz
VRANITZKY, chainnan; Aus)ri;in People''s
Party (OEVP), Erhard BUSEK. chainnan:
Freedotn Party of Austria (FPOE). Joerg
HAIDER, chainnan; Communist Party
(KPOE). Walter SILBERMAYER. chairman;
Green Alternative List (GAL), Peter PILZ.
chairman; Liberal Fomm (LF). Heidi
SCHMIDT
Other political or pres.sure groups; Federal
Chamber of Commerce and Industry; Austrian
Trade Union Federation (primarily Siwialist);
three comprrsite leagues of the Austrian
People''s Party (OEVP) representing business,
labor, and farmers; OEVP-oriented League of
Austrian Industrialists; Roman Catholic
Church, including its chief lay organization.
Catholic Action
Member of: AIDB, AG (observer), AsDB,
Australia Group. BIS. CCC. CE, CEl, CERN.
COCOM (cixvperating). CSCE. EBRD. ECE,
26
EFTA. ESA, FAO. G-9, GATT, lADB, IAEA,
IBRD, ICAO, ICC, ICFTU, IDA, lEA, IFAD,
IFC, ILO, IMF. IMO. INTELSAT.
INTERPOL. IOC, lOM, (SO. ITU, l.ORCS.
MINURSO, MTCR. NAM (guest). NBA.
NSG, OAS (oKserver), OECD, ONUSAL,
PCA, UN, UNCTAD, UNESCO, UNDOF,
UNFICYP, UNHCR. UNIDO. UNIKOM,
UNOMIG. UNTAC. UNTSO, UPU, WCL.
WFTU. WHO, WIPO. WMO, WTO. ZC
Diplomatic representation in US:
chief of mission: Ambassador Helmut TUERK
chancen-: .1524 International Court NW,
Washington. DC 2()0()8-3035
telephone; (202) 895-67{X)
FAX; (202) 895-6750
consulate(s) geneivl; Chicago, Los Angeles,
and New York
US diplomatic representation:
chief of mission; Ambas.sador Swanee G.
HUNT
chancery: Bolt/.manngasse 16, A- 1091,
Vienna
mailing athlress; Unit 27937, Vienna
/W<v>/k)/m''.I431(I)31-3-,39
MX; 1431(1)513-4.3-51
consiilate(s) general; Salzburg
Flag: three equal horizontal bands of red
(top), white, and red','7214674f5adb5c7d908376a342ee52c6bdc5d326749a7c4ab509932af95fc87b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1dcebe10a0b04a0259ce48c87f5a3176a8c7beb7d8e08e32f1d79ea5400a5e6d',1994,'AZ','Azerbaijan','government',91,'Names:
conventional long form; Azerbaijani Republic
conventional short form; Azerbaijan
l(Kal long form; Azarbaycan Respublikasi
local short form; none
former; Azerbaijan Soviet Socialist Republic
Digraph: AJ
Type: republic
Capital: Baku(Baky)
Administrative divisions: I autonomous
republic (avtomnaya respublika); Nakhichevan
(administrative center at Nakhichevan)
note; all rayons except for the exclave of
Nakhichevan are under direct republic
jurisdiction
Independence: .30 August 1991 (from Soviet
Union)
National holiday: Novruz Bayram, 21-22
March
Constitution; adopted NA April 1978;
writing a new constitution mid- 1993
Legal system: based on civil law system
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state; President Heydar ALIYEV
(since 18 June 1993 after President ELCIBEY
lef) Baku for Nakhichevan): election last held 3
October 1993 (next to be held NA): results-—
Heydar ALIYEV won 97% of vote
head of government; Prime Minister Surat
HUSEYNOV (since .30 June 1993)
cabinet; Council of Ministers: appointed by
the president and confirmed by the Mejias
Legislative branch; unicameral
National Assembly (Milli Mejlis); elections
last held .30 September and 14 C)ctober 1990
for the Supreme Soviet (next expected to be
held NA 1994 for the National Assembly);
seats for Supreme Soviet — (360 total)
Communists 280. Democratic Bloc 45
(grouping of opposition parties), other 15,
vacant 20; note — on 19 May 1992 the Supreme
Soviet was prorogued in favor of a Popular
Front-dominated National Council; seats — (50
total) Popular Front 25, opposition elements 25
Judicial branch; Supreme Court
Political parties and leaders: Azerbaijan
Popular Front (APF). Ebulfez ELCIBEY,
chairman; Musavat Party. Isa GAMBAR.
chairman: National Independence Party. Etibar
MAMEDOV, chairman: Social Democratic
Party (SDP), Araz ALIZADE, chairman:
Communist Party. Ramiz AKHMEDOV,
chairman: People''s Freedom Party, Yunus
OGUZ. chairman; Independent Social
Democratic Party, Arif YUNUSOV and Leila
YUNOSOVA. cochairmen; New Azerbaijan
Party. Heydar ALIYEV, chairman: Boz Gurd
Party. Iskander HAMIDOV, chairman:
Azerbaijan Democratic Party. Sardar
MAMEDOV, chairman: Azerbaijan
Democratic Independence Party, Qabil
HUSELNLI. chairman: Islamic Party of
28
Azerbaijan, All Akram. chairman
Other political or premurc groups: self-
proclaimed Armenian Nagorno-Karabakh
Republic; Talysh independence movement
Member of; BSEC.CCC, CIS, CSCE,
EBRD, ECE, ECO, ESCAP, IBRD. ICAO.
IDB. ILO. IMF, INTELSAT. INTERPOL.
IOC, ITU, NACC, OIC. UN, UNCTAD,
UNESCO, UPU, WHO
Diplomatic representation in US:
chief of mission: Ambassador Hafiz Mir Jalal
Ogly PASHAYEV
chancery: Suite 700, 927 1 5th Street NW,
Washington, DC 20005
telephone: (202) 842-0001
FAX. (202) 842-0004
US diplomatic representation;
chief of mission: Ambassador Richard
KAZLAURICH
emhassy; Hotel Intourist, Baku
mailing address: use embassy street address
telephone: 7-8922-92-63-06 through 09,
extension 44 1 , 442, 446, 447, 448. 450
FAX: Telex 1421 10 AMEMB SU
Flag: three equal horizontal bands of blue
(top), red. and green; a crescent and eight-
pointed star in white are centered in red band
Names:
conventional long form: Commonwealth of
The Bahamas
conventional short form: The Bahamas
Digraph: BF
Type; commonwealth
Capital; Nassau
Administrative divisions: 21 districts;
Acklins and Crooked Islands, Bimini, Cat
Island, Exuma, Freeport, Fresh Creek,
Governor’s Harbour, Green Turtle Cay,
Harbour Island, High Rock, Inagua, Kemps
Bay, Long Island. Marsh Harbour, Mayaguana,
New Providence, Nichollstown and Berry
Islands, Ragged Island, Rock Sound, Sandy
Point, San Salvador and Rum Cay
Independence: 10 July 1973 (from UK)
National holiday: National Day, 10 July
(1973)
Constitution: 10 July 1973
Legal system: based on English common law
Suffrage: 1 8 years of age; universal
Execitive branch;
chief of state: Queen ELIZABETH II (since 6
February 1952), represented by Governor
General Sir Cliffoid DARLING (since 2
January 1992)
head of government: Prime Minister Hubert A.
INGRAHAM (since 19 August 1992); Deputy
Prime Minister Orville A. TURNQUEST
(since 19 August 1992)
cabinet: Cabi net; appointed by the go vemor on
the prime minister’s recommendation
Legislative branch: bicameral Parliament
Senate: a 16-member body appointed by the
governor general
House of Assembly: elections last held 19
August 1992 (next to be held by August 1997);
results — percent of vote by party NA; seats —
(49 total) FNM 32,PLP17
Judicial branch: Supreme Court
Political parties and leaders: Progressive
Liberal Party (PLP), Sir Lynden O.
PINDLING; Free National Movement (FNM),
Hubert Alexander INGRAHAM;
Member of: ACP, C, CCC, CARICOM,
CDB, ECLAC, FAO. G-77, lADB, IBRD,
ICAO, ICFTU. IFC. ILO, IMF. IMO.
INTELSAT, INTERPOL. IOC, ITU. LORCS,
MAM, OAS. OPANAL, UN, UNCTAD,
UNESCO, UNIDO, UPU, WHO, WIPO,
WMO
Diplomatic representation in US:
chief of mission: Ambassador Timothy
Baswell DONALDSON
chancery: 2220 Massachusetts Avenue NW,
Washington, DC 20008
telephone: (202) 319-2660
MAX- (202) 319-2668
consulate(s) general: Miami and New York
US diplomatic representation:
chief of mission: (vacant); Charge d’ Affaires
Lino GUTIERREZ
embassy: Mosmar Building, Queen Street,
Nassau
mailing address: P. O. Box N-8197, Nassau
telephone: (809) 322-1181 or 328-2206
FAX: (809) 328-7838
Flag: three equal horizontal bands of
aquamarine (top), gold, and aquamarine with a
black equilateral triangle based on the hoist
side','0874d8534cb929ccb52d22a8212418ebe6bdfc925e9a7e05f3e533b3e668e205','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('be4c34d08ed879d08dd88416d428488c2a74931098571d4747311457329dfef0',1994,'BH','Bahrain','government',98,'Names:
conventional long form: State of Bahrain
conventional short form: Bahrain
local long form: Dawlat al Bahrayn
local short form: Al Bahrayn
Digraph: BA
Type: traditional monarchy
Capital: Manama
A dministrati ve divisions: 1 2 districts
(manatiq. singular — mintaqah); Al Hadd. Al
Manamah, Al Mintaqah al Gharbiyah. Al
Mintaqah al Wu.sta. Al Mintaqah ash
Shamaliyah, Al Muharraq, Ar Rifa''wa al
Mintaqah al Janubiyah, Jidd Hafs, Madinal
Hamad, Madinat ''Isa, Mintaqat Juzur Hawar.
Sitrah
Independence: 15 August 1971 (from UK)
National holiday: Independence Day. 16
December (1961)
Constitution: 26 May 1973, effective 6
December 1973
Legal system: based on Islamic law and
English common law
Suffrage: none
Executive branch:
chief of state: Amir ISA bin Salman Al Khalifa
(since 2 November 1961); Heir Apparent
HAMAD bin I.sa bin Salman Al Khalifa (son of
Amir; bom 28 January 1950)
head of government: Prime Minister
KHALIFA bin Salman Al Khalifa (since 19
January 1970)
cabinet: Cabinet
Legislative branch: unicameral National
Assembly was dissolved 26 August 1975 and
legislative powers were assumed by the
Cabinet; appointed Advisory Council
established 16 December 1992
Judicial branch: High Civil Appeals Court
Political parties and leaders: political
parties prohibited; several small, clandestine
leftist and Islamic fundamentalist groups are
active
Member of: ABEDA, AFESD, AL, AMF,
ESCWA. FAO, G-77. GATT, GCC. IBRD,
ICAO, IDB. ILO, IMF. IMG. INMARSAT.
INTELSAT (nonsignatory user), INTERPOL.
KXT. ISO (correspondent), ITU. LORCS,
NAM, OAPEC, OIC. UN. UNCTAD.
UNESCO. UNIDO, UPU. WFTU, WHO.
WMO
Diplomatic representation in US:
chief of mission: Ambassador Mohammad
ABDal-GHAFFAR
chancery: 3502 International Drive NW.
Washington. DC 20008
telephone: (202) 342-0741 or 342-074.''>
consulate! s) general: New York
US diplomatic representation;
chief of mission: (vacant): Charge d'' Affaires
David S. ROBINS
embassy: Road No. 3 1 19 (next to Alahli Sports
Club). Zinj District, Manama
mailing address: FPO AE 09834-5100; P.O.
Box 26431, Manama
telephone: (973] 273-300
FAX: (973) 272-594
Flag: red with a white serrated band (eight
white points) on the hoist side
Names:
conventional long form: none
convei. ''ional short form: Baker Island
Digraph: FQ
Type: unincorporated territory of the US
administered by the Fish and Wildlife Service
of the US Department of the Interior as part of
the National Wildlife Refuge system
Capital: none; administered from
Washington, DC','da09fdc1e71737f200dba521e79f1cb0ab9bf92b48c838501c2723a1f64239fc','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88d6d59616e06acc4331236b71022f9425c66708c5c17dc52f85a5b053d6462c',1994,'BD','Bangladesh','government',102,'Names:
conventional long form: People''s Republic of
conventional short form: Bangladesh
former: East Pakistan
Digraph: BG
Type: republic
Capital: Dhaka
Administrative divisions: 64 districts
(zillagulo, singular- -zilla); Bagcrhat,
Bandarbun. Barguna, Barisal, Bhola, Bogra,
Brahmanbaria, Chandpur, Chapai Nawabgunj,
Chattagrain, Chuadanga, Comilla, Cox''s
Bazar, Dhaka. Dinajpur. Faridpur, Feni.
Gaibandha, Gazipur, Gopalganj, Habiganj,
Jaipurhat, Jamalpur, Jessore, Jhalakati,
Jhenaidah, Khagrachari, Khulna, Kishorganj,
Kurigram, Kushtia, Laksmipur, Lalmonirhat,
Madaripur, Magura, Manikganj, Meherpur,
Moulavibazar. Munshiganj, Mymensingh,
Naogaon, Narail, Narayanganj, Narsingdi,
Nator, Netrakona, Nilphamari, Noakhali,
Pabna, Panchagar, Parbattya Chattagram,
Patuakhali, Pirojpur, Rajbari, Rajshahi,
Rangpur, Satkhira, Shariyatpur. Sherpur,
Sirajganj, Sunamganj, Sylhet, Tangail,
Thakurgaon
Independence; 16 December 1971 (from
Pakistan)
National holiday: Indepiendence Day, 26
March (1971)
Constitution: 4 November 1972, effective 16
December 1972, suspended following coup of
24 March 1982, restored 10 November 1986,
amended many times
Legal system: ba.sed on English common law
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: President Abdur Rahman
BISWAS (since 8 October 1991); election la.st
held 8 October 1991 (next to be held by NA
October 1996); resull.s — Abdur Rahman
BISWAS received 52. 1 % of parliamentary
vote
head of government: Prime Minister Khaleda
ZIAur RAHMAN (since 20 March 1991)
cabinet: Council of Ministers; appointed by
the president
Legislative branch: unicameral
National Parliament (Jatiya Sangsad):
elections lust held 27 February 1 99 1 (next to be
held NA February 1996); results — percent of
vote by party NA; seats — (330 total, 300
elected and .30 seats reserved for women) BNP
168, AL 93, JP 35. JI 20, BCP 5. National
Awami Party (Muzaffar) 1, Workers Party 1,
JSD l.Ganotantri Party l.lslami OikyaJote I,
NDP 1 . independents 3
Judicial branch: Supreme Coun
Political parties and leaders: Bangladesh
Nationalist Party (BNP), Khaleda ZIAur
RAHMAN; Awami League (AL), Sheikh
Hasina WAJED; Jatiyo Party (JP), Hussain
Mohammad ERSHAD (in jail); Jamaat-E-
Islumi (JI), Ali KHAN; Bangladesh
Communist Party (BCP), Saifuddin Ahmed
MANIK; National Awami Party (Muzaffar);
Workers Party, leader NA; Jatiyo Samajtantik
Dal (JSD). Serajul ALAM KHAN; Ganotantri
Party, leader NA; Islami Oikya Jote, leader
NA; National Democratic Party (NDP), leader
NA; Muslim League, Khan A. SABUR;
Democratic League. Khondakar
MUSHTAQUE Ahmed; Democratic League.
Khondakar MUSHTAQUE Ahmed; United
People''s Party, Kazi ZAFAR Ahmed
Member of: AsDB. C, CCC. CP. ESCAP,
FAO, G-77. GATT. IAEA, IBRD, ICAO,
ICFTU, IDA. IDB, IFAD. IFC. ILO. IMF.
34
IMO, INTELSAT, INTERPOL, IOC, lOM,
ISO, ITU, LORCS, MINURSO, NAM, OIC,
SAARC, UN, UNCTAD, UNESCO, UNIDO,
UNIKOM, UNOMIG, UNOMOZ, UNOMUR,
UNOSOM, UNPROFOR, UNTAC, UPU,
WCL, WHO, WFTU, WIPO, WMO, WTO
Diplomatic representation in US:
chief of mission: Ambassador Abul AHSAN
chancery: 2201 Wisconsin Avenue NW,
Washington, DC 20007
telephone: (202) 342-8372 through 8376
consulate(s) general: New York
US diplomatic representation:
chief of mission: Ambassador David
MERRILL
embassy: Diplomatic Enclave, Madani
Avenue, Baridhara, Dhaka
mailing address: G. P. O. Box 323, Dhaka
1212
telephone: [880] (2) 884700-22
FAX: [880] (2) 883-744
Flag: green with a large red disk slightly to the
hoist side of center: green is the traditional
color of Islam','7f069c4b437dc92be9feb44c525f6f414ca1c81ee6abf325afd3d9d5acbfbb5b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('257a5b30fe60c96cf79d76b28f9f14c33f6544fe911cf047fdce2d9bb5cd4379',1994,'BB','Barbados','government',108,'Names:
conventional long form: none
conventional short form: Barbados
Digraph: BB
Type: parliamentary democracy
Capital: Bridgetown
Administrative divisions: 1 1 parishes: Christ
Church, Saint Andrew. Saint George. Saint
James, Saint John, Saint Joseph. Saint Lucy.
Saint Michael. Saint Peter. Saint Philip, Saint
Thomas
note: the new city of Bridgetown may be given
parish status
Independence: 30Noveiiiber 1966 (from
UK)
National holiday: Independence Day. 30
November (1966)
Constitution: .30 November 1966
Legal system: English common law: no
judicial review of legislative acts
Suffrage: 1 8 years of age: universal
Executive branch:
chief of state: Queen ELIZABETH II (since 6
February 1952), represented by Governor
General Dame Nita BARROW (since 6 June
1990)
head of government: Prime Minister Lloyd
Erskine SANDIFORD (since 2 June 1987):
Deputy Prime Minister Philip Marlowe
GREAVES (sinee 2 June 1987)
cabinet; Cabinet: appointed by the governor
general on advice of the prime minister
Legislative branch: bicameral Parliament
Senate; consists of a 21-member body
appointed by the governor general
House of Assembly: elections last held 22
January 1991 (next to be held by January
1996): results — DLP 49.8%: seat.s — (28 total)
DLF 18. BLP 10
Judicial branch: Supreme Court of
Judicature
Political parlies and leaders: Democratic
Labor Party (DLP), Erskine SANDIFORD:
Barbados Labiir Party (BLP). Owen
ARTHUR; National Democratic Party (NDP),
Richie HAYNES
Other political or pressure groups:
Barbados Wiirkers Union, Leroy TROTMAN;
People''s Progressive Movement, Eric SEALY:
Workers'' Party of Barbados. Dr. George
BELLE: Clement Payne Labor Union. David
COMMISSIONG
Member of; ACP. C. CARICOM. CDB.
ECLAC. FAO. G-77. GATT. lADB. IBRD,
ICAO, ICFTU. IFAD. IFC. ILO, IMF. IMO,
INTELSAT. INTERPOL, lOC. ISO
(correspondent). ITU. LAES, LORCS. NAM,
OAS. OPANAL. UN. UNCTAD. UNESCO.
UNIDO. UPU. WHO. WIPO. WMO
Diplomatic representation in US:
chief of mission: Ambassador Dr. Rudi
Valentine WEBSTER
chancery: 2144 Wyoming Avenue NW,
Washington, DC 20008
telephone: (202) 939-9200 through 9202
consulate(s) general; New York
consulate(s): Los Angeles
US diplomatic representation:
chief of mission: Ambassador Jeanette W.
HYDE
embassy: Canadian Imperial Bank of
Commerce Building, Broad Street. Bridgetown
mailing address: P. O. Box 302. Bridgetown;
FPO AA 34055
telephone: (809) 436-4950
FAX: (809) 429-5246
Flag: three equal vertical bands of blue (hoist
side), yellow, and blue with the head of a black
trident centered on the gold band; the trident
head represents independence and a break with
the past (the colonial coat of arms contained a
complete trident)','a333df42a20fbe6657f7705f11c84a3b79f6b0b1e636adbbbfebc924311de7da','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8cef0a722d8d2eb9243b32872faba1f2a039b2f04b46a84bb9e29d53c9de8a75',1994,'MG','Madagascar','government',113,'Names:
conventional long form: none
37
Bassas da India (continued)
Names:
conventional long form: none
conventional short form; Europa Island
local long form; none
local short form: lie Europa
Digraph: EU
Names:
conventional long form: none
conventional short form: Clorioso Islands
local long form: none
local short fonn: lies Glorieuses
Digraph: GO
Type: French possession administered by
Commissioner of the Republic, resident in
Reunion
Capital: none: administered by France from
Reunion
Independence: none (possession of France)
Names:
conventional long form: Hellenic Republic
conventional short form: Greece
local long form: Elliniki Dhiniokratia
local short form: Ellas
former: Kingdom of Greece
Digraph: GR
Type: presidential parliamentary government:
monarchy rejected by referendum 8 December
1974
Capital: Athens
Administrative divisions: 52 prefectures
(nomoi. singular — nomos); Aitolia kai
Akarnania. Akhaia, Argolis, Arkadhia. Arta.
Attiki. Dhodhekanisos, Dhrama, Evritania,
Evros, Evvoia, Fiorina, Fokis, Fthiotis,
Grevena, Ilia, Imathia, loannina, Iraklion.
Kardhitsa, Kastoria, Kavala, Kefallinia,
Kerkira, Khalkidhiki, Khania. Khios,
Kikladhes, Kilkis, Korinthia, Kozani, Lakonia,
Larisa, Lasithi, Lesvos, Levkas, Magnisia,
Messinia. Pella, Pieria, Piraievs. Preveza,
Rethimni, Rodhopi. Samos. Seirai, Thesprotia,
Thessaloniki, Trikala, Voiotia. Xanthi.
21akinthos, autonomous region: Agion Oros
(Mt. Athos)
Independence: 1829 (from the Ottoman
Empire)
National holiday: Independence Day. 25
March (1821) (proclamation of the war of
independence)
Constitution: 1 1 June 1975
Legal system; based on codified Roman law;
Judiciary divided into civil, criminal, and
administrative courts
Suffrage: 1 8 years of age: universal and
compulsory
Executive branch;
chief of state: President Konslantinos
KARAMANLIS (since 5 May 1990); election
last held 4 May 1990 (next to be held May
1995); result.s — Konstantinos KARAMANLIS
was elected by Parliament
head of government: Prime Minister Andreas
PAPANDREOU (since 10 October 1993)
cabinet: Cabinet; appointed by the president
on recommendation of the prime minister
Legislative branch: unicameral
Chamber of Deputies (Vottii ton Ellitum):
elections last held 10 October 1993 (next to be
held by NA October 1997); results — PASOK
46.88%. ND 39.30%. Political Spring 4.87%.
KKE 4.54%, and Progressive Left Coalition
2.94%; seals— (300 total) PASOK 170. ND
111. Political Spring 10, KKE 9
Judicial branch: Supreme Judicial Court.
Special Supreme Tribunal
Political parties and leaders: New
Democracy (ND; conservative), Milliades
EVERT; Panhelleiiic Socialist Movement
(PASOK). Andreas PAPANDREOU;
Progressive Left Coalition. Maria
DAMANAKl: Democratic Renewal
(DIANA), Konstantinos STEFANOPOULOS;
Communist Party (KKE). Aleka PAPARIGA;
Ecologist-Alternative List, leader rotates:
Political Spring. Antonis SAMARAS
Member of: Australian Group. BIS. BSEC,
CCC. CE. CERN. COCOM. CSCE. EBRD.
EC, ECE, EIB. FAO. G-6. GATT, IAEA,
IBRD. ICAO. ICC. ICFTU. IDA. lEA. IFAD.
IFC. ILO. IMF, IMO. INMARSAT.
INTELSAT. INTERPOL. IOC. lOM. ISO.
ITU. LORCS. MINURSO. MTCR. NACC.
NAM (guest), NATO. NEA. NSO. OAS
(observer), OECD. PCA. UN. UNCTAD.
UNESCO. UNHCR, UNIDO. UNIKOM.
UNOMIG, UNO.SOM. UPU. WEU
(associate), WFTU. WHO. WIPO, WMO,
WTO. ZC
Diplomatic representation in US;
chief of mission: Ambassador Loucas TSILAS
chancery: 222 1 Massachusetts Avenue NW,
Washington, DC 20008
telephone: (202) 939-58(X)
FAX: (202) 939-5824
constdatelsj general: Atlanta, Boston,
Chicago, Houston, Los Angeles, New York,
and San Francisco
consulate! s): New Orleans
US diplomatic representation:
chief of mission: Ambassador Thomas ’ i.T.
NILES
embassy: 91 Vasilissis Sophias Boulevard,
10160 Athens
mailing address: PSC 108, Athens; APO AE
09842
telephone: [30] (1) 721-2951 or 721-8401
FAX: [.301(1)64.5-6282
consulate(s) general: Thessaloniki
Flag: nine equal horizontal stripes of blue
alternating with white; there is a blue square in
the upper hoist-side comer bearing a white
cross: the cross symbolizes Greek Orthodoxy,
the established religion of the country
Names:
conventional long form: none
conventional short form: Juan de Nova Island
local long form: none
local short form; lie Juan de Nova
Digraph: JU
Type: French possession administered by
Commissioner of the Republic, resident in
Reunion
Capital: none; administered by France from
Reunion
Independence: none (possession of France)
Names:
conventional long form: Republic of
Names:
conventional long form: Republic of
conventional short form: Madagascar
local long form: Republique de Madagascar
local short form: Madagascar
former: Malagasy Republic
Digraph: MA
Type: republic
Capital: Antanavarivo
Administrative divisions: 6 provincc.s —
Antananarivo, Antsiranana. Fianaruntsoa.
Mahajanga, Toamasina. Toliary
Independence: 26 June I960(fn)m France)
National holiday: Independence Day, 26
June (1960)
Constitution: 1 9 August 1 992 by national
referendum
Legal system: based on French civil law
system and traditional Malagasy law; has not
accepted compulsory ICJ jurisdiction
Suffrage; 1 8 years of age; universal
Executive branch:
chief of state: President Albert ZAFY (since 9
March 1993); election last held on lOFebmary
1993 (next to be held 1998); results — Albert
ZAFY (UNDO), 67%; Didier RATSIRAKA
(AREMA), 33%
head of government: Prime Minister
Francisque RAVONY (since 9 August 1993)
cabinet: Council of Ministers; appointed by
the prime minister
Legislative branch: bicameral Parliament
Senate: (Senat) two-thirds of upper hou.se seats
are to be filled by an electoral college made up
of representatives of territorial collectivities;
the remaining third is to be filled by
presidential appointment, following
nomination by economic, social, and cultural
groups; the selection of senators was scheduled
for March 1994
National Assembly: (Assemblee Nationale)
elections last held on 16 June 1993 (next to be
held June 1997); results — percent of vote by
party NA; seats — ( 1 38 total) CFV coalition 76,
PMDM/MFM 16. CSCD 1 1, Famima 10,
RPSD 7. various pro-Ralsiraka groups 1 0.
others 8
note: the National Assembly has suspended its
operations during 1992 and early 1993 in
preparation for new legislative elections. In its
place, an interim High Authority of State and a
Social and Economic Recovery Council have
been established
Judicial branch: Supreme Court (Cour
Supreme), High Constitutional Court (Haute
Cour Constitutionnelle)
Political parties and leaders; Committee of
Living Forces (CFV ), an alliance of National
Union for Development and Democracy
(UNDO), Support Group for Democracy and
Development in Madagascar (CSDDM),
Action and Reflection Group for the
Development of Madagascar (Grad). Congress
Party for Madagascar Independence —
Renewal (AKFM-Fanavaozana), and some 12
other anti-Ratsiruka oppositon parties, trade
unions, and religious groups; leader Dr. Albert
ZAFY; Militant Party for the Development of
Madagascar (PMDM/MFM: formerly the
Movement for Proletarian Power), Manandafy
RAKOTONIRINA: Confederation of Civial
Societies for Development (CSCD). Guy Willy
RAZANAMASY; Association of United
Malagasys (Famima); Rally for Social
Democracy (RPSD), Pierre TSIRANANA
Other political or pressure groups;
National Council of Christian Churches
(FFKM); Federalist Movement
Member of: ACCT, ACP, AtDB, CCC, ECA,
FAQ. G-77. GATT. IAEA, IBRD, ICAO, ICC.
ICFTU, IDA. IFAD. IFC. ILO, IMF, IMO,
241
Madagascar (continued}
INTELSAT, INTERPOL, IOC, ISO
(correspondent), ITU, LORCS, NAM, OAU,
UN, UNCTAD, UNESCO, UNHCR, UNIDO,
UPU, WCL, WFTU, WHO, WlPO, WMO,
WTO
Diplomatic representation in US:
chief of mission: Ambassador Pierrot Jocelyn
RAJAONARIVELO
chancen: 2374 Massachusetts Avenue NW,
Washington, DC 2(X)08
telephone: (202) 265-5525 or 5526
consulate(s) general: New York
US diplomatic representation:
chief of mission: Ambassador Dennis P.
BARRETT
embassy: 14-16 Rue Rainitovo, Antsahavola,
Antananarivo
mailing address: B. P. 620, Antananarivo
telephone: |261] (2) 212-57, 200-89, 207-18
FAX: 261-234-539
Flag: two equal horizontal bands of red (top)
and green with a vertical white band of the
same width on hoist side
Names;
conventional long form: Republic of','a6ddfa4f383b8413297beff8dd86618f4390e8b82c33323598748ac03357353d','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8301b411e52c8ec48d675770d1c52a055859b4748a0e21b45e412182edfd7686',1994,'BY','Belarus','government',114,'conventional short form; Bassas da India
Digraph: BS
Type: French possession administered by a
Commissioner of the Republic, resident in
Reunion
Capital; none; administered by France from
Reunion
Independence: none (possession of France)
Names:
conventional long form; Republic of Belarus
conventional short form; Belarus
local long form; Respublika Byelarus''
local short form; none
former; Belorussian (Byelorussian) Soviet
Socialist Republic
Digraph; BO
Type: republic
Capital: Minsk
Administrative divisions; 6 voblastsi
(singular — voblasts") and one municipality*
(harady, singular — horad); Brestskaya (Brest),
Homyel''skaya (HomyeD, Horad Minsk*,
Hrodzyenskaya (Hrodna), Mahilyowskaya
(Mahilyow), Minskaya, Viisyebskaya
(Vitsyebsk)
note; the administrative centers of the voblastsi
are included in parentheses
Independence: 25 August 1991 (from Soviet
Union)
National holiday: Independence Day. 27 July
(1990)
Constitution: adopted 15 March 1994;
replaces constitution of April 1978
Legal system; based on civil law system
Sulfirage: 18 years of age; universal
Executive branch;
38
chief of slate: Chairman of the Supreme Soviet
Mechislav Ivanovich GRIB (since 28 January
1994)
head of government: Prime Minister
Vyacheslav F. KEBICH (since NA April
1990), First Deputy Prime Minister Mikhail
MYASNIKOVICH (since NA 1991)
cabinet: Council of Ministers
note: first presidential elections scheduled for
23 June 1994
Legislative branch: unicameral
Supreme Soviet: elections last held 4 April
1990 (next to be held NA): results —
Communists 87%; seats — (360 total) number
of seats by party NA; note — 50 seats are for
public bodies; the Communist Party obtained
an overwhelming majority
Judicial branch: Supreme Court
Political parties and leaders: Belarusian
Popular Front (BPF). Zenon PAZNYAK,
chairman; United Democratic Party of Belarus
(UDPB), Aleksandr DOBROVOLSKIY,
chairman; Social Demociatic Party of Belarus
(SDBP), Mikhail TKACHEV, chairman;
Belarus Workers Union, Mikhail SOBOL,
Chairman; Belarus Peasants Party; Party of
People’s Unity, Gennadiy KARPENKO;
Movement for Democracy, Social Progress,
and Justice (DSPS; includes the Communist
Party), Viktor CHIKIN, chairman
Member of: CBSS (observer), CE (guest),
CEI (participating), CIS, CSCE, ECE, IAEA,
IBRD. ICAO. IFC, ILO, IMF. INMARSAT,
INTELSAT (nonsignatory user), KXI, ITU,
NACC, PCA, UN. UNCTAD, UNESCO.
UNIDO. UPU, WHO. WIPO, WMO
Diplomatic representation In US;
chief of mission: Ambassador Sergey
Nikolayevich MARTYNOV
chancery: 1619 New Hampshire Avenue NW,
Washington, DC 20009
telephone: (202) 986- 1 604
FAX; (202) 986- 1805)
US diplomatic representation:
chief of mission: (vacant); Charge d'' Affaires
George KROL
embassy: Starovilenskaya #46, Minsk
mailing address: use embassy street address
telephone: 7-0172-34-65-37
Flag: three horizontal bands of white (top),
red. and white','b546c5fe74f824a48ec7beff41fadec1b69a4749bce2b6ac0de73b67de0ed40f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3b9ce68e74654c43d4cbf5d6d638081acffc55a18d5502cde4e02b13f85ce04',1994,'BZ','Belize','government',125,'Names:
conventional longfonn; none
conventional short fortu; Belize
former: British Honduras
Digraph: BH
Type; parliamentary democracy
Capital: Belmopan
Administrative divisions: 6 districts; Belize,
Cayo. Corozal. Orange Walk, Slann Creek,
Toledo
42
Indepcndcncci 21 September 1981 (from
UK)
National holiday: Independence Day, 21
September (1981)
Constitution: 21 September 1981
Legal system: English law
SufTtage: 1 8 years of age; universal
Executive branch;
chief of state: Queen ELIZABETH II (since 6
February 1952), represented by Governor
General Sir Colville YOUNG (since 17
November 1993)
head o) government: Prime Minister Manuel
ESQUIVEL (since July 1993); Deputy Prime
Minister Dean BARROW (since NA 1993)
cabinet: Cabinet; appointed by the governor
general on advice from the prime minister
Legislative branch: bicameral National
Assembly
Senate: consists of an 8-member body, 5 are
appointed on the advice of the prime minister,
2 on the advice of the leader of the opposition,
and I after consultation with the Belize
Advisory Council
National Assembly: elections last held 30 June
1993 (next to be tield June 1998); results —
percent of vote by party NA; seats — (28 total)
PUP13UDP15
Judicial branch: Supreme Court
Political parties and leaders: People''s
United Party (PUD, George PRICE, Florencio
MARIN, Said MUSA; United Democratic
Party (UDP), Manuel ESQUIVEL, Dean
LINDO, E)ean BARROW; National Alliance
for Belizean Rights, Philip GOLDSON
Other political or pressure groups: Society
for the Promotion of Education and Research
(SPEAR). Assad SHOMAN; United Workers
Front, leader NA
Member of: ACP, C. CARICOM, CDB,
ECLAC. FAO, G-77, GATT. lADB, IBRD,
ICAO, ICFTU. IDA. IFAD, IFC, ILO, IMF,
IMO, INTELSAT (nonsignatory user),
INTERPOL, IOC, lOM (observer), ITU.
LAES. LORCS, NAM, OAS, UN. UNCTAD,
UNESCO. UNIDO. UPU, WCL. WHO, WMO
Diplomatic representation in US;
chief of mission: Ambassador Dean LINDO
chancery: 2.5,35 Massachusetts Avenue NW,
Washington, DC 20008
telephone: (202) 332-%36
FAX: (202) 332-6888
consulate(s) general: Miami
US diplomatic representation:
chief of mission: Ambassador Eugene L.
SCASaA
embassy: Gabourel Lane and Hutson Street,
Belize City
mailing address: P. O. Box 286, Belize City
telephone: 1501) (2) 77161 through 77163
MX.'' (.501 1(2) .30802
nag: blue with a narrow red stripe along the
top an;l the bottom edges; centered is a large
white uisk hearing the coat of arms; the coat of
arms features a shield flanked by two workers
in front of a mahogany tree with the related
motto SUB UMBRA FLOREO (I Flourish in
the Shade) on a scroll at the bottom, all
encircled by a green garland','125429ff9c9840287114f40da01936c20e61f53454f78a9185c0be2c3ef3dcca','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae33e2f3374b6a3b6fe392e27578aaaa6985cd29f8c3bf97e3d367107ef8854a',1994,'TG','Togo','government',132,'Names:
conventional long form: Republic of Benin
conventional short form: Benin
local long fonn: Republique Populaire du','0650fff6c7f6ce7be083ce8dd1e3cb3f9f041db6afdaca291ffee1420faab3e6','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7eb954f4a62ebcc6ed6b7d2a115a1f9bc802bbef4bbe82cd616f74c122cbf840',1994,'BJ','Benin','government',133,'local short form: Benin
former: Dahomey
Digraph: BN
Type: republic under multiparty democratic
rule dropped Marxism-l,eninism December
1989; democratic reforms adopted February
1990; transition to multiparty system
completed 4 April 1991
Capital: Porto-Novo
Administrative divisions: 6 provinces;
Atakora, Atlantique. Borgou. Mono. Oueme.
Zou
Independence: 1 August 1 960 (from France)
National holiday: National Day, I August
(1990)
Constitution; 2 December 1990
Legal system: based on French civil law and
customary law; has not accepted compulsory
ICJ jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state and head of government:
President Nicephore SCXJLO (since 4 April
1991); election last held 10 and 24 March
1991; results — Nicephore SOGLO 68%,
Mathieu KEREKOU 32%
cabinet: Exeeutive Council; appointed by the
president
Legislative branch: unicameral
National Assembly (Assemblee Nationale):
elections last held 10 and 24 March 1991 ;
results — percent of vote by party NA; seats —
(64 total) UDFP-MDPS-ULD 12, PNDD/PRD
9, PSD/UNSP 8, NCC 7, RND 7, MNDD/
MSUPAJDRN 6, CDS 5, RDL 4, ASD/BSD 3,
ADP/UDRS 2, UNDP 1
Judicial branch: Supreme Court (Cour
Supreme)
Political parties and leaders: Alliance of the
Democratic Union for the Forces of Progress
(UDFP), Timothee ADANLIN; Movement for
Democracy and Social Progress (MDPS),
Jean-Roger AHOYO; Union for Liberty and
Development (ULD), Marcellin DEGBE;
Alliance of the National Party for Democracy
and Development (PNDD) and the Democratic
Renewal Party (PRD), Pascal Chabi KAO;
Alliance of the Social Democratic Pany (PSD)
and the National Union for Solidarity and
Progress (UNSP). Bruno AMOUSSOU; Our
Common Cause (NCC). Albert TEVOEDJRE;
National Rally for Democracy (RND), Joseph
KEKE; Alliance of the National Movement for
Democracy and Development (MNDD). leader
NA; Movement for Solidarity. Union, and
Progress (MSUP), Adebo ADENIYI; Union
for Democracy and National Reconstruction
(UDRN), Azaria FAKOREDE; Union for
Democracy and National Solidarity (UDS).
Mama Amadou N’DIAYE; Assembly of
Liberal Democrats for National Reconstruction
(RDL), Severin ADJOVl; Alliance of the
Alliance for Social Democracy (ASD). Robert
DOSSOU; Bloc for Social Democracy (BSD),
Michel MAGNIDE; Alliance of the Alliance
for Democracy and Progress (ADP), Akindes
ADEKPEDIOU; Democratic Union for Social
Renewal (UDRS), Bio Gado Seko N’GOYE;
National Union for Democracy and Progress
(UNDP). Robert TAGNON; Party for Progress
and Democracy, Thiophile NATA; African
Rally for Progress and Solidarity (RAPS).
Florentin MITO-BABA; The Benin
Renaissance Party . Desire VIEYRA and
Rosine SOGLO: The Patriotic Union for the
Republic (UPR), Jean-Marie ZAHOUN;
Union for the Conservation of Democracy,
Bernard HOUEGNON
note: as of May 1994, Benin had about 60
political parties
Member of: ACCT, ACP, AfDB. CEAO,
EGA. ECOWAS, Entente, FAO, FZ, G-77,
GATT, IBRD, ICAO, ICFTU. IDA, IDB,
44
IFAD, IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL, IOC, ITU, LORCS, NAM, OAU,
OIC, UN, UNCTAD, UNESCO, UNIDO,
UPU, WADB, WCL, WFTU, WHO, WIPO,
WMO, WTO
Diplomatic representation in US;
chief of mission: Ambassador Candide
AHOUANSOU
chancery: 2737 Cathedral Avenue NW,
Washington, DC 20008
telephone: (202) 232-6656
FAX: (202) 265-1996
US diplomatic representation:
chief of mission: Ambassador Ruth A. DAVIS
embassy: Rue Caporal Anani Bernard,
Cotonou
mailing address: B. P. 2012, Cotonou
telephone: [229] 30-06-50, 30-05-13, 30-17-
92
FAX: [229J 30-14-39 and 30-19-74
Flag: two equal horizontal bands of yellow
(top) and red with a vertical green band on the
hoist side','0d7ccb5576fc078f42424bd3b076fe26b6b62c85a6ce089d88e3f040b7deec00','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b0387a7682dba4e1b1f7a8eeae507ff9107fe112847d8fce494023f53b49a5a',1994,'BM','Bermuda','government',138,'Names:
conventional long form: none
conventional short form: Bermuda
Digraph: BD
Type: dependent territory of the UK
Capital: Hamilton
Administrative divisions: 9 parishes and 2
municipalities*; Devonshire. Hamilton.
Hamilton*, Paget, Pembroke, Saint George*.
Saint Georges, Sandys, Smiths, Southampton,
Warwick
Independence: none (dependent territory of
the UK)
National holiday: Bermuda Day, 22 May
Constitution: 8 June 1968
Legal system: English law
Suffrage; 2 1 years of age: universal
Executive branch:
chief of state: Queen ELIZABETH 11 (since 6
February 1952), represented by Governor Lord
David WADDINGTON (since 25 August
1992)
head of government: Premier John William
David SWAN (since NA January 1982);
Deputy Premier J. Irving PEARMAN (since 5
October 1993)
cabinet: Cabinet; nominated by the premier,
appointed by the governor
Legislative branch: bicameral Parliament
Senate: consists of an 1 1 -member body
appointed by the governor
House of Assembly: elections last held 5
October 1993 (next to be held by NA October
1998); results — percent of vote by party NA;
seats — (40 total) UBP 22, PLP 18
Judicial branch: Supreme Court
Political parties and leaders: United
Bermuda Party (UBP), John W. D. SWAN;
Progressive Labor Party (PLP), Frederick
WADE; National Liberal Party (NLP), Gilbert
DARRELL
Other political or pressure groups:
Bermuda Industrial Union (BIU), Ottiwell
SIMMONS
Member of: CARICOM (observer), CCC,
ICFTU, INTERPOL (subbureau), IOC
Diplomatic representation in US: none
(dependent territory of the UK)
US diplomatic representation:
chief of mission: (vacant)
consulate general: Crown Hill, 16 Middle
Road, Devonshire, Hamilton
mailing address: P. O. Box HM325, Hamilton
HMBX; PSC 1(X)2, FPO AE 09727-1002
telephone: (809) 295-1342
MX.- (809) 295- 1592
Flag: red with the flag of the UK in the upper
hoist-side quadrant and the Bermudian coat of
arms (white and blue shield with a red lion
holding a scrolled shield showing the sinking
of the ship Sea Venture off Bermuda in 1609)
centered on the outer half of the flag','b10981f64845dc6301a6923fe2f645ec0653ec8d9a88735f67bbaec4396fa087','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('288ffdbbeff036f2f6adea996d38b8ce5d7897a620842967b1e0d040541c808c',1994,'BT','Bhutan','government',145,'Names:
conventional long form; Kingdom of Bhutan
conventional short form: Bhutan
Digraph: BT
Type: monarchy; special treaty relationship
with India
Capital: Thimf''hu
Administrative divisions: 1 8 districts
(dzongkhag, singular and plural); Bumthang.
Chhukha. Chirang. Daga, Geylegphug. H''''.,
Lhuntshi, Mongar, Paro, Pemagatsel. Punakha,
Samchi, Samdrup Jongkhar, Shemgang,
Tushigang. Thimphu. Tongsa. Wangdi
Phodrang
Independence: 8 August 1949 (from India)
National holiday: National Day, 1 7
December (1907) (Ugyen Wangchuck became
first hereditary king)
Constitution: no written constitution or bill of
rights
Legal system: based on Indian law and
English common law; has not accepted
compulsory ICJ jurisdiction
Bhutan (continued)
Suflhige; each family has one vote in village-
level elections
Executive branch:
Chief of Slate and Head of Government: King
Jigme Singye WANGCHUCK (since 24 July
1972)
Royal Advisory Council (Lodoi Tsokde):
nominated by the king
cabinet: Council of Ministers (Lhengye
Shungtsog); appointed by the king
Legislative branch: unicameral National
Assembly (Tshogdu): no national elections
Judicial branch: High Court
Political parties and leaders: no legal
parties
Other political or pressure groups:
Buddhist clergy; Indian merchant community;
ethnic Nepalese organizations leading militant
antigovemment campaign
Member of: AsDB. CP, ESCAP, FAO, G-77,
IBRD, ICAO, IDA. IFAD. IMF. INTELSAT,
IOC, ITU, NAM, SAARC, UN. UNCTAD,
UNESCO. UNIDO, UPU. WHO
Diplomatic representation in US: no
formal diplomatic relations; the Bhutanese
mission to the UN in New York has consular
jurisdiction in the US
consulale(s) general: New York
US diplomatic representation: no formal
diplomatic relations, although informal contact
is maintained between the Bhutanese and US
Embassies in New Delhi (India)
Flag: divided diagonally from the lower hoist
side comer: the upper triangle is orange and the
lower triangle is red; centered along the
dividing line is a large black and white dragon
facing away from the hoist side
Names:
conventional long form: Republic of Bolivia
conventional short form: Bolivia
local long form: Republica de Bolivia
local short form; Bolivia
Digraph: BL
Type: republic
Capital: La Paz (seal of government); Sucre
(legal capital and seat of judiciary)
Administrative divisions; 9 departments
(departamentos, singular — departamento);
Chuquisaca, Cochabamba, Beni, La Paz.
Oruro, Pando, Potosi, Santa Cruz, Tarija
Independence; 6 August 1825 (from Spain)
National holiday: Independence Day, 6
August (1825)
Constitution: 2 February 1967
Legal system: based on Spanish law and
Code Napoleon; has not accepted compulsory
ICJ jurisdiction
Suffrage: 18 years of age, universal and
compulsory (married); 21 years of age,
universal and compulsory (single)
Executive branch:
chief of state and head of government:
President Gonzalo SANCHEZ DE LOZADA
Bustamente (since 6 August 1993); Vice
President Victor Hugo CARDENAS Conde
(since 6 August 1 993); election last held 6 June
1993 (next to be held May 1997); results —
Gonzalo SANCHEZ DE LOZADA (MNR)
34%, Hugo BANZER Suarez (ADN/MIR
alliance) 20%, Carlos PALENQUE Aviles
(CONDEPA) 14%, Max FERNANDEZ Rojas
(DCS) 13%. Antonio ARANIBAR Quiroga
(MBL) 5%; nocandidate received a majority of
the popular vote: Gonzalo SANCHEZ DE
LOZADA won a congressional mnoff election
on 4 Augu.st 1 993 after forming a coalition with
Max FERNANDEZ and Antonio ARANIBAR
cabinet: Cabinet; appointed by the president
from panel proposed by the Senate
Legislative branch: bicameral National
Congress (Congreso Nacional)
Chamber of Deputies ( Camara de Diputados):
elections last held 6 June 1993 (next to be held
May 1997); results - percent of vote by party
NA; seats—! 1 30 total) MNR 52. UCS 20.
ADN 17. MIR 17, CONDEPA 13, MBL 7.
ARBOL l.ASD I.EJE l.PDC 1
Chamber of Senators f Camara de Senadores);
elections last held 6 June 1 993 (next to be held
May 1997): results - percent of vote by party
NA; seats— (27 total) MNR 17, ADN 4, MIR
4, CONDEPA LUCS I
Judicial branch: Supreme Court (Cone
Suprema)
Political parties and leaders; Movement of
the Revolutionary Left (MIR), Jaime PAZ
Zamora: Nationalist Democratic Action
(ADN), Jorge LANDIVAR; Nationalist
Revolutionary Movement (MNR), Gonzalo
SANCHEZ DE LOZADA; Civic Solidarity
Union (UCS), Max FERNANDEZ Rojas;
Conscience of the Fatherland (CONDEPA),
Carlos PALENQUE Aviles; Free Bolivia
Movement (MBL). Antonio ARANIBAR;
Tupac Katari Revolutionary Liberation
Movement (MRTK-L), Victor Hugo
CARDENAS Conde; Christian Democrat
Party (PDC), Jorge AGREDA
Member of: AG, ECLAC. FAO. GATT.
G- 1 1 , G-77, lADB. IAEA, IBRD, ICAO. IDA,
IFAD, IFC, ILO. IMF, IMO, INTELSAT.
INTERPOL, IOC, lOM, ITU, LAES, LAIA,
LORCS, NAM. OAS, OPANAL, PCA, RG.
UN, UNCTAD. UNESCO, UNIDO, UPU,
WCL. WFTU, WHO. WlPO, WMO, WTO
Diplomatic representation in US:
chief of mission: Ambassador Andres
PETRICEVIC
chancery: 3014 Massachusetts Avenue NW,
Bolivia (continued)
Washington, DC lOOOS
telephone: (202) 483-4410 through 4412
FAX: (202) 328-3712
consulate(s) general: Los Angeles, Miami,
New York, and San Francisco
US diplomatic representation:
chief of mission: Ambassador Charles R.
BOWERS
embassy: Banco Popular del Peru Building,
comer of Calle Mercado and Calle Colon, La
Paz
mailing address: P. O. Box 425, La Paz, or
APO AA 34032
telephone: [591] (2) 350251 or 350120
FAX.- [591] (2) 359875
Flag: three equal horizontal bands of red
(top), yellow, and green with the coat of arms
centered on the yellow band; similar to the flag
of Ghana, which has a large black five-pointed
star centered in the yellpw band','ed271181b4fb1b05055b9bebe72484dd4e612538dffe4f5d883f508eef33a7ff','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e4d142618599df40e329577db65dcec98bd7ce1ed56156e9474fbfaf8ae20c5',1994,'BA','Bosnia and Herzegovina','government',150,'Names:
conventional long form: Republic of Bosnia
and Herzegovina
conventional short form: Bosnia and
Herzegovina
local long form: Republika Bosna i
Hercegovina
local short form: Bosna i Hercegovina
Digraph: BK
Type: emerging democracy
Capital: Sarajevo
Administrative divisions: 1 09 districts
(opstinas, singular — opstina) Banovici. Banja
Luka, Bihac, Bijeljina, Bileca, Bosanska
Dubica. Bosanska Gradiska, Bosanska Krupa.
Bosanski Brod, Bosanski Novi. Bosanski
Petrovac, Bosanski Samac, Bo.sansko
Grahovo, Bratunac. Breko. Breza. Bugojno,
Busovaca, Cazin, Cajnice. Capljina, Celinac,
Citiuk. Derventa, Doboj. Donji Vakuf. Foca,
Fojnica. Gacko. Glamoc. Gorazde. Gomji
Vakuf, Gracanica. Gradacac. Crude, Han
Pijesak, Jablanica. Jajee. Kakanj, Kalesija.
Kalinovik. Kiseljak, Kladanj. Kljuc, Konjic,
Kotor Varos, Kre.sevo, Kupres, Laktasi.
Listica. Livno, Lopare, Lukavac. Ljubinje,
Ljubuski. Maglaj, Modrica, Mostar, Mrkonjic-
Grad. Neum, Nevesinje, Odzak, Olovo, Orasje,
Posusje, Prijedor, Pmjavor. Prozor. (Pucarevo)
Novi Travnik, Rogatica. Rudo, Sanski Most.
Sarajevo-Centar, Sarajevo-Hadzici, Sarajevo-
11 idza, Sarajevo-Ilijas. Sarajevo-Novi Grad.
Sarajevo-Novo. Sarajevo-Pale, Sarajevo-Stari
Grad, Sarajevo-Tmovo, Sarajevo- Vogosca,
Skender Vakuf, Sokolac, Srbac. Srebrenica.
Srebrenik. Stolac, Sekovici, Sipovo, Teslic.
Tesanj. Drvar. Duvno, Travnik, Trebinje.
Tuzia, Ugljevik, Vares, Velika Kladusa.
Visoko. Visegrad. Vitez.. Vla.senica.
Zavidovici, Zenica, Zvomik. Zepce. Zivinice
note: currently under negotiation with the
assistance of international mediators
Independence: NA April 1992 (from
Yugoslavia)
National holiday: NA
Constitution: promulgated in 1974 (under the
Communists), amended 1989, 1990. and 1991;
51
(continued)
the Assembly planned to draft a new
constitution in 1991, before conditions
deteriorated; constitution of Federation of
Bosnia and Herzegovina (including Muslim
and Croatian controlled parts of Republic)
ratified April 1994
Legal system: based on civil law system
SufOrage: 1 6 years of age, if employed; 1 8
years of age, universal
Executive branch:
chief of state: President Alija IZETBEOOVIC
(since 20 December 1990), other members of
the collective presidency: Ejup GANIC (since
NA November 1990), Nijaz DURAKOVIC
(since NA October 1993), Stjepan KLJUJIC
(since NA October 1993), Ivo KOMSIC (since
NA October 1993), Mirko PEJANOVIC f since
NA June 1992), Tatjana LJUJIC-MIJATOVIC
(since NA December 1992)
head of government: Prime Minister Haris
SILAJDZIC (since NA October 1993); Deputy
Prime Minister Edib BUKVIC (since NA
October 1993)
cabinet: executive body of ministers; members
of, and responsible to, the National Assembly
Legislative branch: bicameral National
Assembly
Chamber of Municipalities (Vijece Opeina):
elections last held November-December 1990
(next to be held NA); seats — ( 1 10 total) SDA
43, SDS BiH 38, HDZ BiH 23, Party of
Democratic Changes 4, DSS 1, SPO 1
Chamber of Citizens ( Vijece Gradanstvo):
elections last held November-December 1990
(next to be held NA): seats— (130 total) SDA
43, SDS BiH .34, HDZ BiH 2 1 , Party of
Democratic Changes 15, SRSJ BiH 12, MBO
2, DSS 1,DSZ l,LS I
note: legislative elections for the Federation of
Bosnia and Herzegovina are slated for late 1 994
Judicial branch: Supreme Court,
Constitutional Court
Political parties and leaders: Party of
Democratic Action (SDA), Alija
IZETBEGOVIC; Croatian Democratic Union
of Bosnia and Herzegovina (HDZ BiH),
KresimirZUBAK; Serbian Democratic Party
of Bosnia and Herzegovina (SDS BiH),
Radovan KARADZIC, president; Muslim-
Bosnian Organization (MBO). Adil
ZULFIKARPASIC, president; Democratic
Parly of Socialists (DSS). Nijaz
DURAKOVIC, president; Party of Democratic
Changes, leader NA; Serbian Movement for
Renewal (SPO). Milan TRIVUNCIC; Alliance
of Reform Forces of Yugoslavia for Bosnia and
Herzegovina (SRSJ BiH). Dr, Nenud
KECMANOVIC. president; Democratic
League of Greens (DSZ), Drazen PETROVIC:
Liberal Party (LS), Rasim KADIC, president
Other political or pressure groups: NA
Member of: CEl, CSCE, ECE, ICAO. ILO.
IMO. INTELSAT (nonsignatory user),
INTERPOL. IOC, ITU. NAM (guest), UN,
UNCTAD. UNESCO. UNIDO. UPU, WHO
Diplomatic representation in US:
chief of mission: (vacant); Minister-
Coun.selor, Charge d'' Affaires ad interim Seven
ALKALAJ
chancery: Suite 760, 1707 L Street NW,
Washington, DC 10036
telephone: (202) 833-3612. 3613. and 3615
FAX: (202) 833-2061
considate(s) general: New York
US diplomatic representation:
chief of mission: (vacant); Charge d'' Affaires
Victor JACKOVICH
embassy: American Embassy Bosnia, c/o
AmEmbassy Vienna, Boitzmanngasse 16,
A-1091, Vienna, Austria
mailing address: (Bosnia) Vienna,
Department of State, Washington. D.C. 2052 1 -
9900
/e/epJiwie; [43] (1)31-3.39
MX.- [431(1) 310-0682
note: the US maintains full diplomatic
relations with Bosnia and Herzegovina but has
not yet established an embassy in Sarajevo
Flag: white with a large blue shield: the shield
contains white Roman crosses with a white
diagonal band running from the upper hoist
corner to the lower fly side
Exchange rates: NA
Fiscal year: calendar year','3b2bb4429f741ab154b687f3465873a7bbd52f3aa8f77d78e0a4dc4c8f898d1f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71e9165200de720e107119ebe397cf785d02414b120b3b333a9f852d566ade3c',1994,'BW','Botswana','government',155,'Names:
conventional long form: Republic of
conventional short form: Botswana
former: Bechuanaland
Digraph: BC
Type: parliamentary republic
Capital: Gaborone
Administrative divisions: 10 districts;
Central, Chobe, Ghanzi. Kgalagadi. Kgatleng,
Kweneng, Ngamiland. North-East. South-East.
Southern; in addition, there are 4 town
councils — Francistown, Gaborone, Lobaste.
Selebi-Phikwe
Independence: 30 September 1966 (from
UK)
National holiday: Independence Day. .30
September (1966)
Constitution: March 1965, effective .30
September 1966
Legal system: based on Roman-Dutch law
and local customary law; judicial review
limited to matters of interpretation; has not
accepted compulsory ICJ jurisdiction
Botswana (continued)
Suffhigc: 21 years of age; universal
Executive branch;
chief of slate and head of government:
President Sir Ketumile MASIRE (since 1 3 July
1980); Vice President Festus MOGAE (since 9
March 1 992); election last held 7 October 1 989
(next to be held October 1994): results —
President Sir Ketumile MASIRE was reelected
by the National Assembly
cabinet: Cabinet; appointed by the president
Legislative branch: bicameral Parliament
House of Chiefs: is a largely advisory 15-
member body consisting of chiefs of the 8
principal tribes, 4 elected subchiefs, and 3
members selected by the other 1 2
National Assembly: elections last held 7
October 1989 (next to be held October 1994):
results — percent of vote by party NA; seats —
(38 total of which 34 are elected and 4 are
appointed) BDP 31, BNF 3, unfilled seats
pending new elections 4
Judicial branch: High Court, Court of
Appeal
Political parties and leaders: Botswana
Democratic Party (BDP), Sir Ketumile
MASIRE; Botswana National Front (BNF),
Kenneth KOMA; Botswana People’s Party
(BPP), Knight MARIPE; Botswana
Independence Party (BIP), Motsamai MPHO
Member of: ACP, AtDB, C, CCC, ECA,
FAO, FLS, G-77, GATT, IBRD, ICAO,
ICFTU, IDA, IFAD, IFC. ILO, IMF,
INTELSAT (nonsignatory user), INTERPOL,
IOC, ITU, LORCS, NAM, OAU, SACU,
SADC, UN, UNCTAD. UNESCO, UNIDO,
UNOMOZ, UNOMUR, UNOSOM, UPU,
WCL, WHO, WMO
Diplomatic representation in US;
chief of mission: Ambassador Botsweletse
Kingsley SEBELE
chancery: Suite 7M, 3400 International Drive
NW. Washington, DC 20008
telephone: (202) 244-4990 or 499 1
MX.- (202) 244-4164
US diplomatic representation:
chief of mission: Ambassador Howard JETER
embassy: address NA, Gaborone
mailing address: P. O. Box 90, Gaborone
telephone: [267] 353-982
FAX: [267] 356-947
Flag: light blue with a horizontal white-edged
black stripe in the center
Names:
conventional long form: none
conventional short form: Bouvet Island
Digraph: BV
Type: territory of Norway
Capital: none; administered from Oslo.','f86aa3510b7b018bcf1d5ddf7a6a8c12938b580030b7576dcdfc0ebfc54efe7b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ac11b492fd93ada2e9b47dfd3134b8fa42ae8df68179820367284f3b7fd338d',1994,'NO','Norway','government',161,'Names:
conventional long form: Federative Republic
of Brazil
conventional short form; Brazil
local long form; Republica Federativa do
Brasil
local short form; Brasil
Digraph: BR
Type: federal republic
Capital: Brasilia
Administrative divisions: 26 states (estados,
singular — estado) and I federal district*
(distrito federal): Acre, Alagoas. Amapa,
Amazonas, Bahia, Ceara, Distrito Federal*.
Espirito Santo, Goias, Maranha Mato
Grosso,''Mato Grosso do Sul. Minas Gerais.
Para. Paraiba. Parana. Pernambuco. Piaui. Rio
de Janeiro. Rio Grande do Norte. Rio Grande
do Sul. Rondunia, Roraima, Santa Catarina.
Sao Paulo, Sergipe, Tocantins
Independence: 7 September 1822 (from
Portugal)
National holiday: Independence Day, 7
September ( 1 822)
Constitution: 5 October 1988
Legal system: based on Roman codes; has not
accepted compulsory ICJ jurisdiction
Suffrage: voluntary between 16 and 1 8 years
of age and over 70; compulsory over 18 and
under 70 years of age
Executive branch:
chief of state and head of government;
President Itamar FRANCO (since 29
December 1992); election last held 15
November 1989, with runoff on 17 December
1989 (next to be held October 1994); results —
Fernando COLLOR de Mello 53%. Luis Inacio
LULA da Silva 47%; note — first free, direct
presidential election since 1960; Fernando
COLLOR de Mello was impeached in
December 1992 and succeeded by former Vice
President Itamar FRANCO
cabinet; Cabinet; appointed by the president
Legislative branch: bicameral National
Congress (Congre.sso Nacional)
Federal Senate (Senado Federal); election
last held 3 October 1990 (next to be held
October 1994); results — percent of vote by
party PMBD 33%. ’’FL 1 6%. PSDB 12%. PDS
4%. PDT 6%, PT I %. other 28%; seats— (8 1
total as of 3 February 1991) PMDB 27, PFL 15,
PSDB 10, PTB 8, PDT 5, other 16
Chamber of Deputies (Camara dos Deputa-
dos); election last held 3 October 1 990 (next to
be held October 1994); results — PMDB 21%.
PFL 1 7%. PDT 9%. PDS 8%. PRN 7.9% , PTB
7%, PT 7%, other 23.1%; seats — (503 total as
of 3 February 1991) PMDB 108. PFL 87, PDT
46. PDS 43. PRN 40. PTB 35. PT 35. other 1 09
Judicial branch: Supreme Federal Tribunal
Political parties and leaders: National
Reconstruction Party (PRN), Daniel
TOURINHO, president; Brazilian Democratic
Movement Party (PMDB), Luiz HENRIQUE
da Silveira. president; Liberal Front Party
(PFL), Jorge BORNHAUSEN. president:
Workers'' Party (PT). Luis Inacio LULA da
Silva, president; Brazilian Workers'' Party
(PTB), Rodrigues PALMA, president;
Democratic Workers’ Party (PDT), Lconel
BRlZOt ,A. president: Progressive Renewal
Party (PPR), Paulo MALUF. president;
Brazilian Social Democracy Party (PSDB),
Tasso JEREISSATI, president; Popular
Socialist Party (PPS), Roberto FREIRE,
president; Communist Party of Brazil
(PCdoB), Joao AMAZONAS, secretary
general; Liberal Party (PL), Flavio R(X)HA,
president
Other political or pressure groups^ left
wing of the Catholic Church .ind labor tinions
allied to leftist Workers’ Party are critical of
government''s social and economic policies
Member of: AfDB, AG (observer), CCC,
ECLAC, PAD. G- 1 1 . G- 1 5, G- 1 9, G-24. G-77,
GATT. I.\\DE, IAEA, IBRD, ICAO. ICC.
ICFTU. IDA. IFAD. IFC, ILO, IMF, IMO,
INMARSAT. INTELSAT. INTERPOL. IOC.
lOM (observer), ISO, ITU. LAES, LAIA.
LORCS, MERCOSUR, NAM (observer),
OAS, ONUSAL, OPANAL. PCA, RG. UN.
UNAVEM II. UNCTAD, UNESCO. UNHCR,
UNIDO, UNOMOZ, UNOMUR,
UNPROFOR. UPU. WCL. WHO. WFTU.
WIPO, WMO, WTO
Diplomatic representation in US:
chief of mission; Ambassador Paulo Tarso
FLECHA de LIMA
chancery; 3(X)6 Mass.ichusetts Avenue NW,
Washington. DC 20O">8
telephone; (202) 745-2700
FAX; (202) 745-2827
consulate! s) general; Boston, Chicago, Hong
Kong (Trust Territories of the Pacific Islands),
Los Angeles. Miami. New York, and San Juan
(Puerto Rico)
consulate! s); Houston and San Francisco
US diplomatic representation;
chief of nu::sion; Ambassador Melvyn
LEVITSKY
embassy; Avenida das Nacoes, Lote 3,
Brasilia, Distrito Federal
mailing address; APO AA 34030
telephone; [55] (61) 321-7272
M/r.- (551(61)225-9136
consulateis) general; Rio de Janeiro, Sao
Paulo
consulate(s); Porto Alegre, Recife
Flag; green with a large yellow diamond in
the center bearing a blue celestial globe with 3,7
white five-pointed stars (one for each state and
district) arranged In the same pattern us the
night sky over Brazil; the glote has a white
equatorial band with the motto ORDEM E
PROGRESSO (Order and Progress)
Names:
conventional Iona form; ntine
conventional short form; Greenland
local long form; none
local short form; Kalaallit Nunaat
Digraph: GL
Type: part of the Danish realm: self-
governing overseas administrative division
Capital: Nuuk (Godthab)
Administrative divisions: 3 municipalities
(kommuner. singular — kommun);
Nordgronland, Ostgronland, Veslgronland
Independence: none (part of the Danish
realm: self-governing overseas administrative
division)
National holiday: Birthday of the Queen, 16
April (1940)
Constitution: 5 June 1953 (Danish
constitution)
Legal system: Danish
Suffrage: 18 years of age: universal
Executive branch:
chief of slate; Queen MARGRETHE II (since
14 January 1972), represented by High
Commissioner Torben Hede PEDERSEN
(since NA)
head of government; Home Rule Chairman
Lars Emil JOHANSEN (since 15 March 1991 )
cabinet; Landsstyre; formed from the
Landsting on basis of strength of parties
Legislative branch: unicameral
Parliament (Landsting); elections last held on
5 March 1991 (next to be held 5 March 1995):
results - percent of vote by party NA; .seats —
(27 total) Siumut i I, Atassut Party 8, Inuit
Ataqatigiit 5, Center Party 2, Polar Party I
Danish Folketing; last held on 1 2 December
1990 (next to be held by December 1994);
Greenland elects two representatives to the
Folketing; results — percent of vote by party
NA; seats — (2 total) Siumut 1, Atas.sut 1
Judicial branch; High Court (Landsret)
Political parties and leaders; two-party
ruling coalition; Siumut (a moderate socialist
party that advocates more distinct Greenlandic
identity and greater autonomy from Denmark),
Lars Emil JOHANSEN, chairman; Inuii
Ataqatigiit (lA; a Marxist-Leninist party that
favors complete independence from Denmark
rather than home mie), Arqaluk LYNGE;
Atassut Party (a more conservative party that
favors continuing close relations with
Denmark), leader NA; Polar Party
(conservative-Greenland nationalist). Lars
CHEMNITZ; Center Party (a new nonsncialisi
protest party), leader NA
Diplomatic representation in US: none
(self-governing overseas administrative
division of Denmark)
US diplomatic representation: none (self-
governing overseas administrative division of
Denmark)
Flag: two equal horizontal bands of white
(top) and red with a large disk slightly to the
hoist side of center — the top half of the disk is
red. the bottom half is white','47630c185bec4ebbccb7bf8d86eb38aa33786c02d07b3e5e97c07c9e05f60787','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f74972a0f84453839c08efa789ad941e9b3495d4824bf1eb2b4ff709f7bc98b8',1994,'IO','British Indian Ocean Territory','government',168,'Names:
conventional long form: British Indian Ocean
Territory
conventional short form: none
Abbreviation: BIOT
Digraph: lO
Type: dependent territory of the UK
Capital: none
Independence: none (dependent territory of
the UK)
Executive branch:
chief of state; Queen ELIZABETH II (since 6
February 1952)
head of government: Commissioner Thomas
GEORGE (since September 1991);
Administrator Mr. R. G. WELLS (since NA
1991); note — both reside in the UK
Diplomatic representation in US; none
(dependent territory of the UK)
US diplomatic representation: none
(dependent territory of the UK)
Flag: white with the flag of the UK in the
upper hoist-side quadrant and six blue wavy
horizontal stripes bearing a palm tree and
yellow crown centered on the outer half of the
nag
Airports:
total: 1
usable: I
with permanent-surface runways; 1
with runways over 3,659 m: I on Diego Garcia
with runways 2,440-3,659 m: 0
with runways 1,229-2,439 m: 0
Telecommunications: minimal facilities;
broadcast stations (operated by US Navy) — 1
AM, 1 FM, 1 TV; 1 Atlantic Ocean
INTELSAT earth station
Defense Forces
Note: defense is the responsibility of the UK
Names:
conventional long form; none
conventional short form: British Virgin
Islands
Abbreviation: BVl
Digraph: VI
Type: dependent territory of the UK
Capital: Road Town
Administrative divisions: none (dependent
territory of the UK)
Independence: none (dependent territory of
the UK)
National holiday: Territory Day, 1 July
Constitution: I June 1977
Legal system: English law
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II (since 6
February 1 952). represented by Governor Peter
Alfred PENFOLD (since 14 October 1991)
head of government; Chief Minister H. Lavity
STOUTT (since NA September 1986)
cabinet: Executive Council; appointed by the
governor
Legislative branch: unicameral
Legislative Council: election last held 12
November 1990 (next to be held by November
1995); results — percent of vote by party NA;
.seats — (9 total) VIP 6, iPM I, independents 2
Judicial branch: Eastern Caribbean Supreme
Court
Political parties and leaders: United Party
(UP), Conrad MADURO; Virgin Islands Party
(VIP), H. Lavity STOUTT; Independent
Progressive Movement (IPM), E. Walwyln
BREWLEY
Member of: CARICOM (associate), CDB,
ECLAC (associate), INTERPOL (subbureau),
IOC, OECS (associate), UNESCO (associate)
Diplomatic representation in US; none
(dependent territory of the UK)
US diplomatic representation: none
(dependent territory of the UK)
Flag; blue with the flag of the UK in the upper
hoist-side quadrant and the Virgin Islander
coat of arms centered in the outer half of the
flag; the coat of arms depicts a woman flanked
on either side by a vertical columi. of six oil
lamps above a scroll bearing the Latin word
VIGILATE (Be Watchful)
Names:
conventional long form: Negara Brunei
Darus.salam
conventional short form: Brunei
Digraph: BX
Type: constitutional sultanate
Capital: Bandar Seri Begawan
Administrative divisions; 4 districts
(daerah-daerah, singular — daerah): Belait.
Brunei and Muara, Temburong. Tutong
Independence: I January 1984 (from UK)
National holiday: National Day 23 February
(1984)
Constitution: 29 September 1959 (some
provisions suspended under a State of
Emergency since December 1962, others since
independence on 1 January 1984)
Legal system: based on Islamic law
Suffrage: none
60
Executive branch:
chief of slate and head of government: Sultan
and Prime Minister His Majesty Paduka Seri
Baginda Sultan Haji HASSANAL Bolkiah
Mu’izzaddin Waddaulah (since 5 October
1967)
cabinet: Council of Cabinet Ministers;
composed chiefly of members of the royal
family
Legislative branch: unicameral
Legislative Council (Majlis Masyuarat
Megeri): elections last held in March 1962; in
1 970 the Council was changed to an appointive
body by decree of the sultan; an elected
legislative Council is being considered as part
of constitution reform, but elections are
unlikely for several years
Judicial branch: Supreme Court
Political parties and leaders: Brunei United
National Party (inactive), Anak
HASANUDDIN, chairman; Brunei National
Democratic Party (the first legal political parly
and now banned), leader NA
Member of: APEC, ASEAN, C, ESCAP,
FAO, G-77, GATT, ICAO, IDB, IMO,
INTELSAT (nonsignatory user), INTERPOL,
IOC, ISO (correspondent), ITU. NAM. OIC,
UN, UNCTAD, UPU. UNTAC, WHO. WMO
Diplomatic representation in US;
chief of mission: Ambassador JAVA bin
Abdul Latif
chancery: 2600 Virginia Avenue NW, Suite
.300. Washington. DC 200.37
telephone: (202) 342-0159
fAX; (202) .342-0 158
US diplomatic representation:
chief of mission: Ambassador Theresa A.
TULL
embassy: Third Floor, Teck Guan Plaza, Jalan
Sultan, Bandar Seri Begawan
mailing address: American Embassy Box B,
APO AP 96440
telephone: |67.3] (2) 229-670
FAX: 1673] (2) 225-293
Flag: yellow with two diagonal bands of
white (top, almost double width) and black
starting from the upper hoist side; the national
emblem in red is superimposed at the center;
the emblem includes a swallow-tailed flag on
top of a winged column within an upturned
crescent above a scroll and flanked by two
upraised hands','1476abe5676a41421fc7bb68b6e1be44d647ee985e249f0330546ceaf94aa9ce','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b33b5fa6847c5e725db843739117808e235e87fba8e657be6a4f14adcf5f02ae',1994,'BG','Bulgaria','government',174,'Names:
conventional long form: Republic of Bulgaria
conventional .short form: Bulgaria
Digraph: BU
Type: emerging democracy
Capital: Sofia
Administrative divisions; 9 pmvinces
(oblasti. singular — oblast): Burgas. Grad
Sofiya, Khaskovo, Lovech, Montana. Plovdiv.
Ruse. Sofiya, Varna
Independence: 22 September 1908 (from
Ottoman Empire)
National holiday: Independence Day 3
March (1878)
Constitution: adopted 12 July 1991
Legal system: ba.sed on civil law system, with
Soviet law influence; has accepted compulsory
ICJ jurisdiction
Suffrage: 1 8 years of age; universal and
compulsory
Executive branch:
chief of state: President Zhelyu Mitev
ZHELEV (since 1 August 1990); Vice
President (vacant); election last held January
1992; results — Zhelyu ZHELEV was elected
by popular vote
head of government: Chairman of the Council
of Ministers (Prime Minister) Lyuben Borisov
BEROV (since 50 December 1992); Deputy
Chairman of the Council of Ministers (Deputy
Prime Minister) Evgeniy MATINCHEV (since
30 December 1992)
cabinet: Council of Ministers: elected by the
National Assembly
Legislative branch: unicameral
National Assembly (Narodno Sobranie): last
held 13 October 1991 ; results — DDF (and
breakaway factions) .54%. BSP .53%, MRF
7.5%; seals— (240 total) UDF 1 10. BSP 106,
Movement for Rights and Freedoms 24
note: the UDF split in March 1993 to form the
New Union for Democracy (NUD) with 18
seats, and the Union of Democratic Forces
(UDF) with 92 seats
Judicial branch; Supreme Court.
Constitutional Court
Political parties and leaders; Union of
Democratic Forces (UDF), Filip DIMITROV,
chairman, an alliance of approximately 20 pro-
Democratic parlies including United
Democratic Center, Democratic Party, Radical
Democratic Party, Christian Democratic
Union, Alternative Social Liberal Party,
Republican Party, Civic Initiative Movement,
and about a dozen other groups; Movement for
Rights and Freedoms (mainly ethnic Turkish
party) (MRF). Ahmed DOGAN. chairman;
Bulgarian Sociali.st Party (BSP), Zhan
VIDENOV, chairman; New Union for
Democracy (NUD). Dimitar LUDZHEV.
chairman
Other political or pressure groups:
Ecoglasnost; Podkrepa (Support) Labor
Confederation; Fatherland Union; Bulgarian
Democratic Youth (formerly Communist
Youth Union); Confederation of Independent
Trade Unions of Bulgaria (KNSB):
Nationwide Committee for Defense of
National Interests; Peasant Youth League;
Bulgarian Agrarian National Union — United
(BZNS); Bulgarian Democratic Center;
"Nikola Petkov" Bulgarian Agrarian National
Union; Internal Macedonian Revolutionary
Organization — Union of Macedonian
Societies (IMRO-UMS); numerous regional,
ethnic, and national interest groups with
various agendas
62
Member of: ACCT (observer), BIS, BSEC,
CCC, CE. CEI (participating), CSCE, EBRD,
ECE, FAO, G-9, IAEA, IBRD, ICAO, ICFTU,
IDA, IFC, ILO, IMF, IMO, INMARSAT,
INTELSAT (nonsignatory user), INTERPOL,
IOC, lOM (observer). ISO. ITU. LORCS.
NACC, NAM (guest), NSG, PCA, UN,
UNCTAD, UNESCO, UNIDO, UNTAC,
UPU, WFTU. WHO. WIPO, WMO. WTO, ZC
Diplomatic representation in US:
chief of mission: Ambassador Ognyan
Raytchev PISHEV
chancery: 1621 22nd Street NW, Washington.
DC 20008
telephone: (202) 387-7969
FAX: (202) 234-7973
US diplomatic representation:
chief of mission: Ambassador William D.
MONTGOMERY
embassy: I Saboma Street, Sofia
mailing address: Unit 25402, Sofia; APO AE
09213
telephone: (359) (2) 88-48-01 through 05
FAX; 1359] (2) 80-19-77
Flag: three equal horizontal bands of white
(top), green, and red; the national emblem
formerly on the hoist side of the white stripe
has been removed — it contained a rampant lion
within a wreath of wheat ears below a red five-
pointed star and above a ribbon bearing the
dates 68 1 (first Bulgarian state established) and
1944 (liberation from Nazi control)
Names:
eanventianal Ian); farm: Burkina Fa.so
eanventianal sliart farm: Burkina
firmer: Upper Volta
Digraph; UV
Type: parliamentary
Capital: Ouagadougou
Administrative divisions: 30 provinces;
Bum, Bazega, Bougouriba. Boulgou,
Boulkiemdc. Gan/ourgou, Gnagna. Gourmu,
Houet. Kadiogo. Kenedougou. Komoe. Kossi,
Kouritenga. Mouhoup. Namenlenga. Naouri,
Oubriienga. Oudulan. Passore, Poni. Sanguie.
Sanmatengu, Seno. Sissili. Soum. Sourou.
Tapoa, Yatenga, /.oundweogo
Independence: 5 August 1960 (from France)
National holiday: Anniversary of the
Revolution. 4 August (1983)
Constitution: 2 June 1991
Legal system: based on French civil law
system and customary law
Suffrage: none
Executive branch;
chief of state: President Capiain Blaise
COMPAORE (since 15 October 1987);
election last held December 1991
bead of government; Prime Minister Roch
KABORE (since March 1994)
cabinet: Council of Ministers; appointed by
the president
Legislative branch: unicameral
Assembly of People''s Deputies: elections last
held 24 May 1992 (next to be held NA);
results — percent of vote by party NA; seats —
( 107 total). ODP-MT 78. CNPP-PSD 1 2, RDA
6. ADF 4, other 7
note: the current law'' also provides for a second
consultative chamber, which had not been
formally constituted as of 1 July 1992
Judicial branch: Appeals Coun
Political parties and leaders: Organization
for People''s Democracy-Labor Movement
(ODP-MT). ruling party, Simon COMPAORE.
Secretary General; National Convention of
Progressive Patriots-Social Democratic Party
(CNPP-PSD). Moussa BOLY; African
DeiiHKratic Rally (RDA), Gerard Kango
OUEDRACXjO; Alliance for Deniwracy and
Federation (ADF). Amadou Michel NANA
Other political or pressure groups;
committees for the defense of the revolution;
watchdog/political action groups throughout
the country in both organizations and
communities
Member of: ACCT, ACP. AfDB, CCC,
CEAO. ECA, ECOWAS, Entente, FAO. FZ.
G-77. GATT. IBRD. ICAO. ICC. ICFTU.
IDA. IDB. IFAD, IFC. ILO, IMF, INTELSAT,
INTERPOL. IOC, ITU. LORCS. NAM. OAU,
OIC, PCA, UN. UNCTAD. UNESCO.
UNIDO. UPU. WADB, WCL. WFTU. WHO.
WIPO. WMO, WTO
Diplomatic representation in US:
chief of mission: (vacant); Charge d''Affaires
Thomas Yara KAMBOU
chancers-: 2340 Massachusetts Avenue NW.
Washington. DC 2(XX)8
telephone: (202) 332-5577 or 6895
US diplomatic representation;
chief of missian: .Ambassador Donald J.
McCCINNELL
embassy: Avenue Raoul Follerau.
Ouagadougou
mailing address: 01 B. P. 35. Ouagadougou
telephone: 12261 30-67- 23 through 25
FAX: (2261 31-23-68
Flag: tw o equal horizontal bands of red (top)
and green w ith a yellow five-pointed star in the
center: uses the popular pan-African colors of','1e8d165fb72d0fbf0f5f7ac5d9a0a01af43aa56800fe6d9d97f6df9b7cc18008','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3cdbaa75b6f3caf155f574211d8d2a9dcb7d18542ef12e68803df2cb75f7521c',1994,'ET','Ethiopia','government',176,'64
Burma
Economy Communications
Railroads: 620 km total; 520 km
Ouagadougou to Cote d’Ivoire border and 100
km Ouagadougou to iCaya; all 1.00-meter
gauge and single track
Highways:
total: 16,500 km
paved; 1,300 km
unpaved: improved earth 7,400 km;
unimproved earth 7,800 km (1985)
Airports:
total; 48
usable; 38
with permanent-surface runways: 2
with runways over 3,659 m; 0
with runways 2,440-3,659 m; 2
with runways 1,220-2,439 m: 8
Telecommunications; all services only fair;
microwave radio relay, wire, and radio
communication stations in use; broadcast
stations — 2 AM, 1 FM, 2TV; 1 Atlantic Ocean
INTELSAT earth station
Defense Forces
Branches: Army, Air Force, National
Gendarmerie, National Police, People''s Militia
Manpower availability; males age 1 5-49
2,01 3,763; fit for military service 1 ,029,960
Defense expenditures: exchange rate
conversion — $NA, NA% of GDP
Digraph: ER
Type: transitional government
note: on 29 May 1991 ISSAIAS Afeworke,
secretary general of the Eritrean People''s
Liberation Front (EPLF), announced the
formation of the Provisional Government in
Eritrea (PGE), in preparation for the 23-25
April 1993 referendum on independence for
the autonomous region of Eritrea; the result
was a landslide vote for independence that was
announced on 27 April 1993
Capital: Asmara (formerly Asmera)
Administrative divisions; 8 provinces:
Akale Guzay, Baraka, Elenakil, Hamasen,
Samhar, Seraye, Sahil ( 1993)
Independence: 27 May 1993 (from Ethiopia;
formerly the Eritrea Autonomous Region)
National holiday: National Day
(independence from Ethiopia), 24 May (1993)
Constitution: transitional "constitution"
decreed 19 May 1993
Legal system: NA
Suffeage: NA
Executive branch:
chief of state and head of government:
President ISSAIAS Afeworke (since 22 May
1993)
cabinet: State Council; the collective executive
authority
note: election to be held before 20 May 1997
Legislative branch: unicameral
National Assembly: EPLF Central Committee
serves as the country’s legislative body until
multinational elections are held (before 20
May 1997)
Judicial branch: Judiciary
Political parties and leaders: Eritrean
People’s Liberation Fn at (EPLF) (Christian
Muslim), ISSAIAS Aferworke, PETROS
Solomon: Eritrean Liberation Front (ELF)
(Muslim), ABDULLAH Muhammed; Eritrean
Liberation Front-United Organization
(ELF-UO), Mohammed Said NAWUD;
Eritrean Liberation Front-Revolutionary
Council (ELF-RC), Ahmed NASSER
Other poittical or pressure groups:
Eritrean Islamic Jihad (EIJ); Islamic Militant
Group
Member of: OAU, ACP, AfDB. ECA, ILO,
IMO, INTELSAT (nonsignatory user), ITU,
UN, UNCTAD, UNESCO. UPU, WMO
Diplomatic representation in US;
chief of mission: Ambassador-designate
HagosGEBREHlWOT
chancery: Suite 400, 910 17th Street NW,
Washington DC 20()06
telephone: (202) 429-1991
FAX: (202) 429-9004
US diplomatic representation:
chief of mission: Ambassador Robert G.
HOUDEK
embassy: 34 Zera Yacob St,. Asmara
mailing address: P.O. Box 211, Asmara
telephone; (2911 (1) 123-720
FAX.- [291] (1) 127-584
Flag: red isosceles triangle (based on the hoist
side) dividing the flag into two right triangles;
the upper triangle is green, the lower one is
blue: a gold wreath encircling a gold olive
branch is centered on the hoist side of the red
triangle','f3b28684de730ae3df576c18fdb6aba781c356038f1f48bbd0dd1e5b407dbc28','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd6836593fde1b1745eb3ce01e7c956c1a1792b3a46cc6393c543a1a3579ab68',1994,'TH','Thailand','government',181,'Names:
conventional long form: Union of Burma
conventional short form: Burma
local long form: Pyidaungzu Myanma
Naingngandaw (translated by the US
Government as Union of Myanma and by the
Burme.se as Union of Myanmar)
local short form: Myanma Naingngandaw
former: Socialist Republic of the Union of
Burma
Digraph: BM
Type: military regime
Capital; Rangoon (sometimes translated as
Yangon)
Administrative divisions: 7 divisions* (yin-
mya, singular — yin) and 7 states (pyine-mya,
singular — pyine); Chin State. Irrawaddy*,
Kachin State. Karan State. Kayah State,
Magwe*, Mandalay*, Mon State, Pegu*,
Rakhine State, Rangoon*, Sagaing*, Shan
State, Tenasserim*
Independence: 4 January 1948 (from UK)
National holiday: Independence Day, 4
January (1948)
Constitution: 3 January 1974 (suspended
since 18 September 1988); National
Convention started on 9 January 1993 to draft
chapter headings for a new constitution
Legal system: has not accepted compulsory
ICJ Jurisdiction
Suffrage: 1 8 years of age: universal
Executive branch:
chief of state and head of government:
Chairman of the State Law and Order
Restoration Council Gen. THAN SHWE (since
23 April 1992)
Stale Law and Order Restoration Council:
military junta which assumed power 18
September 1988
Legislative branch:
People ''s Assembly (Pyithu Hlutiaw): last held
27 May 1990, but Assembly never convened;
results — NLD 80%; .seats — (485 total) NLD
396, the regime-favored NUP 1 0. other 79; was
dissolved after the coup of 18 September 1988
Judicial branch: none; Council of People''s
Justices was abolished after the coup of 18
September 1988
Political parties and leaders: Union
Solidarity and Development Association
(USDA), leader NA: National Unity Party
(NUP; proregime). THA KYAW; National
League for Democracy (NLD), U AUNG
SHWE
Other political or pressure groups;
National Coalition Government of the Union
of Burma (NCGUB), headed by the elected
prime minister SEIN WIN (consists of
individuals legitimately elected to Parliament
but not recognized by the military regime; the
group fled to a border area and joined with
insurgents in December 1990 to form a
parallel government; Kachin Independence
Army (KIA); United Wa State Army (UWSA):
Karen National Union (KNU); several Shan
factions, including the Mong Tai Army
(MTA); All Burma Student Democratic Front
(ABSDF)
Member of: AsDB, CCC. CP, ESCAP, FAO,
G-77. GATT, IAEA. IBRD. ICAO, IDA.
IFAD, IFC, ILO. IMF. IMO. INTELSAT
(nonsignatory user), INTERPOL, IOC, ITU,
LORC3. NAM, UN. UNCTAD, UNESCO,
UNIDO, UPU, WHO, WMO
Diplomatic representation in US:
chief of mission: Ambassador U THAUNG
chancerv: 2300 S Street NW. Wa.shington, DC
20008
telephone: (202) 332-9044 or 9045
consulate(s) general: New York
US diplomatic representation;
chief of mission: (vacant); Deputy Chief of
Mission, Charge d''Affaires Franklin P.
HUDDLE, Jr,
embassy: 581 Merchant Street, Rangoon
mailing address: American Embassy, Box B,
APO AP 96546
telephone: (95) (1) 82055, 82181
FAX: 195) (i) 80409
Flag: red with a blue rectangle in the upper
hoist-side comer bearing, all in white, 14 five-
pointed stars encircling a cogwheel containing
a stalk of rice; the 14 stars represent the 14
administrative divisions','35289cc8373536eac5b14d9d4319299c6fc94a7bd67dc8cf987062c0a7857ab3','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efe06461ac1b5aaf10b931e9d458cc0ad19f9394a2cdefddc0dc58cf6b61e0e2',1994,'BI','Burundi','government',190,'Names;
conventional lonuforin: Republic of Burundi
conventional short form: Burundi
ItK''al long form: Republika y’u Burundi
local short form: Burundi
Digraph: BY
Type: republic
Capital: Bujumbura
Administrative divisions: 15 provinces;
Bubanza, Bujumbura, Bururi, Cankuzo,
Cibitoke, Gitcga, Karuzi, Kayanza, Kirundo,
Makambu, Muramvya. Muyinga. Ngozi,
Rutana, Ruyigi
independence; I July 1962 (from UN
trusteeship under Belgian administration)
National holiday: Independence Day. 1 July
(1962)
Constitution: 13 March 1992; provides for
e.stablishmcm of a plural political system
Legal .system: ba.sed on German and Belgian
civil codes and customary law; has not
accepted compulsory ICJ jurisdiction
Suffrage: universal adult at age NA
Executive branch:
chief of state: Interim President Sylvestre
NTIBANTUNGANYA, Speaker of the
National Assembly, succeeded deceased
President NTARYAMIRA and will remain in
office for 90 oays, atter which elections must
be held
note: President Melchior NDADAYE died in
the military coup of 21 October 1993 and was
succeeded on 5 February 1994 by President
Cypricn NTARYAMIRA. who was killed in a
mysterious airplane esplosion on 6 April 1994
head of government: Wme Minister Anatole
KANYENKIKO (since 7 February 1994);
chosen by the president
cabinet: Council Of Ministers ; appointed by
prime minister
Legislative branch: unicameral
National Assembly (Assemhiee Nationale):
elections last held 29 June 1993 (next to be
held NA); results— FRODEBU 71%.
UPRONA 21.4%; seats— (81 total)
FRODEBU 65. UPRONA 16; other parties
won too small shares of the vote to win seats in
the assembly
note: The National Unity Charter outlining the
principles for constitutional government was
adopted by a national referendum on 5
February 1991
Judicial branch: Supreme Court (Cour
Supreme)
Political parties and leaders; Unity for
National Progress (UPRONA); Burundi
DemtK.jtic Front (FRODEBU): Organizntion
of the People of Burundi (RBP): Socialist Party
of Burundi (PSB); People’s Reconciliation
Party (PRP)
Other political or pressure groups:
opposition parties legalized in March 1992;
Burundi African Alliance for the Salvation
(ABASA): Rally for Democracy and
Economic and Social Development
(RADDES)
Member of: ACCT. ACP. AfDB, CCC,
CEEAC, CEPGL, ECA, FAO. G-77. GATT.
IBRD, ICAO. IDA. IFAD. IFC, ILO. IMF.
INTELSAT (nonsignatory user). INTERPOL,
ITU, LORCS. NAM, OAU. UN. UNCTAD,
UNESCO. UNIDO. UPU. WHO, WIPO,
WMO, WTO
Diplomatic representation in US;
chief of mission: Amba.s.sudor Jacques
BACAMURWANKO. dc.signatcd (January
1994)
chancerv: Suite 212. 2233 Wi.sconsin Avenue
NW. Washington. DC 2(XK)7
telephone: (202) ,342-2574
US diplomatic representation:
ehiefof mission: (vacant); Charge d'' Affaires
Leonard J. LANGE
embassy: Avenue des Eiats-Unis, Bujumbura
mailing address: B, P. .34, 1720, Bujumbura
telephone: |257| (22,3) 4.54
FAX: 1 2,57 1 (222)926
Flag: divided by a white diagonal cross into
red panels (top and brntom) and green panels
(hoist side and outer side) with a white disk
superimposed at the center bearing three red
six-pointed stars outlined in green arranged in
a triangular design (one star above, two stars
below)','d575416319cfe54aadb6bd7ba03c5a989442c86bcf07b21d4730295b873990db','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4f150ddc1f1c34ea3ac9d6179f4e60bf079314b0a3da1a21cbe4542f1344eba',1994,'KH','Cambodia','government',196,'Names;
conventional long form: Kingdom of Cambodia
conventional short form: Cambodia
Digraph; CB
Type: multiparty liberal democracy under a
constitutional monarchy established in
September 1993
Capital: Phnom Penh
Administrative divisions: 20 provinces
(khet. singular and plural); Banteay Meanchey ,
Batdambang, Kampong Cham, Kampong
Chhnang, Kampong Spoe, Kampong Thum,
Kampot, Kandal, Kaoh Kong, IGacheh,
Mondol Kiri, Phnum Penh, Pouthisat, Preah
Vihear, Prey Veng, Rotanokiri, Siemreab-
Otdar Meanchey, Stoeng Treng, Svay Rieng,
Takev
Independence: 9 November 1949 (from
France)
National holiday: Independence Day,
9 November 1949
Constitution: promulgated September 1993
69
Cambodia i continued)
Legal system: currently being defined
Suffk''age: 1 8 years of age; universal
Executive branch:
chief of state; King Norodom SIHANOUK
(reinstated NA September 1993)
head of government; power shared between
First Prime Minister Wnce Norodom
RANARIDDH and Second Prime Minister
HUN SEN
cahinet; Council of Ministers; elected by the
National Assembly
Legislative branch: unicameral; a
1 20-member constituent assembly based on
proportional representation within each
province was establised following the
UN-supervised election in May 1993; the
constituent assembly was transformed into a
legislature in September 1993 afier delegates
promulgated the constitution
Judicial branch: Supreme Court established
under the constitution has not yet been
established and the future judicial system is yet
to be deFined by law
Political parties and leaders: National
United Front for an Independent, Neutral,
Peticeful, and Cooperative Cambodia
(FUNCINPEC) under Prince NORODOM
RANARIDDH: Cambodian Pracheachon
Party or Cambodian People''s Party (CPP)
under CHE A SIM; Buddhist Liberal
DcnuKrutic Party under SON SANN;
DemiK''ratic Kampuchea (DK, also known as
the Khmer Rouge) under KHIEU SAMPHAN
Member of: ACCT (observer), AsDB, CP,
ESCAP, FAQ, G-77, IAEA, IBRD, ICAO,
IDA, IFAD, ILO, IMF, IMO, INTELSAT
(nonsignatory user), INTERPOL, ITU,
LORCS, NAM, PCA, UN, UNCTAD,
UNESCO. UPU. WFTU, WHO. WMO, WTO
Diplomatic representation in US:
Ambassador SISOWATH SIRIRATH
represents Cambtxlia at the United Nations
US diplomatic representation:
chief of mission; Ambassador Charles H.
TWINING
enihassy; 27 EO Street 240. Phnom Penh
mailing address; Box P, APO AP 96546
telephone; (855) 23-26436 or (855) 23-26438
FAX; (855) 23-26437
Flag: horizontal band of red separates two
equal hori/onial bands of blue with a white
three-towered temple representing Angkor
Wat in the center
Names:
conventional long form; Kingdom of Thailand
conventional short form; Thailand
Digraph: TH
Type: constitutional monarchy
Capital: Bangkok
Administrative divisions: 73 provinces
(changwat, singular and plural): Ang Thong,
Buriram, Chachoengsao. Chai Nat,
Chaiyaphum, Chanihaburi, Chiang Mai,
Chiang Rai. Chon Buri, Chumphon, Kalasin.
Kamphaeng Phet, Kanchanaburi, Khon Kaen,
Krabi, Krung Thep Mahanakhon, Lampang,
Lamphun. Loei, Lop Buri, Mae Hong oon,
Maha Sarakham, Mukdahan, Nakhon Vayok,
Nakhon Pathom, Nakhon Phanom, Nashon
Ratchasima. Nakhon Sawan. Nakhon bi
Thammarat, Nan, Narathiwat, Nonf Khai,
Nonthaburi, Pr''hum Thani, Pattani, Phangnta,
Phatthalung, Phayao. Pheichabun,
Phetchaburi, Phichit, Phitsanulok, Phra
Nakhon Si Ayutthaya, Phrae, Phuket, Prachin
Buri, Prachuap Khiri Khan, Ranong,
Ratchaburi, Rayong, Roi Et, Sakon Nakhon,
Samul Prukan, Samut Sakhon, Samut
Songkhram. Sara Buri. Satun, Sing Buri,
Sisaket, Songkhia, Sukhothai, Suphan Buri,
Surat Thani, Surin, Tak, Trang, Trat. Ubon
Ratchathani, Udon Thani, Uthai Thani,
Uttaradit, Yala, Yasothon
Independence; 1238 (traditional founding
date; never colonized)
National holiday; Birthday of His Majesty
the King, 5 December (1927)
Constitution: new constitution approved 7
December 1991; amended 10 June 1992
Legal system: based on civil law system, with
influences of common law; has not accepted
compulsory ICJ jurisdiction; martial law in
effect since 23 February 1991 military coup
Suffrage: 21 years of age; universal
Executive branch:
chief of state: King PHUMIPHON Adunyadet
(since 9 June 1946); Heir Apparent Crown
Prince WACHIRALONGKON (bom 28 July
1952)
head of government: Prime Minister CHUAN
Likphai (since 23 September 1992)
cabinet: Council of Ministers
Privy Council; NA
Legislative branch: bicameral National
Assembly (Rathasatha)
Senate ( Vuthisatha); consists of a 270-member
appointed body
House of RepresentativesiSaphaphoothan-
Rajsadhom): elections last held 1 3 September
1992 (next to be held by NA); results — percent
of vote by parly NA; seats — (360 total) DP 79.
TNP 77. NDP 60, NAP 5 1 . Phalang Tham 47.
SAP 22, LDP 8, SP 8, Mass Party 4. Thai
Citizen’s Party 3, People’s Party 1. People’s
Force Party 0
Judicial branch: Supreme Court (Samdika)
Political parties and leaders; Democrat
Party (DP). Chuan LIKPHAI; Thai Nation
Pary (TNP or Chat Thai Party), Banhan
SINLAPA-ACHA; National Development
Party (NDP or Chat Phattana), Chatchai
CHUNHAWAN; New A.spiration Party
(NAP). Gen. Chawalit YONGCHAIYUT;
Phalang Tham (Palang Dharma), Bunchu
ROTCHANASATIEN; Social Action Party
(SAP), Montri PHONGPHANIT; Liberal
Democratic Party (LDP or Seri Tham), Athit
URAIRAT; Solidarity Party (SP), Uthai
PHIMCHAICHON; Mass Party (Muanchon),
Pol, Cpt. Choem YUBAMRUNG; Thai
Citizen’s Party (Prachakon Thai). Samak
389
Thailand (continued)
SUNTHONWET; People’s P.''rty (Ratsadon),
Chaiphak SIRIWAT; People’> Force Party
(Phalang Prachachon), Col. Sophon
HANCHAREON
Member of: APEC. AsDB. ASEAN. CCC,
CP. ESCAP. FAO, G-77. GATT. IAEA.
IBRD, ICAO, ICFTU, IDA, IFAD, IFC, ILO,
IMF, IMO, INTELSAT, INTERPOL. IOC,
lOM, ISO, ITU, LORCS, NAM (observer),
PCA. UN, UNCTAD, UNESCO, UNHCR,
UNIDO, UNIKOM, UNTAC, UPU, WCL,
WFTU, WHO, WIPO, WMO
Diplomatic representation in US:
chief of mission: Ambas.sador
PHIRAPHONG Kasemsi
chancery: 2300 Kalorama Road NW,
Washington, DC 20008
telephone: (202) 483-7200
FAX: (202) 234-4498
consulate(s) general: Chicago, Los Angeles,
and New York
US dipiomatic representation:
chief of mission: Ambassador David F.
LAMBERTSON
embassy: 95 Wireless Road, Bangkok
mailing address: APO AP 96546
telephone; [66] (2) 252-5040
FAX: [66] (2) 254-2990
consulate(s) general; Chiang Mai
constilaie(s): Udom (Udon Thani)
Flag: five horizontal bands of red (top), white,
blue (double width), white, and red
Names:
conventional long form: The Former Y ugoslav
Republic of Macedonia
conventional short form: none
local long form: Republika Makedonija
local short form: Makedonija
Abbreviation: F.Y.R.O.M.
Digraph; MK
Type: emerging democracy
Capital: Skopje
Administrative divisions: 34 counties
(opstinas, singular — opstina) Berovo, Bilola,
Brod, Debar, Delcevo, Gevgelija, Gostivar,
Kavadarci. Kicevo. Kocani, Kratovo, Kriva
Palanka, Krusevo, Kumanovo, Murgasevo,
Negotino, Ohrid, Prilep. Probistip. Radovis,
Resen, Skopje-Centar, Skopje-Cair. Skopje-
Karpos, Skopje-Kisela Voda. Skopje-Gazi
Baba, Stip. Struga. Strumica, Sveti Nikolc,
Tetovo, Titov Velcs, Valandovo, Vinica
independence: 17 September 1991 (from
Yugoslavia)
National holiday: NA
Constitution: adopted 17 November 1991.
effective 20 November 1991
Legal system: based on civil law system;
judicial review of legislative acts
SulTfage: 18 years of age; universal
Executive branch:
chief of state: President Kiro GLIGOROV
(since 27 January 1991): election last held 27
January 1991 (next to be held NA); results—
Kiro GLIGOROV was elected by the
.Assembly
head of government: Prime Minister Branko
CRVENKOVSKI (since 4 September 1992).
Deputy Prime Ministers Jovan ANIXJNOV
(since NA March 1991 ), Risto IVANOV (since
NA), and BecirZUTA (since NA March 1991)
cabinet: Council of Ministers; elected by the
majority vote of all the deputies in the Sobranje
Legislative branch: unicameral
Assembly (Sobranje): elections last held 1 1
and 25 November and 9 December 1990 (next
to be held November 1994): results — percent
of vote by patty NA: seats — (120 total)
VMRO-DPMNE 32. SDSM 29, PDPM 23,
SRSM 19. SPM 4. DP 4. SJM 2. others 7
Judicial branch: Constitutional Court,
Judicial Court of the Republic
Political parties and leiulers: Social-
Democratic Alliance of Macedonia (SDSM;
former Communist Party). Branko
CRVENKOVSKI. president: Party for
Democratic Prosperity (PDPM); National
Democratic Party (PDP). Ilijas HALlNi.
president; Alliance of Reform Forces of
Macedonia— Liberal Party (SRSM-LP). Stojan
ANDOV, president; Socialist Party of
Macedonia (SPM). Kiro POPOVSKl.
president; Internal Macedonian Revolutionary
Organization — Democratic Party for
Macedonian National Unity (VMRO-
DPMNE). Ljupco GEORGIEVSKl. president;
Party of Yugoslavs in Macedonia (SJM). Milan
DURCINOV. president; Democratic Party
(DP). Petal GOSEV. president
Other political or pressure groups:
Movement for All Macedonian Action
(MAAK); Democratic Party of Serbs:
Democratic Party of Turks; Party for
Democratic Action (Slavic Muslim)
Member of: CE (guest), CSCE (observer),
EBRD. ECE. ICAO, ILO, IMF, INTELSAT
(nonsignatory user), ITU. UN, UNCTAD,
UNESCO. UNIDO. UPU. WHO. WIPO.
WMO
Diplomatic representation in US: the US
recognized The Former Yugoslav Republic of
Macedonia on 9 February 1 994
US diplomatic representation: the US
recognized The Former Yugoslav Republic of
Macedonia on 9 February 1994
Flag: 16-point gold sun (Vergina. Sun)
centered on a red field','26585a7439290e6556b0e19ca652df5fc96895fb2c5297250a7d848566658b6b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f809d76029ea81fe1bfa784c156ef5a203d89bd6cb39c57321a8c0c2ec017cd',1994,'CM','Cameroon','government',200,'Names;
conventional longjdrrn: Republic of
conventional short form: Cameroon
former: French Cameroon
Digraph: CM
Type: unitary republic: multiparty
presidential regime (opposition parties
legalized 1990)
Capital; Yaounde
Administrative divisions: 10 provinces:
Adamauua. Centre. Est, Extreme-Nord.
Littoral, Nord, Nord-Ouest. Quest, Sud,
Sud-Ouest
Independence: I January I960 (from UN
trusteeship under French administration)
National holiday: National Day, 20 May
(1972)
Constitution: 20 May 1972
Legal system: ba.sed on French cit 11 law
system, with common law influence; has not
accepted compulsory ICJ Jurisdiction
Suninge: 20 years of age; universal
Executive branch:
chief of state: President Paul BIYA (since 6
November 1982); election last held 1 1 October
1992; results — President Paul BIYA reelected
with about 40% of the vote amid widespread
allegations of fraud; SDF candidate John FRU
NDI got 36% of the vote; UNDP candidate
Bello Bouba MAIGARI got 19% of the vote
head of government: Prime Minister Simon
ACHIDI ACHU (since 9 April 1992)
cabinet: Cabinet; appointed by the president
Legislative branch: unicameral
National Assembly (Assemblee Nationale):
elections last held I March 1992 (next
scheduled for March 1997); result.s — (180
seats) CPDM 88. UNDP 68. UPC 18. MDR 6
Judicial branch: Supreme Court
Polillcal parlies and leaders: Cameroon
People''s Democratic Movement (CPDM).
Paul BIYA, president, is
government-controlled and was formerly the
only party, but opposition patties were
legalized in 1990
major opposition parties: National Union for
Democracy and Pwgress (UNDP); Social
Democratic Front (SDF); Cameroonian
DemiKiatic Union (UDC); Union of
Cameroonian Populations (UPC)
Other political or pressure groups; NA
Member of: ACCT, ACP. AtDB. BDEAC,
CCC. CEEAC. ECA. FAQ. FZ. G-19. G-77,
GATT. IAEA. IBRD, ICAO, ICC. ICFTU.
IDA, IDB, IFAD. IFC, ILO. IMF, IMO,
INMARSAT, INTELSAT, INTERPOL, IOC,
ITU, LORCS. NAM. OAU. OIC, PCA,
UDEAC, UN. UNCTAD. UNESCO. UNIDO.
UNTAC, UPU, WCL. WHO. WIPO, WMO.
WTO
Diplomatic representation in US:
chief of mission: Ambassador Jerome
MENDOUGA
choncerv: 2349 Massachusetts Avenue NW,
Washington. DC 2(XX)8
telephone: (202) 265-8790 through 8794
US diplomatic representation:
chief of mission: Ambassador Harriet ISOM
embassy: Rue Nachtigal, Yaounde
mailing address: B. P. 817, Yaounde
telephone: 1237] 23-40-14 and 23-05-12
FAX: [237] 23-07-.i3
eonsalale(s): none (Douala closed July 1993)
Flag: three equal vertical bands of green
71
Cameroon (continued)
(hoisi side), red, and yellow with a yellow
five-pointed star centered in the red band; uses
the popular pan-African colors of Etiiiopia
Names:
conventional long form: Federal Republic of','8ab7d342c6670a025073cc2176874e16ab0113a4053a7050b109fb0949e4f1e0','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88b0850a8404678f5294f9efcbbc936a8c0d765fceda6333e5a02d8f93fa02f2',1994,'CA','Canada','government',205,'Names:
conventional long form: none
conventional short form: Canada
Digraph; CA
Type: confederation with parliamentary
democracy
Capital: Ottawa
Administrative divisions: 1 0 provinces and 2
territories*; Alberta, British Columbia,
Manitoba, New Brunswick, Newfoundland,
Northwest Territories*. Nova Scotia, Ontario.
Prince Edward Island, Quebec, Saskatchewan,
Yukon Territory*
Independence: 1 July 1867 (from UK)
National holiday: Canada Day, I July ( 1 867)
Constitution; amended British North
America Act 1 867 patriated to Canada 17 April
1982; charier of rights and unwritten customs
Legal system: based on English common law,
except in Quebec, where civil law system
based on French law prevails; accepts
compulsory ICJ jurisdiction, with reservations
Suffrage: 18 years of age; universal
Executive branch;
chief of state: Queen ELIZABETH II (since 6
February 1952), repre.sented by Governor
General Raymond John HNATYSHYN (since
29 January 1990)
head of government: Prime Minister Jean
CHRETIEN (since 4 November 1993) was
elected on 25 October 1993, replacing Kim
CAMBELL; Deputy Prime Minister Sheila
COPPS
cabinet: Federal Ministry; chosen by the prime
minister from members of his own party sitting
in Parliament
Legislative branch: bicameral Parliament
(Parlement)
Senate (Senat); consisting of a body whose
members are appointed to serve until 75 years
of age by the governor general and selected on
the advice of the prime minister; its normal
limit 104 senators
House of Commons ( Cbanihre des
Communes): elections last held 25 October
1993 (next to be held by NA October 1998):
results — number of votes by percent NA;
scats — (295 total) Liberal Party 178, Bloc
Quebecois 54. Reform Party 52, New
Democratic Party 8. Progressive Conservative
Party 2, independents 1
Judicial branch: .Supreme Court
Political parties and leaders: Liberal Party.
Jean CHRETIEN: Bkx: Quebecois. Lucien
BOUCHARD; Reform Party, Preston
MANNING; New Democratic Party, Audrey
McLAUGHLIN; Progressive Conservative
Party, Jean CHAREST
Member of: ACCT, AfDB. AG (observer),
APEC. AsDB. Australia Group, BIS, C, CCC.
CDB (non-regional), COCOM, CSCE. EBRD.
ECE. ECLAC. ESA (cooperating state). FAO,
G-7. 0-8, G-IO, GATT. lADB. IAEA. IBRD.
ICAO, ICC, ICFTU. IDA, lEA, IFAD, IFC.
ILO, IMF, IMO. INMARSAT. INTELSAT,
INTERPOL. IOC, lOM, ISO, ITU. LORCS,
MINURSO. MTCR. NACC. NAM (guest).
NATO. NEA, NSG. OAS, OECD, ONUSAL.
PCA. UN. UNAVEM II, UNCTAD. UNDOF.
UNESCO. UNFICYP. UNHCR, UNIDO,
UNI ROM. UNOMOZ. UNOMUR.
UNPROFOR, UNTAC. UNTSO. UPU. WCL.
WHO. WMO, WIPO, WTO, ZC
73
Canada (continued)
Diplomatic representation in US:
chief of mission: Ambussiidor Rnyniond
CHRETIEN
chancery: 501 Pennsylvania Avenue NW,
Washington, DC 2(XK)I
telephone: (2()2) 682-1740
FAX. (202) 682-7726
consulale(s) general: Atlanta, Boston,
Buffalo, Chicago, Dallas, Detroit, Los
Angeles, Minneapolis, New York,
Philadelphia, and Seattle
consulalc(s): Cincinnati, Cleveland, Miami,
Pittsburg, Princeton, San Diego, San
Francisco, and San Juan (Puerto Rico)
US diplomatic representation:
chief ofnii.ssion: Ambassador Janies Johnston
BLANCHARD
emhas.sy: l(K) Wellington Street, K 1 P 5T I ,
Ottawa
mail inf! address: P. O, Box 5(KK),Ogdensburg,
NY l.^669-(M,M)
telephone: (6 1 ,5) 2.18-5.535 or 4470
FAX: (613)238-5720
con.\\ulalels) peneral: Calgary. Halifax.
Montreal, Quebec, Toronto, and Vancouver
Flag: three vertical bands of red (hoist side),
white (double width, square), and red with a
red maple leaf centered in the white band
Names:
conventional long form: Republic of Cape
Verde
conventional short form: Cape Verde
local long form: Republica de Cabo Verde
local short form: Cabo Verde
Digraph: CV
Type: republic
Capital: Praia
Administrative divisions: 14 districts
(concelhos, singular — concelho); Boa Vista.
Brava, Fogo, Maio. Paul, Praia, Porto Novo.
Ribeira Grande. Sat. Santa Catarina. Santa
Cruz., Sao Nicolau. Sao Vicente, Tarrafal
Independence: 5 July 1975 (from Portugal)
National holiday: Independence Day. 5 July
(1975)
Constitution: new constitution came into
force 25 September 1992
Legal system; NA
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Antonio
MASCARENHAS Monteiro (since 22 March
1991) election last held 1 7 February 1 99 1 (next
to be held February 1996); results — Antonio
Monteiro MASCARENHAS (independent)
received 72.6% of vote
head of government: Prime Minister Carlos
Alberto Wahnon de Carvalho VEIGA (since
13 lanuary 1991);
cabinet: Council of Ministers; appointed by
prime minister from members of the Assembly
Legislative branch: unicameral
People ''s National Assembly (Assembleia Na-
cional Popular): elections last held 13 January
1991 (next to be held January 1996); results —
percent of vote by party NA; seats — (79 total)
MPD 56, PAICV 23; note — this multiparty
Assembly election ended 15 years of
single-party rule
Judicial branch: Supreme Tribunal of Justice
(Supremo Tribunal de Justia)
Political parties and leaders: Movement for
Democracy (MPD). Prime Minister Carlos
VEIGA, founder and chairman: African Party
for Independence of Cape Verde (PAICV),
Pedro Verona Rodrigues PIRES, chairman
Member of: ACP, AfDB. CCC. ECA.
ECOWAS, FAO. G-77. IBRD, ICAO. ICFTU,
IDA. IFAD, IFC, ILO. IMF. IMO,
INTELSAT. INTERPOL. lOM (observer).
ITU, LORCS. NAM. OAU. UN (Cape Verde
assumed a nonpemianent seat on the Security
Council on 1 January 1992). UNCTAD.
UNESCO, UNIDO. UNOMOZ, UPU, WCL,
WHO. WMO
Diplomatic representation in US;
chief of mission: Ambassador Carlos Alberto
Santos SILVA
chancery: 3415 Massachusetts Avenue NW,
Washington, DC 20007
telephone: (202) 965-6820
FAX.- (202) 965-1207
consulaie{s) general: Boston
US diplomatic representation:
chief of mission: Ambassador Joseph M.
SEGARS
embassy: Rua Hoji Ya Henda 81, Praia
mailing address: C. P. 201, Praia
telephone: 1238] 61-56-16 or 61-56-17
FAX: 12.38)61-13-55
Flag: three horozontal bands of light blue
(top. double width), white (with a horozontal
red stripe in the middle third), and light blue; a
circle of 10 yellow five pointed stars is
centered on the hoist end of the red stripe and
extends into the upper and lower blue bands','1f4749061b77580ef3ea209d8504aecbeaa1c8acdd89d529ef3a44cbf1df5f02','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5dcc9c884fb0463f9d429403a5aa2becbee4dc84ec6b08c995caff356df768fa',1994,'KY','Cayman Islands','government',214,'Names;
conventional loiift form: none
conventional short form: Cayman Islands
Digraph: CJ
Type: dependent territory of the UK
Capital: George Town
Administrative divisions; 8 districts: Creek.
Eastern. Midland. South Town. Spot Bay.
Stake Bay, West End, Western
Independence: none (dependent territory of
the UK)
National holiday: Constitution Day (first
Monday in July)
Constitution: 1959, revised 1972 and 1992
Legal system: British common law and local
statutes
Suffrage: 1 8 years of age: universal
Executive branch:
chief of .state: Queen ELIZABETH II (since 6
February 1952)
head of government: Governor and President
of the Executive Council Michael GORE
(since 15 September 1992)
cabinet: Executive Council; 3 members are
appointed by the governor. 4 members elected
by the Legislative Assembly
Legislative branch: unicameral
Legislative A.s.semhly: election last held
November 1992 (next to be held November
1996): results — percent of vole by party NA;
seats — (15 total. 12 elected)
Judicial branch: Grand Court. Cayman
Islands Court of Appeal
Political parties and leaders: no formal
political parties
Member of: CARICOM (observer). CDB,
INTERPOL (subbureau). IOC
Diplomatic representation in L''S: none
(dependent territory of the UK)
US diplomatie representation: none
(dependent territory of the UK)
Flag: blue, with the flag of the UK in the
upper hoist-side quadrant and the Caymanian
coat of arms on a white disk centered on the
outer half of the flag; the coat of arms includes
a pineapple and turtle above a shield with three
stars (representing the three islands) and a
scroll at the bottom bearing the motto HE
HATH FOUNDED IT UPON THE SEAS','36120fe6ba536ca51502ae43871386c2774e64944613dd2403352cb06549414f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a585392af3fd590337bd4d8181f7bb0ba70d4632dbc3ab86c2ab82dbbefe61ab',1994,'CF','Central African Republic','government',218,'Names;
conventional longfonn: Central African
Republic
conventional short form: none
local lonti form: Republique Centrafricaine
local shtirt Jbrm: none
former: Central African Empire
Abbreviation: CAR
Digraph: CT
Type; republic; one-party presidential regime
since 1986
Capital: Bangui
Administrative divisions: 14 prefectures
(prefectures, singular — prefecture), 2
economic prefectures* (prefectures
economiques. singular — prefecture
cconomique), and I commune**:
Bumingui-Bangoran, Bangui** Ba.sse-Kotto,
Gribingui*. Haute-Kotto. Haute-Sungha, Haut-
Mbomou. Kemo-Gribingui, Lobaye, Mbomou.
Nana-Mambere. Ombella-Mpoko, Ouaka.
Ouham, Ouham-Pcndc. Sangha*. Vakaga
Independence; 13 August I960 (from
France)
National holiday; National Day, I December
(1958) (proclamation of the republic)
Constitution: 2 1 November 1 986
Legal system: based on French law
Suffrage: 2 1 years of age; universal
Executive branch:
chief of state: President Felix (Ange)
PATASSE (since 22 October 1993) election
last held 19 September 1993; PATASSE
received 52.45% of the votes and Abel
GOUMBA received 45.62%; next election
scheduled for 1998
head of government: Prime Minister
Dr. Jean-Luc MANDABA (since 25 October
1993)
cabinet: Council of Ministers; appointed by
the president
Legislative branch: unicameral
National Assembly (Assetnblee Nationale):
elections last held 19 September 1993;
results — percentage vote by party NA; seatst —
(85 total) MLPC 33, RDC 14, PLD 7, ADP 6.
PSD 3. others 22
note: the National Assembly is advised by the
Economic and Regional Council (Coiiseil
Economique et Regional); when they sit
together they are called the Congress
(Congres)
Judicial branch: Supreme Court (Cour
Supreme)
Political parties and leaders: Movement for
the Liberation of the Central Africun People
(MLPC). the party of the new president. Ange
Felix PATASSE: Central African Democratic
Pany (RDC). Laurent GOMINA-PAMPALI;
Council of Moderates Coalition includes;
Union of the People for Economic and Social
Development (UPDS), Katossy SlMANl;
Liberal Republican Party (PARELI), .Augustin
M''BOE; Centrul African Socialist Movement
(MSCA). Michel BENGUE; Concerted
Democratic Forces (CFD), a coalition of 13
parties, including; Alliance for Democracy and
Progress (ADP), Francois PEHOUA; Central
African Republican party (PRC). Ruth
ROLLAND; Social Democratic Party (PSD),
Enoch DERANT-LAKOUE; Civic Forum
(FC), Gen. Timothee MALENDOMA; Liberal
Democratic Party (PLD), Nestor
KOMBOT-NAGUEMON; Movement for the
Liberation of the Central African People
(MLPC). Felix (Ange) PATASSE
Member of: ACCT, ACP. AfDB, BDEAC.
CCC. CEEAC, ECA, FAO. FZ. G-77, GATT,
IBRD. ICAO. IDA. IFAD. IFC. ILO. IMF.
INTELSAT. INTERPOL, IOC. ITU, LORCS.
NAM, OAU, UDEAC, UN. UNCTAD.
UNESCO, UNIDO. UPU, WCL, WHO,
WIPO. WMO
Diplomatic representation in US:
chief of mission: Ambassador Henri KOBA
chancerv: 1618 22nd Street NW. Wa.shington,
DC 2(X)08
telephone: (202) 483-78(K) or 7801
US diplomatic representation:
chief of mission: Ambassador Robert E.
GRiBBIN
78','0b3429185acbb481ba7432b06d65be00873675fcef1f2c6927f63a7614bb2293','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd1151510611c88cc1a5eb7649d7b899197fc228c1a24086caa02689e0c33998',1994,'TD','Chad','government',219,'embassy: Avenue David Dacko, Bangui
moiling address; B, P. 924, Bangui
telephone: [236] 61-02-00, 61-25-78,
61-43-33,61-02-10
FAX; [236] 61-44-94
Flag: four equal horizontal bands of blue
(top), white, green, and yellow with a vertical
red band in center; there is a vellow
five-pointed star on the hoist side of the blue
band','aa737a0cbb00ecb56ac5a7ede943aa7f05e21c12b6d600074f82596b87e15ee6','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b92146306a1bc655ec9e3b9763dc8bca4a60af5322c74203499fa70894e6762',1994,'NG','Nigeria','government',226,'Names;
conventional long form: Republic of Chad
conventional short form: Chad
local long form: Republique du Tchad
local short form: Tchad
Digraph: CD
Type: republic
Capital: N''Djamena
Administrative divisions; 14 prefectures
(prefectures, singular — prefecture): Batha,
Biltine, Borkou-Ennedi-Tibesti,
Chari-Baguirmi, Guera. Kunem, Lac, Logone
Occidental, Logone Oriental, Mayo-Kcbbi,
Moyen-Chari, Ouaddai, Salamat. Tandjile
Independence: 1 1 August 1 960 (from
France)
National holiday: Independence Day 1 1
August (1960)
Constitution: 22 December 1 989. suspended
3 December 1990; Provisional National
Charter I March 1991: constitutional
commission drafting new constitution to
submit to transitional parliament for
ratification in April 1994
Legal system; based on French civil law
system and Chadian customary law: has not
accepted compulsory ICJ jurit^iction
Suffrage: universal at age NA
Executive branch:
chief of stale: President Col. Idriss DEB Y.
since 4 December 1 990 (after seizing power on
3 December 1990 — transitional government''s
mandate expires April 1995)
head of government: Prime Minister Kassire
Delwa KOUMAKOYE (since 17 November
1993)
cabinet: Council of State; appointed by the
president on recommendation of the prime
minister
Legislative branch: unicameral
National Consulutiive Council IConceil
National Consulialif): elections last held 8
July 1990; disbanded 3 December 1990 and
replaced by the Provisional Council of the
Republic having 30 members appointed by
President DEBY on 8 MuK-h 1991 ; this, in turn,
was replaced by a 57-member Higher
Transitional Council (Conseil Supericur de
Transition) elected by a specially convened
Sovereign National Conference on 6 April
1993
Judicial branch: Court of Appeal
Political parties and leaders; Pairiotic
Salvation Movement (MPS; fontier dissident
group), Idriss DEBY, chairman
note: President DEBY, who promised political
pluralism, a new constitution, and free
elections by April 1994, has po.siponed these
initiatives for another year; there are numerous
dissident groups and 26 opposition political
parties
Other political or pressure groups; NA
Member of: ACCT. ACP. AfDB. BDEAC.
CEEAC. ECA, FAO, FZ. G-77. GATT, IBRD.
ICAO. ICFTU, IDA. IDB. IFAD, ILO, IMF.
INTELSAT. INTERPOL. IOC. ITU, LORCS.
NAM. OAU. OIC. UDEAC. UN. UNCTAD.
UNESCO, UNIDO. UPU. WCL, WHO.
WIPO. WMO. WTO
Diplomatic representation in US:
chief of mission: (vacant); Ambassador
KOUMBARIA Laoumaye Mekonyo died on
1 6 May 1994
chancen: 2(X)2 R Street NW. Washington, DC
20(X)9
telephone: (202) 462-4009
FAX: (202) 265-1937
US diplomatic representation;
chief of mission: Ambassador Lawrence POPE
embassy: Avenue Felix Eboue, N''Djamena
mailing address: B. P. 413, N’Djamena
telephone: [235] (5 1 ) 62- 1 8, 40-09, or 62- 1 1
MX.’ [2351(51) 33-72
Flag: three equal vertical bands of blue (hoist
side), yellow, and red; similar to the flag of
Romania; also similar to the flag of Andorra,
which has a national coat of arms featuring a
quartered shield centered in the yellow band;
design was based on the flag of France
Imports: $63.5 million (f.o.b., 1991 est.)
commodities: foodstuffs, transport equipment,
petroleum products, machinery and equipment
partners: Portugal, Netherlands, China,
Gennany, Senegal
External debt: $462 million (December 1 990
est.)
Industrial production: growth rate 0. 1 %
(1991 est.); accounts for 5% of GDP
Electricity:
capacity: 22,000 kW
production: 30 million kWh
consumption per capita: 30 kWh ( 1991 )
Industries: agricultural processing, beer, soft
drinks
Agriculture: accounts for over 45% of GDP,
nearly 100% of exports, and 90% of
employment; rice is the staple food; other crops
include com. beans, cassava, cashew nuts,
peanuts, palm kernels, and cotton; not self-
sufficient in food; fishing and forestry potential
not fully exploited
Economic aid:
recipient: US commitments, including Ex-lm
(FY70-89), $49 million: Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $615 million; OPEC
bilateral aid (1979-89), $41 million;
Communist countries (1970-89). $68 million
Currency: 1 Guinea-Bissauan peso (PG) =
100 centavos
Exchange rates: Guinea-Bissauan pesos
(PG) per US$1— 1 1,850 (December 1993),
10.082 ( 1993), 6,9.34 (1992), .3,6.59 ( 1991 ),
2,185 (1990), 1,810(1989)
Fiscal year: calendar year
Names:
conventional long farm: Co-operative
Republic of Guyana
conventional short form: Guyana
former: British Guiana
Digraph: GY
Type: republic
Capital; Georgetown
Administrative divisions: 10 regions:
Barima-Waini, Cuyuni-Mazaruni, Demerara-
Muhuica. East Berbice-Corentyne, Essequibo
Islands-West Demerara. Mahaica-Berbice,
Potneroon-Supenaam. Potaro-.Siparuni, Upper
Demerara-Berbice, Upper Takutu-Upper
Essequtbo
Independence; 26 May 1966 (from UK)
National holiday; Republic Day. 23 February
(1970)
Constitution; 6 October 1980
Legal system: based on English common law
with certain admixtures of Roman-Dutch law;
has not accepted compulsory ICJ jurisdiction
Suffrage: 1 8 years of age; universal
Executive branch:
chief of slate: Executive President Cheddi
JAGAN (since 5 October 1992); First Vice
President Sam HINDS (since 5 October 1992);
election last held on 5 October 1992; results —
Cheddi JAGAN was elected president since he
was leader of the party with the most votes in
the National Assembly elections
head of government: Prime Minister Sam
HINDS (since 5 October 1992)
cabinet: Cabinet of Ministers; appointed by the
president, responsible to the legislature
Legislative branch: unicameral
National A.\\.sembly: elections last held on 5
October 1992 (next to be held in 1997);
results— PPP .53.4%, PNC 42.3%. WPA 2%.
TUF 1 .2%; seats — (65 total, 53 elected) PPP
36, PNC 26, WPA 2, TUF 1
Judicial branch: Supreme Court of
Judicature
Political parties and leaders: People''s
Progressive Party (PPP). Cheddi JAGAN:
People''s National Congress (PNC), Hugh
Desmond HOYTE; Working People''s Alliance
(WPA), Eusi KWAYANA. Rupert
RCXJPNARINE; Democratic Labor
Movement (DLM). Paul TENNASSEE:
People''s Democratic Movement (PDM).
Llewellyn JOHN; National Democratic Front
(NDF), Joseph BACCHUS; The United Force
(TUF), Manzoor NADIR; United Republican
Party (URP), Leslie RAMSAMMY; National
Republican Party (NRP), Robert
GANGADEEN: Guyana Utbor Party (GLP).
Nanda GOPAUL
Other political or pressure groups: Trades
Union Congress (TUC); Guyana Council of
Indian Organizations (GCIO); Civil Liberties
Action Committee (CLAC)
note: the latter two organizations are small and
active but not well organized
Member of: ACP, C. CARICOM. CCC,
CDB, ECLAC. FAO. G-77, GATT. lADB,
IBRD, ICAO. ICFTU. IDA. IFAD, IFC. ILO.
IMF, IMO, INTELSAT (nonsignatory user),
INTERPOL. IOC, ITU. LAES. LORCS,
NAM, OAS. ONUSAL. UN. UNCTAD.
UNESCO. UNIDO. UPU, WCL, WFTU,
WHO. WMO
Diplomatic representation in US:
chief of mission: Ambassador Dr. Ali Odeen
ISHMAEL
chancery: 249(ITracy Place NW. Washington,
DC 20()()8
telephone: (202) 265-6900 through 6903
US diplomatic representation:
chief of mission: Ambassador George F. Jones
embassy: 99-100 Young and Duke Streets,
Kingstown, Georgetown
mailing address: P. O. Box 10507,
Georgetown
telephone: [592 1 (2) 549(X) through 54909 and
57960 llitough 57969
FAX: [.592] (2) 58497
Flag: green with a red isosceles triangle
(based on the hoist side) superimposed on a
long yellow arrowhead; there is a narrow black
border between the red and yellow, and a
narrow white border between the yellow and
the green
conventional short form: Nigeria
Digraph: NI
Type: military government since 3 1
December 1983; plans to institute a
constitutional conference to prepare for a new
transition to civilian rule after plans for a
transition in 1993 were negated by General
BABANGIDA
Capital: Abuja
note: on 12 December 1991 the capital was
officially moved from Lagos to Abuja; many
government offtces remain in Lagos pending
completion of facilities in Abuja
Administrative divisions: 30 states and I
territory*; Abia, Abuja Capital Territory*.
Adamawa, Akwa Ibom, Anambra, Bauchi,
Benue, Bomo, Cross River, Delta, Edo, Enugu,
Imo, Jigawa, Kaduna, Kano, Katsina, Kebbi,
Kogi, Kwara, Lagos, Niger, Ogun, Ondo,
Osun. Oyo, Plateau, Rivers, Sokoto. Taraba,
Yobe
Independence: I October I960 (from UK)
National holiday: Independence Day, I
October (1960)
Constitution: 1979 constitution still in force;
plan for 1 989 constitution to take effect in 1993
was not implemented
Legal system: based on English common law,
Islamic law, and tribal law
Suffrage: 21 years of age; universal
Executive branch:
chief of state and head of government:
Chairman of the Provisional Ruling Council
and Commander in Chief of Armed Forces and
Defense Minister Gen. Sani ABACHA (since
17 November 1993): ''/ice-Chairman of the
Provisional Ruling Council Oladipo DIYA
(.since 17 November 1993)
cabinet: Federal Executive Council
Legislative branch: bicameral National
Assembly
Senate: suspended after coup of 17 November
1993
House of Representatives: suspended after
coup of 17 November 1993
Judicial branch: Supreme Court, Federal
Court of Appeal
Political parties and leaders:
note: two political party system suspended
after the coup of 17 November 1993
Member of: ACP. AfDB, C. CCC. ECA,
ECOWAS, FAO, G- 1 5, G- 1 9, G-24. G-77,
GATT. IAEA. IBRD, ICAO, ICC, IDA. IFAD,
IFC, ILO, IMO, IMF. INMARSAT.
INTELSAT, INTERPOL. IOC, ITU, LORCS,
MINURSO, NAM. OAU, OIC (observer),
OPEC, PCA. UN, UNAVEM, UNCTAD,
UNESCO. UNHCR. UNIDO. UNIKOM.
UNPROFOR, UNTAC, UPU. WCL. WHO.
WMO, WTO
Diplomatic representation in US:
chief of mission: Ambassador Zubair Mahmud
KAZAURE
chancery: 1333 16lh Street NW, Washington,
DC 200.36
telephone: (202)986-8400
consulaiels) general: New York
US diplomatic representation:
291
Nigeria (continued)
chief of mission; Ambassador Walter
CARRINGTON
embassy: 2 Eleke Crescent, Lagos
mailing address; P. O. Box 554, Lagos
telephone; [234] (1) 610050
FAX: [234] (1)610257
consulate(s) general: Kaduna
Flag: three equal vertical bands of green
(hoist side), white, and green','59f4a565f4a6dc2892b34a7160ca3b10def959cbe72a76bf2d8397eba9064b9f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c9433a247f77fc8d5294941ef7bff76668c7ed437ec0311a3a7747c1e1d956d',1994,'CL','Chile','government',233,'Names;
conventional long form: Republic of Chile
conventional .short form: Chile
l(Kal long form: Republica de Chile
liKol short form: Chile
Digraph: Cl
Type: republic
Capital: Santiago
Administrative divisions: 1 3 regions
81
Chile (continued)
(rcgiones, singular — region); Aisen del
General Carlos Ibanez del Campo,
Antofagasta. Araucania, Atacama, Bio-Bio.
Coquimbo, Libertador General Bernardo
O''Higgins, Los Lagos. Magallanes y de la
Antartica Chilena, Maule, Region
Metropolitana, Tarapaca, Valparaiso
note: the US does not recognize claims to','ae47b5f74225ed90230ced80f7e42a09962d02cec39010c680a1e4873f842ba4','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac79610b75d483c346323d3c1b6f0a3e0b7d47b8e1ca9f5ea3c701f4168a9dbf',1994,'MN','Mongolia','government',238,'Names:
conventional long form: People''s Republic of
Names:
conventional long form: none
conventional short form: Mongolia
local long form: none
local short form: Mongol Uls
former: Outer Mongolia
Digraph: MG
Type: republic
Capital: Ulaanbaatar
Administrative divisions: 18 provinces
(aymguud. singular — aymug) and 3
municipalities* (hutuud. singular — hot):
Arhangay, Bayanhongor, Bayan-Olgiy,
Bu''.gan. Durban*. Doniod. Dornogovi,
Dundgovi. Dzavhan. Erdenet*. Govi-Altay,
Hentiy. Hovd. Hovsgol. Omnogovi,
Ovorhangay. Selenge, Suhbuutur, Tov,
Ulaanbaatar*. Uvs
Independence: 13 Muroh 1921 (from China)
National holidav: National Day. 1 1 July
(1921)
Constitution: adopted 13 January 1992
Legal system: blend of Russian, Chinese, and
Turkish systems of law; no constitutional
provision for judicial review of legislative acts;
has not accepted compulsory ICJ jurisdiction
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: President Punsalmaagiyn
OCHIRBAT (since 3 September 1990);
election last held 6 June 1993 (next to be held
NA 1997); results — Punsalmaagiyn
OCHIRBAT (MNDP and MSDP) elected
directly with 57.8% of the vote; other
candidate Lodongiyn TUDEV (MPRP)
head of government: Prime Minister Putsagiyn
JASRAY (since 3 August 1992); Deputy Prime
Ministers Lhamsuren ENEBISH and
Choijilsurengiyn PUREVDORJ (since NA)
cabinet: Cabinet; appointed by the Great Hural
Legislative branch: unicameral
State Great Hural: elections first time held 28
June 1992 (next to be held NA); re.sults —
percent of vote by party NA; seats — (76 total)
MPRP 71. United Party 4. MSDP 1
note: the People’s Small Hural no longer exists
Judicial branch: Supreme Court serves as
appeals court for people’s and provincial
courts, but to date rarely overturns verdicts of
lower courts
Political parties and leaders: Mongolian
People''s Revolutionary Party (MPRP),
Budragehagiin DASH-YONDON, secretary
general; Mongolian Democratic Party (MDP).
Erdenijiyn BAT-UUL, general coordinator:
National Progress Party (NPP), S. B Y AMB AA
and Luusandambyn DASHNYAM, leaders;
Social Democratic Party (SDP), BATE AVAR
and Tsohiogyyn ADYASUREN. leaders;
Mongolian Independence Party (MIP). D.
ZORIGT. leader; United Party of Mongolia
(made up of the MDP, SDP. and NPP);
Mongolian National Democratic Party
(MNDP), D. GANBOLD, chairman;
Mongolian Social Democratic Party (MSDP),
B. BATBAYAR. chairman; Mongolian
Conservative Party, O. ZOYA; Mongolian
Green Party (MGP), M. GANBAT
note: opposition parties were legalized in May
1990
Member of: AsDB, CCC, ESCAP. FAO.
G-77, IAEA, IBRD, ICAO, IDA, IFC. ILO,
IMF. INTELSAT (nonsignatory user),
INTERPOL, IOC. ISO, ITU, LORCS. NAM
(observer), UN. UNCTAD. UNESCO.
UNIDO. UPU, WFTU, WHO, WIPO. WMO,
WTO
Diplomatic representation in US:
chief of mission: Ambassador Luvsandorj
DAWAGIV
chancerv: 2833 M Street NW, Washington,
DC 2(X)07
telephone: (202) .333-71 17
FAX: (202) 298-9227
consulate! s) general: New York
US diplomatic representation:
chief of mission: Ambassador Donald C.
JOHNSON
embassy: address NA, Ulaanbaatar
mailing address; Ulaanbaatar, c/o American
Embassy Beijing, Micro Region II, Big Ring
Road; PSC 46 1 , Box 300, FPO AP 9652 1 -0002
telephone; (976| (I) 329095 through 329606
FAX'' [976] (1)320-776
Flag: three equal, vertical bands of red (hoist
side), blue, and red, centered on the hoist-side
red band in yellow is the national emblem
("soyombo" — a columnar arrangement of
abstract and geometric representation for fire,
sun, moon, earth, water, and the yin-yang
symbol)','39b36b41d88aa2283f63f43ce1ade07d2a3f5048a22d74032d0f71eeb329e44b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc6cf0c0b9701cd32f4cfffd807dc3e49730dcac9fa7aae54a808ee872db740b',1994,'CN','China','government',239,'conventional short form: China
local long form: Zhonghua Renmin
Gongheguo
l(K''al short form: Ziiong Guo
Abbreviation: PRC
Digraph: CH
Type: Communist state
Capital: Beijing
Administrative divisions: 2.^ provinces
(sheng, singular and plural), 5 autonomous
regions* (zizhiqu. singular and plural), and
municipalities** (shi, singular .and plural);
Anhui, Beijing Shi**. Fujian Gansu,
Guangdong, Guangxi*, Guizhou. Hainan.
Hebei, Heilongjiang, Henan, Hubei, Hunan,
Jiangsu, Jiangxi, Jilin. Liaoning, Nei Mongol*,
Ningxia*, Qinghai, Shaanxi, Shandong,
Shanghai Shi**, Shanxi, Sichuan, Tianjin
Shi**, Xinjiang*. Xizang* (Tibet), Yunnan,
Zhejiang
note: China i ..msiders Taiwan its 2.^rti
province
Independence; 221 BC (unification underthc
Qin or Ch''in Dynasty 221 BC; Qing or Ch’ing
Dynasty replaced by the Republic on 1 2
February 1912; People''s Republic established
1 October 1949)
National holiday: National Day, I October
(1949)
Coastitution; most recent promulgated 4
December 1982
Legal system: a complex amalgam of custom
and statute, largely criminal law; rudimentary
civil code in effect since 1 January 1987; new
legal codes in effect since 1 January 1980;
continuing efforts are being made to improve
civil, administnitive, criminal, and commercial
law
Suffrage: 1 8 years of age; universal
Executive branch;
chief of state: President JIANG Zemin (since
27 March 199.7); Vice President RONG Yiren
(since 27 March 199.7); election la.st held 27
March 199.7 (next to be held NA 1998);
results — JIANG Zemin was nominally elected
by the Eighth National People''s Congress
chief of state and head of government fde
facto): DENG Xiaoping (since NA 1977)
head of government: Premier LI Peng (Acting
Premier since 24 November 1987, Premier
since 9 April 1988) Vice Premier ZHU Rongji
(since 8 April 1991); Vice Premier ZOU Jiahua
(since 8 April 1991); Vice Premier QIAN
Qichen (since 29 March 199.7); Vice Premier
LI Lanqing (29 March 199.7)
enhinet: State Council; containing 28 ministers
and 8 state commissions and appointed hy the
National People’s Congress (March 1993)
Legislative branch: unicameral
National People''s Congress: (Quanguo
Renmin Daibiao Dahui) elections last held
March 199.7 (next to be held March 1998);
results — CCP is the only party but there are
also independents; seats — (2,977 total)
(elected at county or xian level)
Judicial branch: Supreme People''s Court
Political parties and leaders: Chine.se
Communist Party (CCP). JIANG Zemin,
general secretary of the central Committee
(since 24 June 1989); eight registered small
parties controlled by CCP
Other political or pressure groups: such
meaningful opposition as exists consists of
loose coalitions, usually within the party and
government organization, that vary by issue
Member of: AfDB, APEC. AsDB. CCC,
ESCAP, FAO, IAEA, IBRD. ICAO, ICFTU,
IDA. IFAD. IFC. ILO. IMF. IMO,
INMARSAT, INTELSAT, INTERPOL. IOC,
ISO, ITU, LORCS, MINURSO. NAM
(Observer). PCA, UN. UNCTAD. UNESCO.
UNHCR. UNIDO, UNIKOM. UN Security
Council, UNTAC, UNTSO, UN Trusteeship
Council. UPU, WHO. WIPO, WMO, WTO
Diplomatic representation in US:
chief of mission: Ambassador LI Daoyu
chancery: .2,7(X) Connecticut Avenue NW,
Washington, DC 20008
telephone: (202) 328-2500 through 2502
consulate! s) general: Chicago, Houston. Los
Angeles. New York, and San Francisco
US diplomatic representation:
chief of mission: Ambu.ssador J. Stapleton
ROY
embassy: Xiu Shui Bci Jic 3. Beijing
mailing address: 100600, PSC 461 . Box 50,
Beijing or FPO AP 9652 1 -0002
telephone: [86| ( I ) 532-38.7 1
MX.- [86 1(1). 5.72-3 1 78
consulate! s) general: Chengdu. Guangzhou.
Shanghai, Shenyang
Flag: red with a large yellow five-pointed star
and four smaller yellow five-pointed .stars
(arranged in a vertical arc toward the middle of
the flag) in the upper hoist-side comer','e4fe1e5464e965101097ccffdd6fd11b1dbcffa0ee90356bc951892c521576e7','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1db183a901f3838536f3d581540ad8ac09274d2260e72fadbb4e99c87dffce31',1994,'CX','Christmas Island','government',245,'Names:
conventional tong form: Territory of
conventional short form: Christmas Island
Digraph: KT
Type: territory of Australia
Capital: The Settlement
Administrative divisions: none (territory of
Australia)
Independence: none (territory of Australia)
National holiday: NA
Constitution: Christmas Island Act of 1958
Legal system: under the authority of the
governor general of Australia
Executive branch:
chief of state: Queen ELIZABETH II (since 6
February 1952)
head of government: Administrator M. J.
GRIMES (since NA)
cabinet: Advisory Council
Legislative branch; none
Judicial branch: none
Political parties and leaders: none
Member of: none
Diplomatic representation in US: none
(territory of Australia)
US diplomatic representation: none
(territory of Australia)
Flag: the flag of Australia is used
Names:
conventional long form: none
conventional short form: Clipperton Island
local long form: none
local short form: He Clipperton
former: sometimes called lie de la Passion
Digraph: IP
Type: French possession administered by
86
France from French Polynesia by High
Commissioner of the Republic
Capital: none; administered by France from','208fed7cf3f1582b7e3ee8939432a283322c5c0fbe7e13d7cec4192ae2ba9def','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6c05aa7da7bd0f7e94e75c24be4bbbfb3553ad41aff425743f901404a8f998f',1994,'PF','French Polynesia','government',247,'Independence: none (possession of France)
Names:
conventional long form: Territoiy of French
Polynesia
conwntional short form: French Polynesia
local long form: Territoire de la Polynesia
Francaise
ItHttl short form: Polynesie Francaise
Digraph: FP
Type: overseas territory of France since 1946
Capital: Papeete
Administrative divisions: none (overseas
territory of France); there are no first-order
administrative divisions as defined by the US
Government, but there arc 5 archipelagic
divisions named Archipel des Marquises,
Archipel des Tuamotu, .^rchipel des Tubuai.
lies du Vent, and lies Sous-le-Vent
note: Clipperion Island is administered by
France from French Polynesia
Independence: none (overseas territory of
France)
National holiday; National Day, Taking of
the Bastille, 14 July (1789)
Constitution: 28 September 1958 (French
Constitution)
Legal system: based on French system
SuffVage: 18 years of age; universal
Executive branch;
chief of state: President Francois
MITTERRAND (since 21 May 1981); High
Commissioner of the Republic Michel JAU
(since NA February 1992)
head of government: President of the
Territorial Government of French Polynesia
Gaston FLOSSE (.since 10 May 1991); Deputy
to the French Assembly and President of the
Territorial Assembly Jean JUVENTIN (since
NA November 1992); Territorial Vice
President and Minister of Health Michel
BUILLARD (since 12 September 1991)
cabinet: Council of Ministers; president
submits a list of members of the Assembly for
approval by them to serve as ministers
Legislative branch: unicameral
Territorial Assembly: elections last held 1 7
March 1991 (next to he held March 1996);
results — percent of vote by party NA; seats —
(41 total) People''s Rally for the Republic
(Gaullist) 1 8, Polynesian Union Party 1 2, New
Fatherland l4ity 7, other 4
French Senate: elections last held 24
September 1989 (next to be held September
1998); result!! — percent of vote by patty NA;
seats — (I total) party NA
French National Assembly: elections last held
21 and 28 March 1993 (next to be held NA
March 1998); results — percent of vote by party
NA; seats — (2 total) People’s Rally for the
Republic (Gaullist) 2
Judicial branch: Court of Appeal, Court of
the First Instance, Court of Administrative Law
Political parties and leaders: People''s
Rally for the Republic (Tahoeraa Huiraatira),
Gaston FLOSSE; Polynesian Union Party
includes Te Tiarama. Alexandre LEONTIEFF,
and Pupu Here Ai''a Te Nuneao la Ora, Jean
JUVEOTIN; New Fatherland Party (Ai’a Apt),
Emile VERNAUDON; Polynesian Liberation
Front (Tavini Huiraatira), Oscar TEMARU;
Independent Party (la Mana Te Nunaa), James
SALMON; other small parties
Member of: ESCAP (associate), FZ, ICFTU.
SPC, WMO
Diplomatic representation in US: none
(overseas territory of France)
US diplomatic representation: none
(overseas territory of France)
Flag: the flag of France is used
Names;
conventional long form: Territory of the
French Southern and Antarctic Lands
conventional short form; French Southern and
Antarctic Lands
local long form: Territoire des Terres
Australes et Antarctiques Francaises
local short form: Terres Australes et
Antarctiques Francaises
Digraph: FS
Type: overseas territory of France since 1955;
governed by High Administrator Bernard de
GOUTTES (since May 1990), who is assisted
by a 7-member Consultative Council and a 12-
member Scientific Council
Capital: none; administered from Paris,','88748a46229935c46e567ddf2c94735a5c4b9d2846df2dd90c8459bcc8f31756','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf48b030db5951e09b5610f955c9416e0003318bcec17d2929f7ac9d64ffd014',1994,'CC','Cocos (Keeling) Islands','government',254,'Names:
conventional long form: Territory of Cocos
(Keeling) Islands
conventional short form: Cocos (Keeling)
Islands
Digraph: CK
Type; territory of Australia
Capital: West Island
Administrative divisions: none (territory of
Australia)
Independence: none (territory of Australia)
National holiday: NA
Constitution: Cocos (Keeling) Islands Act of
1955
Legal system: based upon the laws of
Australia and local laws
SuITrage: NA
Executive branch:
chief of state: Queen ELIZABETH II (since 6
February 1952)
head of government: Administrator B.
CUNNINGHAM (since NA)
cabinet: Islands Council; Chairman of the
Islands Council Haji WAHIN bin Bynie (since
NA)
Legislative branch: unicameral Islands
Council
Judicial branch: Supreme Court
Political parties and leaders: NA
Member of: none
Diplomatic representation in US: none
(territory of Australia)
US diplomatic representation: none
(territcry of Australia)
Flag: the flag of Australia is used','4be2482fada44a0dc53580bdc2c36034326faa2e8eb40d3e354c43fb9f11f214','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bb98ee02b15d552616e2a1afceec8d74a027ae8fc0307de73f2cbe22c6bf37b',1994,'CO','Colombia','government',260,'Names:
conventional long form: Republic of
conventional short form: Colombia
local long form: Republica de Colombia
local .short form: Colombia
Digraph: CO
Type: republic; executive branch dominates
government structure
Capital: Bogota
Administrative divisions: 32 departments
(departamentos. singular — departamento) and
1 capital district* (distrito capital): Amazonas,
Antioquia, Arauca, Atlantico, Bogota*,
Bolivar, Boyaca, Caldas, Caqueta, Casanare.
Cauca, Cesar, Choco. Cordoha, Cundinamarca,
88
Guilinia. Guaviare. Huila. La Guajira.
Magdalena. Mela. Narino. Norte de Santander.
Puiumayo. Quindio. Risaralda. San Andres y
Providencia. Santander. Sucre. Tolima. Valle
del Cauca. Vaupes. Vichada
Independence: 20 July 1810 (from Spain)
National holiday; Independence Day. 20 July
(1810)
Constitution; 5 July 1991
Legal system: bused on Spanish law; a new
criminal code modeled after US procedures
was enacted in 1992-93: judicial review of
executive and legislative acts; accepts
compulsory ICJ jurisdiction, with reservations
Suffrage: 18 years of age; universal and
compulsory
Executive branch:
chief of slate ami head of govenwieni:
President Cesar GAVIRIA Trujillo (since 7
August 1990); President-designate Juan
Manuel SANTOS (since NA 1993); election
last held 27 May 1990 (next to be held May
1994); results— ^esar GAVIRIA Trujillo
(Liberal Party) 47%. Alvaro GOMEZ Hurtado
(National Salvation Movement) 24%. Antonio
NAVARRO Wolff (AD/M- 19) 13%. Rodrigo
LLOREDA (Conservative Party) 12%
note: a new government will be inaugurated on
7 August 1994; the presidential election if 29
May 1994 resulted in no candidate receiving
more than 50% of the total vote and a run-off
election to select a president from the two
leading candidates was held on 19 June 1994;
results — Ernesto SAMPER Pizano (Liberal
Party) 50.4%. Andres PASTRANA Arango
(Conservative Party) 48.6%. blank votes 1%;
Humberto de la CALLE was elected vice
president; electing a vice president is a new
procedure that replaces the traditional
appointment of president-designates by newly
elected presidents
cahiiiel: Cabinet
Legislative branch; bicameral Congress
(Congreso)
Senate iSenado): elections last held 13 March
1994 (next to be held NA March 1998);
preliminary results — percent of vote by party
NA; seats — (102 total) Liberal Party 59.
conservatives (includes PC. MSN. and NDF)
3 1 . other 1 2
House of Representatives I Camara de Repre-
senianiesj: lections last held 13 March 1994
(next to be held NA March 1998); preliminary
results — percent of vote by party NA; seats —
(161 total) Liberal Parly 89. conservatives
(includes PC. MSN. and NDF) 53. AD/M- 1 9 2.
other 17
Judicial branch; Supreme Court of Justice
(Corte Suprema de Justical). Constitutional
Court. Council of State
Political parties and leaders: Liberal Party
(PL). Ernesto SAMPER Pizano. president;
Conservative Party (PC). Misael PASTRANA
Borrero; National Salvation Movement
(MSN). Alvaro GOMEZ Hurtado; New
DemiKratic Force (NDF). Andres
PASTRANA Arango: Democratic Alliance
M-19 (AD/M- 19) is a coalitioii of small
leftist parties and dissident liberals and
conservatives; Patriotic Union (UP) is a legal
political party formed by Revolutionary Armed
Forces of Colombia (FARC) and Colombian
Communist Patty (PCC), Carlos ROMERO
Other political or pressure groups: three
insurgent groups are active in Colombia —
Revolutionary Armed Forces of Colombia
(FARC), Manuel MARULANDA and Alfonso
CANO; National Liberation Army (ELN),
Manuel PEREZ; and di.ssidents of the recently
demobilized People’s Liberation Army (EPL).
Francisco CARABALLO (captured June
1994)
Member of: AG, CDB. CG. ECLAC. FAO.
G-3. G-l I, G.24. G-77. GATT. lADB, IAEA.
IBRD. ICAO, ICC. ICFTU. IDA. IFAD. IFC,
ILO. IMF. IMO. INMARSAT. INTELSAT.
INTERPOL. IOC. lOM. ISO. ITU. LAES.
LAIA. LORCS, NAM, OAS. ONUSAL.
OPANAL. PCA. RG. UN. UNCTAD.
UNESCO. UNHCR. UNIDO. UNPROFOR.
UNTAC. UPU. WCL. WFTU. WHO. WIPO.
WMO, WTO
Diplomatic representation In US:
chief of mission: Ambassador Gabriel SILVA
chancerw 2118 Leroy Place NW, Wa.shington.
DC2(X)b8
telephone: (202) 387-8338
f .\\X: (202) 232-8643
considatets) ftenerul: Boston. Chicago.
Houston. Los Angeles. Miami. New Orleans.
New York. San Francisco. San Juan (Puerto
Rico), and Washington
consulatelsl; .Atlanta, Detroit. Los Angeles,
and Tampa
US diplomatic representation:
chief of mission: Ambassador Morris D.
BUSBY
emhassy: Calle 38, No. 8-61. Bogota
maiiinf! address: Apartado Acreo 383 1 .
Bogota or APO AA 34038
telephone:
h''AX: |57| ( I ) 288-.V»87
I vnsiilaiets I: Barranqu i I la
Flag; three horizontal bands of yellow (top,
double-w idth). blue, and red; similar tir the Bag
of Ecuador, which is longer and bears the
Ecuadorian coat of arms superimposed in the
center','764620b11efc663643483d84d70c7c5d36cac2af566b9199397fc7dde9737e8c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7139f12d7f782e55ada79c17d87965845d780a2d8771711615e3525636481fde',1994,'KM','Comoros','government',267,'Names:
conventional long form: Federal Islamic
Republic of the Comoros
conventional .short form: Comoros
hwal long form: Republique Federate
Islamique des Coniores
local short fonti: Comores
Digraph: CN
Type: independent republic
Capital. Moroni
Administrative divisions; three islands;
Grand Comore (Njazidja). Anjouan (Nzwani).
and Moheli (Mwali)
note: there are also four municipalities named
Domoni. Fomboni. Moroni, and Mutsamudu
Independence: 6 July 1975 (from France)
National holiday; Independence Day. 6 July
(1975)
Constitulion: 7 June 1992
Legal system: French and Muslim law in a
new consolidated code
Sufftnge: 1 8 years of age: universal
Executive branch:
ch''ef of .stale: President Said Mohamed
DJOHAR '' since 1 1 March 1990); election last
held 1 1 March 1990 (next to be held Mareh
19%); results — Said Mohamed DJOHAR
tUDZIMA) 5.5%. Mohamed TAKI
Abdulkarim (UNDO 4.5%
head of government: Prime Minister
Mohamed Abdou MADI (since 6 January
1Q94) appointed by President DJOHAR 6
January 1994 (DJOHAR has appointed 14
prime ministers in the last three years)
cabinet: Council of Ministers; apptointed by
the president
Legislative branch: unicameral
Federal Assembly (Assemblee Federale):
elections last held 1 2-20 December 1 993 (next
to be held by NA January 1998); results —
percent of vote by party NA; seats — (42 total)
Ruling Coalition: RDR 15, UNDC 5,
MWANGAZA 2; Opposition: UDZIMA 8.
other smaller parties 10; 2 seats remained
unfilled
note: opposition is boycotting the National
Assembly until the government promises to
investigate fraud in the last election
Judicial branch: Supreme Court (Cour
Supreme)
Political parties and leaders: over 20
political parties are currently active, the most
important of which are; Comoran Union for
Progress (UDZIMA), OmarTAMOU; Islands''
Fraternity and Unity Party (CHUMA), Said Ali
KEMAL; Comoran Party for Democracy and
Progress (PCDP), Ali MROUDJAE: Realizing
Freedom’s Capability (UWEZO). Mouazair
ABDALLAH; Democratic Front of the
Comoros (FDR), Moustapha CHELKH:
Dialogue Proposition Action
(DPA/MWANGAZA). Said
MCHAWGAMA: Rally for Change and
Democracy (RACHADE), Hassan HACHIM;
Union for Democracy and Decentralization
(UNDC). Mohamed Taki Halidi IBRAHAM;
Rally for Democracy and Renewal (RDR);
Comoran Popular Front (FPC), Mohamed
HASSANALI. Mohamed El ArifOUKACHA.
Abdou MOUSTAKIM (Secretary General)
Member of: ACCT.ACP. AIDB.ECA.FAO.
FZ, G-77. IBRD. ICAO. IDA, IDB, IFAD.
IFC, ILO. IMF. INTELSAT (nonsignatory
user). ITU, NAM. OAU. OIC. UN, UNCTAD.
UNESCO. UNIDO, UPU. WHO. WMO
Diplomatic representation in US:
chief of mission: Ambassador Amini Ali
MOUMIN
chancery: (temporary) at the Comoran
Permanent Mission to the UN. 336 East 45th
Street, 2nd Floor. New York, NY I(X)I7
telephone: (212) 972-8010
FAX,- (2 1 2) 983-47 12
US diplomatic representation: none; post
closed in September 1993
Flag: green with a white crescent placed
diagonally (closed side of the cre.scent points to
the upper hoist-side comer of the flag); there
are four white five-pointed stars placed in a line
between the p«)ints of the crescent; the
crescent, stars, and color green arc traditional
symbols of Islam: the four stars represent the
four main islands of the archifrclago — Mwali.
Njazidja. Nzwani, and Mayotte (which is a
territorial collectivity of France, but claimed by
the Comoros)','e12ae585d6a1352f925e88833ff2a96c670cef8f55c3b5b24f5202a4f1ffea9a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42c14aa97d61783db67215d5fa902450206e8bfa1f9393a0b5e24ee0a69c84fc',1994,'CK','Cook Islands','government',277,'Names:
conventional long form: none
conventional short form: Cook Islatids
Digraph: CW
Type: self-governing parliamentary
government in free association with New
Zealand: Cook Islands is fully responsible for
internal affairs: New Zealand retains
responsibility for external affairs, in
consultation with the Cook Islands
Capital: Avarua
Administrative divisions: none
Independence: none (became self governing
in free association with New Zealand on 4
August 1965 and has the right at any time to
move to full independence by unilateral action)
National holiday: Constitution Day, 4
August
Constitution: 4 August 1965
Legal system: NA
SufDvge: universal adult at age NA
Executive branch:
chief of state: Queen ELIZABETH II (since 6
February 1952): Representative of the Queen
Apenera SHORT (since NA); Representative
of New Zealand Adrian SINCfX^K (since NA)
head of government: Prime Minister Geoffrey
HENRY (since I February 1989); Deputy
Prime Minister Inatio AKARURU (since I
February 1989)
cabinet: Cabinet; collectively responsible to
the Parliament
Legislative branch: unicameral
Parliament: elections last held 24 March 1994
(next to be held NA); results— percent of vote
by party NA; seats — (25 total) Cook Islands
Party 20. Democratic Party 3, Alliance Party 2
note: the House of Arikis (chiefs) advises on
traditional matters, but has no legislative
powers
Judicial branch: High Court
Political parties and leaders: Cook Islands
Patty, Geoffrey HENRY; Democratic Party,
Sir Thomas DAVIS; Cook Islands Labor Party,
Rena JONASSEN; Cook Islands People''s
Party, Sadaroka SADARAKA; Alliance,
Norman GEORGE
Member of: AsDB, ESCAP (associate),
ICAO, ICFTU, IFAD, INTELSAT
(nonsignatory user), IOC, SPARTECA, SPC,
SPF, UNESCO, WHO
Diplomatic representation in US; none
(self-governing in free association with New
Zealand)
US diplomatic representation: none
(self-governing in free association with New
Zealand)
Flag; blue, with the flag of the UK in the
upper hoist-side quadrant and a large circle of
15 white Five-pointed stars (one for every
island) centered in the outer half of the flag
Names:*
conx’entional long form: Coral Sea Islands
Territory
conventional short form: Coral Sea Islands
Digraph: CR
Type: territory of Australia administered by
the Ministry for Environment, Sport, and
Territories
Capital: none; administered from Canberra,','7386abd33b59f72d369fcdca36b2c5ed4fca1e8851b31e5e1efebe90a5c3c835','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f783ef4035427e646a92ea4cbf547b76982e5b331800d60e25b72624119ce61f',1994,'CR','Costa Rica','government',282,'Names:
conventional long form: Republic of Costa
Rica
conventional short form: Costa Rica
local long form: Republica de Costa Rica
local short form: Co,sta Rica
Digraph: CS
Type: democratic republic
Capital; San Jose
Administrative divisions: 7 provinces
(provincias, singular — provincia); Alajuela,
Cartago. Guanaca.ste, Heredia, Limon,
Puntarenas, San Jose
Independence; 15 September 1821 (from
Spain)
National holiday: Independence Day, 15
September (1821)
Constitution: 9 November 1949
Legal system: based on Spanish civil law
system: judicial review of legislative acts in the
Supreme Court; has not accepted compulsory
iCJ jurisdiction
Sufftage; 1 8 years of age; universal and
compulsory
Executive branch:
chief of state and head of government:
President Jose Maria FIGUERES Olsen (since
8 May 1994): First Vice President Rodrigo
OREAMUNO Blanco (since 8 May 1994):
Second Vice President Rebeca GRYNSPAN
Mayufis (since 8 May 1994); election last held
6 February 1994 (next to be held February
1998); results— President FIGUERES (PLN
patty) 49.7%. Miquel Angel RODRIGUEZ
(PUSC party) 47,.5%
cabinet: Cabinet: selected by the president
Legislative branch; unicameral
Legislative Assembly (Asamblea Legislativa):
elections last held 6 Febmaiy 1994 (next to be
held February 1998): results — percent of vote
by party NA; seats — (61 total) PLN 28, PUSC
29. minority parties 4
Judicial branch: Supreme Court (Cotte
Supreme)
Political parties and leaders: National
Liberation Party (PLN), Manuel AGUILAR
Bonilla; Social Christian Unity Party (PUSC),
Rafael Angel CALDERON Fournier; Marxist
Popular Vanguard Party (PVP). Humberto
VARGAS Carbonell; New Republic
Movement (MNR). Sergio Erick ARDON
Ramirez; Progre.ssive Party (PP), Isaac Felipe
AZOFEIFA Bolanos; People’s Party of Costa
Rica (PPC), Lenin CHACON Vargas; Radical
Democratic Party (PRD), Juan Jose
ECHEVERRIA Brealey
Other political or pressure groups: Costa
Rican Confederation of Democratic Workers
(CCTD; Liberation Party affiliate);
Confederated Union of Workers (CUT,
Commun’St Party affiliate); Authentic
Confederation of Democratic Workers
(CATD, Communist Party affiliate); Chamber
of Coffee Growers; National Association for
Economic Development (ANFE); Free Costa
Rica Movement (MCRL. rightwing militants);
National Association of Educators (ANDE)
Member of: AG (observer), BCIE, CACM,
ECLAC, FAO. G-77, GATT. lADB. IAEA,
IBRD, ICAO. ICFTU. IDA. IFAD. IFC. ILO,
IMF. IMO. INTELSAT, INTERPOL. IOC.
lOM, ITU. LAES, LAI A (observer), LORCS,
NAM (observer), OAS, OPANAL, UN,
UNCTAD. UNESCO, UNIDO, UPU, WCL,
WFTU. WHO, WIPO. WMO
Diplomatic representation in US:
chief of mission: AmbassadorGonzalo FACIO
Segreda
chancerv; 2 1 1 4 S Street NW, Washington, DC
20008
telephone: (202) 234-2945
FAX: (202) 265-4795
consulate(s) general: Albuquerque, Atlanta.
Boston, Chicago, Houston, Los Angeles.
Miami, New Orleans, New York, Orlando,
Philadelphia, San Antonio, San Diego, San
Francisco, and San Juan (Puerto Rico)
consulate(s): Austin and Raleigh
US diplomatic representation:
chief of mission: (vacant); Charge d'' Affaires
Joseph BECELIA
embassy: Pavas Road. San Jose
mailing address: APO AA 34020
96
telenluHur [5061 20-39-50
FAX: (506) 20-2305
Flag: l1x e horizontal hands of blue (lop),
white, red (double width), white, and blue, with
the coal of arms in a while disk on the hoist side
of the red band
Econom.v
Overview; In 1993 the econnni> grew at an
estimated 6.5<^. compared with 7.7''?- in 1992
and 2.1‘)f in 1991. Increases in agricultural
production (colTee and bananas),
nontraditional exports, and tourism are
responsible for much of the growth. Inflation in
1993 dropped to O'';?- from 1 1% in 1992 and
259?- in 1991. an indication of basic financial
stability. Unemployment is oflicially reported
at 4.0^f. but much underemployment remains.
National product: GDP — purchasing power
equivalent — S19.3 billion (1993 est.)
National product real gr-iwth rate; 6.5'';?''
(1993 est.)
National product per capita: $S,9(X) ( 1 993
est.)
Inflation rate (consumer prices): 9% (1993
est.)
Unemployment rate; 49r ( 1993); much
underemployment
Budget:
revenues: .SI. I billion
expenditures: SI. 34 billion, including capital
expenditures of $1 10 million (1991 est.)
Exports: $1.9 billion (f.o.b., 1993)
commodities: coffee, bananas, textiles, sugar
poriners: US, Germany, Italy, Guatemala. El
Salvador. Netherlands. UK. France
Imports; $2.9 billion (c.i.f.. 1993)
comnuhiities: raw materials, consumer gtxxls,
capital equipment, petroleum
IHiriners: US, Japan, Mexico, Guatemala.
Venezuela. Germany
External debt; $3.2 billion (1991)
Industrial production: real grow th rate
lO.S*;?- (1992); accounts for 22'';?- of GDP
Electricity:
, 927,000 kW
production: 3.612 billion kWh
consumption per copito: 1 , 1 30 kWh ( 1 992)
Industries: food processing, textiles and
clothing, construction materials, fertilizer,
plastic products
Agriculture: accounts for I9'';f of GDP and
7t)Cf of exports: cash commodities — coffee,
beef, bananas, sugar; other food crops include
corn. rice, beans, ptuatoes; normally
self-sufficient in food except for grain;
depletion of forest resources resulting in lower
timber output
Illicit drugs: transshipment countiy for
cocaine and heroin from South America; illicit
production of cannabis on small scattered plots
Economic aid:
recipient: US commitments, including Ex-lm
(FY7()-89). $1,4 billion. Western (non-US)
countries. ODA and OOF bilateral
commitments (1970-89) $935 million;
Communist countries (1971-89). $27 million
Currency; I Costa Rican colon (C) = 100
centimos
Exchange rates: Costa Rican colones ( C) per
US$1— 150.67 (December 199.3), 142.17
(1993). 1.34.51 (1992). 122.43(199l).91.58
(1990). 81.504 (1989)
Fiscal year: calendar year
Names:
conventional long form: Republic of Cote
d’Ivoire
conventional short form: Cote d''Ivoire
local long form: Republique de Cote d’Ivoire
local short form: Cote d''Ivoire
former: Ivory Coast
Digraph: IV
Type: republic multiparty presidential regime
established I960
Capital; Yamoussoukro
note: although Yamoussoukro has been the
capital since 1983, Abidjan remains the
administrative center: foreign governments,
including the United States, maintain presence
in Abidjan
Admliiistrative divisions: 50 departments
(departements, singular — (departemrnt);
Abengourou, Abidjan, Aboisso, Adzope,
Agboville, Agnibilekrou, Bangolo, Beoumi,
Biankouma. Bondoukou. Bongouanou,
Bouafle, Bouake, Bouna, Boundiali, Dabakala,
Daloa, Danane, Daoukro, Dimbokro, Divo,
Duekoue, Ferkessedougou, Gagnoa, Grand-
Lahou, Guiglo, Issia, Katiola, Korhogo,
Lakota, Man, Mankono, Mbahiakro, Odienne,
Oume, Sakassou, San-Pedro, Sassandra,
Seguela, Sinfra, Soubre, Tabou, Tanda,
Tingrela, Tiassale, Touba, Toumodi, Vavoua,
Yamoussoukro, Zuenoula
Independence: 7 August 1960 (from France)
National holiday: National Day, 7 December
Constitution: 3 November 1960; has been
amended numerous times, last time November
1990
Legal system: based on French civil law
system and customary law; judicial review in
the Constitutional Chamber of the Supreme
Court; has not accepted compulsory ICJ
jurisdiction
Suffrage; 21 years of age; universal
Executive branch:
chief of state: President Henri Konan BEDIE
(since 7 December 1993) constitutional
successor who will serve during the remainder
of the term of former President Felix
HOUPHOUET-BOIGNY who died in office
after continuous service from November I960
(next election October 1995)
head of government: Prime Minister Kablan
Daniel DUNCAN (since 10 December 1993)
cabinet: Council of Ministeis; appointed by
the prime minister
Le^atlve branch; unicameral
National Assembly (Assemblee Nationale):
elections last held 25 November 1990 (next to
be held November 1995); results — percent of
vote by party NA; seats — (175 total) PDCl
163, FPl 9, PIT 1, independents 2
Judicial branch; Supreme Court (Cour
Supreme)
Political parties and leaders; Democratic
Party of the Cote d’Ivoire (PDCI). Henri
Konan BEDIE; Ivorian Popular Front (FPl),
Laurent GBAGBO; Ivorian Worker''s Party
(PIT), Francis WODIE; Ivorian Socialist Party
(PSI), Morifere BAMBA; over 20 smaller
parties
Member of: ACCT, ACP, AfDB, CCC,
CEAO, ECA, ECOWAS, Entente, FAO, FZ,
G-24, G-77, GATT, IAEA, IBRD, ICAO, ICC,
IDA, IFAD, IFC, ILO, IMF, IMO,
INTELSAT. INTERPOL, IOC, ITU. LORCS,
NAM. OAU, UN, UNCfAD, UNESCO,
UNIDO, UPU, WADB, WCL, WHO. WIPO,
WMO, WTO
Diplomatic representation In US;
chief of mission: Ambassador Jean-Marie
KACOU-GERVAIS
chancery: 2424 Massachusetts Avenue NW,
Washington, DC 20008
telephone: (202) 797-0300
US diplomatic representation:
chief of mission: Ambassador Hume A.
HORAN
embassy: 5 Rue Jesse Owens, Abidjan
mailing address: 01 B. P. 1712, Abidjan
telephone: [225] 21-09-79 or 21-46-72
FAX: [225] 22-32-59
Flag; three equal vertical bands of orange
(hoist side), white, and green; similar to the
flag of Ireland, which is longer and has the
colors reversed — green (hoist side), white, and
orange: also similar to the flag of Italy, which
is green (hoist side), white, and red; design was
based on the flag of France','03a9081d1f3c3ca0ea8d903d2bad9cc3d28be4b4d5e85dc4e0173dbd61d717b6','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7503f3475e102d08c8e8db8cb4dd920669d704111a68a1979d4e09d590ba14c',1994,'HR','Croatia','government',290,'Names:
conventional long form: Republic of Croatia
conventional short form: Croatia
local long form: Republika Hrvatska
local short form: Hrvatska
Digraph: HR
Type: parliamentary democracy
Capital: Zagreb
Administrative divisions; 21 counties
(zupanijas, zupanija — singular): Bjelovar-
Bilogora, City of Zagreb. Dubrovnik-Neretva,
Istra, Karlovac, Koprivnica-Krizevci. Krapina-
Zagorje. Lika-Senj, Medimurje, Osijek-
Baranja. Pozega-Slavonija, Primorje-Gorski
Kotar, Sibenik, Si.sak-Moslavina. Slavonski
Brod-Posavina, Split-Dalmatia. Varazdin,
Virovitica-Podravina. Vukovar-Srijem. Zadar-
Knin, Zagreb
Independence: N A June 1991 (from
Yugoslavia)
National holiday: Statehood Day. 30 May
(1990)
Constitution: adopted on 2 December 1990
Legal system: based on civil law system
Suffrage: 16 years of age, if employed: 18
years of age. universal
Executive branch:
chief of stale: President Franjo TUDJMAN
(since 30 May lOW): election last held 4
August 1 992 (next to be held NA 1 995): Franjo
TUDJMAN reelected with about 56% of the
vote; his opponent Dobroslav PARAGA got
5% of the vote
head of government: Prime Minister Nikica
VALENTIC (since 3 April 1993): Deputy
Prime Ministers Mato GRANIC (since 8
September 1992). Ivica KOSTOVIC (since
NA). Vladimir SEKS (since September 1992).
Borislav SKEGRO (since NA)
cabinet: Council of Ministers: appointed by
the president
Legislative branch: bicameral Assembly
(Sabor)
Hou.se of Districts (Zupanije Dont): elections
last held 7 and 21 Febmary 1993 (next to be
held NA February 1997): seats — (68 total: 63
elected. 5 prcsidcntially appointed) HDZ 37.
HSLS 16. HSS 5. Istrian Ctemocratic Assembly
-LSPH-SDP I, HNS I
House of Representatives {Predstavnicke
Dorn): elections lust held 2 August 1992 (next
to be held NA August 1996); seats— ( I .^8 total)
HDZ 85. HSLS 14, SPH-SDP 1 1. HNS 6.
Dalmatian Action/lstrian Democratic
Assembly/ Rijeka DemiK’ratic Alliance
coalition 6. HSP 5. HSS 3. SNS 3,
independents 5
Judicial branch; Supreme Court.
Constitutional Court
Political parties and leaders: Croatian
Democratic Union (HDZ). Stjepun MESIC.
chairman of the executive council: Croatian
People''s Party (HNS). Savka DABCEVIC-
KUCAR. president; Serbian People''s Party
(SNS). Milan DUKIC: Croatian Party of
Rights (HSP). leader NA: Croatian SiKial
Liberal Party (HSLS). Drazen BUDISA.
president: Croatian Peasant P:irty (HSS).
leader NA; Dalmatian Action/lstrian
DenuKTatic Assembly/Rijccka Democratic
Alliance coalition; Social Democratic Party of
Croatia-Party of DemiKratic Changes (SPH-
SDP), Ivica RAC AN
Other political or pressure groups: NA
Member of: CE (guest), CEI. CSCE. ECE,
IAEA, IBRD, ICAO. IDA, IFC, ILO. IMF.
IMO, INMARSAT, INTELSAT, INTERPOL,
IOC, lOM (observer). ITU, NAM (observer),
UN, UNCTAD, UNESCO, UNIDO, UPU,
WHO, WIPO, WMO
Diplomatic representation in US:
chief of mis.sion: Ambassador Petr A.
SARCEVIC
chancery: (temporary) 236 Massachusetts
Avenue NE. Washington, DC 20002
telephone: (202) 543-5580
US diplomatic representation;
chief of mission: Ambassador Peter W.
GALBRAITH
embassy: Andrijc Hcbranga 2, Zagreb
mailing address: Unit 25402. Zagreb;
American Embassy APO AE 092 1 3
telephone: [38] (41)444-800
FAX: 1381(41)440-235
Flag: red. white, and blue horizontal bands
with Croatian coat of arms (red and white
checkered)','1ed1b919c029b5043bfe7dff0a2fc012647e31cc15c27e9b877303b64669d9ec','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a9dc57e15dee417d11cf64e97dec93462543733adf9d678651bd1fa32ebf8ef',1994,'CU','Cuba','government',295,'Names:
conventional long form: Republic of Cuba
conventional short form: Cuba
local long form: Republica de Cuba
local short form: Cuba
Digraph: CU
Type: Communist state
Capital: Havana
Administrative divisions: 14 provinces
(provincias, singular — provincia) and 1 special
municipality* (municipio especial);
Camaguey, Ciego de Avila. Cienfuegos,
Ciudad de La Habana, Granma, Guantanamo,
Holguin, isla de la Juventud*, La Habana, Las
Tunas, Matanzas, Pinardel Rio, Sancti
Spiritus, Santiago de Cuba, Villa Clara
Independence: 20 May 1902 (from Spain 10
December 1 898; administered by the US from
1898 to 1902)
National holiday: Rebellion Day. 26 July
(1953)
Constitution: 24 February 1 976
Legal system: based on Spanish and
American law, with large elements of
Communist legal theory; does not accept
compulsory ICJ jurisdiction
Suffrage: 1 6 years of age: universal
Executive branch:
chief of state and head of government:
President of the Council of Stale and President
of the Council of Ministers Fidel CASTRO
Ruz (Prime Minister from February 1959 until
24 February 1976 when office was abolished;
President since 2 December 1976); First Vice
President of the Council of State and First Vice
President of the Council of Ministers Gen.
Raul CASTRO Ruz (since 2 December 1976)
cabinet: Council of Ministers; proposed by the
president of the Council of State, appointed by
the National Assembly
Legislative branch: unicameral
National Assembly of People’s Power:
(Asamblea Nacional del Poder Popular)
elections last held February 1993; seats — 589
total, indirectly elected from slates approved
by special candidacy commissions
Judicial branch: People’s Supreme Court
(Tribunal Supremo Popular)
Political parties and leaders: only party —
Cuban Communist Party (PCC), Fidel
CASTRO Ruz, first secretary
Member of: CCC, ECLAC, FAO, G-77,
GATT, IAEA, ICAO, IFAD. ILO, IMO,
INMARSAT, INTELSAT (nonsignatory user).
INTERPOL, IOC, ISO. ITU. LAES, LAIA
(observer), LORCS, NAM, OAS (excluded
from formal participation since 1962), PCA,
UN, UNCTAD. UNESCO, UNIDO, UPU,
WCL, WFTU, WHO, WIPO, WMO, WTO
Diplomatic representation in US:
chief of mission: Principal Officer Alfonso
FRAGA Perez (siiKe August 1 992)
represented by the Cuban Interests Section of
the Swiss Embassy in Washington, DC
chancery: 2630 and 2639 16th Street NW, US
Interests Section, Swiss Embassy. Washington,
DC 20009
telephone: (202) 797-8518 or 8519, 8520,
8609, 8610
US diplomatic representation:
chief of mission: I^ncipal Officer Joseph
SULLIVAN
US Interests Section: USINT. Swiss Embassy,
Calzada Entre L y M, Vedado Seccion, Havana
mailing address: use street address
telephone: 33-335 1 or 33-3543
PAX: O'' service available at this time
note: protecting power in Cuba is
Switzerland — US Interests Section, Swiss
Embassy
Flag: five equal horizontal bands of blue (top
and bottom) alternating with white: a red
equilateral triangle based on the hoist side
bears a white five-pointed star in the center','aef33138af3d4df5efee6026edc3a734ea3a5fd99ee4e8693ccef30d189af27f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c607ced5b50962bbaad75750f3128536c2c8391430c8a2617373826dee3efaab',1994,'CY','Cyprus','government',301,'Names:
conventional long form: Republic of Cyprus
conventional short form: Cyprus
Digraph: CY
Type: republic
note: a disaggregation of the two ethnic
communities inhabiting the island began after
the outbreak of communal strife in 1963; this
separation was further solidified following the
Turki.sh invasion of the island in July 1974.
which gave the Turkish Cypriots de facto
control in the north: Greek Cypriots control the
only internationally recognized government:
on 15 November 1983 Turkish Cypriot
President Rauf DENKTASH declared
independence and the formation of a "Turkish
Republic of Northern Cyprus" (TRNC). which
has been recognized only by Turkey; both sides
publicly call for the resolution of
intercommunal differences and creation of a
new federal system of government
Capital: Nicosia
Adminiitrativc diviiioiia: 6 districts:
Famagusta. Kyrenia. Lamaca. Limassol.
Nicosia. Paphos
Independence: 16 August I960 (from UK)
National holiday: Independence Day. I
October (15 November ( 1983) is celebrated as
Independence Day in the Turkish area)
Con^itution: 16 August I960: negotiations
to create the basis for a new or revised
constitution to govern the island and to better
relations between Greek and Turkish Cypriots
have been held intermittently: in 1975 Turki.sh
Cypriots created their own Constitution and
governing bodies within the "Turkish
Federated State of Cyprus." which was
renamed the "Turkish Republic of Northern
Cyprus" in 1983; a new Constitution for the
Turkish area passed by referendum in 5 May
1985
Legal system: based on common law. with
civil law modifications
Snffhigc: 1 8 years of age: universal
Executive branch;
chief of slate and head of government:
President Glafkos CLERIDES (since 28
February 1993); election last held 14 February
1993 (next to be held February 1998): results—
Glafkos CLERIDES 50.3%, George
VASSILIOU 49.7%
cabinet: Council of Ministers: appointed
jointly by the president and vice-president
note: RaufR. DENKTASH has been president
of the Turkish area since 13 February 1975;
Hakki ATUN has been prime minister of the
Turkish area since I January 1994; there is a
Council of Ministers (cabinet) in the Turkish
area
Legislative branch: unicameral
House of Representatives (Vouli Antiproso-
pon): elections last held 19 May 1991 (next to
be held NA); results— DISY 35.8%. AKEL
(Communist) .30.6%. DIKO 19.5%. EDEK
10.9%; others 3.2%; seats — (56 total) DISY
20. AKEL (Communist) 18. DIKO 1 1. EDEK
7
Turkish Area: Assembly of the Republic (Cum-
huriyet Meclisi): elections last held 12
December 1993 (next to be held NA); results —
percent of vote by party NA; seats — (50 total)
UBP (conservative) 17, DP I5.CTP (3,tKP5
Judicial branch: Supreme Court; note —
there is also a Supreme Court in the Turkish
area
Political parties and leaders:
Greek Cypriot: Progressive Party of the
Working People (AKEL, Communist Patty),
Dimitrios CHRISTOFIAS: Democratic Rally
(DISY). John MATSIS; Democratic Party
(DIKO), Spyros KYPRIANOU; United
Democratic Union of the Center (EDEK).
Vassos LYSSARIDIS; .Socialist Democratic
Renewal Movement (ADISOK), Mikhalis
PAPAPETROU; Liberal Party, Nikos
ROl.ANDIS: Free Democrats, George
VASSILIOU
Turkish area: National Unity Party (UBP),
Dervis EROGLU ; Communal Liberation Party
(TKP), Mustafa AKINCI; Republican Turkish
Party (CTP). Ozker OZGUR; New Cyprus
Party (YKP). Alpay DURDURAN; Social
Democratic Party (SDP), Ergun VEHBI: New
Birth Party (YDP). Ali Ozkan ALTINISHIK;
Free Democratic Party (HDP). Ismet KOTAK;
National Struggle Party (MSP), Zorlu TORE;
Unity and Sovereignty Party (USP), Arif Salih
KIRDAG; Democratic Party (DP). Hakki
ATUN: Fatherland Party (VP). Orhan UCOK;
note: CTP. TKP. and YDP Joined in the
coalition Democratic Struggle Party ( DMP) for
the 22 April 1 990 legislative election; the CTP
and TKP boycotted the by-election of 13
October 1 99 1 , in which 1 2 seats were at stake;
the DMP was dissolved after the 1 990 election
Other political or preasure groups: United
Democratic Youth Organization (EDON;
Communist controlled); Union of Cyprus
Farmers (EKA. Communist controlled);
Cyprus Farmers Union (PEK, pro- West): Pan-
Cyprian Labor Federation (PEO. Communist
controlled); Confederation of Cypriot Workers
(SEK, pro-West): Federation of Turkish
Cypriot Labor Unions (Turk-Sen);
Confederation of Revolutionary Labor Unions
(Dev-ls)
Member of: C. CCC, CE. CSCE. EBRD.
ECE. FAO, G-77, GATT. IAEA, IBRD,
ICAO. ICC. ICFTU. IDA. IFAD. IFC. ILO,
IMF. IMO, INMARSAT. INTELSAT.
INTERPOL. IOC, lOM, ISO. ITU. NAM.
OAS (observer). UN. UNCTAD. UNESCO,
UNIDO. UPU. WCL, WFTU, WHO. WIPO.
WMO. WTO
Diplomatic representation in US:
chief of mission: Ambassador Andreas
JACOVIDES
chancerv: 221 1 R Street NW, Washington, DC
20008
telephone: (202) 462-5772
consulate(s) general: New York
note: Representative of the Turkish area in the
US is Namik KORMAN, office at 1667 K
Street NW, Washington. DC, telephone (202)
887-6198
US diplomatic representation:
chief of mission: Ambassador Richard
BOUCHER
embassy: comer of Metochiou and
Ploutarchou Streets, Nicosia
mailing address: APO AE 09836
telephone: |357] (2)476100
FAX: [357] (2) 465944
Flag: white with a copper-colored silhouette
104
of the island (the name Cyprus is derived from
the Greek word for copper) above two green
crossed olive branches in the center of the flag;
the branches symbolize the hope for peace and
reconciliation between the Greek and Turkish
communities
note: the Turkish Cypriot flag has a horizontal
red stripe at the top and bottom with a red
crescent and red star on a while field
Names:
conventional long form: Czech Republic
conventional short form: Czech Republic
local long form: Ceska Republika
local short form: Cechy
Digraph: EZ
Type: parliamentary democracy
Capital: Prague
Adminiatralivc divMona: 8 regions (kraje,
kraj— singular): Jihocesky. lihomuravsky.
Praha, Severocesky. Severomoravsky,
Stredocesky, Vychodocesky. Zapadocesky
iMtepcndcncc: I January 1993 (from
Czechoslovakia)
National holiday: National Liberation Day. 9
May: Founding of the Republic. 28 October
Cuiistltution: ratified 16 December 1992:
effective I January 1993
Legal system: civil law system based on
AustrtvHungarian codes; has not accepted
compulsory ICJ jurisdiction; legal code
modified to bring it in line with Conference on
Security and Cooperation in Europe (CSCE)
obligations and to expunge Marxist-Leninist
legal thetvy
Suffirage: 18 years of age: universal
Executive branch;
chief of slate: President Vaclav HAVEL(since
26 January 1993); election last held 26 January
1993 (next to be held NA January 1998):
results — Vaclav HAVEL elected by the
National Council
head of government: Prime Minister Vaclav
KLAlis (since NA June 1992); Deputy Prime
Ministers Ivan KOCARNIK, Josef LUX. Jan
KALVODA (since NA June 1992)
cabinet: Cabinet; appointed by the president
on recommendation of the prime minister
Lcgislalive branch: bicameral National
Council (Narodni rada)
Semite.- elections not yet held; seats (81 total)
Chamber of Deputies: elections lust held 5-6
June 1992 (next to be held NA 1996); results -
percent of vote by party N A; seals— ( 200 total)
Civic Democratic Party/Christian Democratic
Party 76. Left Bloc 35. Czech Social
Democratic Party 16. Liberal Social Union 16,
Christian Democratic Union/Czech People’s
Party 15. Assembly for the Republic/
Republican Party 14, Civic Democratic
Alliance 14. Movement for Self-Governing
Democracy for Moravia and Silesia 14
Judicial branch: Supreme Court.
Constitutional Court
PoiUical parties and leaders: Civic
Democratic Party (ODS), Vaclav KLAUS,
chairman; Christian Democratic Union-Czech
People’s Party (KDU-CSL). Josef LUX.
chairman: Civic Democratic Alliance (ODA).
Jan KALVODA. chairman; Christian
Democratic Party (KDS), Ivan PILIP.
chairman; Czech Social Democratic Party.
Milos ZEMAN. chairman: Czech-Moravian
Center Party, Jan KYCER, chairman: Liberal
Social Union (LSU), Frantisek TRNKA;
Communist Party of Bohemia/Moravia
(KSCM). Miroslav GREBENICEK. chairman:
Asso''-iation for the Republic — Republican
Party. Miroslav SLADEK, chairman; Left
Bloc, Marie STIBOROVA, chairman
Other political or pressure groups; Left
Bloc; Liberal Party; Czech-Moravian Chamber
of Trade Unions
Member of: BIS, CCC. CE (guest). CEl,
106
CERN. CCXrOM (cooperating). CSCE. EBRD.
ECE. FAO. GATT. IAEA. IBRD. ICAO, IDA.
IFC. It=CTU. ILO. IMF. IMO. INMARSAT.
INTELSAT. INTERPOL. IOC. lOM
(Observer). ISO, ITU, LORCS, NACC, NSG,
PCA. UN (asof 8 January 1993), UNAVEM II.
UNCTAD. UNESCO, UNIDO. UNOMIG.
UNOMOZ. UNPROFOR, UPU. WFTU.
WHO. WIPO. WMO. WTO. ZC
DipkNiiatic reprcacntation In US:
chief of mission: Ambassador Michael
ZAWOVSKY
vhancen: .3900 Spring of Freedom Street NW,
Washington. DC 20008
telephone: ( 202 ) .363-63 1 .3 or 6.3 1 6
FAX: (202) 966-8.340
US diploinatk representation:
chief of mission: Ambassador Adrian A.
BASORA
embassy: Trziste 1.3. 11801. Prague I
mailing address: Unit 2.3402; APO AE 092 1 3
telephime: |42) (2) 251-0847
FAY. 1421(2)5.31-19.3
nag: two equal horizontal bands of white
(top) and red with a blue isosceles triangle
based on the hoist side (almost identical to the
flag of the former Czechoslovakia)','d278e811cc79784ef993911fe0b67801bed395f2f88e78de3ffb9f72455ef5ae','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60a8270c53bc2266259728c1c78d5bb775e7e594767e5971363e96c43ed25c31',1994,'GL','Greenland','government',308,'Names:
conventional long form: Kingdom of Denmark
conventional short form: Denmark
Un-u! lonft jdmi: Kongeriget Danmark
Ith-al short fomi: Danmark
Digraph; DA
Type: constitutional monarchy
Capital; Copenhagen
Administrative divisions: metropolitan
Denmark — 1 4 counties (amter, singular — amt)
and I city* (stad); Arhus. Bornholm.
Fredcriksborg. Fyn. Kbenhavn. Nordjylland.
Ribe. Ringkbing, Roskilde. Snderjylland.
Staden Kbenhavn*. Storstrm. Vejle.
Vcstsiuelland. Viborg
note: see separate entries fot the Faroe Islands
and Greenland, w hich are part of the Danish
realm and self-governing adminis''rative
divisions
Independence: 1 849 ( became a constitutional
monarchy)
National holiday: Birthday of the Queen. 16
April (1940)
Constitution; .s June 19.5.3
Legal system: civil law system: judicial
re\\ iew of legislative acts; accepts compulsory
ICJ jurisdiction, with reservations
SuffhMie; 21 years of age; universal
Executive branch:
chief of state: Queen MARGRETHE II (since
NA January 1972); Heir Apparent Crown
Prince FREDERIK. elder son of the Queen
(bom 26 May 1968)
head of itovernmeni: Prime Minister Poul
Nvrup RASMUSSEN (since NA January
1993)
cahinei: Cabinet; appt''inied by the monareh
Legislative branch; unicameral
Parliament iFolketinn): elections last held 12
December 1990 (next to he held by December
19*)4); results — Six’ial Democratic Party
37,49). Conservative Party 16,09). Liberal
1 .5.89) . Six''ialist Petiple''s Party 8.39). Progress
Party 6.49), Center Denxx''ratic Party .5, 1 9).
Radical Liberal Party .3..59), Christian People''s
Party 2. .39), iHher .5.29); seats— -( 179 total;
includes 2 from Greenland and 2 from the
Faroe Islands) Six''ial Democratic 69.
Conservative ,30. Liberal 29. Six''ialist People''s
1 5. Progress Party 1 2, Center Demix''ratic 9,
Radical Liberal 7, Christian People''s 4
Judkial branch: Supreme Court
Polllical parties and leaders: Stx''ial
Demtx''ratic Party. Ptnil Nyrup RASMUSSEN;
Conservative Pariv. Torben RECHENDORFF;
Liberal Parly. UlTe ELLEM.ANN-JENSEN;
.Six''ialist People''s Party. Holger K. NIELSEN;
Progress Party, Johannes SORENSEN; Center
Demix-ratic Party. Mimi Stilling JAKOBSEN:
Radical Liberal Party, Marianne JELVED;
Christian People''s Party. Jann SJURSEN;
Common Course. Prehen Moller HANSEN;
Danish Workers'' Party
Member of; AfDB. AG (observer). AsDB.
Australia Group. BIS. CBSS. CCC. CE.
CERN. COCOM. CSCE. EBRD, EC, ECE.
ElB. ESA. FAO. G-9, GATT, lADB, IAEA.
IBRD. ICAO. ICC, ICFTU. IDA. lEA. IFAD.
IFC. ILO, IMF. IMO. INMARSAT,
108
INTELSAT. INTERPOL, IOC, lOM, ISO,
ITU. LORCS. MTCR. NACC. NATO. NC.
NEA. NIB. NSG, OECD. PCA. UN.
UNCTAD. UNESCO. UNFICYP. UNHCR.
UNIDO. UNIKOM. UNOMIG. UNMOGIP.
UNPROFOR. UNTSO. UPU. WEU. WFTU.
WHO. WIPO, WMO. ZC
Diplomatic representation In US:
chief of mission; Ambassador Peter Pedersen
DYVIG
chancerv: 3200 Whitehaven Street NW.
Washington. DC 20008
telephone; (202) 234-4300
FAX; (202) 328-1470
consulate(s) general: Chicago. Lo.i Angeles,
and New York
US diplomatic representation;
chief of mission: Ambassador Edward E.
ELSON
embassy; Dag Hammarskjotds Al''e 24. 2100
Copenhagen O
mailing address: APO AE 09716
telephone; [4.^] (31 ) 42-31-44
FAX; (45] (35) 43-0223
Flag: red with a white cross that extends to the
edges of the flag; the vertical part of the cross
is shifted to the hoist side, and that design
element of the DANNEBROG (Danish flag)
was subsequently adopted by the other Nordic
countries of Finland. Iceland. Norway, and','a6268b836ef136803d75efaa045f3b1fad6ea3346bb39e884083f1dd094fdb89','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14ac2e1c7cf3da8e9e8975b6b0e98a5a572da28a6aafa74d41df48811f8cc3c8',1994,'DJ','Djibouti','government',314,'Names:
conventional long form; Republic of Djibouti
conventional short form: Djibouti
former: French Territory of the Afars and Issas
French Somaliland
Digraph: DJ
Type: republic
Capital: Djibouti
Administrative divisions; 5 districts (ccrcies,
singular — cercle); ‘Ali Sabih, Dikhil, Djibouti,
Obock, Tadjoura
Independence: 27 June 1977 (from France)
National holiday: Independence Day, 27
June (1977)
Constitution: multiparty constitution
approved in referendum 4 September 1992
Legal system: based on French civil law
system, traditional practices, and Islamic law
SulDrage: universal adult at age NA
Executive branch:
chief of state: President HASSAN GOULED
Aptidon (since 24 June 1977); election last
held 7 May 1993 (next to be held NA 1999):
results — F^sident Hassan GOULED Aptidon
was reelected
head of government: Prime Minister
BARKAT Gourad Hamadou (since .30
September 1978)
cabinet: Council of Ministers: responsible to
the president
Legislative branch: unicameral
Chamber of Deputies (Chambre des Deputes):
elections last held 18 December 1992;
results~RPP is the only party: seats — (65
total) RPP 65
Judicial branch: Supreme Court (Cour
Supreme)
Political parties and leaders:
ruling party; People''s Progress Assembly
(RPP), Hassan GOULED Aptidon
other parties: Democratic Renewal Party
(PRD), Mohamed Jama ELABE; Democratic
National Party (PND). ADEN Robleh Awaleh
Otiicr political or pressure groups: Front
for the Restoration of Unity and Democracy
(FRUD) and affiliates: Movement for Unity
and DemrKracy (MUD)
Member of; ACCT. ACP. AfDB, AFESD.
AL, EGA. FAO. G-77. IBRD, ICAO. IDA.
IDB, IFAD. IFC, IGADD, ILO. IMF, IMO,
INTELSAT (nonsignatory user), INTERPOL,
IOC, ITU. LORCS, NAM. OAU. OIC. UN,
UNESCO, UNCTAD. UNIDO, UPU. WHO,
WMO
Diplomatic representation in US:
chief of mission: Ambas.sador Roble
OLHAYF
chancerv: Suite 515, 1156 15th Street NW,
Washington. DC 20005
telephone: (202) 331-0270
FAX: (202) 331-0.302
US diplomatic representation:
chief of mission: Ambassador Martin
CHESES
embassy: Plateau du Serpent, Boulevard
Marechal Joffre, Djibouti
mailing address: B. P. 185. Djibouti
telephone: [253] 35-39-95
FAX: J2S31 35--39-40
Flag; two equal horizontal bands of light blue
(top) and light green with a white isosceles
triangle based on the hoist side bearing a red
five-pointed sic'' in the center','2449c90320980116be94e934c57cfa9ed2b52e58a9c5d8519173d555cfca5c4b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10d8a5eca61532ba009be34518802238457b7630395f1f20e679233274646393',1994,'TT','Trinidad and Tobago','government',321,'Names:
conventional long form: Commonwealth of
Names:
conventional long form: Republic of Trinidad
and Tobago
conventional short form; Trinidad and Tobago
Digraph: TD
Type; parliamentary democracy
Capital: Port-of-Spain
Administrative divisions: 8 counties. 3
municipalities*, and 1 ward**; Arima*.
Caroni, Mayaro. Nariva. Port-of-Spain*. Saint
Andrew, .Saint David. Saint George. Saint
Patrick. San Fernando*. Tebago**. Victoria
Independence: 31 August 1962 (from UK)
National holiday; independence Day, 3 1
August (1962)
Constitution: I August 1976
Legal system: based on English common law ;
judicial review of legislative acts in the
Supreme Court; has not accepted compulsory
ICJ jurisdiction
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state; President Noor Mohammed
HASSANALI (since 1 8 Match 1987)
head of government: Prime Minister Patrick
Augustus Mervyn MANNING (since 17
December 1991)
cabinet; Cabinet; responsible to parliament
Legislative branch: bicameral Parliament
Senate: consists of a 3 1 -member body
appointed by the president
House of Representatives: elections last held
16 December 1991 (next to be held by
December 1996); results— PNM 32%. UNC
13%. NAR 2%; seats— (36 total) PNM 21.
UNC 1.3. NAR 2
Judicial braiteh: Court of Appeal, Supreme
Court
Political parties and leaders: People''s
National Movement (PNM). Patrick
MANNING: United National Congress
(UNC). Basdeo PANDAY: National Alliance
for Reconstruction (NAR), Selby WILSON:
Movement for Social Transformation
(MOTION). David ABDULLAH; National
Joint Action Committee (NJAC), Makandal
DAAGA; Republic Patty. Nello MITCHELL;
National Development Party (NDP), Carson
CHARLES
Member of: ACP. C. CARICOM. CCC.
CDB. ECLAC. FAO. G-24. G-77. GATT.
lADB. IBRD. ICAO. ICFTU. IDA, IFAD.
IFC. ILO. IMF. IMO. INTELSAT.
INTERPOL. KX:. ISO. ITU. LAES. LORCS.
NAM. OAS. OPANAL. UN. UNCTAD.
UNESCO. UNIDO. UPU. WFTU. WHO,
WIPO. WMO
Diplomatic representation in US:
chief of mission: Ambassador Corinne
Averille McKNlGHT
chancen''; 1 708 Massachusetts Avenue NW.
Washington. DC 20036
telephone: (202) 467-6490
FAX; (202) 785-31.30
consulateisi general; New York
US diplomatic representation:
chief of mission: Ambassador Sally G.
COWAL
embassy; 1 5 Queen''s Park West. Port-of-Spain
mailing address; P, O, Box 752. Port-of-Spain
telephone; (809) 622-6372 through 6376, 61 76
FAX: (809) 628-5462
Flag: red with a white-edged black diagonal
band from the upper hoist side
Names;
conventional long form; none
,398','00152ce15fdcf4623dc22125c61d92777b08695a9a3abfee6b3139f47a6b699e','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b1757673cc1da8ebc593a06ada3af26c7f09b5ea1479966fab4aae4d4809f66',1994,'DM','Dominica','government',322,'conventional short form; Dominica
Digraph: DO
Type: parliamentary democracy
Capital: Roseau
Administrative divisions: 10 parishes; Saint
Andrew, Saint David. Saint George. Saint
John, Saint Joseph, Saint Luke. Saint Mark,
Saint Patrick. Saint Paul. Saint Peter
Independence: 3 November 1978 (from UK)
National holiday: Independence Day, 3
November (1978)
Constitution: 3 November 1978
Legal system: based on English common law
Suffrage: 1 8 years of age: universal
Executive branch:
chief of stale: President Crispin Anselm
SORHAINDO (since 25 October 1993)
election last held 4 October 1993 (next to be
held NA October 1998): results — President
Crispin Anselm SORHAINDO was elected by
the House of Assembly to a five year term
head of government: f^ime Minister (Mary)
Eugenia CHARLES (since 21 July 1980.
elected for a third term 28 May 1990)
cahinti: Cabinet; appointed by the president
on the advice of the prime minister
Legislative branch: unicameral
House of Assembly: elections last held 28 May
1990 (next to be held May 1995); results —
percent of vote by party NA; seats — (30 total;
9 appointed senators and 21 elected
representatives) DFP 1 1 , U WP 6, DLP 4
Judicial branch; Eastern Caribbean Supieme
Court
Political parties and leaders; Dominica
Freedom Party (DFP). Brian ALLEYNE;
Dominica La^r Party (DLP), Rosie
DOUGLAS; United Workers Party (UWP).
Edison JAMES
Other political or pressure groups:
Dominica Liberation Movement (DLM), a
small leftist group
Member of: ACCT, ACP, C, CARICOM,
CDB, ECLAC, FAO, G-77, GATT. IBRD.
ICFTU. IDA. IFAD, IFC, ILO, IMF. IMO,
INTERPOL. LORCS. NAM (observer). OAS.
OECS, UN, UNCTAD. UNESCO. UNIDO,
UPU. WCL, WHO, WMO
Diplomatic representation in US:
Dominica has no chancery in the US
consulate(s) general: New York
US diplomatic representation: no official
presence since the Ambassador resides in
Bridgetown (Barbados), but travels frequently
to Dominica
Flag: green with a centered cross of three
equal bands — the vertical part is yellow (hoist
side), black, and white — the horizontal part is
yellow (top), black, and white; superimposed
in the center of the cross is a red disk bearing a
sisserou parrot encircled by 10 green five-
pointed stars edged in yellow; the 10 stars
represent the 10 administrative divisions
(parishes)','79e99e9a5796e35dc5c0095f4ea78a5819ede2962a3af7c6a6f6cb119d6da67e','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc73f73cf3c9015a84a8e1200fc7d8826bf532e7a0251037b03da5f95ec87e3a',1994,'DO','Dominican Republic','government',326,'Names:
conventional long form: Dominican Republic
conventional short form: none
local long form: Republica Dominicana
local short form: none
Digraph: DR
Type: republic
Capital: Santo Domingo
Administrative divisions: 29 provinces
(provincias, singular — provincia) and 1
district* (distrito): Azua, Baoruco, Barahona,
Dajabon, Distrito Nacional*. Duarte, Elias
Pina, El Seibo. Espaillat, Hato Mayor.
Independencia, La Altagracia, La Romana, La
Vega, Maria Trinidad Sanchez, Monsenor
Nouel. Monte Cristi, Monte Plata, Pedernales,
Peravia, Puerto Plata, Salcedo. Samana,
Sanchez Ramirez. San Cristobal. San Juan, San
Pedro De Macoris, Santiago, Santiago
Redriguez, Valverde
Independence: 27 February 1844 (from
Haiti)
National holiday; Independence Day. 27
February ( 1 844)
Constitution: 28 November 1966
Legal system: based on French civil codes
Suffrage: 1 8 years of age; universal and
compulsory or married persons regardless of
age
note: members of the armed forces and police
cannot vote
Executive branch;
chief of state and head of government:
President Joaquin BALACJUER Ricardo (since
16 August 1986, fifth elected term began 16
August 1990); Vice President Carlos A.
MORALES Troncoso (since 16 August 1986);
election last held 1 6 May 1 990 (next to be held
May 1994); results — Joaquin BALAGUER
(PRSC) 35.7%, Juan BOSCH Gavino (PLD)
34.4%, Jose Francisco PENA Gomez (PRD)
22.9%
cabinet: Cabinet; nominated by the president
Legislative branch: bicameral National
Congress (Congreso Nacional)
Senate (Senado): elections last held 16 May
1990 (next to be held May 1994); results —
percent of vote by party NA; seats — (30 total)
PRSC 16. PLD 1 2. PRD 2
Chamber of Deputies ( Camara de Diputados):
elections last held 16 May 1990 (next to be
held May 1994); results — percent of vote by
party NA; scats — ( 1 20 total) PLD 44, PRSC
41, PRD 33, PRI2
Judicial branch: Supreme Court (Corte
Suprema)
Political parties and leaders;
Major parties: Social Christian Reformist
Party (PRSC), Joaquin BALAGUER Ricardo;
Dominican Liberation Party (PLD). Juan
BOSCH Gavino; Dominican Revolutionary
Party (PRD), Jose Franciso PENA Gomez;
Independent Revolutionary Party (PRI).
Jacobo MAJLUTA
Minor parties: National Veterans and Civilian
Party (PNVC), Juan Rene BEAUCHAMPS
Javier; Liberal Party of the Dominican
Republic (PLRD). Andres Van Der HORST;
Democratic Quisqueyan Party (PQD). Elias
WESSIN Chavez; National Progressive Force
(FNP), Marino VINICIO Castillo; Popular
Christian Party (PPC), Rogelio DELCJADO
Bogaert; Dominican Communist Party (PCD),
Narciso ISA Conde; Dominican Workers’
Party (PTD), Ivan RODRIGUEZ; Anti-
Imperialist Patriotic Union (UPA), Ignacio
RODRIGUEZ Chiappini: Alliance for
Democracy Party (APD). Maximilano
Rabelais PUIG Miller, Nelsida
MARMOLEJOS. Vicente BENGOA
note: in 1983 several leftist parties, including
the PCD. joined to form the Dominican Leftist
Front (FID); however, they .still retain
individual party structures
Other political or pressure groups:
Collective of Popular Organzations (COP),
leader NA
Member of: ACP. CARICOM (observer),
ECLAC, FAO. G-l 1. Ci-77. GATT. lADB,
IAEA. IBRD. ICAO, ICFTU. IDA. IFAD. IFC,
ILO. IMF, IMO. INTELSAT. INTERPOL,
IOC. lOM. ITU. LAES, LAIA (observer).
LORCS. NAM (guest). OAS. OPANAL. PCA,
UN. UNCTAD. UNESCO, UNIDO. UPU.
WCL. WFTU. WHO. WMO. WTO
113
Dominican Republic (continued)
Diplomatic representation in US;
chief of mission: Ambassador Jose del Carmen
ARIZA Gomez
chancery: 1 7 1 5 22nd Street NW, Washington,
DC 20008
telephone: (202) 332-6280
FAX: (202) 265-8057
consulate(s) general: Boston, Chicago, Los
Angeles, Mayaguez (Puerto Rico), Miami,
New Orleans, New York, Philadelphia, San
Francisco, and San Juan (Puerto Rico)
consulate(s): Charlotte Amalie (Virgin
Islands), Detroit, Houston, Jacksonville,
Minneapolis, Mobile, Ponce (Puerto Rico), and
San Francisco
US diplomatic representation:
chief of mission: Ambassador Robert S.
PASTORINO
embassy: comer of Calle Cesar Nicolas Penson
and Caile Leopoldo Navarro, Santo Domingo
mailing address: Unit 55(X), Santo Domingo;
APO A A 34(MI-0008
telephone: (809) 54 1 -2 1 7 1 and 54 1 -8 1 00
FAX: (809) 686-7437
Flag: a centered white cross that extends to
the edges, divides the flag into four
rectangles — the top ones are blue (hoist side)
and red, the bottom ones are red (hoist side)
and blue; a small coat of arms is at the center of
the cross','70a388fee2b865ac93aefc334dab4c2f0544d62d9fad9e60e0ee6e508d922bef','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf71037653f68b221fa660de478bccf4390c4d7e6fdc92d98a120e1d29422850',1994,'EC','Ecuador','government',332,'Names:
conventional lonpform: Republic of Ecuador
conventioni''J short form: Ecuador
local loiift form: Republicu del Ecuador
local short form: Ecuador
Digraph; EC
Type: republic
Capital: Quito
Administrative divisions; 21 provinces
(provincia.s, singular — provincial; Azuay,
Bolivar. Canar. Carchi. Chimborazo. Cotopaxi.
El Oro. Esmeraldas. Galapagos, Guayas,
Imbabura, Loja. Los Rios. Manabi, Morona-
Santiago, Napo, Pastaza. Pichincha.
Sucumbios, Tungurahua. Zamora-Chinchipe
Independence: 24 May 1822 (from Spain)
National holiday: Independence Day. 10
August ( 1 809) (independence of Quito)
Constitution: 10 August 1979
Legal system: based on civil law system; has
not accepted compulsory ICJ jurisdiction
Suffrage: 1 8 years of age; universiil.
cttmpulsory for literate persons ages 18-65,
optional for other eligible voters
Executive branch;
chief of state and head of government:
President Sixto DURAN BALLEN Cordovez
(since 10 August 1992); Vice President
Alberto DAHIK Garzoni (since 10 August
1 992); election runoff election held 5 July 1 992
(next to be held NA 1996); results — Sixto
DURAN BALLEN elected as president and
Alberto DAHIK elected as vice president
cabinet; Cabinet; appointed by the president
Legislative branch; unicameral
National Congress (Congreso Nacional);
elections last held 17 May 1992 (next to be
held I May 1994); results — percent of vote by
party NA; seats — (77 total) PSC 20, PRE 15.
PUR 1 2, ID 7. PC 6, DP 5, PSE 3. MPD 3.
PLRE 2, CEP 2. FRA I, APRE I
Judicial branch: Supreme Court (Cone
Suprema)
Political parties and leaders:
Center-Right parties; Social Christian Party
(PSC), Jaime NEBOT Saudi, president;
Republican Unity Party (PUR), President Sixto
DURAN BALLEN, leader; Conservative Party
(PC), Vice President Alberto DAHIK.
president
Center-Left parties: Democratic Left (ID),
Andres VALLEJO Arcos, Rodrigo BORJA
Cevallos, leaders; Popular Democracy (DP),
Jamil MANUAD Witt, president; Ecuadorian
Radical Liberal Party (PLRE). Carlos Luis
PLAZA Aray, director; Radical Alfarista Front
(FRA). Jaime ASPIAZU Seminario, director
Populist parties; Roldista Party (PRE). Abdala
BUCARAM Ortiz, director; Concentration of
Popular Forces (CFP), Rafael SANTELICES,
director; Popular Revolutionary Action
(APRE), Frank VARGAS Passes, leader;
Assad Bucarum Party (PAB), Avicena
BUCARAM, leader; People, Change, and
Dernwracy (PCD), Raul AULESTIA, director
Par-Left parties: Popular Democratic
Movement (MPD). Jorge Fausto MORENO,
director; Ecuadorian StK''ialist Party (PSE),
Leon ROLDOS, leader; Broad Leftist Front
(FADI), Jose Xavier GARAYCOA. president;
Ecuadorian National Liberation (LN), Alfredo
CASTILLO, director
Communists: Communist Party of Ecuador
(PCE, pro-North Korea), Rene Leon Mague
MOSWUERRA. secretary general (5,000
members); Communist Party of Ecuador/
Marxist-Leninist (PCMLE. Maoist), leader NA
(3,(KK) members)
Member of: AG. ECLAC. FAO, G- 1 1 , 0-77,
lADB, IAEA, IBRD. ICAO. ICC. ICFTU,
IDA. IFAD. IFC, ILO, IMF. IMO,
INTELSAT. INTERPOL, IOC. lOM. ITU.
LAES. LAIA. LORCS, NAM, OAS.
ONUSAL. OPANAL, PCA. RG, UN.
UNCTAD. UNESCO, UNIDO, UPU, WCL.
WFTU, WHO. WIPO. WMO. WTO
Diplomailc representation in US:
chief of mission: Ambassador Edgar TERAN
chancery: 2535 I5lh Street NW, Washington,
115
Ecuador (continued)
DC 20009
telephone: (202) 234-7200
consulate(s) general: Chicago, Houston, Los
Angeles, Miami, New Orleans, New York, San
Diego, and San Francisco
US diplomatic representation:
chief of mission: Ambassador Peter F.
ROMERO
embassy: Avenida 1 2 de Octubre y Avenida
Patria, Quito
mailing address: P. O. Box 538, Unit 5309,
Quito, or APO AA 34039-3420
telephone: 1593] (2) 562-890, 561-623 or 624
FAX; [593] (2) 502-052
consulate(s) general: Guayaquil
Flag: three horizontal bands of yellow (top,
double width), blue, and red with the coat of
arms superimposed at the center of the flag;
similar to the flag of Colombia that is shorter
and does not bear a coat of arms
Names:
conventional long form: Republic of Peru
conventional short form: Peru
local long farm: Republica del Peru
local short form: Peru
Digraph: PE
Type: republic
Capital: Lima
Administrative divisions: 24 departments
(departamentos, singular — departamento) and
1 constitutional province''" (provincia
constitucional): Amazonas, Ancash,
Apurimac, Arequipa, Ayacucho. Cajamarca.
Callao''", Cusco, Huancavelica, Huanuco, Ica.
Junin, La Libenad. Lambayeque, Lima,
Loreto, Madre de Dios, Moquegua, Pasco,
Piura, Puno. San Martin. Tacna, Tumbes,
Ucayali
note: the 1979 Constitution and legislation
enacted from 1987 to 1990 mandate the
creation of regions (regiones, singular —
region) intended to function eventually as
autonomous economic and administrative
entities; so far. 12 regions have been
constituted from 23 existing departments —
Amazonas (from Loreto), Andres Avelino
Caceres (from Huanuco. Pasco, Junin),
Arequipa (from Arequipa), Chavin (from
Ancash), Grau (from Tumbes, Piura), Inca
(from Cusco. Madre de Dios, Apurimac), La
Libertad (from La Libertad), Los
Libenadores-Huari (from Ica. Ayacucho,
Huancavelica). Mariategui (from Moquegua,
Tacna, Puno), Nor Oriental del Maranon (from
Lambayeque, Cajamarca, Amazonas). San
Martin (from San Martin). Ucayali (from
Ucayali); formation of another region has been
delayed by the reluctance of the constitutional
province of Callao to merge with the
department of Lima. Because of inadequate
funding from the central government and
organizational and political difficulties, the
regions have yet to assume major
responsibilities. The 1993 Constitution
maintains the regionalization process with
some modifications that will limit the powers
of the regional governments. The new
constitution also reaffirms the roles of
departmental and municipal governments.
Independence: 28 July 1821 (from Spain)
National holiday: Independence Day, 28 July
(1821)
Constitution; 31 December 1993
Legal system: based on civil law system; has
not accepted compulsory ICJ jurisdiction
SufDrage: 1 8 years of age; universal
Executive branch:
chief of state and head of government:
President Alberto Kenyo RJJIMORI Fujimori
(since 28 July 1990); election last held on 10
June 1990 (next to be held NA April 1995);
results — Alberto FUJIMORI 56.53%, Mario
VARGAS Llosa 33.92%, other 9.55%
cabinet: Council of Ministers; appointed by
the president
note: Prime Minister Efniin GOLDENBERG
Schreiber (since February 1994) does not
exercise executive power; this power is in the
hands of the president
Legislative branch: unicameral
Democratic Constituent Congress (CCD):
elections last held 25 November 1992 (next to
be held April 1995); seats — (80 total) New
Majority/Change 90 44, Popular Christian
Party 8, Independent Moralization Front 7,
Renewal 6, Movement of the Democratic Left
4, Democratic Coordinator 4, others 7; note —
several major patties (American Popular
Revolutionary Alliance, Popular Action) did
not participate; with the next election the
congress will be expanded to 100 seals
Judicial branch: Supreme Court of Justice
(Corte Suprcma de Juslicia)
Political parties and leaders;
note: Peru''s political party sy.stem has become
fragmented in recent years with independent
movements proliferating; key parties are listed
New Majority/Change 90 (Cambio 90).
Alberto FUJIMORI; Popular Christian Party
(PPC), Luis BEDOYA Reyes; Popular Action
Party (AP). Raul DIEZ CANSECO; American
Popular Revolutionary Alliance (APRA),
Armando VILLANUEVA del CAMPO;
Independent Moralizing Front (HM),
Fernando OLIVERA Vega; National Renewal.
Rafael REY Rey; Democratic Coordinator,
Jose BARBA Caballero; Democratic Left
Movement, Henry PEASE; Solidarity and
Democracy (SODE), Manuel MOREYRA;
National Front of Workers and Peasants
(FRENATRACA), Roger CACARES
Other political or pressure groups: leftist
guerrilla groups include Shining Path, Abimael
GUZMAN Reynoso (imprisoned); Tupac
Amaru Revolutionary Movement, Nestor
SERPA and Victor POLAY (imprisoned)
Member of: AG, CCC, ECLAC, FAO, G- 1 1 ,
G- 1 5, G- 1 9, G-24, G-77, GATT. I ADB, IAEA,
IBRD, ICAO, ICFTU, IDA. IFAD, IFC, ILO.
IMF. IMO, INMARSAT, INTELSAT,
INTERPOL. IOC, lOM. ISO (correspondent).
ITU, LABS, LAIA, LORCS, NAM, OAS,
OPANAL. PCA. RG (suspended). UN.
UNCTAD, UNESCO. UNIDO. UPU, WCL,
WFTU, WHO. WIPO. WMO, WTO
Diplomatic representation in US;
chief of mission: Ambassador Ricardo LUNA
Mendoza
chancery: 1 700 Massachusetts Avenue NW.
Washington. DC 20036
telephone: (202) 833-9860 through 9869
FAX: (202) 659-8124
consulate(s) general: Chicago, Houston, Los
Angeles, Miami, New York, Paterson (New
Jersey), and San Francisco
US diplomatic representation:
chief of mission: Ambassador Alvin P.
ADAMS. Jr.
embassy: comer of Avenida Inca Garcilaso de
la Vega and Avenida Espana, Lima
mailing address: P. O. Box 1991, Lima I , Unit
3822, or APO AA 34031
telephone: [51] (14) 33-8000
FAX: [511(14)31-6682
Flag: three equal, vertical bands of red (hoist
side), white, and red with the coat of arms
centered in the white band; the coat of arms
features a shield bearing a llama, cinchona tree
(the source of quinine), and a yellow
cornucopia spilling out gold coins, all framed
by a green wreath','04174791b3c0a870f869b987b21f8a7e15e1cc93a2e94e46e2366c958a0a4c80','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4021cf688090b119625049b2d4625703ee22331614303f591080ed169503dafa',1994,'EG','Egypt','government',339,'Names;
conventional long form: Arab Republic of
conventional short form: Egypt
local long form: Jumhuriyat Misr al-.Arabiyah
local short form: none
former: United Arab Republic (with Syria)
Digraph: EG
Type: republic
Capital: Cairo
Administrative divisions: 26 govemorates
(muhafazat, singular — muhafazah); Ad
Daqahliyah, Al Bahr al Ahmar, Al Buhayrah,
Al Fayyum, Al Gharbiyeh, Al Iskandariyah, Al
Isma''iliyah, Al Jizah, Al Minufiyah, Al Minya,
Al Qahirah, Al Qalyubiyah, Al Wadi al Jadid,
Ash Sharqiyah, As Suways, Aswan, Asyu''t,
Bani Suwayf. Bur Sa''id, Dumyat. Janub Sina,
Kafr ash Shaykh, Matruh, Qina, Shamal Sina,
Suhaj
Independence: 28 February 1922 (from UK)
National holiday: Anniversary of the
Revolution. 23 July (1952)
Constitution: IlSeptembtr 971
Legal system: based on English common law,
Islamic law. and Napoleonic codes: judicial
review by Supreme Court and Council of State
(oversees validity of administrative decisions);
accepts compulsory ICJ jurisdiction, with
reservations
Suffrage: 1 8 years of age; universal and
compulsory
Executive branch:
chief of state: President Mohammed Hosni
MUBARAK (was made acting President on 6
October 1 98 1 upon the assassination of
President SADAT and sworn in as president on
14 October 1981); national referendum held 4
October 1993 validated Mubarak’s nomination
by the People’s Assembly to a third 6-year
presidential term
head of government: Prime Minister Atef
Mohammed Najib SEDKY (since 1 2
November 1986)
cabinet: Cabinet; appointed by the president
Legislative branch: bicameral
People ''s Assembly (Majlts al-Cha ’b):
elections last held 29 November 1990 (next to
be held NA November 1995); results — NDP
86.3%, NPUG 1.3%. independents 12,4%;
seats — (454 total, 444 elected. 10 appointed by
the president) NDP 383, NPUG 6,
independents 55; note — most opposition
parties boycotted; NDP figures include NDP
members who ran as independents and other
NDP-affiliated independents
Advisory Council (Majlis al-Shura):
functions only in a consultative role; elections
last held 8 June 1 989 (next to be held NA June
117
Egypt (continued)
1995); results — NDP 100%; seats — (258 total,
1 72 elected, 86 appointed by the president)
NDP 172
Judicial branch: Supreme Constitutional
Court
Political parties and leaders: National
Democratic Party (NDP), President
Mohammed Hosni MUBARAK, leader, is the
dominant party; legal opposition parties are;
New Wafd Party (NWP), Fu’ad SIRAJ AL-
DIN; Socialist Labor Party, Ibrahim SHUKRI;
National Progressive Unionist Grouping
(NPUG), Khalid MUHYI-AL-DIN; Socialist
Liberal Party (SLP), Mustafa Kamal MURAD;
Democratic Unionist Party, Mohammed ’Abd-
al-Mun''im TURK; Umma Party, Ahmad al-
SABAHI; Misral-Fatah Party (Young Egypt
Party), Ali al-Din SALIH; Nasserist Arab
Democratic Patty. Dia'' al-din DAWUD;
Democratic Peoples’ Party, Anwar AFIFI; The
Greens Party, Kamal KIRAH
note: formation of political parties must be
approved by government
Other political or pressure groups: the
constitution bans religious-based political
parties; nonetheless, the government tolerates
limited political activity by tbe technically
illegal Muslim Brotherhood, which constitutes
Mubarak''s chief political opposition; trade
unions and professional associations are
officially sanctioned
Member of: ABEDA. ACC, ACCT
(associate), AfDB, AFESD, AO (observer),
AL, AMF, CAEU, CCC, EBRD, ECA,
ESCWA, FAO, G-15, G-19, G-24, G-77.
GATT, IAEA, IBRD, ICAO, ICC, IDA, IDB,
IFAD. IFC. ILO. IMF, IMO, INMARSAT.
INTELSAT, INTERPOL, IOC, lOM, ISO,
ITU, LORCS, MINURSO, NAM, OAPEC,
OAS (observer), OAU, OIC, PCA, UN,
UNAVEM II, UNCTAD, UNESCO, UNIDO,
UNOMOZ, UNOSOM, UNPROFOR,
UNTAC, UPU, UNRWA, WHO. WlPO,
WMO, WTO
Diplomatic representation in US:
chief of mission: Ambassador Ahmed Maher
El SAYED
chancery: 2310 Decatur Place NW,
Washington, DC 20008
telephone: (202) 232-5400
consulate(s) general: Chicago, Houston, New
York, and San Francisco
US diplomatic representation:
chief of mission: Ambassador Edward
WALKER
embassy: (North Gate) 8, Kamel El-Din Saleh
Street, Garden City, Cairo
mailing address: APO AE 09839-4900
telephone: [20](2) 355-7371
FAX: [20] (2) 357-.3200
Flag: three equal horizontal bands of red
(top), white, and black with the national
emblem (a shield superimposed on a golden
eagle facing the hoist side above a scroll
bearing the name of the country in Arabic)
centered in the white band; similar to the flag
of Yemen, which has a plain white band; also
similar to the flag of Syria that has two green
stars and to the flag of Iraq, which has three
green .stars (plus an Arabic inscription) in a
horizontal line centered in the white band','a552d1ec47ef15bc9808cbe0d5f0ac67f55fa4261ea521c5ee975537faa30e26','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a5c1da2c060a8c9fb6735d96d7bcec71acc1dfc0ab7b7c64fa15a42d68dd85c',1994,'HN','Honduras','government',346,'Names:
conventional long form; Republic of El
Salvador
conventional .short form; El Salvador
local long form; Republica de El Salvador
local short form; El Salvador
Digraph: ES
Type; republic
119
El Salvador (continued)
Capital: San Salvador
Administrative divisions: 1 4 departments
(departamentos, singular — departamento):
Ahuachapan. Cabanas, Chalatenango.
Cuscatlan, La Liberiad. La Paz, La Union,
Morazan. San Miguel. San Salvador, Santa
Ana, San Vicente, Sonsonate, Usulutan
Independence: 15 September 1821 (from
Spain)
National holiday: Independence Day, IS
September (1821)
Constitution: 20 December 198.^
Legal system: based on civil and Roman law,
with traces of common law; judicial review of
legislative acts in the Supreme Coun: accepts
compulsory ICJ Jurisdiction, with reservations
Suffrage: 1 8 years of age: universal
Executive branch:
chief of state and head of government:
President Armando CALDERON SOL (since 1
June 1994); Vice President Enrique BORGO
Bustamante (since 1 June 1994) election last
held 20 March 1994 (next to be held March
1999); results— Armando CALDERON SOL
(ARENA) 49.03^^, Ruben ZAMORA Rivas
(CD/FMLN/MNR) 24.09%. Fidel CHAVEZ
Mena (PDC) 16.39%, other 10.49%; because
no candidate received a majority, run off
election was held 24 April 1994; results —
Armando CALDERON SOL (ARENA)
68.35%. Ruben ZAMORA Rivas (CD/FMLN/
MNR) 31.6.5%
cabinet: Council of Ministers
Legislative branch: unicameral
Legislative Assembly (Asamblea Legislativa):
elections last held 20 March 1994 (next to be
held March 1997); results— ARENA 46.4%.
FMLN 25.0%. PDC 21.4%, PCN4.8%, other
2.4%: seats— (84 total) ARENA 39, FMLN 2 1 ,
PDC 18. PCN 4. other 2
Judicial branch: Supreme Court (Cone
Suprema)
Political parties and leaders; National
Republican Alliance (ARENA); Farabundo
Marti National Liberation Front (FMLN) has
five factions — Popular Liberation Forces
(FPL). Armed Forces of National Resistance
(FARN). Popular Expression of Renewal
(ERP). Salvadoran Communist Party (PCES).
and Central American Workers'' Revolutionary
Party (PRTC); Christian Democratic Party
(PDC); National Conciliation Party (PCN);
Democratic Convergence (CD), a coalition of
three parties — the Social Democratic Party
(PSD), Democratic Nationalist Union (UDN),
and the Popular Social Christian Movement
(MPSC); Authentic Christian Movement
(MAC)
note: new party leaders not yet designated at
time of publication
Other political or pressure groups:
labor organizations: Salvadoran Communal
Union (UCS). peasant association; General
Confederation of Workers (CGT). moderate;
United Workers Front (FUT)
business organizations: Productive Alliance
(AP), conservative; National Federation of
Salvadoran Small Businessmen (FENAPES),
conservative
Member of: BCIE, CACM, ECLAC. FAO,
G-77, GATT, lADB. IAEA, IBRD, ICAO,
ICFTU, IDA, IFAD, IFC. ILO, IMF. IMO.
INTELSAT. IOC. lOM. ITU. LAES, LAIA
(observer), LORCS, NAM (observer), OAS,
OPANAL, PCA. UN. UNCTAD. UNESCO.
UNIDO, UPU. WCL, WFTU. WHO. WIPO,
WMO
Diplomatic representation In VS:
chief of mission: Ambassador Ana Cristina
SOL
chancery: 2308 California Street NW.
Washington. DC 20008
telephone: (202) 265-9671 or 9672
consulate(s) general: Chicago. Houston. Los
Angeles, Miami, New Orleans, New York, and
San Francisco
US diplomatic representation:
chief of mission: Ambassador Alan H,
FLANIGAN
embassy: Final Boulevard. Station Antigua
Cuscatlan. San Salvador
mailing address: Unit 3116, San Salvador;
APO AA 34023
telephone: (503] 78-4444
FAX: [503] 78-601 1
Flag: three equal horizontal bands of blue
(top), white, and blue with the national coat of
arms centered in the white band; the coat of
arms features a round emblem encircled by the
words REPUBLICA DE EL SALVADOR EN
LA AMERICA CENTRAL; similar to the flag
of Nicaragua, which has a different coat of
arms centered in the white band — it features a
triangle encircled by the words REPUBLICA
DE NICARAGUA on top and AMERICA
CENTRAL on the bottom; also similar to the
flag of Honduras, which has five blue stars
arranged in an X pattern centered in the white
band
Names;
conventional long form: Republic of Honduras
conventional short form: Honduras
local long form: Republica de Honduras
local short form: Honduras
Digraph; HO
Type: republic
175
Honduras (continued)
Capital: Tegucigalpa
Administrative divisions: 1 8 departments
(departamentos. singular — departamento):
Atlantida, Choluteca, Colon, Comayagua,
Copan, Cortes, El Paraiso, Francisco Morazan,
Gracias a Dios, Intibuca, Islas de la Bahia, La
Paz., Lempira, Ocotepeque, Olancho, Santa
Barbara, Valle, Yoro
Independence: LS September 1821 (from
Spain)
National holiday: Independence Day. 15
September (1821)
Constitution: 1 1 January 1982, effective 20
January 1982
Legal system: rooted in Roman and Spanish
civil law; some influence of English common
law; accepts ICJ jurisdiction, with reservations
Suffrage: 1 8 years of age; universal and
compulsory
Executive branch:
chief of xiate ami head of f;ovemmein:
President Carlos Roberto REINA idiaquez.
(since 27 January 1994); election last held on
28 November 1993 (next to be held November
1997); results — Carlos Roberto REINA
idiaquez (PLH) 53%. Oswaldo RAMOS Soto
(PNH)41%. other 6%
cahinet: Cabinet
Legislative branch: unicameral
Naiional Conarexs (Congreso Naciomd):
elections last held on 27 November 1993 (next
to be held November 1997); results — PNH
5.3%,PLH41%,PDCH 1.()%,PINU-SD 2.5%.
other 2.5%; seats— (134 total) PNH 55, PLH
77. PINU-SD 2
Judicial branch; Supreme Court of Justice
(Corte Suprema de Justica)
Political parties and leaders: Liberal Party
(PLH). Rafael PINEDA Ponce, president;
National Party (PN) has two factions:
Movimiento Nacionul de Reivindication
Callejista (Monarca). Rafael Leonardo
CALLEJAS. and Oswaldista. Oswaldo
RAMOS Soto, presidential candidate; National
Innovation and Unity Party (PINU), Olban
VALLADARES, president; Christian
Democratic Party (PDCH), Efrain DIAZ
Arrivillaga. president
Other political or pressure groups:
National Association of Honduran Campesinos
(ANACH); Honduran Council of Private
Enterprise (COHEP); Confederation of
Honduran Workers (CTH); National Union of
Campesinos (UNO; General Workers
Confederation (CGT); United Federation of
Honduran Workers (FUTH); Committee for
the Defense of Human Rights in Honduras
(CODEH); Coordinating Committee of
Popular Organizations (CCOP)
Member of: BCIE, CACM. ECLAC. FAO,
G-77, GATT. lADB. IBRD, ICAO, ICFTU.
IDA. IFAD. IFC, ILO. IMF. IMO,
INTELSAT. INTERPOL, IOC, lOM, ITU.
LAES. LAIA (observer). LORCS, MINURSO.
OAS. OPANAL. PCA. UN. UNCTAD,
UNESCO. UNIDO. UPU, WCL. WFTU.
WHO, WIPO, WMO
Diplomatic representation in US:
chief of mission; Ambassador Rene Arturo
BENDANA
chancery; 3007 Tilden Street NW,
Washington. DC 20(X38
telephone; (202) 966-7702, 2604. 5008, 4596
FAX; (202)966-9751
consiilateisj general; Chicago. Houston, Los
Angeles, Miami, New Orleans, New York. San
Francisco, and San Juan (Puerto Rico)
consulaie(sl; Boston, Detroit, and Jacksonville
US diplomatic representation:
chief of mission; Ambassador William
PRYCE
embassy; Avenida La Paz, Tegucigalpa
mailing address; American Embassy, APO
AA 34022, Tegucigalpa
telephone; (5041 32-3120
FAX; [5041 32-0027
Flag: three equal horizontal bands of blue
(top), white, and blue with five blue five-
pointed stars arranged in an X pattern centered
in the white band; the stars represent tfie
members of the former Federal Republic of
Central America — Costa Rica. El Salvador,
Guatemala, Honduras, and Nicaragua; similar
to the flag of El Salvador, which features a
round emblem encircled by the words
REPUBLICA DE EL SALVADOR EN LA
AMERICA CENTRAL centered in the white
band; also similar to the flag of Nicaragua,
which features a triangle encircled by the word
REPUBLICA DE NICARAGUA on top and
AMERICA CENTRAL on the bottom,
centered in the white band','9b844b12ef754acdd430b893f6b3c7edfca5ca3a8d1e746e6d88e9d450d6915d','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c3676c504e1d7bcd7c598fc143ff5b908c57ebec4d8d8a33c54b45ad0bb6015',1994,'GQ','Equatorial Guinea','government',353,'Names:
conventional long form: Republic of
conventional short form: Equatorial Guinea
liK ol long form: Republica de Guinea
Ecuatorial
local short form: Guinea Ecuatorial
former: Spanish Guinea
Digraph: EK
Type: republic in transition to multiparty
democracy
Capital: Malabo
Administrative divisions: 7 provinces
(provincias. singular — provincial; Annobon,
Bioko Norte. Bioko Sur, Centro Sur. Kie-
Ntem, Litoral, Wele-Nzas
Independence: 1 2 October 1 968 (from Spain)
National holiday: Independence Day, 12
October (1968)
Constitution: new constitution 1 7 November
1991
Legal system: partly based on Spanish civil
law and tribal custom
Sufikage: universal adult at age NA
121
Equatorial Guinea (coniimieii}
Executive branch:
chii''f of xiiiiv; Presidenl Brig. Gen. (Ret.)
Teodoro OBIANG NGUEMA MBASOGO
(since } August 1 979) election last held 25
June 1989 (next to be held 25 June 19%);
results — President Brig. Gen, (Ret.) Teixloix)
OBIANG NGUEMA MBASOGO was
reelected without oppirsition
head of fioveniment: Prime Minister Silvestre
SIALEBILEKA (since 1 7 January 1 992); Vice
Prime Minister Anatolio NDONG MBA (since
November 199.^);
eahinei: Council of Ministers; appointed by
the president
Legislative branch: unicameral
House of People''s Repivsematives: (Camara
de Representantes del Pueblo) elections last
held 21 November 1993); seat.s — (82 total)
PDGE 72, various opposition parties 10
Judicial branch: Supreme Tribunal
Political parties and leaders: ruling —
Democratic Party for Equatorial Guinea
(PDGE), Brig. Gen. (Ret.) Teodoro OBIANG
NGUEMA MBASOGO, party leader;
Progressive Democratic Alliance (ADP).
Antonio-Ebang Mbele Abang, president;
Popular Action of Equatorial Guinea
(APGE).Cusiano Masi Edu. leader; Liberal
Democratic Convention (CLD). Alfonso Nsue
MOKUY, president; Convergence for Social
Democracy (CPDS).Santiago Obama Ndong,
president; Social Democratic and Popular
Convergence (CSDP), Secundino Oyono
Agueng Ada, general secretary; Party of the
Social Democratic Coalition (PCSD),
Buenaventura Moswi M''Asumu, general
coordinater; Liberal Party (PL), leaders
unknown; Party of Progress (PP), Severn
MOTO Nsa, president; Social DeoKKratic
Party (PSD) , Benjaniin-Gabriel Balingha
Balinga Alene, general secretary; StK''ialist
Party of Equatorial Guinea (PSGE). Tomas
MICHEBE Fernandez, general secretary;
National Democratic Union (UDENA). Jose
MECHEBA Ik.ika, president; Democratic
Swial Union (L''DS), Jesus Nze Obama
Avomo. general secretary; Popular Union
(UP), Juan Bitui. president
Member of: ACCT, ACP, AIDB. BDEAC,
CEEAC, ECA. FAO, FZ. G-77, IBRD, ICAO.
IDA, IFAD, IFC, ILO, IMF, IMO. INTELSAT
(nonsignatory user), INTERPOL, IOC, ITU,
LORCS (as.sociatc), NAM, OAS (observer),
OAU. UDEAC, UN, UNCTAD, UNESCO,
UNIDO. UPU, WHO
Diplomatic representation in US:
chief of mission: Ambassador DAMASO
Obiang Ndong
cluwceiy: (temporary) 57 Magnolia Avenue,
Mount Vernon. NY 10553
telephone: (914) 738-9584 or 6fi7-69l3
MX; (914) 667-6838
US diplomatic representation:
chief of mission: Ambassador John E.
BENNETT
embassy: Calle de Los Ministros. Malabo
mailitift address: P.O. Box .597. Malabo
telephone: 1240| (9) 2185. 2406. 2.507
F.4X; 12401 (9)2164
Flag: three equal horizontal bands of green
(top), white, and red with a blue isosceles
triangle based on the hoist side and the coat of
amts centered in the white band: the coat of
arms has six yellow six-pointed stars
(representing the mainland and five offshore
islands) above a gray shield bearing a silk-
cotton tree and below which is a scroll with the
motto UNIDAD. PAZ. JUSTICIA (Unity.
Peace. Justice)','b9f226b638ca29ddad2f31d586a4935a75fcdc5a872e5e1f9585af30715c4e22','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c167fdcc695bdb9a4bbf8f8642885a5e43f5a3c8ed6b5d9f4924acf9a08c556',1994,'ER','Eritrea','government',358,'Names:
conventional long form; State of Eritrea
conventional short form: Eritrea
local long form: none
local short form; none
former; Eritrea Autonomous Region in
Names:
conventional long form: none
conventional short fonn: Ethiopia
local long form: none
local short form: Ityop’iya
Digraph: ET
Type: transitional government
note: on 28 May 1991 the Ethiopian People''s
Revolutionary Democratic Front (EPRDF)
toppled the authoritarian government of
MENGISTU Haile-Mariam and took control in
Addis Ababa; the Transitional Government of
Ethiopia (TGE), announced a two-year
transitional period
Capital: Addis Ababa
Administrative divisions: 14 administrative
regions (astedader akababiwach, singular —
astedadcr akababi) Addis Ababa. Afar,
Amhara. Benishangul. Gambela.
126
Gurage-Hadiya-Kambata, Harer, Kefa, Omo,
Oromo, Sidamo, Somali, Tigray, Wolayta
Independence: oldest independent country in
Africa and one of the oldest in the world — at
least 2,000 years
National holiday: National Day, 28 May
(1991) (defeat of Mengistu regime)
Constitution: to be redrafted by 1993
Legal system: NA
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President MELES Zenawi (since
I June 1991); election last held 10 September
1987; next election planned after new
constitution drafted; results — MENGISTU
Haile-Mariam elected by the now defunct
National Assembly, but resigned and left
Ethiopia on 2 1 May 1991
head of government: Prime Minister
TAMIRAT Layne (since 6 June 1991)
cabinet: Council of Ministers; designated by
the chairman of the Council of Representatives
Legislative branch: unicameral
Constituent Assembly: elections were held on
5 June 1994 (next to be held NA); results —
NA; a major task of the new Assembly will be
to ratify the constitution to drafted by the end
of 1994
Judicial branch: Supreme Court
Political parties and leaders: Ethiopian
People’s Revolutionary Democratic Front
(EPRDF), MELES Zenawi; Oromo People''s
Democratic Organization (OPDO), Kuma
DEMEKSA
Other political or pressure groups; Oromo
Liberation Front (OLF); Ethiopian People''s
Revolutionary Party (EPRP); numerous small,
ethnic-based groups have formed since
Mengistu’s resignation, including several
Islamic militant groups
Member of: ACP, AfDB, CCC, ECA, FAO,
G-24, G-77, IAEA. IBRD, ICAO. IDA. IFAD,
IFC. IGADD, ILO. IMF. IMO. INTELSAT.
INTERPOL, IOC, ISO, ITU, LORCS, NAM.
OAU, UN. UNCTAD, UNESCO. UNHCR,
UNIDO, UPU, WFTU. WHO, WMO, WTO
Diplomatic representation in US:
chief of mission: Ambassador BERHANE
Gebre-Christos
chancery: 2 1 34 Kalorama Road NW.
Washington, DC 20008
telephone: (202) 234-2281 or 2282
FAX: (202) 328-7950
US diplomatic representation;
chief of mission: Ambassador Marc A. BAAS
embassy: Enteto Street. Addis Ababa
mailing address: P. O. Box 1 0 1 4, Addis Ababa
telephone: 1 25 1 1 ( I ) 550-666
MX.- [2511 (1)552-191
Flag: three equal horizontal bands of green
(top), yellow, and red: Ethiopia is the oldest
independent country in Africa, and the colors
of her flag were so often adopted by other
African countries upon independence that they
became known as the pan-African colors','f0e4c9fc1234851f423a21494ae89be45be8f245acdfe2dc213bb56187189bb0','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('056921b2748fd12790bc157021060e98d1fd0c4f5532c74362b0da8153f50932',1994,'EE','Estonia','government',364,'Names;
conventional long form; Republic of Estonia
conventionci short form; Estonia
ItKal long form; Eesti Vabariik
local short form; Eesti
former; Estonian Soviet Socialist Republic
Digraph: EN
Type: tepublic
Capital; Tallinn
Administrative divisions: 15 counties
(maaknnnad, singular — maakond) and 6
municipalities*: Harju maakond (Tallinn),
Hiiu maakond (Kardia), Ida-Vira maakond
(Johvi). Jarva maakond (Paide). Jogeva
maakond (Jogeva). Kohtla-Jarve*. Laane
maakond (Haapsalu). Laane-Viru maakond
(Rakvere). Narva*. Pamu*. Pamu maakond
(Pamu). Polva maakond (Polva), Rapla
maakond (Rapla), Saare maakond (Kuessaate),
Sillamae*. Tallinn*. Tartu*. Tartu maakond
(Tartu). Valga maakond (Valga), Viljandi
maakond (Viljandi). Voru maakond (Voru)
note; county centers are in parentheses
Independence: 6Septemt«r 1991 (from
Soviet Union)
National holiday: Independence Day. 24
February (1918)
Constitution: adopted 28 June 1992
Legal system: based on civil law system: no
judicial review of legislative acts
Suffrage: 18 years of age; universal
Executive branch:
chief of state; President Lennart MERl (since
21 October 1992): election last held 20
124
September 1992; (next to be held NA 1997);
results — no candidate received majority;
newly elected Parliament elected Lennart
MERl (21 October 1992)
head of government: Prime Minister Mart
LAAR (since 21 October 1992)
cabinet; Council of Ministers; appointed by
the prime minister, authorized by the
legislature
Legislative branch: unicameral
Parliament (Riigikogu); elections last held 20
September 1992; (next to be held NA);
results — Fatherland 219L. Safe Haven 14%.
Popular Front 1.1%, M 10%, ENIP 8%. ERP
7%. ERL 7%. EP 2%. other 18%; seats— (101
total) Fatherland 29, Safe Haven 18. Popular
Front 15. M 12, ENIP 10, ERP 8, ERL 8. EP 1
Judicial branch: Supreme Court
Political parties and leaders: National
Coalition Party ''Pro Patria'' (Isamaaof
Fatherland), Mart LAAR. president, made up
of 4 parties: Christian Democratic Party
(KDE). Aivar KALA, chairman; Christian
Democratic Union (KDL), lllar HALLASTE,
chairman; Conservative People’s Party (KR).
Enn TARTO, chairman: Republican Coalition
Party (VK). Leo STARKOV, chairman;
Moderates (M). made up of two parties;
Estonian Social Democratic Patty (ESDB),
Marju LAURISTIN, chairman; Estonian Rural
Center Pary (EMK). Ivar RAIG. chairman;
Estonian National Independence Party (ENIP),
T unne KELAM, chairman; Liberal Democratic
Party (LDP), Paul-Eerik RUMMO, chairman;
Safe Haven, made up of three parties: Estonian
Coalition Party (EK), Tiit VAHI. chairman;
Estonian Rural Union (EM). Arvo SIRENDI.
chairman; Estonian Democratic Justice Union/
Estonian Pensioners’ League (EDO/EPU),
Harri KARTNER, chairman; Estonian Centrist
Party (EK), Edgar SAVISAAR, chairman;
Estonian Democratic Labor Party (EDT),
Vaino VAUAS, chairman: Estonian Green
Party (ERL). Tonu OJA; Estonian Royalist
Party (ERP). Kalle KULBOK, chairman;
Entrepreneurs’ Party (EP), Tiit MADE;
Estonian Citizen (EKL). Juri TCXJMEPUU,
chaiiman
Member of: BIS, CBSS, CCC. CE. CSCE.
EBRD. ECE, FAO, IAEA, IBRD, ICAO,
ICFTU, IFC, ILO, IMF, IMO, INTERPOL,
IOC. ISO (correspondent). ITU. NACC, UN.
UNCTAD, UNESCO. UPU, WHO, WMO
Diplomatic representation In US;
chief of mission; Ambassador Tinimas
Hendrik ILVES
chancers; 1030 15th Street NW, Washington.
DC 20005, Suite 1000
telephone; (202) 789-0320
FAX; (202) 789-0471
consulate! s) general; New York
US diplomatic representation:
chief of mission; Ambassador Robert C.
ERASURE
embassy: Kentmanni 20. Tallin EE(X)01
mailing uildress: use embassy street address
telephone; 01 1 -|372] (6) 3 1 2-02 1 through 024
FAX; 1372) (6) 312-025
Flag: pre-1940 flag re.siored by Supreme
Soviet in May 1990 — three equal horizontal
bands of blue (top), black, and white','44a86017668b29c2cc15a232f8543f877d4cdc23098e39e10b2aa140cbee5f66','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6812dcc0c4f06c4543e5ae7c325928ae30b28ddb792fc958045eeab56bbb9e1b',1994,'AR','Argentina','government',374,'Names:
conventional long form: Colony of the
Falkland Islands
conventional short form: Falkland Islands
(Islas Malvinas)
Digraph: FA
Type: dependent territory of the UK
Capital: Stanley
Administrative divisions: none (dependent
territory of the UK»
Independence: none (dependent territory of
the UK)
National holiday: Liberation Day. 14 June
(1982)
Constitution: 3 October 1985
Legal system: English common law
Suffrage: 18 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH 11 (since 6
February 1952)
head of government: Governor David Everard
TATHAM (since August 1992)
cabinet: Executive Council; 3 members
elected by the Legislative Council. 2 ex-officio
members (chief executive and the financial
secretary), and the governor
Legislative branch: unicameral
Legislative Council: elections last held 1 1
October 1989 (next to be held October 1994);
results — percent of vote by party NA; seats —
( 10 total, 8 elected) number of seats by party
NA
Judicial branch: Supreme Court
Political parties and leaders: NA
Member of: ICFTU
Diplomatic representation in US: none
(dependent territoiy of the UK)
US diplomatic representation: none
(dependent territory of the UK)
Flag: blue with the flag of the UK in the upper
hoist-side quadrant and the Falkland Island
coat of arms in a white disk centered on the
outer half of the flag: the coat of arms contains
a white ram (sheep raising is the major
economic activity) above the sailing ship
Desire (whose crew discovered the islands)
with a scroll at the bottom bearing the motto
DESIRE THE RIGHT','6cbfb4c5aeb3728f5368886d638a36c00c4b69cdacf1020a8107893a85d01518','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('929ecae083f144038074f9d7aa88d222b868f6217a692f1f18f15f75c1f2abed',1994,'FO','Faroe Islands','government',379,'Names:
conventional long form: none
conventional short form: Faroe Islands
local long form: none
local short form: Foroyar
Digraph: FO
Type: part of the Danish realm; self-
governing overseas administrative division of','837bc24a51e661ac8c30e7a111025a83db107d8b60be5095c9e8fa45f4018ae3','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('956ba6b0f081fa9d73e53a03a93824f7a4525d38906aa3be70b21d69ef693b5a',1994,'DK','Denmark','government',380,'Capital: Torshavn
Administrative divisions: none (self-
governing overseas administrative division of
Denmark)
Independence: none (part of the Danish
realm; self-governing overseas administrative
division of Denmark)
National holiday: Birthday of the Queen, 16
April (1940)
Constitution: 5 June 1953 (Danish
constitution)
Legal system: Danish
Suffk''age; 20 years of age; universal
Executive branch:
chief of state: Queen MARGRETHE II (since
14 January 1972), represented by High
Commissioner Bent KLINTE (since NA)
head of government: Prime Minister Marita
PETERSEN (since 18 January 1993)
cabinet: Landsstyri; elected by the local
legislature
Legislative branch: unicameral
Faroese Parliament (Loegting): elections last
held 17 November 1990 (next to be held
November 1994); results- -Social Democratic
27.4%, People’s Party 2 1 .9%, Cooperation
Coalition Party 18.9%, Republican Party
14.7%, Home Rule 8.8%. PRP-CPP 5.9%,
other 2.4%; seats — (32 total) two-party
coalition 17 (Social Democratic 10, People''s
Party 7), Cooperation Coalition Party 6,
Republican Party 4, Home Rule 3, PFIP-CPP 2
Danish Parliament: elections last held on 12
December 1990 (next to be held by December
1994); results — percent of vote by party NA;
seats — (2 total) Social Democratic 1, People’s
Party 1 ; note — the Faroe Islands elects two
representatives to the Danish Parliament
Judicial branch: none
Political parties and leaders:
three-party ruling coalition: Social
Democratic Party, Marita PETERSEN;
Republican Party, Signer HANSEN; Home
Rule Party, Hilmar KASS
opposition: Cooperation Coalition Party, Pauli
ELLEFSEN; Progressive and Fishing Industry
Party-Christian People’s Party (PFIP-CPP),
leader NA; Progress Party, leader NA;
People’s Party, Jogvan SUND-STEIN
Member of; none
Diplomatic representation in US: none
(self-governing overseas administrative
division of Denmark)
US diplomatic representation: none (self-
governing overseas administrative division of
Denmark)
Flag: white with a red cross outlined in blue
that extends to the edges of the flag; the vertical
part of the cross is shifted to the hoist side in
the style of the DANNEBROG (Danish flag)','2e58820b8138a1b1dc79af56612fed4b9e0578bcd753461e7c00751ed5bdfe92','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32129d7a28036e6c6544ec9e197d9d41102329f3299941b497bf5d4400871d9c',1994,'JE','Jersey','government',386,'Names:
conventional long form: Republic of Fiji
conventional short form: Fiji
Digraph: FJ
Type: republic
note: military coup leader Maj. Gen. Sitiveni
RABUKA formally declared Fiji a republic on
6 October 1987
Capital: Suva
Administrative divisions: 4 divisions and I
dependency*; Central. Eastern, Northern.
Rotuma*, Western
Independence: 10 October 1970 (from UK)
National holiday: Independence Day, 10
October (1970)
Constitution: 10 October 1970 (suspended 1
October 1987); a new Constitution was
proposed on 23 September 1988 and
promulgated on 25 July 1990; the 1990
Constitution is under review; the review will be
complete by 1997
Legal system; based on British system
Suffrage: none
Executive branch:
chief of stale: President Ratu Sir Kamisese
MARA (since 12 January 1994); First Vice
President Ratu Sir Josaia TAIVAiQlA (since
1 2 January 1 994); Second Vice President Ratu
Inoke TAKIVEiKATA (since 12 January
1994); note — President GANILAU died on 15
December 1993 and Vice President MARA
became acting president; MARA was elected
president by the Great Council of Chiefs on 12
January 1994
head of government: Prime Minister Sitiveni
RABUKA (since 2 June 1992)
Presidential Council: appointed by the
governor general
Great Council of Chiefs: (highest ranking
members of the traditional chiefly system)
cabinet: Cabinet; appointed by prime minister
from members of Parliament and responsible
to Parliament
Legislative branch: the bicameral Parliament
was dissolved following the coup of 14 May
1987
Senate: nonelective body containing 34 seats,
24 reserved for Melanesians. 9 for Indians and
others. 1 for the island of Rotuma
House of Representatives: elections last held
18-25 February 1994 (next to be held NA
1997); results — percent of vote by party NA;
seats — (70 total, with ethnic Fijians allocated
37 seats, ethnic Indians 27 seats, and
independents and other 6 seats) number of
seats by party SVT 3 1 , NFP 20. FLP 7. FA 5,
GVP 4, independents 2, ANC 1
Judicial branch: Supreme Court
Political parties and leaders: Fijian Political
Party (SVT — primarily Fijian), leader Maj.
Gen. Sitivini RABUKA; National Federation
Party (NFP; primarily Indian), Jai Ram
REDDY; Christian Fijian Nationalist Party
(CFNP), Sakeasi BUTADROKA; Fiji Labor
Party (FLP), Mahendra CHAUDHRY; All
National Congress (ANC). Apisai TORA;
General Voters Party (GVP), Max OLSSON;
Fiji Conservative Party (FCP), Isireli
VUIBAU; Conservative Party of Fiji (CPF),
Jolale ULUDOLE and Viliame SAVU; Fiji
Indian Liberal Party. Swami MAHARAJ; Fiji
Indian Congress Party. Ishwari BAJPAl; Fiji
Independent Labor (Muslim), leader N A; Four
Comers Party. David TULVANUAVOU;
Fijian Association (FA). Josevata
KAMIKAMICA
Member of: ACP. AsDB, CP. ESCAP. FAO.
G-77. GATT. IBRD, ICAO, ICFTU, IDA.
IFAD. IFC. ILO, IMF, IMO. INTELSAT,
INTERPOL. IOC, ITU. LORCS, PCA.
SPARTECA. SPC, SPF. UN. UNCTAD.
UNESCO. UNIDO, UNIFIL. UNIKOM.
UNOMUR UNTAC, UPU. WHO, WIPO,
WMO
Diplomatic representation in US:
chief of mission: Ambassador Pita Kewa
NACUVA
chancery: Suite 240, 2233 Wisconsin Avenue
NW. Washington, DC 20007
telephone: (202) 337-8320
MX.- (202) 3.37-1996
consulaiels): New York
US diplomatic representation:
chief of mission: (vacant); Charge d’ Affaires
William ROPE
embassy: 3 1 Loftus Street. Suva
mailing address: P. O. Box 218, Suva
telephone: [679J 314-466
FAX: [679] 300-081
Flag: light blue with the flag of the UK in the
upper hoist-side quadrant and the Fijian shield
centered on the outer half of the flag; the shield
depicts a yellow lion above a white field
quartered by the cross of Saint George
featuring stalks of sugarcane, a palm tree,
bananas, and a white dove
Names;
conventional long form; Bailiwick of Jersey
conventional short form; Jersey
Digraph: JE
Type: British crown dependency
Capital: Saint Helier
Administrative divisions: none (British
crown dependency)
Independence: none (Briti.sh crown
dependency)
National holiday: Liberation Day. 9 May
(1945)
Constitution: unwritten; partly statutes,
partly common law and practice
Legal system; English law and local statute
Sulhrage: universal adult at age NA
Executive branch:
Chief of Slate; Queen ELIZABETH II (since 6
February 1952)
Head of Government; Lieutenant Governor
and Commander in Chief Air Marshal Sir John
SUTTON (since NA 1990); Bailiff Sir Peter L,
CRILL (since NA)
cabinet; committee.s; appointed by the States
Legislative branch: unicameral
Assembly of the Stales; elections last held NA
(next to be held NA); results — no percent of
vote by party since all are independents;
seats-^56 total. 52 elected) 52 independents
Judicial branch: Royal Court
Political parties and leaders: none; all
independents
Member of: none
Diplomatic representation in US: none
(British crown dependency)
US diplomatic representation: none (British
crown dependency)
Flag: white with the diagonal red cross of
Saint Patrick (patron saint of Ireland)
extending to the comers of the flag
205
Jersey (continued)
Johnston Atoll
(territory of the US)
Saint Heller. Oorey, Saint Aubin
Alrporti:
total: 1
usable: I
with permanent-sutface runways: I
with runways overJ,6S9m: 0
with runways 2,4^0-3,659 m: 0
with runways 1,220-2,439 m: I
TekcommunicatkHis: 63.700 telephones:
broadcast stations — I AM. no FM, I TV; 3
submarine cables
Defeiue Forces
Note: defense is the responsibility of the UK
Names:
amvcntioihil /onfi/omi: none
amwntumul short form: Johnston Atoll
Digraph: JQ
Type: unincorportuted territory of the US
administered by the US Defense Nuclear
Agency (DNA) and managed cixtperatively by
DNA and the Fish and Wildlife Service of the
US Department of the Interior as part of the
National Wildlife Refuge system
Capital; none: administered from
Washington, DC
Diplomatic representation In US; none
(territory of the US)
US diplomatic representation: none
(territory'' of the US)
Flag: the flag of the US is used
Names;
conventional long form: State of Kuwait
conventional short form: Kuwait
local long form: Dawlat ul Kuwuyt
220
local short form: Al Kuwayt
Digraph: KU
Type: nominal constitutional monarchy
Capital: Kuwait
Administrative dlvtshms: S govemorates
(muhafazat, singular — muhafazah); Al
''Ahmadi, Al Jahrah, Al Kuwayt, Hawalli, Al
Parwaniyah
Independence: 19 June l%l (from UK)
National holiday: National Day, 25 February
(1948)
Constitution: 16 November 1962 (some
provisions suspended since 29 August 1962)
Legal system: civil law system with Islamic
law signiHcant in personal matters; has not
accepted compulsory ICJ jurisdiction
Sulfivge: adult males who resided in Kuwait
before 1920 and their male descendants at age
21
note: only I09(> of all citizens are eligible to
vole
Executive branch:
chief of state: Amir Shaykh JABIR al-Ahmad
al-Jabir Al Sabah (since 31 December 1977)
head of government: Prime Minister and
Crown Mnce SAAD al-Abdallah al-Salim Al
Sabah (since 8 February 1978); Deputy Prime
Minister SABAH al-Ahmad al-Jabir Al Sabah
(since 17 October 1992)
cabinet: Council of Ministers; appointed by
the Prime Minister and approved by the Amir
Legislative branch: unicameral
National Assembly (Majlis al-umma):
dissolved 3 July 1986; new elections were held
on 5 October 1 992 with a second election in the
14th and 16th constituencies held February
1993
Judicial branch: High Court of Appeal
Political parties and leaders: none
Other political or pressure groups: small,
clandestine leftist and Shi''a fundamentalist
groups are active; several groups critical of
government policies are publicly active
Member of: ABEDA. AfDB, AFESD. AL,
AMF. BDEAC. CAEU. ESCWA. FAO. G-77.
GATT, GCC, IAEA. IBRD. ICAO. ICC, IDA,
IDB. IFAD. IFC. ILO, IMF. IMO.
INMARSAT. INTELSAT. INTERPOL. IOC.
ISO (correspondent), ITU, LORCS. NAM,
OAPEC. OIC. OPEC. UN, UNCTAD.
UNESCO. UNIDO. UPU. WFTU, WHO.
WMO.WTO
Diplomatic representation In US:
chief of mission: Ambassador MUHAMMAD
al-Sabah al-Salim al-Sabah
chancery: 2940 Tilden Street NW.
Washington. DC 20(X)8
telephone: (202) 966-0702
MX.- (202)966-0.517
US dlploriMtlc representation:
chief of mission: Ambassador-designate Ryan
CROCKER
embassy: Bneid al-Gar (opposite the Kuwait
International Hotel), Kuwait City
mailing address: P.O. Box 77 SAFAT, 13001
SAFAT. Kuwait; Unit 69000. Kuwait: APO
AE 09880-9000
telephone: [965] 242-4151 through 4159
FAX: (956) 244-2855
Flag: three equal horizontal bands of green
(top), white, and red with a black trapezoid
ba.sed on the hoist side
Ecotwmy
Overview: Kuwait is a small and relatively
open economy with proven crude oil reserves
of about 94 billion barrets — 10% of world
reserves. Kuwait has rebuilt its war-ravaged
petroleum sector; its crude oil production
reached at least 2.0 million barrels per day by
the end of 1993. The government ran a sizable
fiscal deficit in 1993. Petroleum accounts for
nearly half of GDP and 90% of export and
government revenues.
Natloiuil product: GDP— purchasing power
equivalent — $25.7 billion (1993 est.)
National product real growth rate: 15%
(1993e.sl.)
National product per caidta: $15,100(1993
est.)
Inflation rate (consumer prices); 3% ( 1 993)
Unemployment rate: NEGL%( 1992 est.)
Budget:
revenues: $9 billion
expenditures: $13 billion, including capital
expenditures of $NA {FY93)
Exports: $10.5 billion (f.o.b.. 1993 est.)
commodities: oil
partners: France 16%, Italy 15%, Japan 12%,
UK 11%
Imports: $6 billion (f.o.b., 1993 est.)
commodities: food, construction materials,
vehicles and parts, clothing
partners: US 35%. Japan 12%. UK 9%.
Canada 9%
External debt: $7.2 billion (December 1989
est.)
note: external debt has grown sub.stantially in
1991 and 1992 to pay for restoration of war
damage
Industrial production: growth rate NA%;
accounts for N A% of GDP
Electricity:
capacity: 6.873.000 kW available out of
7..398,()()0 kW due to Persian Gulf war
production: 1 2.264 billion kWh
consumption per capita: 8,890 kWh ( 1992 )
Industries: petroleum, petrochemicals,
desalination, food processing, building
materials, salt, construction
Agriculture: practically none: dependent on
imports for food; about 75% of potable water
must be distilled or imported
Economic aid:
donor: pledged bilateral aid to less developed
countries (1979-89). $18.3 billion
Currency: I Kuwaiti dinar (KD) = l.0(X) Ills
Exchange rates: Kuwaiti dinars (KD) per
US$ 1 —0.2982 (January 1994). 0.30 1 7 ( 1993).
0.2934 (1992), 0.2843 (1991), 0.2915 (1990),
0.2937(1989)
Fiscal year: I July— .30 June
Communkathms
Railroads: none
Hlghwayst
total: 3,9(X) km
pa\\''ed: bituminous 3,000 km
unpaved: gravel, .sand, earth 900 km
npcHncs: crude oil 877 km; petroleum
pr^ucts 40 km: natural gas lU km
Ports: Ash Shu''aybah, Ash Shuwaykh, Mina''
al Ahmadi, Mina’ ''Abd Allah, Mina'' Su''ud
Merchant nmrine: 46 ships ( 1 .000 CRT or
over), totaiing 2,153,693 GRT/3.56 1.568
DWT. cargo 10, livestock carrier 4, oil tanker
23. liquefied gas 7, container 2
Alrpt^:
total: 7
usable: 4
with permanent-surface runways: 4
with runways over 3.659 m: 0
with runways 2,440-3,659 m: 4
with runways 1,220-2,439 m: 0
Tcicconununicattons: civil network suffered
extensive damage as a result of the Gulf war
and recon.struction is still under way with some
restored international and domestic
capabilities; broadcast .stations — 3 AM, 0 PM,
3 ''TV; satellite earth stations — destroyed
during Gulf war and not rebuilt yet; temporary
mobile satellite ground stations provide
international telecommunications; coaxial
cable and microwave radio relay to Saudi
Arabia; service to Iraq is nonoperational
Defense Forces
Branches: Army. Navy. Air Force. National
Police Force. National Guard
Manpower availability: males age 15-49
537,6%; fit for military'' service 321.767; reach
military age (18) annually I5,.354 (1994 est.)
Defense expenditures: exchange rate
conversion — $2.5 billion, 7.3% of GDP
(FY92/93)
221
Names:
ctmventional hmg form: Territory of New
Caledonia and Dependencies
cimveniional short form: New Caledonia
hn-al long form: Territoire dcs
Nouvcllc-Caledmiie et Dependances
hk-al short form; Nouvelle-Caledonie
Digraph; NC
Type: o> enwas (erriiory of France since 1 9.56
Ci^tal; Noumea
.Adndnlitratlve divMoni; mme (overseas
(ciritory of France); there are m> nrst-order
administrative divisions as defined by the US
Cmvemment. but there are 3 provinces named
Iks Loyaute, Nord. and Sud
Independence; none toverseas territory of
France; a referendum on independence will be
held in 1498)
National holiday: National Day. Taking of
the Bastille. 14 July (1789)
Comtitnlion: 28 September 1958 (French
Cons(iiu(ion)
Legal system: the 1488 Matigmm Accords
grant substantial automimy to the islands;
formerly under French law
SunVnge; 18 years of age; universal
Executive branch:
chief of state; President FrniKois
MITTERRAND tsince 2 1 May 1481)
head of government; High Commissioner and
President of the Council of Government Alain
CHRI.STNACHT (since 15 January 1991;
appointed by the French Ministry of the
Interior); President of the Tcrriltirial Congress
.Simon l.OUF.CKHOTE (since 26 June i984)
cahinet; Consultative Committee
Legislative branch: unicameral
Territorial Assembly: elections last held 1 1
June 1989 (next to be held 1993); results —
RPCR 44,5%, FLNKS 28.5%, FN 7%. CD 5%.
UO 4%. other 1 1%; seats— (.54 total) RPCR
27, FLNKS 19. FN 3, other 5; note — election
boycotted by FULK
French Senate; elections last held 27
September 1 992 (next to be held September
2001); results — percent of vote by party NA;
seals — ( I total) RPCR 1
French National Assembly; elections last held
21 March 1993 (next to be held 21 and 28
March 1 998); results — percent of vote by party
NA; seats— (2 total) RPCR 2
Judicial branch: Court of Appeal
Political parties and leaders: white-
dominated Rassemblement pour la Caledonie
dans la Republique (RPCR). conservative.
Jacques LAFLEUR — affiliated to France''s
Rassemblement pour la Republique (RPR);
Melanesian proindepcndence Kanaka Socialist
National Liberation Front (FLNKS). Paul
NEAOUTYINE; Melanesian moderate Kanak
Socialist Liberation (LKS). Nidoish
NAISSELINE; National Front (FN). extreme
right, Guy GEORGE; Caledonie Dcmain (CD),
right-wing. Bernard MARANT; Union
Oceanienne (UO). conservative, Michel
HEMA; Front Uni de Liberation Kanak
(FULK). proindependence. Clarence
UREGEI; Union Caledonian (UC), Francois
BURCK
Member of: ESCAP (associate), FZ, ICFTU,
SPC. WFTU. WMO
Diploimtic repreaeululhm In US: m>ne
(overseas territory of France)
US diplomatic representution: mme
(overseas territory of France)
Elug: the flag of FraiKC is used
Names;
conventional long form; Republic of Slovenia
conventional short form; Slovenia
local long form; Republika Slovenije
local short form; Slovenija
Digraph: SI
Type: emerging democracy
Capital; Ljubljana
Administrative divisions: 60 provinces
(pokajine. singular — pokajina) Ajdovscina,
Brezice. Celje. Cerknica, Cmomelj,
Dravograd, Oomja Radgona, Grosuplje,
Hrastnik Lasko, Idrija. Ilirska Bistrica, Izola,
Jesenice. Kamnik, Kocevje. Koper, Kranj.
Krsko, Lenart, Lendava. Litiju, Ljubljana-
Bezigrad, Ljubljana-Center, Ljubljuna-Moste-
Polje, Ljubljana-Siska. Ljubljana-Vic-Rudnik.
Ljutomer, Logatec. Maribor. Metlika, Mozirje.
Murska Sobota, Nova Gorica, Novo Mesto,
Ormoz, Pesnica, Plran, Postojna, Ptuj, Radlje
Ob Dravi, Radovljica, Ravne Na Koroskem,
Ribnica, Ruse, Sentjur Pri Celju, Sevnica,
Sezana, SkuQa Loka, Slovenj Gradec,
Slovenska Bistrica, Siovenske Konjice, Smarje
Pri Jelsah, Tolmin, Trbovlje, Trebi\\je, Trzic,
Velenje, Vrhnika, Zagorje Ob Savi, Zalec
Independence; 25 June 1991 (from
Yugoslavia)
National holiday: Statehood Day. 25 June
(1991)
Constitution: adopted 23 December 1991,
effective 23 December 1991
Legal system: based on civil law system
Suffrage: 16 years of age, if employed; 18
years of age, universal
Executive branch:
chief of state; President Milan KUCAN (since
22 April 1990); election last held 6 December
1992 (next to be held NA 19%); results —
Milan KUCAN reelected by direct popular
vote
head of government; Prime Minister Janez
DRNOVSEK (since 14 May 1992): Deputy
Prime Minister Lojze PETERLE (since NA)
cabinet; Council of Ministers
Legislative branch: bicameral National
Assembly
State Assembly; elections last held 6 December
19!<2 (next to be held NA 19%); results —
percent of vote by party NA; seats — (total 90)
LDS 22, SKD 15, United List (former
Communists and allies) 14, Slovene National
Party 12. SLS 10. Democratic Party 6, ZS 5,
SDSS 4, Hungarian minority 1 , Italian
minority 1
State Council: will become operational after
next election in 1996; in the election of 6
December 1 992 40 members were elected to
represent K>cal and socioeconomic interests
Judicial branch: Supreme Court,
Constitutional Court
Political parties and leaders: Slovene
Christian Democrats (SKD), Lozje PETERLE,
chairman; Liberal Democratic (LDS), Janez
DRNOVSEK, chairman; Social-Democratic
Party of Slovenia (SDSS), Joze PUCNIK,
chairman; Socialist Party of Slovenia (SSS),
Viktor ZAKEU , chairman; Greens of Slovenia
(ZS), Dusan PLUT, chairman; National
Democratic, Rajko PIRNAT, chairman;
Democratic Peoples Party, Marjun
PODOBNIK, chairman; Reformed Socialists
(former Communist Party), Ciril RIBICIC,
chairman: United List (former Communists
and allies); Slovene National Party, leader NA;
Democratic Party, Igor BAVCAR; Sloven-
People’s Party (SLS), Ivan OMAN
note: parties have changed as of the December
1992 elections
Other political or pressure groups: none
Member of: CCC. CE, CEl. CSCE, EBRD.
ECE, IAEA, IBRD, ICAO. IDA, IFC. ILO,
IMF, IMO. INTELSAT (nonsignatory user).
INTERPOL. KX:. lOM (observer). ITU,
.358
NAM (guest), UN, UNCTAD, UNEl-''O.
UNIDO, UPU, WHO. WIPO, WMO
Diplomatic repreKntation in US:
chief of mmion: Ambas.sador Ernest PETRIC
chanceiy: 1525 New Hampshir Avenue NW.
Washington, DC, 20036
telephone: (202) 667-5363
consulaie(s) general; New York
US diplomatic representation:
chief of mix.fion: Ambassador E, Allan
WENDT
embassy; P.O. Box 254, Prazakova 4, 61 (XX)
Ljubljana
mailing address; use embassy street address
telephone: [386] (61) 301-427/472/485
FAX; [386] (61). 301 -401
Flag: three equal horiztiiu il bands of white
(top), blue, and red with tiic Slovenian seal (a
shield with the image of TAglav in white
against a blue background at the center,
beneath it are two wavy blue lines depicting
seas and rivers, and around it, there are three
six-sided stars arranged in an inverted
triangle); the seal is locoted in the up^er hoist
side of the flag centeted in the white and blue
bands
Names:
conventional Ion); form: Kingdom of
Swaziland
conventional short form: Swaziland
Digraph: WZ
Type: monarchy; independent member of
Commonwealth
Capital; Mbabane (administrative): Lobamba
(legislative)
Administrative divisions: 4 districts;
Hhohho, Lubombo. Manzini, Shiselweni
Independence: 6 September 1968 (from UK)
National holiday: Somhiolo (Independence)
Day. 6 September ( 1968)
Constitution: none; constitution of 6
September 1968 was suspended on 12 April
1973; a new constitution was promulgated 13
October 1978, but has not been formally
presented to the people
Legal system; based on South African
Roman-Dutch law in statutory courts, Swazi
tradi'' onal law and custom in traditional courts;
has not accept'' :d compulsory ICJ jurisdiction
Suffrage: none
Executive b.anch:
chief of state: King MSWATI III (since 25
April 1986)
head of government: Prime Minister Prince
Jameson Mbilini DLAMINI (since 12
November 1993)
cabinet: Cabinet: designated by the monarch
Legislative branch: bicameral Parliament is
advisory and consists of an upper house or
Senate and a lower house or House of
Assembly; the 30 members of the Senate are
appointed — 10 by the House of As-sembly and
20 by the king; the members of the House are
elected by popular vote; last election held in
October 1993
Judicial branch: High Court, Court of
Appeal
Political parties and leaders: none; banned
by the Constitution promulgated on 1 3 October
1978
Member of; ACP, AfDB, C, CCC, ECA,
FAO, C-77, GATT, IBRD. ICAO, ICFTU,
IDA, IFAD, IFC, ILO, IMF, INTELSAT,
INTERPOL. IOC, ITU, LORCS, NAM, OAU,
PCA. SACU. SADC, UN. UNCTAD,
UNESCO. UNIDO, UPU, WHO, WIPO,
WMO
Diplomatic representation in US:
chief of mission; Ambassador Absalom
Vu.sani MAMBA
chancery: 3400 International Drive NW.
Washington. DC 20008
telephone; (202) 362-6683 or 6685
FAX; (202) 244-8059
US diplomatic representation:
chief of mission; Ambassador John SPROTT
emhassy: Central Bank Building, Warner
Street. Mbabane
mailing address: P. O. Box 1 99. Mbabane
telephone: (268)46441 through 46445
FAX; 1268) 45959
Flag: three horizontal bands of blue (top), red
(triple width), and blue; the red band is edged
in yellow; centered in the red band is a large
black and white shield covering two spears and
a staff decorated with feather tassels, all placed
horizontally','b95dfc3a75faf9cb1980b3cb4d169fc199a969865a4ec216be0d8d47f15b1d9c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82485ece4bbd9b6fd88a37457c9ffb10de107b84635ee6fed29d4312dc27236a',1994,'FI','Finland','government',393,'Names:
conventional long form: Republic of Finland
conventional short form: Finland
local long form: Suomen Tasavalta
local short form: Suomi
Digraph; FI
Type; republic
133
Finland (continued)
Capital: Helsinki
Administrative divisions: 1 2 provinces
(laanit, singular — laani); Ahvenanmaa, Hame,
Keski-Suomi. Kuopio, Kymi, Lappi, Mikkeli,
Oulu, Pohjois-Kaijala, Turku ja Pori, Uusimaa,
Vaasa
Independence: 6 December 1917 (f^om
Soviet Union)
National holiday: Independence Day. 6
December (1917)
Constitution: 1 7 July 1919
Legal system: civil law system based on
Swedish law; Supreme Court may request
legislation interpreting or modifying laws;
accepts compulsory ICJ jurisdiction, with
reservations
Sufftnge; 18 years of age; universal
Executive branch:
chief of state; President Martti AHTISAARI
(since 1 March 1994); election last held 31
January — 6 February 1994 (next to be held
January 2000); results — Martti AHTISAARI
54%, Elisabeth REHN 46%
head of government; Prime Minister Esko
AHO (since 26 April 1991); Deputy Prime
Minister Pertti SALOLAINEN (since at least
January 1992)
cabinet; Council of State (Valtioneuvosto);
appointed by the president, responsible to
Parliament
Legislative branch: unicameral
Parliament (Eduskunta); elections last held 17
March 1991 (next to be held March 1995);
results — Center Party 24,8%, Social
Democratic Party 22.1%. National Coalition
(Conservative) Party 19.3%, Leftist Alliance
(Communist) 10. 1 %, Green League 6.8%,
Swedish People’s Party 5.5%. Rural 4.8%,
Finnish Christian League 3.1%, Liberal
People''s Party 0.8%; seals — (200 total) Center
Party 55. Social Democratic Party 48, National
Coalition (Conservative) Party 40, Leftist
Alliance (Communist) 19, Swedish People’s
Party 12, Green League 10, Finnish Christian
League 8. Rural 7, Liberal People''s Party 1
Judicial branch: Supreme Court (Korkein
Oikeus)
Political parties and leaders:
government coalition; Center Party, Esko
AHO; National Coalition (conservative) Party,
Perti SALOLAINEN; Swedish People’s Patty,
(Johan) Ole NORRBACK; Finnish Christian
League, Toimi KANKAANNIEMI
other parties: Social Democratic Party, Paavo
LIPPONEN, acting chairman; Leftist Alliance
(Communist) People''s Democratic League and
Democratic Alternative. Claes ANDERSON;
Green League, Pekka SAURl; Rural Party.
Tina MAKELA; Liberal People’s Party, Kalle
MAATTA
Other political or pressure groups: Finnish
Communist Party-Unity. Yrjo HAKANEN;
Constitutional Rightist Party; Finnish
Pensioners Party: Communist Workers Party.
Timo LAHDENMAKl
Member of: AfDB, AG (observer), AsDB,
Australia Group. BIS, CBSS, CCC, CE,
CERN, COCOM (cooperating), CSCE, EBRD,
ECE, EFTA, ESA (associate), FAO, G-9,
GATT, lADB, IAEA. IBRD. ICAO, ICC,
ICFTU, IDA, lEA, IFAD, IFC, ILO, IMF,
IMO, INMARSAT, INTELSAT, INTERPOL,
IOC. lOM, ISO, ITU, LORCS, MTCR, NAM
(guest), NC, NEA, NIB, NSG, OAS
(observer), OECD, PCA. UN, UNCTAD.
UNDOF, UNESCO, UNFICYP, UNHCR.
UNIDO, UNIFIL, UNIKOM, UNMOGIP,
UNPROFOR. UNTSO, UPU, WFTU, WHO,
WIPO, WMO, WTO, ZC
Diplomatic representation in US:
chief of mission; Ambassador Jukka
VALTASAARI
chancery’; 3216 New Mexico Avenue NW.
Washington, DC 20016
telephone; (202) 363-2430
FAX; (202) 363-8233
considate(s) general; Los Angeles and New
York
US diplomatic representation:
chief of mission; Ambassador John H. KELLY
embassy: Itainen Puistotie 14A, SF-00140,
Helsinki
mailing address; APO AE 09723
telephone; [3581 (0) 171931
FAX; 13581 (0) 174681
Flag: white with a blue cross that extends to
the edges of the flag; the vertical part of the
cross is shifted to the hoist side in the style of
the DANNEBROG (Danish flag)','76de9626e3cd5616888cb00070507d38ca62ebc0dd3d63962b2158d6611d9082','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('487c28fe7340ef4c7aea91d27dab60bb74b42f524c435b927410d3dd0c6e90b8',1994,'DE','Germany','government',400,'Names;
cimventUmal Um^form: French Republic
conventional short form: France
local long form: Republique Francaise
local short form: France
Digraph: FR
Type: republic
Capital: Paris
Administrative divisions: 22 regions
(regions, singular — region); Alsace, Aquitaine,
Auvergne, Basse-Normandie, Bourgogne,
Bretagne, Centre, Champagne-Ardenne,
Corse, Franche-Comte, Haute-Normandie, Ile-
de-France, Languedoc-Roussillon, Limousin,
Lorraine, Midi-Pyrenees, Nord-Pas-de-Calais,
Pays de la Loire, Picardie, Poilou-Charentes,
Provence-Alpes-Cote d’Azur, Rhone-Alpes
note: the 22 regions are subdivided into •Xi
departments; see separate entries for the
overseas departments (French Guiana,
Guadeloupe, Martinique, Reunion) and the
territorial collectivities (Mayotte, Saint Pierre
and Miquelon)
Dependent areas: Bassas da India,
Clippeilon Island, Europa Island, French
Polynesia, French Southern and Antarctic
Lands, Glorioso Islands, Juan de Nova Island,
New Caledonia, Tromelin Island. Wallis and
Futuna
note: the US does not recognize claims to
Names:
conventional long form: Federal Republic of
conventional short form: Germany
local long form: Bundesrepublik Deutschland
local short form: Deutschland
Digraph: GM
Type: federal republic
Capital; Berlin
note: the shift from Bonn to Berlin will take
place over a period of years with Bonn
retaining many administrative functions and
several ministries
Administrative divisions: 16 slates (laender,
singular — land): Baden-Wurtlemberg, Bayern,
Berlin, Brandenburg, Bremen, Hamburg,
Hessen, Mecklenburg-Vorpommern,
Niedersachsen, Nordrhein-Westfalen,
Rheinland-Pfalz. Saarland, Sachsen, Sachsen-
Anhalt, Schleswig-Holstein, Thuringen
Independence: 18 January 1871 (German
Empire unification); divided into four zones of
occupation (UK, US, USSR, and later, France)
in 1945 following World War 11; Federal
Republic of Germany (FRG or West Germany)
proclaimed 23 May 1949 and included the
former UK. US. and French zones; German
Democratic Republic (GDR or East Germany)
proclaimed 7 October 1949 and included the
former USSR zone: unification of West
Germany and East Germany took place 3
October 1990: all four power rights formally
relinquished 15 March 1991
National holiday: German Unity Day (Day of
Unity), 3 October ( 1 990)
Constitution: 23 May 1 949, known us Basic
Law; became constitution of the united
German people 3 October 1990
Legal system: civil law system with
indigenous concepts; judicial review of
legislative acts in the Federal Constitutional
Court; has not accepted compulsory ICJ
jurisdiction
Suffrage: 18 years of age: universal
Executive branch:
chief of state: President Dr. Richard von
WEIZS ACKER (since 1 July 1984); note —
presidential elections were held on 23 May
1994; Roman HERZOG was the winner and
will be inaugurated I July 1994
head of government: Chancellor Dr. Helmut
KOHL (since 4 October 1982)
cabinet: Cabinet; appointed by the president
upon the proposal of the chancellor
Legislative branch: bicameral chamber (no
official name for the two chambers as a whole)
Federal Assembly (Bundestag): last held 2
December 1990 (next to be held by 1 6 October
1994); results— CDU 36.7%, SPD 33.5%, FDP
1 1 .0%, eSU 7.1%, Green Party (West
Gennany) 3.9%. PDS 2.4%. Republikaner
2.1%. Alliance 90/Green Parly (East Germany)
1.2%. other 2. 1 %; seats— (662 total) CDU 268,
eSU 51, SPD 239, FDP 79, PDS 17, Greens/
Alliance ‘90 8; elected by direct popular vote
under a system combining direct and
proportional representation; a party must win
5% of the national vote or 3 direct mandates to
gain representation
Federal Council (Bundesrat): State
governments are directly represented by votes;
each has 3 to 6 votes depending on size and are
required to vote as a block; current
composition; votes — (68 total) SPD-led states
37. CDU-led states 31
Judicial branch: Federal Constitutional
Court (Bundesverfassungsgericht)
Political parties and leaders: Christian
Democratic Union (CDU), Helmut KOHL,
chairman; Christian Social Union (CSU), Theo
WAIGEL, chairman; Free Democratic Party
(FDP), Klaus KINKEL, chairman; Social
Democratic Party (SPD), Rudolf
SCHARPING. chairman; Alliance ’90/Greens,
Ludger VOLMER, Marianne BIRTHLER, co-
chairmen; Party of Democratic Socialism
(PDS), Lothar BISKY, chairman;
Republikaner, Franz SCHOENHUBER;
National Etemocratic Party (NPD), Guenter
DECKERT; Communist Party (DKP), Rolf
PRIEMER
Other political or pressure groups;
expellee, refugee, and veterans groups
Member of: AfDB, AG (observer). AsDB,
Australian Group, BDEAC. BIS. CBSS, CCC,
CDB (non-regional), CE. CERN, COCOM,
CSCE. EBRD, EC. ECE, EIB. ESA. FAO,
G-5. G-7. G-10, GATT, lADB, IAEA, IBRD.
ICAO. ICC, ICFTU, IDA, lEA, IFAD, IFC,
ILO, IMF. IMO, INMARSAT, INTELSAT.
INTERPOL, IOC, lOM, ISO. ITU, LORCS.
MTCR. NACC. NAM (guest). NATO. NEA.
NSG. OAS (observer). OECD, PCA. UN.
UNCTAD, UNESCO. UNIDO, UNHCR,
UNOMIG, UNOSOM. UNTAC, UPU, WEU.
WHO. WIPO, WMO. WTO. ZC
Diplomatic representation in US:
chief of mission: Ambassador Immo
STABREIT
chancerv: 4645 Reservoir Road NW.
Washington. DC 20007
telephone: (202) 298-4000
FAX: (202) 298-4249
consiilate(s) general: Atlanta. Boston,
Chicago, Detroit. Houston. Los Angeles,
Miami, New York, San Francisco, Seattle
considate(s): Manila (Trust Territories of the
Pacific Islands) and Wellington (America
Samoa)
US diplomatic repres.entatlon:
chief of mission: Ambassador Richard C.
HOLBROOKE
embassy: Deichmanns Avenue 29. 53 1 70
Bonn
mailing address: Unit 21701, Bonn; APO AE
09080
telephone: [49] (228) .''''.,391
FAX: 149) (228) 339-2663
branch office: Berlin
considate(s) general: Frankfurt. Hamburg,
Leipzig, Munich, and Stuttgart
Flag: three equal horizontal bands of biack
(top), red, and yellow
Kxtcrnal debt: $2.2 billion ( 1442 est.)
Industrial production: growth rale 1 .4''/r
(1441 est. ); accounts for l8''/( of GDP
Klectricity;
( Yt/XK ifv. 847,(48) kW
/>i<iihicti<m: 2.5 billion kWh
conxiiiiiinioii per cupilti: 260 kWh ( 1442)
Industries: sugar, textiles and clothing,
furniture, chemicals, petroleum, metals,
rubber, tourism
Agriculture: ticcounts for 26'',} of GDP; most
important sector of economy; contributes twti-
ihirds of export eaniings; principal crops —
sug;ircanc, corn, bananas, coffee, beans,
cardamom; livestrark — cattle, sheep, pigs,
chickens; fotnl importer
Illicit drugs: transit country for cocaine
shipments; illicit priKlueer of opium poppy and
cannabis for the international drug trade; the
government has an active eradication program
for cannabis and opium poppy
Kctmtimic aid:
recipient: U.S commitments, including F-x-lm
(l•Y7()-4()), $1,1 billion; Westcni (non-US)
countries, ODA and tK)F bilalerul
conttniimenis (1470-84), $7.42 billion
Currency: I quetzal (Q) - l(K) centavos
Kxchungc rates: free market quctzales (Q)
per US$1— 5,8542 (January IW4). 5,67.54
( 1447), 5. 1 7(Ki ( 1442). 5,0284 ( IWl i, 4.4858
( 1440). 2.8 161 ( 1484); note — black-market
rate 2.800 (May 1484)
Fiscal year: calendar year
Clint niunications
Kailrnuds: 1.014 km ().4l4-inetcr gauge,
single iritck; 417 km government owned. 102
km privately owned
Highways:
totiil: 2(>,424 km
IHieed: 2,868 km
iiniHieed: gravel 1 1,421 km; unimproved earth
12,140 km
Inland waterways: 260 km navigable year
round; additional 770 km navigable during
high-water season
Pipelines: crude oil 275 km
Ports: Pueno Barrios, Puerto Quetzal, Santo
Tomas de Castilla
Merchant marine: I cargo ship ( I ,(H)() GR1''
or over) totaling 4. 1 24 ORT/6,450 DWT
Airports:
louil: 527
iixuhle: 465
with permonent-xurjoce ninwoyx: 1 1
with rumeiiyx over .7,654 ni: 0
with rumviiyx m: 7
with ninwoyx 1 .220-2Ai‘i m: 20
Telecommunications: fairly tnodern network
cenlererl in the city of Guatemtila; 47,670
telephones; broadcast sttiiions — 4 1 AM. no
FM. 25 TV. 1 5 shortwave; connection into
Central American Microwave .Sy.stem; I
Atlantic (icean INTFLSAT earth station
IHTcase Forces
Branches; Army. Navy. Air F‘orce
Manpower availability: mules age 1 5-44
2.491.582; lit for military service 1.624.222;
reach military age (18) annually 1 14,545(1444
est.)
Defense expenditures; exchange rate
conversion — $121 million. I''/i- of GDP ( 1447)','6cbc1e4d844d700495de82ced6ee637f2dbe7ec949b826d502d902bf8e4f4e0f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6e1784bba569ac44ace80a2eb3d902b9456bc90eb373c1aefef7016d01d502f',1994,'GF','French Guiana','government',405,'Names:
conventional long form: Department of
Guiana
conventional short form: French Guiana
local long form: none
local short form: Guyane
Digraph: FG
Type: overseas department of France
Capital: Cayenne
Administrative divisions; none (overseas
department of France)
Independence; none (overseas department of
France)
National holiday: National Day. Taking of
the Bastille, 14 July (1789)
Constitution: 28 September 1958 (French
Constitution)
Legal system: French legal system
SufIFage: 1 8 years of age; universal
Executive branch:
chief of state: President Francois
MITTERRAND (since 21 May 1981)
head of government: Prefect Jean-Francois
CORDET (since NA 1992); President of the
General Council Elie CASTOR (since NA);
President of the Regional Council Antoine
KARAM (22 March 1993)
cabinet: Council of Ministers
Legislative branch: unicameral General
Council and a unicameral Regional Council
General Council: elections last held 25
September and 8 October 1 988 (next to be held
NA); results — percent of vote by party NA;
seats— ( 19 total) PSG 12. URC 7
Pegional Council: elections last held 22 March
1992 (next to be held NA); results — percent of
vole by party NA; seats — (31 total) PSG 16
French Senate: elections last held 24
September 1989 (next to be held September
1998); results— percent of vole by party NA;
seats — (I total) PSG I
French National AssemMy: elections last held
21 and 28 March 1993 (next to be held NA
1998); results - percent of vote by party NA;
seats — (2 total) RPR I, independent I
Judicial branch: Court of Appeals (highest
local court based in Martinique with
jurisdiction over Martinique. Guadeloupe, and
French Guiana)
Political parties and leaders: Guianese
Socialist Party (PSG), Elie CASTRO;
Conservative Union for the Republic (UPR),
Leon BERTRAND; Rally for the Center Right
(URC); Rally for the Republic (RPR); Guyana
Democratic Front (FDG), Georges OTHILY;
Walwari Committee, Christine TAUBIRA-
DELANON
Member of: FZ.WCL
Diplomatic represenextion in US: none
(overseas department of France)
US diplomatic representation: none
(overseas department of France)
Flag: the flag of France is used','1394af001f851ad7b70b1382be0df1dc2d8f32fefe98af7f81e0965082234d8e','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61bce642c6abd6b689551f5f7217f7d03166b81d207be797103b1bbcd21400b6',1994,'FR','France','government',410,'Administrative divisions; none (overseas
territory of France); there are no first-order
administrative divisions as defined by the US
Government, but there are 3 districts named lie
Crozet, lies Kerguelen, and lies Saint Paul et
Amsterdam; excludes Terre Adelie claim in
Antarctica that is not recognized by the US
Independence: none (overseas territory of
France)
Flag: the flag of France is used
2.38
Names:
conventional long form: none
conventional short form; Macau
local long form: none
local short form: Ilha de Macau
Digraph: MC
Type: overseas territory of Portugal
scheduled to revert to China in 1999
Capital: Macau
.Administrative divisions: 2 districts
(concelhos, singular — concelho): Ilhas, Macau
Independence; none (territory of Portugal;
Portugal signed an agreement with China on 1 3
April 1987 to return Macau to China on 20
December 1999; in the joint declaration, China
promises to respect Macau''s existing .social
and economic systems and lifestyle for 50 year
after transition)
National holiday: Day of Portugal, 10 June
(1580)
Constitution: 17 February 1976, Organic
Law of Macau; basic law drafted primarily by
Beijing awaiting final approval
Legal system: Portuguese civil law system
Suffrage: 1 8 years of age: universal
Executive branch:
chief of slate: President (of Portugal) Mario
Alberto SOARES (since 9 March 1986)
head of government: Governor Gen, Vasco
Joachim Rocha VIEIRA (since 20 March
1991)
cabinet: Consultative Council: consi.sts of five
members appointed by the governor, two
nominated by the governor, five members
elected for a four-year term (2 represent
administrative bodies. I represents moral,
cultural, and welfare interests, and 2 economic
interests), and three statuatory members
Legislative branch: unicameral
Legislative Assembly: elections last held on 1 0
March 1991; results — percent of vote by party
NA; seats — (23 total; 8 elected by universal
suffrage, 8 by indirect .suffrage, and 7
appointed by the governor) number of seats by
party NA
Judicial branch: Supreme Court
Political parties and leaders: Association to
Defend the Interests of Macau; Macau
Democratic Center; Group to Study the
Development of Macau; Macau Independent
Group
Other political or pressure groups:
wealthy Macanese and Chinese representing
local interests, wealthy pro-Communist
merchants representing China''s interests; in
January 1967 the Macau Government acceded
to Chinese demands that gave China veto
power over administration
Member of: ESCAP(associate).GATT, IMO
(associate). INTERPOL (subbureau). WTO
(associate)
Diplomatic representation in US: none
(Chinese territory under Portuguese
administration)
US diplomatic representation: the US has
no offices in Macau, and US intere.sts are
monitored by the US Consulate General in
Names:
conventional long form: Kingdom of Spain
conventional short form: Spain
local short form: Espana
Digraph: SP
Type: parliamentaiy monarchy
Capital: Madrid
Administrative divisions: 17 autonomous
communities (comunidades autonomas,
singular — comunidad auionoma); Andalucia.
Aragon. Asturias, Canarias, Cantabria,
Custilla-La Mancha, Castilla y Leon, Cataluna,
Communidad Valencia. Extremadura, Galicia,
Islas Baleares, La Rioja, Madrid. Murcia,
Navarra, Pais Vasco
note; there are five places of sovereignty on
and off the coast of Morocco (Ceuta, Mellila,
Islas Chafarina.s, Penon de AIhucemas, and
Penon de Velez de la Gomera) with
administrative status unknown
Independence: 1 492 (expulsion of the Moors
and unification)
National holiday: National Day, 12 October
Constitution; 6 December 1978. effective 29
December 1978
Legal system: civil law system, with regional
applications; does not accept compul.sory ICJ
Jurisdiction
Suffrage; 1 8 years of age; universal
Executive branch;
chief of state: King JUAN CARLOS 1 (since
22 November 1975)
head of goveniment; Prime Minister Felipe
GONZALEZ Marquez (since 2 December
1982): Deputy Prime Minister Narcis SERRA
y Serra (since 13 March 1991)
cabinet: Council of Ministers: designated by
the prime mini.ster
Council of State; is the supreme consultative
organ of the government
Legislative branch: bicameral The General
Courts or National As.sembly (Las Cortes
Generales)
Senate (Senadol: elections last held 6 June
1993 (next to be held by NA June 1997);
results — percent of vote by party NA: seals —
(2.55 total) PSOE 1 17, PP 107. CiU 15. PNV 5,
lU 2, other 9
Congress of Deputies (Congreso de los
Diputados): elections last held 6 June 1993
(next to be held by NA June 1997): results —
percent of vole by parly NA; sears — (350 total)
PSOE I59,PP 141. lU 18. CiU I7.PNV5.CN
4, HB 2, other 4
Judicial branch; Supreme Court (Tribunal
Supremo)
Political parties and leaders;
principal national parties, from right to left:
Popular Party (PP). Jo,se Maria AZNAR;
Social Democratic Center(CDS). Rafael Calvo
ORTEGA; Spanish Socialist Workers Party
(PSOE). Felipe GONZALEZ Marquez,
secretary general: Socialist Democracy Party
(DS), Ricardo Garcia DAMBORENEA;
Spanish Communist Party (PCE). Julio
ANGUITA; United Left (lU) a coalition of
parties including the PCE. a branch of the
PSOE, and other small parties, Julio
ANGUITA
chief regional parties: Convergence and Unity
(CiU), Jordi PUJOL Saley and Miguel ROCA
in Catalonia; Basque Nationalist Party (PNV),
Xabier ARZALLUS and Jose Antonio
ARDANZA; Basque Solidarity (EA), Carlos
GARAICOETXEA Urizza; Basque Popular
Unity (HB), Jon IDIGORAS and Inaki
ESNAOLA; Basque Stwialist Party (PSE),
coalition of the PSE, EE and PSOE, Jose Maria
BANEGAS and Jon LARRINAGA;
Andalusian Progress Party (PA), Pedro
PACHECO: Canarian Coalition (CN), Dimas
MARTIN; Catalan Republican Left, Angel
COLOM: Galician Coalition, Senen
BERNARDEZ: Aragonese Regionalis . Party
(PAR), Jose Maria MUR Bemad; Valencian
Union (UV), Vicente GONZALEZ Lizondo,
Manuel CAMPILLOS Martinez
Other political or pressure groups: on the
extreme left, the Basque Fatherland and
Liberty (FTA) and the First of October
Antifascist Resistance Group (GRAPO) use
terrorism to oppose the government; free labor
unions (authorized in April 1977) include the
Communist-dominated Workers Commissions
(CCOO); the Socialist General Union of
Workers (UGT). and the smaller independent
Workers Syndical Union (USO); business and
landowning interests: the Catholic Church;
Opus Dei; university students
Member of: AG (ob..erver), AsDB.
Australian Group, BIS, CCC. CE. CERN,
COCOM, CSCE, EBRD. AfDB. EC, ECE,
ECLAC. ElB. ESA. FAO. G-8. GATT. lADB.
IAEA. IBRD. ICAO, ICC. ICFTU, IDA. lEA,
IFAD, IFC, ILO. IMF. IMO, INMARSAT.
INTELSAT. INTERPOL. IOC. lOM
(observer), ISO, ITU, LAIA (observer),
LORCS. MTRC. NACC, NAM (guest),
NATO. NEA. NSG. OAS (observer), OECD,
ONUSAL. PCA, UN. UNAVEM II.
UNCTAD. UNESCO, UNIDO, UNOMOZ,
UNPROFOR. UPU. WCL. WEU, WHO,
WIPO. WMO. WTO, ZC
Diplomatic representation in US:
chief of mission; Ambassador Jaime De
OJEDA y Eiseley
chuncen'': 27(K) 15th Street NW, Washington,
DC 20009
telephone; (202) 265-0190 or 0191
consulateis) general; Boston, Chicago,
Houston, Los Angeles. Miami, New Orleans.
New York, San Francisco, and San Juan
(Puerto Rico)
US diplomatic representation:
chief of mission: Ambassador Richard N.
GARDNER
embassy: Serrano 75, 28(X)6 Madrid
mailing address: APO AE 09642
telephone: [34] ( 1 ) 577-4000
FAX: |.34| ( 1 ) 577-5735
consulateis) general: Barcelona
consulateis); Bilbao
Flag: three horizontal bands of red (top),
yellow (double width), and red with the
national coat of arms on the hoist side of the
367
Spain (continued)
yellow band; the coat of arms includes the
royal seal framed by the Pillars of Hercules,
which ate the two promontories (Gibraltar and
Ceuta) on either side of the eastern end of the
Strait of Gibraltar','c76cbe5d04f17fde3fa068a56eb0d22bf9c3afbe5503abe6659b150e5df8b52e','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4480403e1c7274c1f22c2456a2d44eafbc1e58158c731507cbd229bdae6faad9',1994,'GA','Gabon','government',415,'Names;
conventional long form; Gabonese Republic
conventional short form; Gabon
local long form: Republique Oabnnaise
local short form: Gabon
Digraph: GB
Type: republic: multiparty presidential
regime (opposition parties legalized 1990)
Capital: Libreville
Administrative divisions: 9 provinces;
Estuaire, Haut-Ogooue, Moyen-Ogooue.
Ngounie. Nyanga, Ogooue-lvindo. Ogooue-
Lolo. Ogooue-Maritime. Woleu Ntein
Independence: 17 August 1960 (from
France)
National holiday: Renovation Day, 12 March
(1968) (Gabonese Democratic Party
established)
Conslilutlon: adopted 14 March 1991
Legal system: based on French civil law
system and customary law; Judicial review of
legislative acts in Constitutional Chamber of
the Supreme Court: compulsory ICJ
jurisdiction not accepted
141
Gabon (continued)
Suffrage: 21 years of age; universal
Executive branch;
chief of state: President El Hadj Omar
BONGO (since 2 December 1967); election
last held on S December 1993 (next to be held
Na 1998); results — President Omar BONGO
was reelected with 5 1 % of the vote
head of government: Prime Minister Casimir
OYE-MBA (since 3 May 1990)
cabinet: Council of Ministers; appointed by
the prime minister in consultation with the
president
Legislative branch: unicameral
National Assembly (Assemblee Nationale):
elections last held on 21 and 28 October and 4
November 1990 (next to be held by NA);
results — percent of vote by party NA; seats —
(120 total) PDG 62, Morena-Bucherons/RNB
19, PGP 18, National Recovery Movement
(Morena-Original) 7, APSG 6, USG 4, CRP I,
independents 3
Judicial branch: Supreme Court (Cour
Supreme)
Political parties and leaders: Gabonese
Democratic Party (PDG, former sole party),
Jaques ADIAHENOT, Secretary General;
National Recovery Movement — Lumberjacks
(Morena-Bucherons/RNB), Fr, Paul
M''BA-ABESSOLE, leader; Gabonese Party
for Progress (PGP), Pierre-Louts AGONDHO-
OKAWE, President; National Recovery
Movement (Morena-Original). Pierre
ZONGUE-NOUEMA, Chairman; Association
for Socialism in Gabon (APSG), leader NA;
Gabonese Socialist Union (USG), leader NA;
Circle for Renewal and Progress (CRP). leader
NA; Union for Democracy and Development
(UDD), leader NA; Rally of Democrats (RD),
leader NA; Forces of Change for Democratic
Union, leader NA
Member of; ACCT. ACP, AIDB. BDEAC,
CCC, CEEAC, ECA. FAO, FZ. G-24. G-77,
GATT. IAEA. IBRD, ICAO, ICC. ICFTU,
IDA, IDB, IFAD, IFC, ILO, IMF, IMO,
INMARSAT, INTELSAT, INTERPOL. IOC,
ITU, LORCS (associate). NAM. OAU, OIC,
OPEC. UDEAC, UN. UNCTAD. UNESCO,
UNIDO. UPU. WCL. WHO. WIPO. WMO,
WTO
Diplomatic representation in US:
chief of mission: Ambassador Paul
BOUNDOUKOU-LATHA
chancery: 2034 20th Street NW, Washington,
DC 20009
telephone: (202)797-1000
US diplomatic representation:
chief of mission: Ambassador Joseph C.
WILSON IV
embassy: Boulevard de la Mer, Libreville
mailing address: B. P. 4000, Libreville
telephone: (241) 762003/4, or 743492
FAX: (24l)745-.‘i07
Flag: three equal horizontal bands of green
(top), yellow, and blue
Names:
conventional tong form: Republic of The','34edec659bd378ef51d865902fde72c003424652280869bf1f5d90dbcfd3c419','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('808deb4d30ca412aa7a680fe50f25e7efe52cdc84daad2720932537369ff9ba6',1994,'GM','Gambia','government',417,'conventional short form: The Gambia
Digraph: GA
Type: republic under multiparty democratic
rule
Capital: Banjul
Administrative divisions: 3 division.'': and I
city*; Banjul*. Lower River, MacCarlhy
Island, North Bank, Upper River. Western
Independence: 18 February 1965 (from UK;
The Gambia and Senegal signed an agreement
on 1 2 December 1 98 1 that called for the
creation of a loose confederation to be known
us Senegambia, but the agreement was
di.ssolved on 30 September 1989)
National holiday: Independence Day, 1 8
February (1965)
Constitution: 24 April 1970
Legal system: based on a composite of
English common law. Koranic law, and
customary law; accepts compulsory ICJ
jurisdiction, with reservations
Suffrage; 21 years of age; universal
Executive branch:
t hief of state and head of government:
President Alhaji Sir Dawda Kairaba JAWARA
(since 24 April 1970); Vice President Saihou
SAB ALLY (since NA); election last held on 29
April 1992 (next to be held April 1997);
results — Sir Dawda JAWARA (PPP) 58.5%,
Sherif Mustapha DIBBA (NCP) 22.2%, Assan
Musa CAMARA (GPP) 8.0%
cabinet: Cabinet; appointed by the president
from members of the House of Representatives
Legislative branch: unicameral
House of Representatives: elections last held
on 29 April 1992 (next to be held April 1997);
results — PPP 58. 1 %, seats — (43 total, 36
elected) PPP 30, NCP 6
Judicial branch: Supreme Court
Political parties and leaders; People’s
Progressive Party (PPP), Dawda K. JAWARA,
secretary general; National Convention Party
(NCP). Sheriff DIBBA: Gambian People’s
Party (GPP), Hassan Musa CAMARA; United
Party (UP), leader NA; People’s Democratic
Organization of Independence and Socialism
(PDOIS). leader NA; People’s Democratic
Party (PDP), Jabel SALLAH
Member of: ACP, AfDB, C. CCC. ECA,
ECOWAS, FAO, G-77, GATT. IBRD, ICAO,
ICFTU. IDA, IDB, IFAD, IFC, IMF, IMO,
INTELSAT (nonsignatory user), INTERPOL,
IOC, ITU, LORCS, NAM, OAU, OIC, UN.
UNCTAD, UNESCO, UNIDO. UPU, WCL.
WFTU, WHO. WlPO, WMO, WTO
Diplomatic representation in US:
chief of mission: Ambassador Ousman A.
SALLAH
chancery: Suite 1000, 1 155 15th Street NW,
Washington, DC 20005
telephone: (202) 785-1399, 1379, or 1425
FAX: (202) 785-1430
US diplomatic representation:
chief of mission: Ambassador Arlene
RENDER
embassy: Fajara, Kairaba Avenue, Banjul
mailing address: P. M. B. No. 19, Banjul
telephone: (220) 92856 or 92858. 91970,
91971
FAX: (220) 92475
Flag: three equal horizontal bands of red
(top), blue with white edges, and green
Note: Under the Israeli-PLO Declaration of
Principles on Interim Self-Government
Arrangements (“the DOP"), Israel agreed to
transfer certain powers and re.sponsibilities to
the Palestinian Authority, and subsequently to
an elected Palestinian Council, as part of
interim self-governing arrangements in the
West Bank and Gaza Strip. A transfer of
powers and responsibilities for the Gaza Strip
and Jericho has taken place pursuant to the
Israel-PLO 4 May 1994 Cairo Agreement on
the Gaza Strip and the Jericho Area. The DOP
provides that Israel will retain responsibility
during the transitional period for external
security and for internal security and public
order of settlements and Israelis. Final status is
to be determined through direct negotiations
within five years.
Names:
conventional long form; none
conventional short form: Gaza Strip
local long form; none
local short form; Qita Ghazzah
Digraph: GZ','e4ed7035dd76ac0e7d58bbf1e15012b16a7fe6d827e223feae228824160335c1','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d714b683b6faf2a5900106eff1223d4b91b1daa6e14a873d5c9584736abb131c',1994,'GE','Georgia','government',426,'Names;
conventional long form: Republic of Georgia
conventional short form: Georgia
local long form; Sak’art’velos Respublika
local short fonn: Sak’art’velo
former; Georgian Soviet Socialist Republic
Digraph: GG
Type: republic
Capital: T''bilisi
Administrative divisions: 2 autonomous
republics (avtomnoy respubliki. singular —
avtom respublika); Abkhazia (Sokhumi),
Ajaria (Bat''umi)
note; the administrative centers of the
autonomous republics are included in
parentheses; there are no oblasts — the rayons
around T’bilisi are under direct republic
jurisdiction
Independence: 9 April 1991 (from Soviet
Union)
National holiday: Independence Day, 9 April
(1991)
Constitution: adopted NA February 1921;
currently amending constitution for
Parliamentary and popular review by late 1995
Legal system: based on civil law system
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: Chairman of Parliament Eduard
Amvrosiyevich SHEVARDNADZE (since 10
March 1992); election last held 1 1 October
1992 (next to be held NA 1995); results —
Eduard SHEVARDNADZE 95%
head of government: Prime Minister Otar
PATSATSIA (since September 1993); Deputy
Prime Ministers Avtandil MARGIANI, Zurab
KERVALISHVILI (since NA), Tamaz
NADARISHVILI (since September 1993),
Teimuraz BASILIA (since NA)
cabinet: Council of Ministers
Legislative branch: unicameral
Georgian Parliament (Supreme Soviet);
elections last held 1 1 October 1992 (next to be
held NA 1995); results — percent of vote by
party NA; seats — (225 total) number of seats
by party NA; note — representatives of 26
parties elected; Peace Bloc, October 1 1 , Unity,
National Democratic Party, and the Greens
Party won the largest representation
Judicial branch: Supreme Court
Political parties and leaders: Merab
Kostava Society, Vazha ADAMIA, chairman;
Traditionalists'' Union, Akaki ASATIANl,
chairman; Georgian Social Democratic Party,
Guram MUCHAIDZE, chairman; Green Party,
Zurab ZHVANIA, chairman; Georgian
Popular Front (GPF), Nodar NATADZE,
chairman; National Democratic Party (NDP),
Gia CHANTURIA, chairman; National
Independence Party (NIP), Irakliy
TSERETELI, chairmen; Charter 1991 Party,
Tedo PATASHVILI, chairman; Peace Bloc;
Unity; October 1 1
Other political or pressure groups:
supporters of ousted President Zuiad
GAMSAKhURDIA (deceased 1 January
1994) boycotted the October elections and
remain a source of opposition and instability
Member of: BSEC, CIS, CSCE. EBRD,
ECE, IBRD, IDA, ILO, IMF. IMO,
INMARSAT, IOC, ITU. NACC, UN.
UNCTAD, UNESCO, UNIDO, UPU. WHO
Diplomatic representation in US:
chief of mission: Ambassador Petr
CHKHEIDZE
chancery: (temporary) Suite 424. 151 1 K
Street NW, Washington, DC
telephone: (202) 393-6060
US diplomatic representation:
chief of mission; Ambassador Kent N.
BROWN
146
embassy: #25 Antoneli Street. T''bilisi 380026
mailing address: use emba.ssy street address
telephone: (7) 8832-98-99-68
FAX: (7) 8832-93-37-59
Flag; maroon field with small rectangle in
upper hoist side comer; rectangle divided
horizontally with black on top, white below
Names:
conventional long form: South Georgia and
the South Sandwich Islands
conventional short form: none
Digraph: SX
Type: dependent territory of the UK
Capital: none; Grytviken on South Georgia is
the garrison town
Administrative divisions; none (dependent
territory of the UK)
Independence: none (dependent territory of
the UK)
National holiday: Liberation Day, 14 June
(1982)
Constitution; 3 October 1983
Legal system: English common law
Executive branch:
chief of state: Queen ELIZABETH li (since 6
February I9.S2), represented by Commissioner
David Everard TATHAM (since August 1992;
resident at Stanley, Falkland Islands)
Legislative branch: no elections
Judicial branch: none','10bc85ad7981bc1183bebb1d37960602c104413b565247f114633e987c8dd13e','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5307d9a3de149621df6dec92823366767c378a844ef9581625a9b02a259fb94',1994,'GH','Ghana','government',431,'Names:
conventional tong form: Republic of Ghana
conventional short form: Ghana
former: Gold Coast
Digraph: GH
Type: constitutional democracy
Capital: Accra
Administrative divisions: 10 regions:
Ashanti, Brong-Ahafo. Central. Eastern,
Greater Accra, Northern, Upper East, Upper
West. Volta. Western
Independence: 6 March 1957 (from UK)
National holiday: Independence Day. 6
March (1957)
Constitution: new constitution approved 28
April 1992
L^al system: based on English common law
and customary law: has not accepted
compulsory ICJ jurisdiction
Sufliuge: universal at 18
Executive branch:
chief of state and head of government:
President Jerry John RAWLINGS (since 3
November 1 992) election last held 3
November 1992 (next to be held NA)
cabinet: Cabinet: president nominates
members subject to approval by the Parliament
Legislative branch: unicameral
National Assembly: elections last held 29
December 1992 (next to be held NA)
Judicial branch: Supreme Court
Political parties and leaders: National
Democratic Congress, Jerry John Rawlings:
New Patriotic Party. Albert Adu BOAHEN;
People''s Heritage Party, Alex Erskine; various
other smaller parties
Member of; ACP, AfDB, C, CCC, EGA,
ECOWAS, FAO, G-24, G-77. GATT, IAEA,
IBRD. ICAO. ICFTU. IDA. IFAD, IFC. ILO,
IMF. IMO. INTELSAT, INTERPOL. IOC.
lOM (observer). ISO. ITU. LORCS.
MINURSO, NAM. OAU, UN. UNCTAD,
UNESCO. UNIDO. UNIFIL, UNIKOM,
UNPROFOR. UNTAC. UPU. WCL. WHO.
WIPO. WMO. WTO
Diplomatic representation in US:
chief of mission: Ambassador Ekwow SPIO-
GARBRAH
chancery: 3512 International Drive NW,
Washington. DC 20008
telephone: (202) 686-4520
MX; (202)686-4527
consulate(s) general: New York
US diplomatic representation:
chief of mission: Ambassador Kenneth L,
BROWN
embassy: Ring Road East. East of Danquah
Circle, Accra
mailing address: P. O. Box 194, Accra
telephone: [233) (2 1 ) 775348, 775349, 775297
or 775298
MX; 1233] (21) 776008
Flag: three equal horizontal bands of red
(top), yellow, and green with a large black five-
pointed star centered in the gold band; uses the
popular pan-African colors of Ethiopia: similar
to the flag of Bolivia, which has a coat of arms
centered in the yellow band
Names;
conventional lon/ifonn: Republic of Togo
conventional short form: Togo
ItH-al lonii form: Republique Togolaise
local short fonn: none
former: French Togo
Digraph: TO
Type: republic under transition to multiparty
democratic rule
Capital; Lome
Administrative divisions: 23
circumscriptions (circonscriptions. singular —
circonscription); Amlame (Amou). Aneho
(Lacs). Atakpame (Ogou), Badou (Wawa),
Bafilu (Assoli), Bassar (Bassari), Dapango
(Tone), Kande (Reran), Klouto (Kioto),
Pagouda (Binah). Lama-Kara (Kozah), Lome
(Golfe), Mango (Oti). Niamtougou
(Doufelgou). Notse (Haho), Pagouda,
Sotouboua, Tabligbo(Yo(o). Tchamba, Nyala,
Tchaoudjo, Tsevie (Zioi, Vogan (Vo)
note: the 23 units may now he called
prefectures (prefectures, singular— prefecture)
and reported name changes for individual units
are included in parentheses
Independence: 27 April I960 (from UN
tmsteeshir under French administration)
National holiday: Independence Day, 27
April (I960)
Constituthm: multiparty draft constitution
approved by High Council of the Republic I
July 1992: adopted by public referendum 27
September 1992
Lqal system; French-based court system
Suffrage: universal adult at age N A
Executive branch:
chief of state: President Gen. Gnassingbe
EYADEMA (since 14 April 1967); election
last held 25 August 1993 (next election to be
held NA 1998); all major opposition parties
boycotted the election; Gen. EY ADEM A won
96.59(- of the vote
hetui of government: Prime Minister Edem
KODJO (since April 1994)
cabinet: Council of Ministers; appointed by
the president and the prime minister
Legislative branch: unicameral
National Assembly: elections la.st nrld on 6 and
20 February 1994 (next to be held NA);
results —percent of vote by party NA: seats —
(81 total) RPT and allies (pro government) 38.
CAR. UTD (the opposition) 40. still contested
as of 3 May 1994
Judicial branch; Court of Appeal (Cour
d’Appel), Supreme (!ourt (Cour Supreme)
Political parties and leaders:
pnhgovemment: Rally of the Togolese People
(RPT). President Gen. Gna.ssingbe
EY ADEM A: Coordination des Forces
Nouvelles (CFN). Joseph KOFFIGOH
miuierate: The Togolese Union for Democracy
(UTD), Edem KODJO; The Action Committee
for Renewal (CAR), Yao AGBOYIBOR
radical: The Union for Democracy and
Solidarity (UDS), Antoine FOLLY; The Pan-
African Sociodemocrats Group (GSP). an
alliance of three radical patties: The
Democratic Convention of African Peoples
(CDPA), Leopold GNININVI; The Pany for
Democracy and Renewal (PDR), Zarifou
AYEVA; The Pan- African Social Party (PSP).
Francis AGBAGLI; The Union of Forces for
Change (UFO, Gilchrist OLYMPIO (in exile)
note: Rally of the Togolese People (RPT) led
by President EYADEMA was the only party
until the formation of multiple patties was
legalized 12 April 1991
Member of: ACCT, ACP, AfDB, CCC,
CEAO (observer), ECA, ECOWAS, Entente,
FAO. FZ. G-77. GATT. IBRD. ICAO. ICC.
ICFTU. IDA. IFAD. IFC. ILO, IMF. IMO,
INTELSAT, INTERPOL. IOC. ITU. LORCS.
NAM. OAU, UN, UNCTAD. UNESCO.
UNIDO. UPU. WADB. WCL. WHO. WIPO.
WMO, WTO
DIploiiuitic repreienhUkHi in US:
chief of mission: Charge d'' Affaires Edem
Frederic HEGBE
chancery: 2208 Massachusetts Avenue NW.
Washington. DC 20008
telephone: (202) 234-4212
US diphmulk repreaentalhm:
chief of mission: Ambassador Harmon E.
KIRBY (Ambassador Johnny YOUNG to
replace Ambassador KIRBY during the
summer of 1994)
embassy: Rue Pelletier Uaventou and Rue
Vauban, Lome
mailing address: B. P. 852. Lome
telephone: 1228) 21-29-91
FAX: 1228) 21-79-52
Flag: five equal horizontal bands of green (top
and bottom) alternating with yellow; there is a
white five-pointed star on a r^ square in the
upper hoist-side c.rmer; uses the popular pan-
African colors of Ethiopia','a391e2f4dfd7b597c8dab79f7943615592bb9632176d73aa42b9fde7e87c43ed','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e361ea2d49deaa367175bc9826445a14a20bbb950169695d20522fa11127446f',1994,'GD','Grenada','government',439,'Names:
conventional long form: none
conventional short form: Grenada
Digraph: GJ
Type: parliamentary democracy
Capital: Saint George’s
Administrative divisions: 6 parishes and 1
dependency*; Carriacou and Petit
Martinique’*. Saint Andrew. Saint David, Saint
George, Saint John, Saint Mark. Saint Patrick
Independence: 7 February 1974 (from UK)
National holiday; Independence Day, 7
February ( 1 974)
Constitution: 19 December 1973
Legal system: ba.sed on English common law
Suffrage; 1 8 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II (since 6
Febmary 1952). represented by Governor
General Reginald Oswald PALMER (since 6
August 1992)
head of government: Prime Minister Nicholas
BRATHWAITE (since 13 March 1990)
cabinet: Cabinet; appointed by the governor
general on advice of the prime minister
Legislative branch: bicameral Parliament
Sennre.- consists of a 13-member body, 10
appointed by the government and 3 by the
Lender of the Opposition
House of Representatives: elections last held
on 13 March 1990 (next to be held by NA
March 1995); results — percent of vote by party
158
NA: seats— ( 15 total) NIX: 7, GULP 4, TNP2,
NNP2
Judicial branch; Supreme Court
Political parties and leaders: National
Democratic Congress (NDC). Nicholas
BRATHWAITE; Grenada United Labor Party
(GULP). Sir Eric GAIRY; The National Party
(TNP), Ben JONES; New National Party
(NNP). Keith MITCHELL; Maurice Bishop
Patriotic Movement (MBPM), Terrence
MARRYSHOW
Member of: ACP, C, CARICOM, CDB.
ECLAC. FAO. G-77. GATT. IBRD. ICAO.
ICFTU. IDA. IFAD, IFC. ILO. IMF,
INTERPOL, IOC. ITU. LAES. LORCS,
NAM, OAS, OECS. OPANAL. UN,
UNCTAD. UNESCO, UNIDO. UPU, WCL,
WHO. WTO
Diplomatic representation in US:
chief of iiiisxioii: Ambassador Denneth
MODESTE
chancery: 1701 New Hampshire Avenue NW.
Washington. DC 20009
telephone: (202) 265-2561
US diplomatic representation:
chief of mission: Charge d'' Affaires Ollie P.
ANDERSON
embassy: Point Salines. Saint George''s
mailing address: P. O. Box 54, Saint George''s,
Grenada, W.I.
telephone: (809) 444- 1 1 7.T through 1178
FAX; (809) 444-4820
Flag: a rectangle divided diagonally into
yellow triangles (top and bottom) and green
triangles (hoist side and outer side) with a red
border around the flag; there are seven yellow
five-pointed stars with three centered in the top
red border, three centered in the bottom red
border, and one on a red disk superimposed at
the center of the flag; there is also a symbolic
nutmeg pod on the hoist-side triangle (Grenada
is the world''s second-largest producer of
nutmeg, after Indonesia); the seven stars
represent the seven administrative divisions','cacda608c49fad387372d1581817ef2281574e0d404272ec70fdf4304e98442f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5e489772095187213eb153c49a8e182249b0b5b5800805d6eff066bc6e5d3e0',1994,'GP','Guadeloupe','government',444,'Names:
conventional long form: Department of
conventional short form: Guadeloupe
local long form: Departement de la
local short form: Guadeloupe
Digraph: GP
Type: overseas department of France
Capital: Basse-Terre
Administrative divisions: none (overseas
department of France)
Independence; none (overseas department of
France)
National holiday: National Day, Taking of
the Bastille, 14 July (1789)
Constitution: 28 September 1958 (French
Constitution)
Legal system: French legal system
Suffrage: 1 8 years of age: universal
Executive branch:
chief of state: President Francois
MITTERRAND (since 21 May 1981)
head of government: Prefect Franck PERRIEZ
(since NA 1992); President of the General
Council Dominique LARiFA (since NA);
President of the Regional Council Lucette
MICHAUX-CHEVRY (since 22 March 1992)
cabinet: Council of Ministers
Legislative branch: unicameral General
Council and unicameral Regional Council
General Council: elections last held NA
March 1992 (next to be held by NA 1996);
results — percent of vote by parly NA: seats —
(43 total) FRUI.G 13, RPR/DUD 13. PPDG 8,
FGPS 3. PCG 3 UPLG 1 . PSG 1 , independent 1
Regional Council: elections last held on 3 1
January 1993 (next to be held by 16 March
1998); results— RPR/DUD 48.30%, FGPS
17.09%, FRUI.G 7.44%, PPDG 8.90%, UPLG
7.75% PCG 6.05%; seats — (41 total) seats by
party NA
French Senate: elections last held in
September 1986 (next to be held Sept -mber
1995); Guadeloupe elects two representatives;
results — percent of vote by party NA; seats —
(2 total) PCG 1,PS 1
French National Assembly: elections last held
on 21 and 28 March 1993 (next to be held
March 1998); Guadeloupe elects four
representatives; results — percent of vote by
party NA; seats — (4 total) PS l.RPR l.PCG I,
independent 1
Judicial branch: Court of Appeal (Cour
d'' Appel) with jurisdiction over Guadeloupe,
French Guiana, and Martinique
Political parties and leaders; Rally for the
Republic (RPR), Aldo BLAISE: Communist
Party of Guadeloupe (PCG). Christian Medard
CELESTE; Socialist Party (FGPS), Georges
LOUISOR; Popular Union for the Liberation
of Guadeloupe (UPLG). Lucien PERATIN;
FGPS Dissidents (FRUI.G); Union for French
Democracy (UDF), Simon BARLAGNE;
Union for the Center Rally (URC; coalition of
the FGPS. RPR, and UDF): Guadeloupe
Objective (OG), Lucette MICHAUX-
CHEVRY ; Progressive Democratic Party
(PPDG), Henri BANGOU
Other political or pressure groups:
Popular Union for the Liberation of
Guadeloupe (UPLG); Popular Movement for
Independent Guadeloupe (MPGI); General
Union of Guadeloupe Workers (UGTG);
General Federation of Guadeloupe Workers
(CGT-G); Christian Movement for the
Liberation of Guadeloupe (KLPG)
Member of: FZ.WCL.WFTU
Diplomatic representation in US; none
(overseas department of France)
US diplomatic representation: none
(overseas department of France)
Flag: the flag of France is used','047ccb34c9c073a2816ec250e8a3c43e51114164b3947c65c972a72155c28416','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a330c1af418fd1d44e1ceb3bba8f7bb9478cf35220da8bac061388eb82ed0816',1994,'GU','Guam','government',451,'Names:
eonventional lony fom: Teaitory of Guam
eonvenlional short form: Guam
Digraph; GQ
Type: organized, unincorporated territory of
the US with policy relations between Guam
and the US under the jurisdiction of the Office
of Territorial ;ind International Affairs. US
Department of the Interior
Capital: Agana
Administrative divisions; none (territory of
the US)
Independence: none (territory of the US)
National holiday: Guam Discovery Day (first
Monday in March 1(1521); Liberation Day, 2 1
July
Constitution; Organic Act of I August 1950
Legal system: modeled on US; federal laws
apply
Suffrage: 1 8 years of age; universal; US
citizens, but do not vote in US presidential
elections
162
Executive branch:
chief of state: President William Jefferson
CLINTON (since 20 January 1993); Vice
F*resident Albert GORE. Jr. (since 20 January
1993)
head of goventinent: Governor Joseph A.
ADA (since November 1986): Lieutenant
Governor Frank F. BLAS (since NA); election
last held on 6 November 1990 (next to be held
NA November 1994); results — Joseph F. ADA
reelected
cabinet: executive departments; heads
appointed by the governor with the consent of
the Guam legislature
Legislative branch: unicameral
Legislature: elections last held on 9 November
1992 (next to be held NA November 1994);
results — percent of vote by party NA: seats —
(21 total) Democratic 14, Republican 7
US House of Represeiilaiives: elections last
held 9 November 1992 (next to be held NA
November 1994); Guam elects one delegate;
results — Robert UNDERWOOD was elected
as delegate; seats— (I total) Democrat I
Judicial branch: Federal District Court.
Territorial Superior Court
Political parties and leaders: Democratic
Party (controls the legislature); Republican
Party (party of the Governor)
Member of: ESCAP (associate). IOC, SPC
Diplomatic representation in VS: none
(territory of the US)
US diplomatic representation: none
(territory of the US)
Flag: territorial flag is dark blue with a narrow
red border on all four sides; centered is a red-
bordered, pointed, vertical ellipse containing a
beach scene, outrigger canoe with sail, and a
palm tree with the word GUAM superimposed
in hold red letters; US flag is the national flag','8a5dca7b2d7e8f8e4bf82632aa1bbb9456a00b6d7d1986ef360f93207e6e0a78','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1837ce334afd005b2f773cdfdc60e4312c9380a9fcd535b1cebcc4b09935a8a',1994,'GT','Guatemala','government',455,'Names:
conventional long form: Republic of
conventional short form: Guatemala
local long form: Republica de Guatemala
local short form: Guatemala
Digraph: GT
Type: republic
Capital: Guatema''a
Administrative divisions: 22 departments
(departamentos. singular — departamento);
Alta Verapaz, Baja Verapaz. Chimaltenango,
Chiquimula. El Fixrgreso, Escuintla,
Guatemala. Huehuetenango. Izabal, Julapa.
Jutiapa. Peten. Quetzaltenango. Quiche,
Retaihuleu. Sacatepequez, San Marcos, Santa
Rosa, Solola, Suchitepequez, Totonicapan,
Zacapa
Independence: 15 September 1821 (from
Spain)
National holiday: Independence Day, IS
September (1821)
Constitution: 31 May 1985, effective 14
January 1986
note: suspended on 25 May 1993 by President
SERRANO; reinstated on 5 June 1993
following ou.ster of president
Legal system: civil law system; Judicial
review of legislative acts; has not accepted
compulsory ICJ jurisdiction
Suflirage: 18 years of age; universal
Executive branch:
chief of state and head of government:
President Ramiro DE LEON Carpio (since 6
June 1993): Vice President Arturo
HERBRUGER (since 18 June 1993); election
runoff held on 1 1 January 1991 (next to be held
1 1 November 1995); results — Jorge
SERRANO Elias (MAS) 68. 1%. Jorge
CARPIO Nicolle (UCN) 31.9%
note: President SERRANO resigned on 1 June
1 993 shortly after dissolving Congress and the
judiciary: on 6 June 1993, Ramiro DE LEON
Carpio was chosen as the new president by a
vote of Congress: he will finish off the
remainder of SERRANO’s five-year term
which expires in 1995
cabinet: Council of Ministers; named by the
president
Legislative branch: unicameral
Congress of the Republic (Congreso de la Re¬
publica): last held on 1 1 November 1990 (next
to be held 1 1 November 1995): result.s — UCN
25.6%. MAS 24,3%. DCG 17.5%, PAN
17.3%. MLN 4.8%, PSD/AP-5 3.6%, PR 2, 1 %;
seats— ( 1 1 6 total ) UCN 38, DCG 27, MAS 1 8,
PAN 12, Pro-Rios Montt 10. MLN 4. PR 1,
PSD/AP-5 1 , independent 5
note: by agreement of 1 1 November 1993, a
special election is to be held in mid- 1994 to
elect a new congress
Judicial branch: Supreme Court of Justice
(Code Supremu de Justicia)
Political parties and leaders: National
Centrist Union (UCN), (vacant); Solidarity
Action Movement (MAS). Oliverio GARCIA
Rodas; Christian Democratic Party (DCG),
Alfonso CABRERA Hidalgo; National
Advancement Party (PAN), Alvaro ARZU
Irigoyen; National Liberation Movement
(MLN), Mario SANDOVAL Alarcon: Social
Democratic Party (PSD), Mario
SOLARZANO Martinez; Popular Alliance 5
(AP-5), Max ORLANDO Molina;
Revolutionary Party (PR), Carlos
CHAVARRIA Perez; National Authentic
Center (CAN), Hector MAYORA Dawe;
Democratic Institutional Party (PID), Oscar
RIVAS: Nationalist United Front (FUN),
Gabriel GIRON: Guatemalan Republican
Front (ERG), Efrain RIOS Montt
163
Guatemala uontm<wd}
other pnlillcal nr pressure gmups:
Coordinating C''oinittcc ol'' Agrieiilturiil.
Coiiiorcial, liidusliiul, and I''ioanclal
AssiK-ialions (CACII''); Mutual Supfxin Ciroup
(GAM); Agrarian Owners Ciroup (L''NACiRO);
C’ oinmittce I''orCanipcsino Unity (CUC); leftist
gueiTillti inovcuicnt known as Ciualeinalan
National Revolutionary Union (LIRNG) has
lour main faetions — Guerrillti army of the Poor
(liCiPl; Revolutionary Organi/tition of the
People in Anns (ORPA); Rebel Aniied I''orees
(FAR); Ciualeinalan Labor Pany (KiT/O)
Member of: BCIL, CACM, CCC, F:cLAC,
FAO, G-24, G-77. GAH''. lADB. lAI-A.
IBRD. ICAO, ICFTU, IDA, IFAD. IFC, ILO,
IMF, IMG, INTFI-SAT. INTliRPOl., IOC'',
lOM, ITU, LAF;.S, LAIA (observer). LORCS,
NAM. OAS, OPANAl.. K:a, UN, UNCTAD,
UNFSCO. UNIDO. UPU. WCL, Wimj,
WHO. WlPO, WMO
Dipinmutic representation in US:
chief i‘fmixsion: Ainhassailor Falmond
MULFiT Lesseur
clumi''eiy: 2220 R Street NW. Washington, DC
2(K)()R
leU’iihtiiie: (202) 74.S-4y.‘i2 through 4454
/7U''.'' (202) 745.|4()«
cimxiilaM.t) neiienil.'' C''hietigo, Housion. I.os
Angeles, Miami, New York, and San iTantiseo
US diplomatic representation:
chief of misxion: Ainhass;tdor Marilyn
McAIdii; (since 2S May IW.1)
einhdsxy: 7-01 Avenida de la Reforma, /one
10, Ciiialeinala Ci(y
nioiliiia iiMexx: A1>0 AA ,74024
lelephoiie: 1.5021 (2) .71-15-41
FAX: 1502|(2)7l-88-.5.5
Flag: three etitial vertical hands of light blue
(hoist side), white, and light blue with (he coal
of arms centered in the white band; the coat of
arms includes a green and red quetzal (the
niitional bird) and a seroll bearing the
inscription LIBI-RTAD 15 DM SFPriFMBRF
DF 1821 (the original date of independence
from Spain) all superimposed on a pair of
crossed rilles tind a pair of crossed swords and
framed by a wreath
Kconumy
Overview: The economy is based on family
and corporate agriculture, which tiecounts for
2b''/, of CiDP, employs about 60''/, of the labor
force, and supplies two-thirds of e.sports.
Manufacturing, predominantly in private
htmds, accounts for about I8''4 of GDP and
12''/, of the labor force. In both IWOand 1441.
the economy givw by 7'';( , the fourth and fifth
consecutive years of mild growth. In 1442
growth picked up to almost 5''/, as government
policies favoring compelilion tind foreign trade
and investment hnik stronger hold. In 144.7,
ilespite political unrest, this inomenluni
contimietl, foreign investment held up, and
growth was estimated at 4''.''( .
Nullonnl pmduci: GDP — purchasing power
equivalent — $7 1 .7 billion ( 1447 csl.)
National product real growth rate: 454''
(I447esl.)
National product per capita: $7.()()() ( 1447
cst.)
Inflation rate (consumer prlcett): 1 1 .ft%
(I447est.)
Uncmplnyment rate: 6.l'')('' (1442 est.). with
.7()-4()''^- underemployiiient
Budget:
reveniiex: Sb()4 million ( I4'')())
exiM''iulitiircx: S8()8 million, including capital
expenditures of $1 74 million (1440)
Kxports: $1.7 billion (f.o.b.. 1447)
conmiodiiiex: cuffee. sugar, bananas,
cardamon, beef
ptirlnerx; US .77''if . FI .Salvador, Costa Rica,
Germany, Honduras
Imports; S2.b billion (c.i.f., 1447)
coimnoiliiiex: fuel and iretroleiim products,
machinery, grain, fertilizers, motor vehicles
/uirinerx: U,S45''^''. Mexico. Venezuela, Japan.','3b125da741fac241e526c997cdd450a5d0c390c71919fa496013d0648c95ca1a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bdcb7d8372225f6acd59a7db5ef3fcb332312921e056ba0bdb35f15b0905f263',1994,'GG','Guernsey','government',456,'(British crown dependency)
Bufhc''ti
Aht»rn9Y
English Chinnel
Gmrnsay
''St> S«mpion
•^Harm
*j9thQu ^ ^
Litth
Names:
conventional long form: Bailiwick of
conventional short form: Guernsey
Digraph: GK
Type: British crown dependency
Capital: Saint Peter Port
Administrative divisions: none (British
crown dependency)
Independence: none (British crown
dependency)
National holiday: Liberation Day, 9 May
(1945)
Constitution: unwritten; partly statutes,
partly common law and practice
Legal system; English law and local statute;
justice is administered by the Royal Coun
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH 11 (since 6
February 1952)
head of government: Lieutenant Governor and
Commander in Chief Lt. CJen. Sir Michael
WILKINS (since NA 1990); Bailiff Mr.
Graham Martyn DOREY (since February
1992)
cabinet: Advisory and Finance Committee
(other committees); appointed by the States
Legislative branch; unicameral
Assembly of the States: elections last held NA
(next to be held NA); results — no percent of
vote by party since all are independents;
seats — (60 total. 33 elected), all independents
Judicial branch: Royal Court
Political parties and leaders: none; all
independents
Member of: none
Diplomatic representation in US: none
(British crown dependency)
US diplomatic representation: none (British
crown dependency)
Flag: white with the red cross of Saint George
(patron saint of England) extending to the
edges of the flag','59d87d699a08b5e26175c10de07e482f0a211cb481ded85d7ea9306b77bafb21','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b4a6f8e5d8957be8554a362f6afec4ca904ad7715cb1c639903959456167649',1994,'GN','Guinea','government',466,'Names:
conventional long form: Republic of Guinea
conventional short form; Guinea
local long form; Republique de Guinee
local .short form: Guinee
former: French Guinea
Digraph: GV
Type; republic
Capital: Conakry
Administrative divisions: 33 administrative
regions (regions administratives, singular —
region administrative); Beyla, Boffa, Boke,
Conakry, Coyah, Dabola, Dalaba, Dinguiraye,
Faranah. Forecariah. Fria, Gaoual. Gueckedou.
Kankan, Kerouane, Kindia, Kissidougou,
Koiibia, Koundara, Kouroussa, Labe,
Lelouma. Lola, Macenta. Mali, Mamou.
Mandiana. Nzerekore, Pita. Siguiri, Telimele,
Tougue, Yomou
Independence: 2 October 1 958 (from France i
National holiday: Anniversary of the Second
Republic, 3 April (1984)
Constitution: 23 December 1990 (Loi
Fundamentale)
Legal system: based on French civil law
system, customary law. and deco*-: legal codes
currently being revised; has not ao .-pted
compulsory ICJ jurisdiction
Sutfrage: none
Executive branch:
chief of state and head of government:
President Lansana CONTE, elected in the first
multi-party election 19 December 1 993 prior to
the election he had ruled as head of military
government since 5 April 1984
cabinet: Council of Ministers: appointed by
the president
Legislative branch: unicameral
People''s National Assembly (Asseinblee
Natiomde Poptdaire): the People’s National
Assembly was dissolved after the 3 April 1984
coup: framework est iblished in December
19''^i for a new Natkmjl A.ssembly with 1 14
seats: legislative elections are scheduled for
1994
Judicial branch: Court of Appeal (Cour
d'' Appel)
Political parties and leaders: political
parties were legalized on I April 1992
pro-government: Party for Unity and Progress
(PUP)
other: Rally for the Guinean People (RPG).
Alpha CONDE; Union for a New Republic
(UNR). Mamadou BAH: Party for Renewal
and Progress (PRP), Siradiou Dl.ALLO
Member of: ACCT, ACP, AfDB. CCC.
CEAO (observer). EC A, ECOWAS, FAO.
G.77. IBRD. ICAO, IDA. IDB. IFAD. IFC,
ILO. IMF. IMO. INTELSAT, INTERPOL,
KX:. ITU, LORCS, MINURSO, NAM, OAU,
QIC. UN. UNCTAD, UNESCO, UNIDO,
UPU. WCL, WHO. WIPO. WMO, WTO
Diplomatic representation in US:
chief of mission: Ambassador ElhadJ
Boubacar BARRY
chancerv: 2112 Leroy Place NW, Washington,
DC200()8
telephone: (202) 483-9420
FAX: (202 J 483-8688
US diplomatic representation:
ciiicfof mission: Ambassador Joseph A.
SALOOM
embassy: 2nd Boulevard and 9th Avenue.
Conakry
mailing address: B. P. 603, Conakry
telephone: (224) 44-15-20 through 24
FAJ(:,(224)44-l5-.’2
Flag: three equal vertical bands of red (hoist
side), yellow, and green; uses the popular pan-
Afi ican colors of Ethiopia: similar to the flag of
Rwanda, which has a large black letter R
cent.ired in the yellow band','a7911adc703f234ac28b88434eba41ac5ca1fa353565d0ad667e6f845a220c8f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa89ca9a71f6adf67fb304403533ccdaf40dde38f9320cee96be976b279efb53',1994,'SN','Senegal','government',470,'Names:
conventional long form: Republic of Guinea-
Bissau
conventional short form: Guinea-Bissau
local long form: Republica dc Guine-Bissau
local short form: Guine-Bissau
former: Portuguese Guinea
Digraph: PU
Type: republic formerly highly centralized,
multiparty .since mid- 1991
Capital: Bissau
Administrative divisions: 9 regions (regioes.
singular — regiao); Bafala, Biombo. Bis.sau.
Bolama, Cacheu, Gabu, Oio. Quinara. Tombali
Independence: 10 September 1974 (from
Portugal)
National holiday: Independence Day, 10
September (1974)
Constitution: 16 May 1984, amended 4 May
1991 (currently undergoing revision to
liberalize popular participation in the
Legal system: NA
Suffrage: 1 5 years of age: universal
Executive branch:
chief of state and head of government:
President of the Council of State Gen. Joao
Bernardo VIEIRA (assumed power 14
November 1980 and wa.s elected President of
Council of State on 1 6 May 1 984); election last
held 19 June 1989 (next to be held 3 July
1994); results — Gen. Joao Bernardo VIEIRA
was reelected without opposition by the
National People’s Assembly
Council of State: this body is elected by the
National People’s Assembly from among its
own members to legislate between sessions of
the National People’s Assembly
cabinet: Council of Ministers; appointed by
the president
Legislative branch: unicameral
National People ''s Assembly: (Assembleia
Nacional Popular) elections last held 15 June
1989 (next to be held 3 July 1994); results —
PAIGC was the only party: seat.s — (150 total)
PAIGC ISO
Judicial branch: none; there is a Ministry of
Justice in the Council of Ministers
Political parties and leaders: African Party
for the Independence of Guinea-Bissau and
Cape Verde (PAIGC), President Joao Bernardo
VIEIRA, leader; Democratic Social Front
(FDS). Rafael BARBOSA, leader; Bafata
Movement. Domingos Fernandes GARNER,
leader; Democratic Front (FD), Aristides
MENEZES, leader
note: PAIGC is .still the major party (of 10
parties) and controls all aspects of the
Member of: ACCT (associate), ACP, AfDB,
ECA. ECOWAS, FAO, G-77, IBRD, ICAO,
IDA. IDB, IFAD. IFC, ILO, IMF. IMO.
INTELSAT (nonsignatory user), INTERPOL,
lOM (observer), ITU, LORCS, NAM, OAU,
OIC, UN, UNAVEM II, UNCTAD, UNESCO,
UNIDO, UNOMOZ, UPU, WFTU. WHO,
WlPO, WMO. WTO
Diplomatic representation in US:
chief ofmis.sion: Ambassador Alfredo Lopes
CAB RIAL
chancers'': 918 16th Street NW, Mezzanine
Suite, Washington, DC 20006
telephone: (202) 872-4222
FAX: (202) 872-4226
US diplomatic representation:
chief of mission: Ambassador Roger A.
McGUlRE
embassy: Barrio oe Penha, Bissau
mailing address: C.P. 297, 1067 Bissau
Codex. Bissau. Guinea-Bissau
telephone: 1245 1 25-2273. 2,5-2274. 25-2275,
25-2276
FAX: [245] 25-2282
Flag: two equal horizontal bands of yellow
(top) and green with a vcitical red band on the
hoist side; there is a black five-pointed star
centered in the red band; uses the popular pan-
.African colors of Ethiopia; similar to the flag of
Cape Verde, which has the black star raised
above the center of the red band and is framed
by iwo corn stalks and a yellow clam shell
Names:
conventional loni> form: Islamic Republic of
Names:
conventional long form: Republic of Senegal
conventional short form: Senegal
local long form: Republique du Senegal
local short form: Senegal
Digraph: SG
Type: republic under multiparty democratic
rule
Capital: Dakar
Administrative divisions: 10 regions
(regions, singular — region); Dakar, Diourbel,
Fatick, Kuolack, Kolda. Louga, Saint-Louis,
Tambacounda, Thies, Ziguinchor
Independence: 20 August I960 (from
France; The Gambia and Senegal signed an
agreement on 1 2 December 1981 that called for
the creation of a loose confederation to be
known as Senegambia, but the agreement was
dissolved on 30 September 1989)
National holiday: Independence Day, 4 April
(1960)
Constitution; 3 March 1963, last revised in
1991
Legal system: based on French civil law
system; judicial review of legislative acts in
Supreme Court, which also audits the
government''s accounting office; has not
accepted compulsory ICJ jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Abdou DIOUF (since
I January 1 98 1); election last held 21 February
1 993 (next to be held February 2000); results —
Abdou DIOUF (PS) 58.4%, Abdoulaye
WADE (PDS) 32.03%, other 9.57%
head of government: Prime Minister Habib
THIAM (since 7 April 1991)
cabinet: Council of Ministers; appointed by
the prime minister in consultation with the
president
Legislative branch: unicamerai
National Assembly {Assemhlee Nationale):
elections last held 9 May 1993 (next to be held
NA May 1998); results— PS 70%. PDS 23%.
other 7%; seats — ( 120 total) PS 84. PDS 27,
LD-MPT 3, Let Us Unite Senegal 3. PIT 2.
UDS-R 1
Judicial branch: Supreme Court (Cour
Supreme)
Political parties and leaders: Socialist Party
(PS), President Abdou DIOUF: Senegalese
Democratic Party (PDS), Abdoulaye WADE;
Democratic League-Labor Party Movement
(LD-MPT), Dr. Abdoulaye BATHILY;
Independent Labor Party (PIT), Amath
DANSOKHO; Senegalese Democratic Union-
Renewal (UDS-R), Mamadou Puritain FALL;
other small uninfluential parties
Other political or pressure groups:
students: teachers; labor; Muslim
Brotherhoods
Member of: ACCT, ACP, AfDB. CCC,
CEAO, ECA, ECOWAS. FAO, FZ. G-15.
G-77. GATT, IAEA, IBRD, ICAO, ICC.
ICFTU, IDA. IDB, IFAD. IFC. ILO, IMF,
IMO, INTELSAT, INTERPOL, IOC, lOM
(observer), ITU, LORCS, NAM. OAU, QIC.
PCA, UN. UNAVEM II, UNCTAD.
UNESCO, UNIDO, UNIKOM, UNOMUR,
UNTAC. UPU, WADB, WCL. WFTU, WHO,
WlPO, WMO. WTO
Diplomatic representation in US:
chief of mission: Ambassador Mamadou
Mansour SECK
chancery: 2112 Wyoming Avenue NW,
Washington, DC 20008
telephone: (202) 234-0540 or 054 1
US diplomatic representation:
chief of mission: Ambassador Mark
JOHNSON
embassy: Avenue Jean XXIII at the comer of
Avenue Kleber, Dakar
mailing address: B. P. 49, Dakar
telephone: [221] 23-42-96 or 23-34-24
FAX: 1221] 22-29-91
Flag: three equal vertical bands of green
(hoist side), yellow, and red with a small green
five-pointed star centered in the yellow band;
uses the popular pan- African colors of Ethiopia
Names:
conventional long form; none
conventional short form; Serbia and','3cf4207f376c7c7ba3a39f53bc01577997ce713cbb6daa93f812a99196eb1d78','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3712d75acd1775f967ed2ce6b944c503f270ee5df743e707cf07fcccd325f31e',1994,'GY','Guyana','government',471,'Econom)’
Overview; Guinea-Bissau ranks among the
poorest countries in the world, with a per capita
GDP of roughly $800. Agriculture and fishing
are the main economic activities. Cashew nuts,
peanuts, and palm kernels are the primary
exports. Exploitation of known mineral
deposits is unlikely at present because of a
weak infrastructure and the high cost of
development.
National product: GDP — purchasing power
equivalent — $860 million (1993 est.)
National product real growth rate: NA
National product per capita: $8(X) (1993
est.)
Inflation rate (consumer prices): 55%
(1991 est.)
Unemployment rate: NA%
Budget:
revenues: $33.6 million
expenditures: $44.8 million, including capital
expenditures of $570,000 (1991 est.)
Exports; $20.4 million (f.o.b., 1991 est.)
commodities: cashews, fish, peanuts, palm
kernels
partners: Portugal, Spain, Senegal. India,','5051fd124870148a58315c54bc24c3ae476dba3d0229fc3cdb3fe909ce5c927c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af3420115a001f585ecc5cad68afd9c98e024fd1bb9d38144757b5ee8880135d',1994,'HT','Haiti','government',478,'Names:
conventional lon.e forin: Republic of Haiti
eonveniional shori form: Haiti
local loiif! form: Republique d'' Haiti
local .shall form: Haiti
Digraph: HA
Type: republic
Capital: Port-;iu-Prince
Administrative divisions: 9 departments.
(departements. singular — departemen );
Artibonite, Centre, Grand’ Ansc. Nord. Nord-
Est. Nord-Ouest, Ouest, .Sud. Sud-Est
Independence: I January 1804 (from Fiance)
National holiday: Independence Day. I
January ( 1 804)
Constitution; constitution approved March
1987, suspended June 1988. most articles
reinstated March 1989; October 1991.
government claims to be observing the
Constitution
Legal sy.stem: based on Roman civil law
system; accepts compulsory ICJ jurisdiction
.Suffrage: 1 8 years of age: universal
171
Haiti (continued)
Executive branch:
chief of slate: President Jean-Bertrand
ARISTIDE (since 7 February 1991), ousted in
a coup in September 1991, but still recognized
by international community as Chief of State;
election lust held 16 December 1990 (next to be
held by December 1995); results — Rev. Jeun-
Benrand ARISTIDE 67,5%, Marc BAZIN
14.2%, Louis DEJOIE 4.9%
head of government: acting Prime Minister
Robert MALVAL (since August 199.^)
cabinet: Cabinet; chosen by prime minister in
consultation with the president
Legislative branch: bicameral National
Assembly (Assemblee Nationale)
Senate: elections last held 18 January 1993,
widely condemned as illegitimate (next to be
held December 1 994); results — percent of vote
NA; seats— (27 total) FNCD 12, ANDP 8,
PAIN 2, MRN 1 , RDNP 1 , PNT 1 , independent
2
Chamber of Deputies: elections lust held 16
December 1990, with runoff held 20 January
1991 (next to be held by December 1994);
results — percent of vote NA; seats — (83 total)
FNCD 27, ANDP 17. PDCH 7, PAIN 6, RDNP
6. MDN 5. PNT 3, MKN 2. MODELH 2. MRN
1 . independents 5, other 2
Judicial branch; Court of Appeal (Cour de
Cassation)
Political parties and leaders: National
Front for Change and Democracy (FNCD),
including National Congress of Democratic
Movements (CONACOM), Victor BENOIT,
and National Cooperative Action Movement
(MKN), Volvick Remy JOSEPH; Movement
for the Installation of Democracy in Haiti
(MIDH), Marc BAZIN; National Progressive
Revolutionary Party (PANPRA), Serge
GILLES; National Patriotic Movement of
November 28 (MNP-28), Dejean BELIZAIRE;
National Agricultural and Industrial Party
(PAIN), Louis DEJOIE; Movement for
National Reconstruction (MRN), Rene
THEODORE; Haitian Christian Democratic
Party (PDCH), Joseph DOUZE; Assembly of
Progressive National Democrats (RDNP),
Leslie MANIGAT; National Party of Labor
(PNT), Thomas DESULME; Mobilization for
National Development (MDN), Hubert DE
RONCERAY; Democratic Movement for the
Liberation of Haiti (MODELH), Francois
LATORTUE; Haitian Social Christian Party
(PSCH), Gregoire EUGENE; Movement for
the Organization of the Country (MOP),
Gesner COMEAU and Jean MG. lERE
Other political or pressure groups:
Democratic Unity Confederation (KID);
Roman Catholic Church; Confederation of
Haitian Workers (CTH); Federation of
Workers Trade Unions (FOS); Autonomous
Haitian Workers (CATH); National Popular
A.ssembly (APN); Revolutionary Front for
Haitian Advancement and Progress (FRAPH)
Member of: ACCT, ACP. CARICOM
(observer), CCC, ECLAC, FAO, G-77, GATT,
lADB, IAEA, IBRD, ICAO, IDA. IFAD, IFC,
ILO, i''/IF. IMO, INTELS \\T, INTERPOL,
IOC, ITU, LAES, LORCS. OAS, OPANAL,
PCA. UN. UNCTAD, UNESCO, UNIDO,
UPU, WCL, W''FTU, WHO, WIPO, WMO,
WTO
Diplomatic representation in US:
chief of mission: Ambassador Jean CASIMIR
chancer," 23 1 1 Massachusetts Avenue NW,
Washington, DC 20008
telephone: (202) 332-4090 through 4092
FAX.- (202) 745-7215
consulate(s) general: Boston, Chicago,
Miami, New York, and San Juan (Puerto Rico)
US diplomatic representation;
chief of mission: Ambassador William Lacy
SWING
embassy: Harry Truman Boulevard, Port-au-
Prince
mailing address; P. O. Box 1761, Port-au-
Prince
telephone: [509) 22-0354, 22-0368. 22-0200,
or 22-0612
FAX.- 1.509] 2.3-1641
Flag: two equal horizontal bands of blue (top)
and red with a centered white rectangle bearing
the coat of arms, which contains a palm tree
flanked by flags and two cannons above a
scroll bearing the motto L''UNION FAIT LA
FORCE (Union Makes Strength)
Names;
conventional long fonn: Territory of Heard
Island and McDonald Islands
conventional short form: Heard Island and
McDonald Islands
Digraph: HM
Type: territory of Australia administered by
the Ministry for Environment, Sport, and
Territories
Capital: none; administered from Canberra,','fa73dd5ff9464fbee92a83d2bc8366061bf585810f304bf310ee138613b35a36','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('100f0c8f765bd550f139043b6e3f85f85b7b2ee8a7680e4e8af68abfa9c58ec9',1994,'IT','Italy','government',479,'Political parlies and leaders; none
Other political or pressure groups: none
(exclusive of intluencc exerci.scd by church
officers)
Member of: CSCE, IAEA. ICFTU. IMF
(observer), INTELSAT. lOM (observer). ITU.
OAS (observer), UN (observer), UNCTAD.
UNHCR, UPU. WIPO, WTO (observer)
Diplomatic representation in US:
chief of mission: Apostolic Pro-Nuncio
Archbishop Agostino CACCIAVILLAN
chancery: 3339 Massachusetts Avenue NW,
Washington, DC 20008
telephone: (202) 333-7121
US diplomatic representation:
chief of mission: Ambassador Raymond L.
FLYNN
embassy: Villino Pacelli, Via Aurelia 294,
00165 Rome
mailing address: PSC 59, APO AE 09624
telephone: [396] 46741
FAX: [396) 638-0159
Flag: two vertical bands of yellow (hoist side)
and white with the crossed keys of Saint Peter
and the papal miter centered in the white band
Names:
conventional long form: Italian Republic
conventional short form: Italy
local long form: Repubblica Italiana
local short form: Italia
former: Kingdom of Italy
Digraph: IT
Type: republic
Capital: Rome
Administrative divisions: 20 regions
(regioni, singular — regione); Abruzzi,
Basilicata, Calabria, Campania, Emilia-
Romagna. Friuli-Venezia Giulia, Lazio,
Liguria, Lombardia, Marche, Molise.
Piemonte, Puglia. Sardegna, Sicilia, Toscana,
Trentino-Alto Adige. Umbria, Valle d’Aosta,
Veneto
Independence: 17 March 1861 (Kingdom of
Italy proclaimed)
National holiday: Anniversary of the
Republic, 2 June (1946)
Constitution: 1 January 1948
Legal system; based on civil law system, with
ecclesiastical law influence; appeals treated as
trials de novo; judicial review under certain
conditions in Constitutional Court; has not
accepted compulsory ICJ Jurisdiction
Suffrage: 1 8 years of age, universal (except in
senatorial elections, where minimum age is 25)
Executive branch:
chief of state: President Oscar Luigi
SCALFARO (since 28 May 1992)
head of government: Prime Minister Silvio
BERLUSCONI (since 1 1 May 1994)
cabinet: Council of Ministers; appointed by
the president
Legislative branch: bicameral Parliament
(Parlamento)
Senate (Senato della Repubblica); elections
last held 27-28 March 1994 (next expected to
be held by spring 2001 ); results — percent of
vote by party NA; seats — (326 total; 315
elected, 1 1 appointed senators-for-life) PDS
61, Northern League 60, National Alliance 48,
Forza Italia 36, Popular Party 31, Communist
Refounding 18, Greens and The Network 13,
Socialist Party 1 3, Christian Democratic
Center 12, Democratic Alliance 8, Christian
Socialists 5. Pact for Italy 4, Radical Party I ,
others 5
Chamber of Deputies (Camera dei Deputati):
elections last held 27-28 March 1994 (next
expected to be held by spring 2001); result.s —
percent of vote by party NA; seats — (630 total)
Northern League 1 17, PDS 1 14, Forza Italia
1 13, National Alliance 109, Communist
Refounding 39, Christian Democratic Center
33. Popular Party 33. Greens and The Network
20, Democratic Alliance 18. Socialist Party 16,
Pact for Italy 1 3, Christian Socialists 5
Judicial branch: Constitutional Court (Corte
Costituzionale)
Political parties and leaders;
Rightists: Forza Italia, Silvio BERLUSCONI;
National Alliance (was Italian Social
Movement — MSI — until January 1994),
Gianfranco FINI, party secretary; Lega Nord
(Northern League). Umberto BOSSI, president
Leftists: Democratic Party of the Left (PDS —
was Communist Party, or PCI, until January
1991 ), Achille (XCHETTO, secretary;
Communist Refounding, Fausto
BERTINOTTI; Greens, Carlo RIPA di
MEARA; Radical Party, Marco PANNELLA;
Italian Socialist Party, Ottaviano DELTURCO;
The Network, Leoluca ORLANDO: Christian
Socialists, Ermanno GORRIERI
Centrists: Pact for Italy, Mario SEGNl;
Popular Party, Rosa JERVOLINO; Christian
Democratic Center, Pier Ferdinando CASINI
Other political or pressure groups: the
Roman Catholic Church; three major trade
union confederations (CGIL — formerly
Communist dominated, CISL — Christian
Democratic, and UIL — Social Democratic,
Socialist, and Republican); Italian
manufacturers and merchants associations
(Confindustria, Confcommercio); organized
farm groups (Confcoltivatori, Confagricoltura)
Member of: AfDB, AG (observer), Aus.ralia
Group, AsDB, BIS, CCC, CDB (non-regional),
CE, CEl, CERN, COCOM, CSCE, EBRD, EC.
ECE, ECLAC, EIB, ESA, FAO, G-7, G-10,
GATT, lADB, IAEA. IBRD, ICAO, ICC,
ICFTU, IDA, IFAD, lEA, IFC, ILO, IMF,
IMO, INMARSAT, INTELSAT, INTERPOL,
IOC, lOM, ISO, ITU, LAIA (observer),
LORCS, MINURSO. MTCR, NACC. NATO,
NEA, NSG, OAS (observer), OECD,
ONUSAL, PCA, UN, UNCTAD, UNESCO,
UNHCR. UNIDO, UNIRL, UNIKOM,
UNMOGIP, UNOSOM, UNTAC, UNTSO,
UPU, WCL, WEU, WHO, WlPO, WMO,
WTO, ZC
Diplomatic representation in US:
chief of mission: Ambassador Boris
BIANCHERI-CHIAPPORI
chancery: 1601 Fuller Street NW,
Washington. DC 20009
telephone: (202) 328-5500
consulate(s) general: Boston, Chicago,
Houston, Miami, New York, Los Angeles,
Philadelphia, San Francisco
consulate(s): Detroit, New Orleans, and
Newark (New Jersey)
US diplomatic representation:
chief of mission: Ambassador Reginald
BARTHOLOMEW
embassy: Via Veneto ! 19/A, 00187-Rome
mailing address: PSC 59, Box 100, Rome;
APO AE 09624
telephone: [39] (6)46741
FAX: [39] (6)488-2672
consulate(s) general: Florence, Milan, Naples
Flag: three equal vertical bands of green
(hoist side), white, and red; similar to the flag
of Ireland, which is longer and is green (hoist
side), white, and orange; also similar to the flag
of the Cote d’Ivoire, which has the colors
reversed — orange (hoist side), white, and green','5dedf4d5ba4cf26dae9ca661f94130fa0212bd2f97774a57ace2dc745dd1659c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5ba9487d5187fde4173409a0e36dce81ffe25ed7c8c7730e064885f17659d97',1994,'HK','Hong Kong','government',486,'Names:
conventional long fonn: none
conventional .short form; Hong Kong
Abbreviation: HK
Digraph; HK
Type: dependent territory of the UK
scheduled to revert to China in 1997
Capital: Victoria
Administrative divisions: none (dependent
territory of the UK)
Independence: none (dependent territory of
the UK; the UK signed an agreement with
China on 19 December 1984 to return Hong
Kong to China on 1 July 1997; in the joint
declaration, China promises to respect Hong
Kong''s existing social and economic systems
and lifestyle)
National holiday: Liberation Day, 29 August
(1945)
Constitution: unwritten; partly statutes,
partly common law and practice; new Basic
Law approved in March 1990 in preparation
for 1997
Legal system: based on English common law
Suffrage: direct election 2 1 years of age;
universal for permanent residents living in the
territory of Hong Kong for the past seven
years; indirect election limited to about
lOO.(XK) professionals of electoral college and
functional constituencies
Executive branch:
chief of .ttate: Queen ELIZABETH II (since 6
February 1952)
177
Hong Kong (continued}
head of govemnent: Governor Chris
PATf EN (since 9 July 1992); Chief Secretary
Anson CHAN Fang On-Sang (since 29
November 1993)
cabinet; Executive Council; appointed by the
governor
Legislative branch: unicameral
Legislative Council; indirect elections last
held 12 September 1991 and direct elections
were held for the first time 1 5 September i 99 1
(next to be held in September 1995 when the
number of directly-elected seats increases to
20); results — percent of vote by party NA;
seats — (60 total; 21 indirectly elected by
functional constituencies, 18 directly elected,
18 appointed by goverttor, 3 ex officio
members); indirect elections — number of seats
by functional constituency NA; direct
elections — UDHK 12, Meeting Point 3, ADPL
I, other 2
Judicial branch: Supreme Court
Political parties and leaders: United
Democrats of Hong Kong, Martin LEE,
chairman; Democratic Alliance for the
Betterment of Hong Kong, TSANG
Yuk-shing, chairman; Hong Kong Democratic
Foundation, Dr, Patrick SHIU Kin-ying,
chairman
note; in April 1994, the United Democrats of
Hong Kong and Meeting Point merged to form
the "Democratic Party;" the merger becomes
effective in October 1994
Other political or pressure groups: Liberal
Party, Allen LEE. chairman; Meeting Point,
Anthony CHEUNG Bing-leung, chairman;
Association for Democracy and People''s
Livelihood, Frederick FUNG Kin Kee,
chairman; Liberal Deinwratic Federation, HU
Fa-kuang, chairman: Federation of Trade
Unions (pro-China), LEE Chark-tim,
president; Hong Kong and Kowloon Trade
Union Council (pro-Taiwan); Confederation of
Trade Unions (pro-demwracy), LAU
Chin-shek, chairman; Hong Kong General
Chamber of Commerce; Chinese General
Chamber of Commerce (pro-China);
Federation of Hong Kong Industries; Chinese
Manufacturers'' Association of Hong Kong;
Hong Kong Professional Teachers'' Union,
CHEUNG Man-kwong, president; Hong Kong
Alliance in Support of the Patriotic Democratic
Movement in China, S?.eto WAH, chairman
note: in April 1994, the United Democrats of
Hong Kong and Meeting Point merged to form
the "DcmiKraiic Party;" the merger becomes
effective in October 1994
Member of: COCOM (cooperating), APEC,
AsDB, CCC, ESCAP (associate), GATT,
ICFTU, IMO (associate), INTERPOL
(subbureau), IOC, ISO (corre.spondent), WCL,
WMO
Diplomatic representation in US: none
(dependent territory of the UK)
US diplomatic repre,sentation;
chief of mission: Consul General Richard
MUELLER
consulate genenil: 26 Garden Road, Hong
Kong
mailing address: PSC 464. Box 30, Hong
Kong, or FPO AP 96522-0002
telephone: |852J 523-901 1
FAX; [852] 845-1598
Flag: blue with the flag of the UK in the upper
hoist-side quadrant with the Hong Kong coat of
arms on a white disk centered on the outer half
of the flag; the coat of arms contains a shield
(bearing two junks below a crown) held by n
lion (representing the UK) and a dragon
(representing China) with another lion above
the shield and a banner bearing the words
HONG KONG below the shield
Names:
conventimal long form: none
conventional short form: Howland Island
Digraph: HQ
Type: unincorporated territory of the US
administered by the Fish and Wildlife Service
of the US Deportment of the Interior as part of
the National Wildlife Refuge System
Capital: none; administered from
Washington, DC
Flag: the flag of Portugal is used','38b81512e773fb39d483d6787dcb4cf7d8e7191cc7c3e058fba78c141e2096ee','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2f2972de24cced0bea7a06087c37efbbd33416bbca011dfbc3143bafd5538a4',1994,'HU','Hungary','government',490,'Names:
conventional long form: Republic of Hungary
conventional short form: Hungary
local long form: Magyar Koztarsasag
local short form: Magyarorszag
Digraph; HU
Type: republic
Capital: Budapest
.Administrative divisions: 38 counties
(megyek, singular — megye)and I capital city*
(fovaros); Bacs-Kiskun. Baranya, Bekes.
Bekesesaba. BorsiKl-Abauj-ZempIcn.
Budapest*. Csongrad, Debrecen. Dunaujvaros,
Eger. Fejer. Gyor, Gyor-Mo.son-Sopron.
Hujdu-Bihar, Heves. Hodniezovasarhely, Jasz-
Nagykun-Szolnok. Kaposvar. Kecskemet,
Komarom-Esztergom. Miskolc, Nagykaniz.su.
Nograd, Nyiregyhaza, Pecs. Pest, Somogy.
Sopron, Szabolcs-Szatinar-Bereg. Szeged,
Szekesfehervar, Szolnok. Szombathely,
Taiabanya, Tolna, Vas. Veszprem, Zala.
Zalaegerszeg
Independence; l(K)l (unification by King
Stephen I)
National holiday; St. Stephen''s Day
(National Day), 20 August (commemorates the
founding of Hungarian state circa UXK) A.D.)
Constitution; 18 August 1949. effective 20
August 1949, revised 19 April 1972; 18
October 1989 revision ensured legal rights for
individuals and constitutional checks on the
authority of the prime minister and a*so
e.stublished the principle of parliamentary
oversight
Legal system: in priK''ess of rt vision, moving
toward rule of law based on Western mixlel
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: President Arpad GONCZ (since
3/ jgust 1990: previously interim president
from 2 May 1990); election last held .3 August
1990 (next to be held NA 199.‘t); results —
President GONCZ elected by parliamentary
vote; note — Piesideet GONCZ was elected by
the National Assembly with a total of 295 votes
out of 304 as interim President from 2 May
1990 until elected President
head of government: Prime Minister Peter
BOROSS (since 12 December 1993 on the
death of Joz.sef ANTALL); new prime minister
will probably be Gyula HORN
cabinet: Council of Ministers: elected by the
National Assembly on recommendation of the
president
Legislative branch; unicameral
National Assembly lOrszaggyules): elections
last held on 8 and 29 May 1 994 (next to be held
.spring 1 998); results — percent of vote by party
NA; scats — (.386 total) Hungarian SiK''ialist
Party 209. Alliance of Free Democrats 70,
Hungarian Democratic Forum 37, Independent
Smallholders 26, Christiati Democratic
People’s Party 22. Federation of Young
Democrats 2(), other 2
Judicial branch: Constitutional Coun
Political parties and leaders: Democratic
Foritm, Sandor LESZAK, chairman:
Independent Smallholders (FKQP), Jozsef
TORGYAN, president; Hungarian Socialist
Party (MSZP), Gyula HORN, president;
Christian Democratic People''s Parly (KDNP),
Dr, Lazio SURJAN, president; Federation of
Young Democrats (FIDE.SZ). ViktorORB AN,
chairman; Alliance of Free Democrats
(SZDSZ), Ivan PETO, chairman
note: the Hungarian Socialist (Communist)
Workers'' Party (MSZMP) renounced
Communism and became the Hungarian
.Socialist Parly (MSZP) in OctolK''r 1 989; there
is .still a smali MSZMP
Member of: Australian Group. BIS, CCC,
CE. CEl, CERN. COCOM (cooperating).
CSCE. EBRD. ECE, FAO. C.-9, GATL IAEA.
IBRD. ICAO. IDA. IFC. ILO. IMF. IMO.
INTELSAT. INTERPOL, IOC. lOM. ISO,
180
ITU, LORCS. MTCR. NACC, NAM (guest),
NSG, OAS (observer). K''A. UN. UNAVEM
II, UNCTAD, UNESCO, UNHCR, UNIDO,
UNIKOM. UNOMOZ, UNOMUR,
UNOSOM. UNTAC, UPU, WFTU. WHO,
WtPO, WMO. WTO, ZC
Diplomatic repi''esenlation in US;
chief of mission: Ambassador Pal TAR
clumcen; 3910 Shoemaker Street NW,
Washington, DC 20008
telephone; (202) 362-6730
FAX.- (202) 966-8135
constilate(s) general; Los Angeles and New
York
US diplomatic representation;
chief of mission: Ambassador Donald
BLINKEN
embassy: V. Szabadsag Ter <2. Budapest
mailing address; Am Embassy, Unit 1320,
Budapest; APO AE 092 1 3
telephone: 136] (1)11 2-6450
FAX.-[36](1) 132-S934
Flag; three equal horizontal bands of red
(top), white, and green','6c2d1731213214df8e107ac019da488e9db2b125d89c525ea38d977ef29c27d5','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c3175607809ad15356d99340c787f08efe6c8614e9858fcf2abfc69ca8b27a6',1994,'IS','Iceland','government',495,'Names;
conventional long form: Republic of Iceland
conventional short form: Iceland
local long form: Lyoveldio Island
local short form: Island
Digraph: IC
Type: republic
Capital: Reykjavik
Administrative divisions: 23 counties
(syslar, singular — sysla) and 14 independent
towns* (kaupsiadhir. singular — kaupstadhur):
Akranes*. Akureyri*. Arnessysla, Auslur-
Bardhastrandarsysla. Austur-Hunavatnssysla,
Austur-Skaftafellssysla, Borgarfjardharsysla,
Dalasysla, Eyjafjardharsysla, Gullbringusysla,
Hafnarfjordhur*, Husavik*, Isafjordhur*,
Keflavik*, Kjosarsysla, Kopavogur*,
Myrasysla, Neskaupstadhur*, Nordhur-
Isafjardharsysla, Nordhur-Mulasys-la,
Nordhur-Thingeyjarsysla, Olafsfjordhur*.
Rangarvalla.sysla, Reykjavik*.
Saudharkrokur*. Seydhisfjordhur*,
Siglufjordhur*, Skagafjardharsysla,
Snaefellsnes og Hnappadalssysla,
Strandasysla, Sudhur-Mulasysla, Sudhur-
Thingeyjarsysla, Vesttmannaeyjar*. Vestur-
Bardhastrandarsysla, Vestur-Hunavatnssysla,
Vestur-Isaljardharsysla, Vestur-
Skaftafellssysla
Independence: 17 June 1944 (from
Denmark)
National holiday: Anniversary of the
Establishment of the Republic. 17 June (1944)
Constitution: 16 June 1944, effective 17 June
1944
Legal system: civil law system based on
Danish law; does not accept compulsory ICJ
jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Vigdis
FINNBOGADOTTIR (since 1 August 1980);
election last held on 29 June 1988 (next
scheduled for June 1996); results — there was
no election in 1992 as President Vigdis
FINNBOGADOTTIR was unopposed
head of government: Prime Minister David
ODDSSON (since .30 April 1991)
cabinet: Cabinet: appointed by the president
Legislative branch: unicameral
Parliament (Althing): elections last held on 20
April 1991 (next to be held by April 1995);
results — Independence Party 38.6%,
Progressive Party 18.9%, Social Democratic
Party 15.5%, People’s Alliance 14.4%,
Womens List 8.3%. Liberals 1.2%, other 3.1%:
seats — (63 total) Independence 26, Progressive
1 3, Social Democratic i 0, People''s Alliance 9,
Womens List 5
Judicial branch: Supreme Court
(Haestirettur)
Political parties and leaders: Independence
Party (conservative), David ODDSSON;
Progressive Party, Steingrimur
HERMANNSSON: Social Democratic Party,
Jon Baldvin HANNIBALSSON; People''s
Alliance (left socialist). Olafur Ragnar
GRIMSSON; Women''s List
Member of: Australian Group, BIS, CCC,
CE. CSCE. EBRD. ECE, EFTA. FAO, GATT,
IAEA, IBRD, ICAO, ICC. ICFTU. IDA. IFC,
ILO, IMF. IMO, INMARSAT, INTELSAT.
INTERPOL. IOC, ISO. ITU. LORCS, MTCR,
NACC, NATO, NC. NEA. NIB. OECD. PCA,
UN. UNCTAD. UNESCO. UPU, WEU
(associate). WHO, WlPO, WMO
Diplomatic representation In US:
chief of mission: Ambassador Einar
BENEDIKTSSON
182
chancery: 2022 Connecticut Avenue NW,
Washington, DC 20O08
telephone: (202) 265-6653 through 6655
FAX: (202) 265-6656
consulate! s) general: New York
US diplomatic representation:
chief of mission: Ambassador Parker W.
BORG
embassy: Laufasvegur 2 1 . Box 40, Reykjavik
mailing address: US Embassy, PSC 1()03, Box
40, Reykjavik; FPO AE 09728-0340
telephone: [3541(1)629100
FAX; [354] (1)629139
Flag: blue with a red cross outlined in white
that extends to the edges of the flag; the vertical
part of the cross is shifted to the hoist side in
the style of the Dannebrog (Danish flag)','0e30dd94fc2f74d72f0c238ecb211e2fb532f60ec4559cfee4538880c786ee04','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32441bbb2e768676357c9899d47cda2ad80482d5138ff952b2865a8520d78ad2',1994,'IN','India','government',500,'Names:
conventional long form: Republic of India
conventional short form: India
Digraph: IN
Type: federal republic
Capital: New Delhi
Administrative divisions: 25 states and 7
union territories*: Andaman and Nicobar
Islands*. Andhra Pradesh. Arunachal Pradesh.
Assam. Bihar, Chandigarh ^ Dadra and Nagar
Haveli*. Daman and Diu*. Delhi*. Goa.
Gujarat, Haryana. Himachal Pradesh. Jammu
and Kashmir. Karnataka. Kerala.
Lakshadweep*. Madhya Pradesh,
Maharashtra. Manipur, Meghalaya. Mizoram,
Nagaland. Orissa, Pondicherry*, Punjab,
Rajasthan. Sikkim, Tamil Nadu. Tripura, Uttar
Pradesh. West Bengal
Independence: 15 August 1947 (from UK)
National holiday; Anniversary of the
Proclamation of the Republic, 26 January
(19.50)
Constitution: 26 January 1950
Legal system: based on English common law:
limited judicial review of legislative acts;
accepts compulsory ICJ jurisdiction, with
reservations
Suffrage: 18 years of age: universal
Executive branch;
chief of .state: President Shankar Dayal
SHARMA (since 25 July 1992); Vice
President Kicheril Raman NARAYANAN
(since 21 August 1992)
head of government: Prime Minister P. V.
Narasimha RAO(since21 June 1991)
cabinet: Council of Ministers; appointed by
the president on recommendation of the prime
minister
Legislative branch: bicameral Parliament
(Sansad)
Council of States (Rajya Sahha): body
consisting of not more than 250 members, up to
1 2 appointed by the president, the remainder
chosen by the elected members of the state and
territorial assemblies
People''s A.ssemhiy (Lok Sahha): elections last
held 21 May. 12 and 15 June 1991 (next to be
held by November 19%); results — percent of
vote by party NA; seats — (545 total. 543
elected. 2 appointed) Congress (1) Party 245,
Bharatiya Janata Party 1 19. Janata Dal Party
39. Janata Dal (Aji) Singh) 20. CPI/M 35, CPI
14. Telugu Desam 13. AlADMK 1 1,
Samajwadi Janata Party 5. Shiv Sena 4. RSP 4.
BSP 1. Congress (S) Party I . other 23. vacant 9
184
Judicial branch: Supreme Court
Political parties and leaders: Congress (I)
Party. P. V. Narasimha RAO, president;
Bharatiya Janata Party (BJP), L.K. ADVANI:
Janata Dal Party. Chandra SHEKHAR; Janata
Dal (Ajit Singh), Ajit SINGH; Communist
Party of India/Marxist (CPl/M), Harkishan
Singh SURJEET; Communist Party of India
(CPI), Indrajii GUPTA; Telugu Desam (a
regional party in Andhra Pradesh), N. T. Rama
RAO; All-India Anna Dravida Munnetra
Kazagham (AIADMK; a regional parly in
Tamil Nadu), Jayaratn JAYALALITHA;
Samajwadi Party (SP, formerly Samajwadi
Janata Party), Mulayam Singh YADAV
(President), Om Prakash CHAUTALA, Devi
LAL; Shiv Sena. Bal THACKERAY;
Revolutionary Socialist Party (RSP), Tridip
CHOWDHURY; Bahujana Samaj Party
(BSP), Kanshi RAM; Congress (S) Party,
leader NA; Communist Party of India/Marxist-
Lenini.st (CPl/ML), Vinod MISHRA; Dravida
Munnetra Kazagham (a regional party in Tamil
Nadu), M. KARUNANIDHI; Akali Dal
factions representing Sikh religious
community in the Punjab; National Conference
(NC; a regional party in Jammu and Kashmir).
Farooq ABDULLAH
Other political or pressure groups: various
separatist groups seeking greater communal
and/or regional autonomy; numerous religious
or militant/chauvinistic organizations,
including Adam Sena. Ananda Marg. Vi.shwa
Hindu Parishad. and Rashtriya Swuyamsevak
Sangh
Member of: AO (observer). AsDB. C. CCC.
CP. ESCAP, FAO. G-6. G-l.^. G-19. AIDB.
G-24. G-77. GATT, IAEA. IBRD, ICAO, ICC,
ICFTU. IDA, IFAD. IFC. ILO. IMF. IMO.
INMARSAT. INTELSAT. INTERPOL. IOC.
lOM (observer). ISO. ITU. LORCS. NAM.
OAS (observer). ONUSAL. PCA. SAARC.
UN. UNAVEM II, UNCTAD. UNESCO.
UNIDO. UNIKOM. UNOMOZ. UNOSOM.
UNPROFOR. UNTAC. UPU, WFTU. WHO.
WIPO. WMO. WTO
Diplomatic representation in US:
chief oj mission: Ambassador Siddhartha
Shankar RAY
cheincen: 2107 Massachusetts Avenue NW.
Washington. DC 20008
lelephone: (202) 939-7000
consiiUiteis) f;enenil: Chicago, New York, and
San Francisco
US diplomatic representation:
chief of mission: Ambassador-designate
Frank WISNER
einhiissy: Sbanii Path. Chanakyapuri 1 10021,
New Delhi
mnilinf; address: use embassy street address
lelephone: [91 1 ( 1 1) 6(K)6.S|
/•''AY.- |9I| (I I (687-2028
considaleisi general: Bombay. Calcutta,
Madras
Flag: three equal horizontal bands of orange
(top), white, and green with a blue chakra
(24-spoked ''vheel) cei ered in the white band;
similar to the flag of Niger, which has a small
orange disk centered in the white band
Digraph: XO
Kconomy
Overview: The Indian CKean provides major
sea routes connecting the Middle East. Africa,
and East Asia w ith Europe and the Americas. It
carries a particularly heavy traffic of petroleum
and petroleum pnxlucts from the oil fields of
the Persian Gulf and Indonesia. Its fish arc of
great and growing importance to the bordering
countries for domestic consumption and
expvirt. Fishing fic''cts from Russia. Japan.
Korea, and Taiwan also exploit the Indian
(Kean, mainly for shrimp and tuna. Large
reserves of hydrocartHms are being tapped in
(he offshorc ureas of .Saudi Arabia. Iran. India,
and Westeni .Australia. .An estimated 4(>''''f of
the world'' s offshorc oil production comes from
(he Indian (Kean. Beach sands rich in heavy
minerals and offshorc placer deposits are
actively exploited by Ixirdering countries,
particularly India. South Africa, Indonesia. Sri
Lanka, and Thailand.
InduMries; bused on exploitation of natural
resources, particularly fish, minerals, oil and
gas, fishing, sand and gravel
(''runmunkallonK
Poii.s: Bombay (Indial. Calcutta lindiai.
Madras (Indial. Colombo (Sri Lanka t. Durban
(South Africa). Fremantle (. Australia l. Jakarta
(Indonesia). Melbourne (Australia), Richards
Bay (South Africa)
Tel«eoiiimunication!i: submarine cables from
India to United .Arab Emirates and Malaysia,
and from Sri Lanka to Djibouti and Indonesia
Names:
conventional long form; Republic of Maldives
conventional short form; Maldives
Digraph: MV
Type: republic
Capital: Male
Administrative divisions: 19 districts
(atolls); Aliff, Baa. Daalu, Faafu. Gaafu Aliff,
Gaafu Daalu, Haa Aliff, Haa Daalu. Kaafu.
Laamu. Laviyani, Meemu, Naviyani, Noonu,
Raa. Seenu. Shaviyani, Than, Waavu
Independence: 26 July 1965 (from UK)
National holiday: independence Day. 26 July
(1965)
Constitution: 4 June 1968
Legal system: based on Islamic law with
admixtures of English common law primarily
in commercial matters; has not accepted
compulsory ICJ jurisdiction
Sufh^ge: 2 1 years of age; universal
Executive branch:
chief of state and head of government;
President Muumoon Abdul GAYOOM (since
1 1 November 1978); election last held 1
October 1993 (next to be held NA): results —
President Maumoon Abdul GAYOOM was
reelected with 92,76% of the vote
cabinet; Ministry of Atolls; appointed by the
president
Legislative branch: unicameral
Citizens'' Council (Majlis): elections last held
on 7 December 1989 (next to be held 7
December 1994); results — percent of vote NA;
seats — (48 total. 40 elected)
Judicial branch: High Court
Political parties and leaders: no organized
political parties; country governed by the Didi
clan for the past eight centuries
Member of: AsDB. C. CP. ESCAP. FAO.
G-77, GATT. IBRD. ICAO. IDA. IDB. IFAD.
IFC. IMF, IMO, INTELSAT (nonsignatory
user). INTERPOL, IOC. ITU. NAM. OIC.
SAARC. UN. UNCTAD. UNESCO. UNIDO,
UPU. WHO. WIPO, WMO. WTO
Diplomatic representation in US: Maldives
has no embas.sy in the US, but does have a UN
mission in New York: Permanent
Representative to the UN Ahmed ZAKI
US dipiomatic representation:
chief of mission: the US Ambassador to Sri
Lanka is accredited to Maldives and makes
periodic visits there
consular agency; Midhath Hilmy, Male
telephone: 2581
Flag: red with a large green rectangle in the
center bearing a vertical white crescent; the
closed side of the crescent is on the hoist side
of the flag
Names:
conventional loan form: Islamic Republic of','e17a55e39507eaf617026de9975bdc029461fac18ef06562de71613f6ea1a194','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb3549267e8498e62fb2fb6a6378886cf3c7290ba3b2a108372bd03a165ae6ce',1994,'OM','Oman','government',508,'Names:
caaventional long form; Islamic Republic of
Iran
conventamal short form: Iron
local longfitrtn: Jomhuri-ye Esiami-ye Iran
liK''ul short form; Iran
Digraph: IR
Type: theocratic republic
Capital: Tehran
Administrative divisions: 24 provinces
(ostanha. singular — ostan); Azurbayjan-e
Bakhtari, Azarbayjan-e Khavuri, Bakhtaran.
Bushehr, Chahar Mahall va Bakhtiari. Esfahan,
Ears, Gilan, Hamadan. Hormozgan, Ham.
Kerman. Khorusan, Khuzestan, Kuhkiluyeh va
Buyer Ahmadi. Kordestun, Lorestan. Markazi,
Mazandaran. Semnan. Sistan vu Baluchestan,
Tehran. Yazd, Zanjun
Independence: I April 1474 (Islamic
Republic of Iran proclaimed)
Natlonnl holiday: Islamic Republic Day, I
Aptil ( 1474)
ConstHuthm: 2-.5 December 1474; revised
1484 to expand powers of the presidency and
eliminate the prime ministership
Legal system: the Constitution codiftes
Islamic principles of government
Sttffeage: 15 years of age; universal
Executive branch:
supreme leiuler amt functional chief of state;
Leader of the Islamic Revolution Ayatollah All
Htvseini- KHAMENEI (since 4 June 1484);
supreme leader (velayat-e faqih)
hemi of gocemm''nt: Presideni Ali Akbar
Hashemi-RAFSANJANI (since .5 .August
1484); election last held June 144.5 (next to be
held Junc-Julv 1447); results— Ali Akbiir
HASHEMI RAFSANJANI was elected with
b.5''-i i»f the v(<te
cabinet: Council of Ministers; selected by the
president w ith legislative uppmvul
legislative branch: unicameral
Islamic Cimsidtativc A.s.\\emhly; iMujles-e-
Shuru-ye-Eslanii I elections lust held 8 April
1442 (next to be held April I4UM; results —
percent of vote by patty NA; scats — (270 seats
total) number of seats by party NA
Judicial branch: SupreiiK* Court
PnilNcal pnrties and leaders: there are at
least 7b licensed parlies: the three most
important are — Tehran Militani Clergy
Ass(K''iuii(*n. Mohammad Re/u MAHDAVI-
KANI: Militant Clerics AsMK''iution. Mehdi
MAHP WI-KARIIBI and Mohammad Asqur
MI''.SAVI-KHOINIHA; Erdaiyin Islam
Organization. Sadeq KHALKHAI.I
Other political or pressure groups; groups
that generally support (he Islamic Republic
include Hi/buHah. Hojjaiiyeb Siviety.
184
Iran (coniinued)
Mojahedin of the Islamic Revolution, Muslim
Students Following the Line of the Imam;
armed political groups that have been almost
completely repressed by the goventment
include Mojahedin-e Khalq Organization
(MEK), People''s Fedayeen. Kurdish
Democratic Party; the Swiety for the Defense
of Freedom
Member of; CCC. CP. ESCAP, ECO, FAO.
G- 1*). 0-24. 0-77, IAEA, IBRD. ICAO. ICC.
IDA. IDB. IFAD, IK''. ILO, IMF. IMO,
INMARSAT. INTELSAT. INTERPOL. IOC.
ISO. ITU. LORCS. NAM. OIC. OPEC, PCA,
UN, UNCTAD. UNESCO. UNHCR. UNIDO,
UPU. WCL. WFTU. WHO. WIPO. WMO.
WTO
Diplomatic representation in US:
chiefof mission: Iran has an Intere.sts Section
in the Pakistani Embassy in Washington. DC
I''htmcen; Iranian Interests Section. 2209
Wisconsin Avenue NW. Washington, DC
20007
teiephone: (202) 96.S-4990
US diplomatic representation: protecting
power in Iran is Switzerland
Flag: three equal horizontal bands of green
(top), white, and red; the national emblem (a
stylized representation of the word Allah) in
red is centered in the white band; Allah Alkbar
(God is Great) in white Arabic script is
repeated 1 1 times along the bottom edge of the
green band and 1 1 times along the top edge of
the red band
Names;
conventional long form; Sultanate of Oman
conventional short form: Oman
l<H’al long firm: Saltanat Uman
Uu-al short form: Usnuij
Digraph: MU
Tvpe: numarchy
CapHai; Muscat
Adminbtrative divisions; there are no first-
order administrative divisions as defined by the
US Government, but there are .3 govemorutes
(muhafazah, singular — muhafazai); Masqat.
Musandam. Zufar
Independence: 16.50 (expulsion of the
Portuguese)
National holiday: National Day, 18
November (1940)
Constitution: none
Legal system; based on English common law
and Islamic law; ultimate appeal to the sultan;
has not accepted compulsory ICJ jurisdiction
Sudkwge: none
Executive branch:
chief of stale and head of government: Sultan
and Prime Minister QAB(X)S bin Said Al Said
(since 2.3 July 1970)
cabinet: Cabinet
Legislative branch: unicameral Consultative
Council
Judicial branch: none; traditional Islamic
judges and a nascent civil court system
Political parties and leaders: none
Other polllIcBl or pressure groups: NA
Member of: ABEDA. AFESD. AL. AMF.
ESeWA. FAO. G-77. GCC, IBRD. ICAO.
IDA. IDB. IFAD. IFC. ILO. IMF. IMO.
INMARSAT. INTELSAT. INTER''LL. IOC.
ISO (correspondent). ITU. NAM. OIC. UN.
UNCTAD. UNESCO. UNIDO. UPU. WFTU,
WHO. WMO
Diplomatic representation in US:
chief of mission; Ambassador-designate
Ahmad bin Muhammad al-RASBI
chancery; 2.342 Massachusetts Avenue NW.
Washington. DC 20008
telephone: (202) .387-1980 through 1982
US diplomatic representation;
chief of mission: Ambassador David J.
DUNFORD
embassy: address NA. Muscat
mailing address: P. O. Box 202 CixJe No. 1 15.
Muscat
telephone: 1968) 698-989
FAX.- 1%81 604-.3I6
Flag; three horizontal bands of white (top,
double width), red, and green (double width)
with a broad, vertical, red band on the hoist
side; the national emblem (a khanjar dagger in
its sheath superimposed on two crossed swords
in scabbards) in white is centered at the top of
the vertical band','a4e473a2302f0fb0c2966cfdc021e1d00ad4d6e58390245648b94b8de66f86df','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f7450512eae8f903440c0e78adeecf120cf7423e22fa6ebc775d8049bcdd9c5',1994,'SA','Saudi Arabia','government',513,'Names;
conventional longfiinn: Republic of Iraq
conventional short jdmi: Iraq
hn-al tonfi form: Al Jumhuriyah al Iruqiyuh
local short fonn: Al Iraq
Digraph: IZ
Type: republic
Capital: Baghdad
Administrative divisions: 1 8 provinces
(muhafazat, singular — muhafazah): Al Anbar,
Al Basrah, Al Mulhanna, Al Qudisiyuh. An
Najaf. Arbil, As Sulaymaniyah, AtTa''mim,
Bubil. Baghdad, Dahuk. Dhi Qar, Diyala.
Karbala''. May sun, Ninuwa. Saluh ad Din,
Wasit
Independence: 3 October 1932 (from League
of Nations mandate under British
administration)
National holiday; Anniversary of the
Revolution. 17 July ( 1968)
Constitution: 22 September 1968. effective
16 July 1970 (provisional Constitution): new
constitution drafted in 1990 but not adopted
Legal system: based on Islamic law in .special
religious courts, civil law system elsewhere:
has not accepted compulsory ICJ jurisdiction
.Sufft^ge; 18 years of age: universal
Executive branch;
chief of state: President SADDAM Husayn
(since 16 July 1979); Vice President Taha
Muhyi al-Din MARUF (since 21 April 1974);
Vice President Taha Yasin RAMADAN (since
23 March 1991)
headofaovernment: Prime Minister Ahmad
Husayn Khudayir al-SAMARRAl (since 5
.September 1993); Deputy Prime Minister
Tariq Mikhail AZIZ (since NA 1979)
Revolutionary Command Council: Chairman
SADDAM Husayn, Vice Chairman Izzat
IBRAHIM al-Duri
cabinet: Council of Ministers
Legislative branch: unicameral
National Assembly (Majlis al-Watani):
elections last held on I April 1989 (next to be
held NA); results — Sunni Arabs 539}, Shi''a
Arabs .309}, Kurds 159}. Christians 29} est.:
seats — (250 total) number of seats by party NA
note: in northern Iraq, a “Kurdish Assembly"
was elected in May 1992 and calls for Kurdish
self-detcrnnnation within a federated Iraq: the
assembly is not recognized by the Baghdad
Judicial branch; Court of Cas.sution
191
Iraq (continued}
Political parties and leaders; Bu''lh Party
Other political or pressure groups:
poliik''ul parties and activity severely restricted;
opposition to regime I''mitt disaffected
memhers of the Baath Party. Army otTicors,
and Shi ''a a''ligious and ethnic Kurdish
dissidents; the Green Parly (government-
controlled)
Member of: ABEDA. ACC, AFESD, AL.
AME. CAEU. cre, ESCWA, FAO. G-PJ.
G-77. IAEA. IBRD. ICAO, IDA. IDB. IFAD.
IFC. ILO. IMF. IMO. INMARSAT,
INTELSAT. INTERPOL. IOC, ISO, ITU.
LORCS. NAM. OAPEC. OlC. OPEC. PC A.
UN, UNCTAD, UNESCO. UNIDO. UPU.
WFTU, WHO. WlPO, WMO, WTO
Diplomatic representation in US:
chief of ini.ssiim: Iraq has an Interest Section in
the Algerian Embassy in Washington. DC
chnneen: Iraqi Interests Section. 1801 PStrect
NW, Washington, DC 2(X),t6
telephone: (202) 48.T7.S(X)
FAX: (202) 462-.''i()66
US diplomatic representation:
chief of mhsion: (vacant); note — operations
have been tenqHtrarily suspended; a US
Interests .Section is located in Poland''s
embassy in Baghdad
enihtisxy: Masbah Quarter (opposite the
Foreign Ministry Club). Baghdad
nuiilin}! othlress: P. O. Box 2447 Alwiyah.
Baghdad
telephone. 1 964 1 ( I ) 7 1 9-6 1 .^8 or 7 1 <)-6 1 ,4''^,
718-1840. 7 19- ,4791
Flag: three equal horizontal bands of red
(top), white, and black with three green tlvc-
pointed stars in a horizontal line centered in the
white band; the phrase ALLAHU AKBAR
(God is Great) in green Arabic script — Allahu
to the right of the middle star and Akbar to the
left of the middle star — was added in January
1991 during the Persian Gulf crisis; similar to
the Hag of Syria that has two stars but ''to script
and the Hag of Yemen that has a plain white
band; also similar to the flag of Egypt that has
a symbolic eagle centered in the white band
Names:
conventional Ions form: Hashemite Kingdom
of Jordan
conventional short form: Jordan
liH ol lonsfonii: Al Mamlakahul Urduniyuh al
Hashimiyah
local short form: Al Urdun
former: Transjordan
Digraph: JO
Type: constitutional monarchy
Capital: Amman
Administrative divisions; 8 goveniorates
(muhafazat. singular — muhafazah): Al Balqu'',
Al Karak, Al Mafraq. ''Amman. AlTalilah. Az
Zurqu''. Irbid. Ma''an
Independence: 25 May 1 946 ( from League of
Nations mandate under British administration)
National holiday: Independence Day. 25
May ( 1946)
Constitution: 8 January 1952
Legal system: bused on Islamic law and
French codes; judicial review of legislative
acts in a specially provided High Tribunal: has
not accepted compul.sory iCJ jurisdiction
SufDage: 20 years of age: universal
Executive branch:
207
Jordan (continued)
chief of state: King HUSSEIN Bin Talal A!
Hashimi (since 1 1 August 1952)
head of government: Prime Minister Abd al-
Salam al-MAJALI (since May 1993)
cabinet: Cabinet appointed by the monarch
Legislative branch; bicameral National
Assembly (Majlis al-’Umma)
House of Notables (Majlis al-A ''ayan):
consists of a 40-member body appointed by the
king from designated categories of public
Figures
House of Representatives: elections last held 8
November 1993 (next to be held NA
November 1997); results — percent of vote by
party NA; seats — (80 total) Muslim
Brotherhood (fundamentalist) 16, Independent
Islamic bloc (generally traditionalist) 6,
Radical leftist 3, pro-government 55
note: the House of Representatives has been
convened and dissolved by the King several
times since 1974 and in November 1989 the
first parliamentary elections in 22 years were
held
Judicial branch; Court of Cassation
Political parties and leaders; NA; note —
political parties were legalized in December
1992
Member of; ABEDA. ACC, AFESD, AL,
AMF, CAEU, CCC, ESCWA, FAO, G-77,
IAEA, IBRD, ICAO. ICC, IDA, IDB, IFAD,
IFC, ILO, IMF. IMO, INTELSAT.
INTERPOL. IOC, lOM (observer), ISO
(correspondent), ITU, LORC.S, NAM, OIC,
PCA, UN, UNAVEM 11. UNCT.3D,
UNESCO. UNIDO. UNOSOM, UNRWA.
UNPROFOR, UNTAC. UPU, WFTU, WHO.
WIPO. WMO, WTO
Diplomatic representation In US;
chief of mission: Ambassador Fayiz A.
TARAWNAH
chancery: 3504 International Drive NW.
Washington. DC 20008
telephone: (202) 966-2664
MX; (202) 966-31 10
US diplomatic representation;
chief of mission: Ambassador Wesley EGAN,
Jr.
embassy: label Amman. Amman
mailing address: P. O. Box 354, Amman, or
APO AE 09892-0200
telephone: [962] (6)820-101
Flag; three equal horizontal bands of black
(top), white, and green with a red isosceles
triangle based on the hoist side bearing a small
white seven-pointed star; the seven points on
the star represent the seven fundamental laws
of the Koran
Names;
conventional long form: State of Qatar
conventional short form: Qatar
local long form: Dawlat Qatar
local short form: Qatar
Digraph: QA
Type: traditional monarchy
Capital: Doha
Administrative divisions; there are no
first-order administrative divisions as defined
by the US Government, but there are 9
municipalities (baladiyat, singular —
baladiyah); Ad Dawhah. A1 Ghuwayriyah, A1
Jumayliyah, Al Khawr. Al Rayyun, Al
Wakrah, Ash Shamal, Jarayan al Batnah. Umm
Salal
Independence: 3 September 1971 (from UK)
National holiday: Independence Day. 3
September (1971)
Constitution: provisional constitution
enacted 2 April 1970
Legal system: discretionary system of law
controlled by the amir, although civil cixics are
being impleinenicd; Islamic law is significant
in personal matters
Suffrage: none
Executive branch:
chief of state and head of government: Amir
and Prime Minister KHALIFA bin Hamad Al
.124
Thani (since 22 February 1972); Crown Prince
HAMAD bin Khalifa A1 Thani (appointed 31
May 1977; son of Amir and Minister of
Defense)
cabinet; Council of Ministers; appointed by
the amir
Legislative branch: unicameral
Advisory Council (Majlis al-Shura);
constitution calls for elections for part of tiiis
consultative body, but no elections have been
held; seats — (30 total)
Judicial branch: Court of Appeal
Political parties and leaders; none
Member of: ABEDA, AFESD, AL, AMF,
CCC, ESCWA, FAO. 0-77, GCC, IAEA,
IBRD, ICAO, IDB, IFAD, ILO, IMF, IMO,
INMARSAT, INTELSAT, INTERPOL, IOC,
ITU, LORCS, NAM, OAPEC, QIC, OPEC,
UN, UNCTAD, UNESCO, UNIDO. UPU,
WHO, WIPO, WMO
Diplomatic representation in US:
chief of mission: Ambassador ABD
AL-RAHMAN bin Saud bin Faud A1 Thani
chancery: Suite 1 180, 600 New Hampshire
Avenue NW, Washington, iX: 2(X)37
telephone; (202) 338-01 1 1
US diplomatic representation:
chief of mission; Ambassador Kenton W.
KEITH
embassy; 149 Ali Bin Ahmed St.. Farig Bin
Omran (opposite the television station), Doha
mailing address; P. O. Box 2399, Doha
telephone: (0974) 864701 through 864703
FAX: (0974) 861669
Flag: maroon with a broad white serrated
band (nine white points) on the hoist side
Names:
conventional lonuform: Department t)f
Reunion
conventional short form: Reunion
local lonuform: none
local short form: He de la Reunion
Digraph; RE
Type: overseas department of France
Capital: Saint-Denis
Adc.inistrative divisions: none (overseas
department of France)
Independence: none (overseas department of
France)
National holiday: Taking of the Bastille, 14
July (1789)
Constitution: 28 September 1958 (French
Constitution)
Legal sy.stem; French law
SulTrage: 1 8 years of age; universal
Executive branch:
chief of state: President Francois
MITTERRAND (since 2 1 May 1981)
head of Kovernment: Prefect of Reunion Island
Hubert FOURNIER (since NA)
cahinet: Council of Ministers
Legislative branch: unicameral General
Council and unicameral Regional Council
(leneral Ctiuncil: elections last held 22 March
1991 (next to be held March 1997); rcsult.s —
percent of vote by party NA; scuts — (44 total)
scuts by party NA
Keffional Council: elections last held 22 March
1992 (next to be held by NA Maa-h 1998);
results— UPF 25.6%.. PCR 17.9%.. PS 10.5%.,
Independent 55.4%, other 12.6%.; seats — (45
total) Sudie 17, UPF 14, PCR 9. PS 5
French Senate: elections last held 24
September 1992 (next to be held NA);
results— percent of vote by party NA; seats —
(5 total) RPR I, FRA I, independent I
French National Assembly: elections last held
21 and 28 March 1995 (next to be held NA
1998); results — percent of vote by party NA;
scats— (5 total) PS I. PCR I, UPF I, RPR 1,
UDF-CDS I ; note — 5 member.s to the French
National As.sembly who are voting members
Judicial branch: Court of Appeals (Cour
d''Appel)
PolilicBl parties and leaders: Rally for the
Republic (RPR), Francois MAS; Union for
French Democracy (UDF), Gilbert GERARD
Communist Party of Reunion (PCR), Elie
HOARAU; France-Reunion Future (FRA),
Andre THIEN AH KOON; Reunion
Communist Party (PCR); Socialist Party (PS),
Jean-Claude FRUTEAU; Social Democrats
(CDS); other small parties
Member of: FZ.WFTU
Diplomatic representation in US: none
(overseas department of France)
US diplomatic representation: none
(overseas department of France)
Flag: the flag of France is used
Names:
cmtventional hmg form: Kingdom of Saudi
Arabia
conventional short form: Saudi Ara''tia
local long form: Al Mamlakah al Arabiyah as
Suudiyah
local short form: Al Arabiyah as Suudiyah
Digraph: SA
Type: monarchy
Capital: Riyadh
Administrative divisions: 1 4 emirates
(imarat, singular — imarah); Al Bahah, Al
Hudud ash Shamaliyah. Al Jawf, Al Madirah.
Al Qusim, Al Qurayyat, Ar Riyod, Ash
Sharqiyah. Asir, Hail. Jizan. Makkah, Najran,
Tabuk
Independence: 23 September 1932
(uniftcation)
National holiday: Uniftcation of the
Kingdom, 23 September (1932)
Constitution: none; governed according to
Shari''a (Islamic law)
Legal system: based on Islamic law, several
secular codes have been introduced;
commercial disputes handled by special
committees; has not accepted compulsory ICJ
jurisdiction
Suffrage: none
ExccuUve branch:
chief of state and head of goi<emment: King
and Prime Minister FAHD bin Abd al-Aziz Al
Saud (since 13 June 1982); Crown Prince and
First Deputy Prime Minister ABDALLAH bin
Abd al-Aziz Al Saud (half-brother to the King,
appointed heir to the throne 13 June 1982)
cabinet: Council of Ministers; mostly made up
of the royal family appointed by the king
Legislative branch: a consultative council
comprised of 60 members and a chairman who
are appointed by the King for a term of four
years
Judicial branch: Supreme Council of Justice
Polllicnl parties and leaders: none allowed
Member of: ABEDA. AfDB, AFESD, AL,
AMF. CCC, ESeWA, FAO, G-19. G-77,
GCC. IAEA, IBRD. ICAO, ICC, IDA, IDB,
IFAD. IFC, ILO, IMF. IMO, INMARSAT,
INTELSAT. INTERPOL, IOC, ISO, ITU,
LORCS, NAM, OAPEC, OAS (observer),
OlC, OPEC. UN. UNCTAD. UNESCO,
UNIDO. UNOSOM, UPU, WFTU, WHO.
WIPO, WMO
Diplomatic representation In US:
chief of mission; Ambas.sador BANDAR bin
Sultan Abd al-Aziz Al Saud
chancery; 601 New Hampshire Avenue NW,
Washineton, DC 2(X)37
telephone; (202) 342-3800
consulatelsl genertti: Houston, Los Angele,s,
and New York
US diplomatic representation:
chief of mission: (vacant); Charge d''Affaires
C. David Welch
embassy: Collector Road M, Diplomatic
Quarter. Riyadh
mailing address: American Embassy, Unit
61307, Riyadh; International Mail: P. O. Box
94309, Riyadh 1 1693; or APO AE 09803- 1 307
telephone: (966] ( 1 ) 488-3800
FAX,- (966) (1)482-4.364
cansulate(s) general: Dhahran. Jiddah
(Jeddah)
Flag: green with large white Arabic .script
(that may be translated as There is no God but
God: Muhammad is the Messenger of God)
above a white horizontal .saber (the tip points to
the hoist side): green is the traditional color of
Islam','e932e22c44ca8cc8b624fa682fb50425206dee3dc02d85fe51a570b05a997095','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae79db03201cb2309b9303ec531cee5c6ba19f2e8802bbf8e2d36ccdd72e8254',1994,'IE','Ireland','government',519,'Names;
conveniiomd tong ji>rm: none
conventional short fonn: lieland
Digraph; El
Type: republic
Capital: Dublin
Administrative divisions: 26 counties;
Carlow. Cavan, Clare, Cork. Dttnegal. Dublin.
G;\\lway. Kerry. Kildurc. Kilkenny, Laois.
Leifiin. Limerick, Longford. Louth, Mayo,
Meath. Monaghan. Offaly. Roscommon. Sligo,
Tippentrv, Waterford. Westmeath. Wexford,
Wicklow-
Ireland (continued)
Independence; 6 December 1921 (from UK)
National holiday: Saint Patrick''s Day, 17
March
Constitution: 29 December 1937; adopted 1
July 1937 by plebecite
Legal system: based on English common law,
substantially modified by indigenous concepts;
judicial review of legislative acts in Supreme
Court; has not accepted compulsory ICJ
jurisdiction
Suffrage: 18 years of age; universal
Executive branch;
chief of •Hale: President Mary Bourke
ROBINSON (since 9 November 1990);
election last held 9 November 1990 (next to be
held November 1997); results — Mary Bourke
ROBINSON 52.8%, Brian LENIHAN 47.2%
head of government: Prime Minister Albert
REYNOLDS (since 1 1 February 1992)
cabinet: Cabinet; appointed by president with
previous nomination of the prime minister and
approval of the House of Representatives
Legislative branch: bicameral Parliament
(Oireachtas)
Senate (Seunad Eireann): elections last held
on NA February 1 992 (next to be held February
1997); results — percent of vote by party NA:
seats — (60 ''otal, 49 elected) Fianna Fail 26,
Fine Gael 16. Labor 9, Piogressive Democrats
2, Democratic Left 1 , independents 6
House of Representatives (Dail Eireann):
elections last held on 25 November 1992 (next
to be held by June 1995); results — Fianna Fail
.39.1%. Fine Gael 24.5%, Labor Party 19.3%,
Progressive Democrats 4.7%, Democratic Left
2.8%, Sinn Fein 1.6%. Workers'' Party 0.7%.
independents 5.9%; seat.s — (166 total) Fianna
Fail 68, Fine Gael 45, Labor Party 33,
Progressive Democrats 10, Democratic Left 4,
Greens I . independents 5
•ludicial branch; Supreme Court
Political parties and leaders; Democratic
Left, Proinsias DE ROSSA; Fianna Fail, Albert
REYNOLDS; Labor Party. Richard SPRING:
Fine Gael, John BRUTON: Communist Party
of Ireland. Michael O''RIORDAN; Sinn Fein,
Gerry ADAMS; Progressive Democrats,
Desmond O''MALLEY
note: Prime Minister REYNOI.DS heads a
coalition consi.sting of the Fianna Fail and the
Labor Party
Member of: Australian Group, BIS. CCC,
CE. COCOM (cooperating). CSCE, EBRD,
EC, ECE, EIB, ESA. FAO. GATT, lAFA,
IBRD, ICAO, ICC. IDA. lEA. IFAD. IFC.
ILO. IMF. IMO. INTELSAT. INTERPOL,
IOC, ISO. ITU, LORCS, MINURSO. MTCR.
NEA, NSG, OECD, ONUSAL, UN,
UNAVEM II, UNCTAD, UNESCO,
UNFICYP, UNIDO, UNIFIL, UNIKOM,
UNOSOM. UNPROFRO. UNTAC, UNTSO,
UPU, WEU (observer). WHO. WIPO, WMO,
ZC
Diplomatic representation in US:
chief of mission: Ambassador Dermot A.
GALLAGHER
chancery: 2234 Mas.sachusetts Avenue NW,
Washington. DC 2(X)08
telephone: (202) 462-3939
consulale(s) general: Boston, Chicago, New
York, and San Francisco
US diplomatic representation:
chief of mission: Ambassador Jean Kennedy
SMITH
embassy: 42 Elgin Road. Ballsbridge, Dublin
mailing address: use embassy street address
fe/epft«ne: [353] (1)6687122
FAX: [3531(1)6689946
Flag: three equal vertieal bands of green
(hoist side), white, and orange: similar to the
flag of the Cote d''Ivoire, which is shorter and
has the colors reversed — orange (hoist side),
white, and green; also similar to the flag of
Italy, which is shorter .and has colors of green
(hoist side), white, and red','848e0ee86dd2ae760a5af0dc89088f09cde6141ee816c41900abe6a023c31ce8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f519d61badec86ff9b1092e74c88a94bb8d8405b2cf7601f03a9435cf250a80',1994,'JO','Jordan','government',528,'Names:
conventional long form: State of Israel
conventional short form: Israel
local long form: Medina! Yisra’el
local short form: Yisra’el
Digraph: IS
Type: republic
Capital: Jerusalem
note: Israel proclaimed Jerusalem its capital in
1950, but the US, like nearly all other
countries, maintains its Embassy in Tel Aviv
Administrative divisions: 6 districts
(mehozot, singular — mehoz); Central, Haifa,
Jerusalem, Northern, Southern, Tel Aviv
Independence: 1 4 May 1 948 ( from League of
Nations mandate under British administration)
National holiday: Independence Day, 1 4
May 1948 (Israel declared independence on 14
May 1 948, but the Jewish calendar is lunar and
the holiday may occur in April or May)
Constitution: no formal constitution: some of
the functions of a constitution are filled by the
Declaration of Establishment (1948), the basic
laws of the parliament (Knesset), and the
Israeli citizenship law
Legal system: mixture of English common
law, British Mandate regulations, and. in
personal matters, Jewish, Christian, and
Muslim legal systems: in December 1985,
Israel informed the UN Secretariat that it
would no longer accept compulsory ICJ
jurisdiction
Suffrage: 1 8 years of age: universal
Executive branch:
chief of state: President Ezer WEIZMAN
(since 13 May 1993) election last held 24
March 1993 (next to be held NA March 1999):
results — Ezer WEIZMAN elected by Knesset
head of government: Prime Minister Yitzhak
RABIN (since NA July 1992)
cabinet: Cabinet: selected from and approved
by the Knesset
Legislative branch: unicameral
parliament (Knesset): elections last held NA
June 1992 (next to be held by NA 1996):
results — percent of vote by party NA: seats —
( 1 20 total) Labor Party 44. Likud bloc 32.
Meretz 1 2. Tzomel 8, National Religious Party
6. Shas 6, United Torah Jewry 4, Democratic
Front for Peace and Equality (Hadash) 3,
Moledet 3, Arab Democratic Party 2; note — in
1994 three new parties were formed, Y.’ud
(from Tzomet), Histadrut List (from the Labor
Party), and Peace Guard (from Moledet),
resulting in the following new distribution of
seats — Labor Party 41, Likud bloc 32, Meretz
1 2, National Religious Party 6. Shas 6. Tzomet
5, United Torah Jewry 4, Democratic Front for
Peace and Equality (Hadash) 3. Yi’ud 3,
Histadrut List 3, Moledet 2, Arab Democratic
Party 2, Peace Guard 1
Judicial branch: Supreme Court
Political parties and leaders:
members of the government: Labor Party.
Prime Minister Yitzhak RABIN: MERETZ.
Minister of Communications Shulamit ALONI
not in coalition, but voting with the govern¬
ment: SHAS. Arieh DERI; Democratic Front
for Peace and Equality (Hadash). Hashim
MAHAMID; Arab Democratic Party. Abd al
Wahab DARAWSHAH; Histadrut List. Haim
RAMON
opposition parties: Likud Party. Einyamin
NETANYAHU: Tzomet, Rafael EITAN;
National ^.eligious Party. Zcvulun HAMMER:
United Torah Jewry, Avraham SHAPIRA:
Moledet, Rehavam ZEEVI; Yi''ud, Gonen
SEGEV: Peace Guard. Shoul GUTMAN
note: Israel currently has a coalition
government comprising 3 parties that hold 56
seals of the Knesset’s 120 seats
Other political or pressure groups: Gush
Emunim. Jewish nationalists advocating
Jewish settlement on the West Bank and Gaza
Strip: Peace Now. critical of government''s
West Bank/Gaza Strip and Lebanon policies
Member of: AG (observer), CCC, (TE
(observer), CERN (oberver), EBRD. ECE,
FAQ. GATT, lADB, IAEA, IBRD, ICAO,
ICC, ICFTU, IDA, IFAD. IFC, ILO, IMF.
IMG. INMARSAT. INTELSAT. INTERPOL.
IOC, lOM, ISO, ITU, OAS (observer). PCA,
UN. UNCTAD, UNESCO, UNHCR, UNIDO,
UPU. WHO. WIPO, WMO. WTO
Diplomatic representation in US:
chief of mission: Ambassador Ilamar
RABINOVICH
chancery: 3514 International Drive NW,
Washington, DC 20008
telephone: (202) 364-5500
FAX: (202) .364-5610
consulate(s) general: Atlanta. Boston,
Chicago. Hou.ston, Los Angeles. Miami, New
York, Philadelphia, and San Francisco
US diplomatic representation:
chief of mission: Ambassador Edward
DJEREJIAN (expected to resign in August
1994)
embassy: 1 1 Huyarkon Street. Tel Aviv
mailing address: PSC 98. Box 1(X). Tel Aviv:
APO AE 098.30
telephone: 1972] (3)517-4338
FAX: (9721 (3) 663-449
Flag: white with a blue hexagram (six-pointed
linear .star) known as the Magcn David (Shield
of David) centered between two equal
horizontal blue bands near the top and bottom
edges of the flag','0101cfb7af959152d6ed32035f28cdd19e7d817a0a1761cc1767eb58299195c9','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf7a5aedb3e3f94b4b20d244b888ef0ec0879e8d9d43ba20e27a9482945a6e60',1994,'JM','Jamaica','government',536,'Names:
conventional lonft form: none
conventional short form: Jamaica
Digraph: JM
Type: parliamentary democracy
Capital: Kingston
Administrative divisions: 14 parishes;
Clarendon. Hanover. Kingston. Manchester.
Portland. Saint Andrew. Saint Ann. Saint
Catherine. Saint Elizabeth. Saint James. Saint
Mary. Saint Thomas, Trelawny. Westmoreland
Independence: 6 August 1962 (from UK)
National holiday: Independence Day (first
Monday in August) (1962)
Constitution; 6 August 1962
Legal s.vsiem; basedon English common law;
has not accepted compulsory ICJ jurisdiction
SufTtuge: 1 8 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH 11 (since 6
February 1952), represented by Governor
General Sir Howard C(X)KE (since I August
1991)
head of government: Prime Minister P, J,
PATTERSON (since .V) March 1992): Deputy
Prime Minister Seymour MULLINGS (since
NAl
cabinet: Cabinet; appointed by the governor
general on the advice of the prime minister
LegMative branch; bicameral Parliament
Senate: consists of a 2 1 -member body
appointed by (be governor general
House of Representatives: elections last held
.V) March 199.1 (next to be held by February
1998); results— percent of vote by party NA;
scuts — (60 tiMal) PNP 52. JLP 8
Judicial branch: Supreme Court
Polittcal parties and leaders; People''s
National Party (PNP) P. J. PATTERSON:
Jamaica Labor Party (JLP), Edward SEAGA
Other polittcal cr pressure groups;
Rastafarians (black religious/racial cultists.
pan-Africanists); New Beginnings Movement
(NBM)
Member of: ACP. C. CARICOM. CCC.
CDB. ECLAC, FAO. G-19. G-77, GATT,
G-15. lADB. IAEA. IBRD. ICAO. ICFTU.
IFAD. IFC. ILO. IMF. IMO. INTELSAT,
INTERPOL. IOC. ISO. ITU. LAES. LORCS.
NAM. OAS. OPANAL. UN. UNCTAD.
UNESCO. UNIDO. UPU, WCL. WFTU.
WHO. WIPO. WMO. WTO
Diplomatic representation in US:
chief of mission: Ambassador Richard
Leighton BERNAL
chancers: Suite .155. 18.50 K Street NW.
Washineton. DC 2(XX)6
telephone: (202) 452-0660
MX. (202)452-0081
consulatetsi general: Miami and New York
US diplomatic representation:
chief of mission: (vacant); Charge d'' Affaires
Lacy A. WRIGHT. Jr.
embassy: Jamaica Mutual Life Center. 2
Oxford Road, ,1rd IliHrr, Kingston
mailing address: use Embassy street address
telephone: (809) 929-4850 through 4859
FAX. (809) 926-674.1
Flag; diagonal yellow cross divides the flag
into four triangles — green (top and bottom)
and black (hoist side and lly side)','e258e52955cf287a25449c91940a860fa54a4f3935ac33377acaca78ca727c2a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61bf13f36e6195bf20114091c4edeeda196ddaed1c04e41e98685704af4a66c4',1994,'JP','Japan','government',540,'Names:
conventional long form: none
conventional short form: Japan
Digraph: JA
Type: con.stitulional monarchy
Capital: Tokyo
Administrative divisions: 47 prefectures;
Aichi. Akita. Aomori. Chiba. Ehime, Fukui,
Fukuoka. Fukushima, Gifu. Gumma.
202
Himshima, Hokkaido. Hyogo, Ibaraki.
Ishikawa. Iwate, Kagawu. Kagoshima.
Kanagawa. K«K''hi. Kumamoto. Kyoto. Mie.
Miyagi. Miya/aki. Nagano. Nagasaki. Nam.
Niigata. Oita. Okayama. Okinawa. Osaka.
Saga. Suitama. Shiga. Shimane. Shizuoka.
Twhigi. Tokushima. Tokyo. Tmiori. Toyama.
Wakayama. Yamagata. Yamaguchi.
Yamanashi
indcpciidciicc: hht) BC (traditional founding
hy Emparor Jimmu)
NaliomI holiday: Birthday of the Emperor.
2.^ December ( 103.^)
Constftutloii: .3 May IW(7
Legal system: modeled after European civil
law system with English-Amcrican inHuence:
judicial review of legislative acts in the
Supreme Court; accepts compulsory ICJ
jurisdiction, with reservations
Sulltrage: 20 years of age: universal
Executive branch:
chief of. <iUih‘: Emperor AKIHITO (since 7
January 1989)
head of ^ocernmi’iii: Prime Minister Tsutomu
HATA (since 2.5 April 1994); Deputy Prime
Minister (vacant)
cabinet: Cabinet; appointed by the prime
minister
largislatlvc branch: bicameral Diet ( Kokkui)
House of Councillors iSttngi-inI; elections last
held on 2b July 1992 (next to he held NA July
I99.S); results — percent of vote by party NA;
seats— (2.52 total) LDP 95. SDPJ 68. Shin
Ryoku fo-Kai .37. CGP 24. JCP 1 1. rther 17
House of Represeniaiives tShufti-in);
elections last held on 1 8 July 199.3 (next to be
held by NA »; results— percent of vtae bv party
NA; seats— (51 1 total) LDP 20b. SDPj''74.
Shinseito b2. CGP 52. JNP ,37. DSP 19. JCP
15. Sakigake 15. others 19. independents 10.
vacant 2
Judicial branch: Supreme Ci>un
Political parties and leaders: Liberal
Demwratic Party (LDP). Yohei KONO,
president: Yoshiro MORI, secretary general:
SiK''ial DemiK-ratic Party of Japan (SDPJ).
Tomiichi MURAYAMA; Democratic
SiK''ialist Party (DSP), Keigo OUCHl,
chairman; Japan Communist Party (JCP),
Tetsuzo FDWA. Presidium chairman; Komeito
(Clean Government Party, CGP). Koshiro
ISHIDA. chaimian; Japan New Party (JNP).
Morihiro HOSOKAWA. chairntun: Shinseito
(Japan Renewal Party, JRP). Tsutomu HATA.
chaimtun: lchiit> OZAWA, secretao'' general;
Sakigake (Harbinger), Masayoshi
TAKEMURA, chairman; Mirai (Future Party).
Michihiko KANO, chairman; The Liberal
Party, Koji KAKIZAWA, chairman
note: Shin Ryoku fu-Kai is a new. upper house
only, parliamentary alliance which includes the
JRP, JNP, DSP. and a minor labor group
Member of; AIDB. AG (observer). Australia
Group. APEC. AsDB. BIS. CCC, COCOM.
CP. CSCE (observer). EBRD, ESCAP. FAO.
G 2. G-5. G-7. G-8. G-IO. GATT, lADB,
IAEA. IBRD. ICAO. ICC. ICFTU. IDA. lEA.
IFAD. IFC. ILO. IMF, IMO. INMARSAT.
INTELSAT. INTERPOL. IOC, lOM
(Observer). ISO. ITU. LORCS. MTCR. NEA.
NSG. OAS observer), OECD. PCA. UN.
UNCTAD. UNESCO. UNHCR. UNIDO.
UNRWA. UNTAC, UPU, WFTU. WHO.
WIPO. WMO. WTO. ZC
DlploimHk representation In US:
chief of mission: Ambassador Takakazu
KURIYAMA
chancers: 2520 Massachusetts Avcuih: NW.
Washington. DC 20008
telephone: (202) 9.39-b700
FAX: (202) .328-2187
consiilaieis) neneral: Agana (Guam).
Anchorage. Atlanta. Boston. Chicago. Detmit.
Honolulu. Houston. Kansas City (Missouri).
Los Angeles, Miami, New Orleans. New York.
Portland (Oregon), San Francin''o. and Seattle
con.sulatets): Saipan (Northern Mariana
Islands)
US dlplonwtk representation;
chief of mission: Ambassador Walter F.
MONDALE
emhttssw 10-5, Akasaka l-chome. Minato-ku
(107). Tokyo
nuiilinfi tuldress: Unit 4.5(X>4. Box 258. T)>kvo:
.APOAP9b.3.37-(XK)l
telephone: |81 1 (.3) .3224-5(X)0
FAX.1811(.3).350.5-18b2
consulaiefsi general: Naha (Okinawa), Osaka-
Kobe. Sappoixt
( •on.sulutei s (.''Fukuoka
Fing: white with a large red disk (representing
the sun without rays) in the center
Names;
conventional long form: none
conventional short form; Jarvis Island
Digraph: DQ
Type: unincorporated territory of the US
administered by the Fish and Wildlife Service
of the US Department of the Interior as part of
the National Wildlife Refuge System
Capital: none; administered from
Washington, DC
Names;
conventional loiift form; Republic of Korea
conventional short form: South Korea
local loiif; form: Taehan-min''guk
local short •orm: none
Abbreviation: ROK
Digraph: KS
Type: republic
Capital: Seoul
Administrative divksions; 9 provinces (do,
singular and plural) and 6 special cities’*
(,jikhalsi, singular and plural); Cheju-do,
Cholla-bukto, Chollu-namdo, Ch''ungch''ong-
bukto, Ch''ungch''ong-namdo. Inch’on-
jikhalsi», Kangwon-do, Kwangju-jikhalsi’*.
Kyonggi-do. Kyongsang-bukto. Kyongsang-
numdo. Pusan-jikhulsi’*. Soul-t''ukpyolsi*.
Taegu-jikhalsi''*. Taejon-jikhalsi*
Independence: 1 5 August 1948
National holiday: independence Day, 15
August (1948)
Constitution; 25 February 1988
Legal system: combines elements of
continental European civil law systems.
218
AnglO''American law, and Chinese classical
thought
Suffrage: 20 years of age; universal
Executive brunch:
chief of state: President KIM Yong-sam (since
25 February 1993); election last held on 18
December 1 992 (next to be held N A December
1997); results— KIM Yong-sam (DLP) 41 .9%.
KIM Tae-chung (DP) 33.8». CHONG Chu-
yong (UPP) 16.3%, other 8%
head of government: Prime Minister Y1 Yong-
tok (since 29 April 1994); Deputy Prime
Minister CHONG Chac-sok (since 21
December 1993) and Deputy Prime Minister
YI Hong-ku (since 30 April 1994)
cabinet: State Council; appointed by the
president on the prime minister''s
recommendation
Legtslulivc branch: unicameral
National Assembly (Kukhoe): elections last
held on 24 March 1992; results— DLP 38.3%,
DP 29.2%, Unification National Party (UNP)
17.3% (name later changed to UPP), other
15%: seats— (299 total) DLP 149, DP 97, UNP
31, other 22; the distribution of seats as of
January 1 994 was DLP 1 72, DP 96. UPP 1 1 .
other 20
note: the change in the distribution of seats
reflects the fluidity of the current situation
where patty members are constantly switching
from one party to another
Judicial branch; Supreme Court
Political parties and leaders;
majority party: Democratic Liberal Party
(DLP), KIM Yong-sam, president
opposition: Democratic Party (DP), YI
Ki-taek. executive chairman: United People''s
Party (UPP), KIM Tong-kil, chairman: several
smaller parties
note: the DLP resulted from a merger of the
Democratic Justice Party (DJP), Reunirication
Democratic Patty (RDP), and New Democratic
Republican Party (NDRP) on 9 February 1990
Other political or pressure groups; Korean
National Council of Churches; National
Democratic Alliance of Korea; National
Federation of Student Associations; National
Federation of Farmers'' Associations: National
Council of Labor Unions; Federation of
Korean Trade Unions; Korean Veterans''
Association; Federation of Korean Industries;
Korean Traders Association
Member of: AfDB, APEC. AsDB, CCC.
COCOM (cooperating), CP. EBRD, ESCAP,
FAO.G-77. GATT. IAEA, IBRD, ICAO, ICC,
ICFTU. IDA, IFAD. IFC. ILO, IMF. IMG.
INMARSAT. INTELSAT, INTERPOL. IOC.
lOM, ISO, ITU, LORCS, OAS (observer). UN,
UNCTAD. UNESCO, UNIDO. UNOSOM,
UPU. WHO. WlPO, WMO, WTO
Diplomatic representation in US;
chief of mission: Ambassador HAN Sung-su
chancery: 2450 Massachusetts Avenue NW,
Washington, DC 2(X)08
telephone: (202) 939-5600
consulate(s) general: Agana (Guam).
Anchorage, Atlanta, Boston, Chicago,
Honolulu, Houston, Los Angeles, Miami, New
York, San Francisco, and Seattle
US diplomatic representation:
chief of mission: Ambassador James T.
LANEY
embassy: 82 Sejong-Ro, Chongro-ku, Seoul
mailing address: American Embassy, Unit
155.50, Seoul; APO AP 96205-0001
telephone: [82 ) (2) 397-4000 through 4(X)8 and
397-41 14
FAX: [82] (2) 738-8845
consulate! s}: Pu.san
Flag: white with a red (top) and blue yin-yang
symbol in the center; there is a different black
trigram from the ancient I Ching (Book of
Changes) in each comer of the white field
Names:
conventional long form; none
conventional short form; Saint Helena
Digraph: SH
Type; dependent territory of the UK
Capital: Jamestown
Administrative divisions: I administrative
area and 2 dependencies*: Ascension*, Saint
Helena, Tristan da Cunha*
Independence; none (dependent territory of
the UK)
National holiday: Celebration of the
Birthday of the Queen, 10 June 1989 (second
Saturday in June)
Constitiition: I January 1989
Legal system: NA
Suffrage: NA
Executive branch:
chief of state; Queen ELIZABETH II (since 6
February 1952)
head of government; Governor A. N. HOOLE
(since NA)
cabinet; Executive Council
Legislative branch: unicameral
Legislative Council; elections last held
October 1984 (next to be held NA); results —
percent of vote by party NA; seats — (15 total,
12 elected) number of seats by party NA
Judicial branch: Supreme Court
Political parties and leaders: Saint Helena
Labor Pany; Saint Helena Progressive Party
note; both political parties inactive since 1976
Member of: ICFTU
Diplomatic representation in US: none
(dependent territory of the UK)
US diplomatic representation: none
(dependent territory of the UK)
Flag: blue with the flag of the UK in the upper
hoist-side quadrant and the Saint Helenian
shield centered on the outer half of the flag; the
shield features a rocky coastline and three-
masted sailing ship
Names;
conventional long form: Federation of Saint
Kitts and Nevis
conventional short form: Saint Kitts and Nevis
former: Federation of Saint Christopher and
Nevis
Digraph: SC
Type: constitutional monarchy
Capital: Basseterre
Administrative divisions: 14 parishs; Christ
Church Nichola Town, Saint Anne Sandy
Point, Saint George Basseterre, Saint George
Cingerland, Saint James Windward, Saint John
Capesterre, Saint John Figtree, Saint Mary
Cayon, Saint Paul Capesterre. Saint Paul
Charlestown, Saint Peter Basseterre, Saint
Thomas Lowland, Saint Thomas Middle
Island, Trinity Palmetto Point
Independence: 19 September 1983 (from
UK)
National holiday: Independence Day. 19
September (1983)
Constitution; 19 September 1983
Legal system: based on English common law
SutTrage: universal adult at age N A
Executive branch:
chief of state: Queen ELIZABETH II (since 6
February 1952). represented by Governor
General Sir Clement Athclston ARRINDELL
(since 19 September 1983, previously
Governor General of the Associated State since
NA November 1981)
head of government: Prime Minister Dr.
Kennedy Alphonse SIMMONDS (since 19
September 1983. previously Premier of the
Associated State since NA February 1980);
Deputy Prime Minister Sydney Earl MORRIS
(since NA)
cabinet: Cabinet; appointed by tiie governor
general in consultation with the prime minister
Legislative branch; unicameral
House of Assembly: elections last held 29
Novemter 1993 (next to be held by 21 March
1998); results — percent of vote by party NA;
seats — (14totai, 11 elected)PAM4,skNLP4,
NRP 1,CCM2
Judicial branch: Eastern Caribbean Supreme
Court
Political parties and leaders: People’s
Action Movement (PAM), Dr. Kennedy
SIMMONDS; Saint Kitts and Nevis Labor
Party (SKNLP), Dr. Denzil DOUGLAS; Nevis
Reformation Party (NRP), Simeon DANIEL;
Concerned Citizens Movement (CCM), Vance
AMORY
Member of: ACP, C. CARICOM, CDB,
ECLAC, FAO, G-77, IBRD, ICFTU, IDA,
IFAD. IMF. INTERPOL, LORCS, OAS,
OECS, UN, UNCTAD, UNESCO, UNIDO,
UPU, WCL, WHO
Diplomatic representation in US:
chief of mission: (vacant); Minister-Counselor
(Deputy Chief of Mission), Charge d’ Affaires
ad interim Aubrey Eric HART
chancery: Suite 608, 2100 M Street NW.
Washington, DC 20037
telephone: (202) 833-3550
FAX: (202) 833-3553
US diplomatic representation: no official
pre.sence since the Charge d’ Affaires resides in
Saint John''s (Antigua and Barbuda)
Flag: divided diagonally from the lower hoist
side by a broad black band bearing two white
five-pointed stars; the black band is edged in
yellow; the upper triangle is green, the lower
triangle is red','d0a1db662d3a38fc97516eb2f36ddf9c051cb9ffd1e2d4ed2a1c72ce71b1250c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c13f6bc1298f8e22376700e57146c735d7763b16f3f110eb1630989ca48202f',1994,'KZ','Kazakhstan','government',544,'i iinventiotial short form: Kazakhstan
local long form: Kazakhstan Respublikasy
local short form: none
former: Kazakh Soviet Socialist Republic
Digraph: KZ
Type: republic
Capital: Almaty
Administrative divisions: 1 9 ohiy star
(singular — oblys) and I city (qalalar,
singular — qala)*; Almaty*, Almaty Oblysy,
Aqmola Oblysy, Aqtobe Oblysy. Atyrau
Oblysy. Batys Qazaqstan Oblysy (Oral).
Kokshetau Oblysy, Mangghystau Oblysy,
Ongtustik Qazaqstan Oblysy (Shymkent),
Qaraghandy Oblysy, (^stanay Obly.sy.
Qyzylorda Obly.sy, Pavlodar Obly.sy, Semey
Oblysy, Shyghys Qazaqstan Oblysy
(Oskemen; formerly Ust’-Kamenogorsk),
Soltustik Qazaqstan Obly.sy (Petropavl),
Taldyqorghan Oblysy. Torghay Oblysy.
Zhambyl Oblysy. Zhezqazghan Oblysy
note: names in parentheses arc administra'' zc
centers when name differs from oblys name
Independence: 16 December 1991 (from the
Soviet Union)
National holiday: Independence Day. 16
December (1991)
Constitution: adopted 28 January 1991
Legal system: based on civil law system
Suffrage: 1 8 years of age: universal
Executive branch:
chief of state: President Nursultan A.
NAZARBAYEV (since NA April 1990); Vice
President Yerik ASANBAYEV (since 1
December 1991); election last held I
December 1991 (next to be held NA 1995);
percent of vote by party NA; Nursultan A.
NAZARBAYEV ran unopposed
head of government: Prime Minister Sergey
TERESHCHENKO (since 14 October 1991);
First Deputy Prime Minister Arkezhan
KAZHEGELDIN (since NA November 1991)
cabinet: Council of Ministers; appointed by
the prime minister
Legislative branch: unicameral
Supreme Council: elections last held 7 March
1994 (next to be held NA 1999); results—
percent of vote by party NA; .scat.s — ( 1 77 total)
Union Peoples'' Unity of Kazakhstan 11.
Federation of Trade Unions of the Republic of
Kazakhstan 1 1, People’s Congress of
Kazakhstan Party 9. SiKiulist Party of
Kazakhstan 8, Peasant Union of the Republic
Kazakhstan 4, .StHiial Movement "LAD" 4.
Organization of Veterans I. Union of Youth of
Kazakhstan i. Democratic Committee for
Human Rights I. Association of Lawyers of
Kazakhstati I. International Public Committee
"Aral-Asia-Kazakhstan" I, Congress of
Entrepreneurs of Kazakhstan 1. Deputies of the
1 2th .Supreme .Soviet 40. independents 62
Judicial branch: .Supreme Court
Political parlies and leaders: Peoples Unitv
Movement (PUU). Kuanysh SULTANOV,
chairman; Peoples Congress. Olzhus
SULEYMENOV. chairman; Kazakhstan
Socialist Party (SPK; former Communist
Party). PiotrSVOIK. co-chairman; Republican
Party (Azat). Kamal ORMANTAYEV.
chairman; Democratic Progress (Russian)
Party. Alexandra DOKUCHAYEVA,
chairman; Union Peoples'' Unity of Kazakhstan
(SNEK); Federation of Trade Unions of the
Republic of Kazakhstan; Peasant Union of the
Republic Kazakhstan; Social Movement LAD
(Slavic Rebinh Society), V. MIKHAYLOV,
chairman; Union of Youth of Kazakhstan;
Democratic Committee for Human Rights;
Association of Lawyers of Kazakhstan;
International Public Committee "Aral-Asia-
Kazakhstan"; Congress of Entrepreneurs of
Kazakhstan; Deputies of the 12th Supreme
Soviet
Other politicBl or pressure groups:
Independent Trade Union Center (Birlesu: an
assiK''iation of independent trade union and
business associations), Leonid SOLOMIN,
president
IVlember of: CCC, CIS. CSCE. EBRD, ECO,
ESCAP. IBRD. ICAO, IDA, IFC. ILO, IMF,
INTFLSAT {nonsignatory user). INTERPOL.
lOD, 1 .ACC, OIC (observer). UN. UNCTAD.
UNESCO. UPU, WHO. WMO
Dipinmatic representation in US:
chief of mission: Ambassador Tuleutai
SULEYMENOV
chancerv: 1421 Massachusetts Avenue, NW,
Washington. DC 2(XX)7
telephone: (202) 113-4504/7
FAX; (202) 111-4509
U.S diplomatic representation:
chief of mission: /Ambassador William H.
COURTNEY
embassy: 99/97 Furmanova .Street. Almaty.
Republic of Kazakhstan 48(K)1 2
mailing address: American Embassy Almaty,
c/o Department of State. Washington, DC,
20521-7010
telephone: (7) (1272) 61-17-70, 63-24-26. 61-
28-80. 61-14-05
FAX: (7) (1272) 61-18-81
Flag: sky blue background representing the
endless sky and a gold sun with 12 rays soaring
above a golden steppe eagle in the center; on
the hoist side is a "national ornamentation" in
yellow
Names:
conventional long form: Kyrgyz Republic
conventional short form: Kyrgyzstan
local long form: Kyrgyz Respublikasy
local short form: none
former: Kirghiz Soviet Socialist Republic
Digraph: KG
Type: republic
Capital: Bishkek
Administrative divisions: 6 oblasttar
(singular — oblast); Chuy Oblasty, Jalal-Abad
Oblasty, Naryn Oblasty, Osh Oblasty, Talas
Oblasty, Ysyk-K.ol Oblasty
note: the administrative center for Chuy
Oblasty is Bishkek; the administrative center
for Ysyk-Kol Oblasty may be Ksyk-Kol or
Karakul; all other oblasttar have administrative
centers of the same name as the oblast
Independence: 31 August 1991 (from Soviet
Union)
National holiday: National Day, 2
December; Independence Day, 31 August
(1991)
Constitution: adopt.3d 5 May 1993
Legal system: based on civil law system
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Askar AKAYEV
(since 28 October 1990); election last held 12
October 1991 (next to be held NA 1996);
results — Askar AKAYEV won in uncontested
election with 95% of vote and with 90% of
electorate voting; note — president elected by
Supreme Soviet 28 October 1990, then by
popular vote 12 October 1991; note —
AKAYEV won 96% of the vote in a
referendum on his status as president on 30
January 1993
head of government: Prime Minister Apas
DZHUMAGULOV (since NA December
1993); First Deputy Prime Minister Almambel
MATURBRAIMOV (since NA)
cabinet: Cabinet of Ministers; subordinate to
the president
Le^slative branch: unicameral
Zhogorku Keneshom: elections last held 25
February 1990 for the Supreme Soviet (next to
be held no later than NA November 1994 for
the Zhogorku Keneshom); results—
Communists 90%; seals — (350 total)
Communists 310
Judicial branch: Supreme Court
Political parties and leaders: Social
Democrats. Ishenbai KADYRBEKOV,
chairman: Kyrgyzstan Democratic Movement
(KDM), Kazat AKHMATOV, chairman;
National Unity, German KUZNETSOV;
Communist Party. Dzhumalbek
AMANBAYEV. chairman; Erkin (Free)
Kyrgyzstan Party, Topchubek
TURGUNALIYEV, chairman
Other political or pressure groups:
National Unity Democratic Movement;
Peasant Party; Council of Free Trade Unions;
Union of Entrepreneurs; Agrarian Party
Member of: CIS, CSCE, EBRD, ECE, ECO,
ESCAP, IBRD, ICAO, IDA, IDB, IFAD. IFC,
ILO, IMF, IOC, NACC. OIC, PCA, UN,
UNCTAD, UNESCO, UNIDO, UPU, WHO
Diplomatic representation in US:
chief of mission: (vacant)
chancery: (temporary^ Suite 705, 151 1 K
Street NW, Washington. DC 20005
telephone: (202) 347-3732/3
F/Uf.- (202) .347-37 18
US diplomatic representation:
chief of mission: Ambassador Edward
HURWITZ
embassy: Erkindik Prospekt #66, Bishkek
720002
mailing address: use embassy street address
telephone: 7-33 1 2 22-29-20, 22-26-93, 22-29-
89
FAX.- 7-.33 12 22-35-51
Flag: red field with a yellow sun in the center
having 40 rays representing the 40 Krygyz
tribes: on the obverse side the rays run
counterclockwise, on the reverse, clockwise; in
the center of the sun is a red ring crossed by
222
two sets of three lines, a stylized representation
of the roof of the traditional Kyrgyz yurt
Names:
conventional long form: Lao People''s
Democratic Republic
conventional short form: Laos
local long form: Sathalanalat Paxathipatai
Paxaxon Lao
local short form: none
Digraph: LA
Type: Communist state
Capital: Vientiane
Administrative divisions: 1 6 provinces
(khoueng, singular and plural) and I
municipality* (kamphengnakhon, singular and
plural); Attapu. Bokeo. Bolikhamsai.
Champasak, Houaphan. Khammouan. Louang
Namtha, Louangphrabang, Oudomxai.
Phongsali, Saravan, Savannakhet, Xekong,
Vientiane, Viangchan*, Xaignabouri,
Xiangkhoang
Independence: 19 July 1949 (from France)
National holiday: National Day, 2 December
(1975) (proclamation of the Lao People''s
Democratic Republic)
Constitution: promulgated 14 August 1991
Legal system: based on civil law .system; has
not accepted compulsory ICJ Jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President NOUHAK
PHOUMSAVAN (since 25 November 1992)
head of government: Prime Minister Gen.
KHAMTAI SIPHANDON (since 15 August
1991)
cabinet: Council of Ministers; appointed by
the president, approved by the As.sembly
Legislative branch: unicameral
Third National Assembly: elections last held
on 20 December 1992 (next to be held NA);
result.s — percent of vote by party NA; seats —
(85 total) number of seats by party NA
Judicial branch: Supreme People''s Court
Political parties and leaders: Lao People''s
Revolutionary Pa''ty (LPRP), KHAMTAI
Siphandon, party president; includes Lao Front
for National Construction (LFNC); other
parties moribund
Other political or pressure groups:
non-Communist political groups moribund;
most leaders fled the country in 1975
Member of: ACCT, AsDB. ASEAN
(observer), CP, ESCAP, FAO, G-77, IBRD,
ICAO, IDA, IFAD, IFC, ILO, IMF,
INTELSAT (nonsignatory user), INTERPOL,
IOC, ITU. LORCS. NAM, PCA. UN,
UNCTAD. UNESCO. UNIDO. UPU, WFTU,
WHO, WMO, WTO
Diplomatic representation in US:
chief of mission: Ambassador HIEM
PHOMMACHANH
chancety: 2222 S Street NW, Washington, IX
20008
telephone: (202) 332-6416 or 6417
FAX: (202) 332-4923
US diplomatic representation:
chief of mission: Ambassador Victor
TOMSETH
embassy: Rue Bartholonie, Vientiane
mailing address: B. P. 114, Vientiane, or
American Embassy, Box V. APO AP 96546
telephone: 1851) 2220, 2357, or 3570, 1 6-958 1
FAX: [851)4675
Flag: three horizontal bands of red (top), blue
(double width), and red with a large white disk
centered in the blue band','bfd6909192f39c41c2b5ff1c0f15782e7f2f2261646de9c767519b0ba77da11c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f4a74f55dfd9a7e198fb484995b254ce1285862fcb0043774d5037767518595',1994,'KE','Kenya','government',549,'Names:
conventional lonpform: Republic of Kenya
conventional short form: Kenya
former: British East Africa
Digraph: KE
Type: republic
Capital: Nairobi
Administrative dlvislon.s: 8 provinces;
Central. Coast. Eastern. Nairobi. North
Eastern. Nyanza. Rift Valley. Western
Independence: 12 December 19( 5 (from
UK)
National holiday: Independence Day, 1 2
December (1963)
Constitution: 12 December 1963, amended
as a republic 1964; reissued with amendments
1979. 1983, 1986, 1988, 1991. and 1992
Legal system; based on English common law,
tribal law, and Islamic law; Judicial review in
High Court; accepts compulsory ICJ
jurisdiction, with reservations; constitutional
amendment of 1982 making Kenya a de jure
one-party state repealed in 1991
Suffrage: 18 years of age; universal
Executive branch:
chief of state and head of government:
President Daniel Teroitich arap MOl (since 14
October 1978); Vice President George
SAITOTI (since 10 May 1989); election last
held on 29 December 1992 (next to be held NA
1997); results — President Daniel T, arap MOl
was reelected with 37% of the ''''cie; Kenneth
Matiba (FORD-ASILI) 26%. wai Kibaki
(SP) 19%. Oginga Odinga (Fi (h 0-Kcnya)
17%
cabinet: Cabinet; appointed by the president
Legislative branch: unicameral
National Assembly t Bunge): elections last held
on 29 December i992; seats — (188 total)
KANU 100. FORD-Kenya 3 1 . FORD-Asili 3 1 .
DP 23. smaller parties 3; president nominates
1 2 additional members
note: first multiparty election since repeal of
one-party state l.iw in 1991
Judicial branch; Coim of Appeal, High
Court
Political parties and leaders; ruling party is
Kenya .African National Union (KANU).
Daniel T. arap MOl. president; opposition
panics include Forum for the Restoration of
Democracy (FORD-Kenya). Michael
WAMALWA; Forum for the Restoration of
Democracy (FORD-Asili). Kenneth MATIBA;
Democratic Pany of Kenya (DP), Mwai
KIBAKI; Kenya National Congress (KNC).
Titus MBATHl; Kenya Stx''ial Congress
(KSC). George ANYONA; Kenya National
Denuwratic Alliance (KENYA). Mukara
NG''ANG’A; Party for Independent
Candidates of Kenya (PKK). OtienoOTOERA
Other political or pressure groups; labor
unions: Roman Catholic Church
Member of: ACP, AfDB. C. CCC. EADB.
ECA. FAO. G-77, GATT, IAEA. IBRD.
ICAO. ICFTU. IDA. IFAD. IFC, IGADD.
ILO. IMF, IMO. INTELSAT. INTERPOL.
IOC, lOM. ISO. ITU. LORC.S. MINURSO.
NAM. OAU. UN. UNCTAD. UNE.SCO.
UNIDO. UNIKOM. UNPROFOR. UNTAC.
UPU. WCL. WHO. WlPO, WMO, WTO
Diplomatic representation in US;
chief of mission: (vacant)
chancerv: 2249 R Street NW. Washington. DC
20008
telephone: (202) 387-6101
consulateis) general: Los Angeles and New
York
212
US diplomatic representation:
chief of mission: Ambassador Aurelia
BRAZEAL
embassy: comer of Moi Avenue and Haile
Selassie Avenue, Nairobi
mailing address: P. O. Box 30 1 37, Unit 64 1 00,
Nairobi or APOAE 09831
telephone: [254] (2) 334I4I
FAX: [254] (2) 340838
Flag: three equal horizontal bands of black
(top), red, and green; the red band is edged in
white: a large wairior’s shield covering crossed
spears is superimposed at the center','394ff6f326ba3945bc07e5605c99d15800b5b275f6a3d0ef3a09b6255a64b3d6','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c52576a576be514c7bbed70f2995a6d56e71851124eb0c9f905db07e16a37c2b',1994,'AS','American Samoa','government',557,'Names;
conventional '' ngform: Republic of Kiribati
conventi '' ''•//orm.- Kiribati
former: ''slands
Digraph: is
Type: rept:''
Capital: Tarawa
Administrative divisions: 3 units; Gilbert
Islands, Line Islands Phoenix Islands
note: a new admrn: ative structure of 6
districts (Banaba. Cvittral Gilberts, Line
Islands. Northern <7iiberts. Southern Gilberts,
Tarawa) may ha. - i''.en changed to 21 island
councils (one for each of the inhabited islands)
named Abaiang, Abemama, Aranuka, Arorae,
Banaba, Bern, Butaritari. Canton, Kiritimati,
Kuria, Maiana. Makin, Marakei, Nikunau,
Nonouti, Onotoa, Tabiteuea, Tabuaeran,
Tamana. Tarawa, Teraina
Independence: 12 July 1979 (from UK)
National holiday: Independence Day, 1 2 July
(1979)
Constitution: 1 2 July 1979
Legal system: NA
Suffrage; 1 8 years of age; universal
Executive branch:
chief of state and head of government:
President (Beretitenti) Teatao TEANNAKl
(since 8 July 1991); Vice President (Kauoman-
ni-Beretitenti) Taomati lUTA (since 8 July
1991); election last held on 8 July 1 99 1 (next to
be held by NA 1996); rettults — Teatao
TEANNAKl 52%, Roniti TEIWAKI 28%
cabinet: Cabinet; appointed by the president
from an elected parliament
Legislative branch: unicameral
House of Assembly (Muneaba Ni
Maungatabu): elections last held on 8 May
1991 (next to be held by NA 1996); results —
percent of vote by party NA; seats — (40 total;
39 elected) percent of seats by party NA
Judicial branch: Court of Appeal, High
Court
Political parties and leaders; National
Progressive Party, Teatao TEANNAKl;
Christian Democratic Party, Teburoro TITO;
New Movement Party, leader NA; Liberal
Party, Tewareka TENTOA; Maneaba Party,
Roniti TEIWAKI
note: there is no tradition of formally
organized political parties in Kiribati; they
niore closely resemble factions or interest
groups because they have no party
headquarters, forma) platforms, or party
structures
Member of: ACP, AsDB, C, ESCAP. IBRD.
ICAO, ICFTU. IDA, IFC, IMF, INTELSAT
(nonsignatory user), INTERPOL, ITU,
SPARTECA, SPC, SPF, UNESCO, UPU,
WHO
Diplomatic repre.sentalion in US: Kiribati
has no mission in the US
US diplomatic representation: the
ambassador to Fiji is accredited to Kiribati
Flag: the upper half is red with a yellow
frigate bird flying over a yellow rising sun, and
the lower half is blue with three horizontal
wavy white stripes to represent the ocean
Names;
conventional long form: Democratic People’s
Republic of Korea
conventional short form: North Korea
local long form: Choson-minjujuui-inmin-
konghwaguk
l(?cal short form; none
Abbreviation: DPRK
Digraph: KN
Type: Communist slate; Stalinist dictatorship
Capital: P''yongyang
Administrative divisions: 9 provinces (do,
singular and plural) and 3 special cities''*
(jikhalsi, singular and plural); Chagang-do
(Chagang Province), Hamgyong-bukto (North
Hamgyong Province), Hamgyong-namdo
(South Hamgyong Province), Hwanghae-
bukto (North Hwanghae Province),
Hwanghae-namdo (South Hwanghae
Province), Kaesong-si* (Kaesong City),
Kangwon-do (Kangwon Province), Namp’o-
si* (Namp’o City), P’yongan-bukto (North
P’yongan Province), P’yongan-namdo (South
P’yongan Province), P’yongyang-si*
(P''yongyang City), Yanggang-do (Yanggang
Province)
Independence: 9 September 1948
note: IS August 1945, date of independence
from the Japanese and celebrated in North
Korea as National Liberation Day
National holiday: DPRK Foundation Day, 9
September (1948)
Constitution: adopted 1948, completely
revised 27 December 1972, revised again in
April 1992
Legai system: based on German civil law
system with Japanese influences and
Communist legal theory; no judicial review of
legislative acts; has not accepted compulsory
ICJ jurisdiction
Suffrage: 17 years of age; universal
Executive branch:
chief ofstate: President KIM 11-song (national
leader since 1948, president since 28
December 1972); designated successor KIM
Chong-il (son of president, bom 16 February
1942); election last held 24 May 1990 (next to
be held by NA 1995); results — President KIM
11-song was reelected without opposition
head of government: Premier KANG Song-
san (since December 1992)
cabinet: State Administration Council:
appointed by the Supreme People’s Assembly
Legislative branch: unicameral
Supreme People ''s Assembly ( Ch ''oego Inmin
Hoeui): elections last held on 7-9 April 199,1
(next to be held NA); results — percent of vote
by party NA; seats — (687 total) the KWP
approves a single list of candidates who are
elected without opposition; minor parties hold
a few .seats
Judicial branch: Central Court
Political parties and leaders: major party —
Korean Workers'' Party (KWP), KIM Il-song,
general secretary, and his son, KIM Chong-il,
secretary. Central Committee; Korean Social
Democratic Party, KIM Pyong-sik, chairman;
Chondoist Chongu Party, YU Mi-yong,
chairwoman
Member of: ESCAP, FAO, G-77. IAEA,
ICAO, IFAD, IMF (observer), IMO,
INTELSAT (nonsignatory u.ser), IOC, ISO,
ITU, LORCS, NAM, UN, UNCTAD,
UNESCO, UNIDO, UPU, WFTU, WHO,
WIPO, WMO, WTO
Diplomatic representation in US: none
US diplomatic representation: none
Flag: three horizontal bands of blue (top), red
(triple width), and blue: the red band is edged
in white; on the hoist side of the red band is a
white disk with a red five-pointed star
Names:
amventiomil lon^form: none
conventional short form: Palmyra Atoll
Digraph: LQ
Type: incorporated territory of the US:
privately owned, but administered by the
Office of Territorial and International Affairs,
US Department of the Interior
Capital: none; administered from
Washington, DC','b44ab012d78c8d730da1a4b6092d37422ab51a60117501512e9ec507e5a600d8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f314dc44c02c8d725d9977fd4623e8a0005d3930dbf9429c0910e303f306725',1994,'LV','Latvia','government',568,'Names:
conventional longjbrm: Republic of Latvia
conventional short form: Latvia
local lon,^form: Latvijas Republika
local short form: Latvija
former: Latvian Soviet Sivialist Republic
Digraph; LG
Type: republic
Capital: Riga
Administrative divisions; 26 counties
(singular — rajons) and 7 municipalities’*;
Ai/krauklcs Rajons, Aluksnes Rajons. Baivu
Rajons, Bauskas Rajons, Cesu Rajon...
Daugavpils*, Daugavpils Rajons. Dobeles
Rajons. Gulbenes Rajons, Jekabpils Rajons,
Jelgava*. Jelgavas Rajons. Jurmala*.
Kraslavas Rajons, Kuldigas Rajons, Leipaja*.
Liepajas Rajons, Limbazu Rajons, Ludzas
Rajons, Madonas Rajons, Ogres Rajons, Preiju
Rajons, Rezekne*. Rezeknes Rajons. Riga*,
Rigas Rajons. Saldus Rajons, Talsu Rajon.s.
Tukuma Rajons, Valkas Rajons. Valmieras
Rajons, Ventspils*, Ventspils Rajons
Independence: 6 September 1991 (from
Soviet Union)
National holiday: Independence Day. 1 8
November(l918)
Constitution: newly elected Parliament in
1993 restored the 1933 constitution
Legal system: bused on civil law system
Suffrage; 1 8 years of age; universal
Executive branch:
chief of state: President Guntis ULMANIS
(since 7 July 1993): Saeima elected President
ULMANIS in the third round of balloting on 7
July 1993
head of government: Prime Minister Valdis
BIRKAVS (since 20 July 1993)
cabinet: Council of Ministers; appointed by
the Supreme Council
Legislative branch: unicameral
Parliament (Saeima): elections last held 5-6
June 1993 (next to be held NA June 1996);
results — percent of vote by party NA; seats —
( 1 00 total) LC 36. LNNK 1 5. Concord for
Latvia 1 3. LZS 12, Equal Rights 7, LKDS 6,
TUB 6, DCP 5
Judicial branch: Supreme Court
Political parties and leaders: Latvian Way
Union (LC), Valdis BIRKAVS; Latvian
Farmers Union (LZS), Alvars BERKIS;
Latvian National Independence Movement
(LNNK), Andrejs KRASTINS, Aristids
LAMBERGS, cochairmen: Concord for
Latvia, Janis JURKANS: Equal Rights, Sergejs
DIMANIS; Christian Democrat Union
(LKDS), Peteris CIMDINS, Andris
SAULITIS, Janis RUSKO; Fatherland and
Freedom (TUB), Maris GRINBLATS, Roberts
MILBERGS, Oigetts DZENTIS; Democratic
Center (DCP), IntsCALITIS; Popular Front of
Latvia (LTF), UIdis AUGSTKALNS
Member of: BIS. CBSS, CCC, CE (guest),
CSCE. EBRD. ECB, FAO, IBRD. ICAO, IDA,
IFC, ILO, IMF, IMO, INTELSAT
(nonsignatory user), INTERPOL, IOC, lOM
(observer). ITU. LORCS. NACC. UN,
UNCTAD, UNESCO, UNIDO. UPU, WHO.
WIPO, WMO
Diplomatic representation in US:
chief of mission: .Ambassador Ojars Eriks
KALNINS
chanceiy: 4325 1 7th Street NW, Washington.
DC2(X)11
telephone: (202) 726-821? and 8214
US diplomatic representation:
chief of mission: Ambassador Ints M. SILINS
embassy: Raina Boulevard 7, Riga 226050
mailing address: use embassy street address
telephone: 46-9-882-0046
FAX: 46-9-882-0047
Flag: two horizontal bands of maroon (top
and bottom), white (middle, narrower than
other two bands)','5d7123614bba0023de1db0122c2c1605c646a150fd79cdf65b8544ef6a92a7a6','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('489be44739374f5a238e27e54a5aeff2c4d4656b8c10a95cbba061487a46618c',1994,'LB','Lebanon','government',573,'Names;
amventional Ion/; form: Republic of Lebanon
conventional short form: Lebanon
local loiifi form: Al Jumhuriyah al Lubnaniyah
local short form: none
Digraph; LE
Type: republic
Capital: Beirut
Administrative divisions; 5 govemorutes
(muhafazal, singular — muhafazah); Al Biqu,
"Al Janub, Ash .Shamal, Bayrut. Jabal Lubnan
Independence; 22 November 1943 (from
i^eague of Nations mandate under French
administration)
National holiday: Independence Day, 22
November ( 1943)
Constitution: 23 May 1926, amended a
number of times
Legal system; mixture of Ottoman law, canon
law, Naptslconic code, and civil law; no
judicial review of legislative acts; has not
accepted compulsory ICJ jurisdiction
Suffrage: 2 1 years of age; compulsory for all
males; authorized for women at age 2 1 with
elementary education
Executive branch:
chief of state: President Ilyas HARAWI (since
24 November 1989); note — by custom, the
president is a Muronite Christian, the prime
minister is a Sunni Muslim, and the speaker of
the legislature is a Shi''a Muslim
head of government: Prime Minister Rafiq
HARIRI (since 22 October 1992)
cahinet: Cabinet; chosen by the president in
consultation with the members of the National
Assembly
Legislative branch: unicameral
National Assemhiy: (Arabic — Majlis
Alnuwab, French — Assemblee Nationale)
Lebanon''s first legislative election in 20 years
was held in the summer of 1992; the National
Assembly is composed of 1 28 deputies,
one-half Christi;in and one-half Muslim; its
mandate expires in 1996
Judicial branch: four Courts of Cassation
(three courts for civil and comtncrciul cases
and one court for criminal cases)
Political parties and leaders: political party
activity is organized along largely sectarian
lines; numerous political groupings exist,
consisting of individual political figures and
followers motivated by religious, clan, and
economic considerations
Member of: ABEDA. ACCT. AFESD. AL.
AMF, CCC, ESeWA, FAO, G-24. G-77.
IAEA. IBRD, ICAO. ICC. ICFTU. IDA. IDB.
IFAD, IFC. ILO. IMF. IMO. INTELSAT.
INTERPOL. IOC. ITU. LORCS. NAM. OIC.
PCA, UN. UNCTAD. UNESCO. UNHCR.
UNIDO, UNRWA. UPU. WFTU. WHO.
WIPO. WMO. WTO
Diplomatic representation In US:
chief of mission: Ambassador Riad
TABBARAH
chancerv: 2560 28th Street NW. Washington.
DC 2(KK)8
telephone: (202)939-6300
FAX; (202) 939-6324
ctmsulateis) general: Detroit, New York, and
Los Angeles
US diplomatic representation;
chief of mission: Ambassador Mark
HAMBLEY
mailing emhassv: Amelias, Beirut
address: P. O. Box 70-840. PSC 815. Box 2.
Beirut; FPO AE 098.36-0002
telephone: (96 1 1 4 1 7774 or 4 1 5802 through
415803. 4()22(X). 403300
MY; (961 1(1)407-1 12
Flag: three horizontal bands of red (lop).
white (double width), .and red with a green and
brown cedar tree centered in the white band
Names:
conventional long fomt: Syrian Arab Republic
conventional short form: Syria
Imal long form: Al Jumhuriyah al Ambiyuhas
Suriyah
liH ot short fitrm: Suriyah
fomter: United Arab Republic (with Egypt)
Digraph: SY
Type: republic under left wing military regime
since March 1963
Capital: Damascus
Administralivc divisions: 14 provinces
(muhafazat, singular— muhafazah); Al
Hasakah, Al Lodhiqiyah. Al (^naytirah. Ar
Raqqah, As Suwayda’, Dar''a, Dayr az Zawr.
Dimashq. Halab, Hamah, Hims. Idlib, Rif
Dimashq. Tartus
Independence: 17 April 1946 (from League
of Nations mandate under French
administration)
National holiday: National Day, 17 April
(1946)
Constitution: 13 March 1973
Legal system: bused on Islamic law and civil
law system: special religious courts; has not
accepted compulsory ICJ jurisdiction
Suffi«ge: 18 years of age; universal
Executive branch:
chief of state: President Hafiz al-ASAD (since
22 February 1971 see note); Vice Presidents
''Abd al-Halim ibn Said KHADDAM, Rif at al-
ASAD, and Muhammad Zuhayr
MASHARIQA (since II March 1984);
election last held 2 December 1991 (next to be
held December 1998); lesuli.s — Pivsidem
Hafiz al-ASAD was reelected for a fourth
seven-year term with 99.98% of the vote;
note — President ASAD seized power in the
November 1970 coup, assumed presideiititd
powers 22 February 1971. and was confinned
as president in the 12 March 1971 national
elections
head ofgovertiment: Prime Minister Mahmud
ZU’BI (since 1 November 1987); Deputy
Prime Minister Lt, Gen, Mustafa TALAS
(since 1 1 March 1984); Deputy Prime Minister
Salim YASIN (since NA IJecember 1981);
Deputy Prime Minister Rashid AKHTARINI
(since 4 July 1992)
cabinet: Council of Ministers; appointed by
the president
Legislative branch: unicameral
People''s Council (Majlis al-Chaab):
elections last held 22-23 May 1990 (next to be
held NA May 1994); results — Bu''th 53.6%.
ASU 3,2%, SCP3,2%. Arab Six''iulist Unionist
Movement 2.8%, ASP 2%. Denux''ratic
SiKiulist Union Party 1.6%, independents
33,6%; seats— (2.50 total) Ba’th 1.34. ASU 8.
SCP 8, Arab SiKiulist Unionist Movement 7.
ASP 5. DemiKratic SiK''ialist Union Party 4,
independents 84: note — the People’s Council
was expanded to 250 seats total prior to the
May 1 990 election
Judicial branch: Supreme Constitutional
Court. High Judicial (Council. Court of
Cassation, State Security Courts
Political parties and leaders: ruling party is
the Arab SiK''ialist Resutrcetionist (Ba''th)
Party; the Progressive National is dominated
by Ba''thists but includes inilependems and
members of the Syrian Arab Socialist Party
(ASP); Arab SiK''ialist Union (ASU): Syrian
Communist Party (SCP); Arab Socialist
Unionist Movement; and Democratic Socialist
Union Party
Other political or pressure groups: non-
Ba''th parties have little effective pirlitical
influence; Communist party ineffective;
conservative religious leaders; Muslim
Protherhood
Member of: ABEDA. AFESD, AL, AMF,
CAEU. CCC. ESeWA, FAO, G-24. G-77,
IAEA. IBRD, ICAO. ICC. IDA, IDB. IFAD,
IFC. ILO, IMF. IMO, INTELSAT.
INTERPOL. IOC. ISO. ITU. LORCS. NAM,
OAPEC, QIC. UN. UNCTAD. UNESCO.
UNIDO. UNRWA. UPU. WFTU. WHO.
WMO. WTO
Diplomatic representation in US:
chief of mission: Ambassador Wulid
MUALEM
chancerw 2215 Wyoming Avenue NW,
Washington. DC 20008
telephone: (202) 232-63 1 3
FAX: (202) 234-9548
US diplomatic representation:
chief of mission: Amba.ssador Christopher W.
S.ROSS
embassy: Abou Roumaneh, Al-Mansur Street
No. 2. Damascus
mttiling address: P. O. Box 29. Damascus
telephone: t%3] (1 1) 332-814. 332-315.
7 14- 108, .3.30-788
MJf.'' 1963] (1 1)247-9-38
Flag: three equal horizontal bunds of red
(top), white, and black with two small green
five-pointed stars in a horizontal line centered
in the white band; similar to the flag of Yemen,
which has a plain white bund and of Iraq, which
has three green stars (plus an Arabic
inscription) in a horizontal line centered in the
white band; also similar to the flag of Egypt,
which has u symbolic eagle centered in the
white band
Names:
conventional lonfifinm; Republic of','23c10234d9ef9850ae52c328df384f07f35a2aa00c2f98d8ffc7cff4bc94d423','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('284f3acde7780fecb15f62891cdb342747558734f6dbf660f72f028f27740774',1994,'ZA','South Africa','government',578,'Names:
conventional long form: Kingdom of Lesotho
conventional short form: Lesotho
former: Basutoland
Digraph: LT
Type: constitutional monarchy
Capital: Ma.seru
Administrative divisions; I Odistricts; Berea,
Butha-Buthe, Leribe, Mafeteng, Maseru,
Mohale''s Hoek, Mokhotlong. Qacha’s Nek,
Quthing. Thaba-Tseka
Independence: 4 October 1966 (from UK)
National holiday; Independence Day, 4
October (1966)
Constitution: 2 April 1993
Legal system: based on English common law
and Roman-Dutch law; judicial review of
legislative acts in High Court and Court of
Appeal; has not accepted compulsory ICJ
jurisdiction
Suffrage: 2 1 years of age; universal
Executive branch:
chief of state: King LETSIE III (since 12
November 1990)
head of government: Prime Minister Ntsu
229
Lesotho (continued)
MOKHEHLE (since 2 April 1993 )
cabinet; Cabinet
Legislative branch: bicameral Parliament
consisting of the Assembly or lower house
whose members are chosen by popular election
and the Senate or upper house whose members
consist of the 22 principal chiefs and 10 other
members appointed by the ruling party;
election held in March 1993 (first since 1971);
all 65 seats in the Assembly were won by the
BCP
Judicial branch: High Court, Court of
Appeal
P^itical parties and leaders; Basotho
National Party (BNP), Evaristus
SEKHON YANA; Basutholand Congress Party
(BCP), Ntsu MOKHEHLE; National
independent Party (NIP), A. C, MANYELI;
Marematlou Freedom Party (MFP). Vincent
MALEBO; United Democratic Party, Charles
MOFELI; Communist Party of Lesotho (CPL),
Jacob M. KENA
Member of: ACP. AfDB, C, CCC, ECA,
FAO, G-77, GATT, IBRD, ICAO, ICFTU,
IDA, IFAD, IFC, ILO, IMF, INTELSAT
(nonsignatory user), INTERPOL, IOC, ITU,
LORCS, NAM, OAU, SACU, SADC, UN,
UNCTAD, UNESCO, UNHCR, UNIDO.
UPU, WCL, WHO. WIPO, WMO. WTO
Diplomatic representation in US:
chief of mission; Ambassador Teboho
KlTLELl
chancery; 251 1 Massachusetts Avenue NW,
Washington. DC 20008
telephone; (202) 797-5533 through 5536
FAX; (202) 2.34-6815
US diplomatic representation:
chief of mission; (vacant): Charge d’ Affaires
Karl HOFMANN
embassy; address NA, Maseru
mailing address; P. O. Box 333, Maseru 100,
Names:
conventional long form: Republic of Namibia
conventional short form: Namibia
Digraph: WA
Type: republic
Capital: Windhoek
Administrative divisions: 1 3 di.stricts;
Erango, Hardap. Karas, Khomas, Kunene,
Liambezi. Ohanguena. Okarango, Oinaheke.
Omusat, Oshana, Oshikoto, Otjozondjupa
Independence; 21 March 1990 (from South
African mandate)
National holiday: Independence Day. 2 1
March (1990)
Constitution: ratified 9 February 1990;
effective 12 March 1990
Legal system: bused on Roman-Dutch law
and 1990 constitution
Suffirage: 1 8 years of age; universal
Executive branch:
chief of state and head {^government;
Pre.sident Sam NUJOMA (since 21 March
1990); election last held 16 February 1990
(next to be held March 1995); results — Sam
NUJOMA was elected president by the
Constituent Assembly (now the National
Assembly)
cabinet: Cabinet: appointed by the president
from the National A.ssembly
Legislative branch: bicameral legislature
Natiimal Council; elections last held 30
November-3 December 1992 (next to be held
by December 1998); seats — (26 total) SWAPO
19. DTA 6. UDF I
National Assembly; “lections last held on 7-1 1
November 1989 (next to he held by November
1994); results — percent of vote by party NA;
seat.s— (72 total) SWAPO 4 1 . DTA 2 1 . UDF 4.
ACN3. NNF 1, FCN l.NPF I
Judicial branch: Supreme Court
Political parlies and leaders: South West
Africa People’s Organization (SWAPO). Sam
NUJOMA; DTA of Namibia (formerly
Democratic Tumhalle Alliance) (DTA),
Mi.shake MUYONGO; United Democratic
Front (UDF), Justus GAROEB; Action
Christian National (ACN), Kosie
PRETORIUS; National Patriotic Front (NPF),
Moses KATJIUONOUA; Federal Convention
of Namibia (FCN), Hans DIERGAARDT:
Namibia National Front (NNF), Vekuii
RUKORO
Other political or pressure groups: NA
Member oft ACP, AfDB, C. CCC, ECA.
FAO. FLS. G-77, GATT. IAEA, IBRD, ICAO,
IFAD, IFC. ILO. IMF. INTELSAT
(nonsignatory user), INTERPOL, IOC, lOM
(observer). ITU. NAM, OAU. SACU, SADC,
UN, UNCTAD, UNESCO, UNHCR. UNIDO.
UPU, WCL, WFTU. WHO, WIPO. WMO
Diplomatic representation US:
chief of mission: Ambassador Tuliameni
KALOMOH
cluincery: 1605 New Hampshire Avenue NW.
Washington. DC 20(K)9
telephone: (202) 986-0540
FAX.- (202)986-0443
US diplomatic representation:
chief of mission: (vacant): Charge d'' Affaires
Howard F. JETER
embassy: Ausplan Building. 14 Lo.s.sen St.,
Windhoek
mailing address: P. O. Box 9890, Windhoek
9000
telephone: [264] (61) 221-601. 222-675. 222-
680
FAX; 12641(61)229-792
Flag: a large blue triangle with a yellow
sunburst fills the upper left section, and an
equal green triangle (.solid) fills the lower right
section; the triangles are separated by a red
stripe that is contrasted by two narrow white-
edge borders
Names:
conventional lonftfonn: Republic of South
Africa
conventional short form; South Africa
Abbreviation: RSA
Digraph: SF
Type: republic
Capital: Pretoria (administrative); Cape
Town (legislative); Bloemfontein (judicial)
Administrative divisions: 9 provinces;
Eastern Cape, Eastern Transvaal, Kwa Zulu/
Natal, Northern Cape, Northern Transvaal,
Northwest, Orange Free State, Pretoria-
Witwatersrand-Vereeniging, Western Cape
note: previously the administrative divisions
consisted of 4 provinces; Cape, Natal, Orange
Free State, Transvaal; there were 1 0 homelands
not recognized by the US — 4 independent
(Bophuthatswana. Ciskei, Transkei, Venda)
and 6 other (Gazankulu, Kangwane,
KwaNdebele, KwaZulu, Lebowa, QwaQwa)
Independence: 31 May 1910 (from UK)
National holidav: Republic Day, 3 1 May
(1910)
Constitution: 27 April 1994 (interim
constitution, replacing the constitution of 3
September 1984)
Legal system: based on Roman-Dutch law
and English common law; accepts compulsory
ICJ Jurisdiction, with reservations
Suffrage: 1 8 years of age; universal
Executive branch;
chief of state and head of government:
Executive President Nelson MANDELA
(since 10 May 1994); Deputy Executive
President Frederik W. DE KLERK (since 10
May 1994); Deputy Executive President Thabo
MBEKI (since 10 May 1994)
note: any political party that wins 20% or more
of the National Assembly votes in a general
election is entitled to name a Deputy Executive
President
cabinet: Cabinet appointed by the Executive
President
Legislative branch: bicameral
National Assembly; elections held 26-29 April
1994 (next to be held NA); results — ANC
62.6%. NP 20.4%, IFP 10.3%, FF 2.2%, DP
1.7%, PAC 1.2%. ACDP 0.5%. other 0.9%;
seats— (400 total) ANC 252. NP 82, IFP 43. FF
9, DP 7, PAC 5, ACDP 2
Senate; the Senate is composed of members
who are nominated by the nine pro icial
parliaments (which arc elected in parallel with
the National Assembly) and has special powers
to protect regional interests, including the right
to limited self-determination for ethnic
minorities; seats — (90 total) ANC 61, NP 17,
FF 4. IFP 5. DP 3
note: when the National Assembly meets in
joint session with the Senate to consider the
provisions of the Constitution, the combined
group is referred to as the Constitutional
Assembly
Judicial branch: Supreme Court
Political parties and leaders: African
National Congress (ANC), Cyril
RAMAPHOSA; National Party (NP), Frederik
W. DE KLERK, president; Inkatha Freedom
Pany (IFP), Mangosuthu BUTHELEZl,
president; Freedom Front (FF). Constand
VILJOEN, president; Democratic Party (DP);
Pan Africanist Congress (PAC), Clarence
MAKWETU. president; African Christian
Democratic Party (ACDP)
note; in addition to these seven parties which
won seats in the National Assembly, twelve
other parties won votes in the national elections
in April 1994
Other political or pressure groups: NA
Member of: BIS. CCC. EGA. GATT, IAEA,
IBRD, ICAO (suspended), ICC, IDA, IFC,
IMF, INTELSAT. IOC, ISO, ITU (suspended),
LORCS. SACU, UN. UNCTAD, WFTU,
WHO, WIPO, WMO (suspended). ZC
Diplomatic representation in US:
chief of mission; Ambassador Harry Heinz
SCHWARZ
chancery: 305 1 Massachusetts Avenue NW,
Washington, DC 20008
telephone; (202) 232-4400
consiilate(s) general: Beverly Hills
(California), Chicago, and New York
US diplomatic representation:
chief of mission: Ambassador Princeton N,
LYMAN
embassy: 877 Pretorius St.. Arcadia 0083
mailing address: P.O. Box 9536, Pretoria 0001
telephone: (271(12) 342-1048
FAX: (27] (12) 342-2244 or 2299
considate(s) general: Cape Town, Durban.
Johannesburg
Flag: two equal width horizontal bands of red
(top) and blue separated by a central green
band which splits into a horizontal Y. the arms
of which end at the comers of the hoist side,
embracing a black isoceles triangle from which
the arms are separated by narrow yellow bands;
the red and blue bands are separated from the
green band and its arms by narrow white stripes
note: prior to 26 April 1994 the flag was
actually four flags in one — three miniature
flags reproduced in the center of the white band
of the former flag of the Netherlands, which
has three equal horizontal bands of orange
(top), white, and blue; the miniature flags are a
vertically hanging flag of the old Orange Free
State with a horizontal flag of the UK adjoining
on the hoist side and a horizontal flag of the old
Transvaal Republic adjoining on the other side','efb3d17e5bc731aa0daee31ff6092cc5d774947b92a585fed38c89041f75bb7b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('894b8e007122c675e110de847bf7f871077b7bec945296db19cf1bc6f303100b',1994,'LS','Lesotho','government',579,'telephone; (266) 312-666
FAX; 1266] 310-116
Flag: divided diagonally from the lower hoist
side eorner; the upper half is white bearing the
brown silhouette of a large shield with crossed
spear and club; the lower half is a diagonal blue
band with a green triangle in the comer','4596f72a2b17e6ecf18f57b772259219dfbbdcabb57a630d151898d0e188e5ae','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb91ec8a0eea0f8ad8f2cbbaaada29c2ebb007037df7e5294672be204a5a37f8',1994,'LR','Liberia','government',584,'Names:
conventional long form: Republic of Liberia
conventional short form: Liberia
Digraph: LI
Type: republic
Capital; Monrovia
Administrative divisions; 1 3 counties:
Bomi, Bong, Grand Bassa, Cape Mount, Grand
Gedeh, Grand Kru, Lofa, Margibi, Maryland.
Montseaado, Nimba. River Cess, Sinoe
Independence; 26 July 1847
National holiday: Independence Day, 26 July
(1847)
Constitution; 6 January 1986
Legal system: dual system of .statutory law
based on Anglo-American common law for the
modern sector and customary law based on
unwritten tribal practices for indigenous sector
Suffrage: 18 years of age; universal
Executive branch:
chief of state and head of government:
Chairman of the Council of State David
KPOMAKPOR (since March 1994); election
last held on 1 5 October 1 985 (next scheduled to
be held September 1994); results — Gen. Dr.
Samuel Kanyon DOE (NDPL) 50.9%, Jackson
DOE (LAP) 26.4%, other 22.7%; note —
President Doe was killed by rebel forces on 9
September 1990
cabinet: Cabinet; selected by the leaders of the
major factions in the civil war
note: a transitional coalition government was
formed as part of a July 1993 Cotonou Peace
Treaty negotiated under UN auspices by the
leaders of the major factions in the civil war;
elections now scheduled fur September 1994
Legislative branch: unicameral Transitional
Legislative Assembly, the members of which
are appointed by the leaders of the major
factions in the civil war
note: the fonner bicameral legislature no
longer exists and there is no assurance that it
will ever be reconstituted
Judicial branch: Supreme Court
Political parties and leaders: National
Democratic Party of Liberia (NDPL),
Augustus CAINE, chairman: Liberian A ^t*on
Party (LAP). Emmanuel KOROMAH,
chairman; l.''.-''ity Party (UP). Jn.;eph KOFA,
chairma.;: Uniied People''s .''any (UPP),
Gabriel Bacces MATTHEW:), chairman;
National P.itikitic Party (h!PP), Charles
TAYLOR, chairman; Liberian Peoples Party
(LPP), Dusty WOLOKOLLIE, chairman
Member of: ACP, AfDB, CCC, ECA,
ECOWAS, FAO, G-77. IAEA. IBRD. ICAO.
ICFTU, IDA. IFAD, IFC, ILO, IMF. IMO,
INMARSAT, INTELSAT (nonsignatory user),
INTERPOL. IOC, ITU. LORCS, NAM, OAU,
UN. UNCTAD, UNESCO, UNIDO, UPU.
WCL, WHO. WlPO, WMO
Diplomatic representation in US;
chief of mission: (vacant); Charge d'' Affaires
Konah K. BLACKETT
chancem: 5201 16th Street NW. Washitigton.
DC 2001 1
telephone: (202) 723-0437 through 0440
consulateis) general: New York
US diplomatic representation:
chief of mission: (vacant): Charge d’ Affaires
William P. TWADDELL
embassy: 1 1 1 United Nations Drive, Monrovia
mailing address: P. O. Box 100098, Mamba
Point, Monrovia, or APO AE 09813
telephone: [231] 222991 through 222994
FAX: [231] 22.3710
Flag: 1 1 equal horizontal stripes of red (top
and bottom) alternating with white; there is a
while five-pointed star on a blue square in the
upper hoist-side corner; the design was based
on the US Hag
231
Liberia (continued)
Highways:
total; 10,087 km
paved; 603 km
unpaved; gravel 5,171 km (includes 2323km
of private roads of rubber and timber firms,
open to the public); earth 4,3 1 3 km
Ports: Monrovia, Buchanan, Greenville,
Harper (or Cape Palmas)
Merchant marine: 1 ,595 ships ( 1 ,000 GRT
or over) totaling 56,923,236 GRT/97, 692,3 16
DWT, passenger 32, shoit-sea passenger 2,
cargo 1 26, refrigerated cargo 61 ,
roll-on/roll-off cargo 19. vehicle carrier 59,
container 1 12, barge carrier 3. oil tanker 468,
chemical 122, combination ore/oil 64,
liquefied gas 67, specialized tanker 7, bulk
423. combination bulk 30
note; a flag of convenience registry; all ships
are foreign owned; the top 4 owning flags are
US 14%, Japan 13%, Norway 10%, and Hong
Kong 8%
Airports:
total; 59
usable; 41
with permanent-surface runways; 2
with runways over 3.659 m; 0
with runways 2,440-3,659 m; 1
with runways 1,220-2,439 m; 4
Telecommunications: telephone and
telegraph service via radio relay network; main
center is Monrovia; broadcast stations — 3 AM,
4 FM. 5 TV; 1 Atlantic Ocean INTELSAT
earth station; most telecommunications
services inoperable due to insurgency
movement
Defense Forces
Branches: the ultimate structure of the
Liberian military force will depend on who is
the victor in the ongoing civil war
Manpower availability: males age 15-49
707,927; fit for military service 377,950
DelanM expenditures: exchange rate
conversion — $NA, NA% of GDP
232
Names:
conventional long form: Republic of Sierra
Leone
conventional short form: Sierra Leone
Digraph: SL
Type: military government
Capital; Freetown
Administrative divisions: 3 provinces and I
area*; Eastern. Northern. Southern. Western*
Independence; 27 April 1961 (from UK)
National holiday; Republic Day, 27 April
(1961)
Constitution: I October 1991; suspended
following 19 April 1992 coup
Legal system: based on English law and
customary laws indigenous to local tribes; has
not accepted compulsory ICJ jurisdiction
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state and head of government:
Chairman of the Supreme Council of State
Capt. Valentine E. M. STRASSER (since 29
April 1992)
cabinet; Council of Secretaries; responsible to
the NPRC
Legislative branch: unicameral Hou.se of
Representatives (suspended after coup of 29
April 1992); Chairman STRASSER promises
multi-party elections sometime in 1995
Judicial branch: Supreme Court (suspended
after coup of 29 April 1992)
Political parties and leaders: status of
existing political parties is unknown following
29 April 1992 coup
Member of: ACP, AfDB. C. CCC. ECA,
ECOWAS, FAO, G-77, GATT, IAEA, IBRD,
ICAO, ICFTU, IDA. IDB, IFAD, IFC, ILO,
IMF, IMO, INTELSAT (nonsignatory user).
INTERPOL, IOC, ITU, LORCS. NAM, OAU,
OIC, UN, UNCTAD, UNESCO, UNIDO,
UNOMIG, UPU, WCL. WHO. WIPO. WMO,
WTO
Diplomatic representation in US:
chief of mission: Ambassador Thomas Kahota
KARGBO
chancerv: 1701 19th Street NW, Wasihington,
DC 20009
telephone: (202) 939-9261
US diplomatic representation:
chief of mission: Amba.ssador Lauralee M.
PETERS
embassy; Walpole and Siaka Stevens Street,
Freetown
maiiing address: u.se embassy street address
telephone: [232] (22) 226-481
MX.- 12.32] (22)225-471
Flag: three equal horizontal bands of light
green (top), white, and light blue','124df10740b9696ee5403e144b14e9885a8817f09659dbf894beb6a58aba01cc','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94bcd7b9a4a6eedb81a8339fbdc916bbf48daf093d8a19aaf9141fa297c3d052',1994,'LY','Libya','government',590,'Names:
conventional long fonn: Stx.''ialist People''s
Libyan Arab Jamahiriya
conventional short form: Libya
local long form; Ai Jumahiriyuh al Arabiyuh al
Libiyah ash Shabiyah al Ishirakiyah
local short fonn: none
Digraph: LY
Type: Jamahiriya (a state of the masses) in
theory, governed by the populace through local
councils: in fact, a military dictatorship
Capital: Tripoli
Administrative divisions; 25 municipalities
(baladiyah, singular — baladiyat); Ajdabiya. Al
''Aziziyah. Al Fatih. Al Jabal al Akhdar, Al
Jufrah. Al Khums, Al Kufrah. An Nuqat al
Khams, Ash Shati'', Awbari, Az Zawiyah,
Banghazi, Damah. Ghadamis, Gharyan,
Misratah. Murzuq, Sabha, Sawfajjin, Suit,
Tarabulus, Tarhunah, Tubruq, Yafran, Zlitan
Independence; 24 December 1951 (from
Italy)
National holiday; Revolution Day, I
September ( 1 969)
Constitution: 1 1 December 1969, amended 2
March 1977
Legal system: based on Italian civil law
system and Islamic law: separate religious
courts; no constitutional provision for judicial
review of legislative acts; has not accepted
compulsory ICJ jurisdiction
Suffrage: 1 8 years of age; universal and
compulsory
Executive branch;
chief of state: Revolutionary Leader Col,
Mu''ammar Abu Minyaral-QADHAFI (since I
September 1969)
head of government: Chairman of the General
People''s Committee (Premier) Abd al Majid
al-Qa''ud (since 29 January 1994)
cabinet: General People''s Committee;
established by the General People''s Congress
note: national elections are indirect through a
hierarchy of peoples'' committees
Legislative branch: unicameral
General People ''s Congress: national elections
are indirect through a hierarchy of peoples''
committees
Judicial branch; Supreme Court
Political parties and leaders: none
Other political or pressure groups: various
Arab nationalist movements with almost
negligible memberships may be functioning
clandestinely, as well as some Islamic elements
Member of: ABEDA. AfDB. AFESD, AL.
AMF, AMU, CAEU. CCC, EC A, FAO. G-77.
IAEA, IBRD. ICAO. IDA. IDB, IFAD, IFC,
ILO. IMF. IMG. INTELSAT. INTERPOL.
IOC, ISO. ITU, LORCS. NAM. OAPEC,
OaU, OIC, OPEC, UN, UNCTAD, UNESCO.
UNIDO. UPU, WHO. WIPO, WMO, WTO
Diplomatic representation in US: none
US diplomatic representation: none
Flag: plain green; green is the traditional color
of Islam (the state religion)
Names:
conventional long form: Republic of Tunisia
conventional short fomt: Tunisia
ItH-al lotigfimn: Al Jumhuriyah at Tunisiyah
l<H-al .short form; Tunis
Digraph: TS
Type: republic
Capital: Tunis
Administrative divisions; 23 govemorates;
Beja, Ben Arous, Bizerte. Gabes. Gafsa.
Jendouba, Kairouan, Kasserine, Kebili.
L''Ariana, Le Kef, Mohdia, Medenine,
Monustir, Nabeul. Sfax, Sidi Bou Zid. Siliana,
Sousse. Tataouine, Tozeur, Tunis, Zaghouan
Independence: 20 March 1 956 ( from France)
National holiday: National Day, 20 March
(1956)
Constitttlion: I June 1959; amended 12 July
1988
Legal system: based on French civil law
system and Islamic law; some judicial review
of legislative acts in the Suptente Court in joint
session
Sullhige: 20 years of age; universal
Executive branch:
chief of Slate: President Gen. Zine el Abidine
BEN ALI (since 7 November 1987); election
Tunisia {cominued)
last held 20 March 1994 (next to be held NA);
results — Gen. Zine el Abidine BEN ALl was
reelected without opposition
head of government; Prime Minister Named
KAROUI (since 26 September 1989)
cahinel: Council of Ministers; appointed by
the president
Legislative branch: unicameral
Chamber of Deputies (Majlis al-Nuwaabi;
elections last held 2 April 1 989 (next to be held
NA March 1994); results — RCD 80,7%,
iiidependents/Islamisis 1 1%, MDS 3.2%,
other 2,4%: seats — (141 tc;al) RCD 141
Judicial branch: Court of Cassation (Cour de
Cassation)
Political parties and leaders: Constitutional
Demtx:ratic Rally Party (RCD), President BEN
ALl (official luling party); Movement of
Democratic Socialists (MDS), Mohammed
MOUAADA; five other political parties are
legal, including the Communist Party
Other political or pre$.sure groups: the
Islamic fundamenta''ist party. An Nahda
(Rebirth), is outlawed
Member of: ABEDA, ACCT, AtDB,
AFESD, AL, AMF, AMU, CCC, ECA, FAO,
0-77, GATT, IAEA, IBRD. ICAO, ICC,
ICFTU, IDA, IDB. IFAD. IFC, ILO, IMF,
IMO, INMARSAT, INTELSAT. INTERPOL.
IOC, ISO, ITU, LORCS, MINURSO. NAM,
OAPEC (withdrew from active membership in
1986). OAS (observer), OAU, OIC, UN,
UNCTAD. UNESCO. UNHCR. UNIDO,
UNOSOM. UNPROFOR. UNTAC. UPU,
WHO. WIPO. WMO, WTO
Diplomatic representation in US:
chief of mission: Ambassador Ismail KHALIL
chancerv: 1515 Massachusetts Avenue NW,
Washington, DC 20005
telephone: (202) 862-1850
US diplomatic representation:
chief of mission: Ambassador John T.
McCarthy
embassy: 144 /''.venue de la Liberte, 1(X)2
Tunis-Belvedere
mailing address: use embassy street address
telephone: |2I6| ( I ) 782-.566
MX.- 1216|( 1)789-719
Flag: red with a white disk in the center
bearing a red crescent nearly encircling a red
five-pointed star; the crescent and star are
traditional symbols of Islam
Names:
conventional long form: Republic of Turkey
conventional short form: Turkey
local long form: Turkiye Cumhuriyeti
local short form: Turkiye
Digraph: TU
Type: republican parliamentary democracy
Capital: Ankara
Administrative divisions: 73 provinces
(iller. singular — il); Adana. Adiyaman, Afyon.
Agri. Aksaray. Amasya. Ankara. Antalya.
Artvin, Aydin, Balikesir, Batman, Bayburt,
Bilecik, Bingol, Bitlis, Bolu, Burdur, Bursa,
Canakkale, Cankiri, Corum, Denizii,
Diyarbakir, Edime, Elazig, Erzincan, Erzurum,
Eskisehir, Gazi Antep, Giresun, Gumushane,
Hakkari, Hatay, Icel, Isparta, Istanbul, Izmir,
Kahraman Maras, Karaman, Kars, Kastamonu,
Kayseri, Kirikkale, Kirklareli, Kirsehir,
Kocaeli, Konya, Kutahya, Malatya, Manisa,
Mardin, Mugla, Mus, Nevsehir, Nigde, Ordu,
Rize, Sakarya, Samsun, Sanli Urfa, Siiit,
Sinop, Simak, Sivas, Tekirdag, Tokat,
Trabzon, Tunceli, Usak, Van, Yozgat,
Zonguldak
Independence: 29 October 1923 (successor
state to the Ottoman Empire)
National holiday: Anniversary of the
Declaration of the Republic, 29 October ( 1 923)
Constitution: 7 November 1982
Legal system: derived from various
continental legal systems; accepts compulsory
ICJ jurisdiction, with reservations
Suffrage: 21 years of age; universal
Executive branch:
chief of state: President Suleyman DEMIREL
(since 16 May 1993)
head of government: Prime Minister Tansu
CILLER (sinee 5 July 1993)
National Security Council: advisory body to
the President and the Cabinet
cabinet: Council of Ministers; appointed by
the president on nomination of the prime
minister
Legislative branch: unicameral
Turkish Grand National Assembly: (Turkiye
Buyuk Millet Meclisi) elections last held 20
October 1991 (next to be held NA October
1996); results— DYP 27.03%. ANAP 24.01%,
SHP 20.75%. RP 16.88%, DSP 10.75%, SBP
0.44%, independent 0. 14%; seats — (450 total)
DYP 1 78. AN AP 1 1 5, SHP 86. RP 40. MCP
19. DSP 7. other 5
note: seats held by various parties are subject
to change due to defections, creation of new
parties, and ouster or death of sitting deputies;
present seats by party are as follows; DYP 1 78,
AN AP 1 0 1 . SHP 55, RP 39. CHP 1 8. MHP 1 3,
DEP 13, BBP 7, DSP 3, YP 3, MP 2,
independents 10, vacant 8
Judicial branch: Court of Cassation
Political parties and leaders: Correct Way
Party (DYP), Tansu CILLER; Motherland
Party (ANAP). Mesut YILMAZ; Social
Democratic Populist Party (SHP), Murat
KARAYALCIN; Welfare Party (RP).
Necmettin ERBAKAN; Democratic Left Party
(DSP). Bulent ECEVIT; Nationalist Action
Party (MHP), Alparslan TURKES; Democracy
Party (DEP), Hatip DICLE; Socialist Unity
Party (SBP). Sadun AREN; New Party (YP),
Yusuf Bozkurt OZAL; Republican People''s
Party (CHP), Deniz BAYKAL; Labor Party
(IP). Dogu PERINCEK; National Party (MP),
Aykut EDIBALI; Democrat Party (DP), Aydin
MENDERES; Grand Unity Party (BBP).
Muhsin YAZICIOOLU; Rebirth Party (YDP),
401
Turkey (continued)
Hasan Celal GUZEL; People’s Democracy
Party (HADEP), Murat BOZLAK; Main Path
Party (ANAYOL), Gurcan BASER
Other political or pressure groups:
Turkish Confederation of Labor (TURK-IS),
Bayram MERAL
Member of: AsDB, BIS, BSEC, CCC, CE,
CERN (observer), COCOM, CSCE, EBRD,
ECE, ECO, FAO, GATT. IAEA, IBRD, ICAO,
ICC, ICFTU, IDA. IDB, lEA, IFAD, IFC, ILO,
IMF, IMO, INMARSAT. INTELSAT,
INTERPOL, IOC, lOM (observer), ISO, ITU.
LORCS, NACC, NATO, NEA, OECD, OIC,
PCA, UN, UNCTAD, UNESCO, UNHCR,
UNIDO, UNIKOM, UNOSOM, UNRWA.
UPU, WEU (associate), WFTU, WHO, WIPO,
WMO, WTO
Diplomatic representation in US:
chief of mission: Ambassador Nuzhet
KANDEMIR
chancery: 1714 Massachusetts Avenue NW,
Washington, DC 20036
telephone: (202) 659-8200
consulateis) general: Chicago, Houston, Los
Angeles, and New YoiK
US diplomatic representation:
chief of mission: Ambassador Richard C.
BARKLEY
embassy: 1 10 Ataturk Boulevard, Ankara
mailing address: PSC 93, Box 5000, Ankara,
or APOAE 09823
telephone: [90] (312) 468-61 10 through 6128
FAX: [90] (312)467-0019
"onsulatelsj general: Istanbul
consulateis): Adana
Flag: red with a vertical white crescent (the
closed portion is toward the hoist side) and
white five-pointed star centered just outside the
crescent opening','d688bfb376bd55cc2c60c81da8911c8222637263ab9b22a37ef7d09dcd7cecd3','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6dccf38b1a08c75eef0b409e6046cf2b1945e1c476597035f24a8d4b7762b79',1994,'LI','Liechtenstein','government',596,'Nam«:i''>:
l onventional lon.^fonn; Principality of
amventional short form; Liechtenstein
Imal long form; Fursientum Liechtenstein
loeal short form; Liechtenstein
Digraph; LS
Type: hereditary constitutional monarchy
Capital: Vaduz
Administrative divisions: 1 1 communes
(gemcinden. singular — gemeinde); Balzcrs,
Eschen. Gamprin, Mauren, Planken. Ruggell.
Schaan, Schellenberg, friesen, Triesenberg.
Vaduz
Independence: 23 January 1719 (Imperial
Principality of Liechtenstein established)
National holiday: Assumption Day, 15
August
Constitution: 5 October 1921
Legal system: kK''al civil and penal codes;
accepts compulsor) ICJ jurisdiction, with
reservations
.Suffrage: 1 8 years of age: universal
Executive branch:
ehief of state; Prince Hans ADAM It (since 13
November 1989; assumed executive powers 26
August 1984); Heir Apparent Prince ALOIS
von und zu Liechtenstein (bi>m 1 1 June 1968)
heail of government; Mario ERICK (since 15
December 1993); Deputy Head of Government
Dr. Thomas BDECHEL (since 15 December
1993)
cabinet; Cabinet: elected by the Diet,
confirmed by the sovereign
l^islatlvc branch: unicameral
Diet (Landtagt; elections last held on 24
October 1993 (next to be held by March 1997);
results— VIJ 50. 1 %. EBP 4 1 .3%. EL 8.5%;
seats— (25 total) VU 13. EBP 1 1. EL I
Judicial branch: Supreme Court (Oherster
Gerichtshof) fur criminal ca.scs. SuperiorCourt
(Obergcricht) for civil cases
Political parties and leaders: Fatherland
Union (VU). Dr. Otto HASLBR; Pixrgressive
Citizens’ Party (EBP), Emanuel VOGT; Free
Electoral List (FL)
Member of; CE. CSCE. EBRD. ECE, EFTA,
IAEA. INTELSAT. INTERPOL. IOC. ITU.
LORCS, UN. UNCTAD. UPU. WCL. WIPO
Diplomatic representation In US; in routine
diplomatic matters, Liechtenstein is
represented in the US by the Swiss Embassy
US dipiomatic representation: the US has
no diplomatic or consular mission in
Liechtenstein, but the US Consul General at
Zurich (Svvit/eiiand) has consular
accreditation at Vaduz
Flag: two equal horizontal bunds of blue (top)
und red with u gold crown tm the hoist side of
the blue band','10ae2b41cf83bf211fc6701b72cfa540ea088a5b176891af5b2663122999a984','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e4223c24866e28058175be8a7068f6dd33c5b12f2ad4071e4c440ae68630fcd',1994,'LT','Lithuania','government',602,'Names:
conventional Iona form: Republic of Lithuania
conventional short form: Lithuania
local Iona form: Lietuvos Respublika
local .short form: Lietuva
former: Lithuanian .Soviet Socialist Repulilic
Digraph: l.H
Type: republic
Capital; Vilnius
Administrative divisions; 44 regions
(rajonai, singular — rajonas) and 1 1
municipalities*: Akinenes Rujonus, Alytaus
Rajonas. Alytus*. Anyksciu Rajonas.
Birsionas*. Bir/u Rajonas. Driiskininkai*.
Ignalinos Rajonas. Jonavos Rajonas. Joniskio
Rajonas. Jurharko Rajonas. Kaisiadoriu
Rajonas, Marijampoles Rajonas. Kaunas*.
Kauno Rajonas. Keduiniu Rajonas. Kelmes
Rajonas. Klaipeda*. Klaipcdos Rajonas,
Kretingos Ragonas. Kupiskio Rujonus. I.a/.ili ju
Rajonas. Marijampole*. Mu/.cikiu Ragonas.
Moletu Rajonas. Nerjnga* Pakruojo Rajonas,
Palanga*. Paneve/io Rajonas. Paneve/.ys*.
Pasvallo Rajonas. Plunges Rajonas. Prienu
Rajonas. Radviliskio Rajonas. Raseiniu
Rajonas. Rokiskio Rujonus. Sakiu Rajonas.
.Sulcininky Rajonas. .Siuuliai*. Siuulju Rajonas.
Silalcs Rajonas, .Siltiies Rajonas. Sirvinty
Rajonas. Skuodo Rujonus. .Svcncioniu
Rajonas, Taurages Rajonas. Tclsiu Rajonas.
Traky Rajonas. Likmerges Rajonas, Utenos
Rajonas, Varenos Rajonas. Vjikaviskio
Rajonas, Vilniaus Rajonas. Vilnius*. Zarasu
Rajonas
Independence: 6 September 1991 (from
Soviet Union)
National holiday: Independence Day. 16
February (1918)
Constitution: adopted 25 October 1992
Legal system: based on civil law system; no
judicial review of legislative acts
Suffrage: 1 8 years of age; universal
Executive branch:
chhf of state: President Algirdus Mykolas
BRAZAUSKAS (since 25 November 1992;
elected acting president by Parliament 25
November 1992 and elected by direct vote 15
February 1993); election last held 14 February
1993 (next to be held NA 1997); results —
Algirdas BRAZAUSKAS was elected; note —
on 25 November 1992 BRAZAUSKAS was
elected chairman of Parliament and. as such,
acting president of the Republic; he was
confirmed in office by direct balloting 15
February 1993
head of aovernment: Premier Adolfas
SLEZEVICIUS (.since 10 March 199.3)
cahinei: Council of Ministers; appointed by
the president on the nomination of the prime
minister
Legislative branch: unicameral
Seimas iparUament): elections lust held 26
October and 25 November 1992 (next to be
held NA): results — LDDP 519} ; .veals — ( 141
total) LDDP 73, Conservative Parly .50. LKDP
17. LTS 8. Farmers'' Union 4. LLS 4, Center
Union 2. others 3
Judicial branch: Supreme Coun, Court of
Appeals
Political parties and leaders: Christian
Democratic Party (LKDP). Povilas
KATILIUS, chairman; Democratic Labor
Party of Lithuania (LDDP), Adolfas
SLEZEVICIUS. chairman; Lithuanian
Nationalist Union (LTS). Rimantas
SMETONA, chairman; Liihuunian Social
Democratic Party (LSDP), Aloy/as
SAKAl.AS. chairman; Farmers'' Union. Jonas
CIULEVICIUS, chairman; Center Union.
Romualdas OZOLAS, chairman; Conservative
Party. Vytautas LANDSBERCdS. chairman;
I.iihicmian Polish Union (LI.S). Rytardas
MACIKIANEC. chairman
Other political or pressure groups;
Homeland Union: Lithuanian Future Forum:
Farmers Unitm
Member of: BIS, CBSS, CCC. Ci:. CSCE.
EBRD. F;CF;. fad. IBRD. ICAO. ILO. IMF.
IN TIiLSAT (nonsignalorv user), INTERPOL,
IOC, ISO (correspondent). rflJ. LORCS.
NACC. UN. UNCTAD. UNE.SCO. UNIDO.
UPU, WHO. WIPO. WMO
Diplomatic representation in IIS:
chief of mission: Ambassador Allonsas
EIDINTAS
chain cr\\: 2622 16th Street NW, Washinglon.
DC 2()()()9
telephone: (202) 2.54-5860, 2639
FAX: (202) 328-0466
consulate''s) general: New York
US diplomatic representation:
chief of mission: Ambassador Darryl N.
JOHNSON
embassy: Akmenu 6, Vilnius 232600
mailing address: APO AE 09723
telephone: 370-2-223-031
FAX: 370-2-222-779
?lag: three equal horizontal bands of yellow
(top), green, and red','b8bfc0fbf53e8a4104594112094bda7bb1c9f2a597b1ac9e576025474c757d56','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd5d98753bc05692dd31906aa1d47578adbc451c7ad8efa0de9421281f32c38d',1994,'LU','Luxembourg','government',607,'Names:
conventional long form: Grand Duchy of
conventional short form: Luxembourg
local long form; Grand-Duche de
local short form: Luxembourg
Digraph: LI.''
Type: constitutional monarchy
Capital: Luxembourg
Administrative divisions: 3 districts;
Diekirch. Orevenmacher, Luxembourg
Independence; 1839
National holiday: National Day. 23 June
(1921) (public celebration of the Grand Duke''s
birthday)
Constitution: 17 October 1868, occasional
revisions
Legal system: based on civil law system;
accepts compulsory ICJ jurisdiction
Suffrage: 1 8 years of age; universal and
compulsory
Executive branch:
chief of state: Grand Duke JEAN (since 12
November 1964); Heir Apparent Prince
HENRI (son of Grand Duke Jean, bom 16
April 1955)
head of government: Prime Minister Jacques
SANTER (since 21 July 1984); Vice Prime
MinisterJacquesF. POOS (since 21 July 1984)
cabinet: Council of Ministers; appoint^ by
the sovereign
Legislative branch: unicameral
Chamber of Deputies ( Chambre des Deputes );
elections last held on 18 June 1989 (next to be
held by June 1994); results — CSV 31.7%,
LSAP 27.2%, DP 16.2%, Greens 8.4%, PAC
7.3%, KPL 5. 1 %, other 4. 1 %; seats — (60 total)
CSV 22. LSAP 18, DP 1 1, Greens 4. PAC 4,
KPL I
note: the Council of State (Conseil d’Etat) is an
advisory body whose views are considered by
the Chamber of Deputies
Judicial branch: Superior Court of Justice
(Cour Superieure de Justice)
Political parties and leaders: Christian
Social Party (CSV). Jacques SANTER;
Socialist Workers Party (LSAP), Jacques
POOS; Liberal (DP), Colette FLESCH;
Communist (KPL). Andre HOFFMANN;
Green Alternative (GAP), Jean HUSS
Other political or pressure groups: group
of steel companies representing iron and steel
industry: Centrale Paysanne representing
agricultural producers; Christian and Socialist
labor unions; Federation of Industrialists;
Anisans and Shopkeepers Federation
Member of: ACCT, Australia Group.
Benelux. CCC. CE. COCOM. CSCE. EBRD,
EC, ECE. EIB. FAO, GATT, IAEA, IBRD.
ICAO, ICC. ICFTU. IDA, lEA, IFAD, IFC.
ILO, IMF. IMO, INTELSAT. INTERPOL.
IOC, lOM, ITU. LORCS. MTCR, NACC,
NATO. NBA. NSG. OECD, PCA, UN,
UNCTAD. UNESCO. UNIDO. UNPROFOR.
UPU. WCL. WEU, WHO, WIPO, WMO, ZC
Diplomatic representation in US:
chief of mission: Ambassador Alphonse
BERNS
chancery: 22{X) Massachusetts Avenue NW,
Washington. DC 2(XX)8
telephone: (202) 265-4171
FAX: (202) 328-8270
consulatels) general: New York and San
Francisco
US diplomatic representation:
chief of mission: Ambassador Edward M.
ROWELL
embassy: 22 Boulevard Emmanuel-Servais,
2535 Luxembourg City
mailing address: PSC 1 1 . Luxembourg City:
APOAE09I.32-.5380
telephone: |352) 460123
FAX: 1.352)461401
Flag: three equal horizontal bunds of red
(top), white, and light blue; similar to the flag
of the Netherlands, which uses a darker blue
and is shorter; design was based on the flag of','c3e4c68ace110d27987ae95c7fca25b0dc118b192c9045a101d87d0e571d6aa4','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7cb029ee432017e6e96345173b510cdef5c204fc98663f9c32b92d8c99f38e1a',1994,'MW','Malawi','government',613,'Names:
conventional long form: Republic of Malawi
conventional short form: Malawi
former: Nyasaland
Digraph: MI
Type: multiparty democracy following a
referendum on 14 June 1993; formerly a
one-party republic
Capital: Lilongwe
Administrative divisions; 24 districts:
Blantyre, Chikwawa, Chiradzulu. Chitipa,
Dedza, Dowa, Karonga, Kasungu, Lilongwe,
Machinga (Kasupe), Mangochi, Mchinji,
Mulanje, Mwanza. Mzimba, Ntcheu. Nkhata
Bay, Nkhotakota, Nsanje, Ntchisi, Rumphi.
Salima, Thyolo, Zomba
Independence: 6 July 1964 (from UK)
National holiday: Independence Day. 6 July
(1964)
Constitution: 6 July 1966; republished as
amended January 1974
Legal system; based on English common law
and customary law; judicial review of
legislative acts in the Supreme Court of
Appeal; has not accepted compulsory ICJ
jurisdiction
Suffrage: 21 years of age; universal
Executive branch:
chief of state and head of government:
President Dr. Hastings Kamuzu BANDA
(since 6 July 1966); note — President BANDA
sworn in as President for Life on 6 July 1971 ;
rescinded by parliament in November 1993;
elections to be held May 1994
cabinet: Cabinet: named by the president
Legislative branch: unicameral
National Assembly: elections last held 26-27
June 1987 (next to be held by June 1997);
seats — (141 total, 136 elected) MCP 141
Judicial branch: High Court, Supreme Court
of Appeal
Political parties and leaders:
ruling party: Malawi Congress Party (MCP),
Gwanda CHAKUAMBA Phiri, secretary
general (top party position)
opposition groups: Alliance for Democracy
(Aford), Chakufwa CHIHANA; United
Democratic Front (UDF), Bakili MULUZl;
Socialist League of Malawi (Lesoma), Kapote
MWAKUSULA, secretary general; Malawi
Democratic Union (MDU), Harry
BWANAUSI; Congress for the Second
Republic (CSR). Kanyama CHIUME; Malawi
Socialist Labor Party (MSLP). Stanford
SAMBANEMANJA
Member of: ACP, AfDB, C, CCC, ECA.
FAO, G-77, GATT, IBRD, ICAO, ICFTU,
IDA, IFAD, IFC, ILO, IMF, IMO,
INTELSAT, INTERPOL, IOC, ISO
(correspondent), ITU, LORCS, NAM, OAU,
SADC, UN, UNCTAD, UNESCO, UNIDO,
UPU, WHO, WIPO, WMO, WTO
Diplomatic representation in US:
chief of mission: Ambassador Robert B.
MBAYA
chancery: 2408 Massachusetts Avenue NW,
Washington. DC 20008
telephone: (202) 797-1007
US diplomatic representation:
chief of mission: Ambassador Michael T. F.
PISTOR
embassy: address NA, in new capital city
development area in Lilongwe
mailing address: P. O. Box 30016, Lilongwe
3, Malawi
telephone: 1265] 783-166
FAX: 1265] 780-471
Flag: three equal horizontal bands of black
(top), red. and green with a radiant, rising, red
sun centered in the black band; similar to the
flag of Afghanistan, which is longer and has
the national coat of arms superimposed on the
hoist side of the black and red bands
243
Malawi (continued)','4a97c25a146aaf46db15df79e5875c47d86e6671832b82a7281a414616dd3dcd','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca162bb4a38b4036614a502313c1531cec9528cc08920dcc7216d265c8bb66fc',1994,'MX','Mexico','government',621,'Names:
conventional long form: none
conventional short form: Malaysia
former: Malayan Union
Digraph: MY
Type: constitutional monarchy
note: Federation of Malaysia formed 9 July
1963; nominally headed by the paramount
ruler (king) and a bicameral Parliament:
Peninsular Malaysian states — hereditary rulers
in all but Melaka, where governors are
appointed by
Malaysian l^lau Pinang Government; piowers
of state governments are limited by federal
Constitution; Sabah — self-governing state,
holds 20 seats in House of Representatives,
with foreign affairs, defense, internal security,
and other powers delegated to federal
government: Sarawak — self-governing state,
holds 27 seats in Hou.se of Representatives,
with foreign affairs, defense, internal security,
and other powers delegated to federal
Capital: Kuala Lumpur
Administrative divisions: 1 3 states (negeri-
negeri. singular — negeri) and 2 federal
territories* (wilayah-wilayah persekutuan,
singular — wilayah persekutuan); Johor,
Kedah, Kelantan. Labuan*, Melaka, Negeri
Sembilan, Pahang, Perak, Perils, Pulau Pinang,
Sabah, Sarawak, Selangor, Terengganu,
Wilayah Persekutuan*
Independence; 31 August 1957 (from UK)
National holiday; National Day, 3 1 August
(1957)
Constitution: 31 August 1957, amended 16
September 1963
Legal system: based on English common law;
Judicial review of legislative acts in the
Supreme Court at request of supreme head of
the federation; has not accepted compulsory
ICJ jurisdiction
Suffrage: 21 years of age: universal
Executive branch:
chief of state: Paramount Ruler JA’ AFAR ibni
Abdul Rahman (since 26 April 1994); Deputy
Paramount Ruler SALAHUDDIN ibni
Hisammuddin Alam Shah (since 26 April
1994)
head of government: Prime Minister Dr.
MAHATHIR bin Mohamad (since 16 July
1981); Deputy Prime Minister ANWAR bin
Ibrahim (since I December 1993)
cabinet: Cabinet; appointed by the Paramount
Ruler from members of parliament
Legislative branch: bicameral Parliament
(Parlimcn)
Senate (Dewan Negara): consists of a 58-
member body, 32 appointed by the paramount
ruler and 16 elected by the state legislatures
House of Representatives I Oewan Rakyat):
elections last held 21 October 1990 (next to be
held by August 1995): results — National Front
52%, other 48%; seals — (180 total) National
Front 1 27, DAP 20, PAS 7, independents 4,
other 22: note — within the National Front,
UMNO got 7 1 seats and MCA 1 8 scats
Judicial branch; Supreme Court
Political parties and leaders:
Peninsular Malaysia: National Front, a
confederation of 13 ptditical parties dominated
by United Malays National Organization Bum
(UMNO Bam), MAHATHIR bin Mohamad;
Malaysian Chinese Association (MCA), LING
Liong Sik: Gerakan Rakyat Malaysia, LIM
Keng Yaik: Malaysian Indian Congress (MIC),
S. Sarny VELLU
Sahah: National Front, Tan Sri SAKARAN,
Sabah Chief Minister; United Sabah National
Organizaton (USNO), leader NA
Sarawak: coalition Sarawak National Front
composed of the Party Pesaka Bumiputra
Bersatu (PBB), Datuk Patinggi Amar Haji
Abdul TAIB Mahmud; Sarawak United
People’s Party (SUPP), Datuk Amar James
WONG Soon Kai: Sarawak National Party
(SNAP). Datuk Amar James WONG; Parti
Bansa Dayak Sarawak (PBDS), Datuk Leo
MOGGIE: major opposition parties are
Democratic Action Party (DAP), LIM Kit
Siang and Pan-Malaysian Islamic Party (PAS),
Fadzil NOOR
Member of: APEC, AsDB, ASEAN, C.CCC,
CP. ESCAP. FAO. G- 1 5. G-77, GATT. IAEA,
IBRD, ICAO. ICFTU. IDA. IDB. IFAD, IFC.
ILO, IMF. IMO, INMARSAT. INTELSAT.
INTERPOL. IOC, ISO, ITU, LORCS,
MINURSO. NAM. OIC, UN, UNAVEM II.
UNCTAD, UNESCO. UNIDO. UNIKOM.
UNOMOZ. UNOSOM, UNTAC. UPU. WCL,
WHO. WIPO. WMO. WTO
Diplomatic representation in US:
chief of mission: Ambassador Abdul MAJID
bin Mohamed
chancery: 2401 Massachusetts Avenue NW.
Washington, DC 20008
telephone: (202) 328-2700
FAX: (202) 48.3-7661
consulate(s) general: Los Angeles and New
York
US diplomatic representation;
chief of mission: Ambassador John S. WOLF
embassy: 376 Jalan Tun Razak, 50400 Kuala
Lumpur
mailing address: P. O. Box No. 10035, 50700
Kuala Lumpur; APO AP 96535-5000
telephone: 1601 (3) 248-901 1
MX.- [60| (3) 242-2207
Flag: fourteen equal horizontal stripes of red
(top) alternating with white (bottom); there is a
blue rectangle in the upper hoist-side comer
bearing a yellow cre.scent and a yellow
fourteen-pointed star; the crescent and the star
are traditional symbols of Islam; the design
was based on the flag of the US
Names:
conventional long form: United Mexican
Slates
conventional short form: Mexico
local long form: Estados Unidos Mexicanos
local short form: Mexico
Digraph: MX
Type: federal republic operating under a
centralized government
Capital: Mexico
Administrative divisions: 3 1 states (estados,
singular — estado) and 1 federal district*
(distrito federal); Aguascalientes, Baja
California, Baja California Sur, Campeche.
260
Chiapas. Chihuahua, Coahuila, Colima,
Distrito Federal*, Durango. Guanajuato,
Guerrero, Hidalgo, Jali,sco. Mexico,
Michoacan, Morelos, Nayarit, Nuevo Leon.
Oaxaca, Puebla, Queretaro, Quintana Roo. San
Luis Potosi, Sinaloa, Sonora, Tabasco,
Tamaulipas, Tlaxcala, Veracruz, Yucatan,
Zacatecas
Independence: 1 6 September 1810 (from
Spain)
National holiday: Independence Day, 16
September (1 810)
Constitution: S February 1917
Legal system: mixture of US constitutional
theory and civil law .system; judicial review of
legislative acts; accepts compulsory ICJ
jurisdiction, with reservations
Sufh''age: 1 8 years of age; universal and
compulsory (but not enforced)
Executive branch;
chief of state and head of government:
President Carlos SALINAS de Gortari (since I
December 1988); election last held on 6 July
1988 (next to be held 21 Augu.st 1994);
results — Carlos SALINAS de Gortari (PRI)
50.74%, Cuauhtemoc CARDENAS Solorzano
(FDN) 31.06%. Manuel CLOUTHIER (PAN)
16.81%; other I. .39%; note — several of the
smaller parties ran a common candidate under
a coalition called the National Democratic
Front (FDN)
cabinet; Cabinet; appointed by the president
Legislative branch: bicameral National
Congress (Congreso de la Union)
Senate (Camara de SenadoresI: elections last
held on 18 August 1991 (next to be held 21
.\\ugust 1994); results— percent of vole by
party NA; seats in full Senate — (64 total;
Senate will expand to 1 28 .seats following next
election) PRI 62, PRD I. PAN I
Chamber of Deputies ( Camara de Diputados);
elections la.st held on 18 August 1991 (next to
be held 21 August 1994); results — PRI 53%.
PAN 20%. PFCRN 10%. PPS 6%, PARM 7%,
PMS (now part of PRD) 4%; seats — (500 total)
PRI 320, PAN 89. PRD 4 1 . PFCRN 23. PARM
15, PPS 12
Judicial branch: Supreme Court of Justice
(Corte Supreme de Justicia)
Political parties and leaders; (recognized
parties) Institutional Revolutionary Party
(PRI), Ignacio Pichardo PAGAZA: National
Action Party (PAN). Carlos CASTILLO;
Popular Socialist Party (PPS). Indalecio
SAYAGO Herrera; Democratic Revolutionary
Party (PRD), Porfirio MUNOZ Ledo;
Cardenist Front for the National
Reconsti tretion Party (PFCRN), Rafael
AGUILAR Talamantcs; Authentic Party of the
Mexican Revolution (PARM), Rosa Maria
MARTINEZ Denagri; Democratic Forum
Party (PFD), Pablo Emilio MADERO;
Mexican Green Ecologist Party (PVEM), Jorge
GONZALEZ Torres
Other political or pressure groups: Roman
Catholic Church; Confederation of Mexican
Workers (CTM); Confederation of Industrial
Chambers (CONCAMIN): Confederation of
National Chambers of Commerce
(CONCANACO); National Peasant
Confederation (CNC); Revolutionary Workers
Party (PRT); Revolutionary Confederation of
Workers and Peasants (CROC); Regional
Confederation of Mexican Workers (CROM);
Confederation of Employers of the Mexican
Republic (COPARMEX); National Chamber
of Transformation Industries
(CANACINTRA): Coordinator for Foreign
Trade Business Organizations (COECE);
Federation of Unions Providing Goods and
Services (FESEBES)
Member of: AG (observer), BCIE,
CARICOM (observer). CCC, CDB, CG,
EBRD, ECLAC. FAO. G-3, G-6, G- 1 1 , G- 1 5.
G-19. G-24. GATT. lADB. IAEA, IBRD.
ICAO, ICC. ICFTU, IDA. IFAD. IFC, ILO,
IMF, IMO, INTELSAT. INTERPOL. IOC.
lOM (observer), ISO. ITU, LAES. LAIA,
l.ORCS, NAM (observer). OAS. OECD.
ONUSAL, OPANAL. PCA. RG. UN.
UNCTAD, UNESCO, UNIDO. UPU, WCL,
WFTI, WHO, WIPO, WMO, WTO
Diplomatic representation in US:
chief of mission; Ambassador Jorge
MONTANO Martinez
chancery; 1911 Penn.sylvania Avenue NW,
Washington, DC 20(X)6
telephone; (202) 728-1600
considate(s) general; Atlanta, Chicago,
Dallas, Denver, El P.nso, Houston, Los
Angeles. Miami, New Orleans, New York, San
Antonio. San Diego, San Francisco, San Juan
(Puerto Rico)
consulate(s); Albuquerque. Austin. Boston,
Brownsville (Texas), Calexico (California),
Corpus Christi, Del Rio (Texa.s). Detroit, Eagle
Pass (Texas). Fresno (California). Loredo. Me
Allen (Texas), Midland (Texas), Nogales
(Arizona), Oxnard (California). Philadelphia
US diplomatic representation;
chief of mission; Ambassador James JONES
embassy; Paseo de la Refonua .305, Colonia
Cuauhtemoc, 06500 Mexico, D.F.
mailing address: P. O, Box 3087, Laredo, TX
78044-3087
telephone; 152] (5)211-0042
FAX; 152| (5) 51 1-9980, 208-3373
considoie(s) general; Ciudad .luarez,
Guadalajara. Monterrey, Tijuana
considate(s); Hermosillo. Matamnros. Merida,
Nuevo Laredo
Flag: three equal vertical bands of green
(hoist side), white, and red; the coat of arms (an
eagle perched on a cactus with a snake in its
beak) is centered in the while band
Names:
conventional long form; Kingdom of Norway
conventional short form; Norway
local long form; Kongeriket Norge
local short form: Norge
Digraph: NO
Type: constitutional monarchy
Capital: Oslo
Administrative divisions: 19 provinces
(fylker, singular — fylke): Akershus, Aust-
Agder, Buskerud, Finnmark, Hedmark,
Hordaland, More og Romsdal, Nordland.
Nord-Trondelag, Oppland. Oslo. Ostfold.
Rogaland, Sogn og Fjordane, Sor-Trondelag,
Telemark. Troms, Vest-Agder, Vestfold
Dependent areas: Bouvet Island, Jan Mayen,
Svalbard
Independence: 26 October 1905 (from
Sweden)
National holiday: Constitution Day. 17 May
(1814)
Constitution: 1 7 May 1814, modified in 1 884
Legal system: mixture of customary law,
civil law system, and common law traditions;
Supreme (2ourt renders advisory opinions to
legislature when asked; accepts compuLsory
ICJ jurisdiction, with reservations
SufDage: 1 8 years of age: universal
Executive branch:
chief of state; Kmg HARALD V (since 1 7
January 1991); Heir Apparent Crown Prince
HAAKON MAGNUS (bom 20 July 1973)
head of government; Prime Minister Gro
Harlem BRUNDTLAND (since 3 November
1990)
cabinet; State Council; appointed by the king
in accordance with the will of the Storting
IwCgislative branch: unicameral Parliament
(Storting)
Storting; elections last held on 1 3 September
1993 (next to be held September 1997);
results — Labor 37. 1 %, Center Party 1 8.5%,
Conservatives 15.6%, Christian Peoples''
8.4%. Socialist Left 7.9%, Progress 6%, Left
Party 3.6%, Red Electoral Alliance 1 .2%;
seats — (165 total) Labor 67, Center Party 32,
Consevatives 18. Christian Peoples'' 13.
Socialist Left 13, Progress 10, Left Party I,
Red Electoral Alliance I, unawarded 10
Lagting: Storting elects one-fourth of its
member to upper house
Judicial branch: Supreme Court
(Hoyesterett)
Political parties and leaders: Labor Party.
Thorbjom JAGLUND: Conservative Party, Jan
PETERSEN; Center Party, Anne ENGER
LAHNSTEIN; Christian People’s Party, Kjell
Magne BONDEVIK; Socialist Left, Eric
SOLHEIM; Norwegian Communist, Ingre
IVERSEN; Progress Party. Carl I, HAGEN:
Liberal, Odd Einar DORUM; Finnmark List,
leader NA; Left Party; Red Electoral Alliance
Member of: AfDB. AsDB, Australia Group,
BIS, CBSS. CCC, CE. CERN. COCOM.
CSCE, EBRD, ECE, EFTA, ESA. FAO,
GATT. lADB. IAEA, IBRD, ICAO, ICC.
ICFTU, IDA, lEA, IFAD, IPC, ILO, IMF,
IMO, INMARSAT. INTELSAT. INTERPOL,
IOC, lOM, ISO, ITU, LORCS, MTCR. NACC,
NAM (guest), NATO. NC, NEA, NIB. NSG.
OECD, ONUSAL, PCA, UN, UNAVEM II.
UNCTAD, UNESCO. UNHCR, UNIDO,
UNIFIL, UNIKOM. UNMOGIP. UNOSOM,
UNPROFOR, UNTAC, UNTSO, UPU, WEU
(associate), WHO, WIPO, WMO, ZC
Diplomatic representation in US:
chief of mission; Ambassador Kjeld VIBE
chancery; 2720 34th Street NW, Washington.
DC 20008
telephone; (202) 333-60(X)
FAX; (202) 337-0870
consulate(s) general; Houston. Los Angeles.
Minneapolis, New York, and San Francisco
consulate(s); Miami
US diplonutic representation:
chief of mission; Ambassador Thomas A.
LOFTUS
embassy; Drammensveien 1 8, 0244 Oslo 2
mailing address; PSC 69. Box 1000. APO AE
09707
telephone: [47J 22-44-85-50
FAX; [47] 22-43-07-77
Flag: red with a blue cross outlined in white
that extends to the edges of the flag; the vertical
pan of the cross is shifted to the hoist side in
the style of the Dannebrog (Danish flag)
Names:
conventional long form: Republic of Poland
conventional short form: Poland
local long form: Rzeczpospolita Polska
local short form: Polska
Digraph: PL
Type: democratic state
Capital: Warsaw
Administrative divisions: 49 provinces
(wojewodztwa, singular — wojewodztwo);
Biala Podlaska, Bialystok. Bielsko Biala,
Bydgoszcz, Chelm, Ciechanow, Czestochowa,
318
Elblag, Gdansk, Gorzow, Jelenia Gora, Kalisz,
Katowice, Kielce, Konin, Koszalin, Krakow,
Krosno, Legnica, Leszno, Lodz, Lomza,
Lublin, Nowy Sacz, Olsztyn, Opole, Ostroleka,
Pila, Piotrkow, Plock, Poznan, Przemysl,
Radom, Rzeszow, Siedice, Sieradz,
Skiemiewice, Slupsk, Suwalki, Szczecin,
Tamobrzeg, Tamow, Torun, Walbrzych,
Warszawa, Wloclawek, Wroclaw, Zamosc,
Zielona Gora
Independence: 1 1 November 1918
(independent republic proclaimed)
National holiday: Constitution Day, 3 May
(1791)
Constitution: interim "small constitution"
came into effect in December 1992 replacing
the Communist-imposed Constitution of 22
July 1952; new democratic Constitution being
drafted
Legai system: mixture of Continental
(Napoleonic) civil law and holdover
Communist legal theory; changes being
gradually introduced as pan of broader
democratization process; limited judicial
review of legislative acts; has not accepted
compulsory ICJ jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Lech WALESA (since
22 December 1990); election first round held
25 November 1990, second round held 9
December 1 990 (next to be held NA November
1995); results— second round Lech WALESA
74.7%, Stanis''aw TYMINSKI 25.3%
head of government; Prime Minister
Waldemar PaWLAK (since 26 October 1993)
cabinet: Council of Ministers; responsible to
the president and the Sejm
Le^slative branch: bicameral National
Assembly (Zgromadzenie Narodowe)
Senate (Scnat): elections last held 19
September 1993 (next to be held no later than
NA October 1997); seats — (l(X) total)
post-Solidaritv bloc; UW 6, NSZZ 12.
BBWR2
non-Communist, non-Solidarity:
independents 7, unaffiliated I, vacant I (to be
filled in a 19 June election)
Communist origin or linked: PSL 34, SLD 37
Diet (Sejm): elections last held 19 September
1993 (next to be held no later than NA October
1997); seats — (460 total)
post-Solidaritv bloc; UW 74, UP 41 ,
BBWR 16
non-Communist, non-Solidarity: KPN 22
Communist origin or linked; SLD 171,
PSL 132
note: 4 seats were won by ethnic Germans
Judicial branch: Supreme Court
Political parties and leaders:
post-SoUdarity parties: Freedom Union (WD;
UD and Liberal Democratic Congress merged
to form Freedom Union), Tadeusz
MAZOWIECKl; Christian-National Union
(ZCHN), Wieslaw CHRZANOWSKl;
Centrum (PC), Jaroslaw KACZYNSKl;
Peasant Alliance (PL), Gabriel JANOWSKI;
Solidarity Trade Union (NSZZ), Marian
KRZAKLEWSKI; Union of Labor (UP),
Ryszard BUGA); Christian-Democratic Party
(PCHD), Pawel LACZKOWSKi;
Conservative Party, Alexander HALL;
Nonparty Bloc for the Support of the Reforms
(BBWR)
non-Communist, non-Solidarity;
Confederation for an Independent Poland
(KPN), Uszek MOCZULSKI; Polish
Economic Program (PPG), Janusz
REWINSKI; Christian Democrats (CHD),
Andrzej OWSINSKI; German Minority (MN),
Henryk KROL; Union of Real Politics (UPR),
Janusz KORWIN-MIKKE; Democratic Party
(SD), Antoni MACKIEWICZ; Party X,
Stanislaw Tyminski
Communist origin or linked: Social
Democracy (SDRP, party of Poland),
Aleksander KWASNIEWSKI; Polish
Peasants’ Party (PSL), Waldemar PAWLAK;
Democratic Left Alliance, Aleksander
KWASNIEWSKI
Other political or pressure groups:
powerful Roman Catholic Church; Solidarity
(trade union); All Poland Trade Union Alliance
(OPZZ), populist program
Member of; BIS, BSEC (observer), CBSS,
CCC, CE. CEl, CERN, COCOM
(cooperating), CSCE, EBRD, ECE, FAO,
GATT, IAEA. IBRD, ICAO, ICFTU, IDA,
IFC, ILO, IMF, IMO, INMARSAT,
INTELSAT (nonsignatory user), INTERPOL,
IOC, lOM, ISO. ITU, LORCS, MINURSO,
NACC, NAM (guest), NSG, OAS (observer),
PCA, UN, UNCTAD. UNESCO, UNDOF,
UNIDO, UNIHL, UNIKOM. UNOMIG,
UNPROFOR, UNTAC, UPU, WCL, WFTU,
WHO, WIPO, WMO, WTO, ZC
Diplomatic representation in US:
chief of mission: Ambassador Jerzy
KOZMINSKI
chancerv: 2640 16th Street NW, Washington,
DC 20009
telephone: (202) 234-3800 through 3802
FAX; (202) 328-6271
consulate(s) general; Chicago, Los Angeles,
and New York
US diplomatic representation:
chief of mission; Ambassador Nicholas A.
REY
embassy; Aleje Ujazdowskie 29/31, Warsaw
mailing address: American Embassy Warsaw,
Unit 1 340, or APO AE 092 1 3- 1 340
telephone: [48] (2) 628-3041
FAX: [48] (2) 628-8298
consulatefs) general: Krakow, Poznan
Flag: two equal horizontal bands of white
(top) and red; similar to the flags of Indonesia
and Monaco which are red (top) and white
Names:
conventional long form: Socialist Republic of
Vietnam
conventional short form: Vietnam
local long form: Cong Hoa Chu Nghiu Viet
Nam
local short form: Viet Nam
Abbreviation: SRV
Digraph: VM
Type: Communist state
Capital: Hanoi
Administrative divisions: 50pr.tvinces(iinh,
singular and plural), 3 municipalities* (thanh
pho, singular and plural): An Giang, Ba
Ria-Vung Tau, Bac Thai, Ben Tre, Binh Dinh,
Binh Thuan, Can Tho, Cao Bang, Dac Lac,
Dong Nai. Dong Thap, Gia Lai, Ha Bac. Ha
Giang, Ha Noi*. Ha fay. Ha Tinh, Hai Hung.
Hal Phong*, Ho Chi Minh*, Hoe Binh, Khanh
Hoa, Kien Giang, Kon Turn, Lai Chau, Lam
Dong, Lang Son, Lao Cai, Long An, Minh Hal,
Nam Ha, Nghe An, Ninh Binh, Ninh Thuan.
Phu Yen, Quang Binh. Quang Nam-Da Nang,
Quang Ngai, Quang Ninh, Quang Tri, Soc
Trang, Son La, Song Be, Tay Ninh, Thai Binh,
Thanh Hoa. Thua Thien, Tien Giang, Tra Vinh,
Tuyen Quang. Vinh Long, Vinh Phu. Yen Bat
Independence: 2 September 1945 (from
France)
Netlonul holiday: Independence Day, 2
September (1945)
Constitution; 1 5 April 1992
Legal system: based on Communist legal
theory and French civil law system
Sufftrage: 1 8 years of age; universal
Executive branch:
chief of Slate: President Le Due ANH (since 23
September 1992)
head of government: Prime Minister Vo Van
KIET (since 9 August 1991); First Deputy
Prime Minister Phan Van KHAI (since 10
August 1991 ); Deputy Prime Minister Nguyen
KHANH (since NA February 1987); Deputy
Prime Minister Tran Due LliONO (since NA
February 1987)
cabinet: Cabinet: appointed by the president
on proposal ol the prime minister and
ratification of the Assembly
Legislative branch: unicameral
National Assembly (Quoc-Hoi): elections last
held 19 July 1992 (next to be held NA July
1997): results — NCP is the only party: seats —
(395 total) VCP or VCP-approv^ ,395
Judicial branch: Supreme People''s Court
Political parties and leaders: only party —
Vietnam Communist Party (VCP), DO MUOl,
general secretary
Member of: ACCT, AsDB, ASEAN
(Observer), ESCAP, FAO, G-77, IAEA, IBRD,
fCAO, IDA, IFAD, IFC, ILO, IMF, IMO,
INTELSAT. INTERPOL, IOC. lOM
(observer), ISO. ITU. LORCS, NAM. UN,
UNCTAD, UNESCO. UNIDO. UPU. WCL.
WFTU, WHO, WIPO, WMO, WTO
Diplomatk representation in US: none;
Ambassador Le Van B \\NG is the Permanent
Representative to the UN
US diplomatic representation: none
Flag: red with a large yellow five-pointed star
in the center
Names:
conventional long form: Virgin IsL.ids of the
United Stales
conventional short form: Virgin Islands
Digraph: VQ
Type: organized, unincorporated territory of
the US administered by the Office of
Territorial and International Affairs, US
Department of the Interior
Capital: Charlotte Amalie
Administrative divisions: none (territory of
the US)
National holiday: Transfer Day, 31 March
( 1917) (from Denmark to US)
Constitution: Revised Organic Act of 22 July
1954
Legal system: based on US
Suffrage: 1 8 years of age: universal; note —
indigenous inhabitants are US citizens but do
not vote in US presidential elections
Executive branch:
chief of state: President William Jefferson
CLINTON (since 20 January 1993); Vice
President Albert GORE. Jr. (since 20 January
1993)
head of government: Governor Alexander A.
FARRELLY (since 5 January 1987);
Lieutenant Governor Derek M. HODGE (since
5 January 1 987); election last held 6 November
1990 (next to be held November 1994);
results — Governor Alexander FARRELLY
(Democratic Party) 56.5% defeated Juan LUIS
(independent) 38.5%
Legislative branch; unicameral
Senate: elections last held 3 November 1992
(next to be held 2 November 1994); results —
percent of vote by party NA: seats — (15 total)
number of seats by party NA
US House of Representatives: elections last
held 3 November 1992 (next to be held 2
November 1994); results — Ron DE LUGO
reelected as delegate; seats — ( I total); seat by
party NA; note — the Virgin Islands elect one
representative to the US House of
Representatives
Judicial branch:
US District Court: handles civil matters over
$50,000, felonies (persons 15 years of age and
over), and federal cases
Territorial Court; handles civil matters up to
$50,000, small claims, juvenile, domestic,
misdemeanors, and traffic cases
Political parties and leaders: Democratic
Party. Marilyn STAPLETON; Independent
Citizens’ Movement (ICM), Virdin C.
BROWN; Republican Party, Charlotte-Poole
DAVIS
Member of: ECLAC (associate), IOC
Diplomatic representation in US: none
(territory of the US)
US diplomatic representation: none
(territory of the US)
Flag: white with a modified US coat of arms
in the center between the large blue initials V
and I; the coat of arms shows an eagle holding
an olive branch in one talon and three arrows in
the other with a superimposed shield of vertical
red and white stripes below a blue panel','1b3e5ceabe80ece192defaefce523dc99250d7b777c057bca45503f7fe529180','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6bed1b99f5281982ae8043606e682c7eebdf58ee2126cee3d96ab6af512dd5fb',1994,'ML','Mali','government',628,'Names;
conventional long form: Republic of Mali
conventional short form: Mali
local Ion)! form: Republique de Mali
local short form: Mali
former: French Sudan
Digraph: ML
Type: republic
Capital: Bamako
Administrative divisions: 8 regions (regions,
singular — region): Gao, Kayes, Kidal,
Koulikoro. Mopti, Segou. Sikasso,
Tombouctou
independence: 22 September I960 (from
France)
National holiday: Anniversary of the
Proclamation of the Republic, 22 September
(1960)
Constitution: new constitution adopted in
constitutional referendum in 12 January 1992
Legal system: based or. French civil law
system and customary law; judicial review of
legislative acts in Ccnstitutional Court (which
was formally established on 9 March 1994);
has not accepted compulsory ICJ jurisdiction
Suffrage: 2 1 years of age: universal
Executive branch;
chief of state: President Alpha Oumar
KONARE (since 8 June 1992); election last
held in April 1992 (next to be held NA 1997>i
Alpha KONARE was elected in runoff race
against Montagn TALL
head of jtovernment: Prime Minister Ibrahima
Boubacar KEITA (since March 1994)
cabinet: Council of Ministers; appointed by
the prime minister
Legislative branch: unicameral
National Assembly: elections last held on 8
March 1992 (next to be held NA): results —
percent of vote by party NA; seats — (total 1 16)
Adema 76, CNID 9. US/RAD 8, Popular
Movement for the Development of the
Republic of West Africa 6, RDP 4. UDD 4,
RDT 3. UFDP 3. PDP 2. UMDD 1
Judicial branch: Supreme Court (Cour
Supreme)
Political parties and leaders: Association
for Democracy (Adema). Alpha Oumar
KONARE; National Congress for Democratic
Initiative (CNIDi. Mountaga TALL; Sudanese
Union/African DcmiKratic Rally (US/RDA).
Mamadou Madeira KEITA: Popular
Movement for the Development of the
Republic of West Africa: Rally for Democracy
and Progress (RDP). Almamy SYLLA; Union
for Democracy and Development (UDD),
Moussa Balia COULIBALY: Rally for
Democracy and Labor (RDT); Union of
DemtKratic Forces for Progress (UFDP).
Dembo DIALLO: Party for Democracy and
Progress (PDP), Idrissa TRAORE; Malian
Union for Democracy and Development
(UMDD)
Member of: ACCT, ACP, AIDB. CCC.
CEAO, EC A, ECOWAS, FAO. FZ. G-77.
GATT, IAEA, IBRD, ICAO, ICFTU, IDA,
IDB. IFAD, IFC. ILO. IMF, INTELSAT.
INTERPOL. IOC. ISO (correspondent), ITU,
LORCS. NAM. OAU, OlC, UN, UNCTAD,
UNESCO. UNIDO, UPU, WADB, WCL.
WHO. WIPO. WMO, WTO
Diplomatic representation in US:
chief of mission: Ambassador Siragatou
Ibrahim CISSE
chancen'': 2 1 30 R Street NW, Washington, DC
20(K)8
telephone: (202) 332-2249 or 939-8950
US diplomatic representation:
chief of mission: Ambassador William H.
DAMERON 111
embassy: Rue Roche.ster NY and Rue
Mohamed V.. Bamako
mailing address: B, P. 34, Bamako
telephone: |223] 225470
248','788129df97e9040af4b8676f528d4c0793eda2abac3f3b20581a3d0d75cd5b9a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c253b032e244ae9245ef61f36ac394aa18b909b8f468c2c61e8b3fcd2412105',1994,'MT','Malta','government',629,'FAX. 1223] 2280S9
Hag: three equal vertical hands of green
(hoist side), yellow, and red; uses the popular
pan-African colors of Ethiopia
Names;
conventional Um^form: Republic of Malta
conventional .short form: Malta
Digraph: MT
Type: parliamentary democracy
Capital: Valletta
Administrative divisions: none
(administration directly from Valletta)
Independence: 21 September 1964 (from
UK)
National holiday: Independence Day, 21
September (1964)
Constitution: 1964 constitution substantially
amended on 13 December 1974
Legal system: based on English common law
and Roman civil law; has accepted compulsory
ICJ jurisdiction, with re.servaticns
Suffrage: 1 8 years of age; universal
Executive branch:
chief of .slate: President Ugo MIFSUD
BONNICI (since 4 April 1994)
head of government: Prime Minister Dr.
Edward (Eddie) FENECH ADAMl (since 12
May 1987); Deputy Prime Minister Dr. Guido
DE MARCO (since 14 May 1987)
cabinet: Cabinet; app.iinted by the president
on advice of the prime minister
Legisiative branch: unicameral
House of Representatives: elections last held
on 22 February 1992 (next to be held by
February 1997); results— NP 51.8%, MLP
46.5%; seats — (usually 65 total) MLP 36. NP
29; note — additional seats are given to the
party with the largest popular vote to ensure a
legislative majority; current total 69 (MLP 33,
NP 36 after adju.stment)
Judicial branch: Constitutional Court, Court
of Appeal
Political parties and leaders: Nationalist
Party (NP), Edward FENECH ADAMl; Malta
Labor Party (MLP). Alfred SANT
Member of: C. CCC. CE. CSCE, EBRD.
ECE, FAO, G-77. GATT. IBRD, ICAO.
ICFTU, IFAD. ILO. IMF. IMO, INMARSAT.
INTELSAT (nonsignatory user), INTERPOL,
IOC, lOM (observer), ISO (correspondent),
ITU. NAM. PCA, UN. UNCTAD, UNESCO,
UNIDO, UPU, WCL. WHO, WlPO, WMO,
WTO
Diplomatic representation in US:
chief of mission: Ambas.sador Albert BORG
OLIVIER DE PUGET
chancery: 20 1 7 Connecticut Avenue NW,
Washington, DC 20008
telephone: (202) 462-36 II or 36 1 2
FAX: (202) 387-5470
con.sulate(s): New York
US diplomatic representation:
chief of mi.s.sion: (vacant); Charge d''Affaires
William A. MOFFITT (new ambassador
nominated, but not confirmed)
emha.s,sy: 2nd Floor, Development House,
Saint Anne Street, Floriana, Valletta
mailing address: P. O. Box 535, Valletta
telephone: (356) 235960
FAX: (3561 243229
Flag: two equal vertical bands of while (hoist
side) and red; in the upper hoist-side corner is
a representation of the George Cross, edged in
red
Names:
conventional long form: none
conventional short form: Isle of Man
Digraph: IM
Type: British crown dependency
Capital: Douglas
Administrative divisions: none (Briti.sh
crown dependency)
Independence: none (British crown
dependency)
National holiday: Tynwald Day. 5 July
Constitution: 1961. Isle of Man Constitution
Act
Legal system: English law and local statute
Suffrage: 2 1 years of age; universal
Executive branch;
chief of state: Lord of Mann Queen
ELIZABETH II (since 6 February 1952),
reprc.sented by Lieutenant Governor Air
Marshal Sir Laurence JONES (since NA 1990)
head of government: President of the
Legislative Council Sir Charles KERRUISH
(since NA 1990)
cabinet: Council of Ministers
Legislative branch; bicameral Tynwald
U’gislative Council: consists of a lO-membcr
body composed of the Lord Bishop of Sodor
and Man. a nonvoting aluirney general, and 8
others named by the House of Keys
House of Keys: elections last held in 1991
(next to be held NA 1996); results — percent of
vote NA: seats— (24 total) independents 24
Judicial branch; Court of Tynwald
Political parties and leaders; there is no
party system and members sit as independents
Member of; none
Diplomatic representation in US: none
(British crown dependency)
US diplomatic representation: none (British
crown dependency)
Flag: red with the Three Legs of Man emblem
251
Man, Isle of (continued)','17af1bedad8a683a8c57e34ccf9a72b5016f5086274efb85bd0fa94e5080cb4c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('948046630d44dc602525a4313330a5623a478b35c20decc540933d140338710e',1994,'MH','Marshall Islands','government',635,'(Trinacria), in ihe center; the three legs are
joined at the thigh and bent at the knee; in order
to have the toes pointing clockwise on both
sides of the Hag, a two-sided emblem is used
Names:
conventional long form: Republic of the
conventional short form: Marshall Islands
former: Marshall Islands District (Trust
Territory of the Pacific Islands)
Digraph: RM
Type: constitutional government in free
association with the US; the Compact of Free
Association entered into force 2 1 October 1986
Capital: Majuro
Administrative divisions; none
Independence: 21 October 1986 (from the
US-administered UN tmsteeship)
National holiday: Proclamation of the
Republic ofthe Marshall Islands, I May (1979)
Constitution: I May 1979
Legal system: based on adapted Trust
Territory laws, acts of the legislature,
municipal, common, and customary laws
Suffrage: 18 years of age; universal
Executive branch:
chief of state and head of government:
President Amata KABUA (.since 1979);
election last held 6 January 1992 (next to be
held NA; results — President Amata KABUA
was reelected)
cabinet: Cabinet; president selects from the
parliament
Legislative branch: unicameral
Parliament (Nitijela): elections last held 1 8
November 1991 (next to be held November
1 995); results — percent of vote NA; seats — (33
total)
Judicial branch: Supreme Court
Political parties and leaders: no formal
parties; President KABUA is chief political
(and traditional) leader
Member of; AsDB, ESCAP, IBRD, ICAO,
IDA, IFC, IMF, INTELSAT (nonsignatory
user), INTERPOL, SPARTECA, SPC, SPF,
UN, UNCTAD. WHO
Diplomatic representation in US:
chief of mission: Ambassador Wilfred I.
KENDALL
chancery: 2433 Massachusetts Avenue NW,
Washington, DC 20008
telephone: (202) 234-5414
FAX: (202) 232-32.36
consulate(s) general: Honolulu and Los
Angeles
US diplomatic representation:
chief of mission: Ambassador David C.
FIELDS
embassy: NA address, Majuro
mailing address: P. O. Box 1379, Majuro,
Republic of the Marshall Islands 96960-1379
telephone: (692) 625-401 1
MX.- (692) 625-4012
Flag: blue with two stripes radiating from the
lower hoist-side comer — orange (top) and
white: there is a white star with four large rays
and 20 small rays on the hoist side above the
two stripes','2a8a7c952f7a78cf2902f477e85da5e2ad460889c85c992e4977072a5fdd5178','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f9c5c8f71e1e8a4375ee716afda9c4649b56b9dfaddbfc8f882a12807e0fd55',1994,'MQ','Martinique','government',643,'Names:
conventional long form: Department of
conventional short form: Martinique
local long form: Departement de la Martinique
local short form: Martinique
Digraph: MB
Type; overseas department of France
Capital: Fort-de-France
Administrative divisions: none (overseas
department of France)
Independence: none (overseas department of
France)
National holiday: National Day, Taking of
the Bastille, 14 July (1789)
Constitution: 28 September 1968 (French
Constitution)
Legal system: French legal system
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: President Francois
MITTERRAND (since 2 1 May 1981)
head of government: Prefect Michel MORIN
(since NA); President of the General Council
Claude LISE (since 22 March 1992); President
of the Regional Council Emile CAPGRAS
(since 22 March 1992)
cabinet: Council of Ministers
Legislative branch: unicameral General
Council and a unicameral Regional Assembly
General Council: elections last held in 26
September and 8 October 1988 (next to be held
by NA); results — percent of vote by party NA;
seats — (44 total) number of seats by party NA;
note — a leftist coalition obtained a one-seat
margin
Regional Assembly: elections last held on 22
March 1992 (next to be held by March 1998);
results — percent of vote by party NA; seats —
(41 total) RPR-UDF 16, MIM 9, PPM 9, PCM
5, independents 2
French Senate: elections last held 24
September 1989 (next to be held NA);
results — percent of vote by party NA; seats —
(2 total) UDFLPPM I
French National Assembly: elections last held
on NA June 1993 (next to be held June 1998);
results — percent of vote by party NA; seats —
(4 total) RPR 3, FSM I
Judicial branch; Supreme Court
Political parties and leaders; Rally for the
Republic (RPR), Stephen B AGOE; Union for a
Martinique of Progress (UMP); Martinique
Progressive Party (PPM), Aime CESAIRE and
Camille DARSIERES; Socialist Federation of
Martinique (FSM), Jean CRUSOL; Martinique
Communist Party (PCM); Maninique Patriots
(PM); Union for French Democracy (UDF),
Jean MARAN; Martinique Independence
Movement (MIM), Alfred MARIE-JEANNE
Other political or pressure groups:
Proletarian Action Group (GAP); Alhed
Marie-Jeanne Socialist Revolution Group
(GRS): Caribbean Revolutionary Alliance
(ARC); Central Union for Martinique Workers
(CSTM), Marc PULVAR; Frantz Fanon
Circle; League of Workers and Peasants; Parti
Martiniquais Socialiste (PMS)
Member of: FZ, WCL, WFTU
Diplomatic representation in US: none
(overseas department of France)
US diplomatic representation: the post
closed in August 1993 (overseas department of
France)
Flag: the flag of France is used','a3f5d7e8dc11c97aadaf288f9532c8873c1e3e2a68a87fc80582886c4c7e3e2b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c697383c92e813bf26fec7ed568e2b9d67cdb9d973ef14f73c64fd873d6a3afb',1994,'MR','Mauritania','government',649,'conventional short form: Mauritania
loccd Ion}’ form: Al Jumhuriyah al Islamiyah al
Muritaniyah
local short form: Muritaniyah
Digraph: MR
Type; republic
Capital: Nouakchott
Administrative divisions: 1 2 regions
(regions, singular— region); Adrar, Assaba,
Brakna. Dakhlet Nouadhibou. Gorgol.
Guidimaka. Hodh ech Chargui. Hodh el
Gharbi. Inchiri, Tagant. Tiris Zemmour. Trarza
note: there may be a new capital district of
Nouakchott
Independence: 28 November 1960 (from
France)
National holiday: Independence Day, 28
November (1960)
Constitution: 1 2 July 1991
Legal system: three-tier system: Islamic
(Shari''a) courts, special courts, state security
courts (in the process of being eliminated)
Suffrage: 18 years of age; universal
Executive branch:
chief of state and head of government:
President Col. Maaouya Quid Sid'' Ahmed
TAYA (since 12 December 1984); election last
held January 1992 (next to be held January
1998); results — President Col. Maaouya Quid
Sid ''Ahmed TAYA elected
cabinet: Council of Ministers
Legislative branch: bicameral legislature
Senate (Majlis al-Sbuyukh): elections last held
1 5 April 1994 (one-third of the seats up for re-
election in 1996)
National Assembly (Majlis al-Watani):
elections last held 6 and 13 March 1992 (next
to be held March 1997)
Judicial branch: Supreme Court (Cour
Supreme)
Political parties and leaders: legalized by
constitution pas.sed 12 July 1991. however,
politics continue to be tribally based: emerging
parties include Democratic and Social
Republican Party (PROS), led by President
Col. Maaouya Quid Sid’ Ahmed TAYA; Union
of Democratic Forces — New Era (UFD/NE),
headed by Ahmed Quid DADDAH; As.sembly
for Democracy and Unity (RDU), Ahmed Quid
SIDI BABA; Popular Social and Democratic
Union (UPSD). Mohamed Mahmoud Quid
MAH; Mauritanian Party for Renewal (PMR),
Hameida BOUCHRAYA: National Avant-
Garde Party (PAN). Khaltry Quid JIDDOU;
Mauritanian Party of the Demwratic Center
(PCDM). Bamba Quid SIDI BADI
Other political or pressure groups:
Mauritanian Workers Union (UTM)
Member of; ABEDA, ACCT (associate),
ACP. AIDB, AFESD, AL, AMF. AMU.
CAEU, CCC, CEAO. ECA. ECOWAS. FAO.
G-77. GATT. IBRD, ICAO. IDA. IDB, IFAD,
IFC, ILO, IMF. IMO. INTELSAT.
INTERPOL, IOC, ITU. LORCS, NAM. OAU.
OIC. UN, UNCTAD, UNESCO, UNIDO.
UPU, WHO, WIPO, WMO, WTO
Diplomatic representation in US:
chief of mission: Ambassador Mohamed Fall
Ould AININA
chancerv: 2 1 29 Leroy Place NW, Washington.
DC 20008
telephone: (202) 232-57(X)
US diplomatic representation:
chief of mission: Ambassador Gordon S.
BROWN
embassy: address NA. Nouakchott
mailing address: B. P. 222. Nouakchott
telephone: 1222] (2) 526-60 or 526-63
FAX: 12221(2)51.5-92
Flag: green with a yellow five-pointed star
above a yellow, horizontal crescent; the closed
side of the crescent is down; the crescent, star,
and color green are traditional symbols of
Islam','64edf0c36a89de3598369b9597876be57c60932d2d4cea8f7930e3762f77fd9c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f32f5e3b23f21e7bb9e259e79b42552be43ca378057158e0d7c76a8f944a4490',1994,'MU','Mauritius','government',655,'Names:
conventional long form: Republic of Mauritius
conventional .short form: Mauritius
Digraph; MP
Type: parliamentary democracy
Capital: Port Louis
Administrative divisions: 9 districts and 3
dependencies*; Agalega Islands*, Black River,
Cargados Carajos*, Flacq, Grand Port, Moka,
Pamplemousses, Plaines Wilhems, Port Louis.
Riviere du Rempart. Rodrigues*, Savanne
Independence: 12 March 1968 (from UK)
National holiday: Independence Dav, 12
March (1968)
Constitution: 12 March 1968; ‘ i 12
March 1992
Legal system: ba.sed on French ■ i iw
257
Mauritius (continued)
system with elements of English common law
in certain areas
Suffrage; I g years of age; universal
Executive branch:
chief of state: President Cassam UTEEM
(since I July 1992); Vice President
Rabindranath GHURBURRON (since 1 July
1992)
hem! ofiioverrinieiit: Prime Minister Sir
Anerood JUGNAUTH (since 12 June 1982);
Deputy Prime Minister Prem NABABSING
(since 26 September 1 990)
cabinet: Council of Ministers; appointed by
the president on recommendation of the prime
minister
Legislative branch; unicameral
Legislative Assembly: elections last held on 15
September 1991 (next to be held by 15
September 1996); results — MSM/MMM 53%,
MLP/PMSD 38%; seats — (70 total, 62 elected)
MSM/MMM alliance 59 (MSM 29, MMM 26,
OPR 2, MTD 2); MLP/PMSD 3
Judicial branch; Supreme Court
Political parties and leaders:
government coalition: Militant Socialist
Movement (MSM), A. JUGNAUTH;
Mauritian Militant Movement (MMM). Prem
NABABSING (less 1 2 legislators under the
leadership of Paul BERENGER, now voting
with the opposition); Organization of the
People of Rodrigues (OPR), Louis Serge
CLAIR; Democratic Labor Movement (MTD),
Anil BAICHCK)
opposition: Mauritian Labor Party (MLP),
Navin RAMGOOLMAN;
Socialist Workers Front. Syivio MICHEL;
Mauritian Social Democratic Party (PMSD),
X. DUVAL; MMM-Berenger Faction, Paul
BERENGER
Other political or pressure groups: various
labor unions
Member of: ACCT. ACP, AfDB, C, CCC,
ECA. FAO, G-77, GATT. IAEA, IBRD,
ICAO. ICFTU, IDA. IFAD, IFC. ILO, IMF,
INMARSAT. IMO, INTELSAT. INTERPOL.
KX'', ISO (correspondent), ITU, LORCS,
NAM, OAU, PCA, UN, UNCTAD, UNESCO,
UNIDO, UPU, WCL, WFTU, WHO. WIPO.
WMO. WTO
Diplomatic representation in US;
chief of mission: Ambassador Anund
NEEWOOR
chancery: Suite 441, 4301 Connecticut
Avenue NW. Washington, DC 20(X)8
telephone: (202) 244-1491 or 1492
FAX: (202) 966-0983
US diplomatic representation;
chief of mission: Ambassador Leslie
ALEXANDER
embassy: 4th Floor, Rogers House, John
Kennedy Street, Port Louis
mailing address: use Embassy street address
telephone: (230) 208-9763 through 208-9767
FAX: 12301 208-9534
Flag: four equal horizontal bands of red (top),
blue, yellow, and green','6f5f35016da68b81c60b739c690b84d4d7c50544b8d6bf88aa1b35a07262ee74','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1fd435a2fd53b198d745c526e8af6221707e9c2105667b03292cb82e732e1d6',1994,'YT','Mayotte','government',659,'Names;
conventional long form: Territorial
Collectivity of Mayotte
conventional short form: Mayotte
Digraph: MF
Type: territorial collectivity of France
Capital: Mamouiznu
Administrative divisions: none (territorial
collectivity of France)
Independence; none (territorial collectivity
of France)
National holiday: Taking of the Ba.stille, 14
July (1789)
Constitution; 28 September 1958 (French
Constitution)
Legal system: French law
Sunbage: 1 8 years of age; universal
Executive branch:
chief of state: President Francois
MITTERRAND (since 21 May 1981)
head of government: Prefect Jean-Jacques
DERACQ (since NA); President of the General
Council Younoussa BAMANA (since NA
1976)
Legislative branch; unicameral
General Coum''il (Conseil General): elections
last held March 1991 (next to be held March
1996); results — percent of vote by party NA;
seats— ( 1 7 total) MPM 1 2. RPR 5
French Senate: elections last held on 24
September 1989 (next to be held September
1995); results — percent of vote by patty NA;
.seats — (I total) MPM 1
French National AssemSlv: elections last held
21 and 28 March 1993 (.text to be held 1998);
results— UDF-CDS .54.3%, RPR 44.3%;
seats — (1 total) UDF-CDS I
Judicial brarKh; Supreme Court (Tribunal
Superieurd''Appel)
Political parties and leaders: Mahoran
Popular Movement (MPM), Younoussa
BAMANA; Party for the Mahoran Democratic
Rally (PRDM). Daroueche MAOULIDA;
Mahoran Rally for the Republic (RPR),
Mansour KAMARDINE; Union for French
Democracy (UDF), Maoulida AHMED;
Center of Social Elemocrats (CDS).
Member of: FZ
Diplomatic represenutlon in US; none
(territorial collectivity of France)
US diplomatic representation; none
(territorial collectivity of France)
Flag: the flag of France is used','41249e880b29aaaba26f44ed69da1d93f9fe582b09974598b25777214f1f1385','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('124da393bb29a111e8863b828463c5fa919405da470416e34c855b4831deddda',1994,'FM','Micronesia, Federated States of','government',666,'Names;
conventional lon^ form: Federated States of
Micronesia
conventional xhortfonn: none
former: Kosrae, Ponape. Truk, and Yap
Districts (Trust Territory of the Pacific Islands)
Abbreviation: FSM
Digraph: FM
Type: constitutional government in free
asstK''iatioii with the US: the Compact of Free
Assix-''iation entered into force 3 November
1986
Capital: Koloniu (on the island of Pohnpei)
note: a new capital is being built about 10 km
southwest in the Palikir valley
Administrative divisions: 4* states; Kosrae.
Pohnpei. Chuuk (Truk), Yap
Independence: 3 November 1986 (from the
US-administered UN Trusteeship)
National holiday: PriK’laination of the
Federated States of Micronesia, 10 May ( 1 979)
ConstituUon: 10 May 1979
Legal system: based on adapted Trust
Territory laws, acts of the legislature.
muni''.''ipal. common, and customary laws
Sufflrage: 1 8 years of age; universal
Executive branch;
chief of slate and head of government:
President Bailey OUTER (since 2 1 May 1991);
Vice President Jacob NENA (since 21 May
1991); election last held II May 1991 (next to
beheld March 1995); results — President
Bailey OUTER elected president; Vice-
President Jacob NENA
cabinet: Cabinet
Legislative branch: unicameral
Ctmgress: elections last held on 5 March 1 99 1
(next to be held March 1993): results — percent
of vote NA: seats— -( 14 total)
Judicial branch; Supreme Court
Political parties and leaders: no formal
parties
Member of: AsDB, ESCAP. IBRD, ICAO.
IDA, IFC, IMF. ITU. SPARTECA. SPC. SPF,
UN. UNCTAD. WHO
Diplomatic representation in US:
chief of mission: Ambassador Jesse B.
MAREHALAU
chancen: 1 725 N Street NW, Washington. DC
20036
telephone: (202) 223-4383
FAX: (202) 223-4391
consulate(s) general: Honolulu and Tamuning
(Guam)
US diplomatic representation:
chief of mission: Ambassador Aurelia E.
BRAZEAL
embassy: address NA, Kulonia
mailing address: P. O. Box 1286, Pohnpei,
Federated States of Micronesia 9694 1
telephone- 691-320-2187
FAX,'' 691-320-2186
Flag; light blue with four white five-pointed
stars centeied; the stars are arranged in a
diamond pattern
Names:
conventional long form: none
conventional short form: Midway Islands
Digraph: MQ
Type: unincorporated territory of the US
administered by the US Navy, under Naval
Facilities Engineering Command, Pacific
Division; this facility has been operationally
closed since 10 September 1993 and is
currently being transferred from Pacific Fleet
to Naval Facilities Engineering Command via
a Memorandum of Understanding
Capital: none; administered from
Washington, DC
Flag: the US flag is used
Names:
conventional loii); form: Republic of Moldova
con'' ‘’ni tonal short fonn: Moldov,i
local loitji ft'' m: Republica Moldoveneasca
local .short form: none
former: Soviet .Socialist Republic of Moldova;
Moldavia
Digraph; MD
Type: republic
Capital; Chisinau
Administrative divisions; previousiydivided
into 4(i rayons, new districts fKissihle under
new constitution in 1994
independence: 27 August 1991 (from Soviet
Union)
National holiday: Independence Day, 27
August 1991
U''onstilution: old Soviet constitution
(adopted NA 1979) is still in effect hut has
been heavily amended during the past few
years; a new con.stitution is expected in 1994
Legal system; based on civil law system; no
Judicial review of legislative acts; does not
accept compulsory ICJ juri.sdiction but accepts
many UN and CSCE documents
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: President Mircea SNEsGUR
(since 3 September 1990); election Dst held 8
December 1 99 1 (next to be held N A 1 996),
results — Mircea SNEGUR ran unopposed and
won 98. 1 7%i of vote; note — President
SNEGUR was named executive president by
the Supreme Soviet on 3 September 1990 and
was confirmed by popular election on 8
December 1991
head of government: Prime Minister Andrei
SANOHALI (since 1 July 1992; reappointed 5
April 1994 after elections for new legislature)
cabinet: Council of Ministers; appointed by
the president on recommendation of the prime
minister
Legislative branch: unicameral
Parliament: elections last held 27 February
1994 (next to be held NA 1999); result.s —
percent by party NA; seats — (104 total)
Agrarian-Dentocratic Party 56,
Socialist/Yedinstvo Bloc 28, Peasants and
Intellectual Bloc 1 1, Christian Democratic
Popular Front 9
Judicial branch: Supreme Court
Political parties and leaders: Chri.stian
Democratic Popular Front (formerly Moldovan
Popular Front), iurie ROSCA, chairman:
Yedinstvo Intermovemem, V. YAKOVLEV,
chairman; Social Democratic Party, Oazu
NANTOl, chairman, two other chairmen;
Agrarian-Democratic Party, Dumitru
MCTPAN, chairman; Democratic Party,
Ciheorghe GHIMPU, chairman; Democratic
Labor Party. Alexandra ARSENI, chairman;
Reform Party, Anatol SELARU; Republican
Party, Victor PUSCAS; Socialist Party,
Valeriu SENIC. chairman; Communist Party,
Vladimir VORONIN
Other political or pressure groups; United
Council of Labor Collectives (UCLC). Igor
SMIRNOV, chainnan; Congre.ss of
Intellectuals, Alexandrvi MOSANU; The
Ecology Movement of Moldova (EMM), G.
MALARCHUK, chairman; The Christian
Democratic League of Women of Moldova
(CDLWM), L. LARI, chairman; National
Christian Party of Moldova (NCPM ), D.
TODIKE. M, BARAGA. V. NIKU. leaders;
The Peoples Movement Gagauz Khulky
(GKh), S. GULGAR, leader; The Democratic
Party of Gagau/ia ( DPG), G. SAVOSTIN.
chairman; The Alliance of Working People of
MoUlova (AWPM). G. POLOGOV. president;
Christian Alliance for Greater Romania: Stefan
the Great Movement; Liberal Convention of
Moldova; Asstniution of Victims of
Repression; Christian Democratic Youth
League
Member of: BSEC, CE (guest), CIS, CSCE,
EBRD, ECE, IBRD, ICAO, ILO, IMF,
INTELSAT (nonsignatory user), IOC, ITU,
NACC, UN, UNCTAD, UNESCO, UNIDO,
UPU, WHO, WIPO
Diplomatic representation in US:
chief of mission: Ambassador Nicolae TIU
chancery: 1 5 1 1 K Street NW, Room 329,
Washington, DC
telephone: (202) 783-3012 or -2807
US diplomatic representation;
chief of mission: Ambassador Mary C.
PENDLETON
embassy: Strada Alexei Mateevich #103,
Chisinau
mailing address: use embassy street address
telephone: 373 (2) 23-37-72 or 23-34-76
FAX: 7-0422-23-30-44
Flag: same color scheme as Romania — 3
equal vertical bands of blue (hoist side),
yellow, and red; emblem in center of flag is of
a Roman eagle of gold outlined in black with a
red beak and talons carrying a yellow cross in
its beak and a green olive branch in its right
talons and a yellow scepter in its left talons; on
its breast is a shield divided horizontally red
over blue with a stylized ox head, star, rose,
and crescent all in black-outlined yellow','f22c20934352df0fc7f541277350dc198d12e38a16ef111bf6e615062e54c236','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('99ce2af662b7633f8765294448faf8d3dbe123e048c2db1a18f739e5c5a3ad53',1994,'MC','Monaco','government',673,'Names:
conventional long form: FYincipality of
conventional .than form: Monaco
local long form: Principaute de Monaco
local short form: Monaco
Digraph: MN
Type: constitutional monarchy
Capital: Monaco
Administrative divisions: 4 quarters
(quartiers, singular — quarticr); Fontvieille, La
Condamine, Monaco-Ville, Monte-Carlo
Independence: 1 4 1 9 ( rule by the House of
Grimaldi)
National holiday: National Day, 19
November
Constitution: 17 December 1962
Legal sj''stem: based on French law; has not
accepted compulsory ICJ jurisdiction
Suffrage; 25 years of age; universal
Executive branch:
chief of state: Prince RAINIER 111 (.since NA
November 1949); Heir Apparent Prince
ALBERT Alexandre Louis Pierre (bom 14
March 1958)
head of government: Minister of .State Jacques
DUPONT (since NA 1991)
cabinet: Council of Government; under the
authority of the Prince
Legislative branch: unicameral
National Council (Conseil National):
elections last held on 24 January 1988 (next to
be held NA); results — percent of vote by party
NA; seat.s—( 18 total) UND 18
Judicial branch: Supreme Ttibunal
(Tribunal Supreme)
Political parties and leaders: National and
Democratic Union (UND); Democratic Union
Movement (MUD); Monaco Action;
Monegasque Socialist Party (PSM)
Member of: ACCT, CSCE, ECE, IAEA,
ICAO, IMF (observer), IMO, INMARSAT,
INTELSAT, INTERPOL, IOC, ITU, LORCS,
UN, UNCTAD, UNESCO, UPU, WHO,
WIPO
Diplomatic representation in US:
honorary consulate! s) general: Boston,
Chicago, Los Angeles, New Orleans, New
York, San Francisco, San Juan (Puerto Rico)
honorary consulate(s): Dallas, Palm Beach,
Philadelphia, and Washington
US diplomatic representation: no mission in
.Monaco, but the US Consul General in
Marseille, France, is accredited to Monaco
Flag: two equal horizontal bands of red (top)
and white; similar to the flag of Indonesia
which is longer and the flag of Poland which is
white (top) and red','483f7c683fba372b453810849d465f73fc05725b993720d96dfb1219abd6b749','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20756acd4a8957fa60bc1838b290712132025e0fc1a12b3281b1f10d63a53d5a',1994,'MS','Montserrat','government',680,'Names:
conventional lonii ftnin; none
conventional short form; Montserrat
Digraph; MH
Type: dependent territory of the UK
Capital; Plymouth
Administrative divisions: 3 parishes; Saint
Anthony, Saint Georges, Saint Peter
Independence: none (dependent territory of
the UK)
National holiday: Celebration of the
Birthday of the Queen (second Saturday of
June)
Constitution: present constitution came into
force 19 December 1989
Legal system: English common law and
statute law
Suffrage: 18 years of age: universal
Executive branch:
chief of state; Queen ELIZABETH 11 tsince 6
February 1952). represented by Governor
Frank SAVAGE (since NA February 1993)
lh\\i<l of I’o'' cnunent; Chief Minister Reuben T.
MEaDE (since October 1991 )
cabinet; Executive Council; consists of the
governor, the chief minister, three other
ministries, the attorney-general, and the
finance secretary
Legislative branch: uincameral
Legislative Council; elections last held on 8
October 1991 ; results — percent of vote by
party NA; seats — ( 1 1 total, 7 elected) NPP4.
NDP 1, PLM I, independent I
Judicial branch: Supreme Court
Political parties and leaders: National
Progressive Party (NPP) Reuben T. MEADE;
People''s Liberation Movement (PLM), Noel
TUITT; National Development Party (NDP),
Bertrand OSBORNE; Independent (IND),
Ruby BRAMBLE
Member of: CARICOM, CDB. ECLAC
(associate), ICFTU, INTERPOL (subbureau),
OECS, WCL
Diplomatic representation in US: none
(dependent territory of the UK)
US diplomatic representation: none
(dependent territory of the UK)
Flag: blue with the flag of the UK in the upper
hoist-,side quadrant and the Montserratian coat
of arms centered in the outer half of the flag;
the coat of arms features a woman standing
beside a yellow harp with her arm around a
black cro.ss','af667e0df8ce7ca92f73a110baec11bf1867266195cbe4b68799d16b116d62df','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1276c9ea30ac85bf41a54b6f500009e3de409092c1b9c7fc92e95be0104043a4',1994,'GI','Gibraltar','government',686,'Names:
conventional long fonn: Kingdom of Morocco
conventional short form: Morocco
local long fonn: Al Mamlakuhal Maghribiyah
local short form: At Maghrib
Digraph: MO
Type: constitutional monarchy
Capital: Rabat
Administrative divisions: 37 provinces and 5
municipalities* (wilayas. singular — wilaya);
Agadir, Al Hoceima, Azilal, Beni Mellal, Ben
.Slimane, Boulemane. Casablanca*. Chaouen,
El Jadida. El Kelaa des Srarhna, Er Rachidia,
Essaouira, Fes, Fes*. Figuig, Guelmim, Ifrane,
Kenitra, Khemisset, Khenifra, Khouribga,
Laayoune, Earache, Marrakech. Marrakech*,
Meknes. Meknes*, Nador. Ouarzazate, Oujda,
Rabat-Sale*. Safi, Settat, Sidi Kacem. Tanger.
Tan-Tan, Taounate, Taroudannt, Tata. Taza,
Tetouan, Tiznit
Independence: 2 March 1956 (from France)
National holiday: National Day. 3 March
(1961) (anniversary of King Hassan ll’s
accession to the throne)
Constitution: 10 March 1972, revised 4
September 1992
Legal system: based on Islamic law and
French and Spanish civil law .system; judicial
review of legislative acts in Constitutional
Chamber of Supreme Court
Suffrage: 21 years of age; universal
Executive branch:
chief of state: King HASSAN II (since 3
March 1961)
head of government: Prime Minister
Abdellatif FlLALl (since 29 May 1994)
cabinet: Council of Ministers; appointed by
the King
Legislative branch: unicameral
Chamber of Representatives iMttjlis Nawah):
elections last held 1 5 June 1 993 (direct popular
vote) and 17 September 1993 (indirect special
interest vote); next to be held NA 1999;
results — .seats (333 total), direct popular vote
(222 seats) USFP48. IP 43. MP 33, RNl 28,
UC 27, PND 14. MNP 14. PPS 6, PDl 3, SAP
2. PA 2, OADP 2; indirect special intere.st vote
(111 seats) UC 27. MP 18. RNl 13. MNP 11.
PND 10, IP 7. Party of Shura and Istiqlal 6,
USFP 4. PPS 4, CDT 4, UTM 3. UGTM 2.
SAP 2
Judicial branch: Supreme Court
Political parties and leaders:
opposition: Socialist Union of Popular Forces
(USFP), leader NA; Istiqlal Party (IP),
M''Hamed BOUCETTA; Party of Progress and
Socialism (PPS), Ali YATA; Organization of
Democratic and Popular Action (OADP).
leader NA
pro-government: Constitutional Union (UC),
Maati BOUABID; Popular Movement (MP),
Mohamed LAENSER; National Dem(x.''ratic
Party (PND). Mohamed Arsalane EL-JADIDI;
National Popular Movement, Mahjoubi
AHARDANE
independents; National Rally of Independents
(RNl). Ahmed OSMAN; Democracy and
Istiqlal Party (PDI), leader NA; Action Party
(PA), leader NA; Non-Obedience Candidates
(SAP), leader NA
labor unions and community organizations ( in¬
direct elections: DennKratic Confederabon of
Labor (CDT). leader NA; General Union of
Moroccan Workers (UGTM), leader NA;
Moroccan Union of Workers (UTM). leader
271
Morocco {continued)
NA; Party of Shura and Istiqial, leader NA
Member of: ABEDA, ACCT (associate),
AfDB, AFESD, AL, AMF, AMU, CCC,
EBRD. EGA. FAO, G-77, GATT, IAEA.
IBRD, ICAO. ICC, ICFTU, IDA. IDB, IFAD,
IFC, ILO, IMF, IMO, INTELSAT,
INTERPOL. IOC. lOM (observer), ISO, ITU.
LORCS, OAS (observer), NAM. OIC, UN,
UNAVEM II. UNCTAD, UNESCO. UNHCR.
UNIDO. UNOSOM, UNTAC, UPU, WHO,
WlPO, WMO. WTO
Diplomatic representation in US:
chief of mission; Ambassador Mohamed
BENAISSA
chancers: 1601 21st Street NW, Washington,
DC 20009;
telephone: (202) 462-7979 through 7982
FAX: (202) 265-0161
consutate(s) general: New York
US diplomatic representation:
chief of mission: Ambassador Marc C,
GINSBERG
emhassy; 2 Avenue de Marrakech, Rabat
mailing address: PSC 74, Box 00.^ APO AE
09718
telephone: 1212] (7) 76-22-65
FAY; (2121 (7) 76 .56-61
consulale(s) general: Casablanca
Flag: red with a green pentacle (five-pointed,
linear star) known as Solomon''s seal in the
center of the flag: green is the traditional color
of Islam','61cdc468f3d0a7d291f83d5b1bacf2df6ea99b0555c1f4cc3476c7152adba0e0','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6b862504e02aa363f619c8d0255ca36aed234a37e958b4d5959dffae8474018',1994,'MZ','Mozambique','government',690,'conventional short form: Mozambique
local long form: Republica Popular de
Mocumbique
local short form: Mucamhique
Digraph: MZ
Type: republic
Capital: Maputo
Administrative divisions: 1 0 provinces
(provincias, singular — provincia); Cabo
Delgado, Gaza, inhambane. Manica. Maputo.
Nampula. Niassa. Sofala, Tctc, Zambezia
Independence; 25 June 1975 (from Portugal)
National holiday: Independence Day. 25
June (1975)
Constitution: ,7() November I9W
Legal system: based on Portugue.se civil law
system and customary law
Suffrage: 1 8 years of age; universal
Executive b anch:
chief of suiu: Pre.sident Joaquim Alberto
CHi.SSANO (since 6 November 1986)
head of government: Prime Minister Mario da
GracaMACHUNGO (since 17 July 1986)
cabinet: Cabinet
Legislative branch: unicameral Assembly of
the Republic (Asseinbleia da Republica): draft
electoral law provides for periodic, direct
presidential and Assembly elections
Judicial branch; Supreme Court
Political parties and leaders: Front for the
Liberation of Mozambique (FRELIMO).
Joaquim Alberto CHiSSANO, chairman;
formerly a Marxist organization with close ties
to the USSR; FRELIMO was the only legal
party befoie .70 November 1990. when the new
Constitution went into effect establishing a
multiparty system
note: under the terms of the 1992 peace
accords multiparty elections are scheduled for
October 1994; 1 1 parties, including the
Mozambique National Resistance
(RENAMO), Alfonso DHLAKAMA.
president, are registered to participate
Member of: ACP. AfDB. CCC, ECA, FAO.
FLS. 0-77, GATT. IBRD. ICAO. IDA, IFAD,
IFC, ILO. IMF. INMARSAT. IMO,
INTELSAT. INTERPOL. IOC. ITU. LORCS,
NAM. OAU, OIC. SADC. UN. UNCTAD,
UNESCO. UNIDO. UPU, WHO. WMO
Diplomatic representation In US:
chief of mission: Ambassador Hipolito Pereira
Zozimo PATRICIO
chancery; Suite 570, 1990 M Street NW,
Washington. DC 20036
telephone; (202) 293-7146
FAX: (202) 8.75-0245
US diplomatic representation:
chief of mission: Ambassador Dennis JETT
embassy: Avenida Kenneth Kuanda, 1 93
Maputo
mailing address; P. O. Box 783, Maputo
telephone: [2581 (1) 49-27-97
FAX; [2581(1)49-01-14
Flag: three equal horizontal bands of green
(lop), black, and yellow with a red iso.sccles
triangle based on the hoist side; the black band
is edged in white: centered in the triangle is a
yellow five-pointed star bearing a crossed rifle
and hoe in black superimposed on an open
white book
Names:
conventional long form: United Republic of
Tanzania
conventional short form: Tanzania
fortner: United Republic of Tanganyika and
Zanzibar
Digraph: TZ
Type; republic
Capital: Dares Salaam
note: some government offices have been
transferred to Dodoma, which is planned as the
new national capital by the end of the 1990s
Administrative divisions: 25 regions;
Arusha, Dar es Salaam, Dodoma, Iringa,
Kigoma, Kilimanjaro, Lindi, Mara, Mbeya,
Morogoro, Mtwara, Mwanza, Pemba North,
Pemba South, Pwani. Rukwa, Ruvuma,
Shinyanga, Singida, Tabora, Tanga, Zanzibar
Central/South. Zanzibar North, Zanzibar
Urban/West, Ziwa Magharibi
Independence: 26 April 1964; Tanganyika
became independent 9 December 1961 (from
UN trusteeship under British administration);
Zanzibar became independent 19 December
1963 (from UK); Tanganyika united with
Zanzibar 26 April 1964 to form the United
Republic of Tanganyika and Zanzibar;
renamed United Republic of Tanzania 29
October 1964
National holiday: Union Day, 26 April
(1964)
Constitution: 25 April 1 977: major revisions
October 1984
Legal system; based on English common law;
judicial review of legislative acts limited to
matters of interpretation: has not accepted
compulsory IC) jurisdiction
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: President Ali Hassan MWINYI
(since 5 November 1985); First Vice President
John MALECELA (since 9 November 1990);
Second Vice President and President of
Zanzibar Salmin AMOUR (since 9 November
1990) election last held 28 October 1990 (next
to be held NA October 1995); results — Ali
Hassan MWINYI was elected without
opposition
head of government: Prime Minister John
MALECELA (since 9 November 1990)
cabinet: Cabinet; appointed by the president
from the National Assembly
Legislative branch; unicameral
National Assembly (Bunge): elections last held
28 October 1990 (next to be held NA October
1995); results — CCM was the only party;
seats — (241 total. 168 elected) CCM 168
Judicial branch: Court of Appeal. High
Court
Political parties and leaders: Chama Cha
Mapinduzi (CCM or Revolutionary Party), Ali
Hassan MWINYI: Civic United Front (CUF),
James MAPALALA; National Committee for
Constitutional Reform (NCCK), Mabere
MARANDO; Union for Multiparty
Democracy (UMD), Abdullah FUNDIKIRA:
Chama Cha Demokrasia na Maendeleo
(CHADEMA). Edwin l.M. MTEI, chairman
Member of: ACP, AfDB. C, CCC. EADB,
ECA, FAO, FLS, G-6, G-77. GATT, IAEA,
IBRD, ICAO, IDA, IFAD. IFC, ILO, IMF.
IMO, INTELSAT. INTERPOL, IOC. ISO.
387
Tanzania (continued)
ITU, LORCS, NAM, OAU, SADC, UN,
UNCTAD UNESCO, UNHCR. UNIDO,
UPU, WCL. WHO, WIPO, WMO, WTO
Diplomatic representation in US;
chief of mission: Amba.ssador Charles
Musama NYIRABU
chancery: 2 1 39 R Street NW, Washington, DC
20008
telephone: (202) 939-61 25
FAX: (202) 797-7408
US diplomatic representation:
chief of mission: Ambassador Peter Jon DE
VOS
embassy: 36 Laibon Road (off Bagamoyo
Road), Dar es Salaam
mailing address: P. O. Box 9123, Dares
Salaam
telephone: [255] (5 1)660 10 through 13
FAY.- [2.55] (51)66701
Flag: divided diagonally by a yellow-edged
black band from the lower hoist-side comer:
the upper triangle (hoist side) is green and the
lower triangle is blue','f568c83448c5e037033beb75bdf91292dffd78ddf866b849c9881ec6ecfe345b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fee7b49e577f72ae201734ea71c4b506702c527556d1fe03093f0a3adeaea39d',1994,'NR','Nauru','government',700,'Names:
conventional lon.itform: Republic of Nauru
conventional short form: Nauru
former; Pleasant Island
Digraph: NR
Type: republic
Capital: no official capital; government
offices in Yaren District
Administrative divisions; 1 4 districts; Aiwo,
Anabar, Anetan. .Anibarc. Baiti. Boe, Buada,
Denigomodu, Ewa, ljuw, Meneng, Nibok.
Uaboe, Yaren
Independence; 31 January 1968 (from UN
trusteeship under Australia. New Zealand, and
UK)
National holiday: Independence Day, 31
January (1968)
Constitution: 29 January 1968
Legal system: own Acts of Parliament and
British common law
Suffrage: 20 years of ape; universal and
compulsory
Executive branch:
chief of state and head ti/ .government:
President Bernard DOW|Y(XiO (since 12
December 1989); election last held 19
November 1992 (next to be held NA
Navassa Island
(territory of the USi
November 1995): results — Bernard
DOWIYOGO elected by Parliament
cabinet; Cabinet: appointed by the president
from the parliament
Legislative branch: unicameral
Parliament; elections last held on 14
November 1992 (next to be held NA
November 1 995): results — percent of vote N A;
seats — ( 1 8 total) independents 1 8
Judicial branch: Supreme Court
Political parties and leaders: none
Member of: AsDB. C (special). ESCAP.
ICAO. INTELSAT (nonsignatory user).
INTERPOL. ITU. SPARTECA. SPC. SPF.
UPU
Diplomatic representation in US:
consulate(s); Agnna (GuanO
US diplomatic representation: the US
Ambassador to Australia is accredited to Nauru
Flag: blue with a narrow, horizontal, yellow
stripe across the center and a large white 12-
pointed star below the stripe on the hoist side:
the star indicates the country''s location in
relation to the Equator (the yellow stripe) and
the 1 2 points symbolize the 12 original tribes cf','a88b35b0187508cada128a48712be5c2e4265586db9355441c4e3f0f5720ea20','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da731acccce33499a68cc83623aa399d7a7329974f8c6d2f6d009b62f89a43f3',1994,'NP','Nepal','government',707,'Names:
conventional long form: Kingdom of Nepal
conventional short form: Nepal
Digraph: NP
Type: parliamentary democracy as of 1 2 May
1991
Capital: Kathmandu
Administrative divisions: 14 zones (anchal.
singular and plural); Bagmati, Bheri,
Dhawalagiri, Gandaki, Janakpur. Karnali.
Kosi. Lumbini, Mahakali, Mechi, Narayani.
Rapti, Sagarmatha, Seti
Independence: 1768 (unified by Prithvi
Narayan Shah)
National holiday: Birthday of His Majesty
the King, 28 December ( 1 945)
278
Constitution: 9 November 1990
Legal system: based on Hindu legal concepts
and English common law; has not accepted
compulsory ICJ jurisdiction
Sufft^ge; 1 8 years of age; universal
Executive branch;
head of government: Prime Minister Girija
Prasad KOIRALA (since 29 May 1991)
chief of state: King BIRENDRA Bir Bikram
Shah Dev (since 31 January 1972, crowned
King 24 February 1985); Heir Apparent Crown
Prince DIPENDRA Bir Bikram Shah Dev, son
of the King (bom 21 June 1971)
cabinet: Cabinet; appointed by the king on
recommendation of the prime minister
Legislative branch: bicameral Parliament
National Council: consists of a 60-member
body, 50 appointed by House of
Representatives and 10 by the King
House of Representatives: elections last held
on 12 May 1991 (next to be held May 1996);
results— NCP 38%, CPN/UML 28%, NDP/
Chand 6%, UPF 5%, NDP/Thapa 5%, Terai
Rights Sadbhavana Party 4%, Rohit 2%, CPN
(Democratic) I %, independents 4%, other 7%;
seats— (205 total) NCP 1 10, CPN/UML 69,
UPF 9, Terai Rights Sadbhavana Party 6, NDP/
Chand 3, Rohit 2, CPN (Democratic) 2, NDP/
Thapa I, independents 3; note — the new
Constitution of 9 November 1990 gave Nepal a
multiparty democracy system for the first time
in 32 years
Judicial branch: Supreme Court (Sarbochha
Adalat)
Political parties and leaders: Nepali
Congress Party (NCP), president Krishna
Prasad BHATTARAl, Prime Minister Girija
Prasad KOIRALA, Supreme Leader Ganesh
Man SINGH; The Conservative National
Democratic Party (NDP/Thapa), Surya
Bahadur THAPA; Communist Party of Nepal/
United Marxist and Leninist (CPN/UML),
Man Mohan ADHIKARI; Terai Rights
Sadbhavana (Goodwill) Party, Gajendra
Narayan SINGH; United People''s Front
(UPF), Lila Mani POKHREL; Nepal Workers
and Peasants Party (NWPP), Narayan Man
BIJUKCHHE; National Democratic Party/
Chand (NDP/Chand), Lokendra Bahadur
CHAND; Rohit Party, N. M. BIJUKCHHE;
Communist Party of Nepal (Democratic-
Manandhar), B. B. MANANDHAR
Other political or pressure groups;
numerous small, left-leaning student groups in
the capital; several small, radical Nepalese
antimonarchist groups
Member of: AsDB, CCC, CP, ESCAP, FAQ.
G-77, IBRD, ICAO, IDA. IFAD, IFC, ILO,
IMF, IMO, INTELSAT. INTERPOL, IOC,
ISO (correspondent). ITU, LORCS, NAM,
SAARC, UN, UNCTAD, UNESCO, UNIDO.
UNIFIL, UNPROFOR, UNTAC, UPU,
WFTU. WHO. WMO. WTO
Diplomatic representation in US:
chief of mission: (vacant)
chancery: 2131 Leroy Place NW, Washington.
DC 20008
telephone: (202) 667-4550
consulate(s) general: New York
US diplomatic representation:
chief of mission: Ambassador Sandra
VOGELGESANG
embassy: Pani Pokhari, Kathmandu
mailing address: use embassy street address
telephone: [977] ( I ) 4 1 1 1 79 or 4 1 27 1 8,
411613.413890
FAX: [977] (1)419963
Flag: red with a blue border around the unique
shape of two overlapping right triangles; the
smaller, upper triangle bears a white stylized
moon and the larger, lower triangle bears a
while 12-pointed sun','8bc4077bd2080b011b3bce6085cf630795a31e2841468d3fc304de3490f1f992','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb33d884e75d6b4ccfa8255e3bcbb2565005df29c88451b566803d9b8b31e340',1994,'TK','Tokelau','government',710,'Independence: 26 September 1907 (from
UK)
National holiday: Waitangi Day, 6 February
( 1 840) (Treaty of Waitangi established British
sovereignty)
Constitution: no formal, written constitution;
consists of various documents, including
certain acts of the UK and New Zealand
Parliaments: Constitution Act 1986 was to
have come into force 1 January 1987. but has
not been enacted
Legal system: based on English law. with
special land legislation and land courts for
Maoris; accepts compulsory ICJ jurisdiction,
with reservations
Sufh''nge: 1 8 years of age; universal
Executive branch;
chief of mule; Queen ELIZABETH II (since 6
February I9.‘i2), represented by Governor
General Dame Catherine TIZARD (since 12
December 1990)
hecui of fioveniment: Prime Minister James
BOLGER (since 29 October 1990); Deputy
Prime Minister Donald McKlNNON (since 2
November 1990)
cuhinet; Executive Council; appointed by the
governor general on recommendation of the
prime minister
Legislative branch: unicameral
House of RepreseMuUves: (commonly culled
Parliament) elections last held on 6 November
199.^ (next to be held NA November 1996);
results— NP .^5.29f. NZLP Alliance
18,.1''X . New Zealand First 8..19(^; seats — (99
total) NP .SO. NZLP 4.S. Alliance 2. New
Zealand First Party 2
Judicial branch: High Court. Court of
Appeal
Political parties and leaders: National Party
(NP; government). James BOLGER: New
Zealand Labor Party (NZLP; opposition).
Helen CLARK; Alliance. Jim ANDERTON;
Democratic Party. Dick RYAN; New Zealand
Liberal Party. Hanmish MACINTYRE and
Gilbert MYLES; Gmen Party, no official
leader; Mana Motuhake. Martin RATA;
Socialist Unity Party (SUP; pro-Soviet),
Kenneth DOUGLAS; New Zealand First.
Winston PETERS
note; the New Labor, Democratic, and Mana
Motuhake parties formed a coalition called the
Alliance Party, Jim ANDERTON, president, in
September I W1 ; the Green Party joined the
coalition in May 1992
Member of: ANZUS (US suspended security
obligations to NZ on 1 1 August 1986), APEC,
AsDB, Australia Group. C. CCC. CP, C(X^OM
(cooperating). EBRD. ESCAP, FAO, GATT,
IAEA. IBRD. ICAO. ICFTU. IDA. lEA,
IFAD, IFC, ILO, IMF, IMO, INMARSAT,
INTELSAT, INTERPOL. IOC, lOM
(observer), ISO. ITU, LORCS, MTCR, NAM
(guest), OECD, PCA, SPARTECA. SPC. SPF,
UN, UNAVEM II, UNCTAD. UNESCO,
UNIDO, UNOSOM, UNPROFOR, UNTAC,
UNTSO. UPU, WHO, WIPO, WMO
Diplomatic representation in US:
chief of mission; Ambassador Lionel John
wdoD
chwwery; .^7 Observatory Circle NW,
Washington, EXJ 20008
telephone; (202) 328-4800
consiilatefsl general; Los Angeles
US diplomatic representation:
chief of mission; Ambassador Josiah
BEEMAN
embassy; 29 Fitzherbert Terrace, Thomdon,
Wellington
mailing address; P. O. Box 1 190, Wellington:
PSC467. Box I.FPOAP 96531-1001
telephone; |64| (4) 472-2068
FAX; [64] (4) 472-3537
consulate(s) general: Auckland
Flag: blue with the flag of the UK in the upper
hoist-side quadrant with four red five-pointed
stars edged in white centered in the outer half
of the flag; the stars repre.sent the Southern
Cross constellation','c8ad7631c3855596ef0913b18cf7bd89bc3a65c6f26a5b1254cc159f50a27bb4','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1e58a35a82ee14f0e82489bf94d0b238ff5dccb0b9dd17aa6a6fc03ec9036d3',1994,'NI','Nicaragua','government',717,'Names;
conventional long form: Republic of
conventional short fortn: Nicaragua
local long form; Republicudc Nicaragua
local .short form; Nicaragua
Digraph; NU
Type: republic
Capital: Managua
Administrative divisions: 17 departments
(departamentos, singular — depariamemo):
Boaco. Carazo. Chinandega, (Thontules. Esteli.
Granada, Jinotega. Leon. Madriz, Managua.
Masaya. Matagalpa, North Atlantic Coast
Autonomous Zone (RAAN), Nueva Segovia,
Rio San Juan, Rivas, South Atlantic Coast
Autonomous Zone (RAAS)
Independence: 15 September 1821 (from
Spain)
287
Nicaragua (continued)
National holiday: Independence Day. 1.^
September (1821)
Consllluilon: 9 January 1987
Legal sy.ilcm: civil law system: Supreme
Court may review administrative acts
.Sumrage: I6yearsurage:univers.'')l
Executive branch:
chief ofstiile iiiul lietitl o/fiovenmient:
President Violeta Barrios de CHAMORRO
(since 2.^ April 1990); Vice President Virgilio
GODOY Reyes (since 2.^ April 1990); election
last held on 25 February 1 990 (next to be held
November 1996); results — Violeta Barrios de
CHAMORRO (UNO) .Sd.T''if. Daniel
ORTEGA Saavedra (FSLN) dO.gOf . other
4,5%
aihinei: Cabinet
Legislative branch: unicameral
Naiiomil Assembly lAsumb/en Nacional);
elections last held on 25 February 1990 (next to
be held November 1996); results — UNO
5.U9<''^. FSLN 40.8%, PSC 1.6%. MUR 1.0%;
seats— (92 >otal) UNO 41. FSLN 59.
“Centrist" (Dissident UNO)l2
Judicial branch: Supreme Court (Code
Suprema)
Political parties and leaders:
ruliiia coalition; National Opposition Union
(UNO) is a lO-party alliancv slerate
parties; National Conservative Party (PNC).
Silviano MATAMOROS Lacayo. president;
Liberal Constitutionalist Party (PLC). Jose
Ernesto SOMARRIBA. Arnold ALEMAN;
Christian Democratic Union (UDC), Luis
Humbeilo GUZMAN, Agustin JARQUIN,
Azucena FERREY. Roger MIRANDA,
Francisco MAYOROA; National Dennx-ratic
Movement (MDN), Roberto URROZ; National
Action Party (PAN). Duilio BALTODANO;
UNO — hardline panics: Independent Liberal
Party (PLI). Will''redo NAVARRO.Virgilio
GODOY Reyes; Sixrial Democratic Party
(PSD). Guillermo POTOY. Alfredo CESAR
Aguirre, secretary general; Conservative
Popular Alliance Party (PAPC). Myriam
ARGUELLO; Communist Party of Nicaragua
(PCdeN). Eli ALTIMIRANO Perez; Neo-
Liberal Party (PALI), Adolfo GARCIA
Esquivel
opposition parties; Sandinista National
Liberation Front (FSLN), Daniel ORTEGA;
Central American Unionist Party (PUCA),
Blanca ROJAS; Democratic Conservative
Party of Nicaragua (PCDN). Jose BRENES;
Liberal Party of National Unity (PLUIN).
Eduardo CORONADO; Movement of
Revolutionary Unity (MUR). Francisco
SAMPER; Social Christian Party (PSC). Erick
RAMIREZ; Revolutionary Workers'' Party
(PRT), Bonifacio MIRANDA; Social
Conservative Party (PSCX"). Fernando
AGUERRO; Popular Action Movement —
Marxist-Leninist(MAP-ML). Isidro TELLEZ;
Popular Social Christian Party (PPSC).
Mauricio DIAZ
Other political or pressure groups:
National Workers Front (FNT) is a Sandinista
umbrella group of eight labor unions:
Sandinista Workers'' Central (CST); Farm
Workers As.sociation (ATC); Health Workers
Federation (FETASALUD); National Union of
Employees (UNE); National Association of
Educators of Nicaragua (ANDEN); Union of
Journalists of Nicaragua (UPN); Heroes and
Martyrs Confederation of Professional
As.sociations (CONAPRO); and the National
Union of Farmers and Ranchers (UNAG);
Permanent Congress of Workers (CPT) is an
umbrella group of four non-Sandinista labor
unions: Confederation of Labor Unification
(CUS); Autonomous.Nicaraguan Workers''
Central (CTN-A): Independent General
Confederation of Labor (CGT-I); and Labor
Action and Unity Central (CAUS); Nicaraguan
Workers'' Central (CTN) is an independent
labor union: Superior Council of Private
Enterprise (COSEP) is a confederation of
business groups
Member of: BCIE. CACM. ECLAC. FAO.
G-77. GATT. lADB, IAEA. IBRD. ICAO,
ICFTU. IDA. IFAD. IFC. ILO. IMF. IMO.
INTELSAT. INTERPOL, IOC. lOM. ITU.
LAES, LAIA (observer), LORCS. NAM,
OAS. OPANAL. PC A. UN, UNCTAD.
UNESCO. UNHCR. UNIDO. UPU. WCL.
WFTU. WHO, WIPO. WMO. WTO
Diplomatic representation In US:
chief of missitm; Ambassador Roberto
MAYORGA Cortes
chancety; 1627 New Hampshire Avenue NW,
Washington, DC 20(X)9
telephone; (202) 9,59-6570
consiiUitetsl general; Houston. Los Angeles,
Miami. New Orleans. New York. San
Francisco
US diplomatic representation;
chief of mission; Ambassador John MAISTO
embassy; Kilometer 4.5 Carretera Sur.,
Managua
mailing address; APO AA 3402 1
telephone; |.505| (2) 666010 or 666013,
666015 through 18, 666026. 666027. 666032
through ,34
FAX; 1.5051(2)666046
Flag: three equal horizontal bands of bluv
(top), white, and blue with the national coat of
arms centered in the white band; the coat of
arms features a triangle encircled by the words
REPUBLICA DE NICARAGUA on the top
and AMERICA CENTRAL on the bottom;
similar to the tlag of El Salvador, which
features a round emblem encircled by the
words REPUBLICA DE EL SALV ADOR EN
LA AMERICA CENTRAL centered in the
white hand; also similar to the flag of
Honduras, which has five blue stars arranged in
an X pattern centered in the white band','92e93476a2db7e72441a140bb23644d7919b3398301919ac199634c064d8d0d2','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a57669c52a419931fa9534504553ea39057118d2c7256f5fc8c0cd5c4673595b',1994,'NU','Niue','government',726,'Names:
conventional long form: none
conventional short form: Niue
Digraph: NE
Type: self-governing territory in free
association with New Zealand; Niue fully
responsible for intern"! affairs; New Zealand
retains responsibility for external affairs
Capital: Alofi
Administrative divisions: none
Independence: 1 9 October 1 974 (becane a
self-governing territory in free association with
New Zealand on 19 October 1974)
National holiday: Waitangi Day, 6 February
(1840) (Tr>. "y of Waitangi established British
.sovereignty)
Constitution: 19 October 1974 (Niue
Constitution Act)
Legal system: English common law
Suffrage: 18 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II (since 6
February 1952), represented by New Zealand
Representative Kurt MEYER (since NA)
head of government: Premier Frank F. LUl
(since 12 March 1993; Acting Premier since
December 1992)
cabinet: Cabinet; consist.s of the premier and
three other ministers
Legislative branch: unicameral
Legislative Assembly: elections last held on 6
March 1993 (next to be held NA 1996);
results — percent of vote NA: seats — (20 total,
6 elected)
Judicial branch: Appeal Court of New
Zealand, High Court
Political parties and leaders: Niue Island
Party (NIP), Young VIVIAN
Memter of: ESCAP (associate), INTELSAT
(signatory user), SPARTECA, SPC, SPF
Diplomatic representation In LS: none
(self-governing territory in free association
with New Zealand)
US diplomatic representation: none (self-
governing territory in free as.sociation with
New 2^aland)
Flag: yellow with the flag of the UK in the
upper hoi.st-side quadrant; the flag of the UK
bears five yellow five-pointed stars — a large
one on a blue dii.k in the center and a smaller
one on each arm of the bold red cross','a845b306d107874de93c7073ec2166e9dc4bf1e38a36ddf7f1d969ea8fb870ed','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90a284a16fb9699c287190941d80ac119dc88ad51df1f4307a21b67d56a3ac62',1994,'NF','Norfolk Island','government',733,'Names:
conventional long form: Territory of Norfolk
Island
conventional short form: Norfolk isiund
Digraph: NF
Type: territory of Australia
Capital: Kingston (administrative center):
Burnt Pine (commercial center)
Administrative divisions: none (territory of
Australia)
Independence: none (territory of Australia)
National holiday: Pitcairners Arrival Day
Anniversary. 8 June (1856)
Constitution: Norfolk Island Act of 1979
Legal system: wide legislative and executive
responsibility under the Norfolk Island Act of
1979; Supreme Court
Suffrage: 1 8 years of age; universal
Executive branch;
chief of .state: Queen ELIZABETH II (since 6
February 1952), repre.senled by Administrator
A. G. KERR (since NA April 1992) who is
appointed by the Governor General of','49a0b3a848554ed4e9f8551f1c0ebbfc173db4dbfb0600a60794dd4c5f11fc98','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79391e33ba034685b8dbb63e488eec200db994c4b6311f832cc8fabdf4312bf9',1994,'MP','Northern Mariana Islands','government',738,'Names:
conventional long form: Commonwealth of
the Northern Mariana Islands
conventional .short form: Northern Mariana
Islands
Digraph: CQ
Type: commonwealth in political union with
the US: self-governing with locally elected
governor, lieutenant governor, and legislature:
federal funds to the Commonwealth
administered by the US Department of the
Interior, Office of Territorial and International
Affairs
Capital: Saipan
Administrative divisions: none
Independence: none (commonwealth in
political union with the US)
National holiday: Commonwealth Day. 8
January (1978)
Constitution: Covenant Agreement effective
.3 November 1986 and the Constitution of the
Commonwealth of the Northern Mariana
Islands
295
(continued)
Legal fysitiii: baised on US syMcm except for
custom!), wages, immigration laws, and
taxation
SvIOage: 1 8 years of age: universal:
indigenous inhabitants are US citizens but do
not vote in US presidential electitms
Executive bra^:
chief of state: President William Jefferson
CLINTON (since 20 January 1993): Vice
President Albert GORE, Jr. (since 20 January
1993)
head of government; Governor Lorenzo I.
DeLeon GUERRERO (since 9 January 1990):
Lieutenant Governor Benjamin T.
MANGLONA (since 9 January 1990): election
last held in NA November 1989 (next to be
held NA November 1993): results — Lorenzo I.
DeLeon GUERRERO. Republican Party, was
elected governor
Legislative brauch: bicameral Legislature
Senate: elections la.st held NA November 1991
(next to be held NA November 1993):
results — percent of vote by party NA: seats —
(9 total) Republicans 6. Democrats 3
house of Representatives: elections last held
NA November 1991 (next to be held NA
November 1993): results — percent of vote by
party NA: seats — (18 total) Republicans 10.
Democrats 6. Independent 2
VS House of Representatives: the
Commonwealth does not have a nonvoting
delegate in Congress: instead, it has an elected
official "resident representative" located in
Washington. DC: seats— ( I total) Republican
(JuanN.BABAUTA)
Judicial braiKh: Commonwealth Supreme
Court, Superior Court, Federal District Court
Political parties and leaders: Republican
Party, Governor Lorenzo GUERRERO:
Democratic Party, Carlos SHODA, chairman
Member of: ESCAP (associate). SPC
Flag: blue with a white five-pointed star
superimposed on the gray silhouette of a latte
Slone (a traditional foundation stone used in
building) in the center','94ab7b54578d96a67991084d679452b0dc72af8b3a401c7745c0943676455d48','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cbf491da871327c408df9016610688601c38e5f9a43265a92abad8e224f48c7',1994,'PH','Philippines','government',746,'Names:
CO ''ntional long form: Trust Territory of the
Pac c Islands
conventional short form; none
note; may change to Republic of Palau after
independence: the native form of Palau is
Belau and is sometimes used incorrectly in
English and other languages
Digraph; PS
Type: UN trusteeship administered by the US
note; constitutional government signed a
Compact of Free Association with the US on
1 0 January 1 986. which was never approved in
a series of UN-observed plebiscites; until the
UN trusteeship is terminated with entry into
force of the Compact. Palau remains under US
administration as the Palau District of the Trust
Territory of the Pacific Islands; administrative
authority resides in the Department of the
Interior and is exercised by the Assistant
Secretary for Territorial and International
Affairs through the Palau Office, Trust
Territory of the Pacific Islands. J. Victor
HOBSON Jr., Director (since 16 December
1990)
Capita): Koror
note; a new capital is being built about 20 km
northeast in eastern Babeithuap
Administrative divisions: there are no first-
order administrative divisions as defined by the
US Government, but there are 16 states:
Aimeliik, Airai. Angaur, Kayangel, Koror,
Melekeok, Ngaraard, Ngordmau,
Ngaremlengui, Ngatpang, Ngchesar,
Ngerchelong, Ngiwa), Peleliu, Sonsorol. Tobi
Independence: the last polity remaining
under the US-administered UN trusteeship
following the departure of the Republic of the
Marshall Islands, the Federated States of
Micronesia, and the Commonwealth of the
Northern Marianas from the trusteeship;
administered by the Office of Territorial and
International Affairs. US Department of
Interior
National holiday: Constitution Day. 9 July
(1979)
Constitution: I January 1981
Legal system: based on Trust Territory laws,
acts of the legislature, municipal, common, and
customary laws
Suithige: 1 8 years of age; universal
Executive branch:
chief of state and head of government;
President Kuniwo NAKAMURA (since 1
January 1993), Vice-President Tommy E.
REMENGESAU Jr. (since 1 January 1993):
election last held on 4 November 1992 (next to
be held NA November 1996); results —
Kuniwo NAKAMURA 50.7%, Johnson
TORIBIONG 49.3%
Legislative branch; bicameral Parliament
(Olbiil Era Kelulau or OEK)
Senate; elections last held 4 November 1992
(next to be held NA November 1 996);
result.s — percent of vote by party NA: seats —
( 14 total); number of seats by party NA
House of Delegates; elections last held 4
November 1992 (next to be held NA
November 19%); results — percent of vote by
party NA; seats — ( 16 total); number of seats by
party NA
Judicial branch: Supreme Court. National
Court, Court of Common Pleas
Member of; ESCAP (associate). SPC, SPF
(observer)
Diplomatic representation in US: trust
territory of the UN odministered by the US:
Administrative Officer Charles UONG, Palau
Liaison Office, 444 North Capitol Street NW,
Suite 308, Washington. DC 20001
US diplomatic representation:
director; US Liaison Officer Lloyd W. MOSS
liaison office; US Liaison Office at Top Side,
Neeriyas, Koror
mailing address; P.O. Box 6028, Koror, PW
96940
telephone; (680) 488-2920; (680) 488-291 1
Flag: light blue with a large yellow disk
(representing the moon) shifted slightly to the
hoist side
Digraph; ZN
Names:
conventional long form: none
conventional short form; Paracel Islands
Digraph: PF
Names:
conventional long form; Republic of the
conventional short form: Philippines
local long form: Republika ng Pilipinas
local short form: Pilipinas
Digraph: RP
Type: republic
Capital: Manila
Administrative divisions: 72 provinces and
61 chartered cities*; Abra, Agusan del Norte,
Agusan del Sur, Akian, Albay, Angeles*,
Antique, Aurora, Bacolod*, Bago*. Baguio*,
Bais*. Basilan, Basilan City*, Bataan, Batanes,
Batangas, Batangas City*, Benguet, Bohol,
Bukidnon. Bulacan. Butuan*. Cabanatuan*.
Cadiz*. Cagayan, Cagayan de Oro*.
Calbayog*, Caloocan*, Camarines Norte,
Camarines Sur, Camiguin, Canlaon*, Capiz.
Catanduanes, Cavite, Cavite City*, Cebu,
Cebu City*. Cotabato*, Dagupan*, Danao*,
Dapitan*, Davao City* Davao, Davao del Sur,
Davao Oriental. Dipolog*, Dumaguete*.
Eastern Samar, General Santos*, Gingoog*.
Ifugao, Iligan*, tiocos Norte, Ilocos Sur, Iloilo,
Iloilo City*, Iriga*, Isabela, Kalinga-Apayao.
La Carlota*, Laguna, Lanao del Norte, Lanao
del Sur, Laoag*, Lapu-Lapu*, La Union,
Legaspi*, Leyte, Lipa*, Lucena*.
Maguindanao, Mandaue*, Manila*, Marawi*,
Marinduque, Masbate, Mindoro Occidental,
Mindoro Oriental, Misamis Occidental,
Misamis Oriental, Mountain, Naga*. Negros
Occidental, Negros Oriental. North Cotabato,
Northern Samar, Nueva Ecija, Nueva Vizcaya.
Olongapo*, Ormoc*, Oroquieta*, Ozamis*,
Pagadian*. Palawan, Palayan*, Pampanga,
Pangasinan, Pasay*. Puerto Princesa*,
Quezon. Quezon City*, Quirino, Rizal,
Romblon, Roxas*, Samar, San Carlos* (in
Negros Occidental). San Carlos* (in
Pangasinan). San Jose*, San Pablo*, Silay*,
Siquijor. Sorsogon. South Cotabato, Southern
Leyte, Sultan Kudarat, Sulu, Surigao*, Surigao
del Norte, Surigao del Sur, Tacloban*.
Tagaytay*, Tagbilaran*. Tangub*, Tarlac,
Tawitawi, Toledo*, Trece Martires*,
Zambales, Zamboanga*. Zamboanga del
Norte, Zamboanga del Sur
Independence: 4 July 1946 (from US)
National holiday: Independence Day. 12
June ( 1 898) (from Spain)
Constitution: 2 February 1987, effective 1 1
February 1987
Legal system: based on Spanish and Anglo-
American law; accepts compulsory ICJ
jurisdiction, with reservations
Suffirage: 15 years of age; universal
Executive branch:
chief of state and bead of government:
President Fidel Valdes RAMOS (since 30 June
1992); Vice President Joseph Ejercito
ESTRADA (since 30 June 1992); election last
held 1 1 May 1992 (next election to be held NA
May 1998); results — Fidel Valdes RAMOS
won 23.6% of votes, a narrow plurality
cabinet; Executive Secretary; appointed by the
president with the consent of the Commission
of Appointments
Legislative branch: bicameral Congress
(Kongreso)
Senate (Senado); elections last held 1 1 May
1992 (next election to be held NA May 1995);
results— LDP 66%. NPC 20%. Lakas-NUCD
8%, Liberal 6%; seats — (24 total) LDP 15,
NPC 5, Lakas-NUCD 2. Liberal 1,
Independent I
House of Representatives (Kapulungan Ng
Mga Kinatawan): elections last held 1 1 May
1992 (next election to be held NA May 1995);
results— LDP 43.5%; Lakas-NUCD 25%.
NPC 23.5%, Liberal 5%. KBL 3%; seats—
(200 total) LDP 87. NPC 45, Lakas-NUCD 41 ,
Liberal 15, NP 6, KBL 3, Independent 3
Judicial branch: Supreme Court
315
Philippines (continued)
Political parties and leaders: Democratic
Filipino Struggle (Laban ng Demokratikong
Pilipinas. Laban). Edgardo ESPIRITU; People
Power-National Union of Christian Democrats
(Lakas ng Edsa, NUCD and Partido Lakas Tao.
Lakas/NUCD); Fidel V. RAMOS. President of
the Republic, Raul MANGLAPUS, Jose de
VENECIA, secretary general; Nationalist
People’s Coalition (NPC). Eduardo
COJUANGCO; Liberal Party. Jovito
SALONGA; People’s Reform Party (PRP),
Miriam DEFENSOR-SANTIAGO; New
Society Movement (Kilusan Bagong Lipunan;
KBL), Imelda MARCOS; Nacionalista Party
(NP), Salvador H. LAUREL, president
Member of: APEC. AsDB. ASEAN. CCC,
CP. ESCAP, FAO. G-24, G-77. GATT. IAEA,
IBRD. ICAO. ICFTU. IDA, IFAD. IFC, ILO,
IMF. IMO. INMARSAT. INTELSAT,
INTERPOL. IOC, lOM. ISO. ITU, LORCS.
NAM, UN. UNCTAD. UNESCO. UNHCR.
UNIDO. UNTAC, UPU. WCL, WFTU, WHO.
WlPO, WMO, WTO
Diplomatic representation in US:
chief of mission: Ambassador Raul Chaves
RABE
clumcery: 1617 Massachusetts Avenue NW.
Washington. DC 200.16
telephone: (202) 48.V14I4
FAX: (202) .128-7614
consulaie(s) general: Agana (Guam).
Chicago, Honolulu. Houston, Los Angeles,
New York, San Francisco, and Seattle
consiilaiels): San Diego and San Jose (Saipan)
US diplomatic representation:
chief of mission: Ambassador John D,
NEGROPONTE
emhassY: 1201 Rosas Boulevard. Ermita
Manila 1000
mailing address: APO AP 96440
telephone: |612| .121-71 16
FAX: 16121 .‘>22-4.161
considate(s) general: Cebu
Flag: two equal horizontal bands of blue (top)
and red with a white equilateral triangle based
on the hoist side: in the center of the triangle is
a yellow sun with eight primary rays (each
containing three individual rays) and in each
comer of the triangle is a small yellow five-
pointed star
Names:
conventional long form: Pitcairn, Henderson,
Ducie, and Oeno Islands
conventional short form: Pitcairn islands
Digraph: PC
Type: dependent territory of the UK
Capital: Adamstown
Administrative divisions: none (dependent
territory of the UK)
Independence: none (dependent territory of
the UK)
National holiday: Celebration of the
Binhday of the (jueen (second Saturday in
June)
Constitution: Local Government Ordinance
of 1964
Legal system: local island by-laws
Sulfeage: 1 8 years of age; universal with
three years residency
Executive branch:
chief of state: Queen ELIZABETH 11 (since 6
February 1932), represented by UK High
Commissioner to New Zealand and Governor
(non-resident) of the Pitcairn Islands David
Jo.seph MOSS (since NA September 1990);
Commissioner (non-resident) G.D.
HARRAWAY (since NA; is the liason person
between the governor and the Island Council)
head of government: Island Magistrate and
Chairman of the Island Council Jay WARREN
(since NA)
Legislative branch: unicameral
Island Council; elections last held NA (nest to
be held NA); results — percent of vote by patty
NA; seats — ( 1 1 total, 5 elected) number of
seats by party NA
Judidd braiKh: Island Court
Political parties and leaders: NA
Other political or pressure groups: NA
Member of: SPC
Dlploimitlc representation in US; none
(dependent territory of the UK)
US diplomatic representation: none
(dependent territory of the UK)
Flag: blue with the flag ofthe UK in the upper
hoist-side quadrant and the Pitcairn Islander
coat of arms centered on the outer half of the
flag; the coat of arms is yellow, green, and light
blue with a shield featuring a yellow anchor
Names:
conventional long form; none
conventional short form; Spratly Islands
Digraph: PG
Names:
conventional lonft fonn: Democratic Socialist
Republic of Sri Lanka
conventional short form: Sri Lanka
former: Ceylon
Digraph: CE
Type: republic
Capital: Colombo
Administrative divisions: 8 provinces:
Central, North Central. North Eastern, North
Western, Sabaragamuwa, Southern, Uva,
Western
Independence: 4 February 1948 (from UK)
National holiday: Independence and
National Day, 4 February (1948)
Constitution: adopted 16 August 1978
Legal system: a highly complex mixture of
English common law, Roman-Dutch. Muslim.
Sinhalese, and customary law; has not accepted
compulsory ICJ jurisdiction
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state and head of government:
President Dingiri Banda WIJETUNGA (since
7 May 1993); election last held 19 December
1988 (next to be held NA December 1994);
results — Ranasinghe PREMADASA (UNP)
50%. Sirimavo BANDARANAIKE (SLFP)
45%. other 5%: note — following the
assassination of President PREMADASA on I
May 1993, Prime Minister WIJETUNGA
became acting president; on 7 May 1 993. he
was confirmed by a vote of Parliament to finish
out the term of the assassinated president
cabinet: Cabinet; appointed by the president in
consultation with the prime minister
Legislative branch: unicameral
Parliament; elections last held 15 February
1989 (next to be held by N.A February 1995);
results— UNP 51%, SLFP 32%. SLMC 4%.
TULF 3%. USA 3%, EROS 3%-. MEP 1%.
other 3%; seats— (225 total) UNP 125, SLFP
67, other 33
Judicial branch: Supreme Court
Politica> parties and leaders: United
National Party (UNP). Dingiri Banda
WIJETUNGA; Sri Lanka Freedom Patty
(SLFP), Sirimavo BANDARANAIKE; Sri
Lanka Muslim Congress (SLMC), M. H, M.
ASHRAFF; All Ceylon Tamil Congress
(ACTC), C. G, Kumar PONNAMBALAM;
People''s United Front (MEP. or Mahajana
Eksath Peramuna), Dinesh
GUNAWARDENE; Tamil United Liberation
Front (TULF). M, SIVASITHAMBARAM;
New Socialist Party (NSSP, or Nava Sama
Samaju Party), Vasudeva NANAYAKKARA;
Lanka Socialist Party/Trotskyite (LSSP, or
Lanka Sama Saniaja Party). Colin R. DE
SILVA; Sri Lanka People’s Party (SLMP, or
Sri I anka Mahajana Party), Ossie
ABEYGUNASEKERA; Communist Party. K.
P. SILVA; Communist Party/Beijing (CP/B),
N. SHANMUGATHASAN; Democratic
United National Front (DUNF). G. M.
PREMACHANDRA; &lam People''s
Democratic Party (EPDP), Douglas
DEVANANDA; Tamil Eelam Liberation
Organization (TELO), leader NA; Eelam
People''s Revolutionary Liberation From
(EPRL). Suresh PREMACHANDRAN; Lelam
Revolutionary Organization of Students
(EROS). Shankar RAJI; People''s Liberation
Organization of Tamil Eelam (PLOTE),
Dharmalingam SIDARTHAN; Liberal Party
(LP), Chanaka AMARATUNGA; Ceylon
Workers Congress (CLDC), S,
THONDAMAN; several ethnic Tamil and
Muslim parties, represented in either
parliament or provincial councils
note: the United Socialist Alliance (USA),
which was formed in 1987 and included the
NSSP, LSSP, SLMP, CP/M, and CP/B, was
defunct as of 1993. following the formation of
the People’s Alliance Party (PEP)
Other political or pressure groups:
Liberation Tigers of Tamil Eelam (LTTE) and
other smaller Tamil separatist groups; other
radical chauvinist Sinhalese groups; Buddhist
clergy; Sinhalese Buddhist lay groups; labor
unions
Member of: AsDB, C. CCC. CP. ESCAP,
FAO. G-24. G-77. GATT. IAEA, IBRD.
ICAO, ICC. ICFTU. IDA. IFAD, IFC, ILO,
IMF, IMO, INMARSAT, INTELSAT,
INTERPOL, IOC. lOM. ISO. ITU. LORCS.
NAM. PCA. SAARC. UN. UNCTAD,
UNESCO, UNIDO, UPU, WCL. WFTU,
WHO. WIPO, WMO, WTO
Diplomatic representation in US:
chief of mission: Ambassador Ananda W.P,
GURUGE
chancery; 2148 Wyoming Avenue NW,
Washington, DC 2(X)08
telephone: (202) 483-4025 through 4028
FAX.- (202) 2.32-7181
consulaie(s}: New York
US diplomatic representation:
chief of mission: Ambassador Teresita C.
SCHAFFER
embassy; 210 Galle Road. Colombo 3
mailing address: P. O. Box 106. Colombo
telephone: (94] (1)44-80-07
FAX.- [94] (1)57-42-64
Flag: yellow with two panels: the smaller
hoist-side panel has two equal vertical bands of
green (hoist side) and orange; the other panel is
a large dark red rectangle with a yellow lion
holding a sword, and there is a yellow bo leaf
in each comer; the yellow field appears as a
border that goes around the entire flag and
extends between the two panels','1dcd48401e4339bab7603ae308aa28029ca18b05c156066bcabc23467aa351b6','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2afa0d6f8367c24e03e18e0b3a1118e386dded3b05640c43c760f4e5275ffebb',1994,'PA','Panama','government',755,'Names:
conventional long form: Republic of Panama
conventional short form: Panama
local long form: Republica de Panama
local .short form: Panama
Digraph: PM
Type: constitutional republic
Capital: Panama
Administrative divisions: 9 provinces
(provincias, singular — provinciu) and I
territory* (comarca); Bocusdel Tom. Chiriqui,
Code, Colon, Darien, Herrera, Los Santos,
Panama, Sun Bias*. Veruguas
Independence: 3 November 1903 (from
306
Colombia; became independent from Spain 28
November 1821)
National holiday: Independence Day, 3
November (1 903)
Constitution: 1 1 October 1972; major
reforms adopted April 1983
Legal system: based on civil law system;
Judicial review of legislative acts in >he
Supreme Court of Justice; accepts compulsory
ICJ Jurisdiction, with reservations
Suffrage: 1 8 years of age; universal and
compulsory
Executive branch:
chief of state and head of government:
President Guillermo ENDARA (since 20
December 1989, elected 7 May 1989); First
Vice President Guillermo FORD Boyd (since
24 December 1992); Second Vice President
(vacant); election last held on 7 May 1989,
annulled but later upheld; results — anti-
NORIEGA coalition believed to have won
about 75% of the total votes cast
note: a presidential election was held 8 May
1994 (next election to held on 9 May 1999)
with inauguration of the successful candidates
to take place on I September 1 994; results —
President Ernesto PEREZ BALLADARES
Gonzales, First Vice President Tomas
Altamirano DUQUE, and Second Vice
President Felipe VIRZI were elected; percent
of vote for president — BALLADARES 33%,
DE GRUBER 29%. BLADES 17%
cabinet: Cabinet; appointed by the president
Legislative branch: unicameral
National Assembly (Asamblea Nacional):
elections held on 27 January 1991; results—
percent of vote by party NA; seals — (67 total)
progovernment parties; PDC 28, MOLIRENA
15. PA 8, PLA4
opposition parties; PRD 10. PALA I, PL I;
note — the PDC went into opposition after
President Guillermo ENDARA ousted the
PDC from the coalition government in April
1991; an election of members of the National
Assembly was held on 8 May 1994 (next
election to be held on 9 May 1999) and they
will take their seats on I September 1994;
results — percent of vote and seats won by party
NA
Judicial branch: Supreme Court of Justice
(Cone Suprema de Justicia), 5 superior courts,
3 courts of appeal
Political parties and leaders:
government alliance; Nationalist Republican
Liberal Movement (MOLIRENA). Alfredo
RAMIREZ: Authentic Liberal Party (PLA),
Arnulfo ESCALONA; Arnuirista Party (PA),
Mireya MOSCOSO DE GRUBER
other parties; Christian Democratic Party
(PDC). Raul OSSA; Democratic
Revolutionary Party (PRD). Gerardo
GONZALEZ; Agrarian Labor Party (PALA),
Nestor Tomas GUERRA; Liberal Party (PL),
Roberto ALEMAN Zubieta; Doctrinaire
Panamenista Party (PPD), Jose Salvador
MUNOZ: Papa Egoro Movement, Ruben
BLADES; Civic Renewal Party (PRC), Tomas
HERRERA: National Integration Movement
(MINA). Arrigo GUARDIA; National Unity
Mission Party (MUN). Jose Manuel
PAREDES; Solidarity Party (CPS), Samuel
LEWIS GALINDO
note; following the elections of 8 May 1 994
the following realignment of political parties
look place
governing coalition: Democratic
Revolutionary Party (PRD), Gerardo
GONZALEZ; Liberal Republican Party (PLR).
Rodolfo CHIARI; Labor Party (PALA), Carlos
Lopez GUEVARA; Solidarity Party
(PS),Samuel LEWIS GALINDO
other parties: Nationalist Republican Liberal
Movement (MOLIRENA), Alfredo
RAMIREZ; Authentic Liberal Party (PLA),
Arnulfo ESCOLONA; Amulfisla Party (PA),
Mireya Moscoso DE GRUBER: Christian
Democratic Party (PDC), Raul OSSA; Liberal
Party (PL), Roberto ALEMAN Zubieta; Papa
Egoro Movement. Ruben BLADES; Civic
Renewal Party (PRC). Tomas HERRERA;
National Unity Mission Party (MUN). Jose
Manuel PAREDES
Other political or pressure groups:
National Council of Organized Workers
(CONATO); National Council of Private
Enterprise (CONEP); Panamanian Association
of Business Executives (APEDE); National
Civic Crusade; Chamber of Commerce:
Panamanian Indu.strialists Society (SIP);
Workers Confederation of the Republic of
Panama (CTRP)
Member of: AG (associate), CG, ECLAC,
FAO, G-77, lADB. IAEA, IBRD. ICAO,
ICFTU, IDA. IFAD. IFC. ILO, IMF, IMO,
INMARSAT, INTELSAT, INTERPOL. IOC,
lOM, ITU. LAES. LAIA (observer), LORCS,
NAM, OAS, OPANAL, PCA, UN. UNf^TAD,
UNESCO. UNIDO, UPU. WCL, WFTU,
WHO, WIPO, WMO, WTO
Diplomatic representation in US:
chief of mission: Ambassador Jaime FORD
Boyd (to be re;^ laced by Ambassador Ricardo
Alberto ARIAS on I September 1994)
chancery; 2862 McGill Terrace NW,
Washington, DC 2(XK)8
telephone: (202)483-1407
consulate(s) general: Atlanta, Houston.
Miami, New Orleans, New York. San
Francisco, San Juan (Puerto Rico), Tampa.
US diplomatic representation:
chief of mission: (vacant)
embassy: Avenida Balboa and Calle 38.
Apartado 6959, Panama City 5
mailing address; American Embassy Panama,
Unit 0945; APO AA .34002
telephone; (507) 27-1117
MY; (507) 27-1964
Flag: divided into four, equal rectangles; the
top quadrants are white (hoist side) with a blue
five-pointed star in the center and plain red. the
bottom quadrants are plain blue (hoist side) and
white with a red five-pointed star in the center','c9ad191892a29b1e3e3ac07e5581830e4ffddee63ff4d51265d401c0a2108a33','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a434e1d9d24f0a379e06c363a112994a13662be6fa70926f30b0e1adb375ae18',1994,'PG','Papua New Guinea','government',761,'Names:
conventional long form: Independent State of
conventional short form: Papua New Guinea
Digraph: PP
Type: parliamentary democracy
Capital: Port Moresby
Administrative divisions: 20 provinces;
Central, Chimbu, Eastern Highlands, East New
Britain, East Sepik, Enga, Gulf, Madang,
Manus, Milne Bay. Morobe, National Capital,
New Ireland, Northern, North Solomons,
Sandaun, Southern Highlands, Western,
Western Highlands, West New Britain
Independence: 1 6 September 1 975 (from UN
trusteeship under Australian administration)
308
National holiday: Independence Day, 16
September (1975)
Constitution: 16 September 1975
Legal system: based on English common law
Suflhige: 1 8 years of age; universal
Executive branch:
chief of state; Queen ELIZABETH il (since 6
February 1952), represented by Governor
General Wiwa KOROWl (since NA November
1991)
head of government: Prime Minister Paias
WINGTI (since 17 July 1992); Deputy Prime
Minister Sir Julius CHAN (since July 1992)
cabinet; National Executive Council;
appointed by the governor on recommendation
of the prime minister
Legislative branch: unicameral
National Parliament; (sometimes referred to
as the House of Assembly) elections last held
1 3-26 June 1 992 (next to be held NA 1 997):
results — peicent by party NA; seats — (109
total) Pangu Party 24, PDM 17, PPP 10, PAP
10, independents 30, others 18 (association
with political parties is fluid)
Judicial branch: Supreme Court
Political parties and leaders: Papua New
Guinea United Party (Pangu Party), Jack
GENIA; People’s Democratic Movement
(PDM), Paias WINGTI; People''s Action Party
(PAP), Akoka DOl; People’s Progress Party
(PPP), Sir Julius CHAN; United Party (UP),
Paul TORATO; Papua Party (PP), Galeva
KWARARA; National Party (NP), Paul
PORA; Melanesian Alliance (MA), Fr. John
MOMIS
Member of: ACP, APEC, AsDB, ASEAN
(observer), C, CP, ESCAP, FAO, G-77, IBRD,
ICAO, ICFTU, IDA, IFAD, IFC, ILO, IMF,
IMO, INTELSAT, INTERPOL, IOC, ISO
(correspondent), ITU, LORCS, NAM,
SPARTECA, SPC, SPF, UN, UNCTAD,
UNESCO, UNIDO, UPU, WFTU, WHO,
WMO
Diplomatic representation in US:
chief of mission; Ambassador-designate Kepas
WATANGIA
chancer}'': 3rd floor, 1615 New Hampshire
Avenue NW, Washington, DC 2(K)09
telephone; (202) 745-3680
FAX; (202) 745-3679
US diplomatic representation:
chief of mission; Ambassador Richard TEARE
embassy; Armit Street, Port Moresby
mailing address: P. O. Box 1492, Port
Moresby, or APO AE 96553
telephone: |675] 21 1-455 or 594, 654
FAX; (6751 213-423
Flag: divided diagonally from upper hoist-
side comer; the upper triangle is red with a
soaring yellow bird of paradise centered; the
lower triangle is black with five white five-
pointed stars of the Southern Cross
constellation centered','a50ebd5f2b53e4be2f95878a356f1d3da9906679e44087f5490df71596c2d708','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b170099f81c5cb1202ab66fcfa9060224ec7da02d7c79ac6fca27a4d2c382ed0',1994,'PT','Portugal','government',771,'Names:
conventional long fom: Portuguese Republic
conventional .than form: Portugal
local long form; Republica Portuguese
local short form; Portugal
Digraph: PO
Type: republic
Capital: Lisbon
Administrative divisions: 18 districts
(distritos, singular — distrito) and 2
autonomous regions* (regioes autonomas,
singular— regiao autonoma); Aveiro, Acores
(Azores)*, Beja, Braga, Braganca, Castelo
Branco, Coimbra, Evora, Faro, Guards, Leiria,
Lisboa, Madeira*, Portalegre, Porto, Santarem,
Setubal, Viana do Castelo, Vila Real, Viseu
Dependent areas: Macau (scheduled to
become a Special Administrative Region of
China on 20 December 1999)
Independence: 1 140 (independent republic
proclaimed 5 October 1910)
National holiday: Day of Portugal, 10 June
(1580)
Constitution: 25 Aprii 1976, revised 30
October 1982 and I June 1989
Legal system: civil law system; the
Constitutional Tribunal reviews the
constitutionality of legislation; accepts
compulsory ICJ jurisdiction, with reservations
Suffrage: 18 years of age; universal
Executive branch:
chief of Slate; President Dr. Mario Alberto
Nobre Lopes SOARES (since 9 March 1 986);
election last held 13 February 1991 (next to be
held NA February 1996); results — Dr. Mario
Lopes SOARES 70%. Basilic HORTA 14%.
Carlos CARVALHAS 13%. Carlos
MARQUES 3%
head of government: Prime Minister Anibal
CAVACO SILVA (since 6 November 1985)
Council of State: acts as a consultative body to
the president
cabinet; Council of Ministers; appointed by
the president on recommendation of the prime
minister
Legislative branch: unicameral
Assembly of the Republic (Assembleia da Re-
publica): elections last held 6 October 1991
(next to be held NA October 1995); results —
PSD 50.4%, PS 29.3%, CDU 8.8%. Center
Democrats 4.4%. National Solidarity Party
1.7%, PRD 0.6%, other 4.8%; seats— (230
total) PSD 136, PS 71, CDU 17. Center
Democrats 5, National Solidarity Party 1
Judicial branch: SupremeTribunalofJustice
(Supremo Tribunal de lustica)
Political parties and leaders; Social
Democratic Party (PSD). Anibal CAVACO
Silva; Portuguese Socialist Party (PS), Antonio
GUTERRES; Party of Democratic Renewal
(PRD), Pedro CANAVARRO; Portuguese
Communist Party (PCP), Carlos
CARVALHAS; Social Democratic Center
(CDS). Manuel MONTEIRO; National
Solidarity Party (PSN). Manuel SERGIO;
Center Democratic Party (CDS); United
Democratic Coalition (CDU; Communists)
Member of: AfDB, Australian Group, BIS.
CCC, CE. CERN. COCOM, CSCE. EBRD,
EC. ECE. ECLAC, EiB, FAO, GATT. lADB,
IAEA, IBRD. ICAO, ICC, ICFTU, IDA. lEA,
IFAD, IFC, ILO, IMF. IMO, INMARSAT.
INTELSAT. INTERPOL. IOC, lOM. ISO,
ITU. LAIA (observer). LORCS, MTCR.
NACC, NAM (guest). NATO. NEA, NSG.
OAS (Observer). OECD. PCA, UN, UNCTAD.
UNESCO, UNIDO. UNOMOZ, UNPROFOR,
UPU, WCL. WEU, WHO. WIPO, WMO,
WTO. ZC
Diplomatic representation in US:
chief of mission; Ambassador Francisco Jo.se
LacoTreichler KNOPFLl
chancery; 2125 Kalorama Road NW,
Washington, DC 20008
telephone; (202) 328-8610
FAX; (202) 462-3726
consulate(s) general: Boston, New York,
Newark (New Jersey), and San Francisco
consulate(s): Los Angeles, New Bedford
(Massachusetts), and Providence (Rhode
Island)
US diplomatic representation:
chief of mission: (vacant); Charge d'' Affaires
Sharon P. WILKINSON
embassy: Avenida das Forcas Armadas, 1600
Lisbon
mailing address: PSC 83, Lisbon; APO AE
09726
teiephone; [35 1 ] ( 1 ) 726-6600 or 6659, 8670,
8880
F/4Y.- [351] (1)726-9109
consulate(s): Ponta Delgada (Azores)
Flag: two vertical bands of green (hoist side,
two-fifths) and red (three-fifths) with the
Portuguese coat of arms centered on the
dividing line','ceefd5ba82281938906d9d1724120b7ab06fd8a8fabbc670568b715f887a8de0','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('986a067be251dea7bc7e68bf7dbe008533ad732f8d9b9127f98c86c8000e571d',1994,'PR','Puerto Rico','government',777,'Names:
conventional long form: Commonwealth of
conventional short form: Puerto Rico
Digraph: RQ
Type: commonwealth associated with the US
Capital: San Juan
Administrative divisions: none
(commonwealth associated with the US), note:
there are 78 municipalities
Independence: none (commonwealth
associated with the US)
National holiday: US Independence Day, 4
July (1776)
Constitution: ratified 3 March 1952;
approved by US Congress 3 July 1952;
effective 25 July 1952
Legal system: based on Spanish civil code
Suffrage: 1 8 years of age; universal;
indigenous inhabitants are US citizens but do
not vote in US presidential elections
Executive branch:
chief of state: President William Jefferson
CLINTON (since 20 January 1993); Vice
President Albert GORE, Jr. (since 20 January
1993)
head of government: Governor Pedro
ROSSELLO (since NA January 1993);
election last held 3 November 1992 (next to be
held NA November 1996); results — Pedro
ROSSELLO (PND) 50%, Victoria MUNOZ
(PPD) 46%, Fernando MARTIN (PIP) 4%
Legislative branch: bicameral Legislative
Assembly
Senate: elections last held 3 November 1992
(next to be held NA November 1996);
results — percent of vote by party NA; seats —
(27 total) seats by patty NA
House of Representatives: elections last held 3
November 1992 (next to be held NA
November 1996); results — percent of vote by
party NA; seats — (53 total) seats by party NA
US House of Representatives: elections last
held 3 November 1992 (next to be held NA
November 1996); results — percent of vote by
party NA: seats — ( 1 total) seats by party NA:
note — Puerto Rico elects one representative to
the US House of Representatives, Carlos
Romero BARCELO
Judicial branch: Supreme Court
Political parties and leaders: National
Republican Party of Puerto Rico, Freddy
VALENTIN; Popular Democratic Pany
(PPD), Rafael HERNANDEZ Colon; New
Progressive Party (PNP), Carlos ROMERO
Barcelo; Puerto Rican Socialist Party (PSP),
Juan MARI Bras and Carlos G ALLIS A; Puerto
Rican Independence Party (PIP), Ruben
BERRIOS Martinez; Puerto Rican Communist
Party (PCP), leader(s) unknown
Other political or pressure groups: all have
engaged in terrorist activities — Armed Forces
for National Liberation (FALN); Volunteers of
the Puerto Rican Revolution; Boricua Popular
Army (also known as the Macheteros); Armed
Forces of Popular Resistance
Member of: CARICOM (observer), ECLAC
(associate), FAO (associate), ICFTU,
INTERPOL (subbureau), IOC, WCL, WFTU,
WHO (associate), WTO (associate)
Diplomatic representation in US: none
(commonwealth associated with the US)
US diplomatic representation; none
(commonwealth associated with the US)
Flag: five equal horizontal bands of red (top
and bottom) alternating with white; a blue
isosceles triangle based on the hoist side bears
a large white five-pointed star in the center;
design based on the US flag','2d8e7a3aafb5973489fcdcdb0efd03da89538b7920ba562cd436b3fbd957dd3a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('391f7149f2d7634cab799fc86743a4381fed8f5c7bc906851f0ea57f393a5180',1994,'UA','Ukraine','government',786,'Names:
conventional long form; none
conventional short form; Romania
local long form; none
local short form; Romania
Digraph: RO
Type: republic
Capital: Bucharest
Administrative divisions: 40 counties
(judete, singular- -judet) and I municipality*
(municipiu); Alba, Arad, Arges, Bacau, Bihor,
Bistrita-Nasaud, Botosani, Braila, Brasov,
Bucuresti*, Buzau, Calarasi, Caras-Severin,
Cluj, Constanta, Covasna, Dimbovita, DolJ,
Galati, Gorj, Giurgiu, Harghita, Hunedoara,
lalomita, Iasi, Maramures. Mehedinti, Mures,
Neamt, Olt, Prahova, Salaj, Satu Mare, Sibiu,
Suceava, Teleorman, Timis, Tulcea, Vaslui,
Vilcea, Vrancea
Independence: 1881 (from Turkey; republic
proclaimed 30 December 1947)
National holiday; National Day of Romania,
1 December ( 1990)
Constitution: 8 December 1991
Legal system: former mixture of civil law
system and Communist legal theory is being
revised to conform with European norms
Sufhtige: 1 8 years of age; universal
Executive branch:
chief of state; President Ion ILIESCU (since
20 June 1990, previously President of
Provisional Council of National Unity since 23
December 1989); election last held 27
September 1992 — with runoff between top two
candidates on 1 1 October 1 992 (next to be held
NA 1996);results — Ion 1L1ESCU61.4%, Emil
CONSTANTINESCU 38.6%
head of government; Prime Minister Nicolae
VACAROlU (since November 1992)
cabinet; Council of Ministers; appointed by
the prime minister
Legislative branch: bicameral Parliament
Senate (Senat); elections last held 27
September 1992 (next to be held NA 1996);
results— PDSR 27.5%, CDR 22.5%, PP-(FSN)
1 1%, others 39%; seats — ( 143 total) PDSR 49,
CDR 34, PP-(FSN) 18, PUNR 14. UDMR 12,
PRM 6. PDAR 5. PSM 5
House of Deputies (Adunarea Depulatilor);
elections last held 27 September 1992 (next to
be held NA 1996): results— PDSR 27.5%,
CDR 22.5%, PP-(FSN) 1 1%. others 39%;
seats— (341 total) PDSR 1 17, CDR 82.
PP-(FSN) 43. PUNR .30. UDMR 27. PRM 16,
PSM 13, other 13
Judicial branch: Supreme Court of Justice,
Constitutional Court
Political parties and leaders: Democratic
Party (PD-(FSN)), Petre ROMAN; Party of
Social Democracy in Romania (PDSR), Adrian
NASTASE; Democratic Union of Hungarians
in Romania (UDMR), Bela MARKO; National
Liberal Party (PNL), Mircea lONESCU-
QUINTUS; National Peasants’ Christian and
Democratic Party (PNTCD), Comeliu
COPOSU; Romanian National Unity Party
(PUNR), Gheorghe FUNAR; Socialist Labor
Party (PSM), Hie VERDET; Agrarian
Democratic Party of Romania (PDAR), Victor
SURDU; The Democratic Convention (CDR),
Emil CONSTANTINESCU; Romania Mare
Party (PRM), Comeliu Vadim TUDOR
note; numerous other small parties exist but
almost all failed to gain representation in the
most recent election
Other political or pressure groups: various
human rights and professional associations
Member of: ACCT (observer), BIS, BSEC,
CCC, CE, CEI (participating), CSCE. EBRD.
ECE. FAO, G-9. G-77, GATT. IAEA, IBRD,
ICAO, ICFTU, IFAD, IFC. ILO, IMF, IMO,
INMARSAT, INTELSAT. INTERPOL. IOC,
lOM (observer), ISO, ITU, LORCS. NACC,
NAM (guest). NSG, OAS (observer), PCA,
UN. UNCTAD. UNESCO, UNIDO,
UNIKOM, UNOSOM, UPU, WCL. WFTU,
WHO, WIPO, WMO, WTO, ZC
Diplomatic representation In US:
chief of mission; (vacant)
chancery; 1607 23rd Street NW, Washington,
DC 20008
telephone; (202) 332-4846, 4848, 485 1
FAX: (202) 232-4748
consulalels) general: New York
US diplomatic representation:
chief of mission; Ambassador John R. DAVIS,
Jr.
emhas.sv: Strada Tudor Arghezi 7-9, Bucharest
mailing address; AmEmbassy (Buch). Unit
1315, Bucharest; APO AE 092 1 .3- 1 .3 1 5
telephone: [40] (1) 210-4042
F4Y.- (401(1)210-0395
Flag: three equal vertical bands of blue (hoist
side), yellow, and red; the national coat of arms
that used to be centered in the yellow band has
been removed; now similar to the flags of
Andorra and Chad
Names:
conventional long form: Russian Federation
conventional short form: Russia
local long form: Rossiyskaya Federatsiya
local short form: Rossiya
former: Russian Soviet Federative Socialist
Republic
Digraph: RS
I''ype: federation
Capital: Moscow
Administrative divisions: 21 autonomous
republics (avtomnykh tespublik, singular —
avtomnaya respublika); Adygea (Maykop),
Bashkortostan (Ufa). Buryatia (Ulan-Ude).
Chechenia (Groznyy). Chuvashia
(Cheboksary), Dagestan (Makhachkala).
Gomo-Altay (Gorno-Altaysk), Ingushetia
(Nazran''), Kabardino-Balkaria (Nal''chik),
Kalmykia (Elista). Karachay-Cherkessia
(Cherkessk), Karelia (Petrozavodsk),
Khakassia (Abakan), Komi (Syktyvkar), Mari
El (Yoshkar-Ola), Mordovia (Saransk). North
Ossetia (Vladikavkaz), Tatarstan (Kazan’),
Tuva (Kyzyl), Udmurtia (Izhevsk). Yakutia
(Yakutsk); 49 oblasts (oblastey, singular —
oblast''); Amur (Blagoveshchensk).
Arkhangel''sk, Astrakhan’. Belgorod, Bryansk,
Chelyabinsk, Chita, Irkutsk, Ivanovo,
Kaliningrad, Kaluga, Kamchatka
(Petropavlovsk-Kamchatskiy), Kemerovo,
Kirov, Kostroma, Kurgan, Kursk. Leningrad
(St. Petersburg). Lipetsk, Magadan. Moscow,
Murmansk, Nizhniy Novgorod, Novgorod.
Novosibirsk, Omsk, Orel. Orenburg, Penza,
Perm'', Pskov, Rostov, Ryazan'', Sakhalin
(Yuzhno-Sakhalinsk), Samara, Saratov,
Smolensk. Sverdlovsk (Yekaterinburg),
Tambov, Tomsk. Tula, Tver''. Tyumen'',
Ul''yanovsk, Vladimir, Volgograd, Vologda.
Voronezh. Yaroslavl''; 6 krays (krayev.
singular — kray); Altay (Barnaul), Khabarovsk,
Krasnodar. Krasnoyarsk. Primorskiy
(Vladivostok), Stavropol''
note: the autonomous republics of Chechenia
and Ingushetia were formerly the automous
republic of Checheno-Ingushetia (the
boundary between Chechenia and Ingushetia
has yet to be determined); the cities of Moscow
and St. Petersburg are federal cities; an
administrative division has the same name as
its administrative center (exceptions have the
administrative center name following in
parentheses)
Independence: 24 August 1991 (from Soviet
Union)
National holiday: Independence Day, June
12(1990)
Constitution: adopted 12 December 1993
Legal system: based on civil law system;
judicial review of legislative acts
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Boris Nikolayevich
YEL''TSIN (since 12 June 1991) election last
held 12 June 1991 (next to be held 1996);
results — percent of vote ty party NA%; note —
no vice president; if the president dies in office,
cannot exercise his powers because of ill
health, is impeached, or resigns, the premier
succeeds him; the premier serves as acting
president until a new presidential election,
which must be held within three months
head of government: Premier and Chairman of
the Council of Ministers Viktor Stepanovich
CHERNOMYRDIN (since 14 December
1992); Fir t Deputy Chairman of the Council
of Ministers Oleg SOSKOVETS (since 30
April 1993)
Security Council: (originally established as a
presidential advisory body in June 1991, but
restructured in March 1992 with responsibility
for managing individual and state Sv.curity)
Presidential Administration: (drafts
presidential edicts and provides staff and
policy support to the entire executive branch)
cabinet: Council of Ministers; aopointed by
the president
Group of Assistants: (schedules president’.®
appointments, processes presidential edicts and
other official documents, and houses the
president’s piess service and primary
speechwriters)
Council of Heads of Republics: (iiKlui''cs the
leaders of the 21 ethnic-based Republics/
Council of Heads of Administrations:
(includes the leaders of the 68 autonomous
territories and regions, and the mayors of
Moscow and St. Petersburg)
Presidential Council: (prepares policy papers
for the president)
Legislative branch: bicameral Federal
Assembly
Federation Council: elections last held 1 2
December 1993 (next to be held NA); note —
two members elected from each of Russia’s 89
territorial units for a total of 176 deputies; 2
seats unfilled as of 15 May 1994 (Chechenia
did not participate in the election/; Speaker
Vladimir SHUMEYKO (Russia’s Choice)
State Duma: elections last held 12 December
1993 (next to be held NA December 1995):
results — percent of vote by party NA; seats —
(450 total) Russia’s Choice 78, New Regional
Policy 66, Liberal Democrats 63, Agrarian
Party 55, Communist Party of the Russian
Federation 45, Unity and Accord 30,
Yavlinskiy Bloc 27, Women of Russia 23,
Democratic Party of Russia 1 5, Russia’s Path
1 2, other parties 23, affiliation unknown 12,
unfilled (as of 13 March 1994; Chechnya did
not participate in the election) 1 ; Speaker Ivan
RYBKIN (Agrarian Party)
Judicial branch; Constitutional Court,
Supreme Court (highest court for criminal,
civil, and administrative cases), Superior Court
of Arbitration (highest court that resolves
economic disputes)
Political parties and leaders:
pro-market democrats: Party of Russian Unity
and Accord, Sergey SHAKHRAY; Russia’s
Choice electoral association, Yegor
C AYDAR; Russian Movement for Democratic
Reforms electoral association, Anatoliy
SOBCHAK; Yavlinskiy-Boldytev-Lukin Bloc
electoral association, Grigoriy YAVLINSKIY
centrists/special interest parties: Civic Union
for Stability, Justice, and Progress. Arkadiy
VOL’SKIY; Constructive-Ecological
Movement of Russia, Anatoliy PANFILOV;
Democratic Party of Russia, Nikolay
TRAVKIN; Dignity and Charity Federal
Political Movement, Konstantin FROLOV;
Russia’;, Future-New Names electoral
association, Vyacheslav LASHCHEVSKIY;
Women of Russia Party, Alevtina
FEDULOVA
anti-market and/or uitranationalist parties:
Agrarian Party, Mikhail LAPSHIN;
Communist Party of the Russian Federation,
Gennadiy ZYUGANOV; Liberal Democratic
Party of Russia, Vladimir ZHIRINOVSKIY
note: more than 20 political parties and
associations tried to gather enough signatures
to run slates of candidates in the 1 2 December
1993 legislative elections, but only 13
succeeded
Other political or pressure groups: NA
Member of: BSEC, CBSS, CCC, CE (guest),
CERN (observer). CIS. CSCE. EBRD, ECE,
ESCAP. IAEA. IBRD, ICAO, IDA. IFC. ILO.
IMF IMO. INMARSAT. INTELSAT.
INTERPOL. IOC. lOM (observer). ISO, ITU.
LORCS, MINURSO, NACC, NSG, OAS
(observer), PCA. UN, UNCTAD, UNESCO.
UNIDO. UNIKOM. UNOMOZ. UNPROFOR.
UN Security Council. UNTAC, UN
Trusteeship Cou-^cil. UNTSO. UPU. WHO.
WIPO, WMO. WTO. ZC
Diplomatic representation in US;
chief of mission: Ambassador Vladimir
Petrovich LUKIN
chancert: 1 125 16th Street NW. Washington.
DC 20036
telephone: (20?) 628-7551 and 8548
330
consttlatefs) general: New York, San
Francisco, and Seattle
consulateis); Washington
US diplomatic reprcMOtatloii:
chief of mission; Ambassador Thomas R.
PICKERING
embassy; Novinskiy Bul''var 19/23, Moscow
mailing address; APO AE 09721
telephone; [7] (095) 252-2451 through 2459
FAX; [7] (095)-4261/4270
consulate(s); St. Petersburg, Vladivostok
Flag: three equai horizontal bands of white
(top), blue, and red
Names:
conventional long form: none
conventional short form: Ukraine
local long form: none
local short form: Ukrayina
former: Ukrainian Soviet Socialist Republic
Digraph: UP
Type: republic
Capital: Kiev (Kyyiv)
Administrative divisions; 24 oblasti
(singular — oblast''), I autonomous republic*
(avtomnaya lespublika), and 2 municipalites
(mista, singular — misto) with oblast status**;
Cherkas''ka (Cherkasy). Chernihivs''ka
(Chemihiv). Chemivets''ka (Chernitsi),
Dnipropetrovs''ka (Dni(wopetrovs’k).
Donets''ka (Donets''k), Ivano-Frankivs''ka
(Ivano-Frankivs''k), Kharkivs''ka (Kharkiv),
Khersons''ka (Kherson). Khmel''nyts''ka
(Khmel''nyts’kyy), Kirovohrads''ka
(Kirovohrad), Kyyiv**. Kyyivs’ka (Kiev).
Luhans''ka (Luhans''k). L''vivs''ka (L''viv),
Mykolayivs’kn (Mykolayiv), Odes''ka
(Cidesa). ! oltuvs''ka (Poltava). Respublika
Krym* (Siinferopol’), Rivnens''ka (Rivne),
Sesasi ipor**,Sums''ka (Sevastopol''),
Tcrnopil’s’ka (Temopif), Vinnyts''ka
(Vinnytsya), Volyns''ka (Luts''k). Zakarpats’ka
(Uzhhorod), Zaporiz''ka (Zaporizhzhya),
Zhytomyrs’ka (Zbytomyr)
note: names in parentheses are administrative
centers when name differs from oblast'' name
Independence: I December 1991 (from
Soviet Union)
National holiday: Independence Day, 24
August (1 991)
Constitution; u.sing 1978 pre-independence
constitution; new constitution currently being
drafted
Legal system: based on civil law system; no
judicial review of legislative acts
Suffrage; 1 8 years of age; universal
Executive branch:
chief of state: President Leonid Makarovych
KRAVCHUK (since 5 December 1991);
election last held I December 1991 (next to be
held 26 June 1994); results — Leonid
KRAVCHUK 61 .59%. Vyacheslav
CHORNOVIL 23.27%. Levko
LUKYANENKO 4.49%. Volodymyr
HRYNYOV 4.17%, iher YUKHNOVSKY
1.74%. Leopold TABURYANSKYY 0.57%,
other 4, 17%
head of government: Prime Minister (vacant);
Acting First Deputy Prime Minister (and
Acting Prime Minister since September 1993)
Yukhym Leonidovych ZVYAHIL SKYY
(since 1 1 June 1993) and five deputy prime
ministers
cabinet: Council of Ministers; appointed by
the president and approved by the Supreme
Councii
Legislative branch: unicameral
Supreme Council; elections last held 27 March
19^ (next to be held NA); results— percent of
vote by party N A; seats — (450 total) number of
.seats by party NA; note — 338 deputies were
elected; the remaining 1 12 seats to be filled on
24 July 1994
Judicial branch: being organized
Political parties and leaders; Green Party of
Ukraine, Vitaliy KONONOV, leader; Liberal
Party of Ukraine, Ihor MERKULOV.
chairman; Liberal Democratic Party of
Ukraine. Volodymyr KLYMCHUK,
chairman; Elemocratic Patty of Ukraine,
Volodymyr Oleksandrovych
YAVORIVSKIY, chairman; People’s Party of
Ukraine. Leopol''d TABURYANSKYY.
chairman; Peasants'' Party of Ukraine, Serhiy
DOVGRAN''. chairman; Parly of Democratic
Rebirth of Ukraine, Volodymyr FILENKO,
chairman; Social Democratic Party of Ukraine,
Yuriy ZBITNEV, chairman; Socialist Party of
Ukraine. Oleksandr MOROZ, chairman;
Ukrainian Christian Democratic Party. Vitaliy
ZHURAVSKYY, chairman; Ukrainian
Conservative Republican Party, Stepan
KHMARA, chairman; Ukrainian Labor Patty.
Valenlyn LANDYK. chairman; Ukrainian
Party of Justice, Mykhaylo HRECHKO,
chairman; Ukrainian Peasants'' Democratic
Party. Serhiy PLACHINDA, chairman;
Ukrainian Republican Party, Mykhaylo
HORYN’, chairman; Ukrainian National
Conservative Party, Viktor RADiONOV,
chairman; Ukrainian People''s Movement for
Restructuring (Rukh), Vyacheslav
CHORNOUL, chairman; Ukrainian
Communist Party, Petr SYMONENKO
Other political or pressure groups; New
Ukraine (Nova Ukrayina); Congress of
National Democratic Forces
Member of: BSEC, CBSS (observer). CCC,
CE (guest), CEI (participating). CIS, CSCE,
EBRD, ECE. IAEA. IBRD, ICAO, ILO, IMF,
INMARSAT, INTELSAT (nonsignatory user),
INTERPOL, IOC, ITU. NACC. PCA, UN.
UNCTAD. UNESCO. UNIDO. UNPROFOR,
UPU. WHO, WIPO. WMO
Diplomatic representation in US;
chief of mission: Ambassador Oleh
Hryhorovych BILORUS
chancery: 3350 M Street NW, Suite 200,
Washington. DC 20007
telephone: (202) 333-0606
FAX: (202) 333-0817
consulate! s) general: Chicago and New York
l)S diplomatic representation;
chief of mission: Ambassador William
MILLER
embassy: 10 Yuria Kotsyubinskovo, 252053
Kiev 5.3
mailing address: use embassy street address
telephone: [7] (044) 244-7349 or 2A4-Ti44
FAX: [7] (044) 244-7350
Flag: two equal horizontal bands of azure
(top) and golden yellow .''epresent grainfields
unDr a blue sky
410','f0ecfd8a435abf392942ea1ff9529456db8509a6ab11191ecfd2bf2ba09db5e2','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b69615afe82814ed99f1249d005c05520421582d3c1d3fa1b5bf557f8d1cdbcf',1994,'RW','Rwanda','government',793,'Names:
conventional long form; Republic of Rwanda
conventional short form; Rwanda
local long form; Republika y’u Rwanda
local short form: Rwanda
Digraph: RW
Type: republic; presidential system
note; a new, interim government formed in
August 1992 to last until peace accord;
political parties are working to form a
multiethical broad-based transitonal
government to lead them to elections in 1995
Capital; Kigali
Administrative divisions: 10 prefectures
(prefectures, singular — prefecture in French;
plural — NA, singular — prcfegitura in
Kinyarwanda); Butare, Byumba, Cyangugu,
Gikongoro, Gisenyi. Gitarama, Kibungo,
Kibuye, Kigali, Ruhengeri
Independence: I July 1962 (from UN
trusteeship under Belgian administration)
National holiday: Independence Day. 1 July
(1962)
Constitution; 1 8 June 1991
Legal system: ba.sed on German and Belgian
civil law systems and customary law; judicial
review of legislative acts in the Supreme Court;
has not acSindi cepted compulsory ICJ
Jurisdiction
Suffrage; universal adult at age NA
Executive branch:
chief of state; Interim President Dr. Theodore
SINDIKUBWABO (since 8 April 1994,
followin''; the death of President Juvenal
HABYARIMANA on 6 April 1994) election
last held 19 December 1988 (next planned for
1995); results — President Juvenal
HABYARIMANA reelected
h:ad of government: Prime Minister Jean
KA.It BANDA appointed by President
KUBWABWO 8 April 1994 following the
ai^sa .ination of Agatha UWILINGIYIMANA
on? April 1994
cabinet: Council of Ministers; appointed by
the president
Legislative branch; unicameral
National Development Council; (Conseil
National de Developpement) elections last held
19 December 1988 (new elections to be held in
1995); results — MRND was the only party;
■seat.s — (70 total) MRND 70
Judicial branch: Constitutional Court
(consists of the Court of Cassation and the
Council of State in joint session)
Political parties and leaders; Republican
National Movement for Democracy and
Development (MRND); significant
independent parties include; Democratic
Republican Movement (MDR); Liberal Party
(PL); Democratic and Socialist Party (PSD);
Coalition for the Defense of the Republic
(CDR); Party for Democracy in Rwanda
(PADER): Christian Democratic Party (PDL)
note: formerly a one-party state, Rwanda
legalized independent parties in mid- 1991;
since then, at least 10 new political parties have
registered
Other political or pressure groups;
note; peace accord ending three year civil war
with Rwandan Patriotic Front (RPF) was
signed in August 1993
Member oD’aCCT, ACP. AfDB, ECA, CCC,
CEEAC, CEPGL, FAO. G-77. GATT. IBRD,
ICAO. ICFTU, IDA, IFAD. IFC, ILO, IMF.
INTELSAT. INTERPOL, IOC, ITU. LORCS.
NAM, OAU, UN, UNCTAD, UNESCO.
UNIDO. UPU, WCL, WHO, WIPO, WMO,
WTO
Diplomatic representation in US:
chief of mission: Ambassador Aloys
UWIMANA
chancery; 1714 New Hamp.shire Avenue NW.
Washington. DC 2()(X)9
telephone: (202) 232-2882
FAX; (202) 232-4544
US diplomatic representation:
chief of mission; (vacant)
embassy; Boulevard de la Revolution, Kigali
mailing address; B. P. 28. Kigali
telephone: [250] 75601 through 75603
FAX; [250] 72128
note: embassy closed on 10 April 1994 and
personnel withdrawn because of severe civil
strife and consequent danger for foreign
nationals
Flag; three equal vertical bands of red (hoist
side), yellow, and green with a large black
letter R centered in the yellow band; uses the
popular pan- African colors of Ethiopia; similar
to the :1ag of Guinea, which has a plain yellow
band','4f63c41b678f014a4f6399817d8f3833db63c56039c9fc7571532d7bef2eaf43','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca39f0f22a473181118b903fc8a078d1b9a7a6afd66b2d0a5bf9b5eeb57b81cb',1994,'LC','Saint Lucia','government',799,'Names:
conventional long form: none
conventional .short form: Saint Lucia
Digraph: ST
Type: parliamentary democracy
Capital: Castries
Administrative divisions: 1 1 quarters; Anse
La Raye, Castries, ChoiseuI, Dauphin.
Dennery, Gros Islet, Laborie, Micoud, Praslin,
Soufriere, Vieux Fort
Independence: 22 February 1979 (from UK)
National holiday: Independence Day, 22
February (1979)
Constitution: 22 February 1979
Legal system: based on English common law
Suffrage: 18 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II (since 6
February 1952), represented by Governor
General Sir Stanislaus Anthony JAMES (since
10 October 1988)
head of government: Prime Minister John
George Melvin COMPTON (since 3 May
1982); Vice President George MALLET (since
NA)
337
Saint Lucia (continued)
cabinet: Cabinet; appointed by the governor
generai on advice of the prime minister
Legislative branch; bicameral Parliament
Senate: consists of an 1 1 -member body, 6
appointed on the advice of the prime minister,
3 on the advice of the leader of the opposition,
and 2 after consultation with religious,
economic, and social groups
House of Assembly: elections last held 27
April 1 W2 (next to be held by April 1997);
results — percent of vote by party NA; seats —
(l7total)UWP 11,SLP6
Judicial branch: Eastern Caribbean Supreme
Court
Political parties and leaders: United
Workers’ Party (UWP), John COMPTON;
Saint Lucia Labor Party (SLP), Julian HUNTE;
Progressive Labor Party (PLP), George
ODLUM
Member of: ACCT (associate), ACP, C,
CARICOM, CDB, ECLAC, FAO, G-77,
GATT, IBRD, ICAO, ICFTU, IDA, IFAD,
IFC, ILO, IMF, IMO, INTELSAT
(nonsignatory user), INTERPOL, LORCS,
NAM. OAS, OECS, UN, UNCTAD,
UNESCO, UNIDO, UPU, WCL, WHO.
WIPO, WMO
Diplomatic representation In US:
chief of mission: Ambassador Dr. Joseph
Edsel EDMUNDS
chancery: Suite 309, 2100 M Street NW,
Washington, DC 30037
telephone: (202) 463-7378 or 7379
FAX: (202) 887-5746
consulate(s) general: New York
US diplomatic representation: no official
presence since the Ambassador resides in
Bridgetown (Barbados)
Flag: blue with a gold isosceles triangle below
a black arrowhead; the upper edges of the
arrowhead have a white border','52569ffea3b2b13409614cc88867e1ceb454bcba8b30f65fef617db45ba33750','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac2ae21f15da14ebacc3ec2c1e2778ac1613108c6d26faebada49d529d03f29b',1994,'PM','Saint Pierre and Miquelon','government',804,'Names:
conventional long form: Ter.''itorial
Collectivity of Saint Pierre aid Miquelon
conventional short form: Saint Pierre and
Miquelon
local long form: Depanement de Saint-Pierre
et Miquelon
heal short form: Saint-Pierre ct Miquelon
Digraph: SB
Type: territorial collectivity of France
Capital: Saint-Pierre
Administrative divisions: none (territorial
collectivity of France)
Independence: none (territorial collectivity
of France; has been under French control since
1763)
National holiday: National Day. Taking of
the Bastille, 14 July
Constitution: 28 September 1958 (French
Constitution)
Legal system: French law
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: President Francois
MITTERRAND (since 21 May 1981)
head of government: Commissioner of the
Republic Yves HENRY (since NA December
1993); President of the General Council Marc
PLANTE-GENEST (since NA)
cabinet: Council of Ministers
Legislative branch: unicameral
General Council: elections last held
September-October 1988 (next to be held NA
September 1994); results — percent of vote by
party NA; .seats — (19 total) Socialist and other
left-wing parties 13, UDF and right-wing
parties 6
French Senate: elections last held NA
September 1986 (next to be held NA
September 1995); results — percent of vote by
party NA; seats — ( 1 total) PS 1
French National Assembly: elections last held
21 and 28 March 1993 (next to be held NA
June 1998); results — percent of vote by party
NA; seats— (1 total) UDF 1; note — Saint
Pierre and Miquelon elects 1 member each to
the French Senate and the French National
Assembly who are voting members
Judicial branch: Superior Tribunal of
Appeals (Tribunal Superieur d’Appel)
Political parties and leaders: Socialist Party
(PS), Albert PEN; Union for French
Democracy (UDF/CDS), Gerard GRIGNON
Member of: FZ, WFTU
Diplomatic representation in US: none
(territorial collectivity of France)
US diplomatic representation: none
(territorial collectivity of France)
Flag: the flag of France is used','0672a4427d6732b93c6f4a058cb16305695bd881f4f1af43829967ae765adf9a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ded4bd5275e8b18ba095686e6143d4e57f688797c36e3a024ac66d4042c72a03',1994,'VC','Saint Vincent and the Grenadines','government',810,'Names:
conventional long form: none
conventional short form: Saint Vincent and the
Grenadines
Digraph; VC
Type; constitutional monarchy
Capital; Kingstown
Administrative divisions: 6 parishes;
Charlotte, Grenadines, Saint Andrew, Saint
David, Saint George. Saint Patrick
Independence: 27 October 1979 (from UK)
National holiday; Independence Day, 27
October (1979)
Constitution: 27 October 1979
Legal system: based on English common law
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II (since 6
February 1952), represented by Governor
General David JACK (since 29 September
1989)
head of government: Prime Minister James F,
MITCHELL (since 30 July 1984); Deputy
Prime Minister Allan C. CRUICKSHANK
(since NA); note — governor general appoints
leader of the majority party to position of prime
minister
cabinet: Cabinet; appointed by the governor
general on the advice of the prime minister
Legislative branch: unicameral
House of Assembly: elections last held 21
February 1994 (next to be held NA July 1999);
results — percent of vote by party NA; seats —
340
(21 total: 15 elected representatives and 6
appointed senators) NDP 10, MNU 2, SVLP 3
Judicial branch; Eastern Caribbean Supreme
Court
Political parties and leaders: New
Democratic Party (NDP), James (Son)
MITCHELL: Saint Vincent Labor Party
(SVLP), Stanley JOHN: United People’s
Movement (UPM), Adrian SAUNDERS:
Movement for National Unity (MNU), Ralph
GONSALVES: National Reform Patty (NRP),
Joel MIGUEL
Member of: ACP, C, CARICOM, CDB.
ECLAC, FAO, G-77, GATT, IBRD, ICAO,
ICFTU, IDA, IFAD, IMF, IMO, INTELSAT
(nonsignatory user), INTERPOL, IOC, ITU,
LORCS, OAS, OECS. OPANAL, UN,
UNCTAD, UNESCO, UNIDO, UPU, WCL,
WFTU, WHO
Diplomatic representation In US:
chief of mixxUm: Ambassador Kingsley C.A.
LAYNE
chuncery: 1717 Massachusetts Avenue NW,
Suite 102, Washington, DC 20036
telephone: (202) 462-7806 or 7846
FAX; (202) 462-7807
US diplomatic representation: no ofTicial
presence since the Ambassador resides in
Bridgetown (Barbados)
Flag: three vertical bands of blue (hoist side),
gold (double width), and green: the gold band
bears three green diamonds arranged in a V
pattern','7cde068f01e4c31f6fbc5dab5183178e440ce7399c1bb75104c08cf680a502b9','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7260d8df2f6b314b9b605388b4c1e16106174cc260ef4b1cf37fe6800bac71c1',1994,'SM','San Marino','government',815,'Names:
conventional long form; Republic of San
Marino
conventional short form: San Marino
local long form: Repubblica di San Marino
local short form: San Marino
Digraph: SM
Type: republic
Capital; San Marino
Administrative divisions: 9 municipalities
(castelli, singular— castello); Acquaviva,
Borgo Maggiore, Chiesanuova. Domagnano,
Faetano, Fiorentino, Monte Giardino, San
Marino, Serravalle
Independence; 301 AD (by tradition)
National holiday: Anniversary of the
Foundation of the Republic, 3 September
Constitution: 8 October 1600; electoral law
of 1926 serves some of the functions of a
constitution
Legal system: based on civil law system with
Italian law influences; has not accepted
compulsory ICJ jurisdiction
Suffrage; 1 8 years of age: universal
Executive branch:
co-chiefs of state: Captain Regent Alberto
CECCHETTI and Captain Regent Fausto
MULARONI (for the period 1 April 1994-30
September 1994) real executive power is
wielded by the secretary of state for foreign
affairs and the secretary of state for internal
affairs
head of government: Secretary of State
Gabriele GATTI (since July 1986)
cabinet: Congress of State; elected by the
Council for the duration of its term
Legislative branch: unicameral
Great and General Council: (Consiglio
Grande e Generale) elections last held 30 May
1993 (next to be held by NA May 1998);
results— DCS 41.4%, PSS 23.7%, PDF 18.6%,
ADP 7.7%. MD 5.3%. RC 3.3%; seats— (60
total) DCS 26. PSS 14. PDF 11. ADP 4, MD 3.
RC2
Judicial branch: Council of Twelve
(Consiglio dei XII)
Political parties and leaders: Christian
Democratic Party (DCS), Pier Marino
MENICUCCl, Luigi LONFERNINl;
Democratic Progressive Party (PDP) formerly
San Marino Communist Party (PSS), Stefano
MACINA; San Marino Sociaiist Party (PSS),
Dr. Emma ROSSI, Antonio Lazzaro
VOLPINARI; Democratic Movement (MD),
Emilio Della BALDA; Popular E>emocratic
Alliance (ADP); Communist Refoundation
(RC), Guiseppe AMICHI, Renato FABBRI
Member of: CE, CSCE, ECE, ICAO, ICFTU,
ILO, IMF, IOC, lOM (observer), ITU,
LORCS. NAM (guest), UN, UNCTAD,
UNESCO, UPU, WHO. WIPO, WTO
Diplomatic representation in US:
honorary consulate(s) general: Washington
and New York
honorary consulate(s): Detroit
US dlplonuitic representation: no mission in
San Marino, but the Consul General in
Florence (Italy) is accredited to San Marino
Flag: two equal horizontal bands of white
(top) and light blue with the national coat of
arms superimposed in the center; the coat of
aims has a shield (featuring three towers on
three peaks) flanked by a wreath, below a
crown and above a scroll bearing the word
LIBERTAS (Liberty)','1006bbbda9f862567796c492074c27b4dfa60d02cd20140cb28c394518008600','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21d2c0b0b7f73f816da22cdbd9b2cb1620916ef7cdf69cfc8c781ba7293e7b47',1994,'ST','Sao Tome and Principe','government',822,'Names:
conventional long form: Democratic Republic
of Sao Tome and Principe
conventional short form: Sao Tome and
Principe
local long form: Republica Democratica de
Sao Tome e Principe
local short form: Sao Tome e Principe
Digraph: TP
Type: republic
Capital: Sao Tome
Administrative divisions: 2 districts
(concelhos, singular — concelho); Principe,
Sao Tome
Independence: 12 July 1975 (from Portugal)
National holiday: Independence Day. 1 2 July
(1975)
Constitution: new constitution approved
March 1990; effective 10 September 1990
Legal system: based on Portuguese law
system and customary law; has not accepted
compulsory ICJ jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Miguel TROVOADA
(since 4 April 1991); election last held 3 March
1991 (next to be held NA March 1996);
results — Miguel TROVOADA was elected
without opposition in Sao Tome’s first
343
Sao Tome and Principe (continued)
multiparty presidential election
head of government; Prime Minister Noberto
Jose D’Alva COSTA ALEGRE (since 16 May
1992)
cabinet; Council of Ministen: appointed by
the president on the proposal of the prime
minister
Legislative branch: unicameral
National People’s Assembly; (Assembleia
Popular Nacional) elections last held 20
January 1991 (next to be held NA January
1996): results— PCD-GR 54.4%, MLSTP
30.5%, CODO 5.2%, FDC 1.5%, other 8.4%;
seats— (55 total) PCD-GR 33, MLSTP 21,
CODO 1 : note — this was the first multiparty
election in Sao Tome and Principe
Judicial branch: Supreme Court
Political parties and leaders: Party for
Democratic Convergence-Reflection Group
(PCD-GR), Daniel Lima Dos Santos DAIO,
secretary general; Movement for the Liberation
of Sao Tome and Principe (MLSTP), Carlos da
GRACA; Christian Democratic Front (FDC),
Alphonse Dos SANTOS; Democratic
Opposition Coalition (CODO), leader NA;
other small parties
Member of: ACP, AfDB, CEEAC, ECA,
FAO, G-77, IBRD, ICAO, IDA, IFAD, ILO,
IMF, IMO, INTELSAT (nonsignatory user),
INTERPOL, lOM (observer), ITU, LORCS,
NAM. OAU, UN. UNCTAD. UNESCO.
UNIDO, UPU. WHO, WMO, WTO
Diplomatic representation In US: SaoTome
and Principe has no embassy in the US, but
does have a Permanent Mission to the UN.
headed by First Secretary Domingos
AUGUSTO Ferreira, located at 122 East 42nd
Street, Suite 1604, New York, NY 10168,
telephone (212) 697-42 1 1
US diplomatic representation: ambassador
to Gabon is accredited to Sao Tome and
Principe on a nonresident basis and makes
periodic visits to the islands
Flag: three horizontal bands of green (top),
yellow (double width), and green with two
black five-pointed stars placed side by side in
the center of the yellow band and a red
isosceles triangle based on the hoist side: uses
the popular pan-African colors of Ethiopia','fd0838e1f69717871eea29d8111b4eb067705a75c86ddfae3b0dba1d78e0ee1c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b78c850bb67aba4d4a3cc1343b6e7dc8a7dce2deeb00b9bd32ea30ead695bc8',1994,'ME','Montenegro','government',825,'local long form; none
local short form: Srbija-Cma Cora
Digraph;
Serbia: SR
Montenegro: MW
Type: republic
Capital: Belgrade
Administrative divisions; 2 republics
(pokajine, singular — pokajina); and 2
autonomous provinces*; Kosovo*.
Montenegro. Serbia, Vojvodina*
Independence; II April 1992 (Federal
Republic of Yugoslavia formed as self-
proclaimed successor to the Socialist Federal
Republic of Yugoslavia — SFRY)
National holiday: NA
Constitution; 27 April 1992
Legal system: bused on civil law system
Suffrage: 1 6 years of age, if employed; 1 8
years of age, universal
Executive branch:
chief of stale; Zoran LILIC (since 25 June
1993); note— Slobodan MILOSEVIC is
president of Serbia (since 9 December 1990);
Momir BULATOVIC is president of
Montenegro (since 23 December 1990);
Federal Assembly elected Zoran LILIC on 25
June 1993
head of government: Prime Minister Radoje
KONTIC (since 29 December 1992); Deputy
Prime Ministers Jovan ZEBIC (since NA
March 1993), Asim TELACEVIC (since NA
March 1993), Zeljko SIMIC (since NA 1993)
cabinet; Federal Executive Council
Legislative branch; bicameral Federal
As.sembly
Chamber of Republics: elections last held 3 1
May 1992 (next to be held NA 1 996); results —
percent of vote by party NA: seats — (40 total;
20 Serbian, 20 Montenegrin)
Chamber of Citizens; elections last held 31
May 1992 (next to be held NA 1996); results —
percent of votes by party NA; seats — ( 1 38
total; 108 Serbian, 30 Montenegrin) SPS 73,
SRS 33. DPSCG 23. SK-PJ 2, DZVM 2,
independents 2, vacant 3
Judicial branch; Savezni Sud (Federal
Court). Constitutional Court
Political parties and leaders; Serbian
Socialist Party (SPS; former Communist
Party), Slobodan MILOSEVIC; Serbian
Radical Party (SRS), Vojislav SESEU;
Serbian Renewal Movement (SPO), Vuk
DRASKOVIC, president; Democratic Party
(DS). Zoran DJINDJIC; Democratic Party of
Serbia. Vojislav KOSTUNICA; Democratic
Party of Sociali.sts (DPSCG). Momir
BULATOVIC, president; People''s Party of
Montenegro (NS), Novak KILIBARDA;
Liberal Alliance of Montenegro, Slavko
PEROVIC; Democratic Community of
Vojvodina Hungarians (DZVM). Agoston
ANDRAS; League of Communists- Movement
for Yugoslavia (SK-PJ). Dragan
ATANASOVSKI; Democratic Alliance of
Kosovo ;LDK). Dr. Ibrahim RUGOVA,
president
Other political or pressure groups: Serbian
Democratic Movement (DEPOS; coalition of
opposition parties)
Diplomatic representation in US; US and
Serbia and Montenegro do not maintain full
diplomatic relations; the Embassy of the
former Socialist Federal Republic of
Yugoslavia continues to function in the US
US diplomatic representation:
chief of mission: (vacant): Charge d'' Affaires
Rudolf V. PERINA
embassy; address NA, Belgrade
mailing address: American Embassy Box
5070, Unit 25402, APO AE 092 1 3-5070
telephone: |38) ( 1 1 ) 645-655
FAX.- 138] (1)645-221
Flag: three equal horizontal bands of blue
(top), white, and red','45c3d928a03a922e858bc4c0b0f815e7a7861d5da3d07c3538d20efa4b976d14','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('927d586340028d452b6833857ca5ebb8901e27999470ed71947bc2f61903483b',1994,'SC','Seychelles','government',832,'Names:
conventional long form; Republic of
conventional short form: Seychelles
Digraph: SE
Type; republic
Capital; Victoria
Administrative divisions: 23 administrative
districts; Anse aux Pins, Anse Boileau. Anse
Etoile, An.se Louis, Anse Royale, Baie Lazare,
Baie Sainte Anne, Beau Vallon, Bel Air, Bel
Ombre, Cascade, Glacis, Grand'' Anse (on
Mahe Island). Grand’ Anse (on Praslin Island),
La Digue, La Riviere Anglaise. Mont Buxton,
Mont Fleuri. Plaisance. Pointe Larue, Port
Claud, Saint Louis. Takamaka
Independence: 29 June 1976 (from UK)
National holiday: National Day, 18 June
( 1993) ( adoption of new constitution)
Constitution: 1 8 June 1993
Legal system: based on English common law,
French civil law, and customary law
Suffrage: 1 7 years of age; universal
Executive branch;
chief of state and head of government:
President France Albert RENE (since 5 June
1977); election last held 20-23 July 1993;
results — President France Albert RENE
reelected by 59.5% of votes, MANCHAM (PS
party) 36.72%
cabinet: Council of Ministers; appointed by
the president
Legislative branch: unicameral
People ’s Assembly (Assemblee du Peuple):
elections last held 20-23 July 1993; results —
SPPF 82%, DP 15%, UO 3%; seats— (33 total,
22 elected) SPPF 22
Judicial branch: Court of Appeal, Supreme
Court
Political parties and leaders; ruling party —
Seychelles People’s Progressive Front (SPPF),
France Albert RENE; Democratic Party (DP),
Sir James MANCHAM; United Opposition
(UO) is a coalition of the following parties;
Seychelles Party (PS), Wavel
RAMKALAWAN; Seychelles Democratic
Movement (MSPD), Jacques HONDOUL;
Seychelles Liberal Party (SLP), Ogilvie
BERLOUIS
Other political or pressure groups: trade
unions; Roman Catholic Church
Member of: ACCT, ACP. AfDB, C. ECA.
FAO, G-77, IBRD, ICAO, ICFTU, IFAD. IFC.
ILO, IMF, IMO. INTELSAT (nonsignatory
user). INTERPOL, IOC, ISO (correspondent),
NAM. OAU, UN. UNCTAD. UNESCO.
UNIDO. UPU. WCL. WHO, WMO, WTO
Diplomatic representation in US:
chief of mission: Ambassador Marc Michael
Rogers MARENGO
chancery: (temporary) 820 Second Avenue.
Suite 900F. New York, NY 10017
telephone: (212) (>81-9166 or 9767
FAX.- (212) 922-9177
US diplomatic representation:
chief of mission; Ambassador Matthew F.
MATTINGLY
embassy: 4th Floor, Victoria House, Box 251.
Victoria, Mahe
mailing address; Box 148, Unit 62501,
Victoria, Seychelles; APO AE 09815-2501
telephone; (248) 25256
FAX.- (248) 25189
Flag; three horizontal bands of red (top),
white (wavy), and green; the white band is the
thinnest, the red band is the thickest','02f69a4d5c771c73364c5aa62ea07da37728cddfb653ca35ee6773c220bf91e3','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f60a5a773c4d7b2c8b9a17e1711d151d3d24d4e52d256f48a7b74bbae9ff8c99',1994,'SG','Singapore','government',840,'Names:
conventional long form: Republic of
conventional short form: Singapore
Digraph: SN
Type: republic within Commonwealth
Capital; Singapore
Administrative divisions: none
Independence: 9 August 1965 (from
Malaysia)
National holiday: National Day, 9 August
(1965)
Constitution: 3 June 1959, amended 1965;
based on preindependence State of Singapore
Constitution
Legal system: based on Englishcommon law;
has not accepted compulsoiy ICJ jurisdiction
Suffrage: 20 years of age; universal and
compulsory
Executive branch:
chief of .state: President ONG Teng Cheong
(since 1 September 1993) election last held 28
August 1993 (next to be held NA August
354
1997): results — President ONG was elected
with 59% of the vote in the country''s first
popular election for president
/uW of Kovenwwni: Prime Minister OOH
Chok Tong (since 28 November 1990); Deputy
Prime Minister LEE Hsien Loong (since 28
November 1990)
vahini’t: Cabinet; appointed by the president,
responsible to parliament
Legislative branch; unicameral
PdiiUment: elections last held 31 August 1991
(next to be held 31 August 19%); results —
percent of vote by party NA; seats — (81 total)
PAP 77, SDP 3, WP I
Judicial branch: Supreme Court
Political parties and leaders;
ffovernmeni: People''s Action Party (PAP),
GOH Cbok Tong, secretary general
opitosiiion: Workers’ Party (WP), J. B.
JEYARETNAM: Singaptrre Democratic Party
(SDP), CHIAM See Tong: National Solidtiriiy
Party (NSP), leader NA; Barisan Sosialis (BS,
SiKiulist Frtau), leader NA
Member of: APEC, AsDB, ASEAN, C,CCC,
COCOM (cooperating), CP, ESCAP, G-77,
GATT, IAEA, IBRD, ICAO, ICC, ICFTU.
IFC, ILO, IMF, IMO, INMARSAT,
INTELSAT, INTERPOL, IOC. ISO, ITU,
LORCS. NAM, UN, UNAVEM II, UNCTAD,
UNIKOM. UNTAC, UPU, WHO. WlPO,
WMO
Diplomatic representation in US;
chief ofmhsion; Ambassador Sellapan Rama
NATHAN
chmicerv! 1 824 R Street NW, Washington, DC
2(XX)9
telephone; (202) 667-755.3
FAX; (202) 265-7915
US diplomatic representation;
chief of mission; (vacant)
embassy; 30 Hill Street. Singaptrre 0617
mailinf! oMress; FPO AP 96534
telephone; 165 1 338-0251
FAX; 165) 338-5010
Flag: two equal horizontal bunds of red (top)
and white; near the hoist side of the red band,
there is a vertical, while crescent (closed
portion is toward the hoist side) partially
enclosing five while five-pointed stars
arranged in a ciale','a2d3acd0244d8996aa9eadd121f1e697e2b0f1fcfb54bc7a0d539ffe5502303d','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9c7b5c1468e86d2973c5ebdaf8d69010853fc59b7800e5b9709080572869cda',1994,'SK','Slovakia','government',845,'Names;
conventional long form: Slovak Republic
conventional short form: Slovakia
local long form: Slovenska Republika
local short form; Slovensko
Digraph: LO
Type: parliamentary democracy
Capital: Bratislava
Administrative divisions: 4 departments
(kraje. singular — Kraj) Bratislava,
Zapadosiovensky. Stredoslovensky,
V ychodoslovensky
Independence: I January 1993 (from
Czechoslovakia)
National holiday: Anniversary of Slovak
National Uprising. August 29 (1944)
Constitution: ratified 1 September 1992;
fully effective I January 1993
Legal system: civil law system based on
Austro-Hungarian codes; has not accepted
compulsory ICJ jurisdiction; legal code
modified to comply with the obligations of
Conference on Security and Cooperation in
Europe (CSCE) and to expunge Marxist-
Leninist legal theory
Suffirage: 1 8 years of age; universal
Executive branch:
chief of state: President Michal KOVAC
(since 8 February 1993): election last held 8
February 1993 (next to be held NA 1998);
results — Michal KOVAC elected by the
National Council
head of government: Prime Minister Jozef
MORAVCIK (since 16 March 1994)
cabinet; Cabinet; appointed by the president
on recommendation of the prime minister
Legislative branch: unicameral
National Council (Narodni Rada): elections
last held 5-6 June 1992 (next to be held 31
September-1 October 1994); results — percent
of vote by party NA; seats — (150 total)
Movement for a Democratic Slovakia 55, Party
of the Democratic Left 28. Christian
Democratic Movement 18, Slovak National
Party 9. National Democratic Party 5,
Hungarian Christian Democratic Movement/
Coexistence 14, Democratic Union of Slovakia
16, independents 5
Judicial branch: Supreme Court
Political parties and leaders: Movement for
a Democratic Slovakia, Vladimir MECIAR,
chairman; Party of the Democratic Left, Peter
WEISS, chairman; Christian Democratic
Movement. Jan CARNOGURSKY; Slovak
National Party. Jan SLOTA. chairman:
Hungarian Christian Democratic Movement,
Vojiech BUGAR; National Democratic Party-
New Alternative. Ludovit CERNAK,
chairman; Democratic Union of Slovakia,
Jozef MORAVCIK, chairman; Coexistence
Movement, Miklos DURAY, chairman
Other political or pressure groups: Green
Party; Social Democratic Party in Slovakia;
Freedom Party; Slovak Christian Union;
Hungarian Civic Party
Member of: BIS, CCC, CE (guest), CEl,
CERN. CGCOM (cooperating), CSCE, EBRD,
ECE. FAO. GATT, IAEA, IBRD. ICAO.
ICFTU, IDA, IFC, ILO, IMF, IMO,
INMARSAT, INTELSAT (nonsignatory user),
iNTERPOL, IOC, lOM (observer), ISO. ITU,
LORCS. NACC, NSG, PCA, UN (as of 8
January 1993). UNAVEM II, UNCTAD.
UNESCO, UNIDO, UNOMUR, UNPROFOR,
UPU. WFTU, WHO. WIPO, WMO. WTO, ZC
Diplomatic representation in US:
chief of mission: Ambassador-designate
Bravislav LICHARDUS
chanceiy: (temporary) Suite 330, 2201
Wisconsin Avenue NW. Washington. DC
20007
/Wt''p/imic; (202)965-5161
MY; (202) 965-5 166
US diplomatic representation:
chief of mission: Ambassdor Theodore
RUSSELL
embassy: Hviezdoslavovo Namesite 4, 81102
Brali.slavu
maiiing address: use embassy street address
356
telephone: [42] (7) 330-861
MX; |42] (7) 335-439
Flag: three equal horizontal bands of white
(top), blue, and red superimposed with the
Slovak cross in a shield centered on the hoist
side; the cross is white centered on a
background of red and blue','15448adbd130b6a4d4d8d729aa821fcf10230d25e1fada5bee35caeab127e512','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72640b6cc940ac840b019cf26706878d8ae0957013e18fca8f1a828c762c1bea',1994,'SB','Solomon Islands','government',852,'Names:
conventional long form: none
conventional short form: Solomon Islands
former; British Solomon Islands
Digraph: BP
Type: parliamentary democracy
Capital: Honiara
Administrative divisions: 7 provinces and I
town*; Central, Guadalcanal. Honiara*, Isabel,
Makira, Malaita, Teniolu. Western
Independence: 7 July 1978 (from UK)
National holiday: Independence Day, 7 July
(1978)
Constitution: 7 July 1978
Legal system: common law
Suffrage: 2 1 years of age: universal
Executive branch:
chief of state: Queen ELIZABETH II (since 6
February 1952). represented by Governor
General .SirGeoigc I.EPPING (since 27 June
1 989, previously acted as governor general
since 7 July 1988)
head of government: Prime Minister Francis
Billy HILLY (since June 1993); Deputy Prime
MinisterFrancisSAEMALA (since June 1993)
cabinet: Cabinet; appointed by the governor
general on advice of the prime minister from
members of parliament
Legislative branch: unicameral
National Parliament: elections Ia,st held NA
May 1993 (next to be held NA 1997); results —
percent of vote by party NA; seats — (47 total)
National Unity Group 21, PAP 8, National
Action Party 6, LP 4, UP 3, Christian
Fellowship 2, NFP 1. independents 2
Judicial branch: High Court
Political parties and leaders: People''s
Alliance Party (PAP); United Party (UP),
leader NA: Solomon Islands Liberal Party
(SILP). Baitholemew ULUFA’ALU;
Nationalist Front for Progress (NFP), Andrew
NORI; Labor Party (LP). Joses TUHANUKU;
National Action Party, leader NA; Christian
Fellowship, leader NA; National Unity Group,
Solomon MAMALONI
Member of: ACP. AsDB, C. ESCAP, FAO,
G-77. IBRl"), ICAO. IDA. IFAD, IFC. ILO,
IMF. IMO. INTELSAT (nonsignatory user).
IOC, ITU, LORCS, SPARTECA, SPC. SPF,
UN, UNCTAD, UNESCO, UPU, WFTU,
WHO, WMO
Diplomatic representation in US:
chief of mission: (vacant); amba.ssador
traditionally resides in Honiara (Solomon
Islands)
US diplomatic representation: embassy
closed July 1993: the ambassador to Papua
New Guinea is accredited to the Solomon
Islands
Flag: divided diagonally by a thin yellow
stripe from the lower hoist-side comer; the
upper triangle (hoist side) is blue with five
white five-pointed stars arranged in an X
pattern; the lower triangle is green','917bea609dfd2c34c7bed3f5910682cf31fe7bbdbfca2e9fe11a799223cbf025','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d72eff6d148bc6f52aa07982fa1c4098a97f3e6f51f179868b2156cc277b566b',1994,'SO','Somalia','government',859,'Names;
conventional Ion i; form: none
conventional short fonn: Somalia
former: Somali Republic
Digraph; SO
Type: none
Capital; Mogadishu
Administrative divisions: 18 regions
(plural — NA. singular — gobolka); Awdal.
Bakool. Bar.aadir. Bari. Bay. Galguduud.
Gedo, Hiiraan, Jubbada Dhexc. Jubbada
Hoose, Mudtig. Nugaal. Sanaag, Shabeellaha
Dhexe. Shabeellaha Hoose, Sool. Togdheer.
Woqooyi Galbeed
Independence: I July 1960 (from a merger of
British Somaliland, which became independent
from the UK on 26 June 1960. and Italian
Somaliland, which became independent from
the Italian-administered UN trusteeship on 1
July I960, to form the Somali Republic)
National holiday: NA
Constitution: 25 August 1979. presidential
approval 23 September 1979
Legal system: NA
Suffrage: 1 8 years of age: universal
Executive branch: Somalia has no
functioning government; presidential elections
last held 23 December 1986 (next to be held
NA): rcsull.s — President SIAD was reelected
without opposition
Legislative branch: unicameral People''s
Assembly
People ’.V Assemhly (Golalia Shachiga):
elections last held 31 December 1984 (next to
be held NA); results — SRSP was the only
party; seats — (177 total. 171 elected) SRSP
171; note — the United Somali Congress (USC)
ousted the regime of Maj. Gen. Mohamed
SIAD Barreon 27 January 1991; the
provisional government has promised that a
democratically elected government w''ll be
established
Judicial branch: Supreme Court (non-
functioning)
Political parties and leaders: the United
Somali Congress (USC) ousted the former
regime on 27 January 1991; formerly the only
party was the Somali Revolutionary Socialist
Pany (SRSP), headed by former President and
Commander in Chief of the Army Maj. Gen.
Mohamed SIAD Barre
Other political or pressure groups:
numerous clan and stibclan factions arc
currently vying for power
Member of: ACP.AIDB. AFESD. AL. AMF.
CAEU. ECA. FAO. G-77. IBRD, ICAO. IDA,
IDB, IFAD, IFC, IGADD. ILO. IMF. IMO.
INTELSAT. INTERPOL. IOC. lOM
(observer). ITU. LORCS, NAM. OAU, OIC,
UN. UNCTAD, UNESCO. UNHCR. UNIDO.
UPU. WHO, WIPO. WMO
Diplomatic representation in US: Somalian
Embassy ceased operations on 8 May 1991
US diplomatic representation; the US
Embassy in Mogadishu was evacuated and
closed indefinitely in January'' 1991; United
States Liaison Office (USLO) opened in
December 1992
Flag: light blue with a large white five-
pointed star in the center: design based on the
flag of the UN (Italian Somaliland was a UN
trust territory)','a6bb481a45a4ee5cc186da333178ba33ff4b113ee22b0df81f30b9f59140800c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba055111266b64c6571635f9a7ffed8ecc8764dea38d915015541545646ae4e9',1994,'SD','Sudan','government',866,'Names:
conventional long form: Republic of the Sudan
conventional short form: Sudan
local long form: Jumhuriyat as-Sudan
local short form: As-Sudan
former: Anglo-Egyptian Sudan
Digraph: SU
Type: ruling military junta — Revolutionary
Command Council— dissolved on 1 6 October
1993 and government civilianized
Capital: Khartoum
Administrative divisions; 9 states (wilayat,
singular — wilayat or wilayah*); A''ali an Nil,
A1 Wusta*, A1 Lstiwa''iyah*, Al Khartum, Ash
Shamaliyah*, Ash Sharqiyah*, Bahral Ghazal,
Darfur, Kurdufan
Independence: 1 January 1956 (from Egypt
and UK)
National holiday: Independence Day, 1
January (19.56)
Constitution; 12 April 1973, suspended
following coup of 6 April 1985; interim
constitution of 10 October 1985 suspended
following coup of 30 June 1989
Legal system: based on English common law
and Islamic law; as of 20 January 1991 , the
now defunct Revolutionary Command Council
impo.sed Islamic law in the northern states; the
council is still studying criminal provisions
under Islamic law; Lslamic law applies to all
residents of the six northern states regardless of
their religion; some .separate religious courts:
accepts compulsory ICJ Jurisdiction, with
reservations
Suffitige; none
Executive branch:
Chief of State and Head of Government:
President Lt. General Umar Hasan Ahmad al-
BASHIR (since 16 October 1993); prior to 16
October 1 993, BASHIR served concurrently as
Chief of State. Chairman of the RCC, Prime
Minister, and Minister of Defence (since 30
June 1989); Vice President Major General al-
Zubayr Muhammad SALIH (since 19 October
1993); note — upon its dissolution on 16
October 1993, the RCC’s executive and
legislative powers were devolved to the
President and the Transitional National
Assembly (TNA). Sudan''s appointed
legislative body
cabinet: Cabinet: appointed by the president;
note — on 30 October 1993 President BASHIR
announced a new, predominantly civilian
cabinet, consisting of 20 federal ministers,
most of whom retained their previous cabinet
positions
note; Lt, Gen. BASHIR’s government is
dominated by members of Sudan''s National
Islamic Front, a fundamentalist piditical
organization fonned from the Muslim
Brotherhood in 1986; front leader Hasan
al-TURABI controls Khartoum’s overall
domestic and foreign policies
Legislative branch: appointed 3(X)-member
Transitional National As,sembly; officially
assumes all legislative authority for Sudan
until the eventual, unspecified te.sumption of
notional elections
Judicial branch; Supreme Court. Special
Revolutionary Courts
Political parties and leaders; none: banned
following .30 June 1989 coup
Other political or pressure groups;
National Islamic Front. Hasan al-TURABl
Member of: ABEDA. ACP, AfDB. AFESD,
AL. AMF. CAEU. CCC. ECA. FAO. G-77.
IAEA. IBRD. ICAO, IDA. IFAD. IFC,
IGADD. ILO. IMF. IMG. INTELSAT,
INTERPOL. IOC. ITU, LORCS, NAM. OAU,
PCA, UN, UNCTAD. UNESCO. UNHCR.
UNIDO, UPU, WFTU, WHO, WIPO, WMO,
WTO
Diplomatic representation in US:
chief of mission: Ambassador Ahmad
SULAYMAN
chancery: 2210 Massachasetts Avenue NW
Washington, DC 20008
telephone; (202) 338-8565 through 8570
FAX: (202) 667-2406
US diplomatic representation:
chief of mission: Ambassador Donald K.
PETTERSON
embassy: Shar''ia Ali Abdul Latif, Khartoum
mailing address: P, O, Box 699, Khartoum, or
APO AE 09829
telephone: 74700 or 7461 1
FAX: Telex 22619 AMEM SD
Flag: three equal horizontal bands of red
(top), white, and black with a green isosceles
triangle based on the hoist side','0ce6a3531ebb0ddc79f4e9fc20b264a907e1705a8e26940a982e26844e24c549','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fd94e5cd36ab9e2e5ce7433ed37d17564ab731de9bd66c3684f42ec837491bf',1994,'SR','Suriname','government',872,'Names:
conventional long form: Republic of Suriname
conventional short form: Suriname
local long form: Republiek Suriname
local short form: Suriname
former: Netherlands Guitna, Dutch Guiana
Digraph: NS
Type: republic
Capital: Paramaribo
Administrative divisions: 1 0 di stricts
(distrikten, singular — distrikt); Brokopondo,
Commewijnc, Coronie, Marowijne, Nickerie,
Para, Paramaribo, Saramacca, Sipaliwini,
Wanica
Independence: 25 November 1975 (from
Netherlands)
National holiday: Independence Day, 25
November (1975)
Constitution: ratified 30 September 1987
Legal system: NA
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state and head of government:
President Ronald R. VENETIAAN (since 16
September 1991); Vice President and Prime
Minister Jules R. AJODHIA (since 16
September 1991); election last held 6
September 1991 (next to be held NA May
1996); results — elected by the National
Assembly— Ronald VENETIAAN (NF) 80%
(645 votes), Jules WIJDENBOSCH (NDP)
14% ( 1 1 5 votes), Hans PRADE (DA ’91)6%
(49 votes)
cabinet: Cabinet of Ministers; appointed by the
president from members of the National
Assembly
note: Commander in Chief of the National
Army maintains significant power
Legislative branch: unicameral
National Assembly (Assemblee Nationale):
elections last held 25 May 1991 (next to be
held NA May 1996); results — percent of vote
NA; seats— (51 total) NF 30, NDP 10, DA *91
9, Independent 2
Judicial branch: Supreme Court
Political parties and leaders: The New
Front (NF), a coalition of four parties (NFS,
VHP, KTPI, SPA), leader Ronald R.
VENETIAAN; Progressive Reform Party
(VHP), Jaggcmath LACHMON; National
Party of Suriname (NPS), Ronald
VENETIAAN; Party of National Unity and
Solidarity (KTPI), Willy SOEMITA; Suriname
Labor Party (SPA) Fred DERBY; Democratic
Alternative ’91 (DA ''91), Winston
JESSURUN, a coalition of four parties (AF,
HPP, Pendawa Lima, BEP) formed in January
1991; Alternative Forum (AF). Gerard
BRUNINGS, Winston JESSURUN; Reformed
Progressive Party (HPP), Panalal
PARMESSAR; Party for Brotherhood and
Unity in Politics (BEP), Caprino ALLENDY;
Pendawa Lima, Marsha JAMIN; National
Democratic Party (NDP). Desire BOUTERSE;
Progressive Workers’ and Farm Laborers’
Union (PALU), irlwan KROLIS, chairman;
Other political or pressure groups:
Surinamese Liberation Army (SLA), Ronnie
BRUNSWIJK. Johan "Castro" WALLY;
Union for Liberation and Democracy, Kofi
AFONGPONG; Mandela Bushnegro
Liberation Movement, Leendert ADAMS;
Tucayana Amazonica, Alex JUBITANA,
Thomas SABAJO
Member of: ACP, CARICOM (observer),
ECLAC, FAQ. GATT, G-77, lADB, IBRD,
ICAO, ICFTU, IFAD. ILO, IMF. IMO.
INTERPOL, IOC, INTELSAT (nonsignatory
user), ITU, LAES, LORCS. NAM, OAS,
OPANAL, UN. UNCTAD. UNESCO,
UNIDO. tJPU, WCL, WHO. WlPO, WMO
Diplomatic representation in US:
chief of mission: Ambassador Willem A.
UDENHOUT
chancery: Suite 108, 4301 Connecticut
Avenue NW, Washington, DC 20008
telephone: (202) 244-7488 or 7490 through
7492
FAX: (202) 244-5878
consulate(s) general: Miami
US diplomatic representation:
chief of mission: Ambassador Roger R.
GAMBLE
embassy: Dr. Sophie Redmonstraat 129,
Paramaribo
mailing address: P. O. Box 1821, Paramaribo
telephone: [597] 472900, 477881, or 476459
FAX: [597 J 410025
Flag: five horizontal bands of green (top,
double width), white, red (quadruple width),
white, and green (double width); there is a
large yellow five-pointed star centered in the
red band
Names;
conventional long form; none
conventional short form: Svalbard
Digraph: SV
Type: territory of Norway administered by the
Ministry of Industry, Oslo, through a governor
(sysselmann) residing in Longyearbyen,
Spitsbergen; by treaty (9 February 1920)
sovereignty was given to Norway
Capital: Longyearbyen
Independence: none (territory of Norway)
National holiday: NA
Legal system: NA
Executive branch:
Chief of State; King HARALD V (since 17
January 1991)
Head of Government; Governor Odd
BLOMDAL (since NA); Assistant Governor
Jan-Atle HANSEN (since NA September
1993)
Member of: none
Flag: the flag of Norway is used','685ee0446a9de1bee8554903912e016085ff88e7b8cfc474c32e974fb72e8783','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d871b6306d2934b71e12afa8ab9a9a3fd8d13ccc4300ebc19ce9450cab9a8615',1994,'TJ','Tajikistan','government',873,'conventumal short form: Tajikistan
liH''al long form; Respublika i Tojikiston
hwal short form: none
former: Tajik Soviet Socialist Republic
Digraph: Tl
Type: republic
Capital: Dushanbe
Administrative divisions: 2 oblasts
(viloyotho, singular — viloyat) and one
autonomous oblast* (viloyati avtonomii);
Viloyati Avtommiii Badakhshoni Kuni*
(Khorugh — formerly Khorog). Viloyati
Khatlon (Qurghonteppa — fonnerly Kurgan-
Tyube). Viloyati Leninobad( Khujand—
formerly Leninabad)
note; the administrative center names are in
parentheses
Independence: 9 September 1991 (from
Soviet Union)
National hcliday: National Day, 9 September
(1991)
Cottstilulioii: a refetendum on new
constitution planned for June 1994
Legal system: based on civil law system: no
judicial review of legislative acts
Suffrage: 18 years of age; universal
Executive branch:
chief of state; Head of State and Assembly
Chairman Emomili RAKHMONOV (since NA
November '' 992): election last held 27 October
1991 (next to be held NA September 1994);
results — Rakhman NABIYEV. Communist
Party 60%; Davlat KHUDONAZAROV,
Democratic Party, Islamic Rebirth Party and
Rastokhoz Party .30%
head of government: Prime Mini.ster Abdujalil
SAMADOV (since 27 December 99.3)
cabinet; Council of Ministers
note; the presidency was abolished in
Noveniber 1992. when RAKHMANOV
became head of state; a referendum on
presidential or parliamentary system is planned
for June 1994
Legislative branch: unicameral
Supreme Soviet; elections last held 25
February 1990 (next to be held NA September
1994); results — Communist Party 99%, other
I %; seats — (2.30 total) Communist Party 227,
other .3
Judicial branch: Prosecutor General
Political parties and leaders: Communist
Party (Tajik Stx''ialist Party— TSP), Shtxli
SHABDOLOV. chairman; Tqjik Democmtic
Party (TOP). Shodmon YUSUF; Islamic
Revival Party (IRP). Mohammed Sharif
HIMOTZODA. Davat OUSMAN. Rastokhez
Movement. Tohir ABDUJABBAR: Lali
Badakhshan Society. Atobek AMIRBEK
note; all the above-listed parties but the
Communist Party were banned in June 199.3
Other political or pressure groups:
Tajikistan Opposition Movement based in
northern Afghanistan
Member of: CIS, CSCE, EBRD. ECO.
ESCAP. IBRD, IDA, IDB. IMF. INTELSAT
(nonsignatory user), IOC. NACC. OIC. UN.
UNCTAD. UNESCO. UNIDO, WHO. WMO
Diplomatic representation in US:
chief ofmisshn: N A
chancer}'': NA
telephone; NA
US diploniatic representation:
chief of mission: Ambassador Stanley T.
ESCUDERO
embassy: Hotel October. I05A Rudaki
Prospect. Du;;hanbe
mailing address; use embassy street address
telephone: [71 (.3772) 2l-0.3-.56 and 2 1 -0.3-60
Flag: three horizontal stripes of red (top), a
wider stripe of white, and green; a crown
surou.jnted by seven five-pirinted stars is
kvated in the center of the white stripe
.385
Tajikistan (continued)','3ce9fe44233328d67c4a2a48d48039661363e716e09f127f5cebb4a9d4c0e4d8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e89a7a4960f8c8eab5026fbc34e5d0c80895c4eadbf194ca587746c68bee445',1994,'TM','Turkmenistan','government',885,'Names:
conventional long form: none
conventional short form: Turkmenistan
local long form: Tiurkmenostan Respublikasy
local short form: Turkmenistan
former: Turkmen Soviet Socialist Republic
Digraph; TX
Type: republic
Capital: Ashgabat
Administrative divisions: 5 welayatlar
(singular— welayat): Ahal Welayaty
(Ashgabat), Balkan Welayaty (Nebitdag),
Dashhowuz Welayaty (formerly Tashauz),
Lehap Welayaty (Charjew), Maty Welayaty
note: names in parentheses are administrative
centers when name differs from welayat name
Independence: 27 October 1991 (from the
Soviet Union)
National holiday: Independence Day, 27
October (1 991)
Constitution: adopted 1 8 May 1992
I.«gal system: based on civil law system
403
Turkmenistan (continued}
Suffrage; 1 8 years of age; universal
Executive branch:
chief of stale; President Saparmurad
NIYAZOV (since NA October 1990); election
last held 21 June 1992 (next to be held NA
2002); results — Saparmurad NIY AZOV
99.5% (ran unopposed); note — a 15 January
1994 referendum extended NIYAZOV’s term
an additional five years until 2002 (99.99%
approval)
head of government; Prime Minister (vacant);
Deputy Prime Ministers Batyr SARDJAEV,
Valery G. OCHERTSOV, Orazgeldi
AIDOGDIEV. Djourakuli BABAKULIYEV,
Rejep SAPAROV. Boris SHIKHMURADOV,
Abad R:ZAEVA, Yagmur OVEZOV (since
NA)
cabinet; Council of Ministers
Legislative branch: under 1 992 constitution
there are two parliamentary bodies, a
unicameral People''s Council (Halk
Maslahaty — having more than 100 members
and meeting infrequently) and a 50-niember
unicameral Assembly (Majlis)
Assembly (Majlis); elections last held 7
January 1990 (next to be held late 1994 or early
1995); results — percent of vote by party NA;
seats — (175 total) elections not officially by
party, but Communist Party members won
nearly 90% of seats; note— seats to be reduced
to 50 at next election
Judicial branch: Supreme Court
Political parties and leaders:
ruling party; Democratic Party (formerly
Communist), chairman vacant
apposition; Party for Democratic
Development, Durdymurat HOJA-
MUKHAMMED, chairman; Agzybirlik,
Nurberdy NURMAMEDOV, cochairman.
Hubayberdi HALLIYEV, cochairman
note; formal opposition parties are outlawed;
unofficial, small opposition movements exist
Member of: CIS, CSCE, EBRD. ECE, ECO,
ESCAP, IBRD. ICAO. IDB, ILO, IMF, IMO,
INTELSAT (nonsignatory user), IOC, ITU,
NACC. OIC. UN. UNCTAD, UNESCO. UPU,
WHO. WMO
Diplomatic representation in US:
chief of mission; Ambassador Khalil UGUR
chancery; 151 1 K Street NW, Suite 4 1 2,
Washington, DC, 2(X)05
telephone; NA
US diplomatic representation:
chief of mission; Ambassador Joseph S.
HULINGS III
embassy; Yubilenaya Hotel. Ashgabat
mailing address; use embassy street address
telephone; [7] 36320 24-49-25 or 24-49-26
Flag: green field, including a vertical stripe on
the hoist side, with a claret vertical stripe in
between containing five white, black, and
orange carpet guls (an assymetrical design
used in producing rugs) associated with five
different tribes; a white crescent and five white
stars in the upper left corner to the right of the
carpet guls','8c662d79fede8ac422e6a9725ae1f14c30e245d7e9fb26c45bce69f97b7d33a5','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b5729476fddab23c87f05f7166534f3d3e8dc7c9d3c9e1541751d32ec66b42f',1994,'BS','Bahamas','government',890,'Names:
conventional long form: none
conventional short form; Turks and Caicos
Islands
Digraph; TK
Type: dependent territory of the UK
Capital; Grand Turk
Administrative divisions: none (dependent
territory of the UK)
Independence: none (dependent territory of
the UK)
National holiday: Constitution Day, 30
August (1976)
Constitution: inuoduced 30 August 1976,
suspended in 1986. restored and revised 5
March 1988
Legal system: based on laws of England and
Wales with a small number adopted from
Jamaica and The Bahamas
Suffrage: 1 8 years of age; universal
Executive branch:
chief of slate: Queen ELIZABETH II (since 6
February 1953). represented by Governor
Martin BOURXE (since NA February 1993)
head of government: Chief Minister
Washington MISSICK (since N A March 1991)
cabinet: Executive Council; consists of three
ex-offtcio members and five appointed by the
governor from the Legislative Council
Legislative branch: unicameral
Legislative Council: elections last held on 3
April 1991 (next to be held NA); results —
percent of vote by party NA; seats — (20 total.
Selected) PNP 8. PDM 5
Judicial branch: Supreme Court
Political parties and leaders: Progressive
405','8ce0a1f5e63ee8e94cc6b583b49d6833dff47d2fef7eceee1eb9edf841be83d1','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9cded123bfd81ac17dda2efe4c031495dfe94690863fc1c992e41a1d1775ac2',1994,'TC','Turks and Caicos Islands','government',891,'(continued)
National Patty (PNP), Washington MISSICK;
People’s Democratic Movement (PDM),
Oswald SKIPPINOS; National Democntic
Alliance (NDA), Ariel MISSICK
Member of: CARICOM (associate). CDB,
INTERPOL (subbureau)
Diplomatic representation in US: none
(dependent territoiy of the UK)
US diplomatic representation; none
(dependent territory of the UK)
F1^: blue with the flag of the UK in the upper
hoist-side quadrant and the colonial shield
centered on the outer half of the flag; the shield
is yellow and contains a conch shell, lobster,
and cactus','5410c65de179c3027eac98e89428e8b4f4969c42913e296c09b139f48bedde25','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e4e59237f53df65993abf368ff27de6810e178139537a964864c9c59762a8ed',1994,'TV','Tuvalu','government',896,'Names;
conventional long form; none
conventional short form; Tuvalu
former; Ellice Islands
Digraph: TV
Type: democracv began debating republic
status in 199"'': ..mdum expected in 1993
Capital: Fu.nf.
Administraiit I isions: none
Independence; ''tober 1978 (from UK)
National hoUda> . .adependence Day, I
October ( 1978)
Constitution: 1 October 1978
Legal system: NA
Suffrage: 18 years ot .^.e, universal
Executive branch:
chief of state; Quee.- .-i -ZABETH 11 (since 6
February 1952). repre.sonted by Governor
General Tomu Malaefono SIONE (since NA
1993)
head of government; Prime Minister Kamuta
LATASl (since 10 December 1993); Deputy
Prime Minister Otinielu TAUSI (since 10
December 1993)
cabinet; Cabinet: appointed by the governor
general on recommendation of the prime
minister
Legislative branch: unicameral
Parliament (Palamene); elections last held 25
November 19''..-3 (next to be held by NA 1997);
results — percent of vote NA; seats — ( 1 2 total)
Judicial branch: High Court
Political parties and leaders: none
Member of: ACP, AsDB, C (special).
ESCAP, INTELSAT (nonsignatory user). ITU,
SPARTECA, SPC, SPF. UNESCO. UPU.
WHO
Diplomatic representation in US: Tuvalu
has no mission in the US
US diplomatic representation: none
Flag; light blue with the flag of the UK in the
upper hoist-side quadrant; the outer half of the
flag represents a map of the country with nine
yellow Five-pointed stars symbolizing the nine
islands','bbe5b995ee966c9eaf94271e44b90000ce62c7728b15fd0940fed0d1824b8348','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a5fdfd4140aac7c3331d14578fc052ee6dab8e6d2172446c47e127a0c50fe7f',1994,'UG','Uganda','government',900,'Names:
conventional long form: Republic of Uganda
conventional short form: Uganda
Digraph: UG
Type: republic
Capital: Kampala
Administrative divisions: 10 provinces;
Busoga, Central, Eastern. Karamoja. Nile.
North Buganda, Northern, South Buganda.
Southern, Western
Independence: 9 October 1962 (from UK)
National holiday: Independence Day, 9
October (1962)
Constitution: 8 September 1967, in process
of constitutional revision
Legal system: government plans to restore
system based on English common law and
customary law and reinstitute a normal judicial
system; accepts compulsory ICJ Jurisdiction,
with reservations
Sufft-age: 1 8 years of age; universal
Executive branch:
chief of state: President Lt. Gen. Yoweri
Kaguta MUSEVENI (since 29 January 1986);
Vice President Samson Babi Mululu
KISEKKA (since NA January 1991)
head of government: Prime Minister George
Cosmas ADYEBO (since NA January 1991)
cabinet; Cabinet; appointed by the president
Legislative branch; unicameral
National Resistance Council: elections last
held 1 1-28 February 1989 (next to be held by
January 1995); results — NRM was the only
party; seats — (278 total, 2 10 indirectly elected)
210 members elected without patty affiliation
Judicial branch: Court of Appeal, High
Court
Political parties and leaders: only party —
National Resistance Movement (NRM),
Yoweri MUSEVENI
note; Ugandan People’s Congress (UPC),
Milton OBOTE; Democratic Patty (DP), Paul
SSEMtXiEERE; and Conservative Party (CP),
Joshua S. MAYANJA-NKANGl continue to
exist but are all proscribed from conducting
public political activities
Other political or pressure groups:
Uganda People’s Front (UPF); Lord’s
Resistance Army (LRA); Ruwenzori
Movement
Member of: ACP, AfDB, C, CCC, EADB,
ECA, FAO, G-77. GATT. IAEA, IBRD,
ICAO, ICFTU, IDA, IDB, IFAD. IFC.
IGADD, ILO, IMF, INTELSAT, INTERPOL,
KX). lOM, ISO (correspondent), ITU,
LORCS. NAM, OAU, OIC, PCA, UN,
UNCTAD, UNESCO, UNHCR. UNIDO,
UNOSOM, UPU, WHO. WIPO. WMO, WTO
Diplomatic representation in US:
chief of mission: Ambassador S.ephen
Kapimpina KATENTA-APULI
chancers: 5909 16th Street NW, Washington,
DC 2001 1
telephone; (202) 726-7100 through 7102 and
726-0416
FAX: (202) 726-1727
US diplomatic representation:
chief of mission: Ambassador Johnnie
CARSON
embassy; Parliament Avenue, Kampala
mailing address: P. O. Box 7007, Kampala
telephone; [256] (41 ) 259792, 259793, 259795
Flag: six equal horizontal bands of black
(top), yellow, red, black, yellow, and red; a
white disk is superimposed at the center and
depicts a red-crested crane (the national
symbol) facing the staff side','1e2de6ffcfa96dd82f7d883842ff25f56f0406db91b8f3efdca429cf244c15dc','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8429622cfbb40a83d71788b90a42f1be1b2c0481993d6511e77f379fd0b70af',1994,'AE','United Arab Emirates','government',906,'Names:
conventional long form: United Arab Emirates
conventional short fonn; none
local long form; Al imarata al Arabiyuh al
Muttahidah
local short form; none
former; Trucial States
Abbreviation; UAE
Digraph: TC
Type: federation with specified powers
delegated to the UAE central government and
other powers reserved to member emirates
Capital: Abu Dhabi
Administrative divisions: 7emirates(imarat,
singular— imarah); Abu Zaby (Abu Dhabi),
''Ajman, Al Fujayrah, Ash Shariqah (Sharjah),
Dubayy. Ra''s al Khaymah, Umm al Qaywayn
Independence: 2 D^ember 1971 (.'' om UK)
National holiday: National Day, 2 December
(1971)
Constitution: 2 December 197 1 (provisional)
Legal system: secular codes are being
introduced by the UAE Government and in
.several member emirates; Islamic law remains
influential
Suflhige: none
Executive branch:
chief of state; President ZAYID bin Sultan Al
Nuhayyan, (since 2 December 1971 ), ruler of
Abu Dhabi; Vice President Shaykh Maktum
bin Rashid al-MAKTUM (since 8 October
1990). ruler of Dubayy
head of government; Wme Minister Shaykh
MAKTUM bin Rashid al-Maktum (since 8
October 1990). ruler of Dubayy; Deputy Prime
Minister Sultan bin Zayid Al NUHAYYAN
(since 20 November 1990)
Supreme Council of Rulers; composed of the
seven emirate rulers, the council is the highest
constitutional authority in the UAE; establishes
general policies and sanctions federal
legislation. Abu Dhabi and Dubayy rulers have
veto power: council meets four times a year
cabinet; Council of Ministers: appointed by
the president
Legislative branch: unicameral Federal
National Council (Majlis Watani Itihad): no
elections
Judicial branch: Union Supreme Court
Political parties and leaders: none
Other political or pressure groups: NA
Member of: APEDA. AFESD. AL, AMF,
CAEU. CCC. ESeWA. FAO, G-77. GATT.
GCX:, IAEA, IBRD. ICAO. IDA, IDB, IFAD.
IFC. ILO, IMF, IMO. INMARSAT.
INTELSAT. INTERPOL. IOC, ISO
(correspondent), ITU, LORCS, NAM,
OAPEC. OIC. OPEC. UN. UNCTAD.
UNESCO. UNIDO. UNOSOM, UPU. WHO.
WIPO, WMO, WTO
Diplomatic representation in US:
chief of mission; Ambassador Muhammad bin
Husayn al-SHAALi
chancerv; Suite 600, 3000 K Street NW.
Washington. DC 20007
telephone; (202) 338-6.500
US diplomatic representation:
chief of mission; Ambassador William A.
RUGH
embassy: Al-Sudan Street. Abu Dhabi
mailing address; P. O. Box 4009, Abu Dhabi
ffiVpW.- 19711(2)3.36691
FAY.- 1971 1 (2) 318441
consulatels) general; Dubayy (Dubai)
412
United Klntdom
Fta|i three equal horltontal bands of green
(top), white, and black with a thicker vertical
red band on the hoist side
Names:
conventional long form: United Kingdom of
Great Britain and Northern Ireland
conventional short form: United Kingdom
Abbrev iation: UK
Digraph: UK
Type: constitutional monarchy
Capital: London
Administrative divisions: 47 counties, 7
metropolitan counties, 26 districts, 9 regions,
and 3 islands areas
England: 39 counties, 7 metropolitan
counties*; Avon, Bedford, Berkshire,
Buckingham, Cambridge, Cheshire,
Cleveland, Cornwall, Cumbria, Derby, Devon,
Dorset, Durham, East Sussex, Essex,
Gloucester, Greater London*. Greater
Manchester*, Hampshire, Hereford and
Worcester, Hertford, Humberside, Isle of
Wight, Kent, Lancashire, Leicester, Lincoln,
Merseyside*, Norfolk, Northampton,
Northumberland, North Yorkshire,
Nottingham, Oxford, Shropshire, Somerset.
South Yorkshire*, Stafford, Suffolk, Surrey,
Tyne and Wear*, Warwick, West Midlands*,
West Sussex, West Yorkshire*, Wiltshire
Northern Ireland: 26 districts; Antrim, Ards,
Armagh, Ballymena, Ballymoney, Banbridge,
Belfast, Carrickfergus, Castlereagh, Coleraine,
Cookstown, Craigavon, Down, Dungannon,
Fermanagh, Lame, Limavady, Lisburn,
Londonderry, Magherafelt, Moyle, Newry and
Moumc, Newtownabbey, North Down,
Omagh, Strabane
Scotland: 9 regions, 3 islands areas*; Borders.
Central. Dumfries and Galloway, Fife,
Grampian, Highland, Lothian, Orkney*,
Shetland*, Strathclyde, Tayside, Western
Isles*
Wales: 8 counties; Clwyd, Dyfed, Gwent,
Gwynedd, Mid Glamorgan, Powys, South
Glamorgan, West Glamorgan
Dependent areas: Anguilla. Bermuda,
British Indian Ocean Territory, British Virgin
Islands, Cayman Islands, Falkland Islands,
Gibraltar, Guernsey, Hong Kong (scheduled to
become a Special Administrative Region of
China on 1 July 1997), Jersey, Isle of Man,
Montserrat, Pitcairn Islands, Saint Helena,
South Georgia and the South Sandwich
Islands, Turks and Caicos Islands
Independence: I January 1801 (United
Kingdom established)
National holiday: Celebration of the
Birthday of the Queen (second Saturday in
June)
Constitution: unwritten; partly statutes.
partly common law and practice
Legal system: common law tradition with
early Roman and modem continental
influences; no judicial review of Acts of
Parliament; accepts compulsory ICJ
jurisdiction, with reservations
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II (since 6
February 1952); Heir Apparent Prince
CHARLES (son of the Queen, bom 14
November 1948)
head of government: Prime Minister John
MAJOR (since 28 November 1990)
cabinet: Cabinet of Ministers
Legislative branch: bicameral Parliament
House of Lords: consists of a 1 ,200-member
body, four-fifths are hereditary peers, 2
archbishops, 24 other senior bishops, serving
and retired Lords of Appeal in Ordinary, other
life peers, Scottish peers
House of Commons: elections last held 9 April
1992 (next to be held by NA April 1997);
results — Conservative 41 .9%, Labor 34.5%,
Liberal Democratic 17.9%, other 5.7%;
seats — (65 1 total) Conservative 336, Labor
27 1 , Liberal Democratic 20, other 24
Judicial branch; House of Lords
Political parties and leaders; Conservative
and Unionist Party, John MAJOR; Labor
Party; Liberal Democrats (LD), Jeremy
(Paddy) ASHDOWN; Scottish National Party,
Alex SALMOND; Welsh National Party (Plaid
Cymm), Dafydd Iwan WIGLEY; Ulster
Unionist Party (Northern Ireland), James
MOLYNEAUX; Democratic Unionist Party
(Northern Ireland), Rev. Ian PAISLEY; Ulster
Popular Unionist Patty (Northern Ireland), Sir
James KILFEDDER; Social Democratic and
Labor Party (SDLP. Northern Ireland), John
HUME; Sinn Fein (Northern Ireland), Gerry
ADAMS
Other political or pressure groups: Trades
Union Congress; Confederation of British
Industry; National Farmers'' Union; Campaign
for Nuclear Disarmament
Member of: AfDB, AG (observer). AsDB,
Australian Group, BIS, C, CCC, CDB (non-
regional), CE CERN, COCOM, CSCE,
EBRD, EC, ECA (associate). ECE, ECLAC,
ElB, ESCAP, ESA, FAO, G-5, G-7, G-10,
GATT. lADB. IAEA, IBRD, ICAO, ICC,
ICFTU, IDA, lEA, IFAD, IFC, ILO. IMF,
IMO. INMARSAT, INTELSAT, INTERPOL,
IOC, lOM (observer). ISO. ITU, LORCS,
MINURSO, MTRC, NACC, NATO. NEA.
NSG, OECD. PCA, SPC, UN, UNCTAD,
UNFICYP, UNHCR, UNIDO, UNIKOM,
UNPROrOR, UNRWA. UN Security Council.
UNTAC, UN Trusteeship Council. UPU,
WCL, WEU, WHO. WIPO, WMO, ZC
Diplomatic representation in US:
chief of mission: Ambassador Sir Robin
RENWICK
chancery: 3 1 00 Massachusetts Avenue NW,
Washington, DC 20(X)8
414
telephone: (202) 462-\\3AQ
FAX: (202) 898-4255
consulate(s) general: Atlanta, Boston,
Chicago, Cleveland, Houston, Los Angeles,
New York, and San Francisco,
consulate(s): Dallas, Miami, Nuku''alofa, and
Seattle
US diplomatic representation;
chief of mission: Ambassador-designate Adm.
William CROWE
embassy: 24/3 1 Grosvenor Square, London,
W.IAIAE
mailing address: PSC 801 , Box 40, FPO AE
09498-4040
telephone: [44] (7 1 ) 499-9000
FAX: [44] (71)409-1637
consulate(s) general: Belfast and Edinburgh
Flag; blue with the red cross of Saint George
(patron saint of England) edged in white
superimposed on the diagonal red cross of
Saint Patrick (patron saint of Ireland) which is
superimposed on the diagonal white cross of
Saint Andrew (patron saint of Scotland);
known as the Union Flag or Union Jack; the
design and colors (especially the Blue Ensign)
have been the basis for a number of other flags
including dependencies. Commonwealth
countries, and others','6eb452ef9c3f32742cbac5e112bc3848a9a675e86212526d24def02ca4c0b36d','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22008ef76dd463e5881d5c9340a2cf908ba0775f3b5ef556338d606d03b11053',1994,'UY','Uruguay','government',917,'Names:
conventional long form: Oriental Republic of
conventional short form; Uruguay
local long farm: Republica Oriental del
local short form; Uruguay
Digraph; UY
Type: republic
Capital: Montevideo
Administrative divisions: 19 departments
(depaitamentos, singular — departamento);
Artigas, Canelones, Cerro Largo, Colonia,
Durazno, Flores, Florida, Lavalleja,
Maldonado, Montevideo, Paysandu, Rio
Negro, Rivera, Rocha, Salto, San Jose,
418
Soriano, Tacuarembo, Treinta y Tres
Independence: 25 August 1 828 (from Brazil)
National holiday; Independence Day, 25
August (1828)
Constitution: 27 November 1966, effective
February 1967, suspended 27 June 1973, new
constitution rejected by referendum 30
November 1980
Legai system; based on Spanish civil law
system; accepts compulsory ICJ jurisdiction
Suffrage: 1 8 years of age; universal and
compulsory
Executive branch:
chief of state and head of government:
President Luis Alberto LACALLE (since I
March 1990); Vice President Gonzalo
AGUIRRE Ramirez (since I March 1990);
election last held 26 November 1989 (next to
be held NA November 1994); results — Luis
Alberto LACALLE Herrera (Blanco) 37%,
Jorge BATLLE Ibanez (Colorado) 29%, Liber
SEREGNI Mosquera (Broad Front) 20%
cabinet: Council of Ministers; appointed by
the president
Legislative branch: bicameral General
Assembly (Asamblea General)
Chamber of Senators ( Camara de Senadores):
elections last held 26 November 1989 (next to
be held NA November 1994); results — Blanco
40%, Colorado 30%, Broad Front 23% New
Space 7%; seats— (30 total) Blanco 1 2,
Colorado 9, Broad Front 7, New Space 2
Chamber of Representatives ( Camera de Rep-
resentantes): elections last held NA November
1989 (next to be held NA November 1994);
results — Blanco 39%. Colorado 30%, Broad
Front 22%, New Space 8%, other 1%; seats—
(99 total) number of seats by party NA
judicial branch: Supreme Court
Political parties and leaders: National
(Blanca) Party; Colorado Party, Jorge
BATLLE; Broad Front Coalition, Gen. Liber
SEREGNI Mosquera; New Space Coalition.
Hugo BATALLA
Member of: AG (observer), CCC, ECLAC,
FAO, G-1 1, G-77. GATT. lADB. IAEA,
IBRD, ICAO, ICC, IFAD. IFC, ILO, IMF,
IMO, INTELSAT, INTERPOL, IOC, lOM,
ISO, ITU, LAES, LAIA, LORCS,
MERCOSUR, NAM (observer). OAS,
OPANAL. PCA, RG. UN. UNCTAD.
UNESCO, UNIDO, UNIKOM, UNMOGIP,
UNOMOZ, UNTAC, UPU, WCL, WFTU,
WHO, WIPO, WMO, WTO
Diplomatic representation in US:
chief of mission: Ambassador Eduardo
MACGILLYCUDDY
chancery: 1 9 1 8 F Street NW, Washington, DC
20006
telephone: telephone (202) 331-1313 through
1316
consulate(s) general: Los Angeles, Miami,
and New York
consulate(s): New Orleans
US diplomatic representation:
chief of mission: Ambassador Thomas DODD
embassy: Lauro Muller 1776, Montevideo
mailing address: APO AA 34035
telephone: [598] (2) 23-60-61 or 48-77-77
MX.- [598] (2)48-86-11
Flag: nine equal horizontal stripes of white
(top and bottom) alternating with blue; there is
a white square in the upper hoi.st-side corner
with a yellow sun bearing a human face known
as the Sun of May and 16 rays alternately
triangular and wavy','ebeaefb32102c14767cc5525103ee43a11d27d30fbf16b14215656dea6a6919a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86e0a5292d2598f4d310f67b294ddcd8d89439a0da8f68aa2fbfb30e02ac6b7d',1994,'UZ','Uzbekistan','government',923,'Names:
conventional long form: Republic of
conventional short form: Uzbekistan
local long form: Uzbekiston Respublikasi
local short form: none
former; Uzbek Soviet Socialist Republic
Digraph: UZ
Type: republic
Capital: Tashkent (Toshkent)
Administrative divisions: liwiloyatlar
(singular — wiloyat), I autonomous republic''^
(respublikasi, singular — respublika), and 1
city** (shahri); Andijon Wiloyati, Bukhoro
420
Wiloyati, Jizzakh Wiloyati, Farghona
Wiloyati, Karakatpakstan* (Nukus),
Qashqadaryo Wiloyati (Qarshi), Khorazm
Wiloyati (Urganch), Namangan Wiloyati,
Nawoiy Wiloyati, Samarqand Wiloyati,
Sirdaryo Wiloyati (Guliston), Surkhondaryo
Wiloyati (Termiz), Toshkent Shahri**,
Toshkent Wiloyati
note: an administrative division has the same
name as its administrative center (exceptions
have the administrative center name following
in parentheses)
Independence: 31 August 1991 (from Soviet
Union)
National holiday: Independence Day, I
September (1991)
Constitution: new constitution adopted 8
December 1992
Legal system: evolution of Soviet civil law;
still lacks independent judicial system
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Islam KARIMOV
(since NA March 1990): election last held 29
December 1991 (next to be held NA December
1996): results— Islam KARIMOV 86%,
Mukhammad SOLIKH 12%, other 2%
head of government: Prime Minister
Abdulkhashim MUTALOV (since 13 January
1992), First Deputy Prime Minister Ismail
Hakimovitch DJURABEKOV (since NA)
cabinet: Cabinet of Ministers; appointed by the
president with approvai of the Supreme
Assembly
Legislative branch; unicameral
Supreme Soviet- elections last held 1 8
February 1990 tnext to be held winter 1994);
results — percent of vote by party NA; seats —
(S(X) total) Communist 450, ERK iO, other 40;
note — total number of seats will be reduced to
250 in next election
Judicial branch: Supreme Court
Political parties and leaders; Peo;
Democratic Party (PDP; formeriy C''oiiimunist
Party), Islam A. KARIMOV, chairman: Erk
(Freedom) Democratic Party (EDP),
Muhammad SOLIKH, chairman (in exile):
note — ERK was banned 9 December 1992
Other political or pressure groups: Birlik
(Unity) People''s Movement (BPM), Abdul
Rakhim PULATOV, chairman (in exile);
Islamic Rebirth Party (IRP), Abdullah
UTAYEV, chairman
note: PULATOV (BPM) and SOLIKH (EDP)
are both in exile in the West; UTAYF" MRP)
is either in prison or in exile
Member of: CCC, CIS, CSCE, EbRD, ECE,
ECO, ESCAP, IBRD, ICAO, IDA, IFC, ILO,
IMF, IOC, ITU, NACC, NAM, UN,
UNCTAD, WHO, WMO
Diplomatic representation In US:
chief of mission: Ambassador Fatikh
TESHABAYEV
chancers-: Suites 619 and 623, 151 1 K Street
NW, Washington DC, 20005
telephone: (202) 638-4266/4267
FAX: (202) 638-4268
consulate(s) general: New York
US diplomatic representation:
chief of mission: Ambassador Henry L.
CLARKE
embassy: 82 Chelanzanskaya, Tashkent
mailing address: use embassy street address
telephone: [7] (3712) 77-14-07, 77-11-32
FAY,- [71(3712)77-69-53
Flag: three equal horizontal bands of blue
(top), white, and green .separated by red
fimbriations with a crescent moon and 1 2 stars
in the upper hoist-side quadrant','3f76a29cf00439450a7c8465c8785f8456d5c5b3f11b81712b9de3b552b17e29','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5126a34611cee0d1e995ed3917bd0062976baaa916540d1c406db844c755f9c3',1994,'VU','Vanuatu','government',929,'Names:
conventional long form: Republic of Vanuatu
conventional short form: Vanuatu
former: New Hebrides
Digraph: NH
Type: republic
Capital: Port-Vila
Administrative divisions: 1 1 island councils;
Ambrym, Aoba/Maewo, Banks/Torres, Efate,
Epi, Malakula, Paama, Pentecote, Santo/Malo,
Shepherd, Tafea
Independence: 30 July 1980 (from France
and UK)
National holiday: Independence Day, 30 July
(1980)
Constitution: 30 July 1980
Legal system: unified system being created
from former dual French and British systems
SulDage: 1 8 years of age; universal
Executive branch;
chief of state: President Jean Marie LEYE
(since 2 March 1994)
head of government: Prime Minister Maxime
CARLOT Korman (since 16December 1991);
Deputy Prime Minister Sethy REGENVANU
(since 17 December 1991)
cabinet; Council of Ministers; appointed by
the prime minister, responsible to parliament
Lc^slative branch: unicameral
Parliament; elections last held 2 December
1991 (next to be held by November 1995);
note — after election, a coalition was formed by
the Union of Moderate Parties and the National
United Party to form a new government on 16
December 1991, but political party
associations are fluid; seats — (46 total) UMP
19; NUP 10; VP 10; MPP 4; TUP 1 ; Nagriamel
1 ; Friend 1
note; the National Council of Chiefs advises on
matters of custom and land
Judicial branch: Supreme Court
Political parties and leaders: Vanuatu Party
(VP), Donald KALPOKAS; Union of
Moderate Parties (UMP), Serge VOHOR;
Melanesian Progressive Party (MPP), Barak
SOPE; National United Party (NUP), Walter
LINl; Tan Union Party (TUP), Vincent
BOULEKONE; Nagriamel Party, Jimmy
STEVENS; Friend Melanesian Party, leader
NA
Member oft ACCT, ACP, AsDB, C, ESCAP,
FAO, G-77, IBRD, ICAO, IDA, IFC, IMF.
IMO, INTELSAT (nonsignatory user), IOC,
ITU, NAM, SPARTECA, SPC, SPF, UN,
UNCTAD, UNIDO, UPU, WHO, WMO
Diplomatic representation in US: Vanuatu
does not have a mission in the US
US diplomatic representation: the
ambassador to Papua New Guinea is accredited
to Vanuatu
Flag: two equal horizontal bands of red (top)
and green with a black isosceles triangle (based
on the hoist side) all separated by a black-
edged yellow stripe in the shape of a horizontal
Y (the two points of the Y face the hoist side
and enclose the triangle); centered in the
triangle is a boar’s tusk encircling two crossed
namele leaves, all in yellow
Names:
conventional long form: Republic of
Venezuela
conventional short form: Venezuela
local long form; Republica de Venezuela
local short form: Venezuela
Digraph: VE
Type: republic
Capital: Caracas
Administrative divisions; 21 states (estados.
singular — estado), I territory* (teiritorio), 1
federal district** (distrito federal), and 1
federal dependence*** (dependencia federal):
Amazonas*. Anzoategui, Apure, Aragua.
Batinas, Bolivar. Carabobo, Cojedes, Delta
Amacuro, Dependencias Federales***,
Distrito Federal**, Falcon, Guarico, Lara,
Merida, Miranda, Monagas, Nueva Esparta,
Portuguesa, Sucre, Tachira, Trujillo, Yaracuy,
Zulia
note: the federal dependence consists of 1 1
federally controlled island groups with a total
of 72 individual islands
Independence: 5 July 1811 (from Spain)
National holiday: Independence Day, 5 July
(1811)
Constitution: 23 January 1961
Legal system: based on Napoleonic code:
judicial review of legislative acts in Cassation
Court only: has not accepted compulsory ICJ
jurisdiction
Sufhrage: 1 8 years of age: universal
Executive branch:
chief of state and head of government;
President Rafael CALDERA Rodriquez (since
2 February 1994): election last held 5
December 1993 (next to be held December
1998): results— Rafael CALDERA (National
Convergence) .30.45%, Claudio FERMIN
(AD) 2 ’.59%. Oswaldo ALVAREZ PAZ
(COPED 22.72%, Andres VELASQUEZ
(Causa R) 21.94%, other 1.3%
cabinet: Council of Ministers; appointed by
the president
Legislative branch: bicameral Congress of
the Republic (Congreso de la Republica)
Senate (Senado): elections last held 5
December 1993 (next to be held December
1998): results — percent of vote by party NA;
seats— <52 total) AD 1 8. COPEI 1 5. Causa R 9,
MAS 5, National Convergence 5: note — 3
former presidents (2 from AD, 1 from COPEI)
hold lifetime senate seats
Chamber of Deputies ( Camara de Diputados):
elections last held 5 December 1993 (next to be
held December 1998); results — AD 27,9%,
COPEI 26.9%, MAS 12.4%, National
Convergence 12.9%, Causa R 19.9%; seats—
(201 total) AD ,55. COPEI 53. MAS 24.
National Convergence 26. Causa R 40. other 3
Judicial branch; Supreme Court of Justice
(Cone Suprema de Justicia) Gonzalo
RODRIGUEZ Corro. President
Political parties and leaders: National
Convergence (Convergencia), Jose Miguel
UZCATEGUI. director; Social Christian Party
(COPEI). Hilarion CARDOZO, president, and
Jose CURIEL, secretary general; Democratic
Action (AD), Pedro PARIS Montesinos,
president, and Luis ALFARO Ucero, secretary
general; Movement Toward Socialism (MAS),
Argelia LAY A, president, and Freddy
MUNOZ, secretary general; Radical Cau.se (La
Causa R), Pablo MEDINA, secretary general
Other political or pressure groups:
FEDECAMARAS, a conservative business
group: Venezuelan Confederation of Workers
(CTV, labor organization dominated by the
Democratic Action); VECINOS groups
Member of: AG. BCIE, CARICOM
(observer). CDB. CG. ECLAC, FAO. G-3,
424
Q-1 1. G-15. G-19, G-24, G-77, GATT, lADB,
IAEA, IBRD, ICAO, ICC, ICFTU, IFAD, IFC,
ILO, IMF, IMO, INTELSAT, INTERPOL.
IOC. lOM, ISO, ITU, LAES, LAIA, LORCS,
MINURSO, NAM. OAS, ONUSAL,
OPANAL, OPEC, PCA, RG, UN, UNCTAD.
UNESCO, UNHCR, UNIDO, UNIKOM,
UNPROFOR, UPU, WCL, WFTU, WHO.
WIPO, WMO.WTO
Diplomatic representation In US:
chief of mission; Ambassador Pedro Luis
-ECHEVERRIA
chancert; 1099 30th Street NW, Washington,
DC 20007
telephone; (202) 342-2214
consulatefs) general; Boston, Chicago,
Houston, Miami. New Orleans, New York,
Philadelphia, San Francisco, and San Juan
(Puerto Rico)
US diplomatic representation:
chief of mission; Ambassador Jeffrey
DAVIDOW
embassy; Avenida Francisco de Miranda and
Avenida Principal de la Floresta, Caracas
mailing address; P. O. Box 62291, Caracas
1 060- A, or APO AA 34037
telephone; [58] (2) 285-2222
FAX; [58] (2) 285-0336
consulate(s); Maracaibo (closed March 1994)
Flag: three equal horizontal bands of yellow
(top), blue, and red with the coat of arms on the
hoist side of the yellow band and an arc of
seven white five-pointed stars centered in the
blue band','f4c633c780841bca5d16b6204f4e989ad2f883e44eb07a2d0f07cf5332f70d94','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fda04509d69979a73787764e27a0ddced059fdb61cfcceddb5cad40fa41abf9b',1994,'WF','Wallis and Futuna','government',935,'Names:
conventional ''ong form: none
conventional short form: Wake Island
Digraph: WQ
Type: unincorporated territory of the US
administered by the US Air Force (under an
agreement with the US Department of Interior)
since 24 June 1 972; presently administered by
Base Commander, Major James ANDEL until
Augjst r794, when Willis ALLEY will take
over until July 1995
Capita'': none; administered from
Washingtci., DC
Independence: none (territory of the US)
Flag: the US flag is used
Names:
conventional long form; Territory of the
Wallis and Futuna Islands
conventional short form; Wallis and Futuna
local long form; Territoire des lies Wallis et
Futuna
local short form; Wallis et Futuna
Digraph: WF
Type: overseas territory of France
Capital: Mata-Utu (on lie Uvea)
Administrative divisions: none (overseas
territory of France)
Independence: none (overseas territory of
France)
Constitution: 28 September 1958 (French
Constitution)
Legal system; French legal system
Suffrage; 1 8 years of age; universal
Executive branch:
chief of state: President Francois
MITTERRAND (since 21 May 1981)
head of government; High Administrator
Philippe LEGRIX (since NA); President of the
Territorial Assembly Soane Noni UHILA
(since NA March 1992)
cabinet; Council of the Territory consists of 3
kings and 3 members appointed by the high
administrator on advice of the Territorial
Assembly
note; there are three traditional kings with
limited powers
Legislative branch: unicameral
Territorial Assembly (Assemhiee Territori-
ale); elections last held 1 5 March 1 987 (next to
be held NA March 1992); results — percent of
vote by party NA: seats— (20 total) RPR 7,
UPL5. UDF4. UNF4
French Senate: elections last held 24
September 1989 (next to be held by NA
September 1998); results — percent of vote by
party NA; seats — (I total) RPR 1
French National Assembly: elections last held
21 and 28 March 1992 (next to be held by NA
September 1996); results — percent of vote by
party NA; seats — (I total) MRG 1
Judicial branch: none; ju.stice generally
administered under French law by the chief
administrator, but the three traditional kings
administer customary law and there is a
magistrate in Mata-Utu
Political parties and leaders: Rally for the
Republic (RPR); Union Popuiaire Locale
(UPL); Union Pour la Democratie Francaise
(UDF); Lua kae tahi (Giscardians);
Mouvement des Radicaux de Gauche (MRG)
Member of: FZ,SPC
Diplomatic representation in US: none
(overseas territory of France)
US diplomatic representation: none
(overseas territory of France)
Flag: the flag of France is used','20b679e377a73fce4d7e88bbab163d205fc1b72cd44155b90fff879672e61b3a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('53719f0c792d6e8586b69be6276d9fe047b1e45913b7b5a3e442d8a941342c65',1994,'IL','Israel','government',939,'Note: Under the Israeli-PLO Declaration of
Principles on Interim Self-Government
Arrangements (“the DOP”), Israel agreed to
transfer certain powers and responsibilities to
the Palestinian Authority, and subsequently to
an elected Palestinian Council, as part of
interim self-governing arrangements in the
West Bank and Gaza Strip. A transfer of
powers and responsibilities for the Gaza Strip
and Jericho has taken place pursuant to the
Israel-PLO 4 May 1994 Cairo Agreement on
the Gaza Strip and the Jericho Area. The DOP
provides that Israel will retain responsibility
during the transitional period for external
security and for internal security and public
order of settlements and Israelis. Final status is
to be determined through direct negotiations
within five years.
Names:
conventional long form; none
conventional short form; West Bank
Digraph: WE','33ed6be9048a4ceb79fe74466087965720c81e10a7cff6e9785f25e994f36b4f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12257823d2f6e671a7334d5bcaab03b7edb2810b629d624191d7ef0659d1fa34',1994,'YE','Yemen','government',951,'Names:
conventional long form: Republic of Yemen
conventional short form: Yemen
local long form: Al Jumhuriyah al Yamaniyah
local short form: Al Yaman
Digraph: YM
Type; republic
Capital; Sanaa
Administrative divisions; 17 govemorates
(muhafazat, singular — muhafazah); Abyan,
Adan, Al Bayda, Al Hudaydah, Al Jawf, Al
Mahrah, Al Mahwit, Dhamar, Hadramaut,
Hajjah, Ibb, Lahij, Marib, Sadah, Sana,
Shabwah, Taizz
note: there may be a new capital district of
Sana
Independence: 22 May 1990 Republic of
Yemen was established on 22 May 1990 with
the merger of the Yemen Arab Republic
(Yemen (Sanaa) or North Yemen) and the
Marxist-dominated People’s Democratic
Republic of Yemen (Yemen (Aden) or South
Yemen ) ; previously North Yemen had become
independent on NA November 1918 (from the
Ottoman Empire) and South Yemen had
become independent on 30 November 1967
(from the UK)
National holiday; Proclamation of the
Republic, 22 May (1990)
Constitution: 16 May 1991
Legal system: based on Islamic law. Turkish
law, English common law, and local customary
law; does not accept compulsory ICJ
jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state and head of government:
President Ali Abdallah SALIH (since 22 May
1990, the former president of North Yemen);
note — Sanaa dismissed Vice {Resident Ali
Salim al-BIDH, Prime Minister Haydar Abu
Bakr al-ATTAS (the former president of South
Yemen), and 14 other southern officials
following the outbreak of civil war on 4 May
1994
five-member Presidential Council: president,
vice president, two members from General
People’s Congress party, two members from
Yemeni Socialist Party, and one member from
Yemeni Grouping for Reform, or Islaah party
cabinet: Council of Ministers
Legislative branch; unicameral
House of Representatives: elections last held
27 April 1993 (next to be held NA); results —
percent of vote by party NA; seats — (301 total)
GPC 124, YSP 55, Islaah 61, Ba’thist parties 7,
Nasserist parties 4, Hizb al-Haqq 2,
Independents 47. election nullified I
Judicial branch: Supreme Court
Political parties and leaders: Ba''thist
parties; General People’s Congress (GPC), Ali
Abdallah SALIH; Hizb al Haqq, Ibrahim al-
WAZIR, Sheikh Ahmad ibn Ali SHAMl
(Secretary General); Nasserist parties; Yemeni
Socialist Party (YSP). Ali Salim al-BIDH;
Yemeni Grouping for Reform or Islaah,
Shaykh Abdallah bin Husayn al-AHMAR
Other political or pressure groups: NA
Member of; ACC. AFESD. AL. AMF.
CAEU, ESeWA. FAO. G-77. IBRD. ICAO,
IDA. IDB, IFAD, IFC. ILO, IMF. IMO,
INTELSAT, INTERPOL. IOC. ITU, LORCS,
NAM, OIC. UN. UNCTAD. UNESCO.
UNIDO, UPU, WFTU, WHO, WlPO, WMO,
WTO
Diplomatic representation in US:
chief of mission: Ambassador Muhsin Ahmad
AL-AYNI
chancery: Suite 705, 2600 Virginia Avenue
NW, Washington. DC 20037
telephone: (202) 965-4760 or 4761
FAX: (202) 337-2017
consulate general(s): Detroit
US diplomatic representation:
chief of mission: Ambassador Arthur H.
HUGHES
embassy: Dhahr Himyar Zone, Sheraton Hotel
District. Sanaa
mailing address: P, O, Box 22347 Sanaa or
Sanaa, Department of State, Washington, DC
20521-6330
telephone: [967] (1) 238-842 through 238-852
MY.- [967] (1)251-563
Flag: three equal horizontal bands of red
(tup), white, and black: similar to the flag of
Syria which has two green stars and of Iraq
which has three green stars (plus an Arabic
inscription) in a hoiizontal line centered in the
white band; also similar to the flag of Egypt
which has a symbolic eagle centered in the
white band','f301276283b849b8dae83f9b8b0fba8b3bc9ad40a3fab58beccc52781ea50135','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74a41b8bffa4d3d77dc65dc05fbd7ecc9ac7de20aad4dc0c584ec898333635fb',1994,'ZM','Zambia','government',956,'Names:
conventional long form: Republic of Zaire
conventional short form: Zaire
local long form: Republique du Zaire
local short form: Zaire
former: Belgian Congo Congo/l.sopoldville
Congo/Kinshasa
Digraph: CG
Type: republic with a strong presidential
system
Capital: Kinshasa
Administrative divisions: 10 regions
(regions, singular— region) and 1 town*
(ville); Bandundu, Bas-2^ire, Equateur, Haut-
Zaire, Kasai-Occidemal, Kasai-Oriental,
Kinshasa*, Maniema, Nord-Kivu, Shaba, Sud-
Kivu
Independence: 30 June 1 960 (from Belgium)
National holiday: Armiversary of the Regime
(Second Republic). 24 November (1965)
Constitution; 24 June 1967, amended August
1974, revised 15 February 1978; amended
April 1990; new transitional constitution
promulgated in April 1994
Legal system: based on Belgian civil law
system and tribal law; has not accepted
compulsory ICJ jurisdiction
Sufl^ge: 18 years of age; universal and
compulsory
Executive branch:
chief of state: President Marsha) MOBUTU
Sese Seko Kuku Ngbendu wa Za Banga (since
24 November 1965) election last held 29 July
1984 (next to be scheduled by High Council,
the opposition-controlled transition
legislature); results— President MOBUTU was
reelected without opposition
head of government: Prime Minister Etienne
TSHISEKEDI (since NA 1993): note — de
facto executive authority is exercised by
President MOBUTU
cabinet: National Executive Council;
appointed by the president on recommendation
of the prime minister
Legislative branch; unicameral
parliament: a single body consisting of the
High Council li the Republic and the
Parliament of the Transition with membership
equally divided between presidential
supporters and opponents
Judicial branch; Supreme Court (Cour
Supreme)
Political parties and leaders: sole legal
party until January 199| — Popular Movement
of the Revolution (MPR); other parties include
Union for Democracy and Social Progress
(UDPS). Etienne TSHISEKEDI wa Mulumba;
Democratic Social Christian Party (PDSC).
Joseph ILEO; Union of Federalists and
Independent Republicans (UFERl), NGUZ a
Karl-I-Bond; Unified Lumumba.st Party
(PALU), Antoine GIZENGA
Member of: ACCT, ACP, AfDB, CCC,
CEEAC, CEPGL, ECA. FAO. G-19, G-24,
G-77, GATT, IAEA, IBRD, ICAO. ICC. IDA.
IFAD. IFC. ILO, IMF. IMO. INTELSAT,
INTERPOL. IOC, ITU, LORCS. NAM. OAU.
PCA, UN. UNCTAD. UNESCO, UNHCR,
UNIDO, UPU, WCL, WFTU, WHO, WIPO.
WMO. WTO
Diplomatic representation in US;
chief of mission: Ambassador TATANENE
Manata
chancery: 18(X) New Hampshire Avenue NW,
Washington, DC 2(X)09
telephone; (202) 234-7690 or 7691
US diplomatic representation:
chief of mission; (vacant); Deputy Chief of
Mission John YATES
embassy: 310 Avenue des Aviateurs, Kinshasa
mailing address: Unit 3 1550, Kinshasha; APO
AE 09828
telephone; [243] (12) 21532, 21628
FAX: [243] (12) 21232 or 21534/5, ext. 2308
consulate(s) general; Lubumbashi (closed and
evacuated in October 1991 because of the poor
security situation)
Flag: light green with a yellow disk in the
center bearing a black arm holding a red
flaming torch; the flames of the torch are
blowing away from the hoist side; uses the
popular pan-African colors of Ethiopia','828d180d07429dc3673b687f90b8f1d5007be9bb5928ab66012ff91817595732','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49723589f1cf3d464d0c618c596a5386d149316c57ccd61c61d7a71fe845cf10',1994,'ZW','Zimbabwe','government',961,'Names:
conventional long form: Republic of Zambia
conventional short form: Zambia
former: Northern Rhodesia
Digraph: ZA
Type: republic
Capital: Lusaka
Administrative divisions: 9 provinces;
Central, Copperbelt. Ea,stem, Luapula, Lusaka,
Northern, North-Western, Southern, Western
Independence: 24 October 1964 (from UK)
National holiday: Independence Day. 24
October (1 964)
Constitution: 2 August 1991
Legal system: based on English common law
and customary law; judicial review of
legislative acts in an ad hoc constitutional
council; has not accepted compulsory ICJ
jurisdiction
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state and head of government :
President Frederick CHILUBA (since 31
October 1991); Vice President Levy
MWANAWASA (since 31 October 1991);
election last held 3 1 October 1991 (next to be
held in 1996); results— Frederick CHILUBA
84%. Kenneth KAUNDA 16%
cabinet: Cabinet; appointed by the president
from members of the National Assembly
Legislative branch: unicameral
National AssenMy; elections last held 3 1
October 1991 (next to be held in 1996);
results — percent of vote by party NA; seats —
(150 total) MMD 125, UNIP 25; note— the
MMD''s mttjofhy weakened by the
defection of 1 3 of its parliamentary members
during 1993 and the defeat of its candidates in
4 of the resulting by-elections
Judicial branch: Supreme Court
Political parties and Imders: Movement for
Multiparty Democracy (MMD), Frederick
CHILUBA; United National Independence
Party (UNIP), Kebby MUSOK-ATWANE;
National Party (NP), Inonge MBIKUSITA-
LEWANIKA;
Member of: ACP, AfDB, C. CCC, ECA.
FAO, FLS, G-19. G-77. GATT. IAEA. IBRD,
ICAO, IDA, IFAD. IFC. IFTU, ILO, IMF,
INTELSAT. INTERPOL, IOC, lOM, ITU,
LORCS, NAM. OAU, SADC, UN. UNCTAD,
UNESCO. UNIDO. UNOMOZ, UNOSOM,
UPU, WCL, WHO. WIPO. WMO, WTO
Diplomatic representation in US:
chief of mission: Ambassador Dunstan Weston
KAMANA
chancery: 2419 Massachusetts Avenue NW,
Washington. DC 20008
telephone: (202) 265-9717 through 9721
US diplomatic representatiou;
chief of mission: Ambassador Roland
KUCHEL
embassy: comer of Independence Avenue and
United Nations Avenue. Lusaka
mailing address: P. O. Box 31617. Lusaka
telephone: (260-1) 228-595. 228-601, 228-
602, 228-603
FAX: (260-1) 261 -.5,38
Flag; green with a panel of three vertical
bands of t»d (hoist side), black, and orange
below a sc aring orange eagle, on the outer edge
of the flag
Names:
conventional long form: Republic of
conventional short form: Zimbabwe
former- Southern Rhodesia
Digraph: Z1
Type: parliamentary democracy
Capital; Harare
Administrative divisions; 8 provinces:
Manicaland. Mashonaland Central,
Mashonaland East, Mashonaland West,
Masvingo (Victoria), Matabeleland North,
Matabeleland South, Midlands
Independence: 18 April 1980 (from UK)
National holiday: Independence Day, 1 8
April (1980)
Constitution: 21 December 1979
Legal system; mixture of Roman-Dutch and
English common law
Suffrage; 1 8 years of age; universal
Executive branch:
chief of , state and head of government:
Executive President Robert Gabriel MUGABE
(since 31 December 1987); Co-Vice President
Simon Vengai MUZENDA (since 31
December 1987); Co-Vice President Joshua M.
NKOMO (since 6 August 1990); election last
442
held 28-30 March 1990 (next to be held NA
March 1996); results— Robert MUGABE
78.3%, Edgar TEKERE 21.7%
cabinet: Cabinet; appointed by the president;
responsible to Parliament
Le^lative branch: unicameral
Parliament: elections last held 28-30 March
1990 (next to be held NA March 1995);
results— percent of vote by party NA; seats —
( 1 50 total, 1 20 elected) ZANU-PF 1 1 7, ZUM
2, ZANU-S 1
Judicial branch: Supreme Court
Political parties and leaders: Zimbabwe
African National Union-Patriotic Front
(ZANU-PF), Robert MUGABE; Zimbabwe
African National Union-Sithole (ZANU-S),
Ndabaningi SITHOLE; Zimbabwe unity
Movement (ZUM), Edgar TEKERE and Abel
MUYOREWA; [>emocratic Patty (DP),
Emmanuel MAGOCHE; Forum Party, Enoch
DUMBUTSHENA
Member of: ACP, AfDB, C. CCC, ECA,
FAO, FLS, G-15. G-77, GATT, IAEA, IBRD,
ICAO, ICFTU, IDA, IFAD, IFC, ILO, IMF,
INTELSAT. INTERPOL, IOC, lOM
(observer), ISO. ITU, LORCS, NAM, OAU,
PCA, SADC, UN, UNAVEM II, UNCTAD,
UNESCO, UNIDO, UNOMUR, UNOSOM,
UPU, WCL, WHO, WIPO, WMO, WTO
Diplomatic representation in US:
chief of mission: Ambassador Amos Bernard
Muvengwa MIDZI
chancery: 1608 New Hampshire Avenue NW,
Washington, DC 20009
telephone: (202) 332.7100
FAX; (202) 483-9326
US diplomatic representation:
chief of mission; Ambassador Edward Gibson
LANPHER
embassy: 1 72 Herbert Chitepo Avenue, Harare
mailing address: P. O. Box 3340, Harare
telephone: [263] (4) 794-521
FAX: [263] (4) 796-488
Flag: seven equal horizontal bands of green,
yellow, red, black, red, yellow, and green with
a white equilateral triangle edged in black
based on the hoist side; a yellow Zimbabwe
bird is superimposed on a red five-pointed star
in the center of the triangle','0ba16acd536255440f22284cd214d5edb28d84159ecfbd7edaf858ed1f900e22','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50fb49f07071839f9d60a47db662bc45c5d6c98cfeb00f145f36e33bb875bb9d',1994,'AU','Australia','government',23,'Australian Labor Party, Paul John KEATING
opposition:
Liberal Party, John HEWSON; National Party, Timothy FISCHER;
Australian Democratic Party, Cheryl KERNOT; Green Party, leader NA
Other political or pressure groups:
Australian Democratic Labor Party (anti-Communist Labor Party splinter
group); Peace and Nuclear Disarmament Action (Nuclear Disarmament
Party splinter group)
Member of:
AfDB, AG (observer), ANZUS, APEC, AsDB, Australia Group, BIS, C, CCC,
COCOM, CP, EBRD, ESCAP, FAO, GATT, G-8, IAEA, IBRD, ICAO, ICC, ICFTU,
IDA, IEA, IFAD, IFC, ILO, IMF, IMO, INMARSAT, INTELSAT, INTERPOL, IOC,
IOM, ISO, ITU, LORCS, MINURSO, MTCR, NAM (guest), NEA, NSG, OECD, PCA,
SPARTECA, SPC, SPF, UN, UNCTAD, UNESCO, UNFICYP, UNHCR, UNIDO, UNOSOM,
UNPROFOR, UNTAC, UNTSO, UPU, WFTU, WHO, WIPO, WMO, ZC
Diplomatic representation in US:
chief of mission:
Ambassador Donald RUSSELL
chancery:
1601 Massachusetts Avenue NW, Washington, DC 20036
telephone:
(202) 797-3000
FAX:
(202) 797-3168
consulate(s) general:
Chicago, Honolulu, Houston, Los Angeles, New York, Pago Pago (American
Samoa), and San Francisco
US diplomatic representation:
chief of mission:
Ambassador Edward PERKINS
embassy:
Moonah Place, Yarralumla, Canberra, Australian Capital Territory 2600
mailing address:
APO AP 96549
telephone:
[61] (6) 270-5000
FAX:
[61] (6) 270-5970
consulate(s) general:
Melbourne, Perth, and Sydney
consulate(s):
Brisbane
Flag:
blue with the flag of the UK in the upper hoist-side quadrant and a
large seven-pointed star in the lower hoist-side quadrant; the
remaining half is a representation of the Southern Cross constellation
in white with one small five-pointed star and four, larger,
seven-pointed stars
@Australia, Economy
Overview:
Australia has a prosperous Western-style capitalist economy, with a
per capita GDP comparable to levels in industrialized West European
countries. Rich in natural resources, Australia is a major exporter of
agricultural products, minerals, metals, and fossil fuels. Primary
products account for more than 60% of the value of total exports, so
that, as in 1983-84, a downturn in world commodity prices can have a
big impact on the economy. The government is pushing for increased
exports of manufactured goods, but competition in international
markets continues to be severe. Australia has suffered from the low
growth and high unemployment characterizing the OECD countries in the
early 1990s. In 1992-93 the economy recovered slowly from the
prolonged recession of 1990-91, a major restraining factor being weak
world demand for Australia''s exports. Unemployment has hovered around
10% and probably will remain at that level in 1994 as productivity
gains rather than more jobs account for growth.
National product:
GDP - purchasing power equivalent - $339.7 billion (1993)
National product real growth rate:
4% (1993)
National product per capita:
$19,100 (1993)
Inflation rate (consumer prices):
1.1% (1993)
Unemployment rate:
10% (December 1993)
Budget:
revenues:
$71.9 billion
expenditures:
$83.1 billion, including capital expenditures of $NA (FY93)
Exports:
$44.1 billion (1992)
commodities:
coal, gold, meat, wool, alumina, wheat, machinery and transport
equipment
partners:
Japan 25%, US 11%, South Korea 6%, NZ 5.7%, UK, Taiwan, Singapore,
Hong Kong (1992)
Imports:
$43.6 billion (1992)
commodities:
machinery and transport equipment, computers and office machines,
crude oil and petroleum products
partners:
US 23%, Japan 18%, UK 6%, Germany 5.7%, NZ 4% (1992)
External debt:
$141.1 billion (1993)
Industrial production:
growth rate 1.9% (FY93); accounts for 32% of GDP
Electricity:
capacity:
40,000,000 kW
production:
150 billion kWh
consumption per capita:
8,475 kWh (1992)
Industries:
mining, industrial and transportation equipment, food processing,
chemicals, steel
Agriculture:
accounts for 5% of GDP and over 30% of export revenues; world''s
largest exporter of beef and wool, second-largest for mutton, and
among top wheat exporters; major crops - wheat, barley, sugarcane,
fruit; livestock - cattle, sheep, poultry
Illicit drugs:
Tasmania is one of the world''s major suppliers of licit opiate
products; government maintains strict controls over areas of opium
poppy cultivation and output of poppy straw concentrate
Economic aid:
donor:
ODA and OOF commitments (1970-89), $10.4 billion
Currency:
1 Australian dollar ($A) = 100 cents
Exchange rates:
Australian dollars ($A) per US$1 - 1.4364 (January 1994), 1.4704
(1993), 1.3600 (1992), 1.2835 (1991), 1.2799 (1990), 1.2618 (1989)
Fiscal year:
1 July - 30 June
@Australia, Communications
Railroads:
40,478 km total; 7,970 km 1.600-meter gauge, 16,201 km 1.435-meter
standard gauge, 16,307 km 1.067-meter gauge; 183 km dual gauge; 1,130
km electrified; government owned (except for a few hundred kilometers
of privately owned track) (1985)
Highways:
total:
837,872 km
paved:
243,750 km
unpaved:
gravel, crushed stone, stabilized earth 228,396 km; unimproved earth
365,726 km
Inland waterways:
8,368 km; mainly by small, shallow-draft craft
Pipelines:
crude oil 2,500 km; petroleum products 500 km; natural gas 5,600 km
Ports:
Adelaide, Brisbane, Cairns, Darwin, Devonport, Fremantle, Geelong,
Hobart, Launceston, Mackay, Melbourne, Sydney, Townsville
Merchant marine:
83 ships (1,000 GRT or over) totaling 2,517,538 GRT/3,711,549 DWT,
bulk 30, cargo 8, chemical tanker 3, combination bulk 2, container 7,
liquefied gas 5, oil tanker 18, roll-on/roll-off cargo 7, short-sea
passenger 2, vehicle carrier 1
Airports:
total:
481
usable:
440
with permanent-surface runways:
241
with runways over 3,659 m:
1
with runways 2,440-3,659 m:
20
with runways 1,220-2,439 m:
268
Telecommunications:
good international and domestic service; 8.7 million telephones;
broadcast stations - 258 AM, 67 FM, 134 TV; submarine cables to New
Zealand, Papua New Guinea, and Indonesia; domestic satellite service;
satellite stations - 4 Indian Ocean INTELSAT, 6 Pacific Ocean INTELSAT
earth stations
@Australia, Defense Forces
Branches:
Australian Army, Royal Australian Navy, Royal Australian Air Force
Manpower availability:
males age 15-49 4,885,574; fit for military service 4,239,459; reach
military age (17) annually 133,337 (1994 est.)
Defense expenditures:
exchange rate conversion - $7.1 billion, 2.4% of GDP (FY92/93)
@Austria, Geography
Location:
Central Europe, between Germany and Hungary
Map references:
Africa, Arctic Region, Europe, Standard Time Zones of the World
Area:
total area:
83,850 sq km
land area:
82,730 sq km
comparative area:
slightly smaller than Maine
Land boundaries:
total 2,496 km, Czech Republic 362 km, Germany 784 km, Hungary 366 km,
Italy 430 km, Liechtenstein 37 km, Slovakia 91 km, Slovenia 262 km,
Switzerland 164 km
Coastline:
0 km (landlocked)
Maritime claims:
none; landlocked
International disputes:
none
Climate:
temperate; continental, cloudy; cold winters with frequent rain in
lowlands and snow in mountains; cool summers with occasional showers
Terrain:
in the west and south mostly mountains (Alps); along the eastern and
northern margins mostly flat or gently sloping
Natural resources:
iron ore, petroleum, timber, magnesite, aluminum, lead, coal, lignite,
copper, hydropower
Land use:
arable land:
17%
permanent crops:
1%
meadows and pastures:
24%
forest and woodland:
39%
other:
19%
Irrigated land:
40 sq km (1989)','f693701d8f1da4db8b8b299086952df376c18662185459dd0aa2165edd502687','internet-archive','theciaworldfactb00180gut','txt','b76993377cfa6bdd51979833301976cfc440911ee1fe0b90c117008758860b3f','https://archive.org/download/theciaworldfactb00180gut/180.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85045c0eb146426ca9a4d5e358a68b63ef894a380503a04885e3bcfa038a492d',1994,'GL','Greenland','government',99,'National product:
GNP - purchasing power equivalent - $500 million (1988)
National product real growth rate:
-10% (1990)
National product per capita:
$9,000 (1988)
Inflation rate (consumer prices):
1.6% (1991)
Unemployment rate:
9% (1990 est.)
Budget:
revenues:
$381 million
expenditures:
$381 million, including capital expenditures of $36 million (1989)
Exports:
$340.6 million (f.o.b., 1991)
commodities:
fish and fish products 95%
partners:
Denmark 79%, Benelux 9%, Germany 5%
Imports:
$403 million (c.i.f., 1991)
commodities:
manufactured goods 28%, machinery and transport equipment 24%, food
and live animals 12.4%, petroleum products 12%
partners:
Denmark 65%, Norway 8.8%, US 4.6%, Germany 3.8%, Japan 3.8%, Sweden
2.4%
External debt:
$480 million (1990 est.)
Industrial production:
growth rate NA%
Electricity:
capacity:
84,000 kW
production:
176 million kWh
consumption per capita:
3,060 kWh (1992)
Industries:
fish processing (mainly shrimp), lead and zinc mining, handicrafts,
some small shipyards, potential for platinum and gold mining
Agriculture:
sector dominated by fishing and sheep raising; crops limited to forage
and small garden vegetables; 1988 fish catch of 133,500 metric tons
Economic aid:
none
Currency:
1 Danish krone (DKr) = 100 oere
Exchange rates:
Danish kroner (DKr) per US$1 - 6.771 (January 1994), 6.484 (1993),
6.036 (1992), 6.396 (1991), 6.189 (1990), 7.310 (1989)
Fiscal year:
calendar year
@Greenland, Communications
Highways:
total:
150 km
paved:
60 km
unpaved:
90 km
Ports:
Kangerluarsoruseq (Faeringehavn), Paamiut (Frederikshaab), Nuuk
(Godthaab), Sisimiut (Holsteinsborg), Julianehaab, Maarmorilik, North
Star Bay
Airports:
total:
11
usable:
8
with permanent-surface runways:
5
with runways over 3,659 m:
0
with runways 2,440-3,659 m:
2
with runways 1,220-2,439 m:
2
Telecommunications:
adequate domestic and international service provided by cables and
microwave radio relay; 17,900 telephones; broadcast stations - 5 AM, 7
(35 repeaters) FM, 4 (9 repeaters) TV; 2 coaxial submarine cables; 1
Atlantic Ocean INTELSAT earth station
@Greenland, Defense Forces
Note:
defense is responsibility of Denmark
@Grenada, Geography
Location:
Caribbean, in the eastern Caribbean Sea, about 150 im north of','166b8be1d6efef536ad5e10cc8a3e7aa87b4acb50d3b508b07ea0b2d04df2cf6','internet-archive','theciaworldfactb00180gut','txt','b76993377cfa6bdd51979833301976cfc440911ee1fe0b90c117008758860b3f','https://archive.org/download/theciaworldfactb00180gut/180.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bf4c9ea89183516b37333118d6c97a893d5fb105078acdb778df5fd0780e7f7',1994,'TT','Trinidad and Tobago','government',100,'Map references:
Central America and the Caribbean, South America, Standard Time Zones
of the World
Area:
total area:
340 sq km
land area:
340 sq km
comparative area:
slightly less than twice the size of Washington, DC
Land boundaries:
0 km
Coastline:
121 km
Maritime claims:
exclusive economic zone:
200 nm
territorial sea:
12 nm
International disputes:
none
Climate:
tropical; tempered by northeast trade winds
Terrain:
volcanic in origin with central mountains
Natural resources:
timber, tropical fruit, deepwater harbors
Land use:
arable land:
15%
permanent crops:
26%
meadows and pastures:
3%
forest and woodland:
9%
other:
47%
Irrigated land:
NA sq km','ebf2db25cce833e7741819fa44ff14f03127fb522dc8fd43795fb3541df84637','internet-archive','theciaworldfactb00180gut','txt','b76993377cfa6bdd51979833301976cfc440911ee1fe0b90c117008758860b3f','https://archive.org/download/theciaworldfactb00180gut/180.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('569f05d867cac3839b89e0fda48ad4f79b18811aaf8fd7ea727844ba32ef5915',1994,'LR','Liberia','government',139,'Highways:
total:
10,087 km
paved:
603 km
unpaved:
gravel 5,171 km (includes 2323km of private roads of rubber and timber
firms, open to the public); earth 4,313 km
Ports:
Monrovia, Buchanan, Greenville, Harper (or Cape Palmas)
Merchant marine:
1,595 ships (1,000 GRT or over) totaling 56,923,236 GRT/97,692,316
DWT, barge carrier 3, bulk 423, cargo 126, chemical 122, combination
bulk 30, combination ore/oil 64, container 112, liquefied gas 67, oil
tanker 468, passenger 32, refrigerated cargo 61, roll-on/roll-off
cargo 19, short-sea passenger 2, specialized tanker 7, vehicle carrier
59
note:
a flag of convenience registry; all ships are foreign owned; the top 4
owning flags are US 14%, Japan 13%, Norway 10%, and Hong Kong 8%
Airports:
total:
59
usable:
41
with permanent-surface runways:
2
with runways over 3,659 m:
0
with runways 2,440-3,659 m:
1
with runways 1,220-2,439 m:
4
Telecommunications:
telephone and telegraph service via radio relay network; main center
is Monrovia; broadcast stations - 3 AM, 4 FM, 5 TV; 1 Atlantic Ocean
INTELSAT earth station; most telecommunications services inoperable
due to insurgency movement
@Liberia, Defense Forces
Branches:
the ultimate structure of the Liberian military force will depend on
who is the victor in the ongoing civil war
Manpower availability:
males age 15-49 707,927; fit for military service 377,950
Defense expenditures:
$NA, NA% of GDP
@Libya, Geography
Location:
Northern Africa, on the southern coast of the Mediterranean Sea,
between Egypt and Tunisia
Map references:
Africa, Standard Time Zones of the World
Area:
total area:
1,759,540 sq km
land area:
1,759,540 sq km
comparative area:
slightly larger than Alaska
Land boundaries:
total 4,383 km, Algeria 982 km, Chad 1,055 km, Egypt 1,150 km, Niger
354 km, Sudan 383 km, Tunisia 459 km
Coastline:
1,770 km
Maritime claims:
territorial sea:
12 nm
Gulf of Sidra closing line:
32 degrees 30 minutes north
International disputes:
the International Court of Justice (ICJ) ruled in February 1994 that
the 100,000 sq km Aozou Strip between Chad and Libya belongs to Chad,
and that Libya must withdraw from it by 31 May 1994; Libya had
withdrawn its forces in response to the ICJ ruling, but as of June
1994 still maintained an airfield in the disputed area; maritime
boundary dispute with Tunisia; claims part of northern Niger and part
of southeastern Algeria
Climate:
Mediterranean along coast; dry, extreme desert interior
Terrain:
mostly barren, flat to undulating plains, plateaus, depressions
Natural resources:
petroleum, natural gas, gypsum
Land use:
arable land:
2%
permanent crops:
0%
meadows and pastures:
8%
forest and woodland:
0%
other:
90%
Irrigated land:
2,420 sq km (1989 est.)','1da19039034f33b4447171c712202bc4d90d8effd22859c26df9ffa0315e4b6b','internet-archive','theciaworldfactb00180gut','txt','b76993377cfa6bdd51979833301976cfc440911ee1fe0b90c117008758860b3f','https://archive.org/download/theciaworldfactb00180gut/180.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52e20aedbfd67b8962cee8a8ef2fb59b878ac932f99e443a547c0dbac88e79fa',1994,'PK','Pakistan','government',176,'Pakistan People''s Party (PPP), Benazir BHUTTO; Pakistan Muslim League,
Junejo faction (PML/J), Hamid Nasir CHATTHA; National People''s Party
(NPP), Ghulam Mustapha JATOI; Pakhtun Khwa Milli Awami Party (PKMAP),
Mahmood Khan ACHAKZAI; Balochistan National Movement, Hayee Group
(BNM/H), Dr. HAYEE Baluch; National Democratic Alliance (NDA), Maulana
Kausar NIAZI; Pakhtun Quami Party (PKQP), Mohammed AFZAL Khan;
Jamhoori Watan Party (JWP), Akbar Khan BUGTI
opposition:
Pakistan Muslim League, Nawaz Sharif faction (PML/N), Nawaz SHARIF;
Awami National Party (ANP), Khan Abdul WALI KHAN; Pakistan Islamic
Front (PIF), Qazi Hussain AHMED; Balochistan National Movement, Mengal
Group (BNM/M), Sardar Akhtar MENGAL; Mohajir Quami Movement, Altaf
faction (MQM/A); Jamaat-i-Islami (JI); Jamiat-al-Hadith (JAH)
frequently shifting:
Mutaheda Deeni Mahaz (MDM), Maulana Sami-ul-HAQ, the MDM includes
Jamiat Ulema-i-Pakistan, Niazi faction (JUP/NI) and Anjuman
Sepah-i-Sahaba Pakistan (ASSP); Islami-Jamhoori-Mahaz (IJM-Islamic
Democratic Party), the IJM includes Jamiat Ulema-i-Islami, Fazlur
Rehman group (JUI/F); Jamiat Ulema-i-Pakistan, Noorani faction
(JUP/NO); Jamiat Ulema-i-Islam, Sami-ul-Haq faction (JUI/S); Pakistan
Muslim League, Functional Group (PML/F); Pakistan National Party (PNP)
note:
most Pakistani political groups are motivated primarily by opportunism
and political alliances can shift frequently
Other political or pressure groups:
military remains important political force; ulema (clergy),
landowners, industrialists, and small merchants also influential
Member of:
AsDB, C, CCC, CP, ECO, ESCAP, FAO, G-19, G-24, G-77, GATT, IAEA, IBRD,
ICAO, ICC, ICFTU, IDA, IDB, IFAD, IFC, ILO, IMF, IMO, INMARSAT,
INTELSAT, INTERPOL, IOC, IOM, ISO, ITU, LORCS, MINURSO, NAM, OAS
(observer), OIC, PCA, SAARC, UN, UNCTAD, UNESCO, UNHCR, UNIDO, UNIKOM,
UNOSOM, UNTAC, UPU, WCL, WFTU, WHO, WIPO, WMO, WTO
Diplomatic representation in US:
chief of mission:
Ambassador Maleeha LODHI
chancery:
2315 Massachusetts Avenue NW, Washington, DC 20008
telephone:
(202) 939-6205
FAX:
(202) 387-0484
consulate(s) general:
Los Angeles and New York
US diplomatic representation:
chief of mission:
Ambassador John MONJO
embassy:
Diplomatic Enclave, Ramna 5, Islamabad
mailing address:
P. O. Box 1048, PSC 1212, Box 2000, Unit 6220,Islamabad or APO AE
09812-2000
telephone:
[92] (51) 826161 through 79
FAX:
[92] (51) 214222
consulate(s) general:
Karachi, Lahore
consulate(s):
Peshawar
Flag:
green with a vertical white band (symbolizing the role of religious
minorities) on the hoist side; a large white crescent and star are
centered in the green field; the crescent, star, and color green are
traditional symbols of Islam
@Pakistan, Economy
Overview:
Pakistan is a poor Third World country faced with the usual problems
of rapidly increasing population, sizable government deficits, and
heavy dependence on foreign aid. In addition, the economy must support
a large military establishment. Rapid economic growth, averaging 5%-6%
over the past decade has helped Pakistan cope with these problems.
However, growth slumped to 3% in FY93 because of severe flooding,
which damaged the key export crop, cotton. Almost all agriculture and
small-scale industry is in private hands. In 1990, Pakistan embarked
on a sweeping economic liberalization program to boost foreign and
domestic private investment and lower foreign aid dependence. The
SHARIF government denationalized several state-owned firms and
attracted some foreign investment. Pakistan likely will have
difficulty raising living standards because of its rapidly expanding
population. At the current rate of growth, population would double in
25 years.
National product:
GNP - purchasing power equivalent - $239 billion (1993 est.)
National product real growth rate:
3% (FY93 est.)
National product per capita:
$1,900 (1993 est.)
Inflation rate (consumer prices):
12.7% (FY91)
Unemployment rate:
10% (FY91 est.)
Budget:
revenues:
$9.4 billion
expenditures:
$10.9 billion, including capital expenditures of $3.1 billion (1993
est.)
Exports:
$6.8 billion (f.o.b., FY92)
commodities:
cotton, textiles, clothing, rice, leather, carpets
partners:
US, Japan, Hong Kong, Germany, UK
Imports:
$9.1 billion (f.o.b., FY92)
commodities:
petroleum, petroleum products, machinery, transportation equipment,
vegetable oils, animal fats, chemicals
partners:
Japan, US, Germany, UK, Saudi Arabia
External debt:
$24 billion (1993 est.)
Industrial production:
growth rate 7.3% (FY92); accounts for 23% of GDP
Electricity:
capacity:
10,000,000 kW
production:
43 billion kWh
consumption per capita:
350 kWh (1992)
Industries:
textiles, food processing, beverages, construction materials,
clothing, paper products, shrimp
Agriculture:
22% of GDP, over 50% of labor force; world''s largest contiguous
irrigation system; major crops - cotton, wheat, rice, sugarcane,
fruits, vegetables; livestock products - milk, beef, mutton, eggs;
self-sufficient in food grain
Illicit drugs:
major illicit producer of opium and hashish for the international drug
trade; despite some success in reducing cultivation, remains world''s
fourth largest opium producer (140 metric tons in 1993)
Economic aid:
recipient:
US commitments, including Ex-Im (FY70-89), $4.5 billion; Western
(non-US) countries, ODA and OOF bilateral commitments (1980-89), $91
billion; OPEC bilateral aid (1979-89), $2.3 billion; Communist
countries (1970-89), $3.2 billion
note:
including Bangladesh prior to 1972
Currency:
1 Pakistani rupee (PRe) = 100 paisa
Exchange rates:
Pakistani rupees (PRs) per US$1 - 30.214 (January 1994), 28.107
(1993), 25.083 (1992), 23.801 (1991), 21.707 (1990), 20.541 (1989)
Fiscal year:
1 July - 30 June
@Pakistan, Communications
Railroads:
8,773 km total; 7,718 km broad gauge, 445 km 1-meter gauge, and 610 km
less than 1-meter gauge; 1,037 km broad-gauge double track; 286 km
electrified; all government owned (1985)
Highways:
total:
110,677 km
paved:
58,677 km
unpaved:
gravel 23,000 km; improved earth 29,000 km (1988)
Pipelines:
crude oil 250 km; petroleum products 885 km; natural gas 4,044 km
(1987)
Ports:
Gwadar, Karachi, Port Muhammad bin Qasim
Merchant marine:
30 ships (1,000 GRT or over) totaling 352,189 GRT/532,782 DWT, bulk 1,
cargo 25, oil tanker 1, passenger-cargo 3
Airports:
total:
110
usable:
104
with permanent-surface runways:
75
with runways over 3,659 m:
1
with runways 2,440-3,659 m:
30
with runways 1,220-2,439 m:
43
Telecommunications:
the domestic telephone system is poor, adequate only for government
and business use; about 7 telephones per 1,000 persons; the system for
international traffic is better and employs both microwave radio relay
and satellites; satellite ground stations - 1 Atlantic Ocean INTELSAT
and 2 Indian Ocean INTELSAT; broadcast stations - 19 AM, 8 FM, 29 TV
@Pakistan, Defense Forces
Branches:
Army, Navy, Air Force, Civil Armed Forces, National Guard,
paramilitary/security forces
Manpower availability:
males age 15-49 29,548,746; fit for military service 18,134,013; reach
military age (17) annually 1,391,258 (1994 est.)
Defense expenditures:
exchange rate conversion - $3.0 billion, 5.7% of GNP (FY93/94)
@Palmyra Atoll
Header
Affiliation:
(territory of the US)
@Palmyra Atoll, Geography
Location:
Oceania, Polynesia, in the North Pacific Ocean, 1,600 km
south-southwest of Honolulu, almost halfway between Hawaii and','6c11630e96dc22060c7709b031ace0bcdc59cdaf73dae0dc86f88dc736683503','internet-archive','theciaworldfactb00180gut','txt','b76993377cfa6bdd51979833301976cfc440911ee1fe0b90c117008758860b3f','https://archive.org/download/theciaworldfactb00180gut/180.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a4014f516a650c4157319fe0d5d9920ccffa7025817da9ace65eff4a4d8b325',1994,'AS','American Samoa','government',177,'Map references:
Oceania
Area:
total area:
11.9 sq km
land area:
11.9 sq km
comparative area:
about 20 times the size of The Mall in Washington, DC
Land boundaries:
0 km
Coastline:
14.5 km
Maritime claims:
contiguous zone:
12 nm
continental shelf:
200-m depth or to depth of exploitation
exclusive economic zone:
200 nm
territorial sea:
12 nm
International disputes:
none
Climate:
equatorial, hot, and very rainy
Terrain:
low, with maximum elevations of about 2 meters
Natural resources:
none
Land use:
arable land:
0%
permanent crops:
0%
meadows and pastures:
0%
forest and woodland:
100%
other:
0%
Irrigated land:
0 sq km','455aa873a04d1f34ce6956217394a36a15e0ed952831d1f20dfff46374ffe536','internet-archive','theciaworldfactb00180gut','txt','b76993377cfa6bdd51979833301976cfc440911ee1fe0b90c117008758860b3f','https://archive.org/download/theciaworldfactb00180gut/180.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9ba62a847aea00e37aa10741570d38c19fd1a6374b722243d77a7be7f2998d2',1994,'SG','Singapore','government',200,'People''s Action Party (PAP), GOH Chok Tong, secretary general
opposition:
Workers'' Party (WP), J. B. JEYARETNAM; Singapore Democratic Party
(SDP), CHIAM See Tong; National Solidarity Party (NSP), leader NA;
Barisan Sosialis (BS, Socialist Front), leader NA
Member of:
APEC, AsDB, ASEAN, C, CCC, COCOM (cooperating), CP, ESCAP, G-77, GATT,
IAEA, IBRD, ICAO, ICC, ICFTU, IFC, ILO, IMF, IMO, INMARSAT, INTELSAT,
INTERPOL, IOC, ISO, ITU, LORCS, NAM, UN, UNAVEM II, UNCTAD, UNIKOM,
UNTAC, UPU, WHO, WIPO, WMO
Diplomatic representation in US:
chief of mission:
Ambassador Sellapan Rama NATHAN
chancery:
1824 R Street NW, Washington, DC 20009
telephone:
(202) 667-7555
FAX:
(202) 265-7915
US diplomatic representation:
chief of mission:
(vacant)
embassy:
30 Hill Street, Singapore 0617
mailing address:
FPO AP 96534
telephone:
[65] 338-0251
FAX:
[65] 338-5010
Flag:
two equal horizontal bands of red (top) and white; near the hoist side
of the red band, there is a vertical, white crescent (closed portion
is toward the hoist side) partially enclosing five white five-pointed
stars arranged in a circle
@Singapore, Economy
Overview:
Singapore has an open entrepreneurial economy with strong service and
manufacturing sectors and excellent international trading links
derived from its entrepot history. The economy registered nearly 10%
growth in 1993 while stemming inflation. The construction and
financial services industries and manufacturers of computer-related
components have led economic growth. Rising labor costs continue to be
a threat to Singapore''s competitiveness, but there are indications
that productivity is keeping up. In applied technology, per capita
output, investment, and labor discipline, Singapore has key attributes
of a developed country.
National product:
GDP - purchasing power equivalent - $42.4 billion (1993)
National product real growth rate:
9.9% (1993)
National product per capita:
$15,000 (1993 est.)
Inflation rate (consumer prices):
2.4% (1993)
Unemployment rate:
2.7% (1993)
Budget:
revenues:
$11.9 billion
expenditures:
$10.5 billion, including capital expenditures of $3.9 billion (1994
est.)
Exports:
$61.5 billion (f.o.b., 1992)
commodities:
computer equipment, rubber and rubber products, petroleum products,
telecommunications equipment
partners:
US 21%, Malaysia 12%, Hong Kong 8%, Japan 8%, Thailand 6% (1992)
Imports:
$66.4 billion (f.o.b., 1992)
commodities:
aircraft, petroleum, chemicals, foodstuffs
partners:
Japan 21%, US 16%, Malaysia 15%, Saudi Arabia 5%, Taiwan 4%
External debt:
$0; Singapore is a net creditor
Industrial production:
growth rate 2.3% (1992); accounts for 28% of GDP
Electricity:
capacity:
4,860,000 kW
production:
18 billion kWh
consumption per capita:
6,420 kWh (1992)
Industries:
petroleum refining, electronics, oil drilling equipment, rubber
processing and rubber products, processed food and beverages, ship
repair, entrepot trade, financial services, biotechnology
Agriculture:
occupies a position of minor importance in the economy;
self-sufficient in poultry and eggs; must import much of other food;
major crops - rubber, copra, fruit, vegetables
Illicit drugs:
transit point for Golden Triangle heroin going to the US, Western
Europe, and the Third World; also a major money-laundering center
Economic aid:
recipient:
US commitments, including Ex-Im (FY70-83), $590 million; Western
(non-US) countries, ODA and OOF bilateral commitments (1970-89), $1
billion
Currency:
1 Singapore dollar (S$) = 100 cents
Exchange rates:
Singapore dollars (S$) per US$1 - 1.6032 (January 1994), 1.6158
(1993), 1.6290 (1992), 1.7276 (1991), 1.8125 (1990), 1.9503 (1989)
Fiscal year:
1 April - 31 March
@Singapore, Communications
Railroads:
38 km of 1.000-meter gauge
Highways:
total:
2,644 km (1985)
paved:
NA
unpaved:
NA
Ports:
Merchant marine:
533 ships (1,000 GRT or over) totaling 10,656,067 GRT/17,009,400 DWT,
bulk 87, cargo 125, chemical tanker 14, combination bulk 3,
combination ore/oil 8, container 80, liquefied gas 4, livestock
carrier 1, oil tanker 179, passenger-cargo 1, refrigerated cargo 3,
roll-on/roll-off cargo 6, specialized tanker 2, vehicle carrier 20
note:
many Singapore flag ships are foreign owned
Airports:
total:
10
usable:
10
with permanent-surface runways:
10
with runways over 3,659 m:
2
with runways 2,440-3,659 m:
4
with runways 1,220-2,439 m:
3
Telecommunications:
good domestic facilities; good international service; good radio and
television broadcast coverage; 1,110,000 telephones; broadcast
stations - 13 AM, 4 FM, 2 TV; submarine cables extend to Malaysia
(Sabah and Peninsular Malaysia), Indonesia, and the Philippines;
satellite earth stations - 1 Indian Ocean INTELSAT and 1 Pacific Ocean
INTELSAT
@Singapore, Defense Forces
Branches:
Army, Navy, Air Force, People''s Defense Force, Police Force
Manpower availability:
males age 15-49 857,824; fit for military service 630,055
Defense expenditures:
exchange rate conversion - $2.7 billion, 6% of GDP (1993 est.)
@Slovakia, Geography
Location:
Central Europe, between Hungary and Poland
Map references:
Ethnic Groups in Eastern Europe, Europe, Standard Time Zones of the
World
Area:
total area:
48,845 sq km
land area:
48,800 sq km
comparative area:
about twice the size of New Hampshire
Land boundaries:
total 1,355 km, Austria 91 km, Czech Republic 215 km, Hungary 515 km,
Poland 444 km, Ukraine 90 km
Coastline:
0 km (landlocked)
Maritime claims:
none; landlocked
International disputes:
Gabcikovo Dam dispute with Hungary; unresolved property issues with
Czech Republic over redistribution of former Czechoslovak federal
property
Climate:
temperate; cool summers; cold, cloudy, humid winters
Terrain:
rugged mountains in the central and northern part and lowlands in the
south
Natural resources:
brown coal and lignite; small amounts of iron ore, copper and
manganese ore; salt
Land use:
arable land:
NA%
permanent crops:
NA%
meadows and pastures:
NA%
forest and woodland:
NA%
other:
NA%
Irrigated land:
NA sq km','79dee48280edd12d2577f0953dc9da2c4e0c98d832ed969b32da4836d74518a0','internet-archive','theciaworldfactb00180gut','txt','b76993377cfa6bdd51979833301976cfc440911ee1fe0b90c117008758860b3f','https://archive.org/download/theciaworldfactb00180gut/180.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

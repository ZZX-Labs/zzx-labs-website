SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f57e9be923b47d027fe4ea811164379bec0bcc222c59647d0e2da818dd1bb00',1994,'','','raw',1,'Central
Intelligence
Agency
The
World
Factbook
1994
The World Factbook is produced annually by
the Central Intelligence Agency for the use of
US Government officials, and the style, frarmat,
coverage, and content are designed to meet
their specific requirements.
Information was provided by the Bureau of the
Census, Central Intelligence Agency, Defense
Intelligence Agency, Defense Nuclear Agency,
Department of State, Foreign Broadcast
Information Service, Maritime Administration,
National Science Foundation (Polar
Information Program), Naval Maritime
Intelligence Center, Office of Territorial and
International Affairs, US Board on Geographic
Names, US Coast Guard, and others.
Comments and queries are welcome and may
be addressed to;
Central Intelligence Agency
Attn: Office of Public and Agency Information
Washington. DC 20505
(703) 351-2053
85 1®
Contents
Page
Page
Page
Notes, Derinitions, and','a87076c2d283bfbe506e9313490176a519a2fb29c01d405dacb92f9434b6727c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6d9b25f03584fa21d24ced785e8036f770f5579d4b0a1c7406fc700aea72e6c',1994,'LT','Lithuania','raw',2,'236
iii
Appendixes
Page
A: The United Nations System 446
B; Abbreviations for International Organizations and Groups 447
C; International Organizations and Groups 452
D: Abbreviations for Selected International Environmental Agreements 485
E: Selected International Environmental Agreements 486
F: Weights and Measures 492
G: Cross-Reference List of Geographic Names 495
Reference Maps The World
North America
Central America and the Caribbean
South America
Europe
Ethnic Groups in Eastern Europe
Middle East
Africa
Asia
Commonwealth of Independent States — European States
Commonwealth of Independent States — Central Asian States
Southeast Asia
Oceania
Arctic Region
Antarctic Region
Standard Time Zones of the World
Notes, Definitions,
and Abbreviations
There have been some significant changes in this edition. The format and
content of the former entries on the Environment have been changed, and
two new appendixes have been added — Appendix D: Abbreviations for
Selected International Environmental Agreements and Appendix E:
Selected International Environmental Agreements. The name of
Macedonia was changed to The Ponner Yugoslav Republic of Macedonia
(FYROM). The gross domestic product (GDP) of most of the developing
countries is now presented on a purchasing power parity (PPP) basis rather
than on an exchange rate basis. The electronic hies used to produce the
Faetbuok have been restructured into a database. As a result, the formats
of some entries in this edition have been changed. Additional changes will
occur in the 1995 Fa^-tbook.
AbbrevladoiK: (see Appendix B for abbreviations for international
organizations arid groups and Appendix D fur abbreviations for
international environmental agreements)
avdp.
avoirdupois
c.i.f.
cost, insurance, and freight
CY
calendar year
DWT
deadweight ton
est.
estimate
Ex-lm
Export-Import Bank of the United Slates
fob.
free on hoard
FRG
Federal Republic of Germany (West Germany):
used fur inf^ormaiion dated before CXtober I99()
orCY91
FSU
former Soviet Union
FY
fiscal year
FYROM The Former Yugoslav Republic of Macedonia
GDP
gross domestic product
GDR
German Democratic Republic (East Germany);
used for infoimaiion dated before .) October 1990
orCY9l
GNP
gross national product
CRT
gross register ton
GWP
gross world product
km
kilometer
kW
kilowatt
kWh
kilowatt hour
m
meter
NA
not available
NEGL
negligible
nm
nautical mile
NZ','994fdc981eacd3ba95d1d24e35d5ccbf74ead0120a1da5060be8c80b6669df12','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c6021144990d9360dceaa06a7464d19e81bbe9d9b25ba856e39503816b577fe7',1994,'NZ','New Zealand','raw',3,'ODA
official development assistance
OOF
other official flows
PDRY
People''s Democratic Republic of Yemen
(Yemen (Aden) or South Yemen); used for
information dated before 22 May 1990 w CY9I
sq km
square kilometer
sq mi
square mile
UAE','4bc869be34d38515c45b90ad317c82c967fc9efc7b3d32d6edd2d6b74986fe52','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('773e1007c267211fe095d97db279a86c8f76a2bc388e209382081cc80f2660e0',1994,'GB','United Kingdom','raw',4,'US
United Slates
USSR
Union of Soviet Socialist Uepublics (Soviet Union);
used for information dated before 25 December 1991
YAR
Yemen Arab Republic (Yemen (Sanaa) or North
Yemen); used for information dated before
22 May l990orCY9l
VII
Notes, Definitions,
and Abbreviations (continued)
Administrative divisions: The numbers. Jesignatory terms, and first-
order administrative divisions are generally those approved by the US
Board on Geographic Names (BCN). Changes that have been reported but
not yet acted on by BGN are noted.
Area: Total area is the sum of all land and water areas delimited by
international boundaries and/or coastlines. Land area is the aggregate of
all surfaces delimited by international boundaries and/or coastlines,
excluding i.nland water bodies (lakes, reservoirs, rivers). Comparative
areas are based on total area equivalents. Most entities are compared with
the entire US or one of the .50 states. The smaller entities are compared
with Washington. DC ( 178 sq km. 69 sq mi) or The Mall in Washington.
DC (0..59 sq km. 0.23 sq mi. 146 acres).
Birth rate: The average annual number of binhs during a year per 1 .000
population at midyear, also known as crude birth rate.
Dotes of infonmtioa: In general, information available as of I January
1994 was used in Ike preparation of this edition. Population figures are
estimates for t July 1994. with population growth rates estimated for
calendar year 1994. Major political events have been updated through
May 1994.
Death rate: The average annual number of deaths during a year per 1.000
population at midyear: also known as crude death rate.
DIgrapha: The digraph is a two-letter "country code" that precisely
identifies every entity without overlap, duplication, or omission. AF. for
example, is the digrt^ for Afghanistan. It is a siandardired genpislitical
data element promulgated in the Fedrnil tn/ormaium Pnwes.ung
Standards PuhUcation (FIPS) 10- .3 by the National Institute of Standards
and Technology (US Department of Commerce) and maintained by the
Office of the Geographer (US Department of Slate). The digraph is used
to eliminate confusion and incompatibility in the collectiim. processing,
and dissemination of area-specific data and is particularly useful for
interchanging data between databases.
Dipknnatk repreienlndoB: The US Government has diplomatic-
relations with 183 nations, including 177 of the 184 UN members
(excluded UN members are Bhutan. Cuba. Iran. Iraq. North Korea.
Vietnam, and former Yugoslavia) In addition, the US has diplomatic-
relations with 6 nations that are not in the liN~Holy See. Kiribati. Nauru.
Switzerland. Tonga, and Tuvalu.
Ecoaomic aid; This entry refers to bilateral commitmems of official
development assistance (ODA) and other official flows (OOF). ODA is
defined as financial assistance which is c-oncessional in character, has tfie
main objective to promoie economic- develi>pment and welfare of LDCs.
and contains a grant element of at least 2.5''s . OOF transactions are also
official government assistanc-e. but with a main objective other than
development and with a grant element less than 2.5‘t. OOF transactions
include official export credits (such as Ex-lni Bank credits), official equity
and portfolio investment, and debt reorganization by the official sector that
does not meet c-oncessional terms. Aid is consider^ to have been
committed when agreements are initialed by the parlies involved and
consiitute a formal declaration of intent.
Notes, Definitions,
and Abbreviations (continued)
Entities: Some of the nations, dependent areas, areas of special
sovereignty, and governments included in this publication are not
independent, and others are not officially recognized by the US
Government. “Nation" refers to a people politically organized into a
sovereign state with a definite terntory. “Ciependent area" refers to a broad
category of political entities that arc associated in some way with a nation.
Names used for page headings are usually the short-form names as
approved by the US Board on Geographic Names. There are 266 entities
in The World Faclbotdt that may be categorized as follows:
NATIONS
183 UN members (excluding both the Socialist Federal Republic of
Yugoslavia and the Federal Republic of Yugoslavia; membership
status in the UN is still to he determined)
7 nations that are not members of the UN — Holy See. Kiribati. Nauru.
Serbia and Montenegro. Switzerland, Tonga. Tuvalu
OTHER
1 Taiwan
DEPENDENT AREAS
6 Australia — Ashmore and Cartier Islands. Christmas Island. C(x;os
(Keeling) Islands. Coral Sea Islands. Heard Island and McDonald
Islands, Norfolk Island
2 Denmark — Fame Islands. Greenland
16 France — Bassas da India. Clippenon Island. Europa Island. French
Guiana. French Polynesia. French Southern and Antamtic Lands.
Gkirioso Islands. Guadel''mpe. iuan de Nova Island. Martinique,
MaysHie. New Caledonia. Reunion. Saint Pierrc and Miquckm.
Trunwiin Isktrid. Wallis and Futuna
2 Netherlands — Aruba. Netherlands Antilles
.1 New Zealand — Ciaik Islands. Niue. Tokelau
.1 Norway — Bouvet Island. Jan Mayen. Svalbard
I Portugal — Macau
16 United Kingdom — Anguilla. Bermuda. British Indian tX''ean
Territory, British Virgin Islands. Cayman Islands. Falkland Islands.
Gibraltar, Guernsey. Hong Kong, Jersey. Isle of Man, Montserrat.
Pitcairn Islands. Saint Helena. Ssaith Ge«>rgia and the South
Sandwich Islands. Turks and Caicos Islands
1.^ United Stales — American Samoa. Baker Island. Guam. Howland
Island, Jarvis Island. Johnston Atoll. Kingman Reef. Midway
Islands. Nava.vsa Island. Nortltem Mariana Islands. Trust Territory of
the Pacific Islands (Palau). Palmyra Atoll, Puerto Rico, Virgin
Islands. Wake Island
MISCELLANEOUS
6 Antarctica, Gaza Strip. Paracel Islands. Spratly Islands. West Bank.','3e7d262bec737df9bfc524f46d15e5b428336328c38c61702efc1a6865fd8c1e','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35de5711c8939ef770559e398fcd8af3b8dff71c06a3d8d3eb86e34c4e6dd8ed',1994,'EH','Western Sahara','raw',5,'OTHER ENTITIES
4 oceans — Arctic Ocean. Atlantic Ocean. Indian Ocean. Pacific Ocean
I _ World
266 total
Notes, Definitions,
and Abbreviations (continued)
Exchange rate: The value of a nation''s monetary unit at a given date or
over a given period of time, as expressed in units of local currency per US
dollar and as determined by international market forces or ofHcial fl!’*.
Gross domestic product (GDP); The value of all Hnal goods and
sel^''ices produced within a nation in a given year.
Gross national product (GNP): The value of all final goods and services
produced within a nation in a given year, plus income earned abroad,
minus income earned by foreigners from domestic productioi,.
Gross world product (GWP): The aggregate value of all goods and
services produced worldwide in a given year.
GNP/GDP methodology: In the “Economy" section. GNP/GDP dollar
estimates for the great majority of countries are derived from pun-hasing
power parity ( PPPf calculations rather than from conversions at offlcial
currency exchange rates. The PPP methtxl normally involves the use of
international dollar price weights, which are applied to the quantities of
goods and services produced in a given economy. In addition to the lack
of reliable data from the majority of countries, the statistician faces a
major difficulty in specifying, identifying, and allowing for the quality of
gtxidsand services. The division of a GNP/GDP estimate in local currency
by the corresponding PPP estimate in dollars gives the PPP vonversion
rate. On average, one thousand dollars will buy the same market basket of
gtaxls in the US as one tlmusand dollars — convened to the Uval currency
at the PPP conversion rate — w ill buy in the other country. Whereas PPP
estimates for OECD ctninlncs are quite reliable. PPP estimates for
developing ctHiniries are rdfen rough approximatiims. The latter estimates
are hjisesi on exirapol.aiion ol numbers published by the UN Intemiitional
Comparistm Program and by Professors Roben Suminers and Alan
Heston of the University of Pennsylvania and their colleagues. Because
currency exchange rates depend on a variety of international and domestic
rinancial forces that (4''ien have little relation to domestic tiuipui, use of
these rates is less satisfavtory for calculating GNP/GDP than the PPP
method In dc''- ehiping countries with weak currencies the exchange rale
estimate of GNP/GDP in dollars is typically one-fourth to one-half the
PPP estimate. FunhemMire. exchange rates may suddenly go up or down
by Hbi or more because of market forces or ofhcial Hat whereas real
output has remained uiKhiinged. On I ^January lUtM.forexample. the 14
countries of the African Financial Community tw hose currencies are lied
to the French franc) devalued rheo’ currencies by Nbr . This move, of
course, did not cut the real output of these countries by half. One
additional caution; the proportion of. say. defense expenditures us a
(lercent of GNP/GDP in Ux-al currency accounts may dilTer substantially
from the proportion w hen GNP/GDP accounts arc expressed in PPP terms,
as. for example, w hen an obscrv er estimates the dollar level of Russian or
Japanese military expendiiores.
Cirowth rale ipopulalimii: The annual percent change in the population,
resulting from a surplus tor delicii) of births over deaths and the balance
of migrants entering and leaving a country. The rate n;uy be positive or
negative.
IIHcil dniax: There are five categories of illicit drugs—narcotics,
stimulants, depressants (sedatives), hallucinogens, and cannabis. These
categories include many drugs legally produced and prescribed by drx''tors
as well as those illegally prixluced and sold outside medical channels.
Cannabis (Cannabis sativa) is the common hemp plant, which provides
hallucinogens with some sedative properties, and includes marijuana ( pot,
Acapulco gold, grass, reefer), tetrahydtxK''annabiiHil (THC, Marinol),
hashish (hash), and hashish oil (hash oil).
X
Notes, Deflnitions,
and Abbreviations (continued)
Coca (Erythroxy Ion coca) is a bush, and ihe leaves contain the stimulant
cocaine. Coca is not to be confused with cocoa, which contes from cacao
seeds and is used in making chocolate, cocoa, and cocoa butter.
Cocaine is a stimulant derived from the leaves of the coca bush.
Depressants (sedatives) are drugs that reduce tension and anxiety and
include chloral hydrate, barbiturates (Amytal, Nembutal, Second,
phenobarbital), twnzodia/cpines (Librium, Valium), melhaqualone
((^aalude), glutethimide (Doriden), and others (Equanil, Placidyl,
Valmid).
Drugs are any chemical substances that effect a physical, mental,
emotional, or behavioral change in an individual.
Drug abuse is the use of any licit or illicit chemical substance that
results in physical, mental, emotional, or behavioral impairment in an
individual.
Hallucinogens are drugs that affect sensation, thinking, self-awareness,
and emotion. Hallucinogens include LSD (acid, microdot), mescaline and
peyote (mexc. bunons. cactus), amphetamine variants (PMA, STP, DOB),
phencyclidine (POP, angel dust, hog), phencyclidine analogues (PCE,
PCPy, TCP), and others (psilocybin, psilocyn).
Hashish is the resinous exudate of the cannabis or hemp plant (Cannabis
sativa).
Heroin is a semisynthetic derivative of morphine.
Mandrax is a synthetic chemical depressant, the same as. or similar to,
Quaalude.
Marijuana is the dried leaves of the cannabis or hemp plant (Cannabis
sativa).
Narcotics are drugs that relieve pain, often induce sleep, and refer to
opium, opium derivatives, and synthetic substitutes. Natural narcotics
include opium (paregoric, parepectolin). morphine (MS-Contin.
Roxanol). codeine (Tylenol with codeine, Empirin with codeine,
Robitussan AC), and thebaine. Semisynthetic narcotics include heroin
(horse, smack), and hydromorphone (Dilaudid). Synthetic narcotics
include meperidine or Pethidine (Demerol, Mepergan). methadone
(Dolophine, Methadose). and others (Darvon, Lomotil).
Opium is the milky exudate of the incised, unripe seedpod of the opium
poppy.
Opium poppy (Papaver somniferum) is the source for many natural and
semisynthetic narcotics.
Poppy straw concentrate is the alkaloid derived from the mature dried
opium poppy.
Qat (kat, khat) is a stimulant from the buds or leaves of catha edulis that
is chewed or drunk as tea.
Stimulants are drugs that relieve mild depression, increase energy and
activity, and include cocaine (coke, snow, crack), amphetamines
(Desoxyn, Dexedrine). phenmetrazine (Preludin), methylphenidate
(Ritalin), and others (Cylert, Sanorex, Tenuate).
Infant mortality rate: The number of deaths to infants under one year
old in a given year per l.0(X) live births occurring in the same year.
International disputes: This category includes a wide variety of
situations that range from traditional bilateral boundary disputes to
unilateral claims of one sort or another. Information regarding disputes
over international Ik undaries and maritime boundaries has been reviewed
by the Department of State. References to other situations involving
borders or frontiers may also be included, such as resource disputes,
geopolitical questions, or irredentist issues. However, inclusion does not
necessarily constitute official acceptance or recognition by the US','bec00ed36de1cf8e9bfea08538edcf7a97dc8d56172f7981ddafecb8cad69e48','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('047f9df48c72e6099c81625c1c216e80035437f7107f9db716dd227b6324574c',1994,'','','raw',1,'The Project Gutenberg EBook of The 1994 CIA World Factbook, by
United States Central Intelligence Agency
This eBook is for the use of anyone anywhere at no cost and with
almost no restrictions whatsoever. You may copy it, give it away or
re-use it under the terms of the Project Gutenberg License included
with this eBook or online at www.gutenberg.net
Title: The 1994 CIA World Factbook
Author: United States Central Intelligence Agency
Release Date: June 5, 2008 [EBook #180]
Language: English
Character set encoding: ASCII
*** START OF THIS PROJECT GUTENBERG EBOOK THE 1994 CIA WORLD FACTBOOK ***
1994 CIA World Factbook
To search for information on a specific country from the list below,
search for @country: @Afganistan, for example. You can also search
directly for one of the categories of that country as follows:
@Afghanistan, Geography
@Afghanistan, People
@Afghanistan, Government
@Afghanistan, Economy
@Afghanistan, Communications
@Afghanistan, Defense Forces
*The Project Gutenberg Edition of the 1994 CIA World Factbook*
Central Intelligence Agency
The World Factbook 1994
US Government officials should obtain copies of The World Factbook directly from
their own organization or through liaison channels from the Central Intelligence
Agency. This publication is also available in microfiche, magnetic tape, or
diskettes for microcomputers.
This publication may be purchased by telephone (VISA or MasterCard) or mail
from:
Superintendent of Documents
P.O. Box 371954
Pittsburgh, PA 15250-7954
Telephone: (202) 783-3238
A subscription to this publication may be purchased from:
Document Expediting (DOCEX) Project
Exchange and Gift Division
Library of Congress
Washington, DC 20540
Telephone: (202) 707-9527
This publication may be purchased in printed form, photocopy, microfiche,
magnetic tape, or diskettes for microcomputers from:
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Telephone: (703) 487-4650
This publication may be purchased in photocopy or microform from:
Photoduplication Service Library of Congress
Washington, DC 20540-5234
Telephone: (202) 707-5640
The World Factbook is produced annually by the Central Intelligence Agency for
the use of US Government officials, and the style, format, coverage, and content
are designed to meet their specific requirements. Information was provided by
the Bureau of the Census, Central Intelligence Agency, Defense Intelligence
Agency, Defense Nuclear Agency, Department of State, Maritime Administration,
National Science Foundation (Polar Information Program), Naval Maritime
Intelligence Center, Office of Territorial and International Affairs, US Board
on Geographic Names, US Coast Guard, and others.
Comments and queries are welcome and may be addressed to:
Central Intelligence Agency
Attn.: Office of Public and Agency Information
Washington, DC 20505
Telephone: (703) 351-2053
Notes, Definitions, and Abbreviations
A','d1ed267830d80db1fdba0f8b54b181a63c418dd35967b6d653191b88bcc721d2','internet-archive','theciaworldfactb00180gut','txt','b76993377cfa6bdd51979833301976cfc440911ee1fe0b90c117008758860b3f','https://archive.org/download/theciaworldfactb00180gut/180.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1aef028284e4cf70169f4d40a6ef2b03e6b5d70a9cb622e2fa3573a4d1853cdf',1994,'EH','Western Sahara','raw',2,'Western Samoa
World
Y
OTHER ENTITIES
4 -- oceans--Arctic Ocean, Atlantic Ocean, Indian Ocean, Pacific Ocean
1 -- World
266 -- total
Exchange rate: The value of a nation''s monetary unit at a given date or over a
given period of time, as expressed in units of local currency per US dollar and
as determined by international market forces or official fiat.
Gross domestic product (GDP): The value of all final goods and services produced
within a nation in a given year.
Gross national product (GNP): The value of all final goods and services produced
within a nation in a given year, plus income earned abroad, minus income earned
by foreigners from domestic production.
Gross world product (GWP): The aggregate value of all goods and services
produced worldwide in a given year.
GNP/GDP methodology: In the "Economy" section, GNP/GDP dollar estimates for the
great majority of countries are derived from purchasing power parity (PPP)
calculations rather than from conversions at official currency exchange rates.
The PPP method normally involves the use of international dollar price weights,
which are applied to the quantities of goods and services produced in a given
economy. In addition to the lack of reliable data from the majority of
countries, the statistician faces a major difficulty in specifying, identifying,
and allowing for the quality of goods and services. The division of a GNP/GDP
estimate in local currency by the corresponding PPP estimate in dollars gives
the PPP conversion rate. On average, one thousand dollars will buy the same
market basket of goods in the US as one thousand dollars--converted to the local
currency at the PPP conversion rate--will buy in the other country. Whereas PPP
estimates for OECD countries are quite reliable, PPP estimates for developing
countries are often rough approximations. The latter estimates are based on
extrapolation of numbers published by the UN International Comparison Program
and by Professors Robert Summers and Alan Heston of the University of
Pennsylvania and their colleagues. Because currency exchange rates depend on a
variety of international and domestic financial forces that often have little
relation to domestic output, use of these rates is less satisfactory for
calculating GNP/GDP than the PPP method. In developing countries with weak
currencies the exchange rate estimate of GNP/GDP in dollars is typically one-
fourth to one-half the PPP estimate. Furthermore, exchange rates may suddenly
go up or down by 10% or more because of market forces or official fiat whereas
real output has remained unchanged. On 12 January 1994, for example, the 14
countries of the African Financial Community (whose currencies are tied to the
French franc) devalued their currencies by 50%. This move, of course, did not
cut the real output of these countries by half. One additional caution: the
proportion of, say, defense expenditures as a percent of GNP/GDP in local
currency accounts may differ substantially from the proportion when GNP/GDP
accounts are expressed in PPP terms, as, for example, when an observer estimates
the dollar level of Russian or Japanese military expenditures;
Growth rate (population): The annual percent change in the population, resulting
from a surplus (or deficit) of births over deaths and the balance of migrants
entering and leaving a country. The rate may be positive or negative.
Illicit drugs: There are five categories of illicit drugs--narcotics,
stimulants, depressants (sedatives), hallucinogens, and cannabis. These
categories include many drugs legally produced and prescribed by doctors as well
as those illegally produced and sold outside medical channels.
Cannabis (Cannabis sativa) is the common hemp plant, which provides
hallucinogens with some sedative properties, and includes marijuana (pot,
Acapulco gold, grass, reefer), tetrahydrocannabinol (THC, Marinol), hashish
(hash), and hashish oil (hash oil).
Coca (Erythroxylon coca) is a bush, and the leaves contain the stimulant
cocaine. Coca is not to be confused with cocoa, which comes from cacao seeds and
is used in making chocolate, cocoa, and cocoa butter.
Cocaine is a stimulant derived from the leaves of the coca bush.
Depressants (sedatives) are drugs that reduce tension and anxiety and include
chloral hydrate, barbiturates (Amytal, Nembutal, Seconal, phenobarbital),
benzodiazepines (Librium, Valium), methaqualone (Quaalude), glutethimide
(Doriden), and others (Equanil, Placidyl, Valmid).
Drugs are any chemical substances that effect a physical, mental, emotional, or
behavioral change in an individual.
Drug abuse is the use of any licit or illicit chemical substance that results in
physical, mental, emotional, or behavioral impairment in an individual.
Hallucinogens are drugs that affect sensation, thinking, self-awareness, and
emotion. Hallucinogens include LSD (acid, microdot), mescaline and peyote (mexc,
buttons, cactus), amphetamine variants (PMA, STP, DOB), phencyclidine (PCP,
angel dust, hog), phencyclidine analogues (PCE, PCPy, TCP), and others
(psilocybin, psilocyn).
Hashish is the resinous exudate of the cannabis or hemp plant (Cannabis sativa).
Heroin is a semisynthetic derivative of morphine.
Mandrax is a synthetic chemical depressant, the same as, or similar to Quaalude.
Marijuana is the dried leaves of the cannabis or hemp plant (Cannabis sativa).
Narcotics are drugs that relieve pain, often induce sleep, and refer to opium,
opium derivatives, and synthetic substitutes. Natural narcotics include opium
(paregoric, parepectolin), morphine (MS-Contin, Roxanol), codeine (Tylenol with
codeine, Empirin with codeine, Robitussan AC), and thebaine. Semisynthetic
narcotics include heroin (horse, smack), and hydromorphone (Dilaudid). Synthetic
narcotics include meperidine or Pethidine (Demerol, Mepergan), methadone
(Dolophine, Methadose), and others (Darvon, Lomotil).
Opium is the milky exudate of the incised, unripe seedpod of the opium poppy.
Opium poppy (Papaver somniferum) is the source for many natural and
semisynthetic narcotics.
Poppy straw concentrate is the alkaloid derived from the mature dried opium
poppy.
Qat (kat, khat) is a stimulant from the buds or leaves of catha edulis that is
chewed or drunk as tea.
Stimulants are drugs that relieve mild depression, increase energy and activity,
and include cocaine (coke, snow, crack), amphetamines (Desoxyn, Dexedrine),
phenmetrazine (Preludin), methylphenidate (Ritalin), and others (Cylert,
Sanorex, Tenuate).
Infant mortality rate: The number of deaths to infants under one year old in a
given year per l,000 live births occurring in the same year.
International disputes: This category includes a wide variety of situations that
range from traditional bilateral boundary disputes to unilateral claims of one
sort or another. Information regarding disputes over international boundaries
and maritime boundaries has been reviewed by the Department of State. References
to other situations involving borders or frontiers may also be included, such as
resource disputes, geopolitical questions, or irredentist issues. However,
inclusion does not necessarily constitute official acceptance or recognition by
the US Government.
Irrigated land: The figure refers to the land area that is artificially supplied
with water.
Land use: Human use of the land surface is categorized as arable land--land
cultivated for crops that are replanted after each harvest (wheat, maize, rice);
permanent crops--land cultivated for crops that are not replanted after each
harvest (citrus, coffee, rubber); meadows and pastures--land permanently used
for herbaceous forage crops; forest and woodland--under dense or open stands of
trees; and other--any land type not specifically mentioned above (urban areas,
roads, desert).
Leaders: The chief of state is the titular leader of the country who represents
the state at official and ceremonial functions but is not involved with the day-
to-day activities of the government. The head of government is the
administrative leader who manages the day-to-day activities of the government.
In the UK, the monarch is the chief of state, and the Prime Minister is the head
of government. In the US, the President is both the chief of state and the head
of government.
Life expectancy at birth: The average number of years to be lived by a group of
people all born in the same year, if mortality at each age remains constant in
the future.
Literacy: There are no universal definitions and standards of literacy. Unless
otherwise noted, all rates are based on the most common definition--the ability
to read and write at a specified age. Detailing the standards that individual
countries use to assess the ability to read and write is beyond the scope of
this publication.
Maritime claims: The proximity of neighboring states may prevent some national
claims from being extended the full distance.
Merchant marine: All ships engaged in the carriage of goods. All commercial
vessels (as opposed to all nonmilitary ships), which excludes tugs, fishing
vessels, offshore oil rigs, etc.; also, a grouping of merchant ships by
nationality or register.
Captive register--A register of ships maintained by a territory, possession, or
colony primarily or exclusively for the use of ships owned in the parent
country; also referred to as an offshore register, the offshore equivalent of an
internal register. Ships on a captive register will fly the same flag as the
parent country, or a local variant of it, but will be subject to the maritime
laws and taxation rules of the offshore territory. Although the nature of a
captive register makes it especially desirable for ships owned in the parent
country, just as in the internal register, the ships may also be owned abroad.
The captive register then acts as a flag of convenience register, except that it
is not the register of an independent state.
Flag of convenience register--A national register offering registration to a
merchant ship not owned in the flag state. The major flags of convenience (FOC)
attract ships to their register by virtue of low fees, low or nonexistent
taxation of profits, and liberal manning requirements. True FOC registers are
characterized by having relatively few of the ships registered actually owned in
the flag state. Thus, while virtually any flag can be used for ships under a
given set of circumstances, an FOC register is one where the majority of the
merchant fleet is owned abroad. It is also referred to as an open register.
Flag state--The nation in which a ship is registered and which holds legal
jurisdiction over operation of the ship, whether at home or abroad. Differences
in flag state maritime legislation determine how a ship is manned and taxed and
whether a foreign-owned ship may be placed on the register.
Internal register--A register of ships maintained as a subset of a national
register. Ships on the internal register fly the national flag and have that
nationality but are subject to a separate set of maritime rules from those on
the main national register. These differences usually include lower taxation of
profits, manning by foreign nationals, and, usually, ownership outside the flag
state (when it functions as an FOC register). The Norwegian International Ship
Register and Danish International Ship Register are the most notable examples of
an internal register. Both have been instrumental in stemming flight from the
national flag to flags of convenience and in attracting foreign owned ships to
the Norwegian and Danish flags.
Merchant ship--A vessel that carries goods against payment of freight; commonly
used to denote any nonmilitary ship but accurately restricted to commercial
vessels only.
Register--The record of a ship''s ownership and nationality as listed with the
maritime authorities of a country; also, the compendium of such individual
ships'' registrations. Registration of a ship provides it with a nationality and
makes it subject to the laws of the country in which registered (the flag state)
regardless of the nationality of the ship''s ultimate owner.
Money figures: All money figures are expressed in contemporaneous US dollars
unless otherwise indicated.
National product: The total output of goods and services in a country in a given
year. See Gross domestic product (GDP), Gross national product (GNP), and
GNP/GDP methodology.
Net migration rate: The balance between the number of persons entering and
leaving a country during the year per 1,000 persons (based on midyear
population). An excess of persons entering the country is referred to as net
immigration (3.56 migrants/1,000 population); an excess of persons leaving the
country as net emigration (-9.26 migrants/1,000 population).
Population: Figures are estimates from the Bureau of the Census based on
statistics from population censuses, vital statistics registration systems, or
sample surveys pertaining to the recent past, and on assumptions about future
trends. Starting with the 1993 Factbook demographic estimates for some countries
(mostly African) have taken into account the effects of the growing incidence of
AIDS infections; in 1993 these countries were Burkina, Burundi, Central African
Republic, Congo, Cote d''Ivoire, Haiti, Kenya, Malawi, Rwanda, Tanzania, Uganda,
Zaire, Zambia, Zimbabwe, Thailand, and Brazil.
Total fertility rate: The average number of children that would be born per
woman if all women lived to the end of their childbearing years and bore
children according to a given fertility rate at each age.
Years: All year references are for the calendar year (CY) unless indicated as
fiscal year (FY).
Note: Information for the US and US dependencies was compiled from material in
the public domain and does not represent Intelligence Community estimates. The
Handbook of International Economic Statistics, published annually in September
by the Central Intelligence Agency, contains detailed economic information for
the Organization for Economic Cooperation and Development (OECD) countries,
Eastern Europe, the newly independent republics of the former nations of
Yugoslavia and the Soviet Union, and selected other countries. The Handbook can
be obtained wherever The World Factbook is available.
***THE WORLD FACTBOOK 1994
@Afghanistan, Geography
Location:
Southern Asia, between Iran and Pakistan
Map references:
Asia, Middle East, Standard Time Zones of the World
Area:
total area:
647,500 sq km
land area:
647,500 sq km
comparative area:
slightly smaller than Texas
Land boundaries:
total 5,529 km, China 76 km, Iran 936 km, Pakistan 2,430 km,
Tajikistan 1,206 km, Turkmenistan 744 km, Uzbekistan 137 km
Coastline:
0 km (landlocked)
Maritime claims:
none; landlocked
International disputes:
periodic disputes with Iran over Helmand water rights; Iran supports
clients in country, private Pakistani and Saudi sources also are
active; power struggles among various groups for control of Kabul,
regional rivalries among emerging warlords, traditional tribal
disputes continue; support to Islamic fighters in Tajikistan''s civil
war; border dispute with Pakistan (Durand Line); support to Islamic
militants worldwide by some factions
Climate:
arid to semiarid; cold winters and hot summers
Terrain:
mostly rugged mountains; plains in north and southwest
Natural resources:
natural gas, petroleum, coal, copper, talc, barites, sulphur, lead,
zinc, iron ore, salt, precious and semiprecious stones
Land use:
arable land:
12%
permanent crops:
0%
meadows and pastures:
46%
forest and woodland:
3%
other:
39%
Irrigated land:
26,600 sq km (1989 est.)','4b44bf7f995ba10238bc443241a78ef0b24e7f3da1fe8c7aaffc573abc337b7d','internet-archive','theciaworldfactb00180gut','txt','b76993377cfa6bdd51979833301976cfc440911ee1fe0b90c117008758860b3f','https://archive.org/download/theciaworldfactb00180gut/180.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dad968e22fb72ff0081b3fc89d7e9821649dedb90bda34593fca33e0f93ec9d6',1994,'ZW','Zimbabwe','raw',3,'Appendixes
A: The United Nations System
B: Abbreviations for International Organizations and Groups
C: International Organizations and Groups
D: Abbreviations for Selected International Environmental Agreements
E: Selected International Environmental Agreements
F: Weights and Measures
G: Cross-Reference List of Geographic Names
Reference Maps
The World
North America
Central America and the Caribbean
South America
Europe
Ethnic Groups in Eastern Europe
Middle East
Africa
Asia
Commonwealth of Independent States--European States
Commonwealth of Independent States--Central Asian States
Southeast Asia
Oceania
Arctic Region
Antarctic Region
Standard Time Zones of the World
There have been some significant changes in this edition. The format and content
of the former entries on the Environment have been changed, and two new
appendixes have been added--Appendix D: Abbreviations for Selected International
Environmental Agreements and Appendix E: Selected International Environmental
Agreements. The name of Macedonia was changed to The Former Yugoslav Republic of
Macedonia (FYROM). The gross domestic product (GDP) of most of the developing
countries is now presented on a purchasing power parity (PPP) basis rather than
on an exchange rate basis. The electronic files used to produce the Factbook
have been restructured into a database. As a result, the formats of some entries
in this edition have been changed. Additional changes will occur in the 1995
Factbook.
Abbreviations: (see Appendix B for abbreviations for international organizations
and groups and Appendix D for abbreviations for international environmental
agreements)
avdp. -- avoirdupois
c.i.f. -- cost, insurance, and freight
CY -- calendar year
DWT -- deadweight ton
est. -- estimate
Ex-Im -- Export-Import Bank of the United States
f.o.b. -- free on board
FRG -- Federal Republic of Germany (West Germany); used for information dated
before 3 October 1990 or CY91
FSU -- former Soviet Union
FY -- fiscal year
FYROM -- The Former Yugoslav Republic of Macedonia
GDP -- gross domestic product
GDR -- German Democratic Republic (East Germany); used for information dated
before 3 October 1990 or CY91
GNP -- gross national product
GRT -- gross register ton
GWP -- gross world product
km -- kilometer
kW -- kilowatt
kWh -- kilowatt hour
m -- meter
NA -- not available
NEGL -- negligible
nm -- nautical mile
NZ -- New Zealand
ODA -- official development assistance
OOF -- other official flows
PDRY -- People''s Democratic Republic of Yemen [Yemen (Aden) or South Yemen];
used for information dated before 22 May 1990 or CY91
sq km -- square kilometer
sq mi -- square mile
UAE -- United Arab Emirates
UK -- United Kingdom
US -- United States
USSR -- Union of Soviet Socialist Republics (Soviet Union); used for information
dated before 25 December 1991
YAR -- Yemen Arab Republic [Yemen (Sanaa) or North Yemen]; used for information
dated before 22 May 1990 or CY91
Administrative divisions: The numbers, designatory terms, and first-order
administrative divisions are generally those approved by the US Board on
Geographic Names (BGN). Changes that have been reported but not yet acted on by
BGN are noted.
Area: Total area is the sum of all land and water areas delimited by
international boundaries and/or coastlines. Land area is the aggregate of all
surfaces delimited by international boundaries and/or coastlines, excluding
inland water bodies (lakes, reservoirs, rivers). Comparative areas are based on
total area equivalents. Most entities are compared with the entire US or one of
the 50 states. The smaller entities are compared with Washington, DC (178 sq km,
69 sq mi) or The Mall in Washington, DC (0.59 sq km, 0.23 sq mi, 146 acres).
Birth rate: The average annual number of births during a year per 1,000
population at midyear; also known as crude birth rate.
Dates of information: In general, information available as of 1 January 1994 was
used in the preparation of this edition. Population figures are estimates for 1
July 1994, with population growth rates estimated for calendar year 1994. Major
political events have been updated through May 1994.
Death rate: The average annual number of deaths during a year per l,000
population at midyear; also known as crude death rate.
Digraphs: The digraph is a two-letter "country code" that precisely identifies
every entity without overlap, duplication, or omission. AF, for example, is the
digraph for Afghanistan. It is a standardized geopolitical data element
promulgated in the Federal Information Processing Standards Publication (FIPS)
10-3 by the National Institute of Standards and Technology (US Department of
Commerce) and maintained by the Office of the Geographer (US Department of
State). The digraph is used to eliminate confusion and incompatibility in the
collection, processing, and dissemination of area-specific data and is
particularly useful for interchanging data between databases.
Diplomatic representation: The US Government has diplomatic relations with 183
nations, including 177 of the 184 UN members (excluded UN members are Bhutan,
Cuba, Iran, Iraq, North Korea, Vietnam, and former Yugoslavia). In addition, the
US has diplomatic relations with 6 nations that are not in the UN - Holy See,
Kiribati, Nauru, Switzerland, Tonga, and Tuvalu.
Economic aid: This entry refers to bilateral commitments of official development
assistance (ODA) and other official flows (OOF). ODA is defined as financial
assistance which is concessional in character, has the main objective to promote
economic development and welfare of LDCs. and contains a grant element of at
least 25%. OOF transactions are also official government assistance, but with a
main objective other than development and with a grant element less than 25%.
OOF transactions include official export credits (such as Ex-Im Bank credits),
official equity and portfolio investment, and debt reorganization by the
official sector that does not meet concessional terms. Aid is considered to have
been committed when agreements are initialed by the parties involved and
constitute a formal declaration of intent.
Entities: Some of the nations, dependent areas, areas of special sovereignty,
and governments included in this publication are not independent, and others are
not officially recognized by the US Government. "Nation" refers to a people
politically organized into a sovereign state with a definite territory.
"Dependent area" refers to a broad category of political entities that are
associated in some way with a nation. Names used for page headings are usually
the short-form names as approved by the US Board on Geographic Names. There are
266 entities in The World Factbook that may be categorized as follows:
NATIONS
183 -- UN members (excluding both the Socialist Federal Republic of Yugoslavia
and the Federal Republic of Yugoslavia; membership status in the UN is still to
be determined)
7 -- nations that are not members of the UN--Holy See, Kiribati, Nauru, Serbia
and Montenegro, Switzerland, Tonga, Tuvalu
OTHER
1 -- Taiwan
DEPENDENT AREAS
6 -- Australia--Ashmore and Cartier Islands, Christmas Island, Cocos (Keeling)
Islands, Coral Sea Islands, Heard Island and McDonald Islands, Norfolk Island
2 -- Denmark--Faroe Islands, Greenland
16 -- France--Bassas da India, Clipperton Island, Europa Island, French Guiana,
French Polynesia, French Southern and Antarctic Lands, Glorioso Islands,
Guadeloupe, Juan de Nova Island, Martinique, Mayotte, New Caledonia, Reunion,
Saint Pierre and Miquelon, Tromelin Island, Wallis and Futuna
2 -- Netherlands--Aruba, Netherlands Antilles
3 -- New Zealand--Cook Islands, Niue, Tokelau
3 -- Norway--Bouvet Island, Jan Mayen, Svalbard
1 -- Portugal--Macau
16 -- United Kingdom--Anguilla, Bermuda, British Indian Ocean Territory, British
Virgin Islands, Cayman Islands, Falkland Islands, Gibraltar, Guernsey, Hong
Kong, Jersey, Isle of Man, Montserrat, Pitcairn Islands, Saint Helena, South
Georgia and the South Sandwich Islands, Turks and Caicos Islands
15 -- United States--American Samoa, Baker Island, Guam, Howland Island, Jarvis
Island, Johnston Atoll, Kingman Reef, Midway Islands, Navassa Island, Northern
Mariana Islands, Trust Territory of the Pacific Islands (Palau), Palmyra Atoll,
Puerto Rico, Virgin Islands, Wake Island
MISCELLANEOUS
6 -- Antarctica, Gaza Strip, Paracel Islands, Spratly Islands, West Bank,','6810f6e72f15554eda0be8e4a7f87b5f1040ab4db171bb0eaa2dc4a651eaf3ac','internet-archive','theciaworldfactb00180gut','txt','b76993377cfa6bdd51979833301976cfc440911ee1fe0b90c117008758860b3f','https://archive.org/download/theciaworldfactb00180gut/180.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

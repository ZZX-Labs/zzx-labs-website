SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82fdb446d99c5edde3513f2e1352a71c9f579f6c3b1ca7f196d98a6fee354c88',1994,'PK','Pakistan','economy',10,'Overview: Afghanistan is an extremely poor,
landlocked country, highly dependent on
farming (wheat especially) and livestock
raising (sheep and goats). Economic
considerations have played second fiddle to
political and military upheavals during more
than 14 years of war, including the nearly 10-
year Soviet military occupation (which ended
15 February 1989). Over the past decade, one-
third of the population fled the country, with
Pakistan sheltering more than 3 million
refugees and Iran about 3 million. About 1 .4
million Afghan refugees r.main in Pakistan
and about 2 million in Iran. Another I million
probably moved into and around urban areas
within Afghanistan. Aithough reliable data are
unavailable, gross domestic product is lower
than 12 years ago because of the loss of labor
and capital and the disruption of trade and
transpoii.
National product: GDP SNA
National product real growth rate: NA%
National product per capita: SNA
Inflation rate (consumer prices): NA%
Unemployment rate: NA%
Budget:
revenues: SNA
expenditures: SNA, including capital
expenditures of SNA
Exports: S243 million (f.o.b., 1991)
commodities: fruits and nuts, handwoven
carpets, wool, cotton, hides and pelts, precious
and semi-precious gems
partners: FSU countries, Pakistan, Iran,
Germany, India, UK, Belgium, Luxembourg,
Czechoslovakia
Imports: $737 million (c.i.f., 1991)
commodities: food and petroleum products;
most consumer goods
partners: FSU countries, Pakistan, Iran, Japan,
Singapore, India, South Korea, Germany
External debt: $2.3 billion (March 1991 est.)
Industrial production: growth rate 2.3%
(FY9I est.); accounts for about 25% of GDP
Electricity:
capacity: 480,000 kW
production: I billion kWh
consumption per capita: 60 kWh (1992)
Industries: small-scale production of textiles,
soap, furniture, shoes, fertilizer, and cement;
handwoven carpets; natural gas, oil, coal,
copper
Agriculture: largely subsistence farming and
nomadic animal husbandry; cash products —
wheat, fruits, nuts, karakul pelts, wool, mutton
niicit drugs: an illicit cultivator of opium
poppy and cannabis for the international dmg
trade; world''s second-largest opium producer
after Burma (680 metric tons in 1993) and a
major source of hashish
Economic aid:
recipient: $450 million US assistance provided
1985-1993; USAID will stop all programs by
mid- 1994; the UN provides assistance in the
form of food aid. immunization. land mine
removal, and a wide range of aid to refugees
and displacedpersons
Currency: 1 afghani (AF) = 100 puls
Exchange rates: afghanis (AO per US$1 —
1,900 (January 1994), 1,019 (March 1993),
850(1991), 700(1989-90), 220(1988-89);
note — these rates reflect the free market
exchange rates rather than the official
exchange rates
Fiscal year: 21 March — 20 March
Overview: An extremely poor country by
European standards, Albania is making the
difficult transition to a more open-market
economy. The economy rebounded in 1993
after a severe depression accompanying the
collapse of the previous centrally planned
system in 1990 and 1991. Stabilization
policies, including public sector layoffs and
reduced social services, have improved the
government’s fiscal situation and reduced
inflation. The recovery was spurred by the
remittances of some 5% of the population
which works abroad, mostly in Greece and
Italy. Foreign assistance and humanitarian aid
also supported the recovery. Most agricultural
land was privatized in 1992, substantially
improving peasant incomes. Albania''s limited
industrial sector, now less than one-sixth of
GDP, continued to decline in 1 993. A sharp fall
in chromium prices reduced hard currency
receipts from the mining sector. Large
segments of the population, especially those
living in urban areas, continue to depend on
humanitarian aid to meet basic food
requirements. Unemployment remains a .severe
problem accounting for approximately one-
fifth of the work force. Growth is expected to
continue in 1994, but could falter if Albania
becomes involved in the conflict in the former
Yugoslavia, workers'' remittances from Greece
are reduced, or foreign assistance declines.
National product: GDP — purchasing power
equivalent — $3.3 billion (1993 est.)
National product real growth rate: 1 1 %
(1993)
National product per capita: $I,I(X}(I993
est.)
Inflation rate (consumer prices): 3 1 %
(1993 est.)
Unemployment rate: 1 8% ( 1 993 est. )
Budget:
revenues: $1.1 billion
expenditures: $1.4 billion, including capital
expenditures of $70 million ( 1 99 1 est.)
Exports: $70 million (fo.b., 1992)
commodities: asphalt, metals and metallic ores,
electricity, crude oil, vegetables, fruits, tobacco
partners: Italy, The Former Yugoslav
Republic of Macedonia. Germany, Greece,
Czechoslovakia, Poland. Romania, Bulgaria,
Overview: Pakistan is a poor Third World
country faced with the usual problems of
rapidly increasing population, sizable
government deficits, and heavy dependence on
foreign aid. In addition, the economy must
support a large military establishment. Rapid
economic growth, averaging 5%-6% over the
past decade has helped Pakistan cope with
these problems. However, growth slumped to
3% in FY93 because of severe flooding, which
damaged the key export crop, cotton. Almost
all agriculture and small-scale industry is in
private hands. In 1 990, Pakistan embarked on a
sweeping ■ conomic liberalization program to
boost foreign and domestic private investment
and lower foreign aid dependence. The
SHARIF government denationalized several
state-owned ftrms and attracted some foreign
investment. Pakistan likely will have difficulty
raising living standards because of its rapidly
expanding population. At the current rate of
growth, population would double in 25 years.
National product: GNP — purchasing power
equivalent — $239 billion (1993 est.)
National product real growth rate: 3%
(FY93 est.)
National product per capita: $ 1 .900 ( 1 993
est.)
Inflation rate (consumer prices): 1 2.7%
(FY91)
Unemployment rate: 10% (FY91 est.)
Budget:
revenues; $9.4 billion
expenditures; $10.9 billion, including capital
expenditures of $3.1 billion (1993 est.)
Exports: $6.8 billion (f.o.b.. FY92)
commodities; cotton, textiles, clothing, rice,
leather, carpets
partners; US. Japan, Hong Kong, Germany.
UK
Imports: $9.1 billion (f.o.b.. FY92)
commodities; petroleum, petroleum products.
304
Palmyra Atoll
(territory of the US)
machinery, transportation equipment,
vegetable oils, animal fats, chemicals
partners; Japan, US, Germany, UK, Saudi
Arabia
Exteraal debt: $24 billion (1993 est.)
Industrial production: growth rate 7.3%
(FY92); accounts for 23% of GDP
Electricity:
capacity: 10,(XX),(XX) kW
production: 43 billion kWh
consumption per capita: 350 kWh (1992)
Industries: textiles, food processing,
beverages, construction materials, clothing,
paper products, shrimp
Agriculture: 22% of GDP, over 50% of labor
force; world''s largest contiguous irrigation
system; major crops — cotton, wheat, rice,
sugarcane, fruits, vegetables; livestock
products — milk, beef, mutton, eggs;
self-sufTicient in food grain
Illicit drugs: major illicit producer of opium
and hashish for the international drug trade;
despite some success in reducing cultivation,
remains world’s fourth largest op’um producer
(140 metric tons in 1993)
Economic aid:
recipient: US commitments, including Ex-Im
(FY70-89), S4.5 billion; Western (non-US)
countries, ODA and (X>F bilateral
commitments (1980-89), $91 billion; OPEC
bilateral aid (1979-89), $2.3 billion;
Communist countries (1970-89), $3.2 billion
note; including Bangladesh prior to 1972
Currency: 1 Pakistani rupee (PRe) s I00
paisa
Exchange rates: Pakistani rupees (PRs) per
US$1— 30.2 14 (January 1994), 28.107 (1993),
25.083 (1992), 23.801 (1991), 21.707 (1990),
20.541 (1989)
Fiscal year: 1 July — 30 June','b6663fb55ae92f606e19b23f8242e7c17a18c97ae03a64505a4638bd5a907e5a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3e4348038b9e2fc487d5c93aa20cecb5d182d321426ec429e5cd38ebb027ca8',1994,'HU','Hungary','economy',12,'Imports: $.424 million (f.o.b.. 1992)
commodities: machinery, consumer goods,
grains
partners: Italy, The Former Yugoslav
Republic of Macedonia, Germany,
Czechoslovakia. Romania, Poland, Hungary.
Bulgaria. Greece
External debt: $724 million (1993 est.)
Industrial production: growth rate -10%
(1993 est.): accounts for 16% of GDP (1993
est.)
Electricity:
capacity: 1 ,690,000 kW
production: 5 billion kWh
consumption per capita: 1 ,520 kWh ( 1 992)
Industries: food processing, textiles and
clothing, lumber, oil, cement, chemicals,
mining, basic metals, hydropower
Agriculture: accounts for 55% of GDP;
arable land per capita among lowest in Europe;
80% of arable land now in private hands; one-
half of work force engaged in farming;
produces wide range of temperate-zone crops
and livestock
Illicit drugs: transshipment point for
Southwest Asian heroin transiting the Balkan
route; limited opium production
Economic aid:
recipient: $190 million humanitarian aid; $94
million in loans/guarantees/credits
Currency: I lek(L)= lOOqintars
Exchange rates: leke (L) per US$1 — 99
(January 1994), 97 (January l993),50(January
1992), 25 (September 1991)
Fiscal year: calendar year
Overview; Hungary is still in the midst of a
difficult transition from a cotntnand to a market
economy. Its economic reforms during the
Communist era gave it a head .start on this
process, particularly in terms of attracting
foreign investors — Hungary has accounted for
about half of all foreign direct investment in
Eastern Europe since 1989. Nonetheless, the
economy continued to contract in 1993, with
real GDP falling perhaps 1 %. Although the
privatization prix-ess has lagged, in December
1993 Hungary carried out the largest
privatization yet in Eastern Eunipe. selling a
controlling interest in the Muiav
telecommunications firm to private
investors — including a 30‘7r share to a US-
German consortium fer $875 million. Overall,
about half of GDP now originates in the private
sector. Unemployment rose to about 139''r in
1993 while intladon remained above 2()9''r. and
falling exports pushed the trade deficit to about
$3 billion. The government hopes that
economic recovery in Western Europe in 1994
will boost exports. ''lower the trade deficit, and
help jump-start the economy. The budget,
however, is likely to remain a serious concern;
depressed tux revenue pushed up the budget
deficit in 1993.
National product; GDP — purchasing power
equivalent— $57 billion ( 1993 est.)
National product real growth rate: - 1 ff
(1993 est.)
National product per capita; $5.5()() ( 1993
est.)
Inflation rate (consumer prices); 23''/r
(1993 est.)
Unemployment rate: 1 3''/) 1 1 993)
Budget;
revenues; $10.2 billion
expenditures: $12.5 billion, including capital
expem.litures of SNA (1993 est.)
Exports: $8,9 billion (f.o.b.. 1993 est.)
coinmotlities: raw materials, semi-finished
goods, chemicals 39.6%, machinery 14.5%,
consumer ginxls 22.3%, food and agriculture
20.0%, fuels and energy 3.6% (January-June
1993)
IHirtners- EC 49.8% (Germany 27.8%. Italy
9.5% ), Austria 10,7%, the FSU 13.1%, Ea.siern
Europe 9,8% (1992)
Imports: $12.5 billion (f.o.b.. 1993 est.)
commodities; fuels and energy 1 3.9%. raw
materials, semi-finished goods, chemicals
35.9%, machinery 22.4%, consumer goods
21.8%, food and agriculture 6.0% (January-
June 1993)
partners: EC 42.8% (Germany 23.6%. Italy
6.3%). Austria 14.4%. the FSU 16.8%. Eastern
Europe 9.2%
External debt: $24.7 billion (November
1993)
Industrial production: growth rate 4% ( 1 993
est.)
Electricity:
capacity: 7.2(K).0()0 kW
product''on: 30 billion kWh
consumption per capita: 3,0(X) kWh (1992)
Industries: mining, metallurgy, construction
materials, processed fiXKls, textiles, chemicals
(esi-ieciully phurmuceuticuls), bu.se.s,
automobiles
Agriculture: including forestry, accounts for
1 59< of GDP and 16% of employment; highly
diversified crop and livestock farming;
principal crops — wheal, wm, sunfiowers.
potatoes, sugar beets; livestock— hogs, cattle,
poultiy, dairy prtxlucts; self-sufficient in food
output
Illicit drugs: transshipment point for
Southeast Asia heroin transiting the Balkan
route
Economic aid;
recipient; assistance pledged by OECD
countries since 1989 about $9 billion
Currency: 1 forint (Ft) = 100 filler
Exchange rates: forints per US$1 — 93.46
(September 1993). 92.5 (1993), 78.99 (1992).
74 ,74 ( 1 99 1 ). 63 2 1 ( 1 990). 59.07 (1989)
Fiscal year: calendar year','0f1b3f5f1372e65b02051d683b06b13823aba7b6fa232bdb1c931af7e8cc2b4d','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bd4d45408bcafa54d984463ef29974353e29a4e5dd465390a8b9b43ec681bd8',1994,'TN','Tunisia','economy',19,'Overview: The hydrcxtarbons sector is the
backbone of the economy, accounting for
roughly 57% of government revenues. 25% of
GDP. and almost all expon earnings; Algeria
has the fifth largest reserves of natural gas in
the world and ranks fourteenth for oil. Algiers''
efforts to reform one of the most centrally
planned economies in the Arab world began
after the 1986 collapse of world oil prices
plunged the country into a severe recession. In
1989, the government launched a
comprehensive, IMF-supported program to
achieve macroeconomic stabilization and to
introduce market mechanisms into the
economy. Despite substantial progress toward
macroeconomic adjustment, in 1992 the
reform drive stalled as Algiers became
embroiled in political turmoil. In September
1993, a new government was formed, one of
whose priorities was the resumption and
acceleration of the structural adjustment
process. Buffeted by the slump in world oil
prices and burdened with a heavy foreign debt,
Algiers in 1993 resumed negotiations with the
IMF and is on track to conclude a standby
arrangement with the Fund in 1994.
National product: GDP — purchasing power
equivalent — $89 billion (1993 est.)
National product real growth rate: I %
(1993 est.)
National product per capita; $3,3(X) (1992
est.)
Inflation rate (consumer prices): 22%
(1993 est.)
llnemployment rate: 22% (1993 est.)
Budget:
revenuex: $14.4 billion
expenditurex: $14.6 billion, including capital
expenditures of $3.5 billion (1992 est.)
Exports; $1 1.4 billion (f.o.b.. 1993 e.st.)
commoditiex: petroleum and natural gas 97%
partnerx: Italy 21%, France 16%, US 14%.
Germany 13%, Spain 9%
Imports; $9 billion (f.o.b., 1993 est.)
commodities: capital goods 39.7%, food and
beverages 2 1 .7%. consumer grxxls 11.8%
(1990)
panners: France 29%. Italy 14%, Spain 9%,
US 9%, Germany 7%
External debt: $26 billion (1994)
Industrial production: growth rate NA%
Electricity:
capacity: 6,380,000 kW
production: 16.384 billion kWh
consumption per capita: 630 kWh (1992)
Industries: petroleum, light industries,
natural gas, mining, electrical, petrochemical,
food processing
Agriculture; accounts for 1 2.8% of GDP
( 1 993 est. ) and employs 22% of labor force;
products — wheat, barley, oats, grapes, olives,
citrus, fruits, sheep, cattle; net importer of
food — grain, vegetable oil, sugar
Economic aid:
recipient: US commitments, including Ex-lm
(FY70-85), $1.4 billion; We.stem (non-US)
countries. ODA and OOF bilateral
commitments ( 1970-89). $925 million; OPEC
bilateral aid (1979-89), $1.8 billion;
Communist countries (1970-89), $2.7 billion;
net official disbursements (1985-89), $375
million
Currency: 1 Algerian dinar (DA) = 100
centimes
Exchange rates: Algerian dinars (DA) per
US$1— 36,008 (April 1994), 23..345 (1993),
2 1 .836 ( 1 992), 1 8.473 (1991). 8.958 (1990),
7.6086(1989)
Fiscal year: calendar year
Overview: no economic activity
Communicailons
Ports: none; offshore anchorage only
Airports:
total: I
usahir; I
\\sith pertnanein-surfuce rtoiways; 0
with runways owr .1,659 m; 0
with runways 2.440-3,659 m; 0
runways 1. 220-2.439 m; 0
Telecommunications: important
meteorological station
Defense Forces
Note: defense is the responsibility of France','92ebdc4f7480783c7b2e9ba125a3fa61c9073aedf795d18ec350c51ac44bede8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c25c902f281e77f8f4a1d9c2e4f8b6f70a4c8ca1d5bd68c4ada6545410e917cb',1994,'NZ','New Zealand','economy',27,'Overview; Economic activity is strongly
linked to the US. with which American Samoa
conducts 80-90% of its foreign trade. Tuna
fishing and tuna processing plants are the
backbone of the private sector, with canned
tuna the primary export. The tuna canneries
and the government are by far the two largest
employers. Other economic activities include a
slowly developing tourist industry. Transfers
from the US (iovemment add substantially to
American Samoa''s economic well-being.
National product; GDP — purchasing power
equivalent — $ 1 28 million (1991)
National produet real growth rate: NA%
National produet per capita: $2,600(1991)
Inflation rate (consumer prices): 7% ( 1990)
Unemployment rate; 1 2% ( 1 99 1 )
Budget;
revenues: $97 million (includes $43,000,000
in local revenue and $54,000,000 in grant
revenue);
expenditures; SNA, including capital
7
American Samoa (continued)
expenditures of SNA (FV9I)
Exports: $306 million (f.o.b.. 1989)
commodities: canned tuna 93^
partners: US 99.6^t
Imports: $360.3 million (c.i.f., 1989)
commodities: materials for canneries 56''*''.
food 8%, petroleum products 79f. machinery
and parts 691:
partners: US 629t. Japan 99f. NZ 79f.
Australia I I9f. Fiji 4%. other
External debt: SNA
Industrial production: growth rate NA%
Electricity:
capacity: 42,000 kW
priyduction: 100 million kWh
consumption per capita: 2,020 kWh (1990)
Industries; tuna canneries (largely dependent
on foreign Fishing vessels), meat canning,
handicrafts
Agriculture: bananas, coconuts, vegetables,
taro, breadfruit, yams, copra, pineapples,
papayas, dairy farming
Economic aid:
recipient: $21,042,630 in operational funds
and $l.227,0(Xi in construction funds for
capital improvement projects from the US
Department of Interior ( 1991 )
Currency: I United States dollar = 100 cents
Exchange rates: US currency is used
Fiscal year: 1 October — .30 September
commodities: nickel metal 87%, nickel ore
partners: France 32%, Japan 23.5%, US 3,6%
Imports: $764 million (c,i,f., 1989)
commodities: foods, fuels, minerals, machines,
electrical equipment
partners: France 44,0%, US 10%, Australia
9%
External debt; SNA
Industrial production: growth rate NA%
Electricity:
capacity: 400.000 kW
pt^uction: 2.2 billion kWh
consumption per capita: 1 2,790 kWh ( 1 990)
Industries; nickel mining and smelting
Agriculture: large areas devoted to cattle
grazing; coffee, com, wheat, vegetables; 60%
self-sufficient in beef
IlHcit drugs: illicit cannabis cultivation is
becoming a principal source of income for
some families
Economic aid:
recipient: Western (non-US) countries, ODA
and (X)F bilateral commitments ( 1 970-89),
$4,185 billion
Currency: I CFP franc (CFPF) = 100
centimes
Exchange rates: Cnmptoirs Francais
duPacifique francs (CFPF) per US$1— 107.6.^
(January 1994). 1 02 .96 (1 993). 96. 24 (1 992).
102.57 ( 1991 ), 99.00 ( 1990). 11 5,99 ( 1989);
note— linked at the rate of 1 8. 1 8 to the French
franc
Fiscal year: calendar year
Conununicadons
Highways:
total'' 6..340 km
paved: 634 km
unpaved: 5,706 km ( 1987)
Porta: Noumea, Nepoui. Poro. Thio
Airports:
total: .w
ustiMe: 28
with ftrrmanent-surface runways: 4
with runways over m: 0
with runways 2.440-.t.6S9 m: I
with runways I.220.2.4J9 m: I
Teleconununicallons: 32.578 telephones
( I987>; broadcast stations — 5 AM. 3 FM, 7
TV; I Pacific Ocean INTELSAT earth station
Defense Forces
Branches: Gendarmerie. Police Foree
Note: defense is the responsibility of France
>QQ fcm , *
South
Pacific
Location: Southwestern Oceania, southeast
of Australia in the South Pacific Ocean
Map references: Oceania. Standard Time
Zones of the World
Area:
total area: 268,680 sq kni
land arcii'' 268,670 sq km
comparuiive area: about the size of Colorado
note: includes Antipodes Islands. Auckland
Islands. Bounty Islands, Campbell Island,
Chatham Islands, and Kerma^ Islands
Land houndarics: 0 km
CansIHnc: 1.5,1.34 km
MaritlnK cUms:
continental shelf: 200 nm or the edge of
continental margin
e.whsive economic rone: 200 nm
territorial .sea: 1 2 nm
International disputes: territorial claim in
Antarctica (Ross Dependency)
Climate: temperate with sharp regional
contrasts
Terrain: predominately ,''i...tainous with
Hime large coastal plains
Natural resources: natural gas. iron ore,
sand, coal, timber, hydropower, gold.
limestone
Land use:
arable land: 2%
permanent crops: 0%
meadows and pastures: 53%
forest and woodland: ,38%
other: 7%
Irrigated land: 2.8(N)sq km(l989est.)
Overview: Agriculture employs more than
half of the labor force, contributes 50% to
GDP, and furnishes 90% of exports. The bulk
of export earnings comes from the sale of
coconut oil and copra. The economy depends
on emigrant remittances and foreign aid to
support a level of imports much greater than
export earnings. Tourism has become the most
important growth industry, and construction of
the first international hotel is under way. The
economy continued to falter in 1993, as
remittances and tourist earnings fell off. A
fungal plant disease severely damaged the taro
crop, the primary food and export crop.
National product: GDP— purchasing power
equivalent — $400 million (1992 est.)
National product real growth rate: -4.3%
(1992 est.)
National product per capita: $2,000(1992
est.)
Inflation rate (consumer prices): 7% ( 1993
est.)
Unemployment rate: NA%
Budget:
revenues; $95.3 million
expenditures; $95.4 million, including capital
expenditures of $41 million (1992 est.)
Exports; $5.7 million (f.o.b., 1992 est.)
commodities; coconut oil and cream, taro,
copra, cocoa
partners: New Zealand 34%, American Samoa
21%, Germany 18%, Australia 1 1%
Imports: SI 1.5 million (c.i.f., 1992 est.)
commodities: intermediate goods 58%, food
17%, capital goods 12%
partners: New Zealand 37%, Australia 25%,
Japan 11%, Fiji 9%
External debt: $83 million (December 1990
est.)
Industrial production: growth rate -0.3%
(1992 est.); accounts for 16% of GDP
Electricity:
capacity: 29,000 kW
production: 45 million kWh
consumption per capita: 240 kWh (1990)
Industries: timber, tourism, food processing,
fishing
Agriculture: accounts for about 50% of GDP;
coconuts, fruit (including bananas, taro, yams)
Economic aid;
recipient; US commitments, including Ex-Im
(FY70-89), $18 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $306 million; OPEC
bilateral aid (1979-89), $4 million
Currency: I tala (WS$) s 1(X) sene
Exchange rates: tala (WS$) per US$1—
2.5920 (January 1994), 2.5681 (1993), 2.4655
(1992), 2.3975 (1991), 2.3095 (1990), 2.2686
(1989)
Fiscal year: calendar year
Overview: Real global output — gross world
product (GWP) — rose roughly 2% in 1993,
with results varying widely among regions and
countries. Average growth of 1 % in the GDP of
industrialized countries (57% of GWP in 1993)
and average growth of 6% in the GDP of less
developed countries (37% of GWP) were
partly offset by a further 10% drop in the GDP
of the former USSR/Eastem Europe area (now
only 6% of GWP). Within the industrialized
world the US posted a 3% growth rate whereas
both Japan and the 12-member European
Union (formerly the European Community)
had zero growth. With the notable exception of
Japan at 2.5%, unemployment was typically 6-
1 1% in the industrial world. The US accounted
for 22% of GWP in 1993; Western Europe
accounted for 22.5%; and Japan accounted for
9%. These are the three "economic
superpowers" which are presumably destined
to compete fur mastery in international markets
on into the 2 1 st century. As for the less
developed countries, China. India, and the Four
Dragons-South Korea, Taiwan, Hong Kong,
and Singapore-once again posted good
records; however, many other countries,
especially in Africa, continued to suffer from
drought, rapid population growth, inflation,
and civil strife. Central Europe, especially
Poland. Hungary, and the Czech Republic,
made considerable progress in moving toward
"market-friendly" economies, whereas the 15
ex-Soviet countries typically experienced
further declines in output of 10- 1 5%.
Externally, the nation-state, as a bedrock
economic-political institution, is steadily
losing control over international flows of
people, goods, funds, and technology.
Internally, the central government in a number
of cases is losing control over resources as
separatist regional movements — typically
based on ethnicity — gain momentum, e.g., in
the successor states of the former Soviet
Union, in former Yugoslavia, and in India. In
Western Europe, governments face the
difficult political problem of channeling
resources away from welfare programs in order
to increase investment and suengthen
incentives to seek employment. The addition of
nearly 100 million people each year to an
already overcrowded globe is exacerbating the
World (continued)','3f752bc12f02c192f1b9e47169fa2936e6541b1dcd8b21b069514454c085b7d2','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a91db3d4a0881b61ba960629cbddbd69dd2972a715c1089099842a40aab5ce69',1994,'AO','Angola','economy',34,'Overview: Tourism, the mainstay of
Andorra’s economy, accounts for roughly 80%
of GDP. An estimated 13 million tourists visit
annually, attracted by Andorra''s duty-free
status and by its summer and winter resorts.
The banking sector, with its "tax haven" status,
also contributes substantially to the economy.
Agricultural production is limited by a scarcity
of arable land, and most food has to be
imported. The principal livestock activity is
sheep raising. Manufacturing consists mainly
of cigarettes, cigars, and furniture. Andorra is a
member of the EU Customs Union; it is unclear
what effect the European Single Market will
have on the advantages Andorra obtains from
its duty-free status.
Natlonil product: GDP — purchasing power
equivalent — $760 million ( 1992 est.)
National product real growth rate: NA%
National product per capita: $14,000(1992
est.)
Inflation rate (consumer prices): NA%
Unemployment rate: 0%
Budget:
revenues: $138 million
expenditures: $177 million. Including capital
expenditures of $NA (1993)
Exports: $30 million (f.o.b., 1993 est.)
commodities: electricity, tobacco products,
furniture
partners: France, Spain
Imports: $NA
commodities: consumer goods, food
partners: France, Spain
External debt: $NA
Industrial production: growth rate NA%
Electricity:
capacity: 35,000 kW
production: 140 million kWh
consumption per capita: 2,570 kWh (1992)
Industries: tourism (particularly skiing),
sheep, timber, tobacco, banking
Agriculture: sheep raising; small quantities
of tobacco, rye. wheat, barley, oats, and some
vegetables
Economic aid: none
Currency; I French franc (F) = 1 00 centimes;
I peseta (Pta) := 100 centimes; the French and
.Spanish currencies are used
Exchange rates: French francs (F) per
US$1— 5.9205 (January I‘’94), 5.6632 (1993),
5.2938 (1992). 5.6421 (1991), 5.4453 (1990),
6.3801 (1989); Spanish pesetas (Ptas) per
US$1— 14.3.04 (January 1994), 127.26(1993),
102.38(1992), 103.91 (1991). 101.93(1990),
118.38(1989)
Fiscal year: calendar year
Overview: Subsistence agriculture provides
the main livelihmid for 80-90% of the
population but accounts for less than 15% of
GDP. Oil production is vital to the economy,
contributing about 60% to GDP. Bitter internal
fighting continues to severely affect the
economy, and food must be imported. In 1993,
production fell by an estimated 22.6%, mainly
because of the capture by insurgents of the oil
town of Soyo and diamond-producing areas in
northeastern Angola. Angola has rich natural
resources — notably gold, diamonds, and arable
land, in addition to large oil depoaits — but will
need to end the war and reform government
policies if it is to achieve its potential.
National product: GDP — purchasing power
equivalent — $5.7 billion (1W3 est.)
National product real growth rate; -22.6%
(1993 est.)
National product per capita: $600 ( 1 993
e.st.)
Inflation rate (consumer prices): 1.840%
(1993 est.)
Unemployment rate: 1 5% with considerable
underemployment (1993 est.)
Budget:
revenues: $928 million
expenditures; $2.5 billion, including capital
expenditures of $%3 million ( 1992 est.)
Exports: $3 billion (f.o.b.. 1993 est.)
commodities: oil. diamonds, refined petroleum
products, gas, coffee, sisal, fish and fish
products, timber, cotton
partners: US. France, Germany, Netherlands,
External debt; $ 1 63.6 million ( 1 992)
Industrial production: growth rate I %
(1991); accounts for 7% of GDP
Electricity:
capacity: 5,000 kW
production: lO million kWh
consumption per capita: 80 kWh (1991)
Industries: light construction, shirts, soap,
beer, fisheries, shrimp processing
Agriculture: accounts for 25% of GDP;
dominant sector of economy, primary source of
exports; cash crops — cocoa (85%), coconuts,
palm kernels, coffee; food products — bananas,
papaya, beans, poultry, fish; not self-sufficient
in food grain and meal
Economic aid:
recipient: US commitments, including Ex-lm
(FY70-89). $8 million: Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89). $89 million
Currency; 1 dobra (Db) = 100 cenlimos
Exchange rates: dobras (Db) per US$1 —
129.59(1 July 199.3). 2.30 (1992), 260.0
(November 1991), 122.48 (December 1988),
72.827 (1987), .36.993 ( 1986)
Fiscal year: calendar year','75fba536eef3ee92cdd07e3e57f65596b93fc520ca519de06f4de1d60f7bf6db','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b1595ef6b747c074a2f4bde7f72e9740caab6366a8575bbbbcb643c1f468066',1994,'BR','Brazil','economy',39,'imports: $1.6 billion (f.o.b.. 1992 est.)
commodities: capital equipment (machinery
and electrical equipment), foexJ, vehicles and
spare ports, textiles and clothing, medicines;
substantial military deliveries
ptirtners: Portugal, Brazil, US. France, Spain
External debt; $8 billion (1993 est.)
Industrial production: growth rate NA%;
accounts for about 60% of GDP. including
10
petroleum output
Eicctrktty:
capacity: SI 0.000 kW
ptvductioa: 800 million kWli
consumption per capita: 84 kWh ( 1991 )
Indtntrict! petroleum: mining— diamonds,
iron ore, phosphates, feldspar, bauxite,
uranium, and gold: fish processing; food
processing; brewing; tobacco; sugar; textiles;
cement; basic metal products
Agriculture: cash crops— bananas, sugar
cane, coffee, sisal, corn, cotton, cane, manioc,
tobacco; food crops — cassava, corn,
vegetables, plantains ; livestock production
accounts for 20%, Ttshing 4%, forestry 2% of
toul agriculniral output; disruptions caused by
civil war, and marketing deHciencies require
food imports
Economk aM:
recipient: US commitments, including Ex-lm
(FY70-89), $265 million: Western (non-US)
counuies, ODA and OOF bilateral
commitments (1970-89), SI. 105 billion:
Communist countries (1970-89), $1.3 billion:
net official disbursements ( 1 985-89), $750
million
Curreney: I new kwanza (NKz) « 100 Iwei
Exchange rales: kwanza (Kz) per US$1—
90.000 (Official rale I June 1994), 180.000
(black market rale I June 1994); 7,000 (official
rate 16 December 1993), 50.0Cio (black market
rate 16 December 1993); 3,884 (July 1993);
550 (April 1992); 90 (November 1991 ); 60
(October 1990)
Flacalycar: calendar year
ConunuakalioM
Raiiroadt: 3, 1 89 km total; 2,879 km 1 .067-
metf.'' gauge, 3 10 km 0.600-meter gauge;
limited trackage in use because of landmines
still in place from the civil war; majority of the
Benguela Railroad also closed because of civil
war
Highways:
total: 73.828 km
paved: bituminous-surface 8,577 km
unpaved: crushed stone, gravel, improved
earth 29,350 km; unimproved earth 35.90 1 km
Intand waterways: 1,295 kra navigable
Plpchiies: crude oil 179 km
Ports: Luanda. Lobito, Namibe, Cabinda
Mcrehaat marine: 1 2 ships (1, 000 CRT or
over) totaling 63.77b GRT/99,863 DWT. cargo
1 1, oil tanker 1
Airports:
total: 302
usable: 175
wirh permanent-surface runways: 32
with runways over 3,659 m: 2
with runways 2.440-3,659 m: 18
with runways 1,220-2,439 m: 59
Tdccommunkatlons: limited system of
wire, microwave radio relay, and troposcatter
routes; high-frequency radio used extensively','e27351554f66941565d04e13cff3e0bb117c3f46544ac3741ee0e779cc0fc639','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e303aa45ad7f9f0a915acc23dbc00c7e2c865fc22430e9fd8d7eb82c6a60c302',1994,'AI','Anguilla','economy',40,'(dependent territory of the UK)
for military links; telephone service limited — — -
mostly to government attd business use; 40,300
telephones (4. 1 telephones per 1.000 persons);
broadcast stations— 1 7 AM, 1 3 FM. 6 TV; 2
Atlantic Ocean INTELSAT earth stations
Dcflmsc Forces
Branches: Army. Navy. Air Force/Air
Defense, People''s Defense Organization and
Territorial Troops,
Manpower avalhibiltty: males age 15-49
2,262,669; fit for military service 1.139,319;
reach military age (18) annually 96,900 (1994
est.)
Defmse cxpcndltores: exchange rate
conversion — SNA. NA% of QDP
Curibbeun
See
PrKiif9^9»r C»fs
Strut Isiand
Overview; Anguilla has few natural
resources, and the economy depends heavily
on lobster Hshing. otTshoK banking, tourism,
and remittances from emigrants. In recent
years the economy has benefited from a boom
in tourism and construction. Development
plans center amund the improvement of the
infrastructure, particularly transport and tourist
facilities, and also light industry.
National product: GDP — exchange rate
conversion — $.56.5 million (1992 est.)
National product real growth rate: 7.5%
(1992 est.)
National product per capita: $6,800 (1991
est.)
Inflation rate (consumer prices): 5% (1992
est.)
Unemployment rate: 5% (1988 est.)
Budget;
wwiuc.v.'' SI 5.8 million
exitendiiures: $15.2 million, including capital
expenditures of $2.4 million ( 1992 est.)
Exports: $.556,000 (f.o.b.. 1992)
comnuklities: k)bster and s dt
partners: NA
Imports; $5.5.5 million (f.o.b., 1992)
conmuklities; NA
partners: NA
External debt; SNA
Industrial production: growth rate N.A''''/(
Electricity:
capttcity: 2.(KK) kW
prtkiuctum: 6 million kWh
consumption per capita; 862 kWh ( 1992)
Industries: tourism, boat building, salt
Agriculture; pigeon peas. com. sweet
potatoes, sheep, goals, pigs, cattle, poultry.
fishing (including lobster)
Economic aid:
recipient: Western (non-US) counirie.s, ODA
and OOF bilateral commitments (1970-89).
$58 milwon
Currency: 1 EC dollar (ECS) = 100 cents
Exchange rates: East Caribbean dollars
(ECS) per USSI — 2.70 (fixed rale .since 1976)
Fiscal year: NA','2ad08d1c4702791735f4e10dbbf5377a289a8fc6025410cdb4e8da952e28c9d2','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d117c8a727c0ac5e818ab36af8e3cce406058181b97eb55fd2820a982ea931a',1994,'AG','Antigua and Barbuda','economy',51,'Overview: No economic activity at present
except for fishing off the coast and small-scale
tourism, both based abroad.
Overview: The economy is primarily service
oriented, with tourism the most important
determinant of economic performance. During
the perivKl 1 986-9 1 . real GDP expanded at an
annual average rate of about 6%. Tourism
makes a direct contribution to GDP of abviut
I y‘7r and also affects growth in other sectors —
particularly in construction, communications,
and public utilities. In 1992. reduced
government capital spending and private sector
investment, dampened by recession in the
majirr world economies, slowed economic
growth.
National product: GDP— exchange rate
conversion — $.368.5 million ( 1993 est.)
National product real growth ntc: NA
National product per capita: $5,8IX) (1993
est.)
Inflation rate (consumer prices); 7<T ( 1 993)
Unemployment rate: 55f (1988 est.)
Budget;
re\\-eniir.s: $105 million
e.xiH’nditure.s: $I6I million, including capital
expenditures of $56 million (1992»
Exports: $54.7 niillion (f.o.b.. 1992)
commoelitie.s: petroleum products 4831 ,
manufactures 233^, fixxl and live animals 4%,
machinery and transport equipment 1 7T
patiners: OECS 26*F. Barbados 15%. Guyana
4%, Trinidad and Tobago 2%. US 0.3%
Imports: $260.9 million (f.o.b.. 1992)
commtHlitie.s: fixxJ and live animals,
machinery and transport equipment,
manufactures, chemicals, oil
partners: US 27%, UK 16%, Canada 4%,
OECS .3%. other .50%
External debt: $2.50 million ( 1990 est.)
Industrial praduction: growth rate 3% ( 1 989
est.); accounts for 8% of GDP
Electricity:
capacity: 52.100 kW
prixhu''tion: 95 million kWh
consumption per capita: 1 .482 kWh { 1992)
Industries: tourism, construction, light
manufacturing (clothing, alcohol, household
appliances)
Agriculture: accounts for 4% of GDP;
expanding output of cotton, fruits, vegetables,
and livestock; other crops — bananas, coconuts,
cucumbers, mangoes, sugareane; not self-
sulTicient in ftxxl
Economic aid:
lYcipient: US commitments (1985-88), $10
million; Western (non-US) countries. ODA
and OOF bilateral commitments (1970-89),
$50 million
Currency: 1 EC dollar (ECS) = 1(X) cents
Exchange rates: East Caribbean dollars
(ECS) per US$1 — 2.70 (fixed rate since 1976)
Fiscal year; 1 April — 31 Mareh
Overview: Economic activity is limited to the
exploitation of natural resources, including
pc roleum, natural gas. fish, and seals.','304e8949519664907132c88187cb57c0d33b30a276cd74af9f72820538f895c3','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('138b33389d97a39564c84e4ad37410766ec482b425fe27ac681fb365221c6e18',1994,'AQ','Antarctica','economy',58,'Overview; Argentina is rich in natural
resources and has a highly literate population,
an export-oriented agricultural sector, and a
diversified industrial base. Nevertheless,
following decades of mismanagement and
statist policies, the economy in the late 1980s
was plagued with huge external debts and
recurring bouts of hyperinflation. Elected in
1989, in the depths of recession. President
MENEM has implemented a comprehensive
economic restructuring program that shows
signs of putting Argentina on a path of stable,
sustainable growth. Argentina''s currency has
traded at par with the US dollar since April
1991, and inflation has fallen to its lowest level
in 20 years. Argentines have responded to the
relative price stability by repatriating flight
capital and investing in domestic industry.
Growth slowed somewhat in 1993 but
Argentina still registered an impressive 6%
advance, fueled largely by inflows of foreign
capital and strong domestic consumption
spending. The government''s major short-term
objective is encouraging exports, e.g„ by
reducing domestic costs of production. Much
remains to be done in the 1990s in dismantling
the old statist barriers to growth and in
solidifying the recent economic gains.
National product: GDP — purchasing power
equivalent — $185 billion (1993 est.)
National product real growth rate: 6%
(1993 est.)
National product per capita: $5,500 (1993
est.)
Inflation rate (consumer prices): 7.4%
(1993 est.)
Unemployment rate: 10''^ (1993)
Budget:
revenues: $33.1 billion
expenditures: $35.8 billion, including capital
expenditures of S3 .5 billion (1992)
Exports: $12.7 billion (f.o.b., 1993 est.)
commodities: meat, wheat, corn, oilseed,
hides, wool
partners: US 12%, Brazil, Italy. Japan.
Overview: Chile has a prosperous, essentially
free market economy, with the degree of
government intervention varying according to
the philosophy of the different regimes. Under
the center-left government of President
AYLWIN, which took power in March 1990,
spending on .social welfare has ri.-i,.n steadily.
At the same time business investment, exports
and consumer spending have also grown
substantially. The new president, FREE who
takes office in March 1994, is expected to
emphasize social spending even more. Growth
in 1991-93 has averaged 8% annually, with an
estimated one million Chileans having moved
out of poverty in the last four years. Copper
remains vital to the health of the economy;
Chile is the world''s largest producer and
exporter of copper.
National product: GDP — purchasing power
equivalent — $96 billion (1993 est.)
National product real growth rate: 5.8%
(199.3 est.)
National product per capita: $7,(XX) ( 1993
est.)
Inflation rate (consumer prices): 12.3%
(1993 est.)
Unemployment rate; 5. 1 % ( 1993 est.)
Budget;
revenues: $10.9 billion
expenditures: $10.9 billion, including capital
expenditures of $ 1 .2 billion ( 1 993)
Exports: $10 billion (f.o.b., 1992)
commodities: copper 41%, other metals and_
minerals 8.7%, wood products 7.1%,-fish and
fishmeal 9,8%, fruits 8.4% (1991)
partners: EC 29%. Japan 1''7%, US 16%.
Argentina 5%, Brazil 5% (1992)
Imports: $9.2 billion (fo b., 1992)
commodities: capital goods 25.2%, spare parts
24,8%, raw materials 15,4‘/('', petroleum 10%,
foodstuffs 5.7%
partners; EC 24%. US 2 1 %. Brazil 1 0%, Japan
10% (1992)
External debt: $19.7 billion (1993 est.)
Industrial production: growth rate 9.3%
(1992 est.); accounts for 34% of GDP
Electricity:
capacity: 5,769.000 kW
production: 22.01 billion kWh
consumption per capita: 1 ,630 kWh ( 1992)
Industries: copper, other minerals,
foodstuffs, fish processing, iron and steel,
wood and wood products, transport equipment,
cement, textiles
Agriculture: accounts for about 7% of GDP
(including fishing and forestry); major exporter
of fruit, fish, and timber products; major
crops — wheat, com, grapes, beans, sugar beets,
potatoes, deciduous fruit; livestock products —
beef poultry, wool; self-sufficient in most
foods; 1991 fi.sh catch of 6.6 million metric
tons; net agricultural importer
Illicit drugs; a minor transshipment country
for cocaine destined for the US and Europe
Economic aid:
recipient: US commitments, including Ex-Im
(FY70-89). $52 1 million; Western (non-US)
countries, CDA and OOF bilateral
commitments ( 1 970-89), $ 1 .6 billion;
Communist countries (1970-89), $386 million
Currency: 1 Chilean peso (Ch$) = 100
centavos
Exchange rates: Chilean pesos (Ch$) per
US$1— 4.30.57 (January 1994), 404,35 (1993).
.362.59(1992), .349,.37 (1991), 305.06 (1990),
267.16(1989)
Fiscal year: calendar year
Overview: One of the world’s most
developed economies. France has substantial
agricultural resources and a highly diversified
modem industrial sector. Large tracts of fertile
land, the application of modem technology,
and subsidies have combined to make it the
leading agricultural producer in Western
Europe. Largely self-sufficient in agricultural
products, France is a major exporter of wheat
and dairy products. The industrial .sector
generates about one-quarter of GDP. and the
growing services sector has become crucial to
the economy. Although French GDP
contracted by 0.7% in 1993, the economy
showed signs of life by yearend. GDP growth,
however, will remain sluggish in 1994 —
perhaps reaching only 1.0%. Rapidly
increasing unemployment will still pose a
major problem for the government. Paris
remains committed to maintaining the
franc-deulsche murk purity, which has kept
French interest rales high despite France’s low
inflation. Although the pace of economic
integration within the European Community
has slowed down, integration presumably will
remain a major force shaping the fortunes of
the various economic sectors.
National product; GDP — purchasing power
equivalent — $1.05 trillion (1993)
National product real growth rate: -0.7%
(199.3)
National product per capita; $ 1 8.2(K)
(1993)
Inflation rate (consumer prices): 2. 1 %
(1993)
Unemployment rate: 12.2% (May 1994)
Budget:
revenues: $220.5 billion
expenditures: $249. 1 billion, including capital
expenditures of $47 billion ( 1993 budget)
Exports: $270.5 billion (f.o.b., 1993)
commotlities: machinery and transportation
equipment, chemicals, forrdstuffs, agricultural
1.36
products, iron and steel products, textiles and
clothing
partners: Germany 1 8.6%, Italy 1 1 .0%, Spain
1 1 .0%, Belgium-Luxembourg 9.1%, UK 8.8%,
Netherlands 7.9%, US 6.4%, Japan 2.0%,
former USSR 0.7% (1991 est.)
Imports: $250.2 billion (c.i.f., 1993)
commodities: crude oil, machinery and
equipment, agricultural products, chemicals,
iron and steel products
partners: Germany 17.8%, Italy 10.9%, US
9.5%, Netherlands 8.9%, Spain 8.8%,
Belgium-Luxembourg 8.5%, UK 7,5%, Japan
4.1%, former USSR 1.3% (1991 est.)
External debt: $300 billion (1993 est.)
Industrial production: growth rate -4.3%
(1993)
Electricity:
capacity: 1 10 million kW
production: 426 billion kWh
consumption per capita: 7,430 kWh (1992)
Industries: steel, machinery, chemicals,
automobiles, metallurgy, aircraft, electronics,
mining, textiles, food processing, tourism
Agriculture: accounts for 4% of GDP
(including fishing and forestry); one of the
world’s top five wheat producers; other
principal products — beef, dairy products,
cereals, sugar beets, potatoes, wine grapes;
self-sufficient for most temperate-zone foods;
shortages include fats and oils and tropical
produce, but overall net exporter of farm
products; fish catch of 850,0(X) metric tons
ranks among world''s top 20 countries and is all
used domestically
Economic aid:
donor: ODA and OOF commitments (1970-
89), $75.1 billion
Currency; 1 French franc (F) = 100 centimes
Exchange rates: French francs (F) per
US$ 1—5.9205 (January 1994), 5.6632 (1993),
5.2938 (1992). 5.6421 (1991), 5.4453 (1990).
6.3801 (1989)
Fiscal year; calendar year
inland — Rouen
Merchant marine: 1 24 ships ( 1 ,000 CRT or
over) totaling 3,226,175 GRT/5, 1 09,375
DWT, short-sea passenger 7, cargo 10,
container 21, multifunction large-load carrier
1 , roll-on/ioll-off cargo 21, oil tanker 37,
chemical tanker 8, liquefied gas 6, specialized
tanker 3, passenger I, bulk 9
note: France also maintains a captive register
for French-owned ships in the Kerguelen
Islands (French Southern and Antarctic Lands)
and French Polynesia
Airports:
total: 472
usable: 461
with permanent-surface runways: 258
with runways over 3,659 m: 3
with runways 2.440-3,659 m: 37
with runways 1,220-2,439 m: 136
Telecommunications: highly developed;
extensive cable and microwave radio relay
networks; large-scale introduction of optical-
fiber systems: .satellite systems for domestic
traffic; 39,200,000 telephones; broadcast
stations— 41 AM, 800 (mostly repeaters) FM,
846 (mostly repeaters) TV; 24 submarine
coaxial cables; 2 INTELSAT earth stations
(with total of 5 antennas — 2 for the Indian
Ocean INTELSAT and 3 for the Atlantic
Ocean INTELSAT); HF radio communications
with more than 20 countries; INMARSAT
service; EUTELSATTV service
Defense Forces
Branches; Army. Navy (including Naval
Air), Air Force, National Gendarmerie
Manpower availability: males age 15-49
14,7 1 7,461 ; fit for military service 12,265,874;
reach military age (18) annually 376,485 (1994
est,)
Defense expenditures: exchange rate
conversion — $36.6 billion. 3.1% of GDP
(1993 est.)','e12c31c48bced0e76d386dea1db65f99166b8e22740660032f35a7213eebf45d','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a344ef9bf49719152cd31f3ea292b9c91cd05bf7eb24c35271bb5ee788262959',1994,'NL','Netherlands','economy',59,'Imports: $16 billion (c.i.f., 1993 est.)
commodities: machinery and equipment,
chemicals, metals, fuels and lubricants,
agricultural products
partners: US 22%, Brazil, Germany, Bolivia,
Japan, Italy, Netherlands
External debt: $73 billion (April 1994)
Industrial production: growth rate 10%
(1992 est.); accounts for 31% of GDP
Electricity:
capacity: 17,91 1,000 kW
production: 5 1 .305 billion kWh
consumption per capita: 1.559 kWh (1992)
Industries: food processing, motor vehicles,
consumer durables, textiles, chemicals and
petrochemicals, printing, metallurgy, steel
Agriculture: accounts for 8% of (3DP
(including fishing); produces abundant food
for both domestic consumption and exports;
among world''s top five exporters of grain and
beef; principal crops — wheat, com. sorghum,
soybeans, sugar beets
Illicit drugs: increasing use as a
transshipment country for cocaine headed for
the US and Europe
Economic aid;
recipient: US commitments, including Ex-Im
(FY70-89), $1 billion; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $4.4 billion:
Communist countries (1970-89), $718 million
Currency: I nuevopesoargentino^ 100
centavos
Exchange rates: pesos per US$1 — 0.99850
(January 1 994). 0.99895 ( 1993), 0,99064
( 1992), 0.95355 (1991), 0.48759 ( 1 990),
0.04233(1989)
Fiscal year: calendar year
Overview; This small private enterprise
economy has capitalized on its central
geographic location, highly developed
transport network, and diversified industrial
and commercial base. Industry is concentrat .''d
mainly in the populous Flemish area in the
north, although the govemmen; isencouragimt
reinvestment in the southern region of
Walloon. With few natural resources Belgium
must import substantial quantities of raw
materials and export a large volume of
manufactures, making its economy unusually
dependent on the .slate of world markets. Three
fourths of its trade is with other EC countries.
The economy grew i>t a strong 4% pace during
the period 1988-90. but economic growth
slowed to a I % pace in 1991-92 and dropped
by 1.5% in 1993. Belgium''s public debt has
risen to 140% of GDP. and the government is
trying to control its expenditures to bring the
figure more into line with other industrialized
countries.
National product: GDP — purchasing power
equivalent — $177,5 billion (1993)
National product real growth rate: - 1.5%
(1993)
National product per capita: $ 1 7,700
(1993)
Inflation rate (consumer prices): 2.8%
(1993 est.)
Unemployment rate: 13.5% (March 1994)
Budget:
revenues: $97.8 billion
expenditures: $109.3 billion, including capital
expenditures of $NA (1989)
Exports: $117 billion (f.o.b., 1992) Belgium-
Luxembourg Economic Union
commodities: iron and steel, transportation
equipment, tractors, diamonds, peiroleum
products
partners: EC 75.5%. US 3.7%, former
Communist countries 1 .4% ( 1991 )
Imports: $120 billion (c.i.f.. 1992) Belgium-
Luxembourg Economic Union
commodities; fuels, grains, chemicals,
foodstuffs
partners: EC 73%, US 4,8%, oil-exporting less
developed countries 4%, formei Communist
countries 1.8% (1991)
External debt: $31.3 billion ( 1 992 est.)
Industrial production: growth rate -0. 1 %
( 1993 est.); accounts for 25% of GDP
Electricity:
capacity’: 1 7.500.000 kW
production: 68 billion kWh
consumption per capita: 6.790 kWh (1992)
Industries: engineering and metal products,
motor vehicle assembly, processed food and
beverages, chemicals, basic metals, textiles,
glass, petroleum, coal
Agriculture: accounts for 2.0% of GDP:
emphasis on livestock production — beef, veal,
pork, milk; major crops are sugar beets, fresh
vegetables, fruits, grain, tobacco; net importer
of farm products
Illicit drugs: source of precursor chemicals
for South American cocaine processors;
important gateway country for cocaine
entering the European market
Economic aid;
donor: ODA and (X)F commitments (1970-
89). $5.8 billion
Currency: 1 Belgian franc (BF) = 1(K)
centimes
Exchange rates: Belgian francs (BF) per
US$ 1—36,242 (January 1994), .34.597 ( 1993),
32.150 (1992), 34.148 (1991). 33.418 (1990),
39.404(1989)
Fiscal year: calendar year
External debt: $650 million (end of 1991 )
Industrial production: growth rate -27%
(1993)
Electricity:
capacity; 3.700,000 kW
production; 22.9 billion kWh
consumption per capita; 14,245 kWh (1992)
Industries: accounts for 42% of lator force;
oil shale, shipbuilding, phosphates, electric
motors, excavators, cement, furniture,
clothing, textiles, papt-r. shoes, apparel
Agriculture: employs 20% of work force:
very efficient by Soviet standards; net exports
of meat, fish, dairy products, and potatoes;
imports of feedgrains for live.stock; fruits and
vegetables
Illicit drugs; transshipment point for illicit
drugs from Central and Southwest Asia and
Latin America to Western Europe; limited
illicit opium producer; mostly for domestic
con-sumption
Economic aid:
recipient; US commitment.s, including Ex-Im
(1992), $10 million
Currency; 1 Estonian kroon (EEK) = 100
cents (introduced in August 1992)
Exchange rates; kroons (EEK) per US$1 —
13.9 (January 1994). 13.2 (1993): note —
kroons are tied to the German Deutschmark at
a fixed rate of 8 to 1
Fiscal year; calendar year
Overview: This highly developed and
affluent economy is based on private
enterprise. The government makes its presence
felt, however, through many regulations,
permit requirements, and welfare programs
affecting most aspects of economic activity.
The trade and Financial services sector
contributes over .50% of GDP. Industrial
activity provides about 2.5% of GDP and is led
by the food-prtK-essing. oil-reFining, and
metalworking industries. ''The highly
mechanized agricultural sector employs only
5% of the labor force, but provides large
surpluses for export and the domestic food¬
processing industry. Rising unemployment and
a sizable budget deFicit are currently the most
serious economic problems. Many of the
economic issues of the I99()s will reflect the
course of European economic integration.
National product: GDP — purchasing power
equivalent — $262.8 billion (1993)
National product real growth rate: -0.2%
(1993)
National product per capita: $17,200
(1993)
Inflation rate (consumer prices): 3.5%
(1992 est.)
Unemployment rate: 9.1% (March 1994)
Budget:
revenues: $109.9 billion
expenditures: $122.1 billion, including capital
expenditures of $NA (1992 est.)
Exports: $1.39 billion (f.o.b.. 1992)
commodities: metal products, chemicals.
proce,ssed food and tobacco, agricultural
products
partiiers; EC 77% (Germany 27%.
Belgium-Luxembourg 15%, UK 10%), US 4%
(1991)
Imports: $1.30.3 billion (f.o.b., 1992)
commodities: raw materials and semiFinished
products, consumer goods, transportation
equipment, crude oil, food products
partners: EC 64% (Germany 26%, Belgium-
Luxembourg 14%, UK 8%), US 8% (1991)
Externa) debt: $0
Industrial production: growth rate - 1 .5%
(1993 est.); accounts for 25% of GDP
Electricity:
capacity: 22,21 6.000 kW
production: 63.5 billion kWh
consumption per capita: 4,2(X) kWh ( 1992)
Industries: agroindustries, metal and
engineering products, electrical machinery and
equipment, chemicals, petroleum. Fishing,
construction, microelectronics
Agriculture: accounts for 4.6% of GDP;
animal production predominates: crops —
grains, potatoes, sugar beets, fruits, vegetables:
shortages of grain, fats, and oils
Illicit drugs; gateway for cocaine, heroin, and
hashish entering Europe: European producer of
illicit amphetamines and other synthetic drugs
Economic aid:
donor: ODA and OOF commitments
(1970-89). $19.4 billion
Currency: I Netherlands guilder, gulden, or
florin (f.) = 1 00 cents
Exchange rates: Netherlands guilders,
gulden, or florins (f.) per US$1 — 1.9.508
(Januarv 1994). 1.8.573(1993). 1.7.585(1992)
1 .8697 ''( 1991 ). 1 .8209 ( 1990), 2.1207 ( 1989)
Fiscal year: calendar year
Overview: Tourism, petroleum refining, and
offshore finance are the mainstays of the
economy. The islands enjoy a high per capita
income and a well-developed infrastructure as
compared with other countries in the region.
Unlike many Latin American countries, the
Netherlands Antilles has avoided large
international debt. Almost all consumer and
capital goods are imported, with Venezuela
and the US being the major suppliers.
National product: GDP — exchange rate
conversion — $ 1 .8 billion ( 1993 est.)
National product real growth rate: 291
( 1993 est.)
National product per capita: $9,700 ( 1 993
est.)
Inflation rate (consumer prices): 29f ( 1993
est.)
Uncmpioynient rate: I6.49f ( 1991 est.)
Budget;
revenues; $209 million
e.viH''nditures: $232 million, including capital
expenditures of $8 million ( 1992 est.)
Exports: $240 million tf.o.b.. 1993)
coniinoilities: petroleum products 989(
fuinners: US 399{. Brazil 99f . Colombia 69)
Imports: $1.2 billion tf.o.b.. 1993)
conmuHlities: crude petroleum 649( . Ilxxi.
manufactures
fwrtners: Venezuela 269f. US I89(-. Colombia
69}-. Netherlands bT. Japan 59i
External debt: $701 million (December
1987)
Industrial production; growth rale NA9(
Electricity:
ai/Hi. iiv: l25.(K)OkW
production: 365 million kWh
consumption i>er capita: 1,980 kWh ) 1992)
Industries: tourism (Curacao and Sint
Maarten), petroleum refining (Curacao),
petrtileum transshipment facilities (Curacao
and Bonaire), light manufacturing (Curacao)
Agriculture: hampered by ptxtr soils and
scarcity of w ater; chief pnxiucts— aloes,
sorghum, peanuts, fresh vegetables, tropical
fruit; not self-sufficient in fixxi
Illicit drugs; nmney-laundering center;
iransshipmeni point for South American
cocaine and marijuana bound for the US and
Eurt''-;
Economic aid:
recipient; Western inon-US)c«>umries. ODA
and OOF bilateral commitments (1970-89),
$513 million
Currency: I Netherlands Aniillcan guilder,
gulden, or florin (NAf. ) = 100 cents
Exchange rales: Netherlands Antillean
gui Iders. gulden, iw florins ( NAf. ) per USS I —
1 .79 (fixed rate since 1989; 1 .80 fixed rate
1971-88)
Fiscal year: calendar year','11a0e3bff4e96ddc6f3b337b0fb039d6a7c9ae49f6488fdb22965d0df9669a8d','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38e8f893d1dd8ed4c3a57f84c8173bd120a934d78b782feded867764c641669c',1994,'AM','Armenia','economy',65,'Overview: Under the old central planning
system, Armenia had built up a developed
industrial sector, supplying machine building
equipment, textiles, and other manufactured
goods to sister republics in exchange for raw
materials and energy resources. Armenia is a
large food importer and its mineral deposits
(gold, bauxite) are small. The economic
decline in the past three years (1991-93) has
been particularly severe due to the ongoing
conflict over the Armenian enclave of
Nagorno-Karabakh in Azerbaijan. Azerbaijan
and Turkey have blockaded pipeline and
railroad traffic to Armenia for its support of the
Karabakh Armenians. This has left Armenia
with only sporadic deliveries of natural gas
through unstable Georgia, while other fuel and
raw materials are in critical short supply.
Inflation, roughly 14% per month in the first
nine months of 1993, surged even higher in the
fourth quarter. In late 1993, most industrial
enterprises were either shut down or operating
at drastically reduced levels. Onl; small
quantities of food were available (mostly
humanitarian aid), heat was nonexistent, and
electricity strictly rationed. An economic
recovery cannot be expected until the
Nagorno-Karabakh conflict is settled and until
transportation through Georgia improves.
National product: GDP — purchasing power
equivalent — $7,1 billion (1993 estimate from
the UN International Comparison Program, as
extended to 1991 and published in the World
Bank’s World Development Report 199.3: and
as extrapolated to 1993 using official
Armenian statistics, which are very uncertain
because of major economic changes since
1990)
National product real growth rate: -9.9%
(1993 est.)
National product per capita: $2,040 (1993
est.)
Inflation rate (consumer prices): 14% per
month average (first 9 months, 1993)
Unemployment rate: 6.5% of officially
registered unemployed but large numbers of
underemployed (1993 est.)
''budget:
re, •''imm; $NA
expenditures: SNA. including capital
expenditures of SNA
Exports: S3I million to countries outside the
FSUif.o.b.. 1993)
commodities: machinery and transport
equipment, light industrial products, processed
food items, alcoholic products ( 1991 )
partners: NA
Imports: $87 million from countries outside
the FSU (c.i.f., 1993)
commodities: grain, other foods, fuel, other
energy (1991)
partners: Russia. US. EC
External debt: SNA
Industrial production: growth rate - 1 1 %
(1993 est.)
Electricity:
capacity: 2,875.000 kW
production: 9 billion kWh
consumption per capita: 2,585 kWh (1992)
Industries: traditionally diverse, including
(as a percent of output of former USSR)
metalcutting machine tools (5.5%), forging¬
pressing machines (1.9%), electric motors
(9%), tires ( 1 .5%), knitted wear (4.4%),
hosiery (3.0%), shoes (2.2%), silk fabric
(0.8%), washing machines (2.0%). chemicals,
trucks, watches, instruments, and
microelectronics''! 1990); currently, much of
industry is shut down
Agriculture: accounts for about 45% of GDP;
only 17% of land area is arable; employs 20-
30% of labor force as residents increasingly
turn to subsistence agriculture; fruits
(especially grapes) and vegetable farming,
minor livestock sector; vineyards near Yerevan
are famous for brandy and other liqueurs
Illicit drugs: illicit cultivator of cannabis
mostly for domestic consumption; used as a
transshipment point for illicit drugs to Western
Europe
Economic aid:
recipient: considerable humanitarian aid.
mostly food and energy products, from US and
EC: Russia has granted 60 billion rubles in
technical credits
Currency: 1 dram = 100 luma; introduced
separate currency in November 1993
Exchange rates: NA
Fiscal year: calendar year','be9753f51a6d2f0b713e7df3196e99744f3a381db4146bd54138339f8b26e070','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79b073bfadb4718597562a249e37287aa9fb31b787abcc3203d682e407cc8eeb',1994,'AW','Aruba','economy',72,'Overview: Tourism is the mainstay of the
economy, although offshore banking and oil
refining and storage are also important. Hotel
capacity expanded rap'' *!y between 1985 and
1989 and nearly double . i in 1 990 alone.
Unemployment has steadily declined from
about 20% in 1986 to about 3% in 1991 and to
less than 1% in 1992. The reopening of the
local oil refinery, once a major .source of
employment and foreign exchange earnings,
promises to give the economy an additional
boost.
National product: GDP — exchange rate
conversion — $1.2 billion (1993 est.)
National product real growth rate: 5%
(1993)
National product per capita: $1 7,400 ( 1 993
est.)
Inflation rate (consumer prices): 6.5%
(1993)
Unemployment rate: 0.6% (1992)
Budget:
revenues: $145 million
expenditures: $185 million, including capital
expenditures of $42 million (1988)
Exports: $1.3 billion (including oil re¬
exports) (fo.b., 1993 est.)
commodities: mostly petroleum products
partners: US 64%, EC
Imports: $1.6 billion including oil for
processing and re-export (f.o.b., 1993 est.)
commodities; food, consumer goods,
manufactures, petroleum products
partners: US 8%. EC
External debt: $81 million (1987)
Industrial production: growth rate NA%
Electricity:
capacity: 90.000 kW
production; 375 million kWh
21
Aruba (continued)
consumption per capita: 6,000 kWh (1990
est.)
Industries: tourism, transshipment facilities,
oil reFining
Agriculture: poor quality soils and low
rainfall limit agricultural activity to the
cultivation of aloes, some livestock, and
Fishing
Illicit drugs: drug money laundering center
and transit point for narcotics bound for the US
and Europe
Economic aid:
recipient: Western (non-US) countries ODA
and (X)F bilateral commitments (1980-89),
$220 million
Currency: 1 Aruban florin (Af,) = 100 cents
Exchange rates; Aiuban florins (Af,) per
US$1 — 1.7900 (Fixed rate since 1986)
Fiscal year: calendar year','cc1149985a9d9f5ea2224bae7698adbb31db7b51811780c526c90ab0061b77a9','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ced6611753e1dd8db88ae77bb0816b4fd7165f7dc9b37a6ad0af30631caaf7d4',1994,'AU','Australia','economy',77,'Overview; no economic activity
Overview: The Atlantic Ocean provides some
of the world''s most heavily trafficked sea
routes, between and within the Eastern and
Western Hemispheres. Other economic
activity includes the exploitation of natural
resources, e.g., fishing, the dredging of
aragonite sands (The Bahamas), and
production of crude oil and natural gas
(Caribbean Sea, Gulf of Mexico, and North
Sea).
Overview: Australia has a pr.rsperous
Western-style capitalist economy, with a per
capita GDP comparable to levels in
indu.strialized West European countries. Rich
in natural resources, Australia is a major
exporter of agricultural products, minerals,
metals, and fossil fuels. Primary products
account for more than 60‘''/f’ of the value of total
exports, so that, as in 1983-84, a downturn in
world commodity prices can have a big impact
on the economy. The government is pushing
for increased exports of manufactured goods,
but competition in international markets
continues to be severe. Australia has suffered
from the low growth and high unemployment
characterizing the OECD countries in the early
1990s. In 1992-93 the economy recovered
slowly from the prolonged recession of 1990-
9 1 , a major restraining factor being weak world
demand for Au.stralia''s exports.
Unemployment has hovered around 10(5- and
probably will remain at that level in 1994 as
productivity gains rather than more jobs
account for growth.
National product: GDP — purchasing power
equivalent — $339.7 billion ( 1993)
National product real growth rate: 4Vc
(1993)
National product per capita; $ 1 9, 1 00
(1993)
Inflation rate (consumer prices): I . I ^
(1993)
Unemployment rate; I09f (December 1993)
Budget:
revenues; $7 1 ,9 billion
expenditures; $83.1 billion, including capital
expenditures of $NA (FY93)
Exports: $44.1 billion (1992)
commodities; coal, gold. meat. wool, alumina,
wheat, machinery and transpon equipment
partners; japan 255F. US 1 1 9f-. South Korea
65}-, NZ 5.75('', UK, Taiwan. Singapore. Hong
Kong (1992)
Imports: $43.6 billion (1992)
commodities; machinery and transport
equipment, computers and office machines,
crude oil and petroleum products
partners; US 23''*^, Japan ISCf, UK b''lF,
Germany 5.7<''/f. NZ 45F (1992)
External debt: $141.1 billion (1993)
Industrial production: growth rate 1 .9^
(FY93): accounts for 325}- of GDP
Electricity:
capacity; 40.()(X).0()0 kW
production; 150 billion kWh
consumption per capita; 8.475 kWh (1992)
Industries: mining, industrial and
transportation equipment, food pnKessing.
chemicals, steel
Agriculture: accounts for 5% of GDP and
over 305?'' of export revenues; world''s largest
exporter of beef and wool, second-largest for
mutton, and among top wheat exporters; major
crops— wheat, barley, sugarcane, fruit;
livestock - cattle, sheep, poultry
Illicit drugs; Ta.smania is one of the world''s
major suppliers of licit opiate products;
government maintains strict controls over areas
of opium poppy cultivation and output of
poppy straw concentrate
Economic aid:
donor: ODA and OOF commitments ( 1970-
89), $10.4 billion
Currency: I Australian dollar ($A) = 100
cents
Exchange rates; Australian dollars ($A) per
US$1— 1.4,364(January 1994), 1.4704(1993).
1.3600(1992), 1.2835(1991). 1.2799(1990).
1.2618(1989)
Fiscal year; I July — 30 June
Overview: no economic activity
Overview: no economic activity
Imports: $3.8 million (c.i.f., 1985)
commodities: food, live animals, manufactured
goods, machinery, fuels, lubricants, chemicals,
drugs
partners: NZ 59%, Fiji 20%, Japan 13%,
Western Samoa, Australia, US
External debt: SNA
Industrial production: growth rate NA%
Electricity:
capacity: 1 ,500 kW
production: 3 million kWh
consumption per capita: 1 ,490 kWh ( 1990)
Industries: tourist, handicrafts, coconut
products
Agriculture: coconuts, passion fruit, honey,
limes; subsistence crops — taro, yams, cassava
(tapioca), sweet potatoes; pigs, poultry, beef
cattle
Economic aid:
recipient: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-89),
$62 million
Currency: I New Zealand dollar (NZ$)= l(K)
cents
Exchange rates: New Zealand dollars (NZ$)
per US$1— 1.7771 (January 1994). 1.8495
(1993). 1.8584(1992). 1.7265(1991).
293
Niue (continued)
Overview: The primary economic activity is
tourism, which has brought a level of
prosperity unusual among inhabitants of the
Pacific Islands. The number of visitors has
increased steadily over the years and reached
29,000 in FY89. Revenues from tourism have
given the island a favorable balance of trade
and helped the agricultural sector to become
294
self-sufficient in the production of beef,
poultry, and eggs.
National product: GDP SNA
National product real growth rate: NA%
National product per capita: SNA
InHation rate (consumer prices): NA%
Unemployment rate: NA%
Budget:
revenues: SNA
expenditures: $4.2 million, including capital
expenditures of $400,000 ( 1989 est.)
Exports: $ 1 .7 million (f.o.b., FY86)
commodities: postage stamps, seeds of the
Norfolk Island pine and Kentia palm, small
quantities of avocados
partners: Australia, Pacific Islands, NZ, Asia.
Europe
Imports; $15.6 million (c.i.f., FY86)
commodities: NA
partners: Australia. Pacific Islands, NZ. Asia.
Europe
External debt; SNA
Industrial production: growth rate NA%
Electricity:
capacity: 7,0(X) kW
production: 8 million kWh
consumption per capita: 3. 1 60 kWh ( 1 990)
Industries: tourism
Agriculture: Norfolk Island pine seed. Kentia
palm seed, cereals, vegetables, fniit. cattle,
poultry
Economic aid: none
Currency: I Au.stralian dollar ($A) = 100
cents
Exchange rates; Australian dollars ($A) per
US$1— 1.4.364 (January 1994), 1.4704(1993),
1.3600(1992). 1.28.35(1991). 1.2799(1990),
1.2618(1989)
Fiscal year: I July — .30 June','682dfe2d527c3d48601e648d395630486ed009729a50624bda4a8f0627b58ed7','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c6039c8947cb43f9d4d186cb11bb92bf02982ca724fb138baa343d533e7bc61',1994,'AT','Austria','economy',86,'Overview: Austria boasts a prosperous and
stable stx-''ialist market economy with a .tizable
but falling proportion of nationalized industry
and extensive welfare benefits. Thanks to its
raw material endowment, a technically skilled
labor force, and strong links to German
industrial firms, Austria occupies specialized
niches in European industry and services
(tourism, banking) and produces almost
enough ftxxl to feed itself with only 8Vp of the
labor force in agriculture. Increased export
sales resulting from German unification,
boosted Austria''s economy through 1991, but
Austria''s GDP growth slowed to 2% in 1992
and -0.59f in 1993 due to the weak
international economy, particularly in
Germany — its largest trading partner. GDP
growth will resume slowly in 1994, with
estimates ranging from a 0.59f to a I Cf
increase. Unemployment has risen to 1% as a
result of the slowdown and will continue to rise
in 1994. Pmblems for the 199()s include an
aging population, the high level of subsidies,
and the struggle to keep welfare benefits within
budgetary capabilities. Au.stria''s government
has taken measures to make the economy more
liberal and open by introducing a major tax
reform, privatizing state-owned firms, and
liberalizing cross-border capital movements.
Although it will face increased competition,
Austria should benefit from the continued
opening of eastern European markets, as well
as the I January 1994 start of the European
Economic Area which extends the European
Union rules on the free movement of people,
capital, and goods and services to four
members (including Austria) of the European
Free Trade .Association (EFTA). Austria has
concluded membership negotiations with the
European Union and is expected to join in early
1995, thus broadening European economic
unity. The government, however, plans to hold
a national referendum on the matter on 1 2 June
1994; support for and opprrsition to
membership appears about equal.
National product: GDP — purchasing power
equivalent — $134.4 billion (1993)
National product real growth rate: -0.5%
(199-3)
National product per capita: $ 1 7,(X)0
(199.3)
Inflation rate (consumer prices): .3.7%
( 1993 est.)
Unemployment rate: 7% (1993 est.)
Budget:
revenues; $52.2 billion
expenditures: $60.3 billion, including capital
expenditures of $NA (1993 est.)
Exports: $.39,9 billion (f.o.b., 199.3)
commodities: machinery and equipment, iron
and steel, lumber, textiles, paper products,
chemicals
partners; EC 6.3.5% (Germany 38.9%). EFTA
9.0%. Eastern Europe/FSU 12.3%, Japan
1..5%. US .3..35%( 199.3)
Imports: $48,5 billion (f.o.b,. 1993)
commodities: petroleum, foodstuffs,
machinery and equipment, vehicles, chemicals,
textiles and clothing, pharmaceuticals
partners; EC 66,8% (Germany 4 1.3%), EFTA
6.7%. Eastern Europe/FSU 7.5%. Japan 4.4%,
US 4.4% (1993)
External debt: $16.2 billion (1993 est.)
Industrial production: growth rate -4.5%
(1993 est.)
Electricity:
capacity; 1 7,600.000 kW
production: 49.5 billion kWh
consumption per capita: 6.3{X) kWh ( 1992)
Industries: foods, iron and steel, mi.chines.
textiles, chemicals, electrical, paper and pulp,
tourism, mining, motor vehicles
Agriculture: accounts for 3.2% of GDP
(including forestry); principal crops and
animals — grains, fruit, potatoes, sugar beets,
sawn wood, cattle, pigs, poultry; 80-90% self-
sufficient in food
Illicit drugs: transshipment point for
Southwest Asian heroin transiting the Balkan
route and Eastern Europe
Economic aid:
donor: ODA and OOF commitments ( 1970-
89), $2.4 billion
Currency: 1 Austrian schilling (S) = 100
groschen
Exchange rates: Austrian schillings (S) per
US$1— 1 2.2.55 (January 1994). 1 1.6.32(199.3),
10.989(1992). 11.676(1991). 1 1.. 370 (1990),
1.3.2.31 (1989)
Fiscal year: calendar year
Imports: $2.2 billion from outside of the FSU
countries (1993)
commodities: machinery and parts,
transportation equipment, chemicals, textiles
partners: FSU countries, Germany, China,
External debt: SNA
Industrial production: growth rate -14%
(1993); accounts for 50% of GDP
Electricity:
capnc/ry.- 55,882.000 kW
prt)duclion: 28 1 billion kWh
consumption per capita: 5,410 kWh ( 1992)
Industries: coal, electric power, ferrous and
nonferrous metals, machinery and transport
equipment, chemicals, food-processing
(especially sugar)
Agriculture: accounts for about 25% of GDP;
grain, vegetables, meal, milk, sugar beets
Illicit drugs; illicit cultivator of cannabis and
opium poppy; mostly for CIS consumption:
limited guventment eradication program: used
as transshipment points for illicit drugs to
Western Europe
Economic aid: $350 million economic aid
and $350 million to help disassemble the
atomic weapons from the US in 1994
Currency; Ukraine withdrew the Russian
ruble from circulation on 12 November 1992
and declared the karbovanets (plural
karbovantsi) sole legal lender in Ukrainian
markets: Ukrainian officials claim this is an
interim move toward introducing a new
currency — the hryvnya — possibly in mid- 1 994
Exchange rates: NA
Fiscal year: calendar year','0a4a59f3cfa5e1cbbf72a9ee56a38821c48397bb1aa791ecf1a7f93e14ae8c86','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('624917cf368b5fa8568bf8961d46f4a7dd5496bb9abb69169d61168fd9c9fceb',1994,'AZ','Azerbaijan','economy',92,'Overview: Azerbaijan is less developed
industrially than either Armenia or Georgia,
the other Transcaucasian states. It resembles
the Central Asian states in its majority Muslim
population, high structural unemployment, and
low standard of living. The economy''s most
prominent products arc oil, cotton, and gas.
Production from the Caspian oil and gas field
has been in decline for several years. With
foreign assistance, the oil industry might
generate the funds needed to spur industrial
development. However, civil unrest, marked
by anned conflict in the Nagomo-Kumhukh
region between Muslim Azeris and Christian
Amicnians, makes foreign investors wary.
Azerbaijan accounted for l.5''’F to 25f of the
capital stock and output of the former Soviet
Union, Azerbaijan shares all the formidable
problems of the ex-Soviet republics in making
the transition from a command to a market
economy, but its considerable energy resources
brighten its prospects ;iomewhui. Old
economic ties and structures have yet to be
replaced. A particularly galling constraint on
economic icvival is the Nagorno-Karabakh
conflict, said to consume ’.S''ib of Azerbaijan''s
economic resources.
National product: GDP — purchasing power
equivalent — $15.5 billion ( !99,3 estimate from
the UN International Comparison Program, as
extended to 1991 and published in the World
Bunk''s World Development Report 199.3; and
as extrapolated to 1993 using official
Azerbaijani statistics, which arc very uncertain
because of major economic changes since
1990)
National product real growth rate: - 1 3.39f
(1993e,s(.)
National product per capita: $2,040 ( 199.3
est.)
Inflation rate (consunwr pricta): 205f per
month (average 1993); above SO^t per month
(February 1994)
Uncmpioyincnt rate: 0.79f includes
officially registered unemployed; also large
numbers of underemploy^ workers
(December 1993)
Budget:
revenues: $NA
expenditures: SNA, including capital
expenditures of SNA
Exports: $355 million to outside the FSU
countries (fo.h.. 1993)
commtHlities: oil and gas. chemicals, oilfield
equipment, textiles, cotton ( 1991 )
fMirtners: mostly CIS and European countries
Imports: $240 million from outside the FSU
countries (c.i.f., 1993)
commodities: machinery and parts, consumer
durables, fcaxlsiuffs, textiles ( 1991)
[tartners: European countries
External debt: SNA
Industrial production; growth mte -7''''/f
(1993)
Electricity:
caiHicin; 6.025.(K)0 kW
productitm: 22..300kWh
consumption per capita: 2,990 kWh ( 1 992)
Industries: petroleum and natural gns.
pctruleum products, oilfield equipment; steel.
iron ore, cement; chemicals and
petrochemicals; textiles
Agriculture: cotton, grain, rice, grapes, fruit.
vegetables, tea, tobacco; cattle, pigs, sheep and
gouts
Illicit drugs; illicit cultivator of cannabis and
opium poppy; mostly for CIS consumption;
limited government eradication program;
transshipment point for illicit drugs to Western
Europe
Economic aid;
recipient: wheat from Turkey
Currency; 1 manat = UK) gopik
Exchange rates; NA
Fiscal year: calendar year
Overview: The Bahamas is a stable,
developing nation whose economy is based
primarily on tourism and offshore banking.
Tourism alone provides about 40% of GDP and
directly or indirectly employs about 50,000
people or 40% of the local work force. The
economy has slackened in recent years, as the
annual increase in the number of tourists
slowed. Nonetheless, per capita GDP is one of
the highest in the region.
National product: GDP — purchasing power
30','c42aa82a195eb803354b17b7fb42fe5485633932f079f56c705e34bafcb43b97','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9e872213388dac465cb64641fbb5bf7eae47588b7380e18ba6c036c2611a62d',1994,'BH','Bahrain','economy',93,'equivalent — $4.4 billion (1993 est.)
National product real growth rate: 2%
(1991)
National product per capita: $ 1 6,500 ( 1 993
est.)
Inflation rate (consumer prices): 6.3%
(1991)
Unemployment rate: 5.7% ( 1 992 est.)
Budget:
revenues: $628.5 million
expenditures: $574 million, including capital
expenditures of $100 million (1992 est.)
Exports: S3 10 million (f.o.b., 1992)
commodities: pharmaceuticals, cement, rum,
crawfish
partners: US 51%. UK 7%, Norway 7%,
France 6%, Italy 5%
Imports: $1.2 billion (f.o.b„1992)
commodities: foodstuffs, manufactured goods,
mineral fuels, crude oil
partners: US 32%, lapan 17%, Nigeria 12%,
Denmark 7%, Norway 6%
External debt: $ 1 .2 billion (December 1990)
Industrial production: growth rate 3%
(1990); accounts for 15% of GDP
Electricity:
capacity: 424,000 kW
production: 929 million kWh
consumption per capita: 3,599 kWh (1992)
Industries: tourism, banking, cement, oil
refining and transshipment, salt production,
rum, aragonite, pharmaceu''icals, spiral welded
steel pipe
A:^culture: accounts for 5% of GDP;
dominated by small-scale producers; principal
products — citrus fruit, vegetables, poultry;
large net importer of food
Illicit drugs: transshipment point for cocaine
and marijuana bound for US and Europe; also
money-laundering center
Economic aid:
recipient: US commitments, including Ex-Im
(FY85-89), $1 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $345 million
Currency: 1 Bahamian dollar (B$) = 100
cents
Exchange rates: Bahamian dollar (B$) per
US$1 -1.00 (fixed rate)
Fiscal year: calendar year
Overview: Petroleum production and
processing account for about 80% of export
receipts, 60% of government revenues, and
30% of GDP. Economic conditions have
fluctuated with the changing fortunes of oil
since 1 985. for example, during and following
the Gulf crisis of 1990-91. Bahrain with its
highly developed communication and transport
facilities is home In numerous multinational
firms with business in the Gulf. A large share
of exports consi.sts of petroleum products made
from imported crude. Prospects for 1994 are
good, with private enterprise the main driving
force, e.g., in banking and construction.
National product: GDP — purchasing power
equivalent — $6.8 billion (1993 est.)
National product real growth rate: 4%
(1993 est.)
National product per capita; $I2,0(X)(I993
est. I
Inf ation rate (consumer prices): 2% (1993
est.)
Unemployment rate: 8%- 10% (1989)
Budget:
revenues: $1.2 billion
expenditures: $1.6 billion, including capital
expenditures of $NA (1992)
Exports: $3.5 billion (f.o.b., 1993 est.)
commodities: petroleum and petroleum
products 80%, aluminum 7%
partners: Japan 13%. UAE 12%, India 10%.
Pakistan 8%, Singapore 6% (1991)
Imports: $3.7 billion (f.o.b.. 1993 est.)
commodities: nonoil 59%, crude oil 41%
partners: Saudi Arabia 42%. US 14%. UK 7%,
Japan 5%. Germany 4% (1991)
External debt: $2.6 billion ( 1 993)
Industrial production: growth rate 3.8%
(1988); accounts for 44% of GDP
Electricity:
capacity: 1 ,6(X).000 kW
production: 4.7 billion kWh
consumption per capita: 8,500 kWh (1992)
Industries: petroleum processing and
refining, aluminum smelting, offshore
banking, ship repairing
Agriculture; including fishing, accounts for
less than 2% of GDP: not self-sufficient in food
production; heavily subsidized sector produces
fruit, vegetables, poultry, dairy products,
shrimp, fish
Economic aid:
recipient: US commitments, including Ex-Im
(FY70-79). $24 million; Western (non-US)
countries. ODA and OOF bilateral
commitments (1970-89), $45 million; OPEC
bilateral aid (1979-89). $9.8 billion
Currency: 1 Bahraini dinar (BD)= 1.000 fils
Exchange rates: Bahraini dinars (BD) per
USSl — 0.3760 (fixed rate)
Fiscal year: calendar year
Overview; no economic activity','2ef7b73b41c01ec39532d13f423d66c4f58dc1ee07ec0ceadb3a2ef50e455d08','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a9760573292e084124e1c671fb37ddad450dae788f311a65a6a0e648241ec87d',1994,'BD','Bangladesh','economy',103,'Overview: Bangladesh is one of the world''s
poorest, most densely populated, and least
developed nations. Its economy is
overwhelmingly agricultural, with the
cultivation of rice the single most important
activity in the economy. Major impediments to
growth include frequent cyclones and floods,
government interference with the economy, a
rapidly growing labor force that cannot be
absorbed by agricultu.’''e, a low level of
industrialization, failure to fully exploit energy
resources (natural gas), and inefficient and
inadequate power supplies. Excellent rice
crops and expansion of the export garment
industry helped growth in FY92 and FY93.
Policy reforms intended to reduce government
regulation of private industry and promote
public-sector efficiency have been announced
but are being implemented only slowly.
National product: GDP — purchasing power
equivalent — $122 billion (1993 est.)
National product real growth rate: 4.3%
(FY93)
National product per capita: $1,000(1993
est.)
Inflation rate (consumer prices): 1 .4%
(FY93)
Unemployment rate: NA%
Budget:
revenues: $2.5 billion
expenditures: $3.7 billion, including capital
expenditures of $NA (FY92)
Exports: $2.1 billion (FY93)
commodities: garments, jute and jute goods,
leather, shrimp
partners: US 33%, Western Europe 39%
(Germany 8.4%, Italy 6%) (FY92 est.)
Imports: $3.5 billion (FY93)
commodities: capital goods, petroleum, food,
textiles
partners: Hong Kong 7.5%, Singapore 7.4%,
China 7.4%, Japan 7.1% (FY92 est.)
External debt: $13.5 billion (June 1993)
Industrial production: growth rate 6.9%
(FY93 est.); accounts for 9.4% of GDP
Electricity:
capacity: 2,400,000 kW
production: 9 billion kWh
consumption per capita: 75 kWh ( 1 992)
Industries: jute manufacturing, cotton
textiles, food processing, steel, fertilizer
Agriculture: accounts for 33% of GDP, 65%
of employment, and one-fifth of exports;
world’s largest exporter of jute; commercial
products — jute, rice, wheat, tea, sugarcane,
potatoes, beef, milk, poultry; shortages include
wheat, vegetable oils, cotton
Illicit drugs: transit country for illegal drugs
produced in neighboring countries
Economic aid:
recipient: US commitments, including Ex-Im
(FY70-89), $3.4 billion; Western (non-US)
countries, ODA and OOF bilateral
commitments (1980-89), $11.65 million;
OPEC bilateral aid (1979-89), $6.52 million:
Communist countries (1970-89), $1.5 billion
Currency: I taka (Tk) = 100 poiska
Exchange rates; taka (Tk) per US$1 —
40.064 (January 1994), 39.567 (1993), 38.951
(1992), 36.596 (1991), 34.569 (1990), 32.270
(1989)
Fiscal year: 1 July — 30 June','8f2e53dba4d470a80ee5200003959202a02b78788a84952537afa2d93ec89ffd','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2d48fd9c669f744995903198cb2b3a7d55bf824b6c69f4432a280e0bd2f24d0',1994,'BB','Barbados','economy',109,'Overview: A per capita income of $8,700
gives Barbados one of the highest standants of
living of all the small island states of the
36
eastern Caribbean. Historically, the economy
was based on the cultivation of sugarcane and
related activities. In recent years, however, the
economy has diversified into manufacturing
and tourism. The tourist industry is now a
major employer of the labor force and a
primary source of foreign exchange. The
economy slowed in 1990-92 as Bridgetown’s
difficulty in financing its deficits caused it to
exert control over domestic demands
National product: GDP — purchasing power
equivalent — $2.2 billion (1^3 est.)
National product real growth rate: -3%
(1992)
National product per capita: $8,700 (1993
est.)
Inflation rate (consumer prices): 6.1%
(1992)
Unemployment rate: 23% (1992)
Budget:
revenues: $547 million
expenditures: $620 million, including capital
expenditures of $60 million (FY92-93)
Exports: $158 million (f.o.b., 1992)
commodities: sugar and molasses, rum, other
foods and beverages, chemicals, electrical
components, clothing
partners: US 13%, UK 13%, Trinidad and
Tobago 9%, Windward Islands 7.8%
Imports: $465 million (f.o.b., 1992)
commodities: machinery, foodstuffs,
construction materials, chemicals, fuel,
electrical components
partners: US 33%, UK 1 1%. Trinidad and
Tobago 1 1 %, Japan 5%
External debt; $652 million (1991 est.)
Industrial production: growth rate -1.3%
(1991); accounts for 10% of GDP
Electricity:
capacity: 152,100 kW
production: 540 million kWh
consumption per capita: 2, 1 1 8 kWh ( 1 992)
Industries: touris~ ugar. light
manufacturing, co. n .ment assembly for
export, petroleum
Agriculture: accounts for 6% of GDP; major
cash crop is sugarcane: other crops —
vegetables, cotton; not self-sufficient in food
Economic aid;
recipient: US commitments, including Ex-Im
(FY70-89), $15 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $171 million
Currency: I Barbadian dollar (Bds$) = 100
cents
Exchange rates; " > idiano'' . ''Bds$)
per US$1— 7.. '' i,.iAed r*-, - .
Fiscal year: 1 April — 31 March
Ports; Bridgetown
Merchant marine: 2 oil tankers (1,000 CRT
or over) totaling 44,466 ORT/76,2 19 DWT
Airports:
total: 1
usable: 1
with permanent-surface runways: 1
with runways over 3.659 m: 0
with runways 2,440-3,659 m: 1
with runways 1,220-2,439 m: 0
Telecommunications: islandwide automatic
telephone system with 89,000 telephones;
tropospheric scatter link to Trinidad and Saint
Lucia; broadcast stations — 3 AM, 2 FM. 2 ( 1 is
pay) TV; 1 Atlantic Ocean INTELSAT earth
station
Defense Forces
Branches: Royal Barbados Defense Force,
including the Ground Forces and Coast Guard,
Royal Barbados Police Force
Manpower availability: males age 15-49
70,75 1 ; fit for military service 49,330
Defense expenditures: exchange rate
conversion — $ 1 0 million, 0.7% of GDP ( 1 989)
Bassas da India
(possession of France)
3 km','650add317778e073840eace12d25bbe75706156cb8929aba6fb95fdb4de0703a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31113f39cac5e97b17c1708d4711182b3c6ffab2bfae26c52266d64c7fb2cf65',1994,'BY','Belarus','economy',115,'Overview: no economic activity
Overview: Belarus ranks among the most
developed of the former Soviet states, with a
relatively modem — by Soviet standards — and
diverse machine building sector and a robust
agriculture sector. It also serves as a transport
link for Russian oil exports to the Baltic states
and Eastern and Western Europe. The breakup
of the Soviet Union and its command economy
has resulted in a sharp economic contraction us
traditional trade ties have collapsed. At the
same time, the Belamsian Government has
lagged behind most other former Soviet states
in economic reform: privatization has barely
begun; the agriculture sector remains highly
subsidized; the state retains control over many
prices; and the system of state orders and
distribution persists. Meanwhile, the national
bank continues to pour credits into inefficient
enterprises, fueling inflation and weakening
incentives to improve performance. The
government is pinning its hopes on
reintegration with the Russian economy, but
such a path would only partially restore
traditional trade ties. Until economic reform is
embraced, Belarus will continue in its
economic morass.
National product: GDP — purchasing power
equivalent — $61 billion (1993 estimate from
the UN International Compari.son Program, as
extended to 1991 and published in the World
Bank''s World Development Report 1993; and
as extrapolated to 1993 using official
Belarusian statistics, which are very uncertain
because of major economic changes since
1990)
National product real growth rate: -9%
(1993 est.)
National product per capita: $5,890 (1993
est.)
Inflation rate (consumer prices): 30% per
month (1993)
Unemployment rate: 1 .4% officially
registered unemployed (December 1993);
large numbers of underemployed workers
Budget;
revenues: SNA
expenditures: SNA, including capital
expenditures of SNA
Exports; $710 million to outside of the FSU
countries (f.o.b.. 1993)
commodities: machinery and transport
equipment, chemicals, foodstuffs
partners: Russia, Ukraine, Poland. Bulgaria
Imparts; $743 million from outside the FSU
countries (c.i.f., 1993)
commodities: fuel, indu.-:trial raw materials,
textiles, sugar
partners: Russia, Ukraine. Poland
External debt: SNA
Industrial production: growth rate - 1 1.0%
( 1 993); accounts for about 40% of GDP (1992)
Electricity;
capticity: 8,025,000 kW
production: 37.6 billion kWh
consumption per capita: 3,626 kWh ( 1 992)
Industries: employ about 40% of labor force
and produce a wide variety of products
including (in percent share of total output of
former Soviet Union): tractors (12%); metal-
cutting machine tools (1 1%); off-highway
dump trucks up to 1 10-metric-ton load
capacity (100%); wheel-type earthmovers for
construction and mining (100%); eight-wheel-
drive, high-flotation trucks with cargo capacity
of 25 metric tons for use in tundra and roadless
areas ( 1 00%); equipment for animal husbandry
and livestock feeding (25%); motorcycles
(2 1 .3%); television sets (11%); chemical fibers
(28%); fertilizer (18%); linen fabric (1 1%);
wool fabric (7%); radios; refrigerators; and
other consumer goods
Agriculture: accounts for almost 25% of
GDP and 5.7% of total agricultural output of
former Soviet Union; employs 2 1 % of the
labor force; in 1 988 produced the following (in
percent of total Soviet production): grain
(3.6%), potatoes (12.2%), vegetables (3.0%),
meat (6.0%), milk (7.0%); net exporter of
meat, milk, eggs, flour, potatoes
Illicit drugs: illicit cultivator of opium poppy
and cannabis; mostly for the domestic market;
transshipment point for illicit drugs to Western
Europe
Economic aid: SNA
Currency: Belarusian rubel
note: the government signed a framework
agree:nent with Russia for a monetary union in
January 1994, but a schedule and mechanism
for merging the two monetary systems and
replacing Belarusian rubels with Russian
rubles have not been worked out
Exchange rates: NA
Fiscal year: calendar year','018ce5f68a2ec56fa1f8ca75c767b58c2f30f0a5a91fc33304eb9c42e75c3a94','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba9f9f512f7f6bed9ec3bc83ab65cc513bbc2ab1488518a35e31189ff6620ca2',1994,'BZ','Belize','economy',126,'Overview: The economy is based primarily
on agriculture, agro-based industry, and
merchandising, with tourism and construction
assuming increasing importance. Agriculture
accounts for about .30% of GDP and provides
75% of export earnings, while sugar, the chief
crop, accounts for almost 40% of hard currency
earnings. The US, Belize''s main trading
partner, is assisting in efforts to reduce
dependency on sugar with an agricultural
diversification program.
National product: GDP — purchasing power
equivalent — $550 million ( 199,3 est.)
National product real growth rate: 5.3%
tl992)
National product per capita: $2,700(1993
est.)
Inflation rate (consumer prices); 5.5%
(1991)
Unemployment rate: 15% (1992 est.)
Budget:
rei’enue.c $126.8 million
expenditures: $123.1 million, including capital
expenditures of $44.8 million (FY91 est.)
Exports: $1 16 million (f.o.h.. 1992)
ctmmodities: sugar, citrus, clothing, fish
products, bananas. molas.ses, wood
partners: US 5 1 %, UK. other EC ( 1992)
Imports; $273 million (c.i.f., 1992 est.)
commtidities: machinery and tmnsportation
equipment, food, manufactured goods, fuels,
chemicals, pharmaceuticals
partners: US 57%, UK 8%, other EC 7%,
Mexico (1992)
External debt: $143.7 million (1991)
Industrial production: growth rate .3.7%
( 1990); accounts for 12% of GDP
Electricity;
cuixicity: 34,532 kW
production: 90 million kWh
consumption per capita: 393 kWh (1992)
Industries: garment production, citrus
concentrates, sugar refining, rum. beverages,
tourism
Agriculture: accounts for 20% of GDP
(including fish and forestry); commercial crops
include sugarcane, bananas, coca, citrus fruits;
expanding output of lumber and cultured
shrimp; net importer of basic foods
Illicit drugs: transshipment point for cocaine;
an illicit producer of cannabis for the
international drug trade; eradication program
cut marijuana production from 200 metric tons
in 1987 to about 50 metric tons in 1991
Economic aid:
recipient: US commitments, including Ex-lm
(FY70-89). $104 million; We.slem (non-US)
countries, ODA and OOF bilateral
commitments ( 1970-89), $215 million
Currency: I Belizean dollar (Bz$) a lOO
cents
Exchange rates: Belizciin dollars (Bz$) per
USSI— 2.00 (lixcd rate)
Fiscal year: 1 April— 31 March','108f6ea8a6c6ffcea6a6df92cfd26eac5139bda5628a5f7a417811e1bedf8652','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0b4ca559814785efbb84c6acf5cfdc2767d7ff3c336e1370351b46eb02bb288',1994,'BJ','Benin','economy',134,'Overview: Benin is one of the least developed
countries in the world because of limited
natural resources and a poorly developed
infrastructure. Agriculture accounts for about
35% of GDP. employs about 60% of the labor
force, and generates a major share of foreign
exchange earnings. The industrial .sector
contributes only about 10% to GDP and
employs 2% of the work force. Low prices in
recent years have kept down hard currency
earnings from Benin’s major exports of
agricultural products, primarily cotton. A
World Bank supported structural adjustment
program begun in 1989 has helped strengthen
the economy through such measures as
trimming the government payroll, reforming
the tax system, and encouraging private
investment, both domestic and foreign. Benin
has experienced 3 consecutive years of
moderate growth as a result.
National product: GDP — purchasing power
equivalent — $6.2 billion (1993 est.)
National product real growth rate: 3%
(1991)
National product per capita: $ 1 ,2(X) ( 1 993
est.)
Inflation rate (consumer prices): 3.4%
(1990)
Unemployment rate: NA%
Budget:
revenues: $218 million
expenditures: $.355 million, including capital
expenditures of $100 million (1991 est.)
Exports: $328.8 million (fo.b., 1991 est.)
commodities: crude oil. cotton, palm products.
cocoa
partners: FRG .36%, France 16%, Spain 14%.
Italy 8%. UK 4%
Imports: $482.3 million (fo.b,. 1991 est.)
commodities: foodstuffs, beverages, tobacco,
petroleum products, intermediate goods,
capital goods, light consumer goods
partners: France 20%. Thailand 8%.
Netherlands 7%. US 5%
External debt; $1 billion (December 1990
est.)
Industrial production: growth rate -0.7%
(1988); accounts for 10% of GDP
Electricity:
capacity: 30,000 kW
production: 25 million kWh
consumption per capita: 5 kWh (1991)
Industries: textiles, cigarettes, construction
materials, beverages, food production,
petroleum
Agriculture: accounts for 35% of GDP; small
farms produce 90% of agricultural output;
production is dominated by food crops — com,
sorghum, cassava, beans, rice; cash crops
include cotton, palm oil, peanuts; |x>ultry and
livestock output has not kept up with
consumption
Economic aid:
recipient: US commitments, including Ex-lm
(.FY70-89), $46 million; Western (non-US)
countries, ODA and (X)F bilateral
commitments (1970-89), $1.3 billion; OPEC
bilateral aid (1979-89), $19 million;
Communist countries (1970-89). $101 million
Currency: 1 CFA franc (CFAF) = 100
centimes
Exchange rates: Communaute Financiere
Africaine francs (CFAF) per US$1 — 592.05
(January 1 994). 283. 1 6 ( 1 993). 264.69 ( 1 992),
282.11 (1991), 272.26 (1990), 3 19.01 (1989)
note: beginning 12 January 1994 the CFA
franc was devalued to CFAF 100 per French
franc from CFAF 50 at which it had been fixed
since 1948
Fiscal year: calendar year','aa8bcd07edbb1d5202147a953b42e5c38c806cdfd2f23bfde4a053f2a0326def','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b06b75f167e640948b8aae819dbbe602538d09cd4a2ceaf8ef5759cdbd6399cd',1994,'BM','Bermuda','economy',139,'Overview: Bermuda enjoys one of the highest
per capita incomes in the world, having
successfully exploited its location by providing
luxury tourist facilities and financial services.
The tourist industry attracts more than 90% of
its business from North America. The
industrial sector is small, and agriculture is
severely limited by a lack of suitable land.
About 80% of food needs are imported.
National product: GDP — exchange rate
conversion $1.63 billion (1992)
National product real growth rate: - 1 .5%
(1991)
National product per capita: $27, 100
(1992)
Inflation rate (consumer prices): 4.4%
(1991)
Unemployment rate: 6% ( 1991 )
Budget:
revenues: $327.5 million
expenditures: $308.9 million, including capital
expenditures of $35.4 million (FY91 est.)
Exports: $60 million (f.o.b., 1991)
commodities: semitropical produce, light
manufactures, re-exports of pharmaceuticals
partners: US 55%, UK 32%. Canada 1 1%.
other 2%
Imports: $468 million (f.o.b., 1991)
commodities: fuel, foodstuffs, machinery
partners: US 60%>. UK 8%, Venezuela 7%.
Canada 5%. Japan 5%, other 15%
46','f644e606d2bf39dfea89346ebd89640799501ebcfbe90269dfa9993b14626b20','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49a2ffe8a42581b27b52928ac42f338677311d833ead0c1476c0972064080048',1994,'BT','Bhutan','economy',140,'External debt: SNA
Industrial production: growth rate NA%
Electricity:
capacity; 1 54,000 kW
production: 504 million kWh
consumption per capita: 8,370 kWh (1992)
Industries: tourism, finance, structural
concrete products, paints, pharmaceuticals,
ship repairing
Agriculture: accounts for less than I % of
GDP; most basic foods must be imported:
produces bananas, vegetables, citrus fruits,
flowers, dairy products
Economic aid:
recipient: US commitments, including Ex-lm
(FY70-8I), $34 million; Western (non-US)
countries, ODA and (X)F bilateral
commitments (1970-89), $277 million
Currency: I Bermudian dollar (Bd$) = 100
cents
Exchange rates: Bermudian dollar (Bd$) per
US$1— 1.0000 (fixed rate)
Fiscal year: 1 April — 31 March
Overview: The economy, one of the world''s
least developed, is based on agriculture and
forestry, which provide the main livelihood for
909''r of the population and account for about
50% of GDP. Rugged mountains dominate the
terrain and make the building of roads and
other infrastructure difficult and expensive.
The economy is closely aligned with that of
India through strong trade and monetary links.
The industrial sector is small and
technologically backward, with most
production of the cottage industry type. Most
development projects, such as road
construction, rely on Indian migrant labor.
Bhutan''s hydropower potential and its
attraction for tourists are its most important
natural resources; however, the government
limits the number of tourists to 4,000 per year
to minimize foreign influence. Much of the
impetus for growth has come from large
public-sector companies. Nevertheless, in
recent years, Bhutan has shifted toward
decentialized development planning and
greater private initiative. The government
privatized several large public-.sector firms, is
revamping its trade regime and liberalizing
administerial procedures over industrial
licensing. The government''s industrial
contribution to GDP decreased from 13% in
1988 to about 10% in 1992.
National product: GDP — purchasing power
equivalent — $500 million (1993 est.)
National product real growth rate: 5%
(FY93 est.)
National product per capita: $700 (1993
est.)
Inflation rate (consumer prices): 1 1 %
(October 1993)
Unemployment rate: NA%
Budget:
revenues: $100 million
expenditures: $112 million, including capital
expenditures of $60 million (FY92 est.)
note: the government of India finances nearly
one-quarter of Bhutan''s budget expenditures
Exports: $66 million (f.o.b., FY93 est.)
commodities: cardamon, gypsum, timber,
handicrafts, cement, fruit, electricity (to India),
precious stones, spices
partners: India 82%, Bangladesh, Singapore
Imports: $125 million (c.i.f., FY93 est.)
commodities: fuel and lubricants, grain,
machinery and parts, vehicles, fabrics
partners: India 60%, Japan, Germany, US, UK
External debt: $141 million (June 1993)
Industrial production: growth rate NA%;
accounts for 8% of GDP: primarily cottage
industry and home based handicrafts
Electricity:
capacity: 336,000 kW
production: 1 .5422 billion kWh
consumption per capita: 2.203 kWh (25.8% is
exponed to India leaving 1,633 kWh per
capita; 1990-91)
Industries: cement, wood products,
processed fruits, alcoholic beverages, calcium
carbide
Agriculture: accounts for 45% of GDP; based
on subsistence farming and animal husbandry;
self-sufficient in food except for foodgrains;
other production — rice, com. root crops, citrus
fruit, dairy products, eggs
Economic aid:
recipient: Western (non-US) countries. ODA
and OOF bilateral commitments (1970-89).
$115 million; OPEC bilateral aid (1979-89).
$1 1 million
Currency: 1 ngultrum (Nu)= 100 chetrum;
note — Indian currency is also legal tender
Exchange rates: ngultrum (Nu) per US$1 —
31.370 (January 1994), .30.493 (1993), 25.918
(1992). 22.7f.2(l991). 17.504(1990), 16.226
( 1 989); note — the Bhutanese ngultrum is at par
with the Indian rupee
Fiscal year: I July — ''OJune
Overview: With its long history of semifeudal
social controls, dependence on volatile prices
for its mineral exports, and bouts of
hyperinflation. Bolivia has remained one of the
poorest and least developed Latin American
countries. However, Bolivia has experienced
generally improving economic conditions
since the PAZ Estenssoro administration
( 1985-89) introduced market-oriented policies
which reduced inflation from 1 1,700% in 1985
to about 20% in 1988. PAZ Estenssoro was
followed as President by Jaime PAZ 2^mora
(1989-93) who continued the free-market
policies of his predecessor, despite opposition
from his own party and from Bolivia’s once
powerful labor movement. By maintaining
fiscal discipline, PAZ Zamora helped reduce
inflation to 9.3% in 1993, while GDP grew by
an annual average of 3.25% during his tenure.
Inaugurated in August 1993, President
SANCHEZ DE LOZADA has vowed to
advance government market-oriented
economic reforms he helped launch as PAZ
Estenssoro’ s Planning Mini.ster. A major
privatization bill was passed by the Bolivian
legislature in late March 1994.
National product: GDP — purchasing power
equivalent — $15.8 billion (1993 est.)
National product real growth rate: 2.2%
(199.3)
National product per capita: $2, 1 00 ( 1 993
est.)
Inflation rate (consumer prices): 9.3%
(1993)
Unemployment rate: 5.8% (1993)
Budget:
revenues: $3. 19 billion
expenditures: $3.19 billion, including capital
expenditures of $552.4 million ( 1994 est.)
Exports: $752 million (f.o.b., 1993 est.)
commodities: metals 35%, natural gas 26%,
other 39% (coffee, soybeans, sugar, cotton.
timber)
partners: US 16%, Argentina (1992 est.)
Imports: $1.17 billion (c.i.f, 1993 est.)
commodities: food, petroleum, consumer
goods, capital goods
partners: US 23.3% (1992)
External debt: $3.8 billion (January 1994)
Industrial production: growth rate 7%
(1992); accounts for almost 30% of GDP
Electricity:
capacity: 865,000 kW
production: 1 .834 billion kWh
consumption per capita: 250 kWh ( 1992)
Industries: mining, smelting, petroleum, food
and beverage, tobacco, handicrafts, clothing;
illicit drug industry reportedly produces 15%
of its revenues
Agriculture: accounts for about 2 1 % of GDP
(including forestry and fisheries); principal
commodities — coffee, coca, cotton, com,
sugarcane, rice, potatoes, timber; self-
sufficient in food
Illicit drugs: world’s second-largest producer
of coca (after Peru) with an estimated 45,5(X)
hectares under cultivation in 1992; voluntary
and forced eradication program unable to
prevent production from rising to 80,300
metric tons in 1992 from 78,200 tons in 1989;
government considers all but 12,000 hectares
illicit; intermediate coca products and cocaine
exported to or through Colombia and Brazil to
the US and other international drug markets
Economic aid:
recipient: US commitments, including Ex-Im
(FY70-89), $990 million: Western (non-US)
countries. ODA and OOF bilateral
commitments (1970-89), $2,025 billion;
Communist countries (1970-89), $340 million
Currency: 1 boliviano ($B) = 100 centavos
Exchange rates: bolivianos ($B) per US$1 —
4.5 (March 1994), 4.4604 (November 1993),
3.9005 (1992), 3.5806 (1991), 3.1727 (1990),
2.6917(1989), 2.3502(1988)
Fiscal year: calendar year','1d94f8b10d9ab45f82ce9a4abd5343a61670fa9e2d5871aba3c6b4b0fe682cfc','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a8858ba9c665c69cc9a66329eb9057edde33ccca889d246bb9c62fa7765dcd5',1994,'BA','Bosnia and Herzegovina','economy',151,'Overview: Bosnia and Herzegovina ranked
next to The Former Yugoslav Republic of
Macedonia as the poorest republic in the old
Yugoslav federation. Although agriculture has
been almost all in private hands, farms have
been small and inefficient, and the republic
traditionally has been a net importer of food.
Industry has been greatly overstaffed, one
reflection of the rigidities of Communist
central planning and management. Tito had
pushed the development of military industries
in the republic with the result that Bosnia
hosted a large share of Yugoslavia''s defense
plants. As of April 1994, Bosnia and
Herzegovina was being tom apart by the
continued bitter interethnic warfare that has
cau.sed production to plummet, unemployment
and inflation to soar, and human misery to
multiply. No reliable economic statistics for
1992-93 are available, although output clearly
has fallen substantially below the levels of
earlier years.
National product: GDP — purchasing power
equivalent — SNA
National product real growth rate: NA%
National product per capita: SNA
Inflation rate (consumer prices); NA%
Unemployment rate: NA%
Budget;
revenues: SNA
expenditures: SNA, including capital
expenditures of SNA
Exports: SNA
commodities: NA
partners: NA
Imports; SNA
commodities: NA
partners: NA
External debt: SNA
Industrial production: growth rate NA%,
but production is sharply down because of
interethnic and inlerrepublic warfare (1991-93)
Electricity:
capacity: NA kW
production: NA kWh
consumption per capita: NA kWh
Industries: steel production, mining (coal,
iron ore, lead, zinc, manganese, and bauxite),
manufacturing (vehicle assembly, tex''tiles,
tobacco products, wooden furniture, 40% of
former Y ugoslavia''s armaments including lank
and aircraft assembly, domestic appliances),
oil refining (1991)
Agriculture: accounted for 9.0% of GDP in
1 989; regularly produces less than 50% of food
needs; the foothills of northern Bosnia support
orchards, vineyards, livestock, and some wheat
and com; long winters and heavy precipitation
leach soil fertility reducing agricultural output
in the mountains; farms are mostly privately
held, small, and not very productive (1991)
Illicit drugs: NA
Economic aid: SNA
Currency: I dinar = 1 00 para; Croatian dinar
used in Croat-held area, presumably to be
replaced by new Croatian kuna; old and new
Serbian dinars used in Serb-held area; hard
currencies probably supplanting local
currencies in areas held by Bosnian','8912f487806640761f6a9c736e1e9ce65d008981affd7dc5334ce9b3a5088ceb','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f75d9d65503dc6b5b05cf4d2ef96e86ec5e06e32c9b49d049cea32f6e3f6067c',1994,'BW','Botswana','economy',156,'Overview: The economy has historically been
ba.sed on cattle raising and crops. Agriculture
ttxlay provides a livelihood tor more than 80%
of the population but produces only about 50%
of food needs. The driving force behind the
rapid economic growth of the 1970s and 1 980s
has been the mining industry. This sector,
mostly on the strength of diamonds, has gone
from generating 25% of GDP in 1980 to 50%
in 1991 . No other sector has experienced such
growth, especially not agriculture, which is
plagued by erratic rainfall and poor soils. The
unemployment rate remains a problem at 25%.
Although diamond production was down
.slightly in 1992, substantial gains in coal
output and manufacturing helped boost the
economy. Recovery in sluggish diamond
markets in second half 1993 helped Botswana
achieve moderate growth of 3% for the year.
National product: GDP — purchasing power
equivalent — $6 billion (1993 est.)
National product real growth rate: 3%
(1993 est.)
National product per capita: $4,S(X)(I993
est.)
Inflation rate (consumer prices): 1 4%
(1993 est.)
Unemployment rate: 25% (1993 est.)
Budget:
revenues: $1.7 billion
expenditures: $1.99 billion, including capital
expenditures of $652 million (FY94)
Exports: $1.7 billion (f.o.b. 1992)
commodities: diamonds 78%, copper and
nickei 6%. meat 5%
partners: Switzerland. UK, SACU (Southern
African Customs Union)
Imports: $ 1 .8 billion (c.i.f., 1992)
commodities: foodstuffs, vehicles and
transport equipment, textiles, petroleum
products
partners: Switzerland, SACU (Southern
African Customs Union), UK, US
External debt; $344 million (December
1991)
Industrial production; growth rate 6.8%
(FY91 ): accounts for about 53% of GDP,
including mining
Electricity:
capacity: 220,000 kW
production: 901 million kWh (in addition
228,000,000 kWh were imported)
consumption per capita; 874 kWh (1992 est.)
Industries: mining of diamonds, copper.
nickel, coal, salt, soda ash. potash; livestock
processing
Agriculture: accounts for only 5% of GDP;
subsistence farming predominates; cattle
raising supports 50% of the population; must
import up to of 80% of food needs
Economic aid:
recipient: US aid (1992), $13 million; Norway
(1992), $16 million; Sweden (190?) $15.5
million; Germany (1992), $3.o miihumi; EC/
Lome-IV (1992), $3-6 million in grants: $28.7
million in long-term projects (1992)
Currency: 1 pula (P)= 100 thebe
Exchange rates: pula (P) per US$ 1 — 3. 1 309
(January 1 994), 2.4 1 90 ( 1 993), 2. 1 327 ( 1 992).
2.0173(1991), 1.8601 (1990). 2.0125(1989)
Fiscal year: 1 April — 31 March
Overview: no economic activity','761b088f2145ff7fe6ea0e272732f1a51a3c28f822dd6b40b9677e60dbe8c21a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86c062063c1898556accd7e3f6b3fe058b73f0ce8c78098df3ea76403b179770',1994,'NO','Norway','economy',162,'Overview; The economy, with large agrarian,
mining, and manufacturing sectors, entered the
1990s with declining real growth, runaway
inflation, an unserviceable foreign debt of i 1 22
billion, and a lack of policy direction. In
56
oddition. the economy remained highly
regulated, inward-looking, and protected by
.substantial trade and investment barriers.
Ownership of major industrial and mining
facilities is divided among private interests —
including several multinationals — and the
government. Most large agricultural holdings
are private, with the government channeling
financing to this sector. Conflicts between
large landholders and landless peasants have
produced intermittent violence. The COLLOR
government, which assumed office in March
1990. launched an ambitious reform program
that sought to modernize and reinvigomte the
economy by stabilizing prices, deregulating the
economy, and opening it to increased foreign
competition. 1 be government also obtained an
IMF standby loan in January 1992 and reached
agreements with commercial bankers on the
repayment of interest arrears and on the
reduction of debt and deb> service payments.
Galloping inflation (the rate doubled in 1992
and by March 1994 had risen to 429f per
month) continues to undermine economic
stability. Itamur FRANCO, who assumed the
presidency following Presidt.it COLLOR'' S
resignation in December 1992, wis out of step
with COLLOR''S reform agenda: initiatives to
redress fiscal problems, privatize slate
enterprises, and liberalize trade and investment
policies have lo,st momentum. Brazil’s natural
resources remain a major, long-term economic
strength
National product: GDP — purchasing power
equivalent — $78.i billion (1993 est.)
National product real growth rate: S''k
(199.3)
National product per capita: $.3,000 ( 1 993
est.)
Inflation rate (consumer prices): 2.7099(''
(1993)
Unemployment rate: 4,9% ( 1993)
Budget:
re\\’eniie.i: $113 billion
expenditures: $109 billion, including capital
expenditures of $23 billion (1992)
Exports: $38.8 billion (f.o.b. 1993)
coinmoditU s: iron ore. soybean bran, orange
juice footwear, coffee, motor s’chicle parts
partners: EC 27,6%, Latin America 21.8%.
US 17.4%. Japan 6.3% (1993)
Imports: $2,S.7 billion (f.o.b. 1993)
eainmodities: crude oil, capital goods,
ct-tmical products, foodstuffs, coal
partner-.: US 23.3%, EC 22.5%, Middle East
13.0%, Latin America 1 1 .8%, Japan 6.5%
(1993t
External debt: $ 1 1 9 billion ( 1 993)
Industrial production: growth rale 9.5%
(1993); accounts for 3‘>% of GDP
Electricity:
capaeitv: 6‘’,765,(X)0 l;W
prodiwtiat: 242.184 b.llion kWh
consumption per capita: 1,531 kWh (1992)
Industries: textiles and other consumer
gotxis. shoes, chemicals, cement, lumber, iron
ore, steel, motor vehicles and auto parts,
metalworking, capital goods, tin
Agriculture: accounts for 1 1% of GDP;
world''s largest producer and exporter of coffee
and orange juice concentrate and second-
largest exporter of soybeans; other products —
rice, com. sugarcane, cocoa, beef: self-
sufficient in food, except for wheal
Illicit drugs: illicit producer of cannabis and
coca, mostly for domestic consumption;
government has a modest eradication program
to control cannabis and coca cultivation;
important transshipment country for Bolivian
and Colombian cocaine headed for the US and
Europe
Economic aid:
recipient: US commitments, including Ex-Im
(FY70-89). $2.5 billion; Western (non-US)
countries, ODA and OOF bilateral
commitments ( 1 970-89), $ 10.2 million; OPEC
bilateral aid ( 1979-89). $284 million; former
Communist countries (1970-89), SI. 3 billion
Currency: I cruzeiro real (CR$) = 100
centavos
Exchange rates: CRS per US$1 — 390.845
(January 1994), 88.449(199.3). 4.513(1992),
0.407 (1991), 0.068 ( 1990), 0.003 ( 1989)
note: on I August 1993 the cruzeiro real, equal
to 1,000 cruzeiros, was introduced; another
new currency, the real, will be introduced on I
July 1994
Fiscal year: calendar year
Overview: Greenland''s economic situation at
present is difficult. Unemployment is
increasing, and prospects for economic growth
in the immediate future are dim. Following the
ci''.,sing of the Black Angel lead and zinc mine
in 1989. Greenland became almost completely
dependent tm fishing and fish processing, the
.sector accounting for 95% of exports.
Prospects for fisheries are not bright, as the
important shrimp catches will at best stabilize
and cod catches have dropped. Resumption of
mining and hydrocarbon activities is not
around the corner, thus leaving only tourism
with some potential for the near future. The
public sector in Greenland, i.e.. the central
government and its commercial entities and the
municipalities, plays a dominant role in
Greenland accounting for about two-thirds of
total employment. About half the
government''s revenues come from grants from
the Danish Government.
National product; GNP — purchasing power
equivalent — $500 million ( 1988)
National product real growth rate: - 10%
(1990)
National product per capita: S9.(XK) ( 1 988)
Inflation rate (consumer prices): 1 .6%
(1991)
Unemployment rate: 9% (1990 est.)
Budget:
revenues; $381 million
expenditures; $381 million, including capital
expenditures of $36 million (1989)
Exports: $340.6 million (f.o.b., 1991)
commodities; fish and fish products 95%
partners; Denmark 79%, Benelux 9%,
Germany 5%
Imports: $403 million (c.i.f., 1991)
commodities; manufactured goods 28%,
machinery and transport equipment 24%, food
and live animals 12.4%, petroleum products
12%
partners; Denmark 65%. Norway 8.8%. US
4.6%, Germany 3.8%, Japan 3,8%. Sweden
2.4%
External debt; $480 million ( 1990 est.)
Industrial production: growth rate NA%
Electricity:
capacity; 84.000 kW
production; 176 million kWh
consumption per capita; 3,060 kWh (1992)
Industries: fish processing (mainly shrimp),
lead and zinc mining, handicrafts, some small
shipyards, potential for platinum and gold
mining
Agriculture: sector dominated by fishing and
sheep raising; crops limited to forage and small
garden vegetables; 1988 fish catch of 133,500
metric tons
Economic aid: none
Currency: I Danish krone (DKr) = 100 oere
Exchange rates; Danish kroner (DKr) per
US$1— 6.771 (January 1994), 6.484(1993),
6,0.36 (1992). 6..396 ( 1 99 1 ), 6. 1 89 ( 1 990),
7.310 0989)
Fiscal year; calendar year','7d38ef4cee62226b7739330f4a792bc2f1821070521d393e57192e8daf206a3b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('696ca2181a7dc2893c93e23c9bed7d1ca6f879168bfa515f19100d12e0fc5104',1994,'IO','British Indian Ocean Territory','economy',169,'Overview: All economic activity is
concentrated on the largest Island of Diego
Garcia, where joint UK-US defense facilities
ure located. Construction projects and various
services needed to support the military
installations are done by military and contract
employees from the UK. Mauritius, the
Philippines, and the US. There are no industrial
or agricultural activities on the islands.
Electricity: provided by the US military
Overview: The economy, one of the most
prosperous in the Caribbean area, is highly
dependent on the tourist industry, which
generates about 21 % of the national income. In
1985 the government offered offshore
registration to companies wishing to
incorporate in the islands, and, in consequence,
incorporation fees generated about $2 million
in 1987. The economy slowed in 1991 because
of the poor performances of the tourist sector
and tight commercial bank credit. Livestock
raising is the most significant agricultural
activity. The islands’ crops, limited by poor
soils, are unable to meet food requirements.
National product: GDP — purchasing power
equivalent — $133 million (1991)
National product real growth rate: 2%
(1991)
National product per capita: $I0,6(X)
(1991)
Inflation rate (consumer prices): 2.5%
(1990 est.)
Unemployment rate; NEGL%(I992)
Budget:
revenues; $5 1 million
expenditures; $88 million, including capital
expenditures of $38 million (1991)
Exports: $2.7 million (f.o.b., 1988)
commodities: rum, fresh fish, gravel, sand,
fruits, animals
partners: Virgin Islands (US), Puerto Rico, US
Imports; $I 1.5 million (c.i.f., 1988)
commodities: building materials, automobiles,
foodstuffs, machinery
partners. Virgin Islands (US), Puerto Rico, US
External debt: $4.5 million (1985)
Industrial production; growth rate 4.0%
(1985)
Electricity:
capacity; 10,5(K)kW
production: 43 million kWh
consumption per capita; 3,5 10 kWh ( 1990)
Industries: tourism, light industry,
construction, rum, concrete block, offshore
financial center
Agriculture: livestock (including poultry),
fish, fruit, vegetables
59
British Virgin Islands {continued) Brunei
Economic aid: SNA
Currency: 1 United States dollar (USS) = 100
cents
Exchange rates; US currency is used
Fiscal year: 1 April — 1 March
Overview: The economy is a mixture of
foreign and domestic entrepreneurship,
government regulation and welfare measures,
and village tradition. It is almost totally
supported by exports of crude oil and natural
gas. with revenues from the petroleum sector
accounting for more than 50% of GDP. Per
capita GDP is among the highest in the Third
World, and substantial income from overseas
investment supplements domestic production.
The government provides for all medical
services and subsidizes food and housing.
National product: GDP — exchange rate
conversion — $2.5 billion (1991 est.)
National product real growth rate: I %
(1991)
National product per capita: $9.(X)0 (1991
est.)
Inflation rate (consumer prices): 2% ( 1 993
est.)
Unemployment rate: 3.7% (1989)
Budget:
revenues: $1.3 billion
expenditures: $1.5 billion, including capital
expenditures of $255 million (1989 est.)
Exports: $2.3 billion (f.o.b., 1992 est.)
commodities: crude oil, liquefied natural gas,
petroleum products
partners: Japan 53%, UK 12%, South Korea
9%, Thailand 7%, Singa|X)re 5% (1990)
Imports: $2 billion (c.i.f., 1992 est.)
commodities: machinery and transport
equipment, manufactured goods, food,
chemicals
partners: Singapore 35%, UK 26%,
Switzerland 9%, US 9%, Japan 5% (1990)
External debt: $0
Industrial production: growth rate 1 2.9%
(1987); accounts for 52.4% of GDP
Electricity:
capacity: .3 10,000 kW
production: 890 million kWh
consumption per capita: 3,300 kWh (1990)
Industries: petroleum, petroleum refining,
liquefied natural gas, construction
Agriculture: imports about 80% of its food
needs; principal crops and livestock include
rice, cassava, bananas, buffaloes, and pigs
Economic aid:
recipient: US commitments, including Ex-Im
(FY70-87), $20.6 miliion; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $153 million
Currency: I Bruneian dollar(B$)= lOOcents
Exchange rates: Bruneian dollars (B$) per
US$1— 1, 60.32 (January 1994), 1.6158(1993).
1,6290(1992). 1.7276(1991). 1.8125(1990),
1 .9503 (1989); note — the Bruneian dollar is at
par with the Singapore dollar
Fiscal year: calendar year','09266e0bbf72496001a4ee52139418387fe9418d9f972a2b05f4b149eefeb641','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82a91e6b1edbd7b586a93f3d726fafbd4e259a692249b81739afef4b04b994b6',1994,'BG','Bulgaria','economy',175,'Overview: The Bulgarian economy continued
its painful adjustment in 1993 from the
misdirected development undertaken during
four decades of Communist rule. Many aspects
of a market economy have been put in place
and have begun to function, but much of the
economy, especially the industrial sector, has
yet to re-establish market links lost with the
collapse of other centrally planned Eastern
European economies. The prices of many
imported industrial inputs, especially energy
products, have risen markedly, and fulling real
wages have not sufficed to restore
competitiveness. The trade deficit, exacerbated
by UN trade sanctions against neighboring
Serbia, grew in late 1993. accelerating the
depreciation of the lev. These difficulties in
adjusting to the challenges of a more open
system, together with a severe drought, caused
nonagricultural output to fall by perhaps SCf in
1993. The government plans more extensive
privatization in 1994 to improve the
management of state enterprises and to
encourage foreign investment in ailing state
firms. Bulgaria resumed payments on its $10
billion in commercial debt in 1993 following
the negotiation of a 509f write-off. An IMF
program and second agreement with official
creditors on Bulgaria''s smaller amount of
official debt are required to close the debt deal.
National product: GDP — purchasing power
equivalent — $33.9 billion (1993 est.)
National product real growth rate: -4%
(1993 est.)
National product per capita: $3,800 (1993
est.)
Inflation rate (consumer prices): 64%
(1993)
Unemployment rate: 16% (1993)
Budget:
revenues: $14 billion
expenditures: $ 1 7.4 billion, including capital
expenditures of $6i0 million (1993 est.)
Exports; $3.5 billion (f.o.b., 1991)
commodities: machinery and equipment
30.6%; agricultural products 24%;
manufactured consumer goods 22.2%; fuels,
minerals, raw materials, and metals 10.5%;
other 12.7% (1991)
partners: former CEMA countries 57.7%
(USSR 48.6%, Poland 2.1%, Czechoslovakia
0.9%); developed countries 26.3% (Germany
4.8%. Greece 2.2%); less developed countries
1 5.9% (Libya 2. 1 %, Iran 0.7%) (1991)
Imports: $2.8 billion (f.o.b.. 1991)
commodities: fuels, minerals, and raw
materials 58.7%; machinery and equipment
15.8 %; manufactured consumer goods 4.4%;
agricultural products 15.2%; other 5.9%
partners: former CEMA countries 5 1 .0%
(former USSR 43.2%, Poland 3.7%);
developed countries 32.8% (Germany 7,0%,
Austria 4.7%); less developed countries 16.2%
(Iran 2.8%, Libya 2.5%)
External debt: $12 billioi. (1993)
Industrial production: growth rate - 1 0%
(1993 est.); accounts for about 37% of GDP
(1990)
Electricity:
capacity: 1 1,500,000 kW
production: 45 billion kWh
consumption per capita: 5.070 kWh (1992)
Industries; machine building and metal
working, food processing, chemicals, textiles.
building materials, ferrous and nonferrous
metals
Agriculture: climate and soil conditions
support livestwk raising and the growing of
various grain crops, oilseeds, vegetables, fruits,
and tobacco; more than one-third of the arable
land devoted to grain: world''s fourih-largest
tobacco exporter: surplus fiwd producer
Illicit drugs: transshipment point for
southwest Asian heroin transiting the Balkan
route
Economic aid: $NA
Currency: 1 lev(Lv)= l(K)stotinki
Exchange rates: leva (Lv) per US$ I — 32.(X)
(January 1994), 24,56 (January 1993). 17.18
(January 1992), 16.13 (March 1991), 0.7446
(November 1990). 0.84 (1989); note — floating
exchange rate since February 1 99 1
Fiscal year: calendar year','0f04ac0069556fc56a0a4003f67dce1f91edaed1d1edee606f5cc3629e1ed70d','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb8bee817a634cabeb5b7b6ea6efaeabc68d8b3b795171987fb36cc4a8f6de9d',1994,'TH','Thailand','economy',182,'Overview: Burma has a mixed economy with
about 70% private activity, mainly in
agriculture, light industry, and transport, and
with about 30% state-controlled activity,
mainly in energy, heavy industry, and foreign
trade. Government policy in the last five years,
1989-93, has aimed at revitalizing the economy
after four decades of tight central planning.
Thus, private activity has markedly increased;
foreign investment has been encouraged, so far
with moderate success; and efforts continue to
increase the efficiency of state enterprises.
Published estimates of Burma''s foreign trade
are greatly understated because of the volume
of black market trade. A major ongoing
problem is the failure to achieve monetary and
fiscal stability, inflation has been running at
25% to 30% annually. Good weather helped
boost GDP by perhaps 5% in 1993. Although
Burma remains a poor Asian country, its rich
resources furnish the potential for substantial
long-term increases in income, exports, and
living standards.
National product; GDP — purchasing power
equivalent — $41 billion (1993 est.)
National product real growth rate: 5%
(1993 est.)
National product per capita: $950(1993
e.st.)
Inflation rate (consumer prices): 30%
(1 993 est.)
Unemployment rate: NA%
Budget:
revenues: $8, 1 billion
expenditures: $1 1 .6 billion, including capital
expenditures of SNA (1992)
Exports: $613.4 million (FY93)
commodities: pulses and beans, teak, rice,
hardwood
IHirtncrs: Singapore, China, Thailand. India,','19b667294bd1e5357145b6a18bd8eee48ba4eaa620103f2bc9cd66e8350105fb','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcf66dfdea287619675a3cbff73f73f7535786fe4a776c349924faca8dd35e61',1994,'HK','Hong Kong','economy',183,'Imports: $1.02 billion (FY93)
commodities: machinery, transport equipment,
chemicals, food products
IHirtners: Japan, China, Thailand, Singapore.
Overview: Hong Kong has a bustling free
market economy with few tariffs or nontariff
barriers. Natural resources are limited, and
food and raw materials must be imported.
Manufacturing accounts for about 17% of
GDP, Goods and services exports account for
about 50% of GDP. Real GDP growth
averaged a remarkable 8% in 1987-88. slowed
to 3.0% in 1989-90, and picked up to 4.2% in
1991, 5.0% in 1992, and 5.2% in 1993.
Unemployment, which has been declining
since the mid-1980s, is now about 2%. A
shortage of labor continues to put upward
pressure on prices and the cost of living. Shon-
term prospects remain bright so long as major
trading partners continue to be reasonably
prosperous.
National product: GDP — purchasing power
equivalent — $1 19 billion (1993 est.)
National product real growth rate: 5.2%
(1993)
National product per capita: S2 1 .500 ( 1 993
est.)
Inflation rate (consumer prices): 9.5%
(1993)
Unemployment rate: 2.3% (1993 est.)
Budget:
revenues; $19.2 billion
espendilures: $19.7 billion, including capital
expenditures of $NA (FY94)
Exports: $145.1 billion (including re-exports
of $104.2 billion; f.o.b., 1993 est.)
commodities; clothing, textiles, yam and
fabric, footwear, electrical appliances, watches
and clocks, toys
IHirtners; China 32%, US 23%. Germany 5%,
Japan 5%. UK 3% ( 1993 e.st.)
Imports: $149.6 billion (c.i.f., 1993 est.)
commiHlities: fotxlstuffs. transport equipment,
raw materials, semimanufactures, petroleum
luirtners: China 36%, Japan 19%. Taiwan 9%,
US 7%(1993e,st.)
External debt: none (1993)
Industrial production; growth rate 2% ( 1 993
est.)
Electricity:
capacity; 9.566.(XX) kW
production: 29,4 billion kWh
consumption per capita: 4,980 kWh (1992)
Industries: textiles, clothing, tourism,
electronics, plastics, toys, watches, clocks
Agriculture: minor role in the economy; local
farmers produce 26% fresh vegetables, 27%
live poultry; 8% of land area suitable for
farming
Illicit drugs: a hub for Southeast Asian heroin
trade; transshipment and major financial and
money-laundering center
Economic aid;
recipient; US commitments, including Ex-Im
(FY70-87), $152 million; Western (non-US)
countries, ODA and CX)F bilateral
commitments (1970-89). $923 million
Currency; 1 Hong Kong dollar (HK$) = 100
cents
Exchange rates: Hong Kong dollars (HK$)
per USS— 7.800 (1993), 7.741 (1992), 7,771
( 1 99 1 ), 7.790 ( 1 990), 7.800 ( 1 989) ; note-
linked to the US dollar at the rate of about 7,8
HKS per 1 US$ since 1985
Fiscal year: I April — 31 March
Overview: no economic activity
Overview: The economy is based largely on
tourism (including gambling) and textile and
fireworks manufacturing. Efforts to diversify
have spawned other small industries — toys,
artificial flowers, and electronics. The tourist
sector has accounted for roughly 25% of GDP,
and the clothing industry has provided about
two-thirds of export earnings; the gambling
industry represented well over 40% of GDP in
1992. Macau depends on China for most of its
fond, fresh water, and energy imports. Japan
and Hong Kong are the main suppliers of raw
material-, and capital goods.
National product: GDP — exchange rate
conversion — $3.5 billion (1992 est.)
National product real growth rate; 1 2%
(1992)
National product per capita: $7,300 ( 1 992)
Inflation rate (consumer prices): 7.7%
(1992 est.)
Unemployment rate: 2% (1992 est.)
Budget;
revenues: $305 million
expenditures: $298 million, including capital
expenditures of $NA ( 1989 est.)
Exports; $1,8 billion (1992 e.st.)
commodities: textiles, clothing, toys
partners: US 35%. Hong Kong 1 2.5''^,
Germany 12%. China 9.9%. France :;% (1992
est.)
Imports: $2 billion (1992 est)
commodities: raw materials, foodstuffs, capital
goods
partners: Hong Kong 33%, China 20%, Japan
18% (1 992 est.)
External debt; $91 million (1985)
Industrial production; NA
Electricity:
capacity: 258,000 kW
production: 855 million kWh
consumption per capita: 1 ,806 kWh ( 1 992)
Industries; clothing, textiles, toys, plastic
products, furniture, tourism
Agriculture: rice, vegetables; food
shortages — rice, vegetables, meat; depends
mostly on imports for food requirements
Economic aid: none
Currency: 1 pataca (P) = 100 avos
Exchange rates: patacas (P) per US$1 —
8.034 (1991-93). 8.024 (1990), 8,030 (1989);
note - linked to the Hong Kong dollar at the rate
of 1 .03 patacas per Hong Kong dollar
Fiscal year: calendar year','95beac9178ca6f2f9b72b387b0f35d4d38061a817f2c6bc2f5527186e4c61f74','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8528ecfa8ce9556402b116600f9105fb2fa75b8471e73ce80718d2a5784a7b98',1994,'MY','Malaysia','economy',184,'External debt: $4 billion ( 1992)
Industrial production; growth rate 4.9%
(FY93 est,); accounts for 10% of GDP
Electricity:
66
Overview: Landlocked Malawi ranks among
the world''s least developed countries. The
economy is predominately agricultural, with
about 90% of the population living in rural
areas. Agriculture accounts for 40% of GDP
and 90% of export revenues. After two years of
weak performance, economic growth
improved significantly in 1988-91 as a result of
good weather and a broadly based economic
adjustment effort by the government. Drought
cut overall output sharply in 1992. The
economy depends on substantial inflows of
economic assistance from the IMF. the World
Bank, and individual donor nations.
National product: GDP — purchasing power
equivalent — $6 billion (1993 est.)
National product real growth rate: -8%
(1992 est.)
National product per capita: $6(X) ( 1 993
est.)
Inflation rate (consumer prices): 2 1 %
(1992 est.)
Unemployment rate: NA%
Budget:
revenues: $416 million
expenditures: $498 million, including capital
expenditures of SNA (1992 est.)
Exports: $413 million (f.o.b., 1992)
commodities: tobacco, tea, sugar, coffee,
peanuts, wood products
partners: US, UK, Zambia, South Africa,','1494cfddd73eadbe14a1c2783211d13e44d56a1be4240c4b22cd55102aaac6de','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c7cc42b7b9c4d40d634fc8ed998c56eaa146df7559f955a9112f773b5df9ff3',1994,'BI','Burundi','economy',185,'capacity; 1,100.000 kW
production; 2,8 billion kWh
consumption per capita; 65 kWh (1992)
Industries: agricultural processing; textiles
and footwear; wood and wood products;
petroleum refining; mining of copper, tin,
tungsten, iron; construction materials;
pharmaceuticals; fertilizer
Agriculture: accounts for 40% of GDP and
66% of employment (including fish and
forestry); self-sufficient in food; principal
crops — paddy rice, com. oilseed, sugarcane,
pulses; world''s largest stand of hardwood
trees; rice and timber account for 55% of
export revenues
Illicit drugs: world''s largest illicit producer
of opium (2,575 metric tons in 1993) and minor
producer cf cannabis for the international drug
trade: opium production has doubled since the
collapse of Rangoon''s antinarcotic programs
Economic aid:
recipient; US commitments, including Ex-lm
(FY70-89). $158 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89). $3,9 billion;
Communist countries (1970-89), $424 million
Currency: 1 kyat (K) = 100 pyas
Exchange rates: kyats (K) per US$1 —
6.2301 (December 1993). 6.1570(1993),
6.1045 (1992), 6.2837 (1991), 6.3386 (1990),
6.7049 (1989); unofficial— 105
Fiscal year: 1 April — 31 March
Overview: A landlocked, resource-poor
country in an early stage of economic
development, Burundi is predominately
agricultural with only a few basic industries. Its
economic health depends on the coffee crop,
which accounts for 80% of foreign exchange
earnings. The ability to pay for imports
therefore continues to rest largely on the
vagaries of the climate and the international
coffee market. As part of its economic reform
agenda, launched in February 1991 with IMF
and World Bank support, Burundi is trying to
diversify its agricultural exptorts and attract
foreign investment in industry. Several state-
owned coffee companies were privatized via
public auction in September 1991.
National product: GDP — purchasing power
equivalent — $4.4 billion (1993 est.)
National product real growth rate: -3.8%
(1991)
National product per capita: $7(X) (1993
est.)
Inflation rate (consumer prices): 4.7%
(1992 est.)
Unemployment rate; NA%
Budget:
revenues: $318 million
e.\\i>endiiures: $326 million, including capital
expenditures of $150 million (1991 est.)
Exports: $40.8 million (f.o.b., 1992 est.)
commodities: coffee 81%, tea, cotton, hides,
and skins
partners: EC 57%, US 19%. Asia 1%
Imports; $188 million (c.i.f., 1992 est.)
commodities: capital goods 31%, petroleum
prixlucis 15%, foodstuffs, censumer goods
partners: EC 45%. Asia 29%. US 2%
External debt: $970 million ( 1 99 1 )
Industrial production: real growth rate
1 1.0% (1991 est,); accounts for about 15% of
GDP
Electricity:
capacity: 55,(XX) kW
production: 105 million kWh
consumption per capita: 20 kWh (1991)
Industries: light consumer goods such as
blankets, shoes, soap; assembly of imported
components; public works construction; food
processing
Agriculture: accounts for 50% of GDP: 90%
of population dependent on subsistence
farming: marginally .self-sufficient in food
poxluction; cash crops — coffee, cotton, tea:
food crops — com, .sorghum, sweet potatoes,
bananas, manioc; livestock — meat. milk, hides
and skins
Economic aid:
recipient: US commitments, including Ex-lm
68','c2113fa67e49ad6cb76e45e0aa40490fdab72722eadf7598b3fc4aac79065403','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fbc753d2415549c3cc41486d8a35d956276190d8699554568f91d6ae1ab5b515',1994,'KH','Cambodia','economy',191,'(FY70-89), $71 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $10.2 billion; OPEC
bilateral aid (1979-89), $32 million;
Communist countries (1970-89), $175 million
Currency: 1 Burundi franc (FBu) = 100
centimes
Exchange rates: Burundi francs (FBu) per
US$1— 247.94 (November 1993), 208.30
(1992), 181.51 (1991), 171.26(1990), 158.67
(1989), 140.40(1988)
Fiscal year: calendar year
Overview: The Cambodian economy —
virtually destroyed by decades of war — is
slowly recovering, Government leaders are
moving toward restoring fiscal and monetary
discipline and have established good working
relations with intcmtuional financial
institutions. Despite such positive
developments, the reconstruction effort faces
many tough challenges, Rural Cambodia.
where 90% of almost ten million Khmer live,
remains mired in po- -ttty. The almost total lack
of basic infrastructure in the countryside will
hinder development and will contribute to a
growing imbalance in growth between urban
and rural areas over the near term. Moreover,
the new government''s lack of experience in
administering economic and technical
assistance programs, and rampant corruption
among officials, will slow the growth of
critical public sector investment. Inflation for
1 993 as a whole was 60%. less than a quarter of
the 1992 rate, and was declining during the
year. The government hoped the rate would fall
to 10% in early 1994.
National product: GDP — purchasing power
equivalent — $6 billion (1993 est.)
National product real growth rate: 7.5%
(1993 est.)
National product per capita: $600(1993
est.)
Inflation rate (consumer prices): 60%
(1993 e.st.)
Unemployment rate: NA%
Budget:
revenues; $350 million
expenditures; $350 million, including capital
expenditures of $ 1 .33 million ( 1994 est.)
Exports: $70 million (f.o.b., 1992 est.)
commodities; natural rubber, rice, pepper, raw
timber
partners: Thailand. Japan. India, Singapore.
Malaysia, China, Vietnam
Imports: $360 million (c.i.f., 1992 est.)
commodities; international food aid; fuels.
consumer goods, machinery
partners; Japan. India. Singapore. Malaysia,
Thailand, China, Vietnam
External debt: total outstanding bilateral
official debt to OECD members $248 million
(yearend 1991 ), plus 840 million ruble debt to
former CEMA countries
Industrial production: growth rate 15.6%;
accounts for 10% of GDP
Electricity:
capacity; 35,(KK) kW
production; 70 million kWh
consumption per capita; 9 kWh ( 1990)
Industries: rice milling, fishing, wood and
wood prixlucts. rubber, cement, gem mining
Agriculture: accounts for 50% of GDP;
mainly subsistence farming except for rubber
plantations; main crops — rice, rubber, com;
food shortages — rice, meat, vegetables, dairy
prtxlucts, sugar, flour
Illicit drugs: secondary transshipment
country for heroin poxluccd in the Golden
Triangle
Economic aid:
recipient; US commitments, including Ex-lm
(FY7()-89). $725 million; Western (non-US
countries) ( 1970-89), $,300 million;
Communist countries (1970-89). $1.8 billion
donor countries and multilateral institutions
pledged $8X0 million in assistance in 1992
Currency: 1 new riel (CR) = 100 sen
Exchange rates: riels (CR) per US$ I — 2,390
(December 1993), 2,800 (September 1992),
.500 (December 1991). .560 (1990). 159.00
(1988), 100,00(1987)
Fiscal year: calendar year
Overview: Thailand’s economy recovered
rapidly from the political unrest in May 1992 to
post an impressive 7.5% growth rate for the
year and 7.8% in 1993. One of the more
advanced developing countries in Asia,
Thailand depends on exports of manufactures
and the development of the service sector to
fuel the country’s rapid growth. The trade and
current account deficits fell in 1992; much of
Thailand’s recent imports have been for capital
equipment suggesting that the export sector is
poised for further growth. With foreign
investment slowing, Bangkok is working to
increase the generation of domestic capital.
Prime Minister CHUAN’s government —
Thailand’s fifth government in less than two
years — is pledged to continue Bangkok’s
probusiness policies, and the return of a
democratically elected government has
improved business coMl''idence. Nevertheless,
CHUAN must overcome divisions within his
ruling coalition to complete much needed
infrastructure development programs if
Thailand is to remain an attractive place for
business investment. Over the longer-term.
Bangkok must produce more college graduates
with technical training and upgrade workers''
skills to continue its rapid economic
development.
National product: GDP — purchasing power
equivalent — $323 billion (1993 est.)
National product real growth rate: 7.8%
(1993 est.)
National product per capita: $.^,500(1993
est.)
Inflation rate (consumer prices): 4. 1 %
(1992 est.)
Unemployment rate: 3.1% (1992 est.)
Budget:
revenues: $21.36 billion
expenditures: $22.4 billion, including capital
expenditures of $6.24 billion (1993 e.st.)
Exports: $28.4 billion (f.o.b., 1992)
commodities; machinery and manufactures
76.9%, agricultural products 14.9%, fisheries
products 5.9% (1992)
partners: US 22%, Japan 18%, Singapore 8%,
Hong Kong 5%, Germany 4%, Netherlands
4%, UK 4%, Malaysia, France. China (1992)
Imports: $37.6 billion (c.i.f., 1992)
commodities: capital goods 41.4%,
intermediate go<^s and raw materials 32.8%,
consumer goods 10.4%, oil 8.2%
partners: Japan 29.3%, US 1 1 .4%, Singapore
7.6%, Taiwan 5.5%, Germany 5.4%, South
Korea 4.6%. Malaysia 4.2%, China 3.3%,
Hong Kong 3.3%. UK (1992)
External debt: $33.4 billion (1991)
Industrial production: growth rate 9%
i 992); accounts for about 26% of GDP
Electricity:
capacity; 1 0,000,000 kW
production; 43.75 billion kWh
consumption per capita: 760 kWh (1992)
Industries: tourism is the largest source of
foreign exchange: textiles and garments,
agricultural processing, beverages, tobacco,
cement, light manufacturing, such as jewelry;
electric appliances and components, integrated
circuits, furniture, plastics; world''s second-
largest tungsten producer and third-largest tin
producer
Agriculture; accounts for 1 2% of GDP and
60% of labor force; leading producer and
exporter of rice and cassava (tapioca); other
crops — rubber, com. sugarcane, coconuts,
soybeans; except for wheat, self-sufficient in
food
Illicit drugs: a minor producer of opium and
marijuana: major illicit trafficker of heroin,
particularly from Burma and Laos, for the
international dmg market; eradication efforts
have reduced the area of cannabis cultivation
and shifted some production to neighboring
countries; opium poppy cultivation has been
affected by eradication efforts: also a major
drug money laundering center
Economic aid:
recipient: US commitments, including Ex-lm
(FY70-89), $870 Tiillion; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $8.6 billion: OPEC
bilateral aid (1979-89), $19 million
Currency: I baht (B) = 100 satang
Exchange rates: baht (B) per US$1 — 25.446
(December 1993), 25.400 (1992), 25.517
(1991), 25.585 (1990), 25.702 (1989)
Fiscal year: I October- 30 September
Communkatioiis
Railroads: 3,940 km i. 000-meter gauge, 99
km double track
High vays:
total: km
paved; 35.855 km (including 88 km of
expressways)
unpaved: gravel, other stabilizatic-n 14,092
km; earth 27,750 km (1988)
Inland waterways: 3,999 km principal
waterways; 3,701 km with navigable depths of
0.9 m or more throughout the year; numerous
minor waterways navigable by shallow-draft
native craft
Pipelines: natural gas 350 km, petroleum
products 67 km
Ports; Bangkok, Pattani, Phuket, Sattahip, Si
Racha
Merchant marine: 198 ships ( 1 ,000 CRT or
over) totaling 998,372 GRT/1,561 ,824 DWT,
short-sea passenger I, cargo 105, container 13,
oil tanker 43, liquefied gas 9, chemical tanker
2, bulk 14. refrigerated cargo 6, combination
bulk 2, passenger I . roll-on/roll-off cargo I,
specialized tanker I
Airports:
total; 105
usable; 96
with permanent-surface runways; 5 1
with runways over 3,659 m; 1
with runways 2,440-3,659 m: 14
with runways 1,220-2,439 m: 28
Telecommi''nications: service to general
public inadequate; bulk of service to
government activities provided by
multichannel cable and microwave radio relay
network: 739,500 telephones ( 1 987); broadcast
stations — over 200 AM, 1(X) FM, and 1 1 TV in
government-controlled networks; satellite
earth stations — 1 Indian Ocean INTELSAT
and I Pacific Ocean INTELSAT; domestic
satellite system being developed
Defense Forces
Branches: Royal Thai Army, Royal Thai
Navy (including Royal Thai Marine Corps),
Royal Thai Air Force. Paramilitary Forces
Manpower availability: males age 15-49
1 6,982,226; fit for military service 1 0.3 1 2.744;
reach military age (1 8) annually 599.240 (1994
est.)
Defense expenditures: exchange rate
conversion — $2.6 billion, about 2% of GNP
(FY92/93 est.)
390
The Former Yugoslav Republic
of Macedonia
MMTnod M tw net nmi miM>
''mp«4t4 n • MM ttr )*<• UxAM
Overview: The Former Yugoslav Republic of
Macedonia, although the poorest republic in
the former Yugoslav federation, can meet basic
.391
The Forawr Yttioslav RtpubUc
of MacedonUi icmtinurd)
food and (Misy needi throu|h iu own
■gricuhiifal and cool reaauroca. Ila ecowowiic
dKline will continue unfeu tka are refotfcd or
enlarged with ila nel^ittora Serttia and
Montenegro, Altauii^ Greece, and Bulgaria.
The economy depends on outside sources for
all of iu oil and gas and iu modern machinery
and paru. Continued political turmoil, both
inlerrudly and in the region ns a whole,
preveitu any swift readjustments of trade
patterns and economic programs. The
country''s industrial ou^ and ODP arc
expect^ to decline ftmber in 1994. The
Farmer Yugoslav Republic of Macedonia''s
geographical isolation, technological
backwardness, and potential political
instability place it far down the list of countries
of interest to Western investors. Resolution of
the dispute with Greece and an internal
commitment to economic reform would help to
encourage foreign investmem over the long
run. In the immediate foture. the worst scenario
for the economy would be the spread of
fighting across iu borders
National product: GDP— purchasing power
equivalent — $2.2 billion (I est.)
Nattonal product md growth rate: -I4.79f
(1992 est.)
National product per capita: $1,000(1993
est.)
Inflation rate (consunwr priecs): 13%
monthly average (1993 est.)
Unesn^yment rate: 27% (1993 est.)
BndgM;
revenues: SNA
expemtimres: SNA, including capital
expenditures of SNA
Exports: $889 million (1993)
commodities: manufactured goods 40%,
machinery and transport equipment 14%,
miscellaneous manufactured articles 23%, raw
materials 7.6%. food (rice) and live animals
5.7%, beverages and tobacco 4.3%, chemicals
4.7% (1990)
partners: principally Serbia and Montenegro
and the other former Yugoslav republics,
Germany, Greece, Albania
Imports: $963 million (1993)
commodities: fuels and lubricants 19%,
manufactured goods 18%, machinery and
transport equipment 15%, food and live
animals 14%, chemicals ! 1.4%, raw materials
10%, miscellaneous manufactured articles
8.0%, beverages and tobacco 3.3% (1990)
partners: other former Yugoslav republics,
Greece, Albania, Germany, Bulgaria
External debt: $840 million ( 1 992)
Industrial production: growth rate -14%
(1993 est.)
Electricity:
capacity: 1 ,600,000 kW
production: 6.3 billion kWh
consumption per capita: 2,900 kWh ( 1 992)
Industries: low levels of technology
predominate, such as, oil refining by
distillation only; produces basic liquid fuels.','78231170b95b25107150bc6805ee0fc1a7607fdc859f26841d6c3265391b0433','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f883f21d6fa53281fc0e478e2e0edac37332fd093e7ddfcfdfd80bca040e3a98',1994,'CM','Cameroon','economy',201,'Overview: Because of its offshore oil
resources and favorable agricultural
conditions, Cameroon has one of the
best-endowed most diversified primary
commodity economies in sub-Saharan Africa.
Still, it faces many of the .>erious problems
facing other underdeveloped countries, such as
political instability, a top-heavy civil service,
and a generally unfavorable climate for
business enterprise. The development of the oil
sector led rapid economic growth between
1970 and 1 985. Growth came to an abrupt halt
in 1986, precipitated by steep declines in the
prices of major exports: coffee, cocoa, and
petroleum. Export earnings were cut by almost
one-third, and inefficiencies in fiscal
management were exposed. In 1990-93, with
support from the IMF and World Bank, the
government began to introduce reforms
designed to spur business investment, increase
efficiency in agriculture, and recapitalize the
nation''s banks. Political instability following
suspect elections in 1 992 brought IMF/WB
structural adjustment to a halt. Although the
50% devaluation of the currency in January
1 994 improves the potential for export growth,
mismanagement remains and is the main
barrier to economic improvement.
National product: GDP — purchasing power
equivalent — $19.1 billion (1993 est.)
National product real growth rate: NA
National product per capita: $ 1 ,500 ( 1993
est.)
Inflation rate (coasumer prices); 3% (1990
e.st.)
Unemployment rate: 25% (1990 est.)
Budget:
revenues: $1.7 billion
c.v/: nditures: $2.4 billion, including capital
expenditures of $422 million (FY90 est.)
Exports: $1.8 billion (f.o.b., 1991)
eomniotliiies: petroleum products 51%. coffee.
be^ns. cocoa, aluminum products, timber
partners: EC (particularly France) about 50%,
US, African countries
Imports: $1.2 billion (c.i.f., 1991)
commodities: machines and electrical
equipment, food, consumer goods, transport
equipment
partners: EC about 60% (France 41%,
Germany 9%), African countries. Japan, US
4%
External debt: $6 billion (1991)
Industrial production: growth rate 6.4%
(FY87); accounts for 30%. of GDP
Electricity:
capacity: 755.(X)t) kW
production: 2.19 billion kWh
consumption per capita: 1 90 kWh (1991)
Industries; petroleum production and
refining, food processing, light consumer
goods, textiles, sawmills
Agriculture: the agriculture and forestry
sectors provide employment for the majority of
the population, contributing nearly 25% to
GDP and providing a high degree of self-
sufficiency in staple foods; commercial and
food crops include coffee, cocoa, timber,
cotton, rubber, bananas, oilseed, grains,
livestock, root starches
Economic aid:
recipient: US commitments, including Ex-lm
(FY70-90). $479 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-90), $4.75 billion; OPEC
bilateral aid ( 1 979-89), $29 million:
Communist countries (1970-89). $125 million
Currency: 1 CFA franc (CFAF) = 100
centimes
Exchange rates: Communaute Financiere
Afrieaine francs (CFAF) per US$1 — 592.05
(January 1994). 283,16 (1993), 264.69 (1992).
282.11 (199I).272.26(1990).3I9.01 (1989)
note: beginning 12 January 1994, the CFA
franc was devalued to CFAF 100 per French
franc from CFAF 50 at which it had been fixed
since 1948
Fiscal year: 1 July — 30 June','4ceab24d5236b97bf4c4d0a9540a6640698ea87870719ea9c9b7ea8130b3122a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30cb47ebe8a3e890523f843d59d6492a9913851583a10dac3e40a0c0364cc44d',1994,'CA','Canada','economy',206,'Overview: As an afllucnt, high-tech industrial
society, Canada today closely resembles the
US in per capita output, market-oriented
economic system, tind pattern of prtKluction.
Since World War II the impressive growth of
the nianufacturing. mining, and service sectors
has transformed the nation fr<im a largely rural
economy into one primarily industrial and
urban. In the I98()s. Canada registered one of
the highest rales of real growth among the
OECD nations, averaging about 3.2''/} . With its
grciit natural resources, skilled labor force, and
modern capital plant. Canada has excellent
economic prospects, although the country still
faces high unemployment and a growing debt.
Moreover, the continuing constitutional
impasse between English- and
French-speaking ureas has ob.scn .-rs
discussing a possible split in the confederation;
foreign investors have become edgy.
National product: CDP — purchasing power
equivalent — $617.7 billion ( 1993)
National product real growth rate: 2.47/
(1993)
National product per capita: $22,2IK1
(1993)
Inflation rate (consumer prices): 1 .9'')}
( 1993)
Unemployment rate: I I''.f (December 1993)
Budget:
revenues: $92.34 billion (Federal)
e.vpendilures: $123.04 billion, including
capital expenditures of $NA (F''Y93 est.)
Exports: $133.9 billion (l.o.b., 1993)
commodities: newsprint, wood pulp, timber,
crude petroleum, machinery, natural gas,
aluminum, motor vehicles and parts;
telccommunieutions equipment
partners: US, Japan, UK. Germany, South
Korea, Netherlands, China
Imparts: $125.3 billion (c.i.f.. 1993)
commodities: crude oil. chemicals, motor
vehicles and parts, durable consumer go/xis,
electronic computers; telecommunications
equipment and parts
partners: US, Japan. UK, Germany, France,
Mexico, Taiwan, .South Korea
External debt: $4.35 billion ( 1993)
Industrial production: growth rate 3.5%
(1993)
Electricity:
capacity: 1()9,.34(),()<K) kW
production: 493 billion kWh
consumption per capita: l7.9tX) kWh ( 1992)
Industries: processed and unpnKCssed
minerals, RmhI products, wood and paper
pnxJucts, transportation equipment, chemicals,
Ush products, petroleum and natural gas
Agriculture: accounts for about 3‘/c of GDP;
one of the world''s major producers and
exporters of grain (wheat and barley); key
source of US agricultural imports; large forest
resources cover 35% of total land area;
commercial tisherics provide annual catch of
1.5 million metric tons, of which 75% is
exported
Illicit drug.s: illicit producer of cannabis for
the domestic drug market; use of hydroponics
technology permits growers U) plant large
quantities of high-quality marijuana indoors:
growing role as a transit point for heroin and
cocaine entering the U.S market
Economic aid:
donor: ODA and OOF commitments
(1970-89). $7.2 billion
Currency; 1 Canadian dollar (Can$)= 100
cents
Exchange rates: Canadian dollars (Cun$) per
US$1 — 1.3 1 74 (January 191)4). 1 .2901 ( 1993).
1 .2087 ( 1992). 1 .14.57 (1991 ). I . I6(i8 ( 1990).
1.1840(1989)
Fiscal year: I April — 3 1 March
Overview: Cape Verde''s low per capita GDP
reflects a pottr natural resource base, a serious,
long-term drought, and a high birthrate. The
economy is service oriented, with commerce,
transport, and public sersdees accounting for
60% of GDP. Although nearly 70% of the
population lives in rural areas, agriculture''s
share of GDP is only 20%; the fishing sector
accounts for 4%-. About 90% of food must be
75
Cap6 Verde (continued)
imported. The fi.shing potential, mostly lobster
and tuna, is not fully exploited. In 1988 fishing
represented only 3.5% of GDP. Cape Verde
annually runs a high trade deficit, flnanced by
remittances from emigrants and foreign aid.
Economic reforms launched by the new
democratic government in February 1991 are
aimed at developing the private sector and
attracting foreign investment to diversify the
National product: GDP — exchange rate
conversion — $415 million (1991 est.)
National product real growth rate: 3.3%
(1991 est.)
National product per capita: $ 1 ,070 (1991)
Inflation rate (consumer prices): 8.7%
(1991 est.)
Unemployment rate: 25% ( 1 988)
Budget:
revenues: $104 million
expenditures: $133 million, including capital
expenditures of $72 million (1991 est.)
Exports: $6 million (f.o.b., 1990)
commodities: fish, bananas, hides and skins
partners: Portugal 40%, Algeria 31%, Angola,
Netherlands ( 1 990 est.)
Imports; $145 million (c.i.f., 1990)
commodities: foodstuffs, consumer goods,
industrial products, transport equipment
partners: Sweden 33%. Spain 1 1 %, Germany
5%, Ponugal 3%, France 3%, Netherlands, US
(1990 est.)
External debt: $1,56 million (1991)
Industrial production: growth rate 1 8%
(1988 est.); accounts for 7% of GDP
Electricity:
capacity: 15,000 kW
production: 15 million kWh
consumption per capita: 40 kWh ( 1991 )
Industries: fish processing, salt mining,
clothing factories, ship repair, construction
materials, food and beverage production
Agriculture: accounts for 20% of GDP
(including fishing): largely subsistence
farming; bananas are the only export crop;
other crops — com, beans, sweet potatoes,
coffee; growth potential of agricultural sector
limited by poor soils and scanty rainfall; annual
food imports required; fish catch provides for
both domestic consumption and small exports
Economic aid:
recipient: US commitments, including Ex-lm
(FY75-90). $93 million; Western (non-US)
countries, ODA and OOF bilateral
commitments ( 1 970-90), $586 million; OPEC
bilateral aid (1979-89). ‘’’2 million;
Communist countries (1970-89), $36 million
Currency: I Cape Verdean escudo
(CVEsc)= 100 centavos
Exchange rates: Cape Verdean escudos
(CVEsc) per US$ 1 — 85.992 (December 1993).
80.574 ( 1 993 ), 68.0 1 8 ( 1 992). 7 1 .408 (1991).
70.031 (1990). 77.978(1989)
Fiscal year: calendar year','27aa8053519141d837f400113f1e4984a6e8c2d6691aaa7c44451b01367a81e1','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a6410e9e939a6ab64d7d6091788b2d38a140b9fc664d3345b2cc135aa4424a4',1994,'KY','Cayman Islands','economy',209,'(dependent territory of the UK)
Overview: The economy depends heavily on
tourism (70% of GDP and 75% of foreign
currency earnings) and offshore financial
services, with the tourist industry aimed at the
luxury market and catering mainly to visitors
from North America. About 90% of the
islands" food and consumer goods needs must
be imported. The Caymanians enjoy one of the
highest standards of living in the region.
National product: GDP— exchange rate
conversion — $670 million (1991 est.)
National product real growth rate; 4.4%
(1991)
National product per capita: $23, (XX) (1991
est.)
Inflation rate (consumer prices); 1 .5%
(1992 est.)
Unemployment rate: 7% (1992)
Budget;
revenues: $141.5 million
e.spenditurcs; $160.7 million, including capital
expenditures of SNA (1991 )
Exports: $2,6 million (f.o.b.. 1991 est.)
commodities: turtle products, manufactured
consumer goods
partners: mostly US
Imports: $262.2 million (c.i.f.. 1991 est.)
commodities: foodstuffs, manufactured goods
partners: US, Trinidad and Tobago. UK.
Netherlands Antilles, Japan
External debt: $ 1 5 million ( 1986)
Industrial production: growth rate NA%
Electricity;
<«/«Kfry.- 74,000 kW
production: 256 million kWh
consumption per capita: 8.780 kWh (1992)
Industries: tourism, banking, insurance and
finance, construction, building materials,
furniture making
Agriculture: minor production of vegetables,
fruit, livestock; turtle farming
Illicit drugs; a major money-laundering
center for illicit drug profits; transshipment
point for cocaine and marijuana bound for the
US and Europe
Economic aid:
recipient: US commitments, including Ex-Im
(FY70-89), $26.7 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $35 million
Currency: 1 Caymanian dollar (Cl$) = 100
cents
Exchange rates; Caymanian dollars (CI$) per
US$1— 0.85 (22 November 1993)
Fiscal year: 1 April — 3 1 March','b7e7ab08f867296e8fbcef7bb21baa15979a8fa0d3a59f19e511fc21112bd02f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f23203bab29ce4849c094379d19f4c09e5c9fad1c908043b68e1112c888ba0c2',1994,'TD','Chad','economy',220,'Overview: Subsistence agriculture, including
forestry, remains the backbone of the CAR
economy, with mote than 70% of the
population living in the countryside. In 1 990
the agricultural sector generated about 42% of
GDP. Timber accounted for about 26% of
export earnings and the diamond industry for
54%. Important constraints to economic
development include the CAR''s landlocked
position, a poor transportation system, and a
weak human resource base. Multilateral and
bilateral development assistance, particularly
from France, plays a major role in providing
capital for new investment.
National product: GDP — purchasing power
equivalent — $2,5 billion ( 1993 est.)
National product real growth rate: -3%
(1990 est,)
National product per capita: $800 ( 1 993
est,)
Inflation rate (consumer prices): -3% ( 1 990
est.)
Unemployment rate: 30% (1988 est.) in
Bangui
Budget:
revenues: $175 million
expenditures: $312 million, including capital
expenditures of $ 1 22 million ( 1 99 1 est. )
Exports: $123.5 million (f.o.b.l992)
commodities: diamonds, cotton, coffee,
timber, tobacco
partners: France, Belgium, Italy, Japan, US
Imports: $165.1 million (f.o.b.l992)
commodities: food, textiles, petroleum
products, machinery, electrical equipment,
motor vehicles, chemicals, pharmaceuticals,
consumer goods, industrial products
partners: France, other EC countries. Japan.','bd6f4d40281e6d0d395ee53637ce4d21b8e19a9ef7370c2378cf8248fb33a13c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc1727ffda34d6b1070e7d6e966faceaa1c02ba126ac1ae6af2d41ddcab14922',1994,'DZ','Algeria','economy',221,'External debt: $859 million (1991)
Industrial production: growth rate 4% ( 1 990
est.); accounts for 14% of GDP
Electricity;
capacity: 40,000 kW
production; 95 million kWh
consumption per capita: 30 kWh (1991)
Industries: diamond mining, sawmills,
breweries, textiles, footwear, assembly of
bicycles and motorcycles
Agriculture: accounts for 42% of GDP;
self-sufficient in food production except for
grain; commercial crops— cotton, coffee.
tobacco, timber; food crops — manioc, yams,
millet, com, bananas
Economic aid;
rci ipient: US commitments, including Ex-Im
(F Y70-90), $52 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-90), $1.6 billion; OPEC
bilateral aid (1979-89), $6 million; Communist
countries (1970-89), $38 million
Currency: 1 CFA franc (CFAF) = 100
centimes
Exchange rates: Communaule Financiere
Afficaine francs (CFAF) per US$1 — 592.05
(January 1994), 283.16 (1993), 264.69 (1992),
282.11 (1991), 272.26(1990), 319.01 (1989)
note; beginning 12 January 1994, the CFA
franc was devalued to CFAF 100 per French
franc from CFAF 50 at which it had been fixed
since 1948
Fiscal year: calendar year','b08ecc310b76d9926942d1180ab47593e33ad352a6ca6f60c10516575dd7c0a2','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9122de2e6d74bf19cbb34debc3f0b57e8af2f33c977ed46bb5b2839c29d476d7',1994,'NG','Nigeria','economy',227,'Overview: Climate, geographic remoteness,
poor resource endowment, and lack of
infrastructure make Chad one of the most
underdeveloped countries in the world. Its
economy is hobbled by political turmoil,
conflict with Libya, drought, and food
shortages. Consequently the economy has
shown little progress in recent years in
overcoming a severe setback brought on by
civil war in the late 1980s. Over 80% of the
work force is involved in subsistence farming
and fishing. Cotton is the major cash crop,
accounting for at least half of export.''. Chad is
highly dependent on foreign aid, e.specially
food credits, given chroric shortages in several
regions. The government hopes the.t discovery
of several oil deposits near Lake Chad will lead
to economic reviv.''il and a windfall in
government revenues by 2000.
National product: GDP — purchasing power
equivalent — $2.7 billion (1993 e.st.)
National product real growth rate: 8.4%
(1991 est.)
National product per capita: $500(1993
est.)
Inflation rate (consumer prices): 2%-3%
(1991 est.)
Unemployment rate: NA%
Budget;
revenues: $115 million
expenditures: $412 million, including capital
expenditures of $218 million (1991 est.)
Exports: $193.9 million (f.o.b., 1991)
commodities: cotton 48%, cattle 35%, textiles
5%, fish
partners: France, Nigeria, Cameroon
Imports: $294,1 million (f.o.b,, 1991)
coinnuulities: machinery and transportation
equipment .39%. industrial goods 20%.
petroleum products 13%, foodstuffs 9%;
note — excludes military equipment
partners: US. France, Nigeria, Cameroon
External debt: $492 million (December ! 990
est.)
Industrial production: growth rate 1 2.9%
(1989 est.); aceounts for nearly 15% of GDP
Electricity:
80
Overview: Guyana, one of the poorest
countries in the Western Hemisphere, has
pushed ahead strongly in 1991-93, at 7%
average annual growth rate. Favorable factors
include recovery in the key agricultural and
mining sectors, a more favorable atmosphere
for business initiative, a more realistic
exchange rate, a sharp drop in the inflation rate,
and the continued support of international
organizations. Serious underlying economic
problems will continue. Electric power has
been in short supply and constitutes a major
barrier to future gains in national output. The
government will have to persist in efforts to
control external debt and inflation and to
extend the privatization program.
National product: GDP — purchasing power
equivalent — $1.4 billion (1993 est.)
National product real growth rate: 8.3%
(1993 est.)
National product per capita; $ 1 ,900 ( 1 993
est.)
Inflation rate (consumer prices); 7% ( 1 993
Unemployment rate: 1 2% ( 1 992 est.)
Budget:
revenues: $121 million
expenditures: $225 million, including capital
expenditures of $50 million ( 1990 est.)
Exports; $4{X) million (f.o.b.. 1993 est.)
commodities: sugar, bauxite/alumina, rire,
shrimp, molas.ses
partners: UK 33%, US 3 1 %, Canada 9%,
France 5%, Japan 3%, (1992)
Imports: $520 ntillion (c.i.f.. 1993 est.)
commodities: manufactures, machinery,
petroleum, food
partners: US 37%, Trinidad and Tobago 13%,
UK 1 1%. Italy 8%, Japan 5% (1992)
External debt: $1.9 billion including arrears
(1992 est)
Industrial production: growth rate 1 1 %
(1991 est. ), accounts for about 1 1 % of GDP
Electricity:
capacity: 253.500 kW
production: 276 million kWh
vonsumpliim per capita: 370 kWh (1992)
Industries: bauxite mining, sugar, rice
milling, titnber. fishing (shrimp), textiles, gold
mining
Agriculture; iiiost important sector,
accounting for 25% of GDP and about half of
exports; sugar and rice are key crops;
development potential exists for fishing and
forestry; not self-sufficient in food, especially
wheat, vegetable oils, and animal products
Economic aid:
170
Overview; The oil-rich Nigerian economy
continues to be hobbled by poor
macroeconomic management that has resulted
in an average annual inflation rate of 60%, a
growing foreign debt, and a worsening balance
of payments. A deepening political crisis in
1993 has compounded the government’s
failure to reign in deficit spending, which
prevents it from reaching an agreement with
the IMF and its bilateral creditors on debt
relief. Investment in both oil and non-oil sector
industry has been undermined by corruption
and squandered on white elephant projects that
have failed to generate diversification or new
employment.
National product: GDP — purchasing power
equivalent — $95.1 billion (1993 est.)
National product real growth rate: 4. 1 %
(1992)
National product per capita: S 1 .000 ( 1 993
est.)
Inflation rate (consumer prices): 60%
(1992 est.)
Unemployment rate: 28% (1 992 est.)
Budget:
revenues; S9 billicn
expenditures: $10.8 billion, including capital
expenditures of SNA (1992 est.)
Exports: $ 1 1.9 billion (f.o.b., 1992)
commodities: oil 95%. cocoa, rubber
partners: US 54%. EC 23%
Imports: $8.3 billion (c.i.f., 1992)
commodities: machinery and equipment,
manufactured goods, food and animals
partners: EC 64%, US 10%, Japan 7%
External debt: $29.5 billion ( 1992)
Industrial production: growth rate 7.7%
(1991): accounts for 43% of GDP. including
petroleum
Electricity:
capacity; 4,740,000 kW
production: 8.3 billion kWh
consumption per capita: 70 kWh (1991)
Industries: crude oil and mining— coal, tin,
columbite: primary processing industries —
palm oil, peanut, cotton, rubber, wood, hides
and skins; manufacturing industries — textiles,
cement, building materials, food products,
footwear, chemical, printing, ceramics, steel
Agriculture: accounts for 35% of GDP and
half of labor force: inefficient small-scale
farming dominates: once a large net exporter of
food and now an importer; cash crops — cocoa,
peanuts, palm oil, rubber: food crops— com,
rice, sorghum, millet, cassava, yams;
livestock — cattle, sheep, goats, pigs; fishing
and forestry resources extensively exploited
Illicit drugs: passenger and cargo air hub for
West Africa; facilitates movement of heroin en
route from Southeast and Southwest Asia to
Western Europe and North America;
increasingly a transit route for cocaine from
South America intended for West European,
East Asian, and North American markets
Economic aid:
recipient: US commitments, including Ex-Im
(FT70-89), $705 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89). $3 billion;
Communist countries (1970-89), $2.2 billion
Currency: I naira (N) = 100 kobo
Exchange rates: naira (N) per US$ 1 — 2 1 .886
(November 1993), 17.298 (1992). 9.909
(1991), 8.038 (1990), 7.3647 (1989)
Fiscal year: calendar year
External debt: $633 million (FY92 est.)
Industrial proditctlon: growth rate -1.2
FY9 1 ; accounts 1 of GDP
Electricity:
capacity: 85,000 kW
production: 185 million kWh
consumption per capita; 45 kWh (1991)
Industries: mining (diamonds, bauxite,
rutile), small-scale manufacturing (beverages,
textiles, cigarettes footwear), petroleum
refinery
Agriculture- - counts for over 30% of GDP
and two--’ ; he laNir force; largely
subsiste. jp.s — coffee,
cocoa, pa..'' ‘ ■ - of food staple
rice meets 8i, ,■/ 1 . otrse: -ic needs; annual fish
catch averages 53,000 metric tons
Economic aid:
recipient; US commitments, including Ex-lm
(FY70-89), $161 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $848 million; OPEC
bilateral aid ( 1 979-89), $ 1 8 million;
Communist countries (1970-89), $101 million
Currency: I leone (Le) = 100 cents
Exchange rates: leones (Le) per
US$ 1 —578. 1 7 (January 1994). 567.46 ( 1993),
499.44 ( 1 992), 295 .34 ( 1 99 1 ), 1 44.9275
(1990). 58.1395 (1989)
Fiscal year; 1 July — .30 June','07e7cba2acfc369e26f3f2fe70fea84adf6d751d503189a78d6515c9a8d812e0','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20b0c3ed52db95bcc728d51dc491cbbda959b5d0367f127ca90e1e90a65c32b2',1994,'CL','Chile','economy',228,'capai. ity: 40,000 kW
production: 70 million kWh
consumption per capita: 1 5 kWh (1991)
Industries: cotton textile mills,
slaughterhouses, brewery, natron (sodium
carbonate), soap, cigarettes
Agriculture: accounts for about 45% of GDP:
largely subsistence farming; cotton most
important cash crop; food crops include
sorghum, millet, peanuts, rice, potatoes,
maniac; livestock — cattle, sheep, goats,
camels; self-sufficient in food in years of
adequate rainfall
Economic aid:
recipient: US commitments, including Ex-Im
(FY70-89), $198 million: Western (non-US)
countries. ODA and (X)F bilateral
commitments (1970-89), $1.5 billion; OPEC
bilateral aid (1979-89), $28 million;
Communist countries (1970-89). $80 million
Currency: I CFA franc (CFAF) = 100
centimes
Exchange rates: Communaute Financiere
Africaine Francs (CFAF) per US$1 — 592.05
(January 1994), 283.16 (199,1), 264.69 (1992),
282.11 (1991), 272.26 (1990), 319.01 (1989)
note: beginning 12 January 1994 the CFA
franc was devalued to CFAF 100 per French
franc from CFAF 50 at which it had been fixed
since 1948
Fiscal year: calendar year','a3d8e4a20fe95e99542b98ba18058a5e06b531123fd120574152934f481d7bb4','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd097a9539ec8d97a481b3b4da3374473fbc9d762983fc1ad852afa91c6ef3e6',1994,'CN','China','economy',240,'Overview: Beginning in late 1978 the
Chinese leadership has been trying to move the
economy from the sluggish Soviet-style
centrally planned economy to a more
productive and flexible economy with market
elements, but still within the framework of
monolithic Communist control. To this end the
authorities switched to a system of household
responsibility in agriculture in place of the old
collectivization, increased the authority of
local officials and plant managers in industry,
permitted a wide variety of small-scale
enterpri.se in services and light manufacturing,
and opened the economy to increased foreign
trade and investment. The result has been a
strong surge in production, particularly in
agriculture in the early 198^s. Industry also has
posted major gains, especially in coastal areas
near Hong Kong and opposite Taiwan, where
foreign investment atid modern production
methods have helped spur prtKluction of both
domestic and export goods. Aggregate output
has more than doubled since 1978. On the
darker side, the leadership has .often
experienced in its hybrid sy.stem the wor.st
results of socialism (bureaucracy, lassitude,
corruption) and of capitalism (windfall gains
and stepped-up inflation). Beijing thus has
periodically backtracked, retightening central
controls at intervals. In 1992-93 annual growth
of GDP has accelerated, particularly in the
coastal ureas — to more than 10% annually
according to official claims. In late 1993
China''s leadership approved additional
reforms aimed at giving more play to
market-oriented institutions and at
strengthening the center''s control over the
financial system. Popular resistance, changes
in central policy, and loss of authority by rural
cadres have weakened China''s population
control program, which is essential to the
nation’s long-term economic viability.
National product: GDP — purchasing power
equivalent — $2.61 trillion (199.7 estimate
based on a 1990 figure from the UN
International Comparison Program, as
extended to 1991 and published in the World
Bank’s World Development Report 199.7; and
as extrapolated by use of official Chinese
growth statistics for 1992 and 199.7)
National product real growth rate; 1 3.4%
(1993)
National product per capita: $2.2(X) (1993
est.)
Inllation rate (consumer prices): 1 7.6%
(December 199.7 over December 1992)
Unemployment rate: 2.3% in urban areas
(1992); substantial underemployment
Budget: deficit $15.6 billion (199.7)
Exports: $92 billion (f.o.b,, 199.7)
commodities: textiles, garments, footwear,
toys, crude oil
partners: Hong Kong. US, Japan, Germany.
South Korea, Russia (1993)
Imports: $104 billion (c.i.f, 1993)
commodities: rolled steel, motor vehicles,
textile machinery, oil products
partners: Japan, Taiwan, US, Hong Ktmg,
Gemiany, South Korea (1993)
External debt; $80 billion (1993 est.)
Industrial production: growth rate 20.8%
(1992)
Electricity:
capacity; 158,690,000 kW
production; 740 billion kWh
consumption per capita; 630 kWh ( 1992)
Industries: iron and steel, coal, machine
building, armaments, textiles, petroleum,
cement, chemical fertrlizers, consumer
durables, food processing
Agriculture: accounts for 26% of GNP;
among the world’s largest producers of rice,
potatoes, sorghum, peanuts, tea, millet, barley,
and pork: commercial crops include cotton,
other fibers, and oilseeds; produces variety of
livestock products; basically self-sufficient in
food; fish catch of 13.35 million metric tons
(including fresh water and pond raised) ( 1 99 1 )
Illicit drugs: illicit producer of opium; bulk
of production is in Yunnan Province;
transshipment point for heroin produced in the
Golden Triangle
Economic aid:
donor; to less developed countries (1970-89)
$7 billion
recipient; US commitments, including Ex-lm
(FY70-87), $220.7 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-87), $13.5 billion
Currency: 1 yuan (¥)= 10 jiao
Exchange rates: yuan (¥) per US$1— 8.7000
(January 1994). 5.7620(1993), 5,5146(1992).
5.3234 (1991 ), 4.7832 (1990). 3,7651 (1989)
note; beginning 1 January 1994, the People s
Bank of China quotes the midpoint rate against
the US dollar based on the previous day’s
prevailing rate in the interbank foreign
exchange market
Fiscal year: calendar year','babfae305e06caadbb3f3222548044c53b9ed9ac690285bc0c30424701f12ef4','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd2f9f89fa607e20429b30dba6d5f081bb148575ff174d67e2fc223fd22d15da',1994,'CX','Christmas Island','economy',246,'Overview: Phosphate mining had been the
only significant economic activity, but in
December 1 987 the Australian Government
closed the mine as no longer economically
viable. Plans have been under way to reopen
the mine and also to build a casino and hotel to
develop tourism.
National product: GDP SNA
National product real growth rate: NA%
National product per capita: SNA
Inflation rate (consumer prices): NA%
Unemployment rate: NA%
Budget:
revenues: SNA
expenditures: SNA, including capital
expenditures of SNA
Exports: SNA
commodities: phosphate
partners: Australia, NZ
Imports: SNA
commodities: consumer goods
partners: principally Australia
External debt: SNA
Industrial production: growth rate NA%
Electricity:
capacity: 1 1,000 kW
production: 30 million kWh
consumption per capita: 17,800 kWh (1990)
Industries: phosphate extraction (near
depletion)
Agriculture: NA
Economic aid: none
Currency: 1 Australian dollar (SA) = 100
cents
Exchange rates: Australian dollars (SA) per
USSl— 1.4364 (January 1994), 1.4704,
(1993), 1.3600(1992), 1,2836(1991), 1,2799
(1990), 1.2618(1989)
Fiscal year; I July— 30 June','f92b2b32cef86f2ba4ddaa002367717558888cfc245d50b3dc557b26b96303a7','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8f8d995d7663fadb63374b9b2a59969f567a5c8730027331a01c875db213c6e',1994,'PF','French Polynesia','economy',248,'Overview: The only economic activity is a
tuna fishing station.
Overview: Since I %2, when France stationed
military personnel in the region, French
Polynesia has changed from a subsistence
economy to one in which a high proportion of
the work force is either employed by the
military or supports the tourist industry.
Tourism accounts for about 20% of GDP and is
a primary source of hard currency earnings.
National product: GDP — exchange rate
conversion — $1.5 billion (1993 est.)
National product real grovrih rate: NA%
National product per capita: $7,000 ( 1 993
est.)
Inflation rate (consumer prices): -0.6%
(1991)
Unemployment rate; 10% (1990 est.)
Budget;
revenues: $614 million
expenditures: $957 million, including capital
expenditures of $NA (1988)
Exports: $88.9 million (f.o.b., 1989)
139
French Polynesia (continued)
commodities: coconut products 79%. mother-
of-pearl 14%, vanilla, shark meat
partners; France 54%, US 17%. Japan 17%
Imports; $765 million (c.i.f., 1989)
commodities: fuels, foodstuffs, equipment
partners: France 53%, US 11%, Australia 6%,
NZ5%
External debt: SNA
Industrial production: growth rate NA%
Electricity:
capacity: 75,000 kW
production: 275 million kWh
consumption per capita: 1,330 kWh (1992)
Industries: tourism, pearls, agricultural
processing, handicrafts
Agriculture; coconut and vanilla plantations;
vegetables and fruit; poultry, beef, dairy
products
Economic aid:
recipient; Western (non-US) countries, ODA
and OOF bilateral commitments (1970-88),
$3.95 billion
Currency: 1 CFP franc (CFPF) = 1 00
centimes
Exchange rates: Comptoirs Francais du
Pacifique francs (CFPF) per US$1 — 107.63
(January 1994), 102.96 (1993), 96.24 (1992),
102.57 (1991), 99.00 (1990), 1 15.99 (1989);
note — linked at the rate of 18.18 to the French
franc
Fiscal year: calendar year','8b3db1f21d900e7766c19334522fa82edf0140b4c3d7c898dcb0cb2972819f16','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('462117ab3154f99aeca174b4ab0aa30897f60d565af79c3f1d717f0f96b37e52',1994,'CC','Cocos (Keeling) Islands','economy',255,'Overview; Grown throughout the islands,
coconuts are the sole cash crop. Copra and
fresh coconuts are the major export earners.
Smaii iocal gardens and fishing contribute to
the food supply, but additional food and most
other necessities must be imported from
Australia.
National product: GDP SNA
National product real growth rate: NA%
National product per capita: SNA
Inflation rate (consumer prices): NA%
Budget:
revenues: SNA
expenditures: SNA, including capital
expenditures of SNA
Exports: SNA
87
(continued)
commodities: copra
partners: Australia
Imports; SNA
commodities: foodstuffs
partners: Australia
External debt: SNA
Industrial production: growth rate NA%
Electricity:
capacity: 1,000 kW
production: 2 million kWh
consumption per capita: 2,980 kWh (1990)
Industries: copra products
Agriculture: gardens provide vegetables,
bananas, pawpaws, coconuts
Economic aid: none
Currency: 1 Australian dollar (SA) = 100
cents
Exchange rates: Australian dollars (SA) per
US$1— 1.4364 (January 1994), 1.4704(1993),
1.3600(1992), 1.2836(1991), 1.2799(1990),
1.2618(1989)
Fiscal year: 1 July — 30 June','06f0497ee4de8a60c7f43aa779a1a1969f024d6e3c4412593b2f44727a7d3dae','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7e828752c1195afc5a6f8faad498ee42891fd2e984bc852a710d58e2f685357',1994,'CO','Colombia','economy',261,'Overview: Colombia’s economic growth has
recovered steadily since 1991 as President
GAVIRIA’S sweeping economic reform
measures have taken hold. Market reforms
have included trade and investment
liberalization, labor and lax overhauls and
bureaucratic streamlining, among other things.
Furthermore, conservative fiscal and monetary
policies have helped to steadily reduce
inflation to 23% and unemployment to about
7% in 1993. The rapid development of oil,
coal, and other nontraditional industries has
help ,d offset the decline in coffee prices. A
major oi 1 find in 1 993 in eastern Colombia may
provide an extra $3 billion annually to the
economy by 1997. Increased foreign
investment and even greater domestic activity
have been hampered, however, by a
troublesome rural insurgency, a decrepit
energy and transportation infrastructure, and
drug-related violence. Agriculture also has
encountered problems in adjusting to fewer
subsidies, greater competition, and the collapse
of the international coffee agreement, which
has kept world coffee prices at near-record
lows in 1991-93. Business construction was a
leading sector in 1993. The substantial trade
deficit in 1993 was the result of a strong peso
that inhibited exports and a liberalized
government policy that spurred imports.
National pr^uct: GDP — purchasing power
equivalent — $192 billion (1993 est.)
National product real growth rate: 5.1%
( 1993 esi.)
National product per capita: $5,500 (1993
est.)
Inflation rate (consumer prices); 22.6%
(1993 est.)
Unemployment rate: 7.9% (1993 est.)
Budget;
revenues: $1 1 billion
espendiinres: $12 billion, including capital
expenditures of S2.2 billion ( 1993 est.)
Exports: S6.9 billion (f.o.K. 1992 est.)
commtHlities: petroleum, coffee, coal, bananas,
fresh cut flower
IHiriners: US 39 ( . F.C 25.7%, Japan 2.9%,
Venezuela 8.5% ( 1992)
Imports: $6.7 billion (c.i.f.. 1992 est.)
commtHlities: industrial equipment,
irensoorlation equipment, consumer gixxls,
chemicals, paper products
IHiriners: US 36% . EC 18%, Brazil 4% .
Venezuela 6.5%. Japan 8.7% ( 1992)
External debt: $17 billion ( 1992)
Industrial production; gmwth rate 2.0%
( 1 993 est. ); accounts for 2 1 % of GDP
Electricity:
caiHiciiv: 10,193.0(8) kW
priHhiction: 36 billion kWh
consumption per capita: 1.0.50 kWh ( 1992)
Industries: textiles, fiHxi pnKessing. oil,
clothing and ftXJtwear, beverages, chemicals,
metal products, cement; mining — gold. coal,
emeralds, iron, nickel, silver, salt
Agriculture; growth rate 2.7% (1993 est.)
accounts for 21 % of GDP: crops make up
two-thirds and livesUK''k one-third of
agricultural output; climate and soils permit a
wide Variety of crops, such as coffee, rice,
tobacco, com. sugarcane, ctvcoa beans,
oilseeds, vegetables; forest products and
shrimp fanning are becoming more imptmanl
Illicit drugs; illicit pnxluccr of ciKa. opium,
and cannabis; abtiut 37.100 hectares of coca
under cultivation: the world’s largest priKCssor
Colombia (continued)','41ed1a04e1393fb0becba2588203c81f92d22d87716e46ded0fcf0671d10a752','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d46601f8512049080dddc882aad28bfd59c593fa30587523080a6acfeb426246',1994,'KM','Comoros','economy',262,'of coca derivatives into cocaine in 1992;
supplier of cocaine to the US and other
international drug markets
Economic aid:
recipient: US commitments, including Ex-Im
(FY70-89), $1.6 billion; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $3.3 billion;
Communist countries (1970-89), $399 million
Currency: 1 Colombian peso (Col$) = 100
centavos
Exchange rates: Colombian pesos (Col$) per
US$1— 92 1.20 (January 1994), 863.06(1993),
759.28 (1992), 633.05 ( 1991 ), 502.26 (1990),
582.57(1989)
Fiscal year: calendar year
Overview: One of the world’s poorest
countries, Comoros is made up of several
islands that have pemr transportation links, a
young and rapidly increasing population, and
few natural resources. The low educational
level of the labor force contributes to a low
level of economic activity, high
unemployment, and a heavy dependence on
foreign grants and technical assistance.
Agriculture, including fishing, hunting, and
forestry, is the leading sector of the economy,
it contributes 4091- to GDP, employs 80% of
the labor force, and provides most of the
exports. The country is not self-sufficient in
food pnxluction. and rice, the main staple,
accounts for 90% of imports. During 1982-86
the industrial sector grew at an annual average
rate of 5.3%. but its contribution to GDP is
small. Despite major investment in the tourist
industry, which accounts for about 25% of
GDP. growth has stagnated since 1983.
sluggish growth rate of 1.5% during 1985-90
has led to large budget deficits, declining
incomes, and balance-of-payments difficulties.
Estimates for 1992 show a moderate increase
in the growth rate based on increased exports,
tourism, and government investment outlays.
Natimwl product: GDP — purchasing power
equivalent — $360 million (1993 cst.)
National product real prowth rate: 5%
(I992est.)
National product per capita: $700(1993
Cst.)
Inflation rale (consumer prices): 4% ( 1991
est.)
Unemployment rate: over 15.9% (1989)
Budprt:
revenues: $% million
expenditures: $88 million, including capital
expenditures of $33 million (1991 est.)
Exports; $21 million (f.o.b.. 1992 cst.)
comnuulities: vanilla, cloves, perfume oil,
copra, ylang-ylang
inirtners: US 5.3%. France 41%. Africa 4%.
FRG 2% (1988)
Ir''-ports: $60 million (f.o.b., 1992 est.)
conmuuhtics: rice and other fotxistuffs.
cement, petroleum pnvducts. consumer goiHls
/Mirtners: Europe 62% (France 22%). .Africa
5% . Pakistan. China (1988)
External debt: $160 million (1992 est.)
Industrial production: growth rate -6.5%
( 1989 est ); accounts for l()<;f of GDP
Electricity:
i u(Hicity: 16,000 kW
priHluclion: 25 million kWh
consumption /ter capita: .50 kWh ( 1991 )
Industries: perfume distillation, textiles,
furniture, Jewelry, construction materials, soft
drinks
Agriculture: accounts for 40% of GDP; most
of population works in subsistence agriculture
and fishing; plantations produce cash crops for
export — vanilla, cloves, perfume essences,
copra: principal food crops — coconuts,
bananas, cassava: world’s leading producer of
essence of ylang-ylang (for perfumes) and
.second-largest pr^ucer of vanilla; large net
food importer
Economic aid:
recipient: US commitments, including Ex-lm
(FY80-89), $10 million: Western (non-US)
countries, ODA and OOF bilateral
commitments ( 1970-89), $435 million: OPEC
bilateral aid ( 1979-89), $22 million:
Communist countries (1970-89). $18 million
Currency: I Comoran franc (CF) = 100
centimes
Exchange rates: Comoran francs (CF) per
US$1— 444.03 (January 1994). 2.54.57 ( 1993).
264.69 (1992). 282.1 1 ( 1991 ). 272.26 ( 1990).
319.01 (1989)
note: beginning 12 January 1 994. the Comoran
franc was devalued to 75 per French franc from
50 per French franc at which it had been fixed
since 1948
Fiscal year: calendar year','9e341d9f255e3fb1eb484e21bf6b911a4229432624ceadd6193d0f4529bc2406','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29a06e3f88e8408a48e0bb83f92900ae567eeb5127163507a99cd932062650a5',1994,'ET','Ethiopia','economy',271,'Overview: Congo''s economy is a mixture of
village agriculture and handicrafts, an
industrial sector based largely on oil, support
services, and a government characterized by
budget problems and overstaffing. A reform
program, supported by the IMP and World
Bank, ran into difficulties in 1990-91 because
of problems in changing to a demiK''ratic
political regime and a heavy debt-sersicing
burden. Oil has supplanted forestry as the
mainstay of the economy, providing about
two-thiids of government revenues and
exports. In the early I980s rapidly rising oil
revenues enabled Congo tv) finuiK''e large-scale
development projects with growth averaging
5cf annually, one of the highest rales in Africa.
Subsequently, growth has slowed to an average
of rxHighIv 1 .5''''('' annually, only half (he
population growth rale. Political turmoil and
misguided government investment have
derailed economic reform programs sponstired
hy the IMF and Wwld Bank.
NalkHial praduct: GDP —purchasing power
equivalent — $7 billion ( 1993 esi.t
NaHoral product ml growth rale: NA
NalkMUd product per capita: $2.9011(1993
est.)
Inflation niir tcomumer priccsi: -O.b''i
(1991 est.)
I''ncmploymenl rale: NA''f
Budget:
revenues: $765 million
expenditures: $952 million, including capital
expenditures of $65 million ( I990i
FAportn: $1.1 billion (f.o.b. 1990)
comiiuHlities: crude oil 72*7. lumber, ply wihhI.
coffee, c(X''oa. sugar, diamonds
partners I''S. France, other EC countries
Importi: $704 million (c. i f.. I990i
commodities: fiMxIstuffs. consumer gixxis.
intermediate manufactures, capital equipment
ptirtners: France. Germany. Italy, Spain, other
EC countries. CS. Japan. Brazil
External deM: $4. 1 billion ( 1991 1
Industrial production: growth rate 1. 2*3
( 1989); accounts for 33‘t of GDP; includes
petroleum
Electricity:
capacity : 1 40.000 kW
production: 3 1 5 million kWh
consumption per capita: 1 35 kWh (1991)
Industries; petroleum, cement, lumbering,
brewing, sugar milling, palm oil. soap,
cigarette
Agriculture: accounts for 13% of GDP
(including fishing and forestry); cassava
accounts for 90^ of food output; other crops —
rice. com. peanuts, vegetables; cash crops
include coffee and cocoa: forest products
important export earner; imports over 90% of
fo(jd needs
Economic aid:
recipient: US commitments, including Ex-lm
(FY70-90). $63 million; Western (non-US)
countries, ODA and OOF bilateral
commitments ( 1970-90), $2.5 billion: OPEC
bilateral aid ( 1979-89). $15 million;
Communist countries (1970-89), $338 million
CurreiKy: 1 CFA franc (CFAF) = 100
centimes
Excliange rates: Communaute Financiere
Africaine francs (CFAF) per US$1 — 592.05
(January 1994). 28''<. 16 ( 1993). 264,69 (1992).
282 II (1991). 272.26 (1990). 3 1 9.0 1 (1989)
«(>(< iieginning 12 January 1994. the CFA
franc was devalued to CFAF 100 per French
franc fix»m CFAF ,50 at which it had been fixed
since 1948
Fiscal ,vear: calendar year
Overview: With independence from Ethiopia
on 27 April 1993. Eritrea faces the bitter
economic problems of a small, desperately
poor African country. Most of the population
will continue to depend on subsistence
fanning. Domestic output is substantially
augmented by worker remittances from
abroad. Government revenues come from
custom duties and income and sales taxes.
Eritrea has inherited the entire coastline of
Ethiopia and has long-term prospects for
revenues from the development of offshore oil,
offshore fishing and tourism. For the time
being, Ethiopia will be largely dependent on
Eritrean ports for its foreign trade.
National product: GDP — purchasing power
equivalent — SI. 7 billion (1993 est.)
National product real growth rate: NA%
National product per capita: $500(1993
est.)
Inflation rate (consumer prices): NA%
Unemployment rate: NA%
123
Eritrea (continued)','2e8b64a37e363d26874ec76b39159520a097d021531d6383add824f7574bdde8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5ca50dec20010b4dfc0ff9c148c6d3dd31d0fdb1f353051f381c426eb3ab052',1994,'CK','Cook Islands','economy',278,'Overview: Agriculture provides the
economic base. The major export earners are
fruit, copra, and clothing. Manufacturing
activities are limited to a fruit-processing plant
and several clothing factories. Economic
development is hindered by the isolation of the
islands from foreign markets and a lack of
natural resources and good transportation
links. A large trade deficit is annually made up
for by remittances from emigrants and from
foreign aid, largely from New Zealand, Current
economic development plans call for
exploiting the tourism potential and expanding
the Fishing industry.
National product: GDP — purchasing power
equivalent — $57 million (1993 est.)
National product real growth rate; NA%
National product per capita; $3,CXX) ( 1993
est.)
Inflation rate (consumer prices): 6.2%
(1990)
Unemployment rate: NA%
Budget:
revenues: $38 million
expenditures: $34.4 million, including capital
expenditures of $NA (1993 est.)
Exports: $3.4 million (f.o.b,, 1990)
commodities: copra, fresh and canned fruit,
clothing
partners: NZ 80%, Japan
Imports: $50 million (c.i.f., 1990)
commtxlities: food.stuffs, textiles, fuels, timber
partners: NZ 49%. Japan, Australia. US
External debt: $NA
Industrial production; growth rate NA%:
94
Coral Sea Islands
( territory of Australia)
accounts for 5% of GDP
Electricity:
capacity: 14,000 kW
production; 21 million kWh
consumption per capita: 1 , 1 70 kWh ( 1 990)
Industries: fniit processing, tourism
Agriculture: accounts for 12% of GDP,
export crops — copra, citrus fruits, pineapples,
tomatoes, bananas; subsistence crops — yams,
taro
Economic eld:
recipient: Western (non-US) counuies, ODA
and OOF bilateral commitments (1970-89),
$128 million
Currency: I New Zealand dollar (NZ$) = 1 00
cents
Exchange rates: New Zealand dollars (NZ$)
per US$1— 1.7771 (January 1994), 1.8495
(1993), 1.8584(1992), 1.7265(1991), 1,6750
(1990), 1,6708(1989)
Fiscal year: I April — 31 March','be26c81b35ec0c9e15e39376be6e2892da0f284664a708979c42229e2a3a50bc','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b90e8778974e736fcf61d937499185eb9a8507f0e240fefed6c2cdb3a07e31c',1994,'CR','Costa Rica','economy',284,'Overview: Cote d''Ivoire is among the world''s
largest producers and exporters of coffee,
cocoa t«ans, and palm-kernel oil.
Consequently, the economy is highly sensitive
to fluctuations in international prices for coffee
and cocoa and to weather conditions. Despite
attempts by the government to diversify, the
economy is still largely dependent on
agriculture and related industries. The
agricultural sector accounts for over one-third
of GDP and about 80% of export earnings and
employs about 85% of the labor force. A
collapse of world cocoa and coffee prices in
1986 threw the economy into a recession, from
which the country has yet to fully recover.
Continuing weak prices for commodity
exports, a bloated public-sector wage bill, and
a large foreign debt will continue to constrain
economic development, this despite the 50%
currency devaluation in Januaiy 1 994 designed
to restore international price competitiveness.
A large, noncompetitive import-substitution
sector continues to thrive under steep tariff and
import quota barriers.
Natiorwl product; GDP — purchasing power
equivalent — $21 billion (1993 est.)
National product real growth rate: NA
National product per capita; $1,500 (1993
est.)
Inflation rate (consumer prices): 1 % ( 1 99 1
est.)
Unemployment rate: 1 4% ( 1 985)
Budget:
revenues: $2.3 billion
expenditures: $3.6 billion, including capital
expenditures of $274 million (1990 est.)
Exports: $2.8 billion (f.o.b., 1990)
commodities: cocoa 30%, coffee 20%, tropical
woods 1 1 %, petroleum, cotton, bananas,
pineapples, palm oil. cotton
partners: France, FRG, Netherlands, US,
Belgium, Spain (1985)
Imports: $1.6 billion (f.o.b., 1990)
commodities: food, capital goods, consumer
goods, fuel
partners: France 29%, other EC 29%, Nigeria
16%. US 4%, Japan 3% (1989)
External debt: $17.3 billion (1993 est.)
Industrial production: growth rate 6%
(1990); accounts for 11% of GDP
Electricity:','9b146152ffa0144038d8e771681ef01f9d46f77c33aa3647c77570bb3e59426d','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a9bfbd667e268ce767fc03ae0b2bde069b74314677cd3f61143297492cd7070',1994,'HR','Croatia','economy',285,'capacity: 1,210,000 kW
production: 1.97 billion kWh
consumption per capita: 1 50 kWh (1991)
Industries: foodstuffs, wood processing, oil
refinery, automobile assembly, textiles,
fertilizer, beverage
Agriculture: most imponant sector,
contributing one-third to GDP and 80% to
exports; cash crops include coffee, cocoa
beans, timber, bananas, palm kernels, rubber;
food crops — com, rice, manioc, sweet
potatoes; not self-sufficient in bread grain and
dairy products
Illicit drugs: illicit producer of cannabis;
mostly for local consumption; some
international drug trade; transshipment poii.t
for Southwest and Southeast Asian heroin to
Europe and occasionally to the US
Economic aid:
recipient: US commitments, including Ex-Im
(FY70-89), $356 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-88), $5.2 billion
Currency: 1 CFA franc (CFAF) = 100
centimes
Exchange rates: Communaute Financiere
Africaine francs (CFAF) per US$1 — 592.05
(January 1 994), 283. 1 6 ( 1 993), 264.69 ( 1 992),
282.11 (1991), 272.26 (1990), 319.01 (1989)
note: beginning 12 January 1994, the CFA
franc was devalued to CFAF 100 per French
franc from CFAF 50 at which it had been fixed
since 1948
Fiscal year; calendar year
Overview: Before the dissolution of
Yugoslavia, the republic of Croatia, after
Slovenia, was the most prosperous and
industrialized area, with a per capita output
roughly comparable to that of Portugal and
perhaps one-third above the Yugoslav average.
At present. Croatian Serb Nationalists control
approximately one third of the Croatian
territory, and one of the overriding
determinants of Croatia''s long-term political
and economic prospects will be the resolution
of this territorial dispute. Croatia faces
monumental economic problems stemming
from: the legacy of longtime Communist
ntisinanagement of the economy; large foreign
debt; damage during the fighting to bridges,
factories, power lines, buildings, and houses:
the large refugee population, both Croatian and
Bosnian; and the disruption of economic ties to
Serbia and the other former Yugoslav
republics, as well as within its own territory. At
the minimum, extensive Western aid and
investment, especially in the tourist and oil
industries, would seem necessary to salvage a
desperate economic situation. However, peace
and political stability must come Ursl; only
then will recent government moves toward a
"market-friendly" economy reverse the sharp
drop in output. As of May 1994. fighting
continues among Croats, Serbs, and Muslims,
and national boundaries and final political
arrangements are still in doubt.
National product: GDP — purchasing power
equivalent — $21.8 billion (1992 est.)
National product real growth rate: - 1 9%
(1992 est.)
National product per capita: S4,5(X) (1992
est.)
I(X)','f2837e2eee3861fe19491b0c334bb7c340ab14be564f2c830ed17079127e7b62','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('701cea6f9a877e61a51c3aa339afe45e8efa226e994eb9e139081c40ab5714eb',1994,'CU','Cuba','economy',291,'Inflation rate (consumer prices): 26%
monthly average (1993 est.)
Unemployment rate: 21% (December 1993)
Budget:
revenues; SNA
expenditures: SNA. including capital
expenditures of SNA
Exports: S3.9 billion (f.o.b., 1993)
commodities: machinery and transport
equipment 30%, other manufacturers 37%,
chemicals 1 1 %, food and live animals 9%, raw
materials 6.5%, fuels and lubricants S% ( 1 990)
partners; EC countries, Slovenia
Imports: S4.7 billion (c.i.f., 1993)
commodities: machinery and transport
equipment 21%, fuels and lubricants 19%,
fo^ and live animals 16%, chemicals 14%,
manufactured goods 13%, miscellaneous
manufactured articles 9%, raw materials 6.3%,
beverages and tobacco 1% (1990)
partners: EC countries, Slovenia, FSU
countries
External debt: $2.6 billion (December 1993)
Industrial production: growth rate -3.9%
(1993 est.)
Electricity:
capacity; 3,370,000 kW
production: 1 1 .5 billion kWh
consumption pe- capita: 2,400 kWh (1992)
Industries; chemicals and plastics, machine
tools, fabricated metal, electronics, pig iron
and rolled steel products, aluminum reduction,
paper, wood products (including furniture),
building materials (including cement), textiles,
shipbuilding, petroleum and petroleum
refining, food processing and beverages
Agriculture: Cro.-itia normally produces a
food surplus; most agricultural land in private
hands and concentrated in Croat-majority
districts in Slavonia and Istria; much of
Slavonia''s land has been put out of production
by fighting; wheat, corri, sugar beets,
sunflowers, alfalfa, and clover are main crops
in Slavonia; central Croatian highlands are less
fertile but support cereal production, orchards,
vineyards, livestock breeding, and dairy
farming; coastal areas and offshore islands
grow olives, citrus fruits, and vegetables
Economic aid: SNA
Currency: 1 Croatiandinar(CD)s lOOparas;
a new currency, the kuna, replaced the dinar on
30 May 1994
Exchange rates: Croatian dinar per US$1 —
6,344 (January 1994), 3,637 (13 July 1993),
60.00 (April 1992)
Fiscal year: calendar year
Communlcatioiu
Railroads: 2,392 km of standard guage ( 1 .435
m) of which 864 km are electrified (1992);
note — disrupted by territorial dispute
Highways:
total: 32,07 1 km
paved; 23,305 km
unpaved: gravel 8,439 km; earth 327 km
(1990)
Inland waterways: 783 km perennially
navigable
Pipelines; crude oil 670 km. petroleum
products 20 km, natural gas 310 km (1992);
note — now disrupted because of territorial
dispute
Ports: coastal — Omisalj (oil), Ploce, Rijeka,
Split; inland — Osijek. Slavonski Samac,
Vukovar, Zupanja
Merchant nurine: 28 ships (1 ,000 CRT or
over) totaling 108,194 GRT/131.880 DWT,
cargo 1 8, roll-on/roll-off cargo 2, short-sea
passenger 3, passenger 2, refrigerated cargo 1 ,
container I, oil tanker 1
note: also controlled by Croatian shipowners
are 1 3 1 ships ( 1 ,000 CRT or over) under flags
of convenience — primarily Malta and St.
Vincent— totaling 2.221,931 GRT/3.488,263
DWT; includes cargo 60, roll-on/ roll-off 8,
refrigerated cargo 4, container 12,
multifunction large load carriers 3, bulk 43. oil
tanker 9, liquified gas I, chemical tanker 4,
service vessel 3
Airports:
total: 75
usable: 70
with permanent-surface runways: 16
with runways over 3,659 m; 0
with runways 2,440-3,659 m: 7
with runways 1,220-2,439 m; 5
Telecommunications: 350,000 telephones;
broadcast stations — 14 AM, 8 FM, 12 (2
repeaters) TV; 1,100,000 radios; 1,027,000
TVs; satellite ground stations — none
Defense Forces
Branches: Ground Forces, Naval Forces, Air
and Air Defense Forces
Manpower availability: males age 15-49
1 , 1 82,767; fit for military service 946,010;
reach military age (19) annually 33,166 (1994
est.)
Defense expenditures: 337-393 billion
Croatian dinars, NA% of GDP (1993 est.);
note — conversion of defense expenditures into
US dollars using the current exchange rate
could produce misleading results
J«>!B
Str0it$
of florid*
u $ nwbI Bnt
Caribbean Saa cub« oiwimmo bv
Overview: Cuba’s heavily statist economy
remains in a severe depression as a result of the
loss of massive amounts of economic aid from
the former Soviet Bloc. In 1989-93, GDP
declined by about 40% and import capability
fell by about 80%. Reduced imports of fuel,
spare parts, and chemicals combined with rainy
weather to cut the production of sugar — the
country''s top export — from 7 million tons in
1992 to 4.3 million tons in 1993. causing a loss
of more than $400 million in export revenue.
The government implemented several
measures designed to stem the economic
decline, e.g., legalizing the use of foreign
currency by Cuban citizens in August 1993 in
an attempt to increase remittances of foreign
exchange from abroad. Authorities in
September 1993 began permitting self-
employment in over 100 mostly service
occupations. Also in September the
government broke up many state farms into
smaller, more autonomous cooperative units in
an attempt to increase worker incentives and
boost depressed food production levels. Fuel
shortages persisted throughout 1993; draft
animals and bicycles continued to replace
motor-driven vehicles, and the use of
electricity by households and factories was cut
from already low levels. With tiie help of
foreign investment, tourism has been one
bright spot in the economy, with arrivals and
earnings reaching record highs in 1993.
Government officials have expressed guarded
optimism for 1994, as the country struggles to
achieve sustainable economic growth at a
much-reduced standard of living.
National product: GNP — purchasing power
equivalent — $13.7 billion (1993 est.)
National product real growth rate: -10%
(1993 est.)
National product per capita: $ 1 ,250 ( 1 993
est.)
Inflation rate (consumer prices): NA%
Unemployment rate: NA%
Budget:
revenues: $12.46 billion
expenditures: $14.45 billion, including capital
expenditures of $NA (1990 est.)
Exports: $1.5 billion (f.o.b., 1993 est.)
commodities: sugar, nickel, shellfish, tobacco,
medical products, citrus, coffee
partners: Russia 28%, Canada 9%, China 5%,
Ukraine 5%, Japan 4%, Spain 4% (1993 est.)
Imports: $1.7 billion (c.i.f., 1993 est.)
commodities: petroleum, food, machinery,
chemicals
partners: Venezuela 20%, China 9%, Spain
9%, Mexico 7%, Italy 4%, Canada 7%, France
8% (1 993 est.)
External debt: $6.8 billion (convertible
currency, July 1989)
102','e6624b17fc4edc64310d26ee5495c0818ac58f8a5be73f6371a6f3e81329e57b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('866ec879da9f41b9b985d636155dfa6deaebe43cc19b115148722337ed04c3aa',1994,'CY','Cyprus','economy',296,'Industrial production: NA
Electricity:
capacity: 3,889,000 kW
pnduction: 16.248 biliion kWh
consumption per capita: 1,500 kWh ( 1992)
Industries: sugar milling and refining,
petroleum refining, food and tobacco
processing, textiles, chemicals, paper and
wood products, metals (particularly nickel),
cement, fertilizers, consumer goods,
agricultural machinery
Agriculture: accounts for 1 1 % of GNP
(including fishing and forestry); key
commercial crops — sugarcane, tobacco, and
citms fruits; other products — coffee, rice,
potatoes, meat, beans; world''s largest sugar
exporter; not self-sufficient in food (excluding
sugar); .sector hurt by growing shortages of
fuels and parts
Illicit drugs: transshipment point for cocaine
bound for the US
Economic aid:
recipient: Western (non-US) countries. ODA
and OOF bilateral commitments ( 1970-89),
$7 10 million; Communist countries (1970-89),
$18.5 billion
Currency: I Cuban peso (CuS) s 100
centavos
Exchange rates: Cuban pesos (CuS) per
US$1— 1.0000 (non-convertible, official rate,
linked to the US dollar)
Fiscal year: calendar year
Overview; The Greek Cypriot economy is
small, diversified, and prosperous. Industry
contributes 169^ to GDP and employs 29% of
the labor force, while the service sector
contributes 60% to GDP and employs 57%- of
the labor force. An average 6.8%- rise in real
GDP between 1986 and 1990 was temporarily
checked in 1991, because of the adverse effects
of the Gulf War on tourism. Economic growth
surged again in 1992. bolstered by strong
foreign and domestic demand. As the economy
gained momentum, however, it began to
overheat; inflation reached 6.5%. The
economy has likely recorded a sharp drop in
growth in 1 99.5, due to the recession in Western
Europe. Cyprus'' main trading partner, but
probably will pick up again in 1994. The
Turkish Cypriot economy has less than one-
third the per capita GDP in the south. Because
it is recognized only by Turkey, it has had
much difficulty arranging foreign financing,
and foreign firms have hesitated to invest there.
The economy remains heavily dependent on
agriculture, which employs more than one-
quarter of the workforce. Moreover, because
the Turkish lira is legal tender, the Turkish
Cypriot economy has suffered the same high
inflation as mainland Turkey. To compensate
for the economy''s weaknes.s. Turkey provides
direct and indirect aid to nearly every sector;
financial support has reached about one-third
of Turkish Cypriot GDP.
National pr^uct:
Greek area: GDP — purchasing ptwer
equivalent — $6,7 billion (1992)
Turkish area: GDP— purchasing power
equivalent — $550 million (1992)
National product real growth rate:
Greek area: 8.2% (1992)
Turkish area: 7.5% (1992)
National product per capita:
Gree/tflr«(; $11,590 (1992)
Turkish area: $5, 1 50 ( 1 992)
Inflation rate (consumer prices):
Greek area: 6.5% (1992)
Turkish area: 65.4% (1992)
Unemployment rate:
Greek area: 1.8% (1992)
Turkish area: 1.2% (1992)
Budget:
revenues: Greek area — $1.7 billion
Turkish area — $275 million
expenditures: Greek area — $2.2 billion.
including capital expenditures of $550 million
Turkish area — $560 million, including capital
expenditures of $78 million (1994)
Exports: $1.1 billion (f.o.b.. 1995 est.)
commodities: citrus, potatoes, grapes, wine,
cement, clothing and shoes
partners: UK 19%. Greece 8%, Lebanon 2%,
Egypt 7%
Imports: $5.5 billion (f.o.b., 1995 est.)
commodities: consumer goods, petroleum and
lubricants, food and feed grains, machinery
partners: UK 1 1%, Japan 1 1%, Italy 10%.
Germany 9%. US 8%
External debt: $1.6 billion ( 1992)
Industrial production; growth rate 4.0%
( 1995 est.); accounts for 16.0% of GDP
Electricity:
capacity: 620,000 kW
production: 1 .77 billion kWh
consumption per capita: 2,550 kWh ( 1991 )
Industries: food, beverages, textiles,
chemicals, metal products, tourism, wood
products
Agriculture: contributes 7% to GDP and
employs 26% of labor force in the south; major
crops — potatoes, vegetables, barley, grapes,
olives, citrus fruits; vegetables and ,iuit
provide 25% of export revenues
Illicit drugs: transit point for heroin via air
routes and container traffic to Europe,
especially from Lebanon and Turkey
Eronomic aid:
recipient: US commitments, including Ex-Im
(FY70-89). $292 million; Western (non-US)
countries, ODA and OOF bilateral
commitments ( 1970-89), $250 million; OPEC
bilateral aid ( 1979-89), $62 million;
Communist countries (1970-89). $24 million
Currency; I Cypriot pound (£C) = 1 00 cents;
I Turkish lira (TL) = 100 kurus
Exchange rates: Cypriot pounds (£C) per
$US I— 0.5148 (December 1995), 0.4970
(1995), 0.4502 ( 1 992 ), 0.46 1 5 ( 1 99 1 ). 0.4572
(1990), 0.4955 (1989); Turkish liras (TL) per
US$1— 15.196.1 (January 1994), 10.985.5
( 1 995 ). 6.872.4 ( 1992). 4, 1 7 1 .8 ( 1 99 1 ).
2,608.6(1990). 2.121.7(1989)
Fiscal year: calendar year
Overview; The dissolution of Czechoslovakia
into two independent nation states— the Czech
Republic and Slovakia — on 1 Januaiy 1903 has
complicated the task of mo''. ing toward a more
open and decentralized economy. The old
Czechoslovakia, even though highly
industrialized by East European standards,
suffered from an aging capital plant, lagging
technology, and a deftciency in energy and
many taw m.''v.erials. In January 1991.
approsimaiely one year after the end of
communist control of Eastern Europe, the
Czech and Slovak Federal Republic launched a
sweeping program to convert its almost
entirely state-owned and controlled economy
to a market system. In 1 99 1 -92 these measures
resulted in privatization of some medium- and
small-scale economic activity and the setting
of more than 90*^ of prices by the market— but
at a cost in inflation, unemployment, and lower
output. For Czechoslovakia as a whole
inflation in 1991 was roughly .30% and tnitpui
fell 15%. In 1992. in the Czech lands, inflation
dropped to an estimated 12.5% and GDP was
down a more moderate 5% . In 1993. Czech
aggregate output remained unchanged, prices
rose about 19%, and unemployment hovered
above 3%: exports to Slovakia fell roughly
.30%, An estimated 40% of the economy was
privately owned. In 1994. Prague expects 2%
to 3% growth in GDP, roughly 9^ inflation,
and 5% unemployment. Economic growth in
1994 is less important than continued
economic restructuring; a mere I % growth
would be noteworthy if restructuring is
accompanied by rising unemployment and
enterprise bankruptcies.
Nalk''^nal praduct: GDP — purchasing power
equivalent— $75 billion (199.3 esi.)
NaUomtl product real growth rate: 0%
(1993 est.)
NatloiMl product per capita: $7,200(199.3
est.)
Inflation rate (eomumer prim): 19%
(1993 est.)
Unemptoymenl rate: 3.3% ( 1993 est.)
Budget:
revenues: $1 1.9 billion
exiiendiiures: $ 1 1 .9 billion, including capital
expenditures of SNA (1993 est.)
Exports: $ 1 2.6 billion (f.o.b.. 199.3 est.)
commodities: manufactured goods, machinery
and transport equipment, chemicals, fuels,
minerals, and metals
Itartners: Germany. Slovakia. Poland. Austria.
Hungary. Italy. France. US. UK. CIS republics
Imports; $12.4 billion (f.o.b.. 1993 est.)
commodities: machinery and transport
equipment, fuels and lubricants, manfactured
gixtds. raw materials, chemicals, agricultural
pnxlucts
IHirtners: Slovakia. CIS republics. Germany.
Austria. Poland. Switzerland. Hungary. UK.','ebb4a6793f0a5e6c4e7e6490e437553a3e1b9f0d65d5e0085bae1c91201c84ae','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f93a72efd770ed15846ce12e8c3b42a093fda2343b1456f8962d0eca392ac139',1994,'IT','Italy','economy',302,'External debt: $8.6 billitm (October 199.3)
Industrial production: growth rate -5.5%
(December 1993 over December 1992)
Eleclrkity:
capacity: l6..3()(),000kW
production: 62.2 billion kWh
consumption per capita: 6.0.30 kWh ( 1 992 )
Industries: fuels, ferrous metallurgy,
machinery and equipment, coal, motor
vehicles, glass, armaments
Agriculture: largely self-sufflcient in ftxKi
production; diversified crop and livestock
production, including grains, potatoes, sugar
beets, hops, fruit, hogs, cattle, and poultry;
exporter of forest products
Illicit drugs: transshipment point for
Southwe.st Asian heroin and Latin American
ciK''aine to Western Europe
Economic aid:
donor: the fonner Czechoslovakia was a
donor— $4.2 billion in bilateral aid to non-
Communist less developed countries ( 19.34-
89)
Currency: I koruna (Kc)= 100 haleru
Exchange rates: koruny (Kes) per US$1 —
.30,122 (January 1994), 29.153 ( 1993). 28.26
(1992). 29..33 (1991), 17.95 (1990), 15,05
(1989)
note: values before 1 993 retied Czechoslovak
exchange rates
Fiscal year: calendar year
Communkatiom
Railroads: 9.4.34 km total (1988)
Hlghwa.va:
total: 5.3.890 km (1988)
/Hived: NA
unpaved: NA
Inland waterways; NA km; the Elbe (Labe)
is the principal river
PipcUnca; natural gas 5,400 km
Ports: coastal outlets are in Poland (Gdynia,
Gdansk, Szczecin), Croatia (Rijeka), Slovenia
(Koper). Germany (Hamburg, Rostock);
principal river ports are Prague on the Vltava.
Decin on (he Elbe (Labe)
Merchant marine: 1 8 ships ( 1 ,000 GRT or
over) totaling 225.9.34 GRT/.3.30..3.30 DWT.
cargo 1 1. bulk 7
Airports:
total: 1.35
usable: 123
will; itermanenl-surfuce runways: 27
with runways otvr .1,659 m: I
with runways 2,440-.l,659 /n; 17
with runways /, 060- 2. 4.19 m; 52
note: a C- 1 .30 can land on a 1 ,060-m airstrip
Telecommunications: NA
Defense Forces
Branches: Army. AirandAirDefense Forces.
Civil Defense. Railroad Units
Manpower availability: mules age 1 5-49
2,747.126; fit for military service 2.091.532;
reach military age (18) annually 9.s,.342 ( 1994
est.)
Defense expenditures; 23 billion koruny,
N A% of GNP ( 1 99,3 est. ); note — conversion of
defense expenditures into US dollars using the
current exchange rate could produce
misleading results
107
Overview: This unique, noncommercial
economy is supported financially by
contributions (known as Peter’s Pence) from
Roman Catholics throughout the world, the
sale of postage stamps and tourist mementos,
fees for admission to museums, and the sale of
publications. The incomes and living standards
of lay workers are comparable to. or somewhat
better than, those of counterparts who work in
the city of Rome.
Budget;
revenues: $86 million
expenditures: $178 million, including capital
expenditures of SNA (1993 e.st.)
Electricity:
capacin: 5.000 kW standby
production: power supplied by Italy
con.suinption per capita: NA (1992)
Industries: printing and production of a small
amount of mosaics and staff uniforms;
worldwide banking and financial activities
Currency: 1 Vatican lira (VLit) = 1(X)
centesimi
Exchange rates: Vatican lire (VLit) per
US$1 — 1, 700.2 (January 1994), 1,573.7
(1993), 1,2.32.4(1992), 1.240.6(1991).
1.198.1 (1990). 1,372.1 ( 1989); note— the
Vatican lira is at par with the Italian lira which
circulates freely
Fiscal year: calendar year
Electricity;
capacity: 5,835,000 kW
production: 21.84 billion kWh
consumption per capita: 4,600 kWh (1992)
Industries; food processing, diamond cutting
and polishing, textiles and apparel, chemicals,
metal products, military equipment, transport
equipment, electrical equipment,
miscellaneous machinery, potash mining,
high-technology electronics, tourism
Agriculture: accounts for about 7% of GDP;
largely self-sufficient in food production,
except for grains; principal products — citrus
and other fruits, vegetables, cotton; livestock
products — beef, dairy, poultry
Illicit drugs: increasingly concerned about
cocaine and heroin abuse and trafficking
Economic aid:
recipient: US commitments, including Ex-lm
(FY70-90), $18.2 billion; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $2.8 billion
Currency: 1 new Israeli shekel (NIS) = 100
new agorot
Exchange rates: new Israeli shekels (NIS)
per US$1— 2.9760 (February 1994), 2.8301
(1993), 2.4591 (1992), 2.2791 (1991), 2.0162
(1990), 1.9164(19891
Fiscal year: calendar year (since I January
1992)
Overview: Since World War II the Italian
economy has changed from one based on
agriculture into a ranking industrial economy,
with approximately the same total and per
capita output as France and the UK. The
country Is still divided into a developed
industrial north, dominated by private
198
companies, and an undeveloped agricultural
south, dominated by large public enterprises.
Services account for 48% of GDP, industry
35%, agriculture 4%, and public administration
13%. Most raw materials needed by industry
and over 75% of energy requirements must be
imported. After growing at an annual average
rate of 3% in 1983-90, growth slowed to about
1% in 1991 and 1992 and fell by 0.7% in 1993.
In the second half of 1992, Rome became
unsettled by the prospect of not qualifying to
participate in EC plans for economic and
monetary union later in the decade; thus it
finally began to address its huge fiscal
imbalances. Thanks to the determination of
Prime Ministers AMATO and CIAMPI, the
government adopted a fairly stringent budget
for 1993 and 1994, abandoned its highly
inflationary wage indexation system, and
started to scale back its extremely generous
social welfare programs, including pension and
health care benefits. Moneiary officials were
forced to withdraw the lira from the European
monelary system in September 1992 when it
came under extreme pressure in currency
markets. For the 1990s. Italy faces the
problems of refurbishing a tottering
communications system, curbing pollution in
major industrial centers, and adjusting to the
new competitive forces accompanying the
ongoing economic integration of the European
Union.
National product: GDP — purchasing power
equivalent — $967.6 billion (1993)
National product real growth rate: -0.7%
(1993)
National product per capita: $16,700
(1993)
Inflation rate (consumer prices): 4.2%
(1993)
Unemployment rate: 1 1.3% (January 1994)
Budget:
revenues: $302 billion
expenditures: $391 billion, including capital
expenditures of $48 billion ( 1993 est.)
Exports: $178.2 billion (f.o.b., 1992)
commodities: metals, textiles and clothing,
production machinery, motor vehicles,
transportation equipment, chemicals, other
partners: EC 58.3%. US 6.8%, OPEC 5.1%
(1992)
Imports: $188.5 billion (f.o.b., 1992)
commodities: industrial machinery, chemicals,
transport equipment, petroleum, metals, food,
agricultural products
partners: EC 58.8%. OPEC 6.1%, US 5.5%
(1992)
External debt: $67 billion (1993 est.)
Industrial production: growth rate -2.8%
(1993 est.); accounts for almost 35% of GDP
Electricity:
capacity: 58.000,000 kW
production: 235 billion kWh
consuripiion per capita: 4,060 kWh (1992)
Industries; machinery, iron and steel,
chemicals, food processing, textiles, motor
vehicles, clothing, footwear, ceramics
Agriculture: accounts for about 4% of GDP
and about 9.8% of the work force; self-
sufficient in foods other than meat, dairy
products, and cereals; principal crops — fruits,
vegetables, grapes, potatoes, sugar beets,
soybeans, grain, olives; fish catch of 525,000
metric tons in 1990
Illicit drugs: important gateway country for
Latin American cocaine and Southwest Asian
heroin entering the European market
Economic aid:
donor: ODA and (X)F commitments (1970-
89). $25.9 billion
Currency: I Italian lira (Lit) = lOOcentesimi
Exchange rates: Italian lire (Lit) per US$1 —
1,700.2 (January 1994), 1.573.7(1993),
1.232.4(1992), 1,240.6(1991). 1. 198.1
(1990), 1.372.1 (1989)
Fiscal year: calendar year','62609ade68a740034fadd111c1f1eb2b8174207788700525ba792745f99ec712','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cfb8a766bac281ad5a2325439374e7834d363b1a7b298bc7e05e317f8c7b8d0a',1994,'DK','Denmark','economy',303,'too Km
GcoBraphy
Location; Nordic Stale, Northern Europe,
lyirdcring the North Seu on u peninsula north iif
Overview: The Faroese, who have long
enjoyed the affluent living standards of the
Danes and other Scandinavians, now must
cope with the decline of the all-important
fishing industry and one of the world’s heaviest
per capita external debts of nearly $30,000.
When the nations of the world extended their
fishing zones to 200 nautical miles in the early
1970s, the Faroese no longer could continue
their traditional long-distance fishing and
subsequently depleted their own nearby fishing
areas. The government’s tight controls on fish
stocks and its austerity measures have caused a
recession, and subsidy cuts will force
nationalization in the fishing industry, which
has already been plagued with bankniptcies.
Copenhagen has threatened to withhold its
annual subsidy of $130 million — roughly one-
third of the islands’ budget revenues — unless
the Faroese make significant efforts to balance
their budget. To this extent the Faroe
government is expected to continue its tough
policies, including inU''oducing a 20% value-
added tax (VAT) in 1993. and has agreed to an
IMF economic-political stabilization plan. In
addition to its annual subsidy, the Danish
government has bailed out the second largest
Faroe bank to the tune of $140 million since
October 1992.
National product: GDP — purchasing power
equivalent — $662 million (1989 est.)
130
FUi
3 (10 repeaters) FM, 3 (29 repeaters) TV; 3
coaxial submarine cables
Defense Forces
Branches: small Police Force, no organized
native military forces
Note: defense is the responsibility of
South Pacific Ocaan
Vanua Law
• /’
Viti Law^
/Tawim/
J-
luv)^','aec038a9d98c4d6932d76af0843f56b0583362bbc6a28d2048c7791b14e3f721','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('743aace9dbab72a149876c1162344d4025d5ac298631a59b0c24d03efbb28513',1994,'DE','Germany','economy',304,'Map references: Arctic Region. Euixtpe.
Standard Time Zones of the World
Area:
ivhil area: 43,070 sq kin
Uwdami; 42,.370 sq km
comiHtnitive umi: slightly more than twice the
size of Massachusetts
noiv; includes the island of Bornholm in the
Baltic Seu and the rest of metropolitan
Denmark, but excludes the Faroe Islands and
Imports: $1.9 billion (c.i.f., 1993)
commodities: raw materials, consumer goods,
capital goods
partners: US. Guatemala. Mexico, Venezuela.
External debt; $2.6 billion (December 1992)
Industrial production: growth rate 7.6%
(1993)
Electricity:
capacity: 7 1 3.800 kW
production: 2. 19 billion kWh
consumption per capita: 390 kWh (1992)
Industries: food processing, beverages,
petroleum, nonmetallic products, tobacco,
chemicals, textiles, furniture
Agriculture: accounts for 24% of GDP and
40% of labor force (including fishing and
forestry): coffee most important commercial
crop; other products — sugarcane, com. rice,
beans, oilseeds, beef, dairy products, shrimp;
not self-sufficient in food
Illicit drugs: transshipment point for cocaine;
marijuana produced for local consumption
Economic aid:
recipient: US commitments, including Ex-lm
(FY70-90), $2.95 billion (plus $250 million for
1992-96): Western (non-US) countries, ODA
and OOF bilateral commitments ( 1970-89).
$525 million
Currency: 1 Salvadoran colon (C) = 100
centavos
Exchange rates: Salvadoran colones (C) per
USSI— 8.720 (January 1994). 8.670(1993).
8.4500 ( 1 992). 8.080 (1991), 8.0300 ( 1 990),
fi xed rate of 5 .000 ( 1 986- 1989)
Fiscal year; calendar year
Overview: With the collapse of communism
in Eastern Europe in 1989, prospects seemed
bright for a fairly rapid incorporation of East
Germany into the highly successful West
German economy. The Federal Republic,
however, continues to experience difficulties
in integrating and modernizing eastern
Gennany, and the tremendous costs of
unification pushed western Germany into its
deepest recession since World War II. The
western German economy shrank by 1 .9% in
1993 as the Bundesbank maintained high
interest rates to offset the inflationary effects of
large government deficits and high wage
settlements. Eastern Gennany grew by 7. 1 % in
1993 but this was from a .shrunken base.
Despite government transfers to the east
amounting to nearly $1 10 billion annually, a
self-sustaining economy in the region is still
some years away. The bright spots are eastern
Germany''s construction, transportation,
telecommunications, and service sectors,
which have experienced .strong growth.
Western Germany has an advanced market
economy and is a world leader in exports. It has
a highly urbanized and .skilled population that
enjoys excellent living standards, abundant
leisure time, and comprehensive .social welfare
benefits. Western Germany is relatively poor in
natural resources, coal being the most
important mineral. Western Germany’s world-
class companies manufacture technologically
advanced goods. The region’s economy is
mature; services and manufacturing account
for the dominant share of economic activity,
and raw materials and semimanufactured
goods constitute u large portion of imports. In
recent years, manufacturing has accounted for
about 3 1 % of GDP, with other sectors
contributing lesser amounts. Cross fixed
investment in 1993 accounted for about 20.5%
of GDP. GDP in the western region is now
$ 19.400 per capita, or 78% of US per capita
GDP. Eastern Germany’s economy appears to
be changing from one anchored on
manufacturing into a more service-oriented
economy. The German government, however,
is intent on maintaining a manufacturing base
in the east and is considering a policy for
subsidizing industrial cores in the region.
Eastern Germany’s share of all-German GDP
is only 8% and eastern prtHluctivity is just 30%
that of the west even though eastern wages are
at roughly 70% of western levels. The
privatization agency for eastern Germany.
Treuhand, has privatized more than 90% of the
1 3,000 firms under its control and will likely
wind down operations in 1994. Private
investment in the region continues to be
lackluster, resulting primarily from the
deepening recession in western Germany and
excessively high eastern wages. Eastern
Germany has one of the world''s largest
reserves of low-grade lignite coal but little else
in the way of mineral resources. The quality of
statistics from eastern Germany is improving,
yet many gaps remain; the federal government
began producing all-German data for select
economic statistics at the start of 1992. The
most challenging economic problem is
promoting eastern Germany’s economic
reconstruction — specifically, finding the right
mix of fiscal, monetary, regulatory, and tax
policies that will spur investment in eastern
Germany — without destabilizing western
Germany’s economy or damaging relations
with West European partners. The government
hopes a "solidarity pact" among labor unions,
business, state governments, and the SPD
opposition will provide the right mix of wage
restraints, investment incentives, and spending
cuts to stimulate eastern recovery. Finally, the
homogeneity of the German economic culture
has been changed by the admission of large
numbers of immigrants.
National product:
Germany: GDP — purchasing power
equivalent — $1,331 trillion (1993)
western: GDP — purchasing power
equivalent — $1,218 trillion (1993)
eastern: GDP — purchasing power
equivalent — $1 12.7 billion (1993)
National product real growth rate:
Germany: -1.2% (1993)
western: -1.9% (1993)
eastern: 7.1% (1993)
National product per capita:
Germo/iv.- $16,500 (1993)
ue.v/crrt.S 19.400 (1993)
eastern: $6,300 (1993)
Inflation rate (consumer prices):
western: 4.2% (1993)
eastern: 8.9% (1993 est.)
Unemployment rate:
western: 8.1% (December 1993)
eastern: 15.4% (December 1993)
Budget:
revenues: $918 billion
expenditures: $972 billion, including capital
expenditures of $NA (1992)
Exports: $392 billion (f.o.b.. 1993)
commodities: manufactures 89.0% (Including
machines and machine tools, chemicals, motor
vehicles, iron and steel products), agricultural
products 5.4%, raw materials 2.2%, fuels 1 .3%
(1922)
/wrtners: EC 5 1 .3% (France 11.1%,
Netherlands 8.3%, Italy 8.2%, UK 7.9%,
Belgium-Luxembourg 7.5%), EFTA 13.3%,
US 6.8%’, Eastern Europe 5.0%, OPEC 3.3%
(1993)
Imports: $374.6 billion (f.o.b., 1993)
commodities: manufactures 74 9%,
agricultural products 10.3%, fuels 7.4%, raw
materials 5.5% (1992)
partners: EC 49.7 (France 1 1.0%. Netherlands
9.2%. Italy 8.8%, UK 6.6%, Belgium-
Luxembourg 6,7%). EFTA 12.7%, US 5.9%.
Japan 5.2%, Eastern Europe 4.8%. OPEC 2.6%
(1993)
149
Germany (continued)
External debt! $NA
Industrial production:
western: growth rates -7% (1993)
eastern: $NA
Electricity:
capacity: 134,0(X),000kW
pnduction: 580 billion kWh
consumption per capita: 7, 160 kWh ( 1992)
Industries:
western: among world’s largest producers of
iron, steel, coal, cement, chemicals, machinery,
vehicles, machine tools, electronics; food and
beverages
eastern: metal fabrication, chemicals, brown
coal, shipbuilding, machine building, food and
beverages, textiles, peuoleum refining
Agriculture:
western: accounts for about 2% of GDP
(including fishing and forestry); diversified
crop and livestock farming; principal crops and
livestock include potatoes, wheat, barley, sugar
beets, fruit, cabbage, cattle, pigs, poultry; net
importer of food
eastern: accounts for about 10% of GDP
(including fishing and forestry); principal
crops — wheat, rye, barley, potatoes, sugar
beets, fruit; livestock prc^ucts include pork,
beef, chicken, milk, hides and skins; net
imponer of food
Illicit drugs: source of precursor chemicals
for South American cocaine processors;
transshipment point for Southwest Asian
heroin and Latin American cocaine for West
European markets
Economic aid:
western-donor: ODA and (X)F commitments
(1970-89), $75.5 billion
eastern-donor: bilateral to non-Communist
less developed countries (1956-89) $4 billion
Currency; 1 deutsche mark (DM) = 1(K)
pfennige
Exchange rates; deutsche marks (DM) per
US$1— 1.7431 (Januaiy 1994), 1,6533(1993),
1.5617(1992). 1.6595(1991), 1.6157(1990),
1.8800(1989)
Fiscal year: calendar year
Imports: $737 million (c.i.f., 1992)
commodities; food, petroleum products,
semimanufactures, consumer goods,
transportation equipment
partners; South Africa, Japan. US, UK,','dd4c4480702b400ecf5fbb55d597aa2bcc8635e081364df76cff843091624599','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('336c265c3e8596e8c724523bb509e0b2068e67e79042f1ff07656a7b6fba9795',1994,'GL','Greenland','economy',305,'Land boundaries: total 6H km. Germany 68
km
Coastline; 3..379km
Maritime claims:
continuous zone: 4 nm
continental shelf: 200-m depth or to depth of
exploitation
e.xclusice fishin); :oni'': 200 nm
territorial sea: .3 nm
International disputes: Rtvkall continental
shelf dispute involving Iceland. Ireland, and
the UK (Ireland and the UK have signed a
boundary agreement in the Rtx''kall areal;
dispute ^tween Denmark and Norway o\\ er
maritime boundary in Arctic Ocean between
Greenland and Jan Mayen has been settled by
the International Court of Justice
Climate: temperate; humid and overcast;
mild, windy W''inters and cool summers
Terrain: low and Hat to gently ixdling plains
Natural resources: petroleum, natural gas.
fish, salt, limestone
Land use:
arahle land: 6 I''ll-
pennanenl crops: O''/f
meadow s and pastures: b''/''r
forest and woinlland: 1 291-
other: 219}-
Irrigated land; 4,.300 sq km ( 1980 est.)','a5be05f7f4f6330e778fb5ac7152c44020c3e94d2871cdf9bd4887d364a275c8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de78846075831cdbb0c29a799b8356042db76d0dfb700d58e5b1c7aa5d350136',1994,'SE','Sweden','economy',309,'Overview: This modem economy features
high-tech agriculture, up-to-date small-scale
and corporate industry, extensive government
welfare measures, comfortable living
standards, and high dependence on foreign
trade. Denmark''s new center-left coalition
government will concentrate on reducing the
persistent high unemployment rate and the
budget deficit as well as following the previous
government’s policies of maintaining low
inflation and a current account surplus. In the
face of recent international market pressure on
lie Danish krone, the coalition has also vowed
to maintain a stabie currency. The coalition
hopes to iower marginal income taxes while
maintaining overall tax revenues; boost
industrial competitiveness through labor
market and tax reforms and increased research
and deveiopment funds; and improve welfare
services for the neediest while cutting
paperwork and delays. Prime Minister
RASMUSSEN’S reforms will focus on
adapting Denmark to the criteria for European
integration by 1999; although Copenhagen has
won from the European Union (EU) the right to
opt out of the European Monetary Union
(EMU) if a national referendum rejects it.
Denmark is, in fact, one of the few EU
countries likely to fit into the EMU on time.
Denmark is weathering the current worldwide
slump belter than many West European
countries. As the EU’s single market (formally
established on I January 1993) gets underway,
Danish economic growth is expected to pickup
to around 2% in 1994, Danish approval of the
Maastricht treaty on EU political and economic
union in May 1993 has reversed the drop in
investment, further boosting growth. The
current account surplus remains strong as
limitations on wage increa.ses and low
inflation — expected to be around 2% in,
1994 — improve export competitiveness.
Although unemployment is high, it remains
stable compared to most European countries.
National product: GDP — purchasing power
equivalent — $95.6 billion ( 1993)
National product real growth rate: 0.5%
(1993)
National product per capita: $ 1 8,5(X)
(1993)
Inflation rate (consumer prices): 1 .891''
(1993 est.)
Unemployment rate: 1 1 .8% ( 1 993 est. )
Budget:
revenues; $48 billion
expenditures; $55.7 billion, including capital
expenditures of SNA ( 1 993)
Exports; $36,7 billion (f.o.b., 1993)
commodities; mcai and meat products, dairy
products, transport cqi ipmcnt (shipbuilding),
fish, chemicals, industrial machinery
partners; EC 54.3% ((Jermany 23.6%, UK
10, 1 %, France 5.7%), Sweden 10,5%, Norway
5,8%, US 4.9%. Japan 3.6% (1992)
Imports: $29,7 billion (c.i.f., 1993 est.)
commtHlities; petroleum, machinery and
equipment, chemicals, grain and foodstuffs,
textiles, paper
partners; EC 53.4% (Germany 23.1%, UK
8.2%, France 5.6%), Sweden 10.8%, Norway
5,4%, US 5.7%. Japan 4.1% (1992)
External debt; $40 billion (1992 est.)
Industrial production: growth rate -2.5%
(1993 e.st.)
Electricity;
capacity; 1 1.21.5.000 kW
production: 34,17 billion kWh
consumption per capita: 6.610 kWh (1992)
Industries; food processing, machinery and
equipment, textiles and clothing, chemical
products, electronics, construction, furniture,
and other wood products, shipbuilding
Agriculture: accounts for 4% of GDP and
employs 5.6% of labor force (includes fishing
and forestry); farm products account for nearly
15% of export revenues; principal product. s —
meat, dairy, grain, potatoes, rape, sugar beets,
fish; self-sufficient in food production
Economic aid;
donor: ODA and OOF commitments ( 1970-
89), $5.9 billion
Currency: 1 Danish krone (DKr) = 100 oere
Exchange rates: DanLsh kroner (DKr) per
US$1— 6.771 (January 1994). 6.484 (1993).
5.036 ( 1 992). 6.396 ( 1 99 1 ). 6. 1 89 ( 1 990),
7.310(1989)
Fiscal year: calendar year','6151c672437694f66648deaddf28fe8bed5c03e940a7750c1c964e703372e615','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7919faef14ae7a4c2c478a12de79f3bd4578500f723519346ae865a2d25a1b97',1994,'DJ','Djibouti','economy',315,'Overview: The economy is based on service
activities connected with the country''s
strategic location and status as a free trade zone
in northeast Africa. Djibouti provides services
as both a transit port for the region and an
international transshipment and refueling
center. It has few natural resources and little
industry. The nation is, therefore, heavily
dependent on foreign assistance (an important
supplement to GDP) to help support its balance
of payments and to finance development
projects. An unemployment rate of over 30%
continues to be a major problem. Per capita
consumption dropped an estimated 35% over
the last five years because of recession, civil
war, and a high population growth rate
(including immigrants and refugees).
National product: GDP — purchasing power
equivalent — $500 million ( 1993 est.)
National product real growth rate: - 1 %
(1992 e.st.)','9130f2c7a16b81e3ae3f258142082076bab9f7784f2f4cca3ce1fe0db77ce843','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85df1dfeab93d0f556136a3298c5faf788768ea90658d99cb84203115ea52500',1994,'DM','Dominica','economy',316,'with runways 1,220-2,439 m: 4
Tettconununkaliom: telephone facilities in
the city of Djibouti are adequate as are the
microwave radio relay connections to outlying
areas of the country; international connections
via submarine cable to Saudi Arabia and by
sateliite to other counuies; one ground station
each for Indian Ocean INTELSAT and
ARABSAT; broadcast stations — 2 AM. 2 PM,
I TV
Defense Forces
Branches: Djibouti National Army (including
Navy and Air Force), National Security Force
(Force Nationale de Securite), National Police
Force
Manpower availability: males age 15-49
99,81 1; fit for military service 58,346
Defense expenditures: exchange rate
conversion — $26 million, NA% of GDP
(1989)
Geognphy
Locat'' on.* Caribbean, in the eastern Caribbean
Sea, about halfway between Puerto Rico and
Overview; The economy is dependent on
agriculture and thus is highly vulnerable lo
climat''c conditions. Agriculture accounts for
about 30% of GDP and employs 40% of the
labor force. Principal products include
bananas, citrus, mangoes, root crops, and
coconuts. Development of the touri.st industry
remains difficult because of the rugged
coastline and the lack of an international
airport.
National product: GDP — purchasing power
equivalent — $185 million (1992 est.)
National product real growth rate; 2.b%
(1992 est.)
National product per capita: $2,100(1992
est.)
Inflation rate (consumer prices): 5.2%
(1992 est.)
Unemployment rate: 15% ( 1992 est.)
Budget;
revenues: $70 million
expenditures: $84 million, including capital
expenditures of $26 million (FY9I est.)
Exports: $54.6 million (1992)
commodities: bananas, soap, bay oil.
vegetables, grapefruit, oranges
partners: UK 50%. CARICOM countries,
Italy. US
Imports: $97,5 million (1992)
commodities: manufactured goods, machinery
and equipment, food, chemicals
partners: US 25%, CARICOM, UK, Canada
External debt: $92.8 million (1 992)
Industrial production: growth rate
4.2%(I992); accounts for 7% of GDP
Electricity:
capacity: 7.000 kW
production: 16 million kWh
consumption per capita: 185 kWh (1992)
Industries: soap, coconut oil, tourism, copra,
furniture, cement blocks, shoes
Agriculture: accounts for 30% of GDP;
principal crops — bananas, citrus, mangoes,
root crops, coconuts; bananas provide the bulk
of export earnings; forestiy'' and fisheries
potential not exploited
Illicit drugs: transshipment point for cocaine
and marijuana bound for the US and Europe
Economic aid:
recipiei.t: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-89),
$120 million
Currency: I EC dollar (ECS) = 100 cents
Exchange rates; East Caribbean dollars
(ECS) per US$1 — 2.70 (fixtd rate since 1976)
Fiscal year: 1 July — 30 June','1632fd6f2ee3064d397990dd0c6f0187a8d64400fdd848551e2abb991a12fbdb','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f18e203dd420c068005340b05cc7d08f9210eae89452160aedb38117a4ded0f3',1994,'TT','Trinidad and Tobago','economy',317,'Map references: Central America and the
Caribbean, South America, Standard Time
Zones of the World
Area:
National product per capita: $1,200(1993
est.)
Inflation rate (consumer prices): 6%(I992)
Unemployment rate: over 30% (1989)
Budget:
revenues: $ 1 70 million
expenditures: $203 million, including capital
expenditures of $70 million (1991 est.)
Exports: $ 1 58 million (f,o.b., 1992 est.)
commodities: hides and skins, coffee (in
transit)
partners: Africa 47%, Middle East 40%,
Western Europe 12%
Imports: $334 million (f.o.b., 1992 est.)
commodities: foods, beverages, transport
equipment, chemicals, petroleum products
partners: Western Europe 48%, Asia 25%.
Africa 8%
External debt: $355 million (December
1990)
Industrial production: growth rate 3% (1 99 1
est.); manufacturing accounts for 12% of GDP
Electricity:
capacity: 1 15,000 kW
production: 200 million kWh
consumption per capita: S80 kWh (1991)
Industries: limited to a few small-scale
enterprises, such as dairy products and
mineral-water bottling
Agriculture; accounts for only 2% of GDP;
scanty rainfall limits crop production to mostly
fruit and vegetabies; half of population pastoral
nomads herding goats, sheep, and camels;
imports bulk of food needs
Economic aid:
recipient: US commitments, including Ex-Im
(FY78-89), $39 million; Western (non-US)
countries, including ODA ani OOF bilateral
commitments (1970-89), $1.1 billion; OPEC
bilateral aid (1979-89), $149 million;
Communist countries (1970-89). $35 million
Currency: I Djiboutian franc (DF) = l(X)
centimes
Exchange rates: Djiboutian francs (DF) per
US$1— 177.721 (fixed rate since 1973)
Fiscal year: calendar year
Overview: Trinidad and Tobago''s petroleum-
based economy still enjoys a high per capita
income by Latin American standards, even
though output and living standards are
substantially below the boom years of 1 973-82.
The country suffers from widespread
unemployment, large foreign-debt payments,
and periods of low international oil prices.
Seven successive years of economic
contraction were followed by small gains in
output in 1990-91 of 1.2% and 0.9%, in turn
Trinidad and Tobago (continued)
Tromelin Island
(IH)ssesslon of France)
followed by small declines in 1992-93 of
roughly 1 .0%. The government has begun to
make progress in its efforts to diversify
exports.
NatioiMl product: OOP— purchasing power
equivalent — $10.4 billion (1993 est.)
NaUoiwI product real growth rale: -1%
(1993)
National product per capita: $8,000(1993
est.)
Inflation rate (consumer prices): 9.5%
(1993)
IJnemployincnt rate: I8.S%(I99I)
Budget:
revenues; $1.6 billion
expenditures: $1.6 billion, including capital
expenditures of $158 million (1993 est.)
Exports: $1.4 billion (f.o.b., 1993)
commMiiiies; petroleum and petroleum
products, chemicals, steel products, fertilizer,
sugar, cocoa, coffee, citrus, flowers
partners; US 47%. CARICOM 1 3%, Latin
America 9%. EC ,5% (1992)
Imports: $900 million (f.o.b. . 1993)
commodities: machinery, transportation
equipment, manufacture goods, food, live
animals (1992)
partners: US 41%, Venezuela 10%, UK 8%,
other EC 8%
External debt: $2 billion (1993)
Industrial production: growth rate 2.3%,
(1991); accounts for 37% of GDP, including
petroleum
Electricity:
capacity: 1,176,000 kW
production; 3.48 billion kWh
consumption per capita: 2,680 kWh ( 1992)
Industries; petroleum, chemicals, tourism,
food processing, cement, beverage, cotton
textiles
Agriculture; accounts for 3% of GDP; highly
subsidized sector; major crops — cocoa,
sugarcane; sugarcane acreage is being .shifted
into rice, citrus, coffee, vegetables; poultry
sector most important source of animal protein;
must import large share of food needs
Illicit drugs: transshipment point for South
American drugs destined for the US and
Europe
Economic aid;
recipient: US commitments, including Ex-lm
(FY70-89), $373 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), S.S18 million
Currency: I Trinidad and Tobago dollar
{TTS)= 100 cents
Exchange rates: Trinidad and Tobago dollars
(TT$) per US$1— 5,81 1 1 (January 1994),
5..35I I (1993). 4.2500 (fixed rate 1989-1992);
note — effective 13 April 1993. the exchange
rate of the TT dollar is market-determined as
opposed to the prior fixed relationship to the
US dollar
Fiscal year: calendar year
CommunkatkMis
Railroads: minimal agricultural railroad
system near San Fernando
Highways:
total: 8,000 km
paved; 4,000 km
unpaved: improved earth 1.000 km;
unimproved earth 3.000 km
Pipelines: crude oil 1 .032 km. petroleum
products 19 km, natural gas 904 km
Ports: Pott-of-Spain, Pointe-a-Pierre,
Scarborough
Merchant marine: 2 cargo ships ( 1 .000 ORT
or over) totaling 12.,507 GRT/21.923 DWT
Airports:
total; 6
usable: 5
with pennanenhsuiface runways: 2
with runways over 3,659 m: 0
with runways 2.440-3,659 m; 2
with runways 1,220-2.439 m: I
Telecommunications: excellent
international service via tropospheric .scatter
links to Barbados and Guyana; good local
service; 109.000 telephones; broadca.st
stations — 2 AM, 4 FM. 5 TV; I Atlantic Ocean
INTELSAT earth station
Defense Forces
Branches; Trinidad and Tobago Defense
Force (including Ground Forces, Coast Guard,
and Air Wing), Trinidad and Tobago Police
Service
Manpower availability: males age 15-49
.357,904; fit for military service 257,667
Defense expenditures: exchange rate
conversion — $59 million, l%-2% of GDP
(1989 est.)
500 m','f7ab5630ee58e21b8222d72db4ea0c794a4c3411727af3bd11af3748118ffe4c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae314d6be4aa0228386b74d8ee8db0d1c0e44fcf48c984bcdf5375b6659dfa50',1994,'DO','Dominican Republic','economy',327,'Overview: Rapid growth of free trade zones
has led to a substantial expansion of
manufacturing for export, especially of
wearing apparel. Over the past decade, tourism
has also increased in importance and is a major
earner of foreign exchange and a source of new
Jobs. Agriculture remains a key sector of the
economy. The principal commercial crop is
sugarcane, followed by coffee, cotton, cocoa,
and tobacco. Domestic industry is based on the
processing of agricultural products, nil
refining, minerals, and chemicals.
Unemployment is officially reported at about
30%, but there is considerable
underemployment. Growth fell to a moderate
3% in 1993 because of power shortages in
industry and political uncertainty which
slowed down foreign investment.
National product: GDP — purchasing power
equivalent — $23 billion (1993 est.)
National product real growth rate: 3%
(1993 est.)
National product per capita: $3,000 ( 1993
est.)
Inflation rate (consumer prices): 8% (1993
est.)
Unemployment rate: 30% (1993 est.)
Budget;
revenues: $1.4 billion
expenditures: $1.8 billion, including capital
expenditures of SNA (1993 est.)
Exports: $769 million (f.o.b., 1993)
commodities: ferronickel, sugar, gold, coffee,
cocoa
partners: US 56%, EC 22%, Puerto Rico 8%
(1991)
Imports: $2.2 billion (c.i.f.. 1993 est.)
commodities: foodstuffs, petroleum, cotton
and fabrics, chemicals and pharmaceuticals
partners; US 50%
External debt: $4.7 billion (1993 est.)
Industrial production: growth rate -0.1%
(1991); accounts for 14% of GDP
Electricity:
capacity: 2,283,000 kW
production: 5 billion kWh
consumption per capita: 660 kWh (1992)
Industries: tourism, sugar processing,
ferronickel and gold mining, textiles, cement,
tobacco
Agriculture: accounts for 1 8% f GDP and
employs 49% of labor force: sugarcane is the
most important commercial crop, followed by
coffee, cotton, cocoa, and tobacco; food
crops — rice, beans, potatoes, com, bananas;
animal output — cattle, hogs, dairy products,
meat, eggs; not self-sufficient in food
Illicit drugs: transshipment point for South
American drugs destined for the US and
Europe
Economic aid:
recipient: US commitments, including Ex-Im
(FY85-89), $575 million: Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $655 million
Currency; 1 Dominican peso (RD$) = 100
centavos
Exchange rates: Dominican pesos (RD$) per
US$1— 12.841 (January 1994), 12.679(1993),
1 2.774 ( 1 992), 1 2.692 ( 1 99 1 ), 8.525 ( 1 990).
6.340(1989)
Fiscal year: calendar year','4734d31960b1abf5c0dca660de4a283bd0d9b0010bdd237e7266f2a41b8df510','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5365f0a36196b9c773b4e314dfdbbb9b8109ce1e884c5018d3880d0760bba0cd',1994,'EC','Ecuador','economy',333,'Overview; Ecuador has substantial oil
resources and rich agricultural areas. Growth
has been uneven because of natural disasters,
fluctuations in global oil prices, and
government policies designed to curb inflation.
Banana exports, second only to oil, have
suffered as a result of import quotas of the
European Union and banana blight. The new
President Sixto DURAN-BALLEN, has a
much more favorable attitude toward foreign
investment than did his predecessor. Ecuador
has implemented trade agreements with
Colombia, Peru, Bolivia, and Venezuela and
has applied for GATT membership. At the end
of 1 99 1 , Ecuador received a standby IMF loan
of $105 million, which will permit the country
to proceed with the rescheduling of Paris Club
debt, In September 1992, the government
launched a new, macroeconomic program that
gives more play to market forces. In 1993, the
DURAN-BALLEN administration adopted a
rigorous austerity program that resulted in
economic stabilization, with inflation cut in
half and international reserves boosted to a
record ;>L3 billion. Growth in 1993 was
perhay; only 2% due to falling export prices,
notably 9, and slow progress on privatization.
National p/oduct; GDP — purchasing power
equivalent — $41.8 billion
National produet real growth rate; 2%
(1993 est.)
National product per capita: $4,(X)0 ( 1 993
e.st.)
Inflation rate (consumer prices): 31%
(1993)
Unempioyment rate: 8% (1992)
Budget:
revenues: $1.9 billion
expenditures: $1.9 billion, including capital
expenditures of $NA (1992)
Exports; $3 billion (f.o.b., 1992)
commodities: petroleum 42%. bananas.
shrimp, cocoa, coffee
partners: US 53.4%, Latin America,
Caribbean, EC countries
Imports: $2.5 billion (f.o.b.. 1992)
commodities: transport equipment, vehicles,
machinery, chemicals
partners: US 32.7%, Latin America,
Caribbean, EC countries, Japan
External debt: $ 1 2.7 billion (1992)
Industrial production: growth rate 3.9%
(1991); accounts for almost 30% of GDP.
including petroleum
Electricity:
capacity: 2,92 1 ,000 kW
production: 7.676 billion kWh
consumption per capita: 700 kWh (1992)
Industries: petroleum, food processing,
textiles, metal works, paper products, wood
products, chemicals, plastics, fishing, timber
Agriculture: accounts for 18% of GDP and
35% of labor force (including fishing and
forestry); leading producer and exporter of
bananas and balsawood; other exports —
coffee, cocoa, fish, shrimp; crop production —
rice, potatoes, manioc, plantains, sugarcane;
livestock sector — cattle, sheep, hogs, beef
pork, dairy products; net importer of
foodgrains, dairy products, and sugar
Illicit drugs: significant transit country for
derivatives of coca originating in Colombia,
Bolivia, and Peru; minor illicit producer of
coca; importer of precursor chemicals used in
production of illicit narcotics; important
money-laundering hub
Economic aid:
recipient: US commitments, including Ex-lm
(FY70-89). $498 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $2.15 billion;
Communist countries (1970-89). $64 million
Currency: 1 sucre (S/) = 1(X) centavos
Exchange rates: sucres (SI) per US$ I —
1,947.1 (October 1993), 1.534.0(1992).
1 .046. 25 ( 1 99 1 ). 767.8 ( 1 990). 767.78 ( 1 990).
526..35 (I989)
Fiscal year; calendar year
Map references: South America, Standard
Time 2U>nes of the World
Area:
total area: 1 ,285,220 sq km
land area: 1.28 million sq km
comparative area; slightly smaller than
Alaska
Land boundaries: total 6,940 km, Bolivia
9(X) km, Brazil 1 ,560 km, Chile 1 60 km,
Colombia 2,9(X) km. Ecuador 1,420 km
Coastline: 2,414 km
Maritime claims:
territorial sea: 200 nm
International disputes: three sections of the
boundary with Ecuador are in dispute
Climate: varies from tropical in east to dry
desert in west
Terrain: western coastal plain (costa), high
and rugged Andes in center (sierra), eastern
lowland jungle of Amazon Basin (selva)
Natural resources: copper, silver, gold,
petroleum, timber, fish, iron ore, coal,
phosphate, potash
Land use;
arable land: 3%
permanent crops- 0%
meadows and pastures: 2 1 %
forest and woodland: 55%
other; 21%
Irrigated land: 1 2,500 sq km ( 1 989 est.)
Overview: The Peruvian economy is
becoming increasingly market oriented, with
major privatizations scheduled for 1994 in the
mining and telecommunications industries. In
the 1980s the economy suffered from
hyperinflation, declining per capita output, and
mounting external debt. Peru was shut off from
IMF and World Bank support in the mid- I980.S
because of its huge debt arrears. An austerity
313
Peru (continued)
program implemented shortly after the
FUJIMORI government took office in July
1990 contributed to a third consecutive yearly
contraction of economic activity, but the slide
halted late that year, and output rose 2.4% in
1991. After a burst of inflation as the austerity
program eliminated government price
subsidies, monthly price increases eased to the
single-digit level and by December 1991
dropped to the lowest increase since mid- 1987.
Lima obtained a financial rescue package from
multilateral lenders in September 1991,
although it faced $14 billion in arrears on its
external debt. By working with the IMF and
World Bank on new financial conditions and
arrangements, the government succeeded in
ending its arrears by March 1993. In 1992,
GDP fell by 2.8%, in part because a warmer-
than-usual El Nino current resulted in a 30%
drop in the fish catch. In 1993 the economy
rebounded as strong foreign investment helped
push growth to 6%.
National product: GDP — purchasing power
equivalent — $70 billion (1993 est.)
National product real growth rate: 6%
(1993 est.)
National product per capita: $3,000 ( 1 993
est.)
Inflation rate (consumer prices): 39%
(1993 est.)
Unemployment rate: 15% (1992 est.);
underemployment 70% (1992 est.)
Budget;
revenues; $2 billion
expenditures; $1.7 billion, including capital
expenditures of $300 million (1992 est.)
Exports: $3.7 billion (f.o.b., 1993 est.)
commodities: copper, zinc, fishmeal, crude
petroleum and byproducts, lead, refined silver,
coffee, cotton
partners; US 25%, Japan 9%, Italy, Germany
Imports: $4.5 billion (f.o.b., 1993 est.)
commodities; machinery, transport equipment,
foodstuffs, petroleum, iron and steel,
chemicals, pharmaceuticals
partners: US 30%, Colombia, Argentina.
Japan, Germany, Brazil
External debt: $22 billion ( 1993 est.)
Industrial production: growth rate -5%
(1992 est.): accounts for 32% of GDP,
including petroleum
Electricity:
capacity; 5,042,000 kW
production; 17.434 billion kWh
consumption per capita: 760 kWh (1992)
Industries: mining of metals, petroleum,
fishing, textiles, clothing, food processing,
cement, auto assembly, steel, shipbuilding,
metal fabrication
Agriculture: accounts for 1 3% of GDP, about
35% of laborforce; commercial crops — coffee,
cotton, sugarcane; other crops — rice, wheat,
potatoes, plantains, coca; animal products —
poultry, red meats, dairy, wool; not self-
sufficient in grain or vegetable oil; fish catch of
6.9 million metric tons (1990)
Illicit drugs: world’s largest coca leaf
producer with about 108,800 hectares under
cultivation in 1993: source of supply for most
of the world''s coca paste and cocaine base; at
least 85% of coca cultivation is for illicit
production; most of cocaine base is shipped to
Colombian drug dealers for processing into
cocaine for the international drug market
Economic aid:
recipient: US commitments, including Ex-Im
(FY70-89), $1.7 billion; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89). $4.3 billion;
Communist countries (1970-89), $577 million
Currency: I nuevo sol (S/.) = 100 centimos
Exchange rates: nuevo sol (S/.) per US$1 —
2.180(January 1994). 1.988(1993), 1.245
(1992), 0.772 (1991), 0.187 (1990), 0.0027
(1989)
Fiscal year: calendar year','a9e83665800381245e793cd9f4541181d4c0e4269742433c768291a00fd7eb70','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e98943e76c1d84d72f1208806d50b7ad27b3dd6bd33f2ffd537156289615955',1994,'EG','Egypt','economy',340,'Overview; Egypt has one of the largest public
sectors of all the Third World economies, most
industrial plants being owned by the
government. Overregulation holds back
technical modernization and foreign
investment. Even so, the economy grew
rapidly during the late 1970s and early 1980s,
but in 1986 the collapse of world oil prices and
an increasingly heavy burden of debt servicing
led Egypt to begin negotiations with the IMF
for balance-of-payments .support. Egypt’s first
IMF standby arrangement concluded in mid-
1987 was suspended in early 1988 because of
the government’s failure to adopt promised
reforms. Egypt signed a follow-on program
with the IMF and also negotiated a structural
adjustment loan with the World Bank in 1991.
In 199 1 -93 the government made .solid
progress on administrative reforms such as
liberalizing exchange and interest rates but
resisted implementing major structural reforms
like streamlining the public sector. As a result,
the economy has not gained momentum and
unemployment has become a growing
problem. Egypt probably will continue making
uneven progress in implementing the successor
programs with the IMF and World Bank it
signed onto in late 1993. In 1992-93 tourism
plunged 20% or so because of sfioradic attacks
by Islamic extremists on tourist groups.
President MUBARAK has cited population
growth as the main cause of the country''s
economic troubles. The addition of about 1 .4
million people a year to the already huge
population of 60 million exerts enormous
pressure on the 5% of the land area available
for agriculture.
National product: GDP — purchasing power
equivalent — $139 billion (1993 est.)
National product real growth rate: 0.3%
(1993 est.)
National product per capita: $2,400 ( 1993
est.)
Inflation rate (consumer prices): I %
(1993 est.)
Unemployment rate: 20% (1993 est.)
Budget:
revenues: $16.8 billion
expenditures; $19.4 billion, including capital
expenditures of $3.4 billion (FY94 est.)
Exports: $3.5 billion (f.o.b.. FY93 est.)
commodities: crude oil and petroleum
products, cotton yarn, raw cotton, textiles,
metal products, chemicals
partners: EC, Eastern Europe. US, Japan
Imports; $10,5 billion (c.i.f., FY93 est.)
commodities: machinery and equipment.
foods, fertilizers, wood products, durable
consumer goods, capital goods
partners: EC, US, Japan, Eastern Europe
External debt: $32 billion (March 1993 est.)
Industrial production: growth rate -0.4%
(FT 92 est.); accounts for 1 8% of GDP
Electricity:
capacity: 14,175,000 kW
production: 41 billion kWh
consumption per capita: 830 kWh ( 1 992)
Industries: textiles, food processing, tourism,
chemicals, petroleum, construction, cement,
metals
Agriculture: accounts for 20% of GDP and
employs more than one-third of labor force;
dependent on irrigation water from the Nile;
world’s sixth-largest cotton exporter; other
crops produced include rice, com. wheat,
beans, fruit, vegetables; not self-sufficient in
food for a rapidly expanding population;
livestock — cattle, water buffalo, sheep, goats;
annual fish catch about 140,000 metric tons
Illicit drugs: a transit point for Southwest
Asian and Southeast Asian heroin and opium
moving to Europe and the US; popular transit
stop for Nigerian couriers; large domestic
consumption of hashish from Lebanon and
Syria
Economic aid;
recipient: US commitments, including Ex-Im
(FY70-89). $15.7 billion; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-88). $10.1 billion; OPEC
bilateral aid (1979-89), $2.9 billion;
Communist countries (1970-89). $2.4 billion
Currency: 1 Egyptian pound (£E) = 100
piasters
Exchange rates: Egyptian pounds (£E) per
US$1— 3..369 (November 1993), 3.345
(November 1992), 2.7072 (1990), 2.5171
( 1 989), 2.2233 ( 1 988), 1 ,5 1 83 ( 1 987)
Fiscal year: I July — 30 June','e9eef0add7dc9f64e016a2e285599cad1c8670c874c79ec7b77d4a8f4d7d4743','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbe1f564df56fa77266f7f3ad26461128c003b71bf552e58284f8d1d819df0d9',1994,'HN','Honduras','economy',347,'Overview; The agricultural sector accounts
for 24% of GDP, employs about 40% of the
labor force, and contributes about 66% to total
exports. Coffee is the major commercial crop,
accounting for 45% of export earnings. The
manufacturing sector, based largely on food
and beverage processing, accounts for 19% of
GDP and 15% of employment. In 1992-93 the
government made substantial progress toward
privatization and deregulation of the economy.
Growth in national output in 1990-93 exceeded
growth in population for the first time since
1987. and inBation in 1993 of 12% was down
from 17% in 1992
National product: GDP — purchasing power
equivalent — S14.2 billion (1993 est.)
National product real growth rate: 5%
(1993 est.)
National product per capita: $2,500 ( 1 993
est.)
Inflation rate (consumer prices); 1 2%
(1993 est.)
Unemployment rate: 6.7% (1993)
Budget:
revenues: $846 million
expenditures: $890 million, including capital
expenditures of SNA (1992 est.)
Exports: $730 million (f.o.b.. 1993)
commodities: coffee, sugarcane, shrimp
partners: US, Guatemala. Costa Rica,
Overview: Honduras is one of the poorest
countries in the Western Hemisphere.
Agriculture, the most iinptrnant sector of the
economy . accounts for more than 25% of GDP,
employs 62% of the labor force, and produces
two-thirds of exports. Productivity remains
low. Industry, still in its early stages, employs
nearly 9% of the labor force, accounts for 1 5%
of GDP. and generates 20% of exports. The
service sectors, including public
administration, account for 50% of GDP and
employ 20% of the labor force. Basic problems
facing the economy include rapid population
growth, high unemployment, a lack of basic
services, a large and inefl''icient public sector,
and the dependence of the export sector nuxstly
on coffee and bananas, which arc subject to
sharp price Ructuations. A
far-reaching reform program initiated by
former President CALLEJAS in 1990 is
beginning to take hold. In 1993 the large fiscal
deficit emerged as a key economic prtiblem.
the result of improvident state spending.
National product: GDP — purchasing power
equivalent — $10 billion ( 1993 cst.)
National product real growth rate: 3.7%
(1993est.)
National product per capita: $ 1 .950 (1993
est.)
Inflation rate (consumer prices): 13%
(1993 est.)
Unemployment rate: 10% (30-40%
underemployed) (1992)
Budget:
revenues; $1.4 billion
expenditures; $ 1 .9 billion, including capital
expenditures of $5 1 1 million ( 1990 cst.)
Experts: $850 million (f.o.b., 1993 est)
commodities; bananas, coffee, shrimp, lobster,
minerals, meat, lumber
partners; US 53%, Germany 1 1%, Belgium
8%, UK 5%
Imports: $1.1 billion (c.i.f. 1993 est)
commodities; machinery and transport
equipment, chemical products, manufactured
goods, fuel and oil, foodstuffs
partners; US 50%, Mexico 8%, Guatemala 6%
External debt: $2.8 billion (1990)
Industrial production: growth rate 0.8%
( 1 990 est. ); accounts for 1 5% of GDP
Electricity:
capacity; 575,000 kW
production: 2 billion kWh
consumption per capita: 390 kWh (1992)
Industries: agricultural processing (sugar and
coffee), textiles, clothing, wood products
Agriculture: most important sector,
accounting for more than 25% of GDP. more
than 60% of the labor force, and two-lhirds of
exports; principal products include bananas,
coffee, timber, beef, citrus fruit, shrimp;
importer of wheat
Illicit drugs: transshipment point for cocaine;
illicit producer of cannabis, cultivated on small
plots and used principally for local
consumption
Economic aid:
recipient: US commitments, including Ex-lm
(FY7()-89), $1.4 billion; Western (non-US)
countries. ODA and OOF bilateral
commitments (1970-89). $1,1 billion
Currency: 1 lempira (L)= 100 centavos
Exchange rates: lempiras (L) per US$1 —
7.26(X) (December 1993), 7.2600 (1993),
5.8.300 (1992), 5.40(X) (1991); 2.0(X)0 (fixed
rate until 1991) 5,70 parallel black-market rate
(November 1990); the letnpira was allowed to
fioat in 1992
Fiscal year; calendar year','86c051e22ad786716bcdadea0a60a5b0a6fb26073202fc391023b789d46d22d8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea7b5c277851d6daf5a0cbb7b8427058f4c72f7edbd2796eacc68924db8c0ff9',1994,'GQ','Equatorial Guinea','economy',354,'Overview: Agriculture, forestry, and fishing
account for about half of GDP and nearly all
exports. Sub.sistence farming predominates.
Although pre-independence Equatorial Guinea
counted on cocoa prixluction for hard currency
earnings, the deterioration of the rural
economy under successive brutal regimes has
diminished potential for agriculture-led
growth. A number of AID programs sponsored
by the World Bunk and the international donor
community have failed to revitalize export
agriculture. There is little industry; businesses
for the most part are owned by government
officials and their family members. Commerce
accounts for about S**- of GDP and the
construction, public works, and service .sectors
for about 389i''. Undeveloped natural resources
include titanium, iron ore. manganese,
uranium, and alluvial gold. Oil exploration,
taking place under concessions offered to US,
French, and Spanish finns. has been
moderately successful. Increased prrxluction
from recently discovered natural gas fields will
provide a greater share of exports by 1995.
National product: GDP — purchasing power
equivalent — S280 million ( 1993 est.)
National product real growth rate: NA
National product per capita: $7(X) ( 1993
est.)
Inflation rate (consumer prices): 1 .65t-
(1992 est.)
Unemployment rate: NA(i(-
Budget:
revenues: $32.5 million
expenditures: $35.9 million, including capital
expenditures of $3 million (1992 est.)
Exports: $52.8 million (f.o.b.. 1992)
commodities: coffee, timber, cwoa beans
partners: Spain 55.29f, Nigeria I L49f.
Camerewn 9, 1 9i- ( 1992)
Imports: $63.6 million (c.i.f.. 1992)
commodities: petroleum, I''ihhI, beverages,
clothing, machinery
partners: Camerorm 23. 1 ''T. Spain 2 1 .8^?-,
France 14.1Vr, US 4..W
External debt: $2(>() million ( 1992 est)
Industrial production: growth rate -6.5''^
( 1992 est.); accounts for 59(- of GDP
Electricity:
caikieity- 23.(XX) kW
pitHluclion; 60 million kWh
consumption per capita: 1 60 kWh (1991)
Industries: fishing, sawmilling
Agriculture: accounts for almost 509f of
GDP. cash crops— timber and ctiffee from Rio
Muni, cocoa from Bioko; food crops — rice,
yams, cassava, bananas, oil palm nuts, manioc.
livestiKk
Economic aid:
ivcipient: US commitments, including Ex-lm
(FY8I-89), $14 million; Western (non-US)
countries. ODA and OOF bilateral
commitments (1970-89), $1,50 ntillion;
Communist countries (1970-89), $55 million
Currency: I CFA franc (CFAF) = 100
centimes
Exchange rates; Communautc Financiere
Africaine francs (CFAF) per US$1 — .592,05
(January 1994), 273.16(1993). 264,69(1992).
282.11 (1991). 272.26(1990), 319.01 (1989)
note: beginning 12 January 1994. the CFA
franc was devalued to CFAF ItX) per French
franc from CFAF 50 at which it had been fixed
since 1948
Fiscal year; I April — 31 March','771895f3e79fce7ad944f1cded7a7283744fa35fc29d80fd55815130ad1eb03f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01cfecafb0daaa34e1086f6ef66d84a43ef7fcda22da9a505b53547689908d5f',1994,'EE','Estonia','economy',359,'Budget:
revenues; SNA
expenditures; SNA. including capital
expenditures of SNA
Exports: SNA
commodities; NA
partners; NA
Imports: SNA
commodities; NA
partners; NA
External debt: SNA
Industrial production: growth rate NA%
Electricity:
capacity; NA kW
pr^iiction; NA kWh
consumption per capita; NA kWh
Industries: food processing, beverages,
clothing and textiles
Agriculture: products — sorghum, livestock
(including goats), ftsh. lentils, vegetables,
maize, cotton, tobacco, coffee, sisal (for
making rope)
Economic aid: SNA
Currency: I birr (Br) = I (X) cents: at present.
Ethiopian currency used
Exchange rates: I birr (Br) per USSI - .S.OOO
(fixed rate since 1992)
Fiscal year: NA
Overview: Bolstered by a widespread
national desire to reintegrate into Western
Europe, the Estonian government has pursued
a program of market reforms and rough
stabilization measures, which is rapidly
transforming the economy. Two years after
independence — and one year after the
introduction of the kroon — Estonians are
beginning to reap tangible benefits; inflation is
low; production declines appear to have
bottomed out: and living standards ore rising.
Economic restructuring is clearly underway
with the once-dominant energy-intensive
Heavy industrial sectors giving way to labor-
intensive light industry and the
underdeveloped service sector. The private
sector is growing rapidly; the share of the state
enterprises in retail trade has steadily declined
and by June 1993 accounted for only 12.5% of
total turnover, and 70,000 new Jobs have
rejxirtedly been created as a result of new
business start-ups. Estonia’s foreign trade has
shifted rapidly from East to West with the
Western industrialized countries now
accounting for two-thirds of foreign trade.
National product; GDP— purchasing power
equivalent — $8.8 billion (1^3 estimate from
the UN International Comparison Program, us
extended to 1991 and published in the World
Bank’s World Development Report 1993: and
as extrapolated to 1 993 using official Estonian
statistics, which are very uncertain because of
major economic changes since 1990)
National product real growth rate: -5%
( 1993 e.st.)
National product per capita: $5,480(1993
est.)
Inflation rate (consumer prices): 2.6% per
month ( 1993 average)
Unemployment rate: 3.5% (May 1993): but
large number of underemployed workers
Budget:
revenues: $223 million
expenditures; $142 million, including capital
expenditures of $NA (1992)
Exports; $765 million (f.o.b., 1993)
commodities: textile 14%, finxl products 1 1%,
vehicles 1 1 %. metals 1 1 % ( 1 993)
IHirtners: Russia. Finland. Laitvia. Germany,','4143b8ce5a46364b194a4b9d8788ee8b5ffbdcdb61eea67598460dd106de0fb3','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1258206d404f99e9ec09401c228b1d11341b5af5bf28c353c34bfbeaf110b1af',1994,'UA','Ukraine','economy',365,'Imports; $865 million (c.i.f., 1993)
commoilities; machinery IS*)!, fuels 15%.
vehicles 14%, textiles 10% (1993)
IHirmers; Finland, Russia. Sweden, Germany,
Overview: Despite the continuing difficulties
in moving away from the fomier command
system, the Romanian economy seems to have
bottomed out in 1993. Market oriented reforms
have been introduced fitfully since the
downfall of CEAUSESCU in December 1989,
with the result a growing private sector,
especially in services. The slow pace of
structural reform, however, has exacerbated
Romania''s high inflation rate and eroded real
wages. Agricultural production rebounded in
1993 from the previous year''s drought-reduced
harvest; food supplies are adequate, but
expensive. Bucharest resisted pressure to
devalue its currency despite a $638 million
trade deficit in the first half of 1993 and the
emergence of a black market for hard currency .
Unable to support the currency, the national
bank, nonetheless, was forced to depreciate the
currency 65% over the course of the year. ''The
return of v''inter revealed that much of
Romania''s infrastructure had deteriorated over
the last four years due to reduced levels of
public investment. Residents of the capital
reported frequent disruptions of heating and
water services.
National product: GDP — purchasing power
equivalent — $63.7 billion (1993 est.)
National product real growth rate: 1%
(1993)
National product per capita: $2,700(1993
est.)
Inflation rate (consumer prices): 6% per
month (March 1994)
Unemployment rate: 11% (March 1994)
Budget;
revenues: $19 billion
expenditures; $20 billion, including capital
expenditures of $2.1 billion (1991 est.)
Exports: $4 billion (f.o.b., 1993)
commodities; metals and metal products 24%,
mineral products 14%, textiles 10.7%, electric
machines and equipment 9.3%, transport
matenals 9.2% ( 1993)
partners: EC 36.1%. developing countries
27.4%, East and Central Europe 14.9%, EFTA
5.1%. Russia 5%. Japan 1 .4%. US 1 .3% ( 1993)
Imports: $5.4 billion (f.o.b., 1993)
commodities: minerals 29%. machinery and
equipment 17.2%, textiles 10%, agricultural
goods 9% (1993)
partners; EC 45.8%. East and Central Europe
8.6%. developing countries 22.6%, Russia
1 1%, EFTA 6.2%, US 5.0%, Japan 0.8%
(199.3)
External debt; $4 billion ( 1993)
Industrial production: growth rate -I %
(1993 est.); accounts for 45% of GDP
Electricity:
capacity; 22.500.000 kW
production; 59 billion kWh
con.sumption per capita; 2.540 kWh (1992)
Industries: mining, timber, construction
materials, metallurgy, chemicals, machine
building, food processing, petroleum
production and refining
Agriculture: accounts for 1 8% of GDP and
28% of labor force; major wheat and com
producer; other products — sugar beets,
sunflower seed, potatoes, milk, eggs, meat,
grapes
Illicit drugs: transshipment point for
southwest Asian heroin and Latin American
cocaine transiting the Balkan route
Economic aid: SNA
Currency: I leu (L) = 100 bani
Exchange rates: lei (L) per US$1 — 1,387. 16
(January 1994). 760.05 (199.3). .307.95 (1992).
76..39 (1991). 22.4,32 (1990), 14.922 (1989)
Fiscal year: calendar year
328
Russia
Overview; Russia, a vast country with a
wealth of natural resources, a well-educated
population, and a diverse industrial base,
continues to experience severe difficulties in
moving from its old centrally planned
economy to a modem market economy.
President YELTSlN’s government has made
some progress toward a market economy by
freeing most prices, stashing defense spending,
unifying foreign exchange rates, and launching
an ambitious privatization program. Yet much
of the old order persists and YELTSIN faces
formidable opposition to further measures such
as the reduction of subsidies to old-line
industries. Output continues to fall although
the mix is gradually becoming more responsive
to Russia''s needs. According to Russian
official data, GDP declined by 12% in 1993
compared with 19% in 1992. Industrial output
in 1^3 fell 16% with all rntyor sectors taking
a hit. Agricultural production, meanwhile, was
down 6%. The grain harvest totalled 99 million
tons — some 8 million tons less than in 1992.
Unemployment climbed in 1993 but remained
low by Western standards. The official number
01 unemployed rose from 578,000 at the
beginning of 1993 to about 1 million — or
roughly 1 ,4% of the work force — by yearend.
According to the Russian labor minister, the
actual number of unemployed probably was
closer to 4 million. Government fears of large-
scale unemployment continued to hamper
industrial restnicturing efforts. According to
official statistics, average real wages remained
flat. Nonetheless, a substantial portion of the
population, particularly the elderly and people
in remote areas, finds its well-being steadily
shrinking. The disparity in incomes between
the rich and poor continued to rise in 1993,
[irimarily reflecting the high earnings of
enterprise managers and persons employed in
the emerging private sector. The government
tried to narrow the income gap by raising the
wages of budget-funded workers — mainly
teachers and health care specialists. Official
data may ovei-s- ite hardships, because many
Russians supplement their income by
moonlighting or by bartering goods and
services, activities that often go unrepoied.
Russia made good progress on privatization in
1993 despite active opposition from key
cabinet members, haid-line l^islators, and
antireform regional leaders. By yearend, for
example, ^ughly 35% of Russia''s medium and
large state enterprises had been auctioned,
while the number of private farms in Russia
increased by 86,0(X), reaching a total of
I70,(X)0. As a result, abrait 6% of agricultural
land now has been privatized. Financial
stabilization continued to remain a challenge
for the government. Moscow tightened
financial policies in early 1993 — including
postponing planned budget spending — and
succeeded in reducing monthly inflation from
27% in January to 20% in May and June. In the
summer, however, the government relaxed
austerity measures in the face of mounting
pressure from industry and agriculture,
sparking a new round of inflation: the monthly
inflation rate jumped to 25% in August. In
response, Moscow announced a package of
measures designed to curb government
spending and inflation. It included eliminating
bread subsidies, delaying payment obligations,
raising interest rates, and phasing out
concessionary Central Bank credits to
enterprises and regions. The measures met with
some success; the monthly inflation rate
declined to 13% in December. According to
official statistics, Russia''s 1993 trade with
nations outside the former Soviet Union
produced a $16 billion surplas, up from $6
billion in 1992. Moscow arrested the steep
drop in exports that it had been suffering as a
result of ruptured ties with former trading
partners, output declines, and erratic efforts to
move to world prices. Foreign sales —
comprised largely of oil, natural gas, and other
raw materials — grew slightly. Imports were
down by 15% or so as a result of new import
taxes and Moscow''s reluctance to increase its
debt burden by purchasing grain and other
goods with foreign credits. Russian trade with
other former Soviet republics continued to
decline and yielded a surplus of some $5
billion. At the same time. Russia paid only a
fraction of the roughly $20 billion in debt
coming due in 1993. and by mid-year. Russia''s
foreign debt had amounted to $81.5 billion.
While M0.SC0W reached agreement to
restructure debts with Paris Club official
creditors in April 1993. Moscow''s refu.sal to
waive its right to sovereign immunity kept
Russia and its bank creditors from agreeing to
restructure Moscow''s commercial loans.
Capital flight continued to be a serious problem
in 1 993. with billions of dollars in assets owned
by Russians being parked abroad at yearend.
Russia''s capital stock continues to deteriorate
because of insufficient maintenance and new
construction. The capital stock on average is
twice the age of capital stock in the We.st.
Many years will pass before Russia can take
full advantage of its natural resources and its
human assets.
NbRoimI product: GDP— purchasing power
equivalent — $775.4 billion (1993 estimate
from the UN International Comparison
Program, as extended to 1991 and published in
the World Bank''s World Development Report
1 993; and as extrapolated to 1993 using official
Russian statistics, which are very uncertain
because of major economic changes since
1990)
National product real growth rate: -12%
(1993 est.)
National product per capita: $5,190(1993
est.)
Inflation rate (consumer prices): 2 1 % per
month (average 1993); 13% per month
(December 1993)
Unemployment rate; 1.4% (I January 1994;
official data)
Budget:
revenues: SNA
expenditures; $NA, including capital
expenditures of SNA
Exports: $43 billion (f.o.b., 1993)
commodities; petroleum and petroleum
products, natural gas, wood and wood
products, metals, chemicals, and a wide variety
of civilian and military manufactures
parmers; Europe, North America, Japan, Third
World countries, Cuba
Imports: $27 billion (f.o.b., 1993)
commodities; machinery and equipment,
chemicals, consumer goods, grain, meat, sugar,
semifinished metal products
partners; Europe, North America, Japan, ''Third
World countries, Cuba
External debt; $81.5 billion (mid-year 1993
est.)
Industrial production; growth rote -16%
(1993 e.st,)
Electricity:
capacity’: 2 1 3,(XX),000 KW
pnuiuction: 956 billion kWh
consumption per capita; 6,782 kWh ( 1
January 1992)
Industries; complete range of mining and
extractive industries producing coal, oil, gas,
chemicals, and metals; all forms of machine
building from rolling mills to high-
performance aircraft and space vehicles; ship¬
building; road and rail transportation
equipment: communications equipment;
agricultural machinery, tractors, and
construction equipment; electric power
generating and transmitting equipment:
medical and scientific instruments; consumer
durables
Agriculture: grain, sugar beet, sunflower
seeds, meat, milk, vegetables, fruits: because
of its northern location does not grow citrus,
cotton, tea, and other warm climate products
Illicit drugs; illicit cultivator of cannabis and
opium poppy: mostly for domestic
consumption; government has active
eradication program; used as transshipment
point for Asian and Latin American illicit
drugs to Western Europe and Latin America
331
Russia (continued)
Since 1986 the government has acted to
rehabilitate and stabilize the economy by
undertaking currency reform, raising pr^ucer
prices on export crops, increasing prices of
petroleum products, and improving civil
service wages. The policy changes are
especially aimed at dampening inflation, which
was running at over 300% in 1987, and
boosting production and export earnings. In
1990-93, the economy has turned in a solid
performance based on continued investment in
the rehabilitation of infrastructure, improved
incentives for production and exports, and
gradually improving domestic security.
National pr^uct: GDP — purchasing power
equivalent — $24,1 billion (1993 esi.)
National product real growth rate: 6%
(1993 est.)
National product per capita; $ 1 ,200 ( 1 993
est.)
Inflation rate (consumer prices): 41.5%
(1992 est.)
Unemployment rate: NA%
Budget:
revenues: $365 million
expenditures: $545 million, including capital
expenditures of $ 1 65 million ( 1 989 est.)
Exports: $150 million (f.o.b., 1992 est.)
commodities: coffee 97%, cotton, tea
partners: US 25%, UK 18%, France 1 1%,
Spain 10%
Imports: $513 million (c.i.f., 1992 est.)
commodities: petroleum products, machinery,
cotton piece goods, metals, transportation
equipment, food
partners: Kenya 25%, UK 14%. Italy 13%
External debt: $1.9 billion (1991 est.)
Industrial production: growth rate 8.0%
( 1992 est.); accounts for 5% of GDP
Electricity:
capacity: 200,000 kW
production: 610 million kWh
consumption per capita: 30 kWh (1991)
Industries: sugar, brewing, tobacco, cotton
textiles, cement
Agriculture: mainly subsistence; accounts
for 57% of GDP and over 80% of labor force;
cash crops — coffee, tea, cotton, tobacco; food
crops — cassava, potatoes, com, millet, pulses;
livestock products — beef, goat meat, milk,
poultry; .self-sufficient in food
Economic aid:
recipient: US commitments, including Ex-lm
(1970-89), $145 million: Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $1,4 billion; OPEC
bilateral aid (1979-89), $60 million;
Communist countries (1970-89), $169 million
Currency; I Ugandan shilling (USh) = 100
cents
Exchange rates: Ugandan shillings (USh) per
US$1— -1,1 65.0 (November 1993), 1.133.8
(1992), 734.0 (1991), 428.85 (1990), 223.1
(1989)
Fiscal year: 1 July — 30 June
Overview: After Russia, the Ukrainian
republic was far and away the most important
economic component of the former Soviet
Union producing more than three times the
output of the next-ranking republic. Its fertile
black soil generated more than one-fourth of
Soviet agricultural output, and its farms
provided substantial quantities of meal, milk,
grain and vegetables to other republics.
Likewise, its diversified heavy industry
supplied equipment and raw materials to
industrial and mining sites in other regions of
the former USSR. In 1992 the Ukrainian
Government liberalized most prices and
erected a legal framework for privatizing state
enterprises while retaining many central
economic controls and continuing subsidies to
.state production enterprises. In November
1992 the new Prime Minister KUCHMA
launched a new economic reform program
promising more freedom to the agricultural
sector, faster privatization of small and
medium enterprises, and stricter control over
Slate subsidies. In 1993, however, severe
internal political disputes over the scope and
pace of economic reform and payment arrears
on energy imports have led to further declines
in output, and inflation of S0% or more per
month by the last quarter. In first quarter 1994,
national income and industrial ouqiut were less
than two-thirds the first quarter 1^.3 figures,
according to official statistics. At the same
time an increasing number of people are
developing small private businesses and
exploiting opportunities in non-official
markets. Even so, the magnitude of the
problems and the slow pace in building new
market-oriented institutions preclude a near-
term recovery of output to the 1990 level. A
vital economic concern in 1994 will continue
to be Russia''s decisions on the prices and
quantities of oii and gas to be shipped to the
Ukraine.
National product: GDP — purchasing power
equivalent — $205.4 billion (1993 estimate
from the UN International Comparison
Program, as extended to 1991 and published in
the World Bank''s World Development Report
1993; and as extrapolated to 1 993 using official
Ukrainian statistics, which are very uncertain
because of major economic changes since
1990)
National product real growth rate: -16%
(1993 est.)
National product per capita; $3,960(1993
est.)
Inflation rate (consumer prices): 45% per
month (1993)
Unemployment rate: 0.4% officially
registered; large number of unregistered or
underemployed workers
Budget:
revenues: SNA
expenditures: SNA, including capital
expenditures of SNA
Exports: S3 billion to countries outside of the
FSU(I993)
commodities: coal, electric power, ferrous and
nonferrous metals, chemicals, machinery and
transport equipment, grain, meal
partners: FSU countries, Germany, China,','ef3c72befa2d1611684fc716d7b8d6e01e51e51fff079fb6f5f1021658693d4e','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55302bf7193b5e5b81af6874c6b2b4e2fffa4ffd52fc3cdbb5b081181e10d6cc',1994,'ER','Eritrea','economy',367,'Overview: With the independence of Eritrea
on 27 April 1993, Ethiopia continues to face
difficult economic problems as one of the
poorest and least developed countries in
Africa. (The accompanying analysis and
figures predate the independence of Eritrea.)
Its economy is based on subsistence
agriculture, which accounts for about 45% of
GDP, 90% of exports, and 80% of total
employment; coffee generates 60% of export
earnings. The manufacturing sector is heavily
dependent on inputs from the agricultural
sector. Over 90% of large-scale industry, but
less than 10% of agriculture, is stale run; the
government is considering selling off a portion
of state-owned plants. Favorable agricultural
weather largely explains the 4.5% growth in
output in FY89, whereas drought and
deteriorating internal security conditions
prevented growth in FY90. In 1991 the lack of
law and order, particularly in the south,
interfered with economic development and
growth. In 1992, because of some easing of
civil .strife and aid from the outside world, the
economy substantially improved.
National product: (JDP — purchasing power
equivalent — $22.7 billion (1993 est.)
National product real growth rate: 7.8%
(FY93 est)
National product per capita; $400 ( 1 993
est.)
Inflation rate (consumer prices): 2 1 %
(1992 est)
Unemployment rate: NA%
Budget:
revenues: SNA
expenditures: $1.2 billion, including capital
expenditures of SNA ( 1992 est.)
Exports: $189 million (f.o.b..FY9 1 )
commodities: coffee, leather products, gold
petroleum products
partners: Germany. Japan, Saudi Arabia,
France, Italy
Imports: $472 million (c.i.f.,FY9 1 )
commodities: capital goods, consumer goods,
fuel
partners: US. Germany. Italy. Saudi Arabia,','bf48649dc8f08b9cd003fd83cf9a210b6233b4cbaac5bdc0f2ea185704ccf9af','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f7c071e87fe565e596bf353ba9bd96b24b1af8dee8c4864c1a61c49cabc6655',1994,'JP','Japan','economy',368,'External debt: $3.48 billion ( 1991 )
Industrial production: growth rate -3.3%
vFY92); accounts for 12% of GDP
Electricity:
capacity: 330,000 kW
production: 650 million kWh
consumption per capita: 1 0 kWh (1991)
Industries: food processing, beverages,
textiles, chemicals, metals processing, cement
Agriculture: accounts for 47% of GDP and is
the most important sector of the economy even
though frequent droughts and poor cultivation
practices keep farm output low; famines not
uncommon; export crops of coffee and oilseeds
grown partly on state farms; estimated 50% of
agricultural production at subsistence level;
principal crops and livestock — cereals, pulses,
coffee, oilseeds, sugarcane, potatoes and other
vegetables, hides and skins, cattle, sheep, goats
Illicit drugs; transit hub for heroin originating
in Southwest and Southeast Asia and destined
for Europe and North America as well as
cocaine destined for southern African markets;
cultivates qat (chat) for local use and regional
export
Economic aid:
recipient: US commitments, including Ex-lm
{FY70-89), $504 million; Western (non-US)
countries, ODA and (X)F bilateral
commitments (1970-89), $3.4 billion; OPEC
bilateral aid (1979-89), $8 million; Communist
countries (1970-89), $2 billion
Currency: I birr (Br) = 100 cents
Exchange rates: birr (Br) per US$1 — 5.0000
(fixed rate since 1992); fixed at 2.070 before
1992
Fiscal year: 8 July — 7 July
Overview: Jan Mayen is a volcanic island
with no exploitable natural resources.
Economic activity is limited to providing
services for employees of Norway’s radio and
meteorological stations located on the island.
Electricity;
capaciiy: I.S.()0()kW
imHiui''iion; 4() million kWh
conxumpiiim per capita: NA ( l<)92)
Overview; Government-industry
cooperatitm. a siixmg work ethic, mastery of
high technology, and a comparatively small
defense alliK''ation have helped Japan advance
w ith extraordinary rapidity to the rank of
second mos; powerful c*conomy in the world.
Industry . the most important sector of the
economy, is heavily dependent on imported
raw materials and fuels. .Self-sufficient in rice,
Japan must import about 5()‘^ of its
requirements of other grain and fodder crops.
Japan maintains one of the world''s largest
fishing Heels and accounts for nearly I5''3 of
the global catch. Overall economic giowth has
been spectacular: a lO''V average in the I9b()s.
a 5*^4 average in the |97()s and I98()s,
Economic growth came to a halt in 1992-9.3
largely because ol contractionary domestic
ptvlicies intended to wring speculative exces.ses
from the stock and real estate markets. At the
same time, the stnmgcr yen and slower global
growth are containing expttrt growth.
Unemployment and intlation remain
remarkably low in comparison with the other
industrialized nations. Japan continues to run a
huge trade suiplus — $120 billion in 199.3, up
more than lO''/f fn>m the year earlier — which
supports extensive investment in foreign
assets. The new prime minister HATA in early
1994 reiterated previous govemnK''nts'' vow s of
administrative and economic reform, including
reduction in the trade surplus, but his weak
coalition government faces stnmg resistance
from traditional interest groups. The crxrwding
of the habitable land area and the aging of the
population are two major long-run problems.
Nailoiiiil product: GDP — purchasing power
equivalent — S2..549 trillion (199.3)
NalloiHil product real growth rate: 0*^
(199.3)
National product per capita: $2(),4(N)
(199.3)
Inflation rate (consumer prices); l..3(F
(199.3)
Unemptoyment rate: 2.5''4 ( 199.3)
Budgrt:
revenues: $490 billion
e.xitendiwres: $579 billion, including capital
expenditures (public works only) of about $68
billion (FY9.3)
Exports: $.360.9 billion .;f.o.b.. 199.3)
commihlities: manufactures 97fF (including
machinery 46‘''>f . navtor vehicles 20(3 .
consumer electronics 10(3)
partners: Southeast Asia .3.3(3. US 29(3.
Western Europe 18(3, China 5''3
Imports: $240,7 billion (c.i.f.. 199.3)
comniiHliiies: manufactures 52''/3, fossil fuels
20(3. fixxtsiuffs and raw materials 28(3
(Htrtners. Southeast Asia 25(3. US 2.3(3.
Western Europe 1 5''3, China 9''3
External debt: SNA
Industrial production: giowih rate -4.0(3
(199.3) : aevounts for ,30(3 of GDP
Electricity:
caiHicity: l%.0(K).(H)0 kW
prtHluction: 8.35 billion kWh
consumption iht capita: 6.7(X) kWb ( 1992)
Industries: steel and non-ferrous metallurgy,
heavy electrical equipment, construction and
mining equipment, motor vehicles and parts,
electronic and telecommunication equipment
and contponents, machine tixils and automated
pntduction .systems, kx''omotives and railioad
rolling suK''k. shipbuilding, chemicals, textiles,
fiHid priK''essing
Agriculture: accounts for only 2(3 of GDP;
highly subsidized and protected .sector, with
crop yields among highest in world: principal
crops — rice, sugar beets, vegetables, fruit:
animal products include pork, poultry, dairy
and eggs: about 50(3 self-sufficient in fixxl
production; shortages of wheat, com.
soybeans; world''s largest fish catch of 10
million metric tons in 1991
Economic aid:
donor: ODA and (X)F commitments (1970-
9.3), $12.3 billion
note: ODA outlay of $9.9 billion in 1994 (est.)
Currency: yen(V)
Exchange rates: yen (¥ ) per US$ I — 1 1 1 .5 1
(Januarv 1994), 1 1 1. 20 ( 199.3). 126.65 ( 1992),
1.34,7 1(1 991). 144.79(1990). 1.37.96(1989)
JlpMII (itmilinurd)
Jarvis Island
(territory of the US}
FImlytw: I April— -31 March
27.327 km total: 2,012 km I.43.S.
CM.)
Dalh— •ipMSamw exchange rate
conx-emlon— $37 billion. 0.94% of ODP
(FY‘».3me»i.)
I «m
meter Mandanl gauge and 2.3,3 1 .3 km
predominantly l.tir)7-meiernuTnw gauge:
.3,724 km douhletrack and muliitrack sections,
9.038 km 1.067-meier narrow-gauge
electrified. 2,012 km 1.4.3.3-meter standard-
gauge electrined ( 1987)
Hlijiwnjrs:
total: l.l I.3,fl09 km
paved: 782,042 km (including 4,869 km of
national expressways)
unpaxed: gravel, crushed stone, or earth
,3.3.3.567 km (1991)
Inlnid waterways: about 1, 770 km; seagoing
craft ply all coastal inland seas
Plpelliics; crude oil 84 km: petroleum
piquets 322 km: natural gus 1,800 km
Parts: Chiba, Muroran, Kitakyushu, Kobe,
Tomakomai, Nagoya, Osaka, Tokyo,
Yokkaichi. Yokohama. Kawasaki, Niigata,
Fushiki-Toyama, Shimizu, Himeji,
Wakayama-Shimozu, Shimonoseki.
Tokuyama-Shimomatsu
Mcr^nt imrlnc: 926 ships (1.000 CRT or
over) totaling 20,383.101 ORT/.31. 007,5 1.3
DWT, passenger 10, short-sea passenger 36,
passenger cargo 3. cargo 76. container 44. roll¬
on/roll-off cargo 44, refrigerated cargo 66.
vehicle carrier 94. oil tanker 265, chemical
tanker 9, liquefled gas 42, combination ore/oil
9, specialized tanker 2. bulk 225, multi¬
function large load carrier I
note: Japan also owns a large flag of
convenience fleet, including up to 38^ of the
total number of ships under the Panamanian
flag
Airports:
total: 167
usable: 165
with permanent-surface runways: 1 ,37
xvith noiums over .1659 m: 2
xviih runways 2,44()-.i.659 m: .34
with runways 1,220-2,459 m: ,32
Telecommunications: excellent domestic
and international service; 64.000.000
telephones; broadcast stations— 318 AM. 58
FM, l2..350TV(l%major— I kw or greater);
satellite earth stations — 4 Pacific Ocean
INTELSAT and 1 Indian Ocean INTELSAT;
submarine cables to US (via Guam),
Philippines, China, and Russia
Defense Forces
Branches: Japan Ground Self-Defense Force
(Army), Japan Maritime Self-Defense Force
(Navy), Japan Air Self-Defense Force (Air
Force). Maritime Safety Agency (Coast Guard)
Manpower availability: males age 15-49
32.044,032; fit for military service 27,597.444;
reach military age( 18) annually 95.3.928 ( 1994
Geagraphy
Lacation: Oceania, Polynesia, in the South
Pacific Ocean. 2,090 km south of Honolulu,
just south of the Equator, about halfway
between Hawaii and the Cook Islands
Map references: Oceania
Area:
total area: 4.5 sq km
land area: 4.5 sq km
comparative area: about 7.5 times the size of
The Mall in Wa.shington. DC
Land boiindartet: 0 km
Coastline: 8 km
Maritime claims:
contiguous zone: 24 nm
continental shelf; 200-m depth or to depth of
exploitation
exclusive ectmomic ztme: 200 nm
territorial sea: 1 2 nm
International dispates: none
CMmale: tropical: scam rainfall, constant
wind, burning sun
Terraia: sandy, coral island surrounded by a
narrow fringing reef
Natural resources; guamv (deposits worked
until late 1800s)
Land use:
arable land:
pemutneni crops: 03f
meadows and pastures: 0*4-
finest and wimdland: 09(
other: 1009-
Irrigated land: Osqkm
Eavironmcnl:
current issues: lacks fresh water
natural hazards: NA
intematitmal agreements: NA
Note: sparse bunch grass, prostrate vines, and
low-growing shrubs; primarily a nesting,
nxisting. and foraging habitat for seabirds,
shorebirds. and marine wildlife; feral cals
Population: uninhabited; note — Millersville
settlement on western side of island
204
occasionally used as a weather station from
1935 until World War II, when it was
abandoned; reoccupied in 1957 during the
International Geophysical Year by scientists
who left in 1958: public entry is by special-use
permit only and generally restricted to
scientists and educators
Overview; no economic activity
Overview: The driving force behind the
economy''s dynamic growth has been the
planned development of an export-oriented
economy in a vigorously entrepreneurial
society. Real GNP increased more than 10%
annually between 1986 and 1991. This growth
ultimately led to an overheated situation
characterized by a tight tabor market, strong
inflationary pressures, and a rapidly rising
current account deficit. As a result, in 1992.
economic policy focused on slowing the
growth rate of inflation and reducing the
deficit. Annual growth slowed to 5%, still
above the rate in most other countries of the
world. Growth increased to 6.3% in 1993 as a
result of fourth quarter manufacturing
production growth of over 10% and is expected
to be in the 8% range for 1994,
National product: GNP— purchasing power
equivalent — $424 billion ( 1993 est.)
National product reai growth rate: 6.3%
(199.3)
National product per capita: $9,500 (199.3
es? )
Inflation rate (consumer prices): 4.8%''
(1993)
Unemployment rate: 2.5% (October 1993)
Budget:
revenues: $48,4 billion
expenditures: $48.4 billion, including capital
expenditures of $NA (1993 est.)
Exports; $81 billion (f.o.b.. 1993)
commodities: electronic and electrical
equipment, machinery, .steel, automobiles,
ships, textiles, clothing, footwear, fish
partners: US 26%, Japan 17%, EC 14%
Imports: $78.9 billion (c.i.f., 1993)
commodities: machinery, electronics and
electronic equipment, oil, steel, transport
equipment, textiles, organic chemicals, groins
partners; Japan 26%. US 24%, EC 15%
External debt; $42 billion (1992)
Industrial production: growth rate 5.0%
( 1992 est,): accounts for about 45% of GNP
Electricity:
capacity: 27.016 kW (1993)
prtkiuction: 105 billion kWh (1992)
consumption per capita: 2.380 kWh ( 1992)
Industries: electronics, automobile
production, chemicals, shipbuilding, steel,
textiles, clothing, footwear, food processing
Agriculture: accounts for 8% of GNP and
employs 21% of work force (including fishing
and forestry); principal crops — rice, root crops,
barley, vegetables, fruit; livestock and
livestock products — cattle, hogs, chickens,
milk, eggs; self-sufficient in food, except for
wheat; fish catch of 2.9 million metric tons,
.seventh-largest in world
Economic aid:
recipient: US commitments, including Ex-Im
(FY70-89), $3.9 billion; non-US countries
(1 970-89), $3 billion
Currency: I South Korean won (W) = 100
Chun (theoretical)
Exch.vtige rates: South Korean won (W) per
US$1— 8 10.48 (January 1994), 802.68 (1993),
780.65 (1992), 7.33.-35 (1991), 707,76 (1990).
671.46(1989)
Fiscal year: calendar year
Imports: $1.03 billion (c.i.f., 1993 est.)
commodities: food, clothing, farm equipment,
petroleum
partners: US, Western Europe, USSR
External debt; SS billion (1992 est.)
Industrial production: growth rate 5% ( 1 989
est.)
Electricity:
capacity: 2,270,000 kW
production: 1 .745 billion kWh
consumption per capita: 1 1 5 kWh (1991)
Industries; food, beverages, chemicals
(fertilizer, soap, paints), petroleum products,
textiles, nonmetallic mineral products (cement,
glass, asbestos), tobacco
Agriculture: accounts for 50% of GDP and
about 90% of exports; cash crops — cotton,
cashew nuts, sugarcane, tea, shrimp; other
crops — cassava, corn. rice, tropical fruits; not
self-sufficient in food
Economic aid:
recipient: US commitments, including Ex-Im
(FY70-89), $350 million; Western (non-US)
countries. ODA and OOF bilateral
commitments (1970-89), $4,4 billion; OPEC
bilateral aid (1979-89), $37 million;
Communist countries (1970-89), $890 million
Currency: I metical (Mt) = I (X) centavos
Exchange rates; meticais (Mt) per US$1 —
4,941.3 (October 1993). 2.550.40 ( 1992).
1 ,763,99 (1991),! ,053,09 ( 1 990), 844,34
(1989)
Fiscal year: calendar year
External debt: $845 million (1 99 1 est.)
Industrial production: growth rate -2.2%
(1991); accounts for 17% of GDP
333
Rwanda (continued)
Saint Helena
(dependent territory of the UK)
Electricity:
capacity: 30,000 kW
production: 130 million kWh
consumption per capita: 1 5 kWh (1991)
Industries: mining of cassiterite (tin ore) and
wolframite (tungsten ore), tin, cement,
agricultural processing, small-scale beverage
production, soap, furniture, shoes, plastic
goods, textiles, cigarettes
Agriculture: accounts for almost 50% of
GDP and about 90% of the labor force; cash
crops — coffee, tea, pyrethrum (insecticide
made from chrysanthemums); main food
crops — bananas, beans, sorghum, potatoes;
stock raising; self-sufficiency declining;
country imports foodstuffs as farm production
fails to keep up with a 2.8% annual growth in
population
Economic aid:
recipient: US commitments, including Ex-Im
(FY70-89), $128 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $2 billion; OPEC
bilateral aid (1979-89), $45 million;
Communist countries (1970-89), $58 million
note: in October 1 990 Rwanda launched u
Structural Adjustment Program with the IMF;
since September 1991, the EC has given $46
million and the US $25 million in support of
this program (1993)
Currency: 1 Rwandan franc (RF) = 100
centimes
Exchange rates: Rwandan francs (RF) per
US$1— 145.45 (December 1993). 133.35
( 1 992), 1 25. 1 4 ( 1 99 1 ), 82.60 ( 1 990), 79.98
(1989)
Fiscal year: calendar year
Overview: The economy depends primarily
on financial assistance from the UK. The local
population earns some income from fishing,
the raising of livestock, and sales of
handicrafbi. Because there are few Jobs, a large
proportion of the work force has left to seek
employment overseas.
National product: GDP SNA
National product real growth rate; NA%
Natiorul product per capita; SNA
Inflation rate (consumer prices)* •!.'' %
(1986)
Unemployment rate: NA%
Budget;
revenues: $3.2 million
expenditures; $2.9 million, including capital
expenditures of SNA (1984 est.)
Exports: S23.9(X) (f.o.b., 1984)
commodities; fish (frozen and salt-dried
skipjack, tuna), handicrafts
partners: South Africa, UK
Imports: $2.4 million (c.i.f., 1984)
commodities; food, beverages, tobacco, fuel
oils, animal feed, building materials, motor
vehicles and parts, machinery and parts
partners; UK, South Africa
External debt: SNA
Industrial production: growth r: :''.e NA%
Electricity:
capacity; 9,800 kW
production; 10 million kWh
consumption per capita; 1 ,390 kWh ( 1 989)
Industries: crafts (furniture, lacework, fancy
woodwork), fishing
Agriculture: maize, potatoes, vegetables;
timber production being developed;
crawfishing on Tristan da Cunha
Economic aid;
recipient; Western (non-US) countries. ODA
and OOF bilateral commitments (1992-93),
$13.5 million
Currency: I Saint Helenian pound (£$) s 100
pence
Exchange rates: Saint Helenian pounds (£S)
per US$1— 0.6699 (January 1994), 0.6033
(1993), 0.5664 (1992), 0.5652 (1991), 0.5603
(1990), 0.6099 (1989); note— the Saint
Helenian pound is at par with the British pound
Fiscal year; 1 April — 31 March
Overview: The economy has historically
depended on the growing and processing of
sugarcane and on remittances from overseas
workers. In recent years, tourism and export-
oriented manufacturing have assumed larger
roles.
National product: GDP — exchange rate
conversion — $163 million (1992)
National product real growth rate: 4.1%
(1992)
National product per capita: $4,(X)0 (1992)
Inflation rate (consumer prices): 2.9%
(1992)
Unemployment rate: 1 2.2% ( 1 990)
Budget:
revenu ''s: $85.7 million
expenditures: $85.8 million, including capital
expenditures of $42.4 million (1993 est.)
Exports: $32.4 million (fo.b., 1992)
commodities: sugar, clothing, electronics,
postage stamps
partners: US 53%, UK 22%, Trinidad and
Tobago 5%. OECS 5% (1988)
Imports: $100 million (f.o.b.. 1992)
commodities: foodstuffs, intermediate
336','2cacf6189b283cf9929aaf478d2f3f9313e38f1e8ba3fb09d10cd7c2b22b97af','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23377d0dc2673e818f033cff87123fd79178844cfda1828568530ee8b006b45c',1994,'MG','Madagascar','economy',370,'Overview: no economic activity
Overview: no economic activity
Overview: Greece has a mixed capitalist
economy with the basic entrepreneurial system
overlaid in 1981-89 by a socialist system that
enlarged the public sector from 55% of GDP in
198! to about 70% in 1989. Since then, the
public sector has been reduced to about 60% of
GDP. Tourism continues as a major source of
foreign exchange, and agriculture is self-
sufficient except for meat, dairy products, and
animal feedstuffs. Over the last decade, real
GDP growth has averaged 1 .6% a year,
compared with the European Union average of
2.2%’. Inflation is four times the EU average,
and the national debt has reached 140% of
GDP. the highest in the EU. Prime Minister
PAPANDREOU will probably only make
limited progress correcting the economy''s
problems of high intlation. large budget deficit,
and decaying infrastructure. His economic
program suggests that although he will shun his
expansionary policies of the 1980s. he will
avoid tough measures needed to slow inflation
or reduce the state''s role in the economy. He
has limited the previous government''s
privati/ation plans, forexample. and has culled
for generous welfare spending and real wage
increases. In 1994, the GDP growth rate is
likely to remain low, and infialion probably
will accelerate, remaining the highest in the
EU. PAPANDREOU''S failure to improve the
country''s economic perfomiuncc will further
strain relations with the EU. Since Greece''s
accession to the then EC in 1981. Athens''
heavy reliance on EU aid — amounting to about
6% of Greek GDP annually — :ind its poor use
of Union Funds have riled Brussels. Its ailing
economy will continue to be a drag on
155
Greece (continued)
European economic and monetary union.
National product: GDP — purchasing power
equivalent — $93,2 biliion (1993)
National product real growth rate: 1 %
(1993)
National product per capita: $8,900 (1993)
Inflation rate (consumer prices): 14.4%
(1993)
Unemployment rate: 9.5% (1993)
Budget:
revenues: $28,3 billion
expenditures: $37.6 billion, including capital
expenditures of $5.2 billion (1994)
Exports: $6 billion (f.o.b., 1992)
commodities: manufactured goods 53%,
foodstuffs 34%, fuels 5%
partners: Germany 23%, Italy 18%, France
7%. UK 7%, US 4% (1992).
Imports: $23.3 billion (c.i.f., 1992)
commodities: manufactured goods 72%,
foodstuffs 15%, fuels 10%
partners: Germany 20%, Italy 14%, France
8%, Netherlands 7%, Japan 6% (1992)
External debt: $23.1 billion (1992)
Industrial production: growth rate -1.3%
(1992); accounts for 20% of GDP
Electricity:
capacity: 10,500.000 kW
production: 36.4 billion kWh
consumption per capita: 3,6 1 0 kWh ( 1 992)
Industries: food and tobacco processing,
textiles, chemicals, metal products, tourism,
mining, petroleum
Agriculture: including fishing and forestry,
accounts for 1 5% of GDP and 24% of the labor
force: principal products — wheat, com. barley,
sugar beets, olives, tomatoes, wine, tobacco,
potatoes; self-sufficient in food except meal,
dairy products, and animal feedstuffs
Illicit drugs: illicit producer of cannabis and
limited opium: mostly for domestic
production; serves as a gateway to Europe for
traffickers smuggling cannabis and heroin
from the Middle East and Southwest Asia to
the West and precursor chemicals to the East;
transshipment point for Southwest Asian
heroin transiting the Balkan route
Economic aid:
recipient: US commitments, including Ex-Im
(FY70-8I ), $525 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $1.39 billion
Currency: 1 drachma (Dr) = 100 lepta
Exchange rates: drachmae (Dr) per US$1 —
250.28 (January 1994), 229.26 (1993). 190.62
(1992), 182,27 (1991), 158.51 (1990), 162.42
(1989)
Fiscal year: calendar year
Overview: no economic activity
Overview: Madagascar is one of the poorest
countries in the world. Agriculture, including
fishing and forestry, is the mainstay of the
economy, accounting for over 30% of GDP
and contributing more than 70% of total export
earnings. Industry is largely confined to the
processing of agricultural products and textile
manufacturing: in 1991 it accounted for only
1 3% of GDP. In 1986 the government
introduced a five-year development plan that
stressed self-sufficiency in food (mainly rice)
by 1990, increased production for exports, and
reduced energy imports. Subsequently, growth
in output has been held back because of
protracted antigovernment strikes and
demonstrations for political reform.
National product: GDP — purchasing power
equivalent — $10.4 billion (1993 est.)
National product real growth rate: I %
(1992 est.)
National product per capita: $800 ( 1 993
est.)
Inflation rale (consumer prices): 20%
(1992 est.)
Unemployment rate: NA%
Budget:
revenues: $250 million
expenditures: $265 million, including capital
expenditures of $180 million (1991 est.)
Exports: $312 million (f.o.b.. 1991 est.)
commodities: coffee 45%. vanilla 20%. cloves
1 1%. shellfish, sugar, petroleum products
partners: France, Japan, Italy, Germany. US
Imports; $350 million (f.o.b.. 1992 est.)
commodities: intermediate manufactures 30%,
capital goods 28%, petroleum 15%, consumer
goods 14%’. food 13%
partners: France, Germany. UK. other EC, US
External debt: $4.4 billion (1991)
Industrial production: growth rate 5.2%
(1990 est.); accounts for 13% of GDP
Electricity:
capacity: 125,000 kW''
production: 450 million kWh
consumption per capita: 35 kWh (1991)
Industries: agricultural processing (meat
canneries, soap factories, breweries, tanneries,
sugar refining plants), light consumer goods
industries (textiles, glassware), cement,
automobile assembly plant, paper, petroleum
Agriculture: accounts for 3 1 % of GDP; cash
crops — coffee, vanilla, sugarcane, cloves,
cocoa; food crops — rice, cassava, beans,
bananas, peanuts; cattle raising widespread;
almost self-sufficient in rice
Illicit drugs: illicit producer of cannabis
(cultivated and wild varieties) used mostly for
domestic consumption
Economic aid:
recipient: US commitments, including Ex-Im
(FY70-89). $136 million: Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $3,125 billion;
Communist countries (1970-89), $491 million
Currency: I Malagasy franc (FMG) = 100
centimes
Exchange rates: Malagasy francs (FMG) per
US$1— 1.965.8 (January 1994), 1,864.0
(1992). 1.835.4(1991), 1.454.6 (December
1990), 1,603.4(1989)
Fiscal year: calendar year','064b7805023569433c4054bd6f5a96bc9ece89da7d501598c90360b40739159f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44d8764814011f1967dce64001f1371ba52c88964f848279d01df1efaaead6be',1994,'AR','Argentina','economy',375,'Overview: The economy is based on sheep
farming, which directly or indirectly employs
most of the work force. A few dairy herds are
kept to meet domestic consumption of milk and
milk products, and crops grown are primarily
those for providing winter fodder. Exports
feature shipments of high-grade wool to the
UK and the sale of postage stamps and coins.
Rich stocks of fish in the surrounding waters
are not presently exploited by the islanders. So
far, efforts to establish a domestic fishing
industry have been unsuccessful. In 1987 the
government began selling fishing licenses to
foreign trawlers operating within the Falklands
exclusive fishing zone. These license fees
amount to more than $40 million per year and
are a primary source of income for the
government. To encourage tourism, the
Falkland Islands Development Corporation nas
built three lodges for visitors attracted by the
abundant wildlife and trout fishing.
National product: GDP SNA
National product real growth rate: NA%
National product per capita; SNA
Inflation rate (consumer prices): 7.4%
(1980-87 average)
Unemployment rate: NA%; labor shortage
Budget:
revenues: $62.7 million
expenditures: $42.8 million, including capital
expenditures of SNA (FY90)
Exports: at least $14.7 million
commodities: wool, hides and skins, and meat
partners: UK, Netherlands, Japan (1987 est.)
Imports; at least $13,9 million
commodities: food, clothing, fuels, and
machinery
pwtners: UK. Netherlands Antilles (Curacao).
Japan ( 1987 e.st.)
External debt: $NA
Industrial production: growth rate NA%
Electricity:
capacity: 9.200 kW
production: 17 million kWh
consumption per capita: 8.940 kWh (1992)
Industries: wool and fish proces.sing
Agriculture: predominantly sheep farming:
small dairy herds: some fodder and vegetable
crops
Economic aid;
recipient: Western (non-US) countries. ODA
and OOF bilateral commitments (1992-93).
$87 million
Currency; 1 Falkland pound (£F) = 100
pence
Exchange rates: Falkland pound (£F) per
US$1 —0.6699 (January 1 994), 0,6658 ( 1 993),
0.5664 ( 1 992). 0.5652 (1991), 0.5604 ( 1 990),
0.6099 ( 1 989); note — the Falkland pound is at
par with the British pound
Fiscal year: I April — 3 1 March
Imports; $490 million from states outside the
FSU(I993)
commodities; machinery and parts, grain and
food, plastics and rubber, consumer durables,
textiles
partners; Russia, Azerbaijan, Uzbekistan,
Kazakhstan. Turkey
External debt; NEGL
Industrial production: growth rate 5.3%
(1993)
Electricity:
capacity; 2.920,000 kW
production; 13,1 billion kWh
consumption per capita; 3,079 kWh (1992)
Industries: natural gas, oil, petroleum
products, textiles, food processing
Agriculture: cotton, grain, anim al husbandry
Illicit drugs: illicit producer.;; cannabis and
opium; mostly for CIS consumption; limited
government eradication program; used as
transshipment points for illicit drugs from
Southwest Asia to Western Europe
Economic aid:
recipient; Turkmenistan has received about
$200 million in bilateral aid credits
Currency: Turkmenistan introduced its
national currency, the manat, on I November
1993
Exchange rates: NA
Fiscal year: calendar year','c2058aacaf8698d295a0373b0ccca1f971b5f6598af86c49bfecdabb3e934a1b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c63ef8d3e3aaba8e0f3e2c8a71844a64e7bfb7a8af79b49322e1ec5d0a2c146',1994,'JE','Jersey','economy',387,'Overview: Fiji’s economy is primarily
agricultural, with a large subsistence sector.
Sugar exports and tourism are the major
sources of foreign exchange, industry
contributes 1 3% to GDP, with sugar processing
accounting for one-third of industrial activity.
Roughly 250.(XX) tourists visit each year.
Political uncertainty and drought, however,
contribute to substantial fluctuations in
earnings from tourism and sugar. In 1992,
growth was approximately 3%, based on
growth in tourism and a lessening of labor-
management disputes in the sugar and gold¬
mining sectors. In 1993, the government’s
budgeted growth rate of 3% was not achieved
because of a decline in non-sugar agricultural
output and damage from Cyclone Kina.
National product: GDP — purchasing power
equivalent — $3 billion (1993 est.)
National product real growth rate: I %
(1993 est.)
National product per capita: $4,000(1993
est.)
Inflation rate (consumer prices): 5.6%
(1993 est.)
Unemployment rate; 5.9% (1991 est.)
Budget:
revenues: $455 million
expenditures: $546 million, including capital
expenditures of $NA (1993 est.)
Exports: $417 million (f.o.b., 1992)
commodities: sugar 40%. clothing, processed
fish, gold. lumber
partners: EC 26%. Australia 15%. Pacific
Islands 11%, Japan 6%
Imports: $517 million (c.i.f., 1992 est)
commodities: machinery and transport
equipment, petroleum products, food,
consumer goods, chemicals
partners: Australia 30%, NZ 17%, Japan 13%,
EC 6%, US 6%
External debt: $670 million ( 1 994 est.)
Industrial production: growth rate 7.5%
(1992 est.); accounts for 13% of GDP
Electricity:
capacity: 215,000 kW
production: 420 million kWh
consumption per capita: 560 kWh (1992)
132
Overview: The economy is based largely on
financial services, agriculture, and tourism.
Potatoes, cauliflower, tomatoes, and especially
flowers are important export crops, shipped
mostly to the UK. The Jersey br^ of dairy
cattle is known worldwide and represents an
important export earner. Milk products go to
the UK and other EU countries. In I9B6 the
finance sector overtook tourism as the main
contributor to GDP, accounting for 40% of the
island’s output. In recent years the government
has encouraged light industry to locate in
Jersey, with the result that an electronics
industry has developed alongside the
traditional manufacturing of knitwear. All raw
material and energy requirements are
imported, as well as a large share of Jersey''s
food needs.
National product: GDP SNA
National product real growth rate: 8%
(1987 est.)
National product per capita: SNA
Inflation rate (consumer prices): 8% ( 1988
est.)
Uiwmployment rate: NA%
Budget:
revenues: $308 million
e.xpenditures: S284.4 million, including capital
expenditures of SNA (1985)
Exports: SNA
commodities: light industrial and electrical
goods, foodstuffs, textiles
partners: UK
Imports: SNA
commodities: machinery and transport
equipment, manufacture goods, foodstuffs,
mineral fuels, chemicals
partners: UK
External debt: SNA
Industrial production: growth rate NA%
Electricity:
capacity: 50,000 kW standby
p^uction: power supplied by France
consumption per capita: NA (1992)
Industries: tourism, banking and finance,
dairy
Agriculture; potatoes, cauliflowers,
tomatoes: dairy and cattle farming
Economic aid: none
Currency: I Jersey pound (£J) = 100 pence
Exchange rates: Jersey pounds (£J) per
USS 1—0.6699 (January 1994). 0.6658 (1993),
0.5664 (1992). 0.5652 (1991). 0,5603 (1990).
0.6099 (1989); the Jersey pound is at par with
the British pound
Fiscal year; I April— 3 1 March
Comiminicatlons
Highways;
total: NA
paved: NA
unpaved: NA
Overview: Economic activity is limited to
providing services to US military personnel
and contractors kveated on the island. All food
and manufactured gttods must be imported.
Electricity: supplied by the management and
operations contractor
Overview: New Caledonia has mme than
25% of the world''s known nickel resources. In
recent years the ecom>my has suffered because
of depressed iniematiimal demand for nickel,
the principal source of export earnings. Only a
negligible armmnt of the land is suitable for
cultivation, and fixxl accounts for about 25%
of imports.
Notionol product: GNP— exchange rate
conversion — SI billion (1991 est.)
Notionol product real growth rate: 2.4%
(1988)
Natomal product per capMo: $6,000(1991
est.)
Inflation rale (comumer price*); 1.4%
(1990)
Unemplayment role; 16% (1989)
Budget:
revenues; $224 million
e.\\/>endirures; $21 1 million, including capital
expenditures of SNA ( 1985 est.)
Export*; $671 million tf.o.b.. 1484)
284
Overview: Slovenia was by far the most
prosperous of the former Yugoslav republics,
with a per capita income more than twice the
Yugoslav average, indeed not fur below the
levels in neighboring Austria and Italy.
Because of its strong ties to Western Europe
and the small scale of damage during its brief
fight for independence from Yugoslavia,
Slovenia has the brighte.st prospects among the
former Yugoslav republics for economic
recovery over the next few years. The
dissolution of Yugoslavia, however, has led to
.severe short-term dislocations in production,
employment, and trade tics. For example,
overall industrial production has fallen 26'';f
since 1990: particularly hard hit have been the
iron and steel, machine-building, chemical,
and textile industries. Meanwhile, the
continued fighting in other former Yugoslav
republics has led to further destruction of long-
e.stablished trade channels and to an influx of
lens of thousands of Croatian and Bosnian
refugees. The key program for breaking up and
privatizing major industrial firms was
established in late 1992. Despite slow progress
in privatization Slovenia has reasonable
prospects for an upturn in 1994. Bright spots
for enc''Xiraging Western investors are
Slovenia''s comparatively " ell-educated work
force, its developed infrastniciure. and its
Western business attitudes, but instability in
Croatia is a deterrent, Slovenia in absolute
terms is a small economy, and a little Western
investment wouid go a long way.
National product: GDP — purchasing power
equivalent — $15 billion (1993 esi.)
National product real growth rate: 0%
(1993 est,)
National product per capita: 37.600 ( 1 993
est.)
InBatlon rale (consumer prices): 22.99h
(1993)
Unemployment rate: IS.59i(l993)
Budget:
revenues; $NA
exi>enditures; SNA. including capital
expenditures of SNA
Exports: $5.1 billion (f.o.b., 1993)
commodities: machinery and transport
equipment 389(i, other manufactured goods
44%. chemicals 9%, food and live animals
4.6%, raw materials 3%, beverages and
tobacco less than 1% (1992)
partners; Germany 27%, Croatia 14%, Italy
13%. France 9% (1992)
Imports: $5.3 billion (c.i.f., 1993)
caniinodiiies; machinery and transport
equipment 35%, other manufactured goods
26,7%, chemicals 14.5%, raw materials 9.4%,
fuels and lubricants 7%, food and live animals
6% (1992)
partners; Germany 23%, Croatia 14%, Italy
14%, France 8%. Austria 8% (1992)
External debt: $1.9 billion
Industrial production: growth rate -2.8%
(1993); accounts for 30% of GDP
Electricity:
co/wefty; 2,900,000 kW
pi^HCtion; 10 billion kWh
consumption per capita: 5.090 kWh ( 1 992)
Industries: ferrous meiallurgy and rolling
mill products, aluminum reduction and rolled
prtxlucts. lead and zinc smelting, electronics
(including miliiaiy electronics), trucks, electric
power equipment, wood products, textiles,
chemicals, machine tools
Agriculture: accounts for 5% of GDP:
dominated by stock breeding (sheep and cattle)
and dairy funning; main crops — potatoes,
hops. hemp, fiux; an export surplus in these
commotlities; Slovenia must import many
other agricultural products and has a negative
overall trade balance in this sector
Illicit drugs; NA
Economic aid: $NA
Currency: I tolar (SIT) = 1(X) stotins
Exchange rates: tolars (SIT) per US$ I — 1 1 2
(June 1993), 28 (January 1992)
Fiscal year: calendar year
Overview: The economy is based on
subsistence agriculture, which occupies more
than 60% of the population and contributes
nearly 25% to GDP. Manufacturing, which
includes a number of agroprocessing factories,
accounts for another quarter of GDP. Mining
has declined in importance in recent years;
high-grade iron ore deposits were depleted in
1978, and health concerns cut world demand
for asbestos. Exports of sugar and forestry
products are the main earners of hard currency.
Surrounded by South Africa, except for a short
border with Mozambique, Swaziland is heavily
dependent on South Africa, from which it
receives 90% of its imports and to which it
sends about half of its exports.
National product: GDP — purchasing power
equivalent — $2.3 billion (1993 est.)
National product real growth rate: 1%
(1993 est.)
National product per capita: $2,500 (1993
est.)
Inflation rate (consumer prices): 1 1 %
(1993 est.)
Unemployment rate: 15% (1992 est.)
Budget:
revenues: $342 million
expenditures: $410 million, including capital
expenditures of $ 1 30 million ( 1 994 est.)
Exports: $632 million (f.o.b., 1993 est.)
commodities; sugar, edible concentrates, wood
pulp, canned fruit, citrus
partners: South Africa 50% (est.), EC
countries, Canada
Imports: $734 million (f.o.b., 1993 est.)
commodities; m^tor vehicles, machinery,
transport equipment, netroleum products,
foodstuffs, chemicals
partners; South Africa 90% (est.),
Switzerland, UK
External debt: $240 million (1992)
Industrial production: growth rate 2.6%
( 1991 ): accounts for 40% of GDP ( 1989)
Electricity:
capacity; 60,000 kW
production: 198 million kWh (1991)
emsumption per capita: 1 80 kWh (1991)
Industries: mining (coal and asbestos), wood
pulp, sugar
Agriculture: accounts for 23% of GDP and
over 60% of labor force: niosily subsistence
agriculture: cash crops— sugarcane, cotton,
maize, tobacco, rice, citrus fruit, pineapples;
other crops and livesttK''k — com, sorghum,
peanuts, cattle, goats, sheep; not self-sufficient
in grain
Economic aid:
recipient: bilateral aid ( 1991 ) $35 million of
which US disbursements $12 million. UK
disbursements $6 million, and Denmark $2
million; multilateral aid (1991 ) $24 million of
which EC disbursements $8 million
Currency: I lilangeni (E)= 100 cents
Exchange mtea: emalangeni (E) per US$ I—
.3.4551 (March 1994). 3.26.36 (1993). 2.8497
< '' 92). 2.7.56.3 ( 1991 ). 2.5863 ( 1990). 2.6166
(1989); note — the Swazi emalangeni is at par
with the South African rand
Fiscal year: I April — 31 March','d6af2ffa0359ede03529a33cab69ca6126ca20a7e73abfa0b07bef7969284223','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d8d3c3ab58a52dc47fd8a0622047fc6dd94168501843d4b1eb2b221d63717f4',1994,'FI','Finland','economy',388,'Industries: sugar, tourism, copra, gold, silver,
clothing, lumber, small cottage industries
Agriculture: accounts for 2^% of GDP;
principal cash crop is sugarcane: coconuts,
cassava, rice, sweet potatoes, bananas: small
livestock sector includes cattle, pigs, horses,
and goats; fish catch nearly .1,^,000 tons (1989)
Economic aid:
recipient: Western (non-US) countries, ODA
and OOF bilateral commitments (1980-89),
$815 million
Currency: I Fijian dollar (F$) = l(X) cents
Exchange rates; Fijian dollars (F$) per
US$1— 1.5239 (January 1994), 1.5418(1993),
1,5030(1992), 1.47.56(1991). 1.4809(1990),
1.4833(1989)
Fiscal year: calendar year
Overview; Finland has a highly
industrialized, largely free market economy,
with per capita output two-thirds of the US
figure. Its key economic sector is
manufacturing — principally the wood, metals,
and engineering industries. Trade is impiortant.
with the export of goods representing about
30% of GDP. Except for timber and several
minerals, Finland depends on imports of raw
materials, energy, and some components for
manufactured goods. Because of the climate,
agricultural development is limited to
maintaining self-sufficiency in basic products.
The economy, which experienced an average
of 4.9% annual growth between 1987 and
1989, sank into deep recession in 1991 as
growth contracted by 6.5%. The recession —
which continued in 1992 with growth
contracting by 4. 1 % — has been caused by
economic overheating, depressed foreign
markets, and the dismantling of the barter
system between Finland and the former Soviet
Union under which Soviet oil and gas had been
exchanged for Finnish manufactured goods.
The Finnish Government has proposed efforts
to increase industrial competitiveness and
efficiency by an increase in exports to Western
markets, cuts in public expenditures, partial
privatization of state enterprises, and changes
in monetary policy. In June 1991 Helsinki had
tied the markka to the European Union’s (EU)
European Currency Unit (ECU) to promote
stability. Ongoing speculation resulting from a
lack of confidence in the government’s policies
forced Helsinki to devalue the markka by about
12% in November 1991 and to indefinitely
break the link in September 1992. The
devaluations have boosted the competitiveness
of Finnish exports to the extent the recession
bottomed out in 1993 with renewed economic
growth expected in 1994. Unemployment
probably will remain a serious problem during
the next few years, with the majority of Finnish
firms facing a weak domestic market and the
troubled German and Swedish export markets.
Declining revenues, increased transfer
payments, and extensive funding to bail out the
banking system pushed the central
government’s budget deficit to nearly 13% in
1993. Helsinki continues to harmonize its
economic policies with those of the EU during
Finland’s current EU membership bid. In early
1995, Finland is expected to join the European
Union (formerly the European Community),
thus broadening European economic unity.
National product: GDP — purchasing power
equivalent — $81.1 billion (1993)
National product real growth rate: -2.6%
(1993)
National product per capita: $16,100
(1993)
Inflation rate (consumer prices): 2.1%
(1992)
Unemployment rate: 22% (1993)
Budget:
revenues; $26.8 billion
expenditures; $40.6 billion, including capital
expenditures of $NA (1992)
Exports; $23,4 billion (f.o.b., 1993)
commodities; timber, paper and pulp, ships,
machinery, clothing and footwear
partners: EC 53.2% (Germany 15.6%, UK
10.7%). EFTA 19.5% (Sweden 12.8%), US
5,9%, Japan 1.3%, Russia 2.8% (1992)
Imports; $18 billion (c.i.f.. 1993 est.)
commodities; foodstuffs, petroleum and
petroleum products, chemicals, transport
equipment, iron and steel, machinery, textile
yam and fabrics, fodder grains
partners; EC 47.2% (Germany 16.9%, UK
8.7%). EFTA 19.0% (Sweden 1 1.7%). US
6.1%. Japan 5.5%. Russia 7.1% (1992)
External debt: $30 billion (December 1993)
Industrial production: growth rate 7.6%
(1992 est.)
Electricity:
capacity: 1 3,500,000 kW
production; 55.3 billion kWh
consumption per capita; 1 1,050 kWh (1992)
Industries: metal products, shipbuilding,
forestry and wood processing (pulp, paper),
copper refining, foodstuffs, chemicals, textiles,
clothing
Agriculture: accounts for 5% of GDP
1.34
Overview: Aided by a long period of peace
and neutrality during World War I through
World War II, Sweden has achieved an
enviable standard of living under a mixed
system of high-tech capitalism and extensive
welfare benents. It has a nuxlera distribution
system, excellent internal and external
communications, and a skilled labor force.
Timber, hydropower, and iron ore constitute
the resvHirve base of an c%-»»m>my that is heavily
oriented toward foreign trade. Wvately owned
tirms acevHint for about 9()r{ of industrial
output, of which the engineering sector
accounts for 5()‘ii of output and exports. In the
last few years, however, this extraordinarily
favorable picture has been clouded by
inflation, ^rowing unemployment, and a
gradual loss of competitiveness in international
markets. Although Prime Minister BILDT''s
center -right minority coalition had hoped to
charge ahead with free-market-oriented
r«f»>rms. a skyrocketing budget deficit— aintost
14** of GDP in FY94 projections — and n.’ctHxl
unemployment have foresiulled many of the
plans. Unemployment in 199.1 is esiimaied at
around H''t with another .V4 in job training.
Continued heavy foreign exchange speculation
forced the government toevarperate in lute
1992 w ith the opposition .Svreial Deimicrats on
two crisis packages — one a severe austerity
pact and the other a program to spur industrial
competitivenes.s — which basically set
economic policy through 1997. In November
1992, Sweden broke its tie to the EC’s ECU,
and the krona has since depreciated about 25%
against the dollar. The government hopes the
boost in export competitiveness from the
depreciation will help lift Sweden out of its 3-
year recession. To curb the budget deficit and
bolster confidence in the economy, BILDT
continues to propose cuts in welfare benefits,
subsidies, defense, and foreign aid. Sweden
continues to harmonize its economic policies
with those of the EU in preparation for
scheduled membership by early 1995, which
will help to broaden European economic unity.
NnUoml product: GDP— purchasing power
equivalent — $153.7 billion (199.1)
NatlomI product real growth rate: -2.7%
(199.1)
NalioiMl product per capita: $17,600
(1993)
Innalhm rate (coasumer prices): 4.4%
( 199.1 est.)
Uncmploymcnl rale: 8.2% (199.1cm.)
IkudgH:
revenues; $45. 1 billion
expenditures: $73.1 billion, including capital
expenditures of SN.A (FY94)
Exports: $49.7 billion (fo b.. 1993 csi.)
commiH>ities: machinery. nKttor vehicles,
paper products, pulp and wood, iron and steel
products, chemicals, petroleum and petroleum
prcxlucts
IHiriners; EC 55.8% (Germany I5''''4. UK
9.7%. Denmark 7.2%. France 5.8%). EFTA
17.4% (Norway 8.4%, Finland 5,1%). US
8.2% . Central and EaMem Europe 2.5% 1 1 992 )
Impuils: $42.3 billion (c i f . 1993 csi.)
commodities: machinery, petroleum and
petroleum products, chemicals. m«8or vehicles.
fiHHlstuffs. iron and steel. cUnhing
partners; EC 53.6% (Germany 17.9%, UK
6.3%. Denmark 7.5%. France 4.9‘t ). EFTA
(Norway 6.6% , Finland 6% ). l^S 8.4% .Central
and EuMcm Europe 3% ( 1992)
KxIcmaldeM: $19.5 billion ( 1992 cm.)
Industrial production: growth rate 0.8%
(1993 est.)
Electricity:
capacity: .19,716.(8)0 kW
proiliu tion; 142.5 billion kWh
consumption /u-r capita; 16,560 kWh 1 1992)
Industries: iron and Mccl. precision
equipment (hearings, radio and telephone
parts, armunwnis ). wshkI pulp and paper
products. pnKcssed fiaids, imitor vehicles
Agriculture: animal husbandry
predominates, with milk and dairy products
accounting f«»r 37% of farm income; main
crops — grains, sugar hecHs. ptaatoes; 1(81%
self-sufficient in grains and potahws; Sweden
IS about 50% self-mfficient in most products;
farming accounted for 1.2% of GDP and 1.9%
of jobs in 1990
IIHcit drugs: transshipment point for
Sweden (continued)
Switierland
Defense Forces
Branches: Swedish Army, Royal Swedish
Navy, Swedish Air Force
Manpower availability: males age 15-49
2,146,145; fit for military service 1,874,787;
reach military age (19) annually 55,262 (1994
est.)
Defense expenditures: exchange rate
conversion — $6.7 billion, 3.8% of GDP
(FY92/93)
narcotics shipped via the CIS and Baltic states
for the European market
Economic aid:
donor! ODA and OOF commitments (1970-
89), $10.3 billion
Currency: I Swedish krona (SKr) = 100 oere
Exdumge rates: Swedish kronor (SKr) per
US$1— 8.1255 (January l«»94). 7.834(1993),
5.8238 (1992), 6.0475 (1991) 5.9188 (1990),
6.4469 (1989)
Fiscal year: 1 July— 30 June
Conununkations
RaUroads: 12,084 km total; Swedish State
Railways (SJ) 1 1,202 km— 10,819 km 1,435-
meter standard gauge, 6,955 km electrified and
1,152 km double track; 182 km 0.891-meter
gauge; 1 1 7 km rail feny service; privately-
owned railways 882 km — 5 1 1 km 1 .435-mcier
suuidard gauge (332 km electriried) and 371
km 0.891-meter gauge (all electrified)
Highways:
uuul: 205,000 km
paved: 69,7.54 km (including 9.36 km of
expreMiways)
unpa\\<ed: gravel 45.900 km; unimproved earth
.38,060 km; N A 5 1 .286 km ( 1 990)
Inland waterways: 2,052 km navigable for
small steamers and barges
Hpsllam natural gas 84 km
Gavle, GoielKitg. Halmstad.
Helsingborg. Kalmar, Malno. Stockholm:
numerous secondary and minor puil.s
Merchant nnulne: 161 ships (1.000 CRT or
over) totaling 2.049..5.54 GRT/2.5 16.350
DWT, short-sea passenger 10. cargo 24,
conuiner 2, roil-on/ndl-afr cargo 39. vehicle
earner 13. railcar carrier 2. oil tanker .30,
chemical Uuiker 25. specialized tanker 4.
combination ore/oil I . bulk 10, nefrigeniied
cargo I
Airparta:
total: 252
HsoMe: 248
M7/6 permanem-xurfacr mnn-ayx; 1 .38
U’lrt runwavf o\\rr .1.6.59 m: 0
with nrnaov.t .?.440..r.6.59 m: 1 1
with ruwMti.v.t /.220-2.4.?9«,- 94
and iniemalional facilities; 8.200.000
telephones; mainly coaxial and mulficonductor
cables carry long-distance network: parallel
microwave network carries primarily radio.
TV and some telephone channels; automalic
system; broadi-ast stations— .5 AM, .360
(mostly repeaters) FM. 880 (mostly icpeaters)
TV; 5 submarine coaxial cables: satellite earth
stations — I Atlantic Ocean INTELSAT and I
EUTELSAT
Geoiraphy
LocatiM: Central Europe, between France
and Austria
Maprcfermces: Europe. Standard Time
ZotMK of the World
Alta:
total am: 41 .290 sq km
land am: .39,770 sq km
compamin''e am: slightly nwre than twice the
size of New Jersey
Laud hauudirlw; total 1,852 km, Austria
164 km, Frence 57.3 km, lutly 740 km,
Liechtenstein 41 km, Germany .334 km
CmmHm: II km (landlocked)
MarNhue dalwK none; landlocked
lalcnuMiowiI dhqpsecs: none
ClhMde: temperate, but varies with ahilude;
cold, cloudy, rainy/snowy winters; cool to
warm, cloudy, humid summers with occasional
showers
Tcrndn: mostly mounuins (Alps in south.
Jura in northwest) with a central plateau of
rolling hills, plains, and large lakes
Nariual reatwreea: hydropower potential,
limber, salt
Load one:
anthie land: 10%
permanent cn^s: 1%
meadttws and pastures: 40%
fittest and woodland: 26%
otker 2,3%
irtrlpded load; 250 sq km (1989)
EovinNOMOl:
current issues: air pollution from vehicle
emissions and open air burning: acid rain:
water pollution from inciea.sed use of
agricultural fertilizers; kws of biodiversity
natural ha^rds: subject lo avalanches,
landslides, flash flaod.H
international agreements: party to — Air
Pollution, Air l^llutian-Nitrogen Oxides. Air
Poilution-Sulphur. Air l^rllution- Volatile
Organic Compounds, Antarctic Treaty,
Climate Change. Endangered Species.
Environmental Modification. Hazardous
Wa.sles. Marine Dumping. Marine Life
.380
Conservation. Nuclear Test Bun, Ozone Layer
Pnnection. Ship Pollution. Tropical Timber,
Wetlands, Whaling; .signed, but not ratified —
Antarctic-Envimnmental Protocol.
Biodiversity. Law of the Sea
Note: landlocked; enrssroads of northern and
southern Europe: along with southeu.stcm
France and northern Italy, contains the highest
elevations in Europe','c46ee819e2eadde7432d538a98b0ed50421474f895aeafaf0e76a440f75ed2d0','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6502a98582deae7d49b6f5b02dac8270c207b960eeb2453a4611f1f49776248',1994,'FR','France','economy',394,'(including forestry); livestock production,
especially dairy cattle, predominates; forestry
is an important export earner and a secondary
occupation for the rural population;
main crops — cereals, sugar beets, potatoes;
85% self-sufficient, but short of foodgrains and
fodder grains; annual fish catch about I60,(XX)
metric tons
Economic aid:
donor: ODA and OOF commitments (1970-
89), $2.7 billion
Currency: 1 markka (FMk) or Finmark = 1 00
pennia
Exchange rates: markkaa (FMk) per US$1 —
5.6920 (January 1994), 5.7123 ( 1993), 4,4794
(1992), 4.0440(1991), 3.82,35 (1990), 4,2912
(1989)
Fiscal year: calendar year
Overview: Economic activity is limited to
servicing meteorological and geophysical
research stations and French and other fishing
fleets. Tbf fishing catches landed on lies
Kerguelen by foreign ships are exported to
France and Reunion.
Budget:
revenues: $17.5 million
expenditures: $NA, including capital
expenditures of $NA (1992)
Overview: The stable, prosperous economy
features moderate growth, low inflation, and
negligible unemployment. Agriculture is based
on small but highly productive family-owned
farms. The industrial sector, until recently
dominated by steel, has become increasingly
more diversified, particularly toward
high-technology firms. During the past decade,
growth in the financial sector has more than
compensated for the decline in steel. Services,
especially banking, account for a growing
proportion of the economy. Luxembourg
participates in an economic union with
Belgium on trade and most financial matters, is
also closely connected economically to the
Netherlands, and as a member of the
12-member European Union enjoys the
advantages of the open European market.
National product: GDP — purchasing power
equivalent — $8.7 billion (1993)
National product real growth rate: 1%
(1993)
National product per capita: $22,600
(1993)
Inflation rate (consumer prices): 3.6%
(1992)
Unemployment rate: 5.1% (March 1994)
Budget:
revenues: $3.5 billion
expenditures: $3.5 billion, including capital
expenditures of SNA (1992 est.)
Exports: $6.4 billion (f.o.b., 1991 est.)
commodities: finished steel products,
chemicals, rubber products, glass, aluminum,
other industrial products
partners: EC 76%, US 5%
Imports: $8.3 billion (c.i.f., 1991 est.)
commodities: minerals, metals, foodstuffs,
quality consumer goods
partners: Belgium 37%, FRG 31%, France
12%, US 2%
External debt: $ 1 3 1 .6 million (1989 est.)
Industrial production: growth rate -0.5%
( 1 990); accounts for 25% of GDP
Electricity:
capacity: 1,238,750 kW
production: 1.375 billion kWh
consumption per capita: 3,450 kWh (1990)
Industries: banking, iron and steel, food
processing, chemicals, metal products,
engineering, tires, glass, aluminum
Agriculture: accounts for less than 3% of
GDP (including forestry): principal products —
barley, oats, potatoes, wheat, fruits, wine
grapes; cattle raising Widespread
Economic aid: none
Currency: I Luxembourg franc (LuxF) = 100
centimes
Exchange rates: Luxembourg francs (LuxF)
per US$1— 36.242 (January 1994), 34.597
( 1 993), 32. 1 50 ( 1 992), 34. 1 48 ( 1 99 1 ), 33 .4 1 8
( 1 990), 39.404 ( 1 989); note — the Luxembourg
franc is at par with the Belgian franc, which
circulates freely in Luxembourg
Fiscal year: calendar year
Overview: After the economic boom of 1986-
90, the Spanish economy fell into recession
along with the economics of other EU member
states. Real GDP barely grew in 1992 and
declined by approximately in 1993.
Unemployment, now nearly one-fourth of the
workforce, and the sharp downturn in business
investment have contributed to sagging
domestic demand. Devaluation of the peseta
since September 1992 has made Spanish
exports more competitive, but an export-led
recovery in 1994 will depend largely on
economic recovery in Spain''s major market —
the other EU nations. A solid recovery will also
require appropriate domestic policy actions,
including controlling the budget deficit and
wage increases, reforming labor market
regulations, and possibly loosening monetary
policy another notch. Foreign investors,
principally from other EU countries, have
invested over $60 billion in Spain since 1986.
Despite the recession, inflation remained at
about in 1993, The main source of
inflationary pres.sute is the fi.scal deficit.
National product: GDP- purchasing power
equivalent — $498 billion (1993)
National product real growth rate; -1%
(1993)
National product per capita; $12,700
(1993)
Inflation rate (consumer prices): 4.5%
(1993est,)
Unemployment rate: 22% (yearend 1993)
Budget:
revenues: $97,7 billion
exitenditures: $128 billion, including capital
expenditures of SNA ( 1 993 est.)
Exports; $72.8 billion (f.o.b., 1993)
commodities; cars and trucks, semifinished
manufactured goods, foodstuffs, machinery
porlners: EC 71.2%, US 4.8%. other
developed countries 7.9% (1992)
Imports; $92.5 billion (c.i.f, 1993)
commodities: machinery, transport equipment,
fuels, semifinished goods, foodstuffs,
consumer goods, chemicals
piiriners: EC ''i().7%. US 7.4%, other
developed countries 1 1.5%, Middle East 5.9%
(1992)
External debt: $90 billion (1993 est.)
Industrial production; growth rate - 1 .7%
(1992)
Electricity:
capocily: 46,600,000 kW
production: 157 billion kWh
consumption per capita: 4.0(K) kWh (1992)
Industries: textiles and apparel (including
footwear), food and beverages, metals and
metal manufactures, chemicals, shipbuilding,
automobiles, machine tools, tourism
Agriculture: accounts for about 5% of GDP
and 14% of labor force; major products —
grain, vegetables, olives, wine grapes, sugar
beets, citrus fruit, beef, pork, poultry, dairy;
largely self-sufficient in food; fish catch of 1 .4
million metric tons is among top 20 nations
Illicit drugs: key European gateway country
for Latin American cocaine and North African
hashish entering the European market
Economic aid;
recipient: US commitments, including Ex-Im
(FY70-87), $ 1 .9 billion; Western (non-US)
countries, ODA and (X>F bilateral
commitments (1970-79), $545 million
note: not currently a recipient
Currency: 1 peseta (Pia) = 100 centimes
Exchange rates: pesetas (Ptas) per US$ I —
136.6 (May 1994). 127.26(1993). 102.38
(1992), 103.91 (1991), 101.93(1990), 118.38
(1989)
Fiscal year: calendar year','292389bf0265b3e6b11796bab7549027abf050b1fe789416e9f763a59df77ca5','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('362d1f98b281c9935b69ae92a722f4c57548157e36e1c9346b6587d42ac710ac',1994,'GF','French Guiana','economy',406,'Overview: The economy Is lied closely to that
of France through subsidies and imports.
Besides the French space center at Kourou,
fishing and forestry are the most important
economic activities, with exports of ftih and
fish products (mostly shrimp) accounting for
more than 60% of total revenue in 1992. The
large reserves of tropical hardwoods, not fully
exploited, support an expanding sawmill
industry that provides sawn logs for export.
Cultivation of crop.s — rice, cassava, bananas,
and sugar cane — is limited to the coastal area,
where the population is largely conci nirated.
French Guiana is heavily dependent on imports
of food and energy. Unemployment is a seriour
probleiii, particularly among younger workers.
National product: GDP — exchange rate
conversion — $421 million (1986)
National product real growth rate: NA%
National product per caftita: $4,390 ( 1 986)
Inflation rate (consumer prices): 4. i %
(1987)
U nemploy ment rate: 1 3% ( 1 990)
Budget;
revenues: $735 million
expenditures: $735 million, including capital
expenditures of $NA ( 1987)
Exports: $59 million (f.o.b.. 1992)
commodities: shrimp, timber, rum. rosewood
essence
partners: France 52%. .Spain 15%, US 5%
(1992)
Imports: $1.5 billion tc.i.f.. 1992)
rommtulities: food (grains, processed meat).
other consumer goods, producer goods,
petroleum
jHirtners: France 77%, Germany 1 1%. US 5%
(1992)
External debt; $1.2 billion (1988)
Industrial production: growth rate NA%
Electricity:
caiMtcity: 92,000 kW
production: 1 85 million kWh
consumption per capita: 1 ,450 kWh (1992)
Industries; construction, shrimp processing,
forestry products, rum, gold mining
Agriculture: some vegetables for local
consumption; rice, com, manioc, cocoa,
bananas, sugar; livestock— cattle, pigs, poultry
Economic aid:
recipient: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-89),
$1.51 billion
Currency: I French franc (F) = 100 centimes
Exchange rates: French francs (F) per
US$1— 5.9205 (January 1994). 5.6632 (1993),
5.2938 (1992), 5.6421 (1991), .5.4453 (1990),
6.3801 (1989)
Fiscal year; calendar year','8360b4aa3b320a90955acb3675b7e73b8153270cc3714df277962df8401f70b9','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8cdad588a54cbf6082c676a21d4dada4b74e6a20ca55a4a436d6e938953df268',1994,'GA','Gabon','economy',416,'Overview: Notwithstanding its serious
ongoing economic problems, Gabon enjoys a
per capita income more than twice that of most
nations of sub-Saharan Africa. Gabon
depended on timber and manganese until oil
was discovered offshore in the early 1970s.
The oil sector now accounts for 50% of GNP.
Real growth was feeble in 1992 and Gabon
continues to face weak prices for its timber,
manganese, and uranium exports. Despite an
abundance of natural wealth, and a manageable
rate of population growth, the economy is
hobbled by poor fiscal management. In 1992,
the fiscal deficit widened to 2.4% of GDP, and
Gabon failed to settled arrears on its bilateral
debt, leading to a cancellation of rescheduling
agreements with official and private creditors.
Devaluation of the local currency by 50% in
January 1994 could set off an inflationary
spiral if the government fails to reign in
spending and grants large wage increases to an
already overpaid public sector workforce.
National product: GDP — purchasing power
equivalent — $5.4 billion ( 1993 est.)
National product real growth rate: 0.5%
(1992 est.)
National product per capita: $4,800 ( 1 993
est.)
Inflation rate (consumer prices): 0.7%
(1991 est.)
Unemployment rate: NA%
Budget:
revenues: $ 1 .3 billion
expenditures: $1.5 billion, including capital
expenditures of $272 million ( 1992 est.)
Exports: $2.3 billion (f.o.b.. 1992 est)
commodities: crude oil 80%. timber 9%.
mangane.se 7%. uianium 2%
partners: France 48%, US 1 5%. Germany 2%.
Japan 2%
Imports: $702 million (c.i.f., 1992 est.)
commodities: foodstuffs, chemical products,
petroleum products, construction materials,
manufactures, machinery
partners: France 64%, African countries 7%,
US 5%. Japan 3%
External debt: $4.4 billion ( |99 1 )
Industrial production: growth rate — 10%
( 1 988 est.); accounts for 8% of GDP, including
petroleum
Electricity:
capacity: 315,000 kW
production: 995 million kWh
consumption per capita: 920 kWh (1991)
Industries: petroleum, food und beverages,
lumbering and plywood, textiles, mining —
manganese, uranium, gold, cement
Agriculture: accounts for 9% of GDP
(including fishing and forestry); cash crops —
cocoa, coffee, palm oil; livestock not
developed; importer of food; small fishing
operations provide a catch of about 2Q,()()0
metric tons; okoumc (a tropical softwotxl) is
the most important timber product
Economic aid:
recipient: US commitments, including Fx-Im
(FY70-90), $68 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-90), $2,342 billion;
Communist countries (1970-89), $27 million
Currency: 1 CFA franc (CFAF)= KW
centimes
Exchange rates: Communaute Financiere
Africaine francs (CFAF) per US$1 — 592.05
(January 1994), 283.16 (1993), 264.69(1992),
282.11 (1991), 272.26(1990), 319.01 (1989)
note: beginning 12 January 1994, the CFA
franc was devalued to CFAF 1 00 per French
franc from CFAF 50 at which it had been fixed
since 1948
Fiscal year: calendar year','1e80498d5454e113d84b91a4c988ca242ba41e1fe2cc1fd5c875dd52dedd3400','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d041a85de05c540cf937fbeb81589f52b54ce4587e80699790ceae40a53990ab',1994,'GM','Gambia','economy',418,'Overview: The Gambia has no important
mineral or other natural resources and has a
limited agricultural base. It is one of the
world''s poorest countries with a per capita
income of roughly $800. About 75% of the
population is engaged in crop production and
livestock raising, which contribute 30% to
GDP. Small-scale manufacturing activity —
processing peanuts, fish, and hides — accounts
ibr less than 10% of GDP. A sustained
structural adjustment program, including a
The Gambia (continued)
Gaza Strip
Overview; In 1991 roughly 40% of Gaza
Strip workers were employed across the border
by Israeli industrial, construction, and
agricultural enterprises, with worker
remittances accounting for about one-third of
GNP. The construction, agricultural, and
industrial sectors account for about 18%, 16%,
and 1 2% of GNP, respectively. Gaza depends
upon Israel for nearly 90% of its external trade.
Aggravating the impact of Israeli military
administration, unrest in the territory since
1988 (intifadah) has rai.sed unemployment and
lowered the standard of living of Gazans. The
Persian Gulf crisis and its aftershocks also have
dealt blows to Gaza since August 1 990.
Worker remittances from the Gulf states have
dropped, unemployment has increased, and
exports have fallen. The redeployment of the
Israeli army and the transfer of authority in
Gaza to the Palestinian Authority in May 1994
has created a new situation in which
Palestinians are now responsible for the
management of Gaza’s economy.
National product: GNP — exchange rate
conversion — $840 million (1991 est.)
National product real growth rate: 1 %
(1991 est.)
National product per capita; $ 1 ,275 ( 1 99 1
est.)
Inflation rate (consumer prices); 7% (1991
est.)
Unemployment rate: 20% (1991 est.)
Budget:
revenues; $33.6 million
expenditures; $34.5 million, including capital
expenditures of $NA (FY90)
Exports: $75 million (f.o.b., 1991 est.)
commodities: citrus
partners: Israel, Egypt
Imports: $370 million (c.i.f., 1991 est.)
commodities: food, consumer goods,
construction materials
partners: Israel. Egypt
External debt: SNA
Industrial production: growth rate 1 1 %
(1991 est.): accounts for about 12% of GNP
Electricity: power supplied by Israel
Industrijs: generally small family businesses
that produce textiles, soap, olive-wood
carvings, and mother-of-pearl souvenirs; the
Israelis have established some small-scale
modern industries in an industrial center
Agriculture: accounts for about 16% of GNP;
olives, citrus and other fruits, vegetables, beef,
dairy products
Economic aid: $NA
Currency: I new Israeli shekel (NIS) = l(X)
new agorot
Exchange rates; new Israeli shekels (NIS)
per US$1— 2.9760 (February 1994), 2.8301
(1993), 2.4591 (1992), 2.2791 (1991), 2.0162
(1990), 1.9164(1989)
Fiscal year: calendar year (since 1 January
1992)','953a7786d76fd256a3625ddd28010eaee8b20e5a64cd6a70987d934128f4f93a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f1041955b0f08d2eb5b10a0ae3fb9f75b19b2c9f8410d63a9a3908cae4b996a',1994,'GE','Georgia','economy',427,'Overview: Georgia''s economy has
traditionally revolved around Black Sea
tourism; cultivation of citrus fruits, tea, and
grapes; mining of manganese and copper; and
a small industrial sector producing wine,
metals, machinery, chemicals, and textiles. The
country imports the bulk of its energy needs,
including natural gas and coal. Its only sizable
domestic energy resource is hydropower. Since
1990, widespread conflicts, e.g., in Abkhazia,
South Ossetia, and Mengrelia, severely
aggravated the economic crisis resulting from
the disintegration of the Soviet command
economy in December 1991. Throughout
1 993, much of industry was functioning at only
20% of capacity: heavy disruptions in
agricultural cultivation were reported; and
tourism was shut down. The country is
precariously dependent on US and EU
humanitarian grain shipments, as most other
foods are priced beyond reach of the average
citizen. Georgia is al.so suffering from an acute
energy crisis, as it is having problems paying
for even minimal imports. Georgia is pinning
its hopes for recovery on reestablishing trade
ties with Russia and on developing
international transportation through the key
Black Sea ports of P’ot''i and Bat''umi.
National product: GDP — purchasing power
equivalent — $7.8 billion (1993 estimate from
the UN International Comparison Program, as
extended to 1991 and published in the World
Bank''s World Development Report 1993: and
as extrapolated to 1993 using official Georgian
statistics, which are very uncertain because of
major economic changes since 1990)
National product real growth rate: -35%
(1993 est.)
National product per capita: $ 1 .390 ( 1 993
est.)
Inflation rate (consumer prices): 40.5% per
month (2nd half 1993 est.)
Unemployment rate: officially less than 5%
but real unemployment may be up near 20%.
with even larger numbers of underemployed
workers
Budget:
revenues: SNA
expenditures: SNA, including capital
expenditures of SNA
Exports: SNA
commodities: citrus fruits, tea, wine, other
agriculturai products; diverse types of
machinery; ferrous and nonferrous metals;
textiles; chemicals; fuel re-exports
partners: Russia. Turkey, Armenia,
Azerbaijan (1992)
Imparts: SNA
commodities: fuel, grain and other foods,
machinery and parts, transport equipment
partners: Russia, Azerbaijan, Turkey (1993)
External debt: $100 million to $2()0 million
(1993 est.)
Industrial production: growth rate -27%
(1993): accounts for 36% of GDP
Electricity;
capacity: 4,875,000 kW
production: 15.8 billion kWh
consumption per capita: 2,835 kWh ( 1 992)
Industries: heavy industrial products include
raw steel, rolled steel, airplanes; machine tools,
foundry equipment, elecuic locomotives,
tower cranes, electric welding equipment,
machinery for food preparation and meat
packing, electric motors, process control
equipment, instmments; trucks, tractors, and
other farm machinery: light industrial
products, including cloth, hosiery, and shoes;
chemicals: wood-working industries; the most
important food industry is wine
Agriculture: accounts for 41 % of GDP:
accounted for 97% of former USSR citrus
fruits and 93% of former USSR tea: important
producer of grapes; also cultivates vegetables
and potatoes; dependent on imports for grain,
dairy products, sugar; small livestock sector
Illicit drugs; illicit cultivator of cannabis and
opium poppy; mostly for domestic
consumption; used as transshipment point for
illicit drugs to Western Europe
Economic aid:
recipient: heavily dependent on US for
humanitarian grain shipments; EC granted
around $70 million in trade credits in 1992 and
another $40 million in 1993; Turkey granted
$50 million in 1993; smaller scale credits
granted by Russia and China
Currency; coupons introduced in April 1993
to be followed by introduction of the lari at
undetermined future date; in July 1993 use of
the Russian ruble was banned
Exchange rates: NA
Fiscal year: calendar year
irgia
rytvilttn
200km
South
Atlantic Ocean
(March 1994), 3.2636 (1993). 2.8497 (1992),
2.7563 (1991). 2.5863 ( i 990), 2.6 1 66 ( 1 989)
Fiscal year: 1 April — 31 March
Overview: Some fishing lakes place in
adjacent waters. There is a potential source of
income from harvesting fin fish and krill. The
islands receive income from postage stamps
produced in the UK.
Budget:
revenues: $291,777
expenditures: $451,000. including capital
expenditures of SNA (1988 esl.)
Electricity:
capacity: 900 kW
production: 2 million kWh
consumption per capita: NA (1992)','905edf54b0f48ff06340432d91bafa542f2c0b253ac91fc5fdd8e7d1f0e59763','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29297accc6bd555b554ca89744473606155f94dca447ff321b5445846b772789',1994,'GH','Ghana','economy',432,'Overview: Supported by substantial
international assistance, Ghana has been
implementing a steady economic rebuilding
program since 1983. including moves toward
privatization and relaxation of government
controls. The agriculture sector consists largely
of small traditional farm holdings, rain-fed for
151
Ghana (continued} Gibraltar
(dependent territory of the UK)
the most part. Heavily dependent on cocoa,
gold, and timber exports, economic growth so
far has not spread substantially to other areas of
the economy. The costs of sending
peacekeeping forces to Liberia and preparing
for the transition to a democratic government
have boosted government expenditures and
undercut structural adjustment reforms. Ghana
opened a stock exchange in 1990 and plans to
float S% of its stake in Ashanti Goldfields
Corporation, which would make the exchange
the largest in sub-Saharan Africa outside of
South Africa.
National product: GDP — purchasing power
equivalent — $25 billion (1993 est.)
National product real growth rate: 3.9%
(1992 est.)
National product per capita: $ 1 ,500 ( 1 993
est.)
Inflation rate (consumer prices): 10%
(1992)
Unemployment rate: 1 0% ( 1 99 1 )
Budget:
revenues: SI billion
expenditures: $905 million, including capital
expenditures of $200 million (1991 est.)
Exports: $1 billion (f.o.b., 1^2)
commodities: cocoa 40%, gold, timber, tuna,
bauxite, and aluminum
partners: Germany 31%, US 12%, UK 1 1%,
Netherlands 6%, Japan 5% (1991)
Imports: $1.5 billion (c.i.f., 1992)
commodities: petroleum 16%, consumer
goods, foods, intermediate goods, capital
equipment
partners; UK 22%, US 1 1 %, Germany 9%,
Japan 6%
External debt: $4.6 billion (1992 est.)
Industrial production: growth rate 4.7% in
manufacturing (1992); accounts for almost
15% of GDP
Electricity:
capacity: l,180,(X)OkW
production: 4.49 billion kWh
consumption per capita: 290 kWh (1991)
Industries: mining, lumbering, light
manufacturing, aluminum, food processing
Agriculture: accounts for 43% of GDP
(including Fishing and forestry); the major cash
crop is cocoa; other principal crops — rice,
coffee, cassava, peanuts, com. shea nuts,
timber; normally self-sufficient in food
Illicit drugs; illicit producer of cannabis for
the international drug uade; transit hub for
Southwest and Southeast Asian heroin destined
for the US and Europe
Economic aid:
recipient; US commitments, including Ex-lm
(FY70-89). $455 million; Western (non-US)
countries, ODA and CX)F bilateral
commitments (1970-89). $2.6 billion: OPEC
bilateral aid (1979-89), $78 million;
Communist countries (1970-89) $106 million
Currency: I new cedi (C) = l(X) pesewas
Exchange rates: new cedis per US$1 —
7 1 3.00 (October 1993). 437,09 ( 1 992), 367.83
Overview: The British militttry presence has
been severely reduced attd now only
contributes about 1 1*5!'' to the local eevmomy.
The financial sector accounts for 1 5''3'' of GDP;
tourism and shipping services fees also
generate income. Because more than 70*^ of
the economy is in the public sector, changes in
government spending have a major impact on
the level of etnployntent . Construction workers
arc particularly affected when government
expenditures are cut.
National product: GNP — exchange rate
conversion — $182 million (EY87)
National product real gntwlh rate; 3''/(
<;''Y87)
National prirduct per capita: $4,ft(X)(EY87)
Inflation rate (eon-sumer prices): .3.ft'';j
(1988)
Unemployment rate; NA''/i
Budget;
/■(■t''crttrcv.'' $L36 million
espeiulitiiies: $1,39 million, including capital
cx(K‘nditure.s of $NA ((•Y88)
Exptirts: $82 million (f.o.b.. 1988)
coinnuulities: (principally re-ex|iorts)
ix''troleum 3 1 ''-’i . manufactured goods 4 1 ''/r .
other 8''7(
partners: UK. Morivco. Portugal.
Netherlands, .Spain. US, ERG
Imports: $2.38 million (c. i f., 1988)
‘■<>nwuHlities: fuels, tnanufactured gixxls. ;ind
t.''XKlstuffs
partnerx: UK, Spain, Japan, Netherlands
External debt: $318 million (1987)
Industrial production: growth rate NA''4
Electricity:
capacity: 47,(XX) kW
prtHlueiion: 2(X) million kWh
consumption per capita: ft.74t) kWh (1992)
Industries: tourism, banking and finance,
construction, commerce: support to large UK
naval and air bases; transit trade and supply
depot in the poit: light manufacturing of
tobacco, rmrsted coffee, ice, tnincral waters,
candy, beer, and canned fish
Agriculture: none
Economic aid:
recipient: US commitments, including Ex-lm
(FY7()-88), $8(X).(XX); Western (non-US)
countries and ODA bilateral commitments
(1992-93), $2.3 million
Currency: I Gibraltar pound (t.''G) = l(X)
pence
Exchange rales; Gibraltar pounds (£G) |)cr
USSI— 0.6ft99 (January 1994), ().6ft38 (1993).
().56()4 (1992). ()..3fi32 ( 1991 ). ().3ft()3 ( 1990),
(),ft099 (1989); note — the Gibraltar pound is at
pur with the British pound
Fiscal year: 1 July — 30 June
Overview: The economy is heavily dependent
on subsistence agriculture, which accounts for
about 33‘5i'' of GDP and provides employment
for 78% of the labor force. Primary agricultural
exports are cocoa, coffee, and cotton, which
together generate about 30% of total export
earnings. Togo is sclf-suftlcieni in basic
foodstuffs when harvests are normal. In the
industrial sector phosphate mining is by far the
most important activity, although it has
suffered from the collapse of World phosphate
prices and increased foreign competition. Togo
serves as a regional commercial and trade
center. The government’s decade-long IMF
and World Bank supported effort to implement
eeonomic reform measures to encourage
foreign investment and bring revenues in line
with expenditures has stalled. Political unrest,
including private and public sector strikes
throughout 1992 and 1993, has jeopardized the
reform program and has disrupted vital
economic activity.
National product: GDP — purchasing power
equivalent — $3,3 billion ( 1993 est.)
National product real gi . vth rate: NA
National product per capita; $8(X) (1993
est.)
Inflation rate (consumer prices): 0.5%
(1991 est.)
Unemployment rate: NA%
Budget:
revenues: $284 million
expenditures: $407 million, including capital
expenditures of $NA (1991 est.)
Exports: $558 million (f.o.b.. 1991)
commodities: phosphates, cotton, cocoa,
coffee
partners; EC 40%. Africa 1 6%. US I % ( 1 990)
Imports: $636 million (fo b., 1991)
commodities: machinery and equipment,
consumer goods, food, chemical products
393
Togo (caniinutd)
Tokdov
(lerrilory of New Zeahmdi
DctaMtPlfCM
■r— dmt Amy. Nivy. Air Force.
Geitdhrmerie
MmpmwravaOiUlliy: nMle«ate I.M9
898.448; fii for miliuuy service 471.807
Pel^iwe wptiOiUKH exchMUcme S''^m fetm Oemn
converaioii — ^$43 million, about .3% of ODF
<1989)
tAfiMtffHHiu
! ''\\
Ga«nra|)liy
pamen: EC 57*4. Africa 1 794, US 5%, Japan
494(1990)
EMertMlMl: $1.3 billion 0991)
InOnalriai pwOucOaii; growth rale 9.094
(1991 CM.): accounts for 2094 of GDP
EIcctriclly:
I''opacity: 1 79,000 kW
pi^uction: 209 million kWh
Cfmsumplion per capita: 60 kWh ( 1990)
Indualrlft: phosphate mining, agricultural
processing, cement. handicraOs. textiles,
beverages
AoricultHrc: accounts for 33% of GDP, cash
crops — coffee, cocoa, cotton; food crops —
yams, cassava, corn, beans, rice, millet,
sorghum: livestock production not significant;
annual fish catch of 10,000-14,000 tons
llitdl drugi: increasingly used as transit hub
by heroin traffickers
Econamic aM:
rtcipiem: US commitments, including Ex-lm
(FY70-90). $142 million; Western (non-US)
countries, ODA and OOF bilateral
commitments ( 1970-90). $2 billion; OPEC
bilateral aid ( 1979-89), $33 million;
Communist countries ( 1 970-89), $3 1 million
Currency! I CFA franc (CFAP) = 100
centintes
Exchange rales: Communaute Financiere
Africaine francs (CFAF) per US$1 — 392.03
(January 1994), 283. 16 (1993), 264.69 ( 1992),
282.11 (1991). 272.26 (1990). 319.01 (1989)
note: the ofTicial rate is pegged to the French
franc, and beginning 1 2 January 1 994. the CFA
franc was devalued to CFAF 100 per French
franc from CFAF .*0 at which it had been ftxed
since 1948
Fiscal year: calendar year','8bfbef1c824784650424301b7742a88959689fbb5c4b893b76e58845b41d87ed','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2314f871cdef96ff355222ca9893e9a6779a9289605f3e2f5dbe7bf04b6861d',1994,'GD','Grenada','economy',440,'Overview: The economy is essentially
agricultural and centers on the traditional
production of spices and tropical plants.
Agriculture accounts for about IS^ of GDP
and of expons and employs 249r of the
labor force. Tourism is the leading foreign
exchange earner, followed by agricultural
exports. Manufacturing remains relatively
undeveloped, but is expected to grow, given a
more favorable private investment climate
since 1983. The economy achieved an
impressive average annual growth rate of 5.5%
in 1986-91 but stalled in 1992. Unemploy .nent
remains high at about 25%.
National product: GDP — purchasing power
equivalent — S250 million (1992 est.)
National product real growth rate: -0.4%
(1992 est.)
National product per capita: $3,000 (1992
est.)
Inflation rate (consumer prices): 3.6%
(1992 est.)
Unemployment rate: 25% (1992 est.)
Budget:
revenues: $78 million
expenditures: $5 1 million, including capital
expenditures of $22 million (1991 est.)
Exports: $19.9 million (f.o.b.. 1992 est.)
commodities: bananas, cocoa, nutmeg, fruit
and vegetables, clothing, mace
partners: Netherlands. UK, Trinidad and
Tobago, United States
Imports: $103.2 million (f.o.b., 1992 e,st.)
commodities: food 25%. manufactured goods
22%, machinery 20%, chemicals 10%, fuel 6%
(1989)
partners: US 29%. UK, Trinidad and Tobago,
Japan. Canada (1989)
External debt: $ 109 million ( 1992)
Industrial production: growth rate 1.8%
( 1 992 est.); accounts for 9% of GDP
Electricity:
capacity: 12,500 kW
production: 26 million kWh
consumption per capita: 310 kWh (1992)
Industries: food and beverage, textile, light
assembly operations, tourism, construction
Agriculture: accounts for 15% of GDP and
80% of exports; bananas, cocoa, nutmeg, and
mace account for two-thirds of total crop
production; world''s second-largest producer
and fourth-largest exporter of nutmeg and
mace; small-size farms predominate, growing
a variety of citrus fiuits, avocados, root crops,
sugarcane, com. and vegetables
Economic aid:
recipient: US commitments, including Ex-Im
(FY84-89), $60 million; Western (non-US)
countries. ODA and (X>F bilateral
commitments (1970-89), $70 million;
Communist countries (1970-89), $32 million
Currency; 1 EC dollar (ECS) = 100 cents
Exchange rates: East Caribbean dollars
(ECS) per US$1 — 2.70 (fixed rate since 1976)
Fiscal year: calendar year','f7280beeb75a486a94dfe17f3b20d18e4c1d69c220ac0bb3f2132ba2fa0e4cb8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fbc9e6eb8847df505427d2723dad7a55a8ca17dd146904e86bffd2e33c317e5',1994,'GP','Guadeloupe','economy',445,'Overview: The economy depends on
agriculture, tourism, light industry, and
services, it is also dependent upon France for
large subsidies and imports. Tourism is a key
industry, with most tourists from the US. In
addition, an increasingly large number of
cruise ships visit the islands. The traditionally
important sugarcane crop is slowly being
replaced by other crops, such as bananas
(which now supply about 50% of export
earnings), eggplant, and flowers. Other
vegetables and root crops are cultivated for
local consumption, although Guadeloupe is
still dependent on imported food, which comes
mainly from France. Light industry consists
16(1','770a8d5532f4d4bb2d969fefbe1c88289bbf3780c8a8804e357971ada86e962c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3fd3043719b9e5866f9a06120a33f507de9344be9efb648b72b2b55549731a4',1994,'GU','Guam','economy',446,'(territory of the US)
mostly of sugar and rum production. Most
manufactured goods and fuel are imported.
Unemployment is especially high among the
young.
National product; GDP — exchange rate
conversion — $2.9 billion (1991)
National product real growth rate: NA%
National product per capita: $8,4(X) (1991)
Inflation rate (consumer prices); 3.7%
(1990)
Unemployment rate; 3 1 .3% ( 1 990)
Budget:
revenues: $333 million
expenditures; $671 million, including capital
expenditures of SNA (1989)
Exports: $168 million (f.o.b., 1988)
commodities; bananas, sugar, rum
partners; France 68%, Martinique 22% (1987)
Imports: $1.2 billion (c.i.f., 1988)
commodities: vehicles, foodstuffs, clothing
and other consumer goods, construction
materials, petroleum products
partners: France 64%, Italy, FRG, US (1987)
External debt: SNA
Industrial production: growth rate NA%
Electricity:
capacity; 171,500 kW
production: 441 million kWh
consumption per capita: 1 ,080 kWh ( 1 992)
Industries: con.struction, cement, rum, sugar,
tourism
Agriculture: cash crops — bananas,
sugarcane; other products include tropical
fruits and vegetables; livestock — cattle, pigs,
goats; not self-sufficient in food
Economic aid:
recipient; US commitments, including Ex-lm
(FY70-88), $4 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $8,235 billion
Currency: 1 French franc (F) = 100 centimes
Exchange rates: French francs (F) per
US$ 1 —5.9205 (January 1 994), 5.6632 ( 1 993),
5.2938 (1992), 5.6421 (1991), 5.4453 (1990),
6.3801 (1989)
Fiscal year; calendar year
Overview: The economy depends mainly on
US military spending and on revenues from
tourism. Over the past 20 years the tourist
industry has grown rapidly, creating a
construction boom for new’ hotels and the
expansion of older ones. Visitors numbered
about 900,000 in 1992. The slowdown in
Japanese economic growth has been reflected
in less vigorous grow th in the touri.sm sceii.r,
About 60% of the labor force works for the
private sector and the rest for govem:nent.
Most food and industrial goods are imponed,
with about 75% from the US. In early 1994.
Guam faces the problem of building up the
civilian economic sector to offset the inipact of
military downsizing.
National product: GNP — purchasing power
equivalent — S2 billion ( 1991 est.)
National product real growth rate: NA%
National product per capita; $I4.(KX)(I99I
est.)
Inflation rate (consumer prices): 4% (1992
est.)
Unemployment rate: 2% (1992 est.)
Budget:
revenues: $525 million
expenditures: $395 million, including capital
expenditures of SNA (1991)
Exports: $34 million (f.o.b.. 1984)
cummodities: mostly transshipments of refined
petroleum products, construction materials,
fish, food and beverage products
partners; US 25%. Trust Territory of the
Pacific Islands 63%, other 12%;
Imports: $493 million (c.i.f.. 1984)
commodities: petroleum and petroleum
products, food, manufactured goods
partners: US 23%, Japan 19%, other 58%
External debt: SNA
Industrial production; growth rate NA%
Electricity:
capacity: 500,000 kW
production: 2.3 billion kWh
consumption per capita; 16,300 kWh (1990)
Industries; US military, tourism,
construction, transshipment services, concrete
products, printing and publishing, food
processing, textiles
Agriculture: relatively undeveloped with
most food imported; fruits, v''*getables. eggs,
pork, poultry, beef, copra
Economic aid: although Guam receives no
foreign aid. it does receive large transfer
payments from the general revenues of the US
Federal Treasury into which Guamanians pay
no income or excise taxes; under the provisions
of a special law of Coiigress, the Guamanian
Treasury, rather than the US Treasjiy. receives
federal income taxes paid by military and
civilian Federal employees stationed in Guam
Currency: I United Slates dollar (US$)= 100
cents
Exchange ratec; US currency is used
Fiscal year; 1 October — 30 September','7c2c323f40888761e953ae347c90acf3402a675f5811560e33a503cd0da54e3c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8b71613fa6052d39ad7fa6984da9490d454934040cf640e07fc102cbee40066',1994,'GG','Guernsey','economy',460,'Overview: Financial services account from
more than 50% of total income. Tourism,
manufacturing, and horticulture, mainly
to.natoes and cut flowers, have been declining.
Bank profits (1992) registered a record 26%
growth. Fund management and insurance are
the two other major income generators.
National product: GDP SNA
National product real growth rate: 9%
(1987)
National product per capita; SNA
Inflation rate (consumer prices): 7% (1988)
Unemployment rate: NA%
Budget:
revenues: $208.9 million
expenditures: $ 1 73.9 million, including capital
expenditures of SNA ( 1988)
Exports: SNA
commodities: tomatoes, flowers and ferns,
sweet peppers, eggplant, other vegetables
parmers: UK (regarded as internal trade)
Imports: SNA
commodities: coal, gasoline, and oil
partners: UK (regarded as internal trade)
External debt: SNA
Industrial production: growth rate NA%
Electricity:
capacity: 173.000 kW
production: 525 million kWh
consumption per capita: 9,060 kWh (1992)
Industries; tourism, banking
Agriculture: tomatoes, flowers (mostly
grown in greenhouses), sweet peppers,
eggplant, other vegetables, fruit; CJuemsey
cattle
Economic aid: none
Currency: 1 Guernsey (£G) pound = 100
pence
Exchange rates; Guem.sey pounds (£G) per
USS 1 —0.6699 (January 1 994). 0.6658 ( 1 993).
0.5664 (1992). 0.5652 (1991). 0..5603 (1990),
0.6099 (1989): note — the Guernsey pound is at
pur with the British pound
Fiscal year: calendar year','a664952c80098c73b658333b8977172f5f7af6c5c6a759b005d701d4278da190','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bb6008c72fab830dd3a3d726a9844907667be79c7d39736a018b832bb396d294',1994,'GN','Guinea','economy',467,'Overview: Although possessing major
mineral and hydropower resources and
considerable potential for agricultural
development, Guinea remains one of the
prrorest countries in the world. The agricultural
sector contributes about 40% to GDP ond
employs more than 80% of the work force,
while industry accounts for 27% of GDP.
Guinea possesses over 25% of the world''s
bauxite reserves. The mining sector accounted
for 85% of exports in 1991 . Long-run
improvements in literacy, financial
institutions, and the legal framework are
needed if the country is to move out of poverty.
Except in the bauxite industry, foreign
investment remains minimal.
National product: GDP — purchasing power
equivalent — $3.1 billijn (1993 est.)
National product real growth rate: 3.2%
(1992 est.)
National product per capita: $500 (1993
est.)
Inflation rale (consumer prices): 16.6%
(1992 e.st.)
Unemployment rate: NA%
Budget:
revenues: $449 million
expenditures: $708 million, including capital
expenditures of $361 million ( 1990 est.)
Exports: $622 million (f.o.b.. 1992 est.)
commodities: bauxite, alumina, diamonds,
gold, coffee, pineapples, bananas, palm kernels
partners; US 23%, Belgium 12%, Ireland
12%. Spain 12%
Imports: $768 million (c.i.f., 1992 est.)
commodities; petroleum products, metals,
machinery, transport equipment, foodstuffs,
textiles, and other grain
partners: France 26%, Cote d’Ivoire 12%.
Hong Kong 6%, Germany 6%
External debt: 2.5 billion ( 1 992)
Industrial production: growth rate NA%:
accounts for 27% of GDP
Electricity:
capacity: 1 1 3,000 kW
production; ,300 million kWh
consumption per capita: 40 kWh ( 1 989)
Industries: bauxite mining, alumina, gold,
diamond mining, light manufacturing and
agricultural processing industries
Agriculture: accounts for 40% of GDP
(includes fishing and forestry): mostly
subsistence fanning; principal product.s — rice,
coffee, pineapples, palm kernels, cassava,
bananas, sweet potatoes, limber; livestock —
cattle, sheep and goals: not self-sufficient in
food grains
Economic aid:
recipient; US commitments, including Ex-Im
(FY70-89), $227 million; Wc.siem (ron-US)
countries, ODA and OOF bilateral
commitments ( 1 970-89). $ 1 ,465 billion; OPEC
bilateral aid (1979-89), $120 million;
Communist countries (1970-89). .$446 million
Currency: 1 Guinean franc (FG) = UK)
centimes
Exchange rates: Guinean francs (FG) per
US$1— 810,94 (I July 1993), 922.9 v.30
September 1 992), 675 ( 1 990). 6 1 8 ( 1 989), 5 1 5
(1988), 440 (1987), 383 (1986)
Fiscal year; calendar year','2ceba997b1ace5ff6533f3c7a3a37a72f1b2064254b71590aca50c7198454974','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f18fd4b5ce11e03f58e613d35f30fed510e35eddb45db61caf507268f53b7a9',1994,'HT','Haiti','economy',473,'rei ipienl: US commitments, including Ex-lni
(FY70-89), $116 million; Western (non-US)
countries. ODA and OOF bilateral
commitments (1970-89), $325 million;
Communist countries 1970-89, $242 million
Currency: 1 Guyanese dollar (G$) = 1(X)
cents
Exchange rates: Guyanese dollars (G$) per
USSl — 1.30.7 (January 1994), 126.7(1993),
1 25.0 ( 1 992). I 1 1 .8 ( 1 99 1 ). 39.533 ( 1 990),
27.159(1989)
Fiscal year: calendar year
Overview: About 75% of the population live
in abject poverty. Agriculture is mainly small-
scale subsistence farming and employs nearly
three-fourths of the work force. The majority
of the population does not have ready access to
safe drinking water, adequate medical care, or
sufficient food. Few social assistance programs
exist, and the lack of employment
opportunities remains one of the most critical
problems facing the economy, along with soil
erosion and political instability. Trade
sanctions applied by the Organization of
American States in response to the September
1991 coup against President ARISTIDE have
further damaged the economy. Output
continued to drop in 1993 although not as
sharply as in 1992.
National product: GDP — purchasing power
equivalent — $5,2 billion (1993 est.)
National product real growth rate: -13%
(FY92 est.)
National product per capita: $8(X) (1993
est.)
Inflation rate (consumer prices): 20%
(FY92 est.)
Unemployment rate: 25-50% (1991)
Budget:
revenues: $300 million
expenditures: $416 million, including capital
expenditures of $145 million (1990 est.)
Exports: $135 million (f.o.b.. 1992 est.)
commodities: light manufactures 65%. coffee
19%, other agriculture 8%, other 8%
partners: US 84%, Italy 4%, France 3%. other
industrial countries 6%, less developed
countries 3% (1987)
Imports: $423 million (f.o.b., 1992 est.)
commodities: machines and manufactures
34%, food and beverages 22%, petroleum
products 14%, chemicals 10%, fats and oils 9%
partners: US 64%, Netherlands Antilles 5%,
Japan 5%, France 4%, Canada 3%, Germany
3% (1987)
External debt: $838 million (December
1990)
Industrial production: growth rate -2.0%
(1991 est.); accounts for 15% of GDP
Electricity:
capacity: 217,000 kW
production: 480 million kWh
consumption per capita: 75 kWh (1992)
Industries: sugar refining, textiles, flour
milling, cement manufacturing, tourism, light
assembly industries based on imported parts
Agriculture: accounts for 28% of GDP and
employs around 70% of work force; mostly
small-scale subsistence farms; commercial
crops — coffee, mangoes, sugarcane, wood;
staple crops — rice, com. sorghum; shortage of
wheat flour
Illicit drugs: transshipment point for cocaine
and marijuana en route to the US and Europe
Economic aid:
recipient; US commitments, including Ex-lm
(1970-89), $700 million; Western (non-US)
countries, ODA and OOF bilateral
commitments ( 1970-89), $770 million
Currency: 1 gourde (G) = 100 centimes
Exchange rates: gourdes (G) per US$1 —
12.00 (1 July 1993), 8.4 (December 1991),
fixed rate of 5.0(X) through second quarter of
1991
Fiscal year: I October — .30 September','14bb99d8ed6b8cbcee9deba19b5e4bab5c59f561e4318076444edcfd39e1cf61','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a47c9e1a4efee14e37d4c25c750b17890626c6260f2649e24f90c0a4be8f208',1994,'IS','Iceland','economy',496,'Overview: Iceland''s Scandinavian-type
economy is basically capitalistic, but with an
extensive welfare system, relatively low
unemployment, and comparatively even
distribution of income. The economy is heavily
dependent on the fishing industry, which
provides nearly 75% of export earnings and
employs 12% of the workforce. In the absence
of other natural resources — except energy —
Iceland''s economy is vulnerable to changing
world fish prices. Iceland’s economy has been
in recession since 1988. The recession
continued in 1993 due to a third year of
cutbacks in fishing quotas as well us falling
world prices for the country''s main exports:
fish and fish products, aluminum, and
ferrosilicon. Real GDP declined 3.3% in 1992
and rose slightly, by 0.4%, in 1993. The center-
right government’s economic goals include
reducing the budget and current account
deficits, limiting foreign borrowing, containing
inflation, revising agricultural and fishing
policies, diversifying the economy, and
privatizing state-owned industries. The
recession has led to a wave of bankruptcies and
mergers throughout the economy, as well as
the highest unemployment of the post-World
War II period. Inflation, previously a serious
problem, declined from double digit rates in
the 1980s to only 3.7% in 1992-93.
Nalinnal product: GDP — purchasing power
equivalent — $4.2 billion (1993)
National product real growth rate: 0.4%
(1993 est.)
National product per capita: $ 1 6.000
(1993)
Inflation rate (consumer prices): 4% ( 1 993 )
Unemployment rate: 4.5% (1993 est.)
Budget:
revenues: $1.8 billion
expenditures: $1.9 billion, including capital
expenditures of $191 million (1992)
Exports: $1.5 billion (f.o.b., 1992)
commodities: fish and fish products, animal
products, aluminum, ferrosilicon, diatomite
partners: EC 68% (UK 25%, ERG 12%), US
11%, Japan 8% (1992)
Imports: $1.5 billion (c.i.f., 1992)
commodities: machinery and transportation
equipment, petroleum products, foodstuffs,
te.xtiles
partners: EC 53% (Germany 14%, Denmark
10%, UK 9%), Norway 14%, US 9% (1992)
External debt: S3.9 billion (1992 est.)
Industrial production: growth rate 1 .75%
(1991 est.)
Electricity:
capacity: 1,063,000 kW
production: 5.165 billion kWh
consumption per capita: 19,940 kWh (1992)
Industries: fish processing, aluminum
smelting, ferro-silicon production, geothermal
power
Agriculture: accounts for about 1 5% of GDP;
fishing is most important economic activity,
contributing nearly 75% to export earnings;
principal crops — potatoes, turnips; livestock —
cattle, sheep; self-sufficient in crops; fish catch
of about 1 . 1 million metric tons in 1992
Economic aid:
recipient: US commitments, including Ex-lm
(FY70-81),$19.1 million
Currency: I Icelandic krona (IKr)= 100
aurar
Exchange rates: Icelandic kronur (IKr) per
USSl— 72.97 1 (January 1994), 67.603 ( 1 993),
57..546 (1992), 58.996 (1991). 58.284 (1990),
.57.042(1989)
Fiscal year: calendar year','1ec73e2dffc019ed238cf6f78ca38ac5b4c8b1f78cfeb78d0ebfcc3769523f47','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e27909550cde49c5d2fcc8d07682b3993db2993fa49fb342794a1c41c097d0ae',1994,'IN','India','economy',501,'Overview; India’s economy is a mixture of
traditional village farming, modern agriculture,
handicrafts, a wide range of modern industries,
and a multitude of support services. Faster
economic growth in the 1980s permitted a
significant increa.se in real per capita private
consumption. A large share of the population,
perhaps as much as 40%, remains too poor to
afford an adequate diet. Financial strains in
1990 and 1991 prompted government austerity
measures that slowed industrial growth but
permitted India to meet its international
payment obligations without rescheduling its
debt. Policy reforms since 1991 have extended
earlier economic liberalization and greatly
reduced government controls on production,
trade, and investment. US and other foreign
firms are increasing their investment in India.
In January 1994, international financial
reserves were comfortably high.
National product: GDP — purchasing power
equivalent — SI. 17 trillion (FY94esi.)
National product real growth rate: .J.H''if
(FY94est.)
National product per capita: $ 1 .3(M1 ( FY94
est.)
Inflation rale (consumer prices): (l‘A)3
est.)
Unemployment rale: NA''''J
Budget:
revenues: $29.(> billion
e.xpenilitiires: S4.S.I billion, including capital
expenditures of $1 1 .2 billion (FY93)
Exports: S2 1.4 billion (f.o.b.. I9*)3)
commodiiies: gems and jewelry, clothing,
engineering g<H)ds. chemicals, leather
manufactures, cotton \\arn. and fabric
partners: U.S I S.dff . Germanv 7.8''}. Italv
7.8''.t.(FY93)
Imports: $22 billion (c.i.f.. I9‘)3)
commodiiies: cnide oil and pct.oleum
prtxiucts. gems, fertilizer, chemicals,
machinery
partners: US 9.8''/r. Belgium 8.4*}} . Germans
7. 6*7, (FY93)
External debt: .$90.1 billion (March 1993)
Industrial production: growth rate 2''/< ( 1 993
est.); accounts for abmit 25''A of GDP
Electricity:
capacity: 82.(KK).(8K) kW''
production: 310 billion kWh
consumption per capita: 340 kWh (1992)
Industries: textiles, chemicals, fiHxJ
processing, steel, transportation equipment,
cement, mining, petroleum, machinery
Agriculture: accounts for about 4()<7r of GDP
and employs h.3''/r of labor force; principal
erttps — rice, wheat, oilseeds, cotton, jute. tea.
sugarciine. potatoes; livestock — cattle.
buffaloes, sheep, goats, poultry; fish catch of
about 3 million metric tons ranks India among
the world''s ..ip 10 fishing nations
Illicit drugs: licit producer of opium poppy
for the pharmaceutical trade, but some opium
is diverted to illicit international drug markets;
major transit country for illicit narcotics
produced in neighboring countries; illicit
producer of hashish; minor production of illicit
opium
Economic aid:
recipient: US commitments, including Ex-Im
(FY70-89). $4,4 billion; Western (non-US)
countries, ODA and OOF bilateral
commitments (1980-89), $3 1 .7 billion: OPEC
bilateral aid (1979-89), $315 million; USSR
( 1970-89), $I 1.6 billion; Eastern Europe
(1970-89). $105 million
Currency: 1 Indian rupee (Re) = lOOpaise
Exchange rates: Indian rupees (Rs) per
US$ I —3 1 ,370 (January 1 994), 30.493 ( 1 993).
25.918 ( 1992). 22.742 ( 1991 ). I7..5()4 ( 1990).
16.226(1989)
Fiscal year: 1 April — 31 March
Overview; The economy is ba.sed on fishing,
tourism, and shipping. Agriculture is limited to
the production of a few subsistence crops that
provide only 10% of food requirements.
Fishing is the largest industry, employing 25%
of the work force and accounting for over 60%
of exports; it is also an important source of
government revenue. During the 1980s tourism
became one of the most important and highest
growth sectors of the economy. In 1988
industry accounted for about 5% of GDP. Real
GDP is officially estimated to have increased
by about 10% annually during the period 1974-
90.
National product: GDP — exchange rate
conversion — $140 million (1991 est.)
National product real growth rate: 6%
(1993 est.)
National product per capita: $620 (1991
est.)
Inflation rate (consumer prices): 1 5%
(1993 est.)
Unemployment rate; NEGL%
Budget;
revenues: $95 million (excluding foreign
transfers)
expenditures: S143 million, including capital
expenditures of $7 1 million ( 1 993 est. )
Exports: $.56.3 million (f.o.b., 1993 est.)
commodities: fish, clothing
partners; US. UK. Sri Lanka
Imports: $173.6 million (c.i.f., 1993 est.)
commodities; consumer gtxrds, intermediate
Q
and capital goods, petroleum products
partners; Singapore. Germany, Sri Lanka.
External debt; $148 million (1993 est.)
Industrial production: growth rate 24.0%
( 1 990); accounts for 6% of GDP
Electricity:
caiHicity; 5,000 kW
production; 1 1 million kWh
consumption per capita: 50 kWh ( 1 990)
Industries: fishing and fish processing,
tourism, shipping, boat building, some coconut
processing, garments, woven mats, coir (rope),
handicrafts
Agriculture: accounts for almost 25% of
GDP (including fishing): fishing more
important than farming; limited production of
coconuts, com, sweet potatoes; most staple
foods must be imported: fish catch of 67,(X)0
tons (1990 est.)
Economic aid:
recipient: US commitments, including Ex-Im
(FY70-88), $28 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $125 million; OPEC
bilateral aid (1979-89), $14 million
Currency: I rufiyaa (Rf) = 100 laari
Exchange rates: rufiyaa (RO per US$1 —
1 1.105 (January I99-4). 10.9.57(199.3), 10.569
(1992). 10.253 (1991), 9.509 (1990). 9,0408
(1989)
Fiscal year: calendar year','7843b3a31f812982de50a40ef7a01618556bf4cc177f0b09e467b08655b61416','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8aef6aede1fe7ca8a44eb93842d00d9f063e840adb14ed2c8adb6338f48d0fbc',1994,'OM','Oman','economy',509,'Overview: Iran’s economy is a mixture of
central planning, state ownership of oil and
other large enterprises, village agriculture, and
small-scale private trading and service
ventures. Over the pwst several years, the
government has iniriKluced several measures to
liberalize the economy and reduce government
intervention, but most of these changes have
moNcd slowly because of political opposition,
Iran has faced increasingly severe financial
difficulties in 1992-9.^ due to an import surge
since 1989 and general financial
mismanagement. At yearend I99,t the Iranian
Government estimated that it owed foreign
creditors absiut $.10 billion; an estimated $8
billion of this debt was in arrears. Earnings
from oil exports — which provide over 90Ci of
Iran''s export revenues — are providing less
relief to Iran than usual because of declining oil
prices. Estimated overall growth was a robust
h.,ir( in 1992 and a nuxlerate .I''T in 199.1,
National product; GNP — purchasing power
equivalent — $,ll).1 billion ( 199,1 est.)
National product real growth rate: .I''f
( 199.1 est.)
National product per capita; $4,780(199.1
est.)
Inflation rale (consumer prices): l()‘t
(September 1 992 -.September l‘)9.l)
Unemployment rate: .lOT (1991 est.)
Budget:
n''vemws: SNA
expenditures: SNA. including capital
expenditures of SNA
Exports: SI 5.5 billion (f.o.b.. FY92 est.)
commodities: petroleum 909i-. carpets, fruits,
nuts, hides
partners: Japan, Italy, France. Netherlands.
Belgium/Luxembourg, Spain, and Germany
Imports: $2.1.7 billion (c.i.f.. FY92 est.)
comimklities: macliinery. military supplies,
metal works, ftKxJstuffs, pharmaceuticals,
technical services, refined oil products
panners: Germany. Japan, Italy. UK. France
External debt: $.10 billion (December 199.1)
Industrial production: growth rate .IT ( 1 99.1
est.); accounts for almost lOT of GDP.
including petroleum
Electricitv:
capacity: 15,649,(K)0kW
protiuction: 41.6 billion kWh
consumption per capita: 710 kWh ( 1992)
Industries: petroleum, petrochemicals,
textiles, cement and other building materials,
food processing (particularly sugar refining
and vegetable oil production), metal
fabricating
Agriculture: accounts for about 20T of GDP;
principal producl.s— wheat, rice, other grains,
sugar beets, fruit.s. nuts, cotton, dairy products,
wool, caviar: not self-sufficient in fo^
Illicit drugs; illicit producer of opium poppy
for the domestic and international drug trade;
net opiate importer but also a key
transshipment point for Southwest Asian
heroin to Europe
Ecunomic aid:
recipient: US commitments, including Ex-lm
(FY7()-80), $1 billion; Western (non-US)
countries. ODA and OOF bilateral
commitments ( 1970-89), $1,675 billion;
Communist countries ( 1970-89), S976 million
note: aid fell sharply following the 1979
revolution
Currency: I Iranian rial (IR) = 10 tomans
Exchange rates; Iranian rials (IR) per
US$1 — 1,748,86 (January 1994). 1.267.77
( 1991), 65.552 (1992). 67..505 ( 1991 ); note-
in March 1991 the Iranian government
announced a new single-parity exchange rate
system with a new official rate of 1,518 rials
per dollar; there is also a black market rate of
22(X) rials per USSI (December 1991)
Fiscal year; 2 1 Mareh — 20 March
Cummunications
Railroads: 4,852 km total; 4JW km 1 .412-
metcr gauge. 92 km 1 .676-iTK;ter gauge; 480
km under construction from Bafq to Bandur-e
''Abbas, rail construction from Bafq to Sirjan
has been completed and is opcraiional; section
from Sirjan to Bandar-e ''.Abbas still under
construction
Highways;
total: l40,2(X)km
ixtved: 42,694 km
imiKived: gravel, crushed stone 46.866 km;
improved earth 49,440 km; unimpmved earth
1,200 km
Inland waterways: 904 km; the Shatt al Arab
is usually navigable by maritime maffic for
about 110 km; channel has been dredged to 1
meters and is in use
Pipelines; crude oil 5,900 km; petroleum
products 1.900 km; natural gas 4.,150 km
Ports: Abadan (largely destroyed in fighting
during 1980-88 war). Bandar Beheshti,
Bandar-e ‘Abbas. Bandar-e Bushehr. Bandar-e
Khomeyni. Bandar-e Torkeman (Caspian Sea
port), Khorramshahr (repaired after being
largely destroyed in fighting during 1980-88
war) has been in limited operation since
November 1992
Merchant marine: 1 19 ships ( I .(XX) GRT nr
over) totaling 4.480.000 GRT/8, 112,667
DWT, cargo 41 . roll-on/roll-off cargo 8. oil
tanker 1 1 . chemical tanker 4. refrigerated cargo
1. bulk 48. combination bulk 2. liquefied gas I .
short-.sea passenger I
Airports:
total: 2 1 9
iisahle: 191
with permanent-surface runways: 80
with runways over J,6S9 m: 17
with runways 2,440-. i. 659 m: 18
with noiways 1.220-2,439 m: 70
Telecommunications: microwave radio relay
extends throughout country; system centered in
Tehran; 2,141.0(X) telephones (15 telephones
per 1 ,0(X) persons); broadcast stations — 77
AM, 1 FM, 28 TV ; satellite eanh stations — 2
Atlantic Ocean INTELSAT and I Indian
Ocean INTELSAT: HF radio and microwave
radio relay to Turkey. Pakistan. Syria, Kuwait,
Tajikistan, and Uzbekistan; submarine liber
optic cable to UAE
Defense Forces
Branches: Islamic Republic of Iran Ground
Forecs. Navy, Air and Air Defense Force.
Revolutionary Guards (including Basij militia
and own ground, air. and naval I''urees), Law
Enforcement Forces
Manpower availability: mules age 15-49
14,182.216; fit for military'' service 8,.555.76();
reach military age (2 1 ) annually 6tX).61()( 1994
est.)
Defense expenditures: according to official
Iranian data, Iran spent 1.785 billion rials,
including $808 million in hard currency in
1992 and budgeted 2.507 billion rials,
including $850 million in hard currency for
1991 test.)
note: conx ersion of rial expenditures into US
dollars using the prevailing exchange rate
could produce misleading results
Overview: Economic performance is closely
lied to the fortunes of the oil industry,
including trends in international oil prices and
the ability of OPEC producers to agree on
output quotas. Petroleum accounts for more
than SSOf of export earnings, about 80% of
government revenues, and roughly 40% of
GDP. Oman has proved oil re.sei''ves of 4 billion
barrels, equivalent to about 20 years'' supply at
the current rate of extraction. Agriculture is
carried on at a subsistence level and the general
population depends on imported food. The
government is encouraging private inve.stment,
both domestic and foreign, as a prime force for
further economic developntcnt.
National product: GDP — purchasing power
equivalent — $16.4 billion (199.3 e.st.)
299
Onwn ( continued f
Pacific Islands (Palau)« Trust
Territory of the
(UN trusteeship administered by the US)
^irtioMl pndMt rari grawth ralti 6.1%
,1993 CXI.)
NaOaMaprwhKtiMr capita: $10,000(1993
esi.)
laflaSea rate (caaMaacr pricaa): 2% (1993
est.)
UacmplojraMM rate: NA%
BadfM:
m’enues: $4.4 billion
expenditures: $3.2 billion, including capilal
expendilures of $1 billion ( 1994 exi.)
Exports: $3 billion (f.o.b.. 1993 ext.)
commodities: petroleum 87%. re-expons. fish,
processed copper, textiles
partners: DAE 30%, Japan 27%, South Korea
10%. Singapore 5% (1991)
Imports: $3.7 billion (f.o.b, 1993 esi.)
commodities: machinery, transportation
equipment, manufacture goods, food,
livestock, lubricants
partners: Japan 20%, UAE 14%. UK 19%. US
7%(1991)
External debt: $3 billion ( 1993)
Industrial production: growth rate 8.6%
( 1991 ). accounts for almost 60% of GDP,
including petroleum
Electricity:
capacity: 1.142,400 kW
production: 3. 1 billion kWh
consumption per capita: 3.200 kWh (1992)
Industries: crude oil production and refining,
natural gas production, construction, cement.
copper
Agitolture: accounts for 4% of GDP and
40% of the labor force (including fishing); less
than 2% of land cultivated; largely subsistence
farming (dates, limes, bananas, alfalfa,
vegetables, camels, cattle); not self-sufficient
in food; annual fish catch averages IOO.(X)0
metric tons
Economic aid:
recipient: US commitments, including Ex-Im
(FY70-89), $137 million; Western (non-US)
countries. ODA and OOF bilateral
commitments (1970-89), $148 million: OPEC
bilateral aid (1979-89), $797 million
Currency: I Omani rial (RO) = 1 ,0(X) baiza
Exchange rates: Omani rials (RO) per
US$1— 0.3845 (fixed rate since 1986)
Fiscal year: calendar year','2f4661941840b284083a177731438b64ff7f7d76961b207fecc3c0c0e4599900','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bbbf9093e26220c8775ec9aae8ae09c98689f6c92035fcdc560a79b1a9b0700',1994,'SA','Saudi Arabia','economy',510,'Map references: Middle East, Standard Time
Zones of the World
Area:
toUi! ureu: 437,072 sq km
kiiuhirea: 432,162 sq km
comptiiviivf areti: slightly more than twice the
siie of Idaho
Land boundaries: total 3.631 km. Iran I.45K
km. Jordan 181 km. Kuwait 242 km. Saudi
Arabia 814 km, Syria 60,3 km. Turkey 331 km
Coastline: 58 km
Maritime claims:
amtineiiuil shelf: not specified
territorial sea: 1 2 nm
International disputes: Iran and Iraq
re.stored diplomatic relations in 1^90 but are
still trying to work out written agreements
settling outstanding disputes from their eight-
year war concerning border demarcation,
prisoners-of-war. and freedom of navigation
and .sovereignty over the Shatt al Arab
waterway; in April 1991 official Iraqi
acceptance of UN Security Council Resolution
687. which demands that Iraq accept the
inviolability of the boundary set forth in its
1963 agreement with Kuwait, ending earlier
claims to Bubiyan and Warbah islands or to all
of Kuwait; the 20 May 1 993 final reptirt of the
UN Iraq/Kuwait Boundary Demarcation
Commission was welcomed by the Security
Council in Re.solution 833 of 27 May 1993.
which also reaffirmed that the decisions of the
commission on the boundary were final,
bringing to a completion the official
demarcation of the Iraq-Kuwait boundary;
Iraqi officials still refuse to unconditionally
recognize Kuwaiti ;sovercignty or the
inviolability of the UN demarcated border;
periodic disputes with upstream riparian Syria
over Euphrates wttter rights; potential dispute
over water development plans by Turkey for
the Tigris and Euphrates Rivers
Climate: mostly desert; ntild to cixtl winters
with dry, hot. cloudless summers;
northernmost regions along Iranian and
Turkish borders experience cold winters with
iKcasionally heavy snows
Terrain: mostly broad plains; reedy marshes
in southeast; mountains along borders with
Iran and Turkey
Natural resources: petroleum, natural gas.
phosphates, sulfur
l.aiiid u.se:
arable laiul: 1 29f
Itenmuieiil crops: 191-
meadows and /xistures: 9*>
forest and wtHidland: 39f
other: 75''^
Irrigated land: 25,500 sq km ( 1989 est)
Overview: The Ba''thist regime engages in
extensive central planning and management of
industrial prcxluction and foreign trade while
leaving some small-scale industry and services
and most agriculture to private enterprise. The
economy has been dominated by the oil sector,
which has traditionally pros ided about 95''''/} of
foreign exchange earnings. In the 198()s.
financial problems caused by massive
expenditures in the cight-yettr war with Iran
and damage to oil export facilities by Iran, led
the government to implement austerity
measures and to borrow heavily and later
reschedule foreign debt payments. After the
end of hostilities in 1 988. oil exptirts gradually
increased with the construction of new-
pipelines and restoraiinn of damaged facilities.
Agricultural dcveli^ment remained hampered
by labor shortages, sulini/ulion, and
disliKutions caused by previous land reform
and collcctivizatitm pmgrams. The industrial
sector, although accorded high priority by the
government, also was under llnuncial
constraints. Iraq''s seizure of Kuwait in August
1990. subsequent international economic
cmbargiK''s, and military action by an
international coalition beginning in January
1 99 1 drastically changed the economic picture.
Indu.strial and transpitrtaiiun facilities suffered
severe damage and have been only partially
restored. Oil expirris remain at less than 1 OT of
the previous level. Shortages of spare parts
continue. Living standards deteriorated even
further in 199.4 and early l994;consun)er
prices at least tripled in 199.4, The UN-
sponsored economic embargo has reduced
exports and intports and has contributed to the
sharp rise in prices. The govemntent''s policies
of supporting large military and internal
security forces and of allocating resources to
key supporters of the regime have exacerbated
shortage.s. In brief, per capita output in 199.4-94
is far below the 1989-90 level, hut no precise
e.stimate is available.
National product: GNP — purchasing power
equivalent — S.48 billion ( 199.4 cst.)
National product real growth rate: NAT
National product per capita; S2,(XX) (199.4
est.)
Inflation rate (consumer prices): 2(X)f(
(199,4 est.)
Unemployment rate; NAOf
Budget:
revemie.i; SNA
e.Kpeiuiitioe.''!: SNA, including capital
expenditures of SNA
Exports: $10.4 billion (f.o.b.. 1990)
coiwiuHlitie.''i: crude oil and refined products,
fertilizer, sulfur
jwtner.v US, Brazil, Turkey, Japan.
Netherlands. .Spain ( 1990)
Imports: $6.6 billion (c.i.f.. 1990)
commodities: manufactures. IikhI
imrtneiw: Germany. US. Turkey. France. UK
(1990)
External debt: $45 billion ( 1989 est.),
excluding debt of about $35 billion owed to
Arab Gulf states
Industrial production: NAtT; manufacturing
accounts for lO''T of GNP ( 1989)
Electricity;
ciiiuicity: 7..4(X).(XX) kW available out of
9,^)2,(XX) kW due to Gulf war
proihiction: 1 2.9 billion kWh
consumption pervapilo: 7(X) kWh ( 1992)
Industries: petroleum pnxluction and
refining, chemicals, textiles, construction
materials, fintd prrKessing
Agriculture: accounted for 1 19f of GNP and
.JOrT of labor force before the Gulf war;
principal products — wheat, barley, rice,
vegetables, dales, other fruit, cotton, wixil;
livesi(x;k— cattle, shc''cp; not self-sutTicieni in
UkkI output
Economic aid:
recipient: US commitments, including Ex-lm
(FY7()-8()). $3 million; Western (non-US)
countries, ODA and OOF bilateral
commitments ( 1970-89). $647 million;
Communist countries (1970-89), $3.9 billion
Currency: I Iraqi dinar (ID) = l.(XX) fils
Exchange rates: Iraqi dinars (ID) per
US$1— 3,2 (fixed official rale since 1982);
black-market rate (May 1994) USSl = 370
Iraqi dinars
Fiscal year; calendar year
Overview; Jordan benefited from increased
Arab aid during the oil boom of the late 1970s
and early 1980s, when its annual real GNP
growth averaged more than 10%. In the
remainder of the 1 980s, however, reductions in
both Arab aid and worker remittances slowed
real economic growth to an average of roughly
2% per year. Imports — mainly oil, capital
goods, consumer durables, and food —
outstripped exports, with the difference
covered by aid, remittances, and borrowing. In
mid- 1 989, the Jordanian Government began
debt-rescheduling negotiations and agreed to
implement an IMF-supported program
designed to gradually reduce the budget deficit
and implement badly needed structural
reforms. The Persian Gulf crisis that began in
August 1990, however, aggravated Jordan''s
already serious economic problems, forcing
the government to shelve the IMF program,
stop most debt payments, and suspend
rescheduling negotiations. Aid from Gulf Arab
states, worker remittances and trade
contracted, and refugees flooded the country,
producing serious balance-of-paymenis
problems, stunting GDP growth, and straining
government resources. The economy
rebounded in 1992, largely due to the influx of
capital repatriated by workers returning from
the Gulf, but the recovery has been losing
steam since mid-1993. The government is
implementing the reform program adopted in
1992 and continues to secure rescheduling of
its heavy foreign debt.
National product: GDP — purchasing power
equivalent — $1 1 .5 billion (1993 est.)
National product real growth rate: 5%
(1993 est.)
National product per capita; $3,000 (1993
est.)
inflation rate (consumer prices): 5% ( 1 993
est.)
Unemployment rate; 20% (1993 est.)
Budget;
revenues: $1.7 billion
expenditures: $1.9 billion, including capital
expenditures of $420 million ( 1993)
Exports: $1,4 billion (f.o.b.. 1993 est.)
comnuKliiies: phosphates, fertilizers, potash,
agricultural products, manufactures
partners: India, Iraq, .Saudi Arabia, EC.
Indonesia, UAE
Imports: $3.2 billion (c.i.f.. 1993 c.sl.)
commodities: crude oil, machinery, transport
equipment, food, live animals, manufactured
goods
iwriners: EC, US. Iraq, Japan. Turkey
External debt: $6.8 billion (December 1993
est.)
Industrial production: growth rate 3% ( 1 993
est.); accounts for 20% of GDP
Electricity;
capacity: 1.030.000 kW
production: 3.814 billion kWh
consumption per capita: 1,070 kWh ( 1992)
Industries: phosphate mining, petroleum
refining, cement. potu.sh. light manufacturing
Agriculture; accounts for about 10% of GDP;
principal products are wheat, barley, citrus
fruit, tomatoes, melons, olives; livestock —
sheep, goats, poultry; large net importer of
food
Economic aid;
recipient: US commitments, including Ex-lm
(FY70-89), $1.7 billion; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $1,5 billion; OPEC
bilateral aid (1979-89), $9.5 billion;
Communist countries (1970-89), $44 million
Currency: I Jordanian dinar (JD) = 1 ,000 fils
Exchange rates: Jordanian dinars (JD) per
US$1— 0.7019 (February 1994), 0.6928
(1993), 0.6797 (1992), 0.6808 (1991), 0.66.36
(1990). 0.5704 (1 989)
Fiscal year: calendar year
Overview: Oil is the backbone of the
economy and accounts for roughly 86% of
export earnings and 75% of gov .-.ent
revenues. Proved oil reserves oi billion
barrels should ensure continued output at
current levels for about 25 years. Oil has given
Qatar a per capita GDP comparable to the
leading industrial countries. Production and
export of natural gas ate becoming
increasingly important.
National product; GDP — purchasing power
equivalent — $8.8 billion (1 W3 est.)
National product real growth rate: -0.5%
(1993 est.)
National product per capita: $17,500(19°''’
est.)
Inflation rate (consumer |. , .''!%(’ ''>
est.)
Unemployment rate: NA%
Budget:
revenues; $2.5 billion
expenditures; $3 billion, including capital
expenditures of $440 million (1992 est.)
Exports: $3.4 billion (f.o.b., 1993 e.st.)
commodities: petroleum products 85%, steel,
fertilizers
partners; Japan 61%, Brazil 6%, South Korea
5%, UAE 4%, Singapore 3% (1991)
Imports: $1.8 billion (f.o.b., 1993 est.)
commodities: machinery and equipment,
consumer goods, food, chemicals
partners; Japan 14%, UK 12%, US 12%,
Germany 9%, France 5% (1991)
External debt: $ 1 .5 billion ( 1993 est.)
Industrial production: growth rate NA%;
accounts for 64% of GDP, including oil
Electricity:
capacity: 1,596,000 kW
production: 4.818 billion kWh
consumption per capita: 9,655 kWh (1992)
Industries: crude oil production and refining,
fertilizers, petrochemicals, steel (rolls
reinforcing bars for concrete construction),
cement
Agriculture: farming and grazing on small
scale, less than 2% of GDP; agricultural area is
small and government-owned; commercial
fishing increasing in importance; most food
imported
Economic aid:
donor; pledged In ODA to less developed
countries (1979-88), $2.7 billion
Currency: I Qatari riyal (QR) = 100 dirhams
Exchange rates: Qatari riyals (QR) per
US$1 — 3.64(K) riyals (fixed rate)
Fiscal year: 1 April — 31 March
Overview: The economy has traditionally
been bused on agriculture. Sugarcane has been
the primary crop for more than a century, and
in some years it accounts for 85% of expc<rts.
The government has been pushing the
development of a tourist industry to relieve
high unemployment, which recently amounted
to one-third of the labor force. The gup in
Reunion between the well-off and the poor is
extraordinary and accounts for the persistent
social tensions. The white and Indian
communities ate substantially better off than
other segments of the population, often
approaching European standards, whereas
indigenous groups suffer the poverty and
unemployment typical of the poorer nations of
the African continent. The outbreak of severe
rioting in February 1991 illustrates the
seriousness of stK''ioeconomic tensions. The
economic well-being of Reunion depends
heavily on continued financial assistance from
France.
National product: GDP — purchasing power
equivalent — $2.5 billion (1995 est.)
National product real growth rate: NA%
National product per capita: $5,9(X) ( 1995
est.)
Inflation rate (consumer prices): 1 .5%
(1988)
Unemployment rate: 55%. (February 1991)
Budget:
revenues: $558 million
expenditures: $914 million, including capital
expenditures of $NA ( 1986 est.)
Exports: $166 million (f.o.b., 1988)
commodities: sugar 75%., rum and molasses
4%, perfume essences 4%., lobste 5%., vanilla
and tea I %''
partners: l•rancc. Mauritius, Bahrain, .South
Africu. Italy
Imports: $1.7 billion (c.i.f., 1988)
526
Overview: The petroleum sector accounts for
roughly 75% of budget revenues, 35% of GDP,
345
Saudi Arabia (continued)','1242285b763748a47c50554a77d3d9a17de7cdeec6f82b9ee4a491b8760b3b3b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3335ca3fb41babd0a890e64474897b49a4d253a0c038a20873a59e8b54e42202',1994,'IE','Ireland','economy',520,'Overview; The economy is small and trade
dependent. Agriculture, once the most
important sector, is now dwarfed by industry,
which accounts for 37% of GDP, about 80% of
exports, and employs 28% of the labor force.
Since 1987, real GDP growth, led by exports,
has averaged 4% annually. Over the same
period, inflation has fallen sharply and chronic
trade deficits have been transformed into
annual surpluses. Unemployment remains a
serious problem, however, and job creation is
the main focus of government policy. To ease
unemployment, Dublin aggressively courts
foreign investors and recently created a new
industrial development agency to aid small
indigenous firms. Government a.ssi.siance is
constrained by Dublin''s continuing deficit
reduction measures.
National product: GDP — purchasing power
equivalent — $46.3 billion ( 1993)
National product real growth rate; 2.7%
(199,3)
National product per capita; $ 1 3. 100
(1993)
Inflation rate (consumer prices); 2.7%
(1994 est.)
Unemployment rate: 16% (1994 e.st.)
Budget:
revenues: $16 billion
expenditures: $ 16.6 billion, including capital
expenditures of $1 .6 billion ( 1992 est.)
Exports: $28.3 billion (f.o.b., 1992)
commodities: chemicals, data processing
equipment, industrial machinery, live animals,
animal products
partners: EC ^5% (UK 32%. Germany 13%.
France 10%), US 9%
Imports: $23.3 billion (c.i.f.. 1992)
commodities: food, animal feed, data
processing equipment, petroleum and
petroleum products, machinery, textiles,
clothing
partners: EC 66% (UK 41%, Germany 8%.
Netherlands 4%), US 15%
External debt: $17.6 billion (1992)
Industrial production: growth rate 1 1 .5%
(1992); accounts for 37% of GDP
Electricity:
capacity: 5,000,000 kW
production: 14.5 billion kW''h
consumption per capita: 4, 1 20 kWh ( 1 992)
Industries: food products, brewing, textiles,
clothing, chemicals, pharmaceuticals,
machinery, transportation equipment, glass
and crystal
Agriculture: accounts for 8% of GDP and
13% of the labor force; principal crops —
turnips, barley, potatoes, sugar beets, wheat;
livestock — meat and dairy products; 85% self-
sufficient in food; food shortages include bread
grain, fruits, vegetables
Illicit drugs: transshipment point for hashish
from North Africa to the UK and Netherlands
Economic aid:
donor: ODA commitments (1980-89), $90
million
Currency: 1 Irish pound (£Ir) = 100 pence
Exchange rates: Irish pounds (£lr) per
US$1— 0.6978 (January 1 994). 0.6816 (1993),
0.5864 ( 1 992), 0.6 1 90 ( 1 99 1 ), 0.6030 ( 1 990),
0.7472(1989)
Fiscal year: calendar year','8b188731acc6d47ec332b2baab0c25eb373509964b605a3ce8dfe2ddd87ab436','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b047ad418bd6d60f0cf7484af10a9e17ac05dee3aea85051f1a96990f2928621',1994,'JO','Jordan','economy',529,'Overview: Israel has a market economy with
substantial government participation. It
depends on imports of crude oil, grains, raw
materials, and military equipment. Despite
limited natural resources, Israel has intensively
developed its agricultural and industrial sectors
over the past 20 years. Industry employs about
22% of Israeli workers, construction 6.5%,
agriculture, forestry, and Fishing 3.5%, and
services most of the rest. Diamonds, high-
technology equipment, and agricultural
products (fruits and vegetables) are leading
exports. Israel usually posts current account
deficits, which are covered by large transfer
payments from abroad and by foreign loans.
Roughly half of the government''s external debt
is owed to the United States, which is its major
source of economic and military aid. To earn
needed foreign exchange, Israel has been
targeting high-technology niches in
international markets, such as medical
scanning equipment. The influx of Jewish
immigrants from the former USSR, which
lopped 450,000 during the period 1990-93,
increased unemployment, intensified housing
problems, and strained the government budget,
At the same time, the immigrants bring to the
economy valuable scientific and professional
expertise. Economic problems have eased as
immigration has declined, but activity has
slowed as (he economy shifts from housing to
export-driven growth.
National product: GDP — purchasing power
equivalent— $65.7 billion (1993 est.)
National product real growth rate: 3.5%
(199.3 est.)
National product per capita: $ 1 3,350 ( 1 993
est.)
Inflation rate (consumer prices): 1 1 .3%
( 199.3 est.)
Unemployment rate: 1 0.4% ( 1 993 est. )
Budget:
revenues: $33.4 billion
expenditures: $36.3 billion, including capital
expenditures of $9.4 billion (FY93)
Exports: $14.1 billion (f.o.b., 1993 est.)
commodities: machinery and eijuipment, cut
diamonds, chemicals, textiles and apparel,
agricultural products, metals
partners: US, EC. Japan
Imports: $20,3 billion (c.i.f., 1993 est.)
commodities: military equipment, investment
goods, rough diamonds, oil, other productive
inputs, consumer goods
partners: US. EC
External debt: $24.8 billion (December 1993
e.st.)
Industrial production: growth rate 6.5%
(1993 est.): accounts for about 30% of GDP
196','6a434f8f51c709f85c77ebc2cd9e5ffcb88faffc958d1e1bb50df02b0d02cbe9','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5fd23b52e89d2ee915bbdbd275e3553d1a9f6702760ecaf2ce7202601ffd1d9b',1994,'JM','Jamaica','economy',537,'Overview: The economy is based on sugar,
bauxite, and tourism. In September 1988.
Hurricane Gilbert inflicted severe damage on
crops and the electric power system, a sharp
but temporary setback to the economy. By
October 1989 the economic recovery from the
hurricane was largely complete, and real
growth was up to about .IT for 1989. In 1991,
however, growth dropped to 0.2T as a result of
the US recession, lower world bauxite prices,
and monetary instability. In 1992, growth was
1 .2T, supported by a recovery in tourism and
stabilization of the Jamaican dollar in the
second half of 1992.
National product: GDP — purchasing power
200
Jan Mayen
(territory of Norway)
PIpiHiwi! peifoleuin products 10 km
hirtet Kingston, Montego Bay. Pon Antonio
Mcrchaal marine: 4 ships ( 1.000 GRT or
over) totaling 9.618 aRT/l6.2IS DWT, roll-
on/roll-off cargo I. oil tanker I. bulk 2
Airporta:
total: 40
ttrahle: 27
with penmtfieni-surface rutmvvs: 10
with runways oirr i.65V m; 0
with runways 2,440-3.659 m: 2
with runways 1,220-2,439 m: I
Tchconimiiiricatlons: fully automatic
domestic telephone netwrik; 127.000
telephones: broadca.st station.s — 10 AM, 17
FM. 8 TV: 2 Atlantic Ocean INTELSAT earth
stations: 3 coaxial submarine cables
Defenae Forces
Branches: Jamaica Defease Force (including
Ground Forces. Coast Guard and Air Wing),
Jamaica Constabulary Force
Manpower nvailabiUty: males age 13-49
664. 1 22: fit for military service 469,982: reach
military age (18) annually 26.103 ( 1994 est.)
Defense expenditures: exchange rate
conversion — $19.3 million. 1% of GDP
(FY9I/92)
iQfcm
GcoRmphy
Location: Nordic State. Northern Europe, in
the North Atlantic Ocean, north of (he Arctic
Circle about .390 km north-northeast of
Iceland, between the Greenland Sea and the
Norwegian Sea
Map references: Arctic Region
Area:
total area: 373 sq km
land area: 373 sq km
comparative area: slightly more than twice the
size of Washington. DC
Land boundaries: 0 km
equivalent — SB billion ( 1992 est.)
National product real growth rate: 1.2%
(1992 est.)
National product per capita: $.3,200(1992
est.)
Inflation rate (consumer prices): .30%
(1992 est.)
Unemployment rate: 13.4% (1992)
Budget:
revenues: $600 million
exitenditures: $7.36 million, including capital
expenditures of SNA (FY91 est.)
Exports: $1.1 bilikm (f.o.b., 1992)
commodities: alumina, bauxite, sugar,
bananas, rum
partners: US 40%, UK 14%, Germany 10%,
Canada 10%. Norway 7%
Imports: $1.3 billion (f.o.b.. 1992)
commodities: fuel, other raw materials,
construction materials, food, transport
equipment, other machinery and equipment
partners: US 33%, UK 5%, Venezuela 6%,
Germany 5%. Japan 4.0%
External debt: $4.3 billion (1992 est.)
Industrial production: growth rale 2.0%
(1990): accounts for almost 23% of GDP
Electricity:
capadty: 1.127.000 kW
production: 2.736 trillion kWh
consumption per capita: 1 .090 kWh ( 1992)
Industi^: tourism, bauxite mining, textiles,
food processing, light manufactures
Agriralturc: accounts for about 7% of GDP.
2.3% of work force, and 1 7% of exports;
commercial crops — sugarcane, bananas,
coffee, citrus, potatoes, vegetables: livestock
and livestock products include poultry, goats,
milk: not self-sufficient in grain, meat, and
dairy pnxlucts
Illicit drugs: transshipment point for cocaine
from Central and South America to North
America and Europe; illicit cultivation of
cannabis; government has an active cannabis
eradication program
Economic aid:
recipient: US commitments, including Ex-lm
(FY70-89), $1.2 billion; other countries. ODA
and OOF bilateral commitments ( 1 970-89),
$1.6 billion
Currency: I Jamaican dollar (J$) = I (K) cents
Exchange rates: Jamaican dollars (J$) per
US$1 -.32.738(31 December 1993). 22.960
(1992), 12.116(1991). 7,184 ( 1990), 3.7446
(1989)
Fiscal year: I April — 31 March','c870eb469c3b35a1c88c5b7ee9660739e7b2817974de7047c8fc132a9a928f4f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af337118629304addb3e3c86e04f3cf7a33af6c7bbfa1f397d1ecde5d76517b6',1994,'KZ','Kazakhstan','economy',545,'Overview: Kazakhstan, the second largest of
the former Soviet states in territory, possesses
vast oil, coal, rare metals, and agricultural
resources. While the economy is gradually
making the transition from a Soviet command
system to a market system, strong elements of
state control persist including government
ownership of most economic assets and a
continued system of mandatory state
procurement for the key pnxlucts such us grain
and energy; likewise, agriculture remains
largely collectivized. On the other hand, new
businesses arc forming rapidly, the economy is
opening to foreign investment, and 1 2%- of
state-owned commercial enterprises have been
210
privatized. In 1993. a three-year industrial
privatization program was launched; an
independent currency was successfully
introduced; and two large joint ventures were
established with western oil companies. These
far-reaching structural transformations have
resulted in a cumulative decline in national
income of more than 30% since 1990. Loose
monetary policies have kept the inflation rate
high, averaging 28% per month for 1 993 and
accelerating at the end with the disruption
caused by a new currency. Since the
introduction of its independent currency in
November 1993, the government has renewed
its commitment to fiscal discipline and
accelerating economic reform. However,
growing economic hardship and rising ethnic
tensions between Kazakhs and Russians over
the division of economic assets will likely lead
to strong pressure to backtrack.
National product: GDP — purchasing powc
equivalent — $60.3 billion (1993 estimate from
the UN International Comparison Program, as
extended to 1991 and published in the World
Bank''s World Development Report 1993; and
as extrapolated to 1993 using official
Kazakhstani statistics, which are very
uncertain because of major economic changes
since 1990)
National product real growth rate; - 1 3%
(1993 est.)
National product per capita: $3,S 1 0 ( 1 993
est.)
Inflation rate (consumer prices): 28% per
month (1993)
Unemployment rate: 0.6% includes only
officially registered unemployed; also large
numbers of underemployed workers
Budget:
revenurs: SNA
expenditures: SNA. including capital
expenditures of $ 1 .76 billion (1991 est.)
Exports; $1.3 billion to outside the FSU
countries (1993)
commodities: oil. ferrous and nonferrous
metals, chemicals, grain, wool, meat (1992)
partners: Russia, Ukraine. Uzbekistan
Imports: $358.3 million from outside the
FSU countries (1993)
commodities: machinery and parts, industrial
materials, oil and gas (1992)
partners: Russia and other former Soviet
republics. China
External debt: $1.5 billion debt to Ru.ssia
Industrial production: growth rate -16%
(1993)
Electricity;
capacity: 1 9, 1 35,000 kW
production: 81.3 billion kWh
consumption per capita: 4,739 kWh ( 1992)
Industries: extractive industries (oil. coal,
iron ore, manganese, chromite, lead, zinc,
copper, titanium, bauxite, gold, silver,
phosphates, sulfur), iron and steel, nonferrous
metal, tractors and other agricultural
machinery, electric motors, construction
materials
Agriculture: accounts for almost 40% of net
material product; employs about 26% of the
labor force; grain, mostly spring wheat; meat,
cotton, wool
Illicit drugs: illicit cultivation of cannabis
and opium poppy; mostly for CIS
consumption; limited government eradication
program; used as transshipment point for illicit
drugs to Western Europe and North America
from Central and Southwest Asia
Economic aid:
recipient: approximately $1 billion in foreign
credits to become available in 1994
Currency: national currency the tenge
introduced on 15 November 1993
Exchange rates: NA
Fiscal year: calendar year
Overview; Kyrgyzstan is one of the smallest
and poorest states of the former Soviet Union.
Its economy is heavily agricultural, producing
cotton and tobacco on irrigated land in the
south, grain in the foothills of the north, and
sheep and goats on mountain pastures. Its small
and obsolescent industrial sector, concentrated
around Bishkek, is heavily dependent on
Russia and other CIS countries for customers
and for inputs, including most of its fuel. Since
1990, the economy has contracted by almost
40%. Kyrgyzstan’s inflation was high in 1993,
about 23% per month, but rates were declining
at the end of the year. Kyrgyzstan introduced
its national currency, the som, in May 1993, it
has privatized 28% of its former state assets,
and plans call for a massive voucher
privatization in 1994. Although Kyrgyzstan
will receive relatively large flows of foreign
aid. ongoing economic restructuring will
continue to be painful with an anticipated
increase in unemployment as uneconomic
enterprises close. President AKAYEV will be
under strong political pressure to backtrack on
some reform mea.sures.
National product: GDP — purchasing power
equivalent — S 11.3 billion (1993 estimate from
the UN Internatioi''.al Comparison Program, as
extended to 1991 and published in the World
Bank’s World Development Report 1993; and
as extrapolated to 1993 using official Kirghiz
statistics, which are very uncertain because of
major economic changes since 1990)
National product real growth rate: -13.4%
(1993 est.)
National product per capita: $2,440 (1993
est.)
Inilation rate (consumer prices): 23% per
month (1993 est.)
Unemployment rate: 0.2% includes
officially registered unemployed; also large
numbers of unregistered unemployed and
underemployed workers
Budget:
revenues: $NA
expenditures: SNA, including capital
expenditures of SNA
Exports: $100.4 million to countries outside
the FSU (1993 e.st.)
commodities: wool, chemicals, cotlon. ferrous
and nonferrous metals, shoes, machinery,
tobacco
partners: Russia 70%. Ukraine. Uzbekistan,
Kazakhstan, and others
Imports: $105.8 million from countries
outside the FSU (1993 est.)
commodities: grain, lumber, industrial
products, ferrous metals, fuef machinery,
textile!!, footwear
partners: other CIS republics
External debt: SNA
Industrial production: growth rate -27%
(1993 est.)
Electricity:
capacity: 4,100.000 kW
production: 1 1,8 billion kWh
consumption per capita: 2,551 kWh (1992)
Industries: small machinery, textiles, food¬
processing industries, cement, shoes, sawn
logs, refrigerators, furniture, electric motors,
gold, and rare earth metals
Agriculture: wool, tobacco, cotton, livestock
(sheep, goats, cattle), vegetables, meat, grapes,
fruits and berries, eggs, milk, potatoes
Illicit drugs: illicit cultivator of cannabis and
opium poppy; mostly for CIS consumption;
limited government eradication program; used
as transshipment point for illicit drugs to
Western Europe and North America from
Central and Southwest Asia
Economic aid:
recipient: $80 million in 1993 and an
anticipated $400 million in 1994
Currency: introduced national currency, the
som (10 May 1993)
Exchange rates: NA
Fiscal year: calendar year
Overview: Laos has had a Communist
centrally planned economy with government
ownership and control of major productive
enterprises. Since 1986, however, the
government has been decentralizing control
and encouraging private enterprise. Laos is a
landlocked country with a primitive
infrastructure; it has no railroads, a
rudimentary road system, limited external and
internal telecommunications, and electricity
available in only a limited urea. Subsistence
agriculture is the main occupation, accounting
for over 60% of GDP and providing about
85-90% of total employment. The predominant
crop is rice. For the foreseeable future the
economy will continue to depend for its
survival on foreign aid from the IMF and other
international sources; aid from the former
USSR and Eastern Europe has been cut
sharply.
National product: GDP — purchasing power
equivalent— $4.1 billion (1993 est.)
224','28f7a1d88368f23a6f1b213324080bb0c7862314b63f9364e6e378005e96a169','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d24259fceea49e42613326063f8741d83208bec70975ee87b8c6d0f219f505a',1994,'KE','Kenya','economy',550,'Overview: Kenya''s 3. 1 % annual population
growth rate — one of the highest in the world —
has led to a decline in per capita output in each
of the last three years, 1 99 1 -93. Undependable
weather conditions and a shortage of arable
land hamper long-term growth in agriculture,
the leading economic sector. In industry and
services, Nain s reluctance to embrace IMF-
supported reforms has held back investment.
Ethnic clashes and continued suspension of
quick disbursing aid by the international
donors kept growth at only 0.5% in 1993.
National product: GDP — purchasing power
equivalent — $33.2 billion (1993 est.)
National product real growth rate; 0.5%
(1993 est.)
National product per capita: $ 1 .200 ( 1 993
est.)
Inflation rate (consumer prices): 55%
(1993 est.)
Unemployment rate: 23.8% urban (1993
est.)
Budget:
revenues: $2.4 billion
expenditures: $2.8 billion, including capital
expenditures of $740 million (1990 est.)
Exports: $1 billion (f.o.b., 1992 est.)
commodities: tea 25%, coffee 1 8%, petroleum
products 1 1%> (1990)
partners: EC 47%. Africa 23%, Asia 1 1 %, US
4%, Middle East 3% (1991)
Imports: $1.6 billion (f.o.b., 1992 est.)
commodities: machinery and transportation
equipment 29%. petroleum and petroleum
products 15%. iron and steel 7%. raw
materials, food and consumer goods ( 1989)
partners: EC 46%, Asia 23%, Middle East
20%, US 5% (1991)
External debt: $7 billion (1992 est.)
Industrial production; growth rate 5.4%
(1989 est.); accounts for 13% of GDP
Electricity:
capacity: 730,000 kW
production: 2.54 billion kWh
consumption per capita: 1 00 kWh ( 1 990)
Industries: small-scale consumer goods
(plastic, furniture, batteries, textiles, soap.
cigarettes, flour), agricultural processing, oil
refining, cement, tourism
Agriculture: most important sector,
accounting for 25% of GDP and 65% of
exports; cash crops — coffee, tea, sisal,
pineapple; food products — com, wheat,
sugarcane, fruit, vegetables, dairy'' products,
beef, pork, poultry, eggs; food output not
keeping pace with population growth, and crop
production has been extended into marginal
land
Illicit drugs: widespread wild, small-plot
cultivation of marijuana and gat; most locally
consumed; transit country for Southwest Asian
heroin moving to West Africa and onward to
Europe and North America; Indian
methaqualone also transits on way to South
Africa
Economic aid:
recipient: US commitments, including Ex-lm
(FY70-89), $839 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $7.49 billion; OPEC
bilateral aid ( 1979-89), $74 million:
Communist countries (1970-89), $83 million
Currency: I Kenyan shilling (KSh) = 100
cents
Exchange rates: Kenyan shillings (KSh) per
US$1— 68.413 (December 1993), 32.217
(1992), 27.508 (1991), 22.915 (1990), 20.572
(1989)
Fiscal year: 1 July — 30 June','61350803a05a37e5623dcda9c2542f18b7c9d0a00f0d54c98e308baea46e9b93','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4be2acecebefc0183286e3dc054490c13b6e63044571b2ca5df04984fd85f884',1994,'KI','Kiribati','economy',553,'Overview: no economic activity
laouiiL
North PoeUlt Ocoon
. < .
r7-*TAaAWA Kihtimrti* ^ ^
Kiribati ^
(Qiibtrt R»w§ki * <
iMndt) » •
South Poeifie Oeoon','611d4d6752f0f4ac90790330e50ee2ab1a4fa9ec3c650dea6626bd3e34751615','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('969f7d5fe8158ac3a6cb7f90ba0e467e56f41e0ff01272bbebde43050ecef894',1994,'AS','American Samoa','economy',558,'Overview; The country has few national
resources. Commercially viable phosphate
deposits were exhausted at the time of
independence in 1979. Copra and fish now
represent the bulk of production and exports.
The economy has fluctuated widely in recent
years. Real GDP declined about 8% in 1 987. as
the fish catch fell sharply to only one-fourth the
level of 1986 and copra production was
hampered by repeated rains. Output rebounded
strongly in 1988, with real GDP growing by
17%. TTie upturn in economic growth came
from an increase in copra production and a
good fish catch. Following the strong surge in
output in 1988, GNP increased 1% in both
1989 and 1990.
National product; GDP — exchange rate
conversion — $36.8 million (1990 est.)
National product real growth rate: 1 .5%
(1992 est.)
National product per capita: $525 ( 1 990
est.)
Inflation rate (consumer prices): 4% (1992
est.)
Unemployment rate: 2%; underemployment
70% (1 992 est.)
Budget:
revenues: $29.9 million
expenditures: $16.3 million, including capital
expenditures of $14 million (1990 est.)
Exports: $4.2 million (fo b.. 1992 est.)
commodities: copra 50%. seaweed 16%, fish
15%
partners: Denmark, Fiji, US
Imports: $33.1 million (c.i.f, 1992 est.)
commodities: foodstuffs, machinery and
equipment, miscellaneous manufactured
goods, fuel
partners: Australia 40%, Japan 18%, Fiji 17%,
NZ 6%, US 4% (1991)
External debt: $2 million (December 1989
est.)
Industrial production: growth rate 0.7%
(1992 est.); accounts for less than 4% of GDP
Electricity;
capacity: 5,000 kW
production: 13 million kWh
consumption per capita: 190 kWh (1990)
Industries: fishing, handicrafts
Agriculture: accounts for 23% of GDP
(including fishing); copra and fish contribute
about 65% to exports: .subsistence farming
predominates: food crops— taro, breadfruit,
sweet potatoes, vegetables; not .self-sufficient
in food
Economic aid;
recipient: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-89),
$273 million
Currency: I Australian dollar ($A) = 100
cents
Exchange rates: Australian dollars ($A) per
US$ 1 — 1 .4364 (January 1 994), I 4704 ( 1 993),
1.-3600(1992). 1.2835(1991). 1.2799(1990),
1.2618(1989)
Fiscal year: NA
Overview: More than 9Q% of this command
economy is socialized; agricultural land is
collectivized; and state-owned industry
produces 95% of manufactured goods. State
control of economic affairs is unusually tight
even for a Communist country because of the
small size and homogeneity of the society and
the strict rule of KIM Il-song and his son, KIM
Chong-il. Economic growth during the period
1984-88 averaged 2%-3%, but output declined
by 3%-5% annually during 1989-92 because of
systemic problems and disruptions in socialist-
style economic relations with the former USSR
and China. In 1992, output dropped sharply, by
perhaps 7%-9%, as the economy felt the
cumulative effect of the reduction in outside
support. The leadership insisted on
maintaining its high level of military outlays
from a shrinking economic pie. Moreover, a
serious drawdown in inventories and critical
shortages in the energy sector have led to
increasing interruptions in industrial
production. Abundant mineral resources and
hydropower have formed the basis of industrial
development since WWII, Output of the
extractive industries includes coal, iron ore,
magnesite, graphite, copper, zinc, lead, and
precious metals. Manufacturing is centered on
heavy industry, including military industry,
with light industry lagging far behind. Despite
the use of improved seed varieties, expansion
of irrigation, and the heavy use of fertilizers.
North Korea has not yet b^ome self-sufficient
in food production. Six consecutive years of
pour harvests, coupled with distribution
problems, have led to chronic food shortages.
North Korea remains far behind South Korea in
economic development and living standards.
National product; GDP — purchasing power
equivalent — $22 billion ( 1992 est.)
National product real growth rate: -7 to
-9%(l992e.st.)
National product per capita: S I ,(X)0 ( 1 992
e.st.)
Inflation rate (consumer prices): NA%
Unemployment rate: NA%
Budget;
revenues: $19.3 billion
expenditures: $19.3 billion, including capital
expenditures of SNA (1992 est.)
Exports: $1.3 billion (fo.b., 1992 est.)
commodities: minerals, metallurgical
products, agricultural and fishery products,
manufactures (including armaments)
partners: China, Japan, Russia, South Korea,
Germany, Hong Kong, Mexico
Imports: $1.9 billion (f.o.b., 1992 est.)
commodities: petroleum, grain, coking coal,
machinery and equipment, consumer goods
partners: China, Russia, Japan, Hong Kong,
Germany, Singapore
External debt: $8 billion ( 1 992 est.)
Industrial production: growth rate -7% to
-9% (1992 est.)
Electricity:
i opacity; 7,300,000 kW
production: 26 billion kWh
consumption per capita: 1 , 1 60 kWh ( 1 992)
Industries; machine building, military
products, electric power, chemicals, mining,
metallurgy, textiles, food processing
Agriculture: accounts for about 25% of GNP
and 36% of work force; principal crops — rice,
com, potatoes, soybeans, pulses; livestock and
livestock products — cattle, hogs, pork, eggs;
not self-sufficient in grain
Economic aid:
recipient: Communist countries, $ 1 .4 billion a
year in the 1980s, but very little now
Currency: 1 North Korean won (Wn) = 100
chon
Exchange rates: North Korean won (Wn) per
US$1— 2.15 (May 1994). 2.13 (May 1992),
2. 14 (September 1991), 2.1 (January 1990), 2.3
(December 1989)
Fiscal year: calendar year
Overview: no economic activity','cbb18bce9d7304d6f711caa5014a054df661f97016d45529155dc924a9b2a171','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7e3734f293d65a8496e9fb25fcf17b96125ac1e189293085c8eecb523e1039b',1994,'LV','Latvia','economy',563,'National product real growth rate: 7%
(1992 est.)
National product per capita: $900 (1993
est.)
Inflation rate (consumer prices): 9.8%
(1992 est.)
Unemployment rate: 2 1 % ( 1989 est.)
Budget:
revenues: $83 million
expenditures: $ 1 88.S million, including capital
expenditures of $94 million (1990 est.)
Exports: $133 million (f.o.b., 1992 est.)
commodities: electricity, wood products,
coffee, tin
partners: Thailand, Malaysia, Vietnam, FSU,
US, China
Imports: $266 million (c.i.f., 1992 est.)
commodities: food, fuel oil, consumer goods,
manufactures
partners: Thailand, FSU, Japan, France,
Vietnam. China
External debt: $1.1 billion (1990 est.)
Industrial production: growth rate 12%
(1991 est.): accounts for about 1 8% of GDP
(1991 est.)
Electricity:
capacity: 226,000 kW
production: 990 million kWh
consumption per capita: 220 kWh (1992)
Industries: tin and gypsum mining, timber,
electric power, agricultural processing.
construction
Agriculture: accounts for 60% of GDP and
employs most of the work force; subsistence
farming predominates: normally self-sufficient
in nondrought years; principal crops — rice
(80% of cultivated land), sweet potatoes,
vegetables, corn, coffee, sugarcane, cotton;
livestock — buffaloes, hogs, cattle, poultry
Illicit drugs: illicit producer of cannabis,
opium poppy for the international drug trade,
Ihird-largest opium producer ( 1 80 metric tons
in 1993)
Economic aid:
recipient: US commitments, including Ex-lm
(FY70-79). $276 million; Western (non-US)
countries. ODA and OOF bilateral
commitments (1970-89), $605 million;
Communist countries (1970-89), $995 million
Currency: I new kip (NK)= 100 at
Exchange rates: new kips (NK) per US$1 —
720 (July 1993). 710 (May 1992), 710
(December 1991), 7(X) (ocptember 1990). 576
(1989)
Fiscal year: 1 July — 30 June
mid-May to mid-September)
Inland waterways: about 4,587 km,
primarily Mekong and tributaries; 2,897
additional kilometers are sectionally navigable
by craft drawing less than 0.5 m
Pipelines: petroleum products 136 km
Ports: none
Merchant marine: I cargo ship ( 1 ,000 GRT
or over) totaling 2,370 GRT/3,000 DWT
Airports:
total: 53
usable: 41
with permanent-surface runways: 8
with runways over 3,659 m: 0
with runways 2,440-3,659 m; 1
with runways 1 ,220-2,439 m: 15
Telecommunications: service to general
public practically non-existant; radio
communications network provides generally
erratic service to government users; 7,390
telephones ( 1986); broadcast stations — 10
AM, no FM, I TV; 1 satellite earth station
Defense Forces
Branches: Lao People’s Army (LPA;
including naval, aviation, and militia
elements). Air Force, National Police
Department
Manpower availability: males age 15-49
1.015,357; fit for military service 547.566;
reach military age (18) annually 49,348 (1994
est.)
Defense expenditures: exchange rate
conversion — $NA, NA% of GDP
Overview: Latvia is rapidly becoming a
dynamic market economy, rivaled on''y by
Estonia among the former Soviet states in the
speed of its transformation. The transition has
been painful with GDP falling over 45% in
1 992-93, according to official statistics, and
industrial production experiencing even
steeper declines. Nevertheless, the
government''s tough monetary policies and
reform program, which foster the development
of the private sector and market mechanisms,
have kept inflation low, created a dynamic
private sector — much of which is not captured
in official slati.stics — and expanded trade ties
with the West. Much of agriculture is already
privatized and the government plans to step up
the pace of privatization of state enterprises.
The economy is now |X)ised for recovery and
will benefit from the country''s strategic
location on the Baltic Sea, its well-educated
population, and its diverse — albeit largely
obsolete — industrial structure.
National product: GDP — purchasing power
equivalent — $ 1 3.2 billion ( 1 993 estimate from
the UN International Comparison Program, as
extended to 1991 and published in the World
Bank''s World Development Report 1993; and
as extrapolated to 1 993 using official Latvian
statistics, which are very uncertain because of
major economic changes since 1990)
National product real growth rate: -5%
(1993 est.)
National product per capita: $4,8 1 0 ( 1 993
est.)
Inflation rate (consumer prices): 2% per
month (1993 average)
Unemployment rate: 5.6% (December 1993)
Budget:
revenues: SNA
expenditures: SNA, including capital
expenditures of SNA
Exports: $429 million from non-FSU
countries (f.o.b., 1992)
commodities: oil products, limber, ferrous
metals, dairy products, furniture, textiles
partners: Russia, other CIS countries. Western
Europe
Imports: SNA
commodities: fuels, cars, ferrous metals,
chemicals
partners: Russia, other CIS countries. Western
Europe
External debt; SNA
Industrial production; growth rate -38%
(1992 est.)
Electricity;
capacity: 2,140,000 kW
production: 5.8 billion kWh
consumption per capita; 2,125 kWh (1992)
Industries: employs 41% of labor force;
highly diversified: dependent on imports for
energy, raw materials, and inlermediate
products, produces buses, vans, street and
railroad curs, synthetic fibers, agricultural
machinery, fertilizers, washing machines,
radios, elec-./onics, pharmaceuticals, processed
foods, textiles
Agriculture: employs 16% of labor force;
principally dairy farming and livestock
feeding; products — meat, milk, eggs, grain,
sugar beets, potatoes, vegetables; fishing and
fish packing
Illicit drugs: transshipment point for illicit
drugs from Central and Southwest Asia and
226','228dab6cf60f55f817d72942e9f6b3cf1f8a24454c1530056263a0eaf3e61d03','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d9fce2c5e4b427dfc99e4703b7674b881446436882db97e53f2525c0968ea29',1994,'LB','Lebanon','economy',569,'Latin America to Western Europe; limited
producer of illicit opium; mostly for domestic
consumption; also produces illicit
amphetamines for export
Economic aid: $NA
Currency: 1 iat = 100 cents; introduced NA
March 1993
Exchange rates: lats per US$ I — 0.S9 1 7
(January 1994), 1.32 (March 1993)
Fiscal year; calendar year
Overview: Since 1975 civil war has seriously
damaged Lebanon''s economic infrastructure,
cut national output by half, and all but ended
Lebanon''s prisition as a Middle Eastern
entrepot and banking hub. Following October
1990, however, a tentative peace has enabled
the central government to begin re.storing
control in Beirut, collect taxes, and regain
access to key port and government facilities.
The battered economy has also been propped
up by a financially sound banking system and
resilient small- and medium-scale
manufacturers. Family remittances, banking
transactions, manufactured and farm exports,
the narcotics trade, and international
emergency aid are the main sources of foreign
exchange. In the relatively settled year of 1991.
industrial production, agricultural output, and
exports showed substaniial gains. The further
rebuilding of the war-ravaged country was
delayed in 1992 because of an upturn in
politicai wrangling. In October 1992, Rafiq
HARIRI was appointed Prime Minister.
HARIRI, a wealthy entrepreneur, has
announced ambitious plans for Lebanon''s
reconstruction which involve a substantial
influx of foreign aid and investment. Progress
on restoring basic services is limited. Since
Prime Minister HARIRI ''s appointment, the
most significant improvement lies in the
stabilization of the Lebanese pound, which had
gained over 30% in value by yearend 1993.
The year 1993 was marked by efforts of the
new administration to encourage domestic and
foreign investment and to obtain additional
international assistance.
National product: GDP — exchange rate
conversion — $6.1 bil''ion (1993 est.)
National product real growth rate: 4.2%
(1992)
National product per capita: $1,720 (1993
est.)
Inflation rate (consumer prices): 35%
(1 993 est.)
Unemployment rate: 35% (1993 est.)
Budget:
revenues: $990 million
expenditures: $1 .98 billion, including capital
expenditures of SNA (1993 est.)
Exports: $925 million (f.o.b.. 1993 est.)
commodities: agricultural products, chemicals,
textiles, precious and semiprecious metals and
jewelry, metals and metal products
partners: Saudi Arabia 21%, Switzerland
9.5%, Jordan 6%, Kuwait 1 2%, US 5%
Imports; .$4,1 billion (c.i, I''., 1993 est.)
commodities: Consumer goods, machinery and
transport equipment, petroleum privlucts
partners: Italy 14%. France 12%. US 6%.
Turkey 5%. Saudi Arabia 3%
External debt: $7(X) million ( 1993 est.)
Industrial production: growth rate 25%
(1993 est.)
Electricity:
capacity: 1 .3(X).(XX) kW
production: 3.413 billion kWh
consumption per capita: 990 kWh (1992)
Industries; bunking, food processing,
lexliles, cement, oil refining, chemicals,
jewelry, some metal fabricating
Agriculture: accounts for about one-third of
GDP; principal products— citrus fruits,
vegetables, potatoes, olives, tobacco, hemp
(hashish), sheep, goats; not self-sufficient in
grain
Illicit drugs: illicit producer of hashish and
heroin for the international drug trade; hashish
production is shipped to Western Europe, the
Middle East, and North and South America;
increasingly a key locus trf ewaine processing
and trafficking
Economic aid: aid for Lebanon''s
reconstruction programs currently totals $1.3
billion since October 1992. including a $175
million loan from the World Bank
Currency: I Lebanese pound (£1.) = l(X)
piasters
Exchange rates: Lebanese pounds (£L) per
U.S$I — 1.7 13. (X)( December 1993), 2.2(X),(X)
228
Overview: Syria''s state-dominated Bu''thist
economy has benefited Irom the Gulf war of
early 1991. increased oil production, gixid
weather, and economic deregulation.
Economic growth averaged roughly 10% in
1990-93 The Gulf war provided Syria an aid
windfall of nearly $5 billion dollars from Arab,
European, and Japanese donors. These inllows
more than offset Damascus’s war-related costs
and will help Syria cover some of its debt
arrears, restore suspended credit lines, and
initiate selected military and civilian
purchases. In 1992 the government spurred
economic development by Iwsening controls
on domestic and foreign investment while
383
Syria (cimiinitfd)
Taiwan
malnulning strict polliictti controk For the
long run. Syria''s economy is still saddled with
a large number of poorly performing public
sector firms, and industrial productivity
remains to be impioved. Another major long¬
term concern is the additional drain of
upstream Euphrates water by Turkey when its
vast dam and irrigation projMts arc completed
by mid-decade.
Nalioiwl ptroduct! OOP — purchasing power
equivalent — $8 1 .7 billion ( 199.^ est.)
NnUoiial pndHct re«l growth rale: 7.6%
(1993 est.)
NnUotwl product per otpita: $3,700(1993
est.)
lidlation rate (comumcr prkes); 16.3%
(1993 est.)
llnemptoyment rate: 7.3% (1993 est.)
Budget:
wewm.- $7.13 billion
expendimrr.t; $9.3 billion, including capital
expcndiiuies of $4 billion ( 1993 est.)
Exports: $3.4 billion (f.o.b., 1993 est.)
cttnummiiies: petroleum 33%. textiles 22%,
cotton, fruits and vegetables
partners; EC 48%, former CEMA countries
24%. Arab countries 18% ( 1991 )
Imports: $4.1 billion (c.i.f., 1993 est.)
nmmadities; foodstuffs 21%. metal products
17%, machinery 13%
partners; EC 37%. former CEMA countries
13%, US and Canada IU% (1991 )
External debt: S19,4 billion (1993 est.)
Industrial producUon; growth rate 21%
(1991); accounts for 19% of GDP, including
petroleum
Electricity:
atpacity; 3.203.W)0 kW
prt>ductiim; 1 1 ,9 billion kWh
amsnmption per capita: 8,30 kWh ( 1992)
Industries: textiles, food processing,
beverages, tobacco, phosphate rock mining,
petroleum
Agriculture: accounts for 30% of GD? and
one-third of labor force: all mqjor crops
(wheat, barley, cotton, lentils, chickpeas)
grown mainly on rain-watered land causing
wide swings in production: animal products —
beef, lamb, eggs, poultry, milk; not sclf-
suftlcicnt in grain or livestock products
Illicit drugs: a transit country for Lebanese
and Turkish refined cocaine going to Europe
and heroin and hashish bound for regional and
Western markets
Economic aid:
redpiem: no US aid; aid from other countries
(Western and Arab) totals $1,338 billion (1993
est.); no Ex-lm. OPEC programs in plac''e;
almost $3 billion in loans and grunts from Arab
and Western donors from 1 990-92 as a result of
Gulf war stance
Curraicy: I Syrian psHind(£S)= lOOpiastres
Exchange rates: Syrian pounds (£S) per
USSI— 1 1.2 (otTiciul fixed rate). 26.6 vblendcd
rale used by the UN and diplomatic missions).
42.0 (neighboring country rate — applies to
most slate enteiprise Imparts), 46.0—33.0
(offshore rate) (yeaiend 1993)
Elacalyaar. calendar year
CommuBlcationa
Rattranda: 1,998 km total; 1.766 km standard
gauge, 232 km I.a30-meier (narrow) gauge
Highways;
torn/.- 29.000 km
paierf; 22,680 km (including 670 km of
expres,<.ways) ( 1988)
nnpax''ed; 6,320 km
Inlaiid waierwayat 870 km: minimal
economic importance
PipcUiMs: crude oil 1,304 km, petroleum
pr^ucts 313 km
Poria: Taitus, Lalakia. Baniyas, Jablah
Merchant marine: 37 ships (1, 000 CRT or
over) totaling l3t.3l9GRT/243.9|0DWT.
cargo 48. vehicle carrier 2. bulk 7
Airporta:
total; 104
asoNe; 100
with permaneni-sarface ntnways: 24
with runways o\\rr 3,659 m; 0
with runways 2.440''3,559 m; 21
H irh runuays l,220~2,439m; 3
TeiccommunlcatioM: fair system currently
undcigoing significant improvement and
digital upgrades, including fiberoptic
technology; 3 1 2,600 telephones (37 telephones
per 1 .000 persons); broa^''asi stations — 9 AM.
I FM, 17 TV; satellite earth stations — I Indian
Ocean INTELSAT and I Intcrsputnik: I
submarine cable; coaxial cable and microwave
radio relay to Iraq. Jordan. Lebanon, and
Turkey
Dcibnae Forces
Branches: Syrian Arab Army, Syrian Arab
Navy, Syrian Arab Air Force, Syrian Arab Air
Defense Ftwees
Manpower availability: males age 1.3-49
.»,.300,397; fit for military service 1,850,545;
reach military age ( 19) annually 133.369 (1994
est.)
DeOmse expenditures: exchange rate
conversion — $2.2 billion, 6% of GDP ( 1992)
Entry
ihaMoB^M
rarowi
Zhnbobwe
384
T^jlktstan','8f2bf2af571f4ce841360a8ebb5864575dcb874569fad93c18a5e8451a623000','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1cbee02d922a09fdcc96b6773d11624a252390f3697aa080cf1b28cd3e88de12',1994,'LS','Lesotho','economy',574,'(1992), 928.23 (1991), 695.09 (1990), 496.69
(1989)
Fiscal year: calendar year
ComniunicBtions
Railroads; system in disrepair, considered
inoperable
Highways:
total; 7,300 km
paved; 6,200 km
unpaved; gravel 450 km; improved earth 650
km
Pipelines: crude oil 72 km (none in operation)
Ports: Beirut, Tripoli, Ra''Sil''ata, Juniyah,
Sidon, Az Zahrani, Tyre, Jubayl, Shikka
Jadidah
Merchant marine: 63 ships ( 1 ,000 CRT or
over) totaling 268,268 GRT/399,054 DWT,
cargo 39, refrigerated cargo I , vehicle carrier 2.
roll-on/roll-off cargo 2, container 2, livestock
carrier 9. chemical tanker I , specialized tanker
I, bulk 4, combination bulk I, combination
ore/oil 1
Airports;
total; 9
usable; 1
with permanent-surface runways; 5
with runways over 3,659 m; 0
with runways 2,440-3,659 m; 3
with runways 1,220-2,439 m; 1
Telecommunications: telecommunications
system severely damaged by civil war;
rebuilding still underway; 325,000 telephones
(95 telephones per 1,000 persons); domestic
traffic Carrie. I primarily by microwave radio
relay and a small amount of cable; international
traffic by satellite — I Indian Ocean
INTELSAT earth station and 1 Atlantic Ocean
INTELSAT earth station (erratic operations),
coaxial cable to Syria; microwave radio relay
to Syria but inoperable beyond Sy’ - Jordan,
3 submarine coaxial cables; brr^r’ai.i.-.t
stations — 5 AM, 3 FM. 13 TV (numerous AM
and FM stations are operated sporadically by
various factions)
Defense Forces
Branches: Lebanese Armed Forces (LAF;
including Army, Navy, and Air Force)
Manpower availability: males age 1 5-49
827,267; fit for military service 514,291
Defense expenditures: exchange ; .
conversion — $271 million. S " .. .’JP
(1992 budget)
Overview; Small, landlocked, and
mountainous. Lesotho has no important natural
resources other than water. Its economy is
based on agriculture, light manufacturing, and
remittances from laborers employed in South
Africa (recently equal to about 45% of GDP).
The great majority of households gain their
livelihoods from subsistence farming and
migrant labor; a large portion of the adult male
workforce is employed in South African mines.
Manufacturing depends largely on farm
pnxlucts to support the milling, canning,
leather, and Jute industries; other industries
include textile, clothing, and construction (in
particular, a major water improvement project
which will permit the sale of water to South
Africa). Industry''s share of GDP rose from 6%
in 1982 to 13% in 1991.
National product: GDP — purchasing power
equivalent — $2.8 billion (1993 est.)
National product real growth rate: 2.4%
(FY 93)
National product per capita: $I ,500 ( 1 993
est.)
inflation rate (consumer prices): 17%
(FY93)
Unemployment rate: at least 55% among
adult males (1991 est.)
Budget:
revenues; $438 million
expenditures; $430 million, including capital
expenditures of $155 million (1994 est.)
Exports: $109 million (f.o.b.. 1992)
commodities; wool, mohair, wheat, cattle,
peas, beans, com, hides, skins, baskets
partners; South Africa 42%, EC 28%. North
and South America 25% (1991)
Imports: $964 million (c.i.f.. 1992)
commodities; mainly com, building materials,
clothing, vehicles, machinery, medicines,
petroleum
partners; South Africa 94%, Asia 3%. EC 1 %
(1991)
External debt: $428 million (1991)
Industrial production: growth rate 5.0%
(1991 est.): accounts for 13% of GDP
Electricity; power supplied by South Africa
Industries: food, beverages, textiles,
handiri-afts, tourism
Agriculture: accounts for 1 5% of GDP (1991
est.) and employs 60-70% of all households:
exceedingly primitive, mostly subsistence
farming and livestock; principal crops com,
wheat, pulses, sorghum, barley
Economic aid:
recipient; US commitments, including E\\-Im
(FY70-89). $268 million; US (1992), $10,3
million; US ( 1 993 e.st.),$IO. I million; Western
(non-US) countries. ODA and OOF bilateral
commitments (1970-89), $819 million; OPEC
bi lateral aid ( 1 979-89). $4 million; Communist
countries (1970-89). $14 million
Currency: 1 loti (L)= 100 lisente
Exchange rates: maloti (M) per US$1 —
3.4096 (January 1994). 3.2636 (1993), 2.8497
( 1 992), 2.7563 (1991). 2.5863 ( 1 990), 2.6 1 66
( 1 989); note — the Basotho loti is at par with the
South African rand
Fiscal year; 1 April — 31 March','fa6fea4b66fee0bf6b689e51da66dafdf7ac2c7ab3053e9a4bd8ec7deeae75e8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ddb1b11b5e9444bc80a9a370d445098500993d32fe777a4256e7eea70b66ad5',1994,'LR','Liberia','economy',585,'Overview: Civil war since 1 990 has destroyed
much of Liberia''s economy, especially the
infrastructure in and around Monrovia.
Businessmen have fled the country, taking
capital and expertise with them. Many will not
return. Richly endowed with water, mineral
resources, forests, and a climate favorable to
agriculture, Liberia had been a producer and
exporter of basic products, while local
manufacturing, mainly foreign owned, had
been small in scope, ^litical instability
threatens prospects for economic
reconstruction and repatriation of some
730,000 Liberian refugees who have fled to
neighboring countries. The political impasse
between the interim government and rebel
leader Charles Taylor has prevented restoration
of normal economic life, including the
reestablishment of a strong central government
with effective economic development
programs.
National product: GDP — purchasing power
equivalent — $2.3 billion (1^3 est.)
National product real growth rate: 1 .5%
(1988)
National product per capita: $800(1993
est.)
Inflation rate (consumer prices): 1 2%
(1989)
IJnemployroent rate: 43% urban (1988)
Budget:
revenues; $242. 1 million
expenditures; $435.4 million, including capital
expenditures of $29.5 million ( 1 989 est.)
Exports: $505 million (f.o.b., 1989 est.)
commodities; iron ore 61%, rubber 20%,
limber 1 1%, coffee
partners; US, EC, Netherlands
Imports: $394 million (c.i.f., 1 989 est.)
commodities; rice, mineral fuels, chemicals,
machinery, transportation equipment, other
foodstuffs
partners; US, EC, Japan, China, Netherlands,
ECOWAS
External debt: $2,1 billion (September 1993
est,)
Industrial production: NA (1993-94); much
industrial damage cau.sed by factional warfare
Electricity:
capacity; 410,(X)0 kW
production; 750 million kWh
consumption per capita; 275 kWh (1991)
Industries: rubber processing, food
processing, construction materials, furniture,
palm oil processing, mining (iron ore,
diamonds)
Agriculture: accounts for about 40% of GDP
(including fishing and forestry); principal
products — rubber, timber, coffee, cocoa, rice,
cassava, palm oil, sugarcane, bananas, sheep,
goats; not self-sufficient in food, imports 25%
of rice consumption
Illicit drugs: increasingly a transshipment
point for heroin and cocaine
Economic aid:
recipient; US commitments, including Ex-lm
(F^ 70-89), $665 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $870 miilion; OPEC
bilateral aid (1979-89), $25 million;
Communist countries (1970-89), $77 million
Currency: 1 Liberian dollar (L$) = 100 cents
Exchange rates: Liberian dollars (L$) per
US$1 — 1.00 (officially fixed rate since 1940);
unofficial parallel exchange rate of
L$7 = US$1, January 1992 (unofficial rate
floats against the US dollar)
Fiscal year: calendar year
Overview; The economic and social
infrastructure is not well developed.
Subsistence agriculture dominates the
economy, generating about one-third of GDP
and employing about two-thirds of the working
population. Manufacturing, which accounts for
roughly 10% of GDP, consists mainly of the
processing of raw materials and of light
manufacturing for the domestic market.
Diamond mining provides an important source
of hard currency. In 1990-9.3. the government,
with the support of the IMF and the World
Rank, has made substantial progress toward
structural reform and better fiscal
management. The government readily met all
IMF/WB targets in December 199.3. The
budget deficit had been dramatically reduced:
the government workforce had been cut by
25%; large amounts of domestic debt had been
retired; arrears to the IMF. World Bank, and
other creditors had been reduced. On the
negative :''<ide. continued incursions by the
Liberian rebels, bandits, and anny deserters in
southern and eastern Sierra Leone have
severely strained the economy and threaten
economically critical regions of the country.
National product: GDP — purchasing power
equivalent — $4.5 billion (FY93 est.)
National product real growth rate: NA
National product per capita; $1,000 (1993
est.)
Inflation rate (consumer prices); 35%
(1992)
Unemployment rate: NA%
Budget:
revenues: $68 million
expenditures: $118 million, including capital
expenditures of $28 million (1992 est.)
Exports: $149 million (f.o.b., FY92)
commodities; rutile 51%, bauxite 19%,
diamonds 15%, coffee 5%
partners: US. UK, Belgium, Germany, other
Western Europe
Imports: $131 million (c.i.f., FY92)
commodities: foodstuffs 33%, machinery and
equipment 19%, fuels 16%
partners; US, EC countries, japan, China.','43613c1cdc102d387f2bde98f3198e58345728e9c2cb14e21d065d745a2063cd','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcde97780b0fea2e0fa138d5b1405ac85227d54b17ac1fcd20a891353a8ec848',1994,'LY','Libya','economy',591,'Overview: The socialist-oriented economy
depends primarily upon revenues from the oil
sector, which contributes practically all export
earnings and about one-third of GDP. In 1990
per capita GDP was the highest in Africa at
$5.4 1 0, but GDP growth rates have slowed and
fluctuate sharply in response to changes in the
world oil market. Import restrictions and
inefficient resource allocations have led to
shortages of basic goods and foexistuffs.
Windfall revenues from the hike in world oil
prices in late 1990 improved the foreign
Libya (continued)
payments position and resulted in a current
account surplus through 1992. The nonoil
manufacturing and construction sectors, which
account for alx at 20% of GDP, nave expanded
from processing mostly agricultural products
to include petrochemicals, iron, steel, and
aluminum. Although agriculture accounts for
only 5% of GDP, it employs about 20% of the
labor force. Climatic conditioiis and poor soils
severely limit farm output, and Libya imports
about 75% of its food requirements. The UN
sanctions imposed in April 1992 have not yet
had a mtjor impact on the economy because
Libya’s oil revenues generate sufTicient foreign
exchange that, along with Libya''s large
currency reserves, sustain food and consumer
goods imports as well as equipment for the oil
industry and ongoing development projects.
National product: GDP— purchasing power
equivalent — $.t2 billion (1993 est.)
National product real growth rate: I %
(1993 est.)
National product per capita: $6,600 ( 1 993
est.)
Inflation rate (consumer prices): 6% (1993
est.)
Unemployment rate: NA%
Budget:
revenues: $8.1 billion
expenditures: $9.8 billion, including capital
expenditures of $3. 1 billion ( 1989 est.)
Exports: $7.7 billion (f.o.b., 1993 est.)
commodities: crude oil. refined petroleum
products, natural gas
pertners: Italy, Germany, Spain, France, UK,
Turkey. Greece, Egypt
ImpOkis: $8.26 billion (f.o.b., 1993 est.)
commodities: machinery, transport equipment,
food, manufactured goods
partners: Italy, Germany, UK, France, Spain,
Turkey, Tunisia, Eastern Europe
ExterRid debt: $3.5 billion excluding
military debt (1991 est.)
Industrial production; growth rate 10.5%
(1990)
Electricity:
capflcirv.- 4,935,000 kW
p^uction: 14.385 billion kWh
consumption per capita: 2,952 kWh (1992)
industries: petroleum, food processing,
textiles, handicrafts, cement
Agriculture; 5 % of GNP; cash crops — wheat,
barley, olives, dates, citrus fruits, peanuts: 75%
of fo^ is imported
Economic aid:
recipient: Western (non-US) countries, ODA
and (X)F bilateral commitments ( 1970-87),
$242 million
note: no longer a recipient
Currency; 1 Libyan dinar (LD) = 1,000
dirhams
Exchange rates: Libyan dinars (LD) per
US$1— 0.3233 (January 1994), 0.3250 (1993).
0..3013 (1992), 0.2684 (1991), 0.2699 (1990).
0.2922(1989)
Fiscal year: calendar year
Overview: Tunisia has a diverse economy,
with important agricultural, mining, energy,
tourism and manufacturing sectors. The
economy grew rapidly in the mid-l98()s, GDP
growth averaging 5.4% in 198.3-85. Following
a foreign exchange crisis caused by a sharp
drop in agricultural output and tourism,
combined with the oil price collapse in 1986.
Tunisia inaugurated an IMF-sponsored
economic rehabilitation scheme. Subsequent
government structural reforms have helped
liberalize and open the economy, and GDP
growth has been positive since the start of the
program. A sharp rebound in tourism from the
downturn caused by the Gulf war and strong
agricultural performance boosted real GDP
growth to more than 8% in 1992; growth fell
back to 2.6% in 1 993. Further privatization and
further improvements in government
administrative efficiency are among the
challenges for the future.
National product: GDP — purchasing power
equivalent — $34.3 billion (1993 est.)
National product real growth rate: 2.6%
(1993 est.)
National product per capita: $4.(XX) (1993
est.)
Inflation rate (consumer prices): 4.5%
(1993e.st.)
U nemploy ment rate: 1 6.2% ( 1 993 est . )
Budget:
revenues: $4.3 billion
expenditures: $5.5 billion, including capital
expenditures to $NA (1993 est.)
Exports: $4. 1 billion (f.o.b.. 1993)
eommodities: hydrocarbons, agricultural
products, phosphates and chemicals
partners: EC countries 75%, Middle East 1 0% ,
Algeria 2%. India 2%. US 1%
Imports: $6.4 billion (c.i.f., 1993)
commodities: industrial goods and equipment
57%. hydrocarbons 1 3%, food 1 2%. consumer
goods
partners: EC countries 70%. US 5%. Middle
East 2%. Japan 2%. Switzerland 1%, Algeria
1%
External debt: $7.7 billion ( 1993 est.)
Industrial production: growth rate 5%
(1989); accounts for about 25% of GDP,
including petroleum
Electricity:
capacity: 1.545,000 kW
production: 5,096 kWh
consumption per capita: 6(X) kWh ( 1 992)
Industries; petroleum, mining (particularly
phosphate and iron ore), tourism, textiles.
itKJtwear, fotxl. beverages
.Agriculture: accounts for 16% of GDP and
one-third of labor force; output subject to
severe fluctuations because of frequent
droughts; export crops — olives, dates, oranges,
almonds; other products — grain, sugar beets,
wine grapes, poultry, beef, dairy; not self-
sufficient in ftxrd
Economic aid:
recipient: US commitments, including Ex-lm
(FY70-89). $730 million; Western (non-US)
countries. ODA and OOF bilateral
commitments ( 1970-89) $52 million; OPEC
bilateral aid (1979-89), $684 million;
Communist countries (1970-89). $410 million
Currency: I Tunisian dinar (TD)= 1,000
millimes
Exchange rates; Tunisian dinars (TD) per
US$1 — 1.05 14 (January 1994). 1.(X)37(I993).
0.8844 ( 1 992), 0.9246 (1991), 0.8783 ( 1 990).
0.9493(1989)
Fiscal year: calendar year
Overview: In early 1994, after an impressive
economic performance through most of the
1980s, Turkey faces its most damaging
economic crisis in the last 15 years. Sparked by
the downgrading in mid-January of Turkey''s
international credit rating by two US credit
rating agencies, the crisis stems from two years
of loose fiscal and monetary policies that have
exacerbated inflation and allowed the public
debt, money supply, and current account
deficit to explode. Under Prime Minister
CILLER, Ankara has followed seriously
flawed policies that have destroyed public
confidence in the government''s ability to
manage the economy. Inflation is now running
at an annual rate of 107% and the public sector
deficit is equivalent to 16% of GDP. Turkish
firms have been hurt by high interest rates and
a dramatic drop in consumer demand. Three
Turkish banks have folded and the stock
market has fallen 48% since the beginning of
the year. Economic growth may drop to
between 0% and 2% in 1994, compared to
7.3% in 1993. Moreover, the government is
facing a severe cash crunch. In March 1 994, the
treasury came close to defaulting on a loan, and
official foreign currency reserves are equal to
less than two months'' worth of imports. The
unprecedented effort by the Kurdistan
Workers’ Party (PKK) to raise the economic
costs of its insurgency against the Turkish state
is adding to Turkey’s economic problems.
Attacks against the tourism industry have cut
tourist revenues, which account for about 3%
of GDP, while economic activity in
southeastern Turkey, where most of the
violence occurs, has dropped considerably. To
cope with the economic crisis and instill
domestic and international investor confidence
in the fragile coalition government, CILLER
has asked the IMF to endorse a stabilization
package she introduced in early April 1994.
Negotiations are underway for a standby
agreement, which would give Turkey access to
$450 million this year and enable her cash-
starved government to return to the foreign
capital markets.
National product: GDP — purchasing power
equivalent — $3 1 2.4 billion ( 1 993)
National product real growth rate; 7.3%
(1993)
National product per capita: $5, 1 00 ( 1 993)
Inflation rate (consumer prices): 65%
(1993)
Unemployment rate: 1 2.2% ( 1 993)
Budget:
revenues: $36.5 billion
expenditures: $47.6 billion, including capital
expenditures of $5 billion (1994)
Exports: $14.9 billion (f.o.b., 1992)
commodities: manufactured products 72%,
foodstuffs 23%, mining products 4%
partners: EC countries 53%, US 6%, Russia
4%. Saudi Arabia 3%
Imports: $22.9 billion (c.i.f., 1992)
commodities: manufactured products 68%,
fuels 17%, foodstuffs 4%
partners: EC countries 44%. US 11%. Saudi
Arabia 7%, Russia 5%
External debt: $59.4 billion ( 1 993)
Industrial production: growth rate 4.3%
(1992); accounts for 28% of GDP
Electricity:
capacity: l4.4()0,0(K)kW
production: 44 billion kWh
consumption per capita: 750 kWh (1991)
Industries: textiles, fond processing, mining
(coal, chromite, copper, boron minerals), steel,
petroleum, construction, lumber, paper
Agriculture: accounts for 16% of GDP and
employs about half of working force;
products — tobacco, cotton, grain, olives, sugar
beets, pulses, citrus fruit, variety of animal
products; self-sufficient in food most years
Illicit drugs: major transit route for
Southwest Asian heroin and hashish to
Western Europe and the US via air, land, and
sea routes; major Turkish. Iranian, and other
international trafficking organizations operate
out of Istanbul; laboratories to convert
imported morphine base into heroin are in
remote regions of Turkey as well as near
Istanbul; government maintains strict controls
over areas of legal opium poppy cultivation
and output of poppy straw concentrate
Economic aid:
recipient: US commitments, including Ex-Im
(FY70-89), $2.3 billion; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $10.1 billion; OPEC
bilateral aid (1979-89), $665 million;
Communist countries (1970-89), $4.5 billion
note: aid for Persian Gulf war efforts from
coalition allies ( 1 99 1 ), $4. 1 billion; aid
pledged forTurkish Defense Fund, $2.5 billion
Currency: I Turkish lira (TL) = 100 kurus
Exchange rates; Turkish liras (TL) per
US$1— 15,196.1 (January 1994), 10,983.3
( 1 993), 6,872.4 ( 1 992), 4. 1 7 1 .8 ( 1 99 1 ),
2,608.6(1990), 2,121.7(1989)
Fiscal year: calendar year','094089db93b4ae9c3838e77e9a07b284a8271b83442e30b54caec094c0df569f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e715810253965fcc6da37276c1d15ef35b58395e27d0f34291d7e7104c36b701',1994,'LI','Liechtenstein','economy',597,'Overview: The prosperous economy is based
primarily on small-scale light industry und
tourism. Industry accounts for 53% of total
employment, the service sector 45%’ (mostly
based on tourism), and agriculture and forestry
2%. The sale of postage stamps to collectors is
estimated at $10 million annually. Low
business taxes (the maximum tax rate is 20% )
and easy incorporation rules have induced
about 25.(XX) holding or so-called letter box
companies to establish nominal offices in
Liechtenstein. Such companies, incorporated
solely for tux purposes, provide 30% of state
revenues. The economy is tied closely to
Switzerland''s economy in a customs union,
und incomes and living standards parallel those
of the more prospertnis Swiss groups.
National product: GDP— purchasing power
equivalent — $630 million (1990 est, )
National product real growth rate: NA%
National product per capita: $22,.5(X) ( 1 990
e.st.)
Inflation rale (consumer prices): 5.4%
(1990)
Unemployment rate; 1 .5% ( 1 990)
Budget:
revenues; $2.59 million
exiwntlitures; $292 million, including capital
expenditures of SNA 1 19*)() csi.)
Exports: $N.5
vommtHlities; small specialty machinery,
dental products, stamps, hanlwarc, pottery
IHirtners; EFTA countries 20,9% (Switzerland
15.4%). EC countries 42.7% . other .36.4%
(1990)
Imports: SNA
commodities; machinery, metal gtxxls,
textiles, lixHlsiutTs, motor vehicles
IHirtners; N,\\
External debt: SNA
Industrial production: growth rate NA%
Electricity:
capacity; 23,(XX) kW
prtxluction; 150 million kWh
consumption per capita; 5,2.30 kWh ( 1992)
Industries: electronics, metal manufacturing,
textiles, ceramics, pharmaceuticals, I''ihhI
prtxJucts, precision instruments, tourism
Agriculture: livestock, vegetables, com.
wheat, potatws, grapes
Economic aid: none
Currency: 1 Swiss franc, franken, or franco
(SwF) = I (X) centimes, rappen, or centesimi
Exchange rates: Swiss francs, franken. or
franchi (SwF) per US$1 — 1.4715 (January
1994). 1.4776(199.3), 1,4062(1992). 1.4,340
( 1 99 1 ), 1 ,3892 ( 1 990), 1 .6359 ( 1 989)
Fiscal year: calendar year','c7907a2d5567f98d18b5c729b1bf8ce11d764f5aab2ff86b7cd0351da706fd4f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b60e1b0a0cc692375501f7abcc88c623f1d0f1ca2068913484757257ba907a1',1994,'LT','Lithuania','economy',603,'Overview: Since independence in September
1991, Lithuania has made steady progress in
developing a market economy. Over 40% of
slate property has been privatized and trade is
diversifying with a gradual shift away from the
former Soviet Union to Western markets.
Nevertheless, the process has been painful with
industrial output in 1 993 less than half the 199 1
level. Inflation, while lower than in most ex-
Soviet states, has exceeded rates in the other
Baltic states. Full monetary stability and
economic recovery are likely to be impeded by
periodic government backtracking on key
elements of its reform and stabilization
program as it .seeks to ea.se the economic pain
of restructuring. Recovery will build on
Lithuanian''s strategic location with its ice-free
port at Klaipeda and its rail and highway hub in
Vilnius connecting it with Eastern Europe,
Belarus, Russia, and Ukraine, and on its
agriculture potential, highly skilled laborforce,
and diversified industrial sector. Lacking
important natural resources, it will remain
dependent on imports of fuels and raw
materials.
National product: GDP — purchasing power
equivalent — $12.4 billion (1993 estimate from
the UN International Comparison Program, as
extended to 1991 and published in the World
Bank’s World Development Report 1993; and
as extrapolated to 1993 using official
Lithuanian statistics, which are very uncertain
because of maior economic changes since
1990)
National product real growth rate: -10%
(1993 est.)
National product per capita: $3,240 (1993
est.)
Inflation rate (consumer prices): 188%
11993)
Unemployment rale: 1.8% (July 1993)
Budget:
revenues: $2.38.5 million
expenditures: $270.2 million, including capital
expenditures of $NA (1992 est.)
Exports: $NA
commodities: electronics 1 8%, petroleum
products 5%, food 10%, chemicals 6% ( 1989)
partners: Russia 40%, Ukraine 16%. other
FSU countries 32%, West 12%
Imports: $NA
commodities: oil 24%, machinery 14%,
chemicals 8%, grain NA% ( 1989)
partners: Russia 62%, Belarus 18%, other
FSU countries 10%, West 10%
External debt: $NA
Industrial production: growth rate -52%
(1992)
Electricity:
capacity: 5,925,000 kW
production: 25 billion kWh
consumption pet capita: 6,600 kWh (1992)
Industries: employs 42% of the labor force;
accou.its for 23% of GOP shares in the total
prodiiCtion of the former USSR are: metal¬
cutting machine tools 6.6%; electric motors
4.6%; television sets 6.2%; refrigerators and
frt.ezers 5.4%; other branches: petroleum
refining, shipbuilding (.small ships), furniture
making, textiles, food proce-ssing, fertilizers,
agricultural machinery, optical equipment,
elc. tronic components, computers, and amber
Agriculture: employs around 1 8% of labor
force; accounts for 25% of GDP; sugar, grain,
potatoes, sugar beets, vegetables, meat, milk,
dairy products, eggs, fish; most developed are
the livestock and dairy branches, which depend
on imported grain; net exporter of meat, milk,
and eggs
Illicit drugs: transshipment point for illicit
drugs from Central and Southwest Asia and
Latin America to Western Europe; limited
producer of illicit opium; mostly for domestic
consumption
Economic aid;
recipient: US commitments, including Ex-lm
(1992), $10 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-86), SNA million;
Communist countries 1 1 97 1-86), SNA million
Currency: introduced the convertible litas in
June 1993
Exchange rates: litai per US$ I — 4 (fixed rale
1 May 1 994); 3.9 (late January 1994)
Fiscal year; calendar year','afa58ae81846ce2002c84b69d5626d8847309c315bcc643c39f61575e97b947f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f17a902904f1c634a7eb5b3ffa94595aabca1d877e96cf1e4d1ed7488767e74',1994,'ZW','Zimbabwe','economy',614,'External debt: $1.8 billion (December 1991
est.)
Industrial production: growth rate 3.3%
(1992 est.); accounts for about 15% of GDP
(1992 est.)
Electricity:
capacity: 190,(X)0kW
production: 620 million kWh
consumption per capita: 65 kWh (1992)
Industries: agricultural processing (tea,
tobacco, sugar), sawmilling, cement, consumer
goods
Agriculture: accounts for 40% of GDP; cash
crops — tobacco, sugarcane, cotton, tea. and
corn; subsistence crops — potatoes, cassava,
sorghum, pulses; livestock — cattle, goats
Economic aid:
recipient: US commitments, including Ex-Im
(FY70-89), $215 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $2. 15 billion
Currency: 1 Malawian kwacha (MK) = 100
tambala
Exchange rates: Malawian kwacha ( M K ) per
US$l-^.4598 (November 1993), 3.60.33
(1992), 2.8033 (1991), 2.7289 (1990). 2.7595
(1989)
Fiscal year: 1 April — 31 March
Overview: The economy has been in decline
for more than a decade with falling imports and
growing foreign debt. Economic difficulties
stem from a chronically depressed level of
copper production and ineffective economic
policies. In 1991 real GDP fell by 2% and in
1992 by 3% more. An annual population
growth of 3% has brought a decline in per
capita GDP of 30% over the past decade. A
high inflation rate has also added to Zambia''s
economic woes in recent years.
National i,''roduct: GDP — purchasing power
equivalent — $7.3 billion (1993 est.)
National product real growth rale: -2.8%
(1992)
National product per capita: $800 (1993
est.)
Inflation rate (consumer prkca): 191%
(1992)
Unemployment rate: NA%
Budget:
revenues: $665 million
expenditures: $767 million, including capital
expenditures of $300 million (1991 est.)
Exports: $1 billion (f.o.b., 1992 est.)
commodities: copper, rinc, cobalt, lead,
tobacco
partners: EC countries. Japan, South Africa,
US, India
Imports: $1.2 billion (c.i.f., 1992 est.)
commrdities: machinery, transportation
equipment, foodstuffs, fuels, manufactures
partners. EC countries, Japan, Saudi Arabia,
South Africa, US
External debt; $7.6 billion ( 1991 )
Industrial production: growth rate -2%
(1991); accounts for 40% of GDP
Electricity:
capacity: 2.775,000 kW
pt^uction: 12 billion kWh
consumption per capita: 1 ,400 kWh ( 1 99 1 )
Industries; copper mining and processing,
construction, fo^stuffs, beverages, chemicals,
textiles, and fertilizer
Agriculture: accounts for 1 2% of GDP and
85% of labor force: crops — com (food staple),
sorghum, rice, peanuts, sunflower, tobacco,
cotton, sugarcane, cassava; cattle, goats, beef,
eggs
Illicit drugs: role as regional transshipment
center for mandrax and heroin
Economic aid:
recipient: US commitments, including Ex-Im
( 1970-89), $4.8 billion; Western (non-US)
countries. ODA and OOF bilateral
commitments (1970-89). $4,8 billion; OPEC
bilateral aid (1979-89), $60 million:
Communist countries ( 1970-89), $533 million
Currency: I Zambian kwacha (ZK) = 100
ngwee
Exchange rates; Zambian kwacha (ZK) per
US$1— 344.8276 (October 1993). 156.25
(1992). 61.7284 (1991). 28.9855 (1990).
12.9032(1989)
Fiscal year: calendar year
Overview: Agriculture employs three-fourths
of the labor force and supplies almost 40% of
exports. The manufacturing sector, based on
agriculture and mining, produces a variety of
goods and contributes 35% to GDP. Mining
accounts for only 5% of both GDP and
employment, but supplies of minerals and
metals account for about 40% of exports. Wide
fluctuations in agricultural production over the
past six years have resulted in an uneven
growth rate, one that on average has matched
the 3% annual increase in population. Helped
by an IMF/World Bank structural adjustment
program, output rose 3.5% in 1991 . A severe
drought in 1^1/92 caused the economy to
contract by about 10% in 1992.
National product: GDP — (nirchasing power
equivalent — $15.9 billion (1993 est.)
National product real growth rate: 2%
(1993 est.)
National product per capita: $1,400(1993
est.)
Inflation rate (consumer prices): 22%
(January 1994 est.)
Unemployment rate: at least 35% ( 1 993 est.)
Budget:
revenues: $ 1 .7 billion
expenditures; $2.2 billion, including capital
expenditures of $253 million (FY93)
Exports: $1.5 billion (f.o.b., 1992 est.)
commodities; agricultural 35% (tobacco 30%,
other 10%), manufactures 25%, gold 12%,
ferrochrome 10%, textiles 8% (1992)
partners: UK 14%, Germany 1 1%, South
Africa 10%. Japan 7%. US 5% (1991)
Imports: $ 1.8 billion (c.i.f., 1992 est.)
commodities; machinery and transportation
equipment 41 %, other manufactures 23%,
chemicals 16%, fuels 12% (1991)
partners: South Africa 25%, UK 1 5%,
Germany 9%, US 6%, Japan 5% (1991)
External debt: $3.5 billion (December 1992
est.)
Industrial production: growth rate 2.3%
(1992); accounts for 35% of GDP
Electricity:
capacity: 3,650,000 kW
production: 8.18 billion kWh (1992)
consumption per capita: 740 kWh ( 1992)
Industries: mining, steel, clothing and
footwear, chemicals, foodstuffs, fertilizer,
beverage, transportation equipment, wood
products
Agriculture: accounts for 20% of GDP and
employs 74% of population; 40% of land area
divided into 4,500 large commercial farms and
42% in communal larids: crops — com (food
staple), cotton, tobacco, wheat, coffee,
sugarcane, peanuts; livestock — cattle, sheep,
goats, pigs; self-sufficient in food
Economic aid: NA
Currency: I Zimbabwean dollar (Z$) = 100
cents
Exchange rates; Zimbabwean dollars (Z$)
per US$1— 8.10.37 (January 1994), 6.4725
(1993), 5.1046 (1992). 3.4282 (1991), 2.4480
(1990), 2.1133(1989)
Fiscal year: 1 July— 30 June','e34fc73a2c5b203b00a29b868b3576f27913a43f71d970b52c3fa0642bcc1d77','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1f1a2a6ce74d46e8993da9342ef64208a8c5ad7c3871ba9fbfdd095d6af4612',1994,'MX','Mexico','economy',622,'Overview: The Malaysian economy, a
mixture of private enterprise and a soundly
managed public sector, has posted a
remarkable record of 8%-9% average growth
in 1987-93. This growth has resulted in a
substantial reduction in poverty and a marked
rise in real wages. Despite sluggish growth in
the major world economies in 1992-93,
demand for Malaysian gixids remained strong,
and foreign investors continued to commit
large sums in the economy. The government is
Malaysia (continued)
aware of the inflationary potential of this rapid
development and is closely monitoring fiscal
and monetary policies.
National pr^uct: GDP — purchasing power
equivalent — $141 billion (1993 est.)
National product real growth rate: 8%
(1993 est.)
National product per capita: $7,500 ( 1 993
est.)
Inflation rate (consumer prices): 3.6%
(1993)
Unemployment rate: 3% (1993)
Budget:
revenues: $19.6 billion
expenditures: $18 billion, including capital
expenditures of $5.4 billion (1994 est.)
Exports: $46.8 billion (f.o.b., 1993 est.)
commodities: electronic equipment, petroleum
and petroleum products, palm oil, wood and
wood products, rubber, textiles
partners: Singapore 23%, US 15%, Japan
1 3%, UK 4%, Germany 4%, Thailand 4%
(1991)
Imports: $40.4 billion (f.o.b., 1993 est.)
commodities: machinery and equipment,
chemicals, food, petroleum products
partners: Japan 26%, Singapore 21%, US
16%, Taiwan 6%, Germany 4%, UK 3%,
Australia 3% (1991)
External debt: $ 1 ^4 billion ( 1 993 est.)
Industrial production: growth rate 13%
(1992): accounts for 43% of GDP
Electricity:
capacity: 8.(XX).000 kW
production; 30 billion kWh
consumption per capita; 1,610 kWh (1992)
Industries;
Peninsular Malaysia; rubber and oil palm
processing and manufacturing, light
manufacturing industry, electronics, tin mining
and smelling, logging and processing timber
Sabah; logging, petroleum production
Sarawak: agriculture processing, petroleum
production and refining, logging
Agriculture; accounts for 17% of GDP
Peninsular Malaysia: natural rubber, palm oil,
rice
Sabah; mainly subsistence, but also rubber,
timber, coconut, rice
Sarawak: rubber, timber, pepper; deficit of rice
in all areas
Illicit drugs: transit point for Golden Triangle
heroin going to the US, Western Europe, and
the Third World despite severe penalties for
drug trafficking
Economic aid:
recipient; US commitments, including Ex-lm
(FY70-84), $170 million: Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $4.7 million: OPEC
bilateral aid (1979-89), $42 million
Currency; 1 ringgit (M$) = 100 sen
Exchange rates: ringgits (M$) per US$1 —
2.7 123 (January 1994), 2.5741 (1993), 2.5474
( 1992). 2.7501 (1991), 1.7048 (1990), 2.7088
(1989)
Fiscal year: calendar year
Fiscal year: calendar year
Overview: Mexico''s economy, made up
predominantly of private manufacturing and
services and both large-scale and traditional
agriculture, is beginning to rebound from the
economic difficulties of the 1980s but still
faces key challenges. During the 1980s, the
accumulation of large external debts, falling
world petroleum prices, rapid population
growth, and mounting inflation and
unemployment plagued the economy. In recent
years, the government has responded by
implementing .sweeping economic reforms.
Strict fiscal and monetary discipline have
brought inflation under control, reduced the
internal debt, and produced budgetary
surpluses in 1992 and 1993. The tight money
policies, however, have restricted growth:
barely 0.4% in 1993 after a rise of 2.6% in 1992
and 3.6% in 1 99 1 . Another aspect of the reform
has been the privatization of more than 80% of
Mexico''s businesses, including all of the
commercial banks. Seeking out increased trade
and investment opportunities, the government
negotiated the North American Free Trade
Agreement (NAFTA) with the United Stales
and Canada, which entered into force on I
January 1994. Within Latin America. Mexico
has completed bilateral free trade agreements
with Chile and Costa Rica, and is continuing
negotiations with Colombia and Venezuela for
a trilateral deal in addition to hoiding trade
discussions with various other nations. In
January of 1993, Mexico replaced its old peiio
at the rate of I .(XX) old to I new peso. Despite
its hard-won economic progress and the
prospects of long-term gains under NAFTA,
Mexico .still faces difficult problems, including
sluggish growth, unemployment, continuing
social inequalities, serious pollution, and the
prospect of increa.sed competition with the
opening of trade.
National product: GDP— purchasing power
equivalent — $740 billion (1993 esl.)
National product real growth rate: 0.4%
(1993)
National product per capita: $8,2(X) ( 1 993
est.)
Inflation rate (consumer prices): 8% (1993
e.st.)
Unemployment rate: 10.7% ( 1992 esl.)
Budget:
revenues: $58.1 billion
expenditures; $53 billion, including capital
expenditures of $3.4 billion (1992 est.)
Exports: $50.5 billion (f.o.b., 1993 est.),
includes in-bond industries
commodities; crude oil, oil products, coffee,
silver, engines, motor vehicles, cotton,
consumer electronics
partners; US 74%, Japan 8%, EC 4% (1992
e.st.)
Imports: $65.5 billion (f.o.b.. 199.3 est.).
includes in-bond industries
commodities: metal-working machines, steel
mill products, agricultural machinery,
electrical equipment, cur parts for assembly,
repair parts for motor vehicles, aircraft, and
aircraft parts
partners: US 74%-, Japan. 1 1 %, EC 6% ( 1 992)
261
Mexico (continued)
Overview: Norway has a mixed economy
involving a combination of free market activity
and government intervention. The government
controls key areas, such as the vital petroleum
sector (through large-scale state enterprises)
and extensively subsidizes agriculture, fishing,
and areas with sparse resources. Norway also
maintains an extensive welfare sy.stem that
helps propel public se. ir expenditures to
slightly more than 50% of the GDP and results
in one of the highest average lax burdens in the
world (54%). A small country with a high
dependence on international trade, Norway is
basically an exporter of raw materials and
semiprocessed gcxxls, with an abundance of
small- and medium-sized firms, and is ranked
among the major shipping nations. The country
is richly endowed with natural resources —
petroleum, hydropower, ftsh, forests, and
minerals — and is highly dependent on its oil
sector to keep its economy afloat. Although
one of the government''s main priorities is to
reduce this dependency, this situation is not
likely to improve for years to come. The
government also hopes to reduce
297
Norway (cimiinuetl)
iinoniploymeni ami siren^ihen and diversity
Ihc economy through las reform and a series of
expansionary hudgets. The budget deficit is
expected to hit a record K''* of CillP because of
welfare spending and bail-iwis of the banking
system. Unemployment continues at record
levels of over l(l'';( — including those in job
pnrgrams — because of ihc weakness of the
economy outside the oil sector. Economic
growth was only l.b''^ in IW.f. while inllaiion
was a moderate 2.. Iff . Oslo, a iiK''iither of the
European Tree Trade Area, has applied for
membership in the European Union and
continues to deregulate and hannoni/c with
EU regulations. Membership is expected in
early W.S.
NnllonnI prodMct: OliP — purchasing piswei
equivalent —$tl9..S billion ( I W)
National prnducl real Rrowlh rale: I .t''H
(IW)
National produel per capita: $20.K(N)
(199.^)
inflation rale (consumer prices!: 2..t'';i
(IWesl.)
Unemployment rale: .‘''..''''T (excluding
people in job-training programs) (199.1 esi.)
Budgrt:
revenues: $4.^.,t billion
e.xpeiuhiures: S.^I.K billion, including capital
expenditures of SN A ( I ‘W.f )
Exports: $.12.1 billion (f.o.b., I99,t)
eomimHiliies: peiroleutn and petroleum
pnxJucts 4()''.i( . metals and products l().6'';< . fish
and fish prrxlucts 6.9'':} . chemicals 6.-lCi .
natural gas 6.0''T , ships S.4‘4
IHirmers; EC b6..V^. Nordic countries l6.,V;i,
developing ctruntries t(.47r. US 6.09f. Japan
l.8''’4 (199.1)
ImpoiTs; $24.8 billion (c.i.f.. 199.1)
eonmuHlilies: machinery and equipment
.18.9‘T, chemicals and other industrial inputs
26.6''5!, manufactured consumer grHtds I7.8''4 .
fixxlstulTs 6.4''/!
ixiriners: EC 48.6‘T, Nordic countries 2.1. 1 fl .
developing countries 9.6''T, US 8. 1 ''1 . Japan
8.0''''/! (199.1)
External debt; $6..i billion ( 1992 est.)
Industrial production: grow th rale 6.2''/!
(1992); accounts for M''!! of GDP
Electricity:
eapaeily: 26.900.(XK) kW
pnuliH iidu: 1 1 1 billion kWh
ennsumpliim per eapiui: 2.1,8.10 kWh ( 1992)
industries: petroleum and gas. fixxl
prtK''essing. shipbuilding, pulp and paper
pnxJucts, metals, chemicals, timber, mining,
textiles, fishing
Agriculture: accounts for ,1<!! of GDP and
about 6*3! of labor force: among world''s top 10
fishing nations: livcsitK''k output exceeds value
of crops: over half of frxxl needs imported: fish
catch of 1,76 million metric tons in 1989
Illicit drugs: transshipment point for dmgs
.shipped via the CIS and Baltic stales for the
European market
Exmwfflic aid:
lionor: ODA and OOE commitments ( 1970-
89), $4.4 billion
Currency: I Norwegian kmne (NKri = l(N)
«x''re
E!xchange rates: Niawegian knmcriNKri
per US$1 -7 4840 (January 1994), 7.0941
( 1991). 6.2 14S ( 1992). 6.4829 1 1991 ). 6.2.197
( 1990), 6.904.1 ( 1989)
fiscal year: calendar year
Commuaicatlims
Railroads: 4.221 km 1 .4.11-me(er standard
gauge: Norwegian Slate Railways ( NSB )
operates 4.2 1 9 km 1 2.4.10 km electrified and 96
km double track): 4 km mher
HIgliways:
lohit: 88,8(8) km
IHived: 18.180 km
unpstved: gravel, crushed stone, earth .10.220
km
Inland waterways: I..S77 km along west
ctiasi: 2 4 m draft vessels ntaximum
Pipelines: refined pnxiucts .11 km
Ports: Oslo. Bergen. Fredrikstad.
Krisliunsand, .Stavanger, Trondheim
Merchant nurine: 764 ships ( I .(88) CRT or
over) totiiling 20,791.968 GRT/11.409.47 2
DWT. passenger II. shttrt-sca pati.senger 2 1 .
cargo 92. passenger-cargo 2. refrigerated cargo
II, container 17, roll-on/roll-off cargo ,14,
vehicle carrier 28. railcar ■.•airier I, oil tanker
1 62. chemical (anker 81. liquefied gas 8 1 .
combination ore/oil 28, bulk 119. combination
bulk 8
note: the government has created a captive
register, the Norwegian Iniernationul Ship
Register (NIS). as a subset of the Norwegian
register; ships on the NIS enjoy many beneftts
of Hags of convenience and do not have to be
crewed by Norwegians; the iiuytirity of ships
(761 ) under the Nonvegian Hag are ni>w
registered with the NIS
Airports:
mud: 101
iistihle: 102
H''iih permmienl sutidee ruinvtiys: 61
with riimviiys over .i.d.lv ni: 0
ividi rnniedv.v 2,4-/()-.t.6.59ni.- I1
ti''/rJi riimviiys I.220-2.4JV m: II
Telecommunications; high-quality domestic
and international telephone, telegraph, and
telex services: 2 buried coaxial cable systems:
1,102.(8)0 telephones; broadcast stations — 46
AM. 110 private and 141 government FM, 14
(2. 1(8) repealers) TV; 4 ctxixial .submarine
cables: 1 communications satellite earth
stations operating in the EUTEI.SAT.
INTELSAT ( I Atlantic Ocean), MARISAT.
and domestic systems
Defense forces
Brunches: Norwegian Army. Royal
Norwegian Navy. Royal Nmwegian Air Ftxvc,
Home Guard
Manpower uvailnhiiRy; mules age II 49
l.l 19.401; 111 for military service 912,4.18;
reach military age (20) annually .10,117 ( 1994
cst.)
Dcihnw expendllnrex: exchange rate
conversion — $1.8 billion, 1.4''/( of GDP( 1992)
Overview: Poland is continuing the difficult
transition to a market economy that began on
1 January 1990, when the new democratic
government instituted "shock therapy" by
decontrolling prices, slashing subsidies, and
drastically reducing import barriere. The
economy contracted sharply in 1 990 and 1991,
but in 1992 real GDP grew I % despite a severe
drought. Real GDP expanded about 4% in
1993, the highest raie in Europe except for
Albania. About half of GDP now comes from
the private sector even though privatization of
the large state-owned enterprises is proceeding
slowly and most industry remains in state
hands. The pattern of industrial production is
changing rapidly; output of textiles and
construction materials is well above 1990
levels, while output of basic metals remains
depressed. Inflation, which had exceeded 50%
monthly in late 1989, was down to about 37%
for all of 1993, as the government held the
budget deficit below 3% of GDP.
Unemployment has risen steadily, however, to
about 16%. The trade deficit is also a problem,
in part due to recession in Western Europe,
Poland’s main customer. The new government
elected in September 1993 is politically to the
left of its predecessor but is continuing the
reform process.
National product: GDP — purchasing power
equivalent — $180.4 billion (1993 est.)
National product real growth rate: 4. 1 %
(1993 est.)
National product per capita: $4,680 (1993
est.)
Inflation rate (consumer prices): 37%
(1993)
Unemployment rate: 15.7% (December
1993)
Budget:
revenues; $24.3 billion
expenditures: $27. i billion, including capital
expenditures of $ 1 .5 billion ( 1 993 est.)
Exports: $13.5 billion (f.o.b., 1993 est.)
''mmodities; machinery 24%, metals 17%,
chemicals 12%, fuels and power 1 1%, food
10% (1992)
partners; Germany 3 1 .4%, Netherlands 6.0%,
Italy 5.6%, Russia 5.5% (1992)
Imports: $15.6 billion (f.o.b., 1993 est.)
commodities: fuels and power 17%, machinery
36%. chemicals 17%. food 8% (1992)
partners: Germany 23.9%, Russia 8.5%, Italy
6.9%, UK 6.7% (1992)
External debt: $47 billion (1993); note —
Poland’s Western government creditors
promised in 1991 to forgive 30% of Warsaw’s
$35 billion official debt immediately and to
forgive another 20% in 1994; foreign banks
agreed in early 1994 to forgive 45% of their
$12 billion debt claim
Industrial production: growth rate 7%
(1993)
Electricity:
capacity; 31,530,000 kW
production: 137 billion kWh
consumption per capita; 3,570 kWh (1992)
Industries: machine building, iron and steel,
319
Overview: Vietnam has made significant
progress in recent years moving away from the
planned economic model toward a more
effective market-based economic system. Most
''"A
P-
426
prices ue now fully decontrolled, and the
Vietneinese currency hu bem efftetively
devalued and floated at world market rates. In
addition, the scope for private sector activity
has been expand^ primarily through
decollecti viuiion of the agricultural sector and
introduction of laws giving legal recognition to
private business. Neidy three^iuatters of
export earnings are generated by only two
comnsodities, rice and crude oil. Led by
industry and construction, the economy did
well in 1993 with output rising perhaps 7%.
However, the industrial sector remains
burdened by uncompetitive statenrwned
enterprises the government is unwilling or
unable to privatiM. Unemployment looms as a
serious problem with roughly 25% of the
workforce without Jobs and with population
growth swelling the ranks of the unemployed
yearly.
National product: ONP— purchasing power
equivalent — $72 billion (1993 est.)
National product real growth rate: 7%
(1993 est.)
National product per capita: $1,0(X)(1993
est.)
Inflation rate (consumer ptkcs): S.2%
(1993 est.)
Unemployment rate: 25% (1993 est.)
BudgM:
revenues.'' $1.9 billion
expenditum: $2 billion, including capital
expenditures of $NA (1992)
Exports: $2.6 billion (f.o,b., 1993 est.)
commodities! petroleum, rice, agricultural
products, marine products, coffee
partners: Japan, Hong Kong, Thailand,
Ciermany, Indonesia
Imports: $3.1 billion (f.o.b., 1993 est.)
commodities: petroleum products, steel
products, railroad equipment, chemicals,
medichics, raw cotton, fertilizer, grain
partners: Hong Kong, Japan, Indonesia, South
Korea, Taiwan
External debt: $3.4 billion Western
countries; $4.5 billion CEMA debts primarily
to Russia; $700 million commercial debts
(1993 est.)
Industrial production: growth rate 15%
(1992); accounts for 20% of GDP
Electricity:
capacity: 3,300,000 kW
production: 9 billion kWh
consumption per capita: 1 30 kWh (1992)
Industries: food processing, textiles, machine
building, mining, cement, chemical fertilizer,
glass, tires, oil
Agriculture: accounts for almost 40% of
GDP; paddy rice, com, potatoes make up 50%
of farm output; commercial crops (rubber,
soybeans, coffee, tea, bananas) and animal
pr^ucts 50%; since ''989 self-sufficient in
food staple rice; fish catch of 943,100 metric
tons (1989 est.)
Illicit drugs: minor opium producer and
secondary transit point for Southeast Asian
Virgin Islands
(territory the US^
heroin destined for the US aitd Europe
Economic uMt
recipient: $1.9 billion in crediu and grants
pledged by international donon for 1994,
Japan largest contributor with $550 million
Currency: 1 new dong (D) ■ 100 xu
Exchnnge rotea: new d^(D) per US$1—
10,800 (November 1993), 8,100 (July 1991),
7,280 (December I990X 3.996 (Match 1990);
note— 1985-89 figures ate end of year
Flacnlycor: calendar year
Communlcatlona
HnWrooda: 3,059 km total; 2,454 l.OOO-meter
gauge, IS I km 1.435-meier (standard) gauge,
UO km dual gauge (three railsX and 224 km
not restored to service after war damage
HIghwaya:
total: 85,000 km
paved: 9,400 km
unpaved: gravel, improved earth 48,7(X) km;
unimproved earth 26,900 km
Inland wntcrwaya: 17,702 km navigable;
more than 5,149 km navigable at all dmes by
vessels up to 1.8 nteter draft
Pipelines: petroleum products ISO km
Pom: DaNang,Haiph(Hig.HoChiMinhCity
Merchant marine: 101 ^ips (1,000 GRT or
over) totaling 460,225 QRT/741,23 1 DWT,
cargo 86, refogerated cargo 3, toll-oo/roll-ofT
cargo I, oil Uuiker 8, bulk 3
Airports:
total: 100
usable; 100
with permanent''SurfiKe rtmways: 50
with runways over 3,659 m: 0
with runways 2,4^3,659 m: 10
with runways 1,220-2,439 m: 20
Tdeconununkathwa: the inadequacies of
the obsolete switching equipment and cable
system is a serious constraint on the business
sector and on economic growth, and restricts
access to the internationsJ links that Viemam
has established with most migot countries; the
telephone system is not generally available for
private use (25 telefdiones for each 10,000
persons); 3 satellite earth suUons; broadcast
stations— NA AM, 288 FM; 36 (77 repeaters)
TV; about 2,500,000 TV receivers and
7,000,000 radio receivers in use (1991)
Defense Forces
Branches:
People ''s Army of Vietnam (PA VN) including:
Ground, Navy (including Naval Infantry), Air
Force
Manpower availability: males age 15-49
1 8,28 1 ,483; fit for military service 1 1 ,602,3 1 8;
reach military age ( 17) annually 762,943 (1994
est.)
Defense expenditures: exchange rate
conversion-^NA, NA% of GNP
Caribbeen Sea
Saint Croi*
Overview: Tourism is the primary economic
activity, accounting for more than 70% of GDP
and 70% of employment. The manufacturing
sector consists of textile, electronics,
pharmaceutical, and watch assembly plants.
The agricultural sector is small, most food
being imported. International business and
financial services are a small but growing
component of the economy. One of the world''s
largest petroleum refineries is at Saint Croix.
National product: GDP — purchasing piower
equivalent — $1.2 billion (1987)
National product real growth rate: NA%
National product per capita: $ 1 1 ,000
(1987)
Inflation rate (consumer prices): NA%
Unemployment rate: 3.7% (1992)
Budget;
revenues: $364.4 million
expenditures: $364.4 million, including capital
expenditures of $NA (1990 est.)
Exports; $2.8 billion (f.o.b., 1990)
commodities: refined petroleum products
partners; US, Puerto Rico
Imports: $3.3 billion (c.i.f., 1990)
commodities: crude oil, foodstuffs, consumer
goods, building materials
partners: US, Puerto Rico
External debt: $NA
Industrial production: growth rate 12%;
accounts for NA% of GDP
Electricity:
capacity; 380,000 kW
production: 565 million kWh
consumption per capita: 5,710 kWh (1992)
Industries: tourism, petroleum refining,
watch assembly, rum distilling, construction,
pharmaceuticals, textiles, electronics
Agriculture: truck gardens, food crops (small
scale), fruit, sorghum, Senepol cattle
Economic aid:
recipient: Western (non-US) countries. ODA
and (X>F bilateral commitments (1970-89).
$42 million
Currency: 1 United States dollar (US$)= 100
cents
Exchange rates; US currency is used
Fiscal year: I October — 30 September','e626b98cd110ffc00d673eff6218a6ec4a493fc6e87bce194d7941acf0e40ee2','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6b2f9eac6cd237c1c58da9accac279379af052962486d58d63963843482f1f5',1994,'MV','Maldives','economy',623,'Communkationa
Railroads:
Peninsular Malaysia: 1,665 km 1.04-meter
gauge; 1 3 km double track, government owned
Sabah; 136 km 1.0(X)-meter gauge
Sarawak: none
Highways:
total; 29,026 km (Peninsular Malaysia 23,600
km, Sabah 3,782 km, Sarawak 1,644 km)
paved: NA (Peninsular Malaysia 19,352 km
mostly bituminous treated)
unpaved; NA (Peninsular Malaysia 4,248 km)
Inland waterways:
Peninsular Malaysia; 3,209 km
Sabah; 1,569 km
Sarawak: 2,518 km
Pipelines: crude oil 1,307 km; natural gas 379
km
Ports: Tanjong Kidurong, Kota Kinabalu,
Kuching, Pasir Gudang, Penang. Port Kelang,
Sandakan, Tawau
Merchant marine: 1 83 ships ( 1 .000 CRT or
over) totaling 1,935.210 GRT/2.913,808
DWT, passenger-cargo 1, short-sea passenger
2, cargo 69, container 26, vehicle carrier 2, roll¬
on/roll-off cargo 2, livestock carrier 1 , oil
tanker 39, chemical tanker 6, liquefied gas 6,
bulk 29
Airports:
total: 113
usable; 104
with permanent-sutface runways; 33
with runways over 3,659 m: I
with runways 2,440-3,659 m: 7
with runways 1 ,220-2,439 m; 18
Teleconununications; good intercity service
provided on Peninsular Malaysia mainly by
microwave radio relay; adequate intercity
microwave radio relay network between Sabah
and Sarawak via Brunei; international service
good; good coverage by radio and television
broadcasts; 994,860 telephones (1984);
broadcast stations — 28 AM, 3 FM, 33 TV;
submarine cables extend to India and Sarawak;
SEACOM submarine cable links to Hong
Kong and Singapore; satellite earth stations — 1
Indian Ocean INTELSAT, 1 Pacific Ocean
INTELSAT, and 2 domestic
Defense Forces
Branches: Malaysian Army. Royal
Malaysian Navy, Royal Malaysian Air Force,
Royal Malaysian Police Force, Marine Police,
Sarawak Border Scouts
Manpower availability: males age 15-49
4.942,387; fit for military service 3,001 ,972:
reach military age (2 1 ) annually 1 82,850 ( 1 994
est.)
Defense expenditures; exchange rate
conversion — $2,4 billion, about 5% of GDP
(1992)
tCBtm ..
■S''-''
- kUkAltll
Arehlen o''
See Hi,
Leeeedire
■ ''I-- .. See
V*‘^''','6195404d7a0b2cd1fd7f55d1dc4e47873cc5c4a0514d96c9c77f90a2508858c8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f8c52bfb67f38dca1f251fe11da26456775120358f3b23f7195ed8445f1bf66',1994,'MT','Malta','economy',630,'Overview: Mali is among the poorest
countries in the world, with about 70''> of its
land area desert or semidesert. Economic
activity is largely confined to the riverine area
irrigated by the Niger. About 10% of the
population live as nomads and some 80% of the
labor force is engaged in agriculture and
fishing. Industrial activity is concentrated on
pnK''essing farm commodiiic.s. In consultation
with international lending agencies, the
governmeni has adopted a structural
adjustment program for 1992-9.3. aiming at
GDP annual growth of 4.6%. inflation of no
more than 2. .3% on average, and a substantial
reduction in the external current account
deficit.
National product: GDP — purchasing power
equivalent — .3,8 billion (199.3 esi.)
National product real growth rate: -6. 1 %
(1992 est.)
National product per capita: $6.3(> (199.3
est.)
Inflation rate (consumer prices); 2% ( 1992
est.)
Unemployment rate: NA<^
Budget:
wwmies: S376 million
l•.\\■penllilures: S697 million, including capital
expenditures of SNA ( 1 992 esi.)
Exports: S,3.30 million (f.o.b., I9*)2cst,)
cnimmx/ifii’.v,- cotton. livesUK''k, gold
partner: mostly franc zone and Western
Europe
Imports: 5682 million (f.o.b,, 1992 est.)
roinmixtiiU''s; machinery and equipment,
fivodstuffs. construction materials, petroleum,
textiles
IMiriners: mostly franc zone and Western
Europe
External debt: $2.6 billion i 1991 est.)
Industrial production: growth rate - 1 .4'';i-
(1992 est.); accounts for 1.3,0% of GDP
Electricity:
viilHwity: 260,(XK) kW
pi-iHluciion: 7.30 million kWh
coii.Mimption p >■ aipiUi: 90 kWh ( 1991 )
Industries: small lo:'':il consumer gmsis and
poKcssing. construction, phosphate, gold,
fishing
Agriculture: accounts for .30% of GDP; most
pnxluction based on small subsistence farms;
cotton and livestock products account for over
TO''/f of exports; other crops — millet, rice. corn,
vegetables, peanuts; livestiK''k — cattle, sheep,
goats
Economic aid:
nripiem: U.S cotnmitments. iticluding Ex-Itu
(PY7()-89), $.349 million; Western (non-U.S)
countries. ODA and OOF bilateral
commitments ( 1970-89). 5.3.02 billion; OPEC
bilateral aid ( 1979-89), $92 million;
Communist countries ( 1970-89). 5190 million
Currency; 1 CFA franc (CFAF) * l(K)
centimes
Exchange rates: Cnmmunautc Financiere
Africaine francs (CFAF) per U.S$I — .392.0.3
(January 1994). 28.3. 16 ( 199.3). 264.69 (1992).
282.11 (1991), 272,26(1990). .319,01 (1989)
note: beginning 12 January 1994, the CFA
franc was devalued to CFAF 100 per French
franc frotii CFAF .30 at which it hud been fixed
since 1948
Fiscal year: calendar year
Communteatlons
Railroads: 642 km I .OOO-meter gauge; linked
to Senegal''s rail system through Kayes
Highways:
toKil; l.3.7(K)km
/xo''ey/.- 1.670 km
uniHivetl; gravel, improved earth .3,670 km:
unimproved earth I0..360km
Inland waterways; 1 .8 1 .3 km navigable
Airports:
torn!: .3.3
Hsahle; 27
with iH''nmmeiit-.mfface ruimaya; 8
with runways over .t,6.3V in; 0
with runways nr .3
with runways 1,220-2.4.^^ in; 1 1
Telecommunications: doiuestic system pimr
but iniprttving; provides only minimal service
w ith radio relay, wire, and radio
communications stations; expansion of radio
reiay in progress; 1 1 .(XH) telephones; broadcast
stations— 2 AM, 2 FM. 2 TV; satellite earth
stations — I Atlantic Ocean INTELSAT and 1
Indian Ocean INTEl.SAT
Defense Forces
Rranche..: Army, Air Force. Gendarmerie.
Republican Guard, National Police (Suretc
Nationale)
Manpower availabiilty: males age 1.3-49
l,80.3,.3()l; fit for military service 1.027.780
Defense expenditures: exchange rate
conversion — S41 million, 2% of GDP ( 1989)
Overview: Significant resources are
limestone, a favorable geographic location, and
a productive labor force. Malta produces only
about 20% of its food needs, has limited
freshwater supplies, and has no domestic
energy sources. Consequently, the economy is
highly dependent on foreign trade and .services.
Manufacturing and tourism are the largest
contributors to the economy. Manufacturing
accounts for about 27% of GDP. with the
electronics and textile industries major
contributors and the state-owned Malta
drydocks which employs about 4,300 people.
In 1 992, about i ,000,(KX) tourists visited the
island. Fer capita GDP at $6,6(M) places Malta
in the middle-income range of the world''s
nations.
National product: GDP— exchange rate
conversion — $2.4 billion (1992 est.)
National product real growth rate; 4.5%
(1992)
National product per capita: $6,600 ( 1 992)
Inflation rate (consumer prices): 1 .64%
(1992)
Unemployment rate: 4% (1992)
Budget;
revenues: $1.2 billion
e.xpenditures: $1.2 billion, including capital
expenditures of $182 million (FY94est.)
Exports: $1.3 billion (fo.b., 1992)
commodities: machinery and transport
equipment, clothing and footware, printed
matter
partners: Italy 30%, Germany 22%, UK 1 1 %
Imports: $1.93 million (f.o.b., 1992)
commodities: food, petroleum, machinery and
semimanufactured goods
partners: Italy 30%, UK 16%, Germany 13%,
US 4%
External debt; $I 18 million (1990)
Industrial production: growth rate 5.4%
(1992); accounts for 27% of GDP
Electricity:
capacity: 328.000 kW
production: 1.11 billion kWh
consumption per capita: 3,000 kWh ( 1 992)
Industries: tourism, electronics, ship repair
yard, construction, food manufacturing,
textiles, footwear, clothing, beverages, tobacco
Agriculture: accounts for 3% of GDP and 2%
of the work force (1992); overall. 20% self-
sufficient; main products — potatoes,
caulitlower, grapes, wheat, barley, tomatoes,
citrus, cut flowers, green peppers, hogs,
poultry, eggs; generally adequate supplies of
vegetables, poultry, milk, pork products;
seasonal or periodic shortages in grain, animal
fodder, fruits, other basic foodstuffs
Illicit drugs; transshipment point for hashish
from North Africa to Western Europe
Economic aid;
recipient: US commitments, including Ex-Im
(FY7()-8I). $172 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $336 million; OPEC
bilateral aid (1979-89), $76 million;
Communist countries (1970-88), $48 million
Currency: I Maltese lira (LM) = 100 cents
Exchange rates: Maltese liri (LM) per
USSI— 0..395I (January 1994). 0.3821 (1993).
0.3 1 78 ( 1 992). 0.3226 (1991), 0.3 1 72 ( 1 990),
0.3483 (1989)
Fiscal year: I April — 31 March','bdc996cbc6c882f0c45b4bb5bbf4b52cec457da254139c09cd8a4ac092423e57','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d92eee55e5f6a349f9e29b8a01938c411dae4569fb07d6f1c8231e1e0910ce60',1994,'MH','Marshall Islands','economy',636,'Overview; Offshore banking, manufacturing,
and tourism are key sectors of the economy.
The government '' s policy of offeri ng incentives
to high-technology companies and financial
institutions to locale on the island has paid off
in expanding employment opportunities in
high-incomc indu.strics. As a result, agriculture
and fishing, once the mainstays of the
economy, have declined in their shares of
GNP. Banking now contributes about 45% to
GNP. Trade is mostly with the UK. The Isle of
Man enjoys free access to European Union
markets.
National product: GNP — exchange rale
conversion — S490 million (1988)
National product real growth rate; NA''if
National product per capita: $7..i00 ( 1 988 )
Inflation rate (consumer prices): 1% (1992
cst.)
Unemployment rate; I % ( 1 992 cst. )
Budget;
ivveniu’s: $1.40.4 million
expenditures: $1 1 4.4 million, including capital
expenditures of $ 1 8. 1 million (198.^ esi.)
Exports: SNA
(vmimidities: tweeds, herring, processed
shellfish, meat
partners: UK
Imports: SNA
coinnwdities: timber, fertilizers, fish
partners: UK
External debt: SNA
Industrial production: growth rate NA''/r
Electricity:
capacity: 6I,(KK) kW
production: 190 million kWh
consumption per capita: 2.96.4 kWh ( 1992)
Industries: an important offshore financial
center; financial services, light manufacturing.
tourism
Agriculture: cereals and vegetables; cattle,
sheep, pigs, poultry
Economic aid: SNA
Currency: I Manx pound (£M) = 100 pence
Exchange rales: Manx pounds (£M) per
USS I —0.6699 (January 1994), 0.66.48 ( 199.4),
0.5664 (1992). 0.5652 ( 1991 ), 0.560.4 ( 1990).
0,6099 ( 1989); (he Manx pound is at par with
the British pound
Fiscal year: I April — .41 March
Overview: Agriculture and tourism are the
mainstays of the economy. Agricultural
production is concentrated on small farms, and
the most important commercial crops are
coconuts, tomatoes, melons, and breadfmi:. A
few cattle ranches supply the domestic meat
market. Small-scale industry is limited to
handicrafts, fish processing, and copra. The
tourist industry is the primary source of foreign
exchange and employs about 10% of the labor
force. The islands have few natural resources,
and imports far exceed exports. In 1987 the US
Government provided grants of $40 million out
of the Marshallese budget of $55 million.
National product: GDP — purchasing power
equivalent — $63 million (1989 est.)
National product real growth rate: 6%
(1992)
National product per capita: $ 1 .500 ( 1 992
est)
Inflation rate (consumer prices): 7% ( 1992
est)
Unemployment rate: 16% ( 1991 e,st)
Budget:
revenues: $55 million
expenditures: SNA. including capital
expenditures of SNA (1987 est.)
Exports: $3.9 million (f.o.b., 1992 est)
commodities: coconut oil, fish, live animals,
trichus shells
partners: US, Japan, Australia
Imports: $62.9 million (c.i.f., 1992 est)
commodities: foodstuffs, machinery and
equipment, beverages and tobacco, fuels
partners: US, Japan, Australia
External debt: SNA
Industrial production; growth rate NA%
Electricity:
capacity: 42,000 kW
production: 80 million kWh
consumption per capita: 1 ,840 kWh ( 1 990)
Industries: copra, fish, tourism; craft items
from shell, wood, and pearls; offshore banking
(embryonic)
Agriculture: coconuts, cacao, taro,
breadfruit, fruits, pigs, chickens
Economic aid:
recipient: under the terms of the Compact of
Free Association, the US is to provide
approximately $40 million in aid annually
Currency: 1 United States dollar (US$) = 1 00
cents
Exchange rates: US currency is used
Fiscal year: I October — 30 September','00755d4ed87705cdf140ceed4466f6b7ec4fb303ade9b108b162babf99a7bfa1','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c4125ff08fe63fc666c48a133161e94a55ed34df898783ccdd8fd160987e950',1994,'MQ','Martinique','economy',644,'Overview: The economy is based on
sugarcane, bananas, tourism, and light
industry. Agriculture accounts for about 10%
of GDP and the small industrial sector for 10%.
Sugar production has declined, with most of
the sugarcane now used for the production of
rum. Banana exports are increasing, going
mostly to France. The bulk of meat, vegetable,
and grain requirements must he imported,
contributing to a chronic trade deficit that
requires large annual transfers of aid from
France. Tourism has become more important
than agricultural exports as a source of foreign
exchange. The majority of the work force is
employed in the service sector and in
administration. Banana workers launched
protests late in 1992 becau.se of falling banana
prices and fears of greater competition in the
European market from other producers.
National product: GDP — exchange rate
conversion — $3.3 billion (1991 )
2.64','66b8a8c905d37948fbcad177d33aef2033da664a20b084b5f0980b8a77ca9d57','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b8f74795b3d4a8324eaeffaab7ede6f8735d8e1d2f5361ea751573a267c390f',1994,'MR','Mauritania','economy',645,'National product real growth rate: NA%
National product per capita; $9,500 (1991)
Inflation rate (consumer prices): 3.9%
(1990)
Unemployment rate: 32. 1 % ( 1 990)
Budget:
revenues: $268 million
expenditures: $268 million, including capital
expenditures of $NA (1989 est.)
Exports: $201.5 million (f.o.b., 1991)
commodities: refined petroleum products,
bananas, rum, pineapples
partners: France 57. 1 %, Guadeloupe 3 1 .5%,
French Guiana 6.2%
Imports: $1.5 billion (c.i.f., 1991)
commodities: petroleum products, crude oil,
foodstuffs, construction materials, vehicles,
clothing and other consumer goods
partners: France 62.2%, UK, Italy, Germany,
Japan, US
External debt: SNA
Industrial production: growth rate NA%
Electricity:
capacity: 1 1 3, 1 00 kW
production: 588 million kWh
consumption per capita: 1 ,580 kWh ( 1 992)
Industries: construction, rum, cement, oil
refining, sugar, tourism
Agriculture: including fishing and forestry,
accounts for about 10% of GDP; principal
crops — pineapples, avocados, bananas,
flowers, vegetables, sugarcane for rum;
dependent on imported food, particularly meat
and vegetables
Illicit drugs: transshipment point for cocaine
and marijuana bound for the US and Europe
Economic aid:
recipient: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-89),
$10.1 billion
Currency: I French franc (F) = 100 centimes
Exchange rates: French francs (F) per
US$ 1—5.9305 (January 1994), 5.6632 ( 1 993),
5.2938 (1992). 5.6421 (1991), 5.4453 (1990),
6.3801 (1989)
Fiscal year: calendar year
Overview: A majority of the population still
depends on agriculture and livestock for a
livelihood, even though most of the nomads
and many subsistence farmers were forced into
the cities by recurrent droughts in the 1970s
and 1980s. Mauritania has extensive deposi.s
of iron ore, which account for almost 50% of
total exports. The decline in world demand for
this ore, however, has led to cutbacks in
production. The nation''s coastal waters are
among the richest fishing areas in the world,
but overexploitation by foreigners threatens
this key source of revenue. The country’s first
deepwater port opened near Nouakchott in
1986. In recent years, drought and economic
mismanagement have resulted in a substantial
buildup of foreign debt. The government has
begun the second stage of an economic reform
program in consultation with the World Bank,
the IMF. and major donor countries.
National product: GDP — purchasing power
equivalent — $2.2 billion (1992 est.)
National product real growth rate: 3.3%
(1993 est.)
National product per capita: $ 1 ,050 ( 1 992
est.)
Inflation rate (consumer prices): 1 1 .5%
(1993 est.)
Unemployment rate: 20% (1 991 est.)
Budget:
revenues: $280 million
expenditures: $346 million, including capital
expenditures of $61 million (1989 est.)
Exports: $432 million (f.o.b.. 1992 est)
commodities: iron ore, fish and fish products
partners: Japan 27%. Italy. Belgium.','6365eb19dc2813156cb6cca2559fe8d29e3ba7195ab16858d82035b9825cf561','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0101599263e3baadc12d74f9e0846f6baabdb63d5ed8edcc1cf63882dc299310',1994,'LU','Luxembourg','economy',650,'Imports: $413 million (c.i.f., 1992 est)
commodities: foodstuffs, consumer goods,
petroleum products, capital goods
partners: Algeria 15%, China 6%, US 3%.
France, Germany, Spain, Italy
External debt: $1.9 billion (1992 est.)
Industrial production: growth rate 4.4%''
( 1988 est.); accounts for almost .30% of GDP
Electricity:
capacity: 190,000 kW
production: 135 million kWh
consumption per capita: 70 kWh ( 1991 )
Industries: fish processing, mining of iron
ore and gypsum
Agriculture: accounts for 25% of GDP
(including fishing); largely subsistence
farming and nomadic cattle and sheep herding
except in Senegal river valley; crops — dates,
millet, sorghum, root crops; fish products
number-one export; large food deficit in years
of drought
Economic aid:
recipient: U.S commitments, including Ex-Im
(FY7()-89), $168 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $1.3 billion; OPEC
256','eb6536c18c410371d1cea61e51c0cf482417427300dfc724793753706d7abc93','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46a23704c8c497f857598c9a9b45f9e3ccb53f720d2c5f696979af56e48065f2',1994,'MU','Mauritius','economy',651,'bilateral aid (1979-89), S490 million;
Communist countries ( 1 970-89), $277 million;
Arab Development Bank (1991), $20 million
Currency: I ouguiya (UM) = 5 khoums
Exchange rates: ouguiyas (UM) per US$1 —
124.480 (December 1993), 87.082 (1992),
81.946(1991), 80.609(1990), 83.051 (1989)
Fiscal year: calendar year
Overview: The economy is based on sugar,
manufacturing (mainly textiles), and tourism.
Sugarcane is grown on about 90% of the
cultivated land area and accounts for 40% of
export earnings. The government''s
development strategy centers on
industrialization (with a view to exports),
agricultural diversification, and tourism.
Economic performance in 1992 was
impressive, with 6% real growth and low
unemployment.
National product: GOP — purchasing power
equivalent — S8.6 billion (1993 est.)
National product real growth rate: 6.3%
(1992 est.)
National product per capita: S7,800 ( 1993
est.)
Inflation rate (consumer prices): 4.6%
(1992 est.)
Unemployment rate: 2.4% (1991 est.)
Budget:
revenues: $557 million
expenditures: $607 million, including capital
expenditures of $I 1 1 million (1990 est.)
Exports: $1.32 billion (f.o.b., 1992 est.)
commodities: textiles 44%. sugar 40%, light
manufactures 10%
partners; EC and US have preferential
treatment, EU 77%. US 15%
Imports: $1.63 billion (f.o.b., 1992 est.)
commodities: manufactured goods .50%,
capital equipment 17%. foodstuffs 13%.
petroleum products 8%. chemicals 7%
partners: EC, US, South Africa, Japan
External debt: $991 million (1992 est.)
Industrial production: growth rate 7%
(1990); accounts for 25% of GDP
Electricity:
capacity: 235.000 kW
production: 630 million kWh
consumption per capita: 570 kWh ( 1992)
Industries; food proces.sing (largely sugar
milling), textiles, wearing apparel, chemicals,
metal products, transport equipment,
nonelectrical machinery, tourism
Agriculture: accounts for 10% of GDP; about
90% of cultivated land in sugarcane; other
products — tea, com, potatoes, bananas, pulses,
cattle, goats, fish; net food importer, especially
rice and fish
Illicit drugs; illicit producer of cannabis for
the international drug trade; heroin
consumption and transshipment are growing
problems
Economic aid;
recipient; US commitments, including Ex-lm
(FY70-89), $76 million; Western (non-US)
countries ( 1 970-89), $709 million; Communist
countries (1970-89), $.54 million
Currency: I Mauritian rupee (MauR) = 100
cents
Exchange rates; Mauritian rupees (MauRs)
per US$1 — 1 8.696 (January IW4), 17.648
(1993), 15.563(1992), 15.6.52(1991), 14.839
(1990), 15.250(1989)
Fiscal year: I July — 30 June','5fb2821775493d79c929cfc70f03769058a03c0c85680c897b8f3eeae64c91bc','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae7ec4627750f0e5dfbc168854edb53defb3d7f4bf3ae9380670f97ff22224c2',1994,'YT','Mayotte','economy',660,'Overview: Economic activity is based
primarily on the agricultural sector, including
fishing and livestock raising. Mayotte is not
sclf-.sufficient and must import a large portion
of its food requirements, mainly from France.
The economy and future development of the
island are heavily dependent on French
financial assistance. Mayotte''s remote location
is an obstacle to the development of tourism.
National product: GDP — purchasing power
equivalent — $54 million (1993 est.)
National product real growth rate: NA%
National product per capita: $600 ( 1 993
est.)
Inflation rate (consumer prices): NA%
Unemployment rate: NA%
Budget:
revenues: $NA
expenditures: $37.3 million, including capitol
expenditures of $NA (1985 est.)
Exports: $4 million (f.o.b., 1984)
commodities: ylang-ylang, vanilla
partners: France 79%, Comoros 10%, Reunion
9%
Imports; $21.8 million (f.o.b., 1984)
coinmoilities: building materials,
transportation equipment, rice, clothing, flour
partners: France 57%, Kenya 16%, South
Africa 1 1 %, Pakistan 8%
External debt; SNA
Industrial production: growth rate NA%
Electricity:
capacity: NA
production: NA
consumption per capita: NA
Industries; newly created lobster and shrimp
industry
Agriculture: most important .sector; provides
all export earnings; crop.s — vanilla, ylang-
ylang, coffee, copra; imports major share of
food needs
Economic aid;
recipient: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-89),
$402 million
Currency: I French franc (F) = 100 centimes
Exchange rates: French francs (F) per
US$1— 5.9205 (January 1994), 5.6632 (1993).
5.29.38 (1992), 5.6421 (1991), 5.4453 ( 1990).
6,3801 (1989)
259
Mayotte (continued)','345706d4d08fb1b1b4bb988b64e9bafeac36f7d46dccccd80253e461e4c0e022','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3aea891944783ea295327da28bd961316d81c5a9e27033828db71e5c5e359b36',1994,'FM','Micronesia, Federated States of','economy',662,'External debt: $125 billion (1993 est.)
Industrial production: growth rate 2.8%
(1992 est.); accounts for 28% of GDP
Electricity:
capacity: 27,000, (KX) kW
pmduction: 1 20.725 billion kWh
consumption per capita: 1 ,300 kWh ( 1 992)
Industries: food and beverages, tobacco,
chemicals, iron and steel, petroleum, mining,
textiles, clothing, motor vehicles, consumer
durables, tourism
Agriculture: accounts for 9% of GDP and
over 25% of work force; large number of small
farms at subsistence level; major food crops —
com, wheat, rice, beans; cash crops — cotton,
coffee, fruit, tomatoes
Illicit drugs: illicit cultivation of opium
poppy and cannabis continues in spite of active
government eradication program; major
supplier to the US market; continues as the
primary transshipment country for US-bound
cocaine and marijuana from South America
Economic aid:
recipient: US commitments, including Ex-lm
(FY70-89), $3.1 billion; Western (non-US)
countries. ODA and OOF bilateral
commitments (1970-89), $7.7 billion;
Communi.st countries (1970-89), $110 million
Currency: I New Mexican peso
(Mex$) = 100 centavos
Exchange rates: market rate of Mexican
pesos (Mex$) per US$1— 3.3556 (March
1994), 3,094.9 ( 1 992), 3,0 1 8.4 ( 1 99 1 ). 2.8 1 2.6
(1990), 2,461.3 (1989)
note: the new peso replaced the old peso on I
January 1993; 1 new peso = 1 ,000 old pesos
Fiscal year; calendar year
with runways 2,440-3,659 m: 35
with runways 1,220-2,439 tn: 286
Telecommunications; highly developed
system with extensive microwave radio relay
links; privatized in December 1990; connected
into Central America Microwave System;
6,4 1 0,000 telephones; broadcast stations— 679
AM, no FM, 238 TV, 22 shortwave; 1 20
.domestic satellite terminals: earth stations— 4
Atlantic Ocean INTELSAT and I Pacific
Ocean INTELSAT; launched Solidarity i
satellite in November 1993
Defense Forces
Branches: National Defense (including Army
and Air Force), Navy (including Marines)
Manpower availablUty: males age 15-49
22,779,635; fit for military service 16,6 19,809;
reach military age (18) annually 1,053,025
(1994 est.)
Defense expenditures: exchange rate
conversion — SNA. NA% of GDP
Communicatioiis
Railroads: 24,500 km total
Highways:
total: 242,300 km
paved: 84,800 km (including 3,166 km of
expressways)
unpaved: gravel and earth 157,500 km
Inland waterways: 2,900 km navigable
rivers and coastal canals
Pipelines: crude oil 28,200 km; petroleum
pr^ucts 10,150 km; natural gas 13,254 km;
petrochemical 1 ,400 km
Ports: Acapulco, Altamira, Coatzacoalcos.
Ensenada, CJuaymas, Manzanillo, Mazatlan,
Progreso, Puerto Vallarta, Salina Cruz,
Tampico, Tuxpan, Veracruz
Merchant marine: 58 ships ( 1 ,000 CRT or
over) totaling 853,161 GRT/1,269.018 DWT,
short-sea passenger 4. cargo 3, refrigerated
cargo 2, roll-on/roll-off cargo 2, oil tanker 32,
chemical tanker 4, liquefied gas 7, container 4
Airports:
total: 1,993
usable: 1,585
with pennanent-surface runways: 202
with runways over 3,659 m: 3
ICOOHn
Yd
. ititnas XOIONI*
KBpin^tm^rangi
Nonh p*ci/ie Ocm/i
Overview; Economic activity consists
primarily of subsistence farming and fishing.
The islands have few mineral deposits worth
exploiting, except for high-grade phosphate.
The potential for a tourist industry exists, but
the remoteness of the location and a luck of
adequate facilities hinder development.
Financial assistance from the US is the primary
source of revenue, with the US pledged to
spend $1 billion in the islands in the 1990s.
Geographical isolation and a ptxrriy developed
infrastructure are major impediments to long¬
term giowth.
National product; GNP — purchasing power
equivalent — $150 million ( 1989 est.)
note: GNP numbers retlccl US spending
National product real growth rate; NA%
National product per capita; $ 1 ,500 ( 1 989
est.)
Inflation rate (consumer prices); NA%
Unemployment rate: 27% (1989)
Budget:
revenues: SI 65 million
expenditures: $115 million, including capital
expenditures of $20 million ( 1 988 est.)
Exports: $2.3 million (f.o.b., 1988)
commodities: copra
partners: NA
Imports: $67.7 million (c.i.f., 1988)
commodities: NA
partners: NA
External debt: SNA
Industrial production; growth rate NA%
Electricity:
capeiciiy: l8,0(X)kW
production: 40 million kWh
consumption per capita: 380 kWh (1990)
Industries: tourism, construction, fish
pntcessing, craft items from shell, wood, and
pearls
Agriculture: mainly a subsistence economy;
black pepper; tropical fruits and vegetables,
coconuts, cassava, sweet potatoes, pigs,
chickens
Economic aid:
recipient: under tenns of the Compact of Free
Association, the US will provide $1.3 billion in
grant aid during the period 1986-2001
Currency; I United States dollar (US$)= 100
cents
Exchange rates; US currency is used
Fiscal year; I October— 30 September
Overview: The economy is based on
providing support services for US naval
operations located on the islands. All food and
manufactured goods must be imported.
Electricity: supplied by US Military
Overview: Moldova has pushed ahead boldly
on economic reform since gaining its
independence from the Soviet Union In 1991.
It introduced a convertible currency — the
leu — in late 1993 that has remained stable
against the dollar, removed price controls on
most products, eliminated licenses and quotas
on most imports and exports, and freed interest
rates. In 1994, Moldova aims to privatize at
least one-third of state enterprises, lower
inflation to 1 % per month, and reduce the
budget deficit to 3.5% of GDP. Moldova
enjoys a favorable climate and good farmland
but has no major mineral deposits. As a result,
Moldova''s economy is primarily based on
agriculture, featuring fruits, vegetables, wine,
and tobacco, Moldova, however, must import
all of its supplies of oil, coal, and natural gas.
and energy shortages have contributed to sharp
production declines since thr* break-up of the
Soviet Union. Activities by separatist groups in
the Dniester region have held back economic
development in that area. Foreign economic
assistance has been a tangible plus for
Moldova, whereas direct foreign investment
has been lacking.
National product: GDP — purchasing power
equivalent — $16.3 billion (1993 estimate from
the UN International Comparison Program, as
extended to 1991 and published in the World
Bank''s World Development Report 1993: and
as extrapolated to 1993 using official
Moldovan statistics, which are very uncertain
because of major economic changes since
1990)
26.‘i
Moldova (continued)','30f604492177676a6a2e95fce0741376dfd63a0a15f0a20ff781bbd38ae463fe','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d05160967127572e45c5c7d040e25f874d32c2739bb86fa528ad4b0a6197d1e8',1994,'MC','Monaco','economy',668,'National product real growth rate: -4%
(1993 est.)
National product per capita: $3,6S0 (1993
est.)
Inflation rate (consumer prices); 30% per
month (1 993)
Unemployment rate: less than I % (includes
only officially registered unemployed; large
numbers of underemployed workers)
Budget:
revenues: SNA
expenditures; SNA, including capital
expenditures of SNA
note: budget deficit for 1993 approximately
6% of GDP
Exports: SI 08 million to outside the FSU
countries (January-September 1993); over
70% of exports go to FSU countries
commodities; foodstuffs, wine, tobacco,
textiles and footwear, machinery, chemicals
(1991)
partners: Russia, Kazakhstan, Ukraine,
Romania, Germany
Imports: SI 43 million from outside the FSU
countries (January-September 1993); over
70% of imports are from FSU countries
commodities: oil, gas, coal, steel machinery,
foodstuffs, automobiles, and other consumer
durables
partners; Russia, Ukraine, Uzbekistan,
Romania, Germany
External debt: $323 million (end of 1993)
Industrial production: growth rate -10%
(1993)
Electiicity:
capacity: 3,1 13,000 kW
production; II. I billion kWh
consumption per capita: 2,491 kWh (1992)
Industries: key products are canned food,
agricultural machineiy. foundry equipment,
refrigerators and freezers, washing machines,
hosiery, refined sugar, vegetable oil, shoes,
textiles
Agriculture: Moldova''s principal economic
activity; products are vegetables, fruits, wine,
grain, sugar beets, sunflower seed, meat, milk,
tobacco
Illicit drugs: illicit cultivator of opium poppy
and cannabis; mostly for CIS consumption;
transshipment point for illicit drugs to Western
Europe
Economic aid:
recipient: Joint EC-US loan (1993), $127
million; IMF STF credit ( 1993), $64 million;
IMF ''••''.and-by loan (1993), $72 million; US
commitments (1992-93). $61 million in
humanitarian aid. $1 1 million in technical
assistance; World Bank loan (1993). $60
million; Russia (1993), 50 billion ruble credit;
Romania (1993), 20 billion lei credit
Currency: the leu (plural lei) was introduced
in late 1993
Exchange rates: NA
Fiscal year: calendar year
Overview: Monaco, situated on the French
Mediterranean coast, is a popular resort,
attracting tourists to its casino and pleasant
climate. The Principality has successfully
sought to diversify into services and small,
high-value-added, nonpolluting industries. The
state has no income tax and low business taxes
and thrives as a tax haven both for individuals
who have established residence and for foreign
companies that have set up businesses and
offices. About 50% of Monaco''s annual
revenue comes from value-added taxes on
hotels, banks, and the industrial sector; about
25% of revenue comes from tourism. Living
standards are high, that is, roughly comparable
to those in prosperous French metropolitan
suburbs.
National product; GDP — exchange rate
conversion — $475 million (1991 est.)
National product real growth rate: NA%
National product per capita: S 1 6,000 (1991
est.)
Inflation rate (consumer prices): NA%
Unemployment rate: NEGL%
Budget:
revenues: $424 million
expenditures: $376 million, including capital
expenditures of $NA (1991 est.)
Exports: $NA: full customs integration with
France, which collects and rebates Monacan
trade duties; also participates in EU market
system through customs union with France
Imports: $NA; full customs integration with
France, which collects and rebates Monacan
trade duties; also participates in EU market
system through cu.stoms union with France
External debt: $NA
Industrial production: growth rate NA%
Electricity:
capacity: 10,000 kW standby; power imported
from France
production: NA
consumption per capita: NA ( 1992)
Agriculture: none
Economic aid: $NA
Currency: I French franc (F) = 100 centimes
Exchange rates: French francs (F) per
US$1— 5.9205 (January 1994). 5.6632 (1993),
5.2938 (1992), 5.6421 (1991), 5.4453 (1990),
6.3801 (1989)
Fiscal year: calendar year','7f982786db28721b89c4cdc1063172a81791dfd1ab1615866a4f72191ce45121','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1be58e1b8463f18d01e73e09311be47332b597c7fdcaee44940d9929f7f9b17',1994,'MN','Mongolia','economy',675,'Overview: Mongolia’s severe climate,
scattered population, and wide expanses of
unproductive land have constrained economic
development. Economic activity traditionally
has been based on agriculture and the breeding
of livestock — Mongolia has the highest
number of livestock per person in the world. In
past years extensive mineral resources had
been developed with Soviet support; total
Soviet assistance at its height amounted to 30%
of GDP. The mining and processing of coal,
copper, molybdenum, tin. tungsten, and gold
account for a large part of industrial
production. Timber and fishing are also
important sectors. The Mongolian leadership is
trying to make the transition from Soviet-style
central planning to a market economy through
privatization and price reform, and is soliciting
support from international financial agencies
and foreign investors. The economy, however,
has still not recovered from the loss of Soviet
aid, and the country continues to suffer
substantial economic hardships.
National product; GDP — purchasing power
equivalent — $2.8 billion (1993 est.)
National product real growth rate: ■ 1 .3%
(1993 est.)
National product per capita: $ 1 ,200 ( 1 993
est.)
Inflation rate (consumer prices): 325%
(1992 est.)
Unemployment rate: 1 5% (1 99 1 est. )
Budget;
revenues; SNA
expenditures; SNA. including capital
expenditures of SNA (1991 est.)
note: deficit of $67 million
Exports: $355 million (f.o.b., 1992 est.)
commodities: copper, livestock, animal
products, cashmere, wool, hides, fluorspar,
other nonferrous metals
partners: former CMEA countries 62%, China
17%, EC 8% (1992)
Imports: $501 million (fo.b., 1991 est.)
commodities: machinery and equipme.it. fuels,
food products, industrial consumer goods,
chemicals, building materials, sugar, tea
partners: USSR 75%, Austria 5%, China 5%
External debt: $16.8 billion (yearend 1990);
98.6% with USSR
Industrial production: growth rate -15%
( 1 992 est.); accounts for about 42% of GDP
Electricity:
capacity; 1 ,248,000 kW
production: 3,740 kWh
consumption per capita: 1.622 kWh (1992)
Industries: copper, processing of animal
products, building materials, food and
beverage, mining (particularly coal)
Agriculture: accounts for about 35% of GDP
and provides livelihood for about 50% of the
population; livestock raising predominates
(primarily sheep and goats, but also cattle,
camels, and horses); crops — wheat, barley,
potatoes, forage
Economic aid: NA
Currency: I tughrik (Tug) = 100 mongos
Exchange rates: tughriks (Tug) per US$ I —
150(1 January 1993), 40 (1992), 7.1 (1991),
5.63 (1990), 3.00(1989)
note: the exchange rate 40 tughriks = I US$
was introduced June 1991 and was in force to
the end of 1992
Fiscal year: calendar year','edf5a8e5fad9baa2c11d8826417bac3bfac4461db14578d2af2f535be39d4b43','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6af10b6a7f801f30fd81665177e6ebd3a5af658b465a8913001e96bf71feaced',1994,'MS','Montserrat','economy',681,'Overview: The economy is small and open
with economic activity centered on tourism
and construction. Tourism is the most
important sector and accounts for roughly one-
fifth of GDP. Agriculture accounts for about
4% of GDP and industry 1 0%. The economy is
heavily dependent on imports, making it
vulnerable to fluctuations in world prices.
Exports consist mainly of electronic parts sold
to the US.
National product: GDP — purchasing power
equivalent — $53.7 million ( 1992 est.)
National product real growth rate; 4.3%
(1992 est.)
National product per capita; $4,.300 (1992
est.)
Inflation rate (consumer prices): 2.8%>
(1992)
Unemployment rate: 3% ( 1987)
Budget:
revenues; $12.1 million
expenditures; $14.3 million, including capital
expenditures of $3.2 million (1988 est.)
Exports: $2.8 million (f.o.b., 1992)
eommodities; electronic parts, plastic bags,
apparel, hot peppers, live plants, cattle
partners; NA
Imports: $80.6 million (f.o.b., 1992)
eommodities; machinery and transportation
equipment, food.stuffs, manufactured goods,
fuels, lubricants, and related materials
partners; NA
External debt: $2.05 million ( 1987)
Industrial production: growth rate 8.1%
( 1986); accounts for 10% of GDP
Electricity;
capacity; 5.271 kW
production; 12 million kWh
consumption per capita; 950 kWh (1992)
Industries: tourism; light manufacturing —
rum, textiles, electronic appliances
Agriculture; accounts for 4% of GDP;
small-scale farming; RkhI crops — tomatoes,
onions, peppers; not self-sufficient in fiKid,
especially livestock products
Economic aid:
recipient; Western (non-US) countries, ODA
and OOF bilateral commitments (1970-89),
$90 million
Currency: 1 EC dollar (ECS) = 100 cents
Exchange rates: East Caribbean dollars
(ECS) per US$1 — 2.70 (fixed rate since 1976)
Fiscal year: 1 April — 3 1 March','8ff6362ac73dbfd59407896feb5701060aca2302828107137213306c2e00d918','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39bdf7a3829a8afa380c33510adff4a0ef108114cc5a942efe27dc9b30349f75',1994,'GI','Gibraltar','economy',687,'Overview: Morocco faces the typical
problems of developing countries — restraining
government spending, reducing constraints on
private activity and foreign trade, and keeping
inflation within bounds. Since the early 1980s
the government has pursued an economic
program toward these objectives with the
support of the IMF, the World Bank, and the
Paris Club of creditors. The economy has
substantial assets to draw on: the world''s
largest phosphate reserves, diverse agricultural
and fishing resources, a sizable tourist
industry, a growing manufacturing sector, and
large remittances from Moroccans working
abroad. However, a severe drought in 1992-93
has depressed economic activity and held
down experts. Real GDP contracted by 2.9% in
1992, and growth for 1993 is estimated at only
2%. Despite these setbacks, initiatives to relax
capital controls, .strengthen the banking sector,
and privatize state enterprises went forward in
1993. Servicing the large debt, high
unemployment, and vulnerability to external
economic forces remain long-term problems
for Morocco,
National product: GDP — purchasing power
equivalent — $70.3 billion ( 199.3 e.st.)
National product real growth rate: 2%
(1993est.)
National product per capita: $2,500 ( 1 993
est.)
Inflation rate (consumer prices): 4.5%
(199.3 est.)
Unemployment rate: 16% (1992 est.)
Budget:
revenues: $7.5 billion
expenditures: $7.7 billion, including capital
expenditures of $ 1 .9 billion (1992 est.)
Exports: $5.7 billion (f.o.b., 1992)
commodities: food and beverages 30%.
.semiprocessed goods 23%. consumer goods
21%, phosphates 17%
partners: EC 64%, India 6%, Japan 4%. US
3%
Imports: $8.4 billion (c.i.f., 1992)
commodities: capital goods 24%.
semiprocessed goods 22%, raw materials 16%.
fuel and lubricants 16%. food and beverages
13%, consumer goods 9%
partners: EC 63%, US 6%. Saudi Arabia 4%.
FSU4%,Japan 1%
External debt: $21 .3 billion ( 1992)
Industrial production: growth rate 0.1%;
accounts for 3 1 % of GDP ( 1 99 1 )
Electricity:
capacity: 2,384,000 kW
production: 8.864 billion kWh
consumption per capita: 317 kWh (1992)
Industries: phosphate rock mining and
processing, food processing, leather goods,
textiles, construction, tourism
Agriculture: accounts for 14% of GDP, 50%
of employment, and 30% of export value: not
self-sufficient in food; cereal farming and
livestock raising predominate; barley, wheat,
citrus fruit, wine, vegetables, olives
Illicit drugs: illicit producer of hashish;
trafficking on the increase for both domestic
and international drug markets; shipments of
hashish mostly directed to Western Europe;
occasional transit point for cocaine from South
America destined for We.stern Europe.
Economic aid:
recipient: US commitments, including Ex-Im
(FY70-89), $1.3 billion; US commitments,
including Ex-Im (1992). $12.3.6 million;
Western (non-US) countries. ODA and OOF
bilateral commitments ( 1970-89), $7.5 billion;
OPEC bilateral aid (1979-89). $4.8 billion;
Communist countries ( 1970-89), $2.5 billion
note: $2.8 billion debt canceled by Saudi
Arabia (1991); IMF standby agreement worth
$ 1 3 million; World Bank. $450 million (1991)
Currency: I Moroccan dirham (DH)= 100
centimes
Exchange rates: Moroccan dirhams (DH) per
US$1— 9.669 (January 1994), 9.299 (1993),
8.538 (1992), 8,707 (1991), 8.242 (1990),
8.488(1989)
Fiscal year: calendar year','02eeb3a9b4da841dac683bb9363d1e494ffcbd83de7702217a98da079d1fbfb0','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4c5f919e26400c92952b5cb71b4a78683da4a9e9b846c2d41c71af6fb239773',1994,'MZ','Mozambique','economy',691,'Overview; One of Africa''s poorest countries,
Mozambique has failed to exploit the
economic potential of its sizable agricultural,
hydropower, and transportation re.sourees.
Indeed, national output, consumption, and
investment declined throughout the first half of
the I98()s because of internal disorders, lack of
government administrative control, and a
growing foreign debt. A sharp increase in
foreign aid, attracted by an economic reform
policy, resulted in successive years of
economic growth in the late 1980s, but aid has
declined .steadily since 1989. Agricultural
output is at only 75%> of its 198 1 level, and
grain has to be imported. Industry operates at
only 20-40% of capacity. The economy
27.7
Mozambique (continued)
Overview: Tanzania is one of the poorest
countries in the world, The economy is heavily
dependent on agriculture, which accounts for
about 58% of GDP, provides 85% of exports,
and employs 90% of the work force. Industry
accounts for 8% of GOP and is mainly limited
to processing agricultural products and light
consumer goods. The economic recovery
program announced in mid- 1 986 has generated
notable increases in agricultural production
and financial support for the program by
bilateral donors. The World Bank, the
International Monetary Fund, and bilateral
donors have provided funds to rehabilitate
Tanzania''s deteriorated economic
infrastructure. Growth in 1991-93 featured a
pickup in industrial production and a
sub.stantial increase in output of minerals led
by gold.
National product: GDP — purchasing power
equivalent — $16.7 billion (1993 est.)
National product real growth rate; 3.2%
(1993 est.)
Nutional product per capita: $600 ( 1 993
est.)
Inflation rate (consumer prices): 21%
(1993 e.sl.)
Unemployment rate: NA%
Budget:
revenues: $495 million
e.rpinditures: $631 million, including capital
expenditures of$l 18 million ( 1 990 est.)
Exports: $418 million (f.o.b,. 1992 est.)
commodities: coffee, cotton, tobacco, tea.
cashew nuts, sisal
partners: FRG, UK, Japan. Netherlands.
Kenya, Hong Kong, US
Imports: $1.51 billion (c.i.f.. 1992 est.)
commodities: manufactured goods, machinery
and transportation equipment, cotton piece
goods, cmde oil, foodstuffs
partners; FRG, UK, US, Japan, Italy. Denmark
External debt: $6.44 billion (1992)
Industrial production: growth rate 9.3%
( 1 990); accounts for 8% of GDP
Electricity:
capacity: 405,000 kW
production: 600 million kWh
consumption per capita: 20 kWh (1991)
Industries: primarily agricultural processing
(sugar, beer, cigarettes, sisal twine), diamond
and gold mining, oil refinery, shoes, cement,
textiles, wood products, fertilizer
Agriculture: accounts for over 58% of GDP;
topography and climatic conditions limit
cultivated crops to only 5% of land area: cash
crops — coffee, sisal, tea, cotton, pyrethrum
(insecticide made from chrysanthemums),
cashews, tobacco, cloves (Zanzibar): food
crops— corn, wheal, cassava, bananas, fruits,
vegetables; small numbers of cattle, .sheep, and
goats: not self-sufficient in food grain
production
Illicit drugs: growing role in transshipment of
Southwest Asian heroin destined for US and
European markets
Economic aid:
recipient: US commitments, including Ex-Im
(FY70-89). $400 million: Western (non-US)
countries. ODA and OOF bilateral
commitments (1970-89), $9.8 billion: OPEC
bilateral aid (1979-89), $44 million;
Communist countries ( 1970-89), $614 million
Currency: I Tanzanian shilling (TSh) = 100
cents
Exchange rates: Tanzanian shillings (TSh)
per USS I -486.75 (January 1994). 405.27
(1993), 297.71 (1992). 219,16(1991). 195,06
(1990), 143.38(1989)
Fiscal year: I July-.30 June','749c2fffd537a00780375d178f4f566f14f4b74a580bc2ceb62e5abb6e6e3d6b','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5dcb758ee6982318fe6048b965573a0d5de36c3137ffcd7dc671b36d789a823',1994,'NA','Namibia','economy',692,'depends heavily on foreign assistance to keep
afloat. Peace accords signed in October 1992
improved chances of foreign investment, aided
IMF-supported economic reforms, and
.supported continued economic recovery.
National product: GDP — purchasing power
equivalent — $9.8 billion (1993 est.)
National product real growth rate: 4. 1 %
(1993 est.)
National product per capita; $600 ( 1993
est.)
Inflation rate (consumer prices); 40%
(1993 est.)
Unemployment rate: S0% (1989 est.)
Budget:
revenues: $252 million
expenditures; $607 million, including capital
expenditures of SNA (1992 est.)
Exports: $164.4 million (f.o.b., 1993 e.st.)
commodities; shrimp 48%, cashews 21%,
sugar 10%, copra 3%, citrus 3%
partners: US, Western Europe, Germany,','428110d514d651ffd131ada7a61f1f6673fe585af3f1c1c96394e3ce0b75377f','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('403f0280bd877de0d0e4a206930ff2fc0e313dfd6640bec28c4e8d72a5733a3f',1994,'ZA','South Africa','economy',694,'Overview: The economy is heavi ly dependent
on the mining industry to extract and process
minerals for export. Mining accounts for
almost 25% of GDP. Namibia is the fourth-
largest exporter of nonfuel minerals in Africa
and the world''s fifth-largest producer of
uranium. Alluvial diamond deposits are among
the richest in the world, making Namibia a
primary .source for gem-quality diamonds.
Namibia also produces large quantities of lead,
zinc, tin, silver, and tungsten. More than half
the population depends on agriculture (largely
subsistence agriculture) for its livelihood.
National product; GDP — purchasing power
equivalent — $3.85 billion (1993 est.)
National product real growth rate: 3.5%
(1992)
National product per capita: $2,.5(X) (1993
est.)
Inflation rate (consumer prices): 1 7.9%
( 1 992) in urban area
Unemployment rate: 30% (1992)
Budget:
revenues: $941 million
expenditures: $1.05 billion, including capital
expenditures of $157 million (FY93/94)
Exports: $1,289 billion (f.o.b.. 1992 est.)
commodities; diamonds, copper, gold. zinc,
lead, uranium, cattle, processed fish, karakul
skins
partners: Switzerland, South Africa,
Germany, Japan
Imports: $1,178 billion (f.o.b., K''92)
cmnmodities; foodstuffs, petroleum products
and fuel, machinery and equipment
partners; South Africa. Germany, US,
Overview: Many of the white one-seventh of
the South African population enjoy incomes,
material comforts, and health and educational
standards equal to those of Western Europe. In
contrast, most of the remaining population
suffers from the poverty patterns of the Third
World, including unemployment and lack of
job skills. The main Strength of the economy
lies in its rich mineral resources, which provide
two-thirds of exports. Economic developments
for the remainder of the 1990s will be driven
largely by the new government''s attempts to
improve black living conditions and to set the
country on an aggressive export-led growth
path. The shrinking economy in recent years
has absorbed less than 5% of the more than
300,000 workers entering the labor force
annually. Local economists estimate that the
economy must grow between 5% and 6% in
real terms annually to absorb all of the new
entrants.
National product: GDP — purcha.sing power
equivalent — $171 billion (1993 est.)
National product real growth rate; 1.1%
(1993 est.)
National product per capita: $4,000 ( 1993
est.)
Inflation rate (consumer prices): 9.7%
(1993 est.)
Unemployment rate: 50% (1994 est.)
Budget:
revenues: $26.3 billion
expenditures: $34 billion, including capital
expenditures of $2.5 billion (FY94 est.)
Exports: $24.3 billion (f.o.b., 1993)
commodities: gold 27%, other minerals and
metals 20-25%, food 5%, chemicals 3%
partners: Italy. Japan. US. Germany. UK,
other EC countries. Hong Kong
Imports: $18.1 billion (f.o.b.. 1993)
commodities: machinery 32%. transport
equipment 15%, chemicals 1 1%, oil, textiles,
scientific instruments
partners: Germany. US, Japan, UK, Italy
External debt; $17 billion (1993 est.)
Industrial production: growth rate NA%:
accounts for about 40^i of GDP
Electricity;
capacity: 46.000,000 kW
production: 180 billion kWh
consumption per capita; 4, 1 00 kWh (1991)
Industries; mining (world’s largest producer
of platinum, gold, chromium), automobile
assembly, metalworking, machinery, textile,
iron and steel, chemical, fertilizer, foodstuffs
Agriculture: accounts for about 5% of GDP
and 30% of labor force; diversified agriculture,
with emphasis on livestock; products — cattle,
poultry, sheep, wool, milk. beef, corn, wheat,
sugarcane, fruits, vegetables; .self-sufficient in
food
Illicit drugs: transshipment center of heroin
and cocaine; cocaine consumption on the rise
Economic aid: many aid packages for the
new government are still being prepared;
current aid pledges include US $600 million
over 3 years; UK $150 million over 3 years;
Australia $2 1 million over 3 years
Currency: I rand(R)= 100 cents
Exchange rates; rand (R) per US$1 — 3.4551
364
South Georgia and the South
Sandwich Islands
(dependent territory of the UK)
Manpower availability; males age 15-49
10,557,346; fit for military service 6,437,240;
reach military age (18) annually 43 1 ,832 ( 1 994
cst.)
Defense expenditures: exchange rale
conversion — $2.9 billion, about 2.5% of GDP
(FY93 budget)
South','a844ce1b78b4e59bf89795e1d8af626b86526d01816844ce7164a2dfc158ba76','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75b6a5618c68881197549b4ed59bbcc0ebeddf88f3eec5857d807b4cbda6fa12',1994,'CH','Switzerland','economy',695,'External debt; about $220 million ( 1 992 est.)
Industrial production: growth rate 4.9%
(1991); accounts for 35% of GDP, including
mining
Electricity:
catweity: 490.0(X) kW
producli''m: 1.29 billion kWh
consumption per capita: 850 kWh (1991)
Industries; meatpacking, fish processing,
dairy products, mining (copper, lead, zinc.
diamond, uranium)
Agriculture: accounts for 15% of GDP;
mostly suhsistence farming; livestock raising
major source of cash income; crops — millet,
sorghum, peanuts; fish catch potential of over
1 million metric tons not being fulfilled. 1988
catch reaching only 384.i)00 metric tons: not
self-sufficient in food
Economic aid:
recipient: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-87).
$47.2 million
Currency; 1 South African rand (R) = 100
cents
Exchange rates: South African rand (R) per
US$ I —3.4096 (January 1994). 3.2678 ( 1993),
Naniibia (continued)','abd9e0f3db0990c8fb76175a4c6c7ff239c1eee8e8b4a1f12551d8551a6a4282','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ce427c4d86a839856c31df043113bf19ba17bc4b5a7889c461ff912d36ad11f',1994,'NR','Nauru','economy',696,'2,8497 (1992), 2.7653 (1991), 2..5863 (1990),
2,6166(1989)
Fiscal year: 1 April— 31 March
Coinmunicalions
Railroads; 2,341 km 1,067-meter gauge,
single track
Highways;
total: 54,500 km
paved; 4,080 km
unpaved; gravel 2,540 km; earth 47,880 km
(roads and tracks)
Ports; Luderitz; Walvis Bay
Airports;
total: 136
usable; 109
with penmment-siofiice niitways; 2 1
with runways over 3.659 m: I
with runways 2.440-3.659 m; 4
with runways 1.220-2.439 m; 64
Telecommunications; good urban, (''air rural
services; radio relay connects major towns,
wires extend to other population centers;
62,8(X) telephones; broadcast stations — 4 AM,
40 FM. 3 TV
Defense Forces
Branches; National Defense Force (Army),
Police
Manpower availability; males age 15-49
336,145; fit for militaiy service 199,337
Defease expenditures; exchange rate
conversion— $66 million, 3.4‘7f of GDP
(FY92)
Overview: Revenues come from the export of
phosphates, the re.serves of which are expected
to be exhausted by the year 2000, Phosphates
have given Nauruans one of the highest per
capita incomes in the Third World — $10,000
annually. Few other resources exist, so most
necessities must be imported, including fresh
water from Australia. The rehabiiitation of
mined land and the replacement of income
from phosphates are serious long-term
parblems. Substantial amounts of phosphate
income are invested in trust funds to help
cushion the transition.
National product: GNP-— exchange rate
conversion — $90 million ( 198° est.)
National product real growth rate: NA((''
National product per capita: S 1 0.000 ( 1 989
est.)
Inflation rate (consumer prices); NA%
Unemployment rate: 0^^
Budget:
revenues; $69.7 million
exiienditures: $51.5 million, including capital
expenditures of $NA ( 1986 e: '',.)
Exports: $9.1 million (f.o.b., 1984)
commodities; phosphates
inirmers; Australia, NZ
Imports: $7.^ million (c.i.f.. 1984)
comnutdities: food, fuel, manufact ires,
building materials, machinery
partners; Australia. UK. NZ, Japan
External debt: $it.l..l million
Industrial production: growth rate NAf(
Electricity:
capacity; 14,(K)0 kW
production; 50 million kWh
consumption per ca/tita; 5.410 kWh ( 1 990)
Industries: phosphate mining, financial
services, coconut products
Agriculture: coconuts; other agricultural
activity negligible: almost completely
dependent on imports for food and water
Economic aid:
reciphni; Western (non-US) countries (1970-
89), $2 million
Currency: I Australian dollar ($A) = 100
cents
Exchange rates: Australian dollars ($A) per
US$1— 1,4364 (Jaoua.-y 1994). 1,4704(1903).
I.. 3600 (1992), 1.28,34(1991). 1.2799(1990).
1.2618(1989)
Fiscal year: 1 July — ,30 June','62ce01e05501dac625e9c8528a5626cdb7c0db913014e773540582751514b627','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a443a7954e5eb32336857e204ab9ab9e9fe714420d60d403b9fc41b9c0031e4',1994,'NP','Nepal','economy',703,'Overview: no economic activity
Overview: Nepal is among the poorest and
least developed countries in the world.
Agriculture is the mainstay of the economy,
providing a livelihood for over 90% of the
population and accounting for 60% of GDP.
Industrial activity is limited, mainly involving
the processing of agricultural produce (jute,
sugarcane, tobacco, and grain). Production of
textiles and carpets has expanded recently and
accounted for 85% of foreign exchange
earnings in FY94. Apart from agricultural land
and forests, exploitable natural resources are
mica, hydropower, and tourism. Agricultural
production in the late 1 980s grew by about 5%.
as compared with annual population growth of
2.6%. More than 40% of the population is
undernourished. Since May 1991, the
government has been encouraging trade and
foreign investment, e.g., by eliminating
business licenses and registration requirements
in order to simplify domestic and foreign
inve.stment. The government also has been
cutting public expenditures by reducing
subsidies, privatizing state industries, and
laying off civil servants. Prospects for foreign
trade and investment in the 1990s remain poor,
however, because of the small size of the
economy, its technological backwardness, its
remoteness, and susceptibility to natural
disaster. Nepal experienced severe flooding in
August 1993 which caused at least $50 million
in damage to the country''s infrastructure.
National product: GDP — purchasing powet
equivalent — $20.5 billion (1993 est.)
National product real growth rate: 2.9%
(FY93)
National product per capita: $ 1 ,0(X) (1993
est.)
Inflation rate (consumer prices): 9%
(September 1993)
Unemployment rate: 5% (1987);
underemployment estimated at 25-40%
Budget:
revenues: $457 million
expenditures: $725 million, including capital
expenditures of $427 million (FY93 est.)
Exports: $369 million (f.o.b., FY93) but does
not include unrecorded border trade with India
commodities: carpets, clothing, leather goods,
jute goods, grain
partners: US, Germany, India, UK
Imports: $789 million (c.i.f., FY93 est.)
commodities: petroleum products 20%,
fertilizer 1 1%, machinery 10%
partners: India, Singapore, Japan, Germany
External debt: $2 billion (FY93 est.)
Industrial production: growth rate 6%
(FY9I est.); accounts for 16% of GDP
Electricity:
capacity: 300,000 kW
production: 1 billion kWh
consumption per capita: 50 kWh ( 1 992)
Industries: small rice, jute, sugar, and oil.seed
mills; cigarette, textile, carpet, cement, and
brick production; tourism
Agriculture: accounts for 60% of GDP and
93% of work force; fann products — rice, com,
wheat, sugarcane, root crops, milk, buffalo
meat; not self-sufficient in food, particularly in
drought years
Illicit drugs; illicit producer of cannabis for
the domestic and international drug markets;
transit point for heroin from Southeast Asia to
the West
Economic aid;
recipient: US commitments, including Ex-Im
(FY70-89), $304 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1980-89), $2.23 billion; OPEC
bilateral aid (1979-89), $30 million;
Communist countries ( 1970-89), $286 million
Currency: 1 Nepalese rupee (NR) = 1 00 paisa
Exchange rates: Nepalese rupees (NRs) per
US$ 1-^9.240 (January 1 994), 48.607 ( 1 993),
42.742 (1992). 37.255 (1991), 29.370 (1990),
27.189(1989)
Fiscal year: 1 6 J uly — 1 5 July','e58ca5e50895ddecb6dafb31a29a76ddec9b04b7788dfab747e9eebafe6b6c03','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd75fc4938e75265778419ef5a0e341094baf7b150f1285ea39bfb2dac4cbf1e',1994,'TK','Tokelau','economy',711,'Overview: Since 1 984 the government has
been reorienting an agrarian economy
dependent on a guaranteed British market to a
more industrialized, open free market economy
that can compete on the global scene. The
government has hoped that dynamic growth
would boost real incomes, broaden and deepen
the technological capabilities of the industrial
sector, reduce inflationary pressures, and
permit the expansion of welfare benefits. The
results have been mixed: inflation is down
from double-digit levels, but growth was
sluggish in 1988-91. in 1992-93, growth
picked up to 3^^ annually, a sign that the new
economic approach is beginning to pay off.
Business confidence has strengthened, and the
inflation remains among the lowest in the
industrial world. Unemployment, down from
1 1''.^ in 1991, a''lnains unacceptablv high at
National product; GDP — purchasing power
equivalent — $53 billion (1993)
National product real growth rate: 3%
(1993)
National product per capita: $ 15,700
(1993)
Inflation rate (consumer prices): 2%(I993)
Unemployment rate: 9.1% (September
1993)
Budget:
revenues; SNA
expenditures; SNA. including capital
expenditures of SNA
note; deficit $345 million (October 1993)
Exports: $10.3 billion (FY93)
commodities; wool, lamb, mutton, beef, fruit,
fish, cheese, manufactures, chemicals, forestry
products
IHtrtners; Australia 18.9%, Japan 15.1%, US
12.5%, South Korea 4.1%
Imports: $9.4 billion (FY93)
commodities; petroleum, consumer goods,
motor vehicles, industrial equipment
partners; Australia 21.1%, US 19,6%, Japan
14.7%, UK 6.3%, Germany 4.2%
External debt: $35.3 billion (March 1993)
Industrial production: growth rate 1.9%
(1990); accounts for about 20% of GDP
Electricity:
capacity; 8.000,000 kW
production; 31 billion kWh
consumption per capita; 9,250 kWh (1992)
Industries: food processing, wood and paper
products, textiles, machinery, transportation
equipment, banking and insurance, tourism,
mining
Agriculture: accounts for about 9% of GDP
and about 10% of the work force; livestock
predominates — wool, meat, dairy products all
export earners; crops — wheat, barley, potatoes,
pulses, fruits, vegetables; surplus producer of
farm products; fish catch reached a record
503,C){)0 metric tons in 1 988
Economic aid:
donor; ODA and OOF commitments
(1970-89), $526 million
Currency: I New Zealand dollar (NZ$) = l(K)
cents
Exchange rates: New Zealand dollars (NZ$)
per US$1 — 1.^771 (January 1994), 1.8495
(1993). 1.8584(1992). 1.7265(1991), 1.6750
(1990), 1.6711 (1989)
Fiscal year: 1 July — 30 June','f261b0a97dced7ac9f26aeaf9047d256d7a01f1c32ddb7c76b7b348b411926f5','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dde3b411411abb05fc8d19770fd65a63a21568f10adc440112ea46fd512c6f05',1994,'NI','Nicaragua','economy',718,'Overview: Since March 1 991. when President
CHAMORRO began an ambitious economic
stabilization program. Nicaragua has had
considerable success in reducing inflation and
obtaining substantial economic aid from
abroad. Annual inflation fell from more than
7.50% in 1991 to less than 5% in 1992. InHation
ruse again to an estimated 20% in 1993.
although this increase was due almost entirely
to a large currency devaluation in January. As
of early 1994. the government was clase to
finalizing an enhanced structural adju.stment
facility w ith the IMF. after the previous
standby facility expired in early 1993, Despite
the.se successes, achieving overall economic
growth in an economy scarred by misguided
economic values and civil war during the
1980s has proved elusive. Economic growth
was flat in 1992 and slightly negative in 1993,
Nicaragua''s per capita foreign debt is one of
the highest in the world; nonetheless, as of late
1993, Nicaragua was current on its post-1988
debt as well as on payments to the international
financial institutions. Definition of property
rights remains a problem; ownership disputes
over large tracts of land, businesses, and homes
confi.scated by the previous go\\ emnient have
yet to be resolved.
National product: GDP— purchasing power
equivalent — S6.4 billion { 1993 est.)
National product real growth rate; -0.5%
(1993 est.)
National product per capita: $ 1 .600 ( 1 993
est.)
Inflation rate (consumer prices); 20%
(1993 est.)
Unemployment rate: 1 3%; underemployment
.50% (1991)
Budget:
reiwm’.v.'' $375 million (1992)
expenditures; $410 million (1992), including
capital expenditures of S 1 1 5 million (1991 est.)
Exports: $228 million (f.o.b., 1992)
commiHiities; foodstuffs, cotton, coffee,
chemicals
partners; EC 26%, US 26% . Japan, Costa
Rica. El Salvador, Mexico (1992)
Imports; $907 million (c.i.f.. 1992)
commiHiities; petroleum, food, chemicals,
machinery, clothing
IHirtners; US 26%. Venezuela, Costa Rica. EC,
Guatemala (1992)
External debt: $10.5 billion ( 1992)
Industrial production; accounts for 20-25%
of GDP
Electricity:
capacity; 434,000 kW
production; 1.118 billion kWh
consumption per capita; 290 kWh (1992)
Industries: food processing, chemicals, metal
products, textiles, clothing, petroleum refining
and distribution, beverages, footwear
Agriculture: crops account for about 15% of
GDP: export crops — coffee, bananas,
sugarcane, cotton; food crops — rice. corn,
cassava, citrus fruit, beans; also pnxiuces a
variety of animal poxiucts — beef. veal. pork,
poultry, dairy products; normally
self-sufficient in food
288
A
link''ll drugs: trunsshipincul pttini for ciKuine
dcsoiKd for ihe US
Kconomtc «M:
m US coiniDiiinonts. including Ux-hu
(l-YTO-dl), S^20 million; Western (non-USt
countries. ODA and (K)K bilateral
cominiimcnls (IWI-S''J). $I„<8I billion
Currency: I gold cordoba tC’Sl = l(X)
centavos
Kxchuniie rates: gold cordobas (C''S) per
US$1— b 1 10 January IW). .t tW^); note-
gold cordoba replaced cordoba as Nicaragua''s
currency in IWI (exchange rtiie of old cordoba
had reached per USSI— ’.^.(KXl.tKK) bv Match
IWi)
Fiscal year; calendar year','2f6d410bcf3b95c6b3ac7391766797b0762e2f720c045550aada253adf72726a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3c9fb37850e8f419474faeed805e11cbd568a3d4449e4c58091f6f6abb7fae4',1994,'NE','Niger','economy',722,'OvervI iw: Niger’s economy is centered on
subsistence agriculture, animal husbandry, and
re-export trade, and increasingly less on
uranium, its major export throughout the 1970s
and 1980s. Uranium revenues dropped by
almost 50% between 1983 and 19%. Terms of
trade with Nigeria, Niger''s largest regional
trade partner, have improved dramatically
since the 50% devaluation of the African franc
in January 1994; this devaluation boosted
exports of livestock, peas, onions, and the
products of Niger''s small cotton industry. The
government relies on bilateral and multilateral
aid for operating expenses and public
investment, and is strongly induced to adhere
to structural adjustment programs designed by
the IMF and the World Bank.
National product: GDP — purchasing power
equivalent — $5.4 billion (IW3 est.)
National product real growth rate: 1 .9%
(1991 est.)
National product per capita: $650 ( 1 993
est.)
Inflation rate (consumer prices): 1.3%
(1991 est.)
Unemployment rate: NA%
Budget:
revenues: $193 million
expenditures: $355 million, including capital
expenditures of $106 million (1991 est.)
Exports: $294 million (f.o.b., 1991)
commodities: uranium ore 60%, livestock
products 20%. cowpeas, onions
partners: France 77%, Nigeria 8%, Cote
d''Ivoire, Italy
Imports: $346 million (c.i.f., 1991)
commodities: primary materials, machinery,
vehicles and parts, electronic equipment,
cereals, petroleum products, pharmaceuticals,
chemical products, foodstuffs
partners: Germany 26%, Cote d''Ivoire 1 1 %,
France 5%, Italy 4%, Nigeria 2%
External debt; $1.2 billion (December 1991
est.)
Industrial production: growth rate -2.7%
(1991 est.); accounts for 13% of GDP
Electricity:
capacity: 105.000 kW
production: 230 million kWh
consumption per capita: 30 kWh ( 1991 )
Industries: cement, brick, textiles, food
processing, chemicals, slaughterhouses, and a
few other small light industries; uranium
mining began in 1971
Agriculture: accounts for roughly 4()7r of
GDP and 90% of labor force: cash crops —
cowpeas, cotton, peanuts; food crops — millet,
sorghum, cassava, rice; livestock — cattle,
sheep, goats; self-sufficient in food except in
drought years
Economic aid:
recipient: US commitments, including Ex-Im
(FY70-89). $380 million; Western (non-US)
countries, ODA and OOF bilateral
commitments ( 1 970-89), $3. 1 65 billion; OPEC
bilateral aid (1979-89), $504 million;
Communist countries (1970-89), $61 million
Currency: I CFA franc (CFAF) = 100
centimes
Exchange rates: Communaute Financiere
Africaine francs (CFAF) per US$1 — 592.05
(January 1994). 283.16(1993), 264.69(1992),
282. 1 1 ( 199 1 ), 272.26 ( 1 990), 3 1 9.0 1 ( 1 989)
note: the official rate is pegged to the French
franc, and beginning 1 2 January 1 994, the CFA
franc was devalued to CFAF 1 00 per French
franc from CFAF 50 at which it had been fixed
since 1948
Fiscal year: I October — 30 September','a1abe64fad6492006da9215bf8223e7159101cff4b0c0d44824fd4ae803cc733','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc39af54e7ea7700c39fc7cb26fc246a4a13ab7e040e55abd3952e1444bc9f91',1994,'NU','Niue','economy',727,'Overview: The economy is heavily dependent
on aid from New Zealand. Government
expenditures regularly exceed revenues, with
the shortfall made up by grants from New
Zealand — the grants are used to pay wages to
public employees. The agricultural sector
consists mainly of subsistence gardening,
although some cash crops are grown for export.
Industry consists primarily of small factories to
process passion fruit, lime oil, honey, and
coconut cream. The sale of postage stamps to
foreign collectors is an important source of
revenue. The island in recent years has suffered
a serious loss of population because of
migration of Niueans to New Zealand.
National product: CNF — exchange rate
conversion — $2.1 million (1989 est.)
National product real growth rate: NA%
National product per capita: $ 1 ,000 ( 1 989
est.)
Inflation rate (consumer prices): 9.6%
(1984)
Unemployment rate: NA%
Budget:
revenues: $5.5 million
expenditures: $6.3 million, including capital
expenditures of $NA (1985 est.)
Exports: $175,274 (f.o.b., 1985)
commodities: canned coconut cream, copra,
honey, passion fruit products, pawpaw, root
crops, limes, footballs, stamps, handicrafts
partners: NZ 89%, Fiji, Cook Islands,','2e910e18fc941ec1ee65992ec3674b7546f0e2a5f52468f0ae29867da88cc119','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee7369fb2a41d9083eccb98617462429e932898eeb7a18feb81f34d7d4c7ccb1',1994,'NF','Norfolk Island','economy',728,'(territory of Australia)
1.6750(1990), 1.671 1 (1989)
Fiscal year: I April — 31 Murch','235d5fe6c1dde86b77487702cea8e21b4942fae50a7e46198027121ddb49accf','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cfed654e4ba61060cb4f01b415951ef19a8ea7668e3781545285e1071be47764',1994,'MP','Northern Mariana Islands','economy',739,'Overview: The economy benefits
substantially from financial assistance from the
US. The rate of funding has declined as locally
generated government revenues have grown.
An agreement for the years 1986 to 1992
entitled the islands to S228 million for capital
development, government operations, and
special programs. A rapidly growing major
source of income is the tourist industry, which
now employs about 50^(- of the work force.
Japanese tourists predominate. The agricultural
.sector is made up of cattle ranches and small
farms producing coconuts, breadfruit,
tomatoes, and melons. Industry is small scale,
mostly handicrafts and light manufacturing.
National product: GNP — purchasing power
equivalent — $541 million (1992)
note: GNP numbers refleci US spending
National product real growth rate: NA%
National prwtact per capita: $ll..500
(1992)
Inflation rate (conanmer pricca): 6.5-7 5%
(1991 est.)
Unempioynient rate: NA%
Budget;
revenues: $147 million
expenditures: $ 1 27.7 million, including capital
expenditures of $NA (1991 est.)
Exporta: $263.4 million (f.o.b. 1991 est.)
commodities; manufacturni goods, garments,
bread, pastries, concrete blocks, light iron work
pannets: NA
ImpiMla: $.392.4 million (c.i.f. 1991 e.st.)
commodities: food, construction, equipment,
materials
partners: NA
Extemaldebt: $0
Induattrial prodnctlon: growth rate NA%
Electricity:
capacity: 25,000 kW
production: 35 million kWh
consumption per capita: 740 kWh (1990)
Induatrles: tourism, construction, light
industry, handicrafts
Agricuitttre: coconuts, fruits, cattle.
vegetables
Economic aid: none
Currency: I United States dollar(US$)= 100
cents
Exchange ratex: US currency is used
Fiscal year: I October— .30 September','75c669e00d11c4830c36dcc4b49d88016eed10a362c7625e8211d40d6179ff24','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97b8b281836486cceffd43d909f9b1ed753eaafea9fe62a2c66ea202d621f33b',1994,'PH','Philippines','economy',747,'Overview: The economy consists primarily of
subsistence agriculture and fishing. Tourism
provides some foreign exchange, although the
remote location of Palau and a shortage of
suitable facilities has hindered development.
The government is the major employer of the
work force, relying heavily on financial
assistance from the US.
National product; GDP — purchasing power
equivalent — $3 1.6 million (1986)
note; GDP numbers reflect US spending
National product real growth rate: NA%
National product per capita: $2,260 (1986)
Inflation rate (consumer prices): NA%
Unemployment rate: 20% (1986)
Budget:
revenues; $6 million
expenditures; SNA, including capital
expenditures of SNA ( 1 986 est.)
Exports: $500,000 (f.o.b.. 1986)
commodities; trochus (type of shellfish), tuna.
copra, handicrafts
partners; US. Japan
Imports: $27.2 million (c.i.f, 1986)
commodities; NA
fkirtners; US
External debt; about $100 million (1989)
Industrial production: growth rate NA%
Electricity:
capacity; 16,000 kW
production; 22 million kWh
consumption per capita; 1 ,540 kWh (1990)
Industries: tourism, craft items (shell, wood,
pearl), some commercial fishing and
agriculture
Agriculture: subsistence-level production of
coconut, copra, cassava, sweet potatoes
Economic aid:
recipient; US commitments, including Ex-lm
(FY70-89). $2.56 billion; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $92 million
Currency: I United States dollar (US$)= 100
cents
Exchange rates: US currency is used
Fiscal year: 1 October — 30 September
Overview; The Pacific Ocean is a major
contributor to the world economy and
particularly to those nations its waters directly
touch. It provides low-cost sea transportation
between East and West, extensive fishing
grounds, offshore oil and gas fields, minerals,
and sand and gravel for the construction
industry. In 198.^ over half (.S49f'') of the
world’s fish catch came fnmi the Pacific
Ocean, which is the only tx''ean where the fish
catch has increased every year since 1978.
Exploitation of offshore oil and gas reserves is
playing an ever-increasing role in the energy
supplies of Australia, NZ, China, US, and Peru.
The high cost of recovering offshore oil and
gas, combined with the wide swings in world
prices for oil since I98.S. has slowed but not
stopped new drillings.
Industries: fishing, oil and gas prtxluciion
.302
Overview: no economic activity
Location: Central South America, between
Argentina ..nd Brazil
Map references: South America, Standard
Time Zones of the World
Area:
total area: 406,750 sq km
land area: 397,300 sq km
comparative area; slightly smaller than
California
Land boundaries: total 3,920 km, Argentina
1,880 km, Bolivia 750 km, Brazil 1,290 km
Coastline: 0 km (landlocked)
Maritime claims: none; landlocked
International disputes: short section of the
boundary with Brazil, just west of Salto del
Guaira (Guaira Falls) on the Rio Parana, has
not been determined
Climate: varies from temperate in east to
semiarid in far west
Terrain: grassy plains and wooded hills east
of Rio Paraguay; Gran Chaco region west of
Rio Paraguay mostly low, marshy plain near
the river, and dry forest and thorny scrub
elsewhere
Natural resources: hydropower, timber, iron
ore, manganese, limestone
Land use:
arable land; 20%
permanent emps; \\%
meadows and pastures: 39%
forest and woodland; 35%
other; 5%
Irrigated land: 670sqkm(l989est.)
Overview: Agriculture, including forestry,
accounts for about 25% of GDP, employs
about 45% of the labor force, and provides the
bulk of exports, led by soybeans and cotton.
Paraguay lacks substantial mineral or
petroleum resources but possesses a large
hydropower potential. Since 1981 economic
performance has declined compared with the
boom period of 1 976-8 1 , when real GDP grew
at an average annual rate of nearly 11%.
During the period 1982-86 real GDP fell in
three of five years, inflation jumped to an
annual rate of 32%, and foreign debt rose.
Factors re.sponsible for the erratic behavior of
the economy were the completion of the Itaipu
hydroelectric dam, bad weather for crops, and
weak export prices for agricultural
commodities. In 1987 the economy
experienced a minor recovery because of
improved weather conditions and stronger
international prices for key agricultural
exports. The recovery continued through 1990,
on the strength of bumper crops in 1988-89. In
a major step to increase its economic activity in
the region, Paraguay in March 1991 joined the
Southern Cone Common Maiket
(MERCOSUR), which includes Brazil,
Argentina, and Uruguay. In 1992, the
government, through an unorthodox approach,
reduced external debt with both commercial
and official creditors by purchasing a sizable
amount of the delinquent commercial debt in
the secondary market at a substantial discount.
The government had paid 100% of remaining
official debt arrears to the US, Germany,
France, and Spain. All commercial debt arrears
have been rescheduled. For the long run, the
government must press forward with general,
market-oriented economic reforms. Growth of
3.5% in 1993 was spurred by higher-than-
expected agricultural output and rising
international commodity prices. Inflation
picked up steam in fourth quarter 1993 because
of rises in public sector salaries and utility
rates.
Nitlonal product: GDP— purchasing power
311
Paraguay (continued)
Overview: Domestic output in this primarily
agricultural economy failed to grow in 1992
and rose only slightly in 1991. Drought and
power supply prtrblems hampered production,
while inadequate revenues prevented
government pump priming. Worker
remittances helped to supplement GDP. A
marked increase in capital goods imports,
particularly power generating equipment,
telecommunications equipment, and electronic
data pnxressors. contributed to 20% import
growth in brrth 1992 and 1991.
National product; GDP — purchasing power
equivalent — $171 billion (1991 est.)
National product real growth rate: 1 .4%
(1991 est.)
National product per capita: $2,S00 ( 1 991
est.)
Inflation rate (consumer prices): 7.6%
(1991)
Unemployment rate; 9.2% ( 1991)
Budget:
revenues: SI 1.5 billion
expenditures: Stl billion, including capital
expenditures of $1.7 billion ( 1994 est.)
Exports: $11.1 billion (f.o.b.. 1991 est.)
commodities: electronics, textiles, coconut
products, cooper, fi.sh
Ikirtners: US 19%, Japan 18%, Germany 5%.
UK 5%. Hong Kong 5% (1992)
Imports; $17.1 billion (f.o.b.. 1991 est.)
commodities; raw materials 40%, capital
goods 25%. petroleum products 10%
partners: Japan 21%. US 18%, Taiwan 7%,
Saudi Arabia 6%. Hong Kong 5%. South
Korea 5% ( 1992)
External debt: $.14. 1 billion (September
1991)
Industrial production: growth rate - 1 %
(1992 est.); accounts for 14% of GDP
Electricity:
capacity: 7.8.50,000 kW
production: 28 billion kWh
consumption per capita: 420 kWh ( 1992)
industries: textiles, pharmaceuticals,
chemicals, wood products, food processing,
electronics assembly, petroleum refining,
fishing
Agriculture; accounts for about 20% of GDP
and about 45% of labor force; major crops —
rice, coconuts, com. sugarcane, bananas,
pineapples, mangos; animal products — pi>rk,
eggs, lx;ef; net exporter of farm products: fish
catch of 2 million metric tons annually
Illicit drugs; illicit producer of cannabis for
the international drug trade; grtrwers are
producing more and better quality cannabis
despite government eradication efforts; transit
point for Southwest Asian heroin bound for the
US
Economic aid:
recipient: US commitments, including Ex-lm
(FY7()-89). $1.6 billion; Western (non-US)
countries, ODA and OOF bilateral
commitments ( 1970-88), $7.9 billion: OPEC
bilateral aid (1979-89), $5 million; Communist
countries ( 1975-89), $121 million
Currency: 1 Philippine peso (P)= 100
centavos
Exchange rates: Philippine pesos (P) per
US$ I —27.725 (January 1994). 22. 1 20 ( 1 991),
25.5 1 2 ( 1 992 ). 27.479 ( 199 1 ). 24.1 1 1 ( 1 990).
21.7.17(1989)
Fiscal year: calendar year
Overview; The inhabitants exist on fishing
and subsistence farming. The fertile soil of the
valleys produces a wide variety of fruits and
vegetables, including citrus, sugarcane,
watermelons, bananas, yams, and beans.
Bartering is an important part of the economy.
The major sources of revenue ate the sale of
postage stamps to collectors and the sale of
handicrafts to passing ships.
National product: GDP SNA
National product real growth rate: NA%
National product per capita: SNA
Inflation rate (consumer prices): NA9(>
Unemployment rate: NA%
Budget:
revenues: $430,000
expenditures: $429,000, including capital
expenditures of SNA ( 1 987 est.)
Exports: SNA
commodities: fruits, vegetables, curios
partners: NA
Imports: SNA
i''ommodities: fuel oil, machinery, building
materials, flour, sugar, other foodstuffs
partners: NA
External debt: SNA
Industrial production; growth rate NA%
Electricity:
capacity: 1 10 kW
production: 300,000 kWh
consumption per capita: 5,.360 kWh ( 1990)
Industries: postage stamp sales, handicrafts
Agriculture; based on subsistence fishing and
farming; wide variety of fruits and vegetables
grown; must import grain products
Economic aid:
recipient: ODA bilateral commitments (1992-
93), $84,000
Currency: I New Zealand dollar (NZ$) = 1 00
cents
Exchange rates: New Zealand dollars (NZ$)
per US$1 —1. 777 1 (January 1994). 1.8495
(199.3), 1.8584(1992). 1.7265(1991), 1.6750
(1990), 1.6711 (1989)
Fiscal year: 1 April — 31 March
Overview: Economic activity is limited to
commercial fishing. The proximity to nearby
oil- and gas-producing sedimentary basins
suggests the potential for oil and gas deposits,
but the region is largely unexplored, and there
are no reliable estimates of potential reserves;
commercial exploitation has yet to be
developed.
Industries: none
Overview: Industry — dominated by the last-
growing apparel industry — has surpassed
agriculture as the main source of export
earnings and accounts for over 16% of GDP.
The economy has been plagued by high rates of
unemployment since the late 1970s. Economic-
growth. which has been depressed by ethnic-
unrest, accelerated in 1991-93 as domestic
conditions began to improve and conditions for
foreign investment brightened.
National product: GDP — purchasing power
equivalent — $53.5 billion (1993 est.)
National product real growth rate: 5%
(1993 est.)
Overview: Taiwan has a dynamic capitalist
economy with considerable government
guidance of investment and foreign trade and
partial government ownership of some large
bunks and industrial firms. Real growth in
GNP has averaged about 99f a year during the
past three decades. Export growth has been
even faster and has provided the impetus for
industrialization. Agriculture contributes about
49''r to GDP. down from 35*7^ in 1952. Taiwan
currently ranks as number 13 among major
trading countries. Traditional labor-intensive
industries are steadily being replaced with
more capital- and technology-intensive
industries. Taiwan has become a major
investor in China. Thailand. Indonesia, the
Philippines, Malaysia, and Vietnam. The
tightening of labor markets has led to an influx
of foreign workers, both legal and illegal.
National product; GDP — purchasing power
equivalent — $224 billion (1993 est.)
National product real growth rate: 6%
(1993 est.)
National product per capita: $ 1 0,600 (1993
est.)
Inflation rate (consumer prices): 3.2%
(1993 est.)
Unemployment rate: 1.5% (1992 est.)
Budget:
revenues: $30.3 billion
expenditures: $30.1 billion, including capital
expenditures of SNA (1991 est.)
Exports: $85 billion (f.o.b., 1993 est.)
commodities: electrical machinery 19.7%,
electronic products 19.6%, textiles 10.9%,
footwear 3.3%, foodstuffs 1.0%, plywood and
wood products 0,9% (1993 est.)
partners: US 27.6%. Hong Kong 21.7%, EC
countries 15.2%, Japan 10.5% (1993 est.)
Imports: $77.1 billion (c.i.f.. 1993 est.)
commodities: machinery and equipment
15.7%, electronic products 15.6%. chemicals
9.8%, iron and steel 8.5%, crude oil 3.9%.
foodstuffs 2. 1 % ( 1993 est.)
partners: Japan 30.1%, US 21.7%. EC
countries 17.6% (1993 est.)
External debt: $620 million (1992 est.)
Industrial production: growth rate 3.6%
(1993 est.); accounts for more than 40% of
GDP
Electricity:
capacity: 1 8.382,000 kW
production: 98.5 billion kWh
consumption per capita: 4,7 1 8 kWh ( 1 992)
Industries: electronics, textiles, chemicals,
clothing, food processing, plywood, sugar
milling, cement, shipbuilding, petroleum
refining
Agriculture: accounts for 4% of GNP and
1 6% of labor force (includes part-time
farmers); heavily subsidized sector; major
crops — vegetables, rice, fruit, tea; livestock —
hogs, poultry, beef, milk; not self-.sufficient in
wheat, soybeans, corn; fish catch increasing,
reached 1,4 million metric tons in 1988
Illicit drugs: an important heroin transit
point; also a major drug money laundering
center
Economic aid;
recipient: US. including Ex-lm (FY46-82),
$4,6 billion; Western (non-US) countries.
ODA and OOF bilateral commitments ( 1970-
89), $500 million
Currency: I New Taiwan dollar (NTS) = 100
cents
Exchange rates; New Taiwan dollars per
US$1— 26.6 (1993). 25.4 (1992). 25.748
( 199 1 ). 27. 1 08 ( 1 990). 26.407 (1989)
Fiscal year: 1 July — 30 June','5835f3c9cd0efb31e8c1f36be4e310707e5ac5eff8f02a23e7aebf97afcd6866','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29cb654fc2b46254759f4176b89ddacc7f16bda5f97926a82e9011b8b881db36',1994,'PA','Panama','economy',756,'Overview: GDP expanded by roughly 5.9%
in 1993, following growth of 8% in 1992;
banking and financial services led the way in
1993. The economy thus continues to recover
from the crisis that preceded the ouster of
Manuel NORIEGA, even though the
government’s structural adjustment program
has been hampered by a lack of popular support
and a passive administration. F^blic
investment has been limited as the
administration has kept the fiscal deficit below
2% of GDP. Unemployment and economic
reform are the two major issues the new
government must face in 1994-95.
National product: GDP — purchasing power
equivalent — SI 1.6 billion (1993 est.)
National product real growth rate: 5.9%
(1993 est.)
National product per capita: $4,500 (1993
est.)
inflation rate (consumer prices): I % ( 1 993
est.)
Unemployment rate: 1 2.5% ( 1993 est.)
Budget:
revenues: $1.8 billion
expenditures; SI. 9 billion, including capital
expenditures of $200 million (1992 est.)
Exports: $545 million (f.o.b.. 1993 est.)
commodities; bananas 43%. shrimp 1 1%.
sugar 4%, clothing 5%, coffee 2%
partners: US 38%, EC. Central America and
Caribbean
Imports: $2.5 billion (f.o.b., 1993 est.)
commodities; capital goods 21%, crude oil
1 1 %. foodstuffs 9%, consumer goods,
chemicals
partners; US 35%. EC, Central America and
Caribbean, Japan
External debt: $6.1 billion (year-end 1993
est.)
Industrial production: growth rate 7.0%
(1993 est.); accounts for about 9% of GDP
Electricity:
capacity: 1.584,000 kW
production: 4.36 trillion kWh
consumption per capita: 720 kWh (1992)
Industries: manufacturing and construction
activities, petroleum refining, brewing, cement
and other construction material, sugar milling
Agriculture: accounts for 1 0% of GDP ( 1 992
est.), 27% of labor force (1992); crops —
bananas, rice, com, coffee, sugarcane:
live.stock: fishing: importer of food grain,
vegetables
Illicit drugs: major cocaine transshipment
point and drug money laundering center
Economic aid:
recipient; US commitments, including Ex-lm
(FY70-89). $516 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $582 million:
Communi.st countries (1970-89). $4 million
.307
Panama (continued)
Currency: I balboa (B) = 100 centesimos
Exchange rates: balboas (B) per U3$ I —
1.000 (fixed rate)
Fiscal year: calendar year','bb955b13652c5139c334ac929496324a21765e0a275fe28ef4d1f9308faa13ef','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29270448c3559a06932c272d2125510bd51dcc078529fe427b63ace068ff4b28',1994,'PG','Papua New Guinea','economy',762,'Overview: Papua New Guinea is richly
endowed with natural resources, but
exploitation has been hampered by the rugged
terrain and the high cost of developing an
infrastructure. Agriculture provides a
subsistence livelihood for 85% of the
population. Mining of numerous deposits,
including copper and gold, accounts for about
60% of export earnings. Budgetary support
from Australia and development aid under
World Bank auspices have helped sustain the
economy. Robust growth in 1991-92 was led
by the mining sector; the opening of a large
new gold mine helped the advance. The
economy remained strong in 1993, primarily
because of continued growth in the mining and
oil sectors.
National product: GDP — purchasing power
equivalent — $8.2 billion (1W3 est.)
National product real growth rate: 1 .2%
(1993 est.)
National product per capita: $2,000 (1993
est.)
Inflation rate (consumer prices): 4.5%
(1992-93)
Unemployment rate: NA%
Budget:
revenues: $1.33 billion
expenditures: $1.49 billion, including capital
expenditures of $225 million (1993 est.)
Exports: $1.3 billion (f.o.b., 1990)
commodities; gold, copper ore, oil, logs, palm
oil, coffee, cocoa, lob.ster
partners; Australia, Japan, South Korea, UK,
US
Imports: $1.6 billion (c.i.f., 1990)
commodities: machinery and transport
equipment, manufactured goods, food, fuels,
chemicals
partners: Australia, Japan, US. Singapore,
New Zealand, UK
External debt: $2.2 billion (April 1991)
Industrial production: growth rate 21 %
( 1 992): accounts for 3 1 % of GDP
Electricity:
capacity: 400,000 kW
production: 1 .6 billion kWh
consumption per capita: 400 kWh (1992)
Industries: copra crushing, palm oil
processing, plywood production, wood chip
production, mining of gold, silver, and copper,
construction, tourism
Agriculture: Accounts for 28% of GDP;
livelihood for 85% of population; fertile soils
and favorable climate permits cultivating a
wide variety of crops; cash crop.s — coffee,
cocoa, coconuts, palm kernels: other
products — tea, rubber, sweet potatoes, fruit,
vegetables, poultry, pork; net importer of food
for urban centers
Economic aid;
recipient; US commitments, including Ex-Im
(FY70-89), $40.6 million: Western (non-US)
countries, ODA and CX)F bilateral
commitments (1970-89), $6.5 billion; OPEC
bilateral aid (1979-89), $17 million
Currency: 1 kina (K) = 100 toea
Exchange rates: kina (K) per US$1 — 1.0281
(January 1994), 1.0221 (1993), 1 .0367 ( 1992),
1.0504(1991), 1.0467(1990), 1.1685(1989)
Fiscal year: calendar year','15b4d67b8806e472b72c1fec47ec04bec12faf1caad55378eaeaf943b51a0257','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('851aedb54ae85a5c08c5263a9a6a7840fa9a09493af15751cf567c24f34c0e91',1994,'PE','Peru','economy',764,'equivalent — $15.2 billion (1993 est.)
National product real growth rate: 3.5%
(1993 est.)
National product per capita: $3,000 ( 1 993
est.)
Inflation rate (consumer prices): 20.4%
(1993)
Unemployment rate: 11% (1993 est.)
Budget:
revenues: $1.2 billion
expenditures: $1.4 billion, including capital
expenditures of $487 million (1992 est.)
Exports: $728 million (f.o.b., 1993 est.)
commodities: cotton, soybean, timber,
vegetable oils, meat products, coffee, tung oil
partners; EC 37%, Brazil 25%, Argentina
10%, Chile 6%, US 6%
Imports: $ 1.38 billion (c.i.f., 1993 est.)
commodities; capital goods, foodstuffs,
consumer goods, raw materials, fuels
partners; Brazil 30%, EC 20%, US 18%.
Argentina 8%, Japan 7%
External debt: $1.2 billion (1993 est.)
Industrial production: growth rate 2.2%
(1991 est.); accounts for 20% of GDP
Electricity:
capacity; 5,257,000 kW
production: 16.2 billion kWh
consumption per capita: 3,280 kWh (1992)
Industries: mea: packing, oilseed crushing,
milling, brewing, textiles, other light consumer
goods, cement, construction
Agriculture: accounts for 26% of GDP and
44% of labor force: cash crops — cotton,
sugarcane, soybeans; other crops — com,
wheat, tobacco, cassava, fruits, vegetables;
animal products — beef, pork, eggs, milk;
surplus producer of timber; self-sufficient in
most foods
Illicit drugs: illicit producer of cannabis for
the international drug trade; important
transshipment point for Bolivian cocaine
headed for the US and Europe
Economic aid:
recipient: US commitments, including Ex-lm
(FY70-89), $ 1 72 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $1.1 billion
Currency: 1 guarani (G) = 100 centimos
Exchange rates: guaranies (0) per US$ —
1.861.3 (January 1994), 1,744.3(1993),
1.500.3 (1992), 447.5 (March 1992), 1,325.2
(1991). 1.229.8(1990), 1,056.2 (1989), 550.00
(fixed ri>'' 986-February 1989)
FIsr .1 1 y '' calendar year
.!! ■ .ns
Railroads: 970 km total; 440 km 1 .435-meter
standard gauge, 60 km 1 .000-meter gauge, 470
km various narrow gauge (privately owned)
Highways:
total; 28,300 km
paved; 2,600 km
unpaved; gravel 500 km; earth 25,200 km
Inland waterways: 3,100 km
Ports: Asuncion, Villeta, Ciudad del Este
Merchant marine: 13 ships (1,000 CRT nr
over) totaling 16,747 GRT/19,5 1 3 DWT, cargo
1 1 , oil tanker 2
note: I naval cargo ship is sometimes used
commercially
Airports:
total; 969
usable; 827
with permanent-surface runways: 7
with runways over i.659 m; 0
with runways 2,440-3,659 m; 5
with runways 1,220-2,439 m: 93
Telecommunications: meager telephone
service; principal switching center in
Asuncion; fair intercity microwave net; 78,300
telephones; telephone density — 16 telephones
per 1 ,000 persons; broadcast stations — 40 AM,
no FM, 5 TV, 7 shortwave; I Atlantic Ocean
INTELSAT earth station
Defense Forces
Branches: Army, Navy (including Naval Air
and Marines), Air Force
Manpower availability: males age 15-49
1,249,470; fit for military service 907.533;
reach military age (17) annually 53,126 (1994
est.)
Defense expenditures; exchange rate
conversion — $84 million, 1 .4% of GDP ( 1 988
est.)
Location: Western South America, bordering
the South Pacific Ocean between Chile and','7648814e0b48cadf4c74f5a8d5c0d830f840a21ef9fdcbb19f3d0fc8ff529321','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('275c61d7ba5a0a44c27adf774b59dcff2fc3c7a2055507c5d423635d6f7bef9c',1994,'PT','Portugal','economy',767,'Poland (continued)
extractive industries, chemicals, shipbuilding,
focxl processing, glass, beverages, textiles
Agriralturc: accounts for 7% of GDP and a
much larger share of labor force; 75% of output
from private farms, 25% from state farms;
productivity remains low by European
standards; leading European producer of rye,
rapeseed, and potatoes; wide variety of other
crops and livestock; major exporter of pork
products; normally self-sufficient in food
Illicil drugs: illicit producers of opium for
domestic consumption and amphetamines for
the international market; transshipment point
for Asian and Latin American illicit drugs to
Western Europe
Economic aid:
donor: bilateral aid to non-Communist less
developed countries (1954-89), $2.2 billion
recipient; Western governments and
institutions have pledged S8 billion in grants
and loans since 1989, but most of the money
has not been disbursed
Currency: I zloty (Zl) = 100 groszy
Exchange rates: zlotych (Zl) per US$1 —
21,080 (January 1994), 18,115(1993), 13,626
(1992), 1 0,576 (1 991), 9,500 (1 990), 1,439.18
(1989)
Fiscal year: calendar year
Conimunicallons
Railroads: 26,2.50 km total; 23,857 km 1.435-
meter gauge, 397 km 1.520-meter gauge, 1,996
km narrow gauge; 8,987 km double track:
1 1,510 km electrified; government owned
(1991)
Highways:
total: 360,629 km (excluding farm, factory and
forest roads)
paved; 220,000 km (220 km of which are
limited access expressways)
unpaved: 140,629 km (1988)
Inland waterways: 3,997 km navigable
rivers and canals ( 1991 )
Pipelines: natural gas 4.600 km, crude oil
1,986 km, petroleum products 360 km ( 1992)
Ports: Gdansk, Gdynia, Szczecin,
Swinoujscie; principal inland ports are Gli wice
on Kanal Gliwicki, Wrocaw on the Oder, and
Warsaw on the Vistula
Merchant marine: 1 73 ships ( 1 ,000 CRT or
over) totaling 2,327,855 GRT/3.458,445
DWT, short-sea passenger 5, cargo 57,
roll-on/roll-off cargo 8, container 8. oil tanker
I , chemical tanker 4, bulk 89, passenger I
note: Poland owns 3 ships operating under
Liberian registry
Airports:
total; 209
usable; 167
with pennanent-suiface runways; 70
with runway over 3,659 m; I
with runways 2,440-3,659 m; 47
with runways 1,060-2,439 m; 78
note; a C- 1 30 can land on a 1 .060-m airstrip
Telecommunications: severely
underdeveloped and outmoded system; cable,
open wire and microwave; phone density is
10.5 phones per 100 residents (October 1990);
3.6 million telephone subscribers; exchanges
are 86% automatic (1991); broadcast
stations — 27 AM, 27 FM, 40 (5 Soviet
repeaters) TV; 9.6 million TVs; 1 satellite earth
station using INTELSAT. EUTELSAT,
INMARSAT and Intersputnik
Defense Forces
Branches: Army, Navy, Air and Air Defense
Force
Manpower availability: males age 15-49
10,046,993; fit for military service 7,856,680;
reach military age ( 19) annually 3 1 6,339 ( 1 994
est.)
Defense expenditures: 30.8 trillion zlotych,
1 .8% of GNP ( 1 993 est.); note— conversion of
defense expenditures into US dollars using the
current exchange rate could produce
misleading results
Overview; Portugal''s economy registered
only 1.1% growth in 1992 and contracted by
0.4% in 1993, in contrast to the 4.5% average
of the fast-paced 1986-90 period. Recession in
the European Union, which accounts for 75%
of Portugal''s international trade, is the key
factor in the downturn. The government''s
long-run economic goal is the modernization
of Portuguese markets, industry, infrastructure,
and workforce in order to catch up with
productivity and income levels of the more
advanced EU countries, Per capita income now
equals only 55% of the EU average. The
government''s medium-term economic
objective is to be in the first tier of EU
countries eligible to join the economic and
monetary union (EMU) as early as 1997.
Economic policy in 1993 focused on reducing
inflationary pressures by lowering the fiscal
deficit, maintaining a stable escudo,
moderating wage increases, and encouraging
increased competition. Resumption of growth
in the short run depends on the revival of
growth in Europe as a whole, not a likely
prospect in the immediate future.
National product: GDP — purchasing power
equivalent — $91.5 billion (1993)
National product real growth rate: -0.4%
(1993)
National product per capita: $8,700(1993)
Inflation rate (consumer prices): 7% (1993
est.)
Unemployment rate: 7% (1993 est.)
Budget:
revenues; $27,3 billion
expenditures; $33,2 billion, including capital
expenditures of $4.5 billion (1991 est.)
Exports: $17.5 billion (f.o.b., 1993 est.)
commodities: cotton textiles, cork and paper
321
Portugal (continued)
Imports: $3 1 .5 million (f.o.b., 1992 est.)
commodities: machinery and electrical
equipment 44%, food piquets 1 8%, petroleum
11%
partners: Portugal, Japan, Spain, France.','e1c638c6f5f9b55c75160886d86e3d0829ae048dd78ec9ebeee3196165a2e0bf','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01f385c2953d5a946c50d37e953d57d4383b591a3ccc33664ecb128f3b6f633e',1994,'PR','Puerto Rico','economy',772,'(commonwealth associated with the US)
products, canned fish, wine, timber and timber
products, resin, machinery, appliances
partners: EC 75.4%, other developed countries
12.4%, US 3.8% (1992)
Imports: S28 billion (c.i.f., 1993 est.)
commodities; machinery and transport
equipment, agricultural products, chemicals,
petroleum, textiles
partners: EC other developed countries
10.9% less developed countries 12.9%, US
3.4%
External debt; $20 billion ( 1 993 est.)
Industrial production: growth rate 9. 1 %
( 1990); accounts for 40% of GDP
Electricity:
capacity: 6,624,000 kW
production: 26.4 billion kWh
consumption per capita; 2.520 kWh (1992)
Industries: textiles and footwear; wood pulp,
paper, and cork; metalworking; oil refining;
chemicals; fish canning; wine; tourism
Agriculture: accounts for 6. 1 % of GDP and
20% of labor force; small, inefficient farms;
imports more than half of food needs; major
crops — grain, potatoes, olives, grapes;
livestock sector — sheep, cattle, goats, poultry,
meat, dairy products
Illicit drugs: increasingly important gateway
country for Latin American cocaine entering
the European market; transshipment point for
hashish from North Africa to Europe
Economic aid;
recipient; US commitments, including Ex-Im
(FY70.89),$1.8 billion
Western (non-US) countries. ODA and OOF
bilateral commitments ( 1 970-89), $1,2 billion
Currency: I Portuguese escudo (Esc) = 100
centavos
Exchange rates: Portuguese escudos (Esc)
perUSSl— 176. 16 (January 1994), 160.80
(1993), 1.35.00(1992), 144.48(1991), 142,55
(1990), 157.46(1989)
Fiscal year: calendar year
Overview: Puerto Rico has one of the most
dynamic economies in the Caribbean region.
Industry has surpassed agriculture as the
primary sector of economic activity and
income. Encouraged by duty free access to the
US and by tax incentives, US firms have
invested heavily in Fhierto Rico since the
1950s, US minimum wage laws apply.
Important industries include pharmaceuticals.
electronics, textiles, petrochemicals, and
processed foods. Sugar production has lost out
to dairy production and other livestock
products as the main source of income in the
agricultural sector. Tourism has traditionally
been an important source of income for the
island, with estimated arrivals of nearly 3
million tourists in 1989. Unemployment
remains a severe problem at 18%.
National product: GNP — purchasing power
equivalent — $26.8 billion (1992 est.)
National product real growth rate: NA%
National product per capita: $7, 100 (1992
est.)
Inflation rate (consumer prices): 2.1%
(1992 est.)
Unemployment rate: 1 8% ( 1 993 est.)
Budget:
revenues: $5.8 billion
expenditures: $5.8 billion, including capital
expenditures of $258 million (1989 est.)
Exports: $21.8 billion (1992)
commodities: pharmaceuticals, electronics,
apparel, canned tuna, rum, beverage
concentrates, medical equipment, instruments
partners: US 88.3% (1990)
Imports: $14.8 billion (1992)
commodities: chemicals, clothing, food, fish,
petroleum products
partners: US 68.8% (1990)
External debt: SNA
Industrial production: growth rate 1.2%
(FY92)
Electricity:
capacity: 5,040,000 kW
production: 16.1 billion kWh
consumption per capita: 4,260 kWh ( 1 992)
Industries: manufacturing accounts for
55.5% of GDP: manufacturing of
pharmaceuticals, electronics, apparel, food
products, instruments; tourism
Agriculture: accounts for only 3% of labor
force and less than 2% of GDP; crops —
sugarcane, coffee, pineapples, plantains,
bananas; livestock — cattle, chickens; imports a
large share of food needs (1992)
Economic aid: none
Currency: 1 United States dollar (US$) = 100
cents
Exchange rates: US currency is use*.^
Fiscal year: 1 July — 30 June','173dc4129be9e2339ed3a66fa55a4b64b70b085a487f762e8cf45524cc20d2d4','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6aad3ea8ebb35dca0f780a3d1682c86eb9af93b685b2835b620934da4ddc5000',1994,'RO','Romania','economy',780,'commodities; manufactured goods, food,
beverages, tobacco, machinery and
transportation equipment, raw materials, and
petroleum products
partners; France, Mauritius, Bahrain, South
Africa, Italy
External debt: SNA
Industrial production: growth rate NA%;
about 25% of GDP
Electricity:
capacity; 245,000 kW
pi^uction; 750 million kWh
consumption per capita; 1 ,230 kWh (1991)
Industries: sugar, rum, cigarettes, several
small shops producing handicraft items
Agriculture: accounts for 30% of labor force;
dominant sector of economy; cash crops —
sugarcane, vanilla, tobacco; food crops —
tropical fruits, vegetables, com; imports large
share of food needs
Economic aid:
recipient; Western (non-US) countries, ODA
and OOF bilateral commitments (1970-89),
$14.8 billion
Currency: I French franc (F) = 100 centimes
Exchange rates: French francs (F) pur
US$1— 5.9205 (January 1994), 5.6632 (1993),
5.2938 (1992), 5.6421 (1991), 5.4453 (1990),
6.3801 (1989)
Fiscal year: calendar year','d74841b3b0af3fb990141c6a62ce98530768b2abca3140a7493a5562c70907ba','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f05974e8483afc21396826a1bc2f64f8371d67af6837922c5df8b243af10eb23',1994,'RW','Rwanda','economy',788,'Economic aid:
recipient; US commitments, including Ex-Im
(I9M-93), $13 biilion; other countries, ODA
and OOF bilaterai commitments (1988-93),
$115 billion
Currency: I ruble (R) = 100 kopeks
Exchange rates: rublesperUS$l — 1,247(27
December 1993), 415 (24 December 1992);
nominal exchange rate still deteriorating but
real exchange rate strengthening
Fiscal year; calendar year
Overview: Almost 50% of GDP comes from
the agricultural sector; coffee and tea make up
80-90% of total exports. The amount of fertile
land is limited, however, and deforestation and
soil erosion have created problems. The
industrial sector in Rwanda is small,
contributing only 1 7% to GDP. Manufacturing
focuses mainly on the processing of
agricultural products. TTie Rwandan economy
remains dependent on coffee/tea exports and
foreign aid. Weak international prices since
1986 have caused the economy to contract and
per capita GDP to decline. A structural
adjustment program with the World Bank
began in October 1990. Ethnic-based
insurgency in 1990-93 devastated wide areas
of the north and displaced hundreds of
thousands of people. A peace accord in mid-
1993 temporarily ended most of the fighting,
but massive resumption of civil warfare in
April 1994 in the capital city Kigali has been
taking thousands of lives and severely
damaging short-term economic prospects
National product: GDP — purchasing power
equivalent — $6.8 billion (1993 est.)
National product real growth rate: 1 .3%
(1992 est.)
National product per capita: $8(X) ( 1 993
est.)
Inflation rate (consumer prices): 9.5%
(1992 est.)
Unemployment rate: NA%
Budget:
revenues; $3.50 million
expenditures. $NA. including capital
expenditures of $NA (1992 est.)
Exports: $66.6 million (f.o.b.. 1992 est.)
commodities; coffee 63%. tea, cassiterite.
wolframite, pyrethrum
partners: Germany, Belgium, Italy. Uganda,
UK, France. US
Imports; $259.5 million (f.o.b., 1992 est.)
commodities: textiles, foodstuffs, machines
and equipment, capital goods, steel, petroleum
products, cement and construction material
partners; US, Belgium, Germany. Kenya,','c5f084e471c91b0edc5d1338c5b95e226db6f4b0a6bac1cac9ec4a2509c1d6a8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f1bbca6b62c523a5618905286826207cfba1348a91905d943a375521c6a5e8e',1994,'LC','Saint Lucia','economy',794,'manufactures, machinery, fuels
partners: US 36%, UK 17%, Trinidad and
Tobago 6%, Canada 3%. Japan 3%, OECS 4%
(1988)
External debt: $43.3 million (1992)
Industrial production; growth rate 1 1.8%
(1988 est.); accounts for 1 1% of GDP
Electricity;
copoc/''r)’.- 15,800 kW
production: 45 million kWh
consumption per capita: 1,120 kWh (1992)
I Industries: sugar processing, tourism, cotton,
I salt, copra, clothing, footwear, beverages
I Agriculture: accounts for 7% of GDP; cash
[ crop — sugarcane; subsistence crops — rice,
yams, vegetables, bananas; fishing potential
not fully exploited: most food imported
Illicit drugs: transshipment point for South
American drugs destined for the US
Economic aid:
I recipient: US commitments, incl''.- ling Ex-Im
* (FY85-88), $ 1 0.7 million; Western (iion-US)
countries, ODA and OOF bilateral
commitments (1970-89), $67 million
Currency: 1 EC dollar (EC$) = 100 cents
Exchange rates: East Caribbean dollars
(ECS) per US$1 — 2.70 (fixed rate since 1976)
Fiscal year; calendar year
Overview; Since 1983 the economy has
shown an impressive average annual growth
rate of almost 5% because of strong
agricultural and tourist sectors. Saint Lucia
also possesses an expanding industrial base
supported by foreign investment in
manufacturing and other activities, such as data
processing. The economy, however, remains
vulnerable because the important agricultural
sector is dominated by banana production,
which is subject to periodic droughts and
tropical storms. The economy exhibited
relatively strong growth in 1992-93 based on a
recovery of the agricultural and manufacturing
sectors and continued growth in construction
and tourism.
National product: GDP — exchange rate
conversion — $433 million (1993 est.)
National product real growth rate: 6.6%
(1992 est.)
National product per capita: $3,000(1993
est.)
Inflation rate (consumer prices): 5.1%
(1992)
Unemployment rate: NA
Budget:
revenues: $121 million
expenditures: $127 million, including capital
expenditures of $104 million (1992 est.)
Exports: $122.8 million (f.o.b., 1992)
commodities: bananas 60%, clothing, cocoa,
vegetables, fruits, coconut oil
partners: UK 56%. US 22%, CARICOM 19%
(1991)
Imports: $276 million (f.o.b.. 1992)
commodities: manufactured goods 21%,
machinery and transportation equipment 21%,
food and live animals, chemicals, fuels
partners: US 34%, CARICOM 17%, UK 14%,
Japan 7%, Canada 4% (1991)
External debt: $96.4 million (1992 est.)
Industrial production: growth rate 3.5%
(1990 est.); accounts for 12% of GDP
Electricity:
capacity: 32,500 kW
production: 112 million kWh
consumption per capita: 740 kWh ( 1 992)
Industries: clothing, assembly of electronic
components, beverages, corrugated cardboard
boxes, tourism, lime processing, coconut
processing
Agriculture: accounts for 14% of GDP and
43% of labor force; crops — bananas, coconuts,
vegetables, citrus fruit, root crops, cocoa;
imports food for the tourist industry
Illicit drugs: transit country for South
American drugs destined for the US and
Europe
Economic aid:
recipient: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-89),
$120 million
Currency: 1 EC dollar (ECS) = 100 cents
Exchange rates: East Caribbean dollars
(ECS) per US$1 — ^2.70 (fixed rate since 1976)','804e045b8b85a1cc1f7f3fea3eebefb30726b8691712a6703a0dcc7f62b0f21d','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f36c5c1bbc497ee008939df998ecf8281265cb5a3cb6f8ae37e7b276a7d3a34',1994,'PM','Saint Pierre and Miquelon','economy',805,'Overview: The inhabitants have traditionally
earned their livelihood by fishing and by
servicing fishing fleets operating off the coast
of Newfoundland. The economy has been
declining, however, because the number of
ships stopping at Saint Pierre has dropped
steadily over the years. In March 1989, an
agreement between France and Canada set fish
quotas for Saint Pierre''s trawlers fishing in
Canadian and Canadian-claimed waters for
three years. The agreement settles a
longstanding dispute that had virtually brought
fish exports to a halt. The islands are heavily
subsidized by France. Impoits come primarily
from Canada and France.
National product: GDP — exchange rate
conversion — $65 million (1992 est.)
National product real growth rate: NA%
National product per capita: $ 10,000 ( 1 992
est.)
Inflation rate (consumer prices): NA%
Unemployment rate: 9.6% (1990)
Budget;
revenues: $18.3 million
expenditures: $18.3 million, including capital
expenditures of $5.5 million (1989 est.)
Exports; $30 million (f.o.b., 1991 est.)
commodities: fish and fish products, fox and
mink pelts
partners: US 58%. France 17%, UK 1 1%,
Canada. Ponugal (1990)
Imports: $82 million (c.i.f., 1991 est.)
commodities: meat, clothing, fuel, electrical
equipment, machinery, building materials
partners: Canada, France, US, Netherlands,
UK
External debt: $NA
Industrial production; growth rate NA%
Electricity:
rapacity: 10,000 kW
production: 25 million kWh
consumption per capita: 3,840 kWh (1992)
339
(continued)
Industries; fish processing and supply base
for fishing fleets; tourism
Agriculture: vegetables, cattle, sheep, pigs
for local consumption; fish catch of 20,500
metric tons (1989)
Economic aid;
recipient: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-89),
$500 million
Currency: 1 French franc (F) = 100 centimes
Exchange rates: French francs (F) per
US$1— 5.9205 (January 1994), 5.6632 (1993),
5.2938 (1992), 5.6421 (1991), 5.4453 (1990),
6.3801 (1989)
Fiscal year: calendar year','73316e3390c67c7e60990217db47522e6d1ffa3d16f5a5e74b84fd8b15b70c7c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb863e6074ad2dc2053629cf67ae7f2e799f32a974872977216b44d4ac0079fa',1994,'VC','Saint Vincent and the Grenadines','economy',811,'Overview: Agriculture, dominated by banana
production, is the most important sector of the
economy, The services sector, based mostly on
a growing tourist industry, is also important.
The government has been relatively
unsuccessful at introducing new industries, and
high unemployment rates of 35%-4()%
continue.
National product: GDP — purchasing power
equivalent — $215 million (1492 est.)
National product real growth rate: 6.5%
(1992 est.)
National product per capita; $2.()()0 ( 1992
est.)
Inflation rate (consumer prices): 3.3%
(1993 est.)
Unemployment rate: 35%-40% ( 1992 est.)
Budget:
revenues: $62 million
expenditures: $67 million, including capital
expenditures of $2 1 million (1990 est.)
Exports: $77.5 million (f.o.b.. 1992)
coimnodities; bananas, eddoes and dasheen
(tai-o), arrowroot starch, tennis racquets
ptirtners; UK 54%, CARICOM 34%, US 10%
Imports; $1 18.6 million (f.o.b,, 1992)
commodities; fiKidstuffs, machinery and
equipment, chemicals and fertili/ers, minerals
and fuels
partners; US 36%, CARICOM 2 1 %, UK 1 8%.
Trinidad and Tobago 13%
External debt: $62.6 million ( 1 992)
Industrial production; growth rate 0%
( 1989); accounts for 8% of GDP
Electricity:
capacity; 16,600 kW
prtHluciion: 64 million kWh
consumption i>er capita; 555 kWh (1992)
Industries: food processing, cement,
furniture, clothing, .starch
Agriculture: accounts for 1 5% of GDP and
60% of labor force; provides bulk of exports;
product.s — bananas, coconuts, sweet potatoes,
spices; small numbers of cuttle, sheep, hogs,
gouts; small fish catch used locally
Illicit drugs: transshipment point for South
American drugs destined for the US and
Europe
Economic aid:
recipient; US commitments, including Ex-Im
(FY70-87), $1 1 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $81 million
Currency: I EC dollar (ECS) = 1 00 cents
Exchange rates: East Caribbean dollars
(ECS) per US$1 — 2,70 (fixed rate since 1976)
Fiscal year: calendar year
Airports:
total: 46
usable: 32
with permanent-surface runways: 7
with runways over J,639 in: 0
with runways 2,440-3,659 m: 6
with runways 1 ,060-2,439 m: 18
note: a C-1 30 can land on a 1 .060-m airstrip
Telecommunications: NA
Defense Forces
Branches: Army, Air and Air Defense Forces,
Civil Defense. Railroad Units
Manpower availability: males age 15-49
1,426,290; fit for military service 1,095,604;
reach military age (18) annually 48,695 (1994
est.)
Defense expenditures: 8.2 billion koruny,
NA% of GDP (1993 est. ): note — conversion of
defense expenditures into US dollars using the
current exchange rate could produce
misleading results
.357','95345b1bb52ff1a268d18392268901f8e7308bc39e7eb39530b9e81485dbe0d6','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a231ef66f94e20f9ecbc5d0163173575a029f320107561f09dc2c42e4167cac',1994,'SM','San Marino','economy',816,'Overview: The tourist sector contributes over
50% of GDP. In 1991 more than 3.1 million
tourists visited San Marino, 2.7 million of
whom were Italians. The key indusUies are
wearing apparel, electronics, and ceramics.
Main agricultural products are wine and
cheeses. The per eapita level of output and
standard of living are comparable to those of
Italy.
National product: GDP — purchasing power
equivalent — $370 million ( 1992 est.)
National product real growth rate: NA%
National product per capita: $ 1 6,000 ( 1 992
est.)
Inflation rate (consumer prices): 6.2%
(1992 e.st.)
Unemployment rate; 3% ( 1 99 1 )
Budget:
revenues: $275 million
expenditures: $275 million, including capital
expenditures of SNA ( 1 992 est.)
Exports: trade data are included with the
statistics for Italy; commodity trade consists
primarily of exchanging building stone, lime,
wood, chestnuts, wheat, wine, baked goods,
hides, and ceramics for a wide variety of
consumer manufactures
Imports: see exports
External debt: $NA
Industrial production: growth rate NA%;
accounts for 42% of workforce
342','dc297c6e66ef0c4bd0e4924d8c7b3a6bbbf73fa5a32ce84494c7a1ead1387aa8','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f26be8d064a1adbeba848b4e2b534bdac9b0df6b7519737bd59a81d6be4c7d0',1994,'ST','Sao Tome and Principe','economy',817,'Electricity: supplied by Italy
Industries; wine, olive oil, cement, leather,
textile, tourism
Agriculture; employs 3% of labor force;
products — wheat, grapes, maize, olives, meat,
cheese, hides; small numbers of cattle, pigs,
horses; depends on Italy for food imports
Economic aid: $NA
Currency: I Italian lire (Lit) = 100 centesimi;
note — also mints its own coins
Exchange rates: Italian lire (Lit) per
US$1— 1,700.2 (January 1994), 1,573.7
(1993), 1,232.4(1992), 1,240.6(1991),
1,198.1 (1990), 1,372.1 (1989)
Fiscal year: calendar year
Overview: The economy has remained
dependent on cocoa since the country gained
independence nearly 15 years ago. Since then,
however, cocoa production has gradually
deteriorated because of drought and
mismanagement, .so that by 1987 output had
fallen to less than 50% of its former levels. As
a result, a shortage of cocoa for export has
created a serious balance-of-payments
problem. Production of less important crops,
such as coffee, copra, and palm kernels, has
also declined. The value of imports generally
exceeds that of exports by a ratio of 4: 1 . The
emphasis on cocoa production at the expense
of other food crops has meant that Sao Tome
has to import 90% of food needs. It also has to
import all fuels and most manufactured goods.
Over the years, Sao Tome has been unable to
service its external debt, which amounts to
roughly 80% of export earnings. Considerable
potential exists for development of a tourist
industry, and the government has taken steps to
expand facilities in recent years. The
government also implemented a Five-Year
Plan covering 1986-90 to restructure the
economy and reschedule external debt service
payments in cooperation with the International
Development Association and Western
lenders.
National product: GDP — exchange rate-
conversion — $50 million (1990)
National product real growth rate: 1 .5%
(1992 est.)
National product per capita: $450 ( 1 990)
Inflation rate (consumer prices): 27%
(1992 est.)
Unemployment rate: NA%
Budget;
revenues; $10.2 million
expenditures; $36.8 million, including capital
expenditures of $22.5 million (1989 est.)
Exports: $5.4 million (f.o.b., 1992 est.)
commodities: cocoa 78%. copra, coffee, palm
oil
partners; Netherlands, Germany. China.','1f9d29d69412b77c97d720e62909bd936885eb4fa40bffce49a8e1ca9b02e7db','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5285c43bc3cb3039c78e28668d690d44c2851eca7a160d3c7f433a52c0c033e1',1994,'SN','Senegal','economy',824,'Overview: After 14 years of mixed
compliance with IMF and World Bank
economic reform programs, Senegal finds its
economy remains hostage to negative
economic forces. Declining terms of trade,
weather-related setbacks, and relentless growth
in population have held back overall growth
and left per capita incomes stagnant, if not
diminished. The economy continues to rely on
exports of fish, peanuts, and phosphates for
hard currency earnings. A 50% devaluation of
the African franc in January 1994 is likely to
lead to substantial increases in local currency
prices for producers that may spur improved
production. A sheltered import-substitution
sector, comprising textiles, shoes, and other
light manufacturing, will remain plagued,
however, by high labor, transportation, and
energy costs. Public finances face a decade-
long trend in declining tax revenues, making
the government increasingly dependent on
official development assistance from bilateral
donors.
National product: GDP — purchasing power
equivalent — $1 1.8 billion (1993 est.)
National product real growth rate: 1 .2%
(1991 est.)
National product per capita: $ 1 .400 ( 1 993
est.)
Inflation rate (consumer prices): -1.8%
(1991 est.)
Unemployment rate: NA%
Budget:
revenues: SI.2 billion
expenditures: $1.2 billion, including capital
expenditures of $269 million (1992 est.)
Exports: $904 million (f.o.b., 1991 est.)
commodities: fish, ground nuts, petroleum
products, phosphates, cotton
partners: France, other EC members. Cote
d''Ivoire, Mali
Imparts: $1.2 billion (c.i.f,, 1991 est.)
commodities: foods and beverages, consumer
goods, capital goods, petroleum
partners: France, other EC, Nigeria, Cote
d’Ivoire, Algeria, China, Japan
External debt: $2.9 billion (1990)
Industrial production: growth rate 1 .9%
(1991); accounts for 1 5% of GDP
Electricity:
capacity: 215,000 kW
production: 760 million kWh
consumption per capita: 100 kWh (1991)
347
Senegal (continued)
Serbia and Montenegro
Industries: agricultural and fish processing,
phosphate mining, petroleum refining,
building materials
Agriculture; accounts for 20% o^ GDP;
major products — peanuts (cash crop), millet,
com, sorghum, rice, cotton, tomatoes, green
vegetables; estimated two-thirds self-sufficient
in food; fish catch of 354,000 metric tons in
1990
Illicit drugs: transshipment point for
Southwest Asian heroin moving to Europe and
North America
Economic aid:
recipient: US commitments, including Ex-lm
(FY70-89), $551 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $5.23 billion; OPEC
bilateral aid (1979-89), $589 million;
Communist countries (1970-89), $295 million
Currency: 1 CFA franc (CFAF) = 100
centimes
Exchange rates: Communaute Financiere
Africaine francs (CFAF) per US$1 — 592.05
(January 1994), 283.16 (1993), 264.69 (1992),
282.11 (1991), 272.26 (1990), 319.01 (1989)
note: the official rate is pegged to the French
franc, and beginning 12 January 1994, the CFA
franc was devalued to CFAF 100 per French
franc from CFAF 50 at which it had been fixed
since 1948
Fiscal year: calendar year','7d009aceb272d09bd49d1257abc2bfde53cbc9a5594e1b149462906fcde203b2','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38a60d956ad0c6424a143d5c3e1df9b064bc4d5cc99fbe15586164abd096fe02',1994,'ME','Montenegro','economy',826,'Overview; The swift collapse of the Yugoslav
federation has been followed by bloody ethnic
warfare, the destabilization of republic
boundaries, and the breakup of important
interrepublic trade flows. Serbia and
Montenegro faces major economic problems;
349
Serbia and Montenegro (continued)
output has dropped sharply, particularly in
1993. First, like the other former Yugoslav
republics, it depended on its sister republics for
large amounts of foodstuffs, energy supplies,
and manufactures. Wide varieties in climate,
mineral resources, and levels of technology
among the republics accentuate this
interdependence, as did the communist
practice of concentrating much industrial
output in a small number of giant plants. The
breakup of many of the trade links, the sharp
drop in output as industrial plants lost suppliers
and markets, and the destruction of physical
assets in the fighting all have contributed to the
economic difficulties of the republics. One
singular factor in the economic situation of
Serbia and Montenegro is the continuation in
office of a communist government that is
primarily interested in political and military
mastery, not economic reform, A further
complication is the imposition of economic
sanctions by the UN.
National product: GDP — exchange rate
conversion — $10 billion (1993 est.)
National product real growth rate: NA%
National product per capita: $ 1 ,000 (1993
est.)
Inflation rate (consumer prices):
hyperinflation (1993)
Unemployment rate; more than 60% (1993
est.)
Budget:
revenues: SNA
expenditures; SNA, including capital
expenditures of SNA
Exports: $4.4 billion (f.o.b,, 1990)
commodities; machinery and transport
equipment 29%. manufactured go^s 28.5%,
miscellaneous manufactured articles 13.5%,
chemicals 11%, food and live animals 9%, raw
materials 6%, fuels and lubricants 2%.
beverages and tobacco I %
partners: prior to the imposition of sanctions
by the UN Security Council trade partners were
principally the other former Yugoslav
republics; Italy, Germany, other EC. the FSU
countries. East European countries, US
Imports: $6.4 billion (c.i.f., 1990)
commodities: machinery and transport
equipment 26%, fuels and lubricants 18%,
manufactured goods 16%. chemicals 12.5%,
food and live animals 1 1%. miscellaneous
manufactured items 8%. raw materials,
including coking coal for the steel industry 7%.
beverages, tobacco, and edible oils 1 ,5%
partners: prior to the imposition of sanctions
by the UN Security Council the trade partners
were principally the other former Yugoslav
republics; the FSU countries. EC countries
(mainly Italy and Germany). East European
countries. US
External debt: $4.2 billion (1993 est.)
Industrial production: growth rate -42%
(1993 est.)
Electricity:
capacity; 8.850.000 kW
production: 42 billion kWh
consumption per capita: 3.950 kWh (1992)
Industries: machine building (aircraft, tmeks,
and automobiles; armored vehicles and
weapons; electrical equipment; agricultural
machinery), metallurgy (steel, aluminum,
copper, lead, zinc, chromium, antimony,
bismuth, cadmium), mining (coal, bauxite,
nonferrous ore, iron ore, limestone), consumer
goods (textiles, footwear, foodstuffs,
appliances), electronics, petroleum products,
chemicals, and pharmaceuticals
Agriculture: the fertile plains of Vojvodina
produce 80% of the cereal production of the
former Yugoslavia and most of the cotton,
oilseeds, and chicory: Vojvodina also produces
fodder crops to support intensive beef and
dairy production; Serbia proper, although hilly,
has a well -distributed rainfall and a long
growing season; produces fruit, grapes, and
cereals; in this area, livestock production
(sheep and cattle) and dairy farming prosper;
Kosovo produces fruits, vegetables, tobacco,
and a small amount of cereals: the mountainous
pastures of Kosovo and Montenegro support
sheep and goat husbandry; Montenegro has
only a small agriculture sector, mostly near the
coast where a Mediterranean climate permits
the culture of olives, citrus, grapes, and rice
Illicit drugs: NA
Economic aid: $NA
Currency: I Yugoslav New Dinar (YD) =
1 00 paras
Exchange rates: Yugoslav New Dinars (YD)
per US $ I - 1 . 1 00.000 ( 1 5 June 1 993). 28. 230
(December 1991). 15.162(1990). 15.528
( 1 989). 0.70 1 ( 1 988). 0. 1 76 ( 1 987)
Fiscal year: calendar year','6623fa16c9c3dd4dd76a675318e75e9227d66525c5564a3362a36ab15b424a58','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5102819b5f9bd2a726278449faf83f3eff6b73fa88cae93d5a51cdd95d6192cf',1994,'SC','Seychelles','economy',833,'Overview; In this small, open, tropical island
economy, the tourist industry employs about
30% of the labor force and provides more than
70% of hard currency earnings. In recent years
the government has encouraged foreign
investment in order to upgrade hotels and other
services. At the same time, the government has
moved to reduce the high dependence on
351
Seychelles (continued)','e9aa853285d475bd1eb95e9897c6f71c5964e49e8a67d66ad7bcd170a537e425','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('347bf2411ee75719a307546854b7ef22b92e25cd331dface8f16195585f300ff',1994,'SL','Sierra Leone','economy',834,'tourism by promoting the development of
farming, fishing, and small-scale
manufacturing.
National product: GDP — exchange rate
conversion — $407 million (1992 est.)
National product real growth rate: 4%
(1992 est.)
National product per capita: $5,900 (1992
est.)
Inflation rate (consumer prices): 3.3%
(1992 est.)
Unemployment rate: 9% (1987)
Budget:
revenues; $172 million
expenditures; $181 million, including capital
expenditures of $48 million (1991 est.)
Exports: $47 million (f.o.b., 1992 est.)
commodities; fish, copra, cinnamon bark,
petroleum products (re-exports)
partners; UK 54% France 23%, Reunion 14%,
(1991)
Imports: $192 million (f.o.b., 1992 est.)
commodities: manufactured goods, food,
petroleum products, tobacco, beverages,
machinery and transportation equipment
partners: South Africa 13%, Singapore 12%,
UK 12% (1991)
External debt: $201 million (1992 est.)
Industrial production: growth rate 1 .3%
(1991); accounts for 1 2% of GDP
Electricity:
capacity; 30,(X)0 kW
production: 80 million kWh
consumption per capita; 1 , 1 60 kWh (1991)
Industries; tourism, processing of coconut
and vanilla, fishing, coir rope factory, boat
building, printing, furniture, beverage
Agriculture: accounts for 5% of GDP, mostly
subsistence farming; cash crops— coconuts,
cinnamon, vanilla; other products — sweet
potatoes, cassava, bananas; broiler chickens;
large share of food needs imported; expansion
of tuna fishing under way
Economic aid:
recipient: US commitments, including Ex-lm
(FY78-89), $26 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1978-89), $315 million; OPEC
bilateral aid (1979-89), $5 million; Communist
countries ( 1 970-89), $60 million
Currency: I Seychelles rupee (SRe) = 100
cents
Exchange rates: Seychelles rupees (SRe) per
US$1— 5.2681 (January 1994), 5. 1 8 15 (1993).
5. 1 220 ( 1 992). 5.2893 (1991), 5.3369 (1990).
5.6457(1989)
Fiscal year: calendar year','89da112ae5107808db73d4ffd5934ce123b27757d53fd6cd2537e09164e4cfb9','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2962fd7e42e470b824b37813d7b907c03ab6eebd4d1e0e8ee5f62e5d796175a',1994,'SG','Singapore','economy',841,'Overview: Singapore has an open
entrepreneurial economy with strong service
and manufaciuring sectors and excellent
internalionul trading links derived from its
entrepot history. The economy registered
nearly lO''/c growth in 1993 while stemming
inllulion. The construction and financial
services industries and manufacturers of
computer-related components have led
economic growth. Rising labor costs continue
to be a threat to Singapore''s competitiveness,
but there arc indications that productivity is
keeping up. In applied technology, per capita
output, investment, and labor discipline,
Singapore has key attributes of a developed
country.
National product: GDP — purchasing power
equivalent — $42.4 billion (1993)
National product real growth rate: 9.9%
(199.3)
National product per capita: $ 1 5,000 ( 1 993
est.)
Inflation rate (consumer prices): 2.4%
(1993)
Unemployment rate: 2.7% ( 1 993)
Budget:
revenues; $1 1 .9 billion
expenditures; $10.5 billion, including capital
expenditures of $3.9 billion (1994 est.)
Exports; $61.5 billion (f.o.b., 1992)
commodities; computer equipment, rubber and
rubber pnxlucts. petroleum pnxlucts,
telecommunications equipment
partners; US 21%, Malaysia 12%, Hong Kong
8%, Japan 8%. Thailand 6% (1992)
Imports; $66.4 billion (f.o.b.. 1992)
commodities; aircraft, petroleum, chemicals,
fixxlstuffs
partners; Japan 21%, US 16%, Malaysia 15%,
Saudi Arabia 5%, Taiwan 4%
External debt: $0; Singapore is a net creditor
Industrial production: growth rate 2.3%
(1992): accounts for 28% of GDP
Electricity;
capacity; 4,86(),(XX) kW
production; 18 billion kWh
consumption per capita; 6,420 kWh (1992)
Industries; petroleum refining, electronics,
oil drilling equipment, rubber prtKessing and
rubber prxxluct.s, processed food and
beverages, ship repair, entrepot trade, financial
services, biotechnology
Agriculture: iKcupies a position of minor
importance in the economy; self-sufficient in
poultry and eggs; must import much of other
fotxi; major crops — rubber, copra, fruit,
vegetables
Illicit drugs: transit point for Golden Triangle
heroin going to the US, Western Europe, and
the Third World; also a miijor money-
laundering center
Economic aid:
recipient; US commitments, including Ex-Im
(FY7()-83), $.590 million: We.stem (non-US)
countries, ODA and OOF bilateral
commitments ( 1970-89), $1 billion
Currency: 1 Singapore dollar (S$) = 1(H)
cents
Exchange rales: Singapore dollars (S$) per
U,S$ I— 1.6032 (Janu.try 1994). 1.6158(1993),
1.6290(1992). 1.7276(1991). 1.8125(1990),
1.9.503(1989)
Fiscal year: I April — 31 March','42c4a1e7f61202541132d85a3140ed1582f37bc204f398a9f98e654baf682fe4','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52eaaf7e268fb066a344bb3ae43677f70d47eabd7613f785920bb6a2df22f28c',1994,'SK','Slovakia','economy',846,'Overview: The dissolution of Czechoslovakia
into two independent states — the Czech
Republic and Slovakia — on I January 1 993 has
complicated the task of moving toward a more
open and decentralized economy. The old
Czechoslovakia, even though highly
industrialized by East European standards,
suffered from an aging capital plant, lagging
technology, and a deficiency in energy and
many raw materials. In January 1991,
approximately one year after the end of
communist control of Eastern Europe, the
Czech and Slovak Federal Republic launched a
sweeping program to convert its almost
entirely state-owned and controlled economy
to a market system. In 1991-92 these measures
resulted in privatization of some medium- and
small-scale economic activity and the setting
of more than 90% of prices by the market— but
at a cost in inflation, unemployment, and lower
output. For Czechoslovakia as a whole
inflation in 1991 was roughly 50% and output
fell 15%. In 1992 in Slovakia, inflation slowed
to an estimated 8.7% and the estimated fall in
GDP was a more moderate 7%. In 1993 GDP
fell roughly 5%. with the disruptions from the
separation from the Czech lands probably
accounting for half the decline; exports to the
Czech Republic fell about 35%. Bratislava
adopted an austerity program in June and
devalued its currency 10% in July. In 1993,
inllution rose an estimated 23%,
unemployment topped 14%, and the budget
deficit exceeded the IMF target of $485 million
by over $200 million. By yearend 1993
Bratislava estimated that 29%- of GDP was
being prtxluced in the private sector. The
forecast for 1994 is gloomy; Bratislava
optimistically projects no growth in GDP, I
unemployment, a $425 million budget deficit,
and 12% inllation. At be.st, if Slovakia stays on
track with the IMF, GDP could fall by only 2-
in 1994 and unemployineni could be held
under 18%, but a currency devaluation will
likely drive inllation above 15%''.
National product: GDP — purchasing power
equivalent — $31 billion (1993 est.)
National product real growth rate: -5%-
(1993 est.)
National product per capita: $5,800 ( 1993
est.)
Inflation rate (consumer prices): 23%-
( 1993 est.)
Unemployment rate: 14.4% ( 1993 est.)
Budget;
revenues: $4.5 billion
expenditures: $5.2 billion, including capital
expenditures of $NA (1993 est.)
Exports: $5. 13 billion (f.o.b., 1993 est.)
comtnodities: machinery and transport
equipment; chemicals; fuels, minerals, and
metals; agricultural products
partners: Czech Republic, CIS republics,
Germany, Poland, Austria, Hungary, Italy,
France, US, UK
Imports: $5.95 billion (f.o.b,, 1993 e.st.)
commodities: machinery and transport
equipment: fuels and lubricants; manufactured
goods; raw materials; chemicals; agricultural
products
partners: Czech Republic, CIS republics,
Germany, Austria, Poland, Switzerland,
Hungary, UK, Italy
External debt: $3.2 billion hard currency
indebtedness (31 December 1993)
Industrial production: growth rate -13.5%
(December 1993 over December 1992)
Electricity:
capacity: 6.800,000 kW
production: 24 billion kWh
consumption per capita: 4,550 kWh (1992)
Industries: brown coal mining, chemicals,
metal-working, consumer appliances,
fertilizer, plastics, armaments
Agriculture: largely self-sufficient in food
production; diversified crop and livestock
production, including grains, potatoes, sugar
beets, hops, fruit, hogs, cattle, and poultry;
exptirter of forest products
Illicit drugs: transshipment point fur
Southwest Asian heroin bound for Western
Europe
Economic aid:
donor: the former Czechoslovakia was a
donor— $4,2 billion in bilateral aid to non-
Communisl less developed countries (1954-
89)
Currency: 1 koruna (Sk) = 1(X) halierov
Exchange rates: koruny (Sk) per US$1 —
32.9 (December 1993), 28.59 (December
1992). 28.26 (1992). 29.53 (1991), 17.95
(1990). 15.05 ( 1989): note — values before
1993 reflect Czechoslovak exchange rate
Fiscal year: calendar year
Comm>inications
Railroads: 3,669 km total (1990)
Highways:
total: 1 7.6.50 km (1 990)
paved: NA
unpaved: NA
Inland waterways: NA km
Pipelines: natural gas 2.7(X) km: petroleum
products NA km
Ports: maritime outlets arc in Poland (Gdynia.
Gdansk, Szczecin). Croatia (Rijeka). Slovenia
(Koper). Germany (Hamburg, Rostock);
principal river fXJrts are Komarno on the
Danube and Bratislava on the Danube
Merchant marine: 19 ships ( l,(XX) GRT or
over) totaling 309,502 GRT/52 1, 997 DWT,
bulk 13, cargo 6; note — most under the flag of','b7eed92a2ad9ed273fd00fc0ba962f7f8be05bc54b1c6735a81ec1b991a3ae1d','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ac8d4ea074c70d422ce9f63b2e719bdf1c47cec3fcd23cf4c9916480c054034',1994,'SB','Solomon Islands','economy',853,'Overview: The bulk of the population depend
on subsistence agriculture, fishing, and forestry
for at least part of their livelihood. Most
manufactured goods and petroleum products
must be imported. The islands are rich in
undeveloped mineral re.iourccs such as lead,
zinc, nickel, and gold. The economy suffered
from a severe cyclone in mid- 1986 that caused
widespread damage to the infrastructure. In
1993. the government was working with the
IMF 10 develop a structural adjustment
program to address the country’s fiscal deficit.
National product: GDP — purchasing power
equivalent— $9()i) million (1991 est.)
National product real growth rate: 1 .8%
(1991 est.)
National product per capita: $2,500 (1991
est.)','6ab4ec51d6526a6d4b0cae521c16db8cbc49c18f1f363ecaf3c06fa616923178','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a207c9aa11333e184d5445fe09808c7c47397cf707aa87fc813d164c70bb4aaf',1994,'SO','Somalia','economy',854,'Inflation rate (consumer prices); 1 3%
(1992 est.)
Unemployment rate; NA%
Budget;
revenues: $48 million
expenditures: $107 million, including capital
expenditures of $45 million (1991 est.)
Exports: $84 million (f.o.b., 1991)
comnodities: fish 46%, timber 31%, palm oil
5%, cocoa, copra
partners: Japan 39%, UK 23%, Thailand 9%,
Australia 5%, US 2% (1991)
Imports; $1 10 million (c.i.f., 1991)
commodities: plant and machinery
manufactured goods, food and live animals,
fuel
partners: Australia 34%, Japan 16%,
Singapore 14%, NZ 9%
External debt; ... 1 28 million (1988 est.)
Industrial production; growth rate -3.8%
(199’. est.); accounts for 5% of GDP
Electricity:
capacity: 21,0(X) kW
production: 39 million kWh
consumption per capita: 1 15 kWh (1990)
Industries: copra, fish (tuna)
Agriculture: including fishing and forestry,
accounts for 31% of GDP; mostly subsistence
farming; cash crops — cocoa, beans, coconuts,
palm kernels, timber; other products — rice,
potatoes, vegetables, fruit, cattle, pigs; not self-
sufficient in food grains; 90% of the total fish
catch of 44,500 metric tons was exported
(1988)
Economic aid:
recipient: Western (non-US) countries, ODA
and OOF bilateral commitments (1980-89),
$250 million
Currency: I Solomon Islands dollar (SIS) =
100 cents
Exchange rates: Solomon Islands dollars
(SIS) per US$1— 3.2383 (November 1993),
2.928 1 ( 1 992), 2.7 1 48 ( 1 99 1 ), 2.5288 ( 1 990),
2.29.32(1989)
Fiscal year: calendar year
Overview: One of the world''s poorest and
least developed countries. Somalia has few
resources. Moret>vcr, much of the economy has
been devastated by the civil war. Agriculture is
the most important sector, with livestock
accoimling for abttut 40% of GDP and about
659r of export earnings. Nomads and
seminomads who are dependent upon livestock
for their liv elihoods make up more than half of
the population. Crop production generates only
10% of GDP and employs about 20% of the
work force. The main export crop is bananas;
sugar, sorghum, and com arc grown for the
domestic market. The small industrial sector is
based on the processing of agricultural
products and accounts for less than 10% of
GDP. Greatly increased political turmoil in
1991-93 has resulted in a substantial drop in
output, with widespread famine.
National product: GDP — purchasing power
equivalent — $3.4 billion (1993 est.)
National product real growth rate: NA%
National product per capita: $500 (1993
est.)
Inflation rate (consumer prices): 2 1 0%
(1989)
Unemployment rate: NA%
Budget:
revenues: SNA
expenditures: SNA. including capital
expenditures of SNA
Exports: $58 million (1990 est.)
commodities: bananas, live animals, fish, hides
partners: Saudi Arabia, Italy. FRG (1986)
Imports; $249 million (1990 est.)
commodities: petroleum products, foodstuffs.
construction materials
partners: US 13%. Italy. FRG, Kenya, UK.
Saudi Arabia (1986)
External debt: $ 1 .9 billion ( 1 989)
Industrial production: growth rate 0%
(1990), accounts for 4% of GDP
Electricity:
capacity: former 75,000 kW is almost
completely shut down by the destruction of the
civil war; UN. relief organizations, and foreign
military units in Somalia use their own portable
power systems
production: NA
consumption per capita: NA
Industries: a few small industries, including
sugar refining, textiles, petroleum refining;
probably shut down by the widespread
destruction during the civil war
Agriculture: dominant sector, led by
livestock raising (cattle, sheep, goats); crops —
bananas, sorghum, corn, mangoes, sugarcane;
not self-sufficient in food; distribution of food
disrupted by eivil strife; fishing potential
largely unexploited
Economic aid;
recipient: US commitments, including Ex-Im
(FY7()-89), $6.39 million; Western (non-llS)
countries, ODA and OOF bilateral
commitments ( 1970-89), $3.8 billion; OPEC
bilateral aid (1979-89), $1.1 billion;
Communist countries (1970-89). $336 million
Currency: I Somali shilling (So. Sh.) = 1(H)
cents
Exchange rates; Somali shillings (So. Sh.)
perUSSI— 2,6i6(l July 1993). 4,200
(December 1992). 3.800.00 (December 1990).
490.7(1989)
Fiscal year: calendar year','d589c2ae83ddd760a7299c47a305d8a08a4aab50b64b65b8ec95b1a435fcb13e','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f5ff755c16a24dd7e86ff22c8de8670fcb29f8f09e9ca0d248ca3a44e8736a8',1994,'SD','Sudan','economy',862,'National product per capita: $3,000 (1993
esi.)
Inflation rate (consumer prices): 1 1 .6%
(1992)
IJnemployment rate: 15% (1991 est.)
Budget:
revenues: $2.3 billion
expenditures: $3.6 billion, including capital
expenditures of $ 1 .5 billion ( 1 993)
Exports: $2.3 billion (f.o.b., 1992)
commodities; gannents and textiles, teas,
gems, petroleum products, coconuts, rubber,
other agricultural products, marine products,
graphite
partners; US 33.4%, Germany, UK,
Netherlands, Japan, France, Singapore (1992)
Imports: $3 billion (c.i.f, 1992)
commodities; food and bevemr s, textiles and
textile materials, petroleum and petroleum
products, machinery and equipment
partners; Japan, India, US 4.3%, UK,
Singapore, Germany, Hong King, Taiwan,
South Korea (1991)
External debt; $5,2 billion (1991)
Industrial production: growth rate 7% ( 1 99 1
est.): accounts for 16.5% of GDP
Electricity;
capacity; 1.300.000 kW
production; 3.6 billion kWh
consumption per capita; 200 kWh (1992)
Industries; processing of rubber, tea.
coconuts, and other agricultural commodities;
clothing, cement, petroleum refining, textiles,
tobacco
Agriculture: accounts for one-fourth of GDP
and nearly half of labor force; most important
staple crop is paddy rice; other field crops —
sugarcane, grains, pulses, oilseeds, roots,
spices; cash crops — tea, rubber, coconuts;
animal products — milk, eggs, hides, meat; not
self-sufficient in rice production
Economic aid:
recipient; US commitments, including Ex-lm
(FY70-89), $I billion; Western (non-US)
cou..tries, ODA and OOF bilateral
commitments (1980-89), $5.1 billion; OPEC
bilateral aid (1979-89), $169 million;
Communist countries (1970-89), $369 million
Currency: I Sri Lankan rupee (SLRe) = 100
cents
Exchange rates: Sri Lankan rupees (SLRes)
per US$1— 49,672 (January 1994), 48.322
(1993), 43.687 (1992). 41,372 ( 1991 ), 40,063
(1990), 36.047 (1989)
Fiscal year; calendar year
Overview: Sudan is buffeted by civil war,
chronic political instability, adverse weather,
high inflation, a drop in remittances from
abroad, and counterproductive economic
policies. The economy is dominated by
govemment.''il entities that account for more
than 70% of new investment. The private
sector''s main areas of activity are agriculture
and trading, with most private industrial
inve.stment predating 1980. The economy’s
base is agriculture, which employs 80% of the
work force. Industry mainly processes
agricultural items. Sliiggi.sh economic
performance over the past decade, attributable
largely to declining annual rainfall, has
reduced levels of per capita income and
consumption. A large foreign debt and huge
arrearages continue to cause difficulties. In
1990 the International Monetary Fund took the
unusual step of declaring Sudan
noncooperative because of its nonpayment of
arrearages to the Fund. The government
implemented a comprehensive economic
reform program in 1992 that included slashing
the fiscal deficit, liberalizing foreign exchange
regulations, and lifting most price controls, but
it had backtracked on most reforms by mid-
1 993 because of its fear of generating a
domestic backlash. The government''s failure
to pursue economic reform, its continued
prosecution of the civil war. and its growing
international isolation have led to a further
deterioration of the non-agricultural sectors of
the economy during 1993. Agriculture, on the
other hand, after several disappointing years,
enjoyed favorable growing conditions in 1993,
and its strong performance pnxiuced an overall
growth rate in GNP of about 7%,
National product; GDP — purchasing power
372','54dccd1dfb8b96e7212acbcd96aa520bf50bd32459e1d54272173d4223091fdb','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52ae0f10d5732eca1982a18bd7e6099597bb9142600f03dc7ba028fa10ef4970',1994,'SR','Suriname','economy',867,'equivalent — $21,5 billion (1993 est.)
National product real growth rate: 7%
(FY93 est.)
National product per capita: $750 (1993
est.)
Inflation rate (consumer prices); 105%
(FY93 est.)
Unemployment rate: 30% (FY93 est.)
Budget:
revenues: $374.4 million
expenditures: $ 1 .2 billion, including capital
expenditures of $214 million (1993 est.)
Exports: $3.50 million (f.o.b., FY93 est.)
commodities: cotton 52%, se.same, gum arable,
peanuts
partners: Western Europe 46%. Saudi Arabia
14%, Eastern Europe 9%, Japan 9%, US 3%
(FY88)
Imports; $1.1 billion (c.i.f,, FY93 est.)
commodities: foodstuffs, petroleum products,
manufactured goods, machinery and
equipment, medicines and chemicals, textiles
IHirtners: Western Europe 32%, Africa and
Asia 15%. US 13%, Eastern Europe 3%
(FY88)
External debt: $17 billion (June 1993 e.st.)
Industrial production: growth rate 6.8%
(FY93 est.): accounts for 1 1% of GDP (FY92)
Electricity;
capacity: 610,000 kW
pt^uction: 905 million kWh
consumption per capita: 40 kWh (1991)
Industries: cotton ginning, textiles, cement,
edible oils, sugar, soap distilling, shoes,
petroleum refining
Agriculture; accviunts for 35% of GDP and
80% of labor force; water shortages: two-thirds
of land area suitable for raising crops and
livestock; major products — cotton, oilseeds,
sorghum, millet, wheat, gum arable, .sheep;
marginally self-sufficient in most foods
Economic aid: .
recipient: US commitments, including Ex-Im
(FY70-89), $1.5 billion; Western (non-US)
countries, ODA and OOF bilateral
commitments ( 1970-89), $5. 1 billion; OPEC
bilateral aid (1979-89), $3. 1 billion;
Communist countries (1970-89), $588 million
Currency: I Sudanese pound (£Sd)= 100
piastres
Exchange rates: official rate — Sudanese
pounds (£Sd) per US$1 — 215 (January 1994),
333.3 (December 1993), 90.1 (March 1992),
5.4288 (1991). 4,5(X)4 (fixed rate since 1987);
note — the commercial rate is 300 (January
1994)
Fiscal year; 1 July — 30 June
paved; bituminous treated 2,000 km
unpaved: gravel 4,000 km; improved earth
2,304 km; unimproved earth 12,399 km
Inland waterways; 5,310 km navigable
Pipelines: refined products 815 km
Ports: Port Sudan, Sawakin
Merchant marine: 10 ships ( 1 ,00O GRT or
over) totaling 89,842 GRT/1 22,379 DWT,
cargo 8, roll-on/roll-off cargo 2
Airports:
total: 70
usable: 58
with permanent-surface runways: 9
with runways over J,6S9 m: 0
with runways 2,440-3,659 m: 7
with runways 1,220-2,439 m: 29
Telecommunications: large, well-equipped
system by African standards, but barely
adequate and poorly maintained by modem
standards; consists of microwave radio relay,
cable, radio communications, troposcatter, and
a domestic satellite system with 14 stations;
broadcast stations — 1 1 AM, 3 TV; satellite
earth stations for international traffic — I
Atlantic Ocean INTELSAT and 1 ARABSAT
Defense Forces
Branches; Army, Navy, Air Force
Manpower availability: males age 15-49
6,640, 1 23; fit for military service 4,080,7 1 5;
reach military age ( 1 8) annually 305.885 ( 1 994
est.)
Defense expenditures; exchange rate
conversion — $339 million, 2.2% of GDP
(1989 e.st.)
Overview: The economy is dominated by the
bauxite industry, which accounts for 15% of
GDP and about 70% of export earnings. The
economy has been in trouble since the Dutch
ended development aid in 1982. A drop in
world bauxite prices which started in the late
1970s and continued until late 1986 was
followed by the outbreak of a guerrilla
insurgency in the interior that crippled the
important bauxite sector. Although the
insurgency has since ebbed and the bauxite
sector recovered, Paramaribo has failed to
initiate the economic reforms necessary to
stabilize the economy or win renewed Dutch
aid disbursements. High inflation, high
unemployment, widespread black market
activity, and hard currency shortfalls continue
to mark the economy.
National product: GDP — purchasing power
equivalent — $1.17 billion (1993 est.)
National product cal growth rate: -0.3%
(1993 est.)
National product per capita: $2,800 (1993
est.)
Inflation rate (consumer prices): 1 09%
(1993 est.)
Unemployment rate: 16,5% (1990)
Budget:
revenues: $466 million
expenditures: $716 million, including capital
expenditures of $123 million (1989 est.)
Exports: $290 million (f.o.b., 1993 est.)
commodities: alumina, aluminum, shrimp and
fish, rice, bananas
partners: Norway 33%, Netherlands 26%, US
13%, Japan 6%, Brazil 6%. UK 3% (1992)
Imports: $250 million (f.o.b., 1993 est.)
commodities: capital equipment, petroleum,
foodstuffs, cotton, consumer goods
partners: US 42%, Netherlands 22%, Trinidad
374
Svalbard
(territory of Norway)
and Tobago !0%, Brazil 5% (1992)
External debt: $''80 million (March 1993
est.)
Industrial production; growth rate -5.0%
(1991 est.); accounts for 27% of GDP
Electricity:
capacity: 458,000 kW
production; 2.018 biliion kWh
consumption per capita: 4,920 kWh (1992)
Industries: bauxite mining, alumina and
aluminum production, lumbering, food
processing, fishing
Agriculture: accounts for 10.4% of GDP and
25% of export earnings; paddy rice planted on
85% of arable land and represents 60% of total
farm output; other products— bananas, palm
kernels, coconuts, plantains, peanuts, beef,
chicken; shrimp and forestry products of
increasing importance; self-suffi’^ient in most
foods
Economic aid:
recipient; US commitments, including Ex-Im
(FY70-83), $2.5 billion; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $1.5 billion
Currency: 1 Surinamese guilder, gulden, or
florin (Sf.) = ItX) cents
Exchange rates: Surinamese guilders,
gulden, or florins (Sf.) per US$1 — 1 .7850
(fixed rate); parallel rate 109 (January 1994)
Fiscal year: calendar year
Overview: Coal mining is the major
economic activity on Svalbard. By treaty (9
February 1920), the nationals of the treaty
powers have equal rights to exploit mineral
deposits, subject to Norwegian regulation.
Although US, UK, Dutch, and Swedish coal
companies have mined in the past, the only
companies still mining are Norwegian and
Russian. The settlements on Svalbard are
essentially company towns. The Norwegian
state-owned coal company employs nearly
60% of the Norwegian population on the
island, runs many of the local services, and
provides most of the local infrastructure. There
is also some trapping of seal, polar bear, fox,
and walrus.
Budget:
revenues; $13.3 million
expenditures: $13.3 million, including capital
expenditures of $NA (1990 est.)
Electricity:
capacity: 2 1 ,000 kW
production: 45 million kWh
consumption per capita: 13,860 kWh (1992)
Currency: 1 Norwegian krone (NKr) = 100
oere
Exchange rates: Norwegian kroner (NKr)
per US$1— 7.4840 (January 1994), 7.0941
(1993), 6.2145 (1992), 6.4829 (1991), 6.2597
(1990), 6.9045(1989)','7a86221aa2b3c546f6477dde69d2847db2944bac69311f790fd8d5de758c81a2','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('37932c3429dd45b6a15b88c3a07404212e84129ef9548388f63450ac6703ee72',1994,'TJ','Tajikistan','economy',874,'Overview; Tajikistan had the lowest per
capita GDP in the former USSR, the highest
rate of population growth, and the lowest
standard of living. Its economy at the start of
1 994 is producing at roughly the 1 989 level and
faces urgent reconstruction tasks from the 1992
civil war. Tajikistan''s economy was severely
disrupted by the breakup of the Soviet
economy, which provided guaranteed trade
relations and heavy subsidies and in which
specialized tasks were assigned to each
republic. Its economy is highly agricultural
(43% of the work force); it has specialized in
growing cotton for export and must import a
large share of its food. Its industry ( 1 4% of the
work force) produces aluminum, hydropower,
machinery, and household appliances. Nearly
all petroleum products must be imported.
Constant political turmoil and continued
dominance of former Communist officials
have slowed the process of economic reform
and brought near economic collapse while
limiting foreign assistance. Tajikistan is in the
midst of a prolonged monetary crisis in which
it is attempting to continue to use the Russian
ruble as its currency while its neighbors have
switched to new independent currencies;
Russia is unwilling to advance sufficient rubles
without attaching stringent reform conditions.
National product: GDP— purchasing power
equivalent— $6.9 billion (1993 estimate from
the UN International Comparison Program, as
extended to 1991 and published in the World
Bank’s World Development Report 1993; and
as extrapolated to 1993 using official Tajik
statistics, which are very uncertain because of
major economic changes since 1 990)
National product real growth rate: -21%
(1993c.st.)
National product per capita: S 1 , 1 80 ( 1 993
e.st.)
Inflation rate (consumer prices): 38% per
month (1993 average)
Unemployment rate: 1.1% includes only
officially registered unemployed; also large
numbers of underemployed workers an :
unregistered unemployed people
Budget:
revenues: SNA
expenditures: SNA, including capital
expenditures of SNA
Exports: S263 million to outside the FSU
countries (1993)
commodities: cotton, aluminum, fruits,
vegetable oil, textiles
partners: Russia, Kazakhstan. Ukraine,
Uzbekistan, Turkmenistan
Imports: $371 million from outside the FSU
countries (1993)
commodities: fuel, chemicals, machinery and
transport equipment, textiles, t''oodstuffs
partners: Russia. Uzbekistan, Kazakhstan
External debt: SNA
Industrial production: growth rate -20%
(1993 est.)
Electricity:
capacity: 4,585,0(X) kW
production: 16.8 billion kWh
consumption per capita: 2,879 kWh (1992)
Industries: aluminum, zinc, lead, chemicals
and fertOizers, cement, vegetable oil, metal¬
cutting machine tools, refrigerators and
freezers
Agriculture: cotton, grain, fruits, grapes,
vegetables; cattle, sheep and goats
Illicit drugs: illicit cultivation of cannabis
and opium poppy; mostly for CIS
consumption; limited government eradication
programs; used as transr'' pment points for
illicit drugs from Southwest Asia to Western
F.urope and North America
Economic aid:
recipient: Russia reportedly provided
substantial general assistance throughout 1 993
and continues to provide assistance in 1994;
Western aid and credits promised through the
end of 1993 were $700 million but
disbursements were only $104 million; large
scale development loans await IMF approval
of a reform and stabilization plan
Currency: I ruble (R) = 100 kopeks;
acquiring new Russian rubles as currency
under December 1993 agreement
Exchange rates: NA
Fiscal year: calendar year','046284106773e2d537fbbc9803ad4e98ac97caf4eacc2bbc73ec31f01468e110','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3574efbd31a9fdd54a4e6b08ad1ce2607c089bbe74482a08c8569c36e1d03f1',1994,'TG','Togo','economy',879,'coal, metallic chiomium, lead. line, and
fcimnickel; light industry produces basic
textiles, wood products, and tobacco
Ayitiiltitw: provides l2%afGDPandmecis
the bask needs for food; principal crops are
rke. tobacco, wheat, com, and millet: also
grown are cotton, sesame, mulbetTy leaves,
dtius finiit. and vegetables; The Fomer
Yugoslav Republ''c of Macedonia is one of the
seven legal cuhivmors of the opium poppy for
the world pharmaceutical industry, including
some exp^ to the US: agricultural
production is highly IkMr intensive
IMcitdrnie: limited iilkii opium cultivation:
transshipment point for Asian heroin
recipient: US $10 million (for humaniuuian
and technical assistance)
EC promised a 100 ECU million economk aid
package ( 1993)
Currency: the denar, which was adopted by
the Macedonian legislature 26 April 1992, was
initially issued in the form of a coupon pegged
to the German mark; subsequently repegged to
a basket of seven currencies
Exchange rates: denar per US$1 — 865
(Octooer 1992)
Fiscal year: calendar year
ConununkatioM
flallraads: NA
Highways:
total: 10,591 km
paved: 5.091 km
unpaved: gravel 1.404 km; earth 4,096 km
(1991)
laland waterways: NA km
Pipelines: none
Porta: none; landlocked
Airports:
total: 16
usable: 16
with permanent-surface runways: 10
with runways over 3,659 m: 0
with runways 2,440-3.659 m: 2
with runways i. 220-2,439 m: 2
Teteconununications: 125,000 telephones;
broadca.st stations — 6 AM. 2 FM. 5 (2 relays)
TV; 370.000 radios. 325,000 TV; satellite
communications ground stations — none
Defense Forces
Branches: Army, Navy, Air and Air Defense
Force, Police Force
Manpower availabflity: males age 15-49
604,257; fit for military service 489.746; reach
military age (19) annually 19,539 (1994 est.)
Defense expenditures: 7 billion denars,
NA% of GNP ( 1 993 est.); note — conversion of
the military budget into US dollars using the
prevailing exchange rate could produce
misleading results','3caf835253e6de8ec7ca034e22f488546eb97eaf750d0ce95fe65d5dafe1211a','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48a70a4bc19011c0a9bbc50d2f2b834eedc6c8d3fd3211684dfe2ebb14ff0e3c',1994,'TM','Turkmenistan','economy',886,'Overview: Turkmenistan is a largely desert
country with nomadic cattle raising, intensive
agriculture in irrigated oases, and huge gas and
oil resources. Half of its irrigated land is
planted in cotton; it is the world’s tenth largest
producer. It also is the world’s fourth largest
producer of natural gas and has the fifth largest
reserves. Furthermore, Turkmenistan has
substantial oil resources; its two oil refineries
make it an exporter of refined produets.
Profiting from the move toward market prices
for its oil and gas resources. Turkmenistan has
suffered the least economic decline of the 15
states of the former USSR. With an
authoritarian ex-Communist regime in power
and a tribally based social structure,
Turkmenistan has taken a cautious approach to
questions of economic reform, using the profits
from its gas and cotton exports to sustain a
generally inefficient economy. Economic
restructuring and privatization have just begun,
and price liberalization and price increases
have been accompanied by generous wage
hikes and subsidies. At the same time,
Turkmenistan faces serious constraints on its
g.as and oil earnings because of the inability of
its traditional regional customers to pay for the
■urrent level of purchases and the lack of
p ''Kline access to hard currency markets.
Faced with financial shortfalls, rampant
inflation, and the desire to ensure a stable
currency, the regime has become more
receptive to market reforms yet still seeks to
offer widespread social benefits to its
population and to retain state domination over
the economy.
National product: GDP — purchasing power
equivalent — $13 billion (1993 estimate from
the UN International Comparison Program, as
extended to 1991 and published in the World
Bank’s World Development Report 1993; and
as extrapolated to 1993 using official Turkmen
statistics, which are very uncertain because of
major economic changes since 1990)
National product real growth rate: 7.8%
(1993es''.)
National product per capita; $3,330 ( 1 993
est.)
Inflation rate (consumer prices): 45% per
month (1993 est.)
Unemployment rate: 2.9% ( 1992 est.);
includes only officially registered
unemployed; also large number of
underemployed
Budget:
revenues; SNA
expenditures; SNA, including capital
expenditures of SNA
Exports; $1.2 billion to slates outside the PSU
(1993)
commodities; natural gas, cotton, petroleum
products, textiles, carpets
partners; Ukraine, Russia, Kazakhstan,
Uzbekistan, Georgia, Eastern Europe, Turkey,','acef82106dfe627aa3f19f7443a308aa1c8c330423eccbe99547521ab38c1302','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b59b876eaee4941d6d6607419e18b42975bb3610da67d757b56e5e9f750bbc83',1994,'TC','Turks and Caicos Islands','economy',892,'Overview: The economy is based on fishing,
tourism, and offshore banking. Only
subsistence farming — com, cassava, citrus,
and beans — exists on the Caicos Islands, so
that most foods, as well as nonfood products,
must be imported.
National product: GDP — purchasing power
equivalent — S80.8 million (1992 est.)
National product real growth rate: - 1 .5%
(1992)
National product per capita: $6,(XX)(I992
est.)
Inflation rate (consumer prices): NA9Ii
Unemployment rate: 12% (1992)
Budget:
revenues: S20.3 million
expenditures; $44 million, including capital
expenditures of $23.9 million (1989 est.)
Exports: $6.8 million (f.o.b., 1992)
commodities; lobster, dried and fresh conch,
conch shells
partners; US, UK
Imports: $4X8 million (1992)
commodities; food and beverages, tobacco,
clothing, manufactures, construction materials
partners; US, UK
Externa) debt; $NA
Industrial production: growth rate NA%
Electricity:
capacity; 9,050 kW
p^uction; II. I million kWh
consumption per capita; 860 kWh (1992)
Industries: fishing, tourism, offshore
financial services
Agriculture: subsistence farming prevails,
based on com and beans; fishing more
important than farming; not self-sufficient in
food
Economic aid:
recipient; Western (non-US) countries, ODA
and (DOF bilateral commitments ( 1 970-89),
$110 million
Currency: I United States dollar (US$) = 100
cents
Exchange rates; US currency is used
Fiscal year: calendar year','fb670cc80c18d8efaa6d738a3871846594fffc90564de3e3fb4bbad0ad0f4e68','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da9c819893faa0cc08bc5516360c5ca59ebd4dd3525d2623b44767e49925f559',1994,'TV','Tuvalu','economy',893,'Conununications
Highways:
total; 121 km (including 24 km tarmac)
paved; NA
unpaved: NA
Ports: Grand Turk, Salt Cay, Providenciales,
Cockbum Harbour
Airports:
total: 7
usable: 7
with permanent-surface runways; 4
with runways over 3,6f9 m; 0
with runways 2,440-3,659 m; 0
with runways 1,220-2,439 m; 4
Telecommunications: fair cable and radio
services; 1,446 telephones; broadcast
stations — 3 AM, no FM, several TV; 2
submarine cables; 1 Atlantic Ocean
INTELSAT earth station
Defense Forces
Note: defense is the responsibility of the UK
Nut
South
Pocittc
Ocoon
PUNAI
NurUkitB
Overview: Tuvalu consists of a scattered
group of nine coral atolls with poor soil. The
country has no known mineral resources and
few exports. Subsistence farming and fishing
are the primary economic activities. The
islands are too small and too remote for
development of a tourist industry. Government
revenues largely come from the sale of stamps
and coins and worker remittances. Substantial
income is received annually from an
international trust fund established in 1987 by
Australia. NZ, and the UK and supported also
by Japan and South Korea.
National product: GNP — exchange rate
conversion— $6.4 million (1990)
National product real growth rate: 4%
(1990 est.)
National product per capita: $700 ( 1990)
Inflation rate (consumer prices): 2.9%
(1989)
Unemployment rate: NA%
Budget:
revenues; $4.3 million
expenditures; $4.3 million, including capital
expenditures of SNA (1989 est.)
Exports: $165,000 (f.o.b.. 1989)
commodities; copra
partners; Fiji. Australia, NZ
Imports: $4.4 million (c.i.f., 1989)
commodities; food, animals, mineral fuels,
machinery, manufactured goods
partners'' Fiji, Australia, NZ
External debt; SNA
Industrial production; growth rate NA%
Electricity;
capacity; 2,600 kW
production; 3 million kWh
consumption per capita; 330 kWh ( 1 990)
Industries: fishing, tourism, copra
Agriculture: coconuts and fish
Economic aid:
recipient; US commitments, including Ex-lm
(FY70-87), $1 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89). $101 million
Currency: I Tuvaluan dollar ($T) or 1
Austfalian dollar ($A) = 100 cents
Exchange rates: Tuvaluan dollars ($T) or
Australian dollars ($A) per US$1 — 1 .4364
(January 1994), 1.4704(1993). 1.3600(1992).
1.2835(1991), 1.2799(1990), 1.2618(1989)
Fiscal year: NA
Communicatlotis
Highways:
total; 8 km
unpaved; gravel 8 km
Ports: Funafuti, Nukufetau
Merchant marine: 7 ships (1,(KI0 CRT or
over) totaling 57,067 GRT/ 102,037 DWT,
passenger-cargo I, oil tanker 2, chemical
tanker 4
Airports:
total; 1
usable; I
with permanent-suiface runways; 0
with runways over 3,659 m; 0
with runways 2,440-3,659 m; 0
with runways 1,220-2,439 m; 1
Telecommunications: broadcast stations — I
AM. no FM, no TV; 300 radiotelephones;
4,(X)0 radios; 108 telephones
Defense Forces
Branches: Police Force
Defense expenditures: exchange rate
conversion — SNA, NA% of GNP
407','bc1d58c1b6e16e5ee18a878d60af57acd1a2fcea223ce334abd584380075b990','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06eb0e6ca81f39d0273f65b5203794d2ae7b85a34a49140ed575bd60df8214ab',1994,'UG','Uganda','economy',901,'Overview; Uganda has substantial natural
resources, including fertile soils, regular
rainfall, and sizable mineral deposits of copper
and cobalt. The economy has been devastated
by widespread political instability,
mismanagement, and civil war since
independence in 1962. (GDP remains below
the levels of the early 1970s, as does industrial
production.) Agriculture is the most important
sector of the economy, employing over 80% of
the work force. Coffee is the major export crop
and accounts for the bulk of export revenues.
408','ce2d2d1ffbdd0cb9f0c80b0771274983633decf0fd3d5dd0c96ce57458c9c727','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f00059c9b95b32380353fffaf77bb543704f1eafd67e8c2d7593d592451feab6',1994,'AE','United Arab Emirates','economy',907,'Overview: The UAE has an open economy
with one of the world''s highest incomes per
capita and with a sizable annual trade surplus.
Its wealth is based on oil and gas output (about
40% of GDP), and the fortunes of the economy
fluctuate with the prices of those commodities.
Since 1973, the UAE has undergone a
profound transformation from an impoverished
region of small desert principalities to a
modem state with a high standard of living. At
present levels of production, crude oil reserves
should last for over 100 years. Although much
stronger economically than mast Gulf states,
the UAE faces similar problems with weak
international oil prices arul the pressures for
cuts in OPEC oil production quotas. The UAE
government is encouraging increased
privatization within the economy.
NatkMUd product: GDP— purchasing power
equivalent — $63.8 billion (1993 est.)
National product real growth rate: 1%
(1993 est.)
National product per capiU: $24,000 ( 1 993
est.)
Inflation rate (consumer prices): 3,5%
(1992 est.)
Unemployment rate: NEGL%(I988)
Budget:
revenues; $4.3 billion
expenditures; $4.8 billion, including capital
expenditures of $NA (1993 est)
Exports: $22.6 billion (f.o.b., 1993 est.)
commodities; crude oil 66%, natural gas, re¬
exports, dried fish, dates
partners; Japan 39%, Singapore 5%, Korea
4%, Iran 4%, India 4% (1991)
Imports: $18 billion (f.o.b., 1993 est.)
commodities; manufactured goods, machinery
and transport equipment, food
partners; Japan 14%, UK 9%. US 8%,
Germany 6% (1992)
External debt: $1 1 billion (1993 est.)
Industrial production: growth rate 1.7%
(1992 est.); accounts for 50% of GDP,
including petroleum
Electricity:
capacity; 6.090.000 kW
pivduction; 17.85 billion kWh
consumption per capita; 6.718 kWh (1992)
Industries: petroleum, Tishing,
petrochemicals, construction materials, some
boat building, handicrafts, pearling
Agriculture: accountsfor2%ofGDPand5%
of labor force; cash crop — dates; food
products — vegetables, watermelons, poultry,
eggs, dairy, fish; only 25% self-sufTicient in
food
Illicit drugs: growing role as heroin
transshipment and money-laundering center
Economic aMt
donor; pledged in bilateral aid to less
developed countries (1979-89) $9. 1 billion
Currency: I Emirian dirham (Dh) ■ 100 tils
Exchange ratsa: Emirian dirhams (Dh) per
US$1— 3.6710 (Exed rate)
Fiscal year: calendar year
Communkutions
Highways:
total; 2,000 km
paved; 1,800 km
unpaved; gravel, graded earth 200 km
Pipelines: crude oil 830 km, natural gas,
including natural gas liquids, 870 km
Porta: Al Pujayrah, Khawr Fakkan. Mina''
Jabal ''Ali, Mina'' Khalid, Mina'' Rashid, Mina''
Saqr, Mina'' Zayid
Merchant marine: 37 ships ( 1,000 QRT or
over) touling 909,041 ORT/1.5I2.74I DWT,
cargo 18, container 9. roll-on/roll-off cargo 3,
oil tanker 22. bulk I, refrigerated cargo I,
liquified gas 1, chemical tanker 2
Airports:
total; 39
usable; 36
with permanenhsuiface runways: 22
with runuvys over 3.659 m; 6
with miivuvs 2,440-3,659 m; 6
with runways 1,220-2,439 m; 6
Teicconununirations: modem system
consisting of microwave and coaxial cable; key
centers are Abu Dhabi and Dubayy; 386,600
telephones; satellite ground stations — I
Atlantic Ocean INTELSAT, 2 Indian Ocean
INTELSAT and 1 ARABSAT; submarine
cables to Qatar. Bahrain. India, and Pakistan;
tropospheric scatter to Bahrain; microwave
radio relay to Saudi Arabia; broadcast
stations — 8 AM. 3 FM. 12 TV
DefmM Forces
Branches: Army. Navy. Air Force. Federal
Police Force
Manpower availability: males age 15-49
1,040,828; fit for military service 567.766;
reach military age (18) annually 17,303 (1994
est.)
Defense expenditures: exchange rate
conversion — $1.47 billion. 5.3% of GDP
(1989 est.)
Overview: Tiie UK is one of the world’s great
trading powers anti financial centers, and its
economy ranks among the four largest in
Western Europe. The economy is essentially
capitalistic; over the past thirteen years the
ruling Tories have greatly reduced public
ownership and contained the growth of social
welfare programs. Agriculture is intensive,
highly mechanized, and efficient by European
standards, producing about 60% of food needs
with only I % of the labor force. The UK has
large coal, natural gas, and oil reserves, and
primary energy production accounts for 1 2%
of GDP, one of the highest shares of any
industrial nation. Services, particularly
banking, insurance, and business services,
account by far for the largest proportion of
GDP while industry continues to decline in
importance, now employing only 25% of the
work force and generating only 2 1 % of GDP.
The economy is emerging out of its 3-year
recession with only weak recovery in 1993;
even so, the economy fared better in 1 993 than
the economies of most other European
countries. Unemployment is hovering around
10% of the labor force. The government in
1992 adopted a pro-growth .strategy, cutting
interest rates sharply and removing the pound
from the European exchange rate mechanism.
Excess industrial capacity piobably will
moderate inflation which for the first time in a
decade is below the EC average. The major
economic policy question for Britain in the
1990s is the terms on which it participates in
the financial and economic integration of
Europe.
National product: GDP — purchasing power
equivalent — $980.2 billion (1993)
National product real growth rate: 2. 1 %
(1993)
National product per capita: $16,900
(1993)
Inflation rate (consumer prices): 2.6%
(1993)
Unemployment rate: 10.3% (1993)
Budget:
revenues: $325.5 billion
expenditures: $400.9 billion, including capital
expenditures of $33 billion ( 1993 est.)
Exports: $190.1 billion (f.o.b., 1993)
commodities: manufactured goods, machinery,
fuels, chemicals, semifinished goods, transport
equipment
partners: EC countries 56.7% (Germany
14.0%, France 11.1%, Netherlands 7.9%), US
10.9%
Imports: $221.6 billion (c.i.f., 1993)
commodities: manufactured goods, machinery,
semifinished goods, foodstuffs, consumer
goods
partners: EC countries 51.7% (Germany
14.9%. France 9.3%, Netherlands 8.4%), US
11.6%
External debt: $16.2 billion (June 1992)
Industrial production: growth rate 2.2%
(1993 est.)
Electricity:
capacity: 99,000,000 kW
production: 317 billion kWh
consumption per capita: 5.480 kWh ( 1 992)
Industries: production machinery including
machine tools, electric power equipment,
equipment for the automation of production,
railroad equipment, shipbuilding, aircraft,
motor vehicles and parts, electronics and
communications equipment, metals,
chemicals, coal, petroleum, paper and paper
products, food processing, textiles, clothing,
and other consumer goods
Agriculture; accounts for only 1 .5% of GDP
and 1 % of labor force; highly mechanized and
efficient farms; wide variety of crops and
livestock products produced; about 60% self-
sufficient in food and feed needs
Illicit drugs: gateway counuy for Latin
American cocaine entering the European
market; producer of synthetic drugs; money¬
laundering center
Economic aid:
donor: ODA and OOF commitment.s (1992-
93), $3.2 billion
Currency: 1 British pound (£) = 100 pence
Exchange rates: British pounds (£) per
U,S$ I —0.6699 (January 1 994), 0.6033 ( 1 993),
0.5664 ( 1 992), 0,5652 (1991), 0.5603 (1990),
0.6099(1989)
Fiscal year; I April-31 March','bfebb936816c7657a41e9fc1ab7e83ab64daf4c1b649e6f4a78e50ff4d621f2e','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c09cff357e99db865d93150954e7d5cf7188eca2f19d36518e6c557eb3182d6',1994,'US','United States','economy',912,'Overview: The US has the most powerful,
diverse, and technologically advanced
economy in the world, with a per capita GDP of
$24,700. the largest among major industrial
nations. The economy is market oriented with
most decisions made by private individuals and
business firms and with government purchases
of goods and services made predominantly in
the marketplace. In 1 989 the economy enjoyed
its seventh successive year of substantial
growth, the longest in peacetime history. The
expansion featured moderation in wage and
consumer price increases and a steady
reduction in unemployment to 5.2% of the
labor force. In 1990, however, growth slowed
to 1 % because of a combination of factors,
such as the worldwide increase in interest rates.
Iraq''s invasion of Kuwait in August, the
.subsequent spurt in oil prices, and a general
decline in business and consumer confidence.
In 1991 output fell by 1%, unemployment
grew, and signs of recovery proved premature.
Growth picked up to 2.6% in 1992 and to 3.0%
in 1993. Unemployment, however, declined
only gradually, the increase in GDP being
mainly attributable to gains in output per
worker. Ongoing economic problems for the
remainder of the 1990s include inadequate
investment in economic infrastructure, rapidly
rising medical co.sts. and sizable budget and
trade deficits.
National product; GDP — purchasing power
equivalent — $6,379 trillion (1993)
National product real growth rate: 3%
(1993)
National product per capita: $24,700
(1993)
Inflation rate (consumer prices): 3%( 1993)
Unemployment rate: 6% (May 1994)
Budget;
revenues: $1.1535 trillion
expenditures: $1.4082 trillion, including
capital expenditures of SNA ( 1993 est.)
Exports; $449 billion (f.o.b., 1993 est.)
commodities: capital goods, automobiles.
Industrial supplies and raw materials,
consumer gutxls. agricultural products
partners: Western Europe 24.3%, Canada
22. 1 %. Japan 1 0.5% ( I '')93 est.)
Imports: $582 billion (c.i.f.. 1993 e.st.)
commodities: crude oil and refined petroleum
products, machinery, automobiles, consumer
goods, industrial raw materials, food and
beverages
partners: Canada, 19.3%. Western Europe
18.1%, Japan 18.1% (1993 est.)
External debt: $NA
Industrial production: growth rate 4.6%
( 1 993 ); accounts for 23% of GDP (1991)
Electricity:
capacity: 780,000,000 kW
production: 3.23 trillion kWh
consumption per capita: 12,690 kWh (1992)
Industries; leading industrial power in the
world, highly diversified and technologically
advanced; petroleum, steel, motor vehicles,
aerospace, telecommunications, chemicals,
electronics, food processing, consumer goods,
lumber, mining
Agriculture: accounts for 2% of GDP and
2.8% of labor force; favorable climate and soils
support a wide variety of crops and livestock
production; world''s second largest producer
and number one exporter of grain; surplus food
producer; fish catch of 4.4 million metric tons
(1990)
Illicit drugs: illicit producer of cannabis for
domestic consumption with 1987 production
e.stimated at 3,500 metre tons or about 25% of
the available marijuana; ongoing eradication
program aimed at small plots and greenhouses
has not reduced production
Economic aid:
donor: commitments, including ODA and
OOF, (FY80-89). $! 15.7 billion
Currency: I United States dollar (US$)= 100
cents
Exchange rates:
British pounds: (£) per US$ — 0.6699 (January
1994). 0.6033 (1993). 0.5664 (1992). 0.5652
(1991), 0.5603 ( 1 990), 0.6099 (1989)
Canadian dollars: (Can$) per US$ — 1 .3 1 74
(January 1994), 1.2901 (1993), 1.2087 (1992),
1.1457(1991), 1.1668(1990). 1.1840(1989)
French francs: (F) per US$ — 5.9205 (January
1994), .<6632 (1993), 5.2938 (1992), 5.6421
(1991). 5.4453 (1990). 6.3801 (1989)
Italian lire: (Lit) per US$ — l,7(X).2 (January
1994). 1.573.7(1993). 1.2.32.4(1992), 1,240.6
(1991). 1.198.1 (1990), 1..372.1 (1989)
Japanese ven: (¥) per US$— 1 1 1.51 (January
1994), 111.20(1993). 126.65(1992). 1.34.71
(1991). 144.79(1990). 1.37.96(1989)
German deutsche marks: (DM) per US$ —
1.7431 (January 1994). 1.65.33(1993), I..5617
(1992), 1.6595(1991), 1.6157(1990). 1.8800
(1989)
Fiscal year: I October — 30 September','8dfff56e0eb1df0d5262957120b7af05613701cbc55b4886195d761d24ea2acd','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3653b8af55d462ae49293d13c5f255bb7962ab71c138ae668630c5e7dd3f26e8',1994,'UY','Uruguay','economy',918,'Overview: Uruguay is a small economy with
favorable climate, good soils, and solid
hydroprower potential. Economic development
has been held back by excessive government
regulation of economic detail and 50% to
130% inflation. After several years of sluggish
growth, real GDP jumped by about 7.5% in
1992. The rise is attributable mainly to an
increase in Argentine demand for Uruguayan
exports, particularly agricultural products and
electricity. In a major step toward greater
regional economic cooperation, Uruguay in
1991 had Joined Brazil, Argentina, and
Paraguay in forming the Southern Cone
Common Market (Mercosur). A referendum in
December 1992 overturned key portions of
landmark privatization legislation, dealing a
serious blow to President LACALLE’s broad
economic reform plan. Hampered by a
slowdown in the agricultural sector, the
economy grew at only 2% in 1993 compared
with 7.5% in 1992. Although inflation declined
for the second consecutive year, a surge in the
money supply, rising food prices, a record
trade deficit, and an increase in the government
deficit toward the end of the year
foreshadowed troubles ahead in 1994.
National product: GDP — purchasing power
equivalent — $19 billion (1993 est.)
National product real growth rate; 2%
(1993 e.st.)
National product per capita; $6,(X)0 (1993
est.)
Inflation rate (consumer prices): 50%
(1993 est.)
Unemployment rate; 8.8% ( 1993 est.)
Budget:
revenues: $2.9 billion
expenditures: $3 billion, including capital
expenditures of $388 million (1991 est.)
Exports; SI .6 billion (f.o.b., 1993 est.)
commodities: wool and textile manufactures,
beef and other animal products, leather, rice
partners: Brazil, Argentina, US, China, Italy
Imports: $2 billion (f.o.b., 1993 est.)
commodities: machinery and equipment,
vehicles, chemicals, minerals, plastics
partners: Brazil, Argentina, US, Nigeria
External debt: $4.2 billion ( 1993)
Industrial production: growth rate 4.2%
( 1 992 est.), accounts for almost 25% of GDP
Electricity:
capacity: 2,168,000 kW
production: 5.96 billion kWh
consumption per capita: 1 ,900 kWh (1992)
Industries: meat processing, wool and hides,
sugar, textiles, footwear, leather apparel, tires,
cement, fishing, petroleum refining, wine
Agriculture; accounts for 1 2% of GDP; large
areas devoted to livestock grazing; wheat, rice,
com, sorghum; self-sufficient in most basic
foodstuffs
Economic aid:
recipient: US commitments, including Ex-Im
(FY70-88), $105 million; Western (non-US)
countries, ODA and (X>F bilateral
commitments (1970-89), $420 million;
Communist countries (1970-89), $69 million
Currency: 1 Uruguayan peso ($Ur) = 100
centesimos
Exchange rates: Uruguayan pesos ($Ur) per
US$I-^.4710(January 1994), 3.9484( 1993);
new Uruguayan pesos (N$Ur) per US$1 —
3,457.5 (December 1992), 3,026.9 (1992),
2,489 (1991), 1,594 (1990), 805 (1989)
note: on 1 March 1993 the former New Peso
(N$Ur) was replaced as Uruguay''s unit of
currency by the Peso which is equal to 1 ,000 of
the New Pesos; consequently there is a major
change in the peso/dollar exchange rate
Fiscal year: calendar year','cfa20204eb5bb2e9b83b05547462484539efe364ee11ca16f6990cf50e5e2f0d','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('121ab1a08b3e2e5a9be05e67d812d3896b5b59746e6bb3f82e77084d385b091a',1994,'UZ','Uzbekistan','economy',924,'Overview: Uzbekistan is a dry, landlocked
country of which 20% is intensely cultivated,
irrigated river valleys. It is one of the poorest
states of the former USSR with 60% of its
population living in overpopulated rural
communities. Nevertheless, Uzbekistan is the
world''s third largest cotton exporter, a major
producer of gold and natural gas, and a
regionally significant producer of chemicals
and machinery. Since independence, the
government has sought to prop up the Soviet-
style command economy with subsidies and
tight controls on prices and production. Such
policies have buffered the economy from the
sharp declines in output and high inflation
experienced by many other former Soviet
republics. By late 1993, however, they had
become increasingly unsustainable as inflation
soared and Russia forced the Uzbek
Government to introduce its own currency.
Faced with mounting economic problems, the
government has increased its cooperation with
international financial institutions, announced
an acceleration of privatization, and stepped up
efforts to attract foreign investors.
Nevertheless, the regime is likely to resist full-
fledged market reforms.
National product: GDP — purchasing power
equivalent— $53.7 billion (1993 estimate from
the UN International Compari.son Program, as
extended to 1991 and published in the World
Bank''s World Development Report 1993; and
as extrapolated to 1993 using official Uzbek
statistics, which are very uncertain because of
major economic changes since 1990)
National product real growth rate: -3.5%
(1993 est.)
"''-stional product per capita: $2,430 ( 1993
iiUlation rate (consumer prices): 18% per
month (1993)
Unemployment rate: 0.2% includes only
officially registered unemployed; large
numbers of underemploy^ workers
■''«dget:
. • . i - :''s: SNA
•; enditiires: SNA. including capital
expenditures of SNA
Exports: $706.5 million to outside the FSU
co-jntries (1993)
commodities: cotton, gold, natural gas, mineral
fertilizers, ferrous metals, textiles, food
products
partners: Russia, Ukraine, Eastern Europe, US
Imports: $947.3 million from outside the
FSU countries (1993)
commodities: grain, machinery and parts,
consumer durables, other foods
partners: principally other FSU countries,
Czech Republic
External debt: SNA
Industrial production: growth rate -7%
(1993)
Electricity:
capacity: 1 1.950,000 kW
production: 50.9 billion kWh
consumption per capita: 2,300 kWh (1992)
Industries: textiles, food prxxiessing, machine
building, metallurgy, natural gas
Agriculture: livestock, cotton, vegetables,
fruits, grain
Illicit drugs: illicit cultivator of cannabis and
opium poppy; mostly for CIS consumption;
limited government eradication programs:
used as transshipment points for illicit drugs to
Western Europe
Economic aid:
recipient: $125 million by yearend 1993:
future commitments for about S500 million
Currency: introduced provisional som-
coupons 10 November 1993 which circulated
parallel to the Russian rubles; became the sole
legal currency 31 January 1994; will be
replaced in July 1994 by the som currency
Exchange rates: NA
Fiscal year: calendar year','2f0cad39105fc2d76c01a220dd319933741989ec6f649d1621bf7a27f776e5ad','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c3cb3bfceeefdd0ddec9ea6b992dc519cf81e6702c6badbe5531d3b9f9ffaf6',1994,'VU','Vanuatu','economy',930,'Overview: The economy is based primarily
on subsistence farming which provides a living
for about 80% of the population. Fishing and
tourism are the other mainstays of the
economy. Mineral deposits are negligible; the
country has no known petroleum deposits. A
small light industry sector caters to the local
market. Tax revenues come mainly from
import duties.
National product: GDP — exchange rate
conversion — $142 million (1988 est.)
National product real growth rate: 6%
(1991)
National product per capita; $ 1 ,050 ( 1 990)
Inflation rate (consumer prices): 2.3%
(1992 est.)
Unemployment rate: NA%
Budget:
revenues; $90 million
expenditures; $103 million, including capital
expenditures of $45 million ( 1989 est.)
Exports: $14.9 million (f.o.b., 1991)
commodities; copra, beef, cocoa, timber,
coffee
partners; Netherlands, Japan, France, New
Caledonia, Belgium
Imports: $74 million (f.o.b., 1991)
commodities; machines and vehicles, food and
beverages, basic manufactures, raw materials
and fuels, chemicals
partners; Australia 36%, Japan 13%, NZ 10%,
France 8%, Fiji 8%
External debt: $38 million (1991)
Industrial production: growth rate 8.1%
(1990); accounts for about 10% of GDP
Electricity:
capacity; 1 7,000 kW
production; 30 million kWh
consumption per capita; 1 80 kWh ( 1 990)
Industries: food and fish freezing, wood
processing, meat canning
Agriculture: accounts for 40% of GDP;
export crops — coconuts, cocoa, coffee, fish;
subsistence crops — taro, yams, coconuts,
fruits, vegetables
Economic aid:
recipient; Western (non-US) countries, ODA
and OOF bilateral commitments (1970-89),
$606 million
Currency: 1 vatu (VT) = 100 centimes
Exchange rates: vatu (VT) per US$1 —
123.48 (September 1993). 1 13.39 (1992),
111.68(1991), 116.57(1990). 116.04(1989)
Fiscal year: calendar year
Overview; Petroleum is the backbone of the
economy, accounting for 23% of GDP, 61 % of
central government ordinary revenues, and
77% of export earnings in 1993. Former
President PEREZ introduced an economic
readjustment program when he assumed office
in February 1989. Lower tariffs and the
removal of price controls, a free market
exchange rate, and market-linked interest rates
threw the economy into confusion, causing an
8% decline in GDP in 1 989, The economy
recovered part way in 1990 and grew by 9,7%
in 1991 and 6.8% in 1992; economic activity
fell by 1% in 1993, primarily because of
business concerns over political instability.
National product: GDP — purchasing power
equivalent — $161 billion (1993 est.)
National product real growth rate: -1%
(1993 est.)
National product per capita: S8,0(X)(1993
est.)
Inflation rate (consumer prices): 46%
(1993 est.)
Unemployment rate: 8.2% (1993 est.)
Budget:
revenues: $9.8 billion
expenditures: $1 1 .9 billion, including capital
expenditures of $103 million (1993 est.)
Exports: $14.2 billion (f.o.b., 1993 est.)
commodities; petroleum 77%, bauxite and
aluminum, steel, chemicals, agricultural
products, basic manufactures
partners: US and Puerto Rico 42%, Japan,
Netherlands, Italy
Imparts: $1 1 billion (f,o.b., 1993 est.)
commodities: raw materials, machinery and
equipment, transport equipment, construction
materials
partners; US 50%, Germany, Japan,
Netherlands, Canada
External debt: $28.5 billion (1993)
Industrial production: growth rate 6. 1 %
(1992 est.); accounts for 40% of GDP,
including petroleum
Electricity:
capacify.'' 2 1,1 30,000 kW
production; 58.541 billion kWh
consumption per capita; 2,830 kWh (1992)
Industries: petroleum, iron-ore mining,
construction materials, food processing,
textiles, steel, aluminum, motor vehicle
assembly
Agriculture: accounts for 6% of GDP and
16% of labor force; products— com, sorghum,
sugarcane, rice, bananas, vegetables, coffee,
beef, pork, milk, eggs, fish; not self-sufficient
in food other than meat
Illicit drugs: illicit producer of cannabis and
coca leaf for the international drug trade on a
small scale; however, large quantities of
cocaine transit the country from Colombia:
important money-laundering hub
Economic aid:
recipient; US commitments, including Ex-Im
(FY70-86), $488 million; Communist
counuies (1970-89), $10 million
Currency: 1 bolivar (Bs)= I (X) centimes
Exchange rates: bolivBres(Bs) per US$1 —
107.260 (January 1994). 90.826 (1993), 68.38
( 1 992). 56.82 (1991), 46.90 ( 1 990), .34.68
(1989)
Fiscal year: calendar year','d94300ceb50dc5585624113c87f1666488cc59442cec26ba3743fa4bd441d525','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9ac640b53e1007cfcbeb4e8c0628805fda4ee505d1a2600ff45f91a508edb2c',1994,'WF','Wallis and Futuna','economy',936,'Overview: Economic activity is limited to
providing services to US military personnel
and contractors located on the island. All food
and manufactured goods must be imported.
Electricity: supplied by US military
Overview: The economy is limited to
traditional subsistence agriculture, with about
80% of the labor force earning its livelihood
from agriculture (coconuts and vegetables),
livestock (mostly pigs), and fishing. About 4%
of the population is employed in government.
Revenues come from French Government
subsidies, licensing of fishing rights to Japan
and South Korea, import taxes, and remittances
from expatriate workers in New Caledonia.
Wallis and Futuna imports food, fuel, clothing,
machinery, and transport equipment, but its
exports are negligible, consisting of copra and
handicrafts.
National product: GDP — exchange rate
conversion — $25 million (1991 est.)
National product real growth rate: NA%
National product per capita; $ 1 ,500 (1991
est.)
Inflation rate (consumer prices): NA%
Unemployment rate: NA%
Budget:
revenues: $2,7 million
expenditures: $2.7 million, including capital
expenditures of $NA (1983 est.)
Exports: negligible
commodities: copra, handicrafts
partners; NA
Imports: $13.3 million (c.i.f., 1984)
commodities: foodstuffs, manufactured goods,
transportation equipment, fuel
partners; France, Australia, New Zealand
External debt: $NA
Industrial production: growth rate NA%
Electricity:
capacity; 1 ,200 kW
production; 1 million kWh
consumption per capita: 70 kWh ( 1 990)
Industries: copra, handicrafts, fishing,
lumber
Agriculture: dominated by coconut
production, with subsistence crops of yams,
taro, bananas, and herds of pigs and goats
Economic aid:
recipient: Western (non-US) countries, ODA
and OOF bilateral commitments (1970-89),
$1 18 million
Currency; 1 CFP franc (CFPF) = 100
centimes
Exchange rates: Comptoirs Francais du
Pacifique francs (CFPF) per US$1 — 107.63
(January 1994), 102.96 (1993), 96.24 (1992),
102.57 (1991), 99.0 (1990), 1 15.99 (1989);
note — linked at the rate of 1 8. 1 8 to the French
franc
Fiscal year: NA','ac48730df3a3ed86eec1ddf8754842ae48e8d06e23914532a4babc780630da4c','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7173724553062effd3904bb511215eb00263993b5471d2aa2ae5311a542ae5a5',1994,'IL','Israel','economy',940,'Overview: Economic progress in the West
Bank has been hampered by Israeli military
administration and the effects of the
Palestinian uprising (intifadah). Industries
using advanced technology or requiring sizable
investment have been discouraged by a lack of
local capital and restrictive Israeli policies.
Capital investment consists largely of
residential housing, not productive assets that
would enable local Palestinian firms to
compete with Israeli industry. A major share of
GNP has traditionally been derived from
rzmi''tan''.es ''^f ''.voi ker, employed in Israel and
Persian Gulf states. Such transfers from the
Gulf dropped after Iraq invaded Kuwait in
August 1990. In the wake of the Persian Gulf
crisis, many Palestinians have returned to the
West Bank, increasing unemployment, and
export revenues have dropped because of the
decline of markets in Jordan and the Gulf
states. Israeli measures to curtail the intifadah
also have added to unemployment and lowered
living standards. The area’s economic situation
has worsened since Israel''s panial closure of
the territories in 1993.
National product: GNP — exchange rate
conversion — S2 billion (1991 est.)
National product real growth rate: -7%
(1991 est.)
National product per capita: $2,050 (1991
est.)
Infiation rate (consumer prices): 1 2%
(1991 est.)
t''nemploy ment rate: 1 5% ( 1 99 1 cst. )
Dudget:
revenues; $43.4 million
expenditures: $43.7 million, including capital
expenditures of SNA (FY90)
Exports: $175 million (f.o.b., 1991 est.)
commodities; olives, fruit, vegetables
partners: Jordan, Israel
Imports: $775 million (c.i.f., 1991 est.)
commodities: food, consumer goods,
construction materials
partners; Jordan, Israel
External debt: $NA
431
Wtf?t Bank (continued)','a5cbfc910bd02c3c1e259bd6a080c0667a000ecbe4167eb7e7a5104e4aab7377','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2073fa69e18933edb9f4e88e91a63818bcd33827d3510db9c3d42e03807def2',1994,'EH','Western Sahara','economy',941,'Industrial production: growth rate -1%
(1991); accourits for about 6% of GNP
Electricity; power supplied by Israel
Industries: generally small family businesses
that produce cement, textiles, soap, olive-wood
carvings, and mother-of-pearl souvenirs; the
Israelis have established some small-scale
modem industries in the settlements and
industrial centers
Agriculture: accounts for about 23% of GNP;
olives, citrus and other fruits, vegetables, beef,
and dairy products
Economic aid: SNA
Currency: 1 new Israeli shekel (NIS) = 100
new agorot; I Jordanian dinar (JD) = I ,(XX) fils
Exchange rates: new Israeli shekels (NIS)
per US$1- 2.9760 (February 1994), 2.8301
(1993), 2.4591 (1992), 2.2791 (1991), 2.0162
(1990), 1.9164 (1989); Jordanian dinars (JD)
per US$1— 0.7019 (February 1994), 0.6928
(1993), 0.6797 (1992), 0.6808 (1991), 0.6636
(1990), 0.5704(1989)
Fiscal year: calendar year (since 1 January
1992)
Overview: Western Sahara, a territory poor in
natural resources and having little rainfall, has
a per capita GDP of roughly $300. Pastoral
nomadism, fishing, and phosphate mining are
the principal sources of income for the
population. Most of the food for the urban
population must be imported. All trade and
other economic activities are controlled by the
Moroccan Government.
National product: GDP — exchange rate
conversion — $60 million (1991 est.)
National product real growth rate: NA%
National product per capita: $300 (1991
est.)
Inflation rate (consumer prices): NA%
Unemployment rate: NA%
Budget:
revenues: SNA
expenditures: $NA, including capitc''
expenditures of SNA
Exports: $8 million (f.o.b., 1982 est.)
commodities: phosphates 62%
partners; Morocco claims and administers
Western Sahara, so trade partners are included
in overall Moroccan accounts
Imports: $30 million (c.i.f., 1982 est.)
commodities; fuel for fishing fleet, foodstuffs
partners: Morocco claims and adnii.’iisters
Western Sahara, so trade partners are included
in overall Moroccan accounts
External deot; SNA
Industrial production: growth rate NA%
Electricity:
capacity; 60.000 kW
production: 79 million kWh
consumption per capita; 425 kWh ( 1989)
Industries: phosphate mining, fishing,
handicrafts
Agriculture: limited largely to subsistence
agriculture; some barley is grown in
nondrought years; fruit and vegetables are
grown in the few oases; food imports arc
essential; camels, sheep, and goats are kept by
the nomadic natives; cash economy exists
largely for the garri.son forces
Economic aid: $NA
Currency: 1 Moroccan dirham (DH) = 100
centimes
Exchange rates: Mor(K;can dirhams (DH) per
US$1— 9.669 (January 1994), 9.299 (1993).
8-338(1992). 8.707 (1991), 8.242 (1990),
8.488(1989)
Fiscal year: NA','d59d9d967942bb6ead590333ba867d5f6859e7cc5ac0eb82faabf5dc12f348a0','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1cfff7efb9e150d3e055836a7f7c98ac6a3771f8f2c881331a3abf5fc7644e1a',1994,'YE','Yemen','economy',946,'problems of pollution, desertification,
underemployment, epidemics, and famine.
Because of their own internal problems, the
industrialized countries have inadequate
resources to deal effectively with the poorer
areas of the world, which, at least from the
economic point of view, are becoming further
marginalized. (For the specific economic
problems of each country, see the individual
country entries in this volume.)
National product: GWP (gross world
product) — purchasing power equivalent — $29
trillion (1993 est.)
National product real growth rate; 2%
(1993 est.)
National product per capita: $5,200(1993
est.)
Inflation rate (consumer prices):
developed countries; 5% (1993 est.)
developing countries: 50% (1993 est.)
note; these figures vary widely in individual
cases
Unemployment rate: developed countries
typically 6%-l 1%; developing countries,
extensive unemployment and
underemployment (1993)
Exports: $3.64 trillion (f.o.b., 1992 est.)
commodities: the whole range of industrial and
agricultural goods and services
partners; in value, about 75% of exports from
the developed countries
Imports: $3.82 trillion (c.i.f., 1992 est.)
commodities; the whole range of industrial and
agricultural goods and services
partners: in vaiue, about 75% of imports by the
deveioped countries
External debt: $1 trillion for less developed
countries (1993 est.)
Industrial production; growth rate -I %
(1992 est.)
Electricity:
capacity: 2,864,000,000 kW
production: 1 1 .45 trillion kWh
consumption per capita; 2, 1 50 kWh ( 1 990)
Industries: industry worldwide is dominated
by the onrush of technoiogy. especially in
computers, robotics, telecommunications, and
medicines and medical equipment; most of
these advances take place in OECD nations:
only a small portion of non- OECD countries
have succeeded in rapidly adjusting to these
technological forces, and the technological gap
between the industrial nations and the less-
developed countries continues to widen; the
rapid development of new industrial (and
agricultural) technology is complicating
already grim environmental problems
Agriculture: the production of major food
crops has increased substantially in the last 20
years; the annual production of cereals, for
instance, has risen by 50%, from about 1,2
billion metric tons to about 1.8 billion metric
tons; production increases have resulted
mainly from increased yields rather than
increases in planted areas; while global
production is sufficient for aggregate demand.
about one-fifUi of the world''s population
remains malnourished, primarily because local
production cannot adequately provide for large
and rapidly growing populations, which are too
poor to pay for food imports; conditions are
especially bad in Africa where drought in
recent years has intensified the consequences
of overpopulation
Economic aid: $NA
Overview: Whereas the northern city Sanaa is
the political capital of a united Yemen, the
southern city Aden, with its refinery and port
facilities, is the economic and commercial
capital. Future economic development depends
heavily on Western-assisted development of its
moderate oil resources. Former South Yemen’s
willingness to merge stemmed partly from the
steady decline in Soviet economic suppon. The
low level of domestic industry and agriculture
have made northern Yemen dependent on
imports for practically all of its essential needs.
Large trade deficits have been compensated for
by remittances from Yemenis working abroad
and by foreign aid. Because of the Gulf crisis,
remittances have dropped substantially. Once
self-sufficient in food production, northern
Yemen has become a major importer. Land
once used for export crops — cotton, fruit, and
vegetables — has been turned over to growing a
shrub called qat, who.se leaves are chewed for
their stimulant effect by Yemenis and which
has no significant export market. Economic
growth in former South Yemen has been
constrained by a lack of incentives, partly
stemming from centralized control over
production decisions, investment allocation,
and import choices. Nominal growth in 1994-
95 is apt to be under 3% annually because of
low oil prices and political deadlock that is
causing a lack of economic cooperation and
leadership.
National product: GDP — exchange rate
conversion — $9 billion (1993 est.)
437
Yemen (continued)
National product real growth rate: 3. 1 %
(1993 est.)
National product per capita: $800(1993
est.)
Inflation rate (consumer prices): 5S%
(1993 est.)
Unemptoyment rate: 30% (December 1992)
Budget:
revenues: $NA
expenditures: SNA, including capital
expenditures of $NA
Exports: $693 million (f.o.b., 1993 est.)
commodities: crude oil, cotton, coffee, hides,
vegetables, dried and salted fish
partners: Italy 55%, US 32%, Jordan 5%
(1991)
Imports: $1.6 billion (f.o.b., 1993 est.)
commodities: textiles and other manufactured
consumer goods, petroleum products, sugar,
grain, flour, other foodstuffs, cement,
machinery, chemicals
partners: UAE 6%, Japan 6%, Saudi Arabia
6%, Kuwait 6%, US 6% (1991)
External debt: $7 billion (1993)
Industrial production: growth rate NA%,
accounts for 18% of GDP
Electricity:
capacity: 714,000 kW
production: 1 .224 billion kWh
consumption per capita: 1 20 kWh (1992)
Industries: crude oil production and
petroleum refining; small-scale production of
cotton textiles and leather goods; food
processing; handicrafts; small aluminum
products factory; cement
Agriculture: accounted for 26% of GDP;
products — grain, fruits, vegetables, qat (mildly
narcotic shrub), coffee, cotton, dairy, poultry,
meat, fish; not self-sufficient in grain
Economic aid:
recipient: US commitments, including Ex-Im
(FY70-89), $389 million; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89), $2 billion; OPEC
bilateral aid (1979-89), $3.2 billion;
Communist countries (1970-89), $2.4 billion
Currency: Yemeni rial (new currency); 1
North Yemeni riyal (YR) = 100 fils; 1 South
Yemeni dinar (YD) = 1,000 fils
note: following the establishment of the
Republic of Yemen on 22 May 1990, the North
Yemeni riyal and the South Yemeni dinar are
to be replaced with a new Yemeni rial
Exchange rates: Yemeni rials per US$1 —
12.0 (official); 70 (market rate. April 1994)
Fiscal year: calendar year','23ee0d01e83877832721b8a8ef52dd12352fa88b22ebff670d5977edaee72179','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01ac61d6b31ee6ca26fa03541421ea9cef7517db7decbf3ddfb661fcb2d676da',1994,'ZM','Zambia','economy',957,'Overview: Zaire''s economy has continued to
diiiintegratc. While meaningful economic
figures are difficult to come by, Zaire’s
hyperinflation, the la’''gest government deficit
ever, and plunging mineral production have
made the country one of the world''s poorest.
Most formal transactions are conducted in hard
currency as indigenous banknotes have lost
almost all value, and a barter economy now
flourishes in all but the largest cities. Most
individuals and families hang on grimly
through subsistence farming and petty trade.
The government has not been able to meet its
financial obligations to the International
Momentary Fund or put in place the financial
measures advocated by the IMF. Although
short-term prospects for improvement are dim,
improved political stability would boost
Zaire''s long-term potential to effectively
exploit its vast wealth of mineral and
agricultural resources.
National product: GDP — purchasing power
equivalent — $21 billion (1993 est,)
National product real growth rate: -6%
(1992 est.)
National product per capita: SSOO ( 1 993
est.)
Inflation rate (consumer prices): 35%-40%
per month (1992 est.)
Unemployment rate: NA%
Budget:
revenues; SNA
expenditures: SNA, including capital
expenditures of SNA
Exports; $1.5 billion (f.o.b.. 1992 est.)
commodities: copper, coffee, diamonds,
cobalt, crude oil
partners: US, Belgium. France, Germany,
Italy, UK, Japan, South Africa
Imports: SI. 2 billion (f.o.b., 1992 est.)
commodities: consumer goods, foodstuffs.
439
Zaire (continued)
mining and other machinery, tran^^pott
equipment, fiiels
partners: South AfHca, US, Belgium, Prance,
Germany, Italy, Japan, UK
External debt: $9.2 billion (May 1992 est.)
Induatrlal production: growth grate NA%
Electricity:
n>p«cirv.''2,580,{X)0kW
p^ucHon: 6 billion kWh
consumption per capita; 1 60 kWh (1991)
Induitries: mining, mineral processing,
consumer products (including textiies,
footwear, and cigarettes), processed foods and
beverages, cement, diamonds
Agriculture: cash crops — coffee, palm oil,
rubber, quinine; food crops — cassava, bananas,
root crops, com
Illicit drugs: illicit producer of cannabis,
mostly for domestic consumption
Economic aid:
recipient; US commitments, including Ex-Im
(FY70-89). $1,1 billion; Western (non-US)
countries, ODA and OOF bilateral
commitments (1970-89). $6.9 billion; OPEC
bilateral aid (1979-89), $35 million:
Communist countries (1970-89), $263 million
note; except for humanitarian aid to private
organizations, no US assistance was given to
Zaire in 1992
Currency: 1 zaire (Z) = 100 makuta
Exchange rates: zaire (Z) per US$1 ~
7,915.000 (September 1993). 1,990.000
(1992), 15,587 (1991), 719 (1990), 381 (1989)
Fiscal year: calendar year','ae9a992089a95f6b84a3ef273531059dd70e409914917c785ddceb7fd0299966','internet-archive','DTIC_ADA285728','txt','615ec8dcd0bd165d24807333d42111712e1337c2187da65b8e7e1c9bd261cb39','https://archive.org/download/DTIC_ADA285728/DTIC_ADA285728_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

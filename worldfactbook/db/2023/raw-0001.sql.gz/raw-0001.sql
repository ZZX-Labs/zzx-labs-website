SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('79f71f95b8bb161a27c966c6acd90806fd40eea8a6d80c3839e4ddb639f032ee',2023,'','','raw',1,'theworldfactbook_202602
texts
opensource
CIA
2023-12-01
The CIA WORLD FACTBOOK December 2023<div><br /></div><div>Kiwix ZIM format</div><div><br /></div><div>best viewed offline or with the Kiwix-javascript reader </div><div><a href="https://kiwix.org/" rel="ugc nofollow">https://kiwix.org/</a><br /></div>
https://creativecommons.org/publicdomain/mark/1.0/
Internet Archive HTML5 Uploader 1.7.0
CIA
World FactBook
KIWIX
ZIM
CIA WORLD FACTBOOK 2023
iwanttobeagmo@gmail.com
2026-02-06 02:04:48
2026-02-06 02:04:48
[curator]validator@archive.org[/curator][date]20260206021142[/date][comment]checked for malware[/comment]
http://archive.org/details/theworldfactbook_202602
ark:/13960/s272mfdqr1m
Sun Apr 5 13:52:44 UTC 2026','045c994128016be0ed1dcc3ebd8c2c117694a8d39b52cb777e956ada2f87d6ae','internet-archive','theworldfactbook_202602','xml','913e9da91720882d7a7238f1833309f765d36bc8b25c99f15edd3ea872c2744c','https://archive.org/download/theworldfactbook_202602/theworldfactbook_202602_meta.xml','xml') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7bab0f3d398e10b8bc909aad183b1f108e52c7ded8a5a0152503d234f79acb8',2007,'EH','Western Sahara','transportation',20,'Airports
Airports - with paved runways
total
over 3,047 m
2,438 to 3047 m
1 ,524 to 2,437 m
914 to 1,523 m
under 914 m
Airports - with unpaved runways
total
over 3,047 m
2,438 to 3,047 m
1,524 to 2,437 m
914 to 1,523 m
under 914 m
Heliports
Pipelines
Railways
total
broad gauge
standard gauge
narrow gauge
dual gauge
Roadways
total
paved
unpaved
Waterways
Merchant marine
total
ships by type
foreign owned
registered in other countries
Ports and terminals
Transportation - note
Airports: 49,973(2005)
Railways:
total: 1,115,205 km
broad gauge: 257,481 km
standard gauge: 671 ,41 3 km
narrow gauge: 186,311 km (2003)
Roadways:
total: 32,345,165 km
paved: 19,403,061 km
unpaved: 12,942,104 km (2002)
Waterways: 671 ,886 km (2004)','0eb3fa46cae4b4eb859c1496a93fff699f7ded0b440ebfdf738b6fbab6548c0d','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1942010b4e83dadac5b3018212a1ac97d378ab800eb3d6e1c4115e540a5a023e',2007,'AF','Afghanistan','transportation',31,'Airports: 46(2005)
Airports • with paved runways:
total: W
over 3,047 m:Z
2,438 to 3.047 m: 4
1,524 to 2,437 m: 2
under 914 m;1 (2005)
Airports - with unpaved runways:
total: 36
over 3,047 m:1
2,438 to 3,047 m: 5
1.524 to 2, 437 m: 17
914 to 1,523 m: 4
under 914 m: 9 (2005)
Heliports: 9(2005)
Pipelines: gas 387 km (2004)
Roadways:
total: 34.789 km
paved: 8.231 km
unpaved: 26,558 km (2003)
Waterways: 1 .200 km (chiefly Amu Darya, which
handles vessels up to 500 DWT) (2005)
Ports and terminals: Kheyrabad, Shir Khan
Airports: 39(2005)
Airports - with paved runways:
total: 22
over 3,047 m:]
2,438 to 3,047 m: 10 ■
1,524 to 2,437 m: 9
914 to 1,523 m: 2 (2005)
Airports - with unpaved runways:
total: 17
1,524 to 2,437 m: 2
914 to 1,523 m:]
under 914 m:U (2005)
Heliports: 1 (2005)
Pipelines: gas 6,549 km; oil 1 ,395 km (2004)
Railways:
total: 2,440 km
broad gauge: 2,440 km 1.520-m gauge (2004)
Roadways:
total: 24,000 km
paved: 19,488 km
unpaved:4,512km(1999)
Waterways: 1 ,300 km (Amu Darya and Kara Kum
canal important inland waterways) (2006)
Merchant marine:
total: 8 ships (1000 GRT or over) 22,870 GRT/25,801
DWT
by type: barge carrier 1 , cargo 4, petroleum tanker 2,
refrigerated cargo 1 (2005)
Ports and terminals: Turkmenbasy
Airports: 8(2005)
Airports - with paved runways:
total: 6
1,524 to 2,437 m: 3
914 to 1,523 m:\\
under 914 m: 2 (2005)
Airports - with unpaved runways:
total: 2
under 914 m: 2 (2005)
Roadways:
tofa/:121 km
paved: 24 km
unpaved: 97 km (2003)
Ports and terminals: Grand Turk, Providenciales
Military - note: defense is the responsibility of the
UK','19a39891963275fe23cd444610f5a1086a449dc12f62a675d1e7be7d78a65cfa','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9708f39013614c6301b00b89dd64a9b2a8cf845c72279c2dd27f3704aec6ddc8',2007,'AL','Albania','transportation',40,'Airports: 11(2005)
Airports - with paved runways:
total: 3
2,438 to 3,047 m: 3 (2005)
Airports - with unpaved runways:
total: 8
over 3,047 m:\\
1,524 to 2,437 m: 2
914 to 1,523 /n:1
under 914 m: 4 (2005)
Heliports: 1 (2005)
Pipelines: gas 339 km; oil 207 km (2004)
Railways:
total: 447 km
standard gauge: 447 km 1 ,435-m gauge (2004)
Roadways:
total: 18,000 km
paved: 7,020 km
unpaved: 10,980 km (2002)
Waterways: 43 km (2006)
Merchant marine:
total: 23 ships (1000 GRT or over) 50,402 GRT
75,798 DWT
by type: cargo 22, roll on/roll off 1
foreign-owned: 1 (Turkey 1)
registered in other countries: 1 (Georgia 1 ) (2005)
Ports and terminals: Durres, Sarande, Shengjin,
Vlore
Albania (continued)
1','017f3ae706015486ac2e973ddc10e171ebf5fcecf327099e0d296cd52f1861c4','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52ccfdda89807f0bd6a217255627f32dc27a30092bc55b408ee408c312b3a064',2007,'ES','Spain','transportation',50,'Airports: 137(2005)
Airports - with paved runways:
total: 52
over 3, 04 7 m: 10
2,438 to 3,047 m: 27
1.524 to 2,437 m: 10
914 to 1,523 m: 4
under 914 m:1 (2005)
Airports - with unpaved runways:
tofa/:85
2,438 to 3,047 m: 2
1,524 to 2,437 m: 26
914 to 1.523 m: 38
under 914 m: 19 (2005)
Heliports: 1 (2005)
Pipelines: condensate 1 ,344 km; gas 85,946 km;
liquid petroleum gas 2,213 km; oil 6,496 km (2004)
Railways:
total: 3,973 km
standard gauge: 2,888 km 1 .435-m gauge (283 km
electrified)
narrow gauge: 1,085 km 1.055-m gauge (2004)
Roadways:
total: 104,000 km
paved: 71,656 km
unpaved: 32,344 km (1999)
Merchant marine:
total: 52 ships (1000 GRT or over) 840,484 GRT/
880.151 DWT
by type: bulk carrier 9, cargo 13, chemical tanker 4,
liquefied gas 9, passenger/cargo 5, petroleum tanker
6, roll on/roll off 6 (2005)
Ports and terminals: Algiers, Annaba, Arzew,
Bejaia, Djendjene, Jijel, Mostaganem, Oran, Skikda
Airports: none (2005)
Roadways:
total: 269 km
paved: 198 km
unpaved: 71 km
Military branches: no regular military forces, Police
Service of Andorra
Military - note: defense is the responsibility of
France and Spain
Airports: 1 (2005)
Airports • with paved runways:
total: 1
under 914 m:1 (2005)
Roadways:
fofa/:227km(2003)
Ports and terminals: Plymouth
Ports and terminals: McMurdo, Palmer, and
offshore anchorages in Antarctica
note: few ports or harbors exist on southern side of
Southern Ocean; ice conditions limit use of most to
short periods in midsummer; even then some cannot
be entered without icebreaker escort; most Antarctic
ports are operated by government research stations
and, except in an emergency, are not open to
commercial or private vessels; vessels in any port
south of 60 degrees south are subject to inspection by
Antarctic Treaty observers (see Article 7), Antarctica
(HCA), a special hydrographic commission of
International Hydrographic Organization (IHO), is
responsible for hydrographic surveying and nautical
charting matters in Antarctic Treaty area; it
coordinates and facilitates provision of accurate and
appropriate charts and other aids to navigation in
support of safety of navigation in region; membership
of HCA is open to any IHO Member State whose
government has acceded to the Antarctic Treaty and
which contributes resources and/or data to IHO Chart
coverage of the area; members of HCA are Argentina,
Australia, Chile, China, France, Germany, Greece,
India, Italy, New Zealand, Norway, Russia, South
Africa, Spain and the United Kingdom (2005)
Transportation - note: Drake Passage offers
alternative to transit through the Panama Canal','4b8a570dae0d9242e4744c3f268ab53b8132d3faa1890783c05503e4bbc21eba','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('453365965d8277e5f7b0441066fd820ea7d239b1bd1ea8def88917d1ceaa12f5',2007,'NZ','New Zealand','transportation',60,'Airports: 3(2005)
Airports - with paved runways:
total: 2
over 3,047 m: 1
914 to 1,523 m: 1(2005)
Airports - with unpaved runways:
total: 1
under 914 m: 1(2005)
Roadways:
tote/: 185 km (2004)
Ports and terminals: Pago Pago
Airports: 117(2005)
Airports • with paved runways:
total: 46
over 3,047 m: 2
2,438 to 3,047 m: 1
1.524 to 2,437 m: 11
91 ''4 to 1,523 m: 27
under 914 m: 5 (2005)
Airports - with unpaved runways:
total: 71
1,524 to 2,437 m: 2
914 to 1,523 m: 30
under 914 m: 39 (2005)
Pipelines: gas 2,213 km; liquid petroleum gas 79
km; oil 160 km; refined products 304 km (2004)
Railways:
total: 3,898 km
narrow gauge: 3,898 km 1 .067-m gauge (506 km
electrified) (2004)
Roadways:
total: 92,662 km
paved: 59,109 km (including 169 km of expressways)
unpaved: 33,553 km (2003)
Merchant marine:
total: 13 ships (1000 GRT or over) 125,916 GRT/
121,394 DWT
by type: bulk carrier 3, cargo 2, passenger/cargo 4,
petroleum tanker 2, roll on/roll off 2
foreign-owned: 4 (Australia 2, Germany 1 , Isle of Man
1)
registered in other countries: 6 (The Bahamas 1 ,
Marshall Islands 1, Panama 1, UK 1, Vanuatu 2)
(2005)
Ports and terminals: Auckland, Lyttelton,
Tauranga, Wellington, Whangarei
Airports: 6(2005)
Airports - with paved runways:
total: 1
2.438 to 3,047 m: 1 (2005)
Airports - with unpaved runways:
total: 5
1.524 to 2,437 m. 1
914 to 1,523 m: 3
under 914 m;1 (2005)
Roadways:
total: 680 km
paved: 184 km
unpaved: 496 km (1999)
Merchant marine:
total: 20 ships (1000 GRT or over) 102,427 GRT7
148.871 DWT
by type: bulk carrier 2, cargo 12, liquefied gas 2,
passenger/cargo 1 , petroleum tanker 1 , refrigerated
cargo 1 , roll on/roll off 1
foreign-owned: 5 (Australia 1 , Norway 1 . Switzerland
1. UK1, US 1)(2005)
Ports and terminals: Nukualofa
Military branches: Tonga Defense Services:
Ground Forces (Royal Marines, Royal Guard),
Maritime Force (includes Air Wing)
Military service age and obligation: 18 years of
age (est.) (2004)
Military expenditures - dollar figure: NA
Military expenditures - percent of GDP: NA
Airports: 6(2005)
Airports - with paved runways:
total: 3
over 3,047 m: 1
2,438 to 3,047 m:1
1,524 to 2,437 m: 1 (2005)
Airports - with unpaved runways:
total: 3
914 to 1,523 m;1
under 914 m: 2 (2005)
Pipelines: condensate 253 km; gas 1,117 km; oil
478 km (2004)
Roadways:
total: 8,320 km
paved: 4,252 km
unpaved: 4,068 km (1999)
Merchant marine:
total: 6 ships (1000 GRT or over) 12,671 GRT/2,749
DWT
by type: passenger 2, passenger/cargo 3, petroleum
tanker 1
foreign-owned:] (US 1)
registered in other countries: 3 (Panama 1 , unknown
2) (2005)
Ports and terminals: Pointe-a-Pierre, Point Lisas,
Port-of-Spain
Airports: 2(2005)
Airports - with paved runways:
total: 1
1,524 to 2, 437 m: 1(2005)
Airports - with unpaved runways:
total: 1
914 to 1,523 m: 1(2005)
Merchant marine:
total: 6 ships (1000 GRT or over) 106,003 GRT/
56,674 DWT
by type: chemical tanker 1 , passenger 5
foreign-owned: 5 (France 4, US 1) (2005)
Ports and terminals: Leava, Mata-Utu','a88573ea1dcea9d201a68e2c5d81bf06d5be9065f5cfac589b4986d1d0b50770','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f1da57edf6ad07a7bf1eba8af93dd3494d89611eb5e4b420e55591fb1113803',2007,'NA','Namibia','transportation',72,'Airports: 243(2005)
Airports - with paved runways:
total: 31
over 3,047 m: 5
2,438 to 3,047 m: 8
1,524 to 2,437 m: 12
914 to 1,523 m: 5
under 914 m: 1(2005)
Airports - with unpaved runways:
total: 212
over 3,047 m: 2
2,438 to 3,047 m: 5
1,524 to 2,437 m: 30
914 to 1,523 m: 95
under 914 m: 80 (2005)
Pipelines: gas 214 km; liquid natural gas 14 km;
liquid petroleum gas 30 km; oil 837 km; refined
products 56 km (2004)
Railways:
total: 2,761 km
narrow gauge: 2,638 km 1 .067-m gauge; 123 km
0.600-m gauge (2004)
Roadways:
total: 51 ,429 km
paved: 5,349 km
unpaved: 46,080 km (2001)
Waterways: 1 ,300 km (2005)
Merchant marine:
total: 4 ships (1000 GRT or over) 4,343 GRT/4,643
DWT
by type: cargo 1 , passenger/cargo 2, petroleum
tanker 1
registered in other countries: 5 (The Bahamas 5)
(2005)
Ports and terminals: Cabinda, Luanda, Soyo
Airports: 728(2005)
Airports • with paved runways:
tote/: 1 46
over 3, 047 m: 10
2,438 to 3,047 m: 5
1,524 to 2,437 m:51
914 to 1,523 m: 67
under 914 m: 13 (2005)
Airports - with unpaved runways:
total: 582
1,524 to 2,437 m: 34
914 to 1,523 m: 300
under 914 m: 248 (2005)
Pipelines: condensate 100 km; gas 1,052 km; oil
847 km; refined products 1,354 km (2004)
Railways:
total: 20,872 km
512
South Africa (continued)
narrow gauge: 20,436 km 1 .065-m gauge (10,436 km
electrified); 436 km 0.61 0-m gauge
note: includes a 1 ,210 km commuter rail system (2004)
Roadways:
total: 362,099 km
paved: 73,506 km
unpaved: 288,593 km (2002)
Merchant marine:
total: 3 ships (1000 GRT or over) 32,815 GR17
39,295 DWT
by type: container 1 , petroleum tanker 2
foreign-owned: 1 (Denmark 1 )
registered in other countries: 8 (Panama 3,
Seychelles 1, UK 4) (2005)
Ports and terminals: Cape Town, Durban, East
London, Port Elizabeth, Richards Bay, Saldanha Bay
Airports: none (2005)
Ports and terminals: Grytviken','bff5d53eb7455c5c90789e24cad336d5f8d914e59ae17fe8d77732df16f17e29','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('032b44614c1bfcccff47d384b7536ddea859d380fc29957165ce9dc6dcc5ffd0',2007,'PR','Puerto Rico','transportation',83,'Airports: 3(2005)
Airports - with paved runways:
total: 1
1,524 to 2,437 m:1 (2005)
Airports - with unpaved runways:
total: 2
under 914 m: 2 (2005)
Roadways:
fofa/:105km
paved: 65 km
unpaved: 40 km (2002)
Ports and terminals: Blowing Point, Road Bay','f4c950a034692c2b413ee67ad7566708ad826af952555dcada7676ea2560dcda','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12c2c3a769f037b0ad74b29f21488c3acd59816817ef4069b23a8dbbe053273f',2007,'AR','Argentina','transportation',93,'Airports: 28
note: there are no developed public access airports or
landing facilities; 28 stations or remote field locations,
operated by 1 1 National Antarctic Programs from
nations party to the Antarctic Treaty, have restricted
aircraft landing facilities comprising a total of 1 1
runways and 22 skiways for fixed-wing aircraft; some
stations have both runways and skiways; commercial
enterprises operate two aircraft landing facilities at
one station; helicopter pads are available at all 37
year-round and 1 5 seasonal stations operated by
National Antarctic Programs; the 1 1 runways are
suitable for wheeled, fixed-wing aircraft: three are
gravel, four blue-ice, two sea-ice and two compacted
snow; of these, five are 3 km in length, two are
between 2 km and 3 km in length, three are between
1 km and 2 km in length and one is less than 1 km in
length; the 22 snow surface skiways are limited to use
by ski-equipped, fixed-wing aircraft; of these, three are
equal to or greater than 3 km in length, one is between
2 km and 3 km in length, nine are between 1 km and
2 km in length, five are less than 1 km in length, and
four are of unknown or variable length; snow surface
skiways are generally prepared and maintained during
specific periods only and during summer; all aircraft
landing facilities subject to severe restrictions and
limitations resulting from extreme seasonal and
geographic conditions; aircraft landing facilities do not
meet ICAO standards; advance approval from the
respective governmental or nongovernmental
operating organization required for using their
facilities; landed aircraft are subject to inspection in
accordance with Article 7, Antarctic Treaty; guidelines
for the operation of aircraft near concentrations of
birds in Antarctica were adopted in 2004; relevant
legal instruments and authorization procedures
adopted by states party to the Antarctic Treaty
regulating access to the Antarctic Treaty area, that is
to all areas between 60 and 90 degrees of latitude
South, have to be complied with (see information
under "Legal System"); an Antarctic Flight Information
Manual (AFIM) providing up-to-date details of
Antarctic air facilities and procedures is maintained
and published by the Council of Managers of National
Antarctic Programs (2006)
Airports - with unpaved runways:
total: 28
over 3,047 m: 1
2,438 to 3,047 m:Q
1,524 to 2,437 m:1
914 to 1,523 m: 10
under 914 m: 4
length unknown or variable: 4 (2006)
Heliports: 37
note: all 37 year-round and 1 5 seasonal stations
operated by National Antarctic Programs stations
have restricted helicopter landing facilities (helipads)
(2006)
Ports and terminals: there are no developed ports
and harbors in Antarctica; most coastal stations have
offshore anchorages, and supplies are transferred
from ship to shore by small boats, barges, and
helicopters; a few stations have a basic wharf facility;
US coastal stations include McMurdo (77 51 S, 1 66 40
E), and Palmer (64 43 S, 64 03 W); government use
only except by permit (see Permit Office under "Legal
System"); all ships at port are subject to inspection in
accordance with Article 7, Antarctic Treaty; offshore
anchorage is sparse and intermittent; relevant legal
instruments and authorization procedures adopted by
the states parties to the Antarctic Treaty regulating
access to the Antarctic Treaty area, to all areas
between 60 and 90 degrees of latitude south, have to
be complied with (see "Legal System"); Antarctica
(HCA), a special hydrographic commission of
International Hydrographic Organization (IHO), is
responsible for hydrographic surveying and nautical
charting matters in Antarctic Treaty area; it
coordinates and facilitates provision of accurate and
23
Antarctica (continued)
appropriate charts and other aids to navigation in
support of safety of navigation in region; membership
of HCA is open to any IHO Member State whose
government has acceded to the Antarctic Treaty and
which contributes resources and/or data to IHO Chart
coverage of the area; members of HCA are Argentina,
Australia. Chile, China, France, Germany, Greece,
India, Italy, New Zealand, Norway, Russia, South
Africa, Spain, and the United Kingdom (2005)
Airports: 363(2005)
Airports - with paved runways:
total: 72
over 3,047 m: 5
2.438 to 3,047 m: 7
1,524 to 2,437 m: 22
91 4 to 1,523 m:2^
under 914 m:M (2005)
Airports - with unpaved runways:
total: 291
over 3,047 m: 1
2,438 to 3,047 m: 4
1.524 to 2,437 m: 11
914 to 1,523 m: 59
under 914 m: 21 6 (2005)
Pipelines: gas 2,583 km; gas/lpg 42 km: liquid
petroleum gas 539 km; oil 1 ,003 km; refined products
757 km (2004)
Railways:
total: 6,585 km
broad gauge: 2,831 km 1.676-m gauge (1,317 km
electrified)
narrow gauge: 3,754 km 1 .000-m gauge (2004)
Roadways:
total: 79,605 km
paved: 16,080 km (including 407 km of expressways)
unpaved: 63,525 km (2001)
Merchant marine:
total: 46 ships (1000 GRT or over) 692,268 GRT/
942,585 DWT
by type: bulk carrier 1 1 , cargo 6, chemical tanker 9,
container 1, liquefied gas 2, passenger 3, passenger
cargo 2, petroleum tanker 7, roll on/roll off 1, vehicie
carrier 4
registered in other countries: 19 (Argentina 4. Brazil
1 , Greece 1 , Liberia 1 , Marshall Islands 1 . Panama 1 1 )
(2005)
Ports and terminals: Antofagasta, Arica, Huasco,
Iquique, Lirquen, San Antonio, San Vicente,
Valparaiso
Airports: 880(2005)
Airports - with paved runways:
total: 12
over 3,047 m: 3
1,524 to 2,437 m: 5
914 to 1,523 m: 4 (2005)
Airports - with unpaved runways:
total: 868
1,524 to 2, 437 m: 26
914 to 1,523 m: 324
under 914 m: 51 8 (2005)
Railways:
total: 441 km
standard gauge: 441 km 1 .435-m gauge (2004)
Roadways:
total: 29,500 km
paved: 14,986 km
unpaved: 14,514 km (1999)
Waterways: 3,100 km (2005)
Merchant marine:
total: 20 ships (1000 GRT or over) 32,504 GRT/
32,915 DWT
by type: cargo 1 5, livestock carrier 1 , passenger 1 ,
petroleum tanker 2, roll on/roll off 1
foreign-owned: 2 (Argentina 2)
registered in other countries: 1 (Ecuador 1) (2005)
Ports and terminals: Asuncion, Villeta, San
Antonio, Encarnacion
Airports: 246(2005)
Airports - with paved runways:
total: 54
over 3,047 m: 6
2.438 to 3,047 m: 20
1.524 to 2, 437 m: 14
974 fo 7,523 m: 11
under 914 m: 3 (2005)
Airports - with unpaved runways:
total: 192
1.524 to 2.437 m: 22
914 to 1,523 m: 59
under 914 m: 111 (2005)
Heliports: 1 (2005)
Pipelines: gas 388 km; oil 1,557 km; refined
products 13 km (2004)
Railways:
total: 3,462 km
standard gauge: 2,962 km 1 .435-m gauge
narrow gauge: 500 km 0.91 4-m gauge (2004)
Roadways:
total: 78,672 km
paved: 10,314 km (including 276 km of expressways)
unpaved: 68,358 km (2003)
Waterways: 8,808 km
nofe: 8,600 km of navigable tributaries of Amazon
system and 208 km of Lago Titicaca (2005)
440
Peru (continued)
Merchant marine:
total: 4 ships (1000 GRT or over) 38,954 GRT/62,255
DWT
by type: cargo 3, petroleum tanker 1
foreign-owned: 1 (US 1 )
registered in other countries: 14 (Panama 14) (2005)
Ports and terminals: Callao, Iquitos, Matarani,
Pucallpa, Yurimaguas; note - Iquitos, Pucallpa, and
Yurimaguas are on the upper reaches of the Amazon
and its tributaries','41cb48fa013e8048f879f2749494149cfeed6a7cf28349dcbf9c1ac6fccd0b15','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7182cb61c811f3525d959c20e3f9c845aa7d12a0626527a8442478b825e60cbe',2007,'AG','Antigua and Barbuda','transportation',103,'Airports: 3(2005)
Airports - with paved runways:
total: 2
2,438 to 3,047 m: 1
under 914 m:1 (2005)
Airports • with unpaved runways:
total: 1
under 914 m: 1 (2005)
Roadways:
total: 1,165 km
pa^ed: 384 km
unpaved: 781 km (2002)
Merchant marine:
total: 981 ships (1000 GRT or over) 7,040,579 GRT/
9,274,996 DWT
by type: bulk carrier 38, cargo 614, chemical tanker 7,
container 283, liquefied gas 9, petroleum tanker 2.
refrigerated cargo 8, roll on/roll off 1 9, vehicle carrier 1
foreign-owned: 953 (Bangladesh 4, Belgium 3,
Colombia 2, Denmark 11, Estonia 12, Germany 853,
Iceland 7, Isle of Man 1 , Latvia 5, Lebanon 1 , Lithuania
1, Netherlands 10, Norway 10, Russia 6, Slovenia 6,
Switzerland 4, Turkey 5, UK 5, US 7) (2005)
Ports and terminals: Saint John''s
Ports and terminals: Churchill (Canada),
Murmansk (Russia), Prudhoe Bay (US)
Transportation - note: sparse network of air, ocean,
river, and land routes: the Northwest Passage (North
America) and Northern Sea Route (Eurasia) are
important seasonal waterways','1467c435ff9ea8f88162602720caf63daf3a37ac215ae5273fd002670d6bc320','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a660680edd959deb6505d80283c24e3d66e23a0cc6cdbed0fe6357563e2f68a',2007,'AQ','Antarctica','transportation',110,'Airports: 1,333(2005)
Airports - with paved runways:
fofa/: 144
over 3,047 m: 4
2,438 to 3,047 m: 26
1,524 to 2,437 m: 62
914 to 1,523 m: 44
under 914 m: 8 (2005)
Airports - with unpaved runways:
total: 1,189
over 3,047 m: 2
2,438 to 3,047 m: 2
1,524 to 2,437 m: 50
914 to 1,523 m: 569
under 914 m: 566 (2005)
Pipelines: gas 27,166 km; liquid petroleum gas 41
km; oil 3,668 km; refined products 2,945 km; unknown
(oil/water) 13 km (2004)
Railways:
total: 34,091 km (167 km electrified)
broad gauge: 20,594 km 1.676-m gauge (141 km
electrified)
standard gauge: 2,885 km 1.435-m gauge (26 km
electrified)
narrow gauge: 10,375 km 1 .000-m gauge; 237 km
0.750-m gauge (2004)
Roadways:
total: 229,144 km
paved: 68,809 km (including 734 km of expressways)
unpaved: 160,335 km (2004)
Waterways: 1 1 ,000 km (2005)
Merchant marine:
total: 37 ships (1000 GRT or over) 379,788 GRT/
609,005 DWT
by type: bulk carrier 2, cargo 10, chemical tanker 1 ,
passenger 1 , passenger/cargo 3, petroleum tanker
17, refrigerated cargo 2, roll on/roll off 1
foreign-owned: 9 (Chile 4, UK 4, Uruguay 1)
registered in other countries: 23 (Bolivia 1 , Liberia 8,
Panama 9, Paraguay 2, Uruguay 3) (2005)
Ports and terminals: Bahia Blanca, Buenos Aires.
Concepcion del Uruguay, La Plata, Punta Colorada,
Rosario, San Lorenzo-San Martin, San Nicolas','5e9c1f92e839846eece88fe3919f94060997a85fb78b1952eaaca48072b0975e','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef6bb1ebbb276a8f242df451b586b7c6555feee6d5141aae92152d4598e32d2a',2007,'AM','Armenia','transportation',117,'Airports: 16(2005)
Airports - with paved runways:
total: 1 1
over 3,047 m: 2
2,438 to 3,047m: 2
1,524 to 2,437 m: 4
91 4 to 1,523 m: 3 (2005)
Airports - with unpaved runways:
total: 5
1,524 to 2,437 m: 2
914 to 1,523 m: 2
under 914 m: 1 (2005)
Pipelines: gas 1 ,871 km (2004)
Railways:
total: 845 km
broad gauge: 845 km 1.520-m gauge (828 km
electrified)
note: some lines are out of service (2004)
Roadways:
total: 7,633 km
paved: 7,633 km (includes 1 ,561 km of expressways)
(2003)','9f179a808f92db8531cbb1e5c92df83db68140e6796494a532507c39ec3188fc','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('194625126c7ed5b588c855cc5c928f0278eac26e771596c5c9e2610f6b5f7539',2007,'NL','Netherlands','transportation',127,'Airports: 1 (2005)
Airports - with paved runways:
total: 1
2,438 to 3,047 m: 1 (2005)
Ports and terminals: Barcadera, Oranjestad, Sint
Nicolaas
Airports: 5(2005)
Airports - with paved runways:
total: 5
over 3,047 m: 1
2,438 to 3,047 m: 1
1.524 to 2,437 mA
914 to 1,523 m: 1
under 914 mA (2005)
Merchant marine:
total: 161 ships (1000 GRT or over) 1,338,891 GRT/
1,704,829 DWT
by type: barge carrier 3, bulk carrier 4, cargo 84,
chemical tanker 2, container 15, liquefied gas 6,
passenger 2, petroleum tanker 4, refrigerated cargo
33, roll on/roll off 4, specialized tanker 4
foreign-owned: 150 (Belgium 4, Cuba 1, Denmark 1,
Estonia 1 , Germany 52, Netherlands 69, Norway 2,
Sweden 9, Turkey 8, UK 2, US1)
registered in other countries: 1 (Netherlands 1)
(2005)
Ports and terminals: Bopec Terminal, Fuik Bay,
Kralendijk, Willemstad','778d378b14bd94c28b1780543b93f8cc28db0e1dc8b4e447a9ec60c8389178fc','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3550867b6ae94bbd6e826e6dd2c98e95a3c7c437c201eedc3c2e9f7c63cf1eab',2007,'AU','Australia','transportation',136,'Ports and terminals: Alexandria (Egypt), Algiers
(Algeria), Antwerp (Belgium), Barcelona (Spain),
Buenos Aires (Argentina), Casablanca (Morocco),
Colon (Panama), Copenhagen (Denmark), Dakar
(Senegal), Gdansk (Poland), Hamburg (Germany),
Helsinki (Finland), Las Palmas (Canary Islands,
Spain), Le Havre (France), Lisbon (Portugal), London
(UK), Marseille (France), Montevideo (Uruguay),
Montreal (Canada), Naples (Italy), New Orleans (US),
New York (US), Oran (Algeria), Oslo (Norway),
Peiraiefs or Piraeus (Greece), Rio de Janeiro (Brazil),
Rotterdam (Netherlands), Saint Petersburg (Russia),
Stockholm (Sweden)
35
Atlantic Ocean (continued)
Transportation - note: Kiel Canal and Saint
Lawrence Seaway are two important waterways;
significant domestic commercial and recreational use
of Intracoastal Waterway on central and south Atlantic
seaboard and Gulf of Mexico coast of US
Ports and terminals: none; offshore anchorage only
'' i t a r y
Military ■ note: defense is the responsibility of','c69aa1d85249c0265a71275d5311e7304208ebea9d5a6016a305f3ef19199c58','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03754181d788d3bfb5d85a92669cf3dbdee13433b2666e7c30b17a5f017f1792',2007,'ID','Indonesia','transportation',146,'Airports: 450(2005)
Airports - with paved runways:
total: 308
over 3, 04 7 m: 10
2,438 to 3,047 m: 12
1,524 to 2,437 m: 133
914 to 1.523 m: 140
under 914 m: 13 (2005)
Airports • with unpaved runways:
total: 142
1,524 to 2,437 m:18
914 to 1,523 m: 110
under 914 m:14 (2005)
Heliports: 1 (2005)
Pipelines: condensate/gas 492 km; gas 28.680 km;
liquid petroleum gas 240 km; oil 4,773 km; oil/gas/
water 110 km (2004)
Railways:
total: 54,652 km (3,859 km electrified)
broad gauge: 5,434 km 1.600-m gauge
standard gauge: 34,1 1 0 km 1 435-m gauge (1 ,397 km
electrified)
narrow gauge: 14.895 km 1 067-m gauge (2.462 km
electrified)
dual gauge: 213 km dual gauge (2004)
Roadways:
total: 81 1 ,601 km
paved: 316,524 km
unpaved: 495,077 km (2002)
Waterways: 2.000 km (mainly used for recreation on
Murray and Murray-Darling river systems) (2002)
Merchant marine:
total: 53 ships (1 000 GRT or over) 1 ,360,458 GRT/
1,532,874 DWT
by type: barge carrier 2, bulk carrier 15, cargo 5,
chemical tanker 3, container 1, liquefied gas 4,
passenger 6, passenger/cargo 6, petroleum tanker 6,
roll on/roll off 5
foreign-owned: 17 (Canada 1 , France 3, Germany 3,
Japan 1, Netherlands 2, Norway 1, Philippines 1, UK
2, US 3)
registered in other countries: 34 (The Bahamas 3,
Bermuda 2, Fiji 1 , Liberia 2, Marshall Islands 2,
Netherlands 1 , NZ 2, Panama 4, Portugal 1 ,
Singapore 6, Spain 1 , Tonga 1 , UK 4, US 2, Vanuatu
2) (2005)
Ports and terminals: Brisbane, Dampier,
Fremantle. Gladstone, Hay Point, Melbourne,
Newcastle, Port Hedland, Port Kembla, Port Walcott,
Sydney
Airports: 8(2005)
Airports - with paved runways:
total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m:1 (2005)
Airports - with unpaved runways:
total: 5
914 to 1,523 m: 3
under 914 m: 2 (2005)
Heliports: 9(2005)
Roadways:
total: 5,000 km
paved: 2,500 km
unpaved: 2,500 km (2005)
Ports and terminals: Dili
Ports and terminals: Chennai (Madras; India),
Colombo (Sri Lanka), Durban (South Africa), Jakarta
(Indonesia), Kolkata (Calcutta; India) Melbourne
(Australia), Mumbai (Bombay; India), Richards Bay
(South Africa)
Airports: 117(2005)
Airports • with paved runways:
total: 37
over 3,047 m: 5
2,438 to 3,047 m: 7
1,524 to 2,437 m:10
914 to 1,523 m:Q
under 914 m: 7 (2005)
Airports - with unpaved runways:
total: 80
1,524 to 2,437 m: 1
914 to 1,523 m: 7
under 914 m: 72 (2005)
Heliports: 1 (2005)
Pipelines: condensate 279 km; gas 5,047 km; oil
1,841 km; refined products 114 km (2004)
Railways:
total: 1 ,890 km (207 km electrified)
standard gauge: 57 km 1 ,435-m gauge (57 km
electrified)
narrow gauge: 1 ,833 km 1 .000-m gauge (150 km
electrified) (2004)
Roadways:
total: 71 ,814 km
paved: 55,943 km
unpaved: 15,871 km (2001)
Waterways: 7,200 km
note: Peninsular Malaysia 3,200 km, Sabah 1 ,500 km,
Sarawak 2,500 km (2005)
Merchant marine:
total: 312 ships (1000 GRT or over) 5,360,403 GRT/
7,353,105 DWT
by type: bulk carrier 18, cargo 105, chemical tanker
38, container 45, liquefied gas 26, livestock carrier 1 ,
passenger 1 , passenger/cargo 6, petroleum tanker
62, roll on/roll off 5, vehicle carrier 5
foreign-owned: 74 (China'' 1 , Germany 2, Hong Kong
14, Japan 1, Singapore 56)
registered in other countries: 66 (The Bahamas 1 2,
Belize 1, Cayman Islands 1, Panama 13, Philippines
1, Singapore 35, US 3) (2005)
Ports and terminals: Bintulu, Johor, Labuan, Lahad
Datu, Lumut, Miri, George Town (Penang), Port
Kelang, Tanjung Pelepas
Military branches: Malaysian Armed Forces
(Angkatan Tentera Malaysia, ATM): Malaysian Army
(Tentera Darat Malaysia), Royal Malaysian Navy
(Tentera Laut Diraja Malaysia, TLDM), Royal
Malaysian Air Force (Tentera Udara Diraja Malaysia,
TUDM) (2005)
Military service age and obligation: 18 years of
age for voluntary military service (2005)
Manpower available for military service:
males age 18-49: 5,584,231 (2005 est.)
Manpower fit for military service:
males age 18-49: 4,574,854 (2005 est.)
Manpower reaching military service age
annually:
ma/es: 244,41 8 (2005 est.)
Military expenditures • dollar figure: $1 .69 billion
(FY00 est.)
Military expenditures - percent of GDP: 2.03%
(FY00)
Airports: 6(2005)
Airports - with paved runways:
total: 6
1,524 to 2,437 m: A
914 to 1,523 m: 2 (2005)
Roadways:
total: 240 km
paved: 42 km
unpaged: 198 km (1999)
Merchant marine:
total: 2 ships (1 000 GRT or over) 2,423 GRT/1 ,551
DWT
by type: cargo 1 , passenger/cargo 1
foreign-owned: 2 (US 2) (2005)
Ports and terminals: Tomil Harbor
371
Micronesia, Federated States of (continued)
Military branches: no ministry of defense and no
standing armed forces; the paramilitary Maritime
A/ing, a small maritime law enforcement unit, is
esponsible to the Division of Maritime Surveillance
within the Office of the Attorney General (2003)
Military - note: Federated States of Micronesia
FSM) is a sovereign, self-governing state in free
association with the US; FSM is totally dependent on
tie US for its defense
Airports: 572(2005)
Airports - with paved runways:
total: 21
2,438 to 3,047 m: 2
1.524 to 2, 437 m: 14
914 to 1,523 m: 4
under 914 m:1 (2005)
Airports - with unpaved runways:
total: 551
1.524 to 2,437 m: 10
914 to 1,523 m: 62
under 914 m: 479 (2005)
Heliports: 2(2005)
Pipelines: oil 264 km (2004)
Roadways:
total: 19,600 km
paved: 686 km
unpaved: 18,914 km (1999)
Waterways: 10,940 km (2003)
Merchant marine:
total: 23 ships (1000 GRT or over) 49,261 GRT/
64,988 DWT
by type: bulk carrier 2, cargo 18, petroleum tanker 2,
roll on/roll off 1
foreign-owned: 6 (UK 6) (2005)
Ports and terminals: Kimbe, Lae, Rabaul
434
Papua New Guinea (continued)
Airports: 1 (2005)
Airports • with paved runways:
total: 1
1,524 to 2,437 m:1 (2005)
Ports and terminals: small Chinese port facilities on
Woody Island and Duncan Island being expanded
Airports: 256(2005)
Airports - with paved runways:
total: 83
over 3,047 m: 4
2,438 to 3,047 m:7
1,524 to 2,437 m: 26
914 to 1,523 m: 36
under 914 m: 10 (2005)
Airports - with unpaved runways:
total: m
1,524 to 2,437 m: 5
914 to 1,523 m: 68
under 914 m: 100 (2005)
Heliports: 2(2005)
Pipelines: gas 565 km; oil 135 km; refined products
100 km (2004)
Railways:
total: 897 km
narrow gauge: 897 km 1 .067-m gauge (492 km are in
operation) (2004)
Roadways:
total: 200,037 km
paved: 19,804 km
unpaved: 180,233 km (2003)
Waterways: 3,219 km (limited to vessels with draft
less than 1.5 m) (2005)
Merchant marine:
total: 413 ships (1000 GRT or over) 4,740,008 GBT/
6,595,554 DWT
by type: barge carrier 1 , bulk carrier 83, cargo 116,
chemical tanker 13, container 7, liquefied gas 6,
livestock carrier 17, passenger 10, passenger/cargo
72, petroleum tanker 47, refrigerated cargo 1 5, roll on/
roll off 14, vehicle carrier 12
foreign-owned: 67 (Canada 1 , Germany 2, Greece 7,
Hong Kong 2, India 1, Japan 25, Malaysia 1,
Netherlands 20, Taiwan 2, UAE 2, US 4)
registered in other countries: 45 (Australia 1 , The
Bahamas 1, Cambodia 1, Cayman Islands 1,
Comoros 1, Cyprus 2, Hong Kong 15, Indonesia 1,
Panama 17, Singapore 3, unknown 2) (2005)
Ports and terminals: Cagayan de Oro, Cebu,
Davao, lligan, lloilo, Manila, Surigao
Airports: none (2005)
Ports and terminals: Adamstown (on Bounty Bay)
Airports: 9(2005)
Airports - with paved runways:
total: 9
over 3,047 m: 2
2,438 to 3,047 m: A
1,524 to 2,437 m: 4
914 to 1,523 m: 1
under 914 mA (2005)
Pipelines: gas 139 km (2004)
Roadways:
total: 3, 165 km
paved: 3,130 km (including 150 km of expressways)
(2003)
Merchant marine:
total: 1 ,003 ships (1000 GRT or over) 29,1 16,937
GRT/46,51 7,745 DWT
by type: bulk carrier 149, cargo 85, chemical tanker
128, container 196, liquefied gas 45, livestock carrier
2, petroleum tanker 340, refrigerated cargo 8, roll on/
roll off 2, specialized tanker 9, vehicle carrier 39
499
Singapore (continued)
foreign-owned: 554 (Australia 6, Bangladesh 1 ,
Belgium 9, China 20, Denmark 44, Germany 7,
Greece 8, Hong Kong 53, India 4, Indonesia 49, Japan
93, South Korea 17, Malaysia 35, Netherlands 1,
Norway 96, Philippines 3, Slovenia 1, Sweden 12,
Taiwan 49, Thailand 23, UAE 7, UK 10, US 6)
registered in other countries: 277 (The Bahamas 14,
Bangladesh 9, Belize 4, Bolivia 2, Cambodia 4,
Cyprus 2, Dominica 1 1 , Honduras 1 2, Hong Kong 25,
Indonesia 14, Isle of Man 8, South Korea 1 , Liberia 1 6,
Malaysia 56, Marshall Islands 5, Mongolia 8, Nigeria
1 , Norway 4, Panama 57, Saint Vincent and the
Grenadines 7, Thailand 9, Tuvalu 2, Venezuela 1,
unknown 5) (2005)
Ports and terminals: Singapore','050d04d69c7b0eeb9f565b49ab36c723846f4ae9b31fae508c2914a275e5b2d5','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('497b05032258e4846adb19d435461ad14ea79802c45145d71ee64753105a4a0a',2007,'DE','Germany','transportation',156,'Airports: 55(2005)
Airports - with paved runways:
total: 24
over 3,047 m: 1
2,438 to 3,047 m: 5
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 914 m: 14 (2005)
Airports - with unpaved runways:
total: 31
1,524 to 2,437 m: 1
914 to 1,523 m: 3
under 91 ''4 m: 27 (2005)
Heliports: 1 (2005)
Pipelines: gas 2,722 km; oil 663 km; refined
products 149 km (2004)
Railways:
total: 6,021 km (3,552 km electrified)
standard gauge: 5,565 km 1.435-m gauge (3,430 km
electrified)
narrow gauge: 34 km 1 .000-m gauge (28 km
electrified); 422 km 0.760-m gauge (94 km electrified)
(2004)
Roadways:
total: 133,718 km
paved: 133,718 km (including 1,677 km of
expressways) (2003)
Waterways: 358 km (2003)
Merchant marine:
total: 8 ships (1000 GRT or over) 34,072 GRT/44,437
DWT
by type: cargo 6, container 2
foreign-owned: 2 (Netherlands 2)
registered in other countries: 15 (Liberia 14, Malta 1)
(2005)
Ports and terminals: Enns, Krems, Linz, Vienna
Airports: 552(2005)
Airports - with paved runways:
total: 332
over 3,047 m: 12
2,438 to 3,047 m: 55
1,524 to 2, 437 m: 58
914 to 1,523 m: 73
under 914 m: 134 (2005)
Airports - with unpaved runways:
total: 220
2,438 to 3,047 m: 1
1,524 to 2,437 m. 3
914 to 1,523 m: 33
under 914 m: 183 (2005)
Heliports: 33(2005)
Pipelines: condensate 325 km; gas 25,293 km; oil
3,540 km; refined products 3,827 km (2004)
Railways:
total: 46,166 km (20,100 km electrified)
standard gauge: 45,928 km 1.435-m gauge (20,084
km electrified)
narrow gauge: 214 km 1 .000-m gauge (16 km
electrified); 24 km 0.750-m gauge (2004)
Roadways:
total: 231 ,581 km
paved: 231,581 km (including 12,037 km of
expressways) (2003)
Waterways: 7,467 km
note: Rhine River carries most goods; Main-Danube
Canal links North Sea and Black Sea (2005)
Merchant marine:
total: 396 ships (1000 GRT or over) 10,833,329 GRT/
12,866,273 DWT
by type: barge carrier 1 , cargo 72, chemical tanker 14,
container 267, liquefied gas 3, passenger 5,
passenger/cargo 25, petroleum tanker 5,
roll on/roll off 4
foreign-owned: 3 (Finland 2, Switzerland 1)
registered in other countries: 2,303 (Antigua and
Barbuda 853, Australia 3, The Bahamas 12, Belgium 1 ,
Belize 3, Bermuda 1 , Brazil 7, Bulgaria 1 , Burma 5,
Cambodia 1 , Canada 3, Cayman Islands 1 4, Cyprus 21 1 ,
Ecuador 1 , Faroe Islands 1 , French Southern and
Antarctic Lands 2, Georgia 1 , Gibraltar 1 06, Guyana 1 ,
Hong Kong 7, Ireland 3, Isle of Man 55, Jamaica 2, North
Korea 1 , Liberia 510, Luxembourg 8, Malaysia 2, Malta
59, Marshall Islands 157, Morocco 2, Netherlands 58,
217
Germany (continued)
Netherlands Antilles 52, NZ 1 , Norway 2, Panama 29,
Philippines 2. Portugal 17, Russia 2, Saint Vincent and
the Grenadines 1 1 , Samoa 1 , Singapore 7, Spain 1 1 , Sri
Lanka 8, Sweden 4, Tuvalu 2, UK 63) (2005)
Ports and terminals: Bremen, Bremerhaven,
Brunsbuttel, Duisburg, Frankfurt, Hamburg,
Karlsruhe. Mainz, Rostock, Wilhemshaven
Airports: 2(2005)
Airports - with paved runways:
total: 1
over 3.047 m: 1 (2005)
Airports - with unpaved runways:
total: 1
under 914 m:1 (2005)
Heliports: 1 (2005)
Pipelines: gas 155 km (2004)
Railways:
total: 27 ''4 km
standard gauge: 274 km 1 .435-m gauge (242 km
electrified) (2004)
Roadways:
total: 5,210 km
paved: 5,210 km (including 147 km of expressways)
(2002)
Waterways: 37 km (on Moselle River) (2003)
Merchant marine:
total: 41 ships (1000 GRT or over) 509,517 GRT/
517,644 DWT
by type: chemical tanker 15, container 6, liquefied gas
2, passenger 3, petroleum tanker 4, roll on/roll off 1 1
foreign-owned: 41 (Belgium 1 5, Finland 3, France 9,
Germany 8, Netherlands 3, US 3) (2005)
Ports and terminals: Mertert
Airports: 1 (2005)
Airports - with paved runways:
total: 1
over 3,047 m:1 (2005)
Roadways:
total: 345 km
paved: 345 km (2003)
Ports and terminals: Macau
Airports: 17(2005)
Airports - with paved runways:
total: 10
2,438 to 3,047 m: 2
under 914 m: 8 (2005)
Airports - with unpaved runways:
total: 1
914 to 1,523 m: 3
under 914 m: 4 (2005)
Pipelines: gas 268 km; oil 120 km (2004)
Railways:
total: 699 km
standard gauge: 699 km 1 .435-m gauge (233 km
electrified) (2004)
Roadways:
total: 8,684 km
paved: 5,540 km
unpaved: 3,144 km (1999)','3d9028b3bea22c385cf5301e89b29500ac416e86569262cf76f31336689bdb95','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ec28f1b43e848ee8c351ad2b8bc56469651d969095a412ab8224b367bf5ef9a',2007,'AZ','Azerbaijan','transportation',164,'Airports: 45(2005)
Airports - with paved runways:
total: 27
over 3,047 m: 2
2,438 to 3,047 m: 6
1,524 to 2, 437 m. 15
914 to 1.523 m: 3
under 914 mA (2005)
Airports - with unpaved runways:
total: 18
914 to 1,523 m. 3
unde/-9J4m: 15 (2005)
Heliports: 2(2005)
Pipelines: gas 4.451 km; oil 1,518 km (2004)
43
Azerbaijan (continued)
Railways:
total: 2,957 km
broad gauge: 2,957 km 1 .520-m gauge (1 ,278 km
electrified) (2004)
Roadways:
fofa/:27,016km
paved: 12,698 km (including 128 km of expressways)
unpaved: 14,318 km (2003)
Merchant marine:
total: 84 ships (1000 GRT or over) 405,395 GRT7
437,088 DWT
by type: cargo 26, passenger 2, passenger/cargo 8,
petroleum tanker 43, roll on/roll off 2, specialized
tanker 3
registered in other countries: 4 (Georgia 2, Malta 2)
(2005)
Ports and terminals: Baku (Baki)','e5ac6833c914e28f8e6fbbcebf963785051ba0c7dfbe016fc9248be610cb0de2','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b860e57938e70562198e8e0e2d90142ce2430f5dbf33a2d733851e4a5350e61',2007,'BS','Bahamas','transportation',173,'Airports: 64(2005)
Airports - with paved runways:
total: 30
over 3,047 m: 2
2,438 to 3,047 m:3
1,524 to 2,437 m:14
914 to 1,523 m: 10
under 914 m:1 (2005)
Airports • with unpaved runways:
total: 34
1,524 to 2,437 m: 3
914 to 1,523 m: 9
under 914 m: 22 (2005)
Heliports: 1 (2005)
Roadways:
total: 2,693 km
paved: 1.546 km
unpaved: 1,147 km (1999)
Merchant marine:
total: 1,156
by type: barge carrier 1 , bulk carrier 226. cargo 251 ,
chemical tanker 60, combination ore/oil 18, container
71 , liquefied gas 31 , livestock carrier 2, passenger
118, passenger/cargo 37, petroleum tanker 171,
refrigerated cargo 121, roll on/roll off 18, specialized
tanker 4, vehicle carrier 27
foreign-owned: 1 ,070 (Angola 5, Australia 3, Belgium
1 1 , Canada 1 4, China 5, Croatia 1 , Cuba 1 , Cyprus
1 3, Denmark 65, Egypt 1 . Estonia 1 , Finland 7, France
28, Germany 12, Greece 217, Hong Kong 7,
Indonesia 2, Ireland 2, Israel 5, Italy 6, Japan 51,
Jordan 2, Kenya 1 , Latvia 1 , Malaysia 12, Monaco 17,
Netherlands 25, NZ 1 , Nigeria 2, Norway 258,
Philippines 1 , Poland 15, Reunion 1, Russia 4, Saudi
Arabia 12, Serbia and Montenegro 2, Singapore 14,
Slovenia 1, Spain 11, Sweden 10, Switzerland 7,
Thailand 1, Turkey 10, UAE 14, UK 68, US 121,
Uruguay 2)
registered in other countries: 5 (Barbados 1 , Liberia
2, Panama 1, unknown 1) (2005)
Ports and terminals: Freeport, Nassau, South
Riding Point','5b212cd65c3d4088b96b5f81c7871b8faa0c37f607e94515e6fba867c035fc53','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90dc20ec927c16fd7bf8377d0ef32e6bb7a13318844510cbac16872ae975fc16',2007,'BH','Bahrain','transportation',182,'Airports: 3(2005)
Airports - with paved runways:
total: 3
over 3,047 m: 2
1.524 to 2.437 m: 1 (2005)
Heliports: 1 (2005)
Pipelines: gas 20 km; oil 53 km (2004)
Roadways:
total: 3,498 km
paved: 2,768 km
unpaved: 730 km (2003)
48
Bahrain (continued)
Merchant marine:
total: 8 ships (1000 GRT or over) 235,449 GRT/
339,728 DWT
by type: bulk carrier 4, cargo 1 , container 2, petroleum
tanker 1
foreign-owned: 4 (India 1 , Kuwait 3) (2005)
Ports and terminals: Mina'' Salman, Sitrah
Airports: 5(2005)
Airports • with paved runways:
total: 3
over 3,047 m: 2
1,524 to 2,437 mA (2005)
Airports - with unpaved runways:
total: 2
914 to 1,523 mA
under 914 mA (2005)
Heliports: 1 (2005)
Pipelines: condensate 31 9 km; condensate/gas 209
km; gas 1 ,024 km; liquid petroleum gas 87 km; oil 702
km; oil/gas/water 41 km (2004)
Roadways:
total: 1,230 km
paved: 1,107 km
unpaved: 123 km (1999)
Merchant marine:
total: 21 ships (1000 GRT or over) 579,533 GRT/
852,015 DWT
by type: cargo 2, chemical tanker 4, container 8,
liquefied gas 2, petroleum tanker 4. roll on/roll off 1
foreign-owned: 8 (Kuwait 7, UAE 1) (2005)
Ports and terminals: Doha','c8eec5c1cbf769ae8bd94e39db9814f9b10119dd621806853a60544ca820fa6e','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6f7d2a3f077498cb8698e44d30db86fd1ff65baaceadbc726be97ef6cf3ca87',2007,'BD','Bangladesh','transportation',193,'Airports: 16(2005)
Airports - with paved runways:
total: 15
over 3,047 m:]
2,438 to 3,047 m: 4
1,524 to 2,437 m: 4
914 to 1,523 mA
under 914 m: 5 (2005)
Airports - with unpaved runways:
total: 1
1,524 to 2,437 m: 1(2005)
Pipelines: gas 2,012 km (2004)
Railways:
total: 2,706 km
broad gauge: 884 km 1 ,676-m gauge
narrow gauge: 1,822 km 1.000-m gauge (2004)
Roadways:
total: 239,226 km
paved: 22,726 km
unpaved: 216,500 km (2003)
Waterways: 8,372 km
note: includes 5,635 km main cargo routes; network
reduced to 5,200 km in dry season (2005)
Merchant marine:
total: 44 ships (1000 GRT or over) 360,053 GRT/
51 1,789 DWT
by type: bulk carrier 3, cargo 30, container 6,
passenger/cargo 1 , petroleum tanker 4
foreign-owned: 1 1 (China 1 , Saudi Arabia 1 ,
Singapore 9)
registered in other countries: 1 1 (Antigua and
Barbuda 4, Comoros 1 , Malta 3, Panama 1 , Saint
Vincent and the Grenadines 1, Singapore 1) (2005)
Ports and terminals: Chittagong, Mongla Port
Airports: 1 (2005)
Airports - with paved runways:
total: 1
over 3,047 m: 1 (2005)
Roadways:
total: 1,600 km
paved: 1 ,600 km (2003)
Merchant marine:
total: 57 ships (1000 GRT or over) 450,391 GRT/
703,307 DWT
by type: bulk carrier 12, cargo 32, chemical tanker 6,
passenger/cargo 1 , petroleum tanker 3, roll on/roll off
2, specialized tanker 1
foreign-owned: 55 (The Bahamas 1 , Canada 8,
Greece 1 1 , Lebanon 2, Monaco 1 , Norway 24, UAE 1 ,
UK 7)
registered in other countries: 1 (Saint Vincent and the
Grenadines 1) (2005)
Ports and terminals: Bridgetown
Ports and terminals: none; offshore anchorage only
Airports: 2(2005)
Airports - with paved runways:
total: 1
1,524 to 2,437 m: 1 (2005)
Airports - with unpaved runways:
total: 1
914 to 1,523 m:1 (2005)
Roadways:
total: 8,050 km
paved: 4,991 km
unpaved: 3,059 km (2003)','3a7237ff23f691ac2680d5c5e6170739359fccbdd58c47ae1edb3ba3c681a449','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c27ffbe9ac2889f3401809398a77daff03455773132f3d14a955fa1509cbca52',2007,'BY','Belarus','transportation',205,'Airports: 101 (2005)
Airports - with paved runways:
total: 44
over 3,047 m: 2
2,438 to 3,047 m: 22
1,524 to 2,437 m: 4
914 to 1,523 m:)
under 914 m: 15 (2005)
Airports - with unpaved runways:
total: 57
over 3,047 m: 2
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 7
under 914 m: 42 (2005)
Heliports: 1 (2005)
Pipelines: gas 5,223 km; oil 2,443 km; refined
products 1 ,686 km (2004)
Railways:
total: 5,51 2 km
broad gauge: 5,497 km 1 .520-m gauge (874 km
electrified)
standard gauge: 15 km 1.435-m (2004)
Roadways:
total: 93,055 km
paved: 93,055 km (2003)
Waterways: 2,500 km (use limited by location on
perimeter of country and by shallowness) (2003)
Ports and terminals: Mazyr
Military branches: Ground Force, Air and Air
Defense Force (2006)
Military service age and obligation: 1 8-27 years of
age for compulsory military service; conscript service
obligation -18 months (2005)
Manpower available for military service:
males age 18-49: 2,520,644 (2005 est.)
Manpower fit for military service:
males age 18-49: 1 ,657,984 (2005 est.)
Manpower reaching military service age
annually:
males: 85,202 (2005 est.)
Military expenditures - dollar figure: $420.5
million (2006)
Military expenditures - percent of GDP: 1 .4%
(FY02)
Airports: 47(2005)
Airports - with paved runways:
total: 23
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 13 (2005)
Airports - with unpaved runways:
total: 24
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 2
under 914 m: 19 (2005)
Pipelines: gas 1 ,097 km; oil 409 km; refined
products 415 km (2004)
Railways:
total: 2,303 km
broad gauge: 2,270 km 1 .520-m gauge (257 km
electrified)
narrow gauge: 33 km 0.750-m gauge (2004)
Roadways:
total: 69,919 km
pai/ed:69,919km(2003)
Waterways: 300 km (2005)
Merchant marine:
total: 20 ships (1000 GRT or over) 247,743 GRT/
332,058 DWT
by type: cargo 6, chemical tanker 1 , liquefied gas 2,
passenger/cargo 3, petroleum tanker 7, roll on/roll off 1
foreign-owned: 1 (Russia 1 )
registered in other countries: 102 (Antigua and
Barbuda 5, The Bahamas 1, Belize 4, Cambodia 1,
Cyprus 5, Dominica 2, Gibraltar 2, Liberia 17, Malta
36, Marshall Islands 6, Panama 4, Russia 2, Saint
Vincent and the Grenadines 17) (2005)
Ports and terminals: Riga, Ventspils
M i litar
Military branches: Latvian Republic Defense Force:
Ground Forces, Navy, Air Force, Border Guard, Home
Guard (Zemessardze) (2005)
Military service age and obligation: 19 years of
age for compulsory military service; conscript service
obligation - 1 2 months; 1 8 years of age for volunteers;
plans are to phase out conscription, tentatively moving
to an all-professional force by 2007; under current law,
every citizen is entitled to serve in the armed forces for
life (2004)
Manpower available for military service:
males age 19-49: 517,713 (2005 est.)
Manpower fit for military service:
males age 19-49: 361 ,098 (2005 est.)
Manpower reaching military service age
annually:
males: 19,137 (2005 est.)
Military expenditures - dollar figure: $87 million
(FY01)
Military expenditures - percent of GDP: 1 .2%
(FY01)','f6b98cb91f87addb397487f5b6af372e5b36e47bba5b2eb8696a739b07480fb6','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('943c9c797fd69e26257c71db7cda307a972a26fd0484247f11d9ecf65eb3744f',2007,'BE','Belgium','transportation',213,'Airports: 43(2005)
Airports • with paved runways:
total: 25
over 3,047 m: 6
2,438 to 3,047 m: 7
1,524 to 2,437 m: 3
914 to 1,523 m: 2
under 914 m: 7 (2005)
Airports • with unpaved runways:
total: 18
914 to 1,523 m: 2
under 914 m:16 (2005)
59
Belgium (continued)
Heliports: 1 (2005)
Pipelines: gas 1,485 km; oil 158 km; refined
products 535 km (2004)
Railways:
total: 3.521 km
standard gauge: 3,521 km 1.435-m gauge (2,927 km
electrified) (2004)
Roadways:
total: 149.757 km
paved: 117,110 km (including 1,747 km of
expressways)
unpaved: 32,647 km (2003)
Waterways: 2,043 km (1,528 km in regular
commercial use) (2003)
Merchant marine:
total: 68 ships (1000 GRT or over) 4,1 16,336 GRT/
6,962,448 DWT
by type: bulk carrier 20, cargo 3, chemical tanker 2,
container 12, liquefied gas 19, petroleum tanker 12
foreign-owned: 1 4 (Denmark 4, France 2, Germany 1 ,
Greece 4, Hong Kong 1 , Italy 1 , UK 1 )
registered in other countries: 105 (Antigua and
Barbuda 3, The Bahamas 1 1 , Belize 1 , Cyprus 1 ,
French Southern and Antarctic Lands 5, Georgia 1,
Gibraltar 1 , Greece 1 1 , Hong Kong 3, Luxembourg 1 5,
Malta 1 1 , Mozambique 2, Netherlands 2, Netherlands
Antilles 4, Panama 13, Portugal 7, Saint Vincent and
the Grenadines 2, Singapore 9, Sweden 3) (2005)
Ports and terminals: Antwerp, Brussels, Gent,
Liege, Oostende, Zeebrugge','24ba07226cc5f5829dc1c69967cc22e610a2482e5653d75feb8b73b086510dfe','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('191d628eebb55bb7fea005e07ff9785e8e03350e262dc89397bf96c97b5da067',2007,'GT','Guatemala','transportation',222,'Airports: 43(2005)
Airports - with paved runways:
total: 5
1,524 to 2,437 m: 1
914 to 1,523 m: 2
under 914 m: 2 (2005)
Airports - with unpaved runways:
total: 38
2.438 to 3,047 m: 1
914 to 1,523 m.H
under 914 m: 26 (2005)
Roadways:
total: 2,872 km
paved: 488 km
unpaved: 2,384 km (1999)
Waterways: 825 km (navigable only by small craft)
(2005)
Merchant marine:
total: 302 ships (1 000 GRT or over) 1 ,040,813 GRT/
1,398,275 DWT
by type: bulk carrier 29, cargo 21 8, chemical tanker 8,
container 6, passenger/cargo 5, petroleum tanker 17,
refrigerated cargo 13, roll on/roll off 5, specialized
tanker 1
foreign-owned: 173 (Belgium 1, China 71, Cyprus 2,
Estonia 5, Germany 3, Hong Kong 8, Iceland 1 ,
Indonesia 2, Italy 4, Japan 5, South Korea 5, Latvia 4,
Malaysia 1 , Mexico 1 , Pakistan 1 , Poland 2, Russia
33, Singapore 4, Spain 2, Switzerland 2, Turkey 8,
Ukraine 3, UAE 3, US 2) (2005)
Ports and terminals: Belize City
Military branches: Belize Defense Force (BDF):
Army, Maritime Wing, Air Wing, and Volunteer Guard
Military service age and obligation: 18 years of
age for voluntary military service; laws allow for
conscription only if volunteers are insufficient;
conscription has never been implemented; volunteers
typically outnumber available positions by 3:1 (2001)
Manpower available for military service:
males age 18-49: 60,750 (2005 est.)
Manpower fit for military service:
males age 18-49: 41 ,368 (2005 est.)
Manpower reaching military service age
annually:
males: 3,209 (2005 est.)
Military expenditures - dollar figure: $19 million
(2005 est.)
Military expenditures - percent of GDP: 1 .7%
(2005 est.)
Airports: 5(2005)
Airports - with paved runways:
total: 1
1,524 to 2,437 m: 1 (2005)
Airports - with unpaved runways:
total: 4
2,438 to 3.047 m: 1
1,524 to 2,437 mA
914 to 1,523 m: 2 (2005)
Railways:
total: 578 km
narrow gauge: 578 km 1 .000-m gauge (2004)
Roadways:
total: 6,787 km
paved: 1 ,357 km
unpaved: 5,430 km (1999)
Waterways: 150 km (on River Niger along northern
border) (2005)
Ports and terminals: Cotonou
Airports: 449(2005)
Airports - with paved runways:
total: 1 1
2,438 to 3,047 m: 3
1,524 to 2.437 m: 2
914 to 1.523 m: 4
under 914 m: 2 (2005)
Airports - with unpaved runways:
total: 438
2.438 to 3.047 m. 1
1,524 to 2,437 m: 8
914 to 1,523 m: 110
under 914 m: 319 (2005)
Pipelines: oil 480 km (2004)
Railways:
total: 886 km
narrow gauge: 886 km 0.91 4-m gauge (2004)
Roadways:
total: 14,095 km
paved: 4,863 km (including 75 km of expressways)
unpaved: 9.232 km (1999)
Waterways: 990 km
note: 260 km navigable year round: additional 730 km
navigable during high-water season (2004)
Ports and terminals: Puerto Quetzal, Santo Tomas
de Castilla','53d5c8e0417ef9b8c29b5a97518c90298f18e30d830af1bc6a52e1be3e7b370a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81b67fb30a8e70d4a8389f8d8ebc46b398e23d4322b9a1d00535b8113e3a4b2e',2007,'BM','Bermuda','transportation',232,'Airports: 1 (2005)
Airports - with paved runways:
total: 1
2,438 to 3,047 m: 1 (2005)
66
Bermuda (continued)
Roadways:
total: 447 km
paved: 447 km
note: public roads - 225 km; private roads - 222 km
(2002)
Merchant marine:
total: 118 ships (1000 GRT or over) 6,752,122 GRT7
7,464,181 DWT
by type: bulk carrier 25, cargo 2, container 25,
liquefied gas 17, passenger 16, passenger/cargo 6,
petroleum tanker 10, refrigerated cargo 1 1 , roll on/roll
off 6
foreign-owned: 101 (Australia 2, Canada 21, Finland
2, France 1 , Germany 1 , Greece 1 , Hong Kong 6,
Indonesia 1 , Ireland 1 , Israel 1 , Netherlands 1 , Nigeria
10, Norway 6, Sweden 12, Switzerland 1 , UK 8, US
26)
registered in other countries: 9 (Cayman Islands 2,
Liberia 1, Marshall Islands 4, Panama 2) (2005)
Ports and terminals: Hamilton, Saint George','5c13ac35fce4ed9192270299a6f4edc0f840ea78ad94729f89957e7cdaf22ff4','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d9e1a3f17b614f6490e1f2f461e12c7efde4338e8a135b3b9581a09063fdbd9',2007,'BR','Brazil','transportation',240,'Airports: 1,067(2005)
Airports - with paved runways:
tofa/M6
over 3,047 m: 4
2,438 to 3,047 m: 4
1,524 to 2,437 m: 5
914 to 1,523 m: 3 (2005)
Airports - with unpaved runways:
total: 1,051
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 60
914 to 1,523 m: 207
under 914 m: 780 (2005)
Pipelines: gas 4,860 km; liquid petroleum gas 47
km; oil 2,457 km; refined products 1 ,589 km; unknown
(oil/water) 247 km (2004)
Railways:
total: 3,519 km
narrow gauge: 3,519 km 1.000-m gauge (2004)
Roadways:
total: 60,762 km
paved: 4,314 km (including 11 km of expressways)
unpaved: 56,448 km (2003)
Waterways: 10,000 km (commercially navigable)
(2005)
71
Bolivia (continued)
Merchant marine:
total: 25 ships (1000 GRT or over) 125,674 GRT/
193,117 DWT
by type: bulk carrier 1 , cargo 10, chemical tanker 1 ,
container 1 , passenger/cargo 2, petroleum tanker 9,
refrigerated cargo 1
foreign-owned: 8 (Argentina 1, Egypt 1, Iran 1,
Singapore 2, Taiwan 1, US 1, Yemen 1) (2005)
Ports and terminals: Puerto Aguirre (on the
Paraguay/Parana waterway, at the Bolivia/Brazil
border); also, Bolivia has free port privileges in
maritime ports in Argentina, Brazil, Chile, and','885dcf46110c2ebf758321c29b28f0a70146f264d7354ea22152448cacab2021','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d9a0f9eb4c0c5c52e5185f81142e704bc41da674aaaa2160bdc6c3c2bb140ca',2007,'PY','Paraguay','transportation',249,'Airports: 27(2005)
Airports • with paved runways:
total: 8
2,438 to 3,047 m: 4
1,524 to 2,437 m:1
under 914 m: 3 (2005)
Airports - with unpaved runways:
total: ]9
1,524 to 2,437 m:\\
914 to 1,523 m: 7
under 914 m:11 (2005)
Heliports: 5(2005)
Railways:
tote/: 1,021 km (795 km electrified)
standard gauged ,021 km 1.435-m gauge (2004)
Roadways:
total: 21,846 km
paved: 1 1 ,425 km
unpaved: 10,421 km (1999)
Waterways: Sava River (northern border) open to
shipping but use limited (2006)
Ports and terminals: Bosanska Gradiska, Bosanski
Brod, Bosanski Samac, and Brcko (all inland
waterway ports on the Sava), Orasje','1f19f049066d49dc768ce905851a79fea61df685e33b65aff862e51fae648a76','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('160c05c0e45648b7882ec347651ebd51b2c7ed4ca2952beddef2affb7de2f3d2',2007,'BW','Botswana','transportation',255,'Airports: 85(2005)
Airports - with paved runways:
total: 10
2,438 to 3,047 m: 2
1,524 to 2,437 m: 7
914 to 1,523 m: 1 (2005)
Airports - with unpaved runways:
total: 75
1,524 to 2,437 m: 3
914 to 1,523 m: 55
under 914 m: 17 (2005)
Railways:
total: 888 km
narrow gauge: 888 km 1 .067-m gauge (2004)
Roadways:
total: 25,233 km
paved: 8,867 km
unpaved: 16,366 km (2003)','e35cd09c659cd930bce67a773960b9f7b6d6a0890b8265b0613982377849c835','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ed803db53d884816265e868d67d847dfc7f9b800fd720ec6db5705c9f44e8bb',2007,'NO','Norway','transportation',270,'Airports: 4,223(2005)
Airports - with paved runways:
total: 709
over 3,047 m: 8
2,438 to 3,047 m: 24
1,524 to 2,437 m: 162
914 to 1,523 m: 463
under 914 m: 52 (2005)
Airports - with unpaved runways:
total: 3,514
over 3,047 m: 2
1,524 to 2,437 m: 79
914 to 1,523 m: 1,609
under 914 m: 1,824 (2005)
Heliports: 417(2005)
Pipelines: condensate/gas 244 km; gas 10,739 km;
liquid petroleum gas 341 km; oil 5,212 km; refined
products 4,755 km (2004)
Railways:
total: 29,412 km (1,567 km electrified)
broad gauge: 4,907 km 1 .600-m gauge (908 km
electrified)
standard gauge: 1 94 km 1 .440-m gauge
narrow gauge: 23,915 km 1 ,000-m gauge (581 km
electrified)
dual gauge: 396 km 1 .000-m and 1 .600-m gauges
(three rails) (78 km electrified) (2004)
Roadways:
total: 1,724,929 km
paved: 94,871 km
unpaved: 1 ,630,058 km (2000)
Waterways: 50,000 km (most in areas remote from
industry and population) (2005)
Merchant marine:
total: 140 ships (1000 GRT or over) 2,253,902 GRT/
3,473,166 DWT
by type: bulk carrier 23, cargo 23, chemical tanker 8,
container 8, liquefied gas 12, passenger/cargo 12,
petroleum tanker 46, roll on/roll off 8
foreign-owned: 17 (Chile 1 , Germany 7, Norway 2,
Spain 6, UK 1)
registered in other countries: 1 (Ghana 1 , Liberia 4,
Panama 2) (2005)
Ports and terminals: Gebig, Itaqui, Rio de Janeiro,
Rio Grande, San Sebasttiao, Santos, Sepetiba
Terminal, Tubarao, Vitoria
Milita
Military branches: Brazilian Army, Brazilian Navy
(Marinha do Brasil (MB), includes Naval Air and
Marines), Brazilian Air Force (Forca Aerea Brasileira,
FAB) (2006)
Military service age and obligation: 21 -45 years of
age for compulsory military service; conscript service
obligation - nine to 12 months; 17-45 years of age for
voluntary service; an increasing percentage of the
ranks are "long-service" volunteer p-ofessionals;
women were allowed to serve in the armed forces
beginning in early 1980s when the Brazilian Army
became the first army in South America to accept
women into career ranks; women serve in Navy and
Air Force only in Women''s Reserve Corps (2001 )
Manpower available for military service:
males age 19-49: 45,586,036 (2005 est.)
Manpower fit for military service:
males age 19-49: 33,1 19,098 (2005 est.)
Manpower reaching military service age
annually:
males: 1,785,930 (2005 est.)
Military expenditures • dollar figure: $9.94 billion
(2005 est.)
Military expenditures - percent of GDP: 1 .3%
(2005 est.)
Airports: 1 (2005)
Airports - with paved runways:
total: 1
over 3,047 m:\\ (2005)
Ports and terminals: Diego Garcia
Airports: 3(2005)
Airports - with paved runways:
total: 2
914 to 1,523 m:1
under 914 m:1 (2005)
Airports - with unpaved runways:
total: 1
914 to 1,523 m: 1 (2005)
Roadways:
fofa/:177km
paved: 177 km (2002)
Merchant marine:
registered in other countries: 1 (North Korea 1 ) (2005)
Ports and terminals: Road Town
Brunei
s
M il
i t a r y
Airports: 100(2005)
Airports - with paved runways:
total: 67
2,438 to 3,047 m: 13
1,524 to 2, 437 m: 12
914 to 1,523 m: 13
under 914 m: 29 (2005)
Airports - with unpaved runways:
total: 33
914 to 1,523 m: 6
under 914 m: 27 (2005)
Heliports: 1 (2005)
Pipelines: condensate 411 km; gas 6,199 km; oil
2,213 km; oil/gas/water 746 km; unknown (oil/water)
38 km (2004)
Railways:
total: 4,077 km
standard gauge: 4,077 km 1 .435-m gauge (2,518 km
electrified) (2004)
Roadways:
total: 91,916 km
paved: 71 ,235 km (including 21 3 km of expressways)
unpaved: 20,681 km (2003)
Waterways: 1 ,577 km (2002)
Merchant marine:
total: 694 ships (1000 GRT or over) 15,804,021 GRT/
21,843,570 DWT
by type: barge carrier 4, bulk carrier 45, cargo 145,
chemical tanker 142, combination ore/oil 16, container
2, liquefied gas 80, passenger/cargo 115, petroleum
tanker 72, refrigerated cargo 6, roll on/roll off 21 ,
specialized tanker 2, vehicle carrier 44
foreign-owned: 161 (China 3, Cyprus 2, Denmark 31,
Estonia 1, Finland 4, Germany 2, Hong Kong 50,
Iceland 3, Italy 4, Japan 1 , Lithuania 1 , Monaco 3,
Netherlands 3, Poland 3, Saudi Arabia 7, Singapore 4,
Sweden 22, UK 4, US 13)
registered in other countries: 794 (Antigua and
Barbuda 10, Australia 1, The Bahamas 258, Barbados
24, Bermuda 6, Brazil 2, Cambodia 1 , Canada 1 ,
Cayman Islands 2, Comoros 1 . Cook Islands 1 , Cyprus
14, Denmark 3, Dominica 1 , Estonia 2, Faroe Islands 4,
Finland 1 , French Southern and Antarctic Lands 3,
Gibraltar 9, Hong Kong 22, Ireland 1 , Isle of Man 23,
Liberia 46, Malta 43, Marshall Islands 35, Mexico 1 ,
Netherlands 6, Netherlands Antilles 2, Nigeria 1 ,
Panama 57, Portugal 8. Russia 1 . Saint Vincent and the
Grenadines 17, Singapore 96. Spain 7, Sweden 8,
Thailand 30, Tonga 1 , UK 40, US 2, unknown 3) (2005)
Ports and terminals: Borg Havn, Bergen, Mo i
Rana, Molde, Mongstad, Narvik, Oslo, Sture','aa046c0439977811ca2b1c9a8dde9def7d4223052a6ee8b8c42ee58096260cfb','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0485e194cbd90004918ea4c2de887d0524d8868366480ac2f051e4490c4660c1',2007,'MY','Malaysia','transportation',278,'Airports: 2(2005)
Airports • with paved runways:
total: 1
over 3,047 m;1 (2005)
Airports - with unpaved runways:
total: 1
914 to 1,523 m: 1(2005)
Heliports: 3(2005)
Pipelines: gas 665 km; oil 439 km (2004)
Roadways:
total: 1,150 km
paved: 399 km
unpaved: 751 km (1999)
Waterways: 209 km (navigable by craft drawing less
than 1 .2 m) (2005)
Merchant marine:
total: 8 ships (1000 GRT or over) 465,937 GRT/
413,393 DWT
by type: liquefied gas 8
foreign-owned: 8 (UK 8) (2005)
Ports and terminals: Lumut, Muara, Seria
Airports: 108(2005)
Airports - with paved runways:
total: 65
over 3,047 m: 1
2,438 to 3,047 m: 10
1,524 to 2,437 m: 24
914 to 1,523 m: 19
under 914 m: 5 (2005)
Airports • with unpaved runways:
total: 43
over 3,047 m:]
1,524 to 2,437 /n:1
914 to 1,523 m: 15
under 914 m: 26 (2005)
Heliports: 3(2005)
Pipelines: gas 3,1 12 km; refined products 265 km
(2004)
Railways:
total: 4,071 km
narrow gauge: 4,071 km 1.000-m gauge (2004)
Roadways:
total: 57,403 km
paved: 56,542 km
unpaved: 861 km (2000)
Waterways: 4,000 km
note: 3,701 km navigable by boats with drafts up to
0.9 m (2005)
Merchant marine:
total: 394 ships (1000 GRT or over) 2,815,932 GRT/
4,341,947 DWT
by type: bulk carrier 59, cargo 145, chemical tanker
14, combination ore/oil 1, container 20, liquefied gas
28, passenger 3, passenger/cargo 5, petroleum
tanker 89, refrigerated cargo 29, specialized tanker 1
foreign-owned: 45 (Indonesia 1 , Japan 4, South Korea
1 , Norway 30, Singapore 9)
registered in other countries: 37 (The Bahamas 1 ,
Liberia 1, Mongolia 1, Panama 10, Singapore 23,
Tuvalu 1) (2005)
Ports and terminals: Bangkok, Laem Chabang,
Prachuap Port, Si Racha
Airports: 9(2005)
Airports - with paved runways:
total: 2
2,438 to 3,047 m: 2 (2005)
Airports - with unpaved runways:
total: 7
914 to 1,523 m: 5
under 914 m: 2 (2005)
Railways:
total: 568 km
narrow gauge: 568 km 1 .000-m gauge (2004)
Roadways:
total: 7,520 km
paved: 2,376 km
unpaved: 5,144 km (1999)
Waterways: 50 km (seasonally on Mono River
depending on rainfall) (2005)
Merchant marine:
total: 2 ships (1000 GRT or over) 3,918 GRT/3,852
DWT
by type: cargo 1 , refrigerated cargo 1 (2005)
Ports and terminals: Kpeme, Lome','d93671ee62f05ac6e40f9b676ea8bb794edf1de9edaf1e698797824379b88df0','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92f224931ec2194ff41229fa3dd87ad1ae2be52dc7e773c1cf49b8325e3fcb13',2007,'BG','Bulgaria','transportation',287,'Airports: 213(2005)
Airports - with paved runways:
total: 128
over 3,047 m: ■)
2.438 to 3,047 m: 19
1.524 to 2, 437 m: 15
914 to 1.523 m: 1
under 914 m: 92 (2005)
Airports - with unpaved runways:
total: 85
1.524 to 2,437m: 2
914 to 1,523 m:11
under 914 m: 72 (2005)
Heliports: 1 (2005)
Pipelines: gas 2,425 km; oil 339 km; refined
products 156 km (2004)
Railways:
total: 4,294 km
standard gauge: 4,049 km 1 .435-m gauge (2,710 km
electrified)
narrow gauge: 245 km 0.760-m gauge (2004)
Bulgaria (continued)
Roadways:
total: 102,016 km
paved: 93,855 km (including 328 km of expressways)
unpaved: 8,161 km (2003)
Waterways: 470 km (2006)
Merchant marine:
total: 73 ships (1000 GRT or over) 862,164 GRT/
1,276,562 DWT
by type: bulk carrier 40, cargo 15, chemical tanker 4,
container 6, passenger/cargo 1, petroleum tanker 3,
roll on/roll off 4
foreign-owned: 1 (Germany 1 )
registered in other countries: 40 (Cambodia 1 ,
Comoros 1, Malta 14, Saint Vincent and the
Grenadines 16, Slovakia 7, unknown 1) (2005)
Ports and terminals: Burgas, Varna','6669d8673ce4e9da59d72c85c824ad17f169d3fbab46a16562adde12672ff59c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a04b6356d6577212518b40b6d904e9b7b4d99406b7b9e6139cf6c38977cd4559',2007,'BF','Burkina Faso','transportation',295,'Airports: 33(2005)
Airports - with paved runways:
total: 2
over 3,047 m; 1
2,438 to 3,047 m: 1 (2005)
Airports - with unpaved runways:
total: 31
1,524 to 2,437 m: 3
914 to 1,523 m.H
under 914 m: 17 (2005)
Railways:
total: 622 km
narrow gauge: 622 km 1 .000-m gauge
note: another 660 km of this railway extends into Cote
D''lvoire (2004)
Roadways:
total: 12,506 km
paved: 2,001 km
unpaved: 10,505 km (1999)
Burma
a r y
Military branches: Army, Air Force, National
Gendarmerie (2005)
Military service age and obligation: 1 8 years of
age for compulsory military service; 20 years of age
for voluntary military service (2001)
Manpower available for military service:
males age 18-49: 2,664,572 (2005 est.)
Manpower fit for military service:
males age 18-49: 1 ,323,548 (2005 est.)
Military expenditures - dollar figure: $74.83
million (2005 est.)
Military expenditures - percent of GDP: 1 .3%
(2005 est.)','258ff0c00d7ce359667dab355ff26f965e760b37cd3369414239cd7d1fe7455b','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('703e19890e6a69fff836998766ffa8db04752c25bee543899998ef54043956f6',2007,'TH','Thailand','transportation',305,'Airports: 84(2005)
Airports - with paved runways:
total: 19
over 3,047 m: 6
2,438 to 3,047 m: 10
1,524 to 2,437 m: 3 (2005)
Airports - with unpaved runways:
total: 65
1,524 to 2,437 m: 14
914 to 1,523 m: 19
under 914 m: 32 (2005)
Heliports: 1 (2005)
Pipelines: gas 2,056 km; oil 558 km (2004)
Railways:
total: 3,955 km
narrow gauge: 3,955 km 1.000-m gauge (2004)
Roadways:
total: 27,000 km
paved: 3,200 km
unpaved: 23,800 km (2005)
Waterways: 12,800 km (2005)
Merchant marine:
total: 34 ships (1000 GRT or over) 402,724 GRT/
620,642 DWT
by type: bulk carrier 8, cargo 18, passenger 2,
passenger/cargo 3, roll on/roll off 2, specialized tanker
1
foreign-owned: 9 (Germany 5, Japan 4) (2005)
Ports and terminals: Moulmein, Rangoon, Sittwe
Airports: 668(2005)
Airports - with paved runways:
total: 161
over 3,047 m: 4
2,438 to 3,047 m;15
1,524 to 2,437 m: 48
914 to 1,523 m: 51
under 914 m: 43 (2005)
Airports - with unpaved runways:
total: 507
1,524 to 2,437 m: 6
91 ''4 to 1,523 m: 26
under 914 m: 475 (2005)
Heliports: 23(2005)
Pipelines: condensate 850 km; condensate/gas 128
km; gas 8,506 km; oil 7,472 km; oil/gas/water 66 km;
refined products 1 ,329 km (2004)
Railways:
total: 6,458 km
narrow gauge: 5,961 km 1.067-m gauge (125 km
electrified); 497 km 0.750-m gauge (2004)
Roadways:
total: 368,360 km
paved: 21 3,649 km
unpaved: 154,711 km (2002)
Waterways: 21,579 km (2005)
267
Indonesia (continued)
Merchant marine:
total: 750 ships (1000 GRT or over) 3,431 ,605 GRT7
4,598,038 DWT
by type: barge carrier 1 , bulk carrier 38, cargo 422,
chemical tanker 18, container 41, liquefied gas 6,
livestock carrier 1 , passenger 40, passenger/cargo
37, petroleum tanker 126, refrigerated cargo 2, roll on/
roll off 13, specialized tanker 3, vehicle carrier 2
foreign-owned: 25 (France 1 , Japan 4, South Korea 1 ,
Philippines 1, Singapore 14, Switzerland 2, UK 2)
registered in other countries: 117 (The Bahamas 2,
Belize 2, Bermuda 1 , Cambodia 1 , Denmark 1 ,
Georgia 1 , Honduras 1 , Hong Kong 3, Liberia 1 , Malta
1 . Panama 50, Singapore 49, Thailand 1 , unknown 3)
(2005)
Ports and terminals: Banjarmasin, Belawan,
Ciwandan, Krueg Geukueh, Palembang, Panjang,
Sungai Pakning, Tanjung Perak, Tanjung Priok
Airports: 310(2005)
Airports - with paved runways:
total. 129
over 3,047 m: 40
2,438 to 3,047 m: 26
1.524 to 2,437 m: 25
914 to 1,523 m: 33
under 9/4 m: 5 (2005)
Airports - with unpaved runways:
total: 181
over 3.047 m: 1
7,524 to 2,437 m: 8
9?4to 1,523 m: 130
under 974 m: 42 (2005)
Heliports: 15(2005)
Pipelines: condensate/gas 212 km; gas 16,998 km;
liquid petroleum gas 570 km; oil 8,256 km; refined
products 7,808 km (2004)
Railways:
total: 7,203 km
broad gauge: 94 km 1 .676-m gauge
standard gauge: 7,109 km 1 .435-m gauge (189 km
electrified) (2004)
Roadways:
total: 178,152 km
paved: 1 18,1 15 km (including 751 km of
expressways)
unpaved: 60,037 km (2002)
Waterways: 850 km (850 km on Karun River;
additional service on Lake Urmia) (2006)
Merchant marine:
total: 143 ships (1000 GRT or over) 5,129,056 GR17
8,908,336 DWT
by type: bulk carrier 38, cargo 48, chemical tanker 4,
container 14, liquefied gas 1 , passenger 1 , passenger/
cargo 4, petroleum tanker 30, roll on/roll off 3
foreign-owned: 1 (UAE 1 )
registered in other countries: 1 9 (Bolivia 1 , Cyprus 2,
Isle of Man 1 , Kuwait 1 , Malta 9, Panama 4, Saint
Vincent and the Grenadines 1 ) (2005)
Ports and terminals: Assaluyeh, Bushehr
Airports: 111 (2005)
Airports • with paved runways:
total: 78
over 3, 047 m: 20
2.438 to 3,047 m: 37
1,524 to 2,437 m: 5
914 to 1,523 m: 7
under 914 m: 9 (2005)
Airports - with unpaved runways:
total: 33
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 5
914 to 1,523 m: 12
under 914 m:1 0(2005)
Heliports: 8(2005)
Pipelines: gas 1 ,739 km; oil 5,418 km; refined
products 1 ,343 km (2004)
Railways:
total: 2,200 km
standard gauge: 2,200 km 1 .435-m gauge (2004)
Roadways:
total: 45,550 km
paved: 38,399 km
unpaved: 7,151 km (1999)
Waterways: 5,279 km
note: Euphrates River (2,815 km), Tigris River (1 ,899
km), and Third River (565 km) are principal waterways
(2004)
Merchant marine:
total: 13 ships (1000 GRT or over) 67,796 GRT/
101,317 DWT
by type: cargo 1 1 , petroleum tanker 2 (2005)
Ports and terminals: Al Basrah, Khawr az Zubayr,
Umm Qasr
Airports: 44(2005)
Airports - with paved runways:
total: 9
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m: 3 (2005)
Airports - with unpaved runways:
total: 35
1,524 to 2,437 m: 1
914 to 1,523 m: 13
under 914 m:21 (2005)
Pipelines: refined products 540 km (2004)
Roadways:
total: 32,620 km
paved: 4,590 km
unpaved: 28,030 km (2002)
Waterways: 4,600 km
note: primarily Mekong and tributaries; 2,897
additional km are intermittently navigable by craft
drawing less than 0.5 m (2005)
Merchant marine:
total: 1 ships (1000 GRT or over) 2,370 GRT/3,1 10
DWT
by type: cargo 1 (2005)
Military branches: Lao People''s Army (LPA;
includes Riverine Force), Air Force
Military service age and obligation: 15 years of
age for compulsory military service; conscript service
obligation - minimum 18 months (2004)
Manpower available for military service:
males age 15-49: 1 ,500,625 (2005 est.)
Manpower fit for military service:
males age 15-49: 954,816 (2005 est.)
Manpower reaching military service age
annually:
males: 73,167 (2005 est.)
Military expenditures - dollar figure: $1 1 .04
million (2005 est.)
Military expenditures - percent of GDP: 0.4%
(2005 est.)
Military - note: Laos is one of the world''s least
developed countries; the Lao People''s Armed Forces
are small, poorly funded, and ineffectively resourced;
there is little political will to allocate sparse funding to
the military, and the armed forces'' gradual
degradation is likely to continue; the massive drug
production and trafficking industry centered in the
Golden Triangle makes Laos an important narcotics
transit country, and armed Wa and Chinese
smugglers are active on the Lao-Burma border (2005)
Airports: 28(2005)
Airports - with paved runways:
total: 23
over 3,047 m: 7
2,438 to 3,047 m: 5
1,524 to 2,437 m: 10
914 to 1,523 m: 1(2005)
Airports - with unpaved runways:
total: 5
1,524 to 2.437 m: 1
914 to 1,523 m: 2
under 91 ''4 m: 2 (2005)
Pipelines: condensate/gas 432 km; gas 210 km; oil
3 km; refined products 206 km (2004)
Railways:
total: 2,600 km
standard gauge: 178 km 1 .435-m gauge
narrow gauge: 2,1 69 km 1 .000-m gauge
dual gauge: 253 km three-rail track combining
1. 435-m and 1. 000-m gauges (2004)
Roadways:
fora/:215,628km(2000)
Waterways: 17,702 km (5,000 km navigable by
vessels up to 1 .8 m draft) (2005)
Merchant marine:
total: 235 ships (1000 GRT or over) 1 ,290,526 GRT/
1,961 ,403 DWT
by type: bulk carrier 21 , cargo 1 76, chemical tanker 4,
container 4, liquefied gas 5, petroleum tanker 21,
refrigerated cargo 2, roll on/roll off 1, specialized
tanker 1
foreign-owned: 1 (Denmark 1)
registered in other countries: 12 (Cyprus 1 , Honduras
1 , Mongolia 7, Panama 2, Saint Vincent and the
Grenadines 1) (2005)
Ports and terminals: Hai Phong, Ho Chi Minh City
Airports: 2(2005)
Airports - with paved runways:
total: 2
1,524 to 2, 437 m: 2 (2005)
Roadways:
total: 1,257 km (2004)
Ports and terminals: Charlotte Amalie, Limetree
Bay','f780b81c4d46708e5f6593671c64264f26feb82a16b77ba853ef677b18bb8af5','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4391079670353c229acc7dbfc293804d6e2fc646dfac308213d5496305b09156',2007,'CG','Congo','transportation',314,'Airports: 8(2005)
Airports - with paved runways:
total: 1
over 3, 047 m: 1(2005)
Airports - with unpaved runways:
total: 7
914 to 1,523 m: 4
under 914 m: 3 (2005)
Roadways:
total: 14,480 km
paved: 1 ,028 km
unpaved: 13,452 km (1999)
Waterways: mainly on Lake Tanganyika (2003)
Ports and terminals: Bujumbura
Airports: 20(2005)
Airports - with paved runways:
total: 6
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m: 2 (2005)
Airports - with unpaved runways:
total: 14
1,524 to 2,437 m: 2
914 to 1,523 m: 11
under 914 m: 1 (2005)
Heliports: 2(2005)
Railways:
total: 602 km
narrow gauge: 602 km 1 .000-m gauge (2004)
Roadways:
tote/: 12,323 km
paved: 1 ,996 km
unpaved: 10,327 km (2000)
Waterways: 2,400 km (mainly on Mekong River)
(2005)
Merchant marine:
total: 521 ships (1000 GRT or over) 1,715,914 GRT/
2,421,241 DWT
by type: bulk carrier 38, cargo 423, chemical tanker
10, container 12, livestock carrier 3, passenger/cargo
4, petroleum tanker 9, refrigerated cargo 16, roll on/
roll off 5, specialized tanker 1
foreign-owned: 284 (Bulgaria 1 , Canada 6, China 75,
Cyprus 15, Egypt 6, Estonia 2, France 1, Gabon 1,
Germany 1, Greece 7, Hong Kong 10, Indonesia 1,
Isle of Man 1 , Israel 1 , Japan 2, South Korea 1 8,
Latvia 1, Lebanon 1, Nigeria 2, Norway 1, Philippines
1 , Russia 73, Singapore 4, Syria 1 1 , Taiwan 2, Turkey
17, Ukraine 12, UAE 2, US 6, Yemen 2, unknown 1)
(2005)
Ports and terminals: Phnom Penh
Airports: 50(2005)
Airports - with paved runways:
total: 3
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2 (2005)
Airports • with unpaved runways:
total: 47
2,438 to 3,047 m:1
1,524 to 2,437 m: 10
914 to 1,523 m: 23
under 914 m: 13 (2005)
Roadways:
tofa/:23,810km(1999)
Waterways: 2,800 km (primarily on the Oubangui
and Sangha rivers) (2005)
Ports and terminals: Bangui, Nola, Salo, Nzinga
Airports: 232(2005)
Airports - with paved runways:
total: 25
over 3,047 m: 4
2.438 to 3,047 m: 2
1,524 to 2,437 m:16
914 to 1,523 m: 2
under 914 m: 1 (2005)
Airports • with unpaved runways:
total: 207
1,524 to 2,437 m:18
914 to 1,523 m: 92
under 914 m: 97 (2005)
Pipelines: gas 54 km; oil 71 km (2004)
Railways:
total: 5,138 km
narrow gauge: 3,987 km 1 .067-m gauge (858 km
electrified); 1 25 km 1 .000-m gauge; 1 ,026 km 0.600-m
gauge (2004)
Roadways:
total: 157,000 km (including 30 km of expressways)
(1999)
Waterways: 15,000 km (2005)
Ports and terminals: Banana, Boma, Bukavu,
Bumba, Goma, Kalemie, Kindu, Kinshasa, Kisangani,
Matadi, Mbandaka
Airports: 32(2005)
Airports - with paved runways:
total: 4
over 3,047 m; 1
2,435 to 3,047 m: 1
1,524 to 2,437 m: 2 (2005)
Airports - with unpaved runways:
total: 28
1,524 to 2,437 m: 6
914 to 1,523 m.H
under 914 m: 11 (2005)
Pipelines: gas 53 km; oil 646 km (2004)
Railways:
total: 894 km
narrow gauge: 894 km 1 .067-m gauge (2004)
Roadways:
total: 12,800 km
paved: 1 ,242 km
unpaved: 11,558 km (1999)
Waterways: 4,385 km (on Congo and Oubanqui
rivers) (2005)
Merchant marine:
by type: cargo 1
foreign-owned: 1 (France 1)
registered in other countries: 1 (unknown 1) (2005)
Ports and terminals: Brazzaville, Djeno, Impfondo,
Ouesso, Oyo, Poinle-Noire','4b77bb150e5cb4596a0a0327ec6767724ca6f305756cff74763a87ccee543887','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e8c9bb22b56e131ec8851025987a6e7bf7ce8c436cd15eb8655ed4afdb7d00c',2007,'CM','Cameroon','transportation',322,'Airports: 47(2005)
Airports - with paved runways:
total: 11
over 3,047 m: 2
2,438 to 3.047 m: 4
1,524 to 2,437 m: 3
914 to 1,523 m:1
under 914 m:1 (2005)
Airports - with unpaved runways:
total: 36
1,524 to 2,437 m: 7
91 4 to 1,523 m: 20
under 914 m: 9 (2005)
Pipelines: gas 90 km; liquid petroleum gas 9 km; oil
1,120 km (2004)
Railways:
total: 1,008 km
narrow gauge: 1 ,008 km 1 .000-m gauge (2004)
Roadways:
total: 80,932 km
paved: 5,398 km
unpaved: 75,534 km (2002)
Waterways: navigation mainly on Benue River;
limited during rainy season (2005)
Merchant marine:
total: 1 ships (1000 GRT or over) 38.613 GRT/68,820
DWT
by type: petroleum tanker 1
foreign-owned: 1 (France 1) (2005)
Ports and terminals: Douala, Limboh Terminal','26fdb6030c98fca72c121db02027ba6361237a4fbb71cd38312bff9cf88d8bbb','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13ab4b1acb7b7a4f5c35e779e70aeeb81f6ea538f88fef5b250ef48c9065b3f9',2007,'CA','Canada','transportation',332,'Airports: 1,331 (2005)
Airports - with paved runways:
total: 508
over 3, 04 7 m: 18
2,438 to 3,047 m: 15
1,524 to 2,437 m: 151
9 14 to 1,523 m: 247
under 914 m: 77 (2005)
Airports - with unpaved runways
total: 823
1,524 to 2,437 m: 66
914 to 1,523 m: 351
under 914 m: 406 (2005)
Heliports: 319(2005)
Pipelines: crude and refined oil 23,564 km; liquid
petroleum gas 74,980 km (2003)
Railways:
total: 48,683 km
standard gauge: 48,683 km 1.435-m gauge (2004)
Roadways:
total: 1 ,408,900 km
paved: 497,342 km (including 16,906 km of
expressways)
unpaved: 91 1,558 km (2002)
Waterways: 631 km
note: Saint Lawrence Seaway of 3,769 km, including
the Saint Lawrence River of 3,058 km, shared with
United States (2003)
Merchant marine:
total: 175 ships (1000 GRT or over) 2,184,681 GRT/
2,809,249 DWT
by type: bulk carrier 58, cargo 13, chemical tanker 9,
combination ore/oil 1 , container 2, passenger 6,
passenger/cargo 65, petroleum tanker 14, roll on/roll
off 7
foreign-owned: 9 (France 1, Germany 3, Netherlands
1, Norway 1, UK 1, US 2)
registered in other countries: 126 (Australia 1 , The
Bahamas 14, Barbados 8, Bermuda 21, Cambodia 6,
Comoros 1, Cyprus 1, Honduras 1, Hong Kong 23,
Liberia 4, Malta 10, Marshall Islands 6, Panama 3,
Philippines 1 , Saint Vincent and the Grenadines 2, UK
12, US 6, Vanuatu 5, unknown 1) (2005)
Ports and terminals: Fraser River Port, Goderich,
Halifax, Montreal, Port Cartier, Quebec, Saint John''s
(Newfoundland), Sept Isles, Vancouver','3e560794fa57e751af0e3d5e6f07a858d77620a0322b4d3f63a5c675d57e4502','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e403a17ff8e3f55e05e564a31f9167f1d992976508b377ec0ce4ab6b70072035',2007,'PT','Portugal','transportation',337,'Airports: 7
note: 3 airports are reported to be nonoperational
(2005)
Airports - with paved runways:
total: 6
over 3,047 m:)
914 to 1,523 m: 5 (2005)
Airports - with unpaved runways:
total: 1
under 914 m:) (2005)
Roadways:
total: 1 ,350 km
paved: 932 km
(/npaved: 418 km (2000)
Merchant marine:
total: 6 ships (1000 GRT or over) 10,719 GRT/7,482
DWT
by type: cargo 2, chemical tanker 1 , passenger/cargo
3
foreign-owned: 2 (Spain 1 , UK 1 ) (2005)
Ports and terminals: Mmdelo, Praia, Tarrafal
107
Cape Verde (continued)
• ■ •
Military branches: Land Forces (includes Navy
(Marynarka Wojenna, MW)), Polish Air Force (Polsjie
Sily Powietrzne, PSP) (2005)
Military service age and obligation: 17 years of
age for compulsory military service after January 1st
of the year of 18th birthday; 17 years of age for
voluntary military service; in 2005, Poland plans to
shorten the length of conscript service obligation from
12 to 9 months; by 2008, plans call for at least 60% of
military personnel to be volunteers; only soldiers who
have completed their conscript service are allowed to
volunteer for professional service; as of April 2004,
women are only allowed to serve as officers and
noncommissioned officers (2004)
Manpower available for military service:
males age 17-49: 9,673,712 (2005 est.)
Manpower fit for military service:
males age 17-49: 7,740,164 (2005 est.)
Manpower reaching military service age
annually:
males: 275,52 1(2005 est.)
Military expenditures - dollar figure: $3.5 billion
(2002)
Military expenditures - percent of GDP: 1 .71%
(2002)
Airports: 66(2005)
Airports - with paved runways:
total: 42
over 3,047 m: 5
2,438 to 3,047 m: 9
1,524 to 2,437 m: 4
914 to 1,523 m: 14
under 914 m: 10 (2005)
Airports • with unpaved runways:
total: 24
914 to 1,523 m:1
under 914 m: 23 (2005)
Pipelines: gas 1 ,099 km; oil 8 km; refined products
174 km (2004)
Railways:
total: 2,850 km
broad gauge: 2,576 km 1 .668-m gauge (623 km
electrified)
narrow gauge: 274 km 1 ,000-m gauge (2004)
Roadways:
total: 72,600 km
paved: 62,436 km (including 1 ,700 km of
expressways)
unpaved: 10,164 km (2002)
Waterways: 210 km (on Douro River from Porto)
(2003)
Merchant marine:
total: 113 ships (1000 GRT or over) 1,121,828 GRT/
1,475,213 DWT
by type: bulk carrier 14, cargo 28, chemical tanker 1 5,
container 7, liquefied gas 1 1 , passenger 9, passenger/
cargo 8, petroleum tanker 8, roll on/roll off 4, vehicle
carrier 9
foreign-owned: 87 (Australia 1 , Belgium 7, Denmark
7, Germany 17, Greece 4, Italy 10, Japan 9, Lebanon
1 , Malta 1 , Mexico 1 , Netherlands 1 , Norway 8, Spain
17, Switzerland 3)
registered in other countries: 19 (Cyprus 1 , Malta 4,
Marshall Islands 2, Panama 12) (2005)
Ports and terminals: Leixoes, Lisbon, Setubal,
Sines','fa15ab1e5c9924115653fdaa0b8872ad9dc37b69c4175a6c0b32851b15c421ea','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3229fa98cc1f4285a23771a070db356523e8fbce1a33fc82057299e7d6fdd97',2007,'JM','Jamaica','transportation',348,'Airports: 3(2005)
Airports - with paved runways:
total: 2
1,524 to 2.437 m: 2 (2005)
Airports - with unpaved runways:
total: 1
914 to 1.523 m:1 (2005)
Roadways:
total: 785 km
paved: 785 km (2002)
Merchant marine:
total: 132 ships (1000 GRT or over) 2,667,086 GRT
4,255,739 DWT
by type: bulk carrier 33, cargo 14. chemical tanker 38.
liquefied gas 1, passenger 1, petroleum tanker 15,
refrigerated cargo 26, roll on/roll off 3. specialized
tanker 1
foreign-owned: 130 (Bermuda 2, Denmark 13,
Germany 14. Greece 22. Italy 11, Malaysia 1,Nor\\\\,n
2, Philippines 1 , Poland 1 , Sweden 12. UK 9, US 42)
(2005)
Ports and terminals: Cayman Brae, George Town
109
Cayman Islands (continued)
Airports: 35(2005)
Airports - with paved runways:
total: 1 1
2,438 to 3,047 m: 2
914 to 1,523 m: 4
under 914 m: 5 (2005)
Airports - with unpaved runways:
total: 24
914 to 1,523 m: 2
under 914 m: 22 (2005)
Railways:
total: 272 km
standard gauge: 272 km 1.435-m gauge
note: 207 of these km belonging to the Jamaica
Railway Corporation had been in common carrier
service until 1 992 but are no longer operational; 57 km
of the remaining track is privately owned and used by
ALCAN to transport bauxite (2003)
Roadways:
total: 18,700 km
paved: 13,009 km
unpaved: 5,610 km (1999)
Merchant marine:
total: 10 ships (1000 GRT or over) 1 17,805 GRT/
166,922 DWT
by type: bulk carrier 4, cargo 1 , chemical tanker 1 ,
petroleum tanker 1 , roll on/roll off 3
foreign-owned: 10 (Germany 2, Greece 5, UAE 3)
(2005)
Ports and terminals: Kingston, Port Esquivel, Port
Kaiser, Port Rhoades, Rocky Point','d07e012d16a88f035e3ff2985b775fd2edfc6f3bacf6274a7bce88dfaae5d159','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b2ccc6feb9e57102b48fd31dc219dcb3660aa875b693e391f6994f35a69eb4b2',2007,'LY','Libya','transportation',359,'Airports: 51 (2005)
Airports - with paved runways:
total: 7
over 3,047 m: 2
2,438 to 3,047 m:3
1,524 to 2,437 mA
under 914 mA (2005)
Airports • with unpaved runways:
total: 44
1,524 to 2, 437 m: 14
914 to 1,523 m: 21
under 914 m: 9 (2005)
Pipelines: oil 205 km (2004)
Roadways:
total: 33.400 km
paved: 267 km
unpaved.''33,133km(1999)
Waterways: Chari and Legone rivers are navigable
only in wet season (2002)
Airports: 139(2005)
Airports - with paved runways:
total: 59
over 3,047 m: 23
2,438 to 3,047 m: 6
1,524 to 2, 437 m: 23
914 to 1,523 m: 5
under 91 ''4 m: 2 (2005)
Airports - with unpaved runways:
total: 80
over 3,047 m: 5
2,438 to 3,047 m: 2
1,524 to 2,437 mA 4
914 to 1,523 m: 41
under 914 m: 18 (2005)
Heliports: 2(2005)
Pipelines: condensate 225 km; gas 3,61 1 km; oil
7,252 km (2004)
Railways: 0 km
note: Libya is working on seven lines totaling 2,757
km of 1 .435-m gauge track; it hopes to have trains
running by 2008 (2004)
Roadways:
total: 83,200 km
paved: 47,590 km
unpaved: 35,610 km (1999)
Merchant marine:
total: 17 ships (1000 GRT or over) 96,062 GRT/
88,760 DWT
by type: cargo 9, liquefied gas 3, passenger/cargo 2,
petroleum tanker 1 , roll on/roll off 2
foreign-owned: 4 (Kuwait 1 , Turkey 2, UAE 1 ) (2005)
Ports and terminals: As Sidrah, Az Zuwaytinah,
Marsa al Burayqah, Ra''s Lanuf, Tripoli, Zawiyah
Military branches: Armed Peoples on Duty (Army),
Navy, Air Force, Air Defense Command
Military service age and obligation: 17 years of
age (2004)
Manpower available for military service:
males age 17-49: 1 ,505,675 (2005 est.)
Manpower fit for military service:
males age 17-49: 1 ,291 ,624 (2005 est.)
Manpower reaching military service age
annually:
males: 62,034 (2005 est.)
Military expenditures • dollar figure: $1 .3 billion
(FY99)
Military expenditures - percent of GDP: 3.9%
(FY99)','5926be62ab7a3d5b8d1520ccaf32c6dffa931e63b4a11f2af354e3db22f17228','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffa6b42a3a80864e9ff4b4ad37bd26139a70f270c9416ea4c28fe5f2f53512ab',2007,'CN','China','transportation',369,'Airports: 489(2005)
Airports - with paved runways:
total: 389
over 3,047 m: 54
2,438 to 3,047 m: 120
1,524 to 2, 437 m: 139
914 to 1,523 m: 23
under 914 m: 53 (2005)
Airports - with unpaved runways:
total: 89
over 3,047 m: 4
2,438 to 3,047 m: 5
7,524 to 2, 437 m: 15
914 to 1,523 m: 29
under 974 m: 36 (2005)
Heliports: 30(2005)
Pipelines: gas 15,890 km; oil 14,478 km; refined
products 3,280 km (2004)
Railways:
total: 71 ,898 km
standard gauge: 71,898 km 1.435-m gauge (18,115
km electrified)
dual gauge: 23,945 km (multiple track not included in
total) (2002)
Roadways:
total: 1,809,829 km
paved: 1 ,447,682 km (with at least 29,745 km of
expressways)
unpaved: 362,147 km (2003)
Waterways: 123,964 km (2003)
Merchant marine:
total: 1 ,700 ships (1000 GRT or over) 20,441 ,123
GRT/30,808,417DWT
by type: barge carrier 2, bulk carrier 367, cargo 709,
chemical tanker 37, combination ore/oil 1 , container
146, liquefied gas 29, passenger 8, passenger/cargo
84, petroleum tanker 255, refrigerated cargo 32, roll
on/roll off 9, specialized tanker 8, vehicle carrier 13
foreign-owned: 14 (Hong Kong 7, Japan 2, South
Korea 3, UK 1, US 1)
registered in other countries: 1 ,018 (The Bahamas 5,
Bangladesh 1, Belize 71, Cambodia 75, Cyprus 10,
Honduras 3, Hong Kong 259, India 1, Liberia 35,
Malaysia 1, Malta 15, Mongolia 1, Norway 3, Panama
370, Saint Vincent and the Grenadines 106,
Singapore 20, Tuvalu 13, unknown 29) (2005)
Ports and terminals: Dalian, Guangzhou, Nanjing,
Ningbo, Qingdao, Qinhuangdao, Shanghai
Airports: 3(2005)
Airports - with paved runways:
total: 3
over 3,047 m:)
1,524 to 2,437 m:1
under 914 m: 1 (2005)
Heliports: 3(2005)
Roadways:
total: 1,831 km
paved: 1,831 km (1999)
Merchant marine:
total: 895 ships (1000 GRT or over) 29,662,934 GRT/
50,199,048 DWT
by type: barge carrier 2, bulk carrier 485, cargo 122,
chemical tanker 39, combination ore/oil 6, container
122, liquefied gas 21, passenger 6, passenger/cargo
6, petroleum tanker 72, roll on/roll off 2, specialized
tanker 4, vehicle carrier 8
foreign-owned: 534 (Belgium 3, Canada 23, China
259, Denmark 6, France 3, Germany 7, Greece 28,
Indonesia 3, Japan 64, South Korea 12, Monaco 1 ,
Norway 22, Philippines 15, Singapore 25, Taiwan 8,
UAE1.UK 35, US 19)
registered in other countries: 407 (The Bahamas 7,
Belgium 1 , Belize 8, Bermuda 6, Cambodia 10, China
7, Cyprus 1 , French Southern and Antarctic Lands 3,
Honduras 2, India 1 , Isle of Man 1 , Liberia 40,
Malaysia 14, Malta 2, Marshall Islands 8, Norway 50,
Panama 168, Philippines 2, Saint Vincent and the
Grenadines 6, Singapore 53, Taiwan 3, Tuvalu 7,
Venezuela 1 , unknown 6) (2005)
Ports and terminals: Hong Kong
Airports: 37(2005)
Airports - with paved runways:
total: 18
over 3,047 m: 1
2,438 to 3,047 m: 3
1,524 to 2,437 m: 11
under 914 m: 3 (2005)
Airports - with unpaved runways:
total: 19
1,524 to 2,437 m: 2
914 to 1,523 m: 1
under 914 m: 16 (2005)
Pipelines: gas 367 km; oil 13 km (2004)
Railways:
total: 470 km
broad gauge: 470 km 1 .520-m gauge (2004)
Roadways:
total: 18,500 km
paved: 16,854 km
unpaved: 1,646 km (1999)
Waterways: 600 km (2006)
Ports and terminals: Balykchy (Ysyk-Kol or
Rybach''ye)
Airports: 48(2005)
Airports • with paved runways:
tote/: 14
over 3,047 mA
2,438 to 3,047 m: 12
1,524 to 2,437 mA (2005)
Airports - with unpaved runways:
total: 34
over 3,047 m: 3
2,438 to 3,047 m: 4
1,524 to 2, 437 m: 24
914 to 1,523 m: 2
under 914 mA (2005)
Heliports: 2(2005)
Railways:
total: 1,810 km
broad gauge: 1,810 km 1.524-m gauge (2004)
Roadways:
total: 49,250 km
paved: 1 ,724 km
unpaved: 47,526 km (2002)
Waterways: 580 km
note: only waterway in operation is Lake Hovsgol (135
km); Selenge River (270 km) and Orhon River (175
km) are navigable but carry little traffic; lakes and
rivers freeze in winter, are open from May to
September (2004)
Merchant marine:
total: 53 ships (1000 GRT or over) 255,182 GRT/
379,234 DWT
by type: bulk carrier 5, cargo 45, liquefied gas 1 ,
passenger/cargo 1 , roll on/roll off 1
toreign-owned: 39 (China 1 , North Korea 3, South
Korea 1, Lebanon 1, Marshall Islands 1, Russia 10,
Singapore 8, Syria 2, Thailand 1, Ukraine 1, UAE 3,
Vietnam 7) (2005)','508dd47516eb167be20261da7850aafa163c4f6123edeee8d49184de458511b3','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87e9d15da869aa45ad4d2bb7f1b16f548e7f00c1ba95b9b2f68bbba4c7f0cba8',2007,'CX','Christmas Island','transportation',376,'Airports: 1 (2005)
Airports - with paved runways:
total: 1
1,524 to 2,437 m:1 (2005)
Roadways:
fofa/:142km
paved: 32 km
unpaved: 110 km (2006)
Ports and terminals: Flying Fish Cove','3840b29d25c5e43d16493f170fbd8abaacd0ace911b74f37ff121309c525438a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ca58e347bf78a9481ccf5dd381c98a34537fa2101b9bfdc8d9ba0d0553dbd41',2007,'FR','France','transportation',386,'Airports: 1 (2005)
Airports - with paved runways:
total: 1
1,524 to 2, 437 m: 1(2005)
Roadways:
total: 15 km (2005)
Ports and terminals: Port Refuge
Airports: 5(2005)
Airports - with paved runways:
total: 2
2,438 to 3,047 m:1
914 to 1,523 m: 1(2005)
Airports • with unpaved runways:
total: 3
under 914 m: 3 (2005)
Roadways:
total: 440 km
paved: 50 km
unpaved: 390 km (2003)
Ports and terminals: Stanley
Airports: 11 (2005)
Airports - with paved runways:
total: 4
over 3,047 m:1
914 to 1,523 m: 2
under 914 m:) (2005)
Airports - with unpaved runways:
total: 7
914 to 1,523 m: 2
under 914 m: 5 (2005)
Roadways:
fofa/:817km(1998)
Waterways: 3,760 km
note: 460 km navigable by small oceangoing vessels
and coastal and river steamers, 3,300 km by native
craft (2003)
Ports and terminals: Degrad des Cannes
Airports: none (2005)
Merchant marine:
total: 77 ships (1 000 GRT or over) 3,574,270 GRT/
5,647,334 DWT
by type: bulk carrier 1 , cargo 1 , chemical tanker 22,
container 1 8, liquefied gas 8, petroleum tanker 1 7, roll
on/roll off 6, vehicle carrier 4
foreign-owned: 77 (Belgium 5, Denmark 2, France 45,
Germany 2, Greece 2, Hong Kong 3, Japan 4, Norway
3, Saudi Arabia 1, Sweden 8, Switzerland 1, UK 1)
(2005)
Ports and terminals: none; offshore anchorage only
M i
li ta r
y
Airports: 9(2005)
Airports • with paved runways:
total: 8
over 3.047 m: -\\
914 to 1.523 m: 2
under 914 m: 5 (2005)
Airports - with unpaved runways:
total: 1
under 914 m:1 (2005)
Roadways:
total: 947 km (2002)
Ports and terminals: Basse-Terre, Gustavia,
Pointe-a-Pitre
Airports: 2(2005)
Airports - with paved runways:
total: 1
over 3,047 m:1 (2005)
Airports - with unpaved runways:
total: 1
under 914 m: 1 (2005)
Roadways:
total: 2,105 km (including 261 km of expressways)
(2000)
Ports and terminals: Fort-de-France, La Trinite,
Marin
Airports: 2(2005)
Airports - with paved runways:
total: 2
2.438 to 3,047 m: 1
91 4 to 1,523 mA (2005)
Roadways:
tote/: 1,214 km (including 88 km of four-lane roads)
(2001)
Ports and terminals: Le Port
Airports: 30(2005)
Airports - with paved runways:
total: 14
over 3,047 m: 3
2.438 to 3,047 m: 6
1,524 to 2,437 m: 2
914 to 1,523 m: 3 (2005)
Airports • with unpaved runways:
to/a/. 1 6
1,524 to 2,437 m: 2
914 to 1,523 m:l
under 914 m: 7 (2005)
Pipelines: gas 3,059 km; oil 1,203 km; refined
products 345 km (2004)
Railways:
total: 2,152 km
standard gauge: 468 km 1 .435-m gauge
narrow gauge: 1 ,674 km 1 .000-m gauge (65 km
electrified)
dual gauge: 1 0 km 1 .435-m and 1 .000-m gauges
(three rails) (2004)
Roadways:
total: 18,997 km
paved: 12,424 km (including 142 km of expressways)
unpaved: 6,573 km (2001)
Merchant marine:
total: 10 ships (1000 GRT or over) 149,142 GRT/
118,333 DWT
by type: bulk carrier 1 , cargo 1 , chemical tanker 3,
passenger/cargo 4, petroleum tanker 1
registered in other countries: 3 (Panama 1 , Saint
Vincent and the Grenadines 2) (2005)
Ports and terminals: Bizerte, Gabes, La Goulette,
Skhira
Airports: 120(2005)
Airports - with paved runways:
tofa/:88
over 3,047 m:15
2,438 to 3,047 m: 32
1,524 to 2,437 m: 19
914 to 1,523 m: 18
under 914 m: 4 (2005)
Airports - with unpaved runways:
total: 32
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 8
under 914 m: 20 (2005)
Heliports: 16(2005)
Pipelines: gas 3,177 km; oil 3,562 km (2004)
Railways:
total: 8,697 km
standard gauge: 8,697 km 1.435-m gauge (2,122 km
electrified) (2004)
Roadways:
total: 354,421 km
paved: 147,404 km (including 1,886 km of
expressways)
unpaged: 207,01 7 km (2003)
Waterways: 1 ,200 km (2005)
Merchant marine:
total: 538 ships (1000 GRT or over) 4,745,132 GRT/
7,261,125 DWT
by type: bulk carrier 109, cargo 235, chemical tanker
45, combination ore/oil 1 , container 26, liquefied gas
5, passenger 4, passenger/cargo 51, petroleum
tanker 36, refrigerated cargo 1 , roll on/roll off 23,
specialized tanker 2
foreign-owned: 10 (Cyprus 3, Italy 3, South Korea 1,
Monaco 1, Netherlands 1, Switzerland 1)
registered in other countries: 344 (Albania 1 , Antigua
and Barbuda 5, The Bahamas 10, Belize 8, Cambodia
17, Comoros 10, Dominica 1, France 1, Georgia 24,
Honduras 1 , Isle of Man 3, North Korea 4, Liberia 2,
Libya 2, Malta 101, Marshall Islands 24, Netherlands
Antilles 8, Panama 31 , Russia 54, Saint Kitts and
Nevis 2, Saint Vincent and the Grenadines 23,
Slovakia 8, UK 1, unknown 3) (2005)
Ports and terminals: Aliaga, Ambarli, Eregli,
Haydarpasa, Istanbul, Kocaeli (Izmit), Skhira, Toros
Airports: 471 (2005)
Airports - with paved runways:
total: 334
over 3.047 m: 8
3 to 3,047 m: 33
1.524 to 2,437 m: 149
914 to 1.523 m: 85
under 914 m: 59 (2005)
Airports - with unpaved runways:
total: 137
2.438 to 3.047 m: 1
1,524 to 2,437 m:1
974 to 1.523 m: 23
under 914 m: 112 (2005)
Heliports: 1 1 (2005)
Pipelines: condensate 370 km; gas 21 ,446 km;
liquid petroleum gas 59 km; oil 6,420 km; oil/gas/water
63 km: refined products 4,474 km (2004)
Railways:
total: 17,274 km
standard gauge: 1 6,814 km 1 .435-m gauge (5,296 km
electrified)
broad gauge: 460 km 1 .600-m gauge (in Northern
Ireland) (2004)
Roadways:
total: 387,674 km
paved: 387,674 km (including 3,523 km of
expressways) (2004)
Waterways: 3,200 km (620 km used for commerce)
(2003)
Merchant marine:
total: 444 ships (1000 GRT or over) 10,775,537 GRT/
11,464,492 DWT
by type: bulk carrier 20, cargo 64, chemical tanker 45,
container 143, liquefied gas 14, passenger 9,
passenger/cargo 66, petroleum tanker 31 ,
refrigerated cargo 20, roll on/roll off 26, vehicle
carrier 6
foreign-owned: 208 (Australia 4, Canada 1 2, Denmark
41, Finland 2, France 3, Germany 63, Greece 7,
Ireland 1 , Italy 5, Netherlands 2. NZ 1 , Norway 40,
South Africa 4, Sweden 1 5, Taiwan 1 , Turkey 1 , US 6)
registered in other countries: 365 (Antigua and
Barbuda 5, Argentina 4, Australia 2, The Bahamas 68,
Barbados 7, Belgium 1 , Bermuda 8, Brazil 1 , Brunei 8,
Canada 1 , Cape Verde 1 , Cayman Islands 9, China 1 ,
Cyprus 8, Faroe Islands 1, French Southern and
Antarctic Lands 1, Georgia 5, Gibraltar 4. Greece 8,
Hong Kong 35, India 1 , Indonesia 2, Ireland 1 , Italy 6,
South Korea 2, Liberia 49, Malta 6, Marshall Islands
20, Morocco 1 , Netherlands 21 , Netherlands Antilles
2, Norway 4, Panama 36, Papua New Guinea 6, Saint
Vincent and the Grenadines 16, Singapore 10,
Slovakia 1, Tonga 1, US 2) (2005)
Ports and terminals: Hound Point, Immingham,
Milford Haven, Liverpool, London, Southampton,
Sullom Voe, Teesport
Mill
Military branches: Army, Royal Navy (includes
Royal Marines), Royal Air Force
Military service age and obligation: 16 years of
age for voluntary military service; women serve in
military services, but are excluded from ground
combat positions and some naval postings
(January 2004)
Manpower available for military service:
males age 16-49: 14,607,724 (2005 est.)
Manpower fit for military service:
males age 16-49: 12,046,268 (2005 est.)
Military expenditures - dollar figure: $42,836.5
million (2003)
Military expenditures - percent of GDP: 2.4% •
(2003)','15b43bdb509a150cfcb0bd1ec006a21ec24559b6716883b7d47f532f9ba2b035','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb08c4b0d0f33528fb3600792dec8da9bc38095143ceb701012cd4cb688f93d6',2007,'CO','Colombia','transportation',395,'Airports: 981 (2005)
Airports - with paved runways:
total: m
over 3,047 m: 2
2,438 to 3,047 m: 9
1,524 to 2,437 m: 38
914 to 1,523 m: 40
under 91 4 m: 11 (2005)
Airports - with unpaved runways:
total: 881
over 3,047 m: 1
1,524 to 2,437 m: 35
914 to 1,523 m: 273
under 914 m: 572 (2005)
Heliports: 2(2005)
Pipelines: gas 4,360 km; oil 6,134 km; refined
products 3,140 km (2004)
Railways:
total: 3,304 km
standard gauge: 150 km 1.435-m gauge
narrow gauge: 3,154 km 0.914-m gauge (2004)
Roadways:
total: 110,000 km
paved: 26,000 km
unpaved: 84,000 km (2000)
Waterways: 18,000 km (2005)
Merchant marine:
total: 16 ships (1000 GRT or over) 40,463 GRT/
55,802 DWT
by type: cargo 1 3, liquefied gas 1 , petroleum tanker 2
registered in other countries: 8 (Antigua and Barbuda
2, Panama 6) (2005)
Ports and terminals: Barranquilla. Buenaventura.
Cartagena, Muelles El Bosque, Puerto Bolivar. Santa
Maria, Turbo
Airports: 109(2005)
Airports ■ with paved runways:
total: 47
over 3,047 mA
2,438 to 3,047 m: 1
1,524 to 2,437 m: 5
914 to 1,523 m:17
under 914 m: 23 (2005)
Airports - with unpaved runways:
total: 62
914 to 1,523 m: 10
under 914 m: 52 (2005)
Railways:
total: 355 km
standard gauge: 76 km 1 .435-m gauge
narrow gauge: 279 km 0.91 4-m gauge (2004)
Roadways:
total: 11,643 km
paved: 4,028 km
unpaved: 7,61 5 km (2000)
Waterways: 800 km (includes 82 km Panama Canal)
(2005)
Merchant marine:
total: 5,254 ships (1000 GRT or over) 137,914,883
GRT/206,848,688 DWT
by type: barge carrier 27, bulk carrier 1 ,651 , cargo
951 , chemical tanker 452, combination ore/oil 1 1 ,
container 625, liquefied gas 188, livestock carrier 6,
passenger 46, passenger/cargo 77, petroleum tanker
516, refrigerated cargo 307, roll on/roll off 109,
specialized tanker 21 , vehicle carrier 267
foreign-owned: 4,688 (Argentina 9, Australia 4, The
Bahamas 1, Bangladesh 1, Belgium 13, Bermuda 2,
Brazil 2, Canada 3, Chile 1 1 , China 370, Colombia 6,
Croatia 4, Cuba 8, Cyprus 8, Denmark 28, Egypt 17,
Estonia 3, France 8, Germany 29, Greece 536, Hong
Kong 168, India 16, Indonesia 50, Iran 4, Ireland 2,
Isle of Man 2, Israel 3, Italy 16, Japan 1,921, Jordan
12, South Korea 285, Kuwait 2, Latvia 4, Lebanon 1,
Lithuania 6, Malaysia 13, Maldives 2, Malta 2,
Marshall Islands 1 , Mexico 5, Monaco 9, Netherlands
26, NZ 1, Nigeria 6, Norway 57, Pakistan 2, Peru 14,
Philippines 17, Poland 19, Portugal 12, Romania 9,
Russia 6, Saudi Arabia 4, Singapore 57, South Africa
3, Spain 48, Sri Lanka 6, Sudan 1. Swaziland 1,
Sweden 5, Switzerland 206, Syria 9, Taiwan 302,
Thailand 1 0, Trinidad and Tobago 1 , Tunisia 1 , Turkey
31, Ukraine 7, UAE 89, UK 36, US 97, Venezuela 14,
Vietnam 2, Yemen 1, unknown 1) (2005)
Ports and terminals: Balboa. Colon, Cristobal','03d3a3b7a8daebd2d8183234712007ebc40618d83c4cf61a2535a86d9ff26e63','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d15efbcc4effde9a385397abcff1425890ac33810ec67272afde03d200610a0f',2007,'YT','Mayotte','transportation',404,'Airports: 4(2005)
Airports - with paved runways:
total: 4
2.438 to 3,047 m: 1
914 to 1,523 m: 3 (2005)
Roadways:
total: 880 km
paved: 673 km
unpaved: 207 km (1999)
Merchant marine:
total: 117 ships (1000 GRT or over) 522,157 GRT
738,339 DWT
by type: bulk carrier 10, cargo 85, container 1 ,
livestock carrier 1 , passenger 2, passenger/cargo 1 ,
petroleum tanker 7, refrigerated cargo 5, roll on/roll off
4, specialized tanker 1
foreign-owned: 59 (Bangladesh 1 , Bulgana 1 , Canada
1 , Greece 8, India 1 , Kenya 1 , Kuwait 1 , Lebanon 3,
Nigeria 2, Norway 1 . Pakistan 2, Philippines 1 . Russia
5, Saint Vincent and the Grenadines 1, Saudi Arabia
3, Syria 3, Turkey 10, Ukraine 12, US 2) (2005)
Ports and terminals: Mayotte, Moutsamoudou
129
ComorOS (continued)
Airports: 1 (2005)
Airports • with paved runways:
total: 1
1,524 to 2,437 m: 1(2005)
Ports and terminals: Dzaoudzi','c6c0fb182e296ec128a185c3124217a2f1432297e4302e6084a74b3c32e2dc7d','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4b94ed88f3171a855eb7c7614aa1b999a725705fce327fe3fc26a9c432e4b1d',2007,'CK','Cook Islands','transportation',415,'Airports: 9(2005)
Airports - with paved runways:
total: 2
1,524 to 2,437 m: 2 (2005)
Airports - with unpaved runways:
total: 7
1,524 to 2,437 m: 2
914 to 1,523 m: A
under 914 m:1 (2005)
Roadways:
total: 320 km
paved: 33 km
unpaved: 287 km (2003)
Merchant marine:
total: 2 ships (1000 6RT or over) 3,701 GRT/6,488
DWT
by type: cargo 1 , petroleum tanker 1
foreign-owned: 1 (Norway 1) (2005)
Ports and terminals: Avatiu
Ports and terminals: none; offshore anchorage only','95089b708c098fce0b8dcb10a055f5a96f6e45d11bc5a249d3a1436086a618f9','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f71dfc8d28018399ddf2822891cc256de44d52aeb5540a73f6c3d989b7aef34',2007,'CR','Costa Rica','transportation',424,'Airports: 156(2005)
Airports - with paved runways:
total: 31
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
914 to 1,523 m:18
under 914 m: 9 (2005)
Airports - with unpaved runways:
total: 125
914 to 1,523 m: 25
under 914 m: 100 (2005)
Pipelines: refined products 242 km (2004)
Railways:
total: 278 km
narrow gauge: 278 km 1 .067-m gauge (2004)
Roadways:
total: 35,889 km
paved: 8,075 km
unpaved: 27,814 km (2003)
Waterways: 730 km (seasonally navigable by small
craft) (2005)
Merchant marine:
total: 2 ships (1 000 GRT or over) 2,308 GRT/743 DWT
by type: passenger/cargo 2 (2005)
Ports and terminals: Caldera, Puerto Limon
Airports: 35(2005)
Airports • with paved runways:
total: 7
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4 (2005)
Airports • with unpaved runways:
total: 28
1,524 to 2,437 m: 8
914 to 1,523 m: 15
under 914 m: 5 (2005)
Pipelines: condensate 107 km; gas 223 km; oil 104
km (2004)
Railways:
total: 660 km
narrow gauge: 660 km 1 000-meter gauge
note: an additional 622 km of this railroad extends into
Burkina Faso (2004)
142
Cote d''lVOire (continued)
Roadways:
total: 50,400 km
paved: 4,889 km
unpaved: 45,51 1 km (1999)
Waterways: 980 km (navigable rivers, canals, and
numerous coastal lagoons) (2005)
Ports and terminals: Abidjan, Aboisso, Dabou,
San-Pedro
Airports: 176(2005)
Airports - with paved runways:
total: 1 1
2.438 to 3,047 m: 3
1.524 to 2.437 m: 2
914 to 1.523 m: 3
under 914 m: 3 (2005)
Airports - with unpaved runways:
total: 165
1,524 to 2,437 m:1
914 to 1.523 m: 23
under 914 m: 141 (2005)
Pipelines: oil 54 km (2004)
Railways:
total: 6 km
narrow gauge: 6 km 1 .067-m gauge (2004)
Roadways:
total: 18,658 km
paved: 2,120 km
unpaved: 16,538 km (2003)
406
Nicaragua (continued)
Waterways: 2,220 km (including lakes Managua and
Nicaragua) (2005)
Ports and terminals: Bluefields, Corinto, El Bluff','8e8f7f635e205622086251b25fdf833fe756cf0981b6a2798d08c3cb8169a29e','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('04e1d1a46f02a436a49f11989f4a773e13833b7a7fc6b47b223f74a6b2cafb17',2007,'SI','Slovenia','transportation',433,'Airports: 68(2005)
Airports - with paved runways:
total: 23
over 3,047 m: 2
2,438 to 3,047 m:6
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m: 9 (2005)
Airports - with unpaved runways:
total: 45
1,524 to 2,437 m: 1
914 to 1,523 m: 7
under 914 m: 37 (2005)
Heliports: 1 (2005)
Pipelines: gas 1 ,340 km; oil 583 km (2004)
Railways:
total: 2,726 km
standard gauge: 2,726 km 1 .435-m gauge (984 km
electrified) (2004)
Roadways:
total: 28,588 km
paved: 24,186 km (including 583 km of expressways)
unpaved: 4,402 km (2003)
Waterways: 785 km (2006)
Merchant marine:
total: 76 ships (1000 GRT or over) 1 ,090,162 GRT/
1,738,590 DWT
by type: bulk carrier 24, cargo 13, chemical tanker 2,
passenger/cargo 27, petroleum tanker 5, refrigerated
cargo 1 , roll on/roll off 4
registered in other countries: 34 (The Bahamas 1 ,
Cyprus 2, Liberia 6, Malta 1 1 , Marshall Islands 2,
Panama 4, Saint Vincent and the Grenadines 8)
(2005)
Ports and terminals: Omisalj, Ploce, Rijeka,
Sibenik, Vukovar (on Danube)','a19b6877a2627b21e689312d7a0bdf7d277f390f02b2a251625dab2ff799275f','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a53d335726c9fb1fd3cb7e04a0e586ba3c313ebec867a77386e840eaf68da6b6',2007,'HT','Haiti','transportation',444,'Airports: 170(2005)
Airports - with paved runways:
total: 78
over 3,047 m: 7
2,438 to 3,047 m: 9
1,524 to 2, 437 m: 18
914 to 1,523 m: 7
under 914 m: 37 (2005)
Airports - with unpaved runways:
total: 92
1,524 to 2,437 m: 1
914 to 1,523 m: 29
under 914 m: 62 (2005)
Pipelines: gas 49 km; oil 230 km (2004)
Railways:
total: 4,226 km
standard gauge: 4,226 km 1 .435-m gauge (140 km
electrified)
note: an additional 7,742 km of track is used by sugar
plantations; about 65% of this track is standard gauge;
the rest is narrow gauge (2004)
Roadways:
total: 60,858 km
paved: 29,820 km (including 638 km of expressway)
unpaved: 31,038 km (1999)
Waterways: 240 km (2005)
Merchant marine:
total: 1 1 ships (1 000 GRT or over) 33,932 GRT/
48,791 DWT
by type: bulk carrier 2, cargo 2, chemical tanker 1 ,
passenger 1 , petroleum tanker 3, refrigerated cargo 2
foreign-owned: 1 (Spain 1 )
registered in other countries: 17 (The Bahamas 1 ,
Cyprus 3, Netherlands Antilles 1 , Panama 8, Spain 1 ,
unknown 3) (2005)
Ports and terminals: Cienfuegos, Havana,
Matanzas
Airports: 32(2005)
Airports ■ with paved runways:
total: 13
over 3,047 m: 3
2,438 to 3,047 m: 3
1,524 to 2,437 m: 3
914 to 1,523 m: 3
under 914 mA (2005)
Airports - with unpaved runways:
total: 19
1,524 to 2,437 m: 4
914 to 1,523 m: 5
under 914 m: 10 (2005)
Railways:
tofa/:517km
standard gauge: 375 km 1 ,435-m gauge
narrow gauge: 142 km 0.762-m gauge
note: additional 1 ,226 km operated by sugar
companies in 1 .076 m, 0.889 m, and 0.762-m gauges
(2004)
Roadways:
total: 12,600 km
paired: 6,224 km
unpaved: 6,376 km (1999)
Merchant marine:
totals ships (1000 GRT or over) 1,587 GRT/1, 165
DWT
by type: cargo 1 (2005)
Ports and terminals: Boca Chica, Puerto Plata, Rio
Haina, Santo Domingo
Airports: 12(2005)
Airports - with paved runways:
total: 4
2,438 to 3,047 m;1
914 to 1,523 m: 3 (2005)
Airports - with unpaved runways:
total: 8
914 to 1,523 m:1
under 914 m: 7 (2005)
Roadways:
total: 4,160 km
paved: 1,011 km
unpaved: 3,149 km (1999)
Ports and terminals: Cap-Haitien
Ports and terminals: none; offshore anchorage only
Military - note: defense is the responsibility of
Australia; Australia conducts fisheries patrols','c7c76375d5ffa24535be1d1575405565db4f64f32e333ee3eabf4baf8de64780','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b8805dd5e702c90b7fcd96fdd2551b7eb0478e7180874c7b0707d76bafdd92f',2007,'CY','Cyprus','transportation',453,'Airports: 16(2005)
Airports - with paved runways:
total: 13
2,438 to 3,047 m: 7
1,524 to 2,437 m: 2
914 to 1,523 m: 3
under 914 m:\\ (2005)
Airports - with unpaved runways:
total: 3
1,524 to 2,437 m: 1
under 914 m: 2 (2005)
Heliports: 10(2005)
Roadways:
total: 1 4, 1 1 0 km (Republic of Cyprus: 1 1 ,760 km;
north Cyprus: 2,350 km)
paved: Republic of Cyprus: 7,403 km (including 268
km of expressways); north Cyprus: 1 ,370 km
unpaved: Republic of Cyprus: 4,357 km; north
Cyprus: 980 km (2003/1996 est.)
Merchant marine:
total: 877 ships (1000 GRT or over) 18,837,402 GRT/
30,197,663 DWT
by type: bulk carrier 358, cargo 212, chemical tanker
40, container 136, liquefied gas 5, passenger 8,
passenger/cargo 1 9, petroleum tanker 66,
refrigerated cargo 1 9, roll on/roll off 9, vehicle carrier 5
foreign-owned: 782 (Belgium 1, Canada 1, China 10.
Croatia 2, Cuba 3, Egypt 1 , Estonia 3, Germany 21 1 ,
Greece 352, Greenland 1 , Hong Kong 1 , India 7, Iran
2, Israel 3, Japan 17, South Korea 1, Latvia 5,
Netherlands 18, Norway 14, Philippines 2, Poland 19,
Portugal 1, Russia 54, Singapore 2, Slovakia 1,
Slovenia 4, Spain 5, Sweden 4, Switzerland 6, Syria 2,
Ukraine 3, UAE 1 1 , UK 8, US 6, Vietnam 1 )
registered in other countries: 67 (The Bahamas 1 3,
Belize 2, Cambodia 15, Georgia 1, Liberia 6, Malta 5,
Marshall Islands 7, Norway 2, Panama 8, Russia 1 ,
Saint Vincent and the Grenadines 3, Seychelles 1 ,
Turkey 3) (2005)
151
Cyprus (continued)
Ports and terminals: Famagusta, Kyrenia, Larnaca,
Limassol. Vasilikos
Military branches: Republic of Cyprus: Greek
Cypriot National Guard (GCNG; includes air and naval
elements); north Cyprus: Turkish Cypriot Security
Force (GKK)
Military service age and obligation: 18 years of
age (2004)
Manpower available for military service:
males age 18-49: 184,352 (2005 est.)
Manpower fit for military service:
males age 18-49: 150,750 (2005 est.)
Manpower reaching military service age
annually:
males: 6,578 (2005 est.)
Military expenditures - dollar figure: $384 million
(FY02)
Military expenditures - percent of GDP: 3.8%
(FY02)
Airports: 121 (2005)
Airports - with paved runways:
total: 44
over 3.047 m: 2
2.438 to 3,047 m: 9
1.524 to 2.437 m: 14
914 to 1.523 m: 2
under 914 m: 17 (2005)
Airports - with unpaved runways:
total: 77
914 to 1.523 m: 28
under 914 m: 49 (2005)
Heliports: 2(2005)
Pipelines: gas 7,020 km; oil 547 km; refined
products 94 km (2004)
Railways:
total: 9,543 km
standard gauge: 9,421 km 1 .435-m gauge (2,893 km
electrified)
narrow gauge: 122 km 0.760-m gauge (23 km
electrified) (2004)
Roadways:
total: 127,672 km
paved: 127,672 km (including 518 km of
expressways) (2002)
Waterways: 664 km (principally on Elbe as well as
Vltava and Oder rivers) (2005)
Merchant marine:
registered in other countries: 2 (Malta 1 , Saint Vincent
and the Grenadines 1) (2005)
Ports and terminals: Decin, Prague, Usti nad
Labem','ceba64ea2b92efdd2b87b2aef61c35942f1ea365d3f57c5c7175d5336f6e8fba','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('561486667daba99a1108290742cb42280b4c52ec8e7f1d0f87c16cc7ec189cec',2007,'DK','Denmark','transportation',461,'Airports: 97(2005)
Airports - with paved runways:
total: 28
over 3,047 m: 2
2,438 to 3,047 m: 7
1,524 to 2,437 m: 4
914 to 1,523 m: 12
under 914 m: 3 (2005)
Airports - with unpaved runways:
total: 69
914 to 1,523 m: 6
under 914 m: 63 (2005)
Pipelines: condensate 12 km; gas 3,892 km; oil
455 km; oil/gas/water 2 km; unknown (oil/water) 64 km
(2004)
Railways:
total: 2,628 km
standard gauge: 2,628 km 1 .435-m gauge (595 km
electrified) (2004)
Roadways:
total: 71,847 km
paved: 71 ,847 km (including 920 km of expressways)
(2002)
Waterways: 400 km (2001)
Merchant marine:
total: 297 ships (1000 GRT or over) 7,707,196 GRT/
9,469,296 DWT
by type: bulk carrier 6, cargo 69, chemical tanker 45,
container 83, liquefied gas 8, livestock carrier 2,
passenger 1 , passenger/cargo 40, petroleum tanker
24, refrigerated cargo 7, roll on/roll off 8 specialized
tanker 4
foreign-owned: 9 (Greece 1, Greenland 1, Iceland 1,
India 1, Indonesia 1, Norway 3, Russia 1)
registered in other countries: 384 (Antigua and
Barbuda 1 1, The Bahamas 65, Belgium 4, Cayman
Islands 13, Egypt 1, Estonia 1, French Southern and
Antarctic Lands 2, Hong Kong 6, Isle of Man 49, North
Korea 1 , Liberia 5, Lithuania 1 1 , Malta 3, Marshall
Islands 1 , Mexico 2, Netherlands 9, Netherlands
Antilles 1, Norway 31, Panama 28, Portugal 7, Saint
Vincent and the Grenadines 14, Singapore 44, South
Africa 1 , Spain 1 , Sweden 3, UK 41 , US 20, Vanuatu
6, Venezuela 2, Vietnam 1) (2005)
Ports and terminals: Aalborg, Aarhus,
Asnaesvaerkets, Copenhagen, Elsinore, Ensted,
Esbjerg, Fredericia, Frederikshavn, Graasten,
Kalundborg, Odense, Roenne
Airports: 14(2005)
Airports - with paved runways:
total: 9
2,438 to 3,047 m: 2
1.524 to 2,437 mS
914 to 1,523 m:1
under 914 m: 5 (2005)
Airports - with unpaved runways:
total: 5
1,524 to 2,437 m; 1
914 to 1,523 m: 2
under 914 m: 2 (2005)
Merchant marine:
total: 2 ships (1000 GRT or over) 4,236 GRT/400
DWT
by type: passenger 2
registered in other countries: 2 (Cyprus 1 , Denmark
1)(2005)
Ports and terminals: Sisimiut
defense is the responsibility of
T r a n s n a
t i o n a 1
Issues
Disputes - international: managed dispute
between Canada and Denmark over Hans Island in
the Kennedy Channel between Canada''s Ellesmere
Island and Greenland
<* Petne','81b41359e0e610a7895c366b92e3e423d91e78725684d0bc643c7ebef8b8df8d','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84925860cce46c1f7ab8a83eac07a77b49e61544b3cadf5205b2d08709ed822d',2007,'DJ','Djibouti','transportation',470,'Airports: 13(2005)
Airports - with paved runways:
total: 3
over 3,047 m^
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (2005)
Airports - with unpaved runways:
tofa/:10
1.524 to 2,437 m: 2
914 to 1,523 m: 5
under 914 m: 3 (2005)
Railways:
total: 100 km (Djibouti segment of the Addis
Ababa-Djibouti railway)
narrow gauge: 100 km 1 .000-m gauge
note: railway under joint control of Djibouti and
Ethiopia (2004)
Roadways:
total: 2,890 km
paved: 364 km
unpaved: 2,526 km (1999)
Merchant marine:
total: 1 ships (1000 GRT or over) 1 ,369 GRT/3,030
DWT
by type: cargo 1 (2005)
Ports and terminals: Djibouti
Airports: 45(2005)
Airports - with paved runways:
total: 16
over 3,047 m: 4
2,438 to 3,047 m: 8
1,524 to 2,437 m: 2
914 to 1 ,523 m-A
under 914 mA (2005)
Airports - with unpaved runways:
total: 29
over 3,047 m: 3
2,438 to 3,047 m: 7
1 .524 to 2,437 m: 4
914 to 1,523 m: 11
under 914 m: 4 (2005)
Pipelines: gas 88 km; oil 1 ,174 km (2004)
Roadways:
total: 67,000 km
paved: 7,705 km
unpaved: 59,295 km (1999)
Merchant marine:
total: 5 ships (1 000 GRT or over) 1 9,920 GRT/26,277
DWT
by type: cargo 1 , chemical tanker 1 , petroleum
tanker 2, roll on/roll off 1
registered in other countries: 5 (Bolivia 1 , Cambodia
2, North Korea 1, Panama 1) (2005)
Ports and terminals: Aden, Nishtun','e2ed7b6242deb438c6c65573e694f6dc4c6e5f93f5ce38eeceeea7a3c14bd655','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb65b367aacc1e0828a53039eda855fa5a038e072c3fe9dc092a777d941f6a75',2007,'LC','Saint Lucia','transportation',474,'Airports: 2(2005)
Airports - with paved runways:
total: 2
914 to 1,523 m: 2 (2005)
Roadways:
total: 780 km
paved: 393 km
unpaved: 387 km (1999)
Merchant marine:
total: 40 ships (1000 GRT or over) 313,180 GRT/
506,662 DWT
by type: bulk carrier 2, cargo 25, chemical tanker 3,
container 1 , petroleum tanker 5, refrigerated cargo 2,
roll on/roll off 1 , specialized tanker 1
foreign-owned: 34 (Estonia 8, Greece 3, Latvia 2,
Norway 1 , Russia 2, Saudi Arabia 1 , Singapore 1 1 ,
Syria 2, Turkey 1.UAE 3) (2005)
Ports and terminals: Portsmouth, Roseau
Airports: 2(2005)
Airports - with paved runways:
total: 2
2,438 to 3,047 m:1
1,524 to 2,437 m:) (2005)
Roadways:
tote/: 910 km
pa^ed: 48 km
unpaved: 862 km (2000)
Ports and terminals: Castries, Cul-de-Sac,
Vieux-Fort
Airports: 2(2005)
Airports - with paved runways:
total: 2
1.524 to 2.437 m:\\
914 to 1.523 m:1 (2005)
Ports and terminals: Saint-Pierre
Military - note:
Airports: 6(2005)
Airports - with paved runways:
total: 5
914 to 1,523 m: 4
under 914 m: 1 (2005)
Airports • with unpaved runways:
total: 1
under 914 m:1 (2005)
Roadways:
total: 829 km
paved: 580 km
unpaved: 249 km (2003)
Merchant marine:
total: 584 ships (1000 GRT or over) 5,344,823 GRT/
8,033,377 DWT
by type: barge carrier 1 , bulk carrier 95, cargo 349,
chemical tanker 7, container 19, liquefied gas 5,
livestock carrier 3, passenger 5, passenger/cargo 15,
petroleum tanker 16, refrigerated cargo 43, roll on/roll
off 21 , specialized tanker 4, vehicle carrier 1
foreign-owned: 535 (Bangladesh 1 , Barbados 1 ,
Belgium 2, Bulgaria 1 6, Canada 2, China 1 06, Croatia
8, Cyprus 3, Czech Republic 1 , Denmark 1 4, Egypt 3,
Estonia 25, France 8, Germany 11, Greece 84,
Guyana 3, Hong Kong 6, Iceland 10, India 6, Iran 1,
Ireland 1, Israel 1, Italy 17, Kenya 3, Latvia 17,
Lebanon 4. Lithuania 5, Madagascar 1, Monaco 3,
Netherlands 7, Norway 17, Pakistan 2, Poland 1,
Puerto Rico 1 , Romania 2, Russia 21 , Saudi Arabia 2,
Serbia and Montenegro 2, Singapore 7, Slovenia 5,
Spain 1 , Sweden 1 , Switzerland 10, Syria 5, Tunisia 2,
Turkey 23, Ukraine 13, UAE 12, UK 16, US 21 ,
Vietnam 1)
registered in other countries: 2 (Comoros 1 , North
Korea 1) (2005)
Ports and terminals: Kingstown','dddafd309df8ce6d74a0a0e5c25a83e822cc35a7c2be42507e48f65301b9c3bb','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70a5b84e6a5191e12e51a0cde0ec55a2779be3ea15e73ae6e6fe407987b5e16f',2007,'PE','Peru','transportation',488,'Airports: 285(2005)
Airports - with paved runways:
total: 85
over 3,047 m: 3
2,438 to 3,047 m: 4
1,524 to 2, 437 m: 19
914 to 1,523 m: 30
under 914 m: 29 (2005)
Airports • with unpaved runways:
total: 200
914 to 1,523 m: 31
under 914 m: 169 (2005)
Heliports: 1 (2005)
Pipelines: extra heavy crude 578 km; gas 71 km; oil
1,386 km; refined products 1,185 km (2004)
Railways:
total: 966 km
narrow gauge: 966 km 1 .067-m gauge (2004)
Roadways:
total: 43, 197 km
paved: 7,287 km
unpaved: 35,910 km (2003)
Waterways: 1 ,500 km (most inaccessible) (2005)
Merchant marine:
total: 30 ships (1 000 GRT or over) 1 81 ,51 3 GRT/
297,003 DWT
by type: chemical tanker 1 , liquefied gas 1 , passenger
7, petroleum tanker 20, specialized tanker 1
foreign-owned: 2 (Germany 1 , Paraguay 1 )
registered in other countries: 1 (Georgia 1 ) (2005)
Ports and terminals: Esmeraldas, Guayaquil, La
Libertad, Manta, Puerto Bolivar
Airports: 87(2005)
Airports - with paved runways:
total: 72
over 3, 04 7 m: 13
2,438 to 3,047 m: 38
1,524 to 2,437 m: 17
under 914 m: 4 (2005)
Airports - with unpaved runways:
tote/: 15
2,438 to 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 5
under 914 m: 7 (2005)
Heliports: 2(2005)
Pipelines: condensate 289 km; condensate/gas 94
km; gas 6,115 km; liquid petroleum gas 852 km; oil
5,032 km; oil/gas/water 36 km; refined products 246
km (2004)
Railways:
total: 5,063 km
standard gauge: 5,063 km 1 .435-m gauge (62 km
electrified) (2004)
Roadways:
total: 64,000 km
paved: 49,984 km
unpaved: 14,016 km (1999)
Waterways: 3,500 km
note: includes Nile River, Lake Nasser,
Alexandria-Cairo Waterway, and numerous smaller
canals in delta; Suez Canal (193.5 km including
approaches) navigable by oceangoing vessels
drawing up to 17.68 m (2005)
Merchant marine:
total: 76 ships (1000 GRT or over) 987,524 GRT/
1,467,139 DWT
by type: bulk carrier 14, cargo 33, container 2,
passenger/cargo 5, petroleum tanker 13,
roll on/roll off 9
foreign-owned: 9 (Denmark 1 , Greece 6, Lebanon 2)
registered in other countries: 40 (The Bahamas 1 ,
Bolivia 1 , Cambodia 6, Cyprus 1 , Georgia 6, Honduras
1, Panama 17, Saint Vincent and the Grenadines 3,
Sao Tome and Principe 1, Saudi Arabia 1, Syria 1,
unknown 1) (2005)
Ports and terminals: Alexandria, Damietta, El
Dekheila, Port Said, Suez, Zeit','fc1a5eed9bfd20a12fe87f1c90aa04a948d83ff79bc5d830005cdb1470e9e295','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5736a0502ed04427df54ea09202975b95183db3f4ad6b3576e673c9f0aa08aea',2007,'SV','El Salvador','transportation',498,'Airports: 76(2005)
Airports - with paved runways:
total: 4
over 3,047 m:]
1,524 to 2,437 m:1
914 to 1,523 m: 2 (2005)
Airports - with unpaved runways:
total: 72
1,524 to 2,437 m; 1
914 to 1,523 m: 15
under 914 m: 56 (2005)
Heliports: 1 (2005)
Railways:
total: 283 km
narrow gauge: 283 km 0.91 4-m gauge
note: length of operational route reduced from 562 km
to 283 km by disuse and lack of maintenance (2004)
Roadways:
total: 10,029 km
paved: 1 ,986 km
unpaved: 8,043 km (1999)
Waterways: Rio Lempa partially navigable (2004)
Ports and terminals: Acajutla, Puerto Cutuco','fc1bb0ea530a65a045fadec42585293712dc8ea49b476f396d29db3f3995f4f6','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3feb37f079940cd528336cc4ef09751d0ba5954bd4c4a9f8fb3e413ad088d0a2',2007,'GN','Guinea','transportation',508,'Airports: 4(2005)
Airports - with paved runways:
total: 3
2.438 to 3,047 m: 1
1.524 to 2,437 m: 1
under 914 m:1 (2005)
Airports - with unpaved runways:
total: 1
under 914 m: 1 (2005)
Pipelines: condensate 37 km; gas 39 km; liquid
natural gas 4 km; oil 24 km (2004)
Roadways:
tofa/:2,880km(1999)
Merchant marine:
total: 2 ships (1000 GRT or over) 3,409 GRT/5.000
DWT
by type: cargo 1 , refrigerated cargo 1 (2005)
Ports and terminals: Malabo
Airports: 56(2005)
Airports • with paved runways:
total: 1 1
over 3,047 m: 1
2.438 to 3.047 m: 1
1.524 to 2.437 m: 8
914 to 1.523 mA (2005)
Airports - with unpaved runways:
total: 45
1.524 to 2,437 m:l
914 to 1.523 m:15
under 914 m: 23 (2005)
Pipelines: gas 210 km; oil 1,385 km (2004)
Railways:
total: 814 km
standard gauge: 814 km 1 .435-m gauge (2004)
Roadways:
total: 32,333 km
paved: 6,247 km
unpaved: 26,086 km (2003)
Waterways: 1,600 km (310 km on Ogooue River)
(2005)
Merchant marine:
registered in other countries: 1 (Cambodia 1) (2005)
Ports and terminals: Gamba, Libreville, Lucinda,
Owendo, Port-Gentil
Airports: 1 (2005)
Airports • with paved runways:
total: 1
over 3,047 m: 1 (2005)
209
Gambia, The (continued)
Roadways:
total: 3.742 km
paved: 723 km
unpaved: 3,019 km (2003)
Waterways: 390 km (on River Gambia; small
ocean-going vessels can reach 190 km) (2004)
Merchant marine:
total: 4 ships (1000 GRT or over) 30,976 GRT/1 0,978
DWT
by type: passenger/cargo 3, petroleum tanker 1
(2005)
Ports and terminals: Banjul
Airports: 16(2005)
Airports - with paved runways:
total: 5
over 3,047 m: 1
2.438 to 3,047 m: 1
1,524 to 2,437 m: 3 (2005)
Airports - with unpaved runways:
total: 1 1
1,524 to 2,437 m: 6
914 to 1,523 m: 3
under 914 m: 2 (2005)
Railways:
total: 837 km
standard gauge: 175 km 1.435-m gauge
narrow gauge: 662 km 1 .000-m gauge (2004)
Roadways:
total: 44,348 km
paved: 4,342 km
unpaved: 40,006 km (2003)
Waterways: 1 ,300 km (navigable by shallow-draft
native craft) (2005)
Ports and terminals: Kamsar
Military branches: Army (includes Presidential
Guard, Republican Guard), Navy, Air Force, National
Gendarmerie, General Directorate of National Police
Military service age and obligation: 18 years of
age for compulsory military service; conscript service
obligation - 24 months (2004)
Manpower available for military service:
males age 18-49: 1 ,853,31 6 (2005 est.)
Manpower fit for military service:
males age 1 8-49: 1 ,038,036 (2005 est.)
Military expenditures - dollar figure: $1 1 9.7
million (2005 est.)
Military expenditures • percent of GDP: 2.9%
(2005 est.)','bfc081c2b5d4c83743600c42ad3ee48c48d7e4aa49c229311a7806c5b93083d4','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c79940b20d77591eea5772b9fb978f71a1abbe344471cf5e103e0065829033c2',2007,'ER','Eritrea','transportation',517,'Airports: 17(2005)
Airports - with paved runways:
total: 4
over 3,047 m: 2
2,438 to 3,047 m: 2 (2005)
Airports - with unpaved runways:
total: 13
over 3,047 m: 1
2,438 to 3,047 m:1
1,524 to 2,437 m: 5
914 to 1,523 m: 4
under 914 m: 2 (2005)
Railways:
total: 306 km
narrow gauge: 306 km 0.950-m gauge (2004)
Roadways:
total: 4,01 0 km
paved: 874 km
unpaved: 3,136 km (1999)
Merchant marine:
total: 6 ships (1000 GRT or over) 19,506 GRT/23,649
DWT
by type: cargo 3, liquefied gas 1 , petroleum tanker 1 ,
roll on/roll off 1 (2005)
Ports and terminals: Assab, Massawa','2a5c4795b4fb00eb1ed4f00d1c8cb0cd874c49ac4bf11b3860040d8ac10d0c25','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6041e9d517bf6b52f0e25624f4390b9adb3c32f314d1554876ebbcfcfb98b154',2007,'EE','Estonia','transportation',526,'Airports: 26(2005)
Airports - with paved runways:
total: ]2
over 3,047 m: 1
2,438 to 3,047 m: 7
1 ,524 to 2,437 m: 1
914 to 1,523 m: 3 (2005)
Airports - with unpaved runways:
total: 14
over 3,047 m: 1
2,438 to 3,047 m. 1
1,524 to 2,437 m: 2
914 to 1,523 m: 4
under 914 m: 6 (2005)
Heliports: 1 (2005)
Pipelines: gas 859 km (2004)
Railways:
total: 958 km
broad gauge: 958 km 1 .520-m/1 .524-m gauge (1 32
km electrified) (2004)
Roadways:
total: 56,849 km
paved: 13,303 km (including 99 km of expressways)
unpaved: 45,546 km (2003)
Waterways: 500 km (2005)
Merchant marine:
total: 35 ships (1000 GRT or over) 267,319 GRT/
92,993 DWT
by type: cargo 10, passenger/cargo 23, petroleum
tanker 2
foreign-owned: 4 (Denmark 1 , Finland 1 , Norway 2)
registered in other countries: 71 (Antigua and
Barbuda 12, The Bahamas 1, Belize 5, Cambodia 2,
Cyprus 3, Dominica 8, Georgia 1 , Isle of Man 2, Malta
4, Netherlands Antilles 1 , Norway 1 , Panama 3,
Russia 1, Saint Vincent and the Grenadines 25,
Slovakia 1, Vanuatu 1) (2005)
Ports and terminals: Kopli, Kuivastu, Muuga,
Tallinn, Virtsu','9fc8ed4a5c8976a31c29ce6ae1e47bcec8b4e758dc8f89a2296eb2f24d4ac408','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90b8374b57304f878127c3771a41bb809632fef34aed444dc4c90397967108da',2007,'ET','Ethiopia','transportation',534,'Airports: 82(2005)
Airports - with paved runways:
total: 14
over 3,047 m: 3
2.438 to 3,047 m: 5
1.524 to 2,437 m: 5
914 to 1,523 m:: (2005)
Airports • with unpaved runways:
total: 68
over 3,047 m: 3
2,438 to 3,047 m: 3
1.524 to 2.437 m:13
914 to 1.523 m: 27
under 914 m: 22 (2005)
Railways:
total: 681 km (Ethiopian segment of the Addis
Ababa-Djibouti railroad)
narrow gauge: 681 km 1 ,000-m gauge
note: railway under joint control of Djibouti and
Ethiopia (2004)
Roadways:
total: 33.856 km
paved: 4,367 km
unpaved: 29,489 km (2003)
Merchant marine:
total: 8 ships (1000 GRT or over) 79,441 GRT/97.669
DWT
by type: cargo 6. roll on/roll off 2 (2005)
Ports and terminals: Ethiopia is landlocked and has
used ports of Assab and Massawa in Eritrea and port
of Djibouti
Airports: 28(2005)
Airports - with paved runways:
total: 3
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1(2005)
Airports - with unpaved runways:
total: 25
1,524 to 2,437 m: 1
914 to 1,523 m: 4
under 914 m: 20 (2005)
Roadways:
total: 4,400 km
paved: 453 km
unpaved: 3,947 km (1999)
Waterways: four largest rivers are navigable for
some distance; many inlets and creeks give
shallow-water access to much of interior (2006)
Ports and terminals: Bissau, Buba, Cacheu, Farim
Airports: 2(2005)
Airports - with paved runways:
total: 2
1,524 to 2,437 mA
914 to 1,523 m: 1 (2005)
Roadways:
total: 320 km
paved: 21 8 km
unpaved: 102 km (1999)
Merchant marine:
total: 10 ships (1000 GRT or over) 35,939 GRT/
54,246 DWT
by type: bulk carrier 2. cargo 7, chemical tanker 1
foreign-owned: 2 (Egypt 1, Greece 1) (2005)
Ports and terminals: Sao Tome','2034c9954fafbc0ecdc8f82e0086aae12affb776bda9893bd5f0ea8d9e2379fe','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b97d020f8a0a00ca7901610ccd93884e8c5c24104939a631a2a7d3808ad2f6b3',2007,'MZ','Mozambique','transportation',543,'Airports: 1 (2005)
Airports - with unpaved runways:
total: 1
914 to 1,523 m-A (2005)
Ports and terminals: none; offshore anchorage only
i I i t a ry
Military - note: defense is the responsibility of
Airports: 1 (2005)
Airports - with unpaved runways:
total: 1
914 to 1,523 m: 1(2005)
Ports and terminals: none; offshore anchorage only
Airports: 116(2005)
Airports - with paved runways:
total: 29
over 3,047 m:1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 20
under 914 m: 2 (2005)
Airports • with unpaved runways:
total: 87
1,524 to 2,437 m: 2
914 to 1,523 m: 42
under 914 m: 43 (2005)
Railways:
total: 732 km
narrow gauge: 732 km 1 .000-m gauge (2004)
Roadways:
total: 49,827 km
paved: 5,780 km
unpaved:44,047km(1999)
Waterways: 600 km (2005)
Merchant marine:
total: 9 ships (1000 GRT or over) 13,896 GRT/1 8,466
DWT
by type: cargo 7, petroleum tanker 2
registered in other countries: 1 (Saint Vincent and the
Grenadines 1) (2005)
Ports and terminals: Antsiranana, Mahajanga,
Toamasina, Toliara
Airports: 123(2005)
Airports - with paved runways:
total: 11
over 3,047 m: 2
2,438 to 3,047 m: 2
1.524 to 2.437 m: 5
914 to 1,523 mA
under 914 mA (2005)
Airports - with unpaved runways:
total: 112
1,524 to 2,437 m:18
914 to 1,523 m: 61
under 914 m: 33 (2005)
544
Tanzania (continued)
Pipelines: gas 29 km; oil 866 km (2004)
Railways:
total: 3,690 km
narrow gauge: 969 km 1.067-m gauge; 2,721 km
1 ,000-m gauge (2004)
Roadways:
total: 78,891 km
paved: 6,808 km
unpaved: 72,083 km (2003)
Waterways: Lake Tanganyika, Lake Victoria, and
Lake Nyasa principal avenues of commerce with
neighboring countries; rivers not navigable (2005)
Merchant marine:
total: 10 ships (1000 GRT or over) 25,838 GRT/
33.745 DWT
by type: cargo 2, passenger/cargo 4, petroleum
tanker 4
registered in other countries: 1 (Honduras 1 ) (2005)
Ports and terminals: Dar es Salaam, Mtwara,
Zanzibar City','e98e5e11bc786367e7bd78b343f0dc2f0b60adfd8f736cff30bcb6fe065c2cd7','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('336c56ef39bcdbbf31857ea8a9be51e903a5166ec0c9e13bc5d14178aca920b8',2007,'FO','Faroe Islands','transportation',550,'Airports: 1 (2005)
Airports - with paved runways:
total: 1
914 to 1,523 m: 1 (2005)
Roadways:
total: 458 km
note: no roads between towns (2003)
Merchant marine:
total: 19 ships (1000 GRT or over) 93,905 GRT/
58,764 DWT
by type: cargo 9, container 2, passenger/cargo 6,
petroleum tanker 2
foreign-owned: 9 (Germany 1 , Iceland 3, Norway 4,
UK 1) (2005)
Ports and terminals: Torshavn','676f53ec6a9c13363f52d9ff42a161933e30fc5088382ad7a346ce188d244535','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afa26dc52972486820e19a4ba664654bd5f18cd81dfde95d38592e0d788fbb30',2007,'JE','Jersey','transportation',561,'Airports: 28(2005)
Airports - with paved runways:
total: 3
over 3,047 m: 1
1,524 to 2,437 m: 1
914 to 1,523 m: 1(2005)
193
Fiji (continued)
Airports - with unpaved runways:
total: 25
914 to 1,523 m: 7
under 914 m: 18 (2005)
Railways:
total: 597 km
narrow gauge: 597 km 0.600-m gauge
note: belongs to the government-owned Fiji Sugar
Corporation; used to haul sugarcane during harvest
season (May to December) (2003)
Roadways:
total: 3,440 km
oaved: 1 ,692 km
unpaved: 1,748 km (1999)
Waterways: 203 km
note: 122 km navigable by motorized craft and
200-metric-ton barges (2004)
Merchant marine:
total: 7 ships (1000 GRT or over) 15,867 GRT/8,432
DWT
by type: passenger 3, passenger/cargo 2, roll on/roll
Dff2
foreign-owned: 1 (Australia 1 ) (2005)
Ports and terminals: Lambasa, Lautoka, Suva
Airports: 51 (2005)
Airports - with paved runways:
total: 28
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 8
914 to 1,523 m:W
under 914 m: 4 (2005)
Airports - with unpaved runways:
total: 23
1,524 to 2,437 m:1
914 to 1,523 m: 2
under 914 m: 20 (2005)
Heliports: 3(2005)
Pipelines: gas 140 km; oil 1,509 km (2004)
Railways:
total: 640 km
standard gauge: 640 km 1 .435-m gauge (2004)
Roadways:
total: 17,237 km
paved: 17,237 km (including 126 km of expressways)
(2002)
Merchant marine:
total: 18 ships (1000 GRT or over) 728,759 GRT/
863,881 DWT
by type: cargo 1 , chemical tanker 1 , container 1 6
registered in other countries: 53 (The Bahamas 5,
Bermuda 1, Cambodia 1, Cyprus 3, Honduras 1,
Liberia 5, Malta 27, Panama 3, Saint Vincent and the
Grenadines 1 , Slovakia 6) (2005)
Ports and terminals: Ashdod, Elat (Eilat), Hadera,
Haifa
Airports: 7(2005)
Airports - with paved runways:
total: 4
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2, 437 m: 1(2005)
Airports - with unpaved runways:
total: 3
1.524 to 2,437 m: 1
under 914 m: 2 (2005)
Heliports: 4(2005)
Pipelines: gas 169 km; oil 540 km; refined products
57 km (2004)
Roadways:
total: 4,450 km
paved: 3,587 km
unpaved: 863 km (1999)
Merchant marine:
total: 38 ships (1000 GRT or over) 2,294,233 GRT/
3,730,776 DWT
by type: bulk carrier 2, cargo 1 , container 6, liquefied
gas 5, livestock carrier 4, petroleum tanker 20
foreign-owned: 1 (Iran 1)
registered in other countries: 29 (Bahrain 3, Comoros
1 , Liberia 1 , Libya 1 , Panama 2, Qatar 7, Saudi Arabia
6, UAE 8) (2005)
Ports and terminals: Ash Shu''aybah, Ash
Shuwaykh, Az Zawr (Mina'' Sa''ud), Mina'' ''Abd Allah,
Mina'' al Ahmadi
Airports: 25(2005)
Airports - with paved runways:
total: 11
over 3,047 m: 1
914 to 1,523 m: 8
under 914 m: 2 (2005)
Airports - with unpaved runways:
total: 14
914 to 1,523 m: 8
under 914 m: 6 (2005)
Heliports: 6(2005)
Roadways:
total: 5,432 km (2000)
Merchant marine:
total: 2 ships (1000 GRT or over) 3,566 GRT/2,543
DWT
by type: cargo 1 , passenger/cargo 1 (2005)
Ports and terminals: Noumea
Airports: 14(2005)
Airports - with paved runways:
total: 6
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m:\\
914 to 1,523 m:2
under 914 m: 1(2005)
Airports • with unpaved runways:
total: 8
1,524 to 2,437 m: 2
914 to 1,523 m: 2
under 914 m: 4 (2005)
Pipelines: gas 2,526 km; oil 11 km (2004)
Railways:
tote/: 1 .201 km
standard gauge: 1,201 km 1.435-m gauge (499 km
electrified) (2004)
Roadways:
total: 38,400 km
paved: 38,400 km (including 417 km of expressways)
(2003)
Merchant marine:
registered in other countries: 25 (Antigua and
Barbuda 6, The Bahamas 1 , Cyprus 4, Georgia 1 ,
Liberia 2, Malta 3, Marshall Islands 2, Saint Vincent
and the Grenadines 5, Singapore 1) (2005)
Ports and terminals: Koper
Airports: 18(2005)
Airports - with paved runways:
total: 1
2,438 to 3,047 m: 1 (2005)
Airports - with unpaved runways:
total: M
914 to 1,523 m: 7
under 914 m:10 (2005)
Railways:
total: 301 km
narrow gauge: 301 km 1.067-m gauge (2004)
Roadways:
total: 3,594 km
paved: 1 ,078 km
unpaved: 2,516 km (2002)
Merchant marine:
registered in other countries: 1 (Panama 1 ) (2005)','c18db6dd888f5e8581badfb582a2dd1cc6b8d32f34971e1e3f1f3b30e3bd01bd','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1156b0992d24bc53cd0f96e2c0eb7d06da1d86343df1f135dcbb61bd87e7038f',2007,'FI','Finland','transportation',570,'Airports: 148(2005)
Airports - with paved runways:
total: 76
over 3,047 m: 2
2,438 to 3,047 m: 27
1,524 to 2,437 m:10
914 to 1,523 m: 23
under 914 m:U (2005)
Airports - with unpaved runways:
total: 72
914 to 1,523 m: 5
under 914 m: 67 (2005)
Pipelines: gas 694 km (2004)
Railways:
total: 5,851 km
broad gauge: 5,851 km 1.524-m gauge (2,400 km
electrified) (2004)
Roadways:
total: 78, 168 km
paved: 50,616 km (including 653 km of expressways)
unpaved: 27,552 km (2004)
Waterways: 7,842 km
note: includes Saimaa Canal system of 3,577 km;
southern part leased from Russia (2005)
Merchant marine:
total: 96 ships (1 000 GRT or over) 1 ,390,254 GRT/
1,108,246 DWT
by type: bulk carrier 4, cargo 24, chemical tanker 7,
container 1, passenger 5, passenger/cargo 21,
petroleum tanker 7, roll on/roll off 27
toreign-owned: 5 (Norway 1, Sweden 3, US 1)
registered in other countries: 43 (The Bahamas 7,
Bermuda 2, Estonia 1 , Germany 2, Gibraltar 1 ,
Luxembourg 3. Netherlands 9, Norway 4, Serbia and
Montenegro 1 , Sweden 1 1 , UK 2) (2005)
Ports and terminals: Hamina, Hanko, Helsinki,
Kotka, Naantali, Pori, Porvoo, Raahe, Rauma, Turku','e9e4cc5ba5d63e14b171cf548e4ce439361c8d6a690e96313b01c6e4b3b11afe','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39065bbc69af20dcd93cef75fb2bce59ceb02029292bb35864ae10adadf36a43',2007,'WF','Wallis and Futuna','transportation',576,'Airports: 479(2005)
Airports - with paved runways:
total: 288
over 3,047 mAZ
2,438 to 3,047 m: 28
1,524 to 2,437 m: 96
914 to 1,523 m: 82
under 914 m: 69 (2005)
Airports - with unpaved runways:
total: 191
1,524 to 2, 437 m: 3
914 to 1,523 m: 72
under 914 m: 116 (2005)
Heliports: 3(2005)
Pipelines: gas 14,232 km; oil 3,024 km; refined
products 4,889 km (2004)
Railways:
total: 29,51 9 km
standard gauge: 29,352 km 1.435-m gauge (14,481
km electrified)
narrow gauge: 167 km 1.000-m gauge (2004)
Roadways:
total: 891 ,290 km
paved: 891 ,290 km (including 10,390 km of
expressways) (2003)
Waterways: 8,500 km (1 ,686 km accessible to craft
of 3,000 metric tons) (2000)
'''' ■ V
Merchant marine:
total: 54 ships (1000 GRT or over) 1 ,050,735 GRT/
600,979 DWT
by type: cargo 4, chemical tanker 6, container 1 ,
liquefied gas 3, passenger 3, passenger/cargo 29,
petroleum tanker 7, roll on/roll off 1
foreign-owned: 4 (Sweden 3, Turkey 1 )
registered in other countries: 151 (Australia 3, The
Bahamas 28, Belgium 2, Bermuda 1 , Cambodia 1 ,
Cameroon 1 , Canada 1 , Republic of the Congo 1 ,
French Polynesia 1 , French Southern and Antarctic
Lands 45, Gibraltar 1 , Hong Kong 3, Indonesia 1 , Isle
of Man 2, Italy 3, South Korea 12, Liberia 3,
Luxembourg 9, Malta 8, Mexico 1 , Morocco 1 ,
Panama 8, Saint Vincent and the Grenadines 8, UK 3,
Wallis and Futuna 4) (2005)
Ports and terminals: Bordeaux, Calais, Dunkerque,
La Pallice, Le Havre, Marseille, Nantes, Paris, Rouen,
Strasbourg','e76780867a868296daed0cd1aaae070cb66c2a0db628a0a062ef618f13f583b5','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b11f19d8060ee337a0501f8e5ad97e19be76decb33622b2c2a2ddada062b493e',2007,'PF','French Polynesia','transportation',590,'Airports: 50(2005)
Airports - with paved runways:
total: 37
over 3,047 m: 2
1,524 to 2,437 m: 5
914 to 1,523 m: 23
under 914 m: 7 (2005)
Airports - with unpaved runways:
total: 13
914 to 1,523 m: 5
under 914 m: 8 (2005)
Heliports: 1 (2005)
Roadways:
total: 2,590 km
paved: 1 ,735 km
unpaved: 855 km (1999)
Merchant marine:
total: 15 ships (1000 GRT or over) 28,109 GRT/
17,158 DWT
by type: cargo 4, passenger 4, passenger/cargo 5,
refrigerated cargo 1 , roll on/roll off 1
foreign-owned: 1 (France 1) (2005)
Ports and terminals: Papeete','81aa426e418cc26f5e3a6f056e3e315117509259ba89803c21224660a888242b','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d90de855dc2edd276cdfbd045b84d76e86900fa10adb263e1dbe98c269f592b3',2007,'EG','Egypt','transportation',602,'Airports: 2(2001)
note: includes Gaza International Airport (GIA),
inaugurated on 24 November 1998 as part of
agreements stipulated in the September 1995 Oslo II
Accord and the 23 October 1998 Wye River
Memorandum; GIA has been largely closed since
October 2000 by Israeli orders and its runway was
destroyed by the Israeli Defense Forces in
December 2001 (2005)
Airports - with paved runways:
total: 1
over 3,047m:) (2005)
Airports - with unpaved runways:
total: 1
under 914 m:1 (2005)
Heliports: 1 (2005)
Roadways:
note: see entry for West Bank
Ports and terminals: Gaza','756d65ef39a38b1a79d80923e1ebc21b6e6111cc2567360cabd98e62baf995e4','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8c9b0fa56ea3fa53cc302d4904b7799f16931ef5ce8568c58ec6267e2319b24',2007,'GE','Georgia','transportation',611,'Airports: 25(2005)
Airports - with paved runways:
total: 19
over 3,047 m:1
2,438 to 3,047 m: 7
1,524 to 2,437 m: 5
914 to 1,523 m: 4
under 914 m: 2 (2005)
Airports - with unpaved runways:
total: 6
1.524 to 2,437 m: 4
914 to 1,523 mA
under 914 mA (2005)
Heliports: 3(2005)
Pipelines: gas 1,697 km; oil 1,027 km; refined
products 232 km (2004)
Railways:
total: 1,612 km (1,612 km electrified)
broad gauge: 1,575 km 1.520-m gauge (1,575
electrified)
narrow gauge: 37 km 0.91 2-m gauge (37 electrified)
(2004)
Roadways:
total: 20,247 km
paved: 7,973 km
unpaved: 12,274 km (2003)
Merchant marine:
total: 192 ships (1000 GRT or over) 936,396 GRT/
1,373,814 DWT
by type: barge carrier 1 , bulk carrier 23, cargo 150,
container 4, liquefied gas 1 , passenger 1 , passenger/
cargo 3, petroleum tanker 4, refrigerated cargo 3, roll
on/roll off 1 , specialized tanker 1
foreign-owned: 157 (Albania 1, Azerbaijan 2, Belgium
1 , Cyprus 1 , Ecuador 1 , Egypt 6, Estonia 1 , Germany
1, Greece 5, Indonesia 1, South Korea 1, Lebanon 5,
Monaco 12, Romania 8, Russia 20, Slovenia 1, Syria
37, Turkey 24, Ukraine 23, UAE 1, UK 5) (2005)
Ports and terminals: Bat''umi, P''ot''i
Transportation - note: transportation network is in
poor condition resulting from ethnic conflict, criminal
activities, and fuel shortages; network lacks
maintenance and repair
214
Georgia (continued)','d53ac30f7a9b95bf978aa093432588df9c374a470a9b9c4e05dc9ab6e75d4c4b','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a6180d07e951e416d43eaabe4e20aaee34fb503ec86eff14a61e2a2a238faca',2007,'GH','Ghana','transportation',619,'Airports: 12(2005)
Airports - with paved runways:
total: 7
over 3,047 m: 1
1,524 to 2,437 m: A
91 ''4 to 1,523 m: 2 (2005)
Airports - with unpaved runways:
total: 5
914 to 1,523 m: 3
under 914 m: 2 (2005)
Pipelines: refined products 74 km (2004)
Railways:
total: 953 km
narrow gauge: 953 km 1 ,067-m gauge (2004)
Roadways:
total: 47,787 km
paved: 8,563 km
unpaved: 39,224 km (2003)
Waterways: 1,293 km
note: 168 km for launches and lighters on Volta,
Ankobra, and Tano rivers; 1 ,125 km of arterial and
feeder waterways on Lake Volta (2005)
Merchant marine:
total: 4 ships (1000 GRT or over) 6,308 GRT/9,418
DWT
by type: cargo 1 , petroleum tanker 1 . refrigerated
cargo 2
foreign-owned: 1 (Brazil 1) (2005)
Ports and terminals: Takoradi, Tema','da88d4082366d99c89ae6123a099375df1c3536b4ca51ad1fe254fdaaee33765','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5559e35d1e0c32bd6cbfd0c1f1856f6171af9c145562bb25963404bb9cf6dd67',2007,'GI','Gibraltar','transportation',629,'Airports: 1 (2005)
Airports - with paved runways:
total: 1
1.524 to 2.437 m: 1 (2005)
Roadways:
total: 29 km
paved: 29 km (2002)
Merchant marine:
total: 160 ships (1000 GRT or over) 1,1 10,970 GRT/
1,386,556 DWT
by type: barge carrier 3, bulk carrier 1, cargo 102,
chemical tanker 20, container 14, passenger 3,
passenger/cargo 1 , petroleum tanker 1 1 , roll on/roll off
4, specialized tanker 1
foreign-owned: 148 (Belgium 1 , Finland 1 , France 1 ,
Germany 106, Greece 9, Iceland 1, Ireland 1, Italy 5,
Latvia 2, Norway 9, Sweden 5, Taiwan 1 , UK 4, US 2)
(2005)
Ports and terminals: Gibraltar
Airports: 1 (2005)
Airports - with unpaved runways:
total: 1
914 to 1,523 m-A (2005)
Ports and terminals: none; offshore anchorage only
Airports: 60(2005)
Airports - with paved runways:
total: 25
over 3,047 m: 11
2,438 to 3,047 m: 4
1,524 to 2,437 m: 8
914 to 1,523 m-A
under 914 mA (2005)
Airports - with unpaved runways:
total: 35
2,438 to 3,047 m: 2
1,524 to 2,437 m: 9
914 to 1,523 m: 13
under 914 m: 11 (2005)
Heliports: 1 (2005)
Pipelines: gas 695 km; oil 285 km (2004)
Railways:
total: 1,907 km
standard gauge: 1 ,907 km 1 .435-m gauge (1 ,003 km
electrified) (2004)
Roadways:
total: 57,694 km
paired: 32,551 km (including 417 km of expressways)
unpaired:25,143km(2002)
Merchant marine:
total: 41 ships (1 000 GRT or over) 382,994 GRT/
285,435 DWT
by type: cargo 5, chemical tanker 6, container 9,
passenger/cargo 1 3, petroleum tanker 1 , refrigerated
cargo 2, roll on/roll off 5
foreign-owned: 5 (France 1, Germany 2, Switzerland
1, UK 1) (2005)
Ports and terminals: Agadir, Casablanca,
Mohammedia, Nador, Safi, Tangier','56dfb4db1d66ba98c11d494d63a32e4a5e9339d0b1ebbc4a5608aa2bb053d531','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95d21f897ae014f0424a4ea57a8b3c5073173a1629f96992baae86e37cac1725',2007,'GR','Greece','transportation',638,'Airports: 82(2005)
Airports - with paved runways:
total: 67
over 3,047 m: 5
2,438 to 3,047 m: 16
1,524 to 2,437 m: 19
914 to 1,523 m: 17
under 914 m:W {2005)
Airports - with unpaved runways:
tofa/:15
914 to 1,523 m: 3
under 914 m: 12 (2005)
Heliports: 8(2005)
Pipelines: gas 1,166 km; oil 94 km (2004)
Railways:
total: 2,571 km (764 km electrified)
standard gauge: 1 ,565 km 1 .435-m gauge
narrow gauge: 961 km 1.000-m gauge; 22 km
0.750-m gauge
dual gauge: 23 km combined 1 .435-m and 1 .000-m
gauges (three rail system) (2004)
Roadways:
total: 116,470 km
paved: 106,920 km (including 880 km of
expressways)
unpaved: 9,550 km (1999)
Waterways: 6 km
note: Corinth Canal (6 km) crosses the Isthmus of
Corinth; shortens sea voyage by 325 km (2006)
Merchant marine:
total: 813 ships (1000 GRT or over) 30,656,860 GRT/
52,298,434 DWT
by type: bulk carrier 272, cargo 61 , chemical tanker
42, combination ore/oil 1, container 44, liquefied gas
4, passenger 12, passenger/cargo 120, petroleum
tanker 239, roll on/roll off 17, specialized tanker 1
225
Greece (continued)
foreign-owned: 21 (Belgium 1 1 , Chile 1 , Sweden 1 ,
UK 8)
registered in other countries: 2,338 (The Bahamas
217. Barbados 11, Belgium 4, Bermuda 1 , Cambodia
7, Cayman Islands 22, Comoros 8, Cyprus 352,
Denmark 1 , Dominica 3, Egypt 6, French Southern
and Antarctic Lands 2, Georgia 5, Gibraltar 9,
Honduras 3, Hong Kong 28, India 1 , Isle of Man 43,
Italy 6, Jamaica 5, North Korea 1 , Lebanon 2, Liberia
229, Malta 515, Marshall Islands 179, Panama 536,
Philippines 7, Portugal 4, Russia 1 , Saint Vincent and
the Grenadines 84, Sao Tome and Principe 1,
Singapore 8, Slovakia 5, Syria 1 , UAE 2, UK 7, US 3,
Uruguay 1, Vanuatu 1, Venezuela 2, unknown 15)
(2005)
Ports and terminals: Agioitheodoroi, Aspropyrgos,
Irakleion, Pachi, Peiraiefs, Thessaloniki','f096eef9d56c24f1577ce9e243b8dad75111a7074fbea0072e6304b63ac67631','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0704ca082a88b7430d2ba43e8c4a2b1e1b3a14059af2b9c668335d44be284a7f',2007,'MQ','Martinique','transportation',641,'c, ^Hillsborough
S? i"; Carriacou
Caribbean ^
Sea <p
0
Ronde ''
Island o
5-
Sauleurs^
*J Mount
Gouyave, J™^
NORTH
ATLANTIC
Grenville.
OCEAN
SAINT Qn
GEORGE''S
Point Sahnes * J
International
Atrpoft
inada
O 5 10 km
O 5 lOrra
Introductio
Background: Carib Indians inhabited Grenada when
Columbus discovered the island in 1498, but it
remained uncolonized for more than a century. The
French settled Grenada in the 17th century,
established sugar estates, and imported large
numbers of African slaves. Britain took the island in
1762 and vigorously expanded sugar production. In
the 19th century, cacao eventually surpassed sugar
as the main export crop; in the 20th century, nutmeg
became the leading export. In 1967, Britain gave
Grenada full autonomy over its internal affairs. Full
independence was attained in 1974 making Grenada
one of the smallest independent countries in the
Western Hemisphere. Grenada was seized by a
Marxist military council on 19 October 1983. Six days
later the island was invaded by US forces and those of
six other Caribbean nations, which quickly captured
the ringleaders and their hundreds of Cuban advisers.
Free elections were reinstituted the following year and
have continued since that time. On 7 September
2004, Hurricane Ivan struck Grenada directly causing
damage to over 85% of the structures on the island
and at least 39 deaths.
Airports: 3(2005)
Airports - with paved runways:
total: 3
2.438 to 3,047 m; 1
1.524 to 2.437 m: 1
under 914 m:\\ (2005)
Roadways:
total. 1,127 km
paved: 687 km
unpaved:440km(1999)
Ports and terminals: Saint George''s','7b66ed80a806e30547737ccb9c6c5cae297c82008aa65a204ec69c2550d9893d','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebb6025cd560afc466afd29fb8a1dc95ab06f2dfc68767ca5222ef9b5db2c16a',2007,'GU','Guam','transportation',661,'Airports: 5(2005)
Airports - with paved runways:
total: 4
over 3,047 m: 2
2.438 to 3,047 m: 1
914 to 1.523 m: 1 (2005)
Airports - with unpaved runways:
total: 1
under 914 m:1 (2005)
Roadways:
total: 977 km (2004)
Ports and terminals: Apra Harbor','49e43a5af4e537818f129566e3c56c7e8dfe90799be762ea87fa5c4591ef1337','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a7935e3e09b225f3a8abfe03f45afce2072fd36fcab82fdf2b84eea4ce569b2',2007,'GG','Guernsey','transportation',669,'Airports: 2(2005)
Airports - with paved runways:
total: 2
914 to 1,523 m:\\
under 914 mA (2005)
Ports and terminals: Saint Peter Port, Saint
Sampson','14fa85d1bcc92729ddf4259a6da6da33b1ff36ed2bc83e3fe32180f55d2ad61c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f30746f9b91180c9f230ed649d75ea4bb8d0bef89b714ca6d5120ef90bfb326',2007,'GY','Guyana','transportation',680,'Airports: 69(2005)
Airports - with paved runways:
total: 8
1,524 to 2,437 m: 3
under 914 m: 5 (2005)
Airports - with unpaved runways:
total: 61
1,524 to 2,437 m: 2
974 to 1,523 m: 12
under 914 m: 47 (2005)
Railways:
tofa/:187km
standard gauge: 1 39 km 1 .435-m gauge
narrow gauge: 48 km 0.91 4-m gauge
note: all dedicated to ore transport (2001 est.)
Roadways:
total: 7,970 km
paved: 590 km
unpaved: 7,380 km (1999)
Waterways: Berbice, Demerara, and Essequibo
rivers are navigable by oceangoing vessels for 150
km, 100 km, and 80 km respectively (2005)
Merchant marine:
total: 7 ships (1000 GRT or over) 11,031 GRT/1 2,899
DWT
by type: cargo 6, refrigerated cargo 1
foreign-owned: 1 (Germany 1)
registered in other countries: 4 (Saint Vincent and the
Grenadines 3, unknown 1) (2005)
Ports and terminals: Georgetown
Airports: 47(2005)
Airports - with paved runways:
total: 5
over 3,047 m:]
under 914 m: 4 (2005)
Airports - with unpaved runways:
total: 42
1,524 to 2,437 m: 1
914 to 1,523 m: 5
under 914 m: 36 (2005)
Pipelines: oil 51 km (2004)
Roadways:
total: 4,492 km
paved: 1,168 km
unpaved: 3,324 km (2002)
Waterways: 1 ,200 km (most navigable by ships with
drafts up to 7 m) (2005)
Merchant marine:
total: 1 ships (1000 GRT or over) 1 ,078 GRT/1 ,214
DWT
by type: cargo 1 (2005)
Ports and terminals: Paramaribo
Airports: 4(2005)
Airports - with paved runways:
total: 2
1,524 to 2, 437 m: 1
914 to 1,523 m: 1 (2005)
Airports - with unpaved runways:
total: 2
under 914 m: 2 (2005)
Ports and terminals: Barentsburg, Longyearbyen,
Ny-Alesund, Pyramiden','22547eea6e46c2693e8e5b3b163f175dd1f7ff40145ef5d4e55f897fa6343ebf','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5894894afd2df54cf80d0af78b4d0a03143e999b6f9a90de1faeae0c9ea94ff6',2007,'IT','Italy','transportation',690,'Airports: none (2005)
Airports: none (2005)
Roadways:
total: 104 km
paved: 104 km (2003)
Military branches: no regular military forces;
Voluntary Military Force (Corpi Militari Voluntar)
performs ceremonial duties and limited police
functions (2006)
Military expenditures • dollar figure: $700,000
(FY00/01)
Military expenditures - percent of GDP: NA
Military - note: defense is the responsibility of Italy
Airports: 65(2005)
Airports - with paved runways:
total: 42
over 3,047 m: 3
2,438 to 3,047 m: 4
1,524 to 2,437 m: 11
914 to 1,523 m: 8
under 914 m: 16 (2005)
Airports - with unpaved runways:
total: 23
under 914 m: 23 (2005)
Heliports: 2(2005)
Pipelines: gas 1 ,831 km; oil 94 km; refined products
7 km (2004)
Railways:
total: 4,527 km
standard gauge: 3,232 km 1 .435-m gauge (3,21 1 km
electrified)
narrow gauge: 1 ,285 km 1 .000-m gauge (1 ,273 km
electrified); 10 km 0.800-m gauge (10 km electrified)
(2004)
Roadways:
total: 71 ,220 km
paved: 71 ,220 km (including 1 ,726 of expressways)
(2003)
Waterways: 65 km (Rhine River between
Basel-Rheinfelden and Schaffhausen-Bodensee) (2003)
Merchant marine:
total: 25 ships (1000 GRT or over) 468,821 GRT/
778,115 DWT
by type: bulk carrier 9, cargo 9, chemical tanker 2,
container 4, specialized tanker 1
foreign-owned: 2 (Monaco 2)
registered in other countries: 306 (Antigua and
Barbuda 4, The Bahamas 7, Belize 2, Bermuda 1 ,
Cyprus 6, French Southern and Antarctic Lands 1,
Germany 1, Indonesia 2, Ireland 1, Italy 7, Liberia 7,
Malta 21 , Marshall Islands 1 1 , Mauritius 2, Morocco 1 ,
Panama 206, Portugal 3, Russia 8, Saint Kitts and
Nevis 1 , Saint Vincent and the Grenadines 10, Tonga
1, Turkey 1, Vanuatu 2) (2005)
Ports and terminals: Basel
Airports: 92(2005)
Airports - with paved runways:
total: 26
over 3,047m: 6
2,438 to 3,047 m: 15
914 to 1,523 m: 3
under 914 m: 2(2005)
Airports - with unpaved runways:
total: 66
1,524 to 2,437 m: 2
914 to 1,523 m: 10
under 914 m: 54(2005)
Heliports: 7(2005)
Pipelines: gas 2,300 km; oil 2,183 km (2004)
Railways:
total: 2,71 1 km
standard gauge: 2,460 km 1.435-m gauge
narrow gauge: 251 km 1.050-m gauge (2004)
Roadways:
total: 91,795 km
paved: 18,451 km
unpaved: 73,344 km (2003)
Waterways: 900 km (not economically significant)
(2005)
Merchant marine:
total: 114 ships (1000 GRT or over) 397,014 GRT/
578,136 DWT
by type: bulk carrier 7, cargo 100, container 1 ,
livestock carrier 4, petroleum tanker 1 , roll on/roll off 1
foreign-owned: 12 (Egypt 1, Greece 1, Lebanon 7,
Romania 3)
registered in other countries: 104 (Cambodia 1 1 ,
Comoros 3, Cyprus 2, Dominica 2, Georgia 37, Kiribati
1, North Korea 21, Malta 6, Mongolia 2, Panama 9,
Saint Kitts and Nevis 1, Saint Vincent and the
Grenadines 5, Slovakia 2, unknown 2) (2005)
Ports and terminals: Baniyas, Latakia','15577f1fdd2cc37b94627812adf11779d9321448024f066e4c1c9e30860f7b5a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dbb8b87ef254c7a455ed061e8e21a33dc727b135b6f08911ba7a6c441b1100ae',2007,'NI','Nicaragua','transportation',700,'Airports: 116(2005)
Airports - with paved runways:
total: 1 1
2,438 to 3,047 m: 3
1524 to 2,437 m: 2
914 to 1,523 m: 3
under 914 m: 3 (2005)
Airports - with unpaved runways:
tote/: 105
1,524 to 2,437 m: 2
914 to 1,523 m: 19
under 914 m: 84 (2005)
Railways:
total: 699 km
narrow gauge: 279 km 1 .067-m gauge; 420 km
0.91 4-m gauge (2004)
Roadways:
total: 13,603 km
paved: 2,775 km
unpaved: 10,828 km (1999)
Waterways: 465 km (most navigable only by small
craft) (2005)
Merchant marine:
total: 131 ships (1000 GRT or over) 356,805 GRT/
518,767 DWT
by type: bulk carrier 9, cargo 66, chemical tanker 6,
container 1 , liquefied gas 1 , livestock carrier 1 ,
passenger 4, passenger/cargo 5, petroleum tanker
27, refrigerated cargo 8, roll on/roll off 2, specialized
tanker 1
foreign-owned: 43 (Canada 1 , China 3, Egypt 1 ,
Greece 3, Hong Kong 2, Indonesia 1 , Israel 1 , Japan
4, South Korea 6, Lebanon 1 , Mexico 1 , Singapore 1 2,
Taiwan 2, Tanzania 1 , Turkey 1 , US 2, Vietnam 1 )
(2005)
Ports and terminals: Puerto Castilla, Puerto Cortes,
San Lorenzo, Tela','416e036979a294eb5ed69083385aadaea43d988bc6fdf4f3d004e904ad523bca','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('021848d0c57102703d431a7480e665405890a5da0dde3a6fa2e6cf19eb18714d',2007,'RO','Romania','transportation',712,'Airports: 44(2005)
Airports - with paved runways:
total: 19
over 3,047 m: 2
2.438 to 3,047 m: 8
1,524 to 2,437 m: 4
914 to 1,523 m: 4
under 914 m;1 (2005)
Airports - with unpaved runways:
total: 25
2,438 to 3,047 m: 2
1,524 to 2,437 m: 3
914 to 1,523 m: 1 1
under 914 m: 9 (2005)
Heliports: 5(2005)
Pipelines: gas 4,397 km; oil 990 km; refined
products 335 km (2004)
Railways:
total: 7,937 km
broad gauge: 36 km 1 .524-rn gauge
standard gauge: 7,682 km 1 .435-m gauge (2,628 km
electrified)
narrow gauge: 219 km 0.760-m gauge (2004)
Roadways:
total: 159,568 km
paved: 70,050 km (including 527 km of expressways)
unpaved: 89,518 km (2002)
Waterways: 1 ,622 km (most on Danube River)
(2006)
Ports and terminals: Budapest, Dunaujvaros,
Gyor-Gonyu, Csepel, Baja, Mohacs (2003)
Airports: 97(2005)
Airports - with paved runways:
total: 5
over 3,047 m:)
1,524 to 2,437 m: 3
914 to 1,523 m: 1 (2005)
Airports - with unpaved runways:
total: 92
1.524 to 2,437 m: 3
914 to 1.523 m: 29
under 914 m: 60 (2005)
Roadways:
total: 13,028 km
paved/oiled gravel: 4,343 km
unpaved: 8,685 km (2005)
Merchant marine:
total: 2 ships (1000 GRT or over) 4,479 GRT/1 ,296
DWT
by type: cargo 1 , passenger/cargo 1
registered in other countries: 30 (Antigua and
Barbuda 7, Belize 1, Denmark 1, Faroe Islands 3,
Gibraltar 1 , Malta 4, Norway 3, Saint Vincent and the
Grenadines 10) (2005)
Ports and terminals: Grundartangi, Hafnarfjordur,
Hornafjordhur, Reykjavik, Seydhisfjordhur
Airports: 15(2005)
Airports - with paved runways:
total: 6
over 3,047 mA
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
under 914 mA (2005)
Airports - with unpaved runways:
total: 9
1,524 to 2,437 mA
914 to 1,523 m: 4
under 914 m: 4 (2005)
Pipelines: gas 606 km (2004)
Railways:
total: 1,138 km
broad gauge: 1 , 1 24 km 1 .520-m gauge
standard gauge: 1 4 km 1 .435-m gauge (2004)
Roadways:
total: 12,730 km
paved: 10,973 km
unpaved: 1,757 km (2003)
Waterways: 424 km (on Dniester River) (2005)
Merchant marine:
total: 6 ships (1000 GRT or over) 1 1 ,425 GRT/12,185
DWT
by type: cargo 6
foreign-owned: 3 (Ukraine 3) (2005)','1140bba54d67f9cdc3e00bdb3de8fc13f87866c62a79c298027baa4d934af9c5','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('498457e217f89392377016f95f51a13c6bfcf94cc6ffc55a297b87943d387df0',2007,'IN','India','transportation',720,'Airports: 334(2005)
Airports - with paved runways:
total: 239
over 3, 04 7 m: 17
2,438 to 3,047 m: 48
1,524 to 2,437 m: 75
914 to 1,523 m: 79
under 914 m: 20 (2005)
Airports - with unpaved runways:
total: 95
2,438 to 3,047 m: 2
1,524 to 2,437 m: 6
914 to 1,523 m: 39
under 914 m: 48 (2005)
Heliports: 27(2005)
Pipelines: gas 6,171 km; liquid petroleum gas 1,195
km; oil 5,613 km; refined products 5,567 km (2004)
Railways:
total: 63,230 km (16,693 km electrified)
broad gauge: 45,71 8 km 1 .676-m gauge
narrow gauge: 14,406 km 1 .000-m gauge; 3,106 km
0.762-m gauge and 0.61 0-m gauge (2004)
Roadways:
total: 3,851,440 km
pai/ec/:2,411,001 km
unpa ved: 1,440,439 km (2002)
Waterways: 14,500 km
note: 5,200 km on major rivers and 485 km on canals
suitable for mechanized vessels (2005)
Merchant marine:
total: 313 ships (1000 GRT or over) 7,550,865 GRT/
12,891,376 DWT
by type: barge carrier 4, bulk carrier 90, cargo 70,
chemical tanker 1 3, combination ore/oil 1 , container 8,
liquefied gas 16, passenger 3, passenger/cargo 10,
petroleum tanker 97, roll on/roll off 1
foreign-owned: 1 1 (China 1 , Greece 1 , Hong Kong 1 ,
UAE 7, UK1)
registered in other countries: 51 (Bahrain 1 , Comoros
1 , Cyprus 7, Denmark 1 , North Korea 1 , Liberia 4,
Malta 1, Marshall Islands 1, Mauritius 4, Panama 16,
Philippines 1, Saint Vincent and the Grenadines 6,
Singapore 4, Venezuela 1 , unknown 2) (2005)
Ports and terminals: Chennai, Haldia, Jawaharal
Nehru, Kandla, Kolkata (Calcutta), Mumbai (Bombay),
New Mangalore, Vishakhapatnam
263
India (continued)','715af7e4333fd087a2887daa6a885be31f6abccb2955477eb27cf9616ff86063','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fe8de8eee5a1cddce0bdbd435d610116b12fb8955d8e7f1bbd47f1f6c15653a',2007,'IE','Ireland','transportation',730,'Airports: 36(2005)
Airports - with paved runways:
total: 15
over 3,047 m: -\\
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 3
under 914 m: 6 (2005)
Airports - with unpaved runways:
total: 21
914 to 1,523 m: 4
t/nder974m:17(2005)
Pipelines: gas 1 ,795 km (2004)
Railways:
total: 3,312 km
broad gauge: 1 ,947 km 1 .600-m gauge (46 km
electrified)
narrow gauge: 1 ,365 km 0.91 4-m gauge (operated by
the Irish Peat Board to transport peat to power
stations and briquetting plants) (2004)
Roadways:
total: 95,736 km
paved: 95,736 km (including 125 km of expressways)
(2002)
Waterways: 753 km (pleasure craft only) (2005)
Merchant marine:
total: 33
by type: bulk carrier 3, cargo 22, chemical tanker 2,
container 1 , passenger/cargo 3, roll on/roll off 2
foreign-owned: 10 (Germany 3, Italy 2, Norway 1,
Spain 1, Switzerland 1, UK 1, US 1)
registered in other countries: 21 (The Bahamas 2,
Bermuda 1, Gibraltar 1, Netherlands 13, Panama 2,
Saint Vincent and the Grenadines 1 , UK 1) (2005)
Ports and terminals: Cork, Dublin, New Ross,
Shannon Foynes, Watertord','0f4394c51752e53760e9866eeaf1f5691b73e758160b807922aef4c862ac1e32','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('943565c88b8431816d02c8ed4bffd4509eeab4a047d2425065c9d575f97d49f8',2007,'IM','Isle of Man','transportation',739,'Airports: 1 (2005)
Airports • with paved runways:
total: 1
1,524 to 2,437 m: 1(2005)
Railways:
total: 61 km (35 km electrified) (2003)
Roadways:
total: 800 km
paved: 800 km (1999)
Merchant marine:
total: 292 ships (1000 GRT or over) 7,909,896 GRT/
13,339,460 DWT
by type: bulk carrier 40, cargo 60, chemical tanker 52,
combination ore/oil 1, container 16, liquefied gas 35,
passenger/cargo 1 , petroleum tanker 67, refrigerated
cargo 5, roll on/roll off 9, specialized tanker 1 , vehicle
carrier 5
foreign-owned: 205 (Denmark 49, Estonia 2, France
2, Germany 55, Greece 43, Hong Kong 1 , Iran 1 , Italy
7, Japan 4, Monaco 1 , Netherlands 2, Norway 23,
Singapore 8, Sweden 1 , Turkey 3, US 3)
registered in other countries: 10 (Antigua and
Barbuda 1 , Cambodia 1 , Liberia 5, NZ 1 , Panama 2)
(2005)
Ports and terminals: Castletown, Douglas, Ramsey
Military - note: defense is the responsibility of the
UK','deb7194c265303daa3055e634167bda2a46f34ba02f4bb404d32670a95642b71','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fb391becc7d2ea260134cd10ceece03b9862c745f478658025362d523c3f095',2007,'TN','Tunisia','transportation',748,'Airports: 135(2005)
Airports • with paved runways:
total: 98
over 3,047 m: 7
2,438 to 3,047 m: 30
7,524 to 2,437 m: 16
974 to 1,523 m: 31
under974m:14(2005)
Airports - with unpaved runways:
total: 37
1,524 to 2,437 m: 2
914 to 1,523 m: 16
under974m:19(2005)
Heliports: 3(2005)
Pipelines: gas 17,335 km; oil 1,136 km (2004)
Railways:
total: 19,319 km (11,613 km electrified)
standard gauge: 18,001 km 1.435-m gauge (11,333
km electrified)
narrow gauge: 123 km 1 .000-m gauge (122 km
electrified); 1 ,195 km 0.950-m gauge (158 km
electrified) (2004)
Roadways:
total: 479,688 km
paved: 479,688 km (including 6,620 km of
expressways) (1999)
Waterways: 2,400 km
note: used for commercial traffic; of limited overall
value compared to road and rail (2004)
Merchant marine:
total: 571 ships (1000 GRT or over) 10,781 ,338 GRT/
11,194,627 DWT
284
Italy (continued)
by type: bulk carrier 40, cargo 48, chemical tanker
122, combination ore/oil 1 , container 22, liquefied gas
37, livestock carrier 2, passenger 17, passenger/
cargo 155, petroleum tanker 50, refrigerated cargo 4,
roll on/roll off 33, specialized tanker 13, vehicle
carrier 27
foreign-owned: 53 (France 3, Greece 6, Monaco 6,
Switzerland 7, Taiwan 10, UK 6, US 15)
registered in other countries: 149 (The Bahamas 6,
Belgium 1, Belize 4, Cayman Islands 11, Gibraltar 5,
Ireland 2, Isle of Man 7, North Korea 1, Liberia 20,
Malta 25, Marshall Islands 1, Norway 4, Panama 16,
Portugal 10, Romania 2, Saint Vincent and the
Grenadines 17, Spain 2, Sweden 7, Turkey 3, UK 5)
(2005)
Ports and terminals: Augusta, Genoa, Livorno,
Melilli Oil Terminal, Ravenna, Taranto, Trieste, Venice
Airports: 1 (2005)
Airports - with unpaved runways:
total: 1
under 914 mA (2005)
Ports and terminals: none; offshore anchorage only','8a53b117b23e518c75518e8750680c84f20f5348a3d8fb7999be16ad0d0a0709','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c33599ee75613493bd3919d55ecc8d2461489a363983663bf6451b180860e22',2007,'IS','Iceland','transportation',758,'Airports: 1 (2005)
Airports - with unpaved runways:
total: 1
1,524 to 2,437 m: 1 (2005)
Ports and terminals: none; offshore anchorage only','aea83a47568c8d72f9068833fdb106d20c07442932340c4ab8633d478aa79106','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b9d425fbfb51fb9320075a3f60698d28fabc5cce277d9d5ec1b0128f458ea83',2007,'JP','Japan','transportation',766,'Airports: 173(2005)
Airports - with paved runways:
fofa/:142
over 3,047 m: 7
2.438 to 3,047 m: 39
1,524 to 2,437 m: 37
914 to 1,523 m: 29
under 914 m: 30 (2005)
Airports - with unpaved runways:
total: 31
over 3,047 m:1
914 to 1,523 m: 4
under 914 m: 26 (2005)
Heliports: 15(2005)
Pipelines: gas 2,71 9 km; oil 1 70 km; oil/gas/water 60
km (2004)
Railways:
total: 23,577 km (16,519 km electrified)
standard gauge: 3,204 km 1 .435-m gauge (3,204 km
electrified)
narrow gauge: 77 km 1 .372-m gauge (77 km
electrified); 20,265 km 1 ,067-m gauge (13,227 km
electrified); 11 km 0.762-m gauge (11 km electrified)
(2004)
Roadways:
total: 1,177,278 km
paved: 914,745 km (including 6,946 km of
expressways)
unpaved: 262,533 km (2002)
Waterways: 1 ,770 km (seagoing vessels use inland
seas) (2006)
Merchant marine:
total: 683 ships (1000 GRT or over) 10,468,077 GRT/
12,050,990 DWT
by type: barge carrier 5, bulk carrier 127, cargo 30,
chemical tanker 21 , container 12, liquefied gas 53,
passenger 14, passenger/cargo 154, petroleum
tanker 157, refrigerated cargo 4, roll on/roll off 50,
vehicle carrier 56
registered in other countries: 2,351 (Australia 1 , The
Bahamas 51 , Belize 5, Burma 4, Cambodia 2, China
2, Cyprus 1 7, French Southern and Antarctic Lands 4,
Honduras 4, Hong Kong 64, Indonesia 4, Isle of Man
4, Liberia 1 00, Malaysia 1 , Malta 1 , Marshall Islands 5,
Norway 1, Panama 1,921, Philippines 25, Portugal 9,
Singapore 93, Sweden 2, Thailand 4, Vanuatu 26,
unknown 1) (2005)
Ports and terminals: Chiba, Kawasaki, Kiire,
Kisarazu, Kobe, Mizushima, Nagoya, Osaka, Tokyo,
Yohohama
290
Japan (continued)','ee9f3de01a132596507ea7c9bbf5b9a4ec96b7b78583a3c6255cf796e1fe3bba','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a22b4952895adc50c9d60229da5230d8c0f09880d252e3ca807aaba77346076',2007,'US','United States','transportation',770,'Airports: 1 (2005)
Airports - with paved runways:
total: 1
1.524 to 2,437 m: 1(2005)
Ports and terminals: Gorey, Saint Aubin, Saint
Helier
Airports: 14,893(2005)
Airports • with paved runways:
total: 5,120
over 3,047 m: 191
2,438 to 3,047m: 223 •
1,524 to 2,437 m: 1,402
914 to 1,523 m: 2,355
under 914 m: 949 (2005)
Airports - with unpaved runways:
total: 9,773
over 3,047 m: )
2,438 to 3,047 m: 7
1,524 to 2,437 m:156
914 to 1,523 m: 1,736
under 914 m: 7,873 (2005)
Heliports: 153(2005)
Pipelines: petroleum products 244,620 km; natural
gas 548,665 km (2003)
Railways:
total: 227,736 km
standard gauge: 227,736 km 1.435-m gauge (2003)
Roadways:
total: 6,407,637 km
paved: 4,164,964 km (including 74,950 km of
expressways)
unpaved: 2,242,673 km (2004)
Waterways: 41 ,009 km (1 9,31 2 km used for
commerce)
note: Saint Lawrence Seaway of 3,769 km, including
the Saint Lawrence River of 3,058 km, shared with
Canada (2004)
Merchant marine:
total: 470 ships (1000 GRT or over) 10,698,467 GRT/
13,466,359 DWT
by type: barge carrier 7, bulk carrier 65, cargo 93,
chemical tanker 20, container 82, passenger 19,
passenger/cargo 56, petroleum tanker 76,
refrigerated cargo 3, roll on/roll off 28, specialized
tanker 1 , vehicle carrier 20
foreign-owned: 48 (Australia 2, Canada 6, Denmark
20, Greece 3, Malaysia 3, Netherlands 4, Norway 2,
Sweden 4, Taiwan 1, UK 2, US 1)
registered in other countries: 659 (Antigua and
Barbuda 7, Australia 3, The Bahamas 121, Belize 2,
Bermuda 26, Bolivia 1, Cambodia 6, Canada 2,
Cayman Islands 42, China 1, Comoros 2, Cyprus 6,
Finland 1, Gibraltar 2, Honduras 2, Hong Kong 19,
Ireland 1 , Isle of Man 3, Italy 1 5, North Korea 4, Liberia
77, Luxembourg 3, Malta 4, Marshall Islands 131,
Federated States of Micronesia 2, Netherlands 1 1 ,
Netherlands Antilles 1, Norway 13, Panama 97, Peru
1 , Philippines 4, Puerto Rico 2, Saint Vincent and the
Grenadines 21, Singapore 6, Spain 6, Sweden 1,
Tonga 1 , Trinidad and Tobago 1 , UK 6, US 1 , Vanuatu
1 , Venezuela 1 , Wallis and Futuna 1 , unknown 1 )
(2005)
Ports and terminals: Corpus Christi, Duluth,
Hampton Roads, Houston, Long Beach, Los Angeles,
New Orleans, New York, Philadelphia, Tampa, Texas
City
585
United States (continued)
note: 13 ports north of New Orleans (South Louisiana
Ports) on the Mississippi River handle 290,000,000
tons of cargo annually','5bc3b5ab9b8f9f111aca077aa8ce7ba45ec08040ac4497528e137d7f3ec71a44','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e50445f0bb8e967df674f3e4f760e6bfcc33dbbcc3ff18833c7cdf4812578d1',2007,'JO','Jordan','transportation',775,'Airports: 17(2005)
Airports - with paved runways:
tote/: 15
over 3.047 m: 7
2,438 to 3.047 m: 6
914 to 1.523 m:]
under 914 m: 1 (2005)
Airports - with unpaved runways:
total: 2
under 914 m: 2 (2005)
Heliports: 1 (2005)
Pipelines: gas 10 km; oil 743 km (2004)
Railways:
total: 505 km
narrow gauge: 505 km 1 .050-m gauge (2004)
Roadways:
total: 7,364 km
paved: 7,364 km (2003)
Merchant marine:
total: 26 ships (1000 GRT or over) 218,685 GRT/
218,795 DWT
by type: bulk carrier 2, cargo 9, container 2,
passenger/cargo 6, petroleum tanker 1,
roll on/roll off 6
foreign-owned: ]2 (UAE ]2)
registered in other countries: 14 (The Bahamas 2,
Panama 12) (2005)
Ports and terminals: Al Aqabah','163ed5d6a3dc6572b75619df54dcd04c859f5c683444631efa6fc026cc076d20','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44e28c1d67a4937a1ccad5f27d086dac274a794143b140e2622b545a534d02ff',2007,'KZ','Kazakhstan','transportation',778,'Mi
ii tar
y
Airports: 160(2005)
Airports • with paved runways:
total: 66
over 3,047 m: 9
2,438 to 3.047 m: 26
1.524 to 2,437 m: 17
914 to 1.523 m: 4
under 914 m: 10 (2005)
Airports - with unpaved runways:
total: 94
over 3.047 m: 6
2.438 to 3.047 m: 6
1.524 to 2.437 m:12
914 to 1.523 m: 12
under 914 m: 58 (2005)
298
Kazakhstan (continued)
Heliports: 4(2005)
Pipelines: condensate 18 km; gas 10,370 km; oil
10,158 km; refined products 1,187 km (2004)
Railways:
total: 13,700 km
broad gauge: 13,700 km 1.520-m gauge (3,700 km
electrified) (2004)
Roadways:
total: 354,171 km
paved: 247,347 km
unpaved: 106,824 km (2003)
Waterways: 4,000 km (on the Ertis (Irtysh) (80%)
and Syr Darya (Syrdariya) rivers) (2005)
Merchant marine:
total: 5 ships (1000 GRT or over) 19,949 GRT/31 ,1 15
DWT
by type: cargo 2, petroleum tanker 2, refrigerated
cargo 1
foreign-owned: 2 (Oman 2)
registered in other countries: 1 (Marshall Islands 1 )
(2005)
Ports and terminals: Aqtau (Shevchenko), Atyrau
(Gur''yev), Oskemen (Ust-Kamenogorsk), Pavlodar,
Semey (Semipalatinsk)
Airports: 224(2005)
Airports - with paved runways:
tote/: 15
over 3,047 m: 4
2,438 to 3,047 m: 1
1,524 to 2,437 m: 4
914 to 1,523 m: 5
under 914 m:1 (2005)
Airports - with unpaved runways:
total: 209
1,524 to 2,437 m.H
914 to 1,523 m: 114
under 914 m: 84 (2005)
Pipelines: refined products 752 km (2004)
Railways:
total: 2,778 km
narrow gauge: 2,778 km 1.000-m gauge (2004)
Roadways:
total: 63,942 km
paved: 7,737 km
unpaved: 56,205 km (2000)
Waterways: part of Lake Victoria system is within
boundaries of Kenya (2003)
Merchant marine:
total: 3 ships (1000 GRT or over) 6,049 GRT/7,082
DWT
by type: cargo 2, petroleum tanker 1
registered in other countries: 6 (The Bahamas 1 ,
Comoros 1 , Saint Vincent and the Grenadines 3,
unknown 1 ) (2005)
Ports and terminals: Mombasa','e1493b9dbbb91b9e7704b64110e10debb2ac2f0c7dd134e43b2fdb122dbdd1d3','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6884a25221077eb3ef4a545ea9997e191177716b2e4b9011eb354b109ef333e1',2007,'KI','Kiribati','transportation',794,'Airports: 19(2005)
Airports - with paved runways:
total: 3
1,524 to 2,437 m: 3 (2005)
Airports - with unpaved runways:
tofa/:16
1,524 to 2,437 m: 1
914 to 1,523 m: 1 1
under 914 m: 4 (2005)
Roadways:
tote/:670km(1999)
Waterways: 5 km (small network of canals in Line
Islands) (2003)
Merchant marine:
total: 2 ships (1000 GRT or over) 2,749 GRT/3,91 1
DWT
by type: cargo 1 , passenger/cargo 1
foreign-owned: 1 (Syria 1) (2005)
Ports and terminals: Betio
Airports: 79(2005)
Airports - with paved runways:
total: 35
over 3,047 m: 2
2.438 to 3,047 m: 22
1,524 to 2,437 m: 7
914 to 1,523 m:)
under 914 m: 3 (2005)
Airports • with unpaved runways:
total: 44
2,438 to 3,047 m: 1
1,524 to 2,437 m: 21
914 to 1,523 m: 14
under 914 m: 8 (2005)
Heliports: 20(2005)
Pipelines: oil 154 km (2004)
Railways:
tofa/:5,214km
standard gauge: 5,214 km 1 .435-m gauge (3,500 km
electrified) (2004)
Roadways:
tote/: 31,200 km
paved: 1,997 km
unpaved: 29,203 km (1999 est.)
Waterways: 2.250 km (most navigable only by small
craft) (2006)
Merchant marine:
total: 284 ships (1 000 GRT or over) 1 ,1 17,435 GRT/
1,563,258 DWT
by type: barge carrier 1 , bulk carrier 14, cargo 222,
chemical tanker 2, container 3, livestock carrier 4,
passenger/cargo 6. petroleum tanker 20, refrigerated
cargo 5, roll on/roll off 6, vehicle carrier 1
foreign-owned: 84 (British Virgin Islands 1 . Denmark 1 ,
Germany 1 , Greece 1 . India 1 , Italy 1 , South Korea 1 ,
Lebanon 14, Lithuania 1 , Marshall Islands 2, Pakistan 3,
Romania 1 6, Russia 2, Saint Vincent and the Grenadines
1 . Syria 21 , Turkey 4, Ukraine 1 , UAE 7, US 4, Yemen 1 )
registered in other countries: 3 (Mongolia 3) (2005)
Ports and terminals: Ch''ongjin. Haeju. Hungnam
(Hamhung), Kimch''aek, Kosong, Najin, Namp''o, Sinuiju,
Songnim. Sonbong (formerly Unggi), Ungsang, Wonsan
Airports: 108(2005)
Airports - with paved runways:
total: 70
over 3, 047 m: 3
2,438 to 3,047 m: 21
1,524 to 2, 437 m: 14
914 to 1,523 m: 11
under 914 m:21 (2005)
Airports - with unpaved runways:
total: 38
914 to 1,523 m: 3
under 914 m: 35 (2005)
Heliports: 537(2005)
Pipelines: gas 1 ,433 km; refined products 827 km
(2004)
Railways:
total: 3,472 km
standard gauge: 3,472 km 1 .435-m gauge (1 ,342 km
electrified) (2004)
Roadways:
total: 97,252 km
paired: 74,641 km (including 2,778 km of
expressways)
unpaved: 22,61 1 km (2003)
Waterways: 1 ,608 km (most navigable only by small
craft) (2006)
Merchant marine:
total: 650 ships (1000 GRT or over) 7,992,664 GRT/
12,730,954 DWT
by type: bulk carrier 151 , cargo 202, chemical tanker
87, container 79, liquefied gas 20, passenger 5,
passenger/cargo 22, petroleum tanker 53,
refrigerated cargo 18, roll on/roll off 7, specialized
tanker 3, vehicle carrier 3
foreign-owned: 15 (France 12, Singapore 1, UK 2)
registered in other countries: 362 (Belize 5,
Cambodia 18, China 3, Cyprus 1, Georgia 1,
Honduras 6, Hong Kong 12, Indonesia 1 , North Korea
1, Malta 5, Mongolia 1, Panama 285, Singapore 17,
Thailand 1 , Turkey 1 , unknown 4) (2005)
Ports and terminals: Inch''on, Masan, P''ohang,
Pusan, Ulsan','ae4b7938166ca403c3e41d7d962dba77b74897fa14cae83ae06a51cd5c2465ff','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e9ddfd62acfa493781cfb62f8a75798579f3c485d9cee8940903b8f747e6973',2007,'LB','Lebanon','transportation',810,'Airports: 7(2005)
Airports - with paved runways:
total: 5
over 3,047 m: ]
2,438 to 3,047 m: 2
under 914 m: 2 (2005)
Airports - with unpaved runways:
total: 2
914 to 1,523 m: 2 (2005)
Pipelines: oil 209 km (2004)
321
Lebanon (continued)
Railways:
total: 401 km
standard gauge: 31 9 km 1 .435-m
narrow gauge: 82 km 1 .050-m
note: rail system became unusable because of
damage during the civil war in the 1980s; short
sections are operable (2004)
Roadways:
total: 7,300 km
paved: 6,198 km
unpaved: 1,102 km (1999)
Merchant marine:
total: 42 ships (1000 GRT or over) 161,231 GRT7
187,140 DWT
by type: bulk carrier 4, cargo 20, livestock carrier 10,
refrigerated cargo 1 , roll on/roll off 3, vehicle carrier 4
foreign-owned: 2 (Greece 2)
registered in other countries: 53 (Antigua and
Barbuda 1 , Barbados 2, Cambodia 1 , Comoros 3,
Egypt 2, Georgia 5, Honduras 1, North Korea 14,
Liberia 1 , Malta 8, Mongolia 1 , Panama 1 , Portugal 1 ,
Saint Vincent and the Grenadines 4, Syria 7, unknown
1 ) (2005)
Ports and terminals: Beirut, Chekka, Jounie, Tripoli','f9578be4770b51aa907554e1cc603557c2e75887d6e4992fd353222b1649abef','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d07a321cd0acbf910b0109e491a853cac690daa1e8703dd896e2f44dc058094e',2007,'ZA','South Africa','transportation',818,'Airports: 28(2005)
Airports - with paved runways:
total: 3
over 3,047 m: 1
914 to 1,523 m:\\
under 914 m:1 (2005)
Airports - with unpaved runways:
total: 25
914 to 1,523 m: 4
under 914 m:21 (2005)
Roadways:
total: 5,940 km
paved: 1 ,087 km
unpaved: 4,853 km (1999)','8cfa96c337ae6f788e5832eb7978b6c5c42e712f2b272de3e813fa57b2bef049','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f4cb74f4883d5eb11b8e0fd7a0c5017046ba3ff9f27047e8ac79300abb34df5',2007,'LR','Liberia','transportation',828,'Airports: 53(2005)
Airports - with paved runways:
total: 2
over 3,047 mA
1,524 to 2,437 m:) (2005)
Airports - with unpaved runways:
total: 51
1,524 to 2,437 m: 5
914 to 1,523 m: 8
under 914 m: 38 (2005)
Railways:
total: 490 km
standard gauge: 345 km 1 ,435-m gauge
narrow gauge: 145 km 1.067-m gauge
note: none of the railways are in operation because of
the civil war (2004)
Roadways:
total: 10,600 km
paved: 657 km
unpaved: 9,943 km (1999)
Merchant marine:
total: 1 ,533 ships (1 000 GRT or over) 56,681 ,509
GRT/88,825,842 DWT
by type: barge carrier 9, bulk carrier 290, cargo 82,
chemical tanker 1 89, combination ore/oil 1 4, container
409, liquefied gas 75, passenger 3, passenger/cargo
1 , petroleum tanker 355, refrigerated cargo 55, roll on/
roll off 6, specialized tanker 1 1 , vehicle carrier 34
foreign-owned: 1 ,460 (Argentina 8, Australia 2,
Austria 14, The Bahamas 2, Bermuda 1, Brazil 4,
Canada 4, Chile 1 , China 35, Croatia 6, Cyprus 6,
Denmark 5, France 3, Germany 510, Greece 229,
Hong Kong 40, India 4, Indonesia 1, Isle of Man 5,
Israel 5, Italy 20, Japan 100, Kuwait 1, Latvia 17,
Lebanon 1 , Monaco 1 1 , Netherlands 13, Norway 46,
Poland 14, Russia 65, Saudi Arabia 24, Singapore 16,
Slovenia 2, Sweden 8, Switzerland 7, Taiwan 68,
Thailand 1 , Turkey 2, Ukraine 1 5, UAE 1 5, UK 49, US
77, Uruguay 3) (2005)
Ports and terminals: Buchanan, Monrovia','1502c4f791d81918e4fd69310f37f340ec005b0d5f5c2fb97b94ceb6ff65a860','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffa28ee1e9d640c5ee0aead0076181d3fea8cc194a20c957dd7861602ed04084',2007,'LI','Liechtenstein','transportation',838,'Airports: none (2005)
Pipelines: gas 20 km (2004)
Waterways: 28 km (2005)
Ports and terminals: none
Mili
ta r
y
Military - note:','67f585d443ec1ce110ca591ec138975d8e3caf96fe2627d23fd987d73114684a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fd53cb2378f0ad08d14f3f608fcf231ae2850b87d813384a9e95874a19cf4dc',2007,'CH','Switzerland','transportation',839,'defense
is the
responsibility of
T r a n s n a t i o
n a
I Issues
Disputes - international: in February 2005, the ICJ
refused to rule on the restitution of Liechtenstein''s
land and property assets in the Czech Republic
confiscated in 1 945 as German property
Illicit drugs: has strengthened money-laundering
controls, but money laundering remains a concern
due to Liechtenstein''s sophisticated offshore financial
services sector
331','10b1b85e4392fc16b472fb69b4d95839a85e650246555bb473f336216e5d9107','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e4d25462a379626d13f2d41a96b2f7f7303889f8b162fdfc9e112d635a3678e',2007,'LT','Lithuania','transportation',846,'Airports: 95(2005)
Airports - with paved runways:
total: 33
over 3.047 m: 4
2.438 to 3.047 m: 1
1.524 to 2.437 m: 7
914 to 1.523 m: 2
under 914 m: 19 (2005)
Airports • with unpaved runways:
total: 62
7,524 to 2,437 m: 2
914 to 1.523 m: 4
under 974 m: 56 (2005)
Pipelines: gas 1 ,696 km; oil 331 km; refined
products 109 km (2004)
Railways:
total: 1,998 km
broad gauge: 1 ,807 km 1 ,524-m gauge (122 km
electrified)
standard gauge: 22 km 1.435-m gauge
narrow gauge: 1 69 km 0.750-m gauge (2004)
Roadways:
total: 78,893 km
paved: 21 ,617 km (including 417 km of expressways)
unpaved: 57,276 km (2003)
Waterways: 600 km (2005)
Merchant marine:
total: 48 ships (1000 GRT or over) 338,565 GRT7
339,238 DWT
by type: bulk carrier 8, cargo 18, chemical tanker 1,
container 1 , passenger/cargo 6, petroleum tanker 1 ,
refrigerated cargo 12, roll on/roll off 1
foreign-owned: 1 1 (Denmark 11)
registered in other countries: 18 (Antigua and
Barbuda 1 , North Korea 1 , Norway 1 , Panama 6, Saint
Vincent and the Grenadines 5, unknown 4) (2005)
Ports and terminals: Klaipeda','420fa1e0b117ee97e379eab016be19fefa2f9bc77d962e0d8b8308dca9f5a696','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38a49a95fdb353474745040411afeda6a4b0792c2be476c859c16caf91259696',2007,'MW','Malawi','transportation',859,'Airports: 42(2005)
Airports - with paved runways:
total: 6
over 3,047 m;1
7,524 to 2,437 m: 1
914 to 1,523 m: 4 (2005)
Airports - with unpaved runways:
total: 36
1,524 to 2,437 m: 1
914 to 1,523 m. 15
under 914 m: 20 (2005)
Railways:
total: 797 km
narrow gauge: 797 km 1 .067-m gauge (2004)
Roadways:
total: 28,400 km
paved: 5,254 km
unpaved: 23,146 km (1999)
Waterways: 700 km (on Lake Nyasa (Lake Malawi)
and Shire River) (2006)
Ports and terminals: Chipoka, Monkey Bay, Nkhata
Bay, Nkhotakota, Chilumba','fd0a4161dc184ad9ea7dc5059d1cd298c045a035d04197053769254ffa782415','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4caaf57d8f31417d158e8bc9902db44d7ca3db5386a3aa34f18515b1ab5cb6c5',2007,'MV','Maldives','transportation',869,'Airports: 5(2005)
Airports - with paved runways:
total: 2
over 3,047 m:1
2,438 to 3,047 m: 1 (2005)
Airports - with unpaved runways:
total: 3
914 to 1,523 m: 3 (2005)
Merchant marine:
total: 16 ships (1000 GRT or over) 66,804 GRT/
84,615 DWT
by type: cargo 12, passenger/cargo 1, petroleum
tanker 2, refrigerated cargo 1
registered in other countries: 2 (Panama 2) (2005)
Ports and terminals: Male
Airports: 28(2005)
Airports - with paved runways:
total: 9
2,438 to 3,047 m: 4
1524 to 2,437 m: 4
914 to 1,523 mA (2005)
Airports - with unpaved runways:
tote/: 19
2.438 to 3,047 m:\\
1,524 to 2,437 m: 5
914 to 1,523 m: 5
under 914 m: 8 (2005)
Railways:
total: 729 km
narrow gauge: 729 km 1 .000-m gauge (2004)
Roadways:
total: 15,100 km
paved: 1,827 km
unpaved: 13,273 km (1999)
Waterways: 1,815 km (2005)
Ports and terminals: Koulikoro','809b6174f4687167905834dabff668bfa49e9169e428442e939e19d8aca196e0','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('497b506b3a81e2a676a3591a6ad3bcc3f258f82e60ffea16c2735ea6d5912bb8',2007,'MT','Malta','transportation',879,'Airports: 1 (2005)
Airports - with paved runways:
total: 1
over 3,047 m: 1 (2005)
Roadways:
total: 2,254 km
paved: 1 ,973 km
unpaved: 281 km (2003)
Merchant marine:
total: 1,148 ships (1000 GRT or over) 22,791,072
GRT/36,951,514DWT
by type: barge carrier 2, bulk carrier 420, cargo 31 1 ,
chemical tanker 93, combination ore/oil 3, container
57, liquefied gas 8, livestock carrier 1, passenger 9,
passenger/cargo 13. petroleum tanker 144,
refrigerated cargo 40, roll on/roll off 32, specialized
tanker 1, vehicle carrier 14
foreign-owned: 1 ,1 05 (Austria 1 , Azerbaijan 2,
Bangladesh 3, Belgium 11, Bulgaria 14, Canada 10,
China 15, Croatia 11, Cyprus 5, Czech Republic 1,
Denmark 3, Estonia 4, France 8, Germany 59, Greece
515, Hong Kong 2, Iceland 4, India 1 , Indonesia 1 , Iran
9, Israel 27, Italy 25, Japan 1 , South Korea 5, Latvia
36, Lebanon 8, Monaco 4, Netherlands 5. Norway 43,
Pakistan 1 , Poland 27, Portugal 4, Romania 3, Russia
60, Slovenia 3, Spain 1, Sweden 3. Switzerland 21.
Syria 6, Taiwan 1 , Turkey 101 , Ukraine 26, UAE 5, UK
6, US 4)
registered in other countries: 9 (Panama 2. Portugal
1, Russia 5, unknown 1) (2005)
Ports and terminals: Marsaxlokk, Valletta','76bea04fa69224fa4e02797c72e4648c73b2eac23740f465bb035fd2b1ee17f0','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4bd60a9d155d5e6baa4e2171347c846bda8dc4404b6b1256255be148e65c374e',2007,'MH','Marshall Islands','transportation',888,'Airports: 15(2005)
Airports - with paved runways:
total: 4
1 ,524 to 2,437 m: 3
914 to 1,523 m: 1 (2005)
Airports • with unpaved runways:
total: 1 1
914 to 1,523 m: 10
under 914 m;1 (2005)
Roadways:
total: 64.5 km
paved: 64.5 km
note: paved roads on major islands (Majuro,
Kwajalein), otherwise stone-, coral-, or
laterite-surfaced roads and tracks (2002)
Merchant marine:
total: 706 ships (1000 GRT or over) 28,268,51 1 GRT/
47,217,632 DWT
by type: barge carrier 3, bulk carrier 139, cargo 46.
chemical tanker 1 1 0, combination ore/oil 1 0, container
116, liquefied gas 20, passenger 7, petroleum tanker
241 , refrigerated cargo 3, roll on/roll off 7, vehicle
carrier 4
foreign-owned: 632 (Australia 2. Bermuda 4, Canada
6, Chile 1 , Croatia 2, Cyprus 7, Denmark 1 , Germany
157, Greece 179, Hong Kong 8, India 1 . Italy 1 , Japan
5, Kazakhstan 1 , Latvia 6, Monaco 8, Netherlands 5,
NZ 1, Norway 35, Portugal 2, Russia 1, Saudi Arabia
1, Singapore 5, Slovenia 2, Spain 2, Sweden 1,
Switzerland 1 1 , Turkey 24, UAE 2, UK 20, US 1 31 )
registered in other countries: 4 (North Korea 2,
Mongolia 1, Panama 1) (2005)
Ports and terminals: Majuro','035d7dfa2c18d3023ea441f085c6859249d344b2a850a7feb7535d53762079cb','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('473d7bc3f3e88f843658ac19dc34362a32ec0cffaf96a9194727f5a27287f51a',2007,'MR','Mauritania','transportation',899,'Airports: 24(2005)
Airports - with paved runways:
total: 8
2,438 to 3,047 m: 3
1.524 to 2,437 m: 5 (2005)
Airports - with unpaved runways:
total: 16
1,524 to 2,437 m: 9
914 to 1,523 m: 6
under 914 m:1 (2005)
Railways: 717 km
standard gauge: 717 km 1 .435-m gauge (2004)
Roadways:
total: 7,660 km
paved: 866 km
unpaved: 6,794 km (1999)
Ports and terminals: Nouadhibou, Nouakchott
Airports: 11 (2005)
Airports - with paved runways:
total: 3
2,438 to 3,047m: 3 (2005)
Airports - with unpaved runways:
total: 8
1.524 to 2.437 m:)
914 to 1.523 m: 4
under 914 m: 3 (2005)
Ports and terminals: Ad Dakhla. Cabo Bojador.
Laayoune (El Aaiun)
610
Western Sahara (continued)','856bc3ecb536f6a2eb2517cf0f2108b392fca2c1136bbfff2d3fdb58d91ad8cd','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ddf93d9b6c3b3004540445cba1e300592fb0a04537ff7d5025195df45bafa77',2007,'MU','Mauritius','transportation',908,'Airports: 6(2005)
Airports - with paved runways:
total: 2
over 3,047 m: 1
914 to 1,523 m:1 (2005)
Airports - with unpaved runways:
total: 4
914 to 1.523 m: 3
under 914 m:1 (2005)
Roadways:
total: 2,254 km
paved: 2,254 km (including 75 km of expressways)
(2003)
Merchant marine:
total: 8 ships (1000 GRT or over) 26,308 GRT/28,488
DWT
by type: bulk carrier 4, passenger/cargo 2,
refrigerated cargo 2
foreign-owned: 6 (India 4, Switzerland 2) (2005)
Ports and terminals: Port Louis','e42d9fc2b8d3351462b3c8dd7c0dc37aeda67e77d92e67a73fd0ee9be99d63aa','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48dec6577542db2ebe8a8de6844e750dd0ff61a71677966217343d695e70e81c',2007,'CU','Cuba','transportation',913,'Airports: 1,832(2005)
Airports - with paved runways:
total: 227
over 3, 04 7 m: 12
2,438 to 3,047 m: 28
1,524 to 2,437 m: 81
914 to 1,523 m: 77
under 914 m: 29 (2005)
Airports • with unpaved runways:
total: 1,605
over 3,047 m: 1
2,438 to 3,047 m: 1
1,524 to 2,437 m: 69
914 to 1,523 m: 457
under 914 m: 1,077 (2005)
Heliports: 1 (2005)
Pipelines: crude oil 28,200 km; petroleum products
10,150 km; natural gas 13,254 km; petrochemical
1,400 km (2003)
Railways:
total: 17,634 km
standard gauge: 17 ,634 km 1.435-m gauge (2004)
Roadways:
total: 349,038 km
paved: 1 16,928 km (including 6,979 km of
expressways)
unpaved:232,110km(2003)
Waterways: 2,900 km (navigable rivers and coastal
canals) (2005)
Merchant marine:
total: 58 ships (1000 GRT or over) 767,807 GRT/
1,151,898DWT
by type: bulk carrier 2, cargo 6, chemical tanker 7,
liquefied gas 4, passenger/cargo 9, petroleum tanker
26, roll on/roll off 4
foreign-owned: 5 (Denmark 2, France 1 , Norway 1 ,
UAE 1)
registered in other countries: 12 (Belize 1, Honduras
1, Panama 5, Portugal 1, Spain 3, Venezuela 1)
(2005)
Ports and terminals: Altamira, Manzanillo, Morro
Redondo, Salina Cruz, Tampico, Topolobampo,
Veracruz','91cf140a57e187fcf419ee6d6927a20ee1613778d79cea1a44a717a4e1b126e0','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02e8c636b6fecd0ba245dde811c28ae77e788f5097ed800a280cb750b9008d17',2007,'MC','Monaco','transportation',924,'Airports: none; note - linked to the airport at Nice,
France by helicopter service (2005)
Heliports: 1 (shuttle service between the
international airport at Nice, France, and Monaco''s
heliport at Fontvieille) (2005)
Roadways:
total: 50 km
paved:50km(1999)
Merchant marine:
registered in other countries: 81 (The Bahamas 17,
Barbados 1 , Georgia 12, Hong Kong 1 , Isle of Man 1 ,
Italy 6, Liberia 1 1 , Malta 4, Marshall Islands 8, Norway
3, Panama 9, Saint Kitts and Nevis 1 , Saint Vincent
and the Grenadines 3, Switzerland 2, Turkey 1,
unknown 1) (2005)
Ports and terminals: Monaco','71d2de5f93f6ebe8704d470ada589d2c624ef2ce289e7bb79838fb8dc3e897d5','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa0a2c8caf6f7686cb7818c50a0e862d9fd46c50ab1af16cc429eaad12851144',2007,'MA','Morocco','transportation',928,'Milit
a r y
Military branches: Mongolian People''s Army
(MPA), Mongolian People''s Air Force (MPAF); there is
no navy (2005)
Military service age and obligation: 1 8-25 years of
age for compulsory military service; conscript service
obligation - 1 2 months in land or air defense forces or
police; a small portion of Mongolian land forces (2.5
percent) is comprised of contract soldiers (2004)
Manpower available for military service:
males age 18-49: 736,182 (2005 est.)
Manpower fit for military service:
males age 18-49: 570,435 (2005 est.)
Manpower reaching military service age
annually:
males: 34,674 (2005 est.)
Military expenditures - dollar figure: $23.1 million
(FY02)
Military expenditures - percent of GDP: 2.2%
(FY02)','a7ef9ab9856a0b22639a404de12643cd774d045be29e18764d605682b110619a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10af859990f8e5d9488822d2476612e4ae6da446da53832b2faafcf13f5e07b8',2007,'AO','Angola','transportation',939,'Airports: 136(2005)
Airports - with paved runways:
total: 21
over 3,047 m: 3
2,438 to 3,047 m: 2
1,524 to 2,437m: 13
914 to 1,523 m: 3 (2005)
Airports - with unpaved runways:
total: 115
2,438 to 3,047 m: 2
1,524 to 2,437 m: 22
914 to 1,523 m: 71
under 914 m: 20 (2005)
Railways:
total: 2,382 km
narrow gauge: 2,382 km 1 .067-m gauge (2004)
Roadways:
total: 42,237 km
paved: 5,406 km
unpaved: 36,831 km (2002)
Merchant marine:
total: 1 ships (1000 GRT or over) 2,265 GRT/3,605
DWT
by type: cargo 1 (2005)
Ports and terminals: Luderitz, Walvis Bay','73412b8154f955391a4456b726aac01b0a95d1e545887a64c27d3786bd871447','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b52dfaed30f36dfd8c46f524ca7ea323dc4be45d18877f64d770fe6f262bae85',2007,'NR','Nauru','transportation',947,'Unemployment rate: 90% (2004 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): -3.6% (1993)
390
Nauru (continued)
Budget:
revenues: $13.5 million
expenditures: $13.5 million (2005)
Agriculture - products: coconuts
Industries: phosphate mining, offshore banking,
coconut products
Industrial production growth rate: NA%
Electricity - production: 23 million kWh (2003)
Electricity - consumption: 21 .39 million kWh
(2003)
Electricity - exports: 0 kWh (2003)
Electricity - imports: 0 kWh (2003)
Oil - production: 0 bbl/day (2003 est.)
Oil - consumption: 1 ,000 bbl/day (2003 est.)
Oil -exports: NA bbl/day
Oil -imports: NA bbl/day
Natural gas - production: 0 cu m (2003 est.)
Natural gas - consumption: 0 cu m (2003 est.)
Exports: $64,000 f.o.b. (2005 est.)
Exports - commodities: phosphates
Exports - partners: South Africa 43.4%, Germany
20.7%, India 1 1 .8%, Japan 7.2%, Poland 4% (2004)
Imports: $20 million c.i.f. (2004 est.)
Imports - commodities: food, fuel, manufactures,
building materials, machinery
Imports - partners: Australia 65.6%, Indonesia
5.4%, Germany 5.3%, UK 4.4% (2004)
Debt - external: $33.3 million (2002)
Economic aid - recipient: mostly from Australia
Currency (code): Australian dollar (AUD)
Exchange rates: Australian dollars per US dollar -
1.3095 (2005), 1.3598 (2004), 1.5419 (2003), 1.8406
(2002), 1.9334(2001)
Fiscal year: 1 July - 30 June
Airports: 1 (2005)
Airports - with paved runways:
total: 1
1,524 to 2,437 m:1 (2005)
Ports and terminals: Nauru','6f5840e478a0bf69b6f3d2885249f8a1b6d364ec265b40d439658bcb09486e90','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16c0d8f803a201f8678de570e26b2a5432790f1a770b3a52bd516f459c376480',2007,'NP','Nepal','transportation',952,'Ports and terminals: none; offshore anchorage only
Mtlitar
Military - note: defense is the responsibility of the
US
Airports: 48(2005)
Airports - with paved runways:
total: 10
over 3,047 m: 1
914 to 1.523 m: 7
under 914 m: 2 (2005)
Airports - with unpaved runways:
total: 38
1,524 to 2.437 m: 1
914 to 1.523 m: 8
under 914 m: 29 (2005)
Railways:
total: 59 km
narrow gauge: 59 km 0.762-m gauge (2004)
Roadways:
total: 15,905 km
paved: 8,573 km
unpaved: 7,332 km (2003)
Airports: 27(2005)
Airports - with paved runways:
total: 20
over 3,047 m: 2
2,438 to 3,047 m: 9
1,524 to 2.437 m: 3
914 to 1,523 m: 4
under 914 m: 2 (2005)
Airports - with unpaved runways:
total: 7
914 to 1,523 m: 3
under 914 m: 4 (2005)
Heliports: 1 (2005)
Pipelines: condensate 325 km; gas 6,998 km; oil
590 km; refined products 716 km (2004)
Railways:
total: 2,808 km
standard gauge: 2,808 km 1.435-m gauge (2,061 km
electrified) (2004)
Roadways:
total: 116,500 km
paved: 104,850 km
unpaved: 11 ,650 km (1999)
Waterways: 5,046 km (navigable for ships of 50
tons) (2004)
Merchant marine:
total: 563 ships (1000 GRT or over) 4,925,489 GRT/
5,052,931 DWT
by type: bulk carrier 1 1 , cargo 366, chemical tanker
31, container 54, liquefied gas 12, passenger 12,
passenger/cargo 14, petroleum tanker 14,
refrigerated cargo 30, roll on/roll off 16, specialized
tanker 3
foreign-owned: 152 (Australia 1 , Belgium 2, Denmark
9, Finland 9, Germany 58, Ireland 13, Netherlands
Antilles 1 , Norway 6, Sweden 21 , UK 21 , US 1 1 )
registered in other countries: 222 (Antigua and
Barbuda 10, Australia 2, Austria 2, The Bahamas 25,
Bermuda 1 , Canada 1 , Cyprus 1 8, Isle of Man 2,
Liberia 13, Luxembourg 3, Malta 5, Marshall Islands 5,
Netherlands Antilles 69, Norway 3, Panama 26,
Philippines 20, Portugal 1, Saint Vincent and the
Grenadines 7, Singapore 1 , Turkey 1 , UK 2, US 4,
unknown 1) (2005)
Ports and terminals: Amsterdam, Groningen,
Ijmuiden, Rotterdam, Terneuzen, Vlissingen,
Zaanstad','ab2132e0e7d2e8ad8df1fd00fb571d2bb933d55ceabd6c60d2aee486be1a82ee','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5072185b7a2693ce33cf7f2bc365bdf7455ae590fee45cc1d2c2ca29ba4557b5',2007,'NE','Niger','transportation',974,'Airports: 27(2005)
Airports - with paved runways:
total: 9
2,438 to 3,047 m: 3
1,524 to 2,437 m: 5
under 914 m:1 (2005)
Airports - with unpaved runways:
total: 18
1,524 to 2,437 m: 2
914 to 1,523 m:U
under 914 m: 2 (2005)
Roadways:
total: 10,100 km
paired: 798 km
unpaved: 9,302 km (1999)
Waterways: 300 km (the Niger, the only major river,
is navigable to Gaya between September and March)
(2005)
Ports and terminals: none
Airports: 70(2005)
Airports - with paved runways:
total: 36
over 3,047 m: 6
2,438 to 3,047 m: 12
1,524 to 2,437 m: 9
914 to 1,523 m: 6
under 914 m: 3 (2005)
Airports - with unpaved runways:
total: 34
1,524 to 2,437 m: 3
914 to 1,523 m:W
under 914 m: 18 (2005)
Heliports: 1 (2005)
411
Nigeria (continued)
Pipelines: condensate 105 km; gas 1,896 km; oil
3.638 km; refined products 3,626 km (2004)
Railways:
total: 3,557 km
narrow gauge: 3,505 km 1 .067-m gauge
standard gauge: 52 km 1 .435-m gauge (2004)
Roadways:
total: 194,394 km
paved: 60.068 km
unpaved: 134,326 km (1999)
Waterways: 8,600 km (Niger and Benue rivers and
smaller rivers and creeks) (2005)
Merchant marine:
total: 49 ships (1000 GRT or over) 263,452 GRT/
452,012 DWT
by type: barge carrier 1 , cargo 5, chemical tanker 7,
liquefied gas 1 , passenger/cargo 1 , petroleum tanker
33, specialized tanker 1
foreign-owned: 3 (Norway 1 , Pakistan 1 , Singapore 1)
registered in other countries: 26 (The Bahamas 2,
Bermuda 10, Cambodia 2, Comoros 2, Panama 6,
Seychelles 1 , unknown 3) (2005)
Ports and terminals: Bonny Inshore Terminal,
Calabar, Lagos, Port Harcourt','6f90a12c6528e61af68bdf197b4361e65befdccc6a78e70714242bac094ceba1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7685f384ac42cf0f9239c5576ff8d2a32b31af3497dae942432c9d042dd8152a',2007,'NU','Niue','transportation',989,'Airports: 1 (2005)
Airports - with paved runways:
total: 1
1,524 to 2,437 m:1 (2005)
Roadways:
total: 234 km
paved: 86 km
unpaved: 148 km (2001)
Ports and terminals: none; offshore anchorage only','310fd0bb07b4979d7603c316e0c89aaad0cf7ee51ffb75632ee8f76102760753','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bea4626db0503c9b65a2b5ccf9cb0c0919b49fca2acf619f09f10f10a0de4e3a',2007,'NF','Norfolk Island','transportation',997,'Airports: 1 (2005)
Airports - with paved runways:
total: 1
1,524 to 2,437 m: 1 (2005)
Roadways:
total: 80 km
paved: 53 km
unpaved: 27 km (2002)
Ports and terminals: none; loading jetties at
Kingston and Cascade','16fba4fc93d5885404c6bbfb89d3497b0591e0f81517abf23e95818e36da64e1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('34b534c074fc623e2422bbdf5938a3537567634751e9bb3fa83f08f91a5dc726',2007,'MP','Northern Mariana Islands','transportation',1001,'Airports: 5(2005)
Airports - with paved runways:
tofa/:3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 1 (2005)
Airports - with unpaved runways:
fora/: 2
2,438 to 3,047 m: 1
under 914 m:1 (2005)
Heliports: 1 (2005)
Roadways:
total: 536 km (2004)
Ports and terminals: Saipan, Tinian
Airports: 1 (2005)
Airports - with paved runways:
total: 1
2,438 to 3,047 m: 1 (2005)
Ports and terminals: none; two offshore
anchorages for large ships
Transportation - note: there are no commercial or
civilian flights to and from Wake Island, except in
direct support of island missions; emergency landing
is available','46233976fa0189e173b91acc68d93567d8d11a08b5aa41803a193375a3f1b5f3','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7e4a16d7ae1693cc4aa80f82273b296af6bad57f742f81f388c50839cdd6aa5',2007,'OM','Oman','transportation',1010,'Airports: 137(2005)
Airports - with paved runways:
total: 6
over 3,047 m: 4
2.438 to 3.047 m: 1
914 to 1.523 m:1 (2005)
Airports • with unpaved runways:
fofa/:131
over 3,047 m: 2
2.438 to 3,047m: 7
1.524 to 2,437 m: 52
914 to 1,523 m: 35
under 914 m: 35 (2005)
Heliports: 1 (2005)
Pipelines: gas 3,754 km; oil 3,212 km (2004)
Roadways:
total: 34,965 km
paved: 9,673 km (including 550 km of expressways)
unpaved: 25,292 km (2001)
Merchant marine:
total: 1 ships (1000 GRT or over) 10,797 GRT/5,040
DWT
by type: passenger 1
registered in other countries: 2 (Kazakhstan 2) (2005)
Ports and terminals: Mina Qabus, Salalah
422
Oman (continued)
Ports and terminals: Bangkok (Thailand), Hong
Kong (China), Kao-hsiung (Taiwan), Los Angeles
(US), Manila (Philippines), Pusan (South Korea), San
Francisco (US), Seattle (US), Shanghai (China),
Singapore, Sydney (Australia), Vladivostok (Russia),
Wellington (NZ), Yokohama (Japan)
Transportation - note: Inside Passage otters
protected waters from southeast Alaska to Puget
Sound (Washington state)','6ad4eb9f7bed8b1b28cc259de301175b211cb4be842955af723b8702990dd539','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0acdac8e7c01200c6ca2cdcac33d42f440560dec401eee9d586ce4c78adab38d',2007,'PK','Pakistan','transportation',1019,'Airports: 134(2005)
Airports - with paved runways:
total: 91
over 3,047 m: 13
2,438 to 3,047 m: 22
1,524 to 2,437 m: 32
914 to 1,523 m: 16
under 914 m: 8 (2005)
Airports - with unpaved runways:
total: 43
over 3,047 m: 1
1,524 to 2,437 m: 9
914 to 1,523 m: 12
under 914 m:21 (2005)
Heliports: 18(2005)
Pipelines: gas 9,945 km; oil 1,821 km (2004)
426
Pakistan (continued)
Railways:
total: 8,163 km
broad gauge: 7,718 km 1 676-m gauge (293 km
electrified)
narrow gauge: 445 km 1.000-m gauge (2004)
Roadways:
total: 254,41 Okm
paved: 152,646 km (including 367 km of
expressways)
unpaved: 101,764 km (2003)
Merchant marine:
total: 14 ships (1000 GRT or over) 343,630 GR17
570,518 DWT
by type: cargo 10, petroleum tanker 4
registered in other countries: 12 (Belize 1, Comoros
2, North Korea 3, Malta 1 , Nigeria 1 , Panama 2, Saint
Vincent and the Grenadines 2) (2005)
Ports and terminals: Karachi, Port Muhammad Bin
Qasim','ff3451c3f43bdbe86d15fe993d524f5090bd4e0979ab65a1b9ed4f4cae3ee8db','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd751f21925a4f0471d605b13de0e7e79cf303c2297ef5d1c2f63a31b73f2ef3',2007,'PW','Palau','transportation',1028,'Airports: 3(2005)
Airports - with paved runways:
total: 1
1,524 to 2,437 m: 1(2005)
Airports - with unpaved runways:
total: 2
1,524 to 2,437 m: 2 (2005)
Ports and terminals: Koror','0e7eb03f8da31932b2828adc89a30f357add57b2e8be991b8ce684316d4b9ea0','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c83c4f37db41bfa9bbe53f5bb30627289f82e2fae1698e367c108dc0e37426d',2007,'PG','Papua New Guinea','transportation',1031,'Ek.
Military branches: an amendment to the
Constitution abolished the armed forces, but there are
security forces (Panamanian Public Forces or PPF
includes the Panamanian National Police, National
Maritime Service, and National Air Service)
Manpower available for military service:
males age 18-49: 733,031 (2005 est.)
Manpower fit for military service:
males age 18-49: 591 .604 (2005 est.)
Military expenditures - dollar figure: $1 50 million
(2005 est.)
Military expenditures ■ percent of GDP: 1%
(2005 est.)
Military - note: on 10 February 1990, the
government of then President ENDARA abolished
Panama''s military and reformed the security
apparatus by creating the Panamanian Public Forces;
in October 1994, Panama''s Legislative Assembly
approved a constitutional amendment prohibiting the
creation of a standing military force, but allowing the
temporary establishment of special police units to
counter acts of "external aggression"','21a290fad9a8f5c34a45eabe2b2f9dc32947387b3b0e3cd424c3fdc1b9854b34','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a98ab13634dbae3368927b10771569f12c1a3cf3dd93eb6dc64a8a5286c6534d',2007,'MX','Mexico','transportation',1039,'Airports: 123(2005)
Airports - with paved runways:
total: 84
over 3.047 m: 4
2.438 to 3,047 m: 29
1.524 to 2.437 m:41
914 to 1.523 m:7
under 914 m: 3 (2005)
Airports - with unpaved runways:
total: 39
2.438 to 3,047 m: 1
1 .524 to 2,437 m: 4
914 to 1,523 m: 13
under 914 m: 21- (2005)
Heliports: 2(2005)
Pipelines: gas 13,552 km; oil 1,772 km (2004)
Railways:
total: 23,852 km
broad gauge: 629 km 1 .524-m gauge
standard gauge: 23,223 km 1.435-m gauge (20,555
km operational; 1 1 ,962 km electrified) (2004)
448
Poland (continued)
Roadways:
total: 423,997 km
paved: 295,356 km (including 484 km of
expressways)
unpaved: 128,641 km (2003)
Waterways: 3,997 km (navigable rivers and canals)
(2005)
Merchant marine:
total: 9 ships (1000 GRT or over) 47,931 GRT/41 ,074
DWT
by type: cargo 5, chemical tanker 2, passenger/cargo
1, roll on/roll off 1
registered in other countries: 106 (The Bahamas 15,
Belize 2, Cayman Islands 1, Cyprus 19, Liberia 14,
Malta 27, Norway 3, Panama 19, Saint Vincent and
the Grenadines 1 , Vanuatu 5) (2005)
Ports and terminals: Gdansk, Gdynia, Swinoujscie,
Szczecin','cbf659bd6588fb25e2b306a5cd369ff3c5de73fd2f274a616f37fe3fd657eadf','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ded909f59660f204fa8e83406cf9806391f64aaa1d80b7997ba95fb6fa4e7bf',2007,'DO','Dominican Republic','transportation',1046,'Airports: 30(2005)
Airports - with paved runways:
total: 17
over 3,047 m: 3
1,524 to 2,437 m: 2
914 to 1,523 m:7
under 914 m: 5 (2005)
453
Puerto RiCO (continued)
Airports - with unpaved runways:
total: 13
1.524 to 2.437 m: 1
914 to 1.523 m: 2
under 914 m: 10 (2005)
Railways:
total: 96 km
narrow gauge: 96 km 1 .000-m gauge (2004)
Roadways:
total: 25,645 km
paved: 24.363 km (including 426 km of expressways)
unpaved: 1 ,282 km (2004)
Merchant marine:
total: 2 ships (1000 GRT or over) 45,662 GRT/32,223
DWT
by type: roll on/roll off 2
foreign-owned: 2 (US 2)
registered in other countries: 1 (Saint Vincent and the
Grenadines 1) (2005)
Ports and terminals: Las Mareas, Mayaguez, San
Juan','9c84281d0ee99ef897b5d186f4d6ae9022e85d80a53d7dc920f7ab18ebce0c46','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd10f7030af07fc6dbc68c69eee3f80e37edb45083a8e7d91e04c0372415961e',2007,'UA','Ukraine','transportation',1057,'Airports: 61 (2005)
Airports - with paved runways:
total: 25
over 3.047 m: 4
2,438 to 3,047 m: 9
1,524 to 2,437 m: 12 (2005)
Airports - with unpaved runways:
total: 36
1,524 to 2,437 m: 2
914 to 1,523 m:11
under 914 m: 23 (2005)
Heliports: 1 (2005)
Pipelines: gas 3,508 km; oil 2,427 km (2004)
Railways:
total: 1 1 ,385 km (3,888 km electrified)
standard gauge: 10,898 km 1.435-m gauge
broad gauge: 60 km 1 .524-m gauge
narrow gauge: 427 km 0.760-m gauge (2004)
Roadways:
total: 198,817 km
paved: 60,043 km (including 228 km of expressways)
unpaved: 138,774 km (2003)
Waterways: 1,731 km
note: includes 1 ,075 km on Danube River, 524 km on
secondary branches, and 132 km on canals (2005)
Merchant marine:
total: 24 ships (1000 GRT or over) 204,803 GRT/
255,382 DWT
by type: bulk carrier 1 , cargo 1 6, passenger 1 ,
passenger/cargo 2, petroleum tanker 3, roll on/roll off 1
foreign-owned: 2 (Italy 2)
registered in other countries: 41 (Georgia 8, North
Korea 16, Malta 3, Panama 9, Saint Vincent and the
Grenadines 2, Syria 3) (2005)
Ports and terminals: Braila, Constanta, Galati,
Tulcea
Airports: 1,730(2005)
Airports - with paved runways:
total: 640
over 3, 04 7 m. 51
2,438 to 3,047 m: 199
1.524 to 2, 437 m: 129
914 to 1,523 m: 109
under 914 m: 152 (2005)
Airports - with unpaved runways:
total: 1,090
over 3, 04 7 m: 16
2,435 to 3,047 m: 30
7,524 to 2,437 m: 88
914 to 1,523 m: 135
under 914 m:821 (2005)
Heliports: 42(2005)
Pipelines: condensate 122 km; gas 150,007 km; oil
75,539 km; refined products 13,771 km (2004)
Railways:
total: 87,157 km
broad gauge: 86,200 km 1.520-m gauge (40,300 km
electrified)
narrow gauge: 957 km 1 .067-m gauge (on Sakhalin
Island)
note: an additional 30,000 km of non-common carrier
lines serve industries (2004)
Roadways:
total: 537,289 km
paved: 362,133 km
unpaved. 175,156 km (2001)
Waterways: 96,000 km
note: 72,000 km system in European Russia links
Baltic Sea, White Sea, Caspian Sea, Sea of Azov, and
Black Sea (2004)
Merchant marine:
total: 1 ,199 ships (1000 GRT or over) 5,138,457 GRT/
6,385,116 DWT
by type: barge carrier 48, bulk carrier 44, cargo 766,
chemical tanker 24, container 12, passenger 12,
passenger/cargo 9, petroleum tanker 218,
refrigerated cargo 49, roll on/roll off 12, specialized
tanker 5
foreign-owned: 86 (Cyprus 1 , Estonia 1 , Germany 2,
Greece 1 , Latvia 2, Malta 5, Norway 1 , Russia 1 ,
Sweden 1, Switzerland 8, Turkey 54, Ukraine 9)
registered in other countries: 382 (Antigua and
Barbuda 6, The Bahamas 4, Belize 33, Cambodia 73,
Comoros 5, Cyprus 54, Denmark 1 , Dominica 2,
Georgia 20, North Korea 2, Latvia 1 , Liberia 65, Malta
60, Marshall Islands 1, Mongolia 10, Panama 6,
Russia 1 , Saint Kitts and Nevis 4, Saint Vincent and
the Grenadines 21, Sierra Leone 1, unknown 10,
Vanuatu 1, Venezuela 1) (2005)
Ports and terminals: Anapa, Kaliningrad,
Murmansk, Nakhodka, Novorossiysk,
Rostov-na-Donu, Saint Petersburg, Taganrog,
Vanino, Vostochnyy
Airports: 537(2005)
Airports - with paved runways:
total: m
over 3,047 m: 13
2,438 to 3,047 m: 57
1,524 to 2,437 m: 30
914 to 1,523 m: 5
under 914 m: 94 (2005)
Airports - with unpaved runways:
total: 338
over 3,047 m: 2
2,438 to 3,047 m: 3
1,524 to 2,437 m: 13
914 to 1,523 m: 22
under 914 m: 298 (2005)
Heliports: 10(2005)
Pipelines: gas 20,069 km; oil 4,540 km; refined
products 4,169 km (2004)
Railways:
total: 22,473 km
broad gauge: 22,473 km 1.524-m gauge (9,250 km
electrified) (2004)
Roadways:
total: 169,739 km
paved: 164,630 km (including 15 km of expressways)
unpaved: 5,109 km (2003)
Waterways: 1 ,672 km (most on Dnieper River)
(2006)
Merchant marine:
total: 204 ships (1000 GRT or over) 780,262 GRT/
91 1,489 DWT
by type: bulk carrier 6, cargo 153, container 4,
passenger 7, passenger/cargo 5, petroleum tanker 9,
refrigerated cargo 1 1 , roll on/roll off 7, specialized
tanker 2
575
Ukraine (continued)
registered in other countries: 142 (Belize 3,
Cambodia 12, Comoros 12, Cyprus 3, Georgia 23,
North Korea 1, Liberia 15, Malta 26. Moldova 3,
Mongolia 1 , Panama 7, Russia 9, Saint Kitts and Nevis
1 , Saint Vincent and the Grenadines 13, Sierra Leone
1 , Slovakia 8, unknown 4) (2005)
Ports and terminals: Feodosiya, Kerch, Kherson,
Mariupol'', Mykolayiv, Odesa, Reni, Yuzhnyy','034dc37d1d56b59d202437340c6be2cf950e95b804265e537d749679768ea8f9','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('143487406aa6b7c2d5b519b2d9b03f2f82054b9738d9353557663be3aa24d959',2007,'RW','Rwanda','transportation',1067,'Airports: 9(2005)
Airports - with paved runways:
total: 4
over 3,047 m: 1
914 to 1,523 m: 2
under 914 m:1 (2005)
Airports - with unpaved runways:
total: 5
914 to 1,523 m: 2
under 914 m: 3 (2005)
Roadways:
total: 12,000 km
paved: 996 km
unpaved: 11,004 km (1999)
Waterways: Lac Kivu navigable by shallow-draft
barges and native craft (2005)
Ports and terminals: Cyangugu, Gisenyi, Kibuye
Airports: 1
note: Wideawake Field on Ascension Island (2005)
Airports - with paved runways:
total: 1
over 3,047 m:1 (2005)
Roadways:
total: 1 98 km (Saint Helena 1 38 km, Ascension 40 km,
Tristan da Cunha 20 km)
paved: 168 km (Saint Helena 118km, Ascension 40
km, Tristan da Cunha 10 km)
unpaved: 30 km (Saint Helena 20 km, Ascension 0
km, Tristan da Cunha 10 km) (2002)
Ports and terminals:
Saint Helena: Jamestown
Ascension Island: Georgetown
Tristan da Cunha: Calshot Harbor
Transportation - note: there is no air connection to
Saint Helena or Tristan da Cunha; an international
airport for Saint Helena is in development for 2010','17419560ea2767b70c2b7629651dea535dfb8e65f46b2d2cd43ba7e4f0b658cd','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('543c38112a8270f8bbfd4f6c4c88309c9b686700229cf9d9a8213aeb62fda4c9',2007,'KN','Saint Kitts and Nevis','transportation',1076,'Airports: 2(2005)
Airports - with paved runways:
total: 2
1,524 to 2,437 m:1
914 to 1.523 m:) (2005)
Railways:
total: 50 km
narrow gauge: 50 km 0.762-m gauge on Saint Kitts to
serve sugarcane plantations during harvest season
(2003)
Roadways:
total: 320 km
paved: 1 38 km
unpaved: 182 km (1999 est)
Merchant marine:
total: 34 ships (1000 GRT or over) 143,627 GRT/
202,477 DWT
by type: bulk carrier 1 , cargo 21 , chemical tanker 3,
passenger/cargo 2, petroleum tanker 5, refrigerated
cargo 2
foreign-owned: 30 (Monaco 1 , Russia 4, Switzerland
1, Syria 1, Turkey 2, Ukraine 1, UAE 20) (2005)
Ports and terminals: Basseterre, Charlestown','f4ac486373eddf8c3f3aa01b0f01dfe3e34163c8fb94c548a7cff846d255bf38','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df20324c7dc14121132fac1a54c94acacb97ee606933060b3654ebab22d23777',2007,'WS','Samoa','transportation',1096,'Airports: 4(2005)
Airports - with paved runways:
total: 3
2,438 to 3,047 m;1
under 914 m: 2 (2005)
Airports - with unpaved runways:
total: 1
under 914 m:1 (2005)
Roadways:
total: 790 km
paved: 332 km
unpaved: 458 km (1999)
Merchant marine:
total: 1 ships (1000 GRT or over) 7,091 GRT/8,127
DWT
by type: cargo 1
foreign-owned: 1 (Germany 1 ) (2005)
Ports and terminals: Apia','1b6051b81a86fcb7570b211c1c84fd4fced9e6c753c2beaf2c02d70600271800','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e27a914b412b330917a5c7a47282828bcc902742d8f6339ac6046d6539d185e8',2007,'SA','Saudi Arabia','transportation',1106,'Airports: 202(2005)
Airports - with paved runways:
total: 73
over 3, 04 7 m: 32
2.438 to 3,047 m: 13
1.524 to 2, 437 m: 24
914 to 1.523 m: 2
under 914 m: 2 (2005)
Airports - with unpaved runways:
total: 129
over 3,047 mA
2.438 to 3.047 m:5
1.524 to 2.437m: 72
914 to 1.523 m: 39
under 914 m: 12 (2005)
Heliports: 6(2005)
Pipelines: condensate 212 km; gas 1,780 km; liquid
petroleum gas 1,191 km; oil 5,068 km; refined
products 1,162 km (2004)
Railways:
total: 1,392 km
standard gauge: 1 ,392 km 1 ,435-m gauge (with
branch lines and sidings) (2004)
Roadways:
total: 152,044 km
paved: 45,461 km
unpaved: 106,583 km (2000)
Merchant marine:
total: 64 ships (1000 GRT or over) 1 ,266,332 GRT/
1,895,002 DWT
by type: cargo 5, chemical tanker 15, container 4,
passenger/cargo 8, petroleum tanker 20, refrigerated
cargo 3, roll on/roll off 9
foreign-owned: 9 (Egypt 1 , Kuwait 6, Sudan 1 , UAE 1 )
registered in other countries: 57 (The Bahamas 12,
Bangladesh 1, Comoros 3, Dominica 1, French
Southern and Antarctic Lands 1 , Liberia 24, Marshall
Islands 1 , Norway 7, Panama 4, Saint Vincent and the
Grenadines 2, unknown 1) (2005)
Ports and terminals: Ad Dammam, Al Jubayl,
Jiddah, Yanbu'' al Sinaiyah','20ab0aaff8fbcaabbf82f6c63b2dea4c83462de1c164a3287b67b4437e97498c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ade86a30c925bc7351c41ac8b664f96620352e29471dd2cd962f6af047ebd1c',2007,'SN','Senegal','transportation',1113,'Airports: 20(2005)
Airports • with paved runways:
total: 9
over 3,047 m: 1
1,524 to 2,437 m: 6
914 to 1,523 m: 2 (2005)
Airports - with unpaved runways:
total: 1 1
1,524 to 2.437 m: 6
914 to 1,523 m: 4
under 914 m:) (2005)
Pipelines: gas 564 km (2004)
Railways:
total: 906 km
narrow gauge: 906 km 1 .000-meter gauge (2004)
Roadways:
total: 13,576 km
paved: 3,972 km (including 7 km of expressways)
unpaved: 9,604 km (2003)
Waterways: 1 ,000 km (primarily on Senegal,
Saloum, and Casamance rivers) (2005)
Ports and terminals: Dakar','6163b41c021d4deaa4a25c1bc6521b074103aabab38affdf64be0f5f10926dc5','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35fb2e96c479118a741bf1433adee5c5ef7c996eb65e36df2611f7bd30a31dba',2007,'ME','Montenegro','transportation',1121,'Airports: 44(2005)
Airports - with paved runways:
total: 19
over 3,047 m: 2
2,438 to 3,047 m: 5
1,524 to 2,437 m: 6
914 to 1,523 m: 2
under 914 m: 4 (2005)
Airports • with unpaved runways:
total: 25
1,524 to 2,437 m: 2
914 to 1,523 m:W
under 914 m: 13 (2005)
Heliports: 4(2005)
Pipelines: gas 3,177 km; oil 393 km (2004)
492
Serbia and Montenegro (continued)
Railways:
total: 4,380 km
standard gauge: 4,380 km 1.435-m gauge (1,364 km
electrified) (2004)
Roadways:
total: 45,290 km
paved. 28,261 km
unpaved: 17,029 km (2002)
Waterways: 587 km (2002)
Merchant marine:
total: 5
by type: cargo 4, chemical tanker 1
foreign-owned: 1 (Finland 1)
registered in other countries: 4 (The Bahamas 2,
Saint Vincent and the Grenadines 2) (2005)
Ports and terminals: Bar','c99c46709db94ea0ade58bcde697a3b5ec0cb9d3e22cb17a4c5709c45a70f255','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cab6d20d3f80da75b96dfd365e9c9d25974863d5217f5660e53bf301dd3f10d4',2007,'SL','Sierra Leone','transportation',1131,'Airports: 15(2005)
Airports - with paved runways:
total: 8
2,438 to 3,047 m: 1
914 to 1,523 m: 4
under 914 m: 3 (2005)
Airports • with unpaved runways:
total: 7
914 to 1,523 m: 3
under 914 m: 4 (2005)
Roadways:
total: 280 km
paved: 176 km
unpaved: 104 km (2002)
Merchant marine:
total: 5 ships (1000 GRT or over) 69,777 GRT/
112,464 DWT
by type: cargo 1 , chemical tanker 4
foreign-owned: 3 (Cyprus 1 , Nigeria 1 , South Africa 1 ;
(2005)
Ports and terminals: Victoria
Airports: 10(2005)
Airports - with paved runways:
total: 1
over 3,047 m:1 (2005)
Airports - with unpaved runways:
total: 9
914 to 1,523 m: 7
under 914 m: 2 (2005)
Heliports: 2(2005)
Roadways:
total: 11,300 km
paved: 904 km
unpaved: 10,396 km (2002)
Waterways: 800 km (600 km year round) (2005)
Merchant marine:
total: 8 ships (1000 GRT or over) 43,420 GRT/73,931
DWT
by type: cargo 3, chemical tanker 1 , passenger/cargo
1 , petroleum tanker 3
foreign-owned: 3 (Russia 1 , Ukraine 1 , UAE 1 ) (2005)
Ports and terminals: Freetown, Pepel, Sherbro
Islands','ef14df91e80559b7d04f9c175fa5d4e7c6d2c9b187d640f1e552d0457a3de116','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9292cedcda2166ddc1aaa44de4b3e63db47a4f8cc8e6866c4105bae75bef04ed',2007,'SK','Slovakia','transportation',1145,'Airports: 34(2005)
Airports - with paved runways:
total: 17
over 3,047 m: 2
2.438 to 3,047 m: 2
1,524 to 2.437 m: 3
914 to 1,523 m: 3
under 914 m: 7 (2005)
Airports - with unpaved runways:
total: 17
2,438 to 3,047 m: 1
974 to 1,523 m: 9
under974m: 7 (2005)
Heliports: 1 (2005)
Pipelines: gas 6,769 km; oil 449 km (2004)
Railways:
total: 3,662 km
broad gauge: 100 km 1 .520-m gauge
standard gauge: 3,512 km 1.435-m gauge (1,588 km
electrified)
narrow gauge: 50 km (1 .000-m or 0.750-m gauge)
(2004)
Roadways:
total: 42,993 km
paved: 37,533 km (including 313 km of expressways)
unpaved: 5,460 km (2003)
Waterways: 172 km (on Danube River) (2005)
Merchant marine:
total: 39 ships (1000 GRT or over) 204,146 GRT/
287,586 DWT
by type: bulk carrier 5, cargo 33, chemical tanker 1
foreign-owned: 38 (Bulgaria 7, Estonia 1, Greece 5,
Israel 6, Syria 2, Turkey 8, Ukraine 8, UK 1)
registered in other countries: 1 (Cyprus 1) (2005)
Ports and terminals: Bratislava, Komarno','1155d67630025a393bcd494b6824d0b6b194e7d836d4438fbc9ca40a73447149','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29803db3ee4da22868e7d862749e65d204c733d24c2b4d026aa56f6bd71f6302',2007,'VU','Vanuatu','transportation',1151,'Airports: 34(2005)
Airports - with paved runways:
total: 2
1,524 to 2,437 m: 1
914 to 1,523 m:1 (2005)
Airports - with unpaved runways:
total: 32
1,524 to 2,437 m: 1
914 to 1,523 m: 9
under 91 4 m: 22 (2005)
Roadways:
total: 1,360 km
paved: 34 km
unpaved: 1,326 km (1999)
Ports and terminals: Honiara, Malloco Bay,
Shortland Harbor, Viru Harbor, Yandina
t a r y
Military branches: no regular military forces; Royal
Solomon Islands Police (RSIP)
Military expenditures - dollar figure: NA
Military expenditures - percent of GDP: NA
Airports: 31 (2005)
Airports - with paved runways:
total: 3
2.438 to 3,047 m: 1
1,524 to 2,437 m:]
914 to 1,523 m:1 (2005)
Airports - with unpaved runways:
total: 28
914 to 1,523 m: 10
under 914 m: 18 (2005)
Roadways:
total: 1,070 km
paved: 256 km
unpaved: 814 km (1999)
Merchant marine:
total: 52 ships (1000 GRT or over) 1 ,214,417 GRT/
1,649,713 DWT
by type: bulk carrier 28, cargo 10, container 1 ,
liquefied gas 2, refrigerated cargo 4, roll on/roll off 2,
vehicle carrier 5
foreign-owned: 52 (Australia 2, Canada 5, Denmark 6,
Estonia 1 , Greece 1 , Japan 26, NZ 2, Poland 5,
Russia 1, Switzerland 2, US 1) (2005)
Ports and terminals: Forari, Port-Vila, Santo
(Espiritu Santo)
Airports: 370(2005)
Airports • with paved runways:
total: 128
over 3,047 m: 5
2,438 to 3,047 7n; 11
1,524 to 2,437 m: 33
914 to 1,523 m: 60
under 914 m: 19(2005)
Airports - with unpaved runways:
total: 242
1,524 to 2,437 m: 9
914 to 1,523 m: 89
under 914 m: 144(2005)
Heliports: 1 (2005)
Pipelines: extra heavy crude 992 km; gas 5,262 km;
oil 7,360 km; refined products 1,681 km; unknown (oil/
water) 141 km (2004)
Railways:
total: 682 km
standard gauge: 682 km 1 .435-m gauge (2004)
Roadways:
total: 96,155 km
paved: 32,308 km
unpaved: 63,847 km (1999)
Waterways: 7,100 km
note: Orinoco River and Lake de Maracaibo
navigable by oceangoing vessels, Orinoco for 400 km
(2005)
Merchant marine:
total: 57 ships (1000 GRT or over) 800,040 GRT/
1,285,206 DWT
by type: bulk carrier 7, cargo 14, chemical tanker 1 ,
container 1 , liquefied gas 5, passenger/cargo 9,
petroleum tanker 19, roll on/roll off 1
foreign-owned: 1 1 (Denmark 2, Greece 2, Hong Kong
1 , India 1 , Mexico 1 , Russia 1 , Singapore 1 , Spain 1 , US
D
registered in other countries: 1 4 (Panama 1 4) (2005)
Ports and terminals: Amuay, La Guaira,
Maracaibo, Puerto Cabello, Punta Cardon
599
Venezuela (continued)','788486cf2c819826a166d023d9dc16cd0b9f245770dd4a417aef9d4a1b139e4d','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('809ce228c45406e196e55cbaaf0ac53d028cb96e47d4d42a001e954bf31c33df',2007,'KE','Kenya','transportation',1159,'Airports: 64(2005)
Airports - with paved runways:
total: 6
over 3,047 m: 4
2,438 to 3,047 m: 1
1,524 to 2,437 m: 1 (2005)
Airports - with unpaved runways:
total: 58
2,438 to 3,047 m: 4
1,524 to 2, 437 m: 19
914 to 1,523 m: 29
under 914 m: 6 (2005)
Roadways:
total: 22,1 00 km
paved: 2,608 km
unpaved: 19,492 km (1999)
Ports and terminals: Boosaaso, Berbera,
Chisimayu (Kismaayo), Merca, Mogadishu','ebc0e30d8d8b062adca04e4b3bb9bc3989504aca20fea5cb54255d863ce336c4','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('db47f3b3a8005cc788c9911009163d31d79f3381c822a1325705d72a7ab426ec',2007,'DZ','Algeria','transportation',1163,'Airports: 157(2005)
Airports - with paved runways:
total: 95
over 3,047 m: 15
2,438 to 3,047 m: 10
1,524 to 2,437 m: 19
914 to 1,523 m: 25
under 914 m: 26(2005)
Airports • with unpaved runways:
total: 62
over 3,047 m: 1
1,524 to 2,437 m: 2
914 to 1,523 m: 15
under 914 m: 44(2005)
Heliports: 8(2005)
Pipelines: gas 7,306 km; oil 730 km; refined
products 3,512 km (2004)
Railways:
total: 14,781 km (7,718 km electrified)
broad gauge: 1 1 ,829 km 1 .668-m gauge (6,950 km
electrified)
standard gauge: 998 km 1.435-m gauge (998 km
electrified)
narrow gauge: 1 ,926 km 1 .000-m gauge (81 5 km
electrified); 28 km 0.91 4-m gauge (28 km electrified)
(2004)
Roadways:
total: 666,292 km
paved: 659,629 km (including 12,009 km of
expressways)
unpaved: 6,663 km (2003)
Waterways: 1,000 km (2003)
Merchant marine:
total: 165 ships (1000 GRT or over) 2,307,471 GRT/
2,283,181 DWT
by type: bulk carrier 9, cargo 15, chemical tanker 14,
container 23, liquefied gas 9, passenger 2, passenger/
cargo 44, petroleum tanker 15, refrigerated cargo 5,
roll on/roll off 22, specialized tanker 2. vehicle carrier 5
foreign -owned: 33 (Australia 1, Cuba 1, Denmark 1,
Germany 1 1 , Italy 2, Mexico 3, Norway 7, US 6,
Uruguay 1)
registered in other countries: 98 (The Bahamas 1 1 ,
Belize 2, Brazil 6, Cape Verde 1 , Cuba 1 , Cyprus 5,
Ireland 1, Malta 1, Marshall Islands 2, Panama 48,
Portugal 1 7, Saint Vincent and the Grenadines 1 ,
Venezuela 1, unknown 1) (2005)
Ports and terminals: Algeciras, Barcelona,
Cartagena, Gijon, Huelva, La Coruna, Tarragona,
Valencia','27135d72272ee2188e2a8233dcb9e9268b08313c59794a8600a95652a2004313','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('225467786b01b784ad8e26373a12bafce9babe6435e750d10385861cdd73e096',2007,'PH','Philippines','transportation',1169,'Airports: 3(2005)
Airports - with paved runways:
total: 2
914 to 1,523 m: 1
under 914 m: 1 (2005)
Airports - with unpaved runways:
total: 1
914 to 1,523 m: 1 (2005)
Ports and terminals: none; offshore anchorage only','ec86cbadeb9b44e152e823d1f5a48904c9b0fc6e67df817a671d4b978e452b4f','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4000d1db6509e4baa9ae8a897d587558b74f9f1de8f28d0098b581a05c93c05',2007,'LK','Sri Lanka','transportation',1179,'Airports: 16(2005)
Airports - with paved runways:
total: U
over 3,047 m: 1
1,524 to 2,437 m: 6
914 to 1,523 m: 7 (2005)
Airports - with unpaved runways:
total: 2
under 914 m: 2 (2005)
Railways:
total: 1,449 km
broad gauge: 1 ,449 km 1 .676-m gauge (2004)
Roadways:
total: 97,287 km
paved: 78,802 km
unpaved: 18,485 km (2003)
Waterways: 160 km (primarily on rivers in
southwest) (2005)
Merchant marine:
total: 24 ships (1000 GRT or over) 152,667 GRT/
202,199 DWT
by type: cargo 1 8, container 3, passenger 1 ,
petroleum tanker 2
foreign-owned: 10 (Germany 8, UAE 2)
registered in other countries: 6 (Panama 6) (2005)
Ports and terminals: Colombo, Galle','a20b4706efaa4d804afdd7cd09a405badf6bed761a286b07740608640a458f90','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('478d7de2e76921ca057c93d97c0ad74273368990a65a1b19f51b5a1a2454d7fb',2007,'SD','Sudan','transportation',1186,'Airports: 86(2005)
Airports - with paved runways:
total: 14
over 3,047 m: 1
2.438 to 3,047 m: 9
1,524 to 2,437 m: 4(2005)
Airports - with unpaved runways:
total: 72
over 3,047 m: 1
1,524 to 2,437 m: 18
914 to 1,523 m: 37
under 914 m: 16(2005)
Heliports: 1 (2005)
Pipelines: gas 156 km; oil 2,365 km; refined
products 810 km (2004)
Railways:
total: 5,995 km
narrow gauge: 4,595 km 1.067-m gauge; 1,400 km
.600-m gauge for cotton plantations (2004)
Roadways:
total: 11,900 km
paved: 4,320 km
unpaved: 7,580 km (1999)
Waterways: 4,068 km (1 ,723 km open year round on
White and Blue Nile rivers) (2005)
Merchant marine:
total: 2 ships (1 000 GRT or over) 11, 326 GRT/1 4,068
DWT
by type: cargo 1 , livestock carrier 1
registered in other countries: 2 (Panama 1 , Saudi
Arabia 1) (2005)
Ports and terminals: Port Sudan','c1b5e4b85e009df45c6c30f94c90f8106e750aec452e9d3ccb9f95ea3a4fb2a3','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('492a3e22153fefebca70305e0bd1f509822484722eabecb6f77cb38bf9d4f3e6',2007,'SE','Sweden','transportation',1197,'Airports: 255(2005)
Airports - with paved runways:
total: 156
over 3,047 m: 3
2,438 to 3,047 m: 13
1,524 to 2,437 m: 80
914 to 1,523 m: 23
under 914 m: 36 (2005)
Airports - with unpaved runways:
total: 100
914 to 1,523 m: 9
under 914 m: 91 (2005)
Heliports: 2(2005)
Pipelines: gas 798 km (2004)
Railways:
total: 11,481 km
standard gauge: 1 1 ,481 km 1 .435-m gauge (9,400 km
electrified) (2004)
Roadways:
total: 424,981 km
paved: 132,339 km (including 1 ,544 km of
expressways)
unpaved: 292,642 km (2003)
Waterways: 2,052 km (2005)
Merchant marine:
total: 198 ships (1000 GRT or over) 3,528,264 GRT/
2,193,807 DWT
by type: bulk carrier 7, cargo 29, chemical tanker 43,
passenger 4, passenger/cargo 35, petroleum tanker
16, roll on/roll off 38, specialized tanker 6, vehicle
carrier 20
foreign-owned: 39 (Belgium 3, Denmark 3, Finland 1 1 ,
Germany 4, Italy 7, Japan 2, Norway 8, US 1 )
registered in other countries: 161 (The Bahamas 10,
Bermuda 1 2, Cayman Islands 1 2, Cyprus 4, Finland 3,
France 3, French Southern and Antarctic Lands 8,
Gibraltar 5, Greece 1 , Isle of Man 1 , Liberia 8, Malta 3,
Marshall Islands 1, Netherlands 21, Netherlands
Antilles 9, Norway 22, Panama 5, Russia 1, Saint
Vincent and the Grenadines 1, Singapore 12, UK 15,
US 4) (2005)
Ports and terminals: Goteborg, Helsingborg,
Karlshamn, Lulea, Malmo, Oxelosund, Stenungsund,
Stockholm, Trelleborg','000eeba9d74392eca8a8d1112de4a8173d95f4361cc7412914be3f5a36db8255','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f6d4d8f06e1d0af2af1788dbcce72100c7e155bec32688ef9cb4b1fcc093a93',2007,'UZ','Uzbekistan','transportation',1208,'Airports: 45(2005)
Airports - with paved runways:
total: 17
over 3,047 m: 2
2,438 to 3,047 m: 4
1,524 to 2,437 m: 5
914 to 1,523 m: 3
under 914 m: 3 (2005)
Airports - with unpaved runways:
total: 28
1,524 to 2,437 m: 1
914 to 1,523 m: 1
under 914 m: 26 (2005)
Pipelines: gas 541 km; oil 38 km (2004)
Railways:
tote/: 482 km
broad gauge: 482 km 1.520-m gauge (2004)
Roadways:
total: 27,767 km (2000)
Waterways: 200 km (along Vakhsh River) (2006)
Airports: 79(2005)
Airports - with paved runways:
total: 33
over 3,047 m: 6
2,438 to 3,047 m: 13
1,524 to 2,437 m: 5
914 to 1,523 m: 5
under 914 m: 4 (2005)
Airports - with unpaved runways:
total: 46
2,438 to 3,047 m: 2
1,524 to 2,437 m: 2
under 914 m: 42 (2005)
Pipelines: gas 9,149 km; oil 869 km; refined
products 33 km (2004)
Railways:
total: 3,950 km
broad gauge: 3,950 km 1 520-m gauge (620 km
electrified) (2004)
Roadways:
total: 81,600 km
paved: 71,237 km
unpaved: 10,363 km (1999)
Waterways: 1,100 km (2006)
Ports and terminals: Termiz (Amu Darya)','22eea91458a29688ee8971725a8046770b28afd552f4ed5d300481eb6f19fdc2','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86f6f9833e13469840c9a1a70e815f7300088085e355a350cae6cbeef7c27a6a',2007,'TK','Tokelau','transportation',1218,'Airports: none; lagoon landings are possible by
amphibious aircraft (2005)
Ports and terminals: none; offshore anchorage only
/
551
Tokelau (continued)
M i
1 i t a r y','9823c35a2dac3ea2efb4bb5d41e60c39ccd330392556110b58bce961100367eb','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e20f49262271e2545384e5c183efc09a0f43efbdb3eb744f11303b55e5af8c1',2007,'TV','Tuvalu','transportation',1229,'Airports: 1 (2005)
Airports - with unpaved runways
total: 1
1,524 to 2,437 m: 1(2005)
Roadways:
total: 8 km
paved: 8 km (2002)
Merchant marine:
total: 42 ships (1 000 GRT or over) 165,607 GRT/
257,474 DWT
by type: bulk carrier 1 , cargo 36, container 2,
passenger/cargo 2, petroleum tanker 1
foreign-owned: 25 (China 1 3, Germany 2, Hong Kong
7, Singapore 2, Thailand 1) (2005)
Ports and terminals: Funafuti','74190fe8746cedbd8309b4bbf2a96caf9cb65b53f5f744a6571e1351ac9c447a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e643f159538b1bdd78c800d7f341ee9e474e690527d4d631bb2f901312d98b6',2007,'UG','Uganda','transportation',1237,'Airports: 28(2005)
Airports - with paved runways:
total: 4
over 3,047 m: 3
1,524 to 2, 437 m: 1(2005)
Airports - with unpaved runways:
total: 24
2,438 to 3,047 m: 1
1,524 to 2,437 m: 6
914 to 1,523 m: 10
under 914 m: 7 (2005)
Railways:
total: 1,241 km
narrow gauge: 1,241 km 1.000-m gauge (2004)
Roadways:
total: 70,746 km
paved: 16,272 km
unpaved: 54,474 km (2003)
Waterways: on Lake Victoria, 200 km on Lake
Albert, Lake Kyoga, and parts of Albert Nile (2005)
Ports and terminals: Entebbe, Jinja, Port Bell','2d082e9774399d19675dc9b4d62244bb443aafec2b150937f42f358078135cf6','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f8f45c1bb5e44f685e1cc5e9368b4eb3928d4f233d6a5d5c46cd8b7ebad7ec2',2007,'QA','Qatar','transportation',1248,'Airports: 35(2005)
Airports - with paved runways:
total: 22
over 3,047 m: 9
2.438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 4
under 914 m: 3 (2005)
Airports - with unpaved runways:
total: \\2>
over 3,047 m: 1
2,438 to 3,047 m: 2
1,524 to 2,437 m: 3
914 to 1,523 m: 3
under 914 m: 4 (2005)
Heliports: 2(2005)
Pipelines: condensate 469 km; gas 2,655 km; liquid
petroleum gas 300 km; oil 2,936 km; oil/gas/water
5 km (2004)
Roadways:
total: 1,088 km
paved: 1 ,088 km (including 253 km of expressways)
(1999)
Merchant marine:
total: 56 ships (1000 GRT or over) 621 ,292 GRT/
833,840 DWT
by type: bulk carrier 4. cargo 1 1 , chemical tanker 5,
container 6, liquefied gas 1 . passenger/cargo 3.
petroleum tanker 19, roll on/roll off 6. specialized
tanker 1
foreign-owned: 10 (Greece 2, Kuwait 8)
registered in other countries: 234 (The Bahamas 14,
Barbados 1 . Belize 3, Cambodia 2. Cyprus 1 1 , Dominica
3, Georgia 1 , Hong Kong 1 , India 7, Iran 1, Jamaica 3,
Jordan 12, North Korea 7, Liberia 15, Libya 1 , Malta 5,
Marshall Islands 2, Mexico 1 , Mongolia 3, Panama 89,
Philippines 2. Qatar 1 , Saint Kitts and Nevis 20, Saint
Vincent and the Grenadines 12, Saudi Arabia 1. Sierra
Leone 1 , Singapore 7, Sri Lanka 2, unknown 6) (2005)
Ports and terminals: Al Fujayrah, Khawr Fakkan,
Mina'' Jabal ''Ali, Mina'' Rashid, Mina'' Saqr, Mina'' Zayid,
Sharjan
Manpower available for military service:
males age 78-49:653,181
note: includes non-nationals (2005 est.)
Manpower fit for military service:
males age 18-49: 526,671 (2005 est.)
Manpower reaching military service age
annually:
males: 30,706 (2005 est.)
Military expenditures - dollar figure: $1 .6 billion
(FY00)
Military expenditures • percent of GDP: 3.1%
(FY00)','557a48dd569afb5a07bfd82caca1e5a00141260494b5b679e9b5064f44f3cb31','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b843625d60a54983b419d78b51732a104bdc97901eab81e60d90623171f90531',2007,'UY','Uruguay','transportation',1257,'Airports: 64(2005)
Airports - with paved runways:
total: 9
over 3,047 m:]
1,524 to 2,437 m: 4
914 to 1,523 m: 2
under 914 m: 2 (2005)
Airports - with unpaved runways:
total: 55
1,524 to 2,437 m: 3
914 to 1,523 m:21
under 914 m: 31 (2005)
Pipelines: gas 192 km (2004)
Railways:
total: 2,073 km
standard gauge: 2,073 km 1.435-m gauge
note: 461 km have been taken out of service and 460
km are in partial use (2004)
Roadways:
total: 77,732 km
paved: 7,743 km
unpaved: 69,989 km (2004)
Waterways: 1,600 km (2005)
Merchant marine:
total: 13 ships (1000 GRT or over) 37,683 GRT/
19,725 DWT
by type: cargo 2, chemical tanker 1 , passenger/cargo
7, petroleum tanker 2, roll on/rol! off 1
foreign-owned: 4 (Argentina 3, Greece 1)
registered in other countries: 7 (Argentina 1 , The
Bahamas 2, Liberia 3, Spain 1) (2005)
Ports and terminals: Montevideo, Nueva Palmira,
Fray Bentos, Colonia, Juan Lacaze
591
Uruguay (continued)','560431713e8029efb9bbb1506521697272f4a107bed841919f8563fdb143d59a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57894162222d577937c82444e71e4b03bbef7bbd9f9699f62ab4fbdddd4d0177',2007,'IL','Israel','transportation',1271,'Airports: 3(2005)
Airports - with paved runways:
total: 3
2.438 to 3,047 m: 1
1,524 to 2.437 mA
under 914 m: 1 (2005)
Roadways:
total: 4, 158 km
paved: 4, 158 km
note: includes Gaza Strip (2003)','78c6e4213bca5cbc864f03b93600d4efa0607e0bb246d72566d2b6cf186434ec','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('007196cc51a98ac6c2000bda77c474a06e70b0329c7a24867269a3a73af23752',2007,'ZM','Zambia','transportation',1288,'Airports: 109(2005)
Airports - with paved runways:
total: 10
over3.047m.-1
2.438 to 3.047 m: 3
1.524 to 2.437 m: 4
914 to 1.523 m: 2 (2005)
Airports - with unpaved runways:
total: 99
2.438 to 3.047 m: 1
1.524 to 2.437 m: 4
974 fo 7,523 m: 62
under 914 m: 32 (2005)
Pipelines: oil 771 km (2004)
Railways:
total: 2,173 km
narrow gauge: 2,173 km 1 ,067-m gauge
note: includes 891 km of the Tanzania-Zambia
Railway Authority (TAZARA) (2004)
Roadways:
total: 91,440 km
paved: 20,1 17 km
unpaved: 71 ,323 km (2001)
Waterways: 2,250 km (includes Lake Tanganyika
and the Zambezi and Luapula rivers) (2005)
Ports and terminals: Mpulungu
Airports: 404(2005)
Airports - with paved runways:
total: 17
over 3,047 m: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 8 (2005)
Airports - with unpaved runways:
total: 387
1,524 to 2,437 m: 5
914 to 1,523 m:186
under 914 m: 196 (2005)
Pipelines: refined products 261 km (2004)
Railways:
total: 3,077 km
narrow gauge: 3,077 km 1 .067-m gauge (313 km
electrified) (2004)
Roadways:
total: 97,440 km
paved: 18,514 km
unpaved: 78,926 km (2002)
Waterways: on Lake Kariba, length small (2005)
Ports and terminals: Binga, Kariba
Airports: 42(2005)
Airports - with paved runways:
total: 38
over 3,047m: 8
2,438 to 3,047m: 8
1,524 to 2,437m: 12
914 to 1,523m: 8
under 914m: 2 (2005)
Airports - with unpaved runways:
total: 4
1,524 to 2,437m: 1
under 914m: 3 (2005)
Heliports: 3(2005)
Pipelines: condensate 25 km; gas 435 km (2004)
Railways:
total: 2,497 km
narrow gauge: 1 ,097 km 1 .067-m gauge (685 km
electrified)
note: 1 ,400 km .762-m gauge (belonging to the
Taiwan Sugar Corporation and to the Taiwan Forestry
Bureau) used to haul products and limited numbers of
passengers (2004)
Roadways:
total: 37,299 km
paved: 35,621 km (including 1 ,789 km of
expressways)
unpaved: 1,678 km (2002)
Merchant marine:
total: 123 ships (1000 GRT or over) 3,095,383 GRT/
5,044,249 DWT
by type: barge carrier 2, bulk carrier 33, cargo 22,
chemical tanker 2, container 35, passenger/cargo 3,
petroleum tanker 16, refrigerated cargo 8, roll on/roll
off 2
foreign-owned: 3 (Hong Kong 3)
registered in other countries: 450 (Bolivia 1 ,
Cambodia 2, Gibraltar 1 , Honduras 2, Hong Kong 8,
Italy 10, Liberia 68, Malta 1, Panama 302, Philippines
2, Singapore 49, UK 1, US 1, unknown 2) (2005)
Ports and terminals: Chi-lung (Keelung), Hua-lien,
Kao-hsiung, Su-ao, T''ai-chung
Airports: 3,130(2005)
Airports • with paved runways: 1 ,852 (2005)
Airports - with unpaved runways: 1 ,274 (2005)
Heliports: 93(2005)
Railways:
total: 222,293 km
broad gauge: 28,438 km
standard gauge: 186,405 km
narrow gauge: 7,427 km
other: 23 km (2003)
Roadways:
total: 4,634,810 km (including 56,704 km of
expressways)
paved: 4,161,318 km
unpaved: 473,492 km (1999-2000)
Waterways: 53,512 km
Ports and terminals: Antwerp (Belgium), Barcelona
(Spain), Bremen (Germany), Copenhagen
(Denmark), Gdansk (Poland), Hamburg (Germany),
Helsinki (Finland), Las Palmas (Canary Islands,
Spain), Le Havre (France), Lisbon (Portugal), London
(UK), Marseille (France), Naples (Italy), Peiraiefs or
Piraeus (Greece), Riga (Latvia), Rotterdam
(Netherlands), Stockholm (Sweden), Talinn (Estonia)
624
European Union (continued)','9f1a5ceb4a3fb3a951afa0f26e0f4f74929a7e8f5376bda537c062c32f04fe9c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('edfa347f483fd09760712896659d20a774ab1f801633fa708f139b79c58b5ce5',2007,'','','raw',1,'(CIA''s 2006 edition)
Prepared by the
ientral Intelligence Agency
.-"■ ■
III
$60.00
Higher in Canada
The
World
Factbook
The World Factbook, produced annually
by the CIA, has become the ultimate,
authoritative source for information on all
nations of the world. It provides current
data for more than 250 countries and ter-
ritories, from Afghanistan to Zimbabwe.
Topics addressed include the political
climate, natural resources, environment,
population, ethnic groups, GDR agriculture,
industries, defense expenditures, literacy
rate, religion, legal system, and much
more. Key data are grouped under the
headings of geography, people, government,
economy, communications, transportation,
military, and transnational issues. The
World Factbook also contains a multitude
of maps — one of each country and others
for key territories. In addition, readers will
find handy appendixes on international
organizations and groups, international
environmental agreements, and a cross-
referenced list of geographic names. The
World Factbook provides the indispensable
reference for curious individuals concerned
about the world in which they live.
Digitized by the Internet Archive
in 2012
http://archive.org/details/worldfactbook20000cent
THE
WORLD
FACTBOOK
2007
(CIA''s 2006 Edition)
Prepared by the Central Intelligence Agency
Potomac Books, Inc.
Washington, D.C.
Potomac Books, Inc.''s 2007 Edition (CIAs 2006 Edition)
In general, information available as of 1 January 2006 was used in the preparation of this edition.
The World Factbook is prepared by the Central Intelligence Agency for the use of US Government officials,
and the style, format, coverage, and content are designed to meet their specific requirements. Information
is provided by Antarctic Information Program (National Science Foundation), Armed Forces Medical
Intelligence Center (Department of Defense), Bureau of the Census (Department of Commerce), Bureau
of Labor Statistics (Department of Labor), Central Intelligence Agency Council of xManagers of National
Antarctic Programs, Defense Intelligence Agency (Department of Defense), Department of State, Fish and
Wildlife Service (Department of the Interior), Maritime Administration (Department of Transportation),
National Geospatial-Intelligence Agency (Department of Defense), Naval Facilities Engineering Command
(Department of Defense), Office of Insular Affairs (Department of the Interior), Office of Naval Intelligence
(Department of Defense), US Board on Geographic Names (Department of the Interior), US Transportation
Command (Department of Defense), Oil & Gas Journal, and other public and private sources.
Potomac Books publishes a commercial version of The World Factbook in order to extend the limited
audience reached by the CIA''s publication. This annual is a valuable primary source of information, and
Potomac Books seeks to make it more readily available to bookstores and libraries so that the taxpayers
who fund the US government can directly benefit from this excellent effort. Potomac Books makes no
claim to copyright to this publication. Potomac Books''s edition differs in two minor aspects from the CIA
publication. This current Potomac Books edition is identified by the year 2007, following the pattern
Potomac Books uses in other annual publications. The CIA completes its volume late each year, and
Potomac Books republishes it the following year. Also, as a commercial publisher, Potomac Books does
not include the simple but expensive four-color maps contained in the CIA publication. The cost to the
consumer would be prohibitive, and these maps are not unique and are readily available elsewhere.
ISBN 978-1-59797-109-6 (alk. paper)
Printed in the United States of America on acid-free paper that meets the American National Standards
Institute Z39-48 Standard.
Potomac Books, Inc.
22841 Quicksilver Drive
Dulles, Virginia 20166
First Edition
10 987654321
Contents
Page
Page
Notes and Definitions
vii
Guide to Country Profiles
xxxv
World
1
A Afghanistan
3
Akrotiri
7','666bbca5059d598319be6cab19e01786b67f9cee9b61c533cbf542c43ef1bfd1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb0fc83727ace4ba33802adaf8416c413f31545f7b4fb181c9c5e7851667145c',2007,'ET','Ethiopia','raw',2,'184
Europa Island
187
European Union entry follows country listing
F Falkland Islands (Islas Malvinas)
188','96f48f77ad5222d869d55e16764a304b4c7831dcccae09043045ac1d243d58e0','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ed6cc3237851613ec4a370d980039505c513ec428a3c29096ccc7bd0170cd60',2007,'PF','French Polynesia','raw',3,'202
French Southern and Antarctic Lands
204
G Gabon
205
Gambia, The
208
Gaza Strip
210','a5be66187843619f83dfa4aec9c18ed29ae74e55c7f3339e50a27e0d3824c599','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f54db3335ca75d6554238aceeabb03e1c659f507f34663be9a224011a595ecfb',2007,'HK','Hong Kong','raw',4,'253
Howland Island description under
United States Pacific Island
Wildlife Refuges','a4f7560d8f4269c040130ecdfb300aa44253d4964ded6ef48c03666ab67aa987','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e49c14c979e859880b71da15ff14c1a1fd10cd47b9df57cb03350b562dd598d',2007,'JP','Japan','raw',5,'288
Jarvis Island description under
United States Pacific Island
Wildlife Refuges','31bc083dac66ca5486530a22ab24e421296d14b9006c145da49cbcd15183cfc6','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c253925d76992fb2c9cdcd0f27af2d1240eca5ccbdae016e0ca37741d5f58b76',2007,'JE','Jersey','raw',6,'291
Johnston Atoll description under
United States Pacific Island
Wildlife Refuges','58549423b9677653ad66b7b89065640625f9c9b6ec44422535eaa257c4d2c6f8','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ffd58ccd6f8679ec0862982e5868b937b007d0ccc8f87b6c7627ffa5491f57d',2007,'KE','Kenya','raw',7,'299
Kingman Reef description under
United States Pacific Island
Wildlife Refuges','548369d1f3c53945fe9350b62dc32b88ff9fd1195cc61e76d8653aed24b0b09f','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8155278a22c5939835314f374b447de84b55c81741793cd9ad6259d971b6eff2',2007,'FM','Micronesia, Federated States of','raw',8,'370
Midway Islands description under
United States Pacific Island
Wildlife Refuges
Moldova
372','1834261bc9c6fca5eebb894da3f2407c5f4af2eb4ce74f53b9af95a9f8b9df65','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4842643ef7537a2c337964e6fc00bf3ddc3b05ef97388d0096a847187640c185',2007,'PW','Palau','raw',9,'427
Palmyra Atoll description under
United States Pacific Island
Wildlife Refuges','6c366b4d856a3704dc22ef1b5e52ecc05f92d7f9b35b4f487848f033064955b2','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4204cbafe28281bb3a96b237ca1d9c6e5500ba7c3fd39e56443f6258a44a36bd',2007,'UZ','Uzbekistan','raw',10,'592
V Vanuatu
595
Vatican City (see Holy See)
Venezuela
597
Vietnam
600
Virgin Islands
603
W Wake Island
605','6388089e0fc2bee7848ded9ecd85c01ba007272b83eb74903f1b0609536f2b8a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f270c19430e24ae97445c53173b63ba3a1559f63510089b45aae78a5590eaf2',2007,'EH','Western Sahara','raw',11,'609
Y Yemen
611
Z Zambia
614
OTHER ENTITIES
5 oceans - Arctic Ocean. Atlantic Ocean, Indian Ocean, Pacific Ocean,
Southern Ocean
1 World
271 total
Environment - current issues: This entry lists the most pressing and important
environmental problems. The following terms and abbreviations are used
throughout the entry:
Acidification - the lowering of soil and water pH due to acid precipitation and
deposition usually through precipitation; this process disrupts ecosystem nutrient
flows and may kill freshwater fish and plants dependent on more neutral or alkaline
conditions (see acid rain).
Acid rain - characterized as containing harmful levels of sulfur dioxide or
nitrogen oxide; acid rain is damaging and potentially deadly to the earth''s fragile
ecosystems; acidity is measured using the pH scale where 7 is neutral, values
greater than 7 are considered alkaline, and values below 5.6 are considered acid
precipitation: note - a pH of 2.4 (the acidity of vinegar) has been measured in
rainfall in New England.
XII
Notes and Definitions (continued)
Aerosol - a collection of airborne particles dispersed in a gas, smoke, or fog.
Afforestation - converting a bare or agricultural space by planting trees and
plants; reforestation involves replanting trees on areas that have been cut or
destroyed by fire.
Asbestos - a naturally occurring soft fibrous mineral commonly used in
fireproofing materials and considered to be highly carcinogenic in particulate form.
Biodiversity - also biological diversity; the relative number of species, diverse
in form and function, at the genetic, organism, community, and ecosystem level;
loss of biodiversity reduces an ecosystem''s ability to recover from natural or
man-induced disruption.
Bio-indicators - a plant or animal species whose presence, abundance, and
health reveal the general condition of its habitat.
Biomass - the total weight or volume of living matter in a given area or volume.
Carbon cycle - the term used to describe the exchange of carbon (in various
forms, e.g., as carbon dioxide) between the atmosphere, ocean, terrestrial
biosphere, and geological deposits.
Catchments - assemblages used to capture and retain rainwater and runoff; an
important water management technique in areas with limited freshwater
resources, such as Gibraltar.
DDT (dichloro-diphenyl-trichloro-ethane) - a colorless, odorless insecticide
that has toxic effects on most animals; the use of DDT was banned in the US in
1972.
Defoliants - chemicals which cause plants to lose their leaves artificially; often
used in agricultural practices for weed control, and may have detrimental impacts
on human and ecosystem health.
Deforestation - the destruction of vast areas of forest (e.g., unsustainable
forestry practices, agricultural and range land clearing, and the over exploitation of
wood products for use as fuel) without planting new growth.
Desertification - the spread of desert-like conditions in arid or semi-arid areas,
due to overgrazing, loss of agriculturally productive soils, or climate change.
Dredging - the practice of deepening an existing waterway; also, a technique
used for collecting bottom-dwelling marine organisms (e.g. , shellfish) or harvesting
coral, often causing significant destruction of reef and ocean-floor ecosystems.
Drift-net fishing - done with a net, miles in extent, that is generally anchored to
a boat and left to float with the tide; often results in an over harvesting and waste
of large populations of non-commercial marine species (by-catch) by ils effect of
"sweeping the ocean clean".
Ecosystems - ecological units comprised of complex communities of
organisms and their specific environments.
Effluents - waste materials, such as smoke, sewage, or industrial waste which
are released into the environment, subsequently polluting it.
Endangered species - a species that is threatened with extinction either by
direct hunting or habitat destruction.
Freshwater - water with very low soluble mineral content; sources include
lakes, streams, rivers, glaciers, and underground aquifers.
Greenhouse gas - a gas that "traps" infrared radiation in the lower atmosphere
causing surface warming; water vapor, carbon dioxide, nitrous oxide, methane,
hydrofluorocarbons, and ozone are the primary greenhouse gases in the Earth''s
atmosphere.
Groundwater - water sources found below the surface of the earth often in
naturally occurring reservoirs in permeable rock strata; the source for wells and
natural springs.
Highlands Water Project - a series of dams constructed jointly by Lesotho and
South Africa to redirect Lesotho''s abundant water supply into a rapidly growing
area in South Africa; while it is the largest infrastructure project in southern Africa,
XIII
Notes and Definitions (continued)
it is also the most costly and controversial; objections to the project include claims
that it forces people from their homes, submerges farmlands, and squanders
economic resources.
Inuit Circumpolar Conference (ICC) - represents the 145,000 Inuits of Russia,
Alaska, Canada, and Greenland in international environmental issues; a General
Assembly convenes every three years to determine the focus of the ICC; the most
current concerns are long-range transport of pollutants, sustainable development,
and climate change.
Metallurgical plants - industries which specialize in the science, technology,
and processing of metals; these plants produce highly concentrated and toxic
wastes which can contribute to pollution of ground water and air when not properly
disposed.
Noxious substances - injurious, very harmful to living beings.
Overgrazing - the grazing of animals on plant material faster than it can
naturally regrow leading to the permanent loss of plant cover, a common effect of
too many animals grazing limited range land.
Ozone shield - a layer of the atmosphere composed of ozone gas (03) that
resides approximately 25 miles above the Earth''s surface and absorbs solar
ultraviolet radiation that can be harmful to living organisms.
Poaching - the illegal killing of animals or fish, a great concern with respect to
endangered or threatened species.
Pollution - the contamination of a healthy environment by man-made waste.
Potable water - water that is drinkable, safe to be consumed.
Salination - the process through which fresh (drinkable) water becomes salt
(undrinkable) water: hence, desalination is the reverse process; also involves the
accumulation of salts in topsoil caused by evaporation of excessive irrigation
water, a process that can eventually render soil incapable of supporting crops.
Siltation - occurs when water channels and reservoirs become clotted with silt
and mud, a side effect of deforestation and soil erosion.
Slash-and-burn agriculture - a rotating cultivation technique in which trees are
cut down and burned in order to clear land for temporary agriculture; the land is
used until its productivity declines at which point a new plot is selected and the
process repeats: this practice is sustainable while population levels are low and
time is permitted for regrowth of natural vegetation; conversely, where these
conditions do not exist, the practice can have disastrous consequences for the','6066365e08fb1e95727f809b24dbbd5ef96925047976a90f9c6374e2b882d344','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71187672428b22499e5491149c812b67376371940f3acba5390e5b3bd6c2da34',2007,'ZW','Zimbabwe','raw',12,'616
Taiwan
619
European Union
622
Page
Appendixes
A: Abbreviations
626
B: International Organizations and Groups
634
C: Selected International Environmental Agreements
661
D: Cross-Reference List of Country Data Codes
669
E: Cross-Reference List of Hydrographic Data Codes
677
F: Cross-Reference List of Geographic Names 678
Notes and Definitions
In addition to the regular information updates, The World Factbook 2006 features
several new or revised fields. In the Economy category, the Factbook is now
reporting national GDP figures in US dollars converted at Official Exchange Rates
(OER) in addition to GDP at Purchasing Power Parity (PPP) rates, since both
measures contain information useful to our readers. Traditionally, only
PPP-converted CDP values had been reported. In the Transportation category,
the former Highways entry is now Roadways, while Ports and harbors has been
retitled Ports and terminals. Revision of some individual country maps, first
introduced in the 2001 edition, is continued in this edition. The revised maps
include elevation extremes and a partial geographic grid. Several regional maps
have also been updated to reflect boundary changes and place name spelling
changes.
Abbreviations: This information is included in Appendix A: Abbreviations,
which includes all abbreviations and acronyms used in the Factbook, with their
expansions.
Acronyms: An acronym is an abbreviation coined from the initial letter of each
successive word in a term or phrase. In general, an acronym made up solely from
the first letter of the major words in the expanded form is rendered in all capital
letters (NATO from North Atlantic Treaty Organization; an exception would be
ASEAN for Association of Southeast Asian Nations). In general, an acronym made
up of more than the first letter of the major words in the expanded form is rendered
with only an initial capital letter (Comsat from Communications Satellite
Corporation; an exception would be NAM from Nonaligned Movement). Hybrid
forms are sometimes used to distinguish between initially identical terms:
WTO for World Trade Organization and WToO for World Tourism Organization.
Administrative divisions: This entry generally gives the numbers, designatory
terms, and first-order administrative divisions as approved by the US Board on
Geographic Names (BGN). Changes that have been reported but not yet acted on
by BGN are noted.
Age structure: This entry provides the distribution of the population according to
age. Information is included by sex and age group (0-14 years, 15-64 years,
65 years and over). The age structure of a population affects a nation''s key
socioeconomic issues. Countries with young populations (high percentage under
age 15) need to invest more in schools, while countries with older populations
(high percentage ages 65 and over) need to invest more in the health sector. The
age structure can also be used to help predict potential political issues. For
example, the rapid growth of a young adult population unable to find employment
can lead to unrest.
Agriculture - products: This entry is an ordered listing of major crops and
products starting with the most important.
Airports: This entry gives the total number of airports. The runway(s) may be
paved (concrete or asphalt surfaces) or unpaved (grass, dirt, sand, or gravel
surfaces), but must be usable. Not all airports have facilities for refueling,
maintenance, or air traffic control.
Airports - with paved runways: This entry gives the total number of airports with
paved runways (concrete or asphalt surfaces) by length. For airports with more
than one runway, only the longest runway is included according to the following five
groups - (1) over 3,047m, (2) 2,438 to 3,047m, (3) 1,524 to 2.437 m, (4) 914 to
1,523 m, and (5) under 914 m. Only airports with usable runways are included in
this listing. Not all airports have facilities for refueling, maintenance, or air traffic
control.
VII
Notes and Definitions (continued)
Airports • with unpaved runways: This entry gives the total number of airports
with unpaved runways (grass, dirt, sand, or gravel surfaces) by length. For airports
with more than one runway, only the longest runway is included according to the
following five groups - (1 ) over 3,047 m, (2) 2.438 to 3.047 m, (3) 1.524 to 2,437
m, (4) 914 to 1,523 m, and (5) under 914 m. Only airports with usable runways are
included in this listing. Not all airports have facilities for refueling, maintenance, or
air traffic control.
Appendixes: This section includes Factooo/c-related material by topic.
Area: This entry includes three subfields. Total area is the sum of all land and
water areas delimited by international boundaries and/or coastlines. Land area is
the aggregate of all surfaces delimited by international boundaries and/or
coastlines, excluding inland water bodies (lakes, reservoirs, rivers). Water area is
the sum of all water surfaces delimited by international boundaries and/or
coastlines, including inland water bodies (lakes, reservoirs, rivers).
Area • comparative: This entry provides an area comparison based on total area
equivalents. Most entities are compared with the entire US or one of the 50 states
based on area measurements (1990 revised) provided by the US Bureau of the
Census. The smaller entities are compared with Washington, DC (178 sq km, 69
sq mi) or The Mall in Washington, DC (0.59 sq km, 0.23 sq mi, 146 acres).
Background: This entry usually highlights major historic events and current
issues and may include a statement about one or two key future trends.
Birth rate: This entry gives the average annual number of births during a year per
1 ,000 persons in the population at midyear; also known as crude birth rate. The
birth rate is usually the dominant factor in determining the rate of population
growth. It depends on both the level of fertility and the age structure of the
population.
Budget: This entry includes revenues, expenditures, and capital expenditures.
These figures are calculated on an exchange rate basis, i.e., not in purchasing
power parity (PPP) terms.
Capital: This entry gives the location of the seat of government.
Climate: This entry includes a brief description of typical weather regimes
throughout the year.
Coastline: This entry gives the total length of the boundary between the land area
(including islands) and the sea.
Communications: This category deals with the means of exchanging information
and includes the telephone, radio, television, and Internet host entries.
Communications - note: This entry includes miscellaneous communications
information of significance not included elsewhere.
Constitution: This entry includes the dates of adoption, revisions, and major
amendments.
Country data codes: see Data codes
VIII
Notes and Definitions (continued)
Country map: Most versions of the Factbook provide a country map in color. The
maps were produced from the best information available at the time of preparation.
Names and/or boundaries may have changed subsequently.
Country name: This entry includes all forms of the country''s name approved by
the US Board on Geographic Names (Italy is used as an example): conventional
long form (Italian Republic), conventional short form (Italy), local long form
(Repubblica Italiana), local short form (Italia), former (Kingdom of Italy), as well as
the abbreviation. Also see the Terminology note.
Crude oil: See entry for oil.
Currency (code): This entry identifies the national medium of exchange and, in
parenthesis, gives the International Organization for Standardization (ISO) 4217
alphabetic currency code for each country.
Current account balance: This entry records a country''s net trade in goods and
services, plus net earnings from rents, interest, profits, and dividends, and net
transfer payments (such as pension funds and worker remittances) to and from the
rest of the world during the period specified. These figures are calculated on an
exchange rate basis, i.e., not in purchasing power parity (PPP) terms.
Data codes: This information is presented in Appendix D: Cross-Reference List
of Country Data Codes and Appendix E: Cross-Reference List of
Hydro-graphic Data Codes.
Date of information: In general, information available as of 1 January 2006, was
used in the preparation of this edition.
Death rate: This entry gives the average annual number of deaths during a year
per 1 ,000 population at midyear; also known as crude death rate. The death rate,
while only a rough indicator of the mortality situation in a country, accurately
indicates the current mortality impact on population growth. This indicator is
significantly affected by age distribution, and most countries will eventually show a
rise in the overall death rate, in spite of continued decline in mortality at all ages,
as declining fertility results in an aging population.
Debt - external: This entry gives the total public and private debt owed to
nonresidents repayable in foreign currency, goods, or services. These figures are
calculated on an exchange rate basis, i.e., not in purchasing power parity (PPP)
terms.
Dependency status: This entry describes the formal relationship between a
particular nonindependent entity and an independent state.
Dependent areas: This entry contains an alphabetical listing of all
nonindependent entities associated in some way with a particular independent
state.
Diplomatic representation: The US Government has diplomatic relations with
187 independent states, including 186 of the 191 UN members (excluded UN
members are Bhutan, Cuba, Iran, North Korea, and the US itself). In addition, the
US has diplomatic relations with 1 independent state that is not in the UN. the Holy
See, as well as with the EU.
Diplomatic representation from the US: This entry includes the chief of mission,
embassy address, mailing address, telephone number, FAX number, branch office
locations, consulate general locations, and consulate locations.
Notes and Definitions (continued)
Diplomatic representation in the US: This entry includes the chief of mission,
chancery, telephone, FAX, consulate general locations, and consulate locations.
Disputes - international: This entry includes a wide variety of situations that
range from traditional bilateral boundary disputes to unilateral claims of one sort
or another. Information regarding disputes over international terrestrial and
maritime boundaries has been reviewed by the US Department of State.
References to other situations involving borders or frontiers may also be included,
such as resource disputes, geopolitical questions, or irredentist issues; however,
inclusion does not necessarily constitute official acceptance or recognition by the
US Government.
Distribution of family income - Gini index: This index measures the degree of
inequality in the distribution of family income in a country. The index is calculated
from the Lorenz curve, in which cumulative family income is plotted against the
number of families arranged from the poorest to the richest. The index is the ratio
of (a) the area between a country''s Lorenz curve and the 45 degree helping line to
(b) the entire triangular area under the 45 degree line. The more nearly equal a
country''s income distribution, the closer its Lorenz curve to the 45 degree line and
the lower its Gini index, e.g., a Scandinavian country with an index of 25. The more
unequal a country''s income distribution, the farther its Lorenz curve from the 45
degree line and the higher its Gini index, e.g., a Sub-Saharan country with an index
of 50. If income were distributed with perfect equality, the Lorenz curve would
coincide with the 45 degree line and the index would be zero; if income were
distributed with perfect inequality, the Lorenz curve would coincide with the
horizontal axis and the right vertical axis and the index would be 100.
Economic aid - donor: This entry refers to net official development assistance
(ODA) from Organization for Economic Cooperation and Development (OECD)
nations to developing countries and multilateral organizations. ODA is defined as
financial assistance that is concessional in character, has the main objective to
promote economic development and welfare of the less developed countries
(LDCs). and contains a grant element of at least 25V The entry does not cover
other official flows (OOF) or private flows. These figures are calculated on an
exchange rate basis, i.e., not in purchasing power parity (PPP) terms.
Economic aid - recipient: This entry, which is subject to major problems of
definition and statistical coverage, refers to the net inflow of Official Development
Finance (ODF) to recipient countries. The figure includes assistance from the
World Bank, the IMF, and other international organizations and from individual
nation donors. Formal commitments of aid are included in the data. Omitted from
the data are grants by private organizations. Aid comes in various forms including
outright grants and loans. The entry thus is the difference between new inflows and
repayments. These figures are calculated on an exchange rate basis, i.e., not in
purchasing power parity (PPP) terms.
Economy: This category includes the entries dealing with the size, development,
and management of productive resources, i.e., land, labor, and capital.
Economy - overview: This entry briefly describes the type of economy, including
the degree of market orientation, the level of economic development, the most
important natural resources, and the unique areas of specialization. It also
characterizes major economic events and policy changes in the most recent 12
months and may include a statement about one or two key future macroeconomic
trends.
Notes and Definitions (continued)
Electricity - consumption: This entry consists of total electricity generated
annually plus imports and minus exports, expressed in kilowatt-hours. The
discrepancy between the amount of electricity generated and/or imported and the
amount consumed and/or exported is accounted for as loss in transmission and
distribution.
Electricity - exports: This entry is the total exported electricity in kilowatt-hours.
Electricity - imports: This entry is the total imported electricity in kilowatt-hours.
Electricity - production: This entry is the annual electricity generated expressed
in kilowatt-hours. The discrepancy between the amount of electricity generated
and/or imported and the amount consumed and/or exported is accounted for as
loss in transmission and distribution.
Elevation extremes: This entry includes both the highest point and the lowest
point.
Entities: Some of the independent states, dependencies, areas of special
sovereignty, and governments included in this publication are not independent,
and others are not officially recognized by the US Government. "Independent
state" refers to a people politically organized into a sovereign state with a definite
territory. "Dependencies" and "areas of special sovereignty" refer to a broad
category of political entities that are associated in some way with an independent
state. "Country" names used in the table of contents or for page headings are
usually the short-form names as approved by the US Board on Geographic Names
and may include independent states, dependencies, and areas of special
sovereignty, or other geographic entities. There are a total of 271 separate
geographic entities in The World Factbook that may be categorized as follows:
INDEPENDENT STATES
192 Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina
Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica.
Cote d''lvoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, East Timor, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon.
The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Holy See, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein,
Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger.
Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Serbia and Montenegro, Seychelles, Sierra Leone, Singapore,
XI
Notes and Definitions (continued)
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri
Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
OTHER
2 Taiwan, European Union
DEPENDENCIES AND AREAS OF SPECIAL SOVEREIGNTY
6 Australia - Ashmore and Cartier Islands, Christmas Island, Cocos (Keeling)
Islands, Coral Sea Islands, Heard Island and McDonald Islands, Norfolk
Island
2 China - Hong Kong, Macau
2 Denmark - Faroe Islands. Greenland
16 France - Bassas da India, Clipperton Island, Europa Island, French
Guiana. French Polynesia, French Southern and Antarctic Lands, Glorioso
Islands, Guadeloupe. Juan de Nova Island. Martinique, Mayotte, New
Caledonia, Reunion, Saint Pierre and Miquelon, Tromelin Island, Wallis
and Futuna
2 Netherlands - Aruba, Netherlands Antilles
3 New Zealand - Cook Islands, Niue, Tokelau
3 Norway - Bouvet Island. Jan Mayen, Svalbard
17 UK - Akrotiri, Anguilla, Bermuda, British Indian Ocean Territory, British
Virgin Islands, Cayman Islands, Dhekelia. Falkland Islands. Gibraltar,
Guernsey, Isle of Man. Jersey, Montserrat, Pitcairn Islands, Saint Helena,
South Georgia and the South Sandwich Islands, Turks and Caicos Islands
14 US - American Samoa, Baker Island*, Guam, Howland Island*, Jarvis
Island*, Johnston Atoll*, Kingman Reef*. Midway Islands*, Navassa Island,
Northern Mariana Islands, Palmyra Atoll*. Puerto Rico, Virgin Islands,
Wake Island (* consolidated in United States Pacific Island Wildlife Refuges
entry)
MISCELLANEOUS
6 Antarctica. Gaza Strip. Paracel Islands. Spratly Islands, West Bank,','dc9359f1a2def3547a038dc25d395839e82aacc4245c722e6faaa219e1a566fc','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62109e8cc62089c75b876f56a1f9c6d5bcdf4f4b4cb401f407979deaacfaa5df',2007,'','','raw',1,'The Project Gutenberg EBook of The 2007 CIA World Factbook, by United States
This eBook is for the use of anyone anywhere at no cost and with
almost no restrictions whatsoever. You may copy it, give it away or
re-use it under the terms of the Project Gutenberg License included
with this eBook or online at www.gutenberg.net
Title: The 2007 CIA World Factbook
Author: United States
Release Date: December 11, 2008 [EBook #27348]
Language: English
Character set encoding: ASCII
*** START OF THIS PROJECT GUTENBERG EBOOK THE 2007 CIA WORLD FACTBOOK ***
Produced by Al Haines
THE CIA WORLD FACTBOOK 2007
CONTENTS
Countries and Locations
Field Listings
Rank Orders
Appendixes
Notes and Definitions
History of the World Factbook
Contributors and Copyright Information
Purchasing Information
Frequently Asked Questions (FAQs)
======================================================================
What''s New
- Country information has been updated as of 8 February 2007.
- In the Government category, the "Capital" entry has been greatly
expanded and now contains up to four subfields, including significant
new information having to do with time. The subfields consist of the
name of the capital itself, its geographic coordinates, the time
difference at the capital from coordinated universal time (UTC), and,
if applicable, information on daylight saving time (DST). Where
appropriate, a special note has been added to highlight those
countries that have multiple time zones.
- The Transnational issues category now has a "Trafficking in persons"
entry. Human trafficking connotes modern-day slavery and this important
new field will include information on the most egregious countries
(Tier 2 Watch List and Tier 3) as listed in the US State Department''s
annual report.
- A new Appendix G lists Weights and Measures. The appendix includes
information on mathematical notation and metric interrelationships, as
well as over 400 examples of standard conversion factors.
-Revision of some individual country maps, first introduced in the 2001
edition, is continued in this edition. Several regional maps have also
been updated to reflect boundary changes and place name spelling changes.
======================================================================
The World Factbook (2007) - Country Listing
[Transcriber''s note: To search on a country in this file, prefix the
country''s name with "@", e.g. "@Afghanistan". "Afghanistan" will find
all occurrences; prefixing it with "@" will find the correct location.]
World
A','6a7f4781b91d70339a8caa7d88f3d27f62e774a1f75753c4ed16ca0f6d453df5','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b5218ed4b5477d9d6f0f2cd243ee549e246376a2385caea78e72b0e4ea7cdbb1',2007,'ET','Ethiopia','raw',2,'Europa Island description under Iles Eparses
European Union entry follows Taiwan
F
Falkland Islands (Islas Malvinas)','27ce6aee547b39ed9d1262d137208c1a9a2520093969d8f16694fea59bce1aa6','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68008e35b0907c9a8eb64a22c140c1a2e234d3a0fbfc0ce2280a15f6990d71f6',2007,'FM','Micronesia, Federated States of','raw',3,'Midway Islands description under United States Pacific Island Wildlife Refuges
Moldova','11c0f19bc8fff35dddf05d93f6b7f9f4f005e64731aac019bbf520aac4209331','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89220d1a38430985a042b14cd57da4a9b66c8135c3973b03c8459b1d9da62baf',2007,'ZW','Zimbabwe','raw',4,'Taiwan
European Union
=====================================================================
Field Listings
[Transcriber''s note: To search on a field code in this file, prefix
the code number with "@", e.g. "@2001". "2001" will find all
occurrences; prefixing it with "@" will find the correct location.]
Code Field Description
2001 GDP (purchasing power parity)
2002 Population growth rate
2003 GDP - real growth rate
2004 GDP - per capita (PPP)
2006 Dependency status
2007 Diplomatic representation from the US
2008 Transportation - note
2010 Age structure
2011 Geographic coordinates
2012 GDP - composition by sector
2013 Radio broadcast stations
2015 Television broadcast stations
2018 Sex ratio
2019 Heliports
2020 Elevation extremes
2021 Natural hazards
2022 People - note
2023 Area - comparative
2024 Military service age and obligation
2025 Manpower fit for military service
2026 Manpower reaching military service age annually
2028 Background
2030 Airports - with paved runways
2031 Airports - with unpaved runways
2032 Environment - current issues
2033 Environment - international agreements
2034 Military expenditures - percent of GDP
2038 Electricity - production
2042 Electricity - consumption
2043 Electricity - imports
2044 Electricity - exports
2046 Population below poverty line
2047 Household income or consumption by percentage share
2048 Labor force - by occupation
2049 Exports - commodities
2050 Exports - partners
2051 Administrative divisions
2052 Agriculture - products
2053 Airports
2054 Birth rate
2055 Military branches
2056 Budget
2057 Capital
2058 Imports - commodities
2059 Climate
2060 Coastline
2061 Imports - partners
2062 Economic aid - donor
2063 Constitution
2064 Economic aid - recipient
2065 Currency (code)
2066 Death rate
2068 Dependent areas
2070 Disputes - international
2075 Ethnic groups
2076 Exchange rates
2077 Executive branch
2078 Exports
2079 Debt - external
2080 Fiscal year
2081 Flag description
2085 Roadways
2086 Illicit drugs
2087 Imports
2088 Independence
2089 Industrial production growth rate
2090 Industries
2091 Infant mortality rate
2092 Inflation rate (consumer prices)
2093 Waterways
2094 Judicial branch
2095 Labor force
2096 Land boundaries
2097 Land use
2098 Languages
2100 Legal system
2101 Legislative branch
2102 Life expectancy at birth
2103 Literacy
2105 Manpower available for military service
2106 Maritime claims
2107 International organization participation
2108 Merchant marine
2109 National holiday
2110 Nationality
2111 Natural resources
2112 Net migration rate
2113 Geography - note
2115 Political pressure groups and leaders
2116 Economy - overview
2117 Pipelines
2118 Political parties and leaders
2119 Population
2120 Ports and terminals
2121 Railways
2122 Religions
2123 Suffrage
2124 Telephone system
2125 Terrain
2127 Total fertility rate
2128 Government type
2129 Unemployment rate
2137 Military - note
2138 Communications - note
2140 Government - note
2142 Country name
2144 Location
2145 Map references
2146 Irrigated land
2147 Area
2149 Diplomatic representation in the US
2150 Telephones - main lines in use
2151 Telephones - mobile cellular
2153 Internet users
2154 Internet country code
2155 HIV/AIDS - adult prevalence rate
2156 HIV/AIDS - people living with HIV/AIDS
2157 HIV/AIDS - deaths
2172 Distribution of family income - Gini index
2173 Oil - production
2174 Oil - consumption
2175 Oil - imports
2176 Oil - exports
2177 Median age
2178 Oil - proved reserves
2179 Natural gas - proved reserves
2180 Natural gas - production
2181 Natural gas - consumption
2182 Natural gas - imports
2183 Natural gas - exports
2184 Internet hosts
2185 Investment (gross fixed)
2186 Public debt
2187 Current account balance
2188 Reserves of foreign exchange and gold
2193 Major infectious diseases
2194 Refugees and internally displaced persons
2195 GDP (official exchange rate)
2196 Trafficking in persons
=====================================================================
Rank Orders
[Transcriber''s note: To search on a rank order in this file, prefix
the rank''s name with "@", e.g. "@Population". "Population" will find
all occurrences; prefixing it with "@" will find the correct location.]
Rank Order pages are presorted lists of data from selected Factbook
data fields. Rank Order pages are generally given in descending order -
highest to lowest - such as Population and Area. The two exceptions are
Unemployment Rate and Inflation Rate, which are in ascending - lowest
to highest - order. Rank Order pages are available for the following 47
fields in six of the nine Factbook categories.','8c17be2718a2db26e6364e5714e4d339f1c2d5581b7ae8c4a9193b991cff5a74','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

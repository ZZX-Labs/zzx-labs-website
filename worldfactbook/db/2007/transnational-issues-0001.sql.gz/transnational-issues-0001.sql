SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef043137145347ce10d491956a7dcf6542e00010807fe46cee56f66aa6b34dfc',2007,'EH','Western Sahara','transnational-issues',22,'Disputes - international
Refugees and internally displaced persons
refugees (country of origin)
IDPs
Illicit drugs
XXXV
World
Disputes - international: stretching over 250,000
km, the world''s 325 international land boundaries
separate the 1 92 independent states and 73
dependencies, areas of special sovereignty, and other
miscellaneous entities; ethnicity, culture, race,
religion, and language have divided states into
separate political entities as much as history, physical
terrain, political fiat, or conquest, resulting in
sometimes arbitrary and imposed boundaries;
maritime states have claimed limits and have so far
established over 130 maritime boundaries and joint
development zones to allocate ocean resources and
to provide for national security at sea; boundary,
borderland/resource, and territorial disputes vary in
intensity from managed or dormant to violent or
militarized; most disputes over the alignment of
political boundaries are confined to short segments
and are today less common and less hostile than
borderland, resource, and territorial disputes;
undemarcated, indefinite, porous, and unmanaged
boundaries, however, encourage illegal cross-border
activities, uncontrolled migration, and confrontation;
territorial disputes may evolve from historical and/or
cultural claims, or they may be brought on by resource
competition; ethnic and cultural clashes continue to be
responsible for much of the territorial fragmentation
around the world; disputes over islanos at sea or in
rivers frequently form the source of territorial and
boundary conflict; other sources of contention include
access to water and mineral (especially petroleum)
resources, fisheries, and arable land; nonetheless,
most nations cooperate to clarify their international
boundaries and to resolve territorial and resource
disputes peacefully; regional discord today prevails
not so much between the armed forces of
independent states as between stateless armed
entities that detract from the sustenance and welfare
of local populations, leaving the community of nations
to cope with resultant refugees, hunger, disease,
impoverishment, and environmental degradation
Refugees and internally displaced persons: the
United Nations High Commissioner for Refugees
(UNHCR) estimated that in December 2004 there was
a global population of 9.2 million refugees, the lowest
number in 25 years, and as many as 25 million IDPs
in over 49 countries (2005)
Illicit drugs:
cocaine: worldwide coca cultivation in 2004 amounted
to 166,200 hectares; Colombia produced slightly more
than two-thirds of the worldwide crop, followed by
Peru and Bolivia; potential pure cocaine production of
645 metric tons in 2004 marked the lowest level of
Andean cocaine production in the past 1 0 years;
Colombia conducts aggressive coca eradication
campaign, but both Peruvian and Bolivian
Governments are hesitant to eradicate coca in key
growing areas; 376 metric tons of export-quality
cocaine are documented to have been seized in 2003,
and 26 metric tons disrupted (jettisoned or destroyed) ;
consumption of export quality cocaine is estimated to
have been 800 metric tons
opiates: worldwide illicit opium poppy cultivation
reached 258,630 hectares in 2004; potential opium
production of 5,444 metric tons was highest total
recorded since estimates began in mid-1980s;
Afghanistan is world''s primary opium producer,
accounting for 91% of the global supply; Southeast
Asia - responsible for 7% of global opium - continued
to diminish in importance in the world opium market;
Latin America produced 2% of global opium, but most
refined into heroin destined for United States; if all
opium processed into pure heroin, the potential global
production would be 632 metric tons of heroin in 2004
/
Canary Islands Jp
Cabo Bojador
North
Atlantic
Ocean
another term for those less developed countries with below-average per capita GDPs; see less developed countries
(LDCs)
another term for those less developed countries with above-average per capita GDPs; see less developed countries
(LDCs)
members— (166) includes all UN member countries except Andorra, Bhutan, Brunei, Burma, Comoros, Cuba,
Djibouti, Guinea-Bissau, Iraq, Kirabati. North Korea, Liberia. Liechtenstein, Maldives, Marshall Islands, Mexico,
Monaco, Nauru, NZ, Niger, San Marino, Sao Tome and Principe, Somalia, Tonga, Tuvalu
Near Abroad Russian term for the 1 4 non-Russian successor states of the USSR, in which 25 million ethnic Russians live and in
which Moscow has expressed a strong national security interest; the 14 countries are Armenia, Azerbaijan, Belarus.
Estonia, Georgia, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Moldova, Tajikistan, Turkmenistan, Ukraine,
Wl
EH
ESH
732
.eh
Western Samoa
—
—
—
—
• .ws
see Samoa
The Factbook uses the W data code
from DIAM 65-18 Geopolitical Data
Elements and Related Features, Data
Standard No. 3, December 1994,
published by the Defense Intelligence
Agency
34 02N
00 N
16 47N
27 07S
9 00N
20 00N
16 55N
19 00N
7 00N
46 00N
100S
2 00S
8 00N
55 35N
19 00N
64 09N
3610N
20 00S
15 00S
20 00S
56 57N
57 30N
35 00S
23 45N
6 51 W
167 00 E
96 10E
109 22 W
171 00 E
38 00E
62 19W
70 40W
2100E
2 00E
11 45 E
30 00E
1 10E
131 06 W
112 45W
21 57 W
28 00E
30 00E
30 00E
30 00E
24 06E
23 30E
59 00W
15 45W
700
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Rio Muni (mainland region)
24 30N
13 00W
Spanish West Africa (former name for Ifni and Spanish
Sahara)
Morocco. Western Sahara
25 00N
13 00W
Spice Islands (Moluccas)','79930e1d80feed4a50e790be73c1655db30574611dc6ba69f745bb3e7c92f1be','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcdcae6f86966bb3e8f72d6eec614643904b410e135ea513782a0e32a2fea450',2007,'AF','Afghanistan','transnational-issues',25,'Background: Ahmad Shah DURRANI unified the
Pashtun tribes and ''ounded Afghanistan in 1747. The
country served as a buffer between the British and
Russian empires until it won independence from
notional British control in 1919. A brief experiment in
democracy ended in a 1973 coup and a 1978
Communist counter-coup. The Soviet Union invaded
in 1979 to support the tottering Afghan Communist
regime, but withdrew 10 years later under relentless
pressure by internationally supported anti-Communist
mujahedin rebels. A civil war between mujahedin
factions erupted following the 1992 fall of the
Communist regime. The Taliban, a hardline
Pakistani-sponsored movement that emerged in 1 994
to end the country''s civil war and anarchy, seized
Kabul in 1996 and most of the country outside of
opposition Northern Alliance strongholds by 1998.
Following the 1 1 September 2001 terrorist attacks, a
US, Allied, and Northern Alliance military action
toppled the Taliban for sheltering Osama BIN LADIN
In late 2001, a conference in Bonn, Germany,
established a process for political reconstruction that
included the adoption of a new constitution and a
presidential election in 2004, and National Assembly
elections in 2005. On 7 December 2004, Hamid
KARZAI became the first democratically elected
president of Afghanistan. The National Assembly was
inaugurated on 19 December 2005.
Disputes - international: most Afghan refugees in
Pakistan have been repatriated, but thousands still
remain in Iran, many at their own choosing; Coalition
and Pakistani forces continue to patrol remote tribal
areas to control the borders and stem organized
terrorist and other illegal cross-border activities;
regular meetings between Pakistani and Coalition
allies aim to resolve periodic claims of boundary
encroachments; regional conflicts over water-sharing
arrangements with Amu Darya and Helmand River
states
Refugees and internally displaced persons:
IDPs: 200,000-300,000 (mostly Pashtuns and Kuchis
displaced in south and west due to drought and
instability) (2005)
Illicit drugs: world''s largest producer of opium;
cultivation dropped 48% to 107,400 hectares in 2005;
better weather and lack of widespread disease
returned opium yields to normal levels, meaning
potential opium production declined by only 10% to
4,475 metric tons; if the entire poppy crop were
processed, it is estimated that 526 metric tons of
heroin could be processed; source of hashish; many
narcotics-processing labs throughout the country;
drug trade source of instability and some
antigovernment groups profit from the trade; 80-90%
of the heroin consumed in Europe comes from Afghan
opium; vulnerable to narcotics money laundering
through informal financial networks
Akrotiri
^sJL^I
(UK sovereign
base area)
^rd
0 3 6 km
j
33 OO
0 3 6 ml
Disputes - international: have received Haitians
fleeing economic and civil disorder
Illicit drugs: transshipment point for South American
narcotics destined for the US and Europe
567
AF
AF
AFG
004
.af
33 00N
65 00E
Agalega Islands
Kaduna (city)
37 00N
73 00E
Valletta (capital)
Walachia (region)','08ea67f483263ff0281e93ae81a8aa2be24e484f8a64acbc7474f97e7fc3097e','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cac652ee83b87c69c8355f47403690401951319e229f1279dbde6b7784f630c0',2007,'CY','Cyprus','transnational-issues',33,'V
) >
Area controlled by
Cyprus Governmen
(Greek Cypnol area
*~dam
/ • ^.
{ .
Limassolx^^^
l~ Episkopi \\_
| Cantonment
) s
""1 y
rvj /
Akrotiri
J/&\\ 1 Akrotiri
i Bay
Capey
Zevgaii
airfield capa
.. ''Gsta
Mediterranean Sea
Gov
e r n m e
Mediterranean Sea
Kyrenia
UN buffer zone Turkish Cypnot-administered area
/3l -Morptl^ .AJICOSIA
Famagusta. UNbutf8rzone
A '' Larnaca
Area controlled by Cyprus Government
(Greek Cypriot area
, Paphos
V, K Vasilikos^
^-^Umassol
^Dhekelia
Sovereign Base Area
(U.K.)
Mediterranean Sea
Akrotiri
- Sovereign Base Area
(U.K.)
33''3CT
•J
Disputes - international: hostilities in 1974 divided
the island into two de facto autonomous entities, the
internationally recognized Cypriot Government and a
Turkish-Cypriot community (north Cyprus); the
1,000-strong UN Peacekeeping Force in Cyprus
(UNFICYP) has served in Cyprus since 1964 and
maintains the buffer zone between north and south;
March 2003 reunification talks failed, but
Turkish-Cypriots later opened their borders to
temporary visits by Greek Cypriots; on 24 April 2004,
the Greek Cypriot and Turkish Cypriot communities
voted in simultaneous and parallel referenda on
whether to approve the UN-brokered Annan Plan that
would have ended the 30-year division of the island by
establishing a new "United Cyprus Republic," a
majority of Greek Cypriots voted "no"; on 1 May 2004,
Cyprus entered the European Union still divided, with
the EU''s body of legislation and standards (acquis
communitaire) suspended in the north
Refugees and internally displaced persons:
IDPs: 265,000 (both Turkish and Greek Cypriots;
many displaced for over 30 years) (2005)
Illicit drugs: minor transit point for heroin and
hashish via air routes and container traffic to Europe,
especially from Lebanon and Turkey; some cocaine
transits as well; despite a strengthening of
anti-money-laundering legislation, remains vulnerable
to money laundering; reporting of suspicious
transactions in offshore sector remains weak
Czech Republic
Disputes - international: in February 2005, the ICJ
refused to rule on the restitution of Liechtenstein''s
land and property assets in the Czech Republic
confiscated in 1945 as German property; individual
Sudeten Germans seek restitution for property
confiscated in connection with their expulsion from
Czechoslovakia after World War II; Austrian
anti-nuclear activists have revived blockades of the
Czech-Austrian border to protest operation of the
Temelin nuclear power plant in the Czech Republic
Illicit drugs: transshipment point for Southwest
Asian heroin and minor transit point for Latin American
cocaine to Western Europe; producer of synthetic
drugs for local and regional markets; susceptible to
money laundering related to drug trafficking,
organized crime
154
CY
CY
CYP
196
•cy
Czech Republic
EZ
CZ
CZE
203
.CZ
35 00N
33 00E
Kiel Canal (Nord-Ostsee Kanal)
Atlantic Ocean
53 53N
9 08E
Kiev (capital)
35 00N
33 00E
Kirghiziya (former name for Kyrgyzstan)
3510N
33 22E
Nightingale Island
Saint Helena
37 25S
12 30W
Nihon (local name for Japan)
Northern Epirus (region)
Albania, Greece
Northern Grenadines (political region)','3d9e788627624f240d0cf4a2ed165d9c0bc9e8babe9ed9ba6dde7283a254bae5','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f9ca3a2fe96f4bc23ea166692b12b601a809c39939dfcb66e31abe41dc16fc7',2007,'AL','Albania','transnational-issues',42,'Disputes • international: the Albanian Government
calls for the protection of the rights of ethnic Albanians
in neighboring countries, and the peaceful resolution
of interethnic disputes; some ethnic Albanian groups
in neighboring countries advocate for a "greater
Albania," but the idea has little appeal among
Albanian nationals; thousands of unemployed
Albanians emigrate annually to nearby Italy and other
developed countries
Illicit drugs: increasingly active transshipment point
for Southwest Asian opiates, hashish, and cannabis
transiting the Balkan route and - to a far lesser extent -
cocaine from South America destined for Western
Europe; limited opium and growing cannabis
production; ethnic Albanian narcotrafficking
organizations active and expanding in Europe;
vulnerable to money laundering associated with
regional trafficking in narcotics, arms, contraband, and
illegal aliens
AL
AL
ALB
008
.al
4100N
20 00E
Siam (former name for Thailand)
4120N
19 50E
Tirane (see Tirana)
41 20 N
19 50E
Tirol (region)
Austria, Italy
47 00N
11 00 E
Tobago (island)','c62fd9416166ba2df2eeb4b3f58428e6b34c3d15ad17cc128a21ef865566cc8b','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b280447329a653ee55805cb828fd55ee9c18408de2945cb8fc71421c6ffdc27',2007,'DZ','Algeria','transnational-issues',43,'E
PORT
NORTH
NORTH
Atlantic western
.Bir MoghreTn
ocean Sahara
/
V"
>uerat
ediet i/iil
VA
h
5
h
A"
IMALI
Nouadhibou
Atar
„ SeDktta Te*>- #Tidjikdja
Dghamctta
NOUAKCHOTT
Rosso. Boaue Kiffa
J '' r \\. Kaedi
.Nema \\
1
SENEGAL S.
$ °
100
200 km
T 6
100 200 mi
NORTH paftondeVatez Melilla ''.
iondeN. 100 200 km
MOR.
■^ * ISLAS CMAFARINAS (I
PeftondeS. o 10
Alhucemas £ i — •— >
-i . { 0
100
ZOO mi
Disputes - international: in 2003, Gibraltar
residents voted overwhelmingly by referendum to
remain a British colony and against a "total shared
sovereignty" arrangement while demanding
participation in talks between the UK and Spain; Spain
disapproves of UK plans to grant Gibraltar greater
autonomy; Morocco protests Spain''s control over the
coastal enclaves of Ceuta, Melilla. and the islands of
Penon de Velez de la Gomera, Penon de Alhucemas
and Islas Chafarinas, and surrounding waters;
Morocco serves as the primary launching site of illegal
migration into Spain from North Africa; Portugal does
not recognize Spanish sovereignty over the territory of
Olivenza based on a difference of interpretation of the
1815 Congress of Vienna and the 1 801 Treaty of
Badajoz
Illicit drugs; key European gateway country and
consumer for Latin American cocaine and North
African hashish entering the European market;
destination and minor transshipment point for
Southwest Asian heroin; money-laundering site for
Colombian narcotics trafficking organizations and
organized crime
Spratly Islands
Northeast Cay
Southwest Cay— j»
South
AG
DZ
DZA
012
.dz
28 00N
3 00E
Al Kuwayt (local name for Kuwait)
36 47N
2 03E
Alhucemas, Penon de (island group)
Orange River Colony (region; former name of Free State
Province of South Africa)','c1a842a39371c83258063404f4bb1644aca8e5244fb343fcf0eedafb423a81b6','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('298e816ba0c38036cf9fc17d5d03bf04e07e9fd816ec223203cbc4e8c07d4df4',2007,'ES','Spain','transnational-issues',44,'r° P73 —
Mediterranean Sea
''ALGIERS Ann^a^, .
„ X Orar^ " Setif-'' ''corfstantinfi
Atlantic I V___* ,''. Batna* »
TlemceV sA^!^el Biskra* v / /''
Abb6s chon(Tm.-z
Meimir ''
Qf
n t r o d u c t i o n
Background: After more than a century of rule by
France, Algerians fought through much of the 1950s
to achieve independence in 1962. Algeria''s primary
political party, the National Liberation Front (FLN), has
dominated politics ever since. Many Algerians in the
subsequent generation were not satisfied, however,
and moved to counter the FLN''s centrality in Algerian
politics. The surprising first round success of the
Islamic Salvation Front (FIS) in the December 1991
balloting spurred the Algerian army to intervene and
postpone the second round of elections to prevent
what the secular elite feared would be an
extremist-led government from assuming power. The
army began a crack down on the FIS that spurred FIS
supporters to begin attacking government targets. The
government later allowed elections featuring
pro-government and moderate religious-based
parties, but did not appease the activists who
progressively widened their attacks. The fighting
escalated into an insurgency, which saw intense
fighting between 1992-98 and which resulted in over
100,000 deaths - many attributed to indiscriminate
massacres of villagers by extremists. The government
gained the upper hand by the late-1990s and FIS''s
armed wing, the Islamic Salvation Army, disbanded in
January 2000. However, small numbers of armed
militants persist in confronting government forces and
conducting ambushes and occasional attacks on
villages. The army placed Abdelaziz BOUTEFLIKA in
the presidency in 1999 in a fraudulent election but
claimed neutrality in his 2004 landslide reelection
victory. Longstanding problems continue to face
BOUTEFLIKA in his second term, including the ethnic
minority Berbers'' ongoing autonomy campaign,
large-scale unemployment, a shortage of housing,
unreliable electrical and water supplies, government
inefficiencies and corruption, and the continuing -
although significantly degraded - activities of extremist
militants. Algeria must also diversify its
petroleum-based economy, which has yielded a large
cash reserve but which has not been used to redress
Algeria''s many social and infrastructure problems.
Disputes - international: Algeria supports the
exiled Sahrawi Polisario Front and rejects Moroccan
administration of Western Sahara; Algeria''s border
with Morocco remains an irritant to bilateral relations;
each nation has accused the other of harboring
militants and arms smuggling; in an attempt to
improve relations after unilaterally imposing a visa
requirement on Algerians in the early 1990s, Morocco
lifted the requirement in mid-2004 - a gesture not
reciprocated by Algeria; Algeria remains concerned
about armed bandits operating throughout the Sahel
who sometimes destabilize southern Algerian towns;
dormant disputes include Libyan claims of about
32,000 sq km still reflected on its maps of
southeastern Algeria and the FLN''s assertions of a
claim to Chirac Pastures in southeastern Morocco
Refugees and internally displaced persons:
refugees (country of origin): 102,000 (Western
Saharan Sahrawi, mostly living in Algerian-sponsored
camps in the southwestern Algerian town of Tindouf)
IDPs: 400,000-600,000 (conflict between government
forces, Islamic insurgents) (2005)
O 5 10 km
O 5 10 ml
Disputes - international: none
0 100 200 km
Corsica
(FR) •;.
Mediterranean Sea >£.
NORTH
ATLANTIC
OCEAN
■
- .Ceuta (SP.)
Tangier* .Tetouan
Melilla (SP.f '' V
RABAT/enitra.F6s °Uida}
Casablanca.., ''Meknes K
t Mohammedia
El Jadida
Jabel
Toubkal
Marrakech
%l_eixoes
NORTH >orto
ATLANTIC
OCEAN ...Aveiro .V''seu
0 20 40 mi
Azores and Madeira Islands
are not shown
Disputes - international: Antarctic Treaty defers
claims (see Antarctica entry), but Argentina, Australia,
Chile, France, NZ, Norway, and UK assert claims
(some overlapping), including the continental shelf in
the Southern Ocean; several states have expressed
an interest in extending those continental shelf claims
under the United Nations Convention on the Law of
the Sea (UNCLOS) to include undersea ridges; the
US and most other states do not recognize the land or
maritime claims of other states and have made no
claims themselves (the US and Russia have reserved
the right to do so); no formal claims exist in the waters
in the sector between 90 degrees west and 1 50
degrees west
Canary islands are not shown.
Bay
Spratly Islands
3513N
3 53W
Alma-Ata (city; former name for Almaty)
39 30N
3 00E
Balearic Sea (Iberian Sea)
Atlantic Ocean
40 30N
2 00E
Bali (island)
43 00N
2 30W
Bass Strait
Pacific Ocean
39 20S
145 30 E
Basseterre (capital)
4315N
2 58W
Bioko (island)
Canberra (capital)
42 00N
2 00E
Cato Island
35 53N
519W
Ceylon (former name for Sri Lanka)
3512N
2 26W
Chagos Archipelago (Oil Islands)
40 00N
4 00W
Essequibo (region; claimed by Venezuela)
42 45N
810E
Galilee (region)
40 24N
3 41W
Magellan, Strait of
Atlantic Ocean
54 00S
7100W
Maghreb (region)
Algeria, Libya. Mauritania, Morocco, Tunisia
34 00N
3 00E
Magreb (local name for Morocco)
39 30N
3 00E
Majuro (capital)
39 30N
3 00E
Malmady (region)
40 00N
4 00E
Minsk (capital)
3511 N
418W
Venda (enclave)','e1831da04b1f291214b42c7fa6f3b326212a60e2b00bc92a098c438d50269d50','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7ddb2a690e425b04ada008b27f5bb936e1abca64696de4fe7bca7a87665d4f9',2007,'AS','American Samoa','transnational-issues',52,'(territory of the US)
Swains
Island
, SAMOA
South
Pacilic
Ocean
Olu Olosega
\\/
•Ta''u
Tuluila
Rose
Island
South
Pacific
Ocean
to
AQ
AS
ASM
016
.as
14 20S
170 00 W
Eesti (local name for Estonia)
14 13 S
169 35 W
Maputo (capital)
14 16 S
Palawan (island)
Swan Islands
14 18 S
Tyrol, South (region)','495e9b047796d49f1f25795a32c3cbd31b8630add32c24abe039a699c460f896','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87f867a04ac80ba3d86912fb6d996ce39086ffef63b546ade402c097537bdad3',2007,'NZ','New Zealand','transnational-issues',62,'Disputes - international: none
Tasman
Sea
Antipodes Islands. Auckland
Islands. Bounty Islands,
Campbell Island. Chatham
Islands, and Kermadec
Islands ate not shown.
South Pacific
Ocean
North Island
New Plymouth
Cooks
Strait ,
Jauranga
Gisbome./
r
♦ Napier
• Palmerston
North
^WELLINGTON
Greymouth [
South Island
.Chr
hristchurch
Dunedln
South Pacific
Ocean
Stewart
. Island
150 300 km
Disputes • international: asserts a territorial claim
in Antarctica (Ross Dependency) [see Antarctica]
Disputes - international: none
Trinidad and
Tobago
O 10 2Qkm
0 10 20 rro
Caribbean
Sea
Tobago
Scarborough^
-
PORT-OF- —tic*
SPAIN A*iAnpo
Anma
Sangre
Grande
Chaguanas
Point Lisas
Pointe-a-Pierre. Trinidad
San Fernando
.Siparia
_____
Point
Fortin.
NORTH
ATLANTIC
OCEAN
Disputes - international: Barbados will assert its
claim before the UN Convention on the Law of the Sea
(UNCLOS) that the northern limit of Trinidad and
Tobago''s maritime boundary with Venezuela extends
into its waters; Guyana has also expressed its
intention to challenge this boundary as it may extend
into its waters as well
Illicit drugs: transshipment point for South American
drugs destined for the US and Europe; producer of
cannabis
Tromelin Island
(possession of France)
II
Indian
Ocean
OAPEC
OAS^
Organization of Arab Petroleum Exporting Countries
Organization of American States
OAU
Organization of African Unity; see African Union
ODA
official development assistance
OECD
Organization for Economic Cooperation and Development
OECS
Organization of Eastern Caribbean States
OHCHR
Office of the United Nations High Commissioner for Human Rights
OIC
Organization of the Islamic Conference
OIF
International Francophone Organization
ONUB
United Nations Operation in Burundi
OOF
other official flows
OPANAL Agency for the Prohibition of Nuclear Weapons in Latin America and the
Caribbean
OPCW
Organization for the Prohibition of Chemical Weapons
OPEC
Organization of Petroleum Exporting Countries
OSCE
Organization for Security and Cooperation in Europe
Ozone Layer Protection Montreal Protocol on Substances That Deplete the Ozone Layer
PCA
Permanent Court of Arbitration
PFP
Partnership for Peace
PIF
Pacific Islands Forum
PPP
purchasing power parity
Ramsar
see Wetlands
RG
Rio Group
SAARC
South Asian Association for Regional Cooperation
SACEP
South Asia Co-opeative Environment Programme
SACU
Southern African Customs Union
SADC
Southern African Development Community
SAFE
South African Far East Cable
SCO
Shanghai Cooperative Organization
SHF
super-high-frequency
Ship Pollution
Sparteca
Protocol of 1978 Relating to the International Convention for the Prevention of
Pollution From Ships, 1973 (MARPOL)
South Pacific Regional Trade and Economic Cooperation Agreement
SPC
Secretariat of the Pacific Communities
SPF
South Pacific Forum
sqkm
square kilometer
sqmi
square mile
TAT
Trans-Atlantic Telephone
Tropical Timber 83
International Tropical Timber Agreement, 1983
Tropical Timber 94
International Tropical Timber Agreement, 1994
631
Appendix A: Abbreviations (continued)
UAE
Antwerp (city)
5100S
166 30 E
Australes, lies (island group; also lies Tubuai)
47 43S
174 00 E
682
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Bourbon Island (former name of Reunion)
Brasilia (capital)
Reunion
Campeche, Bay of
Atlantic Ocean
Canal Zone (former name for US possessions
in Panama)
44 00S
176 30 W
Chechnya (region; also Chechnia)
Russia
4315N
45 40E
Cheju Strait
Pacific Ocean
34 00N
126 30 E
Cheju-do (island)
Korea, South
33 20N
126 30 E
Chennai (city; also Madras)
29 50S
17815W
Kerulen River
China, Mongolia
48 48N
11700E
Khabarovsk (city)
Russia
48 27N
135 06 E
Khanka, Lake
China, Russia
45 00N
132 24 E
Khartoum (capital)
39 00S
176 00 E
North Korea
North Korea
North Ossetia (region)
Russia
North Pacific Ocean
Pacific Ocean
North Sea
Atlantic Ocean
North Vietnam (former name for northern portion of Vietnam
Vietnam)
North Yemen (Yemen Arab Republic; now part of Yemen) Yemen
Northeast Providence Channel
Atlantic Ocean
Northern Cyprus (region)
43 00S
171 00 E
South Korea
South Korea
37 00N
127 30 E
South Orkney Islands
West Frisian Islands','6370d769cd48eaec150d0314264445c027eb7fbcff19657ee4060ed30e79eb79','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cffa41e54462e658d472eea8e32c7183afe25c6d4411050ed430c0e46464cde9',2007,'AD','Andorra','transnational-issues',63,'|e|
\\ FRANCE
\\^y *EI Serrat
Soldeu . — S
^\\ ANDORRA -EnCamP
\\LAVELLA
r'' ® •
^J Les Escaldes
^v Sant Julia
.de Ldria . y~
AN
AD
AND
020
.ad
42 30N
130E
Andros (island)','e1ffacd7feade30a0b35e6d72fbde27930f1e25d5e07a1e53c0972515fe549b1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80fd41c5cd607c8a2349536943eb49faaa279edb7fb851342882fb22f5cfbe07',2007,'AO','Angola','transnational-issues',65,'trv* Of -m cn^c- -«#
''Soyo
\\
\\Ambriz
0 100 200 km
0 100 200nif
DEM. REP.
OF THE CONGO
.LUANDA
Porto
Amboin
SOUTH
atlantic •''
oceXn [
Mono
LODItO, de Mdco
•r A
Benguela "Huambo
#Lubango
Namibe
Rimdu
"*L Groollunli-in''
*
Swakopmund.
Walv1S Bay'' w,NDHOEK
\\ Rehobou/o
LQderitz. K«elmanshoop
Karasburg
O 100 200 Km
Qobabls
Disputes - international: border commission has
yet to resolve small residual disputes with Botswana
along the Caprivi Strip, including the Situngu
marshlands along the Linyanti River; Botswana
residents protest Namibia''s planned construction of
the Okavango hydroelectric dam on Popa Falls;
managed dispute with South Africa over the location
of the boundary in the Orange River; Namibia has
supported and in 2004 Zimbabwe dropped objections
to plans between Botswana and Zambia to build a
bridge over the Zambezi River, thereby de facto
recognizing a short, but not clearly delimited,
Botswana-Zambia boundary in the river
Refugees and internally displaced persons:
refugees (country of origin): 12,618 (Angola) (2005)
AO
AO
AGO
024
.ao
Cabo Verde (local name for Cape Verde)
Cape Verde
Cabot Strait
Atlantic Ocean
Caicos Islands
8 48S
13 14 E
Lubnan (local name for Lebanon)','7f62abf51e23ae5fa3386b0cd5bff4c63a778c745fa139b70c12166cca491b5e','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65c26184712c2391cf4115eeee4b5b2b8bf60997d7b589a1002625dab7fd1fd8',2007,'NA','Namibia','transnational-issues',74,'Disputes - international: many Cabinda exclave
secessionists have sought shelter in neighboring
states
Refugees and internally displaced persons:
refugees (country of origin): 13,510 (Democratic
Republic of Congo)
IDPs: 40,000-60,000 (27-year civil war ending in
2002; 4 million IDPs already have returned) (2005)
Illicit drugs: used as a transshipment point for
cocaine destined for Western Europe and other
African states
19
Upington
Kimberley*
Bloemfontem
De Aar
Ladysm.th «*f
Durban
•Saidanha
.Cape Town
Port
Elizabeth
East
London.
INDIAN
OCEAN
r
Capt ■ 4
Good Hope
O 100 200 km
PMna Edmfd la h M
Disputes - international: South Africa has placed
military along the border to stem the thousands of
Zimbabweans fleeing to find work and escape political
persecution; managed dispute with Namibia over the
location of the boundary in the Orange River
Refugees and internally displaced persons:
refugees (country of origin): 5,774 (Angola) 9,51 6
(Democratic Republic of Congo) 7,1 18 (Somalia) (2005)
Illicit drugs: transshipment center for heroin,
hashish, marijuana, and cocaine; cocaine
consumption on the rise; world''s largest market for
illicit methaqualone, usually imported illegally from
India through various east African countries; illicit
cultivation of marijuana; attractive venue for money
launderers given the increasing level of organized
criminal and narcotics activity in the region
South Georgia
and the South
Sandwich Islands
(overseas territory of the UK,
also claimed by Argentina)
^11^
Slug Rocks
are not shown.
0 100 200 km
0 100 200 mi
South Georgia
1 .Grytviken
Bird <Ps\\
Island
South
Clerke
Rocks
Atlantic Ocean
Traversay
Islands
South
Scotia Sea
Sandwich Saunders 1.
Islands .. . „ ,
Montagu 1.
Bnstol 1.
Administered by U.K.
claimed by ARGENTINA.
Southern"
Thule
Disputes - international: Argentina, which claims
the islands in its constitution and briefly occupied the
islands by force in 1982, agreed in 1995 to no longer
seek settlement by force
WA
NA
NAM
516
.na
22 00S
17 00E
Germany, Federal Republic of
24 00S
15 00E
Nampo-shoto (island group)
22 00S
17 00E
Soviet Union (former name of a large Eurasian empire,
roughly coequal with the former Russian Empire)
Armenia, Azerbaijan, Belarus. Estonia, Georgia,
Kazakhstan, Kyrgyzstan, Latvia, Lithuania.
Moldova. Russia. Tajikistan, Turkmenistan,
Ukraine. Uzbekistan
Spanish Guinea (former name for Equatorial Guinea)
Warsaw (capital)
Windward Passage
Atlantic Ocean
Wrangel Island (Ostrov Vrangelya)
Russia
19 17 N
37 00N
44 45N
52 30N
13 17 S
22 59S
5215N
38 53N
72 00S
4128S
53 26N
53 22N
12 10S
34 40N
30 00N
60 00N
34 40N
13 35S
8 20S
65 30N
7100S
12 06N
22 34S
20 00N
71 14 N
166 36 E
73 00E
26 05E
3 30W
17610W
14 31 E
2100E
77 02W
45 00W
174 51 E
5 30E
5 20E
96 55E
129 00 E
70 00E
75 00E
129 00 E
172 20 W
126 30 E
38 00E
120 00 E
68 56W
17 06E
73 50W
179 36 W
Xianggang (local name for Hong Kong)','4f92d160e832de1a0b8ab296e4dbbf831a54c604b77fd553bd319ca82201fa0e','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e99ff4f4b7b553cbfee670e231d05add5c6d87959276cd364b756999cb20696',2007,'AI','Anguilla','transnational-issues',75,'(overseas territory
of the UK)
Sombrero
p 5 10 fcm
0 S 10 ml
NORTH ATLANTIC
OCEAN
Dog
Island
Caribbean Sea
Scrub
Island
Anguilla^^s/>
''iP-
tTHE VALLEY
Crocus Hit
Blowing Point
Village
AV
Al
AIA
660
.ai
18 13 N
63 04W
Van Diemen Strait (Osumi Strait)
Pacific Ocean
3100N
131 00 E
Vancouver Island','69abc30288118afc499e614c5a20d05d79504382e8829de8b55402d85bc5538c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4e69b654e210a51d5ad44d736b3004b88ccbf211dc8435a0a0839d7c5d79f2e',2007,'PR','Puerto Rico','transnational-issues',84,'Disputes - international: none
Illicit drugs: transshipment point for South American
narcotics destined for the US and Europe
(territory of the US with commonwealth status)
NORTH ATLANTIC OCEAN
Isla
ft (KtoO
issape
Isla
.Aguadilla
.Mayaguez
SAN JUAN
Arecibo
Bayamon.
Guaynabo.
t •Carolina''
Trujillo
islade
Culebra
Puerto RiCO Caguas.
Cerro de Punta
aTo F^d°V
.San German
.Yauco
^rS&* Vieques
Ponce
Guayama.
Isla
Vieques
Las Mareas
Caribbean Sea
RQ
PR
PRI
630
pr
18 28N
66 07W
San Marino (capital)','8add05af38444153a3e4bfb0ca481628572ea59a650b1230fe65224b78465eef','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a8c2a0d0d5ab272d61f618fc7cbb3276d72f718e4b5ca24b4788fe1fbdd31b8',2007,'AQ','Antarctica','transnational-issues',85,'Southern Ocean
Marie
VV^ Byrd
Amundsen v( Lant
Sea 4. T7 /C&N
\\ 0 shelf
Southern
Ocean
O 400 -800 Km ''
400 800 mi
Disputes - international: Argentina continues to
assert its claims to the UK-administered Falkland
Islands (Islas Malvinas) and South Georgia and the
South Sandwich Islands in its constitution, forcibly
occupying the Falklands in 1982, but in 1995 agreed
no longer to seek settlement by force; territorial claim
in Antarctica partially overlaps UK and Chilean claims
(see Antarctic disputes); unruly region at convergence
of Argentina-Brazil-Paraguay borders is locus of
money laundering, smuggling, arms and illegal
narcotics trafficking, and fundraismg for extremist
organizations; uncontested dispute between Brazil
and Uruguay over Braziliera Island in the Quarai/
Cuareim River leaves the tripoint with Argentina in
question
Illicit drugs: used as a transshipment country for
cocaine headed for Europe; some money-laundering
activity, especially in the Tri-Border Area; domestic
consumption of drugs in urban centers is increasing
29
parties— (16) Argentina, Australia, Belgium, Brazil, Canada, Chile, France, Germany, Italy, Japan, Norway, Poland,
Russia, South Africa, UK, US
countries that have signed, but not yet ratified— -(1 ) NZ
Convention on Biological Diversity
note— abbreviated as Biodiversity
opened for signature— 5 June 1 992
entered into force— 29 December 1 993
objective— to develop national strategies for the
conservation and sustainable use of biological
diversity
Convention on Fishing and Conservation of
Living Resources of the High Seas
nofe— abbreviated as Marine Life Conservation
opened for signature— 29 April 1 958
entered into force— 20 March 1 966
objective— -to solve through international
cooperation the problems involved in the
conservation of living resources of the high seas,
considering that because of the development of
modern technology some of these resources are
in danger of being overexploited
parties— (182) Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan,
The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil,
Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic,
Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands,
Costa Rica, Cote d''lvoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, EU, Fiji, Finland, France,
Gabon, The Gambia, Georgia, Germany. Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, Kiribati, North Korea, South Korea, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall
Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia. Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Nepal. Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman, Pakistan,
Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia. Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and
Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, South
Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
countries that have signed, but not yet ratified— -(6) Afghanistan, Kuwait, Serbia and Montenegro, Thailand, Tuvalu,
US
parties— {37) Australia, Belgium, Bosnia and Herzegovina, Burkina Faso, Cambodia, Colombia, Denmark,
Dominican Republic, Fiji, Finland, France, Haiti, Jamaica, Kenya, Lesotho, Madagascar, Malawi, Malaysia,
Mauritius, Mexico, Netherlands, Nigeria. Portugal, Senegal, Serbia and Montenegro, Sierra Leone, Solomon
Islands, South Africa, Spain, Switzerland, Thailand, Tonga, Trinidad and Tobago, Uganda, UK, US, Venezuela
countries that have signed, but not yet ratified— (21) Afghanistan, Argentina, Bolivia, Canada, Costa Rica, Cuba,
Ghana, Iceland, Indonesia, Iran, Ireland, Israel. Lebanon, Liberia, Nepal, NZ, Pakistan, Panama, Sri Lanka, Tunisia,
AY
AQ
ATA
010
.aq
ISO defines as the territory south of
60 degrees south latitude
66 30S
139 00 E
Aden (city)
7100S
70 00W
Alexandretta (region; former name for Iskenderun)
Turkey
36 34N
36 08E
Alexandria (city)
67 00S
163 00 E
Balochistan (region)
79 30S
49 30W
Berlin (capital)
62 56S
60 34W
Denmark Strait
Atlantic Ocean
67 00N
24 00W
D''Entrecasteaux Islands
75 00S
92 00W
Elobey, Islas de (island group)
65 00S
64 00W
Gran Chaco (region)
Argentina, Paraguay
24 00S
60 00W
Grand Bahama (island)
The Bahamas
26 40N
78 35W
Grand Banks (fishing ground)
Atlantic Ocean
47 06N
55 48W
Grand Cayman (island)
77 00S
130 00 W
Marion Island
68 48S
90 35W
Philip Island
Quemoy (island)
Taiwan
Quito (capital)
79 30S
162 00 W
Roseau (capital)
80 00S
180 00 E
Ross Island
81 30 S
175 00 W
Ross Sea
Antarctica, Southern Ocean
76 00S
175 00 W
Rossiya (local name for Russia)
Russia
60 00N
100 00 E
Rota (island)
67 24S
179 55 W
Senegambia (region; former name of confederation
of Senegal and The Gambia)
The Gambia, Senegal
13 50N
15 25W
Senyavin Islands
Federated States of Micronesia
6 55N
158 00 E
Seoul (capital)
South Korea
37 34N
127 00 E
Serendib (former name for Sri Lanka)
6100S
45 00W
South Ossetia (region)
62 00S
59 00W
South Tyrol (region)
Terres Australes et Antarctiques Francaises (local name
for the French Southern and Antarctic Lands)
French Southern and Antarctic Lands
Thailand, Gulf of
Pacific Ocean
The Former Yugoslav Republic of Macedonia
Macedonia
39 00N
17 37S
25 03N
24 00N
59 25N
6 00S
35 48N
5125N
125N
50 00N
4120N
4 30S
43 00S
50 00N
76 00N
4143N
15 00N
14 06N
35 40N
32 05N
4 00S
0 30S
66 30S
43 00S
10 00N
4150N
71 00 E
149 27 W
121 30 E
119 00E
24 45E
35 00E
5 45W
94 45E
173 00 E
141 00 E
6918E
168 00 E
147 00 E
141 00 E
104 00 E
44 49E
19 00E
8713W
5126E
34 48E
120 45 E
121 00 E
139 00 E
67 00E
101 00 E
22 00E
705
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Thimphu (capital)
72 20S
99 00W
Tiberias, Lake
72 00S
155 00 E
Vienna (capital)
Willemstad (capital)
Netherlands Antilles
Windhoek (capital)','882f9431fe852a6bed1e5faff9aa980fa4aa09dab6488969c696d7191184f7cc','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e764ed284774374a8491952cc7931ccdc2772a7d5e48b5a43a0b9dfeae119de0',2007,'AR','Argentina','transnational-issues',95,'Disputes • international: Antarctic Treaty freezes
claims (see Antarctic Treaty Summary in Government
type entry); Argentina, Australia, Chile, France, NZ,
Norway, and UK claim land and maritime sectors
(some overlapping) for a large portion of the continent;
the US and many other states do not recognize these
territorial claims and have made no claims themselves
(the US and Russia reserve the right to do so); no
claims have been made in the sector between 90
degrees west and 150 degrees west; several states
with territorial claims in Antarctica have expressed
their intention to submit data to the UN Commission on
the Limits of the Continental Shelf to extend their
continental shelf claims to adjoining undersea ridges
l>-
SOUTH
ATLANTIC
OCEAN
FALKLAND ISLANDS
(ISLAS UALVINASI
tr/ MIOEN1 .''.A
Disputes - international: unruly region at
convergence of Argentina-Brazil-Paraguay borders is
locus of money laundering, smuggling, arms and
illegal narcotics trafficking, and fundraising for
extremist organizations
Illicit drugs: major illicit producer of cannabis, most
or all of which is consumed in Brazil, Argentina, and
Chile; transshipment country for Andean cocaine
headed for Brazil, other Southern Cone markets, and
Europe; corruption and some money-laundering
activity, especially in the Tri-Border Area; weak
anti-money-laundering laws and enforcement
Background: Ancient Peru was the seat of several
prominent Andean civilizations, most notably that of
the Incas whose empire was captured by the Spanish
conquistadors in 1533. Peruvian independence was
declared in 1821, and remaining Spanish forces
defeated in 1824. After a dozen years of military rule.
Peru returned to democratic leadership in 1980, but
experienced economic problems and the growth of a
violent insurgency. President Alberto FUJIMORI''S
election in 1990 ushered in a decade that saw a
dramatic turnaround in the economy and significant
progress in curtailing guerrilla activity. Nevertheless,
the president''s increasing reliance on authoritarian
measures and an economic slump in the late 1990s
generated mounting dissatisfaction with his regime.
FUJIMORI won reelection to a third term in the spring
of 2000, but international pressure and corruption
scandals led to his ouster by Congress in November
of that year. A caretaker government oversaw new
elections in the spring of 2001 , which ushered in
Alejandro TOLEDO as the new head of government;
his presidency has been hampered by allegations of
corruption.
Disputes - international: Chile and Ecuador
rejected Peru''s November 2005 unilateral law to shift
the axis of their joint treaty-defined maritime boundary
along the parallel of latitude to an equidistance line
which favors Peru; organized illegal narcotics
operations in Colombia have penetrated Peru''s
shared border; Peru does not support Bolivia''s claim
to restore maritime access through a sovereign
corridor through Chile along the Peruvian border
Refugees and internally displaced persons:
IDPs: 60,000 (civil war from 1980-2000; most IDPs
are indigenous peasants in Andean and Amazonian
regions) (2005)
Illicit drugs: until 1996 the world''s largest coca leaf
producer; cultivation of coca in Peru fell 1 5% to 31 ,1 50
hectares between 2002 and the end of 2003; much of
the cocaine base is shipped to neighboring Colombia
for processing into cocaine, while finished cocaine is
shipped out from Pacific ports to the international drug
market; increasing amounts of base and finished
cocaine, however, are being moved to Brazil and
Bolivia for use in the Southern Cone or transshipped
to Europe and Africa
AR
AR
ARG
032
.ar
Bujumbura (capital)
35 00S
Panama (capital)','a98c6dea7c588e506d0b9df4eaba51bc7ff9eebae94b312336116c0761a734b0','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e4ebb721283dab56e8050ac075c2e0ef3e42a75221b4c348a71fa20fb3218c6',2007,'AG','Antigua and Barbuda','transnational-issues',96,'0 10 20 km
10 20 mi
„Codnngton
Barbuda
Caribbean Sea
Redonda
Antgue
S Al NT International
john''s .r
Antigua ''■ Boggy Peak •<-£■
English Harbou^-"* n
Town
Disputes - international: none
Illicit drugs: considered a minor transshipment point
for narcotics bound for the US and Europe; more
significant as an offshore financial center
Disputes - international: some maritime disputes
(see littoral states)
26
AC
AG
ATG
028
•ag
Antipodes Islands
17 38N
6148W
Barents Sea
Arctic Ocean
74 00N
36 00E
Barranquilla (city)
Republica Dominicana (local name for Dominican
Republic)
17 06N
Saint Lawrence Island','846ea6fc2a5580ca8c7ea6ad5b9217c99a573f351f0c0de5d7d695e57eccaac5','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('753701bd2d2705b529bd68d9a96cbdc377b64b1b880a5dcaff2a6e33b736b744',2007,'AM','Armenia','transnational-issues',112,'Background: Armenia prides itself on being the first
nation to formally adopt Christianity (early 4th
century). Despite periods of autonomy, over the
centuries Armenia came under the sway of various
empires including the Roman, Byzantine, Arab,
Persian, and Ottoman. The eastern area of Armenia
was ceded by the Ottomans to Russia in 1 828; this
portion declared its independence in 1918, but was
conquered by the Soviet Red Army in 1920. Armenian
leaders remain preoccupied by the long conflict with
Muslim Azerbaijan over Nagorno-Karabakh, a
primarily Armenian-populated region, assigned to
Soviet Azerbaijan in the 1920s by Moscow. Armenia
and Azerbaijan began fighting over the area in 1988;
the struggle escalated after both countries attained
independence from the Soviet Union in 1991 . By
May 1994, when a cease-fire took hold, Armenian
forces held not only Nagorno-Karabakh but also a
significant portion of Azerbaijan proper. The
economies of both sides have been hurt by their
inability to make substantial progress toward a
peaceful resolution. Turkey imposed an economic
blockade on Armenia and closed the common border
because of the Armenian occupation of
Nagorno-Karabakh and surrounding areas.
AM
AM
ARM
051
.am
ISO includes with Australia
ISO includes Ashmore and Cartier
Islands, Coral Sea Islands
ISO includes with the US Minor
Outlying Islands
administered with French Southern and
Antarctic Lands; no ISO codes
assigned
669
Appendix D: Cross-Reference List of Country Data Codes (continued)
Entity
Fl PS 10-4
ISO 3166
Internet
Comment
40 00N
45 00E
Heard Island
Y''israel (local name for Israel)','738c40c40013541f477b9f115cb077ed03bc38c652384e4729eed6b565cb3a13','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b052355de160a826d933f718746732c52dd9d8c727cb9255007a9e3995205797',2007,'NL','Netherlands','transnational-issues',129,'Disputes - international: none
Illicit drugs: transit point for US- and Europe-bound
narcotics with some accompanying money-laundering
activity
Ashmore and
Carter Islands
(territory of Australia)
INDONESIA,^ Timor
Map Area l—
Antilles
(part of the Kingdom of
the Netherlands)
/
Caribbean
Sea
Saint-
Martin,
Sint Philipsbutg
Maarten
Saint-
Barthe''lemy
Mount
Scenery
Sint
Eustatius
Westpunt
Barber
MDDU
Hak
Curasao
*
WILLEMSTAD
Fuik*
Bay
Bonaire
Bopec
Terminal^ Hincon
Kralendijk,
Klein
Bonaire
.
Sola,
Salt Works
Klein
Curacao
Disputes - international: none
Illicit drugs: transshipment point for South American
drugs bound for the US and Europe;
money-laundering center
399
NL
NL
NLD
528
.nl
Netherlands Antilles
NT
AN
ANT
530
.an
52 23N
4 54E
Amsterdam Island (lie Amsterdam)
French Southern and Antarctic Lands
37 52S
77 32E
Amundsen Sea
Southern Ocean
72 30S
11200W
Amur River
China, Russia
52 56N
141 10 E
Amurskiy Liman (strait)
Pacific Ocean
53 00N
141 30 E
Anadyrskiy Zaliv (gulf)
Pacific Ocean
64 00N
177 00 E
Anatolia (region)
Turkey
39 00N
35 00E
Andaman Islands
52 05N
Haifa (city)
52 30N
5 45E
Hong Kong (special administrative region)
52 30N
5 45E
Nederlandse Antillen (local name for the Netherlands
Antilles)
Netherlands Antilles
1215N
68 45W
Negev (region)
West Germany (Federal Republic of Germany;
former name for western portion of Germany)','82a85723ddfc52ed0abdd24556465d73e1f087d4fae176e099a14225e0b463a4','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbbb219526be540abb79a7825266eb950247c594f2d7cd1c21e2fb583bc6a6fd',2007,'AU','Australia','transnational-issues',130,'400 800km
800 mi
Hibernia
C^> Reef
(AUSTRALIA!
Qi^Ashmore Reef
west^H ^ ''East Islet
Indian Ocean
10 20 Km
Carter
Island
reef
&
Disputes - international: Indonesian groups
challenge Australia''s claim to Ashmore Reef; Australia
has closed the surrounding waters to Indonesian
traditional fishing and created a national park in the
region while continuing to prospect for hydrocarbons
in the vicinity
>*v>
North
Atlantic
Ocean ■
[V
v:~^ '': J
J [. ''
SOUth '': ( J )\\a /
Atlantic , 1 jjf/
Ocean : \\__/
M>
\\^<x^
Disputes - international: some maritime disputes
(see littoral states)
^
rr-rv
Disputes - international: none
Clipperton Island
(possession of France)
II
0
^jeel o
1 2km
\\
2 mi
reell \\\\
//reef
.....
North Pacific
Ocean
Disputes - international: none
415
Northern Mariana
Islands
(commonwealth in political
union with the US)
Farallon de
Pa/aros
MAUG ISLANDS
Asuncion Island
Philippine
Agrihan
unnamed
Pagan
Sea
Alamagan
Guguan
NORTH
Sarigan
PACIFIC
Anatahan
OCEAN
Farallon de
Metitnilla
SMPM* Saipan
Agwian Tinian
0 SO 100 km
i * — .— • •
0 50 100 mi
Rota
Introd uctio
Background: Under US administration as part of the
UN Trust Territory of the Pacific, the people of the
Northern Mariana Islands decided in the 1970s not to
seek independence but instead to forge closer links
with the US. Negotiations for territorial status began in
1972. A covenant to establish a commonwealth in
political union with the US was approved in 1975, and
came into force on 24 March 1 976. A new government
and constitution went into effect in 1978.
10 12 S
142 16 E
Banks Island
Bristol Bay
Pacific Ocean
Bristol Channel
Atlantic Ocean
Britain (see Great Britain)
Cancun (city)
2315S
155 32 E
Caucasus (region)
Russia
42 00N
45 00E
Cayenne (capital)
10 25S
105 39 E
Christmas Island (Pacific Ocean; also Kiritimati)
3130S
159 00 E
Lorraine (region)
54 36S
158 54 E
Madagasikara (local name for Madagascar)
Tatar Strait
Pacific Ocean
Taymyr Peninsula (Poluostrov Taymyr)
Russia
Tbilisi (capital)','f8436af1b68bcd9fce6443a4e0e1de46ccb95fcff5ad7ac59948ebec2881e6a4','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('409c67a9b9601ab257e8c48ee4888c946f88f6048d02dcc1bc7a11d02b20f68b',2007,'ID','Indonesia','transnational-issues',137,'(^t»or *ra/ura Sea
£?
Sea jr~
Darwin
■^ . J
INDIAN
OCEAN
Coral
Sea
Townsvilla^
Mackay*
Gladstone*
Brisbane.
Newcastle
Adelaide Sydney ♦''
CANBERRA*
Melbourne AMbu*
^->-_ • JioeausjXo
S*.
300 600km
Launceston#
Tasmania • jSobart
LoraHoM Island and
Macquana Istand not snowm
Disputes - international: East Timor and Australia
agreed in 2005 to defer the disputed portion of the
boundary for fifty years and to split hydrocarbon
revenues evenly outside the Joint Petroleum
Development Area covered by the 2002 Timor Sea
Treaty; East Timor dispute hampers creation of a
revised maritime boundary with Indonesia (see also
Ashmore and Cartier Islands dispute); regional states
express concern over Australia''s 2004 declaration of
a 1 ,000-nautical mile-wide maritime identification
zone; Australia asserts land and maritime claims to
Antarctica (see Antarctica); in 2004 Australia
submitted its claims to UN Commission on the Limits
of the Continental Shelf (CLCS) to extend its
continental margin from both its mainland and
Antarctic claims
Illicit drugs: Tasmania is one of the world''s major
suppliers of licit opiate products; government
maintains strict controls over areas of opium poppy
cultivation and output of poppy straw concentrate
38
''£
VttcM
Liquica, *
Pulau Alauro
DILI Baucau
Manatuto
■Sea Ermera.^ Viqueque^ Pulau
Pante (^s.
Makasar ^ Ti
Foho
f Talamailau
Suai
f INDONESIA
<&lX"
Timor Sea
SO 10Okm
Disputes • international: UN Mission of Support in
East Timor (UNMISET) has maintained about 1,000
peacekeepers in East Timor since 2002; East
Timor-Indonesia Boundary Committee continues to
meet, survey, and delimit the land boundary, but
several sections of the boundary especially around
the Oekussi enclave remain unresolved; Indonesia
and East Timor contest the sovereignty of the
uninhabited coral island of Pulau Batek/Fatu Sinai,
which prevents delimitation of the northern maritime
boundaries; many refugees who left East Timor in
2003 still reside in Indonesia and refuse repatriation;
Australia and East Timor agreed in 2005 to defer the
disputed portion of the boundary for fifty years and to
split hydrocarbon revenues evenly outside the Joint
Petroleum Development Area covered by the 2002
Timor Sea Treaty; dispute with Australia also hampers
creation of a southern maritime boundary with
Illicit drugs: NA
167
Disputes • international: some maritime disputes
(see littoral states)
Disputes • international: Malaysia has asserted
sovereignty over the Spratly Islands together with
China, Philippines, Taiwan, Vietnam, and possibly
Brunei; while the 2002 "Declaration on the Conduct of
Parties in the South China Sea" has eased tensions
over the Spratly Islands, it is not the legally binding
"code of conduct" sought by some parties; Malaysia
was not party to the March 2005 joint accord among the
national oil companies of China, the Philippines, and
Vietnam on conducting marine seismic activities in the
Spratly Islands; disputes continue over deliveries of
fresh water to Singapore, Singapore''s land reclamation,
bridge construction, maritime boundaries, and Pedra
Branca Island/Pulau Batu Putih - but parties agree to
ICJ arbitration on island dispute within three years; ICJ
awarded Ligitan and Sipadan islands, also claimed by
Indonesia and Philippines, to Malaysia but left maritime
boundary in the hydrocarbon-rich Celebes Sea in
dispute, culminating in hostile confrontations in March
2005 over concessions to the Ambalat oil block;
separatist violence in Thailand''s predominantly Muslim
southern provinces prompts measures to close and
monitor border with Malaysia to stem terrorist activities;
Philippines retains a now dormant claim to Malaysia''s
Sabah State in northern Borneo; in 2003, Brunei and
Malaysia ceased gas and oil exploration in their
349
Malaysia (continued)
disputed offshore and deepwater seabeds and
negotiations have stalemated prompting consideration
of international adjudication; Malaysia''s land boundary
with Brunei around Limbang is in dispute; piracy
remains a problem in the Malacca Strait
Refugees and internally displaced persons:
refugees (country of origin): 15,181 (Indonesia) 9,601
(Burma) (2005)
Illicit drugs: regional transit point for some illicit
drugs; drug trafficking prosecuted vigorously and
carries severe penalties
1
South F
Ocean
Disputes • international: none
Midway Islands
(territory of the US)
Description under
Disputes - international: relies on assistance from
Australia to keep out illegal cross-border activities
from primarily Indonesia, including goods smuggling,
illegal narcotics trafficking, and squatters and
secessionists
Paracel Islands
South China Sea
Amphitrite
West Sand Tme lsland GrOUP
Rocky Island
Woody
Pattle lsland
Island^y.
Robert Island;'' 2~~Drummond Island
Mono* Island Duncan m ^
Lincoln
Island
cr>
Crescent
Group
Tnton
Island
Passu
Keah
O Bombay
Reel
Disputes - international: occupied by China, also
claimed by Taiwan and Vietnam
Disputes - international: Philippines claims
sovereignty over certain of the Spratly Islands, known
locally as the Kalayaan (Freedom) Islands, also
claimed by China, Malaysia, Taiwan, and Vietnam; the
2002 "Declaration on the Conduct of Parties in the
South China Sea," has eased tensions in the Spratly
Islands but falls short of a legally binding "code of
conduct" desired by several of the disputants; in
March 2005, the national oil companies of China, the
Philippines, and Vietnam signed a joint accord to
conduct marine seismic activities in the Spratly
Islands; Philippines retains a dormant claim to
Malaysia''s Sabah State in northern Borneo based on
the Sultanate of Sulu''s granting the Philippines
Government power of attorney to pursue a
sovereignty claim on his behalf
Refugees and internally displaced persons:
IDPs: 150,000 (fighting between government troops
and MILF and Abu Sayyaf groups) (2005)
Illicit drugs: domestic methamphetamine
production has been a growing problem in recent
years; longstanding marijuana producer
444
Pitcairn Islands
(overseas territory
of the UK)
O, ■!«<
Henderson
l$land
Island
SOUTH
PACIFIC
OCEAN
Pitcairn °
Island
AOAMSTOWN
Disputes - international: none
Disputes - international: disputes persist with
Malaysia over deliveries of fresh water to Singapore,
Singapore''s extensive land reclamation works, bridge
construction, maritime boundaries, and Pedra Branca
Island/Pulau Batu Putih - parties agree to ICJ
arbitration on island dispute within three years;
Indonesia and Singapore pledged in 2005 to finalize
their 1973 maritime boundary agreement by defining
unresolved areas north of Batam Island; piracy
remains a problem in the Malacca Strait
Illicit drugs: as a transportation and financial
services hub, Singapore is vulnerable, despite strict
laws and enforcement, as a venue for money
laundering
ID
ID
IDN
360
id
Iran
IR
IR
IRN
364
ir
8 20S
11500E
Bali Sea
Indian Ocean
7 45S
115 30 E
Balintang Channel
Pacific Ocean
19 49N
121 40 E
Balintang Islands
2 30S
106 00 E
Bangkok (capital)
2 00S
121 00 E
Celebes Sea
Pacific Ocean
3 00N
122 00 E
Celtic Sea
Atlantic Ocean
51 00 N
6 30W
Central African Empire (former name for Central
African Republic)
5 00S
120 00 E
Dutch Guiana (former name for Suriname)
Flores Sea
Pacific Ocean
Florida, Straits of
Atlantic Ocean
Fongafale (capital)
100N
Halmahera Sea
Pacific Ocean
0 30S
10 00E
53 00W
174 29 W
146 10 E
50 00E
144 45 E
418E
35 00E
109 30 E
106 41 E
35 00E
128 00 E
129 00 E
689
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Hamilton (capital)
5 00S
138 00 E
Irish Sea
Atlantic Ocean
53 30N
5 20W
Iron Gate (river gorge)
Romania, Serbia and Montenegro
44 41 N
22 31E
Iskenderun (region; formerly Alexandretta)
Turkey
36 34N
36 08E
690
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Islamabad (capital)
610S
106 48 E
James Bay
Arctic Ocean
54 00N
80 00W
Jamestown (capital)
Saint Helena
15 56S
5 44W
Jammu (city)
7 30S
11000E
Java Sea
Pacific Ocean
5 00S
11000E
Jerusalem (capital, proclaimed)
Israel, West Bank
3147N
3514E
Jiddah (city; also Jeddah)
Kaliningrad (region; formerly part of East Prussia)
Kamaran (island)
Kamchatka Peninsula (Poluostrov Kamchatka)
Kampala (capital)
Russia
8 28S
11640E
Lombok Strait
Indian Ocean
8 30S
11550E
Lome (capital)
2 00S
128 00 E
Mombasa (city)
Pacific Ocean
29 00S
3 30N
3 30N
30 25E
102 30 E
108 00 E
Naxcivan (region)
5 00S
120 00 E
Netherlands Guiana (former name for Suriname)
2 00S
28 00E
Spitsbergen (island)
Svalbard
78 00N
20 00E
Srbija-Crna Gora (local name for Serbia and Montenegro)
Serbia and Montenegro
44 00N
2100E
St. John''s (city)
Canada (Newfoundland)
47 34N
52 43W
Stanley (capital)
Falkland Islands (Islas Malvinas)
5142S
57 41 W
Stockholm (capital)
2 00S
Sulawesi Sea
Pacific Ocean
3 00N
18 03E
911 E
6517W
32 33E
33 27E
8 00E
121 00 E
122 00 E
704
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Sulu Archipelago (island group)
0 00N
102 00 E
Sumba (island)
10 00S
120 00 E
Sumba Strait
Pacific Ocean
910S
120 00 E
Sumbawa (island)
8 30S
11800E
Sunda Islands (Soenda Isles)
Indonesia, Malaysia
2 00S
11000E
Sunda Strait
Indian Ocean
6 00S
105 45 E
Suomi (local name for Finland)','c4719cf6ccc0ce0029340f5064940e6070b18d37f80cafc9a0b62c4b9a8630a7','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('deadfb605be150611568d058ed205a8f9f2e91978f88ddb7ca9546cc3caa77cc',2007,'AT','Austria','transnational-issues',148,'—
""T
0 50 100 Km ''^
/•^ 5 v>
0 50 100 ml \\
{ CZECH REP.
\\ .Schaan ^v ,
\\ +VADUZ
SWITZERLAND! Tnesenberg ?
\\ .Triesen
yS Balzers ,,„,.,,
f • ^^- voider-
0 1 2 3 rri
Ogaden (region)
Ethiopia, Somalia
Oil Islands (Chagos Archipelago)
47 48N
13 02E
Samar (island)
4812N
16 22E
Vientiane (capital)
Laos
17 58N
102 36 E
Vilnius (capital)','bddcf03e7baf2f2c77922a132b8c19558a454a94141f13b45dc34c5969c53646','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ea6726b19f4962e01a6440c242933b4e8b6f421f8a5810f143accaf83189778',2007,'DE','Germany','transnational-issues',149,'^V^y^w
-18
■•vjgregenz ^_^_f.
jrN Unz VJENNA (SL0V
\\ WelS Neusteaier je^
\\ See* \\
.^—tiSalzburg ^~\\
/ H/ Jnnsbruck T
fit''60" o_ .Grossglockner .Graz J
SWITXTV-'' V^KIagenlurt. „ — f~* \\
\\ 7 ^~v*~"^-"^^ <**S
C. SLOVENIAJ ^
ITALY ,
V^ r^i— Arf*s> CROATIA
1 /~^V ^"~''*v>
-45 1
" Ven,ce ^ \\ ^ \\ HER.
Disputes - international: Austrian anti-nuclear
activists have revived blockades of the
Czech-Austrian border to protest operation of the
Temelin nuclear power plant in the Czech Republic
Illicit drugs: transshipment point for Southwest
Asian heroin and South American cocaine destined
for Western Europe
Disputes • international: none
Illicit drugs: source of precursor chemicals for South
American cocaine processors; transshipment point for
and consumer of Southwest Asian heroin, Latin
American cocaine, and European-produced synthetic
drugs; major financial center
BEL.^
MertertJ
) LUXEMBOURG
J *
J Petange
_ t ^~^S^ ^Drtferdange
S___ .Esch
FRANCE W^
Judelange
N
Disputes - international: none
336
Macau
(special administrative
region of China)
CHIN1
Disputes - international: none
338
Macedonia
■U ,;.n
Disputes - international: ethnic Albanians in
Kosovo object to demarcation of the boundary with
Macedonia in accordance with the 2000
Macedonia-Serbia and Montenegro delimitation
agreement; Greece continues to reject the use of the
name Macedonia or Republic of Macedonia
Refugees and internally displaced persons:
IDPs: 2,678 (ethnic conflict in 2001) (2005)
Illicit drugs: major transshipment point for
Southwest Asian heroin and hashish; minor transit
point for South American cocaine destined for Europe;
although not a financial center and most criminal
activity is thought to be domestic, money laundering is
a problem due to a mostly cash-based economy and
weak enforcement (no arrests or prosecutions for
money laundering to date)
West African Economic and Monetary Union
(WAEMU)
note— also known as Union Economique et
Monetaire Ouest Africaine (UEMOA)
established—] August 1994
aim— to increase competitiveness of members''
economic markets; to create a common market
members— (8) Benin, Burkina Faso, Cote d''lvoire, Guinea-Bissau, Mali, Niger, Senegal, Togo
Western European Union (WEU)
established— 23 October 1954
effective— 6 May 1955
aim—\\o provide mutual defense and to move
toward political unification
members— (10) Belgium, France, Germany, Greece, Italy, Luxembourg, Netherlands, Portugal, Spain, UK
associate members— (6) Czech Republic, Hungary. Iceland, Norway, Poland. Turkey
associate partners— (7) Bulgaria, Estonia, Latvia, Lithuania, Romania, Slovakia, Slovenia
observers— (5) Austria, Denmark. Finland, Ireland. Sweden
World Bank Group
World Confederation of Labor (WCL)
established— 19 June 1920 as the International
Federation of Christian Trade Unions (IFCTU),
renamed 4 October 1968
aim— to promote the trade union movement
World Food Program (WFP)
established— -24 November 1961
aim— to provide food aid in support of economic
development or disaster relief; an ECOSOC
organization
includes International Bank for Reconstruction and Development (IBRD), International Development Association
(IDA), International Finance Corporation (IFC), and Multilateral Investment Guarantee Agency (MIGA)
members— (105 national organizations) Antigua and Barbuda, Argentina, Aruba, Austria, Bangladesh, Belgium,
Belize, Benin, Bolivia, Brazil. Bulgaria, Burkina Faso, Cameroon, Canada, Central African Republic, Chad, Chile,
Colombia, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''lvoire, Cuba, Cyprus,
Czech Republic, Denmark, Dominica, Dominican Republic, Ecuador, El Salvador, France, French Guiana, Gabon,
The Gambia, Ghana, Guadeloupe, Guatemala, Guinea, Guyana, Haiti, Honduras, Hong Kong, Hungary, India,
Indonesia, Iran, Italy, Japan, Kazakhstan, South Korea, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg,
Macedonia, Madagascar, Malawi, Malaysia, Malta, Martinique, Mauritania, Mauritius, Mexico, Morocco, Namibia,
Nepal, Netherlands, Netherlands Antilles, Nicaragua, Niger, Pakistan, Panama, Paraguay, Peru, Philippines, Poland,
Portugal, Puerto Rico, Romania, Rwanda, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and Principe,
Senegal, Serbia and Montenegro, Sierra Leone, Singapore, Slovakia, South Africa, Spain, Sri Lanka, Suriname,
Switzerland, Taiwan, Thailand, Togo, Trinidad and Tobago, Ukraine, US, Uruguay, Venezuela, Vietnam, Zambia,
GM
DE
DEU
276
.de
48 30N
1130E
Beagle Channel
Atlantic Ocean
54 53S
6810W
Bear Island (see Bjornoya)
Svalbard
74 26N
19 05E
Beaufort Sea
Arctic Ocean
73 00N
140 00 W
Bechuanaland (former name for Botswana)
52 31 N
13 24E
Berlin, East (former name for eastern sector of Berlin)
52 30N
13 33E
Berlin. West (former name for western sector of Berlin)
52 30N
13 20E
Bern (capital)
48 00N
815E
Black Rock (island)
50 44N
7 05E
Bophuthatswana (region: enclave)
5100N
9 00E
Devils Island (He du Diable)
53 44N
7 25E
East Germany (German Democratic Republic;
former name for eastern portion of Germany)
52 00N
13 00E
East Korea Strait (Eastern Channel or Tsushima Strait)
Pacific Ocean
34 00N
129 00 E
East Pakistan (former name for Bangladesh)
52 00N
13 00E
German Southwest Africa (former name for Namibia)
51 00 N
9 00E
Gibraltar (city, peninsula)
49 25N
7 00E
Saaremaa (island)
5100N
13 00E
Schleswig-Holstein (region)
54 31 N
9 33E
Schweiz (local German name for Switzerland)
48 46N
Sucre (constitutional capital)
Bolivia
19 02S
Suez Canal
5100N
11 00 E
Thurston Island
West Island (capital)','6d5cf81d3a75ced11db1c9a12960c9f7fa4498eea53f7236c520e4dad065d2e6','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca16c23b53927e8de204b60c77aa1789171bb4d293071468f05f5a7492ac4af6',2007,'AZ','Azerbaijan','transnational-issues',166,'Disputes - international: Armenia supports ethnic
Armenian secessionists in Nagorno-Karabakh and
since the early 1990s has militarily occupied 16% of
Azerbaijan; over 800,000 mostly ethnic Azerbaijanis
were driven from the occupied lands and Armenia;
about 230,000 ethnic Armenians were driven from
their homes in Azerbaijan into Armenia; Azerbaijan
seeks transit route through Armenia to connect to
Naxcivan exclave; Organization for Security and
Cooperation in Europe (OSCE) continues to mediate
dispute; Azerbaijan, Kazakhstan, and Russia ratify
Caspian seabed delimitation treaties based on
equidistance, while Iran continues to insist on an even
one-fifth allocation and challenges Azerbaijan''s
hydrocarbon exploration in disputed waters; bilateral
talks continue with Turkmenistan on dividing the
seabed and contested oilfields in the middle of the
Caspian; Azerbaijan and Georgia continue to discuss
the alignment of their boundary at certain crossing
areas
Refugees and internally displaced persons:
refugees (country of origin): 8,367 (Russia)
IDPs: 528,000 (conflict with Armenia over
Nagorno-Karabakh) (2005)
Illicit drugs: limited illicit cultivation of cannabis and
opium poppy, mostly for CIS consumption; small
government eradication program; transit point for
Southwest Asian opiates bound for Russia and to a
lesser extent the rest of Europe
Bahamas, The
T
Grand
Bahama
U''S7 Proarv^TSouttlV,
I FreeP°rt SSfiv
Point
Abaco
J5 ISLANDS
O SO 100 km
O SO 100IT
NORTH
ATLANTIC
OCEAN
NASSAU^ -^Beuhva
I \\ '' New. J
•/* ■* Providence \\
Androsy&\\
Cat Island
)• Mount Alvemla
s^Sovnj
''''San Salvador
Greal''%^ v "Hum Cay
\\ Long Island
Exuma
..Samana
LMe
Inagva
Bahamas, The
40 30N
47 30E
Azerbaidzhan (local name for Azerbaijan)
40 30N
47 30E
Azores (islands)
40 23N
49 51 E
Baku (capital)
40 23N
49 51 E
Baky (see Baku)
40 23N
49 51 E
Balabac Strait
Pacific Ocean
7 35N
117 00 E
Balearic Islands
40 00N
46 40E
Nairobi (capital)
39 20N
45 20E
696
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Naxos (island)','0a85bdf27806e860b35a5a1e0baa87c313d3cdd6ee0e737741d5ac9a5bbbe137','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('655bb7607eca775551131efb6d3f491f8141a11bb6c49a2b49857e53d12fcdb8',2007,'BS','Bahamas','transnational-issues',175,'Disputes - international: disagrees with the US on
the alignment of the maritime boundary; continues to
monitor and interdict Haitian refugees fleeing
economic privation and political instability
Illicit drugs: transshipment point for cocaine and
marijuana bound for US and Europe; offshore
financial center
46
/
NORTH ATLANTIC
tes OCEAN
Isla de la
Juventud
Caribbean Sea
Cayman
%£^ Islands
0 50 100km
50 100 mi
Las Tunas^
Xi - JV--~~ Holguin
Manzanill''o]* .Bayamo
■ * Guantanamo
p<c '' ^— — '' so
<^~^ US " ru s ?aval Base
Guantanamo Bay','db92f3d716a450230a73437817202619a593e080b604b89c1425935a93731b2a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26949f4879a7b010ceb93220274e2e5dac1eb5b8a1c544f72e2c4e0220825ed8',2007,'BH','Bahrain','transnational-issues',176,'SAUDI '',
ARABIA
MANAMA^-fful?arrac<
JicJcTtf afsTl " '' -/*W Salman
'' ^ladfnat \\6>( ''^itrah
''Isa S\\ i ^
SAUDI
Disputes • international: none
-2S''oe
Gull of
•
Al Khuwayr
''1
HAWAP
ISLANDS
(BAHRAIN) ,
Dukhan
.Umm Bab
Umm §alal
Muhammad
DOHA
Ar Rayyan*
Al Wakrah,
Umm Said
Persian
-\\, Gulf
SAUDI
ARABIA
0 10 20 mi
The island ol Halul is not shown
Disputes - international: none
Reunion
(overseas department
of France)
0 5 10 km
1 '' r— '' ,
O 5 10 mi
SAINT-DENIS
Saint-Andre''
Saint-Benoit*
.Saint-Louis
^-^Saint-Pierre
Indian Ocean
.Saint-Joseph
Baker Island
26 00N
50 33E
Al Imarat al Arabiyah al Muttahidah (local name for
the United Arab Emirates)
7 00N
8100E
Diomede Islands
Russia (Big Diomede), United States (Little
Diomede)
65 47N
169 00 W
Diu (region)
25 40N
50 47E
Hayastan (local name for Armenia)
2613N
50 35E
Manchukuo (former state)','453a9b6bd9b06c07bf2ce5f11ef2642ed334ed1bbcb7b2fcb593ce2bd2048b12','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a15b0ec64cd469118bac2a0387f2eaaa313918ff354d39f97e888e813511cd17',2007,'BD','Bangladesh','transnational-issues',184,'Baker Island
(territory of the US)
Description under
■
Disputes - international: discussions with India
remain stalled to delimit a small section of river
boundary, exchange 162 miniscule enclaves in both
countries, allocate divided villages, and stop illegal
cross-border trade, migration, violence, and transit of
terrorists through the porous border; Bangladesh
resists India''s attempts to fence or wall off high-traffic
sections of the porous boundary; a joint
Bangladesh-lnuia boundary inspection in 2005
revealed 92 pillars are missing; dispute with India over
New Moore/South Talpatty/Purbasha Island in the
Bay of Bengal deters maritime boundary delimitation;
Burmese Muslim refugees strain Bangladesh''s
meager resources
Refugees and internally displaced persons:
refugees (country of origin): 20,402 (Burma)
IDPs: 61 ,000 (land conflicts, religious persecution)
(2005)
Illicit drugs: transi! country for illegal drugs
produced in neighboring countries
51
Barbados I\\T/|
Horth Pom
0 4 8 km
0 4 8 mi -
\\
NORTH ATLANTIC
OCEAN
^Speightstown
Mount
Bathsheba
•
Holetown
\\,
v^^^
BRIDGETOWN The Crane/
Gramtey Attains J
tntemettonal Airport^ S
Caribbean ~^^^m
Sea
~\\^T
Disputes - international: in 2005, Barbados and
Trinidad and Tobago agreed to compulsory
international arbitration that will result in a binding
award challenging whether the northern limit of
Trinidad and Tobago''s and Venezuela''s maritime
boundary extends into Barbadian waters and the
southern limit of Barbadian traditional fishing; joins
other Caribbean states to counter Venezuela''s claim
that Aves Island sustains human habitation, a criterion
under the UN Convention on the Law of the Sea
(UNCLOS), which permits Venezuela to extend its
EEZ/continental shelf over a large portion of the
Caribbean Sea
Illicit drugs: one of many Caribbean transshipment
points for narcotics bound for Europe and the US;
offshore financial center
Bassas da India
(possession of France)
D
0 2 4 km
o 2 4 m. Mozambique
Channel
Disputes - international: approximately 105,000
Bhutanese have lived decades as refugees in Nepal,
90% of whom reside in seven UN Office of the High
Commissioner for Refugees camps; Bhutan
cooperates with India to expel Indian separatists
Bolivia
23 43N
90 25E
Dhivehi Raajje (local name for Maldives)
24 00N
90 00E
East Siberian Sea
Arctic Ocean
74 00N
166 00 E
Easter Island (Isla de Pascua)','cfd37d334879e2e148d4f31ef020d3a7160009045560416d82307c57d0642b5e','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b518e163594c5c43d7b814426660954f9e119382ecbec681e5e7bba10bacbd3c',2007,'US','United States','transnational-issues',185,'Pacific Island
Wildlife Refuges
Pacific Island
Wildlife Refuges
255
Pacific Island
Wildlife Refuges
^
O 2 4 km
English Channel
Golle de Samt-Malo
Pacific Island
Wildlife Refuges
301
Pacific Island
Wildlife Refuges
Moldova
|#|
O 20 40 km
0 20 40 mi
Pacific Island
Wildlife Refuges
429
Prudhoe Bay
RUSSIA
.: .Slanos
NORTH PACIFIC
OCEAN
HAWAIIAN ISLANDS
(US I
C"0" TtuMP —
Am- ''.
.Boston
.New York
^•Philadelphia
San Diego*— >
.Honolulu
°_
o
500 1000 km
Francisco. {*■» Oklahoma *>°ianapoiis ^SHINGTON, DC
i „„ fl„„»iDe Vr.t C"y- i Memphis
Los Angeles. Phoenix n^||as 1
• New /''
uston '' Orleans .Jacksonville north
v \\ •_ * . .'' ATLANTIC
\\ Sen Antonio
VJ Miami. - ,
r
ATLANTIC
OCEAN
JAM^
IO0
Disputes - international: prolonged drought,
population growth, and outmoded practices and
infrastructure in the border region strains
water-sharing arrangements with Mexico; the US has
stepped up efforts to stem nationals from Mexico,
Central America, and other parts of the world from
crossing illegally into the US from Mexico; illegal
immigrants from the Caribbean, notably Haiti and the
Dominican Republic, attempt to enter the US through
Florida by sea; 1 990 Maritime Boundary Agreement in
the Bering Sea still awaits Russian Duma ratification;
managed maritime boundary disputes with Canada at
Dixon Entrance, Beaufort Sea, Strait of Juan de Fuca,
and around the disputed Machias Seal Island and
North Rock; US and Canada seek greater cooperation
in monitoring people and commodities crossing the
border; The Bahamas and US have not been able to
agree on a maritime boundary; US Naval Base at
Guantanamo Bay is leased from Cuba and only
mutual agreement or US abandonment of the area
can terminate the lease; Haiti claims US-administered
Navassa Island; US has made no territorial claim in
Antarctica (but has reserved the right to do so) and
does not recognize the claims of any other state;
Marshall Islands claims Wake Island
Refugees and internally displaced persons:
refugees (country of origin): the US admitted 52,868
refugees during FY03/04 including: 13,331 (Somalia),
6,000 (Laos), 3,482 (Ukraine), 2,959 (Cuba), 1,787
(Iran); note - 32,229 refugees had been admitted as of
30 June 2005
Illicit drugs: world''s largest consumer of cocaine,
shipped from Colombia through Mexico and the
Caribbean; consumer of heroin, marijuana, and
increasingly methamphetamine from Mexico;
consumer of high-quality Southeast Asian heroin; illicit
producer of cannabis, marijuana, depressants,
stimulants, hallucinogens, and methamphetamine;
money-laundering center
Background: The following US Pacific island
territories constitute the Pacific Remote Islands
National Wildlife Refuge Complex and as such are
managed by the Fish and Wildlife Service of the US
Department of Interior. These remote refuges are the
most widespread collection of marine- and
terrestrial-life protected areas on the planet under a
single country''s jurisdiction. They protect many
endemic species including corals, fish, shellfish,
marine mammals, seabirds, water birds, land birds,
insects, and vegetation not found elsewhere.
Baker Island: The US took possession of the island in
1857, and its guano deposits were mined by US and
British companies during the second half of the 19th
century. In 1935, a short-lived attempt at colonization
was begun on this island but was disrupted by World
War II and thereafter abandoned. The island was
established as a National Wildlife Refuge in 1974.
Howland Island: Discovered by the US early in the
19th century, the island was officially claimed by the
US in 1857. Both US and British companies mined for
guano until about 1890. In 1935, a short-lived attempt
at colonization was begun on this island, similar to the
effort on nearby Baker Island, but was disrupted by
World War II and thereafter abandoned. The famed
American aviatrix Amelia EARHART disappeared
while seeking out Howland Island as a refueling stop
during her 1937 round-the-world flight; Earhart Light,
a day beacon near the middle of the west coast, was
named in her memory. The island was established as
a National Wildlife Refuge in 1974.
Jarvis Island: First discovered by the British in 1821 ,
the uninhabited island was annexed by the US in 1858,
but abandoned in 1879 after tons of guano had been
removed. The UK annexed the island in 1889, but never
carried out plans for further exploitation. The US
occupied and reclaimed the island in 1935 until it was
abandoned in 1 942 during World War II. The island was
established as a National Wildlife Refuge in 1974.
Johnston Atoll: Both the US and the Kingdom of
Hawaii annexed Johnston Atoll in 1 858, but it was the
US that mined the guano deposits until the late 1880s.
Johnston and Sand Islands were designated wildlife
refuges in 1926. The US Navy took over the atoll in
1934, and subsequently the US Air Force assumed
control in 1948. The site was used for high-altitude
nuclear tests in the 1950s and 1960s, and until late in
2000 the atoll was maintained as a storage and
disposal site for chemical weapons. Munitions
destruction is now complete. Cleanup and closure of
the facility was completed by May 2005. The Fish and
Wildlife Service and the US Air Force are currently
discussing future management options, in the interim
Johnston Atoll and the three-mile Naval Defensive
Sea around it remain under the jurisdiction and
administrative control of the US Air Force.
586
United States Pacific Island
Wildlife Refuges (continued)
Midway Islands
0 1 2 ml
NORTH nwrf_jgjH.»jt
OCEAN
Midway Islands
» (U.S.)
O 300 600 Kllomelers
-I , 1
a u UNITED ISTATES
« Ay
/
<s»
°S>
Johnston Atoll
0 1 2km
/ .
Island Hlklna
Island
Sand
„ Island
airstrip /Z \\
(""V-vf Johnston
Island
''** 5
Hawaii
Johnston Atoll
. (U.S.)
NORTH PACIFIC
OCEAN
Kingman Reef
(U.S.)
Palmyra Atoll
(U.S.)
Howland Island
0 I. ''lHJ
& % Hml
reel
Howland Island
. (U.S.)
Equator
Baker Island
(U.S.)
USSR
Union of Soviet Socialist Republics (Soviet Union); used for information dated
before 25 December 1991
UV
ultra violet
632
Appendix A: Abbreviations (continued)
s
w
VHF
very-high-frequency
VSAT
very small aperture terminal
WADB
West African Development Bank
WAEMU
West African Economic and Monetary Union
WCL
World Confederation of Labor
WCO
World Customs Organization
Wetlands
Convention on Wetlands of International Importance Especially As Waterfowl
Habitat
WEU
Western European Union
WFP
World Food Program
WFTU
World Federation of Trade Unions
Whaling
International Convention for the Regulation of Whaling
WHO
World Health Organization
WIPO
World Intellectual Property Organization
WMO
World Meteorological Organization
WP
Warsaw Pact
WTO
World Trade Organization; note: see WToO for World Tourism Organization
WToO
World Tourism Organization
ZC
Zangger Committee
633
Appendix B:
International Organizations and Groups
An expanded listing may be found at:
http://www.cia.gov/cia/publications/factbook/appendix/appendix-b.html
advanced developing countries
advanced economies
African, Caribbean, and Pacific Group of
States (ACP Group)
established— -6 June 1 975
aim— to manage their preferential economic and
aid relationship with the EU
African Development Bank (AfDB)
note— its predecessor was Organization of
African Unity (OAU)
established— 9 September 1999
aim— to promote economic and social
development
African Union (AU)
note— replaces Organization of African Unity
(OAU)
established— 8 July 2001
aim— to achieve greater unity among African
States: to defend states'' integrity and
independence: to accelerate political, social, and
economic integration: to encourage international
cooperation; to promote democratic principles
and institutions
another term for those less developed countries (LDCs) with particularly rapid industrial development: see newly
industrializing economies (NIEs)
a term used by the International Monetary FUND (IMF) for the top group in its hierarchy of advanced economies,
countries in transition, and developing countries; it includes the following 28 advanced economies: Australia, Austria,
Belgium, Canada, Denmark, Finland, France, Germany, Greece, Hong Kong, Iceland, Ireland, Israel, Italy, Japan,
South Korea, Luxembourg, Netherlands, NZ, Norway, Portugal, Singapore, Spain, Sweden, Switzerland, Taiwan,
UK, US; note— this group would presumably also cover the following seven smaller countries of Andorra, Bermuda,
Faroe Islands, Holy See, Liechtenstein, Monaco, and San Marino that are included in the more comprehensive group
of "developed countries"
members— -(79) Angola, Antigua and Barbuda, The Bahamas, Barbados, Belize, Benin, Botswana, Burkina Faso,
Burundi, Cameroon, Cape Verde, Central African Republic, Chad, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Cook Islands, Cote d''lvoire, Cuba, Djibouti, Dominica, Dominican Republic, East Timor,
Equatorial Guinea, Eritrea, Ethiopia, Fiji, Gabon, The Gambia, Ghana, Grenada, Guinea, Guinea-Bissau, Guyana,
Haiti, Jamaica, Kenya, Kiribati, Lesotho, Liberia, Madagascar, Malawi, Mali, Marshall Islands, Mauritania, Mauritius,
Federated States of Micronesia, Mozambique, Namibia, Nauru, Niger, Nigeria, Niue, Palau, Papua New Guinea,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe,
Senegal, Seychelles, Sierra Leone, Solomon Islands, Somalia, South Africa, Sudan, Suriname, Swaziland,
Tanzania, Togo, Tonga, Trinidad and Tobago, Tuvalu, Uganda, Vanuatu, Zambia, Zimbabwe
regional members— -(53) Algeria, Angola, Benin, Botswana, Burkina Faso, Burundi, Cameroon, Cape Verde, Central
African Republic, Chad, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cote d''lvoire, Djibouti,
Egypt, Equatorial Guinea, Eritrea, Ethiopia, Gabon, The Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Lesotho,
Liberia, Libya, Madagascar, Malawi, Mali, Mauritania, Mauritius, Morocco, Mozambique, Namibia, Niger, Nigeria,
Rwanda, Sao Tome and Principe, Senegal, Seychelles, Sierra Leone, Somalia, South Africa, Sudan, Swaziland,
Tanzania, Togo, Tunisia, Uganda, Zambia, Zimbabwe
nonregional members— -(24) Argentina, Austria, Belgium, Brazil, Canada, China, Denmark, Finland, France,
Germany, India, Italy, Japan, South Korea, Kuwait, Netherlands, Norway, Portugal, Saudi Arabia, Spain, Sweden,
Switzerland, UK, US
members— (53) Algeria, Angola, Benin, Botswana, Burkina Faso, Burundi, Cameroon, Cape Verde, Central African
Republic, Chad, Comoros, Democratic Republic of the Congo. Republic of the Congo. Cote d''lvoire, Djibouti, Egypt,
Equatorial Guinea, Eritrea, Ethiopia, Gabon, The Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Lesotho, Liberia,
Libya, Madagascar, Malawi, Mali, Mauritania, Mauritius, Mozambique, Namibia, Niger, Nigeria, Rwanda, Sahrawi
Arab Democratic Republic (Western Sahara), Sao Tome and Principe, Senegal, Seychelles, Sierra Leone, Somalia,
South Africa, Sudan, Swaziland, Tanzania. Togo, Tunisia, Uganda, Zambia, Zimbabwe
Andean Community of Nations (CAN)
note— formerly known as the Andean Group
(AG), the Andean Parliament, and most recently
as the Andean Common Market (Ancom)
established— 26 May 1969; present name
established 1 October 1992
effective— )6 October 1969
aim— to promote harmonious development
through economic integration
members— (5) Bolivia, Colombia, Ecuador, Peru, Venezuela
634
Appendix B: International Organizations and Groups (continued)
Arab Bank for Economic Development in
Africa (ABEDA)
note— also known as Banque Arabe de
Developpement Economique en Afrique
(BADEA)
established— 18 February 1974
effective— 16 September 1974
aim— to promote economic development
Arab Fund for Economic and Social
Development (AFESD)
es/aMshed— 16 May 1968
aim— to promote economic and social
development
Arab Monetary Fund (AMF)
established-27 April 1976
effective— 2 February 1977
aim— to promote Arab cooperation,
development, and integration in monetary and
economic affairs
members— (17 plus the Palestine Liberation Organization) Algeria, Bahrain, Egypt, Iraq, Jordan, Kuwait, Lebanon,
Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Sudan, Syria, Tunisia, UAE, Palestine Liberation
Organization; note— these are all the members of the Arab League excluding Comoros, Djibouti, Somalia, Yemen
members— (20 plus the Palestine Liberation Organization) Algeria, Bahrain, Djibouti, Egypt, Iraq (suspended 1993),
Jordan, Kuwait, Lebanon, Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia (suspended 1993),
Sudan, Syria, Tunisia, UAE, Yemen, Palestine Liberation Organization
members— (21 plus the Palestine Liberation Organization) Algeria, Bahrain, Comoros, Djibouti, Egypt, Iraq, Jordan,
Kuwait, Lebanon, Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan, Syria, Tunisia, UAE,
Yemen, Palestine Liberation Organization
ASEAN Regional Forum (ARF)
established— 25 July 1994
aim— to foster constructive dialogue and
consultation on political and security issues of
common interest and concern
members— (25) Australia, Brunei, Burma, Cambodia, Canada, China, East Timor, EU, India, Indonesia, Japan,
North Korea, South Korea, Laos, Malaysia, Mongolia, NZ, Pakistan, Papua New Guinea, Philippines, Russia,
Singapore, Thailand, US, Vietnam
Asian Development Bank (AsDB)
established— 1 9 December 1966
aim— to promote regional economic cooperation
Asia-Pacific Economic Cooperation (APEC)
established— 7 November 1989
aim— to promote trade and investment in the
Pacific basin
members— (46) Afghanistan, Armenia, Australia, Azerbaijan, Bangladesh, Bhutan, Burma, Cambodia, China, Cook
Islands, East Timor, Fiji, Hong Kong, India, Indonesia, Japan, Kazakhstan, Kiribati, South Korea, Kyrgyzstan, Laos,
Malaysia, Maldives, Marshall Islands, Federated States of Micronesia, Mongolia, Nauru, Nepal, NZ, Pakistan, Palau,
Papua New Guinea, Philippines, Samoa, Singapore, Solomon Islands, Sri Lanka, Taiwan, Tajikistan, Thailand,
Tonga, Turkmenistan, Tuvalu, Uzbekistan, Vanuatu, Vietnam
nonregional members— {18) Austria, Belgium, Canada, Denmark, Finland, France, Germany, Italy, Luxembourg,
Netherlands, Norway, Portugal, Spain, Sweden, Switzerland, Turkey, UK, US
members— (21) Australia, Brunei, Canada, Chile, China, Hong Kong, Indonesia, Japan, South Korea, Malaysia,
Mexico, NZ, Papua New Guinea, Peru, Philippines, Russia, Singapore, Taiwan, Thailand, US, Vietnam
observers— (3) Association of Southeast Asian Nations, Pacific Economic Cooperation Council, Pacific Islands
Forum Secretariat
Association of Southeast Asian Nations
(ASEAN)
established— 8 August 1967
aim— to encourage regional economic, social,
and cultural cooperation among the
non-Communist countries of Southeast Asia
members— (10) Brunei, Burma, Cambodia, Indonesia, Laos, Malaysia, Philippines, Singapore, Thailand, Vietnam
associate member— {1) Papua New Guinea
dialogue partners— {12) Australia, Canada, China, EU, India, Japan, South Korea, NZ, Pakistan, Russia, US, UNDP
Australia Group
established— June 1 985
aim— to consult on and coordinate export
controls related to chemical and biological
weapons
members— (40) Argentina, Australia, Austria, Belgium, Bulgaria, Canada, Cyprus, Czech Republic, Denmark,
Estonia, European Commission, Finland, France, Germany, Greece, Hungary, Iceland, Ireland, Italy, Japan, South
Korea, Latvia, Lithuania, Luxembourg, Malta, Netherlands, NZ, Norway, Poland, Portugal, Romania, Slovakia,
Slovenia, Spain, Sweden, Switzerland, Turkey, Ukraine, UK, US
635
Appendix B: International Organizations and Groups (continued)
Australia-New Zealand-United States
Security Treaty (ANZUS)
established—} September 1951
effective— 29 April 1952
aim— to implement a trilateral mutual security
agreement, although the US suspended security
obligations to NZ on 1 1 August 1986; Australia
and the US continue to hold annual meetings
members— (3) Australia, NZ, US
Bank for International Settlements (BIS)
established— 20 January 1930
effective— 17 March 1930
aim— to promote cooperation among central
banks in international financial settlements
Benelux Economic Union (Benelux)
nofe— acronym from Belgium, Netherlands, and
US
US
USA
840
.us
ISO includes Baker Island, Howland
Island, Jarvis Island, Johnston Atoll,
Kingman Reef, Midway Islands,
Navassa Island, Palmyra Atoll, Wake
Island
65 00N
153 00 W
Alaska, Gulf of
Pacific Ocean
58 00N
145 00 W
Alboran Sea
Atlantic Ocean
36 00N
2 30W
678
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Aldabra Islands (Groupe d''Aldabra)
52 55N
172 57 E
Auckland Islands
19 45N
155 45 W
Hawaiian Islands
2100N
157 45 W
Hawar (island)
57 49N
152 23 W
Kola Peninsula (Kol''skiy Poluostrov)
Russia
67 20N
37 00E
Kolonia (town; former capital; changed to Palikir)
Federated States of Micronesia
6 58N
158 13 E
Korea Bay
Pacific Ocean
39 00N
124 00 E
Korea Strait
Pacific Ocean
34 00N
129 00 E
692
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Oesterreich (local name for Austria)
Prince Edward Island
4615N
Saint Helier (capital)
49 30N
Saint Lawrence Seaway
Atlantic Ocean
4915N
Saint Lawrence, Gulf of
Atlantic Ocean
48 00N
Saint Paul Island
57 11 N
170 16 W
Saint Paul Island (He Saint-Paul)
French Southern and Antarctic Lands
38 43S
77 29E
Saint Peter and Saint Paul Rocks (Penedos de
Sao Pedro e Sao Paulo)
Weddell Sea
Southern Ocean
Wellington (capital)','856be84960e5b4b939014d145dfd9bbe7595301a971492c696d4ed8b039d7337','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26f994d5a885962083e681e02774e31d88069a07bc5d1ae5cbd9fe05157437d8',2007,'FR','France','transnational-issues',198,'Disputes - international: claimed by Madagascar
54
Disputes - international: none
123
Cocos (Keeling)
Islands
(territory of Australia)
North Keeling J
Island
Indian
Ocean
Horsburgh
Island
*? ^Direction Island
reels* \\ reels
South
%^Home Island
\\
Keeli"9 %west
Islands K ''island \\
\\& ■i^pj'' South Island
reels
Disputes - international: none
Disputes • international: claimed by Madagascar
Entry
follows
country listing
187
Falkland Islands
(Islas Malvinas)
(overseas territory of the UK;\\
also claimed by Argentina)
SOUTH ATLANTIC
OCEAN
West
Falkland
Weddelt
"^./l ^''.Settlement
^■^Soose "Green
M^?7 ^JV^wrSeltlemem
East
Falkland
Scotia Sea
Administered by U.K.,
claimed by argesttina
Disputes - international: Argentina, which claims
the islands in its constitution and briefly occupied them
by force in 1982, agreed in 1995 to no longer seek
settlement by force; UK continues to reject Argentine
requests for sovereignty talks
189
Cherbourg. ,
I
,p.B''rest
'' —
UNITl i
KINGDOM
Dunkerque
no*1
Le Havre
* ''Rouen
PARIS*
.Orleans
Tours
\\ Nantes
Bordeaux
Lyon
Saint-Etienne.
Grenoble
Toulouse Monlpellier
Nice,
.Marseille
Toulon
Disputes - international: Suriname claims area
between Riviere Litani and Riviere Marouini (both
headwaters of the Lawa) in French Guiana
Illicit drugs: small amount of marijuana grown for
local consumption; minor transshipment point to
Europe
201
Disputes • international: none
203
French Southern
and Antarctic Lands
(overseas territory of France)
u
He Amsterdam
fie Saint- Paul .
INDIAN OCEAN
(
ILES CROZET
lie aux Cochons
. . lie Oe lEs!
lie oe la Possession
ILES KERGUELEN
Mont
floss
lie Kergueien
Heard Island and
McDonald Islands
[AU81
200 400km
Disputes - international: claimed by Madagascar
Disputes - international: none
Disputes • international: none
Illicit drugs: transshipment point for cocaine and
marijuana bound for the US and Europe
Disputes - international: Matthew and Hunter
islands east of New Caledonia claimed by France and
Disputes - international: none
Disputes - international: none
;
!
476
Saint Vincent and
the Grenadines
Ivl
Sea
aLa Soulntre
Chaleaubel.ni^
"Georgetown
Saint
Vincent ^KINGSTOWN
£2£ .Port Elizabeth
1,1, ., , ■■ Bakvaux Island
(/
Muslique
Savmn Island.
MrCmouvT
((, Can
Q>
A Corufta
Gij6n Santander
.Vigo
PORT
Le6n
MADRID,.
•» „ a ^ra90za. Barcelona
Tarragona. ''
(Sevilla
Granada
Castellbn
de la Plana
Valencia,
Alicante
Murcia.
Cartagena.
J
of
^°5
Huelva Cadiz .Malaga
Algeclras^Gibraiia,
•Ceutaisf
Palma
de
Mallorca
ATLANTIC
OCEAN
Melilla ■-.>>
Disputes - international: claimed by Mauritius
Disputes - international: none
/
559
BULGARIA S
R''AQ
0 50 100lat)\\
0 SO MXym-
Disputes - international: complex maritime, air, and
territorial disputes with Greece in the Aegean Sea;
status of north Cyprus question remains; Syria and
Iraq protest Turkish hydrological projects to control
upper Euphrates waters; Turkey has expressed
concern over the status of Kurds in Iraq; border with
Armenia remains closed over Nagorno-Karabakh
Refugees and internally displaced persons:
IDPs: 350,000-1,000,000 (fighting from 1984-99
between Kurdish PKK and Turkish military; most IDPs
in southeastern provinces) (2005)
Illicit drugs: key transit route for Southwest Asian
heroin to Western Europe and - to a far lesser extent
the US - via air, land, and sea routes; major Turkish,
Iranian, and other international trafficking
organizations operate out of Istanbul; laboratories to
convert imported morphine base into heroin are in
remote regions of Turkey and near Istanbul;
government maintains strict controls over areas of
legal opium poppy cultivation and output of poppy
straw concentrate; lax enforcement of
money-laundering controls
Disputes - international: in 2002, Gibraltar
residents voted overwhelmingly by referendum to
reject any "shared sovereignty" arrangement between
the UK and Spain; the Government of Gibraltar insists
on equal participation in talks between the two
countries; Spain disapproves of UK plans to grant
Gibraltar greater autonomy; Mauritius and Seychelles
claim the Chagos Archipelago (British Indian Ocean
Territory), and its former inhabitants since their
eviction in 1965; most Chagossians reside in
Mauritius, and in 2001 were granted UK citizenship
but no right to patriation in the UK; UK rejects
sovereignty talks requested by Argentina, which still
claims the Falkland Islands (Islas Malvinas) and South
Georgia and the South Sandwich Islands; territorial
claim in Antarctica (British Antarctic Territory)
overlaps Argentine claim and partially overlaps
Chilean claim; Iceland, the UK, and Ireland dispute
Denmark''s claim that the Faroe Islands'' continental
shelf extends beyond 200 nm
Illicit drugs: producer of limited amounts of synthetic
drugs and synthetic precursor chemicals; major
consumer of Southwest Asian heroin, Latin American
cocaine, and synthetic drugs: money-laundering
center
582
Disputes • international: none
West Bank
s
i<3 CO'' West Bank is israeii-cccupted with cut rem
status subject lo the Israeli-Palestinian
interim Agreement - permanent status to
be determined through further negotiation
,"\\
''Janin
(
\\
r"
t
i fulkarm
)
^Qalqilyah
I
/
\\
I
/
<l
\\,
V I Lalrun
_ .S I Salient
No Man''s Land
Nablus
.7«l Asiir
4
Ramallah
Jericho
France, Metropolitan
48 30N
7 20E
Amami Strait
Pacific Ocean
28 40N
129 30 E
Amindivi Islands (former name for Laccadive Islands)
44 50N
0 34W
Borneo (island)
Brunei. Indonesia, Malaysia
0 30N
114 00 E
Bornholm (island)
42 00N
9 00E
Cosmoledo Group (island group; also Atoll de Cosmoledo)
48 42N
6 11 E
Louisiade Archipelago
Republique Gabonaise (local name for Gabon)','e5d6bc85e0da19994dae4cccd314b9e165ab6d1d9c50e8cde37eab1dbb19d346','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f2a83cc8ff1573f93a4d1b52096c53a9758a8f3d2034f4028a7df79baa7ea750',2007,'BY','Belarus','transnational-issues',206,'Disputes - international: 1 997 boundary treaty with
Ukraine remains unratified over unresolved financial
claims, preventing demarcation and diminishing
border security; the whole boundary with Latvia and
more than half the boundary with Lithuania remains
undemarcated; discussions toward economic and
political union with Russia proceed slowly
Illicit drugs: limited cultivation of opium poppy and
cannabis, mostly for the domestic market;
transshipment point for illicit drugs to and via Russia,
and to the Baltics and Western Europe; a small and
lightly regulated financial center; new
anti-money-laundering legislation does not meet
international standards; few investigations or
prosecutions of money-laundering activities
0
S0m<
Disputes - international: Russia refuses to sign the
1997 boundary treaty due to Latvian insistence on a
unilateral clarificatory declaration referencing Soviet
occupation of Latvia and territorial losses; Russia
demands better Latvian treatment of ethnic Russians
in Latvia; the Latvian parliament has not ratified its
1998 maritime boundary treaty with Lithuania,
primarily due to concerns over oil exploration rights;
as a member state that forms part of the EU''s external
border, Latvia must implement the strict Schengen
border rules
Illicit drugs: transshipment point for opiates and
cannabis from Central and Southwest Asia to Western
Europe and Scandinavia and Latin American cocaine
and some synthetics from Western Europe to CIS;
despite improved legislation, vulnerable to money
laundering due to nascent enforcement capabilities
and comparatively weak regulation of offshore
companies and the gaming industry; CIS organized
crime (including counterfeiting, corruption, extortion,
stolen cars, and prostitution) accounts for most
laundered proceeds
Benadir (region; former name of Italian Somaliland)
Byelorussia (former name for Belarus)
Latitude
(deg min)
2106S
15 47S
48 09N
416S
13 06N
27 28S
57 00N
51 18 N
54 00N
27 30S
13 30S
100N
5 00N
17 15 N
8 00S
10 00N
50 50N
29 47N
44 26N
47 30N
34 36S
3 23S
48 00N
53 00N
53 00N
Longitude
(deg min)
55 36E
47 55W
17 07E
15 17 E
59 37W
153 02 E
160 00 W
3 30W
2 00W
23 30E
34 00E
38 00E
59 00W
88 45W
159 00 E
49 00E
4 20E
48 10E
26 06E
19 05E
58 27W
29 22E
26 00E
28 00E
28 00E
Cabinda (province)
53 54N
27 34E
Misr (local name for Egypt)','bf524c195e77c7a57a865ff0a12fc0cf108d0c67e0208d6caf6af1f0e91030ec','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6a68b759003db7000255379000294e8a3d86549834fa6170fc7b3ced1d8bc97',2007,'BZ','Belize','transnational-issues',215,'Disputes - international: none
Illicit drugs: growing producer of synthetic drugs;
transit point for US-bound ecstasy; source of
precursor chemicals for South American cocaine
processors; transshipment point for cocaine, heroin,
hashish, and marijuana entering Western Europe;
despite a strengthening of legislation, the country
remains vulnerable to money laundering related to
narcotics, automobiles, alcohol, and tobacco
O 25 SOkm
o 25 so mi Corozal,
range | |_j£
/
L
Puer|o
Codes
Caribbean Sea
ISLAS OS LA BAHIA
Puerto
La .Castilla
Ceiba
SWAN
ISLANDS
Tela
GUAT./.San
Santa Rosa p|d.r°
de Copan i>u,a
Juticalpa
Cem, .Comayagua
TEGUCIGALPA
•
/Lorenzo .
.» .Chpluteca
Atlantic Ocean
Southern Ocean
British Solomon Islands (former name for
Solomon Islands)','406fb9ee4441d05dc9aed5cc1df4b3e06909fb1d9f2ba14a6fe3787272704780','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f0f7f6bc6c655b264e4fa02bb190da5a55aad02402679954e61855805d9fbca',2007,'GT','Guatemala','transnational-issues',216,'Big Creekjf ,
~—Ranguana Cay
Gulf ■ ''of
f Honduras
r^X ^"HONDURAS
i
Disputes - international: Guatemalan squatters
continue to settle in the largely uninhabited rain
forests of Belize''s border region; OAS seeks to revive
the 2002 failed Belize-Guatemala Differendum that
created a small adjustment to land boundary, a
Guatemalan maritime corridor in Caribbean, joint
ecological park for disputed Sapodilla Cays, and
substantial US-UK financial package
Illicit drugs: transshipment point for cocaine;
small-scale illicit producer of cannabis for the
international drug trade; money-laundering activity
related to narcotics trafficking and offshore sector
Disputes - international: Benin and Burkina Faso
military clash in 2006 over sections of riverine
boundary involving disputed villages and squatters;
much of Benin-Niger boundary, including tripoint with
Nigeria, remains undemarcated; in 2005, Nigeria
ceded thirteen villages to Benin as a consequence of
a 2004 joint task force to resolve maritime and land
boundary disputes, but clashes among rival gangs
along the border persist; a joint boundary commission
continues to resurvey the boundary with Togo to verify
Benin''s claim that Togo moved boundary stones
Illicit drugs: transshipment point for narcotics
associated with Nigerian trafficking organizations and
most commonly destined for Western Europe and the
US; vulnerable to money laundering due to a poorly
regulated financial infrastructure
Puerto Barr''ros,
Puerto Santo Tomas*
de Castilla
Lago ae
Coban
.Huehuetenango
Volcan
Tajumufco
.Quetzaltenango
.Coatepeque GUATEMALA
Mixco**
Mazatenango * Villa Nueva
''Escumtla
Puerto
Quetzal
~* — — -~^
''- NORTH PACIFIC OCEAN (•» EL SALVADOR
Disputes - international: Guatemalan squatters
continue to settle in the rain forests of Belize''s border
region; Organization of American States (OAS) is
attempting to revive the 2002 failed Differendum that
created a small adjustment to land boundary, a
Guatemalan maritime corridor in Caribbean, a joint
ecological park for the disputed Sapodilla Cays, and a
substantial US-UK financial package; Guatemalans
enter Mexico illegally seeking work or transit to the US
Refugees and internally displaced persons:
IDPs: 250,000 (government''s scorched-earth
offensive in 1980s against indigenous people) 30,000
(Hurricane "Stan" October 2005) (2005)
Illicit drugs: major transit country for cocaine and
heroin; in 2004, reemerged as a potential source of
opium, growing 330 hectares of opium poppy, with
potential pure heroin production of 1 .4 metric tons;
76% of opium poppy cultivation in western highlands
along Mexican border; marijuana cultivation for mostly
domestic consumption; proximity to Mexico makes
Guatemala a major staging area for drugs (particularly
for cocaine); money laundering is a serious problem;
corruption is a major problem; remains on Financial
Action Task Force Non-Cooperative Countries and
Territories List for continued failure to address
deficiencies in money-laundering control regime
236
GT
GT
GTM
320
■gt
14 38N
90 31 W
Guinea Ecuatorial (local name for Equatorial Guinea)','c3143e24e61b3acc234faccb14c93da5d4f085ffa97e34d9d0c60b06885fa6a4','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcd8e880480032b571ce4e7a2aa0b00462eecf8145bb749082eb9517a79fb8f5',2007,'BM','Bermuda','transnational-issues',225,'(overseas territory of
the UK)
NORTH
ATLANTIC
OCEAN
Pond rials
Dockyard
Somerset A* Spanish
Island -■'' ff Ppinl .,7BVmH/«
.Somerset ^HAMILTON
Main Island
NORTH ATLANTIC
OCEAN
Disputes - international: none
BD
BM
BMU
060
.bm
3217N
64 46W
Han-guk (local name for South Korea)
South Korea
37 00N
127 30 E
Hanoi (capital)
Vietnam
2102N
105 51 E
Harare (capital)
32 20N
64 45W
Songkhla (city)','b7d36792469f890c9f6fc72870130e7eb979d68ac15e97056372fb62d16eeb0c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf33119fa3da06c922999c786f39daa44d73b57705d7400b5ae8febec99d35f2',2007,'BT','Bhutan','transnational-issues',234,'H I N
BT
BT
BTN
064
.bt
Bolivia
BL
BO
BOL
068
.bo
27 30N
90 30E
Dubai (city)
27 28N
89 39E
Thuringia (region)','3e2a74ffed02c60c0076562bf94c7ad93c3d04a9eaf90feb68dc74d8b245b14c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f33725d322b08d41f61237c82774137b7a5ebad35488b8cc575a6d512f48e824',2007,'PY','Paraguay','transnational-issues',242,'Disputes • international: Chile rebuffs Bolivia''s
reactivated claim to restore the Atacama corridor,
ceded to Chile in 1884, offering instead unrestricted
but not sovereign maritime access through Chile for
Bolivian natural gas and other commodities
Illicit drugs: world''s third-largest cultivator of coca
(after Colombia and Peru) with an estimated 26,500
hectares under cultivation in August 2005, an 8%
increase from 2004; intermediate coca products and
cocaine exported mostly to or through Brazil,
Argentina, and Chile to European drug markets;
cultivation steadily increasing despite eradication and
alternative crop programs; money-laundering activity
related to narcotics trade, especially along the borders
with Brazil and Paraguay
Bosnia and
Herzegovina
&J
Disputes ■ international: Bosnia and Herzegovina
and Serbia and Montenegro have delimited most of
their boundary, but sections along the Drina River
remain in dispute; discussions continue with Croatia
on several small disputed sections of the boundary
related to maritime access that hinder ratification of
the 1 999 border agreement
Refugees and internally displaced persons:
refugees (country of origin): 19,213 ^Croatia)
IDPs: 309,200 (Bosnian Croats, Serbs, and Muslims
displaced in 1992-95 war) (2005)
Illicit drugs: minor transit point for marijuana and
opiate trafficking routes to Western Europe; remains
highly vulnerable to money-laundering activity given a
primarily cash-based and unregulated economy, weak
law enforcement, and instances of corruption
PA
PY
PRY
600
■py
25 16S
57 40W
Asuncion Island','a2ce4214f9ce7f755c3357332ba2d9381f2ca152a88c84249b5697e9af9c704d','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da7dc6b4f7bf4de9697d0f717012ab9e8fbd7d07e016aeab46ea0da56cb9ccce',2007,'BW','Botswana','transnational-issues',257,'Disputes - international: commission established
with Namibia has yet to resolve small residual
disputes along the Caprivi Strip, including the Situngu
marshlands along the Linyanti River; downstream
Botswana residents protest Namibia''s planned
construction of the Okavango hydroelectric dam at
Popavalle (Popa Falls); Botswana has built electric
fences to stem the thousands of Zimbabweans who
flee to find work and escape political persecution.
Namibia has long supported and in 2004 Zimbabwe
dropped objections to plans between Botswana and
Zambia to build a bridge over the Zambezi River,
thereby de facto recognizing their short, but not clearly
delimited Botswana-Zambia boundary
77
BC
BW
BWA
072
.bw
22 00S
24 00E
Beijing (capital)
24 45S
25 55E
Galapagos Islands (Archipielago de Colon)','ec81e04fbb4ba9c414aefb0dd7cfad92a9a5b44a2ee1903dd931db38e71602bb','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ddaf985de3236d6de44be89a1ee1fb7ebe49a4662bb5cd474d54942ed10f28df',2007,'BV','Bouvet Island','transnational-issues',258,'(territory of Norway)
ss
0 1 2km
SOUTH
MM* ATLANTIC OCEAN
SOUTH
ATLANTIC OCEAN
BV
BV
BVT
074
.bv','ed0c0f2382a41d6d4a777cc91f7bbf82f410a9d6f110c08fb194ab77fcb7010b','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('97a650d63dccb2a50728fbd4a739d92283b0465f4d35438806eb56751b46f6d9',2007,'NO','Norway','transnational-issues',271,'Disputes - international: unruly region at
convergence of Argentina-Brazil-Paraguay borders is
locus of money laundering, smuggling, arms and
illegal narcotics trafficking, and fundraising for
extremist organizations; uncontested dispute with
Uruguay over certain islands in the Quarai/Cuareim
and Invernada boundary streams and the resulting
tripoint with Argentina; in 2004 Brazil submitted its
claims to the United Nations Convention on the Law of
the Sea (UNCLOS) to extend its maritime continental
margin
Illicit drugs: illicit producer of cannabis; trace
amounts of coca cultivation in the Amazon region,
used for domestic consumption; government has a
large-scale eradication program to control cannabis;
important transshipment country for Bolivian,
Colombian, and Peruvian cocaine headed for Europe;
also used by traffickers as a way station for narcotics
air transshipments between Peru and Colombia;
upsurge in drug-related violence and weapons
smuggling; important market for Colombian, Bolivian,
and Peruvian cocaine; illicit narcotics proceeds
earned in Brazil are often laundered through the
financial system; significant illicit financial activity in
the Tri-Border Area
British Indian
^J Lj2^~>.^.|
Ocean Territory
(overseas territory .
sgl^y^*
of the UK)
PEROS
BANHOS ,'' ■"
SALOMON
ISLANDS
INDIAN OCEAN
Nelsons
Island
THREE
EAGLE BROTHERS
ISLANDS ■ **
CHAGOS
Danger
lsland ARCHIPELAGO
EGMONT
ISLANDS
O 20 40 ton
i 1 — *— * ,
O 20 40 mi
Diego
t-\\Garda
Disputes - international: Mauritius and Seychelles
claim the Chagos Archipelago including Diego Garcia;
in 2001 the former inhabitants oi the Chagos
Archipelago, evicted in 1965 and now residing chiefly
in Mauritius, were granted UK citizenship and the right
to repatriation; the UK resists the Chagossians''
demand for an immediate return to the islands;
repatriation is complicated by the exclusive US
military lease of Diego Garcia that restricts access to
the largest island in the chain;
British Virgin
Islands
(overseas territory
of the UK)
O S 10 km
» '' . — i .
O 5 lOmi
NORTH ATLANTIC
OCEAN
Anegada
Jost
Vandyke ROAD
V
townt-^ i S£
Tortola
s?°
Virgin Islands
(U.S.)
Caribbean Sea
Background: Two centuries of Viking raids into Europe
tapered off following the adoption of Christianity by King
Olav TRYGGVASON in 994. Conversion of the
Norwegian kingdom occurred over the next several
decades. In 1 397, Norway was absorbed into a union
with Denmark that lasted more than four centuries. In
1814, Norwegians resisted the cession of their country to
Sweden and adopted a new constitution. Sweden then
invaded Norway but agreed to let Norway keep its
constitution in return for accepting the union under a
Swedish king. Rising nationalism throughout the 19th
century led to a 1905 referendum granting Norway
independence. Although Norway remained neutral in
World War I, it suffered heavy losses to its shipping.
Norway proclaimed its neutrality at the outset of World
War II, but was nonetheless occupied for five years by
Nazi Germany (1940-45). In 1949, neutrality was
abandoned and Norway became a member of NATO.
Discovery of oil and gas in adjacent waters in the late
1 960s boosted Norway''s economic fortunes. The current
focus is on containing spending on the extensive welfare
system and planning for the time when petroleum
reserves are depleted. In referenda held in 1972 and
1994, Norway rejected joining the EU.
Disputes • international: Norway asserts a
territorial claim in Antarctica (Queen Maud Land and
its continental shelf); despite recent discussions,
Russia and Norway continue to dispute their maritime
limits in the Barents Sea and Russia''s fishing rights
beyond Svalbard''s territorial limits within the Svalbard
Treaty zone
420
NO
NO
NOR
578
.no
62 00N
10 00E
Norman Isles (Channel Islands)
Guernsey, Jersey
49 20N
2 20W
North Atlantic Ocean
Atlantic Ocean
30 00N
45 00W
North Channel
Atlantic Ocean
5510N
5 40W
North Frisian Islands
Denmark, Germany
54 50N
812E
North Greenland Sea
Arctic Ocean
78 00N
5 00W
North Island
Osumi Strait (Van Diemen Strait)
Pacific Ocean
Otranto, Strait of
Atlantic Ocean
Ottawa (capital)','627971ffe3760a483429f08085e0604eecb230e7f49c99c682ccb5804c6f2a7c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4074ba0afc80214e2f4436930b6db5b2e17641c4b55f68098ac3e4d37e850151',2007,'MY','Malaysia','transnational-issues',280,'Disputes - international: in 2003 Brunei and
Malaysia ceased gas and oil exploration in their
disputed offshore and deepwater seabeds and
negotiations have stalemated prompting
consideration of international legal adjudication;
Malaysia''s land boundary with Brunei around Limbang
is in dispute; Brunei established an exclusive
economic fishing zone encompassing Louisa Reef in
southern Spratly Islands in 1984 but makes no public
territorial claim to the offshore reefs; the 2002
"Declaration on the Conduct of Parties in the South
China Sea" has eased tensions in the Spratly Islands
but falls short of a legally binding "code of conduct"
desired by several of the disputants
Illicit drugs: drug trafficking and illegally importing
controlled substances are serious offenses in Brunei
and carry a mandatory death penalty
[E€l=
VIETNAM
'' w
Basilan
Island
Mount
Apo N
Celebes
Sea
A
Disputes - international: separatist violence in
Thailand''s predominantly Muslim southern provinces
prompt border closures and controls with Malaysia to
stem terrorist activities; southeast Asian states have
enhanced border surveillance to check the spread of
avian flu; talks continue on completion of demarcation
with Thailand but disputes remain over several areas
along Mekong River and Thai squatters; despite
continuing border committee talks, significant
differences remain with Burma over boundary
alignment and the handling of ethnic rebels, refugees,
and illegal cross-border activities; Cambodia and
Thailand dispute sections of boundary with missing
boundary markers; Cambodia claims Thai
encroachments into Cambodian territory and
obstructing access to Preah Vihear temple ruins
awarded to Cambodia by ICJ decision in 1962; ethnic
Karens from Burma flee into Thailand - to escape
fighting between Karen rebels and Burmese troops -
resulting in Thailand sheltering about 120,000
Burmese refugees in 2005; Karens also protest Thai
support for a Burmese hydroelectric dam construction
on the Salween River near the border;
environmentalists in Burma and Thailand remain
concerned about China''s construction of hydroelectric
dams upstream on the Nujiang/Salween River in
Yunnan Province
Refugees and internally displaced persons:
refugees (country of origin): 120,814 (Burma)
IDPs: 6,000 (26 December 2004 tsunami) (2005)
Illicit drugs: a minor producer of opium, heroin, and
marijuana; illicit transit point for heroin en route to the
international drug market from Burma and Laos;
eradication efforts have reduced the area of cannabis
cultivation and shifted some production to neighboring
countries; opium poppy cultivation has been reduced
by eradication efforts; also a drug money-laundering
center; minor role in methamphetamine production for
regional consumption; major consumer of
methamphetamine since the 1 990s
Disputes - international: in 2001 Benin claimed
Togo moved boundary monuments - joint commission
continues to resurvey the boundary
Illicit drugs: transit hub for Nigerian heroin and
cocaine traffickers; money laundering not a significant
problem
MY
MY
MYS
458
.my
5 26N
100 16 E
Georgetown (capital)
Russia (de facto)
5 23N
100 15 E
Pentland Firth (channel)
Atlantic Ocean
58 44N
313W
Perim (island)
5 20N
117 10 E
Sable Island
2 30N
11330E
Sardinia (island)','b02458fbc3680f6888e2c036fed18b5557efd0f6ec9bb4d85745a7827c55b098','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1191ebfa2b75476507d2a89760d23bb4bbfc2f4c1657457dc0f2ed9afaee426a',2007,'BG','Bulgaria','transnational-issues',289,'Disputes - international: none
Illicit drugs: major European transshipment point for
Southwest Asian heroin and, to a lesser degree,
South American cocaine for the European market;
limited producer of precursor chemicals; some money
laundering of drug-related proceeds through financial
institutions
BU
BG
BGR
100
■bg
42 41 N
2319E
Solomon Islands, northern','99a34e5c072564b82314f2d524758679540ea5a295258bc02de430b41f54180e','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bc6f9aea44a6aaa205b51f91445b1a3c156a96d2d58979b3e1ede079afbc05e',2007,'BF','Burkina Faso','transnational-issues',290,'Background: Burkina Faso (formerly Upper Volta)
achieved independence from France in 1960.
Repeated military coups during the 1970s and 1980s
were followed by multiparty elections in the early
1990s. Burkina Faso''s high population density and
limited natural resources result in poor economic
prospects for the majority of its citizens. Recent unrest
in Cote d''lvoire and northern Ghana has hindered the
ability of several hundred thousand seasonal
Burkinabe farm workers to find employment in
neighboring countries.
Disputes - international: two villages are in dispute
along the border with Benin; Benin accuses Burkina
Faso of moving boundary pillars; Burkina Faso border
regions remain a staging area for Liberia and Cote
d''lvoire rebels and an asylum for refugees caught in
local fighting; the Ivoirian Government accuses
Burkina Faso of sheltering Ivoirian rebels
/\\Bago.
RANGObN
Bengal I ?Palhein * Mawlimyine
<4& ■
UV
BF
BFA
854
.bf
Burma
BM
MM
MMR
104
.mm
ISO uses the name Myanmar
Outer Hebrides (islands)
13 00N
Longitude
(deg min)
60 00E
60 00E
7100W
11 00 E
170 42 W
10 30E
12 00E
20 33E
32 00E
106 53 E
130 52 E
7 00W
57 00E
164 50 W
2 00W
Ural Mountains
Kazakhstan, Russia
60 00N
60 00E
Urdunn (local name for Jordan)','98a1bfcf8d97e4a03b2bda53dd91c6a3f2aca95f046948c304821e36559b8e5d','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4895b5511bb8620a001bfabd5c1eba092b06f6c89290125869247ba1aef6fc8a',2007,'TH','Thailand','transnational-issues',296,'Andaman
Sea
"■ ANDAMAN
r ISLANDS
•> (INDIA)
100 2O0km
Disputes - international: over half of Burma''s
population consists of diverse ethnic groups with
substantial numbers of kin beyond its borders; despite
continuing border committee talks, significant
differences remain with Thailand over boundary
alignment and the handling of ethnic rebels, refugees,
and illegal cross-border activities; ethnic Karens flee
into Thailand to escape fighting between Karen rebels
and Burmese troops; in 2005 Thailand sheltered
about 121 ,000 Burmese refugees; Karens also protest
Thai support for a Burmese hydroelectric dam on the
Salween River near the border; environmentalists in
Burma and Thailand continue to voice concern over
China''s construction of hydroelectric dams upstream
on the Nujiang/Salween River in Yunnan Province;
India seeks cooperation from Burma to keep Indian
Nagaland separatists from hiding in remote Burmese
uplands
Refugees and internally displaced persons:
IDPs: 550,000-1 ,000,000 (government offensives
against ethnic insurgent groups near borders; most
IDPs are ethnic Karen, Karenni, Shan, Tavoyan, and
Mon) (2005)
Illicit drugs: remains world''s second largest
producer of illicit opium (estimated production in
2004 - 292 metric tons, down 40% from 2003 due to
eradication efforts and drought; cultivation in 2004 -
30,900 hectares, a 34% decline from 2003); lack of
government will to take on major narcotrafficking
groups and lack of serious commitment against
money laundering continues to hinder the overall
antidrug effort; major source of methamphetamine
and heroin for regional consumption; currently under
Financial Action Task Force countermeasures due to
continued failure to address its inadequate
money-laundering controls (2005)
South China
Sea
Philippine
Sea
BRUNEI.
•vra 5 ^Puteu Ligilan
MALAYSIA J^ffpuiau c
f * Slpaton Son
rneo <
NORTH
PACIFIC
OCEAN
Sumatra r^
PalembangM^O.
-V^n-
INDIAN
OCEAN
■ i Sea
JAKARTA
* . Semarang u^un,
Cct°cap- ''*" *»fe
Denpasar*
(Celebes)
Sis*
Makassar
Ui
Kupang
'' ''-. / W IRIAN JAY,
c*AmboiV M>r__ Ap"''*f
!/
Jaya
New G
f
•v
7 EAST TIMOR
n
Ur^TR
ALIA
Disputes ■ international: East Timor-Indonesia
Boundary Committee continues to meet, survey, and
delimit land boundary, but several sections of the
boundary remain unresolved; many East Timorese
refugees who left in 2003 still reside in Indonesia and
refuse repatriation; Indonesia and East Timor contest
the sovereignty of the uninhabited coral island of
Pulau Batek/Fatu Sinai, which hinders a decision on a
northern maritime boundary; a 1997 treaty between
Indonesia and Australia settled some parts of their
maritime boundary but outstanding issues remain;
ICJ''s award of Sipadan and Ligitan islands to Malaysia
in 2002 left maritime boundary in the hydrocarbon-rich
Celebes Sea in dispute, culminating in hostile
confrontations in March 2005 over concessions to the
Ambalat oil block; the ICJ decision has prompted
Indonesia to assert claims to and to establish a
presence on its smaller outer islands; Indonesia and
Singapore pledged in 2005 to finalize their 1973
maritime boundary agreement by defining unresolved
areas north of Batam Island; Indonesian
secessionists, squatters, and illegal migrants create
repatriation problems for Papua New Guinea; piracy
remains a problem in the Malacca Strait
Refugees and internally displaced persons:
IDPs: 570,000 (resulting from 26 December 2004
tsunami) 500,000 (government offensives against
rebels in Aceh; most IDPs in Aceh, Central
Kalimantan, Maluku, and Central Sulawesi
Provinces); (2005)
Illicit drugs: illicit producer of cannabis largely for m
domestic use; producer of methamphetamine and
ecstasy
Disputes - international: Iran protests
Afghanistan''s limiting flow of dammed tributaries to
the Helmand River in periods of drought; Iraq''s lack of
a maritime boundary with Iran prompts jurisdiction
disputes beyond the mouth of the Shaft al Arab in the
Persian Gulf; Iran and UAE dispute Tunb Islands and
Abu Musa Island, which are occupied by Iran; Iran
stands alone among littoral states in insisting upon a
division of the Caspian Sea into five equal sectors
Refugees and internally displaced persons:
refugees (country of origin): 952,802 (Afghanistan)
93,173 (Iraq) (2005)
Illicit drugs: despite substantial interdiction efforts,
Iran remains a key transshipment point for Southwest
Asian heroin to Europe; domestic narcotics
consumption remains a persistent problem and
according to official Iranian statistics there are at least
2 million drug users in the country; lacks
anti-money-laundering laws
Disputes - international: coalition forces assist
Iraqis in monitoring boundary security; Iraq''s lack of a
maritime boundary with Iran prompts jurisdiction
disputes beyond the mouth of the Shatt al Arab in the
Persian Gulf; Turkey has expressed concern over the
status of Kurds in Iraq
Refugees and internally displaced persons:
refugees (country of origin): 22,71 1 (Palestinian
Territories)
IDPs: 1 million (ongoing US-led war and Kurds''
subsequent return) (2005)
Disputes - international: Southeast Asian states
have enhanced border surveillance to check the
spread of avian flu; talks continue on completion of
demarcation with Thailand but disputes remain over
several areas along Mekong River and Thai squatters;
concern among Mekong Commission members that
China''s construction of dams on the Mekong River will
affect water levels
Illicit drugs: estimated cultivation in 2004 - 10,000
hectares, a 45% decrease from 2003; estimated
potential production in 2004 - 49 metric tons, a
significant decrease from 200 metric tons in 2003
(2005)
316
SPRATLY
ISLANDS
Kuala
Terengganu
Kota
H,ih,irij
A4mj
George* Taip|ng
Town •• .Ipoh
,Lumut
KUALA Kuantan
LUMPUR*
South China Sea
IUNEI ..
Phuket*
Malacca
indo.-
50 100
.Con Dao
Disputes - international: southeast Asian states
have enhanced border surveillance to check the
spread of avian flu; Cambodia and Laos protest
Vietnamese squatters and armed encroachments
along border; after years of Cambodia claiming
Vietnam had moved or destroyed boundary markers,
in 2005, after much domestic debate, Cambodia
ratified an agreement with Vietnam that settled all but
a small portion of the land boundary; establishment of
a maritime boundary with Cambodia is hampered by
unresolved dispute over offshore islands; in 2004,
Laotian-Vietnamese boundary commission agrees to
erect missing markers in two adjoining provinces;
demarcation of the China-Vietnam boundary
proceeds slowly and although the maritime boundary
delimitation and fisheries agreements were ratified in
June 2004, implementation has been delayed; China
occupies Paracel Islands also claimed by Vietnam
and Taiwan; involved in complex dispute with China,
Malaysia, Philippines, Taiwan, and possibly Brunei
over the Spratly Islands; the 2002 "Declaration on the
Conduct of Parties in the South China Sea" has eased
tensions but falls short of a legally binding "code of
conduct" desired by several of the disputants; Vietnam
continues to expand construction of facilities in the
Spratly Islands; in March 2005, the national oil
companies of China, the Philippines, and Vietnam
signed a joint accord to conduct marine seismic
activities in the Spratly Islands
Illicit drugs: minor producer of opium poppy;
probable minor transit point for Southeast Asian
heroin; government continues to face domestic opium/
heroin/methamphetamine addiction problems despite
longstanding crackdowns
Virgin Islands
(territory of the US)
— i
NORTH ATLANTIC
OCEAN ■ British Virgin Islands
Saint ■ C,o*n „_. .- '' . '''' (U.K.) „
Thomas -MCunlmn CtM
A * .Bay -^
CHARLOTTE *"
AMALIE Saint
John
Caribbean
Sea
Saint Croix
Christiansted,''
Limetree Bay. „ . ...
• O 5 10 km
O 5 10 m,
Disputes - international: none
604
Wake Island
(territory of the US)
13 45N
100 31 E
Bangui (capital)
Pretoria (administrative capital)
15 00N
100 00 E
Siberia (region)
Russia
60 00N
100 00 E
Sibutu Passage
Pacific Ocean
4 50N
11 9 35 E
Sicily (island)
Sicily, Strait of
Sidra, Gulf of
Sikkim (state)
Silesia (region)
Sinai Peninsula
Singapore (capital)
Singapore Strait
Sinkiang (autonomous region; also Xinjiang)
Sint Eustatius (island)
Sint Maarten (island; also Saint-Martin)
Sjaelland (island)
Skagerrak (strait)
Skopje (capital)
Slavonia (region)
712N
100 36 E
Sound, The (strait; also Oresund)
Atlantic Ocean
55 50N
12 40E
South Atlantic Ocean
Atlantic Ocean
30 00S
15 00W
South China Sea
Pacific Ocean
10 00N
113 00 E
South Georgia (island)','c9f088bcd1546ff137700e00e658b5cf066d8f63431a66e3b61a6992053ef443','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d11e98d21bb17a5a83897a82295de3527bfc935fd21c35113b6915d865016bfc',2007,'BI','Burundi','transnational-issues',307,'DEM. REP
OF
THE
BY
Bl
BDI
108
.bi
Bukovina (region)
Romania, Ukraine
Byelarus (local name for Belarus)
3 30S
30 00E
Ussuri River
China, Russia
48 28N
135 02 E
Vaduz (capital)','2e592e8582dcaf656fa152225a003b28144fb9d8d3476c0c3b7f5add7510954c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('40f4b16e276e6ae69d9b6ac84a2383248ca66fb40e5a0730dedce34dcfad79a6',2007,'CG','Congo','transnational-issues',316,'Disputes - international: Tutsi, Hutu, other
conflicting ethnic groups, associated political rebels,
armed gangs, and various government forces
continue fighting in the Great Lakes region,
transcending the boundaries of Burundi, Democratic
Republic of the Congo, Rwanda, and Uganda in an
effort to gain control over populated and natural
resource areas; government heads pledge to end
conflict, but localized violence continues despite the
presence of about 6,000 peacekeepers from the UN
Operation in Burundi (ONUB) since 2004; although
some 150,000 Burundian refugees have been
repatriated, as of February 2005, Burundian refugees
still reside in camps in western Tanzania as well as the
Democratic Republic of the Congo
Refugees and internally displaced persons:
refugees (country of origin): 48,424 (Democratic
Republic of the Congo)
IDPs: 145,000 (armed conflict between government
and rebels; most IDPs in northern and western
Burundi) (2005)
Disputes - international: Southeast Asian states
have enhanced border surveillance to check the
spread of avian flu; Cambodia and Thailand dispute
sections of boundary with missing boundary markers
and Thai encroachments into Cambodian territory;
maritime boundary with Vietnam is hampered by
unresolved dispute over offshore islands; Cambodia
accuses Thailand of obstructing access to Preah
Vihear temple ruins awarded to Cambodia by ICJ
decision in 1962; in 2004, Cambodian-Laotian and
Laotian-Vietnamese boundary commissions
re-erected missing markers completing most of their
demarcations
Illicit drugs: narcotics-related corruption reportedly
involving some in the government, military, and police;
possible small-scale heroin and methamphetamine
production; vulnerable to money laundering due to its
cash-based economy and porous borders
Disputes - international: about 30,000 refugees
fleeing the 2002 civil conflict in the CAR still reside in
southern Chad; periodic skirmishes over water and
grazing rights among related pastoral populations
along the border with southern Sudan persist
Refugees and internally displaced persons:
refugees (country of origin): 19,470 (Sudan) 1 ,864
(Chad) 6,484 (Democratic Republic of the Congo)
IDPs: 200,000 (unrest following coup in 2003) (2005)
Disputes - international: heads of the Great Lakes
states and UN pledge to end conflict but unchecked tribal,
rebel, and militia fighting continues unabated in the
northeastern region of the Democratic Republic of the
Congo, drawing in the neighboring states of Burundi,
Rwanda and Uganda; the UN Organization Mission in the
Democratic Republic of the Congo (MONUC) has
maintained over 14,000 peacekeepers in the region
since 1999; thousands of Ituri refugees from the Congo
continue to flee the fighting primarily into Uganda; 90,000
Angolan refugees were repatriated by 2004 with the
remainder in the DRC expected to return in 2005; in
2005, DRC and Rwanda established a border verification
mechanism to address accusations of Rwandan military
supporting Congolese rebels and the DRC providing
rebel Rwandan "Interhamwe" forces the means and
bases to attack Rwandan forces; the location of the
boundary in the broad Congo River with the Republic of
the Congo is indefinite except in the Pool Malebo/Stanley
Pool area
Refugees and internally displaced persons:
refugees (country of origin): 5,277 (Republic of
Congo) 11,816 (Rwanda) 18,953 (Uganda) 19,400
(Burundi) 45,226 (Sudan) 98,383 (Angola)
IDPs: 2.33 million (fighting between government
forces and rebels since mid-1990s; most IDPs are in
eastern provinces) (2005)
Illicit drugs: illicit producer of cannabis, mostly for
domestic consumption; while rampant corruption and
inadequate supervision leaves the banking system
vulnerable to money laundering, the lack of a
well-developed financial system limits the country''s utility
as a money-laundering center
132
Congo, Republic of the
Background: Upon independence in 1960, the
former French region of Middle Congo became the
Republic of the Congo. A quarter century of
experimentation with Marxism was abandoned in
1990 and a democratically elected government took
office in 1 992. A brief civil war in 1 997 restored former
Marxist President Denis SASSOU-NGUESSO, and
ushered in a period of ethnic and political unrest.
Southern-based rebel groups agreed to a final peace
accord in March 2003, but the calm is tenuous and
refugees continue to present a humanitarian crisis.
The Republic of Congo was once one of Africa''s
largest petroleum producers, but with declining
production it will need to hope for new offshore oil
finds to sustain its oil earnings over the long term.
e o g r a p h y
Location: Western Africa, bordering the South
Atlantic Ocean, between Angola and Gabon
Geographic coordinates: 1 00 S, 1 5 00 E
Map references: Africa
Area:
total: 342,000 sq km
land: 341,500 sq km
water: 500 sq km
Area - comparative: slightly smaller than Montana
Land boundaries:
total: 5,504 km
border countries: Angola 201 km, Cameroon 523 km,
Central African Republic 467 km, Democratic
Republic of the Congo 2,410 km, Gabon 1,903 km
Coastline: 169 km
Maritime claims:
territorial sea: 200 nm
Climate: tropical; rainy season (March to June); dry
season (June to October); persistent high
temperatures and humidity; particularly enervating
climate astride the Equator
Terrain: coastal plain, southern basin, central
plateau, northern basin
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Berongou 903 m
Natural resources: petroleum, timber, potash, lead,
zinc, uranium, copper, phosphates, gold, magnesium,
natural gas, hydropower
Land use:
arable land: 1.45%
permanent crops: 0.1 5%
other: 98.4% (2005)
Irrigated land: 10 sq km (1998 est.;
Natural hazards: seasonal flooding
Environment - current issues: air pollution from
vehicle emissions; water pollution from the dumping of
raw sewage; tap water is not potable; deforestation
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Ozone Layer
Protection, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: Law of the Sea
Geography • note: about 70% of the population lives
in Brazzaville, Pointe-Noire, or along the railroad
between them
Disputes - international: about 7,000 Congolese
refugees fleeing infernal civil conflicts since the
mid-1990s still reside in the Democratic Republic of
the Congo; the location of the boundary in the broad
Congo River with the Democratic Republic of the
Congo is indefinite except in the Pool Malebo/Stanley
Pool area
Refugees and internally displaced persons:
refugees (country of origin): 53,834 (Democratic
Republic of Congo)
IDPs: 60,000 (multiple civil wars since 1992; most
IDPs are ethnic Lari) (2005)','262a8f543709bd19cb2c89c7baa02630dfe310b5f14c61ea52e2a29989b4c2e7','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('951f3ed08703feae3ecf991c433d5e696ee49da98b9aa28957027f788b87c7a0',2007,'CM','Cameroon','transnational-issues',324,'Disputes - international: ICJ ruled in 2002 on the
entire Cameroon-Nigeria land and maritime boundary
but the parties formed a Joint Border Commission,
which continues to meet regularly to resolve
differences bilaterally and have commenced with
demarcation in less-contested sections of the
boundary, starting in Lake Chad in the north;
implementation of the ICJ ruling on the
Cameroon-Equatorial Guinea-Nigeria maritime
boundary in the Gulf of Guinea is impeded by
imprecisely defined coordinates, the unresolved
Bakassi allocation, and a sovereignty dispute between
Equatorial Guinea and Cameroon over an island at
the mouth of the Ntem River; Nigeria initially rejected
cession of the Bakasi Peninsula, then agreed, but has
yet to withdraw its forces while much of the indigenous
population opposes cession; only Nigeria and
Cameroon have heeded the Lake Chad Commission''s
admonition to ratify the delimitation treaty which also
includes the Chad-Niger and Niger-Nigeria
boundaries
Refugees and internally displaced persons:
refugees (country of origin): 39,290 (Chad) 16,686
(Nigeria) 9,634 (Cote d''lvoire) (2005)
102
Bata
Acalayong
Isla de Consco
SCO Bay
(
Mbmi
Ebebiyin
Mongomo,
Evinayong
CM
CM
CMR
120
.cm
Campbell Island
4 03N
9 42E
Douglas (capital)
Man. Isle of
54 09N
4 28W
Dover, Strait of
Atlantic Ocean
5100N
130E
Drake Passage
Atlantic Ocean, Southern Ocean
60 00S
60 00W
Druk Yul (local name for Bhutan)
6 00N
12 00E
French Guinea (former name for Guinea)
Yap Islands
Federated States of Micronesia
Yaren (governmental center)','ec9a3e210c3ca0e16fdcd068e41811e2b8ff47ef1552b06b44f1e18b3949c3ab','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e1c11c08353c177d0f3ea1e59011567d27446fead4c82cd2912a4397859509c',2007,'CA','Canada','transnational-issues',325,'NORTH
XTL4WT/C
OCEAN
St. John''s
Sept-lies
,C!''9ary . w,nn,&a Thund*r Quebec, (\\ .Halifax
jtegina* wnnigeg OTTAWA // ^SamtJo^n
"^ — 7>v , Tte"1flonfreal
iiwiTcn ctatcc G^8"^?. /^onto,/*
'' * ^Hamilton
Disputes - international: managed maritime
boundary disputes with the US at Dixon Entrance,
Beaufort Sea, Strait of Juan de Fuca, and around the
disputed Machias Seal Island and North Rock;
working toward greater cooperation with US in
monitoring people and commodities crossing the
border; uncontested sovereignty dispute with
Denmark over Hans Island in the Kennedy Channel
between Ellesmere Island and Greenland
Illicit drugs: illicit producer of cannabis for the
domestic drug market and export to US; use of
hydroponics technology permits growers to plant large
quantities of high-quality marijuana indoors; transit
point for ecstasy entering the US market; vulnerable to
narcotics money laundering because of its mature
financial services sector
105
Cape Verde
0
Santo o
Antao
1 / Mindelo
Santa Luzia
Sao
Vicente '' ° 0~5^s
*■*/„ Sao Nicolau
«(jj
Santa
Maria
Boa
Vista
NORTH ATLANTIC C/V^0 «—
OCEAN
n0 SOTAVENTO
--— «-,< Sao
\\V-
^S W~ Tarrafal.- ^°
Sao mt 4 \\
Fihpe. a**0 +(
Brava
Fogo
Maio
MA
CA
CA
CAN
124
.ca
Cape Verde
CV
CV
CPV
132
XV
79 30N
90 00W
Azad Kashmir (region)
68 00N
70 00W
Baghdad (capital)
75 15N
121 30 W
Banks Islands (lies Banks)
76 00N
87 00W
Dhaka (capital)
78 00N
103 00 W
Ellesmere Island
8100N
80 00W
Ellice Islands
Atlantic Ocean
45 31 N
73 34W
Moravia (region)
Czech Republic
49 30N
17 00E
Moravian Gate (pass)
Czech Republic
49 35N
17 50E
Moroni (capital)
52 00N
56 00W
Niamey (capital)
40 00N
43 00N
30 00N
56 00N
23 00N
15 00N
25 40N
35 15N
40 00N
12 45N
54 40N
15 00S
74 40N
64 05N
127 00 E
44 10E
165 00 W
4 00E
106 00 E
44 00E
77 09W
33 44E
20 30E
61 15 W
6 45W
30 00E
100 00 W
117 10 W
697
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Norwegian Sea
Atlantic Ocean
Nouakchott (capital)
Nuuk (capital; also Godthab)
Ouagadougou (capital)
Prince Edward Islands
Principe (island)
Queen Charlotte Islands
Queen Elizabeth Islands
Queen Maud Land (claimed by Norway)
43 55N
59 50W
Safety Islands (lies du Salut)
4712N
52 37W
13 00W
8 00W
106 40 E
62 52W
59 38E
62 45W
62 45W
63 00W
61 45 W
6 00W
122 12 W
2 07W
66 04W
61 51 W
67 00W
67 00W
62 00W
60 09W
701
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Saint Paul Island
49 45N
126 00 W
Vatican City (capital)
Holy See
4154N
12 27E
Velez de la Gomera, Penon de (island)
7100N
11000W
Victoria Land (region)','5b74cbe8d57d828576e39e278a38e032d2d5205174efa94ec223b92339c3956c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('904c0689e754388cccff1eec484680e50fe36df0022c264e6336ac9f703fc61f',2007,'PT','Portugal','transnational-issues',339,'Disputes - international: none
Illicit drugs: used as a transshipment point for illicit
drugs moving from Latin America and Asia destined
for Western Europe; the lack of a well-developed
financial system limits the country''s utility as a
money-laundering center
Disputes - international: as a member state that
forms part of the EU''s external border, Poland must
implement the strict Schengen border rules
Illicit drugs: major illicit producer of synthetic drugs
for the international market; minor transshipment point
for Asian and Latin American illicit drugs to Western
Europe
_
Disputes - international: Portugal does not
recognize Spanish sovereignty over the territory of
Olivenza based on a difference of interpretation of the
1815 Congress of Vienna and the 1801 Treaty of
Badajoz
Illicit drugs: gateway country for Latin American
cocaine and Southwest Asian heroin entering the
European market (especially from Brazil);
transshipment point for hashish from North Africa to
Europe; consumer of Southwest Asian heroin
451
PO
PT
PRT
620
■Pt
38 30N
28 00W
Azov, Sea of
Atlantic Ocean
49 00N
36 00E
Bab el Mandeb (strait)
Indian Ocean
12 40N
43 20E
Babuyan Channel
Pacific Ocean
18 44N
121 40 E
Babuyan Islands
38 43N
9 08W
Little Belt (strait; also Lille Baelt)
Atlantic Ocean
55 05N
9 55E
Ljubljana (capital)
32 40N
16 45W
Madras (city; see Chennai)','6bd179a1537a6bbdfa8549dfc1d30bc297d30984749ad5a7c93ff0b1d1ed751f','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a6385778e786004d6081d7eed79335fb89765106a8591b28ee1edb40608ba55b',2007,'KY','Cayman Islands','transnational-issues',340,'(overseas territory
of the UK)
Caribbean Sea
-20
Little The Bfrff
Cayman <-?= ^z
Cayman
Brae
Grand
Cayman
GEORGE TOWN
Caribbean Sea
0 20 40km
O 20 40mi
CJ
KY
CYM
136
,ky
19 20N
81 23 W
George Town (city)
The Bahamas
23 30N
75 46W
George Town (city)
19 20N
8120W
Grand Turk (capital; also Cockburn Town)','f606acd0170a10e8b1a5c509b696cef613aac204c8e1504903f0dfdf42865bda','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fbad3e0c162dd507557c9e4284a46188e544fe99f6421f9d6974a4801b4c864f',2007,'JM','Jamaica','transnational-issues',350,'Disputes - international: none
Illicit drugs: offshore financial center; vulnerable to
drug transshipment to the US and Europe
Central African
Republic
Port
Caribbean Sea
Montego
Bay
Rhoades
•
Saint Ann''s
Bay
*Ocho
Rios
. Savanna-
Negnl o-Mar
.Port Antonio
Lmstead
Black River
•
Mandeville
May
Pen
Blue Mountain
Spanish **«*
Town
• KINGSTON
Portmore Morant Rocky •
Bay Point
Port
Kaiser
•
Port
Esquivel
Caribbean Sea
O 10 20 km
Portland
Po,m
O 10 20 mi
Disputes - international: none
Illicit drugs: transshipment point for cocaine from
South America to North America and Europe; illicit
cultivation of cannabis; government has an active
manual cannabis eradication program; corruption is a
major concern; substantial money-laundering activity;
Colombian narcotics traffickers favor Jamaica for illicit
financial transactions
Jan Mayen
(territory of Norway)
ss
0 5 10 km
JM
JM
JAM
388
jm
Jan Mayen
JN
—
—
—
—
ISO includes with Svalbard
18 00N
76 48W
Kingston (capital)','7e962f1de6a1699c994946a600596746c94b0e31cf95d75aef59e037f75157b7','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d956c4f2f44f9e750a1b0757eceda607e6f2f5737ebd9c27fd5d46e9e32e5860',2007,'TD','Chad','transnational-issues',351,'■ 1
20 O 1QO 200 km
O 100 200 mi
CD
TD
TCD
148
.td
Apia (capital)
12 07N
15 03E
Nederland (local name for the Netherlands)
Tegucigalpa (capital)','8145deca6d366fd894c58554d2975069f5b6bc7d5048b2ddc06d242337b82ca7','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('466561a073daffdd62775c1e445773674ccdffa931d3a05991cd74bc5fb43c45',2007,'LY','Libya','transnational-issues',352,'CENTRAL AFRICAN
REPUBLIC
DEM REP. OF THE CONGO
Disputes - international: since the expulsions of
residents from Darfur in 2003 by Janjawid armed
militia and Sudanese military, about 200,000 refugees
remain in eastern Chad; Chad remains an important
mediator in the Sudanese civil conflict, reducing
tensions with Sudan arising from cross-border
banditry; Chadian Aozou rebels reside in southern
Libya; only Nigeria and Cameroon have heeded the
Lake Chad Commission''s admonition to ratify the
delimitation treaty, which also includes the
Chad-Niger and Niger-Nigeria boundaries
Refugees and internally displaced persons:
refugees (country of origin): 224,924 (Sudan), 29,683
(Central African Republic) (2005)
Isla San
F4*x
''tola San
Ambrosio
SOUTH
PACIFIC
OCEAN
Coquimbo,
Valparaiso. SANTIAGO
San Antonio" */
• Rancagua
APCHIPieUGO JUAN
?&inAnoez
Talcahuano.
Lebu
Temuco''
S_a"n Vicente
/ /, Crete
TUN '' Mediterranean Sea (0B|
«v V ^TRIPOLI parnah
X Zuw^ah a|. .Mj§ra,ah Tobruk
\\ ( Khums Banghazi /
\\) Surt* )
TGhadamis Ra''s* "Al Burayqah < m
\\ Lanuf V . \\eqypt
Sabkhat
I Ghuzayyil
ALGV
( .Sabha
^-» ~ - ,, . r, , AUawl
Y SAHARA
, ^. ^
NIGER V /!%\\. _J
/ CHAD ^^Jsudan
0 300km ^n«u
O 300 n» |
\\
Disputes - international: Libya has claimed more
than 32,000 sq km in southeastern Algeria and about
25,000 sq km in Niger in currently dormant disputes;
various Chadian rebels from the Aozou region reside
in southern Libya
329
LY
LY
LBY
434
•iy
Czechoslovakia (former name for the entity that
subsequently split into the Czech Republic and Slovakia)
Czech Republic, Slovakia
Dagestan (region)
Russia
Dahomey (former name for Benin)
32 54N
1311 E
Tripoli (city)
3100N
14 00E
Tristan da Cunha Group (island group)
Saint Helena
37 04S
12 19 W
Trobriand Islands','7d8703114502b5439037f3b98cbc239064d9bfe7fb48e778a4e968da3b0b969c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f82e59e086c8d997fd055d526533cdda77086705de181c7d073a427681dbc71',2007,'CN','China','transnational-issues',362,'Disputes - international: Chile rebuffs Bolivia''s
reactivated claim to restore the Atacama corridor,
ceded to Chile in 1884, offering instead unrestricted
but not sovereign maritime access through Chile to
Bolivian gas and other commodities; Peru proposes
changing its latitudinal maritime boundary with Chile
to an equidistance line with a southwestern axis;
territorial claim in Antarctica (Chilean Antarctic
Territory) partially overlaps Argentine and British
claims
Illicit drugs: important transshipment country for
cocaine destined for Europe; economic prosperity and
increasing trade have made Chile more attractive to
traffickers seeking to launder drug profits, especially
through the Iquique Free Trade Zone, but a new
anti-money-laundering law improves controls;
imported precursors passed on to Bolivia; domestic
cocaine consumption is rising
di — , Caspian
Disputes - international: in 2005, China and India
initiated drafting principles to resolve all aspects of
their extensive boundary and territorial disputes
together with a security and foreign policy dialogue to
consolidate discussions related to the boundary,
regional nuclear proliferation, and other matters;
recent talks and confidence-building measures have
begun to defuse tensions over Kashmir, site of the
world''s largest and most militarized territorial dispute
with portions under the de facto administration of
China (Aksai Chin), India (Jammu and Kashmir), and
Pakistan (Azad Kashmir and Northern Areas); India
does not recognize Pakistan''s ceding historic Kashmir
lands to China in 1964; about 90,000 ethnic Tibetan
exiles reside primarily in India as well as Nepal and
Bhutan; China asserts sovereignty over the Spratly
Islands together with Malaysia, Philippines, Taiwan,
Vietnam, and possibly Brunei; the 2002 "Declaration
on the Conduct of Parties in the South China Sea" has
eased tensions in the Spratlys but is not the legally
binding "code of conduct" sought by some parties;
Vietnam and China continue to expand construction of
facilities in the Spratlys and in March 2005, the
national oil companies of China, the Philippines, and
Vietnam signed a joint accord on marine seismic
activities in the Spratly Islands; China occupies some
of the Paracel Islands also claimed by Vietnam and
Taiwan; China and Taiwan have become more vocal
in rejecting both Japan''s claims to the uninhabited
islands of Senkaku-shoto (Diaoyu Tai) and Japan''s
unilaterally declared equidistance line in the East
China Sea, the site of intensive hydrocarbon
prospecting; certain islands in the Yalu and Tumen
rivers are in an uncontested dispute with North Korea
and a section of boundary around Mount Paektu is
considered indefinite; China seeks to stem illegal
migration of tens of thousands of North Koreans;
China and Russia prepare to demarcate the boundary
agreed to in October 2004 between the long-disputed
islands at the Amur and Ussuri; demarcation of the
China- Vietnam boundary proceeds slowly and
although the maritime boundary delimitation and
fisheries agreements were ratified in June 2004,
implementation has been delayed; environmentalists
in Burma and Thailand remain concerned about
China''s construction of hydroelectric dams upstream
on the Nujiang/Salween River in Yunnan Province
Refugees and internally displaced persons:
refugees (country of origin): 299,287 (Vietnam)
estimated 30,000-50,000 (North Korea) (2005)
Illicit drugs: major transshipment point for heroin
produced in the Golden Triangle; growing domestic
drug abuse problem; source country for chemical
precursors and methamphetamine
121
Sheung
•?Shui
rai Po
** Tue''n New Territories
'' Mun r»iMoA JL.
I . CHek Lap Kok ■''■ ., W ^ *f ''QV(/
/ internal 1-Alrpo* , . ^..KOWlOOn V 0 & >.
, Aberdeen* W^
,'' Lantau
Island
Disputes - international: none
Illicit drugs: makes strenuous law enforcement
efforts, but faces difficult challenges in controlling
transit of heroin and methamphetamine to regional
and world markets; modern banking system provides
conduit for money laundering; rising indigenous use of
synthetic drugs, especially among young people
Howland Island
(territory of the US)
Description under
Disputes ■ international: delimitation with
Kazakhstan is complete; disputes in Isfara Valley
delay completion of delimitation with Tajikistan;
delimitation of 130 km of border with Uzbekistan is
hampered by serious disputes around enclaves and
other areas
Illicit drugs: limited illicit cultivation of cannabis and
opium poppy for CIS markets; limited government
eradication of illicit crops; transit point for Southwest
Asian narcotics bound for Russia and the rest of
Europe
O 50 IQOkfn
50 100 mi
.Dalandzadgad ^ 5 .•
0 l ^^
C-, 0 |,- — '' 0 100 200 km
^S^ 0 100 200mi
0 100 200 km
Luzon >
South
Sea
BABUYAN
ISLANDS
Ap,
San
Fernando, >BaguJ0
Luzon
^Angeles
" Quezon City
MANILA
Batarigas*
Mindoro
Philippine
Sea
J^gaspi
Palawan
A
Puerto
Pnncesa
lindoro
Panay
"-lo. Bacolod Leyte
CebuCity
os Rir
#Butuan
n,gan. ^aga^an
//"W^ Mindanao
Zamboanga^ Davao.
Sea
Fiery Cross .
Reel ■•
Loaita Warrv
West York
• Jstand
-Thitu Island F''a<
* , Island
^e . •■ — Lankiam Cay ■
Sand Cay^Loaita Island ,.\\
Itu Aba lsland>- e^ldad Reef Nanshan
-. .~-Namyit island
Island
s"
Sin Cowe--r^-'' Mischief0
Island * Reef 9
■ Spratly
Island
Reel
Moon *
Shoal
Amboyna
Cay
CH
CN
CHN
156
.en
see also Taiwan
39 56N
11624E
Beirut (capital)
Bekaa Valley
Belau (Palau Islands)
Belep Islands (lies Belep)
Belgian Congo (former name for Democratic
Republic of the Congo)
Belgie (local name for Belgium)
Belgique (local name for Belgium)
Belgrade (capital)
Belize City
Belle Isle, Strait of
Bellingshausen Sea
Belmopan (capital)
Belorussia (former name for Belarus)
Canton Island (Kanton Island)
35 00N
105 00 E
China, Republic of
Taiwan
23 30N
121 00 E
Chisinau (capital)
Moidova
47 00N
28 50E
Choiseul (island)
19 00N
Haiphong (city)
Vietnam
20 52N
Halalb Triangle (region)
Halmahera (island)
Egypt (claimed), Sudan (de facto)
22 30N
42 00N
11300E
Ionian Islands
Russia (de facto)
44 00N
124 00 E
Manchuria (region)
44 00N
124 00 E
Manila (capital)
42 00N
Netherlands Antilles
17 29N
Netherlands Antilles
18 04N
32 00N
90 00E
Tbilisi (see Tbilisi)
35 00N
105 00 E
Zhonghua (local name for China)
35 00N
105 00 E
Zion, Mount (locale in Jerusalem)
Israel, West Bank
3146N
35 14E
Zurich (city)','9db3875a2a7f73e96b532d1a9564588121515bf9827ecc3199f6f2c586ef23e9','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d519fc199d61679beb2557e5ae08cc57b0cfe33d64246017b04556588fd23e66',2007,'CX','Christmas Island','transnational-issues',370,'(territory of Australia)
0 2 4km
Indian Ocean
Indian Ocean —
KT
CX
CXR
162
.ex
Clipperton Island
IP
—
—
—
—
ISO includes with French Polynesia
18 44N
6419W
Severnaya Zemlya (island group; also Northland)
Russia
79 30N
98 00E
Shaba (region)
Democratic Republic of the Congo
8 00S
27 00E
Shag Island','b0542636f2eefacc3b2c744e0a4141ebae7fbda01f91fe2497253f9cf943bd4b','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9aa30ef7f2f12e33ae774e86f3c0d81b0d56208f80f5b4811f837c7a18ca7b67',2007,'CO','Colombia','transnational-issues',388,'* Puerto Bolivar.
Santa Martaf
Barranquilja*Cp^
Cartagena* cnsuta^
PAMW4,, Turb0 c.cutA
i Bucaramanga.
. Medellin h
•
NORTH ''-''Pereira. ^rogotA
PACiFie ,''lbague.^ *DWW-"M
OCEAN ''/Buenaventura
/Call *
Disputes - international: Nicaragua filed a claim
against Honduras in 1999 and against Colombia in
2001 at the ICJ over disputed maritime boundary
involving 50,000 sq km in the Caribbean Sea,
including the Archipelago de San Andres y
Providencia and Quita Sueno Bank; dispute with
Venezuela over maritime boundary and Los Monjes
Islands near the Gulf of Venezuela;
Colombian-organized illegal narcotics, guerrilla, and
paramilitary activities penetrate all of its neighbors''
borders and have created a serious refugee crisis with
over 300,000 persons having fled the country, mostly
into neighboring states
Refugees and internally displaced persons:
IDPs: 2,900,000 - 3,400,000 (conflict between
government and FARC; drug wars) (2004)
Illicit drugs: illicit producer of coca, opium poppy, and
cannabis; world''s leading coca cultivator (cultivation of
coca in 2004 was 1 14,100 hectares, virtually unchanged
from 2003, but down one-third from its peak of 169.800
ha); producing a potential of 430 mt of pure cocaine, the
world''s largest producer of coca derivatives; supplying
most of the US market and the great majority of cocaine
to other international drug markets; important supplier ot
heroin to the US market; opium poppy cultivation tell 5
between 2003 and 2004 to 2,100 hectares yielding a
potential 3.8 metnc tons of pure heroin, mostly for the US
market; in 2004, aenal eradication treated over 130,000
hectares of coca but aggressive replanting on the part of
growers means Colombia remains a key producer, a
significant portion of non-US narcotics proceeds are
either laundered or invested in Colombia through the
black market peso exchange
127
30 60km
Indian Ocean
^MORONI
Grande Comore
(Njazidja)
Moutsamoudou/\\ ^z^ni)
Moheli r.Fomboni .
(Mwali) -~^> , uuihuih
NORTH PACIFIC OCEAN
CO
CO
COL
170
.CO
10 59N
74 48W
Bashi Channel
Pacific Ocean
22 00N
121 00 E
Basilan Strait
Pacific Ocean
6 49N
122 05 E
Basque Provinces
4 36N
74 05W
Bohemia (region)
Czech Republic
50 00N
14 30E
Bombay (see Mumbai)
4 00N
90 30W
Malta Channel
Atlantic Ocean
56 44N
26 53E
Malvinas, Islas (island group)
Falkland Islands (Islas Malvinas)
5145S
59 00W
Mamoutzou (capital)
13 32N
80 03W
Roosevelt Island
13 00N
8130W
San Bernardino Strait
Pacific Ocean
12 32N
124 10 E
San Felix, Isla (island)
14 25N
8016W
Serranilla Bank (shoal)
1551 N
79 46W
Settlement, The (capital)','8b042e89a0df56aa16586d48d36918121950ddc90fa27fe8449b50fb6089ff06','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb49ad3ef679ab0760d755a3a407d1b24c168e54ba5b7705fa0d270d03730331',2007,'MZ','Mozambique','transnational-issues',397,'Channel
Channel
Channel
reel
Channel
Glonoso Islands
■ ''FRANCE
Antsiranana.
Antsohimbondrona#
Nosy Be
Maro
A
« Mahajanga
Nosy
Chesterfield
. Nosy
Satnle
Marie
Toamasina^
NOSY
ANTANANARIVO^
BARREN
Morondava
Mananjary
Fianarantsoa *
•
Manakara m
INDIAN
OCEAN
Tohara
Tolaharo
Disputes - international: claims Bassas da India,
Europa Island, Glorioso Islands, and Juan de Nova
Island (all administered by France)
Illicit drugs: illicit producer of cannabis (cultivated
and wild varieties) used mostly for domestic
consumption; transshipment point for heroin
343
Disputes - international: disputes with Malawi over
the boundary in Lake Nyasa (Lake Malawi) and the
meandering Songwe River remain dormant
Refugees and internally displaced persons:
refugees (country of origin): 443,706 (Burundi)
153,474 (Democratic Republic of the Congo) 3,036
(Somalia) (2005)
Illicit drugs: growing role in transshipment of
Southwest and Southeast Asian heroin and South
American cocaine destined for South African,
European, and US markets and of South Asian
methaqualone bound for southern Africa; money
laundering remains a problem
MZ
MZ
MOZ
508
.mz
22 30S
34 30E
Inini (former name for French Guiana)
25 56S
32 34E
Loyalty Islands (lies Loyaute)
25 58S
32 35E
Marcus Island (Minami-tori-shima)
18 15 S
35 00E
Mogadishu (capital)
66 00N
18 06N
22 16S
2130S
16 00S
74 00N
20 30N
2108S
72 00N
6411 N
13 30S
13 30S
6 00E
15 57W
166 27 E
165 30 E
167 00 E
57 00E
33 00E
175 12W
90 00W
51 44 W
34 00E
37 00E
0
Oahu (island)
United States (Hawaii)
Ocean Island (Banaba)
18 15 S
35 00E
Portuguese Guinea (former name for Guinea-Bissau)
16 00S
37 00E
Zanzibar (island)
Tanzania
610S
3911 E
Zhong Guo (local name for China)','354ecf72ad96cbf7cfed760be0e26944748de7f23fd916c403c76aba2584cc18','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1ab566664f699b23d1eb6665b02695ee710c95bd74c120584e278c6338ff2a2',2007,'YT','Mayotte','transnational-issues',398,'Administered by FRANCE.
clamed by COMOROS
Disputes • international: claims
French-administered Mayotte
Congo, Democratic
Republic of the
l.rod by FRANCE
; oyCOUOnOS]
(territorial collectivity
of France)
Chissioi
M''Zamboro
AdmireMeied by FRANCE.
by COMOROS
MAM0UDZ0U, .D^ouri/,
Mayotte D "e
•Sada
"Bandfele
Disputes - international: claimed by Comoros
366
i
Chihuahua
Nuevo''
Laredo
Topolobampo Torrebn
Paz#
Monterrey Ma,amoros
NORTH
PACIFIC
OCEAN
ISLAS
REVILLAGIGEDO
\\ Culiacan
Mazatlan
• San Luis
Aguascalientes .P°>°si Jampico
Vallarta. Queretaro Juxpan
''Guadalajara MEXICO
Morelia* + Puebla
-.• Toluca • *■ ''Veracruz
MF
YT
MYT
175
■yt
12 47S
4514E
Managua (capital)','bf5854b4ff4086886b255810a3192478641bab87c399b95885e0823be4dc8e21','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('559293bff202b4ea454b0be2f8ac98da218ea1b2d06c2fcec96777dd4dd363f9',2007,'CK','Cook Islands','transnational-issues',407,'(self-governing in free
association with
New Zealand)
Rakahanga
Pukapuka, ''Manihiki
Nassau
Island
Suwarrow
South Pacific Ocean
Penrtiyn
Palmerslon .
Aitutaki
150 300 km
Rarotonga
Manuae
Takutea Mitiaro
Atiu Mauke
*AVARUA
Mangaia
Disputes - international: none
Coral Sea Islands
(territory of Australia)
+Osprey Reel
^Shark Reel
200
Bougainville
Reetty Moore
y Reels /
jf Holmes Reefs * O yMagdelaine Cays
U. <So f
ra Reel ^Coringa Islets
; Herald Cays— Q Tregrosse Islets
Fit::: /* ^
\\ & JReel £• C-^
fl>c "*>>. <$ Tregrosse Reels
* /■ i ''&r Zbmgton
«:X Reel
Townsville
Willis Islets
Tee''s
Marion
Coral
Sea
''•V
3i
Fredenck
t,Peet
Mackay« Cri >. ,
AUSTRALIA ) " <g^ SaL
\\ \\ J West
islet
Wred -p
Bird Islet
Cato Island-^
Disputes - international: none
(N.Z.)
Baker Island
0 U tol
H ''; mi
NORTH PACIFIC OCEA N
Jarvis Island
0 Vi 1 tan
0 » 1 ml
reel
SOUTH PACIFIC OCEA N
Kingman Reef
0 1 2 km
1 2ml
NORTH PACIFIC
OCEAN
Palmyra Atoll
0 1 2km
0 1 2mi
NORTH PACIFIC OCEA N
587
United States Pacific Island
Wildlife Refuges (continued)
Kingman Reef: The US annexed the reef in 1922. Its
sheltered lagoon served as a way station for flying
boats on Hawaii-to-American Samoa flights during the
late 1930s. There are no terrestrial plants on the reef,
which is frequently awash, but it does support
abundant and diverse marine fauna and flora. In 2001 ,
the waters surrounding the reef out to 12 nm were
designated a US National Wildlife Refuge.
Midway Islands: The US took formal possession of
the islands in 1867. The laying of the trans-Pacific
cable, which passed through the islands, brought the
first residents in 1903. Between 1935 and 1947,
Midway was used as a refueling stop for trans-Pacific
flights. The US naval victory over a Japanese fleet off
Midway in 1 942 was one of the turning points of World
War II. The islands continued to serve as a naval
station until closed in 1993. Today the islands are a
National Wildlife Refuge and are the site of the world''s
largest Laysan albatross colony.
Palmyra Atoll: The Kingdom of Hawaii claimed the atoll
in 1862, and the US included it among the Hawaiian
Islands when it annexed the archipelago in 1898. The
Hawaii Statehood Act of 1959 did not include Palmyra
Atoll, which is now partly privately owned by the Nature
Conservancy with the rest owned by the Federal
government and managed by the US Fish and Wildlife
Service. These organizations are managing the atoll as a
wildlife refuge. The lagoons and surrounding waters
within the 12 nm US territorial seas were transferred to
the US Fish and Wildlife Service and designated as a
National Wildlife Refuge in January 2001 .
Disputes - international: none
International Court of Justice (ICJ)
note— also known as the World Court
established— 3 February 1 946 superseded
Permanent Court of International Justice
aim— primary judicial organ of the UN
members— (15 judges) elected by the UN General Assembly and Security Council to represent all principal legal
systems
International Criminal Court (ICCt)
established--! 1 April 2002
aim— to hold all individuals and countries
accountable to international laws of conduct; to
specify international standards of conduct; to
provide an important mechanism for
implementing these standards; to ensure that
perpetrators are brought to justice
International Criminal Police Organization
(Interpol)
established— September 1923 set up as the
International Criminal Police Commission; 13
June 1956 constitution modified and present
name adopted
aim— to promote international cooperation
among police authorities in fighting crime
members (countries that have ratified the treaty}— (99) Afghanistan, Albania, Andorra, Antigua and Barbuda,
Argentina, Australia, Austria, Barbados, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Bulgaria, Burkina Faso, Burundi, Cambodia, Canada, Central African Republic, Colombia, Democratic Republic of
the Congo, Republic of the Congo, Costa Rica, Croatia, Cyprus, Denmark, Djibouti, Dominica, Dominican Republic,
East Timor, Ecuador, Estonia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Guinea, Guyana, Honduras, Hungary, Iceland, Ireland, Italy, Jordan, Kenya, South Korea, Latvia, Lesotho, Liberia,
Liechtenstein, Lithuania, Luxembourg, Macedonia, Malawi, Mali, Malta, Marshall Islands, Mauritius, Mongolia,
Namibia, Nauru, Netherlands, NZ, Niger, Nigeria, Norway, Panama, Paraguay, Peru, Poland, Portugal, Romania,
Saint Vincent and the Grenadines, Samoa, San Marino, Senegal, Serbia and Montenegro, Sierra Leone, Slovakia,
Slovenia, South Africa, Spain, Sweden, Switzerland, Tajikistan, Tanzania, Trinidad and Tobago, Uganda, UK,
Uruguay, Venezuela, Zambia
signatory states (countries that have signed, but not ratified, the treaty)— (43) Algeria, Angola, Armenia, The
Bahamas, Bahrain, Bangladesh, Cameroon, Cape Verde, Chad, Chile, Comoros, Cote d''lvoire, Czech Republic,
Egypt, Eritrea, Guinea-Bissau, Haiti, Iran, Israel, Jamaica, Kuwait, Kyrgyzstan, Madagascar, Mexico, Moldova,
Monaco, Morocco, Mozambique, Oman, Philippines, Russia, Saint Lucia, Sao Tome and Principe, Seychelles,
Solomon Islands, Sudan, Syria, Thailand, Ukraine, UAE, Uzbekistan, Yemen, Zimbabwe
members— (184) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia, Aruba,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''lvoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, East Timor, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi,
Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia,
Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, Netherlands Antilles, NZ, Nicaragua, Niger, Nigeria,
Norway, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and
Principe, Saudi Arabia, Senegal, Serbia and Montenegro, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia,
Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK,
US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
subbureaus— (10) American Samoa, Anguilla, Bermuda, British Virgin Islands, Cayman Islands, Eastern Africa,
Gibraltar, Montserrat, Puerto Rico, Turks and Caicos Islands
643
Appendix B: International Organizations and Groups (continued)
International Development Association (IDA)
established— 26 January 1960
effective— 24 September 1960
aim— to provide economic loans for low-income
countries; UN specialized agency and IBRD
affiliate
International Energy Agency (IEA)
established— 1 5 November 1974
aim— to promote cooperation on energy matters,
especially emergency oil sharing and relations
between oil consumers and oil producers;
established by the OECD
members— (166)
Part I— (27 developed countries) Australia, Austria, Belgium, Canada, Denmark, EU, Finland, France, Germany,
Iceland, Ireland, Italy, Japan, Kuwait, Luxembourg, Netherlands, NZ, Norway, Portugal, Russia, South Africa, Spain,
Sweden, Switzerland, UAE, UK, US
Part II— (139 less developed countries) Afghanistan, Albania, Algeria, Angola, Argentina, Armenia, Azerbaijan,
Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Burkina Faso,
Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''lvoire, Croatia, Cyprus,
Czech Republic, Djibouti, Dominica, Dominican Republic, East Timor, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Ethiopia, Fiji, Gabon, The Gambia, Georgia, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, India, Indonesia, Iran, Iraq, Israel, Jordan, Kazakhstan, Kenya,
Kiribati, South Korea, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Macedonia, Madagascar, Malawi,
Malaysia, Maldives, Mali, Marshall Islands, Mauritania, •Mauritius, Mexico, Federated States of Micronesia, Moldova,
Mongolia, Morocco, Mozambique, Nepal, Nicaragua, Niger, Nigeria, Oman, Pakistan, Palau, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia and Montenegro, Sierra Leone,
Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, Sri Lanka, Sudan, Swaziland, Syria, Tajikistan, Tanzania,
Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, Uzbekistan, Vanuatu, Vietnam,
Yemen, Zambia, Zimbabwe
members— -(27) Australia, Austria, Belgium, Canada, Czech Republic, Denmark, Finland, France, Germany, Greece,
Hungary, Ireland, Italy, Japan, South Korea, Luxembourg, Netherlands, NZ, Norway, Portugal, Slovakia, Spain,
Sweden, Switzerland, Turkey, UK, US
International Federation of Red Cross and
Red Crescent Societies (IFRCS)
note— formerly known as League Red Cross
and Red Crescent Societies (LORCS)
established— 5 May 1919
aim— to organize, coordinate, and direct
international relief actions; to promote
humanitarian activities; to represent and
encourage the development of National
Societies; to bring help to victims of armed
conflicts, refugees, and displaced people; to
reduce the vulnerability of people through
development programs
members— (182) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma. Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Democratic Republic of
the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote d''lvoire, Croatia, Cuba, Czech Republic,
Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Estonia,
Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia,
Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi,
Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia,
Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Palau,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe,
Saudi Arabia, Senegal, Serbia and Montenegro, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon
Islands, Somalia, South Africa, Spain. Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Taiwan,
Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine,
UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
observers— {5 plus the Palestine Liberation Organization) Comoros, East Timor, Eritrea, Israel, Tuvalu, Palestine
Liberation Organization
644
Appendix B: International Organizations and Groups (continued)
International Fund for Agricultural
Development (IFAD)
established— November 1 974
aim— to promote agricultural development; a UN
specialized agency
members— (164)
Category I— (23 industrialized aid contributors) Australia, Austria, Belgium, Canada, Denmark, Finland, France,
Germany, Greece, Iceland, Ireland, Italy, Japan, Luxembourg, Netherlands, NZ, Norway, Portugal, Spain, Sweden,
Switzerland, UK, US
Category II— (12 petroleum-exporting aid contributors) Algeria, Gabon, Indonesia, Iran, Iraq, Kuwait, Libya, Nigeria,
Qatar, Saudi Arabia, UAE, Venezuela
Category III— (129 aid recipients) Afghanistan, Albania, Angola, Antigua and Barbuda, Argentina, Armenia,
Azerbaijan, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote
d''lvoire, Croatia, Cuba, Cyprus, Djibouti, Dominica, Dominican Republic, East Timor, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Ethiopia, Fiji, The Gambia, Georgia, Ghana, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, India, Israel, Jamaica, Jordan, Kazakhstan, Kenya, Kiribati, North Korea,
South Korea, Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia, Macedonia, Madagascar, Malawi, Malaysia, Maldives,
Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Nicaragua,
Niger, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Romania, Rwanda, Saint Kitts
and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Senegal, Serbia and
Montenegro, Seychelles, Sierra Leone, Solomon Islands, Somalia, South Africa, Sri Lanka, Sudan, Suriname,
Swaziland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda,
Uruguay, Vietnam, Yemen, Zambia, Zimbabwe
International Labor Organization (ILO)
established— 28 June 1919 set up as part of
Treaty of Versailles; 1 1 April 1919 became
operative; 14 December 1946 affiliated with the
UN
aim— to deal with world labor issues; a UN
specialized agency
members— (178) includes all UN member countries except Andorra, Bhutan, Brunei, North Korea, Liechtenstein,
Maldives, Marshall Islands, Federated States of Micronesia, Monaco, Nauru, Palau, Tonga and Tuvalu; note-
includes the following dependencies: Netherlands (Netherlands Antilles and Aruba)
International Maritime Organization (IMO)
note— name changed from Intergovernmental
Maritime Consultative Organization (IMCO) on
22 May 1982
established— 6 March 1948 set up as the
Inter-Governmental Maritime Consultative
Organization
effective— 17 March 1958
aim— to deal with international maritime affairs;
a UN specialized agency
members— (167) includes all UN member countries except Afghanistan, Andorra, Armenia, Belarus, Bhutan,
Botswana, Burkina Faso, Burundi, Central African Republic, Chad, Kyrgyzstan, Laos, Lesotho, Liechtenstein, Mali,
Federated States of Micronesia, Nauru, Niger, Palau, Rwanda, Tajikistan, Uganda, Uzbekistan, Zambia
associate members— {3) Faroe Islands, Hong Kong, Macau
International Monetary Fund (IMF)
established— 22 July 1944
effective— 21 December 1945
aim— to promote world monetary stability and
economic development; a UN specialized
agency
members— (184) includes all UN member countries except Andorra, Cuba, North Korea, Liechtenstein, Monaco,
Nauru, Tuvalu; note— includes the following dependencies or areas of special interest: China (Hong Kong and
Macau), Netherlands (Netherlands Antilles and Aruba)
645
Appendix B: International Organizations and Groups (continued)
International Olympic Committee (IOC)
established— 23 June 1894
aim— to promote the Olympic ideals and
administer the Olympic games: 2006 Winter
Olympics in Turin, Italy; 2008 Summer Olympics
in Beijing, China; 2010 Winter Olympics in
Vancouver, Canada; 2012 Summer Olympics in
London, UK
International Organization for Migration
(IOM)
note— established as Provisional
Intergovernmental Committee for the Movement
of Migrants from Europe; renamed
Intergovernmental Committee for European
Migration (ICEM) on 15 November 1952;
renamed Intergovernmental Committee for
Migration (ICM) in November 1980; current
name adopted 14 November 1989
established— 5 December 1951
aim— to facilitate orderly international emigration
and immigration
National Olympic Committees— (201 plus the Palestine Liberation Organization) Afghanistan, Albania, Algeria,
American Samoa, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia, Aruba, Australia, Austria,
Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bermuda, Bhutan,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, British Virgin Islands, Brunei, Bulgaria, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Canada, Cape Verde, Cayman Islands, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook Islands, Costa Rica,
Cote d''lvoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican Republic, East
Timor, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guam, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hong Kong, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho,
Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali,
Malta, Marshall Islands, Mauritania, Mauritius, Mexico.-Federated States of Micronesia, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, Netherlands Antilles, NZ, Nicaragua, Niger,
Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Puerto Rico, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia and Montenegro,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Taiwan, Tajikistan, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu,
Venezuela, Vietnam, Virgin Islands, Yemen, Zambia, Zimbabwe, Palestine Liberation Organization
members— (1 16) Afghanistan, Albania, Algeria, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bangladesh, Belarus, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Brazil, Bulgaria, Burkina
Faso, Cambodia, Cameroon, Canada, Cape Verde, Chile, Colombia, Democratic Republic of the Congo, Republic
of the Congo, Costa Rica, Cote d''lvoire, Croatia, Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador,
Egypt, El Salvador, Estonia, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala,
Guinea, Guinea-Bissau, Haiti, Honduras, Hungary, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, South Korea, Kyrgyzstan, Latvia, Liberia, Libya, Lithuania, Luxembourg, Madagascar, Mali, Malta,
Mauritania, Mexico, Moldova, Morocco, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Panama,
Paraguay, Peru, Philippines, Poland, Portugal, Romania, Rwanda, Senegal, Serbia and Montenegro, Sierra Leone,
Slovakia, Slovenia, South Africa, Sri Lanka, Sudan, Sweden, Switzerland, Tajikistan, Tanzania, Thailand, Togo,
Tunisia, Turkey, Uganda, Ukraine, UK, US, Uruguay, Venezuela, Yemen, Zambia, Zimbabwe
observers— (21) Bhutan, Burundi, China, Cuba, Ethiopia, Guyana, Holy See, India, Indonesia, Macedonia,
Mozambique, Namibia, Nepal, Papua New Guinea, Russia, San Marino, Sao Tome and Principe, Somalia, Spain,
Turkmenistan, Vietnam
International Organization for
Standardization (ISO)
established— February 1947
aim— to promote the development of
international standards with a view to facilitating
international exchange of goods and services
and to developing cooperation in the sphere of
intellectual, scientific, technological and
economic activity
members— (100 national standards organizations) Algeria, Argentina, Armenia, Australia, Austria, Azerbaijan,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Canada,
Chile, China, Colombia, Costa Rica, Cote d''lvoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Ecuador,
Egypt, Ethiopia, Finland, France, Germany, Ghana, Greece, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea, South Korea, Kuwait, Libya, Luxembourg,
Macedonia, Malaysia, Malta, Mauritius, Mexico, Mongolia, Morocco, Netherlands, NZ, Nigeria, Norway, Oman,
Pakistan, Panama, Philippines, Poland, Portugal, Qatar, Romania, Russia, Saint Lucia, Saudi Arabia, Serbia and
Montenegro, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan, Sweden, Switzerland, Syria,
Tanzania, Thailand, Trinidad and Tobago, Tunisia, Turkey. Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela,
Vietnam, Zimbabwe
correspondent members— (45 plus the Palestine Liberation Organization) Afghanistan, Albania, Angola, Benin,
Bhutan, Bolivia, Brunei, Burkina Faso, Burma, Democratic Republic of the Congo, Dominican Republic, El Salvador,
Eritrea, Estonia, Fiji, Guatemala, Guinea, Guinea-Bissau, Hong Kong, Kyrgyzstan, Latvia, Lebanon, Lithuania,
Macau, Madagascar, Malawi, Mali, Moldova, Mozambique, Namibia, Nepal, Nicaragua, Niger, Papua New Guinea,
Paraguay, Peru, Rwanda, Senegal, Seychelles, Swaziland, Togo, Turkmenistan, Uganda, Yemen, Zambia, Palestine
Liberation Organization
subscriber members— {10) Antigua and Barbuda, Burundi, Cambodia, Dominica, Grenada, Guyana, Honduras,
Lesotho, Saint Vincent and the Grenadines, Tajikistan
646
Appendix B: International Organizations and Groups (continued)
International Telecommunication Union (ITU)
established— 17 May 1865 set up as the
International Telegraph Union; 9 December
1932 adopted present name
effective— 1 January 1934; affiliated with the
UN— 15 November 1947
aim— to deal with world telecommunications
issues; a UN specialized agency
members— (189) includes all UN member countries except East Timor, Palau, Saint Kitts and Nevis (188 total); plus
Holy See
Islamic Development Bank (IDB)
established— 15 December 1973 by declaration
of intent
effective— 12 August 1974
aim— to promote Islamic economic aid and
social development
members— (54 plus the Palestine Liberation Organization) Afghanistan, Albania, Algeria, Azerbaijan, Bahrain,
Bangladesh, Benin, Brunei, Burkina Faso, Cameroon, Chad, Comoros, Cote d''lvoire, Djibouti, Egypt, Gabon, The
Gambia, Guinea, Guinea-Bissau, Indonesia, Iran, Iraq, Jordan, Kazakhstan, Kuwait, Kyrgyzstan, Lebanon, Libya,
Malaysia, Maldives, Mali, Mauritania, Morocco, Mozambique, Niger, Oman, Pakistan, Qatar, Saudi Arabia, Senegal,
Sierra Leone, Somalia, Sudan, Suriname, Syria, Tajikistan, Togo, Tunisia, Turkey, Turkmenistan, Uganda, UAE,
Uzbekistan, Yemen, Palestine Libe','4708c795f70cf05e1570fa14e252e9170236350ae22473d7ece9c40f20ee61b0','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f65aadfccef3a4f8016af5dd5b9da571578ddeb14b86e1f88169513b11d83682',2007,'CK','Cook Islands','transnational-issues',408,'ration Organization
Latin American Integration Association
(LAIA)
note— also known as Asociacion
Latinoamericana de Integracion (ALADI)
established- 12 August 1980
effective— 18 March 1981
aim— to promote freer regional trade
members— (12) Argentina, Bolivia, Brazil, Chile, Colombia, Cuba, Ecuador, Mexico, Paraguay, Peru, Uruguay,
Venezuela
observers— (25) China, Corporacion Andina de Fomento, Costa Rica, Dominican Republic, EC, El Salvador,
Guatemala, Honduras, Inter-American Development Bank, Inter- American Institute for Cooperation on Agriculture,
Italy, Japan, South Korea, Latin America Economic System, Nicaragua, Organization of American States, Panama,
Pan-American Health Organization, Portugal, Romania, Russia, Spain, Switzerland, United Nations Development
Program, United Nations Economic Commission for Latin America and the Caribbean
League of Arab States (LAS)
note— also known as Arab League (AL)
established— 22 March 1945
aim— to promote economic, social, political, and
military cooperation
members— (21 plus the Palestine Liberation Organization) Algeria, Bahrain, Comoros, Djibouti, Egypt, Iraq, Jordan,
Kuwait, Lebanon, Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan, Syria, Tunisia, UAE,
Yemen, Palestine Liberation Organization
least developed countries (LLDCs)
that subgroup of the less developed countries (LDCs) initially identified by the UN General Assembly in 1971 as
having no significant economic growth, per capita GDPs normally less than $1 ,000, and low literacy rates; also
known as the undeveloped countries; the 42 LLDCs are: Afghanistan, Bangladesh, Benin, Bhutan, Botswana,
Burkina Faso, Burma, Burundi, Cape Verde, Central African Republic, Chad, Comoros, Djibouti, Equatorial Guinea,
Eritrea, Ethiopia, The Gambia, Guinea, Guinea-Bissau, Haiti, Kiribati, Laos, Lesotho, Malawi, Maldives, Mali,
Mauritania, Mozambique, Nepal, Niger, Rwanda, Samoa, Sao Tome and Principe, Sierra Leone, Somalia, Sudan,
Tanzania, Togo, Tuvalu, Uganda, Vanuatu, Yemen
647
Appendix B: International Organizations and Groups (continued)
less developed countries (LDCs)
low-income countries
middle-income countries
Multilateral Investment Guarantee Agency
(MIGA)
established— 12 April 1988
aim— encourages flow of foreign direct
investment among member countries by offering
investment insurance, consultation, and
negotiation on conditions for foreign investment
and technical assistance; a UN specialized
agency
the bottom group in the hierarchy of developed countries (DCs), former USSR/Eastern Europe (former USSR/EE),
and less developed countries (LDCs); mainly countries and dependent areas with low levels of output, living
standards, and technology; per capita GDPs are generally below $5,000 and often less than $1,500; however, the
group also includes a number of countries with high per capita incomes, areas of advanced technology, and rapid
rates of growth; includes the advanced developing countries, developing countries, Four Dragons (Four Tigers),
least developed countries (LLDCs), low-income countries, middle-income countries, newly industrializing
economies (NIEs), the South, Third World, underdeveloped countries, undeveloped countries; the 172 LDCs are:
Afghanistan, Algeria, American Samoa, Angola, Anguilla, Antigua and Barbuda, Argentina, Aruba, The Bahamas,
Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, British Virgin Islands, Brunei,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Cayman Islands, Central African Republic,
Chad, Chile, China, Christmas Island, Cocos Islands, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Cook Islands, Costa Rica, Cote d''lvoire, Cuba, Cyprus, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia, Falkland Islands, Fiji, French Guiana,
French Polynesia, Gabon, The Gambia, Gaza Strip, Ghana, Gibraltar, Greenland, Grenada, Guadeloupe, Guam,
Guatemala, Guernsey, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hong Kong, India, Indonesia, Iran, Iraq,
Isle of Man, Jamaica, Jersey, Jordan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Laos, Lebanon, Lesotho,
Liberia, Libya, Macau, Madagascar, Malawi, Malaysia, Maldives, Mali, Marshall Islands, Martinique, Mauritania,
Mauritius, Mayotte, Federated States of Micronesia, Mongolia, Montserrat, Morocco, Mozambique, Namibia, Nauru,
Nepal, Netherlands Antilles, New Caledonia, Nicaragua, Niger, Nigeria, Niue, Norfolk Island, Northern Mariana
Islands, Oman, Palau, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Pitcairn Islands, Puerto
Rico, Qatar, Reunion, Rwanda, Saint Helena, Saint Kitts and Nevis, Saint Lucia, Saint Pierre and Miquelon, Saint
Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Solomon Islands, Somalia, Sri Lanka, Sudan, Suriname, Swaziland, Syria, Taiwan, Tanzania, Thailand,
Togo, Tokelau, Tonga, Trinidad and Tobago, Tunisia, Turks and Caicos Islands, Tuvalu, UAE, Uganda, Uruguay,
Vanuatu, Venezuela, Vietnam, Virgin Islands, Wallis and Futuna, West Bank, Western Sahara, Yemen, Zambia,
Zimbabwe; note— similar to the new International Monetary Fund (IMF) term "developing countries" which adds
Malta, Mexico, South Africa, and Turkey but omits in its recently published statistics American Samoa, Anguilla,
British Virgin Islands, Brunei, Cayman Islands, Christmas Island, Cocos Islands, Cook Islands, Cuba, Eritrea,
Falkland Islands, French Guiana, French Polynesia, Gaza Strip, Gibraltar, Greenland, Grenada, Guadeloupe, Guam,
Guernsey, Isle of Man, Jersey, North Korea, Macau, Martinique, Mayotte, Montserrat, Nauru, New Caledonia, Niue,
Norfolk Island, Northern Mariana Islands, Palau, Pitcairn Islands, Puerto Rico, Reunion, Saint Helena, Saint Pierre
and Miquelon, Tokelau, Tonga, Turks and Caicos Islands, Tuvalu, Virgin Islands, Wallis and Futuna, West Bank,
cw
CK
COK
184
.ck
Coral Sea Islands
CR
—
—
—
—
ISO includes with Australia
21 12 S
159 46 W
Axel Heiberg Island
45 00N
45 00N
22 55N
46 30S
37 00N
3100N
49 00N
43 00N
9 30N
43 00N
14 40N
43 00N
2010N
33 30N
10 53S
34 00E
34 00E
74 35W
5100E
25 10E
22 00E
18 00E
47 00E
215E
17 00E
17 26W
17 00E
73 00E
36 18E
165 49 W
685
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Danish Straits
Atlantic Ocean
58 00N
11 00 E
Danish West Indies (former name for the Virgin Islands)
Virgin Islands
18 20N
64 50W
Danmark (local name)
21 14 S
159 46 W
Hatay (province)
Turkey
36 30N
3615E
Havana (capital)
Punjab (region)
India, Pakistan
Puntland (region)','535865f8c51a77e446c1e75ce8be9c3dbc78aafbf735c6f7ce911af594647c30','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1300b4dad995fc77f22fad85fc5eb9c8f807f195f03456beb902e571961e4c1e',2007,'CR','Costa Rica','transnational-issues',417,'North Pacific
Ocean
Disputes - international: in September 2005, Costa
Rica took its case before the ICJ to advocate the
navigation, security, and commercial rights of Costa
Rican vessels using the Rio San Juan over which
Nicaragua retains sovereignty
Refugees and internally displaced persons:
refugees (country of origin): 8,266 (Colombia) (2005)
Illicit drugs: transshipment country for cocaine and
heroin from South America; illicit production of
cannabis on small, scattered plots; domestic cocaine
consumption, particularly crack cocaine, is rising
Cote d''lvoire
J
1 (
v
.Odienne
Vp Koitiogo*
p.
\\fc?
^1 Touba Seguela
rWl., Man
#Katiola Bondoukou <>
0Bouake /
Daioa
•
<£ Sinfra*
YAMOUSSOUKRO
• Abengouro. (WMA
Dimbokro V
*"% Gagnoa.
Adzope. \\
LIBERuN Divo'' ''*>"»»»* V
Dabou Aboisso.
f San-
t Pedro#
Abidjan -
."■Km
100 mi
Disputes - international: rebel and ethnic fighting
against the central government in 2002 has spilled
into neighboring states, driven out foreign cocoa
workers from nearby countries, and, in 2004, resulted
in 6,000 peacekeepers deployed as part of UN
Operation in Cote d''lvoire (UNOCI) assisting 4,000
French troops already in-country; the Ivorian
Government accuses Burkina Faso and Liberia of
supporting Ivorian rebels
Refugees and internally displaced persons:
refugees (country of origin): 70,402 (Liberia)
IDPs: 500,000-800,000 (2002 coup; most IDPs are in
western regions) (2005)
Illicit drugs: illicit producer of cannabis, mostly for
local consumption; transshipment point for Southwest
and Southeast Asian heroin to Europe and
occasionally to the US, and for Latin American
cocaine destined for Europe and South Africa; while
rampant corruption and inadequate supervision leave
the banking system vulnerable to money laundering,
the lack of a developed financial system limits the
country''s utility as a major money-laundering center
Disputes - international: Nicaragua filed a claim
against Honduras in 1999 and against Colombia in
2001 at the ICJ over disputed maritime boundary
involving 50,000 sq km in the Caribbean Sea,
including the Archipelago de San Andres y
Providencia and Quita Sueno Bank; the 1992 ICJ
ruling for El Salvador and Honduras advised a
tripartite resolution to establish a maritime boundary in
the Gulf of Fonseca, which considers Honduran
access to the Pacific; legal dispute over navigational
rights of San Juan River on border with Costa Rica
Illicit drugs: transshipment point for cocaine
destined for the US and transshipment point for
arms-for-drugs dealing
CS
CR
CRI
188
.cr
Cote d''lvoire
IV
CI
CIV
384
.ci
5 32N
87 04W
Cocos Islands
9 56N
84 05W
San Juan (capital)','42c6ef29da0208ff194a1020f31661e1bffb82851420dc6de4e751e33b721b23','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0edb2e9de738a458737c4665794fe774a3f9620199c692b458a5f387ba447f06',2007,'HR','Croatia','transnational-issues',426,'Background: The lands that today comprise Croatia
were part of the Austro-Hungarian Empire until the
close of World War !. In 1918, the Croats, Serbs, and
Slovenes formed a kingdom known after 1929 as
Yugoslavia. Following World War II, Yugoslavia
became a federal independent Communist state
under the strong hand of Marshal TITO. Although
Croatia declared its independence from Yugoslavia in
1991 , it took four years of sporadic, but often bitter,
fighting before occupying Serb armies were mostly
cleared from Croatian lands. Under UN supervision,
the last Serb-held enclave in eastern Slavonia was
returned to Croatia in 1998.
HR
HR
HRV
191
.hr
Daman (city; also Damao)
4510N
15 30E
Hudson Bay
Arctic Ocean
60 00N
86 00W
Hudson Strait
Arctic Ocean
62 00N
7100W
Hunter Island
New Caledonia. Vanuatu
22 24S
172 06 E
Iberian Peninsula
Portugal, Spain
40 00N
5 00W
Iceland Sea
Arctic Ocean
68 00N
20 00W
Ifni (region; former name of part of Spanish West Africa)
Pribilof Islands
Slovenija (local name for Slovenia)
Slovensko (local name for Slovakia)
Smyrna (region; former name for Izmir)
Society Islands (lies de la Societe)
Socotra (island)
45 27N
45 48N
15 58E
Zaire (former name for the Democratic Republic of
the Congo)
Democratic Republic of the Congo
15 00S
30 00E
Zakhalinskiy Zaliv (bay)
Pacific Ocean
54 00N
142 00 E
Zaliv Shelikhova (bay)
Pacific Ocean
60 00N
157 30 E
Zambezia (region)','c381080214b0681b06ffa4198321b12e97d7fae91094a5762c8de1590097059e','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7dae7e180e3c5a260109eecd7e36da84a9f12e27be6e81c89a214ae4e784119',2007,'SI','Slovenia','transnational-issues',435,'Disputes - international: discussions continue with
Bosnia and Herzegovina over several small disputed
sections of the boundary related to maritime access
that hinders ratification of the 1 999 border agreement;
the Croatia-Slovenia land and maritime boundary
agreement, which would have ceded most of Pinn Bay
and maritime access to Slovenia and several villages
to Croatia, remains un-ratified and in dispute; as a
European Union peripheral state, neighboring
Slovenia must conform to the strict Schengen border
rules to curb illegal migration and commerce through
southeastern Europe while encouraging close
cross-border ties with Croatia
Refugees and internally displaced persons:
IDPs: 12,600 (Croats and Serbs displaced in 1992-95
war) (2005)
Illicit drugs: transit point along the Balkan route for
Southwest Asian heroin to Western Europe; has been
used as a transit point for maritime shipments of South
American cocaine bound for Western Europe
145
O 20 40 km
I n t r o d u c t i o
Background: The Slovene lands were part of the
Austro-Hungarian Empire until the latter''s dissolution
at the end of World War I. In 1 91 8, the Slovenes joined
the Serbs and Croats in forming a new multinational
state, which was named Yugoslavia in 1929. After
World War II, Slovenia became a republic of the
renewed Yugoslavia, which though Communist,
distanced itself from Moscow''s rule. Dissatisfied with
the exercise of power by the majority Serbs, the
Slovenes succeeded in establishing their
independence in 1991 after a short 10-day war.
Historical ties to Western Europe, a strong economy,
and a stable democracy have assisted in Slovenia''s
transformation to a modern state. Slovenia acceded to
both NATO and the EU in the spring of 2004.
Location: Central Europe, eastern Alps bordering
the Adriatic Sea, between Austria and Croatia
Geographic coordinates: 46 07 N, 14 49 E
Map references: Europe
Area:
total: 20,273 sq km
land: 20,151 sq km
water: 122 sq km
Area - comparative: slightly smaller than New
SI
46 03N
14 31 E
Llanos (region)
Venezuela
8 00N
68 00W
Lobamba (city)
Swaziland
26 27S
31 12 E
Lombok (island)
46 00N','9627b32a7ea9e371e0a7abced33650d48c62eacf9ac12ac1d33065ee241c8140','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa34478608b008f23f9d45bbd4f069f94562dbedb73cadb4ea1b808765b94da9',2007,'CU','Cuba','transnational-issues',436,'Gulf of
Progreso. .Cancun
*Menda
Manzanillo*
Lazaro Cardenas*
Acapulco*
u Oriiab i
Coatzacoalcos
''Oaxaca
Salina
Cruz
Disputes - international: prolonged drought,
population growth, and outmoded practices and
infrastructure in the border region have strained
water-sharing arrangements with the US; the US has
stepped up efforts to stem nationals from Mexico,
Central America, and other parts of the world from
illegally crossing the border with Mexico
Refugees and internally displaced persons:
IDPs: 12,000 (government''s quashing of Zapatista
uprising in 1994 in eastern Chiapas Region) (2005)
Illicit drugs: major drug-producing nation; cultivation
of opium poppy in 2004 amounted to 3,500 hectares,
but opium cultivation stayed within the range -
between 3,500 and 5,500 hectares - observed in nine
of the last 12 years; potential production of 9 metric
369
Mexico (continued)
tons of pure heroin, or 23 metric tons of "black tar"
heroin, the dominant form of Mexican heroin in the
western United States; marijuana cultivation
decreased 23°o to 5,800 hectares in 2004 after
decade-high cultivation peak in 2003; potential
production of 1 0.400 metric tons of marijuana in 2004;
government conducts the largest independent
illicit-crop eradication program in the world; major
supplier of heroin and largest foreign supplier of
marijuana and methamphetamine to the US market;
continues as the primary transshipment country for
US-bound cocaine from South America, accounting
for about 90% of estimated annual cocaine movement
to the US; major drug syndicates control majority of
drug trafficking throughout the country; producer and
distributor of ecstasy; significant money-laundering
center
Micronesia,
Federated
States of
Northern ° 35" JOOKm
Philippine Mariana 0 350 700 m
Sea Islands
■''. (U.S.)
North Pacific
Guam (U.S.).- Ocean Marshall
Yap islands
Islands Hall
/ ■ . Islands
,J PALIKIR
•• '' ■ ®
Caroline"- Islands ° • \\Pohnpei
Truk^'' .. Kosrae''
Islands
(Chuuk)
• Kapingamarangi
CU
CU
CUB
192
.cu
20 00N
75 08W
Guatemala (capital)
23 08N
82 22W
Hawaii (island)
Kabardino-Balkaria (region)
Russia
Kabul (capital)
2140N
82 50W
Pleasant Island
Yucatan Channel
Atlantic Ocean
Yucatan Peninsula
From Columbus to Castro
and Beyond, Fifth Edition
Jaime Suchlicki
ISBN 978-1-57488-436-4 Paperback
Fragments of Grace
My Search for Meaning in
the Strife of South Asia
Pamela Constable
ISBN 978-1-57488-618-4 Cloth
ISBN 978-1-57488-619-1 Paperback','531e3d825622be7a109cbc877968b16942ba30349565bf6e55d4e93a55face08','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3068841bb1e8fcb3e9c57d5a2e870415a807f884b1e9e83cc847378d76afebc1',2007,'MX','Mexico','transnational-issues',437,'HAVANA
^K
THE
MX
MX
MEX
484
.mx
16 51 N
99 55W
Accra (capital)
Canton (city; now Guangzhou)
20 30N
86 55W
Crete (island)
2911 N
118 17W
Guantanamo Bay (US Naval Base)
23 13N
106 25 W
Mbabane (capital)
Swaziland
26 18S
3106E
McDonald Islands
Atlantic Ocean
Middle Congo (former name for Republic of the Congo) Republic of the Congo
2127N
36 00N
3519N
55 43N
33 00N
3815N
19 24N
25 00N
100S
39 49E
15 00E
2 58W
2130E
44 00 E
15 35E
99 09W
90 00W
15 00E
695
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Milwaukee Deep (Puerto Rico Trench)
Atlantic Ocean
19 55N
65 27W
Minami-tori-shima (Marcus Island)
25 40N
100 19 W
Montevideo (capital)
Reykjavik (capital)
Yugoslavia
Serbia and Montenegro
Yugoslavia, Kingdom of (former name for
a Balkan federation)
Bosnia and Herzegovina, Croatia, Macedonia,
Serbia and Montenegro, Slovenia
Yugoslavia, Socialist Federal Republic of (former name
for a Balkan federation)
Bosnia and Herzegovina, Croatia, Macedonia,
Serbia and Montenegro, Slovenia
8 00N
39 55N
6 49N
16 47N
3 52N
9 30N
0 32S
56 50N
36 00N
15 00N
14 00N
40 11 N
31 SON
21 40 N
2145N
19 30N
43 00N
43 00N
43 00N
38 00E
124 20 E
517W
9610E
1131 E
138 00 E
166 55 E
60 39E
123 00 E
44 00E
46 00E
44 30E
34 45E
82 50W
85 45W
89 00W
2100E
19 00E
19 00E
708
Appendix F: Cross-Reference List of Geographic Names (continued)
Latitude Longitude
Name Entry in The World Factbook (deg min) (deg min)
Zagreb (capital)
From Montezuma to the Fall
of the PRI, Second Edition
Jaime Suchlicki
ISBN 978-1-57488-326-8 Paperback
Why Secret
Intelligence Fails
Revised Edition
Michael A. Turner
ISBN 978-1-59797-891-1 Paperback
Jacket designed by
Drawing Board Studios
Copyright © 2007 Potomac Books, Inc.
Potomac Books, Inc.
22841 Quicksilver Drive, Dulles, VA 20166
www. potomacbooksinc.com
ms
m
MEfcad
.
references that belong on everyone''s bookshelf
''Excellent for answering quick reference questions on the nations of the world."
— American Reference Books Annual
"A valuable, easy-to-use worldwide information source.
— World Affairs Council Booknotes
''Excellent ... A wealth of unclassified data is provided An indispensable reference for
those involved in global political, military diplomatic, or economic affairs."
— Sea Power
"A readable, easy-to-use reference which should find its way to the bookshelf of any serious
sUident of international affairs."
— Friday Review of Defense Literature
"A complete guide on ever}'' country in the world.
— Marine Corps Gazette
I
WW
^MP
ISBN 978-1-59797-109-6
90000
9 I781597»971096','fa3fc029261a92e17ef2f5d440099ee760c7b96a27c3b566187f540c94038828','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c971f1f1569086e45cfc9c8966460c5e604d1e6d657e279f16a5ea81c7910127',2007,'HT','Haiti','transnational-issues',446,'Disputes - international: US Naval Base at
Guantanamo Bay is leased to US and only mutual
agreement or US abandonment of the area can
terminate the lease
Illicit drugs: territorial waters and air space serve as
transshipment zone for US and European-bound
drugs: established the death penalty for certain
drug-related crimes in 1999
148
Disputes - international: increasing numbers of
illegal migrants from the Dominican Republic cross
the Mona Passage each year to Puerto Rico to find
work
Illicit drugs: transshipment point for South American
drugs destined for the US and Europe; has become a
transshipment point for ecstasy from the Netherlands
and Belgium destined for US and Canada; substantial
money-laundering activity; Colombian narcotics
traffickers favor the Dominican Republic for illicit
financial transactions
East Timor
Danda Sea
Caribbean
Sea
NORTH ATLANTIC OCEAN
lie de la
Tortue
Cap
HaTtien,-
A
^onaives >
Qoltedeie S Saint- Ui„„.<!
GonSvc ( Marc HinchSX
"Verrettes 0^
RT-AU- Hispaniola
DDINCE
Caribbean Sea
Disputes - international: since 2004, about 8,000
peacekeepers from the UN Stabilization Mission in
Haiti (MINUSTAH) maintain civil order in Haiti: despite
efforts to control illegal migration, Haitians fleeing
economic privation and civil unrest continue to cross
into the Dominican Republic and sail to neighboring
countries; Haiti claims US-administered Navassa
Island
Illicit drugs: Caribbean transshipment point for
cocaine en route to the US and Europe: substantial
money-laundering activity; Colombian narcotics
traffickers favor Haiti for illicit financial transactions:
pervasive corruption
Heard Island
and McDonald
Islands
(territory of Australia)
O 8 16 km
O 8 16 m,
McDonald ''. Shag
Islands Island
Flat Island v^A /) ^^_
McDonald Island \\
Heard Island
Indian Ocean
Disputes - international: none
Holy See
(Vatican City)
4
HA
HT
HTI
332
ht
18 32N
72 20W
Port-of-Spain (capital)','03f5b41b323ac8d9951e93a185e7473a512c6dcd954ae7d02b5e1c45e4f211cc','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48c64b583c81b85296d62d53f6b2bae0eed16cc5b7e006b104b4111bb4d22b8b',2007,'DK','Denmark','transnational-issues',455,'Background: Once the seat of Viking raiders and later
a major north European power, Denmark has evolved
into a modem, prosperous nation that is participating in
the general political and economic integration of Europe.
It joined NATO in 1949 and the EEC (now the EU) in
1973. However, the country has opted out of certain
elements of the European Union''s Maastricht Treaty,
including the European Economic and Monetary Union
(EMU), European defense cooperation, and issues
concerning certain justice and home affairs.
Disputes - international: Iceland disputes the
Faroe Islands'' fisheries median line; Iceland, the UK,
and Ireland dispute Denmark''s claim that the Faroe
Islands'' continental shelf extends beyond 200 nm;
Faroese continue to study proposals for full
independence; uncontested sovereignty dispute with
Canada over Hans Island in the Kennedy Channel
between Ellesmere Island and Greenland
Dhekelia
(UK sovereign
base area)
Disputes - international: because anticipated
offshore hydrocarbon resources have not been
realized, earlier Faroese proposals for full
independence have been deferred; Iceland disputes
the Faroe Islands'' fisheries median line boundary;
Iceland, the UK, and Ireland dispute Denmark''s claim
that the Faroe Islands'' continental shelf extends
beyond 200 nm
191
Strait
Paamiut\\
(FredenkshafJ) Narsarsuaq
Nanortalik* •---
DA
DK
DNK
208
.dk
5510N
15 00E
Bosna i Hercegovina (local name for Bosnia and
Herzegovina)
55 40N
12 35E
Coral Sea
Pacific Ocean
15 00S
150 00 E
Corfu (island)
56 00N
10 00E
Danzig (city; former name for Gdansk)
55 20N
10 25E
Gaborone (capital)
Juventud, Isla de la (Isle of Youth)
55 30N
Atlantic Ocean
57 45N
Macedonia
4159N','f146687bc8ede61e33574cdeb0dfeb8f9cc32e0a51317c61097db5be49c3cb3a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24df096971cdb623ccedd0f574eabec5289040dfe66c50f3531ea270abf6bb0c',2007,'DJ','Djibouti','transnational-issues',472,'Disputes ■ international: Djibouti maintains
economic ties and border accords with "Somaliland"
leadership while maintaining some political ties to
various factions in Somalia; thousands of Somali
refugees await repatriation in UNHCR camps in
Refugees and internally displaced persons:
refugees (country of origin): 17,331 (Somalia) (2005)
Dominica •<?!>'' !
NORTH
''Portsmouth
Marigot.
ATLANTIC
OCEAN
A
Morne D''ablotms
Caribbean
Saint
.Joseph
Sea
La Plaine#
ROSEAU
*
0 3 6km
Berekua
•
0 3 6mi
-
■
Disputes - international: Yemen protests Eritrea
fishing around the Hanish Islands awarded to Yemen
by the ICJ in 1999; Saudi Arabia still maintains the
concrete-filled pipe as a security barrier along
sections of the border with Yemen in 2004 to stem
illegal cross-border activities; Yemen protests Saudi
erection of a concrete-filled pipe as a security barrier
in 2004 to stem illegal cross-border activities in
sections of the boundary
Refugees and internally displaced persons:
refugees (country of origin): 63,51 1 (Somalia) (2005)
613
DJ
DJ
DJI
262
•dj
11 30 N
43 00E
Afghanestan (local name for Afghanistan)
11 30 N
4315E
Dnieper (river)
Belarus, Russia, Ukraine (Dnyapro, Dnepr, Dnipro)
46 30N
32 18E
Dniester (river)
Moldova, Ukraine (Nistru, Dnister)
4618N
3017E
Dobruja (region)
Bulgaria, Romania
43 30N
28 00E
Dodecanese (island group)
1130N
43 00E
French Sudan (former name for Mali)
11 30 N
43 00E
French Togoland (former name for Togo)','ff5ba342278fa6a0d5c0e00466cda1ece78ca20fdffe68d614dc93b92bbc1b83','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cd284acddf96b4dd04fe182de8613ee94ba023fd980d8b769c5c1f8b01136142',2007,'LC','Saint Lucia','transnational-issues',476,'Disputes • international: Dominica is the only
Caribbean state to challenge Venezuela''s sovereignty
claim over Aves Island and joins the other island
nations in challenging whether the feature sustains
human habitation, a criterion under the UN
Convention on the Law of the Sea (UNCLOS), which
permits Venezuela to extend its Exclusive Economic
Zone (EEZ) and continental shelf claims over a large
portion of the Caribbean Sea
Illicit drugs: transshipment point for narcotics bound
for the US and Europe; minor cannabis producer;
anti-money-laundering enforcement is weak, making
the country particularly vulnerable to money
laundering
Dennery^
Meunf
Soutri^re*
^Pelil Piton
NORTH
ATLANTIC
OCEAN
Vieux Fort*
Disputes - international: joins other Caribbean
states to counter Venezuela''s claim that Aves Island
sustains human habitation, a criterion under
UNCLOS, which permits Venezuela to extend its EE27
continental shelf over a large portion of the Caribbean
Sea
Illicit drugs: transit point for South American drugs
destined for the US and Europe
474
Saint Pierre
and Miquelon
(territorial collectivity
of France)
0 5 10 Km
Miquelon
Cull ol
wrence
Langlade
(Petite Miquelon)
North Atlantic Ocean
Miquelon
(Grande
Miquelon)
lie Saint-Pierre
*SAINT-PIERRE
Disputes - international: joins other Caribbean
states to counter Venezuela''s claim that Aves Island
sustains human habitation, a criterion under
UNCLOS, which permits Venezuela to extend its EEZ/
continental shelf over a large portion of the Caribbean
Sea
Illicit drugs: transshipment point for South American
drugs destined for the US and Europe; small-scale
cannabis cultivation
478
ST
LC
LCA
662
.lc
14 01 N
6100W
Catalonia (region)','da51b111f08f156ac50aba86b19da88cee44f089fdc374f9a8041847a82b2f2f','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('41804f13f8bd5ff4a073641414020a2af7aff6f88292809f0878dca63b7ab992',2007,'DO','Dominican Republic','transnational-issues',477,'K
NORTH ATLANTIC OCEAN
San Francisco
#de Macorjs_^.,
Bonao
San Cnst6bal
San Pedro HigueK
*. aeMacor''sj.aRomaiia
SANTO ""Y/
''Barahona DOMINGO
''edernales
V
Caribbean Sea
Disputes - international: increasing numbers of
illegal migrants from the Dominican Republic cross
the Mona Passage to Puerto Rico each year looking
for work
East Timor
Republique Centrafricain (local name for Central
African Republic)
18 28N
69 54W
Sao Pedro e Sao Paulo, Penedos de (rocks)','52cc3f009713a65997a693aef3dc2127d4d2fd52b1625e5d1724b5c23d10fba3','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f34e649cd04912bf0b3d1ee11bbcd8873530a8a17c7433038d2832c44f95858',2007,'EC','Ecuador','transnational-issues',481,'Background: The "Republic of the Equator" was one
of three countries that emerged from the collapse of
Gran Colombia in 1830 (the others are Colombia and
Venezuela). Between 1904 and 1942, Ecuador lost
territories in a series of conflicts with its neighbors. A
border war with Peru that flared in 1 995 was resolved
in 1999. Although Ecuador marked 25 years of civilian
governance in 2004, the period has been marred by
political instability. Seven presidents have governed
Ecuador since 1996.
0 00N
90 30W
Commander Islands (Komandorskiye Ostrova)
Russia
55 00N
167 00 E
Comores (local name for Comoros)
0 39S
78 26W
Courantyne River
Guyana. Suriname
5 57N
57 06W
Cozumel (island)
0 00N
90 30W
Galicia (region)
Poland. Ukraine
49 30N
23 00E
Galicia (region)
48 00N
3125N
52 00N
53 00N
78 00N
73 30S
24 27N
013S
68 00E
34 20E
72 00W
132 00 W
95 00W
12 00E
118 23 E
78 30W
Rabat (capital)','5feb37e47fded68f33453b2b5580e9ac84846dae9baa3a61d0090ad1506e7b07','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8b16b90a65433aa5e15fbc5d5b3163aa5186c0239a17d045e99b2a9498932bb',2007,'PE','Peru','transnational-issues',490,'Disputes - international: organized illegal narcotics
operations in Colombia penetrate across Ecuador''s
shared border and caused over 20,000 refugees to
flee into Ecuador in 2004
Refugees and internally displaced persons:
refugees (country of origin): 8,270 (Colombia) (2005)
Illicit drugs: significant transit country for cocaine
originating in Colombia and Peru; importer of
precursor chemicals used in production of illicit
narcotics; attractive location for cash-placement by
drug traffickers laundering money because of
dollarization and weak anti-money-laundering regime;
increased activity on the northern frontier by trafficking
groups and Colombian insurgents
Disputes - international: Egypt and Sudan retain
claims to administer the two triangular areas that
extend north and south of the 1899 Treaty boundary
along the 22nd Parallel, but have withdrawn their
military presence; Egypt is developing the Hala''ib
Triangle north of the Treaty line; since the attack on
Taba and other Egyptian resort towns on the Red Sea
in October 2004, Egypt vigilantly monitors the Sinai
and borders with Israel and the Gaza Strip; Egypt
does not extend domestic asylum to some 70,000
persons who identify themselves as Palestinians but
who largely lack UNRWA assistance and, until
recently, UNHCR recognition as refugees
Refugees and internally displaced persons:
refugees (country of origin): 70,245 (Palestinian
Territories) 14,904 (Sudan) (2005)
Illicit drugs: transit point for Southwest Asian and
Southeast Asian heroin and opium moving to Europe,
Africa, and the US; transit stop for Nigerian couriers;
concern as money-laundering site due to lax
enforcement of financial regulations
173
PE
PE
PER
604
•pe
12 03S
77 03W
Lincoln Sea
Arctic Ocean
83 00N
56 00W
Line Islands
Jarvis Island, Kingman Reef, Kiribati,
Palmyra Atoll
0 05N
157 00 W
Lion, Gulf of
Atlantic Ocean
43 20N
4 00E
Lisbon (capital)','4a152efad43a9584651036b70f231304e331e9c41f86e8b00c89687910aaa14b','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('407e0f2ce0972c3a484c50a33d963a6fee7904575460882e41850603fc8b9428',2007,'SV','El Salvador','transnational-issues',500,'Disputes - international: in 1992, the International
Court of Justice (ICJ) ruled on the delimitation of
"bolsones" (disputed areas) along the El
Salvador-Honduras boundary, but despite
Organization of American States (OAS) intervention
and a further ICJ ruling in 2003, full demarcation of the
border remains stalled; the 1992 ICJ ruling advised a
tripartite resolution to a maritime boundary in the Gulf
of Fonseca advocating Honduran access to the
Pacific; El Salvador continues to claim tiny Conejo
Island, not identified in the ICJ decision, off Honduras
in the Gulf of Fonseca
Illicit drugs: transshipment point for cocaine; small
amounts of marijuana produced for local
consumption; domestic cocaine abuse on the rise
13 42N
8912W
Sanaa (capital)','199488ce4611e7a86131d2fb4d253a3e87e55180a748f6de9ab82af5ea052ac6','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f10e8dfb0d8b28f6d72ec1d4678ab8806df90866b50a265ec2c6ed2baf4cd0e3',2007,'GQ','Equatorial Guinea','transnational-issues',501,'„=4 d O 40 80 km
^•3S>fc?L i • , — •
sST^ &r* O 40
Luba
^MALABO
/
Isla de Bioko
Bight
of
Biafra
Island not shown in true
geographical position.
Isla de Annobdn
□
Antananarivo (capital)
3 30N
8 42E
Biscay, Bay of
Atlantic Ocean
44 00N
4 00W
Bishkek (capital)
0 55N
919E
Corn Islands (Islas del Maiz)
0 59N
9 33E
Enderbury Island
Filipinas (local name for the Philippines)
2 00N
10 00E
Guinea, Gulf of
Atlantic Ocean
3 00N
2 30E
Guine-Bissau (local name for Guinea-Bissau)
3 45N
8 47E
694
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Malacca, Strait of
Indian Ocean
2 30N
101 20 E
Malagasy Republic
130N
10 00E
Riyadh (capital)
2 00N
10 00E
Spanish Morocco (former name for northern Morocco)','b5c69ed9b689119663425f14f75a7c6c10bf79f56a012e2fc4b2c394b258353c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9896af6ec30243bb43eb74982be947213640315ec659bcc3a275b2b3617b740a',2007,'GN','Guinea','transnational-issues',510,'Disputes - international: in 2002, ICJ ruled on an
equidistance settlement of Cameroon-Equatorial
Guinea-Nigeria maritime boundary in the Gulf of
Guinea, but a dispute between Equatorial Guinea and
Cameroon over an island at the mouth of the Ntem
River, imprecisely defined maritime coordinates in the
ICJ decision, and the unresolved Bakasi allocation
contribute to the delay in implementation; UN has
been pressing Equatorial Guinea and Gabon to
pledge to resolve the sovereignty dispute over
Gabon-occupied Mbane Islanc and create a maritime
boundary in the hydrocarbon-rich Corisco Bay
178
Disputes - international: UN presses Equatorial
Guinea and Gabon to resolve the sovereignty dispute
over Gabon-occupied Mbane Island and to establish a
maritime boundary in hydrocarbon-rich Corisco Bay;
only a few hundred out of the 20,000 Republic of the
Congo refugees who fled militia fighting in 2000
remain in Gabon
207
Gambia, The
Background: The Gambia gained its independence
from the UK in 1965; it formed a short-lived federation
of Senegambia with Senegal between 1 982 and 1 989.
In 1991 the two nations signed a friendship and
cooperation treaty. A military coup in 1994 overthrew
the president and banned political activity, but a 1996
constitution and presidential elections, followed by
parliamentary balloting in 1997, completed a nominal
return to civilian rule. The country undertook another
round of presidential and legislative elections in late
2001 and early 2002. Yahya A. J. J. JAMMEH, the
leader of the coup, has been elected president in all
subsequent elections.
Ge
o g r a p h y
Location: Western Africa, bordering the North
Atlantic Ocean and Senegal
Geographic coordinates: 1 3 28 N, 1 6 34 W
Map references: Africa
Area:
total: 1 1 ,300 sq km
land: 10,000 sq km
water: 1 ,300 sq km
Area - comparative: slightly less than twice the size
of Delaware
Land boundaries:
total: 740 km
border countries: Senegal 740 km
Coastline: 80 km
Maritime claims:
territorial sea: 1 2 nm
contiguous zone: 18 nm
continental shelf: not specified
exclusive fishing zone: 200 nm
Climate: tropical; hot, rainy season (June to
November); cooler, dry season (November to May)
Terrain: flood plain of the Gambia River flanked by
some low hills
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location 53 m
Natural resources: fish, titanium (rutile and
ilmenite), tin, zircon, silica sand, clay, petroleum
Land use:
arable land: 27.88%
permanent crops: 0.44%
otfie/-:71.68%(2005)
Irrigated land: 20 sq km (1998 est.)
Natural hazards: drought (rainfall has dropped by
30% in the last 30 years)
Environment • current issues: deforestation;
desertification; water-borne diseases prevalent
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: almost an enclave of Senegal;
smallest country on the continent of Africa
Disputes - international: attempts to stem
refugees, cross-border raids, arms smuggling, and
other illegal activities by separatists from southern
Senegal''s Casamance region, as well as from
conflicts in other west African states
Gaza Strip
O 3 6 km
X
O 3
6 mi
s
/ v.
Gaza /
s
/
.—" 1V30-
Mediterranean
Sea
&
Dayr al
,''jf
Balah si?
4*
/
/ Khan (
Yunis .
NORTH
ATLANTIC
OCEAN
Disputes - international: conflicts among rebel
groups, warlords, and youth gangs in neighboring
states have spilled over into Guinea, resulting in
domestic instability; Sierra Leone has pressured
Guinea to remove its forces from the town of Yenga,
occupied since 1 998
Refugees and internally displaced persons:
refugees (country of origin): 127,256 (Liberia) 7,165
(Sierra Leone) 7,064 (Cote d''lvoire)
IDPs: 82,000 (cross-border incursions from Liberia,
Sierra Leone, Cote d''lvoire) (2005)
240
llheu das Cabras
llha de
Sao Tome
\\ ^-''Santa Cruz
llheu das Rdlas
v^ ^Choiseul
.°* V^.
• Santa Isabel
Yandina
South
Pacific
Ocean
HONIARA*
Guadalcanal *ola
Malaita
Solomon
Sea
San
Cristobal
Santa
Cruz
Islands
Cora! Sea
ISO 300 km
GV
GN
GIN
324
gn
9 31 N
13 43W
Confederatio Helvetica (local name for Switzerland)
11 00 N
10 00W
French Indochina (former name for French possessions in
southeast Asia)
Cambodia. Laos, Vietnam
15 00N
107 00 E
French Morocco (former name for Morocco)
11 00 N
Guyane Francaise (local name for French Guiana)
Ha''apai Group (island group)','f11e9d9575b2a03d31f12775547d15b147be6bd6d144fa355401913a56d447a6','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ced53a70f3ae9d66f3c23313a87c3c5dcf31c2687453a2300034afead51766a3',2007,'ER','Eritrea','transnational-issues',519,'Disputes - international: Eritrea and Ethiopia
agreed to abide by 2002 Ethiopia-Eritrea Boundary
Commission''s (EEBC) delimitation decision, but
despite international intervention, mutual animosities,
accusations, and armed posturing have prevented
demarcation; Ethiopia refuses to withdraw to the
delimited boundary until claimed technical errors
made by the EEBC that ignored "human geography"
are addressed, including the award of Badme, the
focus of the 1998-2000 war; Eritrea insists that the
EEBC decision be implemented immediately without
modifications; in 2005 Eritrea began severely
restricting the operations of the UN Peacekeeping
Mission to Ethiopia and Eritrea (UNMEE) monitoring
the 25km-wide Temporary Security Zone in Eritrea
since 2000; Sudan sustains over 1 10,000 Eritrean
refugees and accuses Eritrea of supporting Sudanese
rebel groups
Refugees and internally displaced persons:
IDPs: 59,000 (border war with Ethiopia from
1998-2000; most IDPs are near the central border
region) (2005)
15 20N
38 53E
Asmera (see Asmara)
15 20N
38 53E
As-Sudan (local name for Sudan)
15 00N
39 00E
Espana','ec6ec1c744740b19ecb139139a676093b5c7f1009ada24056086d0b472f489e2','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c27121cfc12cee55e6afd9e946e8286ea46437da68bf29ed0a8d5ac06727b99',2007,'EE','Estonia','transnational-issues',520,'F,NLA?V^
Z?*^ Gulf ol Fmll
land
SVnrv_
Sea
Paldiski **Muuga Kunda . Natvl
• tai i imm Kohtla- <*
A Saaremaa. ■"
\\r7
Disputes - international: in 2005, Russia refuses to
sign the 1 996 technical border agreement with
Estonia when Estonia prepares a unilateral
declaration referencing Soviet occupation and
territorial losses; Russia demands better
accommodation of Russian-speaking population in
Estonia; Estonian citizen groups continue to press for
realignment of the boundary based on the 1920 Tartu
Peace Treaty that would bring the now divided ethnic
Setu people and parts of the Narva region within
Estonia; as a member state that forms part of the EU''s
external border, Estonia must implement the strict
Schengen border rules
Illicit drugs: transshipment point for opiates and
cannabis from Southwest Asia and the Caucasus via
Russia, cocaine from Latin America to Western
Europe and Scandinavia, and synthetic drugs from
Western Europe to Scandinavia; increasing domestic
drug abuse problem; possible precursor
manufacturing and/or trafficking; potential money
laundering related to organized crime and drug
trafficking is a concern, as is possible use of the
gambling sector to launder funds
59 00N
26 00E
Eire (local name for Ireland)
58 50N
22 30E
Hispaniola (island)
Dominican Republic, Haiti
18 45 N
7100W
Ho Chi Minh City (Saigon)
Vietnam
10 45N
106 40 E
Hokkaido (island)
58 25N
22 30E
Saba (island)
Netherlands Antilles
17 38N
6310W
Sabah (state)
Tanganyika (former name for the mainland portion of
Tanzania)
Tanzania
Tangier (city)','c45a02e433268bf95f8eff1cd3dbb5d44bd3d8fda3dca6338970592c0d63a8be','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d58a71c7c2c05e0bb0ab28246b5cacbcaa88bd72c229bda604179f9b2122471',2007,'ET','Ethiopia','transnational-issues',536,'Disputes - international: Eritrea and Ethiopia
agreed to abide by the 2002 Eritrea-Ethiopia
Boundary Commission''s (EEBC) delimitation
decision, but mutual animosities, accusations, and
armed posturing prevail, preventing demarcation
despite international intervention; Ethiopia refuses to
withdraw to the delimited boundary until technical
errors made by the EEBC that ignored "human
geography" are addressed, including the award of
Badme. the focus of the 1 998-2000 war; Eritrea insists
that the EEBC decision be implemented immediately
without modifications; Ethiopia has only an
administrative line and no international border with the
Oromo region of southern Somalia where it maintains
186
Ethiopia (continued)
alliances with local clans in opposition to the
unrecognized Somali Interim Government in
Mogadishu; "Somaliland" secessionists provide port
facilities and trade ties to landlocked Ethiopia; efforts
to demarcate the porous boundary with Sudan have
been delayed by civil war
Refugees and internally displaced persons:
refugees (country of origin): 90,451 (Sudan) 16,470
(Somalia) 8,719 (Eritrea)
IDPs: 132,000 (border war with Eritrea from
1998-2000 and ethnic clashes in Gambela; most IDPs
are in Tigray and Gambela Provinces) (2005)
Illicit drugs: transit hub for heroin originating in
Southwest and Southeast Asia and destined for
Europe and North America, as well as cocaine
destined for markets in southern Africa; cultivates qat
(khat) for local use and regional export, principally to
Djibouti and Somalia (legal in all three countries); the
lack of a well-developed financial system limits the
country''s utility as a money-laundering center
Europa Island
(possession of France)
II
Disputes - international: attempts to stem refugees
and cross-border raids, arms smuggling, and political
instability from a separatist movement in Senegal''s
Casamance region
Disputes - international: none
484
A'' Galcaio
v<o^- — ^Beledweyne
Europa Island
Falkland Islands (Islas Malvinas)
8 00N
38 00E
Acapulco (city)
9 02N
38 42E
Adelie Land (claimed by France; also Terre Adelie)
8 00N
38 00E
Ivory Coast (former name for Cote d''lvoire)
Cote d''lvoire
8 00N
5 00W
Iwo Jima (island)
Yalu River
China, North Korea
Yamoussoukro (capital)
Cote d''lvoire
Yangon (see Rangoon)
Burma
Yaounde (capital)','3149044c836c84ce2fac7ff9e4d2735483b7fd50c23736ad632f75d845ec57fe','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b5641d029f94b00dd49a266790327f989bed5bcc4b53b78c96a2ccd5028c8e6',2007,'FO','Faroe Islands','transnational-issues',544,'(part of the Kingdom
of Denmark)
NORTH
ATLANTIC
OCEAN
Streymoy b*>naraiw , sv/noy
Fuglafjer&Yiur* ,.KIaksvik
Vestmanna# \\ ^^^8o^°v
^trv ^oir - Eysturoy
iqar *TORSHAVN
v^t», Norwegian
Sandoy
Vdgar
S/cuvoy
S/d*a Dimun
\\ Tyoroyn
Suyuroy
62 00N
7 00W
Fort-de-France (capital)
62 01N
6 46W
Toshkent (see Tashkent)','5c920f07f171d7cf6c8314f80b92b35cdd04bc78a1cd27150453a8f197d07017','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('200b6f85d3beb6f349ed7bbb4f51b13fde4b16c8018ccb54587d94390d596869',2007,'FJ','Fiji','transnational-issues',552,'Roluma
South Pacific Ocean
Vanua Levu ,Lambasa
lautoVa^X .Levuka
Viti Levu
''suVa
Kadavu
. Ceva-i-Ra
100 200 km
12 30S
177 05 E
Ruanda (former name for Rwanda)
Sverdlovsk (city; also Yekaterinburg)
Russia
Sverige (local name for Sweden)
18 00S
178 00 E
Vladivostok (city)
Russia
4310N
131 56 E
Vojvodina (region)
Serbia and Montenegro
45 35N
20 00E
Volcano Islands','3744caafdb4227f5325d95bd2a44560445044c1536d680fa32de8ef7c569c0c3','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c8063810b9513de7303d382aedc32326e1f492dbe1f48a46931e5ce35fe66460',2007,'JE','Jersey','transnational-issues',563,'Disputes - international: none
Disputes - international: West Bank and Gaza Strip
are Israeli-occupied with current status subject to the
Israeli-Palestinian Interim Agreement - permanent
status to be determined through further negotiation;
Israel continues construction of a "seam line"
separation barrier along parts of the Green Line and
within the West Bank; Israel withdrew its settlers and
military from the Gaza Strip and from four settlements
in the West Bank in August 2005; Golan Heights is
Israeli-occupied (Lebanon claims the Shab''a Farms
area of Golan Heights); since 1948, about 350
peacekeepers from the UN Truce Supervision
Organization (UNTSO) headquartered in Jerusalem
monitor ceasefires, supervise armistice agreements,
prevent isolated incidents from escalating, and assist
other UN personnel in the region
281
Israel (continued)
Refugees and internally displaced persons:
IDPs: 276,000 (Arab villagers displaced from homes
in northern Israel) (2005)
Illicit drugs: increasingly concerned about cocaine
and heroin abuse; drugs arrive in country from
Lebanon and, increasingly, from Jordan;
money-laundering center
(British crown dependency)
Jarvis Island
(territory of the US)
Description under
Disputes - international: Kuwait and Saudi Arabia
continue negotiating a joint maritime boundary with
Iran; no maritime boundary exists with Iraq in the
Persian Gulf
311
Land boundaries:
total: 1,334 km
border countries: Austria 330 km, Croatia 670 km,
Italy 232 km, Hungary 102 km
Coastline: 46.6 km
Maritime claims: NA
Climate: Mediterranean climate on the coast,
continental climate with mild to hot summers and cold
winters in the plateaus and valleys to the east
Terrain: a short coastal strip on the Adriatic, an alpine
mountain region adjacent to Italy and Austria, mixed
mountains and valleys with numerous rivers to the east
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Triglav 2,864 m
Natural resources: lignite coal, lead, zinc, mercury,
uranium, silver, hydropower, forests
Land use:
arable land: 8.53%
permanent crops: 1 .43%
other. 90.04% (2005)
Irrigated land: 20 sq km (1998 est.)
Natural hazards: flooding and earthquakes
Environment - current issues: Sava River polluted
with domestic and industrial waste; pollution of coastal
waters with heavy metals and toxic chemicals; forest
damage near Koper from air pollution (originating at
metallurgical and chemical plants) and resulting acid
rain
Environment - international agreements:
party to: Air Pollution, Air Pollution-Sulfur 94,
Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants
Geography - note: despite its small size, this
eastern Alpine country controls some of Europe''s
major transit routes
Disputes - international: the Croatia-Slovenia land
and maritime boundary agreement, which would have
ceded most of Piran Bay and maritime access to
Slovenia and several villages to Croatia, remains
unratified and in dispute; as a member state that forms
part of the EU''s external border, Slovenia must
implement the strict Schengen border rules to curb illegal
migration and commerce through southeastern Europe
while encouraging close cross-border ties with Croatia
Illicit drugs: minor transit point for cocaine and
Southwest Asian heroin bound for Western Europe,
and for precursor chemicals
505
Disputes - international: none
530
JE
—
—
—
•ie
ISO includes with the UK
Johnston Atoll
JQ
—
—
—
—
ISO includes with the US Minor
Outlying Islands
4912N
Saint John (city)
Canada (New Brunswick)
4516N
Saint John''s (capital)','da96d27625a52a5c70bd8986f1c748f6a1911a731576897e9fafa524d09b9f20','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6092924966b949794bda26afbdef72860bf0caa54982d6858f9629322f456414',2007,'FI','Finland','transnational-issues',572,'Disputes - international: various groups in Finland
advocate restoration of Karelia and other areas ceded
to the Soviet Union, but the Finnish Government
asserts no territorial demands
196
6015N
20 00E
Alaska (state)
6010N
24 58E
Herzegovina (political region)
64 00N
26 00E
Surigao Strait
Pacific Ocean
10 15 N
125 23 E
Surinam (former name for Suriname)','ad7e1a218f6811b265125bbac704661a26b99d995c49344603f08c0391ec46c2','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08da6bb2e36a6630b3700cfb121563a7f1652359d67bd54900f05e638967559f',2007,'WF','Wallis and Futuna','transnational-issues',578,'Disputes - international: Madagascar claims the
French territories of Bassas da India, Europa Island,
Glorioso Islands, and Juan de Nova Island; Comoros
claims Mayotte; Mauritius claims Tromelin Island;
territorial dispute between Suriname and the French
overseas department of French Guiana; France
asserts a territorial claim in Antarctica (Adelie Land);
France and Vanuatu claim Matthew and Hunter
Islands, east of New Caledonia
Illicit drugs: transshipment point for and consumer
of South American cocaine, Southwest Asian heroin,
and European synthetics
199
ISO includes Clipperton Island
FIPS 10-4 does not include the
French-claimed portion of Antarctica
(Terre Adelie)
WF
WF
WLF
876
.wf
West Bank
WE
PS
PSE
275
■ps
ISO identifies as Occupied Palestinian
Territory
14 19 S
178 05 W
Fyn (island)
1419S
178 05 W
Hrvatska (local name for Croatia)
13 57S
171 56 W
Matsu (island)
Taiwan
2613N
11 9 56 E
Matthew Island
New Caledonia, Vanuatu
22 20S
171 20 E
Mauritanie (local name for Mauritania)
Walvis Bay (city; former exclave)','8fddd4820c3b410efacf4bae2d1cc16fd18de9429d0ebf5691f925cc9e852c51','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45c6de266a26cac61ae37cfa70fd4a2c0c007cd3c6272e698cdcfccfabc60e39',2007,'GF','French Guiana','transnational-issues',579,'(overseas department
of France)
Background: First settled by the French in 1604,
French Guiana was the site of notorious penal
settlements until 1951 . The European Space Agency
launches its communication satellites from Kourou.
4 56N
52 20W
Celebes (island)
517N
52 35W
Devon Island
4 00N
4 00N
53 00W
Inland Sea
5 20N
Sahara Occidental (former name for Western Sahara) Western Sahara
24 30N
Sahel (region)
Burkina Faso, Chad, The Gambia, Guinea-Bissau,
Mali, Mauritania, Niger, Senegal
15 00N
Saigon (city; former name for Ho Chi Minh City)
Vietnam
10 45N
Saint Barthelemy (island; also Saint Bart''s)','a9a9c3e55172ec14a30128cf8e2b96e1bf16412406bc54be4bdc64e4e5a33578','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('667528f0dd67aa73cd2e0e8b75433bd99032fa6bfd39ec33486967e53a68fac3',2007,'PF','French Polynesia','transnational-issues',583,'(overseas lands
of France)
Jjjtz
KIRIBATI .„£SL™>
u.i,«««fct«- MARQUISES
Hakapehi
SOUTH PACIFIC OCEAN
Makatea
% ARCHIPEL
DES TUAMOTU
^o u,uroa'' -£APEETE
CV Ta/7/(; MonlOmnonii
**>
Mururoa ''■ „., .
^-. Mataura Rikitea.
.flapa
0 200 400 km
0 200 400 mi
French Southern and Antarctic
Lands
EC
EG
ES
EK
ER
EN
ET
EU
FK
FO
FJ
Fl
FR
FG
FP
FS
TL
TLS
626
EC
ECU
218
.ec
EG
EGY
818
•eg
SV
SLV
222
.sv
GO
GNQ
226
•gq
ER
ERI
232
er
EE
EST
233
.ee
ET
ETH
231
.et
FK
FLK
238
.fk
FO
FRO
234
.fo
FJ
FJI
242
Fl
FIN
246
FR
FRA
250
FX
FXX
249
.fr
lx~
GF
GUF
254
•gf
PF
PYF
258
■P*
TF
ATF
260
Comment
administered with French Southern and
Antarctic Lands; no ISO codes
assigned
ISO limits to the European part of
France, excluding French Guiana,
French Polynesia, French Southern
and Antarctic Lands, Guadeloupe,
Martinique, Mayotte, New Caledonia,
Reunion, Saint Pierre and Miquelon,
23 20S
151 00 W
Avarua (capital)
16 30S
151 45 W
Bordeaux (city)
23 09S
134 58 W
Gaspar Strait
Pacific Ocean
3 00S
107 00 E
Gdansk (city; formerly Danzig)
9 00S
139 30 W
Martin Vaz, llhas (island group)
15 00S
140 00 W
Pomerania (region)
Germany, Poland
53 40N
15 35E
Ponape (Pohnpei) (island)
Federated States of Micronesia
6 55N
158 15 E
Port Louis (capital)
17 00S
Taipei (capital)
Taiwan
Taiwan Strait
Pacific Ocean
Tallinn (capital)
19 00S
142 00 W
Tubuai Islands (lies Tubuai)
23 00S
150 00 W
Tunb al Kubra (island)
Iran
2614N
55 19E
Tunb as Sughra (island)
Iran
2614N
55 09E
Tunis (capital)','af17e2e149f4de62f8cca4d4c8c810fd3d564e4b02fae4382f1ae92b8254f4af','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c1b049578fc4a7b29917d694aae17c889e788a4be370f7c3fd2cd5ab2d0b01b',2007,'IL','Israel','transnational-issues',595,'1
\\
I
/
Rafah f*
/
isrMfc-oocupied won current status
(also see separate Gaza Strip
and West Bank entries)
10 .''<) Kill
Nahariyyat
Mediterranean ,
Sea
Hadera
Netanya,
TelAV1v-Yafo. .Pemh Tiqwa
BatYam«^olon< West
Rishon LeZiyyon*
Ashdod. » _
Jerusalem^
Mount
Scopus
J_^» Jerusa
Jerusalem
Bethlehem
Hebron
\\>">Y
1949 Armist''SS--^
(Green
Lir*''1
Disputes - international: West Bank and Gaza Strip
are Israeli-occupied with current status subject to the
Israeli-Palestinian Interim Agreement - permanent
status to be determined through further negotiation;
Israel continues construction of a "seam line"
separation barrier along parts of the Green Line and
within the West Bank; Israel withdrew from four
settlements in the northern West Bank in
August 2005; since 1948, about 350 peacekeepers
from the UN Truce Supervision Organization
(UNTSO), headquarterea ,? Jerusalem, monitor
ceasefires, supervise armistice agreements, prevent
isolated incidents from escalating, and assist other UN
personnel in the region
Refugees and internally displaced persons:
refugees (country of origin): 690,988 (Palestinian
Refugees (UNRWA)) (2005)
IS
IL
ISR
376
il
32 54N
35 20E
Galleons Passage
Atlantic Ocean
1100N
60 55W
Gambier Islands (lies Gambier)
32 50N
Hainan Dao (island)
30 30N
34 55E
Negros (island)
Teluk Bone (gulf)
Pacific Ocean
Teluk Tomini (gulf)
Pacific Ocean
Terre Adelie (claimed by France; also Adelie Land)
32 48N
35 35E
Tibet (autonomous region; also Xizang)
Youth, Isle of (Isla de la Juventud)','1ca87f2c7926afc196bf53f9e5fca7deadd9b05e8fddd3adc0d6965776269785','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd13c9261b2293f2ed513afb260de3aea64f44b445f39b28a212e81621f09332',2007,'EG','Egypt','transnational-issues',596,'. / ^'' Gaza
subject to tne tsraehPatesbraart imeom
\\ | --**- International Airpcn
Agreement - permanent status to be
Abu''Awoah
V / (inoperable)
deiemwed ttvough turtner negotiation
(Joz Abu ''Awtfa/iA
Disputes - international: West Bank and Gaza Strip
are Israeli-occupied with current status subject to the
Israeli-Palestinian Interim Agreement - permanent
status to be determined through further negotiation;
Israel removed settlers and military personnel from
the Gaza Strip in August 2005
Refugees and internally displaced persons:
refugees (country of origin): 969,588 (Palestinian
Refugees (UNRWA)) (2005)
*l»f jo''ioccup''cd *rtth
current • tatut juDjecl
to the t*TMlM>i!«ittnUn
interim Agreement -
permanent status to be
determined through
further negotiation
FIPS10-4
ISO 3166
Internet
DR
DO
DOM
214
.do
TT
31 12 N
29 54E
Algiers (capital)
California, Gulf of
Pacific Ocean
Cameroun (local name for Cameroon)
3013N
33 09E
Gilbert Islands
30 20N
32 23E
Great Britain (island)
27 00N
30 00E
Mitla Pass
30 02N
32 54E
Mocambique (local name for Mozambique)
29 30N
29 55N
Suez, Gulf of
Indian Ocean
28 10N
Suisse (local French name for Switzerland)','e9895f698ea079075ea37fe30d90584e2d7192b4e122b00b27ea11fa507b187a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24ba1cca24a63bef56fe28bc89d8e580e660aee3fb45c6e206ddc0f9b358b043',2007,'GE','Georgia','transnational-issues',604,'+
+
+
+
f "\\_^-v
0 20 40 km
I
0 20 40 mi
ABKHAZIA ^ — «s_> v G/V„
Sokhumf sSSiS-^
R U S S 1
} s<* * — \\/X-
A
C^ ,-3® » "\\
Black Sea
#Zugdidi
\\ (+* Kuraist
Pol''i, ''''So**
#Supsa
^ 4/„ \\
SOUTH °A/r
OSSETIA "''A/s
Ts''khinvali Pankc
Gorge
''*, TBILISI
Batumi^ A J ARIA Akhatts''ikhe.
*
c Rustavi
» AZER.
#Akhalk''alak''i % S~^\\.
,-
TURKEY \\^
V, ^~-^™^r^ 7? AZERBAIJAN
C u ARMENIA <* Va.
L ^-Wl
^y~^
Disputes - international: Russia and Georgia agree
on delimiting 80% of their common border, leaving
certain small, strategic segments and the maritime
boundary unresolved; OSCE observers monitor
volatile areas such as the Pankisi Gorge in the
Akhmeti region and the Argun Gorge in Abkhazia; UN
Observer Mission in Georgia has maintained a
peacekeeping force in Georgia since 1 993; Meshkheti
Turks scattered throughout the former Soviet Union
seek to return to Georgia; boundary with Armenia
remains undemarcated; ethnic Armenian groups in
Javakheti region of Georgia seek greater autonomy
from the Georgian government; Azerbaijan and
Georgia continue to discuss the alignment of their
boundary at certain crossing areas
Refugees and internally displaced persons:
IDPs: 260,000 (displaced from Abkhazia and South
Ossetia) (2005)
Illicit drugs: limited cultivation of cannabis and
opium poppy, mostly for domestic consumption; used
as transshipment pcint for opiates via Central Asia to
Western Europe and Russia
GG
GE
GEO
268
•ge
43 00N
4100E
Abu Dhabi (capital)
4145N
42 10E
Akmola (city; former name for Astana)
42 30N
4152E
Minicoy Island
42 00N
43 30E
Sakhalin Island (Ostrov Sakhalin)
Russia
5100N
143 00 E
Sakishima Islands
42 20N
44 00E
South Pacific Ocean
Pacific Ocean
30 00S
130 00 W
South Sandwich Islands
Tchad (local name for Chad)
4143N
44 49E
Tien Shan (mountains)
China, Kyrgyzstan
42 00N
80 00E
Terra del Fuego (island, island group)
Argentina, Chile
54 00S
69 00W
Timor (island)
East Timor, Indonesia-
9 00S
125 00 E
Timor Sea
Pacific Ocean
1100S
128 00 E
Timor-Leste, Timor Lorosa''e (local names for East Timor)
East Timor
9 00N
126 00 E
Tinian (island)','3442ab0f4bdf9ff2d031467e622388f22d3f6827ac6e881b4b247935e195f294','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f830e96a8744a2acc14f750070f80ea3f5d9b2340eb49d6f8107e8397740122',2007,'GH','Ghana','transnational-issues',621,'Disputes - international: Ghana struggles to
accommodate returning nationals who worked in the
cocoa plantations and escaped fighting in Cote
d''lvoire
Refugees and internally displaced persons:
refugees (country of origin): 40,853 (Liberia) (2005)
Illicit drugs: illicit producer of cannabis for the
international drug trade; major transit hub for
Southwest and Southeast Asian heroin and, to a
lesser extent, South American cocaine destined for
Europe and the US; widespread crime and money
laundering problem, but the lack of a well-developed
financial infrastructure limits the country''s utility as a
money-laundering center
220
GH
GH
GHA
288
•gh
5 33N
013W
Adamstown (capital)
Pitcairn Islands
25 04S
130 05 W
Addis Ababa (capital)
8 00N
2 00W
Golfo San Jorge (gulf)
Atlantic Ocean
46 00S
66 00W
Golfo San Mafias (gulf)
Atlantic Ocean
4130S
64 00W
Good Hope, Cape of','5ac24755cd59285d45a425a409d0f35a7be89cbd0aa750b840409291337bc11a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('591fdd9b4337fc78e6bdeb32547e1808cb10099ecb4beeb9b6b929065f70c36a',2007,'GI','Gibraltar','transnational-issues',622,'(overseas territory
of the UK)
ijj
airfield
lighthouse
Bay ol <
Spain")
NEUTRAL
ZONE
Alboran
Rockot
fortress^
headquarters
Strait ol Gib
lighthouse
Disputes - international: in 2002, Gibraltar
residents voted overwhelmingly by referendum to
reject any "shared sovereignty" arrangement; the
government of Gibraltar insists on equal participation
in talks between the UK and Spain; Spain disapproves
of UK plans to grant Gibraltar even greater autonomy
222
Glorioso Islands
(possession of France)
II
o i B Ikm
0 1.5 3 mi
Wreck
Rock
lie du Lys
reel j
weather / /*\\,
■ station -^^jV
lie \\ Verte
/-
j airstrip Grande Flocks
GlooBuse
South
Rock
Indian Ocean
Disputes - international: claims and administers
Western Sahara whose sovereignty remains
unresolved - UN-administered cease-fire has
remained in effect since September 1991, but
attempts to hold a referendum have failed and parties
thus far have rejected all brokered proposals;
Morocco protests Spain''s control over the coastal
enclaves of Ceuta, Melilla. and Penon de Velez de la
Gomera, the islands of Penon de Alhucemas and Islas
Chafarinas, and surrounding waters; discussions
have not progressed on a comprehensive maritime
delimitation setting limits on exploration and refugee
interdiction since Morocco''s 2002 rejection of Spain''s
unilateral designation of a median line from the
Canary Islands; Morocco serves as one of the primary
launching areas of illegal migration into Spain from
North Africa
Illicit drugs: illicit producer of hashish; shipments of
hashish mostly directed to Western Europe; transit
point for cocaine from South America destined for
Western Europe
Mozambique ''--^^™
~^~V TANZANIA
ZAMBIA ( ^ — <
^S ■
S \\ Pemba.
1 JLichmga *
•^MALAWI ^v
Cidade
de Nacala*.
Nampula
^VN-v_rete* \\ r
Quelimane
C .Chimoio
ZIMBABWE!
f Monte Beira
J Btnga
">*» /Vila Eduardo
\\ Mondlane
0*
i
f
\\ Inhambane.
/-NJ ^MAPUTO
(sWAZJ
SOUTH
AFRICA
INDIAN
OCEAN
0 100
200 km
0 100 200m.
Disputes - international: none
Illicit drugs: Southern African transit point for South
Asian hashish and heroin, and South American
cocaine probably destined for the European and
South African markets; producer of cannabis (for local
consumption) and methaqualone (for export to South
Africa); corruption and poor regulatory capability
makes the banking system vulnerable to money
laundering, but the lack of a well-developed financial
infrastructure limits the country''s utility as a
money-laundering center
Transportati
Airports: 158(2005)
Airports - with paved runways:
total: 22
over 3,047 m: 1
2.438 to 3,047 m: 3
1,524 to 2,437 m:10
914 to 1,523 m: 3
under 914 m: 5 (2005)
o n
386
Gl
Gl
GIB
292
■gi
Glorioso Islands
GO
—
—
—
—
administered with French Southern and
Antarctic Lands; no ISO codes assigned
3611 N
5 22W
Gibraltar, Strait of
Atlantic Ocean
35 57N
5 36W
Gidi Pass','43ad76293ea48aff2ca9d885bb107d8f50ad4d234134103966d88d5cabdbac15','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('557e8896b425bd6de733d05d00178cf7bbb563aaebbef853c1e8ba4b66abab19',2007,'GR','Greece','transnational-issues',631,'• Chios
Ionian* PaVa. ^.stsjVTHENS
Sea
8Urs "-«*
Peiraiels .
lavnon
Simos
Kos
Mediterranei
Sea
Irakleion
Crete
0 50 100 km
Disputes - international: Greece and Turkey
continue discussions to resolve their complex
maritime, air, territorial, and boundary disputes in the
Aegean Sea; Cyprus question with Turkey; Greece
rejects the use of the name Macedonia or Republic of
Macedonia
Illicit drugs: a gateway to Europe for traffickers
smuggling cannabis and heroin from the Middle East
and Southwest Asia to the West and precursor
chemicals to the East; some South American cocaine
transits or is consumed in Greece; money laundering
related to drug trafficking and organized crime
GR
GR
GRC
300
■gr
38 00N
25 00E
Aegean Sea
Atlantic Ocean
38 30N
25 00E
Afars and Issas, French Territory of the (or FTAI;
former name for Djibouti)
37 45N
24 42E
Andros Island
The Bahamas
24 26N
77 57W
Anegada Passage
Atlantic Ocean
18 30N
63 40W
Angkor Wat (ruins)
37 59N
23 44E
Attu Island
39 40N
19 45E
Corinth (region)
37 56N
22 56E
Corisco (island)
3515N
24 45E
Crimea (region)
Cyrenaica (region)
36 00N
27 05E
Dodoma (city)
Tanzania
611 S
35 45E
Doha (capital)
39 00N
22 00E
Ellas (local name for Greece)
39 00N
22 00E
Ellef Ringnes Island
38 30N
20 30E
Ionian Sea
Atlantic Ocean
38 30N
18 00E
Irian Jaya (province)
38 22N
26 04E
Khmer Republic (former name for Cambodia)
Russia
37 05N
25 30E
N''Djamena (capital)
37 30N
22 25E
Pemba Island
Tanzania
5 20S
39 45E
Penang Island
Rhodesia (region)
37 48N
26 44E
San Ambrosio, Isla (island)','e3f4e632f699e34d21e807f2140b839967704080dc2686562535512c8c343314','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebf1d3cc29a836cd3b348f20a26922771eb998533ca15a9342530be53feaa2e6',2007,'GL','Greenland','transnational-issues',640,'(pad of the Kingdom of Denmark)
CANADA ^
Arctic Ocean
Nord Sea
Kangerlussuaq
S1s,miutW^(S0ndreS,r0m,,0rd)
Davis *y~ £"''*Tasiilaq
Strait ''jGooTHkB) 5 (Ammassa|lk>
Kangerluarsorwseq
f
s
Sea
Norwegian
Sea
GL
GL
GRL
304
■gi
6411 N
51 44 W
Golan Heights (region)
Syria
33 00N
35 45E
Gold Coast (former name for Ghana)
Kalahari (desert)
Botswana, Namibia
Kalimantan (region)
Nyasaland (former name for Malawi)','252e34288d354a5177f3a43ec642897477f8a1e5bbd6e6a7536fdd1b51db7253','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b71bf95dab51516b5fb337c6c1d0506e9df92d58a6087f305dc177dc1cc4db4',2007,'MQ','Martinique','transnational-issues',648,'Disputes • international: none
Illicit drugs: small-scale cannabis cultivation; lesser
transshipment point for marijuana and cocaine to US
(overseas department
of France)
Passage
Momagne
Pelee
Le Lorrain
''■
NORTH
ATLANTIC
OCEAN
Sainte-Mariej,
LaTrinite,
Le Robert
Schcelcher
FORT-DE-V„ '' LeLamentirr ;;
FRANCE -^LaZT Le Francois
•_
. Ducos
Riviere-Salee
Riviere-Pilote. ,
J.e Marm
Caribbean
Sea
MB
MQ
MTQ
474
.mq
14 36N
6105W
Franz Josef Land (island group)
Russia
8100N
55 00E
Freetown (capital)','85e2b2f396edc950e0ef0e1718201ddad1d576e21a2854afdd900a0bee43a30d','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef1a90e847ef5e7b680a053cd777cd3921d5a1c06d4f1ae2119dc8cd4a1d204b',2007,'GP','Guadeloupe','transnational-issues',649,'(overseas department
of France)
w •!• •!•
Si. -Martin and Si -Bamrttomy
art not shown
NORTH
ATLANTIC
OCEAN
Pointe-
a-Pitre
Petit-
Bourg.
Le Moule La Desirade
Grande-Terre
*Les Abymes
, ''Sainte-Anne
Le Gosier
Grande-
Anse
Basse-
Terre
Soulnere
A
BASSE-
TERRE
LES
SMNTES
Capeslerre-
• Belle-Eau
iLES DE LA
PETTTE TERHE
Marie-
Galante
Grand-
Bourg
GP
GP
GLP
312
■gp
16 00N
61 44 W
Bastia (city)
France (Corsica)
42 42N
9 27E
Basutoland (former name for Lesotho)
17 55N
Saint Brandon (Cargados Carajos Shoals)
18 04N
63 04W
Saint-Pierre (capital)','e02b13db0718ebbe7ce1d155a0b2a2a2bf2d7b3eb7b81fef37cfbf71a0efafa3','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa2d43c8070a047792ab4a228268c3aaefc3ff72754fed60b6997a42300b4ee5',2007,'GU','Guam','transnational-issues',654,'(territory of the US)
Cabras
Apra island -- + «™
Harbor^g=^^ HAGATN
.
^gat
reef
\\ )
I .Merizo
North
Pacific
Ocean
Cocos „
Island
Disputes - international: none
GWP
Hazardous Wastes
HF
^
gross register ton
global system for mobile cellular communications
acronym for member states - Georgia, Ukraine, Azerbaijan, Moldova
gross world product
Basel Convention on the Control of Transboundary Movements of Hazardous
Wastes and Their Disposal
high-frequency
HIV/AIDS
human immunodeficiency virus/acquired immune deficiency syndrome
IADB
Inter-American Development Bank
IAEA
International Atomic Energy Agency
IANA
Internet Assigned Numbers Authority
IBRD
International Bank for Reconstruction and Development (World Bank)
ICAO
International Civil Aviation Organization
ICC
International Chamber of Commerce
ICCt
International Criminal Court
ICFTU
International Confederation of Free Trade Unions
ICJ
International Court of Justice (World Court)
ICRC
International Committee of the Red Cross
ICRM
International Red Cross and Red Crescent Movement
ICSID
International Center for Secretariat of Investment Disputes
ICTR
International Criminal Tribunal for Rwanda
ICTY
International Criminal Tribunal for the former Yugoslavia
IDA
International Development Association
IDB
Islamic Development Bank
IDP
Internally Displaced Person
IEA
International Energy Agency
IFAD
International Fund for Agricultural Development
IFC
International Finance Corporation
IFRCS
International Federation of Red Cross and Red Crescent Societies
IGAD
Inter-Governmental Authority on Development
IHO
International Hydrographic Organization
ILO
International Labor Organization
IMF
International Monetary Fund
IMO
International Maritime Organization
Inmarsat
International Maritime Satellite Organization
InOC
Indian Ocean Commission
INSTRAW
International Research and Training Institute for the Advancement of Women
Intelsat
International Telecommunications Satellite Organization
Interpol
International Criminal Police Organization
Intersputnik
International Organization of Space Communications
IOC
International Olympic Committee
IOM
International Organization for Migration
ISO
International Organization for Standardization
629
Appendix A: Abbreviations (continued)
ISP
Internet Service Provider
ITU
International Telecommunication Union
kHz
kilohertz
km
kilometer
kW
kilowatt
kWh
kilowatt-hour
LAES
Latin American Economic System
LAIA
Latin American Integration Association
LAS
League of Arab States
Law of the Sea
United Nations Convention on the Law of the Sea (LOS)
LDC
less developed country
LLDC
least developed country
London Convention
see Marine Dumping
LOS
see Law of the Sea
M
m
meter
Marecs
Maritime European Communications Satellite
Marine Dumping Convention on the Prevention of Marine Pollution by Dumping Wastes and Other
Matter
Marine Life Conservation Convention on Fishing and Conservation of Living Resources of the High Seas
MARPOL
see Ship Pollution
Medarabtel
Middle East Telecommunications Project of the International
Telecommunications Union
Mercosur
Southern Cone Common Market
MHz
megahertz
MICAH
International Civilian Support Mission in Haiti
MIGA
Multilateral Investment Geographic Agency
MINURSO
United Nations Mission for the Referendum in Western Sahara
MINUSTAH
United Nations Stabilization Mission in Haiti
MONUC
United Nations Organization Mission in the Democratic Republic of the Congo
NA
not avaiiable
NAFTA
North American Free Trade Agreement
NAM
Nonaligned Movement
NATO
North Atlantic Treaty Organization
NC
Nordic Council
NEA
Nuclear Energy Agency
NEGL
negligible
NGA
National Geospatial-lntelligence Agency
NIB
Nordic Investment Bank
NIC
newly industrializing country
NIE
newly industrializing economy
NIS
new independent states
nm
nautical mile
NMT
Nordic Mobile Telephone
NSG
Nuclear Suppliers Group
630
0
Appendix A: Abbreviations (continued)
/
Nuclear Test Ban
Treaty Banning Nuclear Weapons Tests in the Atmosphere, in Outer Space, and
Under Water
NZ
note— acronym standing for the member
countries, Georgia, Ukraine, Azerbaijan,
Moldova; formerly known as GUUAM before
Uzbekistan withdrew in 5 May 2005
established— 7 June 2001
aim— commits the countries to cooperation and
assistance in social and economic development,
the strengthening and broadening of trade and
economic relations, and the development and
effective use of transport and communications,
highways, and related infrastructure crossing the
boundaries of the member states
members— (4) Azerbaijan, Georgia, Moldova, Ukraine
high income countries
another term for the industrialized countries with high per capita GDPs; see developed countries (DCs)
industrial countries
another term for the developed countries; see developed countries (DCs)
Inter-American Development Bank (IADB)
note— also known as Banco Interamericano de
Desarrollo (BID)
established— 8 April 1959
effective— 30 December 1959
aim— to promote economic and social
development in Latin America
members— (46) Argentina, Austria, The Bahamas, Barbados, Belgium, Belize, Bolivia, Brazil, Canada, Chile,
Colombia, Costa Rica, Croatia, Denmark, Dominican Republic, Ecuador, El Salvador, Finland, France, Germany,
Guatemala, Guyana, Haiti, Honduras, Israel, Italy, Jamaica, Japan, Mexico, Netherlands, Nicaragua, Norway,
Panama, Paraguay, Peru, Portugal, Slovenia, Spain, Suriname, Sweden, Switzerland, Trinidad and Tobago, UK, US,
Uruguay, Venezuela
International Atomic Energy Agency (IAEA)
established- -26 October 1956
effective— 29 July 1957
aim— to promote peaceful uses of atomic energy
International Bank for Reconstruction and
Development (IBRD)
note— also known as the World Bank
established— 22 July 1944
effective— 27 December 1945
aim— to provide economic development loans; a
UN specialized agency
members— (140) Afghanistan, Albania, Algeria, Angola, Argentina, Armenia, Australia, Austria, Azerbaijan,
Bangladesh, Belarus, Belgium, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso,
Burma, Cameroon, Canada, Central African Republic, Chad, Chile, China, Colombia, Democratic Republic of the
Congo, Costa Rica, Cote d''lvoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador,
Egypt, El Salvador, Eritrea, Estonia, Ethiopia, Finland, France, Gabon, Georgia, Germany, Ghana, Greece,
Guatemala, Haiti, Holy See, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kazakhstan, Kenya, South Korea, Kuwait, Kyrgyzstan, Latvia, Lebanon, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malaysia, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia, Morocco, Namibia, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Norway, Pakistan, Panama, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Saudi
Arabia, Senegal, Serbia and Montenegro, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, South Africa,
Spain, Sri Lanka, Sudan, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tunisia, Turkey, Uganda,
Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
members— (184) includes all UN member countries except Andorra, Cuba, North Korea, Liechtenstein, Monaco,
Nauru, and Tuvalu
International Chamber of Commerce (ICC)
established— 1919
aim— to promote free trade and private
enterprise and to represent business interests at
national and international levels
members— (91 national committees) Algeria, Argentina, Australia, Austria, Bahrain, Bangladesh, Belgium, Brazil,
Burkina Faso, Cameroon, Canada, Caribbean, Chile, China, Colombia, Costa Rica, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Finland, France, Georgia, Germany, Ghana,
Greece, Guatemala, Hong Kong, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Japan, Jordan, South
Korea, Kuwait, Lebanon, Lithuania, Luxembourg, Madagascar, Malaysia, Mexico, Monaco, Morocco, Nepal,
Netherlands, NZ, Nigeria, Norway, Pakistan, Panama, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Saudi Arabia, Senegal, Serbia and Montenegro, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka,
Sweden, Switzerland, Syria, Taiwan, Tanzania, Thailand, Togo, Tunisia, Turkey, Ukraine, UAE, UK, US, Uruguay,
Venezuela
642
Appendix B: International Organizations and Groups (continued)
International Civil Aviation Organization
(ICAO)
established— 7 December 1944
effective— 4 April 1947
aim— to promote international cooperation in
civil aviation; a UN specialized agency
members— (189) includes all UN member countries except Dominica, Liechtenstein, and Tuvalu (188 total); plus
GQ
GU
GUM
316
•gu
13 28N
144 45 E
Ajaccio (city)
France (Corsica)
41 55 N
8 44E
Ajaria (region)
13 28N
Hague, The (seat of government)','4772caff435af77d0e0da453205e55747685171d5b177def4478e03ad5339213','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('526c2db88895603700c5f8151d0f1a6948e3c65f10fb15eab994c7edeb3e9154',2007,'GG','Guernsey','transnational-issues',662,'(British crown dependency)
KH
Environment - current issues: NA
Geography - note: large, deepwater harbor at Saint
Peter Port
O 2.5 5 Km
0 2.5 5 ml
English
Channel
Burhou
st. /yiney-"
Aldemey
Lihou
Island
sey ,y^.
iMJ r St. Sampson
r / $Herm
ST. PETER
DODT
Jethou
Brechou o
Ultle Sark
P
Sark
Disputes - international: none
GK
—
—
—
■gg
ISO includes with the UK
671
Appendix D: Cross-Reference List of Country Data Codes (continued)
Entity
FIPS10-4
ISO 3166
Internet
Comment
49 43N
212W
Aleutian Islands
United States (Alaska)
52 00N
176 00 W
Alexander Archipelago (island group)
United States (Alaska)
57 00N
134 00 W
Alexander Island
49 27N
2 32W
Saint Petersburg (city; former capital)
Russia
59 55N
3015E
Saint Thomas (island)
Virgin Islands
1821 N
64 55W
Saint Vincent Passage
Atlantic Ocean
13 30N
6100W
Saint-Denis (capital)
Reunion
20 52S
55 28E
Saint-Martin (island; also Sint Maarten)
49 26N
2 21 W
Savage Island (former name for Niue)','e859efee6d0dc296571e6f0b168ecade4d41c1a94d6ad4baa2f3ae994e98dce1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9386d611020ebca636be9cfe309bf30ca67e888b0487ba0164605127643959e3',2007,'GW','Guinea-Bissau','transnational-issues',670,'''C.ichou Batata *
.Canchungo .Mansoa
BISSAU
Bolama. J
Gabu
NORTH ATLANTIC OCEAN
40 80km
PU
GW
GNB
624
gw
11 25 N
16 20W
Bikini Atoll
11 51 N
15 35W
Bjornoya (Bear Island)
Svalbard
74 26N
19 05E
Black Forest (region)
12 00N
15 00W
Guinee (local name for Guinea
12 00N
15 00W
Portuguese Timor (former name
for East Timor)
East Timor
9 00S
126 00 E
168 19 E
16 55E
699
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Prague (capital)
Czech Republic
Praia (capital)
Cape Verde
Prathet Thai (local name for Thailand)','abf4e72d9ac6bf586e7efa23ea4c822e26e600614cd6b7ffef4b6c79856a2df3','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('320c4b2040744c2c6043b9490457f9f2850f6be9e474e73a5f2d336b81c2ce45',2007,'GY','Guyana','transnational-issues',682,'Disputes - international: all of the area west of the
Essequibo (river) is claimed by Venezuela preventing
any discussion of a maritime boundary; Guyana has
expressed its intention to join Barbados in asserting
claims before UNCLOS that Trinidad and Tobago''s
maritime boundary with Venezuela extends into their
waters; Suriname claims a triangle of land between
the New and Kutari/Koetari rivers in a historic dispute
over the headwaters of the Courantyne; Guyana
seeks arbitration under provisions of the UN
Convention on the Law of the Sea (UNCLOS) to
resolve the long-standing dispute with Suriname over
the axis of the territorial sea boundary in potentially
oil-rich waters
Illicit drugs: transshipment point for narcotics from
South America - primarily Venezuela - to Europe and
the US; producer of cannabis; rising money
laundering related to drug trafficking and human
smuggling
245
Disputes - international: area claimed by French
Guiana between Riviere Litani and Riviere Marouini
(both headwaters of the Lawa); Suriname claims a
triangle of land between the New and Kutari/Koetari
rivers in a historic dispute over the headwaters of the
Courantyne; Guyana seeks United Nations
Convention on the Law of the Sea (UNCLOS)
arbitration to resolve the long-standing dispute with
Suriname over the axis of the territorial sea boundary
in potentially oil-rich waters
Illicit drugs: growing transshipment point for South
American drugs destined for Europe via the
Netherlands and Brazil; transshipment point for
arms-for-drugs dealing
Svalbard
(territory of Norway)
Arctic ,''>. Ocean Kviteya
Nordaustlandet
Ny-Alesund, Spllsbe en
Pans--,, .pyramiden Kong Karts
Karts , -1 V '' Land
Forland Barenlsoya
Barentsburg* * LONGYEARBYEN
— '' Edgeoya
Gre,
Sea
Hopen
50 100 km
Bjornoya
Disputes - international: despite recent
discussions, Russia and Norway dispute their
maritime limits in the Barents Sea and Russia''s fishing
rights beyond Svalbard''s territorial limits within the
Svalbard Treaty zone
528
Swaziland
/ Piggs
/ . Peak
. s
SOUTH /
AFRICA/
Mhlume"
7 O
\\ Is*
I >
/ 3
/ ^MBABANE
1 ^
/ Siteki .
'' Lobamba" .Manzini
c
m
.Mankayane
Big
Bend.
r^
) .Hlatikulu
r
N. , Nhlangano
SOUTH
AFRICA
0 20 40 km ^*""^^^
Lavumisa,
\\
0 20 40 mi
GY
GY
GUY
328
gy
British Honduras (former name for Belize)
6 59N
58 23W
Etorofu (island; also Iturup)
Russia (de facto)
Farquhar Group (island group; also Atoll de Farquhar)
6 48N
58 10W
Georgetown (city)
The Gambia
13 30N
14 47W
German Democratic Republic (East Germany;
former name for eastern portion of Germany)','fc338b0735ef5d8875c5b72fbd1603313bcd7da1de2ee69716801256410e6514','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('090c94c6bd495a1f255f0a249ce315e7fdbca3ab25add220e021e07f65be3b35',2007,'IT','Italy','transnational-issues',683,'(Rome) ^-
( Vatican — ►. "*
city / Museums "■
wall / ,-
f '' Saint Peter''s ^>■ M
/ Basilica _ 3
^j — ^]Jr
O 0.15 0.3 km
a * ■
Saint Pejer"s\\
Square 1
(Rome)
0 0.15 0.3 mi
Disputes- international: none
II
ALB
^w7n^5T Milan Verona Trie!
FR. ?T^J~Jg^Jy*^
Sayona Genoa .Bol6gna $V
«onaco2> «u sPezia.«^o ^
-\\^-* Livorno* Florence^ " *
ConucaJi -\\ Adna,£
™ I romKJ
Porto V VAT1CAW <*
T«r£A - Nap.es Bfj^
■~W» Salerrt° W
.Cagliari soa \\ 1 ,
f 3 I (oman Sea
Porto . J ^
Foxi PaJerrno. Messiha^Reggio di
Mediterranean Sea "C Sta/y .Catama
x — ^» .Augusta
\\/> 0 Gela*
ALU. / MALTA
Domagnano \\
1 ^Acquaviva
Borgo Maggiore
\\ ®
SAN MARINO f
Faetano 1
Chiesanuova
.F,cren,ino > ^ ^
Disputes - international: none
Sao Tome
and Principe
Neves.
.1
SAO TOME
llheu Bombom
llha do Principe .''Sant0 Antonio
W
Uh6u Carogo
Tinhosa Pequena
Tinhosa Grande
Gulf of
0 20 40km
Disputes - international: none
Illicit drugs: a major international financial center
vulnerable to the layering and integration stages of
money laundering; despite significant legislation and
reporting requirements, secrecy rules persist and
nonresidents are permitted to conduct business
through offshore entities and various intermediaries;
transit country for and consumer of South American
cocaine and Southwest Asian heroin
536
Disputes - international: Golan Heights is
Israeli-occupied with the almost 1 ,000-strong UN
Disengagement Observer Force (UNDOF) patrolling a
buffer zone since 1964; Lebanon claims Shaba''a
farms in Golan Heights; international pressure
prompts the removal of Syrian troops and intelligence
personnel stationed in Lebanon since October 1976;
2004 Agreement and pending demarcation settles
border dispute with Jordan
Refugees and internally displaced persons:
refugees (country of origin): 426,919 (Palestinian
Refugees (UNRWA)) 14,391 (Iraq)
IDPs: 170,000 (most displaced from Golan Heights
during 1967 Arab-Israeli War) (2005)
Illicit drugs: a transit point for opiates and hashish
bound for regional and Western markets; weak
anti-money-laundering controls and bank privatization
may leave it vulnerable to money-laundering
Taiwan
E
Entry
follows
IT
IT
ITA
380
it
42 46N
10 17 E
Elemi Triangle (region)
Ethiopia (claimed), Kenya (de facto), Sudan
(claimed)
5 00N
35 30E
Ellada (local name for Greece)
38 30N
15 00E
Epirus, Northern (region)
Albania, Greece
40 00N
20 30E
Ertra (local name for Eritrea)
44 25N
8 57E
George Town (capital)
42 50N
12 50E
Italian East Africa (former name for Italian possessions
in eastern Africa)
Eritrea, Ethiopia, Somalia
8 00N
38 00 E
Italian Somaliland (former name for southern Somalia)
41 13 N
09 24E
Madeira Islands
38 07N
Palestine (region)
Israel. West Bank
32 00N
Palikir (capital)
Federated States of Micronesia
6 55N
Palk Strait
Indian Ocean
10 00N
Pamirs (mountains)
China, Tajikistan
38 00N
Pampas (region)
41 54 N
12 29E
Roncador Cay (island)
40 00N
9 00E
Sargasso Sea (region)
Atlantic Ocean
30 00N
55 00W
Sark (island)
37 30N
Atlantic Ocean
37 20N
Atlantic Ocean
3130N
46 30N
10 30E
South Vietnam (former name for the southern portion of
Vietnam)
Vietnam
12 00N
108 00 E
South Yemen (People''s Democratic Republic of Yemen;
now part of Yemen)
45 04N
7 40E
Turkish Straits (see Bosporus and Dardenelles)
Atlantic Ocean
40 40N
28 00E
Turkiye (local name for Turkey)
Turkey
39 00N
35 00E
706
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Turkmenia (former name for Turkmenistan)
Turkmeniya (former name for Turkmenistan)
43 25N
Tutuila (island)
46 30N
Tyrrhenian Sea
Atlantic Ocean
40 00N
Ubangi-Shari (former name for the Central African
Republic)
Ukrayina (local name for Ukraine)
Ulaanbaatar (capital)','44ed727abfbd0536b4a9871105242e75e31919b9063145f1be2b5395f91c8fe4','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29ce673592a387ac8da232e93c7e53384f01d8f98e509d4212448ed714fb0491',2007,'HN','Honduras','transnational-issues',692,'ft
Esteli
j— '' '' .Matagalpa
Chinandega
Conn.o-'' -Le6n
* MANAGUA
Granada*
Rivas.
7: bbean
Sea
NORTH
PACIFIC
OCEAN
Bluefields**
Lagode
^Nicaragua s
San
Carlos
i
El Bluff
ISLAS DEL
MAIZ
HO
HN
HND
340
hn
35 00N
6317N
18 08S
56 50N
62 00N
47 00N
11 03 S
17 25S
38 00E
20 40W
178 25 E
60 39E
15 00E
8 00E
171 15W
83 56W
Tadzhikistan (former name for Tajikistan)
Tehran (capital)
Iran
Tel Aviv (capital, de facto)','e9b4241f6c96f6201ce2fe90678bb17b38c343c6588781377802ec5fa81516ee','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44dabe5c7d4077e68b14875b97dc4e58cfe52a91265eae46dd15fcdb0f532a11',2007,'NI','Nicaragua','transnational-issues',693,'NORTH PACIFIC
OCEAN
N^
lago lie
s Nicaragua
Disputes - international: in 1992, International
Court ol Justice (ICJ) ruled on the delimitation of
"bolsones" (disputed areas) along the El
Salvador-Honduras border, but despite Organization
of American States (OAS) intervention and a further
ICJ ruling in 2003, full demarcation of the border
remains stalled; the 1 992 ICJ ruling advised a tripartite
resolution to a maritime boundary in the Gulf of
Fonseca with consideration of Honduran access to the
Pacific; El Salvador continues to claim tiny Conejo
Island, not mentioned in the ICJ ruling, off Honduras in
the Gulf of Fonseca; Honduras claims Sapodilla Cays
off the coast of Belize, but agreed to creation of a joint
ecological park and Guatemalan corridor in the
Caribbean in the failed 2002 Belize-Guatemala
Differendum, which the OAS is attempting to revive;
Nicaragua filed a claim against Honduras in 1 999 and
against Colombia in 2001 at the ICJ over a complex
dispute over islands and maritime boundaries in the
Caribbean Sea
Illicit drugs: transshipment point for drugs and
narcotics; illicit producer of cannabis, cultivated on
small plots and used principally for local consumption;
corruption is a major problem; some
money-laundering activity
12 15 N
83 00W
Corocoro Island
Guyana, Venezuela
3 38N
66 50W
Corsica (island; also Corse)
1215N
83 00W
Majorca Island (Isla de Mallorca)
12 09N
86 17W
Manama (capital)','4128df2aea9583b82108973f161189bad88d0cb672720bbf1d6ba364497326a7','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ab9737b76231ce350d201e5bb865b42ed79133e9f2e08833bfd0078454c558f',2007,'HK','Hong Kong','transnational-issues',702,'(special administrative
region of China)
HK
HK
HKG
344
hk
Howland Island
HQ
ISO includes with the US Minor
Outlying Islands
2215N
114 10E
Honiara (capital)
Burma, Thailand
Laos
Arctic Ocean
Spain (Canary Islands)
Syria
22 24N
114 10E
Newfoundland (island, with mainland area, and a province)
2215N
114 10 E
Yaitopya (local name for Ethiopia)','8ac4387ea02725c33f3891a00fd7dc2b74556c70c6964dae5e489e8afa29d3a6','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e391ae1e74dc4df950d801ca1f941cdf0be33f4d90bec6ea22935164a525981',2007,'HU','Hungary','transnational-issues',704,'/ 20 I""*"
\\ SLOVAKIA J
v^— -K UKRAINE
Miskolc
(yV/VvN
AUSTRIA j-i^S GyoN^2^ —
^-ySopron *
I AKekes
^BUDAPEST
Debrecen.
.Nyiregyhaza sP*^ ^>>*-*"
\\ «
) .Szombalhely
J
7 Szekesfehervar*
{
v^l BalatonS^J
• Dunaujvaros
Kecskemet
v^\\i \\
)
HU
HU
HUN
348
hu
Buenos Aires (capital)
47 00N
20 00E
Mahe Island','ca7e022b4d85fe6b429423f16595452c8effc6f0335a2c74d969cd83bc41d88b','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f0f53273afdf3a5fcfb4ecc2d91ddbfec86796c812f1cbb3914de767fb8ec25',2007,'RO','Romania','transnational-issues',705,'sloveniaT^s.
1
Szeged.
S \\ Pecs
1 V.
r~* CROATIA ^~Y_ /
''-''T''SER. AND MONTHS,
0 20 40 km
0 20 40 mi
Disputes • international: Iceland disputes
Denmark''s alignment of the Faroe Islands'' fisheries
median line; Iceland, the UK, and Ireland dispute
Denmark''s claim that the Faroe Islands'' continental
shelf extends beyond 200 nm
260
Sea
Disputes - international: Moldova and Ukraine
have established joint customs posts to monitor transit
through Moldova''s break-away Transnistria region
which remains under OSCE supervision
Refugees and internally displaced persons:
IDPs: 1 ,000 (internal secessionist uprising in
Transnistrian region in 1991) (2005)
Illicit drugs: limited cultivation of opium poppy and
cannabis, mostly for CIS consumption; transshipment
point for illicit drugs from Southwest Asia via Central
Asia to Russia, Western Europe, and possibly the US;
widespread crime and underground economic activity
374
■J
RO
RO
ROU
642
.ro
Russia
RS
RU
RUS
643
.ru
Budapest (capital)
46 30N
24 00E
Trindade, llha de (island)
Wales (region)','a32251e37bc9b8b962e31c6cd905d205e50d6d5c2515f22fa5a4aca117f25a78','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('785eeb4dc30c3da5e21ad1c53c13d26ea23fa6e4d08a80857cf3670bc9382ce3',2007,'IN','India','transnational-issues',714,'^
l_ _ "-^Indian
V? J- NUneof
rinag
^Amritsai
.JEW*
DELHI
Agra* .KanpuFV
\\ikV\\Y BURMA
Kandla^ .Bhopal
Ahnaadabad
''•Mumba, .N"9pur
(Bombay)
. , f ob c c A N
Arabmn '' Hyderabad
• Vishakhapatnam
|Panaij Bay ol
Marmagao • _.
l „ Chennai Bengal Andaman
Bangalore ;(Madras) „£%£.
>,CaHcut .Pondicherry p(M Bm
Cochin. .Madura!
Tuticonn. A m,
I
I LANKA
NICOBAR-
ISLANDS
Disputes - international: since China and India
launched a security and foreign policy dialogue in
2005, consolidated discussions related to the dispute
over most of their rugged, militarized boundary,
regional nuclear proliferation, Indian claims that China
transferred missiles to Pakistan, and other matters
continue; various talks and confidence-building
measures have cautiously begun to defuse tensions
over Kashmir, particularly since the October 2005
earthquake in the region; Kashmir nevertheless
remains the site of the world''s largest and most
militarized territorial dispute with portions under the de
facto administration of China (Aksai Chin), India
(Jammu and Kashmir), and Pakistan (Azad Kashmir
and Northern Areas); in 2004, India and Pakistan
instituted a cease fire in Kashmir and in 2005, restored
bus service across the highly militarized Line of
Control; Pakistan has taken its dispute on the impact
and benefits of India''s building the Baglihar Dam on
the Chenab River in Jammu and Kashmir to the World
Bank for arbitration; UN Military Observer Group in
India and Pakistan (UNMOGIP) has maintained a
small group of peacekeepers since 1949; India does
not recognize Pakistan''s ceding historic Kashmir
lands to China in 1964; disputes persist with Pakistan
over Indus River water sharing; to defuse tensions
and prepare for discussions on a maritime boundary,
in 2004, India and Pakistan resurveyed a portion of
the disputed boundary in Sir Creek estuary at the
mouth of the Rann of Kutch; Pakistani maps continue
to show its Junagadh claim in Indian Gujarat State;
discussions with Bangladesh remain stalled to delimit
a small section of river boundary, to exchange 162
miniscule enclaves in both countries, to allocate
divided villages, and to stop illegal cross-border trade,
migration, violence, and transit of terrorists through
the porous border; Bangladesh protests India''s
attempts to fence off high-traffic sections of the
border; dispute with Bangladesh over New Moore/
South Talpatty/Purbasha Island in the Bay of Bengal
deters maritime boundary delimitation; India seeks
cooperation from Bhutan and Burma to keep Indian
Nagaland and Assam separatists from hiding in
remote areas along the borders; Joint Border
Committee with Nepal continues to demarcate minor
disputed boundary sections; India maintains a strict
border regime to keep out Maoist insurgents and ■
control illegal cross-border activities from Nepal
Refugees and internally displaced persons:
refugees (country of origin): 92,394 (Tibet/China)
57,274 (Sri Lanka) 9,761 (Afghanistan)
IDPs: 600,000 (resulting from 26 December 2004
tsunami); 500,000 (Jammu and Kashmir conflicts;
most IDPs are Kashmiri Hindus) (2005)
Illicit drugs: world''s largest producer of licit opium
for the pharmaceutical trade, but an undetermined
quantity of opium is diverted to illicit international drug
markets; transit point for illicit narcotics produced in
neighboring countries; illicit producer of
methaqualone; vulnerable to narcotics money
laundering through the hawala system
Indian Ocean
IN
IN
IND
356
in
1130N
72 30E
Amirante Isles (island group; also Les Amirantes)
12 00N
92 45E
Andaman Sea
Indian Ocean
10 00N
95 00E
Andorra la Vella (capital)
20 00N
77 00E
Bhopal (city)
2316N
77 24E
Biafra (region)
18 58N
72 50E
Bonaire (island)
Netherlands Antilles
12 10 N
6815W
Bonifacio, Strait of
Atlantic Ocean
4101 N
14 00E
Bonin Islands
13 04N
80 16E
Chesterfield Islands (lies Chesterfield)
Damascus (capital)
Danger Islands (see Pukapuka Atoll)
Syria
20 42N
70 59E
Djibouti (capital)
15 20N
74 00E
Gobi (desert)
China, Mongolia
42 30N
107 00 E
688
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Godthab (capital; also Nuuk)
32 42N
74 52E
Jammu and Kashmir (region)
India, Pakistan
34 00N
76 00E
Japan, Sea of
Pacific Ocean
40 00 N
135 00 E
Jars, Plain of
Laos
19 27N
103 10 E
Java (island)
Indian Ocean
13 04N
80 16E
Madrid (capital)
817N
73 02E
Minorca Island (Isla de Menorca)
28 36N
7712E
New Guinea (island)
Indonesia, Papua New Guinea
5 00S
140 00 E
New Hebrides (island group)
8 00N
93 30E
Nicosia (capital)
27 50N
Czech Republic, Germany, Poland
5100N','efea9f5771d7d63f5c18a829f62288b009f1c131b4de46786f2d1dcc3a4df246','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00a4fc5d4826ce43bf1275db439627d6c303f2ab6f393ac3b178b05f00bd8a68',2007,'IE','Ireland','transnational-issues',723,'Northern \\ %
Ireland <L^ \\
(U.K.j, '' *\\ -
Monaghany
Drogheda.
DUBLIN
''TuMamore
Wicklow.
; ArWow.
Irish
Sea
^=s=^Limerick
/--~-pp .Killarney
* New
.Ross
Waterford*\\''<0>
CsrraunlooNI .Cork
George.
ChatttK
Celtic Sea
Disputes - international: Ireland, Iceland, and the
UK dispute Denmark''s claim that the Faroe Islands''
continental shelf extends beyond 200 nm
Illicit drugs: transshipment point for and consumer
of hashish from North Africa to the UK and
Netherlands and of European-produced synthetic
drugs; minor transshipment point for heroin and
cocaine destined for Western Europe; despite recent
legislation, narcotics-related money laundering - using
bureaux de change, trusts, and shell companies
involving the offshore financial community - remains a
concern
El
IE
IRL
372
ie
53 20N
615W
Dushanbe (capital)
53 00N
8 00W
Elba (island)','d0a04914c10f3abf3eea0d5ff6c3270e9e707f1001ea9eb2615f8ae876e29eab','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('773c4528a79972b784a60eb040c3566cf0c936759eacca1f1cefa7703bffc4ee',2007,'IM','Isle of Man','transnational-issues',732,'E?f9
(British crown dependency)
bl
O 5 10 km
O 5 10 mi
Irish Sea /
Ramsey *
/
/
"Peel
(
DOUGLAS
*
j sS
?
5 j — . .Castletown
Callof / rS \\ / ''
Irish Sea
Chicken
Rock
Disputes - international: none
278
IM
—
—
—
im
ISO includes with the UK','a99f7190d4531b1021c5305c45daba4aa87aca9ff39099b913eb2f4ab4438537','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc80f8accff4176477b615d0cc0bdc49ff9dc2c39679a71d3340e798cae16cb2',2007,'TN','Tunisia','transnational-issues',741,'li Calabria
'' SOLE
- PELMX
SOLE ^
100 200 km
100
200 mi
Disputes • international: Italy''s long coastline and
developed economy entices tens of thousands of
illegal immigrants from southeastern Europe and
northern Africa
Illicit drugs: important gateway for and consumer of
Latin American cocaine and Southwest Asian heroin
entering the European market; money laundering by
organized crime and from smuggling
United States Minor Outlying
Islands
FIPS10-4
SF
SX
SP
PG
CE
SU
NS
SV
WZ
SW
SZ
SY
TW
Tl
TZ
TH
TO
TL
TN
TD
TE
TS
ZA
ISO 3166
ZAF
Internet
710
za
GS
SGS
239
gs
ES
ESP
724
.es
LK
LKA
144
Ik
SD
SDN
736
.sd
SR
SUR
740
.sr
SJ
SJM
744
si
SZ
SWZ
748
.sz
SE
SWE
752
.se
CH
CHE
756
.ch
SY
SYR
760
■sy
TW
TWN
158
.tw
TJ
TJK
762
TZ
TZA
834
.tz
TH
THA
764
.th
TG
TGO
768
■tg
TK
TKL
772
.tk
TO
TON
776
.to
TT
no
780
TN
TUN
788
.tn
UM
UMI
581
.urn
Comment
ISO includes Jan Mayen
administered with French Southern and
Antarctic Lands; no ISO codes assigned
Turkey
TU
TR
TUR
792
.tr
36 48N
1011 E
Turin (city)','50feb75717320e515a63e54e0de551bd08862bc0ee941ed8f054285d4c3a0cc6','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86c2465b9ce3666953dfe3619bde851d3fad10b980bd4643cef5da65bb8afe2b',2007,'JP','Japan','transnational-issues',767,'Disputes - international: the sovereignty dispute
over the islands of Etorofu, Kunashiri, and Shikotan,
and the Habomai group, known in Japan as the
"Northern Territories" and in Russia as the "Southern
Kuril Islands," occupied by the Soviet Union in 1945,
now administered by Russia and claimed by Japan,
remains the primary sticking point to signing a peace
treaty formally ending World War II hostilities; Japan
and South Korea claim Liancourt Rocks (Take-shima/
Tok-do) occupied by South Korea since 1954; China
and Taiwan dispute both Japan''s claims to the
uninhabited islands of the Senkaku-shoto (Diaoyu Tai)
and Japan''s unilaterally declared exclusive economic
zone in the East China Sea, the site of intensive
hydrocarbon prospecting
JA
JP
JPN
392
•JP
Jarvis Island
DQ
—
—
—
—
ISO includes with the US Minor
Outlying Islands
27 00N
142 10 E
Bonn (former capital)
Dakar (capital)
44 00N
143 00 E
Holland (region)
36 00N
138 00 E
Hormuz, Strait of
Indian Ocean
26 34N
56 15E
Horn of Africa (region)
Djibouti, Eritrea. Ethiopia, Somalia
8 00N
48 00E
Horn, Cape (Cabo de Hornos)
34 20N
133 30 E
Inner Hebrides (islands)
24 47N
141 20 E
Izmir (region)
Turkey
38 25N
2710E
Jakarta (capital)
34 41 N
135 10 E
Kodiak Island
2416N
154 00 E
Margarita, Isla (island)
Venezuela
10 00N
64 00W
Mariana Islands
Guam, Northern Mariana Islands
16 00N
145 30 E
Marie Byrd Land (region)
2416N
154 00 E
Mindanao (island)
30 00N
140 00 E
Nassau (capital)
The Bahamas
25 05N
77 21 W
Natal (region)
Natuna Besar Islands
Natuna Sea
36 00N
138 00 E
Nippon (local name for Japan)
36 00N
138 00 E
Nomoi Islands (Mortlock Islands)
Federated States of Micronesia
5 30N
153 40 E
Norge (local name for Norway)
Oland (island)
26 30N
128 00 E
Saar (region)
24 30N
124 00 E
Sala y Gomez, Isla (island)
33 45N
133 30 E
Shikotan (island)
Russia (de facto)
43 47N
146 45 E
Shqiperia (local name for Albania)
35 42N
139 46 E
Tonkin, Gulf of
Pacific Ocean
20 00N
108 00 E
Torres Strait
Pacific Ocean
10 25S
142 10 E
Torshavn (capital)
25 00N
141 00 E
Vostok Island','255827681dbb409ca06eaca0763db0418ef292bc9291b588651d88eec4e31b94','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d1328d6bf15011fa758f0e09569c61cd0b24a479ee04d75014a83cb1fb6eaaf',2007,'JO','Jordan','transnational-issues',777,'Disputes - international: 2004 Agreement settles
border dispute with Syria pending demarcation
Refugees and internally displaced persons:
refugees (country of origin): 1 ,795,326 (Palestinian
Refugees (UNRWA))
IDPs: 168,000 (1967 Arab-Israeli War) (2005)
Juan de Nova
Island
(possession of France)
■1
O 1 2km
O 1 2 mi
JO
JO
JOR
400
■jo
Juan de Nova Island
JU
—
—
—
—
administered with French Southern and
Antarctic Lands; no ISO codes assigned
3100N
36 00E
Al Yaman (local name for Yemen)
3157N
35 56E
Amsterdam (capital)
3100N
36 00E
Transkei (enclave)
3100N
36 00E
Urundi (former name for Burundi)','57882c41812a29f708baa618524c8a821874fca3337091e7e6c29a58a75807c9','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b7951b762ae8d1aac295dcd2c77e317cc292a6cb481a81661f5fda08483bb15c',2007,'KZ','Kazakhstan','transnational-issues',781,'Disputes - international: in 2005, Kazakhstan
agreed with Russia, Turkmenistan, and Uzbekistan to
commence demarcating their boundaries; delimitation
with Kyrgyzstan is complete; creation of a seabed
boundary with Turkmenistan in the Caspian Sea remains
unresolved; equidistant seabed treaties have been
ratified with Azerbaijan and Russia in the Caspian Sea,
but no resolution has been made on dividing the water
column among any of the littoral states
Refugees and internally displaced persons:
refugees (country of origin): 13,684 (Russia) (2005)
Illicit drugs: significant illicit cultivation of cannabis for
CIS markets, as well as limited cultivation of opium poppy
and ephedra (for the drug ephedrine); limited government
eradication of illicit crops; transit point for Southwest
Asian narcotics bound for Russia and the rest of Europe
Disputes - international: Kenya served as an
important mediator in brokering Sudan''s north-south
separation in February 2005; Kenya provides shelter
to approximately a quarter of a million refugees
including Ugandans who flee across the border
periodically to seek protection from Lord''s Resistance
Army (LRA) rebels; the Kenya-Somalia border is open
to pastoralists and is susceptible to cross-border clan
insurgencies; Kenya''s administrative limits extend
beyond the treaty border into the Sudan, creating the
llemi Triangle
Refugees and internally displaced persons:
refugees (country of origin): 153,627 (Somalia)
12,595 (Ethiopia) 67,556 (Sudan)
IDPs: 360,000 (KANU attacks on opposition tribal
groups in 1990s) (2005)
Illicit drugs: widespread harvesting of small plots of
marijuana; transit country for South Asian heroin
destined for Europe and North America; Indian
methaqualone also transits on way to South Africa;
significant potential for money-laundering activity
given the country''s status as a regional financial
center; massive corruption, and relatively high levels
of narcotics-associated activities
Kingman Reef
(territory of the US)
Description under
KZ
KZ
KAZ
398
.kz
51 10 N
71 30 E
Aksai Chin (region)
China (de facto), India (claimed)
35 00N
79 00E
Al Arabiyah as Suudiyah (local name for Saudi Arabia)
4315N
76 57E
Almaty (former capital)
4315N
76 57E
Alofi (capital)
51 10 N
7130E
Asuncion (capital)
48 00N
68 00E
Keeling Islands
Qita Ghazzah (local name Gaza Strip)
Gaza Strip
Quebec (province)','80f56d539dcb18780b7a52a7bb761b43b5ec27293fae9036cdd55951f90c1eba','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aede8311db1aee78779964622ddb0e13532d5fe240adfb91376d16ae96fecffe',2007,'KI','Kiribati','transnational-issues',787,'MARSHALL
ISLANDS
UNITED STATES 7s
(Hawaii)
• Johnston Atoll
(U.S.)
North Pacific Ocean
Kingman Reef pa|myra Ato||
'' ''-. (U.S.)
Banaba *•*''
TUVALU ''.
SOLOMON
ISLANDS
[.•TARAWA
■ (Gilbert
Islands)
Howland I. (U.S.)
.Baker I.PJ.SJ
Kinlimali
Jarvls i: (Christmas I.)
, • . Rawaki
, .• .• (Phoenix
Islands)
(U.S.)
Tokeiau South Pacific Ocean
tNJL) ''• Cook Is. •
.(Nil ''
. SAMOA
VANUATU ■:cf- ••••*
FUI.''
American
Samoa (U.S.)
French ,
Polynesia''
(FH.)
. TONGA
Cook Islands \\ .
(N.Z.).
Disputes - international: none
303
Korea, North
O SO ICOum
130 J
0 50 100 mi /">*.RU^l/
~. .... SonbongA.
CHINA / Naj.nV^
Paeklu-sar>_^^mjr
v^civbngjm,
jr Hyesan
/ .Kanggye
jC^ Kimch''aek.
^/Sinuiju Hamhung.
Hungnam ^ea
Koit .Sunchon 0f
PYONGYANG ^^ Japan
Namp o .Songnim .Kosong
.Sariwon t
Kaesong _, " i5>»
J . «> JPanmunjom-ni
SOUTH KOREA
Disputes - international: China seeks to stem
illegal migration of tens of thousands of North Koreans
escaping famine, economic privation, and political
oppression; North Korea and China dispute the
sovereignty of certain islands in Yalu and Tumen
rivers and a section of boundary around Paektu-san
(mountain) is indefinite; Military Demarcation Line
within the 4-km wide Demilitarized Zone has
separated North from South Korea since 1953;
periodic maritime disputes with South over the
Northern Limit Line: North Korea supports South
Korea in rejecting Japan''s claim to Liancourt Rocks
(Tok-do/Take-shima)
Refugees and internally displaced persons:
IDPs: 50,000-250,000 (government repression and
famine) (2005)
Illicit drugs: for years, from the 1970s into the
2000s, citizens of the Democratic People''s Republic of
(North) Korea (DPRK), many of them diplomatic
employees of the government, were apprehended
abroad while trafficking in narcotics, including two in
Turkey in December 2004; police investigations in
Taiwan and Japan in recent years have linked North
Korea to large illicit shipments of heroin and
methamphetamine, including an attempt by the North
Korean merchant ship Pong Su to deliver 150 kg of
heroin to Australia in April 2003
306
Korea, South
O 50 100 km
NORTH KOREA J '' 5''o 100m.
/ QPnill .Kangnung
Inch''On* , .wc,nlu
SuwOn
.Tonghae UHung-do
Jaejon Sea
Ch6n|u
Ulsan^
Masan Chinhae
•.Mokpo rusan
Yosu
Ch»lu-do
A
Hunan
Disputes - international: Military Demarcation Line
within the 4-km wide Demilitarized Zone has
separated North from South Korea since 1953;
periodic maritime disputes with North Korea over the
Northern Limit Line; South Korea and Japan claim
Liancourt Rocks (Tok-do/Take-shima), occupied by
South Korea since 1954
KR
Kl
KIR
296
ki
Korea, North
KN
KP
PRK
408
kp
Korea, South
KS
KR
KOR
410
kr
0 52S
169 35 E
Banat (region)
Hungary, Serbia and Montenegro, Romania
45 30N
2100E
Banda Sea
Pacific Ocean
5 00S
128 00 E
Bandar Seri Begawan (capital)
Brunei
4 52S
114 55 E
Bangka (island)
Cape Juby (region; former name for
Southern Morocco)
152N
157 20 W
Chukchi Sea
Arctic Ocean
69 00N
171 00 W
Chuuk Islands (Truk Islands)
Federated States of Micronesia
7 25N
151 47 W
684
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Cilicia (region)
Turkey
36 50N
34 30E
Ciskei (enclave)
3 08S
171 05 W
Enewetak Atoll (Eniwetok Atoll)
125N
173 00 E
Goa (state)
2 49S
171 40 W
Kara Sea
Arctic Ocean
76 00N
80 00E
Karachevo-Cherkessia (region)
Russia
43 40N
4150E
Karafuto (island; former name for southern Sakhalin Island)
Russia
50 00N
143 00 E
Karakoram Pass
China, India
35 30N
77 50E
Karelia (region)
Finland, Russia
6315N
30 48E
Karelian Isthmus
Russia
60 25N
30 00E
Karimata Strait
Pacific Ocean
2 05S
108 40 E
Kashmir (region)
India, Pakistan
34 00N
76 00E
Katanga (region)
Democratic Republic of the Congo
10 00S
26 00E
Kathmandu (capital)
152N
157 20 W
Kishinev (see Chisinau)
Moldova
47 00N
28 50E
Kithira Strait
Atlantic Ocean
36 00N
23 00E
Kobe (city)
Ocean Island (Kure Island)
3 30S
172 00 W
Pilipinas (local name for the Philippines)
Tartary, Gulf of
Pacific Ocean
Tashkent (capital)
10 06S
152 23 W
Vrangelya, Ostrov (Wrangel Island)
Russia
71 14 N
179 36 W
707
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
W
Wake Atoll
Wake Island
Wakhan Corridor (see Vakhan)','ed42aae32e23d0cace2ea72a4b5c1cc8f2024eb022a69579376b5215afa213a4','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4da08ad6f7e7b7cab07d8ab3b61242c24af2f23167371db0c1ab31544afa762',2007,'IQ','Iraq','transnational-issues',796,'Qasr as Sa.b[yah
IZ
IQ
IRQ
368
iq
33 00N
44 00E
Al Jaza''ir (local name for Algeria)
33 21 N
44 25E
Baki (see Baku)
Atlantic Ocean','04eff58132ae67a86ff074fab3dd50eb4a77c3c9184398d852486f0f95e3cd51','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab5a3fff8c218bc12d13c306a1089715c9d601f3f7fdf0d6a9174e85cfad9b43',2007,'KW','Kuwait','transnational-issues',797,'Mfna'' al Ahmadf,
Ash Shu''aybah A
MTna'' Abd Allah
Az Zawr
(MTna'' Sa''ud^
Al Wafrah
Faylaka
Persian
Gulf
Oaruh .
\\ An Nuwavsib'' MarTdfm
KU
KW
KWT
414
kw
29 30N
45 45E
Al Maghrib (local name for Morocco)
Bucharest (capital)
Russia','bdd73b0ccd5ddf1396dae992ce31ea8c33538c7585d93c976261d0bc287dee46','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b045c8607dc3f7dc0335f3a91066d2b314a9c89584ac8214aec174f8002326cb',2007,'KG','Kyrgyzstan','transnational-issues',800,'KAZAKHSTAN BISHKEK
Illicit drugs: major transit country for Afghan
narcotics bound for Russian and, to a lesser extent,
Western European markets; limited illicit cultivation of
opium poppy for domestic consumption; Tajikistan
seizes roughly 80% of all drugs captured in Central
Asia and stands third worldwide in seizures of opiates
(heroin and raw opium)
Tanzania
KG
KG
KGZ
417
kg
Laos
LA
LA
LAO
418
la
42 54N
74 36E
Bishop Rock
42 54N
74 36E
Funafuti (former name for Fongafale)
41 00 N
75 00E
Kirgizia (former name for Kyrgyzstan)
41 00 N
75 00E
Kirguizstan (local name for Kyrgyzstan)
41 00 N
75 00E
Kiritimati (Christmas Island)','e0b6968b890c6578826dd76a9ab92d9470ec69434a5cb2262651e48aa9636c17','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebe5dce1b0de5858d310fa16fa3432c136708892fb13f65d01072ab9be4831f0',2007,'LV','Latvia','transnational-issues',801,'"\\5S. ESTONIA
\\ late
"^ Pskov
1
Gull of \\
.Valmiera ^ — J
Venlspils
Riga \\
Aluksne*
< RUSSIA
Baltic
RIGA
Jurmala* * ^alaspils
•Ogre
Galzint
AKalns
Ltepaja
ft
Jelgava*
LG
LV
LVA
428
Iv
Riga, Gulf of
Atlantic Ocean
Rio de la Plata (gulf)
Atlantic Ocean
Rio de Oro (region)','640e2b2c1f578fa5cf8e64321938f6fe6aeebf7aa26c1f8f8fb6758bb3dbd6d8','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('573220a88e2f59d6fefd02cd36623b3eb780369fa0fb6c8caa63a264a5c58b20',2007,'LT','Lithuania','transnational-issues',802,'.Jekabpils
V
i
Nv Daugavpils
Rezekne 7
0
50km \\__ J
Disputes - international: Lithuania and Russia
committed to demarcating their boundary in 2006 in
accordance with the land and maritime treaty ratified
by Russia in May 2003 and by Lithuania in 1999;
Lithuania operates a simplified transit regime for
Russian nationals traveling from the Kaliningrad
coastal exclave into Russia, while still conforming, as
a member state that forms part of the EU''s external
border, to strict Schengen border rules; the Latvian
parliament has not ratified its 1 998 maritime boundary
treaty with Lithuania, primarily due to concerns over
potential hydrocarbons
Illicit drugs: transshipment point for opiates and
other illicit drugs from Southwest Asia. Latin America,
and Western Europe to Western Europe and
Scandinavia; limited production of methamphetamine
and ecstasy; susceptible to money laundering despite
changes to banking legislation
LH
LT
LTU
440
.It
56 00N
24 00E
Ligurian Sea
Atlantic Ocean
43 30N
9 00E
Lilongwe (capital)
54 41 N
25 19E
Viti Levu (island)','70e77e2a924b033dd72e6e2a89bf55a37256239ffeb63b5087d73df775b012b6','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('feceb79399abc781a7b3121f2905750b3404ac35a3dcf5de07b6fd0a76a74bd9',2007,'LB','Lebanon','transnational-issues',803,'El Mina,
Mediterranean
Sea
BEIRUT
.Jbail
jjounie Baalbeck^
SYRIA
Sidon
Tyre,
y ) UNDOF
l Golan Heights
r; (Israeli occupied)
Disputes - international: Lebanese Government
claims Shab''a Farms area of Israeli-occupied Golan
Heights; the roughly 2,000-strong UN Interim Force in
Lebanon (UNIFIL) has been in place since 1978
Refugees and internally displaced persons:
refugees (country of origin): 401 ,071 (Palestinian
Refugees (UNRWA))
IDPs: 300,000 (1975-90 civil war, Israeli invasions)
(2005)
Illicit drugs: cannabis cultivation dramatically
reduced to 2,500 hectares in 2002; opium poppy
cultivation minimal; small amounts of Latin American
cocaine and Southwest Asian heroin transit country
on way to European markets and for Middle Eastern
consumption
LE
LB
LBN
422
lb
672
Appendix D: Cross-Reference List of Country Data Codes (continued)
Entity
33 50N
36 50E
Lubumbashi (city)
Democratic Republic of the Congo
1140S
27 28E
Lusaka (capital)
34 26N
35 51 E
Tripolitania (region)','f410d7eeaa5d905a5a1ff8d3534f7d14734a2d23a24a712d1412a54147720a41','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a23d544b3526c1e1c347c86035b90de0cf7dbc6fbf5415ae259416ed4e2c458f',2007,'ZA','South Africa','transnational-issues',820,'Disputes - international: none
South Georgia and the Islands
29 12S
26 07E
Bo Hai (gulf)
Pacific Ocean
38 00N
120 00 E
Boa Vista (island)
Cape Verde
16 05N
22 50W
Bogota (capital)
26 30S
25 30E
Bora-Bora (island)
British Central African Protectorate (former name
of Nyasaland)
34 15S
18 25E
Cape Province (region; former name for Northern,
Western, and Eastern Cape Provinces of South Africa)
3130S
22 30E
Cape Town (legislative capital)
33 57S
18 28W
Caracas (capital)
Venezuela
10 30N
66 56W
Cargados Carajos Shoals
33 00S
27 00E
Citta del Vaticano (local name for Vatican City)
Holy See
4154N
12 27E
Cochin China (region)
Vietnam
1100N
107 00 E
Coco, Isla del (island)
34 24S
18 30E
Goteborg (city)
2615S
28 00E
Joseph Bonaparte Gulf
Pacific Ocean
14 00S
128 45 E
Juan de Fuca, Strait of
Pacific Ocean
4818N
124 00 W
Juan Fernandez, Islas de (island group)
46 51S
37 52E
Marmara, Sea of
Atlantic Ocean
40 40N
2815E
Marquesas Islands (lies Marquises)
Oranjestad (capital)
Prevlaka peninsula
Prince Patrick Island
3215S
28 15E
Transvaal (region; former name for northeastern
South Africa)
2510S
29 25E
Transylvania (region)
23 00S
3100E
Verde Island Passage
Pacific Ocean
13 34N
120 51 E
Victoria (capital)','b6b696a8185c2d38cc41fe1a661813ac7b1f91be720345df6fc99b68c39c5d14','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ddefa464930fd1e6b5f539cc520e564f0a62f11789707f8ff821497059cd58b8',2007,'LR','Liberia','transnational-issues',821,'A^9voir^jamaS GUINEA P^"^
SIERRA J~* AMoun\\ ^T
LEONE f """M r
yr jf Yekepa^-S''^
/ _ . .Gbarnga (
-* .Tubmanburg * { COTE
.Robertspor, ) D''lVOIRE
MONROVIA <>»
^-<Harbel Zwedr^l
.Buchanan ^*\\J
NORTH I
ATLANTIC . J
Greenville r
OCEAN A
0 30 60 km J
o 30 60 mi Harper
Disputes - international: although Liberia''s
domestic fighting among disparate rebel groups,
warlords, and youth gangs was declared over in 2003,
civil unrest persists, and in 2004, 133,000 Liberian
refugees remained in Guinea, 72,000 in Cote d''lvoire,
67,000 in Sierra Leone, and 43,000 in Ghana; Liberia,
in turn, shelters refugees fleeing turmoil in Cote
d''lvoire and Sierra Leone; since 2003, the UN Mission
in Liberia (UNMIL) has maintained about 18,000
peacekeepers in Liberia; the Cote d''lvoire
Government accuses Liberia of supporting Ivoirian
rebels; UN sanctions ban Liberia from exporting
diamonds and timber
Refugees and internally displaced persons:
refugees (country of origin): 13,941 (Sierra Leone)
12,408 (Cote d''lvoire)
IDPs: 464,000 (civil war from 1990-2004; IDP
resettlement began in November 2004) (2005)
Illicit drugs: transshipment point for Southeast and
Southwest Asian heroin and South American cocaine
for the European and US markets; corruption, criminal
activity, arms-dealing, and diamond trade provide
significant potential for money laundering, but the lack
of well-developed financial system limits the country''s
utility as a major money-laundering center
LI
LR
LBR
430
.lr
618N
1047W
Montenegro (political region)
Serbia and Montenegro
42 30N
19 00E
Monterrey (city)','f4c623318e2879796f474e05b548ca1b409d2402676efab12897dcc65b67268b','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba99c723b6d7cd335e20086ed0546c8d4b5916d25c3db8dd3a3c277e85740bcf',2007,'LI','Liechtenstein','transnational-issues',830,'B
L_ _J
j
h \\
RuggtZer Riel/ N^
/.RuggWll
s^7
/Mauren U
x?y Eschen \\
/ /
LS
LI
LIE
438
Ji
47 09N
9 31E
Vakhan (Wakhan Corridor)','91f385c1c8fe655503eda4339f198ccd68d2251a66635495f9b339c1efa3f144','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5dd199576f534ec989699d6a3fb091910b493beb7f25dae196ad880651550c9',2007,'LU','Luxembourg','transnational-issues',848,'O 5 lpkm S
0 5 10 m, ( *s_T^
/Buurgplaa
S Wiltz
L
Diekirclv
established— 3 February 1 958
effective— 1 November 1960
aim— to develop closer economic cooperation
and integration
members— (55) Algeria, Argentina, Australia, Austria, Belgium, Bosnia and Herzegovina, Brazil, Bulgaria, Canada,
Chile, China, Croatia, Czech Republic, Denmark, Estonia, European Central Bank, Finland, France, Germany,
Greece, Hong Kong, Hungary, Iceland, India, Indonesia, Ireland, Israel, Italy, Japan, South Korea, Latvia, Lithuania,
Macedonia, Malaysia, Mexico, Netherlands, NZ, Norway, Philippines, Poland, Portugal, Romania, Russia, Saudi
Arabia, Serbia and Montenegro, Singapore, Slovakia, Slovenia, South Africa, Spain, Sweden, Switzerland, Thailand,
Turkey, UK, US; note— Serbia and Montenegro have separate central banks; their links with BIS are currently under
review
members— (3) Belgium, Luxembourg, Netherlands
Big Seven
nofe— membership is the same as the
Group of 7
established— 1 975
aim— to discuss and coordinate major economic
policies
members— (7) Big Six (Canada, France, Germany, Italy, Japan, UK) plus the US
Black Sea Economic Cooperation Zone
(BSEC)
established— 25 June 1992
aim— to enhance regional stability through
economic cooperation
members— (12) Albania, Armenia, Azerbaijan, Bulgaria, Georgia, Greece, Moldova, Romania, Russia, Serbia and
Montenegro, Turkey, Ukraine; note— Macedonia is in the process of joining
observers— (9) Austria, Egypt, France, Germany, Israel, Italy, Poland, Slovakia, Tunisia; note— Bosnia and
Herzegovina, Croatia, and Slovenia have applied for observer status
Caribbean Community and Common Market
(Caricom)
established— 4 July 1973
effective— 1 August 1973
aim— to promote economic integration and
development, especially among the less
developed countries
members— (15) Antigua and Barbuda, The Bahamas, Barbados, Belize, Dominica, Grenada, Guyana, Haiti,
Jamaica, Montserrat, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Suriname, Trinidad and
Tobago
associate member— (5) Anguilla, Bermuda, British Virgin Islands, Cayman Islands, Turks and Caicos Islands
Caribbean Development Bank (CDB)
established— 18 October 1969
effective— 26 January 1970
aim— to promote economic development and
cooperation
regional members— (20) Anguilla, Antigua and Barbuda, The Bahamas, Barbados, Belize, British Virgin Islands,
Cayman Islands, Colombia, Dominica, Grenada, Guyana, Jamaica, Mexico, Montserrat, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Trinidad and Tobago, Turks and Caicos Islands, Venezuela
nonregional members— (5) Canada, China, Germany, Italy, UK
636
Appendix B: International Organizations and Groups (continued)
Central European Initiative (CEI)
note— evolved from the Quadrilateral Initiative
and the Hexagonal Initiative
established 1 November 1989 as the
Quadrilateral Initiative, 27 July 1991 became the
Hexagonal Initiative, July 1992 its present name
was adopted
aim— to form an economic and political
cooperation group for the region between the
Adriatic and the Baltic Seas
members— (17) Albania, Austria, Belarus, Bosnia and Herzegovina, Bulgaria, Croatia, Czech Republic, Hungary,
Italy, Macedonia, Moldova, Poland, Romania, Serbia and Montenegro, Slovakia, Slovenia, Ukraine
Colombo Plan (CP)
established— May 1950 proposal was adopted;
1 July 1951 commenced full operations
aim— to promote economic and social
development in Asia and the Pacific
members— (25) Afghanistan, Australia, Bangladesh, Bhutan, Burma, Fiji, India, Indonesia, Iran, Japan, South
Korea, Laos, Malaysia, Maldives, Mongolia, Nepal, NZ, Pakistan, Papua New Guinea, Philippines, Singapore, Sri
Lanka, Thailand, US, Vietnam
Commonwealth (C)
note— also known as Commonwealth of Nations
established— 31 December 1931
aim— to foster multinational cooperation and
assistance, as a voluntary association that
evolved from the British Empire
members— (53) Antigua and Barbuda, Australia, The Bahamas, Bangladesh, Barbados, Belize, Botswana, Brunei,
Cameroon, Canada, Cyprus, Dominica, Fiji, The Gambia, Ghana, Grenada, Guyana, India, Jamaica, Kenya, Kiribati,
Lesotho, Malawi, Malaysia, Maldives, Malta, Mauritius, Mozambique, Namibia, Nauru, NZ, Nigeria, Pakistan
(suspended), Papua New Guinea, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
Seychelles, Sierra Leone, Singapore, Solomon Islands, South Africa, Sri Lanka, Swaziland, Tanzania, Tonga,
Trinidad and Tobago, Tuvalu, Uganda, UK, Vanuatu, Zambia; note— on 7 December 2003 Zimbabwe withdrew its
membership from the Commonwealth
Commonwealth of Independent States (CIS)
established— Q December 1991
effective— 21 December 1991
aim— to coordinate intercommonwealth
relations and to provide a mechanism for the
orderly dissolution of the USSR
members— (11) Armenia, Azerbaijan, Belarus, Georgia, Kazakhstan, Kyrgyzstan, Moldova, Russia, Tajikistan,
Ukraine, Uzbekistan
associates— (\\) Turkmenistan
Communist countries
Coordinating Committee on Export Controls
(COCOM)
Council of Europe (CE)
established— 5 May 1949
effective— 3 August 1949
aim— to promote increased unity and quality of
life in Europe
traditionally the Marxist-Leninist states with authoritarian governments and command economies based on the
Soviet model; most of the original and the successor states are no longer Communist; see centrally planned
economies
established in 1949 to control the export of strategic products and technical data from member countries to
proscribed destinations; members were: Australia, Belgium, Canada, Denmark, France, Germany, Greece, Italy,
Japan, Luxembourg, Netherlands, Norway, Portugal, Spain, Turkey, UK, US; abolished 31 March 1994; COCOM
members established a new organization, the Wassenaar Arrangement, with expanded membership on 12 July
1996 that focuses on nonproliferation export controls as opposed to East-West control of advanced technology
members— (46) Albania, Andorra, Armenia, Austria, Azerbaijan, Belgium, Bosnia and Herzegovina, Bulgaria,
Croatia, Cyprus, Czech Republic, Denmark, Estonia, Finland, France, Georgia, Germany, Greece, Hungary, Iceland,
Ireland, Italy, Latvia, Liechtenstein, Lithuania, Luxembourg, Macedonia, Malta, Moldova, Monaco, Netherlands,
Norway, Poland, Portugal, Romania, Russia, San Marino, Serbia and Montenegro, Slovakia, Slovenia, Spain,
Sweden, Switzerland, Turkey, Ukraine, UK
observers— (6) Canada, Holy See, Israel, Japan, Mexico, US
countries in transition
a term used by the International Monetary Fund (IMF) for the middle group in its hierarchy of advanced economies,
countries in transition, and developing countries; IMF statistics include the following 28 countries in transition: Albania,
Armenia, Azerbaijan, Belarus, Bosnia and Herzegovina, Bulgaria, Croatia, Czech Republic, Estonia, Georgia,
Hungary, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Macedonia, Moldova, Mongolia, Poland, Romania, Russia,
Serbia and Montenegro, Slovakia, Slovenia, Tajikistan, Turkmenistan, Ukraine, Uzbekistan; note— this group is
identical to the group traditionally referred to as the "former USSR/Eastern Europe" except for the addition of Mongolia
637
Appendix B: International Organizations and Groups (continued)
developed countries (DCs)
developing countries
Economic and Monetary Union (EMU)
note— an integral part of the European Union;
also known as the European Economic and
Monetary Union
established— 1 -2 December 1969 (proposed at
summit conference of heads of government; 7
February 1992 (Maastricht Treaty signed)
aim— to promote a single market by creating a
single currency, the euro; timetable— 2 May
1998: European exchange rates fixed for 1
January 1999; 1 January 1999: all banks and
stock exchanges begin using euros; 1 January
2002: the euro goes into circulation; 1 July 2002
local currencies no longer accepted
the top group in the hierarchy of developed countries (DCs), former USSR/Eastern Europe (former USSR/EE), and
less developed countries (LDCs); includes the market-oriented economies of the mainly democratic nations in the
Organization for Economic Cooperation and Development (OECD), Bermuda, Israel, South Africa, and the
European ministates; also known as the First World, high-income countries, the North, industrial countries; generally
have a per capita GDP in excess of $10,000 although four OECD countries and South Africa have figures well under
$10,000 and two of the excluded OPEC countries have figures of more than $10,000; the 34 DCs are: Andorra,
Australia, Austria, Belgium, Bermuda, Canada, Denmark, Faroe Islands, Finland, France, Germany, Greece, Holy
See, Iceland, Ireland, Israel, Italy, Japan, Liechtenstein, Luxembourg, Malta, Monaco, Netherlands, NZ, Norway,
Portugal, San Marino, South Africa, Spain, Sweden, Switzerland, Turkey, UK, US; note— similar to the new
International Monetary Fund (IMF) term "advanced economies" that adds Hong Kong, South Korea, Singapore, and
Taiwan but drops Malta, Mexico, South Africa, and Turkey
a term used by the International Monetary Fund (IMF) for the bottom group in its hierarchy of advanced economies,
countries in transition, and developing countries; IMF''statistics include the following 126 developing countries:
Afghanistan, Algeria, Angola, Antigua and Barbuda, Argentina, Aruba, The Bahamas, Bahrain, Bangladesh,
Barbados, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo,
Republic of the Congo, Costa Rica, Cote d''lvoire, Cyprus, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt,
El Salvador, Equatorial Guinea, Ethiopia, Fiji, Gabon, The Gambia, Ghana, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, India, Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya, Kiribati, Kuwait,
Laos, Lebanon, Lesotho, Liberia, Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Morocco, Mozambique, Namibia, Nepal,
Netherlands Antilles, Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Qatar, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome
and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Solomon Islands, Somalia, South Africa, Sri Lanka,
Sudan, Suriname, Swaziland, Syria, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, UAE, Uganda,
Uruguay, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe; note— this category would presumably also
cover the following 46 other countries that are traditionally included in the more comprehensive group of "less
developed countries": American Samoa, Anguilla, British Virgin Islands, Brunei, Cayman Islands, Christmas Island,
Cocos Islands, Cook Islands, Cuba, Eritrea, Falkland Islands, French Guiana, French Polynesia, Gaza Strip,
Gibraltar, Greenland, Grenada, Guadeloupe, Guam, Guernsey, Isle of Man, Jersey, North Korea, Macau,
Martinique, Mayotte, Montserrat, Nauru, New Caledonia, Niue, Norfolk Island, Northern Mariana Islands, Palau,
Pitcairn Islands, Puerto Rico, Reunion, Saint Helena, Saint Pierre and Miquelon, Tokelau, Tonga, Turks and Caicos
Islands, Tuvalu, Virgin Islands, Wallis and Futuna, West Bank, Western Sahara
members— (12) Austria, Belgium, Finland, France, Germany, Greece, Ireland, Italy, Luxembourg, Netherlands,
Portugal, Spain
638
Appendix B: International Organizations and Groups (continued)
Economic and Social Council (ECOSOC)
members— (54) selected on a rotating basis from all regions
established- 26 June 1945
effective— 24 October 1945
aim— to coordinate the economic and social
work of the UN; includes five regional
commissions (Economic Commission for Africa,
Economic Commission for Europe, Economic
Commission for Latin America and the
Caribbean, Economic and Social Commission
for Asia and the Pacific, Economic and Social
Commission for Western Asia) and nine
functional commissions (Commission for Social
Development, Commission on Human Rights,
Commission on Narcotic Drugs, Commission on
the Status of Women, Commission on
Population and Development, Statistical
Commission, Commission on Science and
Technology for Development, Commission on
Sustainable Development, and Commission on
Crime Prevention and Criminal Justice)
Economic Community of West African States
(ECOWAS)
established— 28 May 1975
aim— to promote regional economic cooperation
members— (15) Benin, Burkina Faso, Cape Verde, Cote d''lvoire, The Gambia, Ghana, Guinea, Guinea-Bissau,
Liberia, Mali, Niger, Nigeria, Senegal, Sierra Leone, Togo
Euro-Atlantic Partnership Council (EAPC)
note— began as the North Atlantic Cooperation
Council (NACC); an extension of NATO
established— 8 November 1991
effective— 20 December 1991
aim— to discuss cooperation on mutual political
and security issues
members— (46) Albania, Armenia, Austria, Azerbaijan, Belarus, Belgium, Bulgaria, Canada, Croatia, Czech
Republic, Denmark, Estonia, Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Ireland. Italy,
Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Luxembourg, Macedonia, Moldova, Netherlands, Norway, Poland,
Portugal, Romania, Russia, Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan, Turkey, Turkmenistan,
Ukraine, UK, US, Uzbekistan
European Bank for Reconstruction and
Development (EBRD)
established— 8-9 January 1990 (proposals
made); 15 April 1991 (bank inaugurated)
aim— to facilitate the transition of seven centrally
planned economies in Europe (Bulgaria, former
Czechoslovakia, Hungary, Poland, Romania,
former USSR, and former Yugoslavia) to market
economies by committing 60% of its loans to
privatization
members— (62) Albania, Armenia, Australia, Austria, Azerbaijan, Belarus, Belgium, Bosnia and Herzegovina,
Bulgaria, Canada, Croatia, Cyprus, Czech Republic, Denmark, Egypt, EU, European Investment Bank (EIB),
Estonia, Finland, France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Israel, Italy, Japan, Kazakhstan,
South Korea, Kyrgyzstan, Latvia, Liechtenstein, Lithuania, Luxembourg, Macedonia, Malta, Mexico, Moldova,
Mongolia, Morocco, Netherlands, NZ, Norway, Poland, Portugal, Romania, Russia, Serbia and Montenegro,
Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan, Turkey, Turkmenistan, Ukraine, UK, US, Uzbekistan
European Community (or European
Communities, EC)
established 8 April 1965 to integrate the European Atomic Energy Community (Euratom), the European Coal and
Steel Community (ECSC), the European Economic Community (EEC or Common Market), and to establish a
completely integrated common market and an eventual federation of Europe; merged into the European Union (EU)
on 7 February 1992; member states at the time of merger were Belgium, Denmark, France, Germany, Greece,
Ireland, Italy, Luxembourg, Netherlands, Portugal, Spain, UK
European Free Trade Association (EFTA)
established— 4 January 1960
effective— 3 May 1960
aim— to promote expansion of free trade
members— (4) Iceland, Liechtenstein, Norway, Switzerland
639
Appendix B: International Organizations and Groups (continued)
European Investment Bank (EIB)
established— -25 March 1957
effective— 1 January 1958
aim— to promote economic development of the
EU and its predecessors, the EEC and the EC
members— (25) Austria, Belgium, Cyprus, Czech Republic, Denmark, Estonia, Finland, France, Germany, Greece,
Hungary, Ireland, Italy, Latvia, Lithuania, Luxembourg, Malta, Netherlands, Poland, Portugal, Slovakia, Slovenia,
Spain, Sweden, UK
European Organization for Nuclear Research
(CERN)
note— acronym retained from the predecessor
organization Conseil Europeenne pour la
Recherche Nucleaire
established July 1953
effective— 29 September 1954
aim— to foster nuclear research for peaceful
purposes only
members— (20) Austria, Belgium, Bulgaria, Czech Republic, Denmark, Finland, France, Germany, Greece,
Hungary, Italy, Netherlands, Norway, Poland, Portugal, Slovakia, Spain, Sweden, Switzerland, UK
observers— (8) European Commission, India, Israel, Japan, Russia, Turkey, United Nations Educational, Scientific,
and Cultural Organization (UNESCO), US
European Space Agency (ESA)
established— -31 May 1975
aim— to promote peaceful cooperation in space
research and technology
members— (17) Austria, Belgium, Denmark, Finland, France, Germany, Greece, Ireland, Italy, Luxembourg,
Netherlands, Norway, Portugal, Spain, Sweden, Switzerland, UK
cooperating states— (3) Canada, Czech Republic, Hungary
European Union (EU)
note— see European Union entry at the end of the "country" listings
First World another term for countries with advanced, industrialized economies; this term is fading from use; see developed
countries (DCs)
Food and Agriculture Organization (FAO)
established— 16 October 1945
aim— to raise living standards and increase
availability of agricultural products; a UN
specialized agency
members— (187) includes all UN member countries except Andorra, Belarus, Brunei, Liechtenstein, Russia, and
Singapore (185 total); plus Cook Islands and Niue
former Soviet Union (FSU)
former USSR/Eastern Europe
(former USSR/EE)
Four Dragons
Franc Zone (FZ)
note— also known as Conference des Ministres
des Finances des Pays de la Zone Franc
esfab//shed-1 964
aim— to form a monetary union among countries
whose currencies were linked to the French
franc
former term often used to identify as a group the successor nations to the Soviet Union or USSR; this group of 15
countries consists of: Armenia, Azerbaijan, Belarus, Estonia, Georgia, Kazakhstan, Kyrgyzstan, Latvia, Lithuania,
Moldova, Russia, Tajikistan, Turkmenistan, Ukraine, Uzbekistan
the middle group in the hierarchy of developed countries (DCs), former USSR/Eastern Europe (former USSR/EE),
and less developed countries (LDCs); these countries are in political and economic transition and may well be
grouped differently in the near future; this group of 27 countries consists of: Albania, Armenia, Azerbaijan, Belarus,
Bosnia and Herzegovina, Bulgaria, Croatia, Czech Republic, Estonia, Georgia, Hungary, Kazakhstan, Kyrgyzstan,
Latvia, Lithuania, Macedonia, Moldova, Poland, Romania, Russia. Slovakia, Slovenia, Tajikistan, Turkmenistan,
Ukraine, Uzbekistan, Yugoslavia; this group is identical to the IMF group "countries in transition" except for the IMF''s
inclusion of Mongolia
the four small Asian less developed countries (LDCs) that have experienced unusually rapid economic growth; also
known as the Four Tigers; this group consists of Hong Kong, South Korea, Singapore, Taiwan; these countries are
included in the IMF''s "advanced economies" group
members— (16) Benin, Burkina Faso, Cameroon, Central African Republic, Chad, Comoros, Republic of the Congo,
Cote d''lvoire, Equatorial Guinea, France, Gabon, Guinea-Bissau, Mali, Niger, Senegal, Togo
640
Appendix B: International Organizations and Groups (continued)
Group of 5 (G-5)
established— 22 September 1985
aim— to coordinate the economic policies of five
major noncommunist economic powers
members— (5) France, Germany, Japan, UK, US
Group of 7 (G-7)
note— membership is the same as the Big Seven
established— 22 September 1985
aim— to facilitate economic cooperation among
the seven major noncommunist economic
powers
members— (7) Group of 5 (France, Germany, Japan, UK, US) plus Canada and Italy
Group of 8 (G-8)
established— October 1 975
aim— to facilitate economic cooperation among
the developed countries (DCs) that participated
in the Conference on International Economic
Cooperation (CIEC), held in several sessions
between December 1975 and 3 June 1977
members— {8) Canada, France, Germany, Italy, Japan, Russia, UK, US
Group of 11 (G-11)
note— also known as the Cartagena Group
established in 21-22 June 1984, in Cartagena, Colombia, aim was to provide a forum for largest debtor nations in
Latin America; members were: Argentina, Bolivia, Brazil, Chile, Colombia, Dominican Republic, Ecuador, Mexico,
Peru, Uruguay, Venezuela
Group of 15 (G-1 5)
note— byproduct of the Nonaligned Movement;
name persists despite increased membership
established— September 1989
aim— to promote economic cooperation among
developing nations; to act as the main political
organ for the Nonaligned Movement
members— (19) Algeria, Argentina, Brazil, Chile, Colombia, Egypt, India, Indonesia, Iran, Jamaica, Kenya, Malaysia,
Mexico, Nigeria, Peru, Senegal, Sri Lanka, Venezuela, Zimbabwe
Group of 77 (G-77)
esfaWis/ied-15 June1964; October 1967 first
ministerial meeting
aim— to promote economic cooperation among
developing countries; name persists in spite of
increased membership
members— (131 plus the Palestine Liberation Organization) Afghanistan, Algeria, Angola, Antigua and Barbuda,
Argentina, The Bahamas, Bahrain, Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Brunei, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Costa
Rica, Cote d''lvoire, Cuba, Djibouti, Dominica, Dominican Republic, East Timor, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Ethiopia, Fiji, Gabon, The Gambia, Ghana, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, India, Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya, North Korea, Kuwait,
Laos, Lebanon, Lesotho, Liberia, Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Marshall Islands,
Mauritania, Mauritius, Federated States of Micronesia, Mongolia, Morocco, Mozambique, Namibia, Nepal,
Nicaragua, Niger, Nigeria, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Qatar,
Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome and
Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore, Solomon Islands, Somalia, South Africa, Sri
Lanka, Sudan, Suriname, Swaziland, Syria, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkmenistan, Uganda, UAE, Uruguay, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe, Palestine
Liberation Organization
Gulf Cooperation Council (GCC)
note— also known as the Cooperation Council
for the Arab States of the Gulf
established— 25 May 1981
aim— to promote regional cooperation in
economic, social, political, and military affairs
members— (Q) Bahrain, Kuwait, Oman, Qatar, Saudi Arabia, UAE
641
Appendix B: International Organizations and Groups (continued)
LU
LU
LUX
442
lu
Macau
MC
MO
MAC
446
.mo
Macedonia
MK
MK
MKD
807
,mk
49 45N
610E
Luzon (island)','304013a2d8236d184dc04c01f41127de452cdbd2ed7244fb7e1e687ff8929176','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12bf3ced79cad8ecb91488dc4a0f2ad8c361fb82dceb4f4f663c21fbaa886460',2007,'MG','Madagascar','transnational-issues',850,'■
MA
MG
MDG
450
.mg
Antigua (island)
20 00S
47 00E
Maddalena, Isola
20 00S
47 00E
Malay Archipelago
Brunei, Indonesia, Malaysia, Papua New Guinea,','39577191a8abf7f2d4945371c64c7463badc0924578a998c4547f206e7f650e4','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('335aaa5d53c28e26450a2afaf9f6ad0d266d3acd9f303b59b6c0dac61e29634e',2007,'MW','Malawi','transnational-issues',852,'(Karonga" \\ TANZANIA
V.Chilumba. /
ZAMBIA / M2uzu \\
NkhataBay* j ~^ \\.
/ ChtSumulu Island
1 "7>to (MALAWI)
\\ Ukoma Island
\\^ \\ (MALAWI)
V, Nkhotakota.
7 I MOZAMBIQUE
S. LILONGWE \\
J^S * Chipoka* , \\
^*^*^ \\ Monkey \\
-^"^ \\ Bay \\
V-^\\ \\
) Zomba \\
MOZAMBIQUE / * j
J ^lantyre
\\. Sapitwa j
^k *\\ I
ZIMB. \\ C_j
0 50km
t 0 50 mi
Disputes - international: disputes with Tanzania
over the boundary in Lake Nyasa (Lake Malawi) and
the meandering Songwe River remain dormant
346
Ml
MW
MWI
454
.mw
British East Africa (former name for British
possessions in eastern Africa)
Kenya, Tanzania, Uganda
British Guiana (former name for Guyana)
13 59S
33 44E
Lima (capital)
Nyassa (region)','3fbfd4ca21a44493288c31b19046d521c64a8d9284c2519cabf7c5a75b84d81f','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('210edb0a874985deae9d66a21722dd666b690650bb08bb3e2ac1dc1414220d6d',2007,'PH','Philippines','transnational-issues',861,'Kudat.
Kota Gunimg
Kmabalu '' AKmabaty
Sandakart*
Sabah
Lahad Datu • ''
Tawau
Klang* .Seremban
•Port Dickson
*Melaka Johor
Bahru
j*1
RP
PH
PHL
608
•pn
Pitcairn Islands
PC
PN
PCN
612
.pn
19 10 N
121 40 E
Baffin Bay
Arctic Ocean
73 00N
66 00W
Baffin Island
19 55N
122 10 E
Balkan Peninsula
Albania, Bosnia and Herzegovina, Bulgaria,
Croatia, Greece, Macedonia, Romania, Serbia •
and Montenegro, Slovenia, Turkey (European part)
42 00N
23 00E
Balleny Islands
20 30N
121 50 E
Bavaria (region; also Bayern)
Finland, Gulf of
Atlantic Ocean
Flores (island)
South Korea
Pacific Ocean
16 00N
121 00 E
Luzon Strait
Pacific Ocean
20 30N
121 00 E
Lyakhov Islands
Russia
73 45N
138 00 E
2 30N
120 00 E
Malay Peninsula
Malaysia, Thailand
710N
100 35 E
Male (capital)
14 35N
121 00 E
Manipa Strait
Pacific Ocean
3 20S
127 23 E
Mannar, Gulf of
Indian Ocean
8 30N
79 00E
Manua Islands
8 00N
125 00 E
Mindanao Sea
Pacific Ocean
915N
124 30 E
Mindoro (island)
12 50N
121 05 E
Mindoro Strait
Pacific Ocean
12 20N
120 40 E
Mingrelia (region)
15 08N
120 21 E
Mozambique Channel
Indian Ocean
19 00S
41 00 E
Muritaniyah (local name for Mauritania)
10 00N
123 00 E
Nejd (region)
9 30N
Palermo (city)
13 00N
122 00 E
Pinatubo, Mount (volcano)
15 08N
120 21 E
Pines, Isle of (island; former name for Isla de la Juventud)
12 00N
125 00 E
Samaria (region)
West Bank
3215N
3510E
Samoa Islands
American Samoa, Samoa
14 00S
171 00 W
Samos (island)
6 00N
121 00 E
Sulu Sea
Pacific Ocean
8 00N
120 00 E
Sumatra (island)','ecb5f3b466ab4454aea5e64eaa7231057070c376089a5856865b1f124360f13d','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('62f61d0dcc5a96f702e3c3dba726b56b2f2edca09b5fd74b8b87db8eb026b0d5',2007,'SG','Singapore','transnational-issues',862,'KEPUIAUAN
ANAMBAS
IINOONESIA)
I Bedok
■ it
town "^SINGAPORE
fl?/port
£ (\\s 103 50 «" ^^•r 10400 Pu,»u Bat3m
Mam Sfra/f
SN
SG
SGP
702
•sg
1 17N
Pacific Ocean
1 15N','d7f136ff01c26be4a875048a909484d4f274c38babbb094293a1076363bd9cd1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('07b0499f5e4e5998e48987f8fa5cd9dfef79c33f4bb7c6da8c4bf901b040cfda',2007,'MV','Maldives','transnational-issues',863,'Arabian
Sea
°
• ''m Male Atoll
*MALE
C Sea
Laccadive
Addu Atoll
^Gan
Disputes • international: none
Refugees and internally displaced persons:
IDPs: 1 1 ,000 (December 2004 tsunami victims)
(2005)
Background: The Sudanese Republic and Senegal
became independent of France in 1960 as the Mali
Federation. When Senegal withdrew after only a few
months, what formerly made up the Sudanese
Republic was renamed Mali. Rule by dictatorship was
brought to a close in 1991 by a coup that ushered in
democratic government. President Alpha KONARE
won Mali''s first democratic presidential election in
1 992 and was reelected in 1 997. In keeping with Mali''s
two-term constitutional limit, KONARE stepped down
in 2002 and was succeeded by Amadou TOURE.
Disputes - international: none
Refugees and internally displaced persons:
refugees (country of origin): 6,185 (Mauritania)
(2005)
MV
MV
MDV
462
.mv
315N
73 00E
Dhofar (region)
410N
73 31 E
Mallorca, Isla de (island; also Majorca)','5304c4365ca9cc546f50c5017e3ec388175b68941dd208315c4153efca04eb64','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e4de48ded4f7dd065731398e83063b910576aa0015e3d53ebc88163830a16e2',2007,'MT','Malta','transnational-issues',872,'a
Mediterranean
Sea
Mediterranean
Sea
Filtla
Disputes - international: none
Illicit drugs: minor transshipment point for hashish
from North Africa to Western Europe
It
MT
MT
MLT
470
.mt
35 54N
14 31 E
Valley, The (capital)','b621bfa8e0c18b12399b91f5582dcfe79d029adbf6446f0dbd081638602fc4a6','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9dcb43cab380ad52eeca314270f713fc5edf0a2d4be10d4ffdf6291c7b192a3e',2007,'MH','Marshall Islands','transnational-issues',881,'NORTH PACIFIC OCEAN
U/elang
E''^Ae-3-
War
Bikini ~%
Aitmgmae Rongelap TaAa
s>
u>ae\\ !q
10 Ukiep ^ ~ »
"" -^ Ebeye
Namu\\
Ajltnglapalap*
Me/it
Island
Matoe/ap
QAur
Ua/ruo ^Amo
MAJURO ~
FEDERATED STATES
OF MICRONESIA
Kosrae
100 200 km
Jafaifjv
Namon** Kill
\\bon
Knot
Disputes • international: claims US territory of
Wake Island
RM
MH
MHL
584
.mh
11 35 N
165 23 E
Bilbao (city)
11 30 N
162 15 E
England (region)
11 30 N
162 15 E
Eolie, Isole (island group)
7 05N
171 08 E
Makassar Strait
Pacific Ocean
2 00S
11730E
Makedonija (local name for Macedonia)
Macedonia
4150N
22 00E
Malabo (capital)
Rangoon (capital; also Yangon)
Burma
Rapa Nui (Easter Island)
Red Sea
Indian Ocean
Redonda (island)','72a11127cd5f35eee76b2598b37fcab4f4ec1b018cb0ba6d3dd4102b15b5b83f','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3779fdf235956fdd11659fadb598e47163d8ed39da6d8b4b5e98eaacc9b75f71',2007,'MR','Mauritania','transnational-issues',900,'Disputes - international: Mauritanian claims to
Western Sahara have been dormant in recent years
362
0 100 2O0km
100
Disputes - international: Morocco claims and
administers Western Sahara, whose sovereignty
remains unresolved; UN-administered cease-fire has
remained in effect since September 1991 ,
administered by the UN Mission for the Referendum in
Western Sahara (MINURSO), but attempts to hold a
relerendum have failed and parties thus far have
rejected all brokered proposals
MR
MR
MRT
478
.mr
20 00N
12 00W
Mazatlan (city)
20 00N
12 00W
Musandam Peninsula
Oman, United Arab Emirates
2618N
56 24E
Muscat (capital)
Noumea (capital)','40c998237097cf43e00f63856abcba0f84840d8277709dc5b4eb2c326f256ce1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c0ae3fe072280faf68af7c0b44acaff7b598c92f111080906fb0965a88e4dcf',2007,'MU','Mauritius','transnational-issues',901,'Caraios Shoali. and
Rodngucs are not ihowtv
.Goodityids
5mi / ''Triolet
Indian Ocean v
2.5 5 Km
PORT LOUIS
Centre*
de Flacq
Quatre Bornes
.Curepipe
Mahebourg\\ o }
. Souillac
Indian
Ocean
Disputes - international: Mauritius claims the
Chagos Archipelago (UK-administered British Indian
Ocean Territory), and its former inhabitants, who
reside chiefly in Mauritius, were granted UK
citizenship but no right to patriation in the UK; claims
French-administered Tromelin Island
Illicit drugs: minor consumer and transshipment
point for heroin from South Asia; small amounts of
cannabis produced and consumed locally; significant
offshore financial industry creates potential for money
laundering, but corruption levels are relatively low and
the government appears generally to be committed to
regulating its banking industry
MP
MU
MUS
480
.mu
10 25S
56 40E
Agana (city; former name for Hagatna)
16 25S
59 38E
Caribbean Sea
Atlantic Ocean
15 00N
73 00W
Caroline Islands
Federated States of Micronesia, Palau
7 30N
148 00 E
Carpatho-Ukraine (region; former name for
Zakarpats''ka oblast'')
20 10S
57 30E
Port Moresby (capital)
19 42S
63 25E
Rome (capital)
16 25S
Saint Christopher (island)','a48229fff411f8ad7395db006527ff7381d47228f8aadbf680c92958ed7cdbf8','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6f124d864c13c46cafe8d2d64ae3e5c2544c1a0b756dec1f50f5c1276f965f5',2007,'PG','Papua New Guinea','transnational-issues',915,'SOLOMON
ISLANDS
■
Disputes - international: organized illegal narcotics
operations in Colombia operate within the border
region with Panama
Illicit drugs: major cocaine transshipment point and
primary money-laundering center for narcotics
revenue; money-laundering activity is especially
heavy in the Colon Free Zone; offshore financial
center; negligible signs of coca cultivation; monitoring
of financial transactions is improving; official
corruption remains a major problem
0 100 200 300 km
NORTH PACIFIC O 100 200 300 mi
OCEAN
SOUTH
__.-■''''• ''• PACIFIC
INDONESIA .tZ>i
7*1
-<**. . OCEAN
^^_ - New
Wewak" - Bismarck Sea Rabau, "^nd
K &"*!g, J New
Mount* A-G^ Bn,am ">eX\\
Hagen » Bougainville
<
New
GUlZ, PORT S%T fc
Daru. MORESBY _ solouon
^ • ''5LAHOS
v.-
Coral Sea
PP
PG
PNG
598
•pg
Paracel Islands
PF
—
—
—
—
210S
147 00 E
Adriatic Sea
Atlantic Ocean
42 30N
16 00E
Adygey (region)
Russia
44 30N
4010E
Aegean Islands
5 00S
150 00 E
Bismarck Sea
Pacific Ocean
4 00S
148 00 E
Bissau (capital)
6 00S
155 00 E
Bougainville Strait
Pacific Ocean
6 40S
156 10 E
Bounty Islands
9 30S
150 40 E
Desolation Islands (Isles Kerguelen)
French Southern and Antarctic Lands
49 30S
69 30E
Deutschland (local name for Germany)
4 30S
154 10 E
Greenland Sea
Arctic Ocean
79 00N
5 00W
Grenadines, Northern (island group)
1100S
153 00 E
Lourenco Marques (city: former name for Maputo)
6 00S
150 00 E
New Delhi (capital)
3 20N
152 00 E
New Siberian Islands
Russia
75 00N
142 00 E
New Territories (mainland region)
9 30S
147 10 E
Port-au-Prince (capital)
6 00S
155 00 E
Solomon Islands, southern
8 38S
151 04 E
Trucial Coast (former name for the United Arab Emirates)','a4dfaeefedbe4b25daaf00887716f4ac0474d9fd2891e7376137b9a22f050bb8','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0ca90f9fd07c377a419859d4302f95e6d3f40f16d6d2f8e485ea2493b88dbcd',2007,'MC','Monaco','transnational-issues',926,'Disputes • international: none
376
MN
MC
MCO
492
.mc
43 44N
7 25E
Mongol Uls (local name for Mongolia)','f16183bc79d5194b4dab95155e5563bc2b9bae0d917e481c881f227cadb322db','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2815beb5863b8cc17a4b82d945a1feef90fc109ef66bc80217905b62885adb9c',2007,'MN','Mongolia','transnational-issues',927,'7
1
^ — "^T^
RUSSIA k
*-*W^. UlaangorrP-^v
t Orgil
\\ ''CHgiy
Erdenet
. V^__ ^^ H0"Nu* / CHINA
Darhan fc /
^-\\. .Hovd
Bulgan#
Choybalsan / /""^-v
f\\
#Uliastay
^ULAANBAATAR ^^ ^\\
)<
Altay#
y
^Bayanhongor
Saynshand / V, r
U1
MG
MN
MNG
496
.mn
46 00N
105 00 E
Monrovia (capital)
2130N
0 52S
28 25N
47 20N
7 00N
6 00S
53 00N
26 30N
56 45N
24 30N
8 30S
35 43N
28 20S
12 33N
55 50N
59 00N
59 55N
3100N
40 00N
45 25N
12 22N
57 45N
46 00N
158 00 W
169 35 E
178 20 W
13 20E
46 00E
71 30 E
150 00 E
128 00 E
16 40E
58 30E
125 00 E
0 43W
26 40E
70 06W
12 40E
3 00W
10 45E
131 00 E
19 00E
75 40W
1 31 W
7 00W
105 00 E
Pacific Islands, Trust Territory of the (former name of a large
area of the western North Pacific Ocean)
Marshall Islands. Federated States of Micronesia,
Northern Mariana Islands, Palau
10 00N
Pagan (island)
47 55N
Ullung-do (island)
South Korea
37 29 N
Ulster (region)
Ireland, United Kingdom
54 35N
Uman (local name for Oman)
Unimak Pass (strait)','96b7d1dbaa5d984b17c18bc05025a6db9772373f3735b94aaf6cb4bccd1bf3a9','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d7397c5acf1d037efaaf17c0ea80cccd8366570ac519926c874c4f6c02ddc5b',2007,'MA','Morocco','transnational-issues',929,'Disputes • international: none
PORTA ,
Laayoune
(El Aaiiin)
.Semara
MO
MA
MAR
504
.ma
32 00N
5 00W
Al Urdun (local name for Jordan)
5 33S
16 00N
47 20N
21 56 N
30 03 N
28 00N
6 00N
52 33S
20 00N
9 00N
28 00N
28 00N
35 17S
21 10 N
23 06N
2 49S
27 53N
12 12 E
24 00W
59 30W
71 58 W
31 15 E
11200W
12 00E
169 09 E
94 00W
79 45W
16 00W
15 30W
149 08 E
86 50W
113 16 E
171 40 W
12 58W
683
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Cape of Good Hope (cape; also alternate name for
Cape Province of South Africa)
32 00N
5 00W
French Somaliland (former name for Djibouti)
29 22N
10 09W
Inaccessible Island
Saint Helena
37 17S
12 40W
Indochina (region)
Cambodia, Laos, Vietnam
15 00N
107 00 E
Ingushetia (region)
Russia
4315N
45 00E
Inhambane (region)
32 00N
5 00W
Magyarorszag (local name for Hungary)
Ralik Chain (island group)
32 00N
7 00W
Spanish North Africa (exclaves)
Spain (Ceuta. Islas Chafarinas, Melilla, Penon de
Alhucemas, Penon de Velez de la Gomera)
3515N
4 00W
Spanish Sahara (former name)
Tannu-Tuva (region)
Russia
Tarawa (island)','1be6e9f200668346ac4d5a0b36849055221b2e06004db9e03182b71a527fa153','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('799ab93e64e1dcc834a0796bf2934c85e1537510f589cb25028cd7bc6f2a5bee',2007,'MS','Montserrat','transnational-issues',930,'(overseas territory
of the UK)
O 1 2 km
O 1 2 mi
Davy Hill .Gerald''s
Sainl
John''s
\\bean
Northern Zom
#Salem
Exclusion Zone ''
Soufnare Hills
Volcano
PLYMOUTH *
* (abandoned/ AChances
Peak
Disputes - international: none
Illicit drugs: transshipment point for South American
narcotics destined for the US and Europe
MH
MS
MSR
500
.ms
16 44N
62 14W
Polska (local name)','fbe7c8483de7c5cdcd3787250f4590985331cb6ba2b58596546a0f0bb441c7aa','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f11593798219f8e0a987e298b07d021f24549be8875170917917ed6a054717a5',2007,'NR','Nauru','transnational-issues',941,'Oc,
phosphate
-^stockpile
— phosphate
facilities
— ■ : ioon
\\* Nauru
Xv International
A^ Airport
Parliament ^
House, in
Yaren District l km
O 0.5 1 m
/
Disputes - international: none
Navassa Island
(territory of the US)
O 5 1km
MorfhwMf
Pn.n:
Northeast
Point
ttghthouso
East
Point
elevation
s
NR
NR
NRU
520
.nr
Navassa Island
BQ
—
—
—
—
ISO includes with the US Minor
Outlying Islands
0 32S
166 55 E
Plymouth (capital)
Yekaterinburg (city; former name for Sverdlovsk)
Russia
Yellow Sea
Pacific Ocean
Yemen Arab Republic (also Yemen (Sanaa);
former name for northern portion of Yemen)','13eaf70771f5949a5c0b5a9923247c59c0886e771f9d90b2de7d80d1fa1b9bce','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d12985feb6435ac7e9d76a0de6f0c1ba28866b9f474f5ae6b19a17febe74d9cd',2007,'NP','Nepal','transnational-issues',953,'Disputes - international: claimed by Haiti, source of
subsistence fishing
Background: In 1951, the Nepalese monarch ended
the century-old system of rule by hereditary premiers and
instituted a cabinet system of government. Reforms in
1990 established a multiparty democracy within the
framework of a constitutional monarchy. A Maoist
insurgency, launched in 1996, has gained traction and is
threatening to bring down the regime, especially after a
negotiated cease-fire between the Maoists and
government forces broke down in August 2003. In 2001 .
the crown prince massacred ten members of the royal
family, including the king and queen, and then took his
own life. In October 2002, the new king dismissed the
prime minister and his cabinet for "incompetence" after
they dissolved the parliament and were subsequently
unable to hold elections because of the ongoing
insurgency. While stopping short of reestablishing
parliament, the king in June 2004 reinstated the most
recently elected prime minister who formed a four-party
coalition government. Citing dissatisfaction with the
governments lack of progress in addressing the Maoist
insurgency and corruption, the king in February 2005
dissolved the government, declared a state of
emergency, imprisoned party leaders, and assumed
power. The King''s government subsequently released
party leaders and officially ended the state of emergency
in May 2005.
Disputes - international: joint border commission
continues to work on small disputed sections of
boundary with India; India has instituted a stricter
border regime to restrict transit of Maoist insurgents
and illegal cross-border activities
Refugees and internally displaced persons:
refugees (country of origin): 104,915 (Bhutan)
IDPs: 100,000-200,000 (ongoing conflict between
government forces and Maoist rebels; displacement
spread across the country) (2005)
Illicit drugs: illicit producer of cannabis and hashish
for the domestic and international drug markets;
transit point for opiates from Southeast Asia to the
West
394
Disputes - international: none
Illicit drugs: major European producer of ecstasy,
illicit amphetamines, and other synthetic drugs;
important gateway for cocaine, heroin, and hashish
entering Europe; major source of US-bound ecstasy;
large financial sector vulnerable to money laundering
NP
NP
NPL
524
.np
27 43N
85 19E
Kattegat (strait)
Atlantic Ocean
57 00N
11 00 E
Kauai Channel
Pacific Ocean
2145N
158 50 W
Kazakstan (former name for Kazakhstan)','d22421334b28522c2ebc15748f1d504bebc4db4d66ceff81995fb86904057c51','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d16399d1938823866b795505eec58c913b2db64e3930bf555056d672043c236e',2007,'NC','New Caledonia','transnational-issues',961,'(overseas territory
of France)
II
o so lookm Elate
0 50
100 mi
NC
NC
NCL
540
.nc
673
Appendix D: Cross-Reference List of Country Data Codes (continued)
Entity FIPS10-4 ISO 3166
Internet
I
Comment '' E
Democratic Republic of the Congo
19 52S
158 15 E
Chihli, Gulf of (see Bo Hai)
Pacific Ocean
38 30N
120 00 E
Chiloe (island)
2100S
167 00 E
Luanda (capital)
Nouvelle-Caledonie (local name for New Caledonia)
Nouvelles Hebrides (former name for Vanuatu)','bfe67c41f1d76176390f4f9c1832fa559fe4f03f1b291c7077ad73e56b9ea82a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82dba9ccee8fda8ade2bc99a2c27cd9957b1c12b71584ae1d5d209076bb7fb1e',2007,'VU','Vanuatu','transnational-issues',962,'Coral Sea L .
'' Vv ^-v
lies
«*
• ^omdimie w6« Loyaute
Mueb''
New" X^Thio.X
Caledonia s
South
Pacific
Ocean
NOUMEA* fodesRhs
Cora/ Sea
ite Hucn anc lies Ctederi 1 d
arc not shown
401
I n t r o d u c t i o
Background: The UK established a protectorate over
the Solomon Islands in the 1 890s. Some of the bitterest
fighting of World War II occurred on these islands.
Self-government was achieved in 1976 and
independence two years later. Ethnic violence,
government malfeasance, and endemic crime have
undermined stability and civil society. In June 2003,
Prime Minister Sir Allen KEMAKEZA sought the
assistance of Australia in reestablishing law and order;
the following month, an Australian-led multinational
force arrived to restore peace and disarm ethnic militias.
The Regional Assistance Mission to the Solomon
Islands (RAMSI) has been very effective in restoring
law and order and rebuilding government institutions.
Disputes - international: Australian Defense Force
leads the Regional Assistance Mission to the Solomon
Islands (RAMSI) at the invitation of the Solomon
Islands'' Government to maintain civil and political
order and reinforce regional security
507
Disputes - international: Matthew and Hunter
Islands east of New Caledonia claimed by Vanuatu
and France
Venezuela
Disputes - international: claims all of the area west
of the Essequibo River in Guyana, preventing any
discussion of a maritime boundary; Guyana has
expressed its intention to join Barbados in asserting
claims before the United Nations Convention on the
Law of the Sea (UNCLOS) that Trinidad and Tobago''s
maritime boundary with Venezuela extends into their
waters; dispute with Colombia over Los Monjes
islands and maritime boundary near the Gulf of
Venezuela; Colombian-organized illegal narcotics and
paramilitary activities penetrate Venezuela''s shared
border region resulting in several thousand residents
migrating away from the border; US, France, and the
Netherlands recognize Venezuela''s claim to give full
effect to Aves Island, which creates a Venezuelan
EEZ/continental shelf extending over a large portion of
the Caribbean Sea; Dominica, Saint Kitts and Nevis,
Saint Lucia, and Saint Vincent and the Grenadines
protest Venezuela''s claim that Aves Island sustains
human habitation and other states'' recognition of it
Illicit drugs: small-scale illicit producer of opium and
coca for the processing of opiates and coca
derivatives; however, large quantities of cocaine,
heroin, and marijuana transit the country from
Colombia bound for US and Europe; significant
narcotics-related money-laundering activity,
especially along the border with Colombia and on
Margarita Island; active eradication program primarily
targeting opium; increasing signs of drug-related
activities by Colombian insurgents on border
Vietnam
O SO 100 km
I '' — *—• <
O SO 100 ml
Nha Trang
Cam Ranh^
DaoPhu l-ongXuyei
Quoc Can
Gull Of
NH
vu
VUT
548
.vu
Venezuela
VE
VE
VEN
862
.ve
Vietnam
VM
VN
VNM
704
.vn
Virgin Islands
VQ
VI
VIR
850
.vi
675
Appendix D: Cross-Reference List of Country Data Codes (continued)
Entity
FIPS10-4
ISO 3166
Internet
Comment
World
Virgin Islands (UK)
—
—
—
—
■vg
see British Virgin Islands
Virgin Islands (US)
—
—
—
—
.vi
see Virgin Islands
Wake Island
WQ
—
—
—
—
ISO includes with the US Minor
Outlying Islands
14 00S
167 30 E
Barbuda (island)
16 00S
167 00 E
New Ireland (island)
Novaya Zemlya (islands)
Russia
Nubia (region)
Egypt. Sudan
Nukualofa (capital)
Poznan (city)','18bfb13f17322b03525cf95381d5735910a5ed9cfcc4eec0ca0f7dfef03adef6','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6a6a1a1cb4415296ecb9667b556b39c671b1c31a50de4de6d0d5ab5c7dd7eaaa',2007,'ML','Mali','transnational-issues',966,'Arlil
Agadez.
Idoukalone
jthlcuktl-m Ttgtm)
ML
ML
MU
466
.ml
12 39N
00 W
680
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Banaba (Ocean Island)
17 00N
4 00W
French Territory of the Afars and Issas (or FTAI; former
name for Djibouti)','2e2d92af3c90e49661b4e242dcae66d698fda754a3ac3efe9c022bef5f973881','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83382b6d2b938e4b284a3fdd9385f5e9ac48628db832a79ba06d085f374b1337',2007,'NE','Niger','transnational-issues',976,'Disputes - international: Libya claims about 25,000
sq km in a currently dormant dispute; much of
Benin-Niger boundary, including tripoint with Nigeria,
remains undemarcated; only Nigeria and Cameroon
have heeded the Lake Chad Commission''s
admonition to ratify the delimitation treaty which also
includes the Chad-Niger and Niger-Nigeria
boundaries
Disputes - international: ICJ ruled in 2002 on the
entire Cameroon-Nigeria land and maritime boundary
but the parties formed a Joint Border Commission to
resolve differences bilaterally and have commenced
with demarcation in less-contested sections of the
boundary, starting in Lake Chad in the north; Nigeria
initially rejected cession of the Bakassi Peninsula,
then agreed, but has yet to withdraw its forces while
much of the indigenous population opposes cession;
the ICJ ruled on an equidistance settlement of
Cameroon-Equatorial Guinea-Nigeria maritime
boundary in the Gulf of Guinea, but imprecisely
defined coordinates in the ICJ decision, the
unresolved Bakasi allocation, and a sovereignty
dispute between Equatorial Guinea and Cameroon
over an island at the mouth of the Ntem River all
contribute to the delay in implementation; a joint task
force was established in 2004 that resolved disputes
over and redrew the maritime and the 870-km land
boundary with Benin on the Okpara River; only Nigeria
and Cameroon have heeded the Lake Chad
Commission''s admonition to ratify the delimitation
treaty which also includes the Chad-Niger and
Niger-Nigeria boundaries
Refugees and internally displaced persons:
IDPs: 200,000 - 250,000 (communal violence
between Christians and Muslims since President
OBASANJO''s election in 1999) (2005)
Illicit drugs: a transit point for heroin and cocaine
intended for European, East Asian, and North
American markets; safehaven for Nigerian
narcotraffickers operating worldwide; major
money-laundering center; massive corruption and .
criminal activity; remains on Financial Action Task
Force Non-Cooperative Countries and Territories List
for continued failure to address deficiencies in
money-laundering control regime
1331 N
2 07E
Nicobar Islands','5c97972a426b76cae7ca73196228e0a24b27329b91272f5658026bcf23fb8792','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f1087ed34bceaee83c7168e590e68ae3ae268162cc290a41fe8a6dce55ef8c78',2007,'NU','Niue','transnational-issues',982,'(self-governing in free
association with
New Zealand)
reef
Disputes - international: none
NE
NU
NIU
570
.nu
19 01 S
169 55 W
Alphonse Island
19 02S
169 52 W
702
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Savu Sea
Pacific Ocean
9 30S
122 00 E
Saxony (region)','f328df0a8b57faa212248585aa3d4955de12aa6d907f15cf28cc5120424d89a5','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('757e7977442b83b12dbb914e0312126699019fa7566b82273014b4ba0f6684fc',2007,'NF','Norfolk Island','transnational-issues',991,'(territory of Australia)
O 2 4km
O 2 4 mi
;
Cascade
, Burnt Pine"^
I
Norfolk Island r
* KINGSTON
South
Pacific
Ocean
Nepean
Philip Island
NF
NF
NFK
574
.nf
29 03S
167 58 E
Kingstown (capital)
29 08S
167 57 E
Philippine Sea
Pacific Ocean
20 00N
134 00 E
Phnom Penh (capital)','8cfe2a159fa7b2b4c9b062d137ed15ada53e04ba91f96c485c5aee7d71a996c1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fca51902e7395d79b7d31d60bcd1e95d268ca8db38b2868de738a802349e6bdc',2007,'MP','Northern Mariana Islands','transnational-issues',1003,'Disputes - international: none
417
CQ
MP
MNP
580
.mp
■
19 40N
145 24 E
Atacama (desert)
18 08N
Pago Pago (capital)
14 10 N
145 12 E
Rotuma (island)
15 12 N
145 45 E
Sak''art''velo (local name for Georgia)
15 00N
145 38 E
Tiran, Strait of
Indian Ocean
28 00N
34 27E
Tirana (capital)','4118f5c464016b0118615bc35f1e9ec95926716a6669e14cb3fb1372ac55cd03','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7288e873f380cad5422433f5a66f499bc8807d94a2bd51e1cfc154b8dfdc5f66',2007,'OM','Oman','transnational-issues',1012,'Disputes - international: boundary agreement
reportedly signed and ratified with UAE in 2003 for
entire border, including Oman''s Musandam Peninsula
and Al Madhah exclave, but details have not been
made public
Disputes - international: some maritime disputes
(see littoral states)
MU
OM
OMN
512
.om
17 00N
54 10E
Diego Garcia (island)
17 30N
56 00E
Khyber Pass
Afghanistan. Pakistan
34 05N
71 10 E
Kibris (Turkish local name for Cyprus)
23 37N
58 35E
Muscat and Oman (former name for Oman)
2100N
57 00E
Myanma, Myanmar
Burma
22 00N
98 00E
Nagorno-Karabakh (region)
2100N
Pacific Ocean
54 20N
Union of Soviet Socialist Republics or USSR (former
name of a large Eurasian empire, roughly coequal with
the former Russian Empire)
Armenia, Azerbaijan, Belarus, Estonia, Georgia,
Kazakhstan, Kyrgyzstan, Latvia, Lithuania,
Moldova, Russia, Tajikistan, Turkmenistan,
Ukraine, Uzbekistan
United Arab Republic or UAR (former name for a
federation between Egypt and Syria)
Egypt, Syria
Upper Volta (former name for Burkina Faso)','69a89e15f84a30fb79e39529b3a9b0defcc8a73922fc4ee19a848cebec6d2887','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('863f5cfe2807984133ee1bd307b23da7f354ecf54e5630ebc01f6ece9628973d',2007,'PK','Pakistan','transnational-issues',1013,'Background: The separation in 1 947 of British India
into the Muslim state of Pakistan (with two sections
West and East) and largely Hindu India was never
satisfactorily resolved, and India and Pakistan fought
two wars - in 1947-48 and 1965 - over the disputed
Kashmir territory. A third war between these countries
in 1971 - in which India capitalized on Islamabad''s
marginalization of Bengalis in Pakistani politics -
resulted in East Pakistan becoming the separate
nation of Bangladesh. In response to Indian nuclear
weapons testing, Pakistan conducted its own tests in
1998. The dispute over the state of Kashmir is
ongoing, but discussions and confidence-building
measures have led to decreased tensions since 2002.
Disputes - international: various talks and
confidence-building measures cautiously have begun
to defuse tensions over Kashmir, particularly since the
October 2005 earthquake in the region; Kashmir
nevertheless remains the site of the world''s largest
and most militarized territorial dispute with portions
under the de facto administration of China (Aksai
Chin), India (Jammu and Kashmir), and Pakistan
(Azad Kashmir and Northern Areas); UN Military
Observer Group in India and Pakistan (UNMOGIP)
has maintained a small group of peacekeepers since
1949; India does not recognize Pakistan''s ceding
historic Kashmir lands to China in 1964; in 2004, India
and Pakistan instituted a cease-fire in the Kashmir,
and in 2005 restored bus service across the highly
militarized Line of Control; Pakistan has taken its
dispute on the impact of India''s building the Baglihar
Dam on the Chenab River in Jammu and Kashmir to
the World Bank for arbitration and in general the two
states still dispute Indus River water sharing; to
defuse tensions and prepare discussions on a
maritime boundary, in 2004, India and Pakistan
resurveyed a portion of the disputed the Sir Creek
estuary at the mouth of the Rann of Kutch; Pakistani
maps continue to show the Junagadh claim in India''s
Gujarat State; by 2005, Pakistan, with UN assistance,
had repatriated 2.3 million Afghan refugees and had
undertaken a census to count the remaining million or
more, many of whom remain at their own choosing;
Pakistan has sent troops into remote tribal areas to
control the border with Afghanistan and stem
organized terrorist or other illegal cross-border
activities; regular meetings with Afghan and Coalition
allies aim to resolve periodic claims of boundary
encroachments
Refugees and internally displaced persons:
refugees (country ol origin): 960,041 (Afghanistan)
IDPs: undetermined (government strikes on Islamic
militants in South Waziristan); 3 million (October 2005
earthquake) (2005)
Illicit drugs: opium poppy cultivation declined 58%
to 3,147 hectares in 2005; federal and provincial
authorities continue to conduct anti-poppy campaigns
that force eradication - fines and arrests will take place
if the ban on poppy cultivation is not observed; key
transit point for Afghan drugs, including heroin, opium,
morphine, and hashish, bound for Western markets,
the Gulf States, and Africa; financial crimes related to
drug trafficking, terrorism, corruption, and smuggling
remain problems
PK
PK
PAK
586
•pk
34 30N
74 00E
Azarbaycan (local name for Azerbaijan)
28 00N
63 00E
Baltic Sea
Atlantic Ocean
57 00N
19 00E
Bamako (capital)
33 42N
7310E
Island (local name for Iceland)
West Siberian Plain
Russia
Western Channel (West Korea Strait)
Pacific Ocean
Western Samoa (former name for Samoa)','cd50741fbee0c0811f420f7a8c3fab73f795a6c0e9e49b89cc9b70b5fd4d4b69','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a31267726f7e380b94ea9eea55b57a52db0f554604276a92cb4e8f7531d6ca5',2007,'PW','Palau','transnational-issues',1021,'KAY ANGEL
ISLANDS
PALAU Mou">
ISLANDS ^c''chc«h™
+ Babelthuap
CHEL8ACHEB *KOROR
Philippine
Belillou
Angaur
SONSORAL
ISLANDS
NORTH
. Pulo Anna
PACIFIC
OCEAN
''Mem
Tobi Helen Reel
O
0
50 10Okm
50 100 mi
Disputes - international: border delineation
disputes being negotiated with Philippines, Indonesia
/
Palmyra Atoll
(territory of the US)
Description under
PS
PW
PLW
585
.pw
Palmyra Atoll
LQ
—
—
—
—
ISO includes with the US Minor
Outlying Islands
Serbia and Montenegro
Federated States of Micronesia
Port-Vila (capital)','6b935999b5bd3387831d577cc4dbecb1311dd1c4c4ded49870823bd0b303a044','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd58c95f050c43f4f0325981ce347d665802a7ad57c0f120d47453365dd557b8',2007,'PA','Panama','transnational-issues',1030,'XXr
Caribbean Sea
SEJ^v/ANAM* ^
/ . ''a,,, Bayano
Ganjn
Canal
Balboa
Vacamonte
Chitr6.
ARCHIPELAGO
DELAS
PERLAS
Gulf Of
isla del
Rey
Caba
PM
PA
PAN
591
■pa
Canarias Sea
Atlantic Ocean
Canary Islands
8 58N
Panama Canal
9 00N
155 00 E
145 47 E
170 42 W
11830E
1321 E
35 15E
158 08 E
79 45E
73 00E
63 00W
79 32W
79 45W
698
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Panama, Gulf of
Panay (island)
Pantellena, Isola di (island)
Papeefe (capital)
Paramaribo (capital)
Parece Vela (island)
Paris (capital)
Pascua, Isla de (Easter Island)
Pashtunistan (region)
Passion, He de la (island)
Patagonia (region)
Peking (see Beijing)
Pelagian Islands (Isole Pelagie)
Peleliu (Beliliou) (island)
Entry in The World Factbook
Pacific Ocean','293b522b95035079de4f131a88bb7908aab5a0384b510357131104df8def4187','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57d983c456ba35f96f55fefc649a071c972b0ceac261323734e009aa846c2b4e',2007,'QA','Qatar','transnational-issues',1048,'Persian Gulf
*
Ar Ru''a''
Vs.
Mfna''Saqri. ($_p~—
„ Musi Ra''sal , .
° Khaymatv I ''OMAN
Ummal y Lf
Qaywayn,^ ^^
/Ajman w* Khawr Fakkan
Dubai. Sharjah n*
/> omani .AlFuiayrah
MTna'' Jabal ''AIT
IRAN
— v-
Disputes - international: the United Arab Emirate
2006 Yearbook published a map and text rescinding
the 1974 boundary with Saudi Arabia, as stipulated in
a treaty filed with the UN in 1993, on the grounds that
the agreement was not formally ratified; boundary
agreement was signed and ratified with Oman in 2003
for entire border, including Oman''s Musandam
Peninsula and Al Madhah enclaves, but contents of
the agreement and maps showing the alignment have
not been published; Iran and UAE dispute Tunb
Islands and Abu Musa Island, which Iran occupies
Illicit drugs: the UAE is a drug transshipment point
for traffickers given its proximity to Southwest Asian
drug producing countries; the UAE''s position as a
major financial center makes it vulnerable to money
laundering; anti-money-laundering controls
improving, but informal banking remains unregulated
QA
QA
QAT
634
;qa
Reunion
RE
RE
REU
638
.re
25 17N
51 32 E
Donets Basin
Russia, Ukraine
4815N
38 30E
Douala (city)','63a7c006517156b0d5dd9680e13cf82c24384ca94db4e56ed59f4d93f36ac7be','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f437d30fbac0c0334b469601398ba5fb96c921db15a20f796ffba02f2ec0a13',2007,'SK','Slovakia','transnational-issues',1050,'r* „ UKRAINE
-«
>/\\-^ +^*j\\ ^^A 48~
"^ "^-^r \\ )
HUNG. /
%. \\ \\.
/bradea Cluj- ^ la?''\\ MOL.^
rj~S, Arad
^s • Targu- • J f>v£»
Mure§ S
\\ .Timi§oara .Sibju \\
, V r^s^MN-ANAuPs Brada.T^O
£ Pite§ti. .P''016?" T^a
N/> walach,a BUCHAREST
SER. ^ ''Craiova ^Constanta.
" AND /
MONT. <
^*~— ''—-^s*S Mangana
S Slack
y BULGARIA Sea
O 50 100 Km
,,
0 50 100 mi
O 20 40 km
Disputes - international: Hungary amended its
status law extending special social and cultural
benefits to ethnic Hungarians in Slovakia, to which
Slovakia had protested; consultations continue
between Slovakia and Hungary over Hungary''s
completion of its portion of the Gabcikovo-Nagymaros
hydroelectric dam project along the Danube; as a
member state that forms part of the EU''s external
border, Slovakia must implement the strict Schengen
border rules
Illicit drugs: transshipment point for Southwest
Asian heroin bound for Western Europe; producer of
synthetic drugs for regional market
LO
Brazzaville (capital)
Republic of the Congo
Bridgetown (capital)
48 40N
Turkey
38 25N','834c5689ec3eca4de7c446f543f0d0e18c58a151a68019a5f542c2357dae7255','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a7bd12fe74132ce6897fcf4639704f04b52f0dea613daf4a89775d3b8967d34',2007,'UA','Ukraine','transnational-issues',1059,'Disputes - international: Romania and Ukraine
have taken their dispute over Ukrainian-administered
Zmiyinyy (Snake) Island and Black Sea maritime
boundary to the ICJ for adjudication; Romania also
opposes Ukraine''s reopening of a navigation canal
from the Danube border through Ukraine to the Black
Sea; Hungary amended the status law extending
special social and cultural benefits to ethnic
Hungarians in Romania, to which Romania had
objected
Illicit drugs: major transshipment point for
Southwest Asian heroin transiting the Balkan route
and small amounts of Latin American cocaine bound
for Western Europe; although not a significant
financial center, role as a narcotics conduit leaves it
vulnerable to laundering which occurs via the banking
system, currency exchange houses, and casinos
s
461
Russia
Disputes - international: in 2005, China and Russia
ratified the treaty to divide up the islands in the Amur,
Ussuri, and Argun Rivers, representing the final
portion of their centuries-long border disputes; the
sovereignty dispute over the islands of Etorofu,
Kunashiri, Shikotan, and the Habomai group, known
in Japan as the "Northern Territories" and in Russia as
the "Southern Kurils," occupied by the Soviet Union in
1945, now administered by Russia, and claimed by
Japan, remains the primary sticking point to signing a
peace treaty formally ending World War II hostilities;
Russia and Georgia agree on delimiting all but small,
strategic segments of the land boundary and the
maritime boundary; OSCE observers monitor volatile
areas such as the Pankisi Gorge in the Akhmeti region
and the Kodori Gorge in Abkhazia; Azerbaijan,
Kazakhstan, and Russia signed equidistance
boundaries in the Caspian seabed but the littoral
states have no consensus on dividing the water
column; Russia and Norway dispute their maritime
limits in the Barents Sea and Russia''s fishing rights
beyond Svalbard''s territorial limits within the Svalbard
Treaty zone; various groups in Finland advocate
restoration of Karelia and other areas ceded to the
Soviet Union following the Second World War but the
Finnish Government asserts no territorial demands; in
May 2005, Russia recalled its signatures to the 1996
border agreements with Estonia (1996) and Latvia
(1997), when the two Baltic states announced
issuance of unilateral declarations referencing Soviet
occupation and ensuing territorial losses; Russia
demands better treatment of ethnic Russians in
Estonia and Latvia; Estonian citizen groups continue
to press for realignment of the boundary based on the
1920 Tartu Peace Treaty that would bring the now
divided ethnic Setu people and parts of the Narva
region within Estonia; Lithuania and Russia committed
to demarcating their boundary in 2006 in accordance
with the land and maritime treaty ratified by Russia in
May 2003 and by Lithuania in 1999; Lithuania
operates a simplified transit regime for Russian
nationals traveling from the Kaliningrad coastal
exclave into Russia, while still conforming, as a
member state that forms part of the EU''s external
border, to strict Schengen border rules; delimitation of
land boundary with Ukraine is complete, but states
have renewed discussions on demarcation; the
dispute over the maritime boundary between Russia
and Ukraine through the Kerch Strait and Sea of Azov
remains unresolved despite a December 2003
framework agreement and on-going expert-level
discussions; discussions toward economic and
political union with Belarus advance slowly;
Kazakhstan and Russia boundary delimitation ratified
November 2005 and demarcation is underway;
Russian Duma has not yet ratified 1990 Maritime
Boundary Agreement with the US in the Bering Sea
Refugees and internally displaced persons:
IDPs: 339,000 (displacement from Chechnya and
North Ossetia) (2005)
Illicit drugs: limited cultivation of illicit cannabis and
opium poppy and producer of methamphetamine,
mostly for domestic consumption; government has
active illicit crop eradication progiam; used as
transshipment point for Asian opiates, cannabis, and
Latin American cocaine bound for growing domestic
markets, to a lesser extent Western and Central
Europe, and occasionally to the US; major source of
heroin precursor chemicals; corruption and organized
crime are key concerns; heroin increasingly popular in
domestic market
465
Disputes - international: 1 997 boundary treaty with
Belarus remains un-ratified due to unresolved
financial claims, stalling demarcation and reducing
border security; delimitation of land boundary with
Russia is complete and parties have renewed
discussions on demarcation; the dispute over the
maritime boundary between Russia and Ukraine
through the Kerch Strait and Sea of Azov remains
unresolved despite a December 2003 framework
agreement and ongoing expert-level discussions;
Moldova and Ukraine have established joint customs
posts to monitor transit through Moldova''s break-away
Transnistria Region, which remains under OSCE
supervision; in 2004 Ukraine and Romania took their
dispute over Ukrainian-administered Zmiyinyy
(Snake) Island and Black Sea maritime boundary to
the ICJ for adjudication; Romania opposes Ukraine''s
reopening of a navigation canal from the Danube
border through Ukraine to the Black Sea
Illicit drugs: limited cultivation of cannabis and
opium poppy, mostly for CIS consumption; some
synthetic drug production for export to the West;
limited government eradication program; used as
transshipment point for opiates and other illicit drugs
from Africa, Latin America, and Turkey to Europe and
Russia; Ukraine has improved anti-money-laundering
controls, resulting in its removal from the Financial
Action Task Force''s (FATF''s) Noncooperative
Countries and Territories List in February 2004;
Ukraine''s anti-money-laundering regime continues to
be monitored by FATF
Ship Pollution
Treaty Banning Nuclear Weapon Tests in the
Atmosphere, in Outer Space, and Under
Water
note— abbreviated as Nuclear Test Ban
opened for signature— 5 August 1963
entered into force— 10 October 1963
objective— to obtain an agreement on general
and complete disarmament under strict
international control in accordance with the
objectives of the United Nations; to put an end to
the armaments race and eliminate incentives for
the production and testing of all kinds of
weapons, including nuclear weapons
see Protocol of 1978 Relating to the International Convention for the Prevention of Pollution From Ships, 1973
(MARPOL)
parties— (113) Afghanistan, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, The Bahamas,
Bangladesh, Belgium, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burma, Canada,
Central African Republic, Chad, China, Colombia, Democratic Republic of the Congo, Costa Rica, Cote d''lvoire,
Croatia, Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Fiji, Finland, Gabon,
The Gambia, Germany, Ghana, Greece, Guatemala, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, South Korea, Kuwait, Laos, Lebanon, Liberia, Luxembourg,
Madagascar, Malawi, Malaysia, Malta, Mauritania, Mauritius, Mexico, Morocco, Nepal, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Norway, Panama, Papua New Guinea, Peru, Philippines, Poland, Romania, Russia, Rwanda, Samoa,
San Marino, Senegal, Serbia and Montenegro, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, South
Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Thailand, Togo, Tonga, Trinidad
and Tobago, Tunisia, Turkey, Uganda, UK, US, Venezuela, Zambia
countries that have signed, but not yet ratified— {17) Algeria, Burkina Faso, Burundi, Cameroon, Chile, Ethiopia,
Haiti, Libya, Mali, Pakistan, Paraguay, Portugal, Somalia, Tanzania, Uruguay, Vietnam, Yemen
Tropical Timber 83
see International Tropical Timber Agreement, 1983
Tropical Timber 94
see International Tropical Timber Agreement, 1994
667
Appendix C: Selected International Environmental Agreements (continued)
United Nations Convention on the Law of the
Sea (LOS)
note— abbreviated as Law of the Sea
opened for signature— 10 December 1982
entered into force— 16 November 1994
objective— to set up a comprehensive new legal
regime for the sea and oceans; to include rules
concerning environmental standards as well as
enforcement provisions dealing with pollution of
the marine environment
United Nations Convention to Combat
Desertification in Those Countries
Experiencing Serious Drought and/or
Desertification, Particularly in Africa
note— abbreviated as Desertification
opened for signature— -1 4 October 1 994
entered into force— 26 December 1 996
objective— to combat desertification and
mitigate the effects of drought through national
action programs that incorporate long-term
strategies supported by international
cooperation and partnership arrangements
United Nations Framework Convention on
Climate Change
note— abbreviated as Climate Change
opened for signature— 9 May 1992
entered into force— -21 March 1994
objective— to achieve stabilization of
greenhouse gas concentrations in the
atmosphere at a low enough level to prevent
dangerous anthropogenic interference with the
climate system
Wetlands
Whaling
parties— (148) Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, The
Bahamas, Bahrain, Bangladesh, Barbados, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana,
Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Cameroon, Canada, Cape Verde, Chile, China, Comoros, Democratic
Republic of the Congo, Cook Islands, Costa Rica, Cote d''lvoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Egypt, Equatorial Guinea, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany,
Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iraq, Ireland, Italy, Jamaica, Japan, Jordan, Kenya, Kiribati, South Korea, Kuwait, Laos, Latvia, Lebanon,
Lithuania, Luxembourg, Macedonia, Madagascar, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Monaco, Mongolia, Mozambique, Namibia, Nauru, Nepal,
Netherlands, NZ, Nicaragua, Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia and Montenegro, Seychelles, Sierra
Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Sweden, Tanzania, Togo, Tonga, Trinidad and Tobago, Tunisia, Tuvalu, Uganda, Ukraine, UK, Uruguay, Vanuatu,
Vietnam, Yemen, Zambia, Zimbabwe
countries that have signed, but not yet ratified— -(29) Afghanistan, Bangladesh, Belarus, Bhutan, Burundi,
Cambodia, Central African Republic, Chad, Colombia, Republic of the Congo, Dominican Republic, El Salvador,
Ethiopia, Iran, North Korea, Lesotho, Liberia, Libya, Liechtenstein, Madagascar, Malawi, Morocco, Niger, Niue,
Rwanda, Swaziland, Switzerland, Thailand, UAE
parties— (178) Afghanistan, Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria,
Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia, Botswana,
Brazil, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook
Islands, Costa Rica, Cote d''lvoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador. Equatorial Guinea, Eritrea, Ethiopia, EU, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hungary, Iceland, India, Indonesia. Iran, Ireland. Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia, Libya, Liechtenstein,
Luxembourg, Madagascar, Malawi, Malaysia, Mali. Malta, Marshall Islands, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal,
Netherlands, NZ, Nicaragua. Niger, Nigeria. Niue. Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal. Qatar. Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Seychelles,
Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden. Switzerland. Syria, Thailand. Tajikistan, Tanzania, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan. Tuvalu, Uganda, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Zambia, Zimbabwe
parties— (189) Afghanistan, Albania. Algeria. Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria,
Azerbaijan, The Bahamas, Bahrain. Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil. Brunei, Bulgaria. Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of
the Congo, Republic of the Congo. Cook Islands, Costa Rica, Cote d''lvoire, Croatia, Cuba, Cyprus, Czech Republic,
Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia,
Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece. Grenada, Guatemala,
Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia,
Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi,
Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia,
Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia and Montenegro, Seychelles, Sierra
Leone, Singapore, Slovakia, Slovenia, Solomon Islands. South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland. Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia,
Turkey. Turkmenistan, Tuvalu. Uganda. Ukraine, UAE, UK, US. Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam,
Yemen, Zambia, Zimbabwe
see Convention on Wetlands of International Importance Especially As Waterfowl Habitat (Ramsar)
see International Convention for the Regulation of Whaling
668
Appendix D:
Cross-Reference List of Country Data Codes
FIPS10:
UP
UA
UKR
804
.ua
48 22N
23 32E
Carpentaria. Gulf of
Pacific Ocean
14 00S
139 00 E
Castries (capital)
Crimean Peninsula
Crooked Island Passage
Atlantic Ocean
Crozet Islands (lies Crozet)
French Southern and Antarctic Lands
Cyclades (island group)
50 26N
30 31 E
Kigali (capital)
Latitude
(deg min)
40 00N
37 00N
7 20N
42 30N
5 20N
2218N
10 20N
6 07S
310N
44 20N
36 00N
4610N
29 20N
54 00N
9 05N
33 00N
50 26N
Longitude
(deg min)
127 00 E
127 30 E
134 29 E
21 00 E
163 00 E
114 10E
99 00E
105 24 E
101 42 E
146 00 E
84 00E
152 00 E
47 59E
86 00E
167 20 E
131 00 E
30 31 E
La Paz (administrative capital)
La Perouse Strait
Labrador (peninsula, region)
Labrador Sea
Laccadive Islands
Laccadive Sea
Lagos (former capital)
Lake Erie
Lake Huron
Lake Michigan
Lake Ontario
Lake Superior
Lakshadweep (Laccadive Islands)
Lantau Island
Lao (local name for Laos)
Laptev Sea
Las Palmas (city)
Latakia (region)
Latvija (local name for Latvia)
Lau Group (island group)
Lefkosa (see Nicosia)
Lemnos (island)
Leningrad (see Saint Petersburg)
Lesser Sunda Islands
Lesvos (island)
Leyte (island)
Liancourt Rocks (claimed by Japan)
Liaodong Wan (gulf)
Liban (local name for Lebanon)
Libreville (capital)
Bolivia
Pacific Ocean
48 22N
23 32E
Ryukyu Islands
48 22N
23 32E
Transjordan (former name for Jordan)
49 00N','88e090221e95947fb62d5a2cabe6c6d49a226d2fbcb2fca3dacba86ad4a0b869','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca1d8d9226288541432a05b6f70a2f43929f3b10769a377ab8be375c684efb03',2007,'RW','Rwanda','transnational-issues',1061,'T UGANDA ^~—
DEM. REP. > r-7~ — ''
OFTHE lo, / \\
CONGO {* f \\ TANZ.
J~wam Ruhengeri .Byumba V
f Kansimbl \\
/''Gisenyi . % \\
| KIGALI CVaM
ito\\ .Kibuye # V
/ojh, J Gitarama Kibungo /
/ (
(~-s A,vu \\«! CyobohaSud \\^ \\
Uyangugu \\ J~
VfS Bu,are* 1 <^r TANZ.
\\ BURUNDI 0 „ <^>~7
6 20 40 mi \\
n t r o d u c t i o
Background: In 1959, three years before
independence from Belgium, the majority ethnic
group, the Hutus, overthrew the ruling Tutsi king. Over
the next several years, thousands of Tutsis were
killed, and some 150,000 driven into exile in
neighboring countries. The children of these exiles
later formed a rebel group, the Rwandan Patriotic
Front (RPF), and began a civil war in 1990. The war,
along with several political and economic upheavals,
exacerbated ethnic tensions, culminating in April 1 994
in the genocide of roughly 800,000 Tutsis and
moderate Hutus. The Tutsi rebels defeated the Hutu
regime and ended the killing in July 1994, but
approximately 2 million Hutu refugees - many fearing
Tutsi retribution - fled to neighboring Burundi,
Tanzania, Uganda, and the former Zaire. Since then,
most of the refugees have returned to Rwanda, but
about 10,000 remain in neighboring Democratic
Republic of the Congo and have formed an extremist
insurgency bent on retaking Rwanda, much as the
RPF tried in 1990. Despite substantial international
assistance and political reforms - including Rwanda''s
first local elections in March 1999 and its first
post-genocide presidential and legislative elections in
August and September 2003 - the country continues
to struggle to boost investment and agricultural output,
and ethnic reconciliation is complicated by the real
and perceived Tutsi political dominance. Kigali''s
increasing centralization and intolerance of dissent,
the nagging Hutu extremist insurgency across the
border, and Rwandan involvement in two wars in
recent years in the neighboring Democratic Republic
of the Congo continue to hinder Rwanda''s efforts to
escape its bloody legacy.
Disputes - international: Tutsi, Hutu, Hema, Lendu,
and other conflicting ethnic groups, associated
political rebels, armed gangs, and various government
forces continue fighting in Great Lakes region,
transcending the boundaries of Burundi, Democratic
Republic of the Congo, Rwanda, and Uganda to gain
control over populated areas and natural resources -
government heads pledge to end conflicts, but
localized violence continues despite UN
peacekeeping efforts; DROC and Rwanda
established a border verification mechanism in 2005
to address accusations of Rwandan military
supporting Congolese rebels and the Congo providing
rebel Rwandan "Interhamwe" forces the means and
bases to attack Rwandan forces; as of 2004,
Rwandan refugees lived in the Democratic Republic of
the Congo, Uganda, and Zambia
Refugees and internally displaced persons:
refugees (country of origin): 45,460 (Democratic
Republic of the Congo)
IDPs: 4,158 (incursions by Hutu rebels from
Democratic Republic of the Congo, 1997-99; most
IDPs in northwest) (2005)
Saint Helena
(overseas territory
of the UK)
200 400 km
Ascension
St. Helena
JAMESTOWN
SOUTH ATLANTIC OCEAN
TRISTAN DA CUNHA
InacessiUe
Island -~ Queer Mar, s Peak
'' A ''"Han da Cunha
NIGKTINGALE
ISLANDS
Gougti
Island
Disputes - international: none
470
Saint Kitts
^P\\
and Nevis
E^
O 4 8 km
0 * 8 mi
Sandy Pom!
Town
• A Mount
Lf.lt''iuiQ.i
Canbb>''
Sea
Saint
BASSETERRE
Kitts
Caribb<
( Nevis
Peek
Charlestown
J
Nevis
RW
RW
RWA
646
.rw
Saint Helena
SH
SH
SHN
654
.sh
1 57 S
30 04E
Kingston (capital)
Republique Togolaise (local name for Togo)
2 00S
30 00E
Rub al Khali (desert)','7f7b9846ab8cdea3b055c656a59ae5edb6a6e1fd09a9d77bbd02da5748df3ed3','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a31901ef2a74258c7801fa8588eb80934b507b19cc7848b3be13de510724ad43',2007,'KN','Saint Kitts and Nevis','transnational-issues',1078,'Disputes • international: joins other Caribbean
states to counter Venezuela''s claim that Aves Island
sustains human habitation, a criterion under
UNCLOS, which permits Venezuela to extend its EEZ/
continental shelf over a large portion of the Caribbean
Sea
Illicit drugs: transshipment point for South American
drugs destined for the US and Europe; some
money-laundering activity
472
SC
KN
KNA
659
.kn
17 18 N
62 43W
Basse-Terre (capital)
17 09N
62 35W
New Britain (island)
17 20N
Saint Christopher and Nevis
17 20N
Saint Eustatius (island)
Netherlands Antilles
17 30N
Saint George''s (capital)','fea7204132503e3627627771ec707458b0f0ae51d83115bcf1a93018597aff22','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7564744acf4aa7d5e5b8792ee40dfc6333b267523a9f6b60c1e4639f7794730d',2007,'GD','Grenada','transnational-issues',1084,'Maymau ■'' i tobagocays
Prune Island
. fVM San Vmcant Island
GJ
GD
GRD
308
■gd
12 07N
6140W
Grytviken (town, on South Georgia)
12 03N
Saint George''s Channel
Atlantic Ocean
52 00N
Saint Helens, Mount (volcano)
12 20N
6130W
Southern Rhodesia (former name for Zimbabwe)','0a4f4f6ebeaad2c8f172c2b69fa574247656f7f296847edbf315b0ad79e4b7f9','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('617c59be8dfea1ab9f5ac4f3a77c7fa440592652d4dbe5f90571cb76efc26c2e',2007,'WS','Samoa','transnational-issues',1089,'16
30 mi
South Pacific Ocean
Apolima
South Pacific Ocean
reel
''ueutele
Nueulua
Disputes - international: none
480
ws
WS
WSM
882
.ws
Aqaba, Gulf of
Indian Ocean
Arab, Shatt al (river)
Iran, Iraq
Arabian Sea
Indian Ocean
Arafura Sea
Pacific Ocean
125S
18 52S
14 34N
49 41S
51 13 N
2210N
22 00N
13 50S
29 00N
29 57N
15 00N
9 00S
5 36E
47 30E
90 44W
178 43 E
4 25E
11333E
18 00E
171 45 W
34 30E
48 34E
65 00E
133 00 E
679
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Aral Sea
Kazakhstan, Uzbekistan
45 00N
60 00E
Argun River
China, Russia
53 20N
121 28 E
Aru Sea
Pacific Ocean
615S
135 00 E
Ascension Island
Saint Helena
7 57S
14 22W
Ashgabat (capital)
Wetar Strait
Pacific Ocean
White Sea
Arctic Ocean
Wilkes Land (region)','3836599803f50687e860159a923bdde9b1af7da2136f790d0a9ce1c7965099fe','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0bdc802fc97bf3331ccad03e251ce19db8d91ff1d007ce8b4ec968964a44bb0',2007,'SM','San Marino','transnational-issues',1098,'&
0 l 2 km
^ La \\
jT Doganal
jT Serravalle Y
O 1 2 m
SM
SM
SMR
674
.sm
43 56N
12 25E
San Salvador (capital)','35a7678522d4080e27ca411397c6da845e2d481a5e597d3df0f5e3edaa067a71','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e74add500e46545eb8e5fd79a5211693376c08754c94e94bf64194c6964e6339',2007,'SA','Saudi Arabia','transnational-issues',1099,'0 100200 km
0 100 200 mi
IRAN
ipuba
Ha'' il Ra'' s al Khalp ,
... Al Jub.iyl
Buraydah. Ad Dammam!;BAH"Alr''
Inf.
Medina
''Yanbu''al RIYADH
v Bahr
Jiddab, ^Mecca
'' ''At, Ta'' if
Al Hufu).
*
SUDAN s
Disputes - international: despite resistance from
nomadic groups, the demarcation of the Saudi
Arabia-Yemen boundary established under the 2000
Jeddah Treaty is almost complete; Saudi Arabia still
maintains the concrete-filled pipe as a security barrier
along sections of the border with Yemen in 2004 to
stem illegal cross-border activities; Kuwait and Saudi
Arabia continue discussions on a maritime boundary
with Iran; the United Arab Emirate 2006 Yearbook
published a map and text rescinding the 1974
boundary with Saudi Arabia, as stipulated in a treaty
filed with the UN in 1993, on the grounds that the
agreement was not formally ratified
Refugees and internally displaced persons:
refugees (country of origin): 240,000 (Palestinian
Territories) (2005)
Illicit drugs: death penalty for traffickers; increasing
consumption of heroin, cocaine, and hashish;
improving anti-money-laundering legislation and
enforcement
l.it.l'' .1" N It
AS Shu ayt
Salt; ;^SANAA
*Al Hudaydah
.fob
1 «Ta pz2
\\Ef*H . Mocha
''Aden
Say" un#
•Al Ghaydah
*Nishtun
Sayhut
AIMukalla Arabian
Sea
Gulf ol Aden
SA
SA
SAU
682
.sa
25 00N
45 00E
Al Bahrayn (local name for Bahrain)
24 30N
38 30E
Helsinki (capital)
2130N
3912E
Johannesburg (city)
Atlantic Ocean
24 05N
4515E
Netherlands East Indies (former name for Indonesia)
24 38N
46 43E
Road Town (capital)
British Virgin Islands
18 27N
64 37W
Robinson Crusoe Island (Mas a Tierra)
19 30N
49 00E
Rumelia (region)
Albania, Bulgaria, Macedonia
42 00N
22 30E
Ruthenia (region; former name for Carpatho-Ukraine)','0c0ff69c5695de34b062f50e8f7658acf2cabc622f6dc2dab86c45968248eda0','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('65848ce0caed5cd799c0e33d7534ec5a75330a0be2bd81f5d47c44996afe5532',2007,'SN','Senegal','transnational-issues',1108,'Background: Independent from France in 1960,
Senegal was ruled by the Socialist Party for forty years
until current President Abdoulaye WADE was elected
in 2000. Senegal joined with The Gambia to form the
nominal confederation of Senegambia in 1 982, but the
envisaged integration of the two countries was never
carried out, and the union was dissolved in 1989. A
southern separatist group sporadically has clashed
with government forces since 1982, but Senegal
remains one of the most stable democracies in Africa.
Senegal has a long history of participating in
international peacekeeping.
Disputes • international: The Gambia and
Guinea-Bissau attempt to stem Senegalese citizens
from the Casamance region fleeing separatist
violence, cross border raids, and arms smuggling
Refugees and internally displaced persons:
refugees (country of origin): 19,778 (Mauritania)
IDPs: 1 7,000 (clashes between government troops
and separatists in Casamance region) (2005)
Illicit drugs: transshipment point for Southwest and
Southeast Asian heroin and South American cocaine
moving to Europe and North America; illicit cultivator
of cannabis
Serbia and
SG
SN
SEN
686
.sn
Serbia and Montenegro
Yl
CS
SCG
891
.CS
Dalmatia (region)','259030a4db4c1eb07c1ec8cae605e7eac26cb453caea36560a7396611c9122e1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9427053458b47f9298bac3c72f075cb42adbd3d8288ecb8d396be026e019cc8e',2007,'ME','Montenegro','transnational-issues',1115,'HUNGARY r^-~~<-~J ° 40 MX™
/v^/v"''*Subotica\\. o <io eom
5 Vo/vodina T
CROATIA ? Zrenjanin. i ROMANIA
N^ . .NoviSad v->^
^^_jL PancevoS
/T3ELGRADE smeo^vo\\//^
80SNIA C f&t
AND /V Kraguievac, .Bo''fy;
HERZEGOVINA^ *UziCe SERBIA { V— — «.
JST Novi .N''S ^N
rl ■ Pazar^ N
L > MONTEr^GRO _ .... , <~ BUI.
vV V PriStina^ >
^"\\^ -r- . /''y L Daravics *».
CR0X jT|vat . / ^A ™soM ;
Podgorica^ .Pnzren-/-^-^sr
Bar* | ALBANIA W^^ACEDONIA^
Disputes - international: Kosovo remains
unresolved and administered by several thousand
peacekeepers from the UN Interim Administration
Mission in Kosovo (UNMIK) since 1999, with Kosovar
Albanians overwhelmingly supporting and Serbian
officials opposing Kosovo independence; the
international community had agreed to begin a
process to determine final status but contingency of
solidifying multi-ethnic democracy in Kosovo has not
been satisfied; ethnic Albanians in Kosovo refuse
demarcation of the boundary with Macedonia in
accordance with the 2000 Macedonia-Serbia and
Montenegro delimitation agreement; Serbia and
Montenegro have delimited about half of the boundary
with Bosnia and Herzegovina, but sections along the
Drina River remain in dispute
Refugees and internally displaced persons:
refugees (country of origin): 95,297 (Bosnia and
Herzegovina) 180,117 (Croatia)
IDPs: 225,000 - 251,000 (mostly ethnic Serbs and
Roma who fled Kosovo in 1999) (2005)
Illicit drugs: transshipment point for Southwest
Asian heroin moving to Western Europe on the Balkan
route; economy vulnerable to money laundering','aa8b04228a101d26a1b2cc1a5c5bdcbfe9a8ea6b53406b0acfae9ff2db8e4b75','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab5752b6e608db3a05a025247eaebbce2f654ce056ed27629e3520fdc2107b43',2007,'SC','Seychelles','transnational-issues',1123,'Mxnc VICTORIA
SaMfWANS *
Mah6
Island
StyrhtHts
trtfamtftonl/
Auport
LES
AMIRANTES
VICTORIA*
Mahe
Prasltn
Alphonse Island
INDIAN OCEAN
lie Plato
Coelivy
ALDABRA
ISLANDS
Atoll de
Cosmoledc
PROVIDENCE
ATOLL
ATOLL DE
FAROUHAR
Agatega Islands
(MAURITIUS)
lies Gkvieusat
"HANCEj
MAOAGASC
\\ O IOO
CAR\\i 0 i
OO 200 mi
Disputes - international: together with Mauritius,
Seychelles claims the Chagos Archipelago
(UK-administered British Indian Ocean Territory)
SE
SC
SYC
690
.SC
9 25S
46 22E
Alderney (island)
7 01S
52 45E
Alsace (region)
6 00S
5310E
Amman (capital)
9 46S
46 34E
Astana (capital; formerly Akmola)
9 43S
47 35E
Cotonou (former capital)
Fergana Valley
Kyrgyzstan, Tajikistan, Uzbekistan
Fernando de Noronha (island group)
4 41S
55 30E
Maiz, Islas del (Corn Islands)
4 38S
55 27E
Victoria (island)','012fadc8b1eadc59b35c747f8cacae7580eee157e37d7d8d597c64f8e9e2b0da','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a206618a58aaa9b703efe3c719620fba657f3412a94b2d02204c6491f94588e',2007,'SL','Sierra Leone','transnational-issues',1130,'/
Disputes - international: domestic fighting among
disparate rebel groups, warlords, and youth gangs in
Cote d''lvoire, Guinea, Liberia, and Sierra Leone
perpetuate insurgencies, street violence, looting, arms
trafficking, ethnic conflicts, and refugees in border
areas; UN Mission in Sierra Leone (UNAMSIL) has
maintained over 4,000 peacekeepers in Sierra Leone
since 1 999; Sierra Leone pressures Guinea to remove
its forces from the town of Yenga occupied since 1 998
Refugees and internally displaced persons:
refugees (country of origin): 65,433 (Liberia) (2005)
497
SL
SL
SLE
694
.si
8 30N
1315W
French Cameroon (former name for Cameroon)','91242e475d01c7c8d20038681f191ef6bc586813c74914a81b6d0f3c05691747','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a3468cf6a2e827cc971c7d1ec390bf3a1523c83dcfe85e65fe7fb1fb0a08159e',2007,'SB','Solomon Islands','transnational-issues',1147,'PAPUA
NEW
British Somaliland (former name for northern Somalia)
7 05S
121 00 E
Choson (local name for North Korea)
North Korea
40 00N
127 00 E
Christmas Island (Indian Ocean)
9 32S
160 12 E
Guadalupe, Isla de (island)
9 26S
159 57 E
Honshu (island)
11 00 S
166 15 E
Santa Sede (local name for the Holy See)
Holy See
41 54 N
12 27E
Santiago (capital)
8 00S
159 00 E
Solomon Sea
Pacific Ocean
8 00S
153 00 E
Somaliland (region)','eda2c1b7b3f442bcd5b9541dd0c0ec21a3db73748489c7bcb2b31f226c9e2b6b','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e02a04ed3188707624e9bf2964afbdd43b3e39b97938af8f4c22e1eab1b8eab',2007,'SO','Somalia','transnational-issues',1152,'GutfofAden O
Boosaaso
0 100 200 wn
SoCOtra
INDIAN
OCEAN
BP
^0~
SK
SVK
703
.sk
SI
SVN
705
SB
SLB
SOM
090
70T
.sb
.so
674
Appendix D: Cross-Reference List of Country Data Codes (continued)
Entity
Bengal, Bay of
Indian Ocean
Berau, Gulf of
Pacific Ocean
Bering Island
Russia
33 53N
34 00N
7 30N
19 45S
0 00N
50 50N
50 50N
44 50N
17 30N
51 35 N
7100S
17 15 N
53 00N
4 00N
15 00N
2 30S
55 00N
35 30E
36 05E
134 30 E
163 40 E
25 00E
4 00E
4 00E
20 30E
88 12W
56 30W
85 00W
88 46W
28 00E
46 00E
90 00E
132 30 E
166 30 E
681
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Bering Sea
Pacific Ocean
60 00N
175 00 W
Bering Strait
Pacific Ocean
65 30N
169 00 W
Berkner Island
Brussels (capital)
10 00N
49 00E
Ittihad al-lmarat al-Arabiyah (local name for the
United Arab Emirates)
2 04N
45 22E
Moldavia (region)
Moldova, Romania
47 00N
29 00E
Molucca Sea
Pacific Ocean
2 00N
127 00 E
Moluccas (Spice Islands)
Pyongyang (capital)
North Korea
40 55N
14 55N
15 00N
25 45S
42 24N
57 00N
46 20N
46 35S
76 30N
138N
53 00N
10 53 5
30 50N
8 21 N
39 01 N
2100E
23 31W
100 00 E
28 10E
1831 E
170 00 W
63 20W
38 00E
119 00W
7 25E
14 00E
165 49 W
73 30E
49 08E
125 45 E
Q
Qazaqstan (local name for Kazakhstan)
9 30N
46 00E
Somers Islands (former name for Bermuda)','88fb6404e159d2d33d292fb184ff4dead3212c37ae7bf516a67819530d453564','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('454b5f4b6d29bd9791b0cd07b4459fa3d5fc6baf85edc782323de0b6787635c1',2007,'KE','Kenya','transnational-issues',1153,'^Baidoa
MOGADISHU,
Merca
INDIAN
OCEAN
\\
"Chisimayu
(Kismaayo)
Disputes - international: "Somaliland"
secessionists provide port facilities to landlocked-
Ethiopia and establish commercial ties with regional
states; "Puntland" and "Somaliland" "governments"
seek support from neighboring states in their
secessionist aspirations and in conflicts with each
other; Ethiopia has only an administrative line with the
Oromo region of southern Somalia and maintains
alliances with local Somali clans opposed to the
unrecognized Somali Interim Government, which
plans eventual relocation from Kenya to Mogadishu;
rival militia and clan fighting in southern Somalia
periodically spills over into Kenya
Refugees and internally displaced persons:
IDPs: 400,000 (civil war since 1988, clan-based
competition for resources) 5,000 (26 December 2004
tsunami) (2005)
KE
KE
KEN
404
.ke
Kingman Reef
KQ
—
—
—
—
ISO includes with the US Minor
Outlying Islands
4 03S
39 40E
Mona Passage
Atlantic Ocean
18 30N
67 45W
Monaco (capital)
1 17S
36 49E
Namib (desert)','d5945c389b63cde86812e76f829d16631e5e8292f01031eb30ea388b9d95a1d9','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('033b7865ac99df8d39ffe65217950c7197a733b69a9cd34bdb77c37f63382d66',2007,'LK','Sri Lanka','transnational-issues',1172,'Disputes - international: all of the Spratly Islands are
claimed by China, Taiwan, and Vietnam; parts of them
are claimed by Malaysia and the Philippines; in 1984,
Brunei established an exclusive fishing zone that
encompasses Louisa Reef in the southern Spratly
Islands but has not publicly claimed the reef; claimants in
November 2002 signed the "Declaration on the Conduct
of Parties in the South China Sea," which has eased
tensions but falls short of a legally binding "code of
conduct"; in March 2005, the national oil companies of
China, the Philippines, and Vietnam signed a joint accord
to conduct marine seismic activities in the Spratly Islands
O 40 SO km
40 80 mi
Bay
of
Bengal
Kalpitly,
Gull
0f Puttalam
iTrincomalee
Anuradhapura
Matale
Negombo,
Dehiwala- ^COLOMBO
Mt. Lavinia--/ Kotte
Moraluwa ''Ratnapura
. .Batticaloa
Hambantola
Disputes - international: none
Refugees and internally displaced persons:
IDPs: 353,000 (both Tamils and non-Tamils displaced
due to Tamil conflict); 450,000 (resulting from 2004
tsunami) (2005)
521
7 00N
8100E
Chafarinas, Islas (island)
6 56N
79 51 E
Colon, Archipielago de (Galapagos Islands)
7 00N
81 00 E
Serrana Bank (shoal)','0558f4b19f303149484cbee8644d14a91f99104898f4f871feae1122e4c77241','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61cba8bc97a99df5abc81cf0e982c3931ec4a6d9d3b379673f0935b07c18f8a3',2007,'SD','Sudan','transnational-issues',1180,'Background: Military regimes favoring
Islamic-oriented governments have dominated
national politics since independence from the UK in
1956. Sudan was embroiled in two prolonged civil
wars during most of the remainder of the 20th century.
These conflicts were rooted in northern economic,
political, and social domination of largely non-Muslim,
non-Arab southern Sudanese. The first civil war
ended in 1972, but broke out again in 1983. The
second war and famine-related effects resulted in
more than 4 million people displaced and, according
to rebel estimates, more than 2 million deaths over a
period of two decades. Peace talks gained momentum
in 2002-04 with the signing of several accords; a final
Naivasha peace treaty of January 2005 granted the
southern rebels autonomy for six years, after which a
referendum for independence is scheduled to be held.
A separate conflict that broke out in the western region
of Darfur in 2003 has resulted in at least 200,000
deaths and nearly 2 million displaced; as of late 2005,
peacekeeping troops were struggling to stabilize the
situation. Sudan also has faced large refugee influxes
from neighboring countries, primarily Ethiopia and
Chad, and armed conflict, poor transport
infrastructure, and lack of government support have
chronically obstructed the provision of humanitarian
assistance to affected populations.
Disputes - international: the effects of Sudan''s
almost constant ethnic and rebel militia fighting since
the mid-twentieth century have penetrated all of its
border states that provide shelter for fleeing refugees
and cover to disparate domestic and foreign
conflicting elements; since 2003, Janjawid armed
militia and Sudanese military have driven about
200,000 Darfur region refugees into eastern Chad;
large numbers of Sudanese refugees have also fled to
Uganda, Ethiopia, Kenya, the Central African
Republic, and the Democratic Republic of the Congo;
southern Sudan provides shelter to Ugandans
seeking periodic protection from soldiers of the Lord''s
Resistance Army; Sudan accuses Eritrea of
supporting Sudanese rebel groups; efforts to
demarcate the porous boundary with Ethiopia have
been delayed by civil and ethnic fighting in Sudan;
Kenya''s administrative boundary extends into the
southern Sudan, creating the "llemi Triangle"; Egypt
and Sudan retain claims to administer triangular areas
that extend north and south of the 1899 Treaty
boundary along the 22nd Parallel, but have withdrawn
their military presence; Egypt is economically
developing the "Hala''ib Triangle" north of the Treaty
Line; periodic violent skirmishes with Sudanese
residents over water and grazing rights persist among
related pastoral populations from the Central African
Republic along the border
Refugees and internally displaced persons:
refugees (country of origin): 110,927 (Eritrea) 5,023
(Chad) 7,983 (Uganda) 14,812 (Ethiopia)
IDPs: 5,300,000 - 6,200,000 (internal conflict since
1980s; ongoing genocide) (2005)
524
15 00N
30 00E
Anjouan (island)
15 00N
30 00E
Assumption Island
15 36N
32 32E
Khios (island)','6a40eb7d6cc78cbf42ec9e9aece0a6b5df8bc398edbb4b13495b977196f5992a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fba95259a11f08d94508a2938d64bf6ade93a11bf5b8cd380e15e7650489142e',2007,'SE','Sweden','transnational-issues',1191,'*%
Wr Lmkbping^
CJBtenungsund
,Goteborg #jonk6ping A
■ . Boras
^STOCKHOLM
Eskiisiunr^^
^"Oxeldsund
EST
''Gotland
Halmslad ,,
Kalmar- 0tand
LAT.
Sea
Helsingborg Karlsriamn
''Krtstianstad
.Malrnd
,DEN JreUeborg
Bcrnholm 0 50
''"■■ o I
L_
''^1
UTH
Disputes - international: none
/-
533
57 43N
11 58 E
Gotland (island)
57 30N
18 33E
Gough Island
Saint Helena
40 20S
9 55W
Graham Land (region)
Oman, Gulf of
Indian Ocean
Ombai Strait
Pacific Ocean
Oran (city)
59 20N
Stuttgart (city)
Svizzera (local Italian name for Switzerland)','a11b50a75925067e2142aa40e85088892942c1405b8d4c52deb77a9c315ee371','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cf779c9c12898c5a42c4a1a3be4015ca6109038aa53dc826c22cf6f3d0e5c0ad',2007,'ZW','Zimbabwe','transnational-issues',1199,'539
another term for the traditionally Marxist-Leninist states of the USSR and Eastern Europe, with authoritarian
governments and command economies based on the Soviet model; the term is fading from use; see centrally
planned economies
members— (6) China, Kazakhstan, Kyrgyzstan, Russia, Tajikistan, Uzbekistan
observer— (4) India. Iran, Mongolia, Pakistan
socialist countries in general, countries in which the government owns and plans the use of the major factors of production; note— the
term is sometimes used incorrectly as a synonym for Communist countries
South a popular term for the poorer, less industrialized countries generally located south of the developed countries; the
counterpart of the North; see less developed countries (LDCs)
South Asia Co-operative Environment
Program (SACEP)
established— January 1 983
aim— to promote regional cooperation in South
Asia in the field of environment, both natural and
human, and on issues of economic and social
development; to support conservation and
management of natural resources of the region
members— {8) Afghanistan, Bangladesh, Bhutan, India, Maldives, Nepal, Pakistan, Sri Lanka
652
Appendix B: International Organizations and Groups (continued)
South Pacific Forum (SPF)
note— see Pacific Island Forum
Southern African Development Community
(SADC)
note— evolved from the Southern African
Development Coordination Conference
(SADCC)
established-) 7 August 1992
aim— to promote regional economic
development and integration
members— (14) Angola, Botswana, Democratic Republic of the Congo, Lesotho, Madagascar, Malawi, Mauritius,
Mozambique, Namibia, South Africa, Swaziland, Tanzania, Zambia, Zimbabwe
Southern Cone Common Market (Mercosur)
or Southern Common Market
note— also known as Mercado Comun del Cono
Sur (Mercosur)
established— 26 March 1991
aim— to increase regional economic cooperation
members— (4) Argentina, Brazil, Paraguay, Uruguay
associate member— (6) Bolivia, Chile, Colombia, Ecuador, Peru, Venezuela
Third World
another term for the less developed countries; the term is obsolescent; see less developed countries (LDCs)
underdeveloped countries
undeveloped countries
United Nations (UN)
established— 26 June 1945
effective— 24 October 1945
aim— to maintain international peace and
security and to promote cooperation involving
economic, social, cultural, and humanitarian
problems
refers to those less developed countries with the potential for above-average economic growth; see less developed
countries (LDCs)
refers to those extremely poor less developed countries (LDCs) with little prospect for economic growth; see least
developed countries (LLDCs)
constituent organizations— -the UN is composed of six principal organs and numerous subordinate agencies and
bodies as follows:
1) Secretariat
2) General Assembly: Joint United Nations Program on HIV/AIDS (UN AIDS), International Research and Training
Institute for the Advancement of Women (INSTRAW), Office of the United Nations High Commissioner for Human
Rights (OHCHR), United Nations Center for Human Settlements (UN-Habitat), United Nations Children''s Fund
(UNICEF), United Nations Conference on Trade and Development (UNCTAD), United Nations Development
Program (UNDP), United Nations Drug Control Program (UNDCP), United Nations Environment Program (UNEP),
United Nations High Commissioner for Refugees (UNHCR), United Nations Institute for Disarmament Research
(UNIDIR), United Nations Institute for Training and Research (UNITAR), United Nations Interregional Crime and
Justice Research Institute (UNICRI), United Nations Population Fund (UNFPA), United Nations Office of Project
Services (UNOPS), United Nations Relief and Works Agency for Palestine Refugees in the Near East (UNRWA),
United Nations Research Institute for Social Development (UNRISD), United Nations System Staff College
(UNSSC), United Nations University (UNU), World Food Program (WFP)
3) Security Council: International Criminal Tribunal for the Former Yugoslavia (ICTY), International Criminal Tribunal
for Rwanda (ICTR), United Nations Compensation Commission, United Nations Disengagement Observer Force
(UNDOF), United Nations Interim Administration Mission in Kosovo (UNMIK), United Nations Interim Force in
Lebanon (UNIFIL), United Nations Mission in Liberia (UNMIL), United Nations Military Observer Group in India and
Pakistan (UNMOGIP), United Nations Operation in Burundi (ONUB), United Nations Operation in Cote d''lvoire
(UNOCI), United Nations Mission for the Referendum in Western Sahara (MINURSO), United Nations Mission in
Ethiopia and Eritrea (UNMEE), United Nations Mission in Sierra Leone (UNAMSIL), United Nations Mission in the
Sudan (UNMIS), United Nations Monitoring and Verification Commission (UNMOVIC), United Nations Observer
Mission in Georgia (UNOMIG), United Nations Organization Mission in the Democratic Republic of the Congo
(MONUC), United Nations Peace-Keeping Force in Cyprus (UNFICYP), United Nations Stabilization Mission in Haiti
(MINUSTAH), and United Nations Truce Supervision Organization (UNTSO)
4) Economic and Social Council (ECOSOC): Commission for Social Development, Commission on Crime
Prevention and Criminal Justice, Commission on Human Rights, Commission on Narcotics Drugs, Commission on
Population and Development, Commission on Science and Technology for Development, Commission on
Sustainable Development, Commission on the Status of Women, Economic and Social Commission for Asia and the
Pacific (ESCAP), Economic and Social Commission for Western Asia (ESCWA), Economic Commission for Africa
(ECA), Economic Commission for Europe (ECE), Economic Commission for Latin America and the Caribbean
(ECLAC), Food and Agriculture Organization of the United Nations (FAO), International Atomic Energy Agency
(IAEA), International Bank for Reconstruction and Development (IBRD), International Center for Secretariat of
Investment Disputes (ICSID), International Civil Aviation Organization (ICAO), International Development
Association (IDA), International Finance Corporation (IFC), International Fund for Agricultural Development (IFAD),
653
Appendix B: International Organizations and Groups (continued)
United Nations (UN) (continued)
United Nations Children''s Fund (UNICEF)
International Labor Organization (ILO), International Maritime Organization (IMO), International Monetary Fund
(IMF), International Telecommunication Union (ITU), Multilateral Investment Geographic Agency (MIGA), Statistical
Commission, United Nations Educational, Scientific, and Cultural Organization (UNESCO), United Nations Forum
on Forests, United Nations Industrial Development Organization (UNIDO), Universal Postal Union (UPU), World
Health Organization (WHO). World Intellectual Property Organization (WIPO), World Meteorological Organization
(WMO), World Tourism Organization (WToO), and World Trade Organization (WTO)
5) Trusteeship Council (inactive; no trusteeships at this time)
6) International Court of Justice (ICJ)
UN members— (191) Afghanistan, Albania. Algeria, Andorra, Angola, Antigua and Barbuda, Argentina, Armenia,
Australia, Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile, China, Colombia, Comoros.
Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''lvoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, East Timor, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Jamaica, Japan. Jordan. Kazakhstan, Kenya, Kiribati, North Korea, South Korea. Kuwait.
Kyrgyzstan, Laos, Latvia, Lebanon. Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated
States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands,
NZ, Nicaragua, Niger, Nigeria, Norway. Oman. Pakistan, Palau, Panama. Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal. Qatar. Romania. Russia, Rwanda. Saint Kitts and Nevis. Saint Lucia, Saint Vincent
and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia and Montenegro,
Seychelles, Sierra Leone, Singapore. Slovakia. Slovenia, Solomon Islands. Somalia, South Africa, Spain, Sri Lanka.
Sudan, Suriname. Swaziland, Sweden. Switzerland, Syria, Tajikistan, Tanzania, Thailand. Togo, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Turkmenistan. Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu,
Venezuela, Vietnam, Yemen, Zambia, Zimbabwe: note— all UN members are represented in the General Assembly
observers— (1 plus the Palestine Liberation Organization) Holy See. Palestine Liberation Organization
members— (37) selected on a rotating basis from all regions
note— acronym retained from the predecessor
organization, UN International Children''s
Emergency Fund
established— -1 1 December 1 946
aim— to help establish child health and welfare
services
United Nations Conference on Trade and
Development (UNCTAD)
members— (192) all UN members plus Holy See
established— 30 December 1 964
aim— to promote international trade
United Nations Development Program
(UNDP)
members (executive board}— {36) selected on a rotating basis from all regions
established— 22 November 1965
aim— to provide technical assistance to
stimulate economic and social development
United Nations Disengagement Observer
Force (UNDOF)
members— {6) Austria, Canada, Japan, Nepal, Poland. Slovakia
established- -31 May 1974
aim—to observe the 1973 Arab-Israeli
cease-fire; established by the UN Security
Council
654
Appendix B: International Organizations and Groups (continued)
United Nations Educational, Scientific, and
Cultural Organization (UNESCO)
established— 1 6 November 1945
effective— 4 November 1946
aim— to promote cooperation in education,
science, and culture
members— (190) includes all UN member countries except Brunei, Liechtenstein, and Singapore (188 total); plus
Cook Islands and Niue
associate member— (6) Aruba, British Virgin Islands, Cayman Islands, Macau, Netherlands Antilles, Tokelau
United Nations General Assembly
established— 26 June 1945
effective— 24 October 1945
aim— to function as the primary deliberative
organ of the UN
members— (191) all UN members are represented in the General Assembly
United Nations High Commissioner for
Refugees (UNHCR)
established— 3 December 1 949
effective— 1 January 1951
aim— to ensure the humanitarian treatment of
refugees and find permanent solutions to
refugee problems
members (executive committee)— (68) Algeria, Argentina, Australia, Austria, Bangladesh, Belgium, Brazil, Canada,
Chile, China, Colombia, Democratic Republic of the Congo, Cote d''lvoire, Cyprus, Denmark, Ecuador, Egypt,
Ethiopia, Finland, France, Germany, Ghana, Greece, Guinea, Holy See, Hungary, India, Iran, Ireland, Israel, Italy,
Japan, Kenya, South Korea, Lebanon, Lesotho, Madagascar, Mexico, Morocco, Mozambique, Namibia,
Netherlands, NZ, Nicaragua, Nigeria. Norway, Pakistan, Philippines, Poland, Romania, Russia, Serbia and
Montenegro, Somalia, South Africa, Spain, Sudan, Sweden, Switzerland, Tanzania, Thailand, Tunisia, Turkey,
Uganda, UK, US, Venezuela, Yemen, Zambia
United Nations Industrial Development
Organization (UNIDO)
established— -17 November 1966
effective— 1 January 1967
aim— UN specialized agency that promotes
industrial development especially among the
members
members— (171) includes all UN member countries except Andorra, Antigua and Barbuda, Australia, Brunei,
Canada, Estonia, Iceland, Kiribati, Latvia, Liechtenstein, Marshall Islands, Federated States of Micronesia, Nauru,
Palau, Samoa, San Marino, Singapore, Solomon Islands, Tuvalu, US
United Nations Interim Administration
Mission in Kosovo (UNMIK)
established— ''\\0 June 1999
aim— to promote the establishment of
substantial autonomy and self-government in
Kosovo; to perform basic civilian administrative
functions; to support the reconstruction of key
infrastructure and humanitarian and disaster
relief
note— gives civilian support only; works closely NATO Kosovo Force (KFOR)
United Nations Military Observer Group in
India and Pakistan (UNMOGIP)
established— 24 January 1949
aim— to observe the 1949 India-Pakistan
cease-fire; established by the UN Security
Council
members— (9) Belgium, Chile, Croatia, Denmark, Finland, Italy, South Korea, Sweden, Uruguay
United Nations Mission in Ethiopia and
Eritrea (UNMEE)
established— -31 July 2000
aim— to monitor the cessation of hostilities
members— (40) Algeria, Austria, Bangladesh, Bosnia and Herzegovina, Bulgaria, China, Croatia, Czech Republic,
Denmark, Finland, France, The Gambia, Germany, Ghana, Greece, India, Iran, Italy, Jordan, Kenya, Malaysia,
Namibia, Nepal, Nigeria, Norway, Paraguay, Peru, Poland, Romania, Russia, South Africa, Spain, Sweden,
Switzerland, Tanzania, Tunisia, Ukraine, US, Uruguay, Zambia
655
Appendix B: International Organizations and Groups (continued)
United Nations Mission in Liberia (UNMIL)
established— 19 September 2003
aim— to support the cease-fire agreement and
peace process, protect UN facilities and people,
support humanitarian activities, and assist in
national security reform
members— (48) Bangladesh, Benin, Bolivia, Brazil, Bulgaria, China, Croatia, Czech Republic, Denmark, Ecuador,
Egypt, El Salvador, Ethiopia, Finland, France, The Gambia, Germany, Ghana, Indonesia, Ireland, Jordan, Kenya,
South Korea, Kyrgyzstan, Malawi, Malaysia, Mali, Moldova, Namibia, Nepal, Niger, Nigeria, Pakistan, Paraguay,
Peru, Philippines, Poland, Romania, Russia, Senegal, Serbia and Montenegro, Sierra Leone, Sweden, Togo,
Ukraine, UK, US, Zambia
United Nations Mission in Sierra Leone
(UNAMSIL)
established— 22 October 1999
aim— to cooperate with the Government of
Sierra Leone and the other parties to the Peace
Agreement in the implementation of the
agreement; to monitor the military and security
situation in Sierra Leone; to monitor the
disarmament and demobilization of combatants
and members of the Civil Defense Forces (CFD);
to assist in monitoring respect for international
humanitarian law
members— (27) Bangladesh, Bolivia, China, Croatia, Czech Republic, Egypt, The Gambia, Germany, Ghana,
Guinea, Indonesia, Jordan, Kenya, Kyrgyzstan, Malaysia, Nepal, Nigeria, Pakistan, Russia, Slovakia, Sweden,
Tanzania, Thailand, Ukraine, UK, Uruguay, Zambia
United Nations Monitoring, Verification, and
Inspection Commission (UNMOVIC)
note— formerly known as United Nations Special
Commission for the Elimination of Iraq''s
Weapons of Mass Destruction (UNSCOM)
established— December 1 999
aim—\\o identify, account for, and eliminate Iraq''s
weapons of mass destruction and the capacity to
produce them
commissioners— (1 6) Argentina, Brazil, Canada, China, France, Germany, India, Ireland, Japan, Mexico, Nigeria,
Russia, Senegal, Ukraine, UK, US; note— the organization''s mandate has been extended up to early 2006
United Nations Observer Mission in Georgia
(UNOMIG)
established- -24 August 1993
aim— to verify compliance with the cease-fire
agreement, to monitor weapons exclusion zone,
and to supervise CIS peacekeeping force for
Abkhazia; established by the UN Security
Council
members— (25) Albania, Austria, Bangladesh, Croatia, Czech Republic, Denmark, Egypt, France, Germany,
Greece, Hungary, Indonesia, Jordan, South Korea, Pakistan, Poland, Romania, Russia, Sweden, Switzerland,
Turkey, Ukraine, UK, US, Uruguay
United Nations Operation in Burundi (ONUB)
established— -21 May 2004
aim— to support and help implement the efforts
undertaken by Burundians to restore lasting
peace and bring about national reconciliation
members— -(47) Algeria, Bangladesh, Belgium, Benin, Bolivia, Burkina Faso, Chad, China, Egypt, Ethiopia, Gabon,
The Gambia, Ghana. Guatemala, Guinea, India. Jordan, Kenya, South Korea, Kyrgyzstan, Malawi, Malaysia, Mali,
Mozambique, Nambia, Nepal, Netherlands, Niger, Nigeria, Pakistan, Paraguay, Peru, Philippines, Portugal,
Romania, Russia, Senegal, Serbia and Montenegro, South Africa, Spain, Sri Lanka, Thailand, Togo, Tunisia,
Uruguay, Yemen. Zambia
United Nations Operation in Cote d''lvoire
(UNOCI)
established— 27 February 2004
aim— to facilitate the implementation by the
Ivorian parties of the peace agreement signed
by them in January 2003
members— (41) Bangladesh. Benin, Bolivia, Brazil. Chad, China, Republic of the Congo, Croatia, Dominican
Republic, Ecuador, El Salvador, France, The Gambia, Ghana, Guatemala, Guinea, India, Ireland, Jordan, Kenya,
Moldova, Morocco, Namibia, Nepal, Niger, Nigeria, Pakistan, Paraguay, Peru, Philippines, Poland, Romania, Russia,
Senegal, Serbia and Montenegro, Togo, Tunisia, Uganda, Uruguay. Yemen, Zambia
656
Appendix B: International Organizations and Groups (continued)
United Nations Organization Mission in the
Democratic Republic of the Congo (MONUC)
established— 30 November 1999
aim— to establish contacts with the signatories
to the cease-fire agreement and to plan for the
observation of the cease-fire and
disengagement of forces
members— (49) Algeria, Bangladesh, Belgium, Benin, Bolivia, Bosnia and Herzegovina, Burkina Faso, Cameroon,
Canada, China, Czech Republic, Denmark, Egypt, France, Ghana, Guatemala, India, Indonesia, Ireland, Jordan,
Kenya, Malawi, Malaysia, Mali, Mongolia, Morocco, Mozambique, Nepal, Netherlands, Niger, Nigeria, Pakistan,
Paraguay, Peru, Poland, Romania, Russia, Senegal, Serbia and Montenegro, South Africa, Spain, Sri Lanka,
Sweden, Switzerland, Tunisia, Ukraine, UK, Uruguay, Zambia
United Nations Peace-keeping Force in
Cyprus (UNFICYP)
members— (9) Argentina, Austria, Canada, Croatia, Finland, Hungary, Slovakia, UK, Uruguay
established— 4 March 1964
aim— to serve as a peacekeeping force between
Greek Cypriots and Turkish Cypriots in Cyprus;
established by the UN Security Council
United Nations Population Fund (UNFPA)
note— acronym retained from predecessor
organization UN Fund for Population Activities
established— Ju\\y 1967
aim— to assist both developed and developing
countries to deal with their population problems
members (executive board)— (36) selected on a rotating basis from all regions
United Nations Relief and Works Agency for
Palestine Refugees in the Near East
(UNRWA)
members (advisory commission)— {10) Belgium, Egypt, France, Japan, Jordan, Lebanon, Syria, Turkey, UK, US
established— 8 December 1949
aim— to provide assistance to Palestinian
refugees
United Nations Secretariat
established— 26 June 1945
effective— 24 October 1945
aim— to serve as the primary administrative
organ of the UN; a Secretary General is
appointed for a five-year term by the General
Assembly on the recommendation of the
Security Council
members— the UN Secretary General and staff
United Nations Security Council (UNSC)
established— 26 June 1945
effective— 24 October 1945
aim— to maintain international peace and
security
permanent members— (5) China, France, Russia, UK, US
nonpermanent members— {10) elected for two-year terms by the UN General Assembly; Argentina (2005-06),
Republic of the Congo (2006-07), Denmark (2005-06), Ghana (2006-07), Greece (2005-06), Japan (2005-06), Peru
(2006-07), Qatar (2006-07), Slovakia (2006-07), Tanzania (2005-06)
United Nations Stabilization Mission in Haiti
(MINUSTAH)
established— 30 April 2004
aim—\\o stabilize Haiti in many areas for at least
six months
members— {22) Argentina, Benin, Bolivia, Brazil, Canada, Chile, Croatia, Ecuador, France, Guatemala, Jordan,
Malaysia, Morocco, Nepal, Paraguay, Peru, Philippines, Spain, Sri Lanka, US, Uruguay, Yemen
657
Appendix B: International Organizations and Groups (continued)
Universal Postal Union (UPU)
established— 9 October 1874, affiliated with the
UN 15 November 1947
effective— 1 July 1948
aim— to promote international postal
cooperation; a UN specialized agency
Warsaw Pact (WP)
West African Development Bank (WADB)
note— also known as Banque Ouest-Africaine
de Developpement (BOAD): is a financial
institution of WAEMU
established— 14 November 1973
aim— to promote regional economic
development and integration
members— (188) includes all UN member countries except Andorra, Marshall Islands, Federated States of
Micronesia, and Palau (187 total); plus Holy See; note— includes the following dependencies or areas of special
interest: Australia (Norfolk Island), China (Hong Kong, Macau), Denmark (Faroe Islands, Greenland), France
(French Guiana, French Polynesia, Martinique, Mayotte, New Caledonia, Reunion, Saint Pierre and Miquelon, Wallis
and Futuna), Netherlands (Aruba, Netherlands Antilles), NZ (Cook Island, Niue, Tokelau), UK (Guernsey, Isle of
Man, Jersey; Anguilla, Bermuda, British Virgin Islands, Cayman Islands, Falkland Islands, Gibraltar, Montserrat,
Pitcairn, Saint Helena, Turks and Caicos), US (American Samoa, Guam, Puerto Rico, Virgin Islands)
established 14 May 1955 to promote mutual defense; members met 1 July 1991 to dissolve the alliance; member
states at the time of dissolution were: Bulgaria, Czechoslovakia, Hungary, Poland, Romania, and the USSR; earlier
members included German Democratic Republic (GDR) and Albania
regional members— (9) Central Bank of West African States, Benin, Burkina Faso, Cote d''lvoire, Guinea-Bissau,
Mali, Niger, Senegal, Togo
international/nonregional members— (5) African Development Bank, Belgium, European Investment Bank, France,
members— (36) selected on a rotating basis from all regions
658
Appendix B: International Organizations and Groups (continued)
World Health Organization (WHO)
established-22 July 1946
effective— 7 April 1948
aim— to deal with health matters worldwide; a
UN specialized agency
World Intellectual Property Organization
(WIPO)
established-) A July 1967
effective— 2Q April 1970
aim— to turnish protection for literary, artistic,
and scientific works; a UN specialized agency
members— (192) includes all UN member countries except Liechtenstein (190 total); plus Cook Islands and Niue
World Meteorological Organization (WMO)
established-) 1 October 1947
efYecf/ve — 4 April 1951
aim— to sponsor meteorological cooperation; a
UN specialized agency
World Tourism Organization (WToO)
established— 2 January 1 975
aim— to promote tourism as a means of
contributing to economic development,
international understanding, and peace
World Trade Organization (WTO)
note— succeeded General Agreement on Tariff
and Trade (GATT)
established— 15 April 1994
effective— 1 January 1995
aim—\\o provide a forum to resolve trade
conflicts between members and to carry on
negotiations with the goal of further lowering
and/or eliminating tariffs and other trade barriers
members— (183) includes all UN member countries except East Timor, Kiribati, Marshall Islands, Federated States
of Micronesia, Nauru, Palau, Solomon Islands, Tuvalu, Vanuatu (182 total); plus Holy See
members— (189) includes all UN member countries except Andorra, East Timor, Equatorial Guinea, Liechtenstein,
Marshall Islands, Nauru, Palau, Saint Kitts and Nevis, Saint Vincent and the Grenadines, San Marino, Tuvalu (180
total); plus Aruba, British Caribbean Territories, Cook Islands, French Polynesia, Hong Kong, Macau, Netherlands
Antilles, New Caledonia, and Niue
members— (146) Afghanistan, Albania, Algeria, Andorra, Angola, Argentina, Armenia, Australia, Austria,
Azerbaijan, Bahrain, Bangladesh, Belarus, Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Bulgaria, Burkina Faso, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad,
Chile, China, Colombia, Democratic Republic of the Congo, Republic of the','f1540b4bfa50cf31fbe76387636dc06833ed39edb8a36ce10e8fe2019b192dd6','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f58e2db252c094a152390901ed8f11e614b6b724f8341b80db1a90a0bee46e68',2007,'ZW','Zimbabwe','transnational-issues',1200,'Congo, Costa Rica, Cote d''lvoire,
Croatia, Cuba, Cyprus, Czech Republic, Djibouti, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Ethiopia, Fiji, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala,
Guinea, Guinea-Bissau, Haiti, Honduras, Hungary, India, Indonesia, Iran, Iraq, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho,
Libya, Lithuania, Macedonia, Madagascar Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius,
Mexico, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, Nicaragua, Niger,
Nigeria, Oman, Pakistan, Panama, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia and Montenegro, Seychelles,
Sierra Leone, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan, Swaziland, Switzerland, Syria,
Tanzania, Thailand, Togo, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, Uruguay, Uzbekistan, Venezuela,
Vietnam, Yemen, Zambia, Zimbabwe
associate member— {7) Aruba, Flanders, Hong Kong, Macau, Madeira Islands, Netherlands Antilles, Puerto Rico
observers—^ plus the Palestine Liberation Organization) Holy See, Palestine Liberation Organization
members— (148) Albania, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Bahrain,
Bangladesh, Barbados, Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Canada, Central African Republic, Chad, Chile, China, Colombia, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''lvoire, Croatia, Cuba, Cyprus, Czech Republic,
Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Estonia, EC, Fiji, Finland, France,
Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Haiti, Honduras, Hong Kong, Hungary, Iceland, India, Indonesia, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kenya, South Korea, Kuwait, Kyrgyzstan, Latvia, Lesotho, Liechtenstein, Lithuania, Luxembourg, Macau,
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova,
Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Rwanda,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Senegal, Sierra Leone, Singapore, Slovakia,
Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka, Suriname, Swaziland, Sweden, Switzerland, Taiwan,
Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda, UAE, UK, US, Uruguay, Venezuela,
Zambia, Zimbabwe
observers— (33) Afghanistan, Algeria, Andorra, Azerbaijan, The Bahamas, Belarus, Bhutan, Bosnia and
Herzegovina, Cape Verde, Equatorial Guinea, Ethiopia, Holy See, Iran, Iraq, Kazakhstan, Laos, Lebanon, Libya,
Montenegro, Russia, Samoa, Sao Tome and Principe, Saudi Arabia, Serbia, Seychelles, Sudan, Tajikistan, Tonga,
Ukraine, Uzbekistan, Vanuatu, Vietnam, Yemen; note— with the exception of the Holy See, an observer must start
accession negotiations within five years of becoming observers; Montenegro and Serbia each sent observers
659
Appendix B: International Organizations and Groups (continued)
Zangger Committee (ZC) members— (35) Argentina, Australia, Austria, Belgium, Bulgaria, Canada, China, Czech Republic, Denmark.
Finland, France, Germany, Greece, Hungary, Ireland, Italy, Japan, South Korea, Luxembourg, Netherlands,
established— early 1970s Norway, Poland, Portugal, Romania, Russia, Slovakia, Slovenia, South Africa, Spain, Sweden, Switzerland,
aim— to establish guidelines for the export Turkey, Ukraine, UK, US
control provisions of the Nonproliferation of
Nuclear Weapons Treaty (NPT)
660
Appendix C:
Selected International Environmental Agreements
■
Air Pollution
see Convention on Long-Range Transboundary Air Pollution
Air Pollution-Nitrogen Oxides
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution Concerning the Control of
Emissions of Nitrogen Oxides or Their Transboundary Fluxes
Air Pollution-Persistent Organic Pollutants see Protocol to the 1 979 Convention on Long-Range Transboundary Air Pollution on Persistent Organic Pollutants
Air Pollution-Sulphur 85
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on the Reduction of Sulphur
Emissions or Their Transboundary Fluxes by at least 30%
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on Further Reduction of Sulphur
Emissions
see Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution Concerning the Control of
Emissions of Volatile Organic Compounds or Their Transboundary Fluxes
Antarctic-Environmental Protocol see Protocol on Environmental Protection to the Antarctic Treaty
Air Pollution-Sulphur 94
Air Pollution-Volatile Organic Compounds
Antarctic Treaty
opened for signature— 1 December 1 959
entered into force— 23 June 1 961
objective— -to ensure that Antarctica is used for
peaceful purposes only (such as international
cooperation in scientific research); to defer the
question of territorial claims asserted by some
nations and not recognized by others; to provide
an international forum for management of the
region; applies to land and ice shelves south of
60 degrees south latitude
parties— (45) Argentina, Australia, Austria, Belgium, Brazil, Bulgaria, Canada, Chile, China, Colombia, Cuba, Czech
Republic, Denmark, Ecuador, Estonia, Finland, France, Germany, Greece, Guatemala, Hungary, India, Italy, Japan,
North Korea, South Korea, Netherlands, NZ, Norway, Papua New Guinea, Peru, Poland, Romania, Russia, Slovakia,
South Africa, Spain, Sweden, Switzerland, Turkey, Ukraine, UK, US, Uruguay, Venezuela
Basel Convention on the Control of
Transboundary Movements of Hazardous
Wastes and Their Disposal
note— abbreviated as Hazardous Wastes
opened for signature— 22 March 1 989
entered into force— 5 May 1 992
objective— to reduce transboundary movements
of wastes subject to the Convention to a
minimum consistent with the environmentally
sound and efficient management of such
wastes; to minimize the amount and toxicity of
wastes generated and ensure their
environmentally sound management as closely
as possible to the source of generation; and to
assist LDCs in environmentally sound
management of the hazardous and other wastes
they generate
Biodiversity
parties— (149) Albania, Algeria, Andorra, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan,
The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Bulgaria, Burkina Faso, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Costa Rica, Cote d''lvoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Estonia, Ethiopia, EU, Finland,
France, The Gambia, Georgia, Germany, Greece, Guatemala, Guinea, Guyana, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Ireland, Israel, Italy, Japan, Jordan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Latvia,
Lebanon, Lesotho, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco, Mongolia,
Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Saudi Arabia, Senegal, Serbia and
Montenegro, Seychelles, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sweden, Switzerland,
Syria, Tanzania, Thailand, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, Uruguay,
Uzbekistan, Venezuela, Vietnam, Yemen, Zambia
countries that have signed, but not yet ratified— (3) Afghanistan, Haiti, US
see Convention on Biological Diversity
Climate Change
see United Nations Framework Convention on Climate Change
Climate Change-Kyoto Protocol
see Kyoto Protocol to the United Nations Framework Convention on Climate Change
661
Appendix C: Selected International Environmental Agreements (continued)
Convention for the Conservation of Antarctic
Seals
note— abbreviated as Antarctic Seals
opened for signature— 1 June 1972
entered into force— 1 1 March 1 978
objective— to promote and achieve the
protection, scientific study, and rational use of
Antarctic seals, and to maintain a satisfactory
balance within the ecological system of
Zl
ZW
ZWE
716
.zw
676
Appendix E:
Cross-Reference List of Hydrographic Data Codes
IHO 23 4TH:
Limits of Oceans and Seas, Special Publication 23, Draft 4th Edition 1986, published by the International Hydrographic Bureau
of the International Hydrographic Organization
IHO 23 3RD:
ACIC M 491:
Limits of Oceans and Seas, Special Publication 23, 3rd Edition 1 953, published by the International Hydrographic Organization
Chart of Limits of Seas and Oceans, revised January 1958, published by the Aeronautical Chart and Information Center
(ACIC), United States Air Force; note - ACIC is now part of the National Geospatial-lntelligence Agency (NGA)
DIAM 65 18:
Geopolitical Data Elements and Related Features, Data Standard No.4, Defense Intelligence Agency Manual 65-18,
December 1994, published by the Defense Intelligence Agency
The US Government has not yet adopted a standard for hydrographic codes similar to the Federal Information Processing
Standards (FIPS) 10-4 country codes. The names and limits of the following oceans and seas are not always directly
comparable because of differences in the customers, needs, and requirements of the individual organizations. Even the
number of principal water bodies varies from organization to organization. Factbook users, for example, find the Atlantic Ocean
and Pacific Ocean entries useful, but none of the following standards include those oceans in their entirety. Nor is there any
provision for combining codes or overcodes to aggregate water bodies. The recently delimited Southern Ocean is not included.
Principal Oceans and Seas of the World
With Hydrographic Codes by Institution
IHO
23-4th
IHO
23-3rd*
ACIC
M49-1
DIAM
65-18
Arctic Ocean
9
17
A
5A
Atlantic Ocean
—
—
—
—
North Atlantic Ocean
1
23
B
1A
South Atlantic Ocean
4
32
C
2A
Baltic Sea
2
1
B26
7B
Indian Ocean
5
45
F
6A
Mediterranean Sea
3.1
28
B11
—
Eastern Mediterranean
3.1.2
28 B
—
8E
Western Mediterranean
3.1.1
28 A
—
8W
Pacific Ocean
—
—
—
—
North Pacific Ocean
7
57
D
3A
South Pacific Ocean
8
61
E
4A
South China and Eastern Archipelagic Seas
49,48
D18 plus others
3U plus others
The letters after the numbers are subdivisions, not footnotes.
677
Appendix F:
Cross-Reference List of Geographic Names
This appendix cross-references a wide variety of geographic names to the appropriate
Factbook "country" entry. Additional information is included in parentheses.
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Abidjan (capital)
Cote d''lvoire
519N
4 02W
Abkhazia (region)
17 50S
3103E
Harvey Islands (former name for Cook Islands)
Rhodesia, Northern (former name for Zambia)
17 50S
105 00 W
Salzburg (city)
20 00S
30 00E
South-West Africa (former name for Namibia)','334d4df1a173fdb9202adc6491d2ec45a424d946f73ce46a14997edac1e625c4','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63c41664837ec8f0641a6a52d67bf51063b7771e3f03fb66c0b22dacf222cd84',2007,'TJ','Tajikistan','transnational-issues',1201,'0 SO lOOlor
Tanzania
38 35N
68 48E
Dutch Antilles (former name for the Netherlands Antilles)
Netherlands Antilles
12 10 N
68 30W
Dutch East Indies (former name for Indonesia)
Tahiti (island)','e4b8ad04f4a0f535f589e826b9732046cc4ee7eecec35831daa48c94f6bd902b','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea244426b7520d456d5a9eda77e13e7e17982d2d96b42205c5c0eb787c9e7731',2007,'UZ','Uzbekistan','transnational-issues',1210,'Disputes • international: boundary agreements
signed in 2002 cede 1,000 sq km of Pamir Mountain
range to China in return for China relinquishing claims
to 28,000 sq km of Tajikistani lands, but neither state
has published maps of ceded areas and demarcation
has not yet commenced; talks continue with
Uzbekistan to delimit border and remove minefields;
disputes in Isfara Valley delay delimitation with
Disputes - international: prolonged drought and
cotton monoculture in Uzbekistan and Turkmenistan
creates water-sharing difficulties for Amu Darya river
states; delimitation with Kazakhstan complete with
demarcation underway; border delimitation of 130 km
of border with Kyrgyzstan is hampered by serious
disputes around enclaves and other areas
594
Uzbekistan (continued)
Refugees and internally displaced persons:
refugees (country of origin): 39,202 (Tajikistan) 5,238
(Afghanistan)
IDPs: 3,000 (forced population transfers by
government from villages near Tajikistan border)
(2005)
Illicit drugs: transit country for Afghan narcotics
bound for Russian and, to a lesser extent, Western
European markets; limited illicit cultivation of cannabis
and small amounts of opium poppy for domestic
consumption; poppy cultivation almost wiped out by
government crop eradication program; transit point for
heroin precursor chemicals bound for Afghanistan
Vanuatu SH
lies
South
Torres
0
Pacific
0
Ocean
0" lies
Banks
Espiritu O
Santo
\\Uk Aoba \\Maewo
Lugartville I <C? \\
1 Pentecdte
2
CD
Malakula^X^ W ryW
X
CD
CT
j£<Forari
PORT® Elate
""
VILA
ex
CO
Erromango ilpola ^
Coral Tannan
0
Sea
Anatom
Matthew
islands claimed Hunter
by FRANCE
and VANUATU
O 50 100 150 km
0 50 100 150 mi
new independent states (NIS)
a term referring to all the countries of the FSU except the Baltic countries (Estonia, Latvia, Lithuania)
newly industrializing countries (NICs)
former term for the newly industrializing economies; see newly industrializing economies (NIEs)
newly industrializing economies (NIEs)
that subgroup of the less developed countries (LDCs) that has experienced particularly rapid industrialization of their
economies; formerly known as the newly industrializing countries (NICs); also known as advanced developing
countries; usually includes the Four Dragons (Hong Kong, South Korea, Singapore, Taiwan) and Brazil
648
Appendix B: International Organizations and Groups (continued)
Nonaligned Movement (NAM)
established— 1-6 September 1961
aim— to establish political and military
cooperation apart from the traditional East or
West blocs
Nordic Council (NC)
established- 1 6 March 1952
effective— 12 February 1953
aim— to promote regional economic, cultural,
and environmental cooperation
members— (114 plus the Palestine Liberation Organization) Afghanistan, Algeria, Angola, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belize, Benin, Bhutan, Bolivia, Botswana, Brunei, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Cote d''lvoire, Cuba, Cyprus, Djibouti, Dominican Republic, Ecuador,
Egypt, Equatorial Guinea, Eritrea, Ethiopia, Gabon, The Gambia, Ghana, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Honduras, India, Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya, North Korea, Kuwait, Laos,
Lebanon, Lesotho, Liberia, Libya, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius,
Mongolia, Morocco, Mozambique, Namibia, Nepal, Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua
New Guinea, Peru, Philippines, Qatar, Rwanda, Saint Lucia, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia
and Montenegro, Seychelles, Sierra Leone, Singapore, Somalia, South Africa, Sri Lanka, Sudan, Suriname,
Swaziland, Syria, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkmenistan, Uganda, UAE, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe, Palestine Liberation Organization
observers— (15) Antigua and Barbuda, Armenia, Azerbaijan, Brazil, China, Costa Rica, Croatia, Dominica, El
Salvadore, Kazakhstan, Kyrgyzstan, Mexico, Paraguay, Ukraine, Uruguay
guests— (28) Australia, Austria, Bosnia and Herzegovina, Bulgaria, Canada, Czech Republic, Finland, Germany,
Greece, Holy See, Hungary, Italy, Japan, South Korea, Netherlands, NZ, Norway, Poland, Romania, Russia, San
Marino, Slovakia, Slovenia, Spain, Sweden, Switzerland, UK, US
members— (5) Denmark (including Faroe Islands and Greenland), Finland (including Aland Islands), Iceland,
Norway, Sweden
observers— (3) the Sami (Lapp) local parliaments of Finland, Norway, and Sweden
Nordic Investment Bank (NIB)
established— 4 December 1975
effective— 1 June 1976
aim— to promote economic cooperation and
development
members— (8) Denmark (including Faroe Islands and Greenland), Estonia, Finland (including Aland Islands),
Iceland, Latvia, Lithuania, Norway, Sweden
North
a popular term for the rich industrialized countries generally located in the northern portion of the Northern
Hemisphere; the counterpart of the South; see developed countries (DCs)
North American Free Trade Agreement
(NAFTA)
members— (3) Canada, Mexico, US
established— 17 December 1992
aim— to eliminate trade barriers, promote fair
competition, increase investment opportunities,
provide protection of intellectual property rights,
and create procedures to settle disputes
North Atlantic Treaty Organization (NATO)
established— A April 1949
aim— to promote mutual defense and
cooperation
members— (26) Belgium, Bulgaria, Canada, Czech Republic, Denmark, Estonia, France, Germany, Greece,
Hungary, Iceland, Italy, Latvia, Lithuania, Luxembourg, Netherlands, Norway, Poland, Portugal, Romania, Slovakia,
Slovenia, Spain, Turkey, UK, US
Nuclear Energy Agency (NEA)
note— also known as OECD Nuclear Energy
Agency
established— 1 February 1 958
aim— to promote the peaceful uses of nuclear
energy; associated with OECD
members— (28) Australia, Austria, Belgium, Canada, Czech Republic, Denmark, Finland, France, Germany, Greece,
Hungary, Iceland, Ireland, Italy, Japan, South Korea, Luxembourg, Mexico, Netherlands, Norway, Portugal, Slovakia,
Spain, Sweden, Switzerland, Turkey, UK, US
649
Appendix B: International Organizations and Groups (continued)
Nuclear Suppliers Group (NSG)
note— also known as the London Suppliers
Group or the London Group
established— 1974
affective— 1975
aim— to establish guidelines for exports of
nuclear materials, processing equipment for
uranium enrichment, and technical information
to countries of proliferation concern and regions
of conflict and instability
members— (44) Argentina, Australia. Austria, Belarus, Belgium, Brazil, Bulgaria, Canada, China, Cyprus, Czech
Republic, Denmark, Estonia, Finland, France, Germany, Greece, Hungary, Ireland, Italy, Japan, Kazakhstan, South
Korea, Latvia, Lithuania, Luxembourg, Malta, Netherlands, NZ, Norway, Poland, Portugal, Romania, Russia,
Slovakia, Slovenia, South Africa, Spain, Sweden, Switzerland, Turkey, Ukraine, UK, US
observer— (1) European Commission (a policy-planning body for the EU)
Organization for Economic Cooperation and
Development (OECD)
established— 14 December 1960
effective— 30 September 1961
aim— to promote economic cooperation and
development
members— (30) Australia, Austria, Belgium, Canada. Czech Republic, Denmark, Finland, France, Germany, Greece,
Hungary, Iceland, Ireland, Italy, Japan. South Korea, "Luxembourg, Mexico. Netherlands, NZ. Norway, Poland,
Portugal, Slovakia, Spain, Sweden, Switzerland, Turkey, UK, US
special member— {1) EU
Organization for Security and Cooperation in
Europe (OSCE)
note— formerly the Conference on Security and
Cooperation in Europe (CSCE) established
3 July 1975
established—] January 1 995
aim— to foster the implementation of human
rights, fundamental freedoms, democracy, and
the rule of law; to act as an instrument of early
warning, conflict prevention, and crisis
management; and to serve as a framework for
conventional arms control and confidence
building measures
members— (55) Albania, Andorra, Armenia, Austria, Azerbaijan, Belarus, Belgium, Bosnia and Herzegovina,
Bulgaria, Canada, Croatia. Cyprus, Czech Republic. Denmark, Estonia, Finland, France, Georgia, Germany.
Greece, Holy See, Hungary, Iceland, Ireland, Italy, Kazakhstan, Kyrgyzstan, Latvia, Liechtenstein, Lithuania,
Luxembourg, Macedonia, Malta, Moldova, Monaco. Netherlands. Norway, Poland, Portugal, Romania, Russia, San
Marino, Serbia and Montenegro, Slovakia, Slovenia, Spain, Sweden. Switzerland, Tajikistan, Turkey, Turkmenistan,
Ukraine, UK, US, Uzbekistan
partners for cooperation— (1 1) Afghanistan, Algeria, Egypt. Israel, Japan, Jordan, South Korea, Mongolia, Morocco,
Thailand, Tunisia
Organization for the Prohibition of Chemical
Weapons (OPCW)
established— 29 April 1997
aim— to enforce the Convention on the
Prohibition of the Development, Production,
Stockpiling, and Use of Chemical Weapons and
on Their Destruction; to provide a forum for
consultation and cooperation among the
signatories of the Convention
members (countries that have ratified the Convention)— (175) Afghanistan, Albania, Algeria Andorra, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, Bahrain, Bangladesh, Belarus, Belgium, Belize, Benin,
Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei. Bulgaria, Burkina Faso, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Chad, Chile, China. Colombia. Democratic Republic of the Congo, Cook Islands,
Costa Rica. Cote d''lvoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominica, East Timor, Ecuador, El
Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Grenada, Guatemala, Guinea. Guyana, Holy See, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Ireland, Italy, Jamaica, Japan. Jordan. Kazakhstan. Kenya, Kiribati, South Korea, Kuwait,
Kyrgyzstan. Laos. Latvia. Lesotho, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi,
Malaysia, Maldives. Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of Micronesia,
Moldova, Monaco. Mongolia, Morocco. Mozambique. Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa. San Marino, Sao Tome and Principe. Saudi Arabia. Senegal, Serbia and Montenegro, Seychelles, Sierra
Leone, Singapore, Slovakia. Slovenia. Solomon Islands. South Africa, Spain, Sri Lanka. Sudan, Suriname.
Swaziland. Sweden, Switzerland, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Tuvalu. Uganda, Ukraine, UAE, UK, US. Uruguay. Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Zambia, Zimbabwe
signatory states (countries that have signed, but not ratified, the Convention)— {11) The Bahamas, Burma,
Cambodia. Central African Republic, Comoros. Republic of the Congo. Djibouti, Dominican Republic,
Guinea-Bissau, Haiti, Israel. Liberia
Organization of African Unity (OAU)
see African Union
650
Appendix B: International Organizations and Groups (continued)
Organization of American States (OAS)
established— 1 4 April 1890 as the International
Union of American Republics; 30 April 1948
adopted present charter
effective— 13 December 1951
aim— to promote regional peace and security as
well as economic and social development
Organization of Arab Petroleum Exporting
Countries (OAPEC)
members— (35) Antigua and Barbuda, Argentina, The Bahamas, Barbados, Belize, Bolivia, Brazil, Canada, Chile,
Colombia, Costa Rica, Cuba (excluded from formal participation since 1962), Dominica, Dominican Republic,
Ecuador, El Salvador, Grenada, Guatemala, Guyana, Haiti, Honduras, Jamaica, Mexico, Nicaragua, Panama,
Paraguay, Peru, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Suriname, Trinidad and
Tobago, US, Uruguay, Venezuela
observers— (60) Algeria, Angola, Armenia, Austria, Azerbaijan, Belgium, Bosnia and Herzegovina, Bulgaria, China,
Croatia, Cyprus, Czech Republic, Denmark, Egypt, Equatorial Guinea, Estonia, EU, Finland, France, Georgia,
Germany, Ghana, Greece, Holy See, Hungary, India, Ireland, Israel, Italy, Japan, Kazakhstan, South Korea, Latvia,
Lebanon, Luxembourg, Morocco, Netherlands, Nigeria, Norway, Pakistan, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Saudi Arabia, Serbia and Montenegro, Slovakia, Slovenia, Spain, Sri Lanka, Sweden,
Switzerland, Thailand, Tunisia, Turkey, Ukraine, UK, Yemen
members— (11) Algeria, Bahrain, Egypt, Iraq, Kuwait, Libya, Qatar, Saudi Arabia, Syria, Tunisia (suspended), UAE
established— 9 January 1 968
aim— to promote cooperation in the petroleum
industry
Organization of Eastern Caribbean States
(OECS)
established--\\Q June 1981
effective— 4 July 1981
aim— to promote political, economic, and
defense cooperation
members— (7) Antigua and Barbuda, Dominica, Grenada, Montserrat, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines
associate member— (2) Anguilla, British Virgin Islands
Organization of Petroleum Exporting
Countries (OPEC)
members— (11) Algeria, Indonesia, Iran. Iraq, Kuwait, Libya, Nigeria, Qatar, Saudi Arabia, UAE, Venezuela
established— 1 4 September 1960
aim— to coordinate petroleum policies
Organization of the Islamic Conference (OIC)
established- 22-25 September 1969
aim— to promote Islamic solidarity in economic,
social, cultural, and political affairs
Pacific Community (SPC)
note— formerly known as the South Pacific
Commission (SPC)
established— 6 February 1 947
effective— 29 July 1948
aim— to promote regional cooperation in
economic and social matters
members— (56 plus the Palestine Liberation Organization) Afghanistan, Albania, Algeria, Azerbaijan, Bahrain,
Bangladesh, Benin, Brunei, Burkina Faso, Cameroon, Chad, Comoros, Cote d''lvoire, Djibouti, Egypt, Gabon, The
Gambia, Guinea, Guinea-Bissau, Guyana, Indonesia, Iran, Iraq, Jordan, Kazakhstan, Kuwait, Kyrgyzstan, Lebanon,
Libya, Malaysia, Maldives, Mali, Mauritania, Morocco, Mozambique, Niger, Nigeria, Oman, Pakistan, Qatar, Saudi
Arabia, Senegal, Sierra Leone, Somalia, Sudan, Suriname, Syria, Tajikistan, Togo, Tunisia, Turkey, Turkmenistan,
Uganda, UAE, Uzbekistan, Yemen, Palestine Liberation Organization
observers— (1 1) AU, Bosnia and Herzegovina, Central African Republic, ECO, LAS, Moro National Liberation Front,
NAM, Russia, Thailand, Turkish Muslim Community of Kibris, UN
members— {27) American Samoa, Australia, Cook Islands, Fiji, France, French Polynesia, Guam, Kiribati, Marshall
Islands, Federated States of Micronesia, Nauru, New Caledonia, NZ, Niue, Northern Mariana Islands, Palau, Papua
New Guinea, Pitcairn Islands, Samoa, Solomon Islands, Tokelau, Tonga, Tuvalu, UK, US, Vanuatu, Wallis and
Futuna
Pacific Islands Forum (PIF)
note— formerly known as South Pacific Forum
(SPF)
established— 5 August 1971
aim— to promote regional cooperation in political
matters
members— (16) Australia, Cook Islands, Fiji, Kiribati, Marshall Islands, Federated States of Micronesia, Nauru, NZ,
Niue, Palau, Papua New Guinea, Samoa, Solomon Islands, Tonga, Tuvalu, Vanuatu
observers— (3) East Timor, French Polynesia, New Caledonia
651
Appendix B: International Organizations and Groups (continued)
Paris Club
established— 1956
aim— to provide a forum for debtor countries to
negotiate rescheduling of debt service payments
or loans extended by governments or official
agencies of participating countries; to help
restore normal trade and project finance to
debtor countries
members— (19) Australia, Austria, Belgium, Canada, Denmark, Finland, France, Germany, Ireland, Italy, Japan,
Netherlands, Norway, Russia, Spain. Sweden, Switzerland, UK, US
Partnership for Peace (PFP)
established— 10-11 January 1994
aim— to expand and intensify political and
military cooperation throughout Europe,
increase stability, diminish threats to peace, and
build relationships by promoting the spirit of
practical cooperation and commitment to
democratic principles that underpin NATO;
program under the auspices of NATO
members— (20) Albania, Armenia, Austria. Azerbaijan, Belarus, Croatia, Finland, Georgia, Ireland, Kazakhstan,
Kyrgyzstan, Macedonia, Moldova, Russia, Sweden, Switzerland, Tajikistan, Turkmenistan, Ukraine, Uzbekistan;
note— a nation that becomes a member of NATO is no longer a member of PFP
Permanent Court of Arbitration (PCA)
established— 29 July 1899
aim— to facilitate the settlement of international
disputes
Second World
Shanghai Cooperative Organization (SCO)
established— 1 5 June 1901
aim— to combat terrorism, extremism, and
separatism; to safeguard regional security
through mutual trust, disarmament, and
cooperative security; and to increase
cooperation in political, trade, economic,
scientific and technological, cultural, and
educational fields
members— (103) Argentina, Australia, Austria. Belarus, Belgium, Belize, Bolivia, Brazil, Bulgaria, Burkina Faso.
Cambodia, Cameroon, Canada. Chile, China. Colombia, Democratic Republic of the Congo, Costa Rica, Croatia,
Cuba, Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Eritrea, Estonia,
Ethiopia, Fiji, Finland, France, Germany, Greece, Guatemala, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Iran, Iraq, Ireland. Israel. Italy, Japan, Jordan, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Libya,
Liechtenstein, Lithuania, Luxembourg. Macedonia. Malaysia, Malta, Mauritius, Mexico, Morocco, Netherlands, NZ,
Nicaragua, Nigeria, Norway, Pakistan, Panama, Paraguay. Peru, Poland, Portugal, Romania, Russia, Saudi Arabia,
Senegal, Serbia and Montenegro. Singapore, Slovakia, Slovenia. South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland. Thailand, Togo. Turkey, Uganda, Ukraine, UK, US, Uruguay, Venezuela, Zambia,
UZ
UZ
UZB
860
.UZ
Tasman Sea
Pacific Ocean
Tasmania (island)
4120N
6918E
Transcarpathia (region; alternate name for
Carpatho-Ukraine)','6ced71fa4fa548a443e4d62d1321f32b4ba5047c1868ce2a1b539136f72b8f2c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91f13bebee178d512a12c800fb1a95242dd91d425f0ce953d9aa11a683e7ed85',2007,'TK','Tokelau','transnational-issues',1211,'(territory of New Zealand)
0
20 40km
0
20 40 mi
Atafu
South Pacific Ocean
Nukunonu
Fakaofo
(N.Z.)
Jarvis Island
(U.S.)
SOUTH PACIFIC
OCEAN','be33183b920f85f58b401d96e7ed7d3b5dce52995cabb1b8bb48696e5504a528','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cbee0fc64188f79aaa3b003277fe214dd0befe2e2a797f064f8083e977bfee53',2007,'TV','Tuvalu','transnational-issues',1224,'''umea
Lolua
_ • Niutao
Tonga.
Nanumanga
Nw
Tanrake
Asau
* Vaitupu
-6
Nukufetau
Savave*
SOUTH
PACIFIC
FUNAFUTI^
Funafuti
OCEAN
Fangaua^
Nukulaelae
0 SO 100 km
0 50 100 mi
I n t r o d u c t i o
Background: In 1974, ethnic differences within the
British colony of the Gilbert and Ellice Islands caused
the Polynesians of the Ellice Islands to vote for
separation from the Micronesians of the Gilbert
Islands. The following year, the Ellice Islands became
the separate British colony of Tuvalu. Independence
was granted in 1978. In 2000, Tuvalu negotiated a
contract leasing its Internet domain name ".tv" for $50
million in royalties over the next dozen years.
Disputes - international: none
/
569
Wallis and
American
Futuna SAMOA Samoa
(FRANCE)
O,^ (U.S.)
TV
TV
TUV
798
.tv
8 00S
178 00 E
Ellsworth Land (region)
44 55N
10 10 s
41 00 N
3 51 S
3 30N
13 00N
60 00N
8 45S
7 40S
25 00N
8 30S
Former Soviet Union (FSU)
Armenia, Azerbaijan, Belarus, Estonia, Georgia,
Kazakhstan, Kyrgyzstan, Latvia, Lithuania,
Moldova, Russia, Tajikistan, Turkmenistan,
Ukraine, Uzbekistan
Formosa (island)
Taiwan
23 30N
Formosa Strait (see Taiwan Strait)
Pacific Ocean
24 00N
147 40 E
51 10 E
72 00E
32 25W
8 42E
122 00 E
27 00E
121 00 E
119 45 E
79 45W
179 12 E
121 00 E
119 00 E
687
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Foroyar (local name for Faroe Islands)
8 30S
179 12 E
Fundy, Bay of
Atlantic Ocean
45 00N
66 00W
Futuna Islands (Hoorn Islands/lies de Home)','8f1d633fd91a3e28cc1f59ff26d13f9ad2ccd9a2716e2273cf45041eae632308','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc9e48c665f9790ed7c4a6f1e0a86d4ab9a19602fbbce359d1f7208365ee8529',2007,'UG','Uganda','transnational-issues',1239,'Disputes - international: Uganda is subject to
armed fighting among hostile ethnic groups, rebels,
armed gangs, militias, and various government forces;
Ugandan refugees have fled the Lord''s Resistance
Army (LRA) into the southern Sudan and the
Democratic Republic of the Congo; LRA forces have
attacked Kenyan villages across the border
Refugees and internally displaced persons:
refugees (country of origin): 214,673 (Sudan) 18,902
(Rwanda) 14,982 (Democratic Republic of Congo)
IDPs: 1 ,330,000-2,000,000 note - ongoing Lord''s
Resistance Army (LRA) rebellion, mainly in the north;
LRA frequently attacks I DP camps (2005)
572
663
Appendix C: Selected International Environmental Agreements (continued)
Convention on Wetlands of International
Importance Especially as Waterfowl Habitat
(Ramsar)
note— abbreviated as Wetlands
opened for signature— 2 February 1971
entered into force— 21 December 1975
objective— to stem the progressive
encroachment on and loss of wetlands now and
in the future, recognizing the fundamental
ecological functions of wetlands and their
economic, cultural, scientific, and recreational
value
parties— (125) Albania, Algeria, Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Belarus, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina
Faso, Cambodia, Canada, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of
the Congo, Costa Rica, Cote d''lvoire, Croatia, Cuba, Czech Republic, Denmark, Ecuador, Egypt, El Salvador,
Estonia, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Guinea,
Guinea-Bissau, Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kenya, South Korea, Latvia, Lebanon, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi,
Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, Monaco, Mongolia, Morocco, Namibia, Nepal, Netherlands,
NZ, Nicaragua, Niger, Norway, Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Romania, Russia, Senegal, Serbia and Montenegro, Sierra Leone, Slovakia, Slovenia, South Africa,
Spain, Sri Lanka, Suriname, Sweden, Switzerland, Syria, Tajikistan, Thailand, Togo, Trinidad and Tobago, Tunisia,
Turkey, Uganda, Ukraine, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Zambia
Desertification
Endangered Species
see United Nations Convention to Combat Desertification in those Countries Experiencing Serious Drought and/or
Desertification, Particularly in Africa
see Convention on the International Trade in Endangered Species of Wild Flora and Fauna (CITES)
Environmental Modification
see Convention on the Prohibition of Military or Any Other Hostile Use of Environmental Modification Techniques
Hazardous Wastes
see Basel Convention on the Control of Transboundary Movements of Hazardous Wastes and Their Disposal
International Convention for the Regulation
of Whaling
note— abbreviated as Whaling
opened for signature— 2 December 1946
entered into force— 1 0 November 1 948
objective— -to protect all species of whales from
overhunting; to establish a system of
international regulation for the whale fisheries to
ensure proper conservation and development of
whale stocks; and to safeguard for future
generations the great natural resources
represented by whale stocks
parties— (42) Antigua and Barbuda, Argentina, Australia, Austria. Brazil, Chile, China, Costa Rica, Denmark,
Dominica, Finland, France, Germany, Grenada, Guinea, India, Ireland, Italy, Japan, Kenya, South Korea, Mexico,
Monaco, Morocco, Netherlands, NZ, Norway, Oman, Panama, Peru, Russia, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Senegal, Solomon Islands, South Africa, Spain, Sweden, Switzerland, UK, US
International Tropical Timber Agreement,
1983
note— abbreviated as Tropical Timber 83
opened for signature— 1 8 November 1 983
entered into force— 1 April 1985; this agreement
expired when the International Tropical Timber
Agreement, 1994, went into force
objective— to provide an effective framework for
cooperation between tropical timber producers
and consumers and to encourage the
development of national policies aimed at
sustainable utilization and conservation of
tropical forests and their genetic resources
parties— (54) Australia, Austria, Belgium, Bolivia, Brazil, Burma, Cameroon, Canada, China, Colombia, Democratic
Republic of the Congo, Republic of the Congo, Cote d''lvoire, Denmark, Ecuador, Egypt, EU, Fiji, Finland, France,
Gabon, Germany, Ghana. Greece, Guyana, Honduras, India, Indonesia, Ireland, Italy, Japan, South Korea, Liberia,
Luxembourg, Malaysia, Nepal, Netherlands. NZ, Norway, Panama, Papua New Guinea, Peru, Philippines, Portugal,
Russia, Spain, Sweden, Switzerland, Thailand, Togo, Trinidad and Tobago, UK, US. Venezuela
International Tropical Timber Agreement,
1994
note— abbreviated as Tropical Timber 94
opened for signature— 26 January 1 994
entered into force— -1 January 1 997
objective— -to ensure that by the year 2000
exports of tropical timber originate from
sustainably managed sources; to establish a
fund to assist tropical timber producers in
obtaining the resources necessary to reach this
objective
parties— (58) Australia, Austria, Belgium, Bolivia, Brazil, Burma, Cambodia, Cameroon, Canada, Central African
Republic. China. Colombia, Democratic Republic of the Congo, Republic of the Congo, Cote d''lvoire, Denmark,
Ecuador, Egypt, EU, Fiji, Finland, France, Gabon, Germany, Ghana, Greece, Guyana, Honduras, India, Indonesia,
Ireland, Italy, Japan, South Korea, Liberia, Luxembourg, Malaysia, Nepal, Netherlands, NZ, Norway, Panama, Papua
New Guinea, Peru, Philippines, Portugal, Spain, Suriname, Sweden, Switzerland, Thailand, Togo, Trinidad and
Tobago, UK, US, Uruguay, Vanuatu, Venezuela
countries that have signed, but not yet ratified— (1 ) Ireland
664
Appendix C: Selected International Environmental Agreements (continued)
Kyoto Protocol to the United Nations
Framework Convention on Climate Change
note— abbreviated as Climate Change-Kyoto
Protocol
opened for signature— 16 March 1998
entered into force— 23 February 2005
objective— to further reduce greenhouse gas
emissions by enhancing the national programs
of developed countries aimed at this goal and by
establishing percentage reduction targets for the
developed countries
Law of the Sea
parties— (144) Algeria, Antigua and Barbuda, Argentina, Armenia, Austria, Azerbaijan, The Bahamas, Bangladesh,
Barbados, Belgium, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, Bulgaria, Burma, Burundi, Cambodia,
Cameroon, Canada, Chile, China, Colombia, Cook Island, Costa Rica, Cuba, Cyprus, Czech Republic, Denmark,
Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Estonia, EU, Fiji, Finland,
France, The Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guyana, Honduras,
Hungary, Iceland, India, Indonesia, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kenya, Kiribati, South Korea,
Kyrgyzstan, Laos, Latvia, Lesotho, Liberia, Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi,
Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritius, Mexico, Federated States of Micronesia, Moldova,
Mongolia, Morocco, Mozambique, Namibia, Nauru, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue, Norway,
Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Saudi Arabia, Senegal,
Seychelles, Slovakia, Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka, Sudan, Sweden, Switzerland,
Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen
countries that have signed, but not yet ratified— (6) Australia, Croatia, Kazakhstan, Monaco, US, Zambia
see United Nations Convention on the Law of the Sea (LOS)
Marine Dumping
see Convention on the Prevention of Marine Pollution by Dumping Wastes and Other Matter (London Convention)
Marine Life Conservation
see Convention on Fishing and Conservation of Living Resources of the High Seas
Montreal Protocol on Substances That
Deplete the Ozone Layer
note— abbreviated as Ozone Layer Protection
opened for signature— 16 September 1987
entered into force— 1 January 1989
objective— to protect the ozone layer by
controlling emissions of substances that
deplete it
parties— (183) Albania, Algeria, Angola, Antigua and Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan,
The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of the Congo, Republic of
the Congo, Costa Rica, Cote d''lvoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, El Salvador, Estonia, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guyana, Haiti, Honduras, Hungary, Iceland,
India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South
Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg,
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia,
Saint Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia and Montenegro,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu,
Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
Nuclear Test Ban
see Treaty Banning Nuclear Weapons Tests in the Atmosphere, in Outer Space, and Under Water
Ozone Layer Protection
see Montreal Protocol on Substances That Deplete the Ozone Layer
Protocol of 1978 Relating to the International
Convention for the Prevention of Pollution
From Ships, 1973 (MARPOL)
note— abbreviated as Ship Pollution
opened for signature- -17 February 1978
entered into force— 2 October 1 983
objective— -to preserve the marine environment
through the complete elimination of pollution by
oil and other harmful substances and the
minimization of accidental discharge of such
substances
parties— (119) Algeria, Angola, Antigua and Barbuda, Argentina, Australia, Austria, The Bahamas, Barbados,
Belarus, Belgium, Belize, Benin, Bolivia, Brazil, Brunei, Bulgaria, Burma, Cambodia, Canada, Chile, China,
Colombia, Comoros, Cote d''lvoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica,
Dominican Republic, Ecuador, Egypt, Equatorial Guinea, Estonia, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Guatemala, Guyana, Honduras, Hungary, Iceland, India, Indonesia, Ireland, Israel, Italy,
Jamaica, Japan, Kazakhstan, Kenya, North Korea, South Korea, Latvia, Lebanon, Liberia, Lithuania, Luxembourg,
Malawi, Malaysia, Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Monaco, Morocco, Netherlands, NZ,
Nicaragua, Norway, Oman, Pakistan, Panama, Papua New Guinea, Peru, Philippines, Poland, Portugal, Romania,
Russia, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and Principe, Senegal,
Serbia and Montenegro, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka,
Suriname, Sweden, Switzerland, Syria, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Tuvalu, Ukraine, UK, US,
Uruguay, Vanuatu, Venezuela, Vietnam
665
Appendix C: Selected International Environmental Agreements (continued)
Protocol on Environmental Protection to the
Antarctic Treaty
note— abbreviated as Antarctic-Environmental
Protocol
opened for signature— 4 October 1 991
entered into force— 1 4 January 1998
objective— to provide for comprehensive
protection of the Antarctic environment and
dependent and associated ecosystems; applies
to the area covered by the Antarctic Treaty
consultative parties— -(27) Argentina, Australia, Belgium, Brazil, Bulgaria, Chile, China, Ecuador, Finland, France,
Germany, India, Italy, Japan, South Korea, Netherlands, NZ, Norway, Peru, Poland, Russia, South Africa, Spain,
Sweden, UK, US, Uruguay
non consultative parties— {16) Austria, Canada, Colombia, Cuba, Czech Republic, Denmark, Greece, Guatemala,
Hungary, North Korea, Papua New Guinea, Romania, Slovakia, Switzerland, Turkey, Ukraine
Protocol to the 1979 Convention on
Long-Range Transboundary Air Pollution
Concerning the Control of Emissions of
Nitrogen Oxides or Their Transboundary
Fluxes
parties— (28) Austria, Belarus, Belgium, Bulgaria, Canada, Czech Republic, Denmark, Estonia, EU, Finland, France,
Germany, Greece, Hungary, Ireland, Italy, Liechtenstein, Luxembourg, Netherlands, Norway, Russia, Slovakia,
Spain, Sweden, Switzerland, Ukraine, UK, US
countries that have signed, but not yet ratified— {1 ) Poland
note— abbreviated as Air Pollution-Nitrogen
Oxides
opened for signature— -31 October 1 988
entered into force— 14 February 1991
objective— to provide for the control or reduction
of nitrogen oxides and their transboundary
fluxes
Protocol to the 1979 Convention on
Long-Range Transboundary Air Pollution
Concerning the Control of Emissions of
Volatile Organic Compounds or Their
Transboundary Fluxes
nofe— abbreviated as Air Pollution-Volatile
Organic Compounds
opened for signature— 18 November 1991
entered into force— 29 September 1997
objective— to provide for the control and
reduction of emissions of volatile organic
compounds in order to reduce their
transboundary fluxes so as to protect human
health and the environment from adverse effects
parties— (21) Austria, Belgium, Bulgaria, Czech Republic, Denmark, Estonia, Finland, France, Germany, Hungary,
Italy, Liechtenstein, Luxembourg, Monaco, Netherlands, Norway, Slovakia, Spain, Sweden, Switzerland, UK
countries that have signed, but not yet ratified— (6) Canada, EU, Greece, Portugal, Ukraine, US
Protocol to the 1979 Convention on
Long-Range Transboundary Air Pollution on
Further Reduction of Sulphur Emissions
note— abbreviated as Air Pollution-Sulphur 94
opened for signature— 1 4 June 1 994
entered into force— 5 August 1 998
objective— to provide for a further reduction in
sulfur emissions or transboundary fluxes
parties— (23) Austria, Belgium, Canada, Croatia, Czech Republic, Denmark, EU, Finland, France, Germany,
Greece, Ireland, Italy, Liechtenstein, Luxembourg, Netherlands, Norway, Slovakia, Slovenia, Spain, Sweden,
Switzerland, UK
countries that have signed, but not yet ratified— (5) Bulgaria, Hungary, Poland, Russia, Ukraine
666
Appendix C: Selected International Environmental Agreements (continued)
Protocol to the 1979 Convention on
Long-Range Transboundary Air Pollution on
Persistent Organic Pollutants
note— abbreviated as Air Pollution-Persistent
Organic Pollutants
opened tor signature— 24 June 1 998
entered into force- -23 October 2003
objective— to provide for the control and
reduction of emissions of persistent organic
pollutants in order to reduce their transboundary
fluxes so as to protect human health and the
environment from adverse effects
parties— (22) Austria, Bulgaria, Canada, Cyprus, Czech Republic, Denmark, EU, Finland, France, Germany,
Hungary, Iceland, Latvia, Liechtenstein, Luxembourg, Moldova, Netherlands, Norway, Romania, Slovakia, Sweden,
UG
UG
UGA
800
■ug
31 35 N
43 00N
56 00N
2140N
43 30N
34 31 N
10 33N
30 00N
72 00N
24 30S
0 00N
54 30N
1521 N
56 00N
019N
35 00E
2100E
915E
82 50W
43 30E
69 12E
7 27E
82 00E
40 00W
2100E
115 00 E
2100E
42 34E
160 00 E
32 25E
691
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Kampuchea (former name for Cambodia)','a3a78768bc147c440db757d616812ab4ececffb7b1907d20e72fac9bdfa274ab','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ea1155d5b99ea1ddbd9c48e3623ac0b5ac3c23f59159e15e866f37115fec296',2007,'AE','United Arab Emirates','transnational-issues',1241,'V <■''
Juntas
Sughii . d funb al KuDri
feflMriM
Persian Gulf
UDEAC
Central African Customs and Economic Union
UHF
ultra-high-frequency
UK
AE
AE
ARE
784
.ae
24 28N
54 22E
Abu Musa (island)
Iran
25 52N
55 03E
Abuja (capital)
24 00N
54 00E
Al Iraq (local name for Iraq)
2518N
55 18E
Dubayy (see Dubai)
2518N
55 18E
Dublin (capital)
24 00N
54 00E
Iturup (island; see Etorofu)
Russia (de facto)
44 55N
147 40 E
Ityop''iya (local name for Ethiopia)
24 00N
54 00E
Trucial Oman (former name for the United Arab Emirates)
24 00N
54 00E
Trucial States (former name for the United Arab Emirates)
24 00N
54 00E
Truk Islands (former name for the Chuuk Islands)
Federated States of Micronesia
7 25N
151 47 E
Tsugaru Strait
Pacific Ocean
4135N
141 00 E
Tuamotu Islands (lies Tuamotu)','8b6070cba6abc5c438130f3c94c2460df892d807a5b9bbec9d1f117d8c25a55c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c849bbdffb35e7fbb7c95699192e5731fa17c7573f2d4b275e72603bf37666a',2007,'UY','Uruguay','transnational-issues',1251,'Background: Montevideo, founded by the Spanish
in 1 726 as a military stronghold, soon took advantage
of its natural harbor to become an important
commercial center. Annexed by Brazil as a separate
province in 1821 , Uruguay declared its independence
four years later and secured its freedom in 1 828 after
a three-year struggle. The administrations of
President BATLLE in the early 20th century
established widespread political, social, and economic
reforms. A violent Marxist urban guerrilla movement
named the Tupamaros, launched in the late 1 960s,
led Uruguay''s president to agree to military control of
his administration in 1973. By yearend, the rebels had
been crushed, but the military continued to expand its
hold throughout the government. Civilian rule was not
restored until 1985. In 2004, the left-of-center EP-FA
Coalition won national elections that effectively ended
170 years of political control previously held by the
Colorado and Blanco parties. Uruguay''s political and
labor conditions are among the freest on the
continent.
Disputes • international: uncontested dispute with
Brazil over certain islands in the Quarai/Cuareim and
Invernada streams and the resulting tripoint with
Convention on Long-Range Transboundary
Air Pollution
nofe— abbreviated as Air Pollution
opened for signature— -1 3 November 1 979
entered into force— 16 March 1983
objective— to protect the human environment
against air pollution and to gradually reduce and
prevent air pollution, including long-range
transboundary air pollution
parties— (48) Armenia, Austria, Belarus, Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia, Cyprus,
Czech Republic, Denmark, Estonia, EU, Finland, France, Georgia. Germany, Greece, Hungary, Iceland, Ireland,
Italy, Kazakhstan, Kyrgyzstan, Latvia, Liechtenstein, Lithuania, Luxembourg, Macedonia, Malta, Moldova, Monaco,
Netherlands, Norway, Poland, Portugal, Romania, Russia, Serbia and Montenegro, Slovakia, Slovenia, Spain,
Sweden, Switzerland, Turkey, Ukraine. UK, US
countries that have signed, but not yet ratified— (2) Holy See, San Marino
662
Appendix C: Selected International Environmental Agreements (continued)
Convention on the Conservation of Antarctic
Marine Living Resources
note— abbreviated as Antarctic-Marine Living
Resources
opened for signature— 5 May 1980
entered into force— 7 April 1 982
objective— to safeguard the environment and
protect the integrity of the ecosystem of the seas
surrounding Antarctica, and to conserve
Antarctic marine living resources
parties— (31 ) Argentina, Australia, Belgium, Brazil, Bulgaria, Canada, Chile, EU, Finland, France, Germany, Greece,
India, Italy, Japan, South Korea, Namibia, Netherlands, NZ, Norway, Peru, Poland, Russia, South Africa, Spain,
Sweden, Ukraine, UK, US, Uruguay, Vanuatu
Convention on the International Trade in
Endangered Species of Wild Flora and Fauna
(CITES)
note— abbreviated as Endangered Species
opened for signature— 3 March 1 973
entered into force— 1 July 1975
objective— to protect certain endangered
species from overexploitation by means of a
system of import/export permits
Convention on the Prevention of Marine
Pollution by Dumping Wastes and Other
Matter (London Convention)
note— abbreviated as Marine Dumping
opened for signature— 29 December 1 972
entered into force— 30 August 1 975
objective— to control pollution of the sea by
dumping and to encourage regional agreements
supplementary to the Convention
parties— (156) Afghanistan, Algeria, Antigua and Barbuda, Argentina, Australia, Austria, Azerbaijan, The Bahamas,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso,
Burma, Burundi, Cambodia, Cameroon, Canada, Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Republic of the Congo, Costa Rica, Cote d''lvoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Honduras, Hungary, Iceland, India, Indonesia, Iran, Israel, Italy,
Jamaica, Japan, Jordan, Kazakhstan, Kenya, South Korea, Latvia, Liberia, Liechtenstein, Lithuania, Luxembourg,
Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia,
Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Panama,
Papua New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts
and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and Principe, Saudi Arabia, Senegal,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Somalia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkey,
Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
countries that have signed, but not yet ratified— (3) Ireland, Kuwait, Lesotho
parties— {78) Afghanistan, Antigua and Barbuda, Argentina, Australia, Azerbaijan, Barbados, Belarus, Belgium,
Brazil, Canada, Cape Verde, Chile, China, Democratic Republic of the Congo, Costa Rica, Cote d''lvoire, Croatia,
Cuba, Cyprus, Denmark, Dominican Republic, Egypt, Finland, France, Gabon, Germany, Greece, Guatemala, Haiti,
Honduras, Hong Kong (associate member), Hungary, Iceland, Iran, Ireland, Italy, Jamaica, Japan, Jordan, Kenya,
Kiribati, South Korea, Libya, Luxembourg, Malta, Mexico, Monaco, Morocco, Nauru, Netherlands, NZ, Nigeria,
Norway, Oman, Pakistan, Panama, Papua New Guinea, Philippines, Poland, Portugal, Russia, Saint Lucia, Serbia
and Montenegro, Seychelles, Slovenia, Solomon Islands, South Africa, Spain, Suriname, Sweden, Switzerland,
Tonga, Tunisia, Ukraine, UAE, UK, US, Vanuatu
Convention on the Prohibition of Military or
Any Other Hostile Use of Environmental
Modification Techniques
note— abbreviated as Environmental
Modification
opened for signature— 10 December 1976
entered into force— 5 October 1 978
objective— to prohibit the military or other hostile
use of environmental modification techniques in
order to further world peace and trust among
nations
parties— (66) Afghanistan, Algeria, Antigua and Barbuda, Argentina, Australia, Austria, Bangladesh, Belarus,
Belgium, Benin, Brazil, Bulgaria, Canada, Cape Verde, Chile, Costa Rica, Cuba, Cyprus, Czech Republic, Denmark,
Dominica, Egypt, Finland, Germany, Ghana, Greece, Guatemala, Hungary, India, Ireland, Italy, Japan, North Korea,
South Korea, Kuwait, Laos, Malawi, Mauritius, Mongolia, Netherlands, NZ, Niger, Norway, Pakistan, Papua New
Guinea, Poland, Romania, Russia, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and Principe, Slovakia,
Solomon Islands. Spain, Sri Lanka, Sweden, Switzerland, Tajikistan, Tunisia, Ukraine, UK, US, Uruguay, Uzbekistan,
Vietnam, Yemen
countries that have signed, but not yet ratified— {17) Bolivia, Democratic Republic of the Congo, Ethiopia, Holy See,
Iceland, Iran, Iraq, Lebanon, Liberia, Luxembourg, Morocco, Nicaragua, Portugal, Sierra Leone, Syria, Turkey,
UY
UY
URY
858
.uy
34 53S
5611 W
Montreal (city)','3e52f28b3001a0a90f17a951c10ed202f477c33c178c1877538ced736fd20043','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fdb6ecf3c95a72a461221836f1767193e6aa09d6c617562fee93c9591f98f50',2007,'ZM','Zambia','transnational-issues',1290,'Disputes - international: in 2004 Zimbabwe
dropped objections to plans between Botswana and
Zambia to build a bridge over the Zambezi River,
thereby de facto recognizing a short, but not clearly
delimited, Botswana-Zambia boundary in the river
Refugees and internally displaced persons:
refugees (country of origin): 88 ,842 (Angola) 66,248
(Democratic Republic of the Congo) 5,791 (Rwanda)
(2005)
Illicit drugs: transshipment point for moderate
amounts of methaqualone, small amounts of heroin,
and cocaine bound for Southern Africa and possibly
Europe; a poorly developed financial infrastructure
coupled with a government commitment to combating
money laundering make it an unattractive venue for
money launderers
\\ MOZAMBIQUE
jKanba ^ — «-
/ Chinhoyi \\
NAMIBIA J * _ / /
^/ J£. HARARE.
*t-~ \\^-^^y Binga .Chitungwizaf
\\ Kadoma a I
\\ Hwange \\
\\ Mutare^
^Gweru /
-20 ^"V.
^Bulawayo .Masvingo T
BOTSWANA \\-^
)
V^^^Beitbridge /
0 50 10Okm _/"■
0 50 100 mi
^ "yjlOZAMBIQUE
SOUTH AFRICA \\
Disputes - international: Botswana has built
electric fences and South Africa has placed military
along the border to stem the flow of thousands of
Zimbabweans fleeing to find work and escape political
persecution; Namibia has supported and in 2004
Zimbabwe dropped objections to plans between
Botswana and Zambia to build a bridge over the
Zambezi River, thereby de facto recognizing a short,
but not clearly delimited Botswana-Zambia boundary
in the river
Refugees and internally displaced persons:
IDPs: 400,000-450,000 (MUGABE-led political
violence, human rights violations, land reform, and
economic collapse) (2005)
Illicit drugs: transit point for African cannabis and
South Asian heroin, mandrax, and
methamphetamines destined for the South African
and European markets
618
Taiwan
. .■■■<.-
The islands ol /^\\ Phi limn
MelsuandQuemoy ^J^ \\Chi-lung
we not shown. TAIPFI*
/ *Su-ao
A$
J .T''ai-chung /
/ "Chang-hua
/ iHua-lien
Pescadores
Ma-kung
j /
^tT''ai-nan /
.T''ai-tung
Kao-hsiung , /
^v / Philippine
• \\ j Sea
0 30 60 Km
) ] Q
0 30 60 ml
" Str
Disputes - international: involved in complex
dispute with China, Malaysia, Philippines, Vietnam,
and possibly Brunei over the Spratly Islands; the 2002
"Declaration on the Conduct of Parties in the South
China Sea" has eased tensions but falls short of a
legally binding "code of conduct" desired by several of
the disputants; Paracel Islands are occupied by
China, but claimed by Taiwan and Vietnam; in 2003,
China and Taiwan became more vocal in rejecting
both Japan''s claims to the uninhabited islands of the
Senkaku-shoto (Diaoyu Tai) and Japan''s unilaterally
declared exclusive economic zone in the East China
Sea where all parties engage in hydrocarbon
prospecting
Illicit drugs: regional transit point for heroin and
methamphetamine; major problem with domestic
consumption of methamphetamine and heroin;
renewal of domestic methamphetamine production is
a problem
/
621
European Union
I -- >^J^
■
^s
Member
| | Candidate
NORTH
ATLANTIC
OCEAN
200 400 km
Disputes - international: as a political union, the EU
has no border disputes with neighboring countries, but
Estonia and Latvia have no land boundary
agreements with Russia, Slovenia disputes its land
and maritime boundaries with Croatia, and Spain has
territorial and maritime disputes with Morocco; the EU
has set up a Schengen area - consisting of 13 EU
member states that have signed the convention
implementing the Schengen agreements (1985 and
1990) on the free movement of persons and the
harmonization of border controls in Europe; the
Schengen agreements ("acquis") became
incorporated into EU law with the implementation of
the 1997 Treaty of Amsterdam on 1 May 1999;
member states are: Austria, Belgium, Denmark,
Finland, France, Germany, Greece, Italy,
Luxembourg, Netherlands, Portugal, Spain, and
Sweden; in addition, non-EU states Iceland and
Norway (as part of the Nordic Union) have been
included in the Schengen area since 1996 (full
members in 2001), bringing the total current
membership to 15; the UK (since 2000) and Ireland
(since 2002) take part in some aspects of the
Schengen area, especially with respect to police and
criminal matters; the 10 new member states that
joined the EU in 2004 eventually are expected to
participate in Schengen, following a transition period
to upgrade their border controls and procedures
/
625
Appendix A:
Abbreviations
ABEDA
Arab Bank for Economic Development in Africa
ACCT
Agency for the French-Speaking Community
ACP Group
African, Caribbean, and Pacific Group of States
AfDB
African Development Bank
AFESD
Arab Fund for Economic and Social Development
Air Pollution
Convention on Long-Range Transboundary Air Pollution
Air Pollution-Nitrogen
Oxides
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution
Concerning the Control of Emissions of Nitrogen Oxides or Their Transboundary
Fluxes
Air Pollution-Persistent
Organic Pollutants
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on
Persistent Organic Pollutants
Air Pollution-Sulphur 85
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on
the Reduction of Sulphur Emissions or Their Transboundary Fluxes by at Least
30%
Air Pollution-Sulphur 94
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution on
Further Reduction of Sulphur Emissions
Air Pollution-Volatile
Organic Compounds
Protocol to the 1979 Convention on Long-Range Transboundary Air Pollution
Concerning the Control of Emissions of Volatile Organic Compounds or Their
Transboundary Fluxes
AMF
Arab Monetary Fund
AMU
Arab Maghreb Union
Antarctic-Environmental
Protocol
Protocol on Environmental Protection to the Antarctic Treaty
Antarctic Marine Living
Resources
Convention on the Conservation of Antarctic Marine Living Resources
ANZUS
Australia-New Zealand-United States Security Treaty
Antarctic Seals
Convention for the Conservation of Antarctic Seals
APEC
Asia-Pacific Economic Cooperation
Arabsat
Arab Satellite Communications Organization
ARF
ASEAN Regional Forum
AsDB
Asian Development Bank
ASEAN
Association of Southeast Asian Nations
AU
African Union
Autodin
Automatic Digital Network
bbl/day
barrels per day
BCIE
Central American Bank for Economic Integration
BDEAC
Central African States Development Bank
Benelux
Benelux Economic Union
BGN
United States Board on Geographic Names'' ''
Biodiversity
Convention on Biological Diversity
BIS
Bank for International Settlements
BSEC
Black Sea Economic Cooperation Zone
626
Appendix A: Abbreviations (continued)
s
Commonwealth
c.i.f.
cost, insurance, and freight
CACM
Central American Common Market
CAEU
Council of Arab Economic Unity
CAN
Andean Community of Nations
Caricom
Caribbean Community and Common Market
CB
citizen''s band mobile radio communications
CBSS
Council of the Baltic Sea States
CCC
Customs Cooperation Council
CDB
Caribbean Development Bank
CE
Council of Europe
CEI
Central European Initiative
CEMAC
Monetary and Economic Community of Central Africa
CEPGL
Economic Community of the Great Lakes Countries
CEPT
Conference Europeanne des Poste et Telecommunications
CERN
European Organization for Nuclear Research
CIS
Commonwealth of Independent States
CITES
see Endangered Species
Climate Change
United Nations Framework Convention on Climate Change
Climate Change-Kyoto
Protocol
Kyoto Protocol to the United Nations Framework Convention on Climate Change
COCOM
Coordinating Committee on Export Controls
COMESA
Common Market for Eastern and Southern Africa
Comsat
Communications Satellite Corporation
CP
Colombo Plan
CY
calendar year
DC
developed country
DDT
dichloro-diphenyl-trichloro-ethane
Desertification
DIA
United Nations Convention to Combat Desertification in Those Countries
Experiencing Serious Drought and/or Desertification, Particularly in Africa
United States Defense Intelligence Agency
DSN
Defense Switched Network
DWT
deadweight ton
EADB
East African Development Bank
EAPC
Euro-Atlantic Partnership Council
EAS
East Asia Summit
EBRD
European Bank for Reconstruction and Development
EC
European Community
ECA
Economic Commission for Africa
ECE
Economic Commission for Europe
ECLAC
Economic Commission for Latin America and the Caribbean
ECO
Economic Cooperation Organization
ECOSOC
Economic and Social Council
ECOWAS
Economic Community of West African States
627
Appendix A: Abbreviations (continued)
ECSC
European Coal and Steel Community
EEC
European Economic Community
EEZ
exclusive economic zone
EFTA
European Free Trade Association
EIB
European Investment Bank
EMU
European Monetary Union
Endangered Species
Entente
Convention on the International Trade in Endangered Species of Wild Flora and
Fauna (CITES)
Council of the Entente
Environmental
Modification
ESA
ESCAP
ESCWA
est.
EU
Euratom
Eutelsat
Ex-lm
Convention on the Prohibition of Military or Any Other Hostile Use of
Environmental Modification Techniques
European Space Agency
Economic and Social Commission for Asia and the Pacific
Economic and Social Commission for Western Asia
estimate
European Union
European Atomic Energy Community
European Telecommunications Satellite Organization
Export-Import Bank of the United States
f.o.b.
FAO
FAX
FLS
FOC
FSU
FY
FZ
free on board
Food and Agriculture Organization
facsimile
Front Line States
flags of convenience
former Soviet Union
fiscal year
Franc Zone
G-2
G-3
G-5
G-6
G-7
G-8
G-9
G-10
G-11
G-15
G-24
G-77
GATT
GCC
GDP
GNP
Group of 2
Group of 3
Group of 5
Group of 6
Group of 7
Group of 8
Group of 9
Group of 10
Group of 1 1
Group of 15
Group of 24
Group of 77
General Agreement on Tariffs and Trade; now WTO
Gulf Cooperation Council
gross domestic product
gross national product
628
Appendix A: Abbreviations (continued)
GRT
GSM
ZA
ZM
ZMB
894
.zm
15 25S
2817E
Luxembourg (capital)
Northwest Passages
Arctic Ocean
Northwest Territories (region)
Rhodesia. Southern (former name for Zimbabwe)
Riga (capital)','c3458503bb7f9f570da5f94cf860208efc7e3fa712f5986ca832c24c2f67e224','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a43145b5b8c4fcebe3c6c306005d718f5b5bdcf719affed35659f82aaf6b51f1',2007,'GB','United Kingdom','transnational-issues',1291,'UNMIS
United Nations Mission in the Sudan
UN
United Nations
UNAMSIL
United Nations Mission in Sierra Leone
UNCLOS
United Nations Convention on the Law of the Sea, also know as LOS
UNCTAD
United Nations Conference on Trade and Development
UNDCP
United Nations Drug Control Program
UNDOF
United Nations Disengagement Observer Force
UNDP
United Nations Development Program
UNEP
United Nations Environment Program
UNESCO
United Nations Educational, Scientific, and Cultural Organization
UNFICYP
United Nations Peace-keeping Force in Cyprus
UNFPA
United Nations Population Fund
UNHCR
United Nations High Commissioner for Refugees
UNICEF
United Nations Children''s Fund
UNICRI
United Nations Interregional Crime and Justice Research Institute
UNIDIR
United Nations Institute for Disarmament Research
UNIDO
United Nations Industrial Development Organization
UNIFIL
United Nations Interim Force in Lebanon
UNITAR
United Nations Institute for Training and Research
UNMEE
United Nations Mission in Ethiopia and Eritrea
UNMIK
United Nations Interim Administration Mission in Kosovo
UNMIL
United Nations Mission in Liberia
UNMOGIP
United Nations Military Observer Group in India and Pakistan
UNMOVIC
United Nations Monitoring, Verification, and Inspection Commission
UNOCI
United Nations Operation in Cote d''lvoire
UNOMIG
United Nations Observer Mission in Georgia
UNOPS
United Nations Office of Project Services
UNRISD
United Nations Research Institute for Social Development
UNRWA
United Nations Relief and Works Agency for Palestine Refugees in the Near East
UNSC
United Nations Security Council
UNSSC
Untied Nations System Staff College
UNTSO
United Nations Truce Supervision Organization
UNU
United Nations University
UPU
Universal Postal Union
US
UK
GB
GBR
826
.uk
ISO includes Guernsey, Isle of Man,
49 52N
6 27W
Bismarck Archipelago (island group)
British Bechuanaland (region; former name for
northwest South Africa)
52 30N
1 30 W
English Channel
Atlantic Ocean
50 20N
1 00 W
Eniwetok Atoll (see Enewetak Atoll)
54 00N
2 00W
Great Channel
Indian Ocean
6 25N
94 20E
Great Inagua (island)
The Bahamas
2100N
73 20W
Great Rift Valley
Ethiopia, Kenya
0 30N
36 00E
Greater Sunda Islands
Brunei, Indonesia, Malaysia
2 00S
110 00 E
Green Islands
56 30N
6 20W
Inner Mongolia (region; also Nei Mongol)
5130N
010W
Longyearbyen (town)
Svalbard
7813N
15 33E
Lord Howe Island
Oslo (capital)
Outer Mongolia (region)
57 35N
13 48W
Rodrigues (island)
57 00N
4 00W
Scott Island
60 30N
130W
Shikoku (island)
Wallis Islands','90369de7722c40db4e01827f94627532e57afb3786e4dd257709ee17f88f4eb3','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84747c4d9f4899045bb205190fec0beb57bc36dc41ac862447034585fc745d57',2007,'CH','Switzerland','transnational-issues',1292,'countries that have signed, but not yet ratified— (1 4) Armenia, Belgium, Croatia, Greece, Ireland, Italy, Lithuania,
Poland, Portugal, Slovenia, Spain, Ukraine, UK, US
Protocol to the 1979 Convention on
Long-Range Transboundary Air Pollution on
the Reduction of Sulphur Emissions or Their
Transboundary Fluxes by at Least 30%
note— abbreviated as Air Pollution-Sulphur 85
opened for signature— & July 1 985
entered into force— 2 September 1 987
objective— to provide for a 30% reduction in
sulfur emissions or transboundary fluxes by
1993
parties— (22) Austria, Belarus, Belgium, Bulgaria, Canada, Czech Republic, Denmark, Estonia, Finland, France,
Germany, Hungary, Italy, Liechtenstein, Luxembourg, Netherlands, Norway, Russia, Slovakia, Sweden, Switzerland,
Syria
Taiwan
46 57N
7 26E
Bessarabia (region)
Moldova, Romania, Ukraine
47 00N
28 30E
Bharat (local name for India)
47 00N
8 00E
Congo (Brazzaville) (former name for Republic of
the Congo)
Republic of the Congo
100S
15 00E
Congo (Leopoldville) (former name for the Democratic
Republic of the Congo)
Democratic Republic of the Congo
0 00N
25 00E
Constantinople (city; former name for Istanbul)
Turkey
4101 N
28 58E
Cook Strait
Pacific Ocean
41 15 S
174 30 E
Copenhagen (capital)
4612N
610E
Genoa (city)
47 00N
8 00E
Scopus, Mount
Israel, West Bank
3148N
3514E
Scotia Sea
Atlantic Ocean, Southern Ocean
56 00S
40 00W
Scotland (region)
47 00N
Sulawesi (island: Celebes)
Swains Island
47 23N
8 32E
709
^
BOSTON PUBLIC LIBRARY
3 9999 05966 099 1
Other Titles
of Interest','32e6d5f2f52d9208920ed1122b0d5f3a6c9eeaec0b3d4e7c26ea751b58457185','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c2c2524267cbf279d8c48a84c2d330d291ee554db1c7d9661978e4a2159e9b6',2007,'AW','Aruba','transnational-issues',1293,'Ashmore and Cartier Islands
Oresund (The Sound) (strait)
Atlantic Ocean
Orkney Islands','404a3e89e6d8a4c572f32cea5e497f5a8d218017189ac2e2c8e839750b60eab4','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('846052254686c0923d1918e2ad211d49229d8299a28489021cfe7a10ccf23f70',2007,'BJ','Benin','transnational-issues',1294,'Countries, Dependencies, Areas of Special Sovereignty, and Their Principal Administrative Divisions (FIPS 10) is
maintained by the Office of Targeting and Transnational Issues, National Geospatial-lntelligence Agency, and published by
the National Institute of Standards and Technology (Department of Commerce). FIPS 10 codes are intended for general use
throughout the US Government, especially in activities associated with the mission of the Department of State and national
defense programs.
AA
AT
AS
AU
AJ
BF
BA
FQ
BG
BB
BS
BO
W
~BH~
~bn~
AW
ABW
533
.aw
AU
AUS
036
.au
AT
AUT
040
.at
AZ
AZE
031
.az
BS
BHS
044
BH
BHR
048
.bs
!b¥
BD
BGD
050
.bd
BB
BRB
052
.bb
BY
~BE~
~BZ~
~BJ~
BLR
BEL
13LZ~
BEN
112
~056~
1)84"
^04~
.by_
.be
ISO 3166:
Codes for the Representation of Names of Countries (ISO 3166) is prepared by the International Organization for
Standardization. ISO 3166 includes two- and three-character alphabetic codes and three-digit numeric codes that may be
needed for activities involving exchange of data with international organizations that have adopted that standard.
Internet:
The Internet country
the ISO 31 66 Alpha-
domains (ccTLDs).
code is the two-letter (
2 list and used by the
digraph maintained by the International Organization for Standardization (ISO) in
nternet Assigned Numbers Authority (IANA) to establish country-coded top-level
Entity
FIPS 10
ISO 3166
Internet
Comment
6 21 N
2 26E
Cotopaxi (volcano)
Daito Islands
6 29N
2 37E
Portuguese East Africa (former i
lame for Mozambique)','90b48bb847903839097f1b691a9fd33d6f2b75e18e5540a77b14157cdcf3701f','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8c24f8605b75516957c11ab4ea28684c401c764328f63686b135fb57e614385',2007,'BA','Bosnia and Herzegovina','transnational-issues',1295,'BK
BA
BIH
070
.ba
44 00N
18 00E
Bosnia (political region)
44 00N
18 00E
Bosporus (strait)
Atlantic Ocean
41 00 N
29 00E
Bothnia, Gulf of
Atlantic Ocean
63 00N
20 00E
Bougainville (island)
44 00N
18 00E
Hiiumaa (island)
43 52N
18 25E
Sarawak (state)','6c6d119e88fd9a8ca9d74b5b9009fb489697b3d29c118cc27148dcbc6e5c3ec5','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9519b06e60b125282329c8f6c3e9d47ad8ac68c209f177b738464f3ba503615',2007,'BR','Brazil','transnational-issues',1296,'BR
BR
BRA
076
.br
Bratislava (capital)
Fernando Po (island; see Bioko)
20 30S
28 51 W
Mas a Tierra (Robinson Crusoe Island)
3 51S
33 49W
Rockall (island)
0 23N
29 23W
Saint Peter Port (capital)
0 23N
29 23W
Sao Tiago (island)
Cape Verde
15 05N
23 40W
Sao Tome (island)
20 31 S
29 20E
Trinidad (island)','a6e9c6dbc619b8de4b3e4c6efb5e0ba5655932a6a8a4f9b671cc85fe4a4b606b','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ba6157d4b2f0dcb0eeced42a18c6e11439d9272807d0c77fad3302968c77d1c5',2007,'IO','British Indian Ocean Territory','transnational-issues',1297,'IO
IO
IOT
086
• .io
British Virgin Islands
VI
VG
VGB
092
■vg
Brunei
BX
BN
BRN
096
.bn
6 00S
71 30 E
Challenger Deep (Mariana Trench)
Pacific Ocean
11 22 N
142 36 E
Channel Islands
Guernsey. Jersey
49 20N
2 20W
Charlotte Amalie (capital)
Virgin Islands
1821 N
64 56W
Chatham islands
7 20S
72 25E
Diego Ramirez (islands)
Okhotsk, Sea of
Pacific Ocean
Okinawa (island group)','a877d45d2541b0ed30fe42dfab9166d494d7f7160f32edbd91d219c85d45c69a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f6e8ea53ce90acba229d3c06e0ef6cb21222dc4d6d4d9061e9b6013a9cd3e3b',2007,'KH','Cambodia','transnational-issues',1298,'CB
KH
KHM
116
.kh
13 26N
103 50 E
Anglo-Egyptian Sudan (former name for Sudan)
13 00N
105 00 E
Kane Basin (portion of channel)
Arctic Ocean
79 30N
68 00W
Kanton Island
13 00N
105 00 E
Khuriya Muriya Islands (Kuria Muria Islands)
1133N
104 55 E
Phoenix Islands','d9230ab999d2e2142311b1aa42cd0a7066a201dc7e97ea8d3f939d9ad90b2ee0','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a71038d7dc11687330aaf80fa3a33ce81aaf46d64a92b07b4d9d73fed1dc88c7',2007,'CF','Central African Republic','transnational-issues',1299,'CT
CF
CAF
140
.cf
4 22N
18 35E
Banjul (capital)
The Gambia
13 28N
16 39W
Banks Island
7 00N
2100E
Ceram (Seram) Sea
Pacific Ocean
2 30S
129 30 E
Ceska Republika (local name for Czech Republic)
Czech Republic
49 45N
15 30E
Ceskoslovensko (former local name for
Czechoslovakia)
Czech Republic. Slovakia
49 00N
17 30E
Ceuta (city)
Republique Francaise (local name for France)
6 38N','4b660576dba9454a59f5f5d1ba13e62d567064e4d92bcc068adfb56b81d28818','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce386a7a55ac6bf3d315ab0a7efff05d60b1479886cf9b8e9aecc66c97ecc8e4',2007,'CL','Chile','transnational-issues',1300,'CI
CL
CHL
152
.cl
23 00S
7010W
Atacama (region)
24 30S
6915W
Athens (capital)
42 50S
74 00W
China, People''s Republic of
56 30S
68 43W
Dili (capital)
East Timor
8 35S
125 36 E
Dilmun (former name for Bahrain)
27 07S
109 22 W
Eastern Channel (East Korea Strait or Tsushima Strait)
Pacific Ocean
34 00N
129 00 E
Eastern Samoa (former name for American Samoa)
55 59S
6716W
Home, lies de (island group)
33 00S
80 00W
Jubal, Strait of
Indian Ocean
27 40N
33 55E
Judaea (region)
Israel, West Bank
Jugoslavia, Jugoslavia (local names for Yugoslavia,
a former Balkan federation)
Bosnia and Herzegovina, Croatia, Macedonia,
Serbia and Montenegro, Slovenia
Jutland (region)
33 38S
78 52W
Mascarene Islands
Mauritius, Reunion
2100S
57 00E
Maseru (capital)
Afghanistan, Pakistan
Clipperton Island
Ratak Chain (island group)
33 38S
78 52W
Rocas, Atol das (island)
26 28S
105 00 W
Salisbury (city; former name for Harare)
26 21 S
79 52W
San Andres y Providencia, Archipielago (island group)
2617S
80 05W
San Jose (capital)
33 27S
70 40W
Santo Antao (island)
Cape Verde
17 05N
2510W
Santo Domingo (capital)','c43bcfdb77289cce793241efbfda32736a724a123dd6b40c058a3aee39e431e8','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dae1743a55e661e7095ea937ea23988b25b6704b717fce69a46dc8103e3eab03',2007,'CC','Cocos (Keeling) Islands','transnational-issues',1301,'CK
CC
CCK
166
.CC
12 30S
96 50E
Colombo (capital)
12 30S
96 50E
Kerguelen, lies (island group)
French Southern and Antarctic Lands
49 30S
69 30E
Kermadec Islands
West Korea Strait (Western Channel)
Pacific Ocean
West Pakistan (former name for present-day Pakistan)','9ec34c0ef79250261b3b0b3171a0987dbf446d11be6acc42fb8ea72d3612c0d9','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35bea8f72d218b8ffc83547c3afe7099d1bb8897c46438807dd277d1bab8a4a1',2007,'KM','Comoros','transnational-issues',1302,'CN
KM
COM
174
.km
Congo, Democratic Republic of the
CG
CD
COD
180
.cd
formerly Zaire
Congo, Republic of the
CF
CG
COG
178
eg
1215S
44 25E
Ankara (capital)
Turkey
39 56N
32 52E
Annobon (island)
1210S
4415E
Con Son (islands)
Vietnam
8 43N
106 36 E
Conakry (capital)
11 41 S
4316E
Mortlock Islands (Nomoi Islands)
Federated States of Micronesia
5 30N
153 40 E
Moscow (capital)
Russia
55 45N
37 35E
Mount Pinatubo (volcano)','cc22dcc8f5ea8a39c278a6e34f5a1ca0a8cf9a3723e2856aaf173e0ed0d3c139','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05a4bb532641cb51dbc8edda07e59c4cad34be8f5871c54d7a8c38a77f6415a6',2007,'DM','Dominica','transnational-issues',1303,'DO
DM
DMA
212
.dm
670
Appendix D: Cross-Reference List of Country Data Codes (continued)
Entity
15 18 N
6124W
Ross Dependency (claimed by New Zealand)','953fa75d4cdb9d1d8f49aadf303170080b551720164735b537cf82993b494e71','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d4b7b866915f6f94ef8a91e49e09f338df3973e51fed01738a01fce3062606f',2007,'GA','Gabon','transnational-issues',1304,'GB
GA
GAB
266
•ga
Gambia, The
GA
GM
GMB
270
.gm
Gaza Strip
GZ
PS
PSE
275
.ps
ISO identifies as Occupied Palestinian
Territory
16 30S
45 45N
54 00N
60 00N
10 00N
7 00N
6 27N
42 30N
45 00N
43 30N
43 30N
48 00N
10 00N
22 15N
18 00N
76 00N
28 06N
36 00N
57 00N
18 20S
3510N
39 54N
59 55N
9 00S
3915N
10 50N
3715N
40 30N
33 50N
0 23N
68 09W
142 00 E
62 00W
55 00W
73 00E
76 00E
3 24E
81 00 W
83 00W
87 30W
78 00W
88 00W
73 00E
113 55 E
105 00 E
126 00 E
15 24W
35 50E
25 00E
178 30 E
33 22E
25 21 E
3015E
120 00 E
2615E
124 50 E
131 50 E
121 20 E
36 50E
9 27E
693
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
M
Lietuva (local name for Lithuania)
Republique Rwandaise (local name for Rwanda)','1ee747ed3ec029c2a133928b5d0d1bf82c466f25c86857c5b21de5b1e71f8e4f','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d92598d319e2f0ec0dd8a392a624956ce542e4bd1ce08d6200d6340e40ad78d',2007,'HM','Heard Island and McDonald Islands','transnational-issues',1305,'HM
HM
HMD
334
hm
Holy See (Vatican City)
VT
VA
VAT
336
va
53 06S
73 30E
Hejaz (region)
53 06S
73 30E
Mecca (city)
Mediterranean Sea
Melilla (exclave)
Memel (region)
Mesopotamia (region)
Messina, Strait of
Mexico City (capital)
Mexico, Gulf of
53 00S
72 30E
Shag Rocks','1d0baa5a22b5de4bdbed771da9e720827e9670c99b772b00d1ae5170e95266fd','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73d2b686e179dae926b6fa79cf64afbb9528b8efd31f02800d24cf4a4417fdb7',2007,'IS','Iceland','transnational-issues',1306,'IC
IS
ISL
352
is
65 00N
18 00W
Islas Malvinas (island group)
Falkland Islands (Islas Malvinas)
5145S
59 00W
Istanbul (city)
Turkey
41 01 N
28 58E
Istrian Peninsula
Croatia, Slovenia
45 00N
14 00E
Italia (local name for Italy)
Rhodes (island)
Suva (capital)','1c4166f5e7ec4bf09a3a91deb83547769e8b448816e7952d5cd63c310e0ac52a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c6ee27cca09b223eb36d0fad57e67d4f3a02be4124340ed48d707f90ab0bce0',2007,'NG','Nigeria','transnational-issues',1307,'FIPS10-4
LT
NZ
W
"ng"
"nT
LS
ISO 3166
LSO
426
Internet
.Is
NZ
NE
"NGf
NZL
NIC
"NER~
NGA
554
^58"
"562"
l566~
.nz
.ni
.ne
•ng
Comment
912N
7 11 E
Abyssinia (former name for Ethiopia)
5 30N
7 30E
Big Diomede Island
Russia
65 46N
169 06 W
Bijagos, Arquipelago dos (island group)
Kailas Range
China, India
Kalaallit Nunaat (local name for Greenland)
Atlantic Ocean
Atlantic Ocean
Atlantic Ocean
Atlantic Ocean
Atlantic Ocean','8666400689bfaf2485155b408de3004990b4796beb2df46d5425f253cd6bf2e8','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38810541590b8391446a9c809f1849bcbde22febd3ce83642ad549815952db93',2007,'FM','Micronesia, Federated States of','transnational-issues',1308,'FM
FM
FSM
583
.fm
Midway Islands
MQ
—
—
—
—
ISO includes with the US Minor
Outlying Islands
Moldova
MD
MD
MDA
498
.md','07fd92f30a81372e4dc5efd5d2a9baad2ebe5dadc577d7e3132e279dd3ad1fca','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('713595fe641540ed771c76791e8cd1f5a754d254019ab9635fd61c5f0900d1c0',2007,'PL','Poland','transnational-issues',1309,'PL
PL
POL
616
.pi
54 23N
18 40E
Dao Bach Long Vi (island)
Vietnam
20 08N
107 44 E
Dar es Salaam (capital)
Tanzania
6 48S
3917E
Dardanelles (strait)
Atlantic Ocean
4015N
26 25E
Davis Strait
Atlantic Ocean
67 00N
57 00W
Dead Sea
Israel, Jordan, West Bank
32 30N
35 30E
Deception Island
54 23N
18 40E
Geneva (city)
Latitude
(deg min)
00 N
11 15N
36 47N
17 32S
5 50N
20 20N
48 52N
27 07S
32 00N
10 17 N
48 00S
39 56N~
35 40N
7 01 N
17 44S
52 25N
Longitude
(deg min)
79 30W
122 30 E
12 00E
149 34 W
55 10W
136 00 E
2 20E
109 22 W
69 00E
10913W
61 00 W
116 24E
12 40E
134 15 E
Peloponnese (peninsula)
52 00N
20 00E
Polynesie Francaise (local nam*
> for French Polynesia)
Washington, DC (capital)','108da42afa23385d2eba70e697cd6fc179315fe73dd581e2dbe99c44352b2604','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc2d0494b8c41f8ed8fe41c36c84295583c56d4e7125ef73cd289177b899a991',2007,'VC','Saint Vincent and the Grenadines','transnational-issues',1310,'VC
VC
VCT
670
.VC
13 15 N
61 12 W
Grenadines, Southern (island group)
13 09N
61 14W
Kinshasa (capital)
Democratic Republic of the Congo
418S
15 18 E
Kipros (Greek local name for Cyprus)
Northern Ireland
Northern Rhodesia (former name for Zambia)','5bb90e0fbfe18a4b933b780c3a07088ad321f76b75703eb0d5578b955d169ca1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fa5802e0833ca68b3eadcdebd962da4408b0bf7ea0c48021395fb19d4e95e0a',2007,'ST','Sao Tome and Principe','transnational-issues',1311,'TP
ST
STP
678
.St
Prussia (region)
Germany, Poland, Russia
Pukapuka Atoll
012N
6 39E
Sapudi Strait
Pacific Ocean
7 05S
114 10E
Sarajevo (capital)','cd0ea11293f46adc908ccd4469ec9e3caa56181dfab198e23a5908ecef236d21','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e4f34427c34bc56e08c599385462832e72b0db03172bfb2da47f1e4255501b7',2007,'SR','Suriname','transnational-issues',1312,'Svalbard
Swaziland
4 00N
56 00W
Dutch West Indies (former name for the
Netherlands Antilles)
Netherlands Antilles
12 10 N
68 30W
Dzungarian Gate (valley)
China, Kazakhstan
45 25N
82 25E
686
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
East China Sea
Pacific Ocean
30 00N
126 00 E
East Frisian Islands
4 00N
56 00W
Nevis (island)
4 00N
56 00W
Suriyah (local name for Syria)
Syria
Surtsey (volcanic island)','ac70b19a4b50537ee90bf1d4bcaa03873a4ad514e8abd4609c182e02eda38c59','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7aa0c6e069ea675f330d7f7199da5bbb937843d52f8f2439bba12f8c7bf7b60c',2007,'TT','Trinidad and Tobago','transnational-issues',1313,'Tromelin Island
10 39N
6131 W
Porto-Novo (capital)
11 15 N
60 40W
Tokyo (capital)
10 22N
61 15W
Tripoli (capital)','33890b1b95c21127892b93fc1fec12f0109ccdc9213806faa712ff8bc4ee8f96','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03bdb42c1ffc15cc09b5256a6b1703d8916817d309483b09a70205ee5f6a7cd5',2007,'TM','Turkmenistan','transnational-issues',1314,'TX
TM
TKM
795
.tm
37 57N
58 23E
Ashkhabad (see Ashgabat)
37 57N
58 23E
Asmara (capital)
40 00N
40 00N
Turks Island Passage
Atlantic Ocean
2140N
Tuscany (region)','6b212903bd9ca05b25be2cca89125c169541be62fcf5c3bec2dbeeabf38f4979','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('452eae25287903bc1f62aa645414fc288546384f1a20c84f519ebef79a602039',2007,'TC','Turks and Caicos Islands','transnational-issues',1315,'TK
TC
TCA
796
.tc
Cairo (capital)
2128N
7108W
Great Australian Bight
Indian Ocean
35 00S
130 00 E
Great Belt (strait; also Store Baelt)
Atlantic Ocean
55 30N
11 00 E
Great Bitter Lake','f99af7faf56951da8b351ee8b6d8afde4501ab77da920472229d358a815d4f5d','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e40477c56e06bd4e150810e5cafd60657a3a68a0d39c21207500b5f87063b717',2007,'YE','Yemen','transnational-issues',1316,'YM
YE
YEM
887
■ye
Zaire
—
—
—
—
—
see Democratic Republic of the Congo
12 46N
45 01E
Aden, Gulf of
Indian Ocean
12 30N
48 00E
Admiralty Island
United States (Alaska)
57 44N
134 20 W
Admiralty Islands
15 00N
48 00E
Aland Islands
15 00N
Hagatna (capital; formerly Agana)
Russia
12 39N
43 25E
Perouse Strait, La
Pacific Ocean
44 45N
142 00 E
Persia (former name for Iran)
Iran
32 00N
53 00E
Persian Gulf
Indian Ocean
27 00N
5100E
Pescadores (islands)
Taiwan
23 30N
11930E
Peter I Island
1521 N
44 12E
Sandzak (region)
Serbia and Montenegro
43 05N
19 45E
Santa Cruz (city)
Bolivia
17 48S
63 10W
Santa Cruz Islands
12 30N
14 00E
11 20 E
18 00E
88 30E
17 00E
34 00E
103 51 E
104 00 E
86 00E
62 58W
63 04W
12 00E
9 00E
2126E
18 00E
15 00E
19 30E
27 10E
150 00 W
54 00E
703
Appendix F: Cross-Reference List of Geographic Names (continued)
Name
Entry in The World Factbook
Latitude
(deg min)
Longitude
(deg min)
Sofia (capital)
MOON
48 00E
Southern Grenadines (island group)
Yemen, People''s Democratic Republic of (also Yemen
(Aden); former name for southern portion of Yemen)
Yerevan (capital)','1a2315fc050528ff861ec0d78c732a76298b06674afe6202ddf0c9b21d00ed43','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f012441136ff5bc9022a1817f9f8454f8a14ce82c76e2a22d1c7be6c3df9b7d7',2007,'BE','Belgium','transnational-issues',1317,'Aomen (local Chinese short-form name for Macau)
Macau
Aozou Strip (region)
Serbia and Montenegro
Bubiyan (island)
50 26N
6 02E
Malpelo, Isla de (island)','2cd5b6addda8a254af588de1fe238bc9a1b698f71ae213c0ee256117e15778b1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d5c08caff5866cfdb1c3635dd284e48c86e1ebf38fda73fa1580f43fc94fdce7',2007,'GS','South Georgia and the South Sandwich Islands','transnational-issues',1318,'53 39S
4148W
Black Sea
Atlantic Ocean
43 00N
35 00E
Bloemfontein (judicial capital)
5415S
36 45W
Guadalcanal (island)
53 33S
42 02W
Shetland Islands
54 15S
36 45W
South Island
57 45S
26 30W
South Shetland Islands','66ba2a7ff1be5430fc3359300b1b455370c46fabe026cc1f96180df4e8265e91','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b93fc00de42e7b1c95521f49835e7ddba04296d85bb099e4a096432f109df6ff',2007,'TG','Togo','transnational-issues',1319,'8 00N
1 10E
French West Indies (former name for French
possessions in the West Indies)
Guadeloupe. Martinique
16 30N
62 00W
Friendly Islands
6 08N
1 13E
London (capital)
Revillagigedo Island
United States (Alaska)
Revillagigedo Islands','6c5580abb72217f959deab82ec5bec1e865f855168bead85d5c2d0142c7cb4e0','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55b3ad9888d38a67be4971eda44f0782b888e223e20f5bedfb17903bb0c7947d',2007,'TO','Tonga','transnational-issues',1320,'20 00S
175 00 W
Frisian Islands
Denmark, Germany, Netherlands
53 35N
6 40E
Frunze (city; former name for Bishkek)
19 42S
Habomai Islands
Russia (de facto)
43 30N
Hadhramaut (region)
Nunavut (region)','ac01478888882ae8eb2e074517fa671c4f6e3db6e322fb3af5a480a0d3e7b7fa','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e26ada7805ace9fd1a606a830bb871ebf78101149d801a8da0c2dedaafb8c451',2007,'KR','Korea, Republic of','transnational-issues',1321,'Koror (capital)
Kosovo (region)
Kosrae (island)
Kowloon (city)
Kra, Isthmus of
Krakatoa (volcano)
Kuala Lumpur (capital)
Kunashiri (island; also Kunashir)
Kunlun Mountains
Kuril Islands
Kuwait (capital)
Kuznetsk Basin
Kwajalein Atoll
Kyushu (island)
Kyyiv (see Kiev)
Entry in The World Factbook
North Korea
South Korea','c4887ede1f6ebeabac0c1522a6b981b2c6010c06530f40c0ad13927f9762b669','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

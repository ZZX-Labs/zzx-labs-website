SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f5993c027a6ba00bc6458e61c240b373f7b0d80417bb45097aeb8870970018b',2007,'EH','Western Sahara','people-and-society',24,'Population: 6.525,170,264 (July 2006 est.)
Age structure:
0-14 years: 27.4% (male 919,219,446/female
870,242.271)
15-64 years: 65.2% (male 2,152.066,888/lemale
2,100,334,722)
65 years and over: 7 4% (male 213,160,216/female
270,146.721) (2006 est.)
World (continued)
Median age:
total: 27.6 years
male: 27 years
female: 28.2 years (2006 est.)
Population growth rate: 1.14% (2006 est.)
Birth rate: 20.05 births/1,000 population (2006 est.)
Death rate: 8.67 deaths/1 ,000 population (2006 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 1 .01 male(s)/female (2006 est.)
Infant mortality rate:
total: 48.87 deaths/1 ,000 live births
male: 50.98 deaths/1 ,000 live births
female: 46.65 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 64.77 years
male: 63.1 6 years
female: 66.47 years (2006 est.)
Total fertility rate: 2.59 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Religions: Christians 33.03% (of which Roman
Catholics 17.33%, Protestants 5.8%, Orthodox
3.42%, Anglicans 1.23%), Muslims 20.12%, Hindus
1 3.34%, Buddhists 5.89%, Sikhs 0.39%, Jews 0.23%,
other religions 12.61%, non-religious 12.03%, atheists
2.36% (2004 est.)
Languages: Mandarin Chinese 13.69%, Spanish
5.05%, English 4.84%, Hindi 2.82%, Portuguese
2.77%, Bengali 2.68%, Russian 2.27%, Japanese
1.99%, Standard German 1.49%, Wu Chinese 1.21%
(2004 est.)
note: percents are for "first language" speakers only
Literacy:
definition: age 15 and over can read and write
total population: 82%
male: 87%
female: 77%
note: over two-thirds of the world''s 785 million illiterate
adults are found in only eight countries (India, China,
Bangladesh, Pakistan, Nigeria, Ethiopia, Indonesia,
and Egypt); of all the illiterate adults in the world,
two-thirds are women; extremely low literacy rates are
concentrated in three regions, South and West Asia,
Sub-Saharan Africa, and the Arab states, where
around one-third of the men and half of all women are
illiterate (2005 est.)','a19c24a60698e6efcb940bba1ff78828a221544e363ad4a0219f39b5eb8c0624','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8e47fd5f3b1d9663832ab29b0885d6817ae79819cab457a4895df613b5996c6',2007,'AF','Afghanistan','people-and-society',27,'Population: 31,056,997 (July 2006 est.)
Age structure:
0-14 years: 44.6% (male 7,095,1 17/female
6,763,759)
15-64 years: 53% (male 8,436,71 6/female 8,008,463)
65 years and over: 2.4% (male 366,642/female
386,300) (2006 est.)
Median age:
total: 17.6 years
male: 17.6 years
female: 17.6 years (2006 est.)
Population growth rate: 2.67% (2006 est.)
Birth rate: 46.6 births/1 ,000 population (2006 est.)
Death rate: 20.34 deaths/1 ,000 population
(2006 est.)
Net migration rate: 0.42 migrant(s)/1,000
population (2006 est.)
Sex ratio:
at binh: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
75-64 years: 1 .05 male(s)/female
65 years and over: 0.95 male(s)/female
total population: 1 .05 male(s)/female (2006 est.)
Infant mortality rate:
total: 160.23 deaths/1 ,000 live births
male: 164.77 deaths/1 ,000 live births
female: 155.45 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 43.34 years
male: 43. 16 years
female: 43.53 years (2006 est.)
Total fertility rate: 6.69 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.01%
(2001 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Major infectious diseases:
degree of risk: high
food or waterbome diseases: bacterial and protozoal
diarrhea, hepatitis A. and typhoid fever
vectorborne disease: malaria is a high risk
countrywide below 2,000 meters from March through
November
animal contact disease: rabies (2004)
Nationality:
noun: Afghan(s)
adjective: Afghan
Ethnic groups: Pashtun 42%. Tajik 27%. Hazara
9%, Uzbek 9%. Aimak 4%, Turkmen 3%, Baloch 2%,
other 4%
Religions: Sunni Muslim 80%, Shi''a Muslim 19%,
other 1 %
Languages: Afghan Persian or Dari (official) 50%.
Pashtu (official) 35%. Turkic languages (primarily
Uzbek and Turkmen) 11%. 30 minor languages
(primarily Balochi and Pashai) 4%. much bilingualism
Literacy:
definition: age 1 5 and over can read and write
total population: 36%
male: 51%
fema/e: 21 °0 (1999 est.)
People - note: of the estimated 4 million refugees in
October 2001, 2.3 million have returned
Population: 5,042,920 (July 2006 est.)
Age structure:
0-14 years: 35.2% (male 913,988/female 863,503)
15-64 years: 60.7% (male 1 ,501 ,486/female
1,557,155)
65 years and over: 4. 1 % (male 79,227/female
127,561) (2006 est.)
563
Turkmenistan (continued)
Median age:
total: 21. 8 years
male: 20.9 years
female: 22.7 years (2006 est.)
Population growth rate: 1 .83% (2006 est.)
Birth rate: 27.61 births/1,000 population (2006 est.)
Death rate: 8.6 deaths/1 ,000 population (2006 est.)
Net migration rate: -0.75 migrant(s)/1,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.62 male(s)/female
total population: 0.98 male(s)/female (2006 est.)
Infant mortality rate:
total: 72.56 deaths/1,000 live births
male: 76.9 deaths/1,000 live births
female: 68 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 61 .83 years
male: 58.43 years
female: 65.41 years (2006 est.)
Total fertility rate: 3.37 children born/woman
(2006 est.)
HIV/AIDS ■ adult prevalence rate: less than 0.1%
(2004 est.)
HIV/AIDS • people living with HIV/AIDS: less than
200 (2003 est.)
HIV/AIDS • deaths: less than 100 (2004 est.)
Nationality:
noun: Turkmen(s)
adjective: Turkmen
Ethnic groups: Turkmen 85%, Uzbek 5%, Russian
4%, other 6% (2003)
Religions: Muslim 89%, Eastern Orthodox 9%,
unknown 2%
Languages: Turkmen 72%, Russian 12%, Uzbek
9%, other 7%
Literacy:
definition: age 15 and over can read and write
fofa/popu/af/on:98.8%
male: 99.3%
female: 98.3% (1999 est.)
Population: 21 , 1 52 (July 2006 est.)
Age structure:
0-14 years: 31 .9% (male 3,432/female 3,312)
15-64 years: 64.4% (male 7,1 55/female 6,457)
65 years and over: 3.8% (male 362/female 434)
(2006 est.)
Median age:
total: 27.5 years
male: 28.3 years
female: 26.8 years (2006 est.)
Population growth rate: 2.82% (2006 est.)
Birth rate: 21 .84 births/1 ,000 population (2006 est.)
Death rate: 4.21 deaths/1 ,000 population (2006 est.)
Net migration rate: 10.54 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at binh: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.11 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 1 .07 male(s)/female (2006 est.)
Infant mortality rate:
total: 15.18 deaths/1 ,000 live births
male: 17.55 deaths/1 ,000 live births
temale:\\21 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 74.73 years
male: 72.48 years
female: 77.08 years (2006 est.)
Total fertility rate: 3.05 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: none
adjective: none
Ethnic groups: black 90%, mixed, European, or
North American 10%
Religions: Baptist 40%, Anglican 18%, Methodist
16%, Church of God 12%, other 14% (1990)
Languages: English (official)
Literacy:
definition: age 1 5 and over has ever attended school
total population: 98%
male: 99%
female: 98% (1970 est.)
People - note: destination and transit point for illegal
Haitian immigrants bound for the Turks and Caicos
Islands, The Bahamas, and US
566
Turks and Caicos Islands (continued)','023e236481272d28815a0a4a82f73976d3425441cae3b95ab725ffe204c4182d','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c922815bce37121f633875f63f76c242919259853000d2ac571d8ede2d6076a',2007,'AL','Albania','people-and-society',36,'Population: no indigenous inhabitants
note: approximately 1 ,300 military personnel are on
the base; there are another 5,000 British citizens who
are families of military personnel or civilian staff on
both Akrotiri and Dhekelia; Cyprus citizens work on
the base, but do not live there
Languages: English, Greek
Country name:
conventional long form: Akrotiri Sovereign Base Area
conventional short form: Akrotiri
Dependency status: overseas territory of UK;
administered by an administrator who is also the
Commander, British Forces Cyprus
Capital: Episkopi Cantonment; also serves as capital
of Dhekelia
Legal system: the laws of the UK, where applicable,
apply
Executive branch:
chief of state: Queen Elizabeth II (since 6 February
1952)
head of government: Administrator Maj. Gen. Peter
Thomas Clayton PEARSON (since 9 May 2003);
note - reports to the British Ministry of Defence
elections: none; the monarch is hereditary; the
administrator is appointed by the monarch
Diplomatic representation in the US: none
(overseas territory of the UK)
Diplomatic representation from the US: none
(overseas territory of the UK)
Flag description: the flag of the UK is used
Population: 3,581 ,655 (July 2006 est.)
Age structure:
0-14 years: 24.8% (male 464,954/female 423,003)
15-64 years: 66.3% (male 1 ,214,942/female
1,158,562)
65 years and over: 8.9% (male 148,028/female
172,166) (2006 est.)
Median age:
total: 28.9 years
male: 28.3 years
female: 29.5 years (2006 est.)
Population growth rate: 0.52% (2006 est.)
Birth rate: 15.11 births/1,000 population (2006 est.)
Death rate: 5.22 deaths/1 ,000 population (2006 est.)
Net migration rate: -4.67 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1.1 male(s)/female
under 15 years: 1.1 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 0.86 male(s)/female
total population: 1 .04 male(s)/female (2006 est.)
Infant mortality rate:
total: 20.75 deaths/1 ,000 live births
male: 21 .2 deaths/1 ,000 live births
female: 20.27 deaths/1 ,000 live births (2006 est)
Life expectancy at birth:
total population: 77 A3 years
male: 74.78 years
female: 80.34 years (2006 est.)
Total fertility rate: 2.03 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Albanian(s)
adjective: Albanian
Ethnic groups: Albanian 95%, Greek 3%, other 2%
(Vlach, Roma (Gypsy), Serb, Macedonian, Bulgarian)
(1989 est.)
note: in 1 989, other estimates of the Greek population
ranged from 1% (official Albanian statistics) to 12%
(from a Greek organization)
Religions: Muslim 70%, Albanian Orthodox 20%,
Roman Catholic 10%
note: percentages are estimates; there are no
available current statistics on religious affiliation; all
mosques and churches were closed in 1967 and
religious observances prohibited; in November 1990,
Albania began allowing private religious practice
Languages: Albanian (official - derived from Tosk
dialect). Greek, Vlach, Romani, Slavic dialects
Literacy:
definition: age 9 and over can read and write
total population: 86.5%
male: 93.3%
female: 79.5% (2003 est.)','3edce83c7898e7b52b24f0dd71f3a1747209bf6afe4ec5605e9610abb4ff2750','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb3e94a42006bca8b4fa7095826e1c893f3288011edde25ed95af4fa16d1ffbb',2007,'ES','Spain','people-and-society',46,'Population: 32,930,091 (July 2006 est.)
Age structure:
0-14 years: 28.1% (male 4,722,076/female
4,539,713)
15-64 years: 67.1% (male 1 1 ,133,802/female
10,964,502)
65 years and over: 4.8% (male 735,444/female
834,554) (2006 est.)
Median age:
total: 24.9 years
male: 24.7 years
female: 25.1 years (2006 est.)
Population growth rate: 1 .22% (2006 est.)
Birth rate: 17.14 births/1 ,000 population (2006 est.)
Death rate: 4.61 deaths/1 ,000 population (2006 est.)
Net migration rate: -0.35 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.88 male(s)/female
total population: 1 .02 male(s)/female (2006 est.)
Infant mortality rate:
total: 29.87 deaths/1 ,000 live births
male: 33.62 deaths/1 ,000 live births
female: 25.94 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 73.26 years
male: 71 .68 years
female: 74.92 years (2006 est.)
Total fertility rate: 1 .89 children born/woman
(2006 est.)
HIV/AIDS • adult prevalence rate: 0.1% ; note - no
country specific models provided (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 9,100
(2003 est.)
HIV/AIDS - deaths: less than 500 (2003 est.)
Major infectious diseases:
degree of risk: intermediate
food or waterborne diseases: bacterial diarrhea,
hepatitis A, and typhoid fever
vectorborne disease: cutaneous leishmaniasis is a
high risk in some locations (2004)
Nationality:
noun: Algerian(s)
adjective: Algerian
Ethnic groups: Arab-Berber 99%, European less
than 1 %
note: almost all Algerians are Berber in origin, not
Arab; the minority who identify themselves as Berber
live mostly in the mountainous region of Kabylie east
of Algiers; the Berbers are also Muslim but identify
with their Berber rather than Arab cultural heritage;
Berbers have long agitated, sometimes violently, for
autonomy; the government is unlikely to grant
autonomy but has offered to begin sponsoring
teaching Berber language in schools
Religions: Sunni Muslim (state religion) 99%,
Christian and Jewish 1 %
Languages: Arabic (official), French, Berber dialects
Literacy:
definition: age 15 and over can read and write
total population: 70%
male: 78.8%
female: 61% (2003 est.)
Population: 71,201 (July 2006 est.)
Age structure:
0-14 years: 14.7% (male 5.456/female 4,994)
15-64 years: 71 .4% (male 26,632/female 24,172)
65 years and over: 14% (male 4,918/female 5,029)
(2006 est.)
Median age:
total: 40.9 years
male: 41.2 years
female: 40.7 years (2006 est.)
Population growth rate: 0.89% (2006 est )
Birth rate: 8.71 births/1 ,000 population (2006 est.)
Death rate: 6.25 deaths/1 ,000 population (2006 est.)
Net migration rate: 6.47 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1 .09 male(s)/female
1 5-64 years: 1 .1 male(s)/female
65 years and over: 0.98 male(s)/female
total population: 1 .08 male(s)/female (2006 est.)
Infant mortality rate:
total: 4.04 deaths/1 ,000 live births
male: 4.38 dsaths/1 ,000 live births
female: 3.68 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 83.51 years
male: 80.61 years
female: 86.61 years (2006 est.)
Total fertility rate: 1 .3 children born/woman
(2006 est.)
HIV/AIDS • adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Andorran(s)
adjective: Andorran
Ethnic groups: Spanish 43%. Andorran 33%.
Portuguese 11%, French 7%, other 6% (1998)
Religions: Roman Catholic (predominant)
Languages: Catalan (official), French, Castihan
Portuguese
15
Andorra (continued)
Literacy:
definition: NA
total population: 100%
ma/e: 100%
fema/e:100°o
Population: 60,876,136 (July 2006 est.)
Age structure:
0-14 years: 18.3% (male 5,704, 152/female 5,427,213)
15-64 years: 65.3% (male 19,886,228/female
19,860,506)
65 years and over: 16.4% (male 4,103,883/female
5,894,154) (2006 est.)
Median age:
total: 39.1 years
male: 37.6 years
female: 40.7 years (2006 est.)
Population growth rate: 0.35% (2006 est.)
Birth rate: 1 1 .99 births/1 ,000 population (2006 est.)
Death rate: 9. 14 deaths/1 ,000 population (2006 est.)
Net migration rate: 0.66 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.95 ma!e(s)/female (2006 est.)
Infant mortality rate:
total: 4.21 deaths/1 ,000 live births
male: 4.71 deaths/1 ,000 live births
female: 3.69 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 79.73 years
male: 76.1 years
female: 83.54 years (2006 est.)
Total fertility rate: 1 .84 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.4% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 120,000
(2003 est.)
HIV/AIDS - deaths: less than 1 ,000 (2003 est.)
Nationality:
noun: Frenchman(men), Frenchwoman(women)
adjective: French
Ethnic groups: Celtic and Latin with Teutonic,
Slavic, North African, Indochinese, Basque minorities
Religions: Roman Catholic 83%-88%, Protestant
2%, Jewish 1%, Muslim 5%-10%, unaffiliated 4%
Languages: French 1 00%, rapidly declining regional
dialects and languages (Provencal, Breton, Alsatian,
Corsican, Catalan, Basque, Flemish)
Literacy:
definition: age 1 5 and over can read and write
total population: 99%
male: 99%
female: 99% (2003 est.)
Population: 9.439
note: an estimated 8,000 refugees left the island
following the resumption of volcanic activity in
July 1995; some have returned (July 2006 est.)
Age structure:
0-14 years: 23.3% (male 1,125/female 1,079)
15-64 years: 65.7% (male 2,957/female 3,245)
65 years and over: 1 0.9% (male 532/female 501 )
(2006 est.)
Median age:
total: 28.9 years
male: 28.6 years
female: 29.2 years (2006 est.)
Population growth rate: 1 .05% (2006 est.)
Birth rate: 1 7.59 births/1 ,000 population (2006 est.)
Death rate: 7.1 deaths/1,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2006 est.)
Sex ratio:
afb/rfAr 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 1 .06 male(s)/female
total population: 0.96 male(s)/female (2006 est.)
Infant mortality rate:
total: 7.19 deaths/1,000 live births
male: 8.35 deaths/1,000 live births
female: 5.97 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 78.85 years
male: 76.67 years
female: 81 .14 years (2006 est.)
Total fertility rate: 1.77 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS • deaths: NA
Nationality:
noun: Montserratian(s)
adjective: Montserratian
Ethnic groups: black, white
Religions: Anglican, Methodist, Roman Catholic,
Pentecostal, Seventh-Day Adventist, other Christian
denominations
Languages: English
Literacy:
definition: age 15 and over has ever attended school
total population: 97%
male: 97%
fema/e:97%(1970est.)
Country name:
conventional long form: none
conventional shod form: Montserrat
Dependency status: overseas territory of the UK
Government type: NA
Capital: Plymouth (abandoned in 1997 due to
volcanic activity; interim government buildings have
been built at Brades Estate, in the Carr''s Bay/Little
Bay vicinity at the northwest end of Montserrat)
Administrative divisions: 3 parishes; Saint ■
Anthony, Saint Georges, Saint Peter
Independence: none (overseas territory of the UK)
National holiday: Birthday of Queen ELIZABETH*II,
second Saturday in June (1926)
Constitution: effective 19 December 1989
Legal system: English common law and statutory law
Suffrage: 18 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II (since 6 February
1952), represented by Governor Deborah
BARNES-JONES (since 10 May 2004)
head of government: Chief Minister John OSBORNE
(since 5 April 2001)
cabinet: Executive Council consists of the governor,
the chief minister, three other ministers, the attorney
general, and the finance secretary
elections: the monarch is hereditary; governor
appointed by the monarch; following legislative
elections, the leader of the majority party usually
becomes chief minister
Legislative branch: unicameral Legislative Council
(1 1 seats, 9 popularly elected; members serve
five-year terms)
note: expanded in 2001 from 7 to 9 elected members
with attorney general and financial secretary sitting as
ex-officio members
elections: last held April 2001 (next to be held by
November 2006)
election results: percent of vote by party - NA%; seats
by party - NPLM 7, NPP 2
note: in 2001, the Elections Commission instituted a
single constituency/voter-at-large system whereby all
eligible voters cast ballots for all nine seats of the
Legislative Council
Judicial branch: Eastern Caribbean Supreme Court
(based in Saint Lucia, one judge of the Supreme Court
is a resident of the islands and presides over the Hiqh
Court)
Political parties and leaders: National Progressive
Party or NPP [Reuben T. MEADE]; New People''s
Liberation Movement or NPLM [John A. OSBORNE]
Political pressure groups and leaders: NA
International organization participation: Caricom,
CDB. ICFTU, Interpol (subbureau), OECS, UPU
Diplomatic representation in the US: none
(overseas territory of the UK)
Diplomatic representation from the US: none
(overseas territory of the UK)
380
Flag description: blue, with the flag of the UK in the
upper hoist-side quadrant and the Montserratian coat
of arms centered in the outer half of the flag; the coat
of arms features a woman standing beside a yellow
harp with her arm around a black cross
Population: 10,605,870 (July 2006 est.)
Age structure:
0-14 years: 16.5% (male 915,604/female 839,004)
15-64 years: 66.3% (male 3,484,545/female
3,544,674)
65 years and over: 1 7.2% (male 751 ,899/female
1,070,144) (2006 est.)
Median age:
total: 38.5 years
male: 36.4 years
female: 40.6 years (2006 est.)
Population growth rate: 0.36% (2006 est.)
Birth rate: 10.72 births/1 ,000 population (2006 est.)
Death rate: 1 0.5 deaths/1 ,000 population (2006 est.)
449
Portugal (continued)
Net migration rate: 3.4 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1 .09 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.95 male(s)/female (2006 est.)
Infant mortality rate:
total: 4.98 deaths/1 ,000 live births
male: 5.45 deaths/1 ,000 live births
female: 4.48 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 111 years
male: 74.43 years
female: 81 .2 years (2006 est.)
Total fertility rate: 1 .47 children bom/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.4% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 22,000
(2001 est.)
HIV/AIDS - deaths: less than 1 ,000 (2003 est.)
Nationality:
noun: Portuguese (singular and plural)
adjective: Portuguese
Ethnic groups: homogeneous Mediterranean stock;
citizens of black African descent who immigrated to
mainland during decolonization number less than
100,000; since 1990 East Europeans have entered','37236fcd358975b23a9aa406ef3968fcccc220e8fd7dfaf407de012b47cb7434','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e14e76c653f5c22827c6b7fdcc9367126d734b9bfe3f037f1028e5e10b746bf',2007,'NZ','New Zealand','people-and-society',56,'Population: 57,794 (July 2006 est.)
Age structure:
0-14 years: 34.7% (male 10,388/female 9,654)
15-64 years: 62.4% (male 18,698/female 17,350)
65 years and over: 2.9% (male 633/female 1 ,071 )
(2006 est.)
Median age:
total: 23.2 years
male: 22.9 years
female: 23.4 years (2006 est.)
Population growth rate: -0.19% (2006 est.)
Birth rate: 22.46 births/1 ,000 population (2006 est.)
Death rate: 3.27 deaths/1 ,000 population (2006 est.)
Net migration rate: -21.11 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .08 male(s)/female
15-64 years: 1 .08 male(s)/female
65 years and over: 0.59 male(s)/female
total population: 1 .06 male(s)/female (2006 est )
Infant mortality rate:
total: 9.07 deaths/1 ,000 live births
male: 9.66 deaths/1 ,000 live births
female: 8.45 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 76.05 years
male: 72.48 years
female: 79.82 years (2006 est.)
Total fertility rate: 3.16 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: American Samoan(s) (US nationals)
adjective: American Samoan
Ethnic groups: native Pacific islander 92 9%. Asian
2.9%, white 1 .2%, mixed 2.8%, other 0.2% (2000
census)
Religions: Christian Congregationalist 50%. Roman
Catholic 20%, Protestant and other 30%
13
American Samoa (continued)
Languages: Samoan 90.6% (closely related to
Hawaiian and other Polynesian languages), English
2.9%. Tongan 2.4%. other Pacific islander 2.1%, other
2%
note: most people are bilingual (2000 census)
Literacy:
definition: age 1 5 and over can read and write
total population: 97%
male: 98%
fema/e:97%(1980est.)
Population: 4,076,140 (July 2006 est.)
Age structure:
0-14 years: 21 .1% (male 439,752/female 419,174)
15-64 years: 67.1% (male 1 ,374.850/female
1,361,570)
65 years and over: 1 1 .8% (male 210,365/female
270.429) (2006 est.)
Median age:
total: 33.9 years
male: 33.2 years
female: 34.7 years (2006 est.)
Population growth rate: 0.99% (2006 est.)
Birth rate: 1 3.76 births/1 ,000 population (2006 est.)
Death rate: 7.53 deaths/1 ,000 population (2006 est.)
Net migration rate: 3.63 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.78 male(s)/female
total population: 0.99 male(s)/female (2006 est.)
Infant mortality rate:
total: 5.76 deaths/1 ,000 live births
male: 6.59 deaths/1 ,000 live births
female: 4.89 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 78.81 years
male: 75.82 years
female: 81 .93 years (2006 est.)
Total fertility rate: 1 .79 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.1% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 1 ,400
(2003 est.)
HIV/AIDS ■ deaths: less than 200 (2003 est.)
Nationality:
noun: New Zealander(s)
adjective: New Zealand
Ethnic groups: European 69.8%, Maori 7.9%, Asian
5.7%, Pacific islander 4.4%, other 0.5%, mixed 7.8%,
unspecified 3.8% (2001 census)
Religions: Anglican 14.9%, Roman Catholic 12.4%,
Presbyterian 10.9%, Methodist 2.9%, Pentecostal
1 .7%, Baptist 1 .3%, other Christian 9.4%, other 3.3%,
unspecified 17.2%, none 26% (2001 census)
Languages: English (official), Maori (official)
Literacy:
definition: age 1 5 and over can read and write
total population: 99%
male: 99%
female: 99% (2003 est.)
Population: 1 14,689 (July 2006 est.)
Age structure:
0-14 years: 35.3% (male 20,679/female 19,843)
15-64 years: 60.5% (male 34,399/female 34,964)
65 years and over: 4.2% (male 2,059/female 2,745)
(2006 est.)
Median age:
total: 20.7 years
male: 20.1 years
female: 21 .3 years (2006 est.)
Population growth rate: 2.01% (2006 est.)
Birth rate: 25.37 births/1 ,000 population (2006 est.)
Death rate: 5.28 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.99 male(s)/female (2006 est.)
Infant mortality rate:
total: 12.3 deaths/1 ,000 live births
male: 13.63 deaths/1 ,000 live births
female: 10.91 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 69.82 years
male: 67.32 years
female: 72.45 years (2006 est.)
Total fertility rate: 3 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Tongan(s)
adjective: Tongan
552
Tonga (continued)
Ethnic groups: Polynesian, Europeans
Religions: Christian (Free Wesleyan Church claims
over 30,000 adherents)
Languages: Tongan, English
Literacy:
definition: can read and write Tongan and/or English
total population: 98.9%
male: 98.8%
female: 99% (1999 est.)
Population: 1 .065,842 (July 2006 est.)
Age structure:
0-14 years: 20.1% (male 109.936/female 104,076)
15-64 years: 71 .3% (male 398,657/female 361 ,093)
65 years and over: 8.6% (male 41,1 62/female
50,918) (2006 est.)
Median age:
total: 31 .2 years
male: 30.8 years
female: 31 .7 years (2006 est.)
Population growth rate: -0.87% (2006 est.)
Birth rate: 12.9 births/1 ,000 population (2006 est.)
Death rate: 10.57 deaths/1 ,000 population
(2006 est.)
Net migration rate: -1 1 .07 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.1 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 1 .07 male(s)/female (2006 est.)
Infant mortality rate:
total: 25.05 deaths/1 ,000 live births
male: 26.86 deaths/1 ,000 live births
female: 23.15 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 66.76 years
male: 65.71 years
female: 67.86 years (2006 est.)
Total fertility rate: 1 .74 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 3.2% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 29,000
(2003 est.)
HIV/AIDS - deaths: 1 ,900 (2003 est.)
Nationality:
noun: Trinidadian(s), Tobagonian(s)
adjective: Trinidadian, Tobagonian
554
Trinidad and Tobago (continued)
Ethnic groups: Indian (South Asian) 40%, African
37.5%, mixed 20.5%, other 1 .2%, unspecified 0.8%
(2000 census)
Religions: Roman Catholic 26%, Hindu 22.5%,
Anglican 7.8%, Baptist 7.2%, Pentecostal 6.8%, other
Christian 5.8%, Muslim 5.8%, Seventh Day Adventist
4%, other 10.8%, unspecified 1 .4%, none 1 .9% (2000
census)
Languages: English (official), Hindi, French,
Spanish, Chinese
Literacy:
! definition: age 15 and over can read and write
total population: 98.6%
male: 99.1%
female: 98% (2003 est.)
Population: 16,025 (July 2006 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA (2006 est.)
Population growth rate: NA
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
note: there has been steady emigration from Wallis
and Futuna to New Caledonia (2006 est.)
Infant mortality rate:
total: NA
male: NA
female: NA
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Wallisian(s), Futunan(s), or Wallis and Futuna
Islanders
adjective: Wallisian, Futunan, or Wallis and Futuna
Islander
Ethnic groups: Polynesian
Religions: Roman Catholic 99%, other 1%
Languages: Wallisian 58.9% (indigenous
Polynesian language), Futunian 30.1%, French
10.8%, other 0.2% (2003 census)
Literacy:
definition: age 1 5 and over can read and write
total population: 50%
male: 50%
female: 50% (1969 est.)','a8f831b7e2d47bec6b0e627b465750440dbfd90508070faeaa5493d43b5e6028','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc33de295ae6a506381fb08a7a6c5889bc9d6b26bf2b7df22484c328e39b3368',2007,'NA','Namibia','people-and-society',68,'Population: 12,127,071 (July 2006 est.)
Age structure:
0-14 years: 43.7% (male 2,678,1 85/female
2,625,933)
15-64 years: 53.5% (male 3,291 ,954/female
3,195,688)
65 years and over: 2.8% (male 1 48,944/female
186.367) (2006 est.)
Median age:
total: 18 years
male: 18 years
female: 18 years (2006 est.)
Population growth rate: 2.45% (2006 est )
Birth rate: 45.11 births/1,000 population (2006 est )
Death rate: 24.2 deaths/1 ,000 population (2006 est )
Net migration rate: 3.55 migrant(s)/1,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 1.02 male(s)/female (2006 est )
17
Angola (continued)
Infant mortality rate:
rora/: 185.36 deaths/1 ,000 live births
male: 197.56 deaths/1 ,000 live births
female: 172.54 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 38.62 years
male: 37.47 years
female: 39.83 years (2006 est.)
Total fertility rate: 6.35 children born/woman
(2006 est.)
HIV/AIDS • adult prevalence rate: 3.9% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 240,000
(2003 est.)
HIV/AIDS - deaths: 21 ,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial and protozoal
diarrhea, hepatitis A, typhoid fever
vectorbome diseases: malaria, African
trypanosomiasis (sleeping sickness) are high risks in
some locations
respiratory disease: meningococcal meningitis
water contact disease: schistosomiasis (2004)
Nationality:
noun: Angolan(s)
adjective: Angolan
Ethnic groups: Ovimbundu 37%, Kimbundu 25%,
Bakongo 1 3%, mestico (mixed European and native
African) 2%, European 1%, other 22%
Religions: indigenous beliefs 47%, Roman Catholic
38%, Protestant 15% (1998 est.)
Languages: Portuguese (official), Bantu and other
African languages
Literacy:
definition: age 15 and over can read and write
total population: 66.9%
male: 82.1%
female: 53.8% (2001 est.)
Population: 44,187,637
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected
(July 2006 est.)
Age structure:
0-14 years: 29.7% (male 6,603,220/female
6,525,810)
15-64 years: 65% (male 13,955,950/female
14,766,843)
65 years and over: 5.3% (male 905,870/female
1,429,944) (2006 est.)
Median age:
total: 24.1 years
male: 23.3 years
female: 25 years (2006 est.)
Population growth rate: -0.4% (2006 est.)
Birth rate: 18.2 births/1 ,000 population (2006 est.)
Death rate: 22 deaths/1,000 population (2006 est.)
Net migration rate: -0.16 migrant(s)/1 ,000
population
note: there is an increasing flow of Zimbabweans into
South Africa and Botswana in search of better
economic opportunities (2006 est.)
Sex ratio:
at birth: 1 .02 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.63 male(s)/female
total population: 0.95 male(s)/female (2006 est.)
Infant mortality rate:
total: 60.66 deaths/1 ,000 live births
male: 64.31 deaths/1,000 live births
female: 56.92 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 42.73 years
male: 43.25 years
female: 42.19 years (2006 est.)
Total fertility rate: 2.2 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 21 .5%
(2003 est.)
HIV/AIDS - people living with HIV/AIDS: 5.3million
(2003 est.)
HIV/AIDS - deaths: 370,000 (2003 est.)
Nationality:
noun: South African(s)
adjective: South African
Ethnic groups: black African 79%, white 9.6%,
colored 8.9%, Indian/Asian 2.5% (2001 census)
Religions: Zion Christian 11.1%, Pentecostal/
Charismatic 8.2%, Catholic 7.1%, Methodist 6.8%,
Dutch Reformed 6.7%, Anglican 3.8%, other Christian
36%, Islam 1 .5%, other 2.3%, unspecified 1 .4%, none
15.1% (2001 census)
Languages: IsiZulu 23.8%, IsiXhosa 17.6%,
Afrikaans 13.3%, Sepedi 9.4%, English 8.2%,
Setswana 8.2%, Sesotho 7.9%, Xitsonga 4.4%, other
7.2% (2001 census)
Literacy:
definition: age 15 and over can read and write
total population: 86.4%
male: 87%
female: 85.7% (2003 est.)
Population: no indigenous inhabitants
note: the small military garrison on South Georgia
withdrew in March 2001 . to be replaced by a
permanent group of scientists of the British Antarctic
Survey, which also has a biological station on Bird
Island; the South Sandwich Islands are uninhabited
(July 2006 est.)','694ec940791dee43a279860634e2c7756b8591fb921c879a644235f13ad08040','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c942eb729426e9f875b88ccc7a2930a341e96ba4418272c6b78fa3ab7756270',2007,'PR','Puerto Rico','people-and-society',79,'Population: 1 3,477 (July 2006 est.)
Age structure:
0-14 years: 22.8% (male 1 ,557/female 1 ,510)
15-64 years: 70.4% (male 4,878/female 4,608)
65 years and over: 6.9% (male 41 2/female 51 2)
(2006 est.)
Median age:
total: 31 .2 years
male: 31 .2 years
female: 31.1 years (2006 est.)
Population growth rate: 1 .57% (2006 est.)
Birth rate: 14.17 births/1 ,000 population (2006 est.)
Death rate: 5.34 deaths/1 ,000 population (2006 est.)
Net migration rate: 6.9 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 1 .03 male(s)/female (2006 est.)
Infant mortality rate:
total: 20.32 deaths/1,000 live births
male: 26.67 deaths/1 ,000 live births
female: 13.79 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 77.28 years
male: 74.35 years
female: 80.3 years (2006 est.)
Total fertility rate: 1 .73 children bom/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Anguillan(s)
adjective: Anguillan
Ethnic groups: black (predominant) 90.1%, mixed,
mulatto 4.6%. white 3.7%. other 1 .5% (2001 Census)
Religions: Anglican 29%, Methodist 23.9%, other
Protestant 30.2%, Roman Catholic 5.7%, other
Christian 1 .7%, other 5.2%, none or unspecified 4.3%
(2001 Census)
Languages: English (official)
Literacy:
definition: age 1 2 and over can read and write
total population: 95%
male: 95%
female: 95% (1984 est.)','0677fcb78f2fd910b3cf8f0340b8e90abc6e5d061dfd3502054c6bc22eb631a3','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46e64d155724b0dcabd745d7bcb3cb95c9a814e555f9dcb116938190e725fd6f',2007,'AQ','Antarctica','people-and-society',88,'Population: no indigenous inhabitants, but there are
both permanent and summer-only staffed research
stations
note: 26 nations, all signatory to the Antarctic Treaty,
operate through their National Antarctic Program a
number of seasonal-only (summer) and year-round
research stations on the continent and its nearby
islands south of 60 degrees south latitude (the region
covered by the Antarctic Treaty); these stations''''
population of persons doing and supporting science or
engaged in the management and protection of the
Antarctic region varies from approximately 4,000 in
summer to 1,000 in winter; in addition, approximately
1,000 personnel, including ship''s crew and scientists
doing onboard research, are present in the waters of
the treaty region; peak summer (December-February)
population - 3,822 total; Argentina 417, Australia 213,
Brazil 40, Bulgaria 15, Chile 224, China 70, Ecuador
22, Finland 20, France 123, Germany 78, India 65,
Italy 112, Japan 150, South Korea 60, NZ85, Norway
44, Peru 28, Poland 40, Russia 429, South Africa 80,
Spain 28, Sweden 20, Ukraine 24, UK 205, US 1,170,
Uruguay 60 (2005-2006); winter (June-August) station
population - 1 .028 total; Argentina 176. Australia 62,
Brazil 12, Chile 88, China 29, France 37, Germany 9.
India 25, Italy 2, Japan 40, South Korea 15, NZ 10,
Norway 7, Poland 12, Russia 148, South Africa 10,
Ukraine 12, UK 37. US 288, Uruguay 9 (2005);
research stations operated within the Antarctic Treaty
area (south of 60 degrees south latitude) by members
of the Council of Managers of National Antarctic
Programs (COMNAP): year-round stations - 37 total;
Argentina 6. Australia 3, Brazil 1, Chile 3, China 2,
France 1 , Germany 1 , India 1 , Japan 1 , South Korea
1 , NZ 1 , Norway 1 , Poland 1 , Russia 5, South Africa 1 .
Ukraine 1 , UK 2, US 3. Uruguay 1 , Italy and France
jointly 1 (2005); seasonal-only (summer) stations - 15
total; Australia 1 . Bulgaria 1 , Chile 1 . Ecuador 1 ,
Finland 1 , Germany 1 . Italy 1 . Japan 1 , Norway 1 ,
Peru 1 , Russia 1 , Spain 2, Sweden 1 , UK 1
(2005-2006); in addition, during the austral summer
some nations have numerous occupied locations such
as tent camps, summer-long temporary facilities, and
mobile traverses in support of research','a780e48356944d9cd54e52c1582c7b2553dc4da10323ec2ef74abf26f0675431','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1745c9f0d261691e43141a33b9783842c546028fdc7788f8f0a0c0dc9aa6d996',2007,'AG','Antigua and Barbuda','people-and-society',99,'Population: 69,108 (July 2006 est.)
Age structure:
0-14 years: 27.6% (male 9,716/female 9,375)
15-64 years: 68.5% (male 23,801 /female 23,524)
65 years and over: 3.9% (male 1 ,020/female 1 ,672)
(2006 est.)
Median age:
total: 30 years
male: 29.5 years
female: 30.5 years (2006 est.)
Population growth rate: 0.55% (2006 est.)
Birth rate: 16.93 births/1,000 population (2006 est.)
Death rate: 5.37 deaths/1 ,000 population (2006 est.)
Net migration rate: -6.08 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.61 male(s)/female
total population: 1 male(s)/female (2006 est.)
Infant mortality rate:
rota/: 18.86 deaths/1 ,000 live births
male: 22.71 deaths/1,000 live births
female: 14.82 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 72. 1 6 years
male: 69.78 years
female: 74.66 years (2006 est.)
Total fertility rate: 2.24 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
24
Antigua and Barbuda (continued)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Antiguan(s), Barbudan(s)
adjective: Antiguan, Barbudan
Ethnic groups: black, British, Portuguese,
Lebanese, Syrian
Religions: Christian (predominantly Anglican with
other Protestant, and some Roman Catholic)
Languages: English (official), local dialects
Literacy:
definition: age 1 5 and over has completed five or more
years of schooling
total population: 85.8%
male: NA%
female: NA% (2003 est.)','ff6a5d6b54e42829334140091324f50a3d39e099839d6dd2dc6fd9a01188b489','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2c42f768740aca5a23156c785dac61519b9c085175767188651a2d8028d079b',2007,'AR','Argentina','people-and-society',107,'Population: 39,921 ,833 (July 2006 est.)
Age structure:
0-14 years: 25.2% (male 5,153,164/female
4,921,625)
15-64 years: 64.1% (male 12,804,376/female
12,798,731)
65 years and over: 1 0.6% (male 1 ,740,1 1 8/female
2,503,819) (2006 est.)
Median age:
total: 29.7 years
male: 28.8 years
female: 30.7 years (2006 est.)
Population growth rate: 0.96% (2006 est.)
Birth rate: 16.73 births/1,000 population (2006 est.)
Death rate: 7.55 deaths/1 ,000 population (2006 est.)
Net migration rate: 0.4 migrant(s)/1,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.7 male(s)/female
total population- 0.97 male(s)/female (2006 est.)
Infant mortality rate:
total: 14.73 deaths/1 ,000 live births
male: 16.58 deaths/1 ,000 live births
female: 12.78 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 76.12 years
male: 72.38 years
female: 80.05 years (2006 est.)
Total fertility rate: 2.16 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.7% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 1 30.000
(2001 est.)
HIV/AIDS - deaths: 1 ,500 (2003 est.)
Nationality:
noun: Argentine(s)
adjective: Argentine
Ethnic groups: white (mostly Spanish and Italian)
97%, mestizo (mixed white and Amerindian ancestry),
Amerindian, or other non-white groups 3°o
Religions: nominally Roman Catholic 92% (less than
20% practicing), Protestant 2%. Jewish 2% other 4%
Languages: Spanish (official), English, Italian,
German, French
Literacy:
definition: age 1 5 and over can read and write
total population: 97.1%
ma/e:97.1%
female: 97.1% (2003 est.)
Population: 16,134,219 (July 2006 est.)
Age structure:
0-14 years: 24.7% (male 2,035,278/female
1,944,754)
15-64 years: 67.1°0 (male 5,403,525/female
5,420,497)
65 years and over: 8.2% (male 555,075/female
775,090) (2006 est.)
Median age:
total: 30.4 years
male: 29.5 years
female: 31 .4 years (2006 est.)
Population growth rate: 0.94% (2006 est.)
Birth rate: 15.23 births/1,000 population (2006 est.)
Death rate: 5.81 deaths/1 ,000 population (2006 est.
Net migration rate: 0 migrant(s)/1,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.98 male(s)/female (2006 est.)
Infant mortality rate:
total: 8.58 deaths/1 ,000 live births
male: 9.32 deaths/1 ,000 live births
female: 7.8 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 76.77 years
male: 73.49 years
female: 80.21 years (2006 est.)
Total fertility rate: 2 children born/woman
(2006 est.)
HIV/AIDS • adult prevalence rate: 0.3% (2003 est.
HIV/AIDS - people living with HIV/AIDS: 26,000
(2003 est.)
HIV/AIDS - deaths: 1 ,400 (2003 est.)
Nationality:
noun: Chilean(s)
adjective: Chilean
Ethnic groups: white and white-Amerindian 95%,
Amerindian 3%, other 2%
Religions: Roman Catholic 89%, Protestant 1 1%,
Jewish NEGL%
Languages: Spanish
Literacy:
definition: age 15 and over can read and write
total population: 96.2%
male: 96.4%
female: %A% (2003 est.)
Population: 6,506,464 (July 2006 est.)
Age structure:
0-14 years: 37.7% (male 1 ,245,1 49/female
1,204,970)
15-64 years: 57.5% (male 1 ,878,761 /female
1,862,266)
65 years and over: 4.8% (male 145.899/female
169,419) (2006 est.)
Median age:
total: 21 .3 years
male: 2 1.1 years
female: 21 .6 years (2006 est.)
Population growth rate: 2.45% (2006 est.)
Birth rate: 29.1 births/1 .000 population (2006 est.)
Death rate: 4.49 deaths/1 ,000 population (2006 est.)
Net migration rate: -0.08 migrant(s)/1,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.86 male(s)/female
total population: 1 .01 male(s)/female (2006 est.)
Infant mortality rate:
total: 24.78 deaths/1 ,000 live births
male: 29.4 deaths/1 .000 live births
female: 19.92 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 75.1 years
male: 72.56 years
female: 77.78 years (2006 est.)
Total fertility rate: 3.89 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.5% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 15.000
(1999 est.)
HIV/AIDS - deaths: 600 (2003 est.)
Nationality:
noun: Paraguayan(s)
adjective: Paraguayan
Ethnic groups: mestizo (mixed Spanish and
Amerindian) 95%, other 5%
Religions: Roman Catholic 90%, Mennonite and
other Protestant 10%
Languages: Spanish (official), Guarani (official)
Literacy:
definition: age 1 5 and over can read and write
total population: 94%
male: 94.9%
female: 93% (2003 est.)
Population: 28,302,603 (July 2006 est.)
Age structure:
0-14 years: 30.9% (male 4,456, 195/female
4,300,233)
15-64 years: 63.7% (male 9,078, 123/female
8,961,981)
65 years and over: 5.3% (male 709,763/female
796,308) (2006 est.)
Median age:
total: 25.3 years
male: 25 years
female: 25.5 years (2006 est.)
Population growth rate: 1 .32% (2006 est.)
Birth rate: 20.48 births/1,000 population (2006 est.)
Death rate: 6.23 deaths/1 ,000 population (2006 est.)
Net migration rate: -1.01 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.89 male(s)/female
total population: 1.01 male(s)/female (2006 est.)
Infant mortality rate:
total: 30.94 deaths/1 ,000 live births
male: 33.49 deaths/1 ,000 live births
female: 28.27 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 69.84 years
male: 68.05 years
female: 71 .71 years (2006 est.)
Total fertility rate: 2.51 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.5% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 82,000
(2003 est.)
HIV/AIDS - deaths: 4,200 (2003 est.)
Nationality:
noun: Peruvian(s)
adjective: Peruvian
Ethnic groups: Amerindian 45%, mestizo (mixed
Amerindian and white) 37%, white 15%, black,
Japanese, Chinese, and other 3%
Religions: Roman Catholic 81%, Seventh Day
Adventist 1.4%, other Christian 0.7%, other 0.6%,
unspecified or none 16.3% (2003 est.)
Languages: Spanish (official), Quechua (official),
Aymara, and a large number of minor Amazonian
languages
Literacy:
definition: age 15 and over can read and write
total population: 87.7%
male: 93.5%
female: 82.V/o (2004 est.)','72fdb21b9acd3f3d2acf6e1a4087dbd2ac0be1443e06c4e7063a72d55f89df13','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d0070039677a2b3d3a075d3c05491af8ffbae5a208953689774d9c0b1f9ee65',2007,'AM','Armenia','people-and-society',114,'Population: 2.976,372 (July 2006 est.)
Age structure:
0-14 years: 20.5°o (male 322,189/female 286,944)
15-64 years: 68.4% (male 949,975/female 1 ,085,484)
65 years and over: 1 1.1% (male 1 33,41 1 /female
198,369) (2006 est.)
Median age:
total: 30.4 years
male: 27.8 years
female: 33.2 years (2006 est.)
Population growth rate: -0.19% (2006 est.)
Birth rate: 12.07 births/1 ,000 population (2006 est.)
Death rate: 8.23 deaths/1 ,000 population (2006 est.)
Net migration rate: -5.72 migrant(s)/1,000
population (2006 est.)
Sex ratio:
at birth: 1.17 male(s)/female
under 15 years: 1.12 male(s)/female
15-64 years: 0.88 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.9 male(s)/female (2006 est.)
Infant mortality rate:
total: 22.47 deaths/1 ,000 live births
male: 27.59 deaths/1 ,000 live births
female: 16.51 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 71 .84 years
male: 68.25 years
female: 76.02 years (2006 est.)
Total fertility rate: 1 .33 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.1% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 2,600
(2003 est.)
HIV/AIDS • deaths: less than 200 (2003 est.)
Nationality:
noun; Armenian(s)
adjective: Armenian
Ethnic groups: Armenian 97.9%, Yezidi (Kurd)
1.3%, Russian 0.5%, other 0.3% (2001 census)
Religions: Armenian Apostolic 94.7%, other
Christian 4%, Yezidi (monotheist with elements of
nature worship) 1 .3%
Languages: Armenian 97.7%, Yezidi 1%, Russian
0.9%, other 0.4% (2001 census)
Literacy:
definition: age 1 5 and over can read and write
total population: 98.6%
male: 99.4%
female: 98% (2003 est.)
G o v e r n m e
Country name:
conventional long form: Republic of Armenia
conventional short form: Armenia
local long form: Hayastani Hanrapetut''yun
local short form: Hayastan
former: Armenian Soviet Socialist Republic; Armenian
Republic
Government type: republic
Capital: Yerevan
Administrative divisions: 1 1 provinces (marzer,
singular - marz); Aragatsotn, Ararat, Armavir,
Geghark''unik'', Kotayk'', Lorri, Shirak, Syunik'', Tavush,
Vayots1 Dzor, Yerevan
Independence: 21 September 1991 (from Soviet
Union)
National holiday: Independence Day,
21 September (1991)
Constitution: adopted by nationwide referendum
5 July 1995; amendments adopted through a
nationwide referendum 27 November 2005
Legal system: based on civil law system
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Robert KOCHARIAN (since
30 March 1998)
head of government: Prime Minister Andranik
MARGARYAN (since 12 May 2000)
cabinet: Council of Ministers appointed by the prime
minister
30
Armenia (continued)
elections: president elected by popular vote for a
five-year term; election last held 19 February and
5 March 2003 (next to be held in 2008); prime minister
appointed by the president and confirmed with the
majority support of the National Assembly; the prime
minister and Council of Ministers must resign if the
National Assembly refuses to accept their program
election results: Robert KOCHARIAN reelected
president; percent of vote - Robert KOCHARIAN
67.5%, Stepan DEMIRCHYAN 32.5%
Legislative branch: unicameral National Assembly
(Parliament) or Azgayin Zhoghov (131 seats; members
elected by popular vote to serve four-year terms; 90
members elected by party list, 41 by direct vote)
elections: last held 25 May 2003 (next to be held in the
spring of 2007)
election results: percent of vote by party - Republican
Party 23.5%, Justice Bloc 13.6%, Rule of Law 12.3%,
ARF (Dashnak) 11.4%, National Unity Party 8.8%,
United Labor Party 5.7%; seats by faction -
Republican Party 39, Rule of Law 20, Justice Bloc 14,
ARF (Dashnak) 1 1 , National Unity 7, United Labor 6,
People''s Deputy Group 1 6, independent (not in faction
or group) 1 8; note - as of 1 0 March 2006; voting blocs
in the legislature are more properly termed factions
and can be composed of members of several parties;
seats by faction change frequently as deputies switch
parties or announce themselves independent
Judicial branch: Constitutional Court; Court of
Cassation (Appeals Court)
Political parties and leaders: Agro-Industrial Party
[Vladimir BADALYAN]; Armenia Party [Myasnik
MALKHASYAN]; Armenian National Movement or
ANM [Alex ARZUMANYAN, chairman]; Armenian
Ramkavar Liberal Party or HRAK [Harutyun
MIRZAKHANYAN, chairman]; Armenian
Revolutionary Federation ("Dashnak" Party) or ARF
[Levon MKRTCHYAN]; Democratic Party [Aram
SARKISYAN]; Justice Bloc (comprised of the
Democratic Party, National Democratic Party,
National Democratic Union, the People''s Party, and
the Republic Party) [Stepan DEMIRCHYAN]; National
Democratic Party [Shavarsh KOCHARIAN]; National
Democratic Union or NDU [Vazgen MANUKIAN];
National Revival Party [Albert BAZEYAN]; National
Unity Party [Artashes GEGHAMYAN, chairman];
People''s Party of Armenia [Stepan DEMIRCHYAN];
Republic Party [Aram SARKISYAN, chairman];
Republican Party or RPA [Andranik MARGARYAN];
Rule of Law Party [Samvel BALASANYAN]; Union of
Constitutional Rights [Hrant KHACHATURYAN];
United Labor Party [Gurgen ARSENYAN]
Political pressure groups and leaders: Yerkrapah
Union [Manvel GRIGORIAN]
International organization participation: ACCT
(observer), AsDB, BSEC, CE, CIS, EAPC, EBRD,
FAO, IAEA, IBRD, ICAO, ICCt (signatory), ICRM, IDA,
IFAD, IFC, IFRCS, ILO, IMF, Interpol, IOC, IOM, IPU,
ISO, ITU, MIGA, NAM (observer), OAS (observer),
OIF (observer), OPCW, OSCE, PFP, UN, UNCTAD,
UNESCO, UNIDO, UPU, WCO, WFTU, WHO, WIPO,
WMO, WToO, WTO
Diplomatic representation in the US:
chief of mission: Ambassador Tatoul MARKARIAN
chancery: 2225 R Street NW, Washington, DC 20008
telephone: tf] (202) 319-1976
FAX:{\\] (202) 319-2982
consulate(s) general: Los Angeles
Diplomatic representation from the US:
chief of mission: Ambassador John M. EVANS
embassy: 1 American Ave., Yerevan 375082
mailing address: American Embassy Yerevan,
Department of State, 7020 Yerevan Place,
Washington, DC 20521-7020
telephone: [374]^ 0)464-700
FAX:[374](1 0)464-742
Flag description: three equal horizontal bands of
red (top), blue, and orange','d523d841a43597c6de36736c818fbf40138a5162ae40cb0becd18a85f1b9a042','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98279191c44975a1033870369627f83416d6c26e9dde382eae8003b048f77bfa',2007,'AW','Aruba','people-and-society',122,'Population: 71 ,891 (July 2006 est.)
Age structure:
0-14 years: 19.5% (male 7,175/female 6,849)
15-64 years: 68.2% (male 23,894/female 25,140)
65 years and over: 1 2.3% (male 3,61 6/female 5,217)
(2006 est.)
Median age:
total: 38.5 years
male: 36.4 years
female: 40.3 years (2006 est.)
Population growth rate: 0.44% (2006 est.)
Birth rate: 1 1 .03 births/1 ,000 population (2006 est.)
Death rate: 6.68 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1. 05 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.93 male(s)/female (2006 est.)
Infant mortality rate:
total: 5.79 deaths/1 ,000 live births
male: 6.6 deaths/1 ,000 live births
female: 4.95 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 79.28 years
male: 75.95 years
female: 82.78 years (2006 est.)
Total fertility rate: 1 .79 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Aruban(s)
adjective: Aruban; Dutch
Ethnic groups: mixed white/Caribbean Amerindian
80%
Religions: Roman Catholic 82%, Protestant 8%,
Hindu, Muslim, Confucian, Jewish
Languages: Dutch (official), Papiamento (a Spanish,
Portuguese, Dutch, English dialect), English (widely
spoken), Spanish
Literacy:
definition: NA
total population: 97%
male: NA%
female: NA%','5da69f6212476c9b6c9f8d6110355cf4ac2190e6fff34abfc093a73ec6ef34d1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7d305b4422fc02b99599e78ee23cbae609238cb532c029e46ce898dc339ec8a8',2007,'AU','Australia','people-and-society',133,'Population: no indigenous inhabitants
note: Indonesian fishermen are allowed access to the
lagoon and fresh water at Ashmore Reef''s West Island
(July 2006 est.)
People - note: the landing of illegal immigrants from
Indonesia''s Rote Island has become an ongoing
problem
Atlantic Ocean
Governmen
t
.w&&
Country name:
conventional long form: Territory of Ashmore and
Cartier Islands
conventional short form: Ashmore and Cartier Islands
Dependency status: territory of Australia;
administered by the Australian Department of
Transport and Regional Services
Legal system: the laws of the Commonwealth of
Australia and the laws of the Northern Territory of
Australia, where applicable, apply
Diplomatic representation in the US: none
(territory of Australia)
Diplomatic representation from the US: none
(territory of Australia)
Flag description: the flag of Australia is used
Population: uninhabited (July 2006 est.)
Population: 82,459 (July 2006 est.)
Age structure:
0-14 years: 19.4% (male 8,350/female 7,623)
15-64 years: 79% (male 26,71 5/female 38,442)
65 years and over: 1 .6% (male 679/female 650)
(2006 est.)
Median age:
total: 29.5 years
male: 31.7 years
female: 28.5 years (2006 est.)
Population growth rate: 2.54% (2006 est.)
Birth rate: 19.43 births/1 ,000 population (2006 est.)
Death rate: 2.29 deaths/1 ,000 population (2006 est.)
Net migration rate: 8.26 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1.1 male(s)/female
15-64 years: 0.7 male(s)/female
65 years and over: 1 .05 male(s)/fema!e
total population: 0.77 male(s)/female (2006 est.)
Infant mortality rate:
total: 6.98 deaths/1 ,000 live births
male: 6.92 deaths/1 ,000 live births
female: 7.03 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 76.09 years
male: 73.5 years
female: 78.83 years (2006 est.)
Total fertility rate: 1 .24 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: NA (US citizens)
adjective: NA
Ethnic groups: Asian 56.3%, Pacific islander
36.3%, Caucasian 1 .8%, other 0.8%, mixed 4.8%
(2000 census)
Religions: Chnstian (Roman Catholic majority,
although traditional beliefs and taboos may still be found)
Languages: Philippine languages 24.4%, Chinese
23.4%, Chamorro22.4%, English 10.8%, other Pacific
island languages 9.5%, other 9.6% (2000 census)
Literacy:
definition: age 1 5 and over can read and write
total population: 97%
male: 97%
female: 96% (1980 est.)','e5f0e4cc00d56e0537ee083633e15b901f70cb4880aa2afc834ca939e05e7712','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cee61cdba8fa98061c93cd9c6f85d111946a12f9bcde12b3c3435e0336790f02',2007,'ID','Indonesia','people-and-society',140,'Population: 20,264,082 (July 2006 est.)
Age structure:
0-14 years: 19.6% (male 2,031 ,313/female
1,936,802)
15-64 years: 67.3% (male 6,881 ,863/female
6,764,709)
65 years and over: 1 3. 1 % (male 1 , 1 70,589/female
1,478,806) (2006 est.)
Median age:
total: 36.9 years
male: 36 years
female: 37.7 years (2006 est.)
36
Australia (continued)
Population growth rate: 0.85% (2006 est.)
Birth rate: 12.14 births/1 ,000 population (2006 est.)
Death rate: 7.51 deaths/1 ,000 population (2006 est.)
Net migration rate: 3.85 migrant(s)/1,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 0.99 male(s)/female (2006 est.)
Infant mortality rate:
total: 4.63 deaths/1 ,000 live births
male: 5.02 deaths/1 ,000 live births
female: 4.22 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 80.5 years
male: 77.64 years
female: 83.52 years (2006 est.)
Total fertility rate: 1 .76 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.1% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 14,000
(2003 est.)
HIV/AIDS - deaths: less than 200 (2003 est.)
Nationality:
noun: Australian(s)
adjective: Australian
Ethnic groups: Caucasian 92%, Asian 7%,
aboriginal and other 1%
Religions: Catholic 26.4%, Anglican 20.5%, other
Christian 20.5%, Buddhist 1.9%, Muslim 1.5%, other
1.2%, unspecified 12.7%, none 15.3% (2001 Census)
Languages: English 79.1%, Chinese 2.1%, Italian
1.9%, other 11.1%, unspecified 5.8% (2001 Census)
Literacy:
definition: age 1 5 and over can read and write
total population: 99%
male: 99%
female: 99% (2003 est.)
Population: 1,062,777
note: other estimates range as low as 800,000
(July 2006 est.)
Age structure:
0-14 years: 36.3% (male 196,293/female 189,956)
15-64 years: 60.6% (male 328,1 1 1 /female 315,401)
65 years and over: 3.1 % (male 1 6,072/female
16,944) (2006 est.)
165
East Timor (continued)
Median age:
total: 20.8 years
male: 20.8 years
female: 20.7 years (2006 est.)
Population growth rate: 2.08% (2006 est.)
Birth rate: 26.99 births/1 ,000 population (2006 est.)
Death rate: 6.24 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1. 03 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.95 male(s)/female
total population: 1 .04 male(s)/female (2006 est.)
Infant mortality rate:
total: 45.89 deaths/1 ,000 live births
male: 52.03 deaths/1 ,000 live births
female: 39.44 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 66.26 years
male: 63.96 years
female: 68.67 years (2006 est.)
Total fertility rate: 3.53 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS ■ deaths: NA
Nationality:
noun: Timorese
adjective: Timorese
Ethnic groups: Austronesian (Malayo-Polynesian),
Papuan, small Chinese minority
Religions: Roman Catholic 90%, Muslim 4%,
Protestant 3%, Hindu 0.5%, Buddhist, Animist
(1992 est.)
Languages: Tetum (official), Portuguese (official),
Indonesian, English
note: there are about 16 indigenous languages;
Tetum, Galole, Mambae, and Kemak are spoken by
significant numbers of people
Literacy:
definition: age 15 and over can read and write
total population: 58.6%
male: NA%
female: NA% (2002)
Population: 24,385,858 (July 2006 est.)
Age structure:
0-14 years: 32.6% (male 4,093,859/female
3,862,730)
15-64 years: 62.6% (male 7,660,680/female
7,613,537)
65 years and over: 4.7% (male 509,260/female
645,792) (2006 est.)
Median age:
total: 24.1 years
male: 23.6 years
female: 24.8 years (2006 est.)
Population growth rate: 1.78% (2006 est.)
Birth rate: 22.86 births/1 ,000 population (2006 est.)
Death rate: 5.05 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
note: does not reflect net flow of an unknown number
of illegal immigrants from other countries in the region
(2006 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 1 .01 male(s)/female (2006 est.)
Infant mortality rate:
total: 17.16 deaths/1 ,000 live births
male: 19.87 deaths/1,000 live births
female: 14.25 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 72.5 years
male: 69.8 years
female: 75.38 years (2006 est.)
Total fertility rate: 3.04 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.4% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 52,000
(2003 est.)
HIV/AIDS - deaths: 2,000 (2003 est.)
Major infectious diseases:
degree of risk: high
food or waterborne diseases: bacterial diarrhea,
hepatitis A, and typhoid fever
vectorbome diseases: dengue fever and malaria are
high risks in some locations (2004)
Nationality:
noun: Malaysian(s)
adjective: Malaysian
Ethnic groups: Malay 50.4%, Chinese 23.7%,
Indigenous 11%, Indian 7.1%, others 7.8% (2004 est.)
Religions: Muslim, Buddhist, Daoist, Hindu,
Christian, Sikh; note - in addition, Shamanism is
practiced in East Malaysia
Languages: Bahasa Melayu (official), English,
Chinese (Cantonese, Mandarin, Hokkien, Hakka,
Hainan, Foochow), Tamil, Telugu, Malayalam,
Panjabi, Thai
note: in East Malaysia there are several indigenous
languages; most widely spoken are Iban and Kadazan
Literacy:
definition: age 1 5 and over can read and write
total population: 88.7%
male: 92%
female: 85.4% (2002)
Population: 108,004 (July 2006 est.)
Age structure:
0-14 years: 36.6% (male 20,1 16/female 19,391)
15-64 years: 60.4% (male 32,620/female 32,659)
65 years and over: 3% (male 1 ,41 3/female 1 ,805)
(2006 est.)
Median age:
total: 20.9 years
male: 20.5 years
female: 21 .4 years (2006 est.)
Population growth rate: -0.1 1 % (2006 est.)
Birth rate: 24.68 births/1,000 population (2006 est.)
Death rate: 4.75 deaths/1 ,000 population (2006 est.)
Net migration rate: -21 .03 migrant(s)/1 ,000
population (2006 est.)
Sex ratio: NA
Infant mortality rate:
total: 29.16 deaths/1 ,000 live births
male: 32.17 deaths/1 ,000 live births
female: 26.01 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 70.05 years
male: 68.24 years
female: 71 .95 years (2006 est.)
Total fertility rate: 3.16 children born/woman
(2006 est.)
HIV/AIDS • adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Micronesian(s)
adjective: Micronesian; Chuukese, Kosraen(s),
Pohnpeian(s), Yapese
Ethnic groups: nine ethnic Micronesian and
Polynesian groups
Religions: Roman Catholic 50%, Protestant 47%
Languages: English (official and common
language), Trukese, Pohnpeian, Yapese, Kosrean,
Ulithian, Woleaian, Nukuoro, Kapingamarangi
Literacy:
definition: age 15 and over can read and write
total population: 89%
male: 91%
female: 88% (1980 est.)
370
Micronesia, Federated States of (continued)
Population: 5,670,544 (July 2006 est.)
Age structure:
0-14 years: 37.8% (male 1 .090,879/female
1,054,743)
15-64 years: 58.3% (male 1 ,703,204/female
1,601,224)
65 years and over: 3.9% (male 103,054/female
117,440) (2006 est.)
Median age:
total: 21.2 years
male: 21 .4 years
female: 21.1 years (2006 est.)
Population growth rate: 2.21% (2006 est.)
Birth rate: 29.36 births/1 ,000 population (2006 est.)
Death rate: 7.25 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 0.88 male(s)/female
total population: 1 .05 male(s)/female (2006 est.)
Infant mortality rate:
total: 49.96 deaths/1 ,000 live births
male: 54.08 deaths/1 ,000 live births
female: 45.63 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 65.28 years
male: 63.08 years
female: 67.58 years (2006 est.)
Total fertility rate: 3.88 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.6% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 16,000
(2003 est.)
HIV/AIDS - deaths: 600 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterbome diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever
vectorborne diseases: dengue fever and malaria are
high risks in some locations (2004)
Nationality:
noun: Papua New Guinean(s)
adjective: Papua New Guinean
Ethnic groups: Melanesian, Papuan, Negrito,
Micronesian, Polynesian
Religions: Roman Catholic 22%, Lutheran 16%,
Presbyterian/Methodist/London Missionary Society
8%, Anglican 5%, Evangelical Alliance 4%,
Seventh-Day Adventist 1%, other Protestant 10%,
indigenous beliefs 34%
Languages: Melanesian Pidgin serves as the lingua
franca, English spoken by 1%-2%, Motu spoken in
Papua region
note: 715 indigenous languages - many unrelated
Literacy:
definition: age 1 5 and over can read and write
total population: 64.6%
male: 71.1%
female: 57.7% (2002)
Population: no indigenous inhabitants
note: there are scattered Chinese garrisons
Population: 89,468,677 (July 2006 est.)
Age structure:
0-14 years: 35° o (male 1 5,961 ,365/female
15,340,065)
15-64 years: 61 °o (male 27,1 73,91 9/female
27.362.736)
65 years and over: 4.1% (male 1 ,576,089/female
2,054,503) (2006 est.)
Median age:
total: 22.5 years
male: 22 years
female: 23 years (2006 est.)
Population growth rate: 1 .8% (2006 est.)
Birth rate: 24.89 births/1,000 population (2006 est.)
Death rate: 5.41 deaths/1 ,000 population (2006 est.)
Net migration rate: -1 .48 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 1 male(s)/female (2006 est.)
Infant mortality rate:
total: 22.81 deaths/1,000 live births
male: 25.59 deaths/1 ,000 live births
female: 19.89 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 70.21 years
male: 67.32 years
female: 73.24 years (2006 est.)
Total fertility rate: 3.1 1 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: less than 0.1%
(2003 est.)
HIV/AIDS - people living with HIV/AIDS: 9,000
(2003 est.)
HIV/AIDS - deaths: less than 500 (2003 est.)
Major infectious diseases:
degree of risk: high
food or waterborne diseases: bacterial diarrhea,
hepatitis A, and typhoid fever
vectorborne diseases: dengue fever and malaria are
high risks in some locations
animal contact disease: rabies (2004)
Nationality:
noun: Filipino(s)
adjective: Philippine
Ethnic groups: Tagalog 28.1%, Cebuano 13.1%,
llocano 9%, Bisaya/Binisaya 7.6%, Hiligaynon llonggo
7.5%, Bikol 6%, Waray 3.4%, other 25.3% (2000
census)
Religions: Roman Catholic 80.9%, Evangelical
2.8%, Iglesia ni Kristo 2.3%, Aglipayan 2%, other
Christian 4.5%, Muslim 5%, other 1 .8%, unspecified
0.6%, none 0.1% (2000 census)
Languages: two official languages - Filipino (based
on Tagalog) and English; eight major dialects -
Tagalog, Cebuano, llocano, Hiligaynon or llonggo,
Bicol, Waray, Pampango, and Pangasinan
Literacy:
definition: age 15 and over can read and write
total population: 92.6%
male: 92.5%
female: 92.7% (2002)
Population: 45 (July 2006 est.)
Age structure:
0- 74 years: N A
15-64 years: NA
65 years and over: NA (2006 est.)
Population growth rate: -0.01% (2006 est.)
Birthrate: NA
Death rate: NA deaths/1 ,000 population
Net migration rate: NA
Sex ratio: NA
Infant mortality rate:
total: NA
male: NA
female: NA
Life expectancy at birth:
total population: HA
male: NA
female: NA
Total fertility rate: NA
HIV/AIDS • adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Pitcairn Islander(s)
adjective: Pitcairn Islander
Ethnic groups: descendants of the Bounty
mutineers and their Tahitian wives
Religions: Seventh-Day Adventist 100%
Languages: English (official), Pitcairnese (mixture of
an 18th century English dialect and a Tahitian dialect)
Literacy: NA
Population: 4,492,150 (July 2006 est.)
Age structure:
0-14 years: 15.6% (male 362,329/female 337.964)
15-64 years: 76.1% (male 1 ,666,709/female
1,750,736)
65 years and over: 8.3% (male 1 65,823/female
208,589) (2006 est.)
Median age:
total: 37.3 years
male: 36.9 years
female: 37.6 years (2006 est.)
Population growth rate: 1 .42% (2006 est.)
Birth rate: 9.34 births/1 ,000 population (2006 est.)
Death rate: 4.28 deaths/1 ,000 population (2006 est.)
Net migration rate: 9.12 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .08 male(s)/female
under 15 years: 1 .07 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 0.96 male(s)/female (2006 est.)
Infant mortality rate:
total: 2.29 deaths/1 ,000 live births
male: 2.5 deaths/1 ,000 live births
female: 2.07 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 81 .71 years
male: 79. 13 years
female: 84.49 years (2006 est.)
Total fertility rate: 1 .06 children born/woman
(2006 est.)
HIV/AIDS ■ adult prevalence rate: 0.2% (2003 est.;
HIV/AIDS - people living with HIV/AIDS: 4,100
(2003 est.)
HIV/AIDS • deaths: less than 200 (2003 est.)
Nationality:
noun: Singaporean(s)
adjective: Singapore
Ethnic groups: Chinese 76.8%, Malay 13.9%,
Indian 7.9%, other 1 .4% (2000 census)
Religions: Buddhist 42.5%, Muslim 14.9%, Taoist
8.5%, Hindu 4%, Catholic 4.8%, other Christian 9.8%,
other 0.7%, none 14.8% (2000 census)
Languages: Mandarin 35%, English 23%, Malay
14.1%, Hokkien 11.4%, Cantonese 5.7%, Teochew
4.9%, Tamil 3.2%, other Chinese dialects 1 .8%,
other 0.9% (2000 census)
Literacy:
definition: age 1 5 and over can read and write
total population: 92.5%
male: 96.6%
female: 88.6% (2002)','126a325af9bd03f6114a2394e5765a51d11f503aec7c33ecba1707b82687ac04','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42dc5a9e86589d08789ff732b2536c2a0e74b92744444c26730293620b507040',2007,'DE','Germany','people-and-society',151,'Population: 8,192,880 (July 2006 est.)
Age structure:
0-14 years: 15.4% (male 645,337/female 614,602)
15-64 years: 67.5% (male 2,782,71 2/female
2,749,620)
65 years and over: 17.1% (male 567,752/female
832,857) (2006 est.)
Median age:
total: 40.9 years
male: 39.8 years
female: 42 years (2006 est.)
Population growth rate: 0.09% (2006 est.)
Birth rate: 8.74 births/1,000 population (2006 est.)
Death rate: 9.76 deaths/1 ,000 population (2006 est.)
Net migration rate: 1 .94 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/femaie
15-64 years: 1 .01 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.95 male(s)/female (2006 est.)
Infant mortality rate:
total: 4.6 deaths/1 ,000 live births
male: 5.65 deaths/1 ,000 live births
female: 3.5 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 79.07 years
male: 76.17 years
female: 82.1 1 years (2006 est.)
Total fertility rate: 1 .36 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.3% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 10,000
(2003 est.)
HIV/AIDS - deaths: less than 100 (2003 est.)
Nationality:
noun: Austrian(s)
adjective: Austrian
Ethnic groups: Austrians 91.1%, former Yugoslavs
4% (includes Croatians, Slovenes, Serbs, and
Bosniaks), Turks 1.6%, German 0.9%, other or
unspecified 2.4% (2001 census)
Religions: Roman Catholic 73.6%, Protestant 4.7%,
Muslim 4.2%, other 3.5%, unspecified 2%, none 12%
(2001 census)
Languages: German (official nationwide), Slovene
(official in Kaernten or Carinthia), Croatian (official in
Burgenland), Hungarian (official in Burgenland)
Literacy:
definition: age 1 5 and over can read and write
total population: 98%
male: NA%
female: NA%
Population: 82,422,299 (July 2006 est.)
Age structure:
0-14 years: 14.1% (male 5,973,437/female
5,665,971)
15-64 years: 66.4% (male 27,889,936/female
26,874,858)
65 years and over: 19.4% (male 6,602,478/female
9,415,619) (2006 est.)
215
Germany (continued)
Median age:
total: 42.6 years
male: 41.3 years
female: 43.9 years (2006 est.)
Population growth rate: -0.02% (2006 est.)
Birth rate: 8.25 births/1 .000 population (2006 est.)
Death rate: 10.62 deaths/1 ,000 population (2006 est.)
Net migration rate: 2.18 migrant(s)/1, 000
population (2006 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.96 male(s)/female (2006 est.)
Infant mortality rate:
total: 4.12 deaths/1 ,000 live births
male: 4.56 deaths/1 ,000 live births
female: 3.66 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 78.8 years
male: 75.81 years
female: 81 .96 years (2006 est.)
Total fertility rate: 1 .39 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.1% (2001 est.)
HIV/AIDS ■ people living with HIV/AIDS: 43,000
(2001 est.)
HIV/AIDS - deaths: less than 1 ,000 (2003 est.)
Nationality:
noun: German(s)
adjective: German
Ethnic groups: German 91 .5%, Turkish 2.4%, other
6.1% (made up largely of Greek, Italian, Polish,
Russian, Serbo-Croatian, Spanish)
Religions: Protestant 34%, Roman Catholic 34%,
Muslim 3.7%, unaffiliated or other 28.3%
Languages: German
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (2003 est.)
Population: 474,413 (July 2006 est.)
Age structure:
0-14years: 18.9% (male 46,118/female 43,356)
15-64 years: 66.5% (male 159,498/female 156,075)
65 years and over: 14.6% (male 28,027/female
41,339) (2006 est.)
Median age:
total: 38.7 years
male: 37.7 years
female: 39.7 years (2006 est.)
Population growth rate: 1 .23% (2006 est.)
Birth rate: 1 1 .94 births/1 ,000 population (2006 est.)
Death rate: 8.41 deaths/1 ,000 population (2006 est.)
Net migration rate: 8.75 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at binh: 1 .07 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.97 male(s)/female (2006 est.)
Infant mortality rate:
total: 4.74 deaths/1 ,000 live births
male: 4.73 deaths/1,000 live births
female: 4.76 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 78.89 years
male: 75.6 years
female: 82.38 years (2006 est.)
Total fertility rate: 1 .78 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.2% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: less than
500 (2003 est.)
HIV/AIDS - deaths: less than 100 (2003 est.)
Nationality:
noun: Luxembourger(s)
adjective: Luxembourg
Ethnic groups: Celtic base (with French and
German blend), Portuguese, Italian, Slavs (from
Montenegro, Albania, and Kosovo) and European
(guest and resident workers)
Religions: 87% Roman Catholic, 13% Protestants,
Jews, and Muslims (2000)
Languages: Luxembourgish (national language),
German (administrative language), French
(administrative language)
Literacy:
definition: age 15 and over can read and write
total population: 100%
male: 100%
female: 100% (2000 est.)
Population: 453,125 (July 2006 est.)
Age structure:
0-14 years: 16.2% (male 37,934/female 35,412)
15-64 years: 75.9% (male 163,975/female 179,830)
65 years and over: 7.9% (male 1 5,099/female
20,875) (2006 est.)
Median age:
total: 36 A years
male: 35.7 years
female: 36.4 years (2006 est.)
Population growth rate: 0.86% (2006 est.)
Birth rate: 8.48 births/1 ,000 population (2006 est.)
Death rate: 4.47 deaths/1 ,000 population (2006 est.)
Net migration rate: 4.56 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .07 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.92 male(s)/female (2006 est.)
Infant mortality rate:
total: 4.35 deaths/1 ,000 live births
male: 4.54 deaths/1 ,000 live births
female: 4.15 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 82.19 years
male: 79.36 years
female: 85.17 years (2006 est.)
Total fertility rate: 1 .02 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Chinese
adjective: Chinese
Ethnic groups: Chinese 95.7%, Macanese (mixed
Portuguese and Asian ancestry) 1 %, other 3.3%
(2001 census)
Religions: Buddhist 50%, Roman Catholic 15%,
none and other 35% (1997 est.)
Languages: Cantonese 87.9%, Hokkien 4.4%,
Mandarin 1.6%, other Chinese dialects 3.1%, other
3% (2001 census)
Literacy:
definition: age 15 and over can read and write
total population: 94.5%
male: 97.2%
female: 92% (2003 est.)
Population: 2,050,554 (July 2006 est.)
Age structure:
0-14 years: 20. 1 % (male 21 3,486/female 1 99, 1 27)
15-64 years: 68.9% (male 71 1 ,853/female 701 ,042)
65 years and over: 1 1 % (male 98,61 8/female
126,428) (2006 est.)
Median age:
fofa/:34.1 years
male: 33.2 years
female: 35.1 years (2006 est.)
Population growth rate: 0.26% (2006 est.)
Birth rate: 12.02 births/1 ,000 population (2006 est.)
Death rate: 8.77 deaths/1 ,000 population (2006 est.)
Net migration rate: -0.65 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .08 male(s)/female
under 15 years: 1 .07 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.78 male(s)/female
total population: 1 male(s)/female (2006 est.)
Infant mortality rate:
total: 9.81 deaths/1,000 live births
male: 9.94 deaths/1 ,000 live births
female: 9.66 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 73.97 years
male: 71.51 years
female: 76.62 years (2006 est.)
Total fertility rate: 1 .57 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: less than 0.1%
(2001 est.)
HIV/AIDS - people living with HIV/AIDS: less than
200 (2003 est.)
HIV/AIDS - deaths: less than 100 (2003 est.)
Nationality:
noun: Macedonian (s)
adjective: Macedonian
Ethnic groups: Macedonian 64.2%, Albanian
25.2%, Turkish 3.9%, Roma 2.7%, Serb 1.8%, other
2.2% (2002 census)
Religions: Macedonian .Orthodox 32.4%, other
Christian 0.2%, Muslim 16.9%, other and unspecified
50.5% (2002 census)
Languages: Macedonian 66.5%, Albanian 25.1%,
Turkish 3.5%, Roma 1.9%, Serbian 1.2%, other 1.8%
(2002 census)
Literacy:
definition: age 1 5 and over can read and write
total population: 96.1%
male: 98.2%
female: 94.1% (2002 est.)','e70a1711267f36548c854268b2ba5dccf95dd3a55217eb024ece420bcc7e5ab5','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5781ec585df318bce9e528b66598e4536009205c59e85e0c5f95554ca113b8db',2007,'AZ','Azerbaijan','people-and-society',160,'Population: 7,961 ,619 (July 2006 est.)
Age structure:
0-14 years: 25.8% (male 1 ,046,501 /female
1,011,492)
15-64 years: 66.3% (male 2,573,1 34/female
2,706,275)
65 years and over: 7.8% (male 246,556/female
377,661) (2006 est.)
Median age:
total: 27.7 years
male: 26.3 years
female: 29.2 years (2006 est.)
Population growth rate: 0.66% (2006 est.)
Birth rate: 20.74 births/1 ,000 population (2006 est.)
Death rate: 9.75 deaths/1 ,000 population (2006 est.)
Net migration rate: -4.38 migrant(s)/1 .000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.65 male(s)/female
total population: 0.94 male(s)/female (2006 est.)
Infant mortality rate:
total: 79 deaths/1 ,000 live births
male: 81 .08 deaths/1 ,000 live births
female: 76.81 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 63.85 years
male: 59.78 years
female: 68.1 3 years (2006 est.)
Total fertility rate: 2.46 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: less than 0.''1%
(2003 est.)
HIV/AIDS - people living with HIV/AIDS: 1,400 .
(2003 est.)
HIV/AIDS - deaths: less than 100 (2001 est.)
Nationality:
noun: Azerbaijani(s), Azeri(s)
adjective: Azerbaijani, Azeri
Ethnic groups: Azeri 90.6%, Dagestani 2.2%,
Russian 1.8%, Armenian 1.5%, other 3.9% (1999
census)
note: almost all Armenians live in the separatist
Nagorno-Karabakh region
Religions: Muslim 93.4%, Russian Orthodox 2.5%,
Armenian Orthodox 2.3%, other 1.8% (1995 est.)
note: religious affiliation is still nominal in Azerbaijan;
percentages for actual practicing adherents are much
lower
Languages: Azerbaijani (Azeri) 89%, Russian 3%,
Armenian 2%, other 6% (1995 est.)
Literacy:
definition: age 15 and over can read and write
total population: 98.8%
male: 99.5%
female: 98.2% (2003 est.)','15e28014b0ac3b01a95e580954d757cd146351e8cfd902b85bb8dd4cf61ab376','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7316639ecb67f03f3c02d264697972a18eca088ce83109cc7269cbfead9c7d75',2007,'CU','Cuba','people-and-society',168,'Population: 303,770
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected
(July 2006 est.)
Age structure:
0-14 years: 27.5% (male 41 ,799/female 41 ,733)
15-64 years: 66.1% (male 98,847/female 102,074)
65 years and over: 6.4% (male 7,891/female 1 1 ,426)
(2006 est.)
Median age:
total: 27.8 years
male: 21 A years
female: 28.6 years (2006 est.)
Population growth rate: 0.64% (2006 est.)
Birth rate: 1 7.57 births/1 ,000 population (2006 est.)
Death rate: 9.05 deaths/1 ,000 population (2006 est.)
Net migration rate: -2.17 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .02 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.96 male(s)/female (2006 est.)
Infant mortality rate:
total: 24.68 deaths/1 ,000 live births
male: 30.29 deaths/1 ,000 live births
female: 18.96 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 65.6 years
male: 62.24 years
female: 69.03 years (2006 est.)
Total fertility rate: 2.18 children born/woman
(2006 est.)
HIV/AIDS ■ adult prevalence rate: 3% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 5,600
(2003 est.)
HIV/AIDS - deaths: less than 200 (2003 est.)
Nationality:
noun: Bahamian(s)
adjective: Bahamian
Ethnic groups: black 85%, white 12%, Asian and
Hispanic 3%
Religions: Baptist 35.4%, Anglican 15.1%, Roman
Catholic 13.5%, Pentecostal 8.1%, Church of God
4.8%, Methodist 4.2%, other Christian 1 5.2%, none or
unspecified 2.9%, other 0.8% (2000 census)
Languages: English (official), Creole (among Haitian
immigrants)
Literacy:
definition: age 15 and over can read and write
total population: 95.6%
male: 94.7%
female: 96.5% (2003 est.)
Population: 1 07,449,525 (July 2006 est.)
Age structure:
0-14 years: 30.6% (male 16,770,957/female
16,086,172)
15-64 years: 63.6% (male 33,071 ,809/female
35,316,281)
65 years and over: 5.8% (male 2,814,707/female
3,389,599) (2006 est.)
Median age:
total: 25.3 years
male: 24.3 years
female: 26.2 years (2006 est.)
Population growth rate: 1 .16% (2006 est.)
Birth rate: 20.69 births/1 ,000 population (2006 est.)
Death rate: 4.74 deaths/1 ,000 population (2006 est.)
Net migration rate: -4.32 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 0.96 male(s)/female (2006 est.)
Infant mortality rate:
total: 20.26 deaths/1 ,000 live births
male: 22.19 deaths/1 ,000 live births
female: 18.24 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 75.41 years
male: 72.63 years
female: 78.33 years (2006 est.)
Total fertility rate: 2.42 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.3% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 160,000
(2003 est.)
HIV/AIDS - deaths: 5,000 (2003 est.)
Nationality:
noun: Mexican(s)
adjective: Mexican
Ethnic groups: mestizo (Amerindian-Spanish) 60%,
Amerindian or predominantly Amerindian 30%, white
9%, other 1%
Religions: nominally Roman Catholic 89%,
Protestant 6%, other 5%
Languages: Spanish, various Mayan, Nahuatl, and
other regional indigenous languages
Literacy:
definition: age 1 5 and over can read and write
total population: 92.2%
male: 94%
female: 90.5% (2003 est.)
367
Mexico (continued)','2c01ba5771afdc47bfb5bca6e81a608924d377a9c743128f181a132fdf13db1d','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8abfe4d00df29047937226448f55b8a964cf749634fb48a4e9dc8f840b0a3596',2007,'BH','Bahrain','people-and-society',178,'Population: 698,585
nofe: includes 235,108 non-nationals (July 2006 est.;
Age structure:
0-14 years: 27.4% (male 96,567/female 94,650)
15-64 years: 69.1% (male 280,272/female 202,451 )
65 years and over: 3.5% (male 12,753/female
11,892) (2006 est.)
Median age:
total: 29 .4 years
male: 32.4 years
female: 25.8 years (2006 est.)
Population growth rate: 1 .45% (2006 est.)
Birth rate: 1 7.8 births/1 ,000 population (2006 est.)
Death rate: 4.14 deaths/1 ,000 population (2006 est.
Net migration rate: 0.82 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years:). 02 male(s)/female
15-64 years: 1 .38 male(s)/female
65 years and over: 1 .07 male(s)/female
total population: 1.26 male(s)/female (2006 est.)
Infant mortality rate:
total: 16.8 deaths/1 ,000 live births
male: 19.65 deaths/1 ,000 live births
female: 13.87 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 74.45 years
male: 71 .97 years
female: 77 years (2006 est.)
Total fertility rate: 2.6 children born/woman
(2006 est.)
HIV/AIDS • adult prevalence rate: 0.2% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: less than
600 (2003 est.)
HIV/AIDS - deaths: less than 200 (2003 est.)
Nationality:
noun: Bahraini(s)
adjective: Bahraini
Ethnic groups: Bahraini 62.4%, non-Bahraini 37.6%
(2001 census)
Religions: Muslim (Shi''a and Sunni) 81 .2%,
Christian 9%, other 9.8% (2001 census)
Languages: Arabic, English, Farsi, Urdu
Literacy:
definition: age 1 5 and over can read and write
total population: 89.1%
male: 91 .9%
female: 85% (2003 est.)
Population: 885,359 (July 2006 est.)
Age structure:
0-14 years: 23.4% (male 105,546/female 101,371)
15-64 years: 73% (male 446.779/female 199,133)
65 years and over: 3.7% (male 24,059/female 8,471 )
(2006 est.)
Median age:
total: 31.7 years
male: 37.1 years
female: 22.7 years (2006 est.)
Population growth rate: 2.5% (2006 est.)
Birth rate: 1 5.56 births/1 ,000 population (2006 est.)
Death rate: 4.72 deaths/1 ,000 population (2006 est:
Net migration rate: 14.12 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 2.24 male(s)/female
65 years and over: 2.84 male(s)/female
total population: 1 .87 male(s)/female (2006 est.)
454
Qatar (continued)
infant mortality rate:
total: 18.04 deaths/1 ,000 live births
male: 21 .27 deaths/1 ,000 live births
temale: 14.63 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 73.9 years
male: 71.37 years
temale: 76.57 years (2006 est.)
Total fertility rate: 2.81 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.09% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Qatari(s)
adjective: Qatari
Ethnic groups: Arab 40%, Indian 18%, Pakistani
18%, Iranian 10%, other 14%
Religions: Muslim 95%
Languages: Arabic (official), English commonly
used as a second language
Literacy:
definition: age 15 and over can read and write
total population: 89%
male: 89.1%
female: 88.6% (2004 est.)
Population: 787,584 (July 2006 est.)
Age structure:
0-14 years: 29.8% (male 1 20, 147/female 114,589)
15-64 years: 64% (male 248,895/female 255,156)
65 years and over: 6.2% (male 1 9,847/female
28,950) (2006 est.)
Median age:
total: 26.9 years
male: 25.7 years
female: 28.1 years (2006 est.)
Population growth rate: 1 .34% (2006 est.)
Birth rate: 18.9 births/1 ,000 population (2006 est.)
Death rate: 5.49 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.98 male(s)/female (2006 est.)
Infant mortality rate:
total: 7.63 deaths/1 ,000 live births
male: 8.37 deaths/1 ,000 live births
female: 6.85 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 74.18 years
male: 70.78 years
female: 77.75 years (2006 est.)
Total fertility rate: 2.45 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Reunionese (singular and plural)
adjective: Reunionese
Ethnic groups: French, African, Malagasy, Chinese,
Pakistani, Indian
Religions: Roman Catholic 86%, Hindu, Muslim,
Buddhist (1995)
Languages: French (official), Creole widely used
Literacy:
definition: age 15 and over can read and write
total population: 88.9%
male: 87%
female: 90.8% (2003 est.)','38523e7b8d243443e160df3f70b838b80265cbfe78aa279c01d2935b775969a7','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6e0edd76ebeb50f51ba1ed40996eefed779c9cabda9f350166bc13f4eafea95',2007,'US','United States','people-and-society',188,'Population: 147,365,352 (July 2006 est.)
Age structure:
0-14 years: 32.9% (male 24,957,997/female
23,533,894)
15-64 years: 63.6% (male 47,862,774/female
45,917,674)
65 years and over: 3.5% (male 2,731 ,578/female
2,361 ,435) (2006 est.)
Median age.
total: 22.2 years
male: 22.2 years
female: 22.2 years (2006 est.)
Population growth rate: 2.09% (2006 est.)
Birth rate: 29.8 births/1,000 population (2006 est.)
Death rate: 8.27 deaths/1 ,000 population (2006 est.)
Net migration rate: -0.68 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1.06 male(s)/temale
15-64 years: 1 .04 male(s)/female
65 years and over: 1.16 male(s)/female
total population: 1 .05 male(s)/female (2006 est.)
Infant mortality rate:
total: 60.83 deaths/1 ,000 live births
male: 61 .87 deaths/1 ,000 live births
female: 59.74 deaths/1,000 live births (2006 est.)
49
Bangladesh (continued)
Life expectancy at birth:
total population: 62.46 years
male: 62.47 years
female: 62.45 years (2006 est.)
Total fertility rate: 3.11 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: less than 0.1%
(2001 est.)
HIV/AIDS - people living with HIV/AIDS: 13,000
(2001 est.)
HIV/AIDS - deaths: 650 (2001 est.)
Major infectious diseases:
degree of risk: high
food or waterborne diseases: bacterial diarrhea,
hepatitis A and E, and typhoid fever
vectorborne diseases: dengue fever and malaria are
high risks in some locations
water contact disease: leptospirosis
animal contact disease: rabies (2004)
Nationality:
noun: Bangladeshi(s)
adjective: Bangladeshi
Ethnic groups: Bengali 98%, tribal groups,
non-Bengali Muslims (1998)
Religions: Muslim 83%, Hindu 16%, other 1%
(1998)
Languages: Bangla (official, also known as Bengali),
English
Literacy:
definition: age 15 and over can read and write
fofa/popu/af/on: 43.1%
male: 53.9%
female: 31.8% (2003 est.)
Population: 91 ,084 (July 2006 est.)
Age structure:
0-14 years: 17.2% (male 8,139/female 7,552)
15-64 years: 67.1% (male 30,407/female 30,691)
65 years and over: 15.7% (male 6,299/female 7,996)
(2006 est.)
Median age:
total: 41.4 years
male: 40.7 years
female: 42.1 years (2006 est.)
Population growth rate: 0.28% (2006 est.)
Birth rate: 9.3 births/1 ,000 population (2006 est.)
Death rate: 9.28 deaths/1 ,000 population (2006 est.)
Net migration rate: 2.74 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .08 male(s)/female
under 15 years: 1 .08 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 0.97 male(s)/female (2006 est.)
Infant mortality rate:
total: 5.16 deaths/1 ,000 live births
male: 5.52 deaths/1 ,000 live births
female: 4.78 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 79.38 years
male: 76.89 years
female: 82.05 years (2006 est.)
Total fertility rate: 1 .58 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Channel Islander(s)
adjective: Channel Islander
Ethnic groups: Jersey 51.1%, British 34.8%, Irish,
French, and other white 6.6%, Portuguese/Madeiran
6.4%, other 1.1% (2001 census)
Religions: Anglican, Roman Catholic, Baptist,
Congregational New Church, Methodist, Presbyterian
Languages: English 94.5% (official), Portuguese
4.6%, other 0.9% (2001 census)
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%
G
o v e r n m e n t
Country name:
conventional long form: Bailiwick of Jersey
conventional shod form: Jersey
Dependency status: British crown dependency
Government type: NA
Capital: Saint Helier
Administrative divisions: none (British crown
dependency)
291
Jersey (continued)
Independence: none (British crown dependency)
National holiday: Liberation Day, 9 May (1945)
Constitution: unwritten; partly statutes, partly
common law and practice
Legal system: English law and local statute; justice
is administered by the Royal Court
Suffrage: NA years of age; universal adult
Executive branch:
chief of state: Queen ELIZABETH II (since 6 February
1952)
head of government: Lieutenant Governor and
Commander in Chief Air Chief Marshal Sir John
CHESHIRE (since 24 January 2001 ); Bailiff Philip
Martin BAILHACHE (since February 1995)
cabinet: committees appointed by the Assembly of the
States
elections: none; the monarch is hereditary; lieutenant
governor and bailiff appointed by the monarch
Legislative branch: unicameral Assembly of the
States (55 voting members - 12 senators (elected for
six-year terms), 12 constables or heads of parishes
(elected for three-year terms), 29 deputies (elected for
three-year terms); the bailiff and the deputy bailiff; and
three non-voting members - the Dean of Jersey, the
Attorney General, and the Solicitor General all
appointed by the monarch)
elections: last held NA (next to be held NA); note - on
23 November 2005, 29 deputies, independents, were
elected
election results: percent of vote - NA; seats -
independents 55
Judicial branch: Royal Court (judges elected by an
electoral college and the bailiff)
Political parties and leaders: none; all
independents
Political pressure groups and leaders: none
Diplomatic representation in the US: none (British
crown dependency)
Diplomatic representation from the US: none
(British crown dependency)
Flag description: white with a diagonal red cross
extending to the corners of the flag; in the upper
quadrant, surmounted by a yellow crown, a red shield
with the three lions of England in yellow
Population: 5,906,760 (July 2006 est.)
Age structure:
0-14 years: 33.8% (male 1 ,018,070/female 976,442)
15-64 years: 62.4% (male 1 ,966,794/female
1,716,255)
65 years and over: 3.9% (male 1 1 1 ,636/female
117,563) (2006 est.)
Median age:
total: 23 years
male: 23.7 years
female: 22.4 years (2006 est.)
Population growth rate: 2.49% (2006 est.)
Birth rate: 21.25 births/1,000 population (2006 est.)
Death rate: 2.65 deaths/1 ,000 population (2006 est.)
Net migration rate: 6.26 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1.15 male(s)/female
65 years and over: 0.95 male(s)/female
total population: 1 .1 male(s)/female (2006 est.)
Infant mortality rate:
total: 16.76 deaths/1 ,000 live births
male: 20.04 deaths/1 ,000 live births
female: 13.28 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 78.4 years
male: 75.9 years
female: 81 .05 years (2006 est.)
Total fertility rate: 2.63 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: less than 0.1%
(2001 est.)
HIV/AIDS - people living with HIV/AIDS: 600
(2003 est.)
HIV/AIDS - deaths: less than 500 (2003 est.)
Nationality:
noun: Jordanian(s)
adjective: Jordanian
Ethnic groups: Arab 98%, Circassian 1 %, Armenian
1%
Religions: Sunni Muslim 92%, Christian 6%
(majority Greek Orthodox, but some Greek and
Roman Catholics, Syrian Orthodox, Coptic Orthodox,
Armenian Orthodox, and Protestant denominations),
other 2% (several small Shi''a Muslim and Druze
populations) (2001 est.)
Languages: Arabic (official), English widely
understood among upper and middle classes
Literacy:
definition: age 1 5 and over can read and write
total population: 91.3%
male: 95.9%
female: 86.3% (2003 est.)
Population: 298,444,21 5 (July 2006 est.)
Age structure:
0-14 years: 20.4% (male 31 ,095,847/female
29,715,872)
15-64 years: 67.2% (male 100,022,845/female
100,413,484)
65 years and over: 12.5% (male 15,542,288/female
21,653,879) (2006 est.)
Median age:
total: 36.5 years
male: 35.1 years
female: 37.8 years (2006 est.)
Population growth rate: 0.91% (2006 est.)
Birth rate: 14.14 births/1,000 population (2006 est.)
Death rate: 8.26 deaths/1 ,000 population (2006 est.)
Net migration rate: 3.18 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.97 male(s)/female (2006 est.)
Infant mortality rate:
total: 6.43 deaths/1 ,000 live births
male: 7.09 deaths/1 ,000 live births
female: 5.74 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 77.85 years
male: 75.02 years
female: 80.82 years (2006 est.)
Total fertility rate: 2.09 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.6% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 950,000
(2003 est.)
HIV/AIDS • deaths: 14,000 (2003 est.)
Nationality:
noun: American(s)
adjective: American
583
United States (continued)
Ethnic groups: white 81.7V black 12.9V Asian
4 2%, Amerindian and Alaska native 1 V native
Hawaiian and other Pacific islander 0.2°o (2003 est.)
note: a separate listing for Hispanic is not included
because the US Census Bureau considers Hispanic to
mean a person of Latin American descent (including
persons of Cuban, Mexican, or Puerto Rican origin)
living in the US who may be of any race or ethnic
group (white, black, Asian, etc.)
Religions: Protestant 52V Roman Catholic 24%,
Mormon 2 V Jewish 1%, Muslim 1%, other 10%, none
10% (2002 est.)
Languages: English 82.1%. Spanish 10.7%, other
Indo-European 3.8%, Asian and Pacific island 2.7%,
other 0.7% (2000 census)
Literacy:
definition: age 1 5 and over can read and write
total population: 99%
male: 99%
female: 99% (2003 est.)','bd6ae8ac42c60f0913ff78a06b81a728e2aad7a0ba0eb632ddcbbcb52390328f','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c117b90b37034eb9825f727d9d54bdbd57ea5a943ee7c6860000dce3844176df',2007,'BD','Bangladesh','people-and-society',197,'Population: 279,912 (July 2006 est.)
Age structure:
0-14 years: 20.1% (male 28,160/female 28,039)
15-64 years: 71 .1% (male 97,755/female 101 ,223)
65 years and over: 8.8% (male 9,508/female 15,227)
(2006 est.)
Median age:
total: 34.6 years
male: 33.4 years
female: 35.6 years (2006 est.)
Population growth rate: 0.37% (2006 est.)
Birth rate: 12.71 births/1,000 population (2006 est.)
Death rate: 8.67 deaths/1 .000 population (2006 est.)
Net migration rate: -0.31 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 M male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.62 male(s)/female
total population: 0.94 male(s)/female (2006 est.)
Infant mortality rate:
total: 1 1 .77 deaths/1 .000 live births
male: 13.38 deaths/1 ,000 live births
female: 10.15 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 72.79 years
male: 70.79 years
female: 74.82 years (2006 est.)
Total fertility rate: 1 .65 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 1 .5% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 2,500
(2003 est.)
HIV/AIDS - deaths: less than 200 (2003 est.)
Nationality:
noun: Barbadian(s) or Bajan (colloquial)
adjective: Barbadian or Bajan (colloquial)
Ethnic groups: black 90%. white 4%, Asian and
mixed 6%
Religions: Protestant 67% (Anglican 40%,
Pentecostal 8%, Methodist 7%, other 12%), Roman
Catholic 4%, none 17%, other 12%
Languages: English
Literacy:
definition: age 1 5 and over has ever attended school
total population: 99.7%
male: 99.7%
female: 99.7% (2002 est.)
Population: uninhabited (July 2006 est.)','30f70815df2239c9c4397e0498169889ce19c3fd0936d9f641bb59915f6cbb91','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83f51e9de8252da5a25775a22f754bed7b83a0ce966238db9a7dc88809203294',2007,'BY','Belarus','people-and-society',201,'Population: 10,293,01 1 (July 2006 est.)
Age structure:
0-14 years: 15.7% (male 825,823/female 791,741)
15-64 years: 69.7% (male 3,490,442/female
3,682,950)
65 years and over: 1 4.6% (male 498,976/female
1,003,079) (2006 est.)
Median age:
total: 37.2 years
male: 34.5 years
female: 39.9 years (2006 est.)
Population growth rate: -0.06% (2006 est.)
Birth rate: 11.16 births/1,000 population (2006 est.)
Death rate: 1 4.02 deaths/1 ,000 population
(2006 est.)
Net migration rate: 2.3 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.5 male(s)/female
total population: 0.88 male(s)/female (2006 est.)
Infant mortality rate:
total: 13 deaths/1 ,000 live births
male: 13.92 deaths/1,000 live births
female: 12.03 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 69.08 years
male: 63.47 years
female: 74.98 years (2006 est.)
Total fertility rate: 1 .43 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.3% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 1 5,000
(2001 est.)
HIV/AIDS - deaths: 1 ,000 (2001 est.)
Nationality:
noun: Belarusian(s)
adjective: Belarusian
Ethnic groups: Belarusian 81 .2%, Russian 1 1 .4%,
Polish 3.9%, Ukrainian 2.4%, other 1.1% (1999
census)
Religions: Eastern Orthodox 80%, other (including
Roman Catholic, Protestant, Jewish, and Muslim)
20% (1997 est.)
Languages: Belarusian, Russian, other
Literacy:
definition: age 15 and over can read and write
total population: 99.6%
male: 99.8%
female: 99.5% (2003 est.)
Population: 2,274,735 (July 2006 est.)
Age structure:
0-14 years: 14% (male 162,562/female 155,091)
15-64 years: 69.6% (male 769,004/female 815,042)
65 years and over: 16.4% (male 121,646/female
251 ,390) (2006 est.)
Median age:
total: 39.4 years
male: 36.3 years
female: 42.4 years (2006 est.)
Population growth rate: -0.67% (2006 est.)
Birth rate: 9.24 births/1 ,000 population (2006 est.)
Death rate: 1 3.66 deaths/1 ,000 population (2006 est.)
Net migration rate: -2.26 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.48 male(s)/female
total population: 0.86 male(s)/female (2006 est.)
Infant mortality rate:
total: 9.35 deaths/1 ,000 live births
male: 1 1 .31 deaths/1 ,000 live births
female: 7.29 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 71 .33 years
male: 66.08 years
female: 76.85 years (2006 est.)
Total fertility rate: 1 .27 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.6% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 7,600
(2001 est.)
HIV/AIDS - deaths: less than 500 (2003 est.)
Nationality:
noun: Latvian(s)
adjective: Latvian
Ethnic groups: Latvian 57.7%, Russian 29.6%,
Belarusian 4.1%, Ukrainian 2.7%, Polish 2.5%,
Lithuanian 1 .4%, other 2% (2002)
Religions: Lutheran, Roman Catholic, Russian
Orthodox
Languages: Latvian (official) 58.2%, Russian
37.5%, Lithuanian and other 4.3% (2000 census)
Literacy:
definition: age 1 5 and over can read and write
total population: 99.8%
male: 99.8%
female: 99.8% (2003 est.)','b513215dbf015c60cda0bfe65b41479c533831036b5a3380f18939edc0fe55c7','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca084c808b5ec1c106894ef00979ad33407c6b8b9f07a2cca49d99b7fb97a5a2',2007,'BE','Belgium','people-and-society',209,'Population: 10,379,067 (July 2006 est.)
Age structure:
0-14 years: 16.7% (male 883,254/female 846,099)
15-64 years: 65.9% (male 3,450,879/female
3,389,565)
65 years and over: 17.4% (male 746,569/female
1,062,701) (2006 est.)
Median age:
total: 40.9 years
male: 39.6 years
female: 42.1 years (2006 est.)
Population growth rate: 0.13% (2006 est.)
Birth rate: 10.38 births/1,000 population (2006 est.)
Death rate: 10.27 deaths/1 ,000 population
(2006 est.)
Net migration rate: 1 .22 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.96 male(s)/female (2006 est.)
Infant mortality rate:
total: 4.62 deaths/1 ,000 live births
male: 5.2 deaths/1 ,000 live births
female: 4.01 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 78.77 years
male: 75.59 years
female: 82.09 years (2006 est.)
Total fertility rate: 1 .64 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.2% (2003 est)
HIV/AIDS - people living with HIV/AIDS: 10,000
(2003 est.)
HIV/AIDS - deaths: less than 100 (2003 est.)
Nationality:
noun: Belgian(s)
adjective: Belgian
Ethnic groups: Fleming 58%, Walloon 31%, mixed
or other 11%
Religions: Roman Catholic 75%, Protestant or other
25%
Languages: Dutch (official) 60%, French (official)
40%, German (official) less than 1%, legally bilingual
(Dutch and French)
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (2003 est.)','c3987eaab1da6a518e0f187e281d0b9564569f2757ad5e0364c5c57d04bf1ed8','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a458aa0d63857442c3d910b1c4289fbaf7c7a1684e1e0b43e965731531b491d8',2007,'GT','Guatemala','people-and-society',219,'Population: 287,730 (July 2006 est.)
Age structure:
0-14 years: 39.5% (male 57,923/female 55,678)
15-64 years: 57% (male 82,960/female 81 ,046)
65 years and over: 3.5% (male 4,888/female 5,235)
(2006 est.)
Median age:
total: 19.6 years
male: 19.5 years
female: 19.8 years (2006 est.)
Population growth rate: 2 31% (2006 est.)
Birth rate: 28.84 births/1 ,000 population (2006 est.;
Death rate: 5.72 deaths/1 ,000 population (2006 est.
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.93 male(s)/female
total population^. 03 male(s)/female (2006 est.)
Infant mortality rate:
total: 24.89 deaths/1 ,000 live births
male: 28.07 deaths/1 ,000 live births
female: 21 .55 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 68.3 years
male: 66.43 years
female: 70.26 years (2006 est.)
Total fertility rate: 3.6 children bom/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 2.4% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 3,600
(2003 est.)
60
Belize (continued)
HIV/AIDS - deaths: less than 200 (2003 est.)
Nationality:
noun: Belizean(s)
adjective: Belizean
Ethnic groups: mestizo 48.7%, Creole 24.9%, Maya
10.6%, Garifuna 6.1%, other 9.7%
Religions: Roman Catholic 49.6%, Protestant 27%
(Pentecostal 7.4%, Anglican 5.3%, Seventh-Day
Adventist 5.2%, Mennonite 4.1%, Methodist 3.5%,
Jehovah''s Witnesses 1.5%), other 14%, none 9.4%
(2000)
Languages: English (official), Spanish, Mayan,
Garifuna (Carib), Creole
Literacy:
definition: age 1 5 and over can read and write
total population: 94.1%
male: 94.1%
female: 94.1% (2003 est.)
G o v e r n m e
Country name:
conventional long form: none
conventional short form: Belize
former: British Honduras
Government type: parliamentary democracy
Capital: Belmopan
Administrative divisions: 6 districts; Belize, Cayo,
Corozal, Orange Walk, Stann Creek, Toledo
Independence: 21 September 1981 (from UK)
National holiday: Independence Day,
21 September (1981)
Constitution: 21 September 1981
Legal system: English law
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II (since 6 February
1952), represented by Governor General Sir Colville
YOUNG, Sr. (since 17 November 1993)
head of government: Prime Minister Said Wilbert
MUSA (since 28 August 1 998); Deputy Prime Minister
John BRICENO (since 1 September 1998)
cabinet: Cabinet appointed by the governor general
on the advice of the prime minister
elections: none; the monarch is hereditary; governor
general appointed by the monarch; following
legislative elections, the leader of the majority party or
the leader of the majority coalition is usually appointed
prime minister by the governor general; prime minister
recommends the deputy prime minister
Legislative branch: bicameral National Assembly
consists of the Senate (12 members appointed by the
governor general - 6 on the advice of the prime minister,
3 on the advice of the leader of the opposition, and 1
each on the advice of the Belize Council of Churches
and Evangelical Association of Churches, the Belize
Chamber of Commerce and Industry and the Belize
Better Business Bureau, and the National Trade Union
Congress and the Civil Society Steering Committee;
members are appointed for five-year terms) and the
House of Representatives (29 seats; members are
elected by direct popular vote to serve five-year terms)
elections: House of Representatives - last held
5 March 2003 (next to be held March 2008)
election results: percent of vote by party - NA%; seats
by party -PUP 21, UDP 8
Judicial branch: Supreme Court (the chief justice is
appointed by the governor general on the advice of
the prime minister)
Political parties and leaders: People''s United
Party or PUP [Said MUSA]; United Democratic Party
or UDP [Dean BARROW, party leader; Douglas
SINGH, party chairman]
Political pressure groups and leaders: Society for
the Promotion of Education and Research or SPEAR
[Adele CATZIM]
International organization participation: ACP, C,
Caricom, CDB, FAO, G-77, IADB, IBRD, ICAO, ICCt,
ICFTU, ICRM, IDA, IFAD, IFC, IFRCS, ILO, IMF, IMO,
Interpol, IOC, IOM, ITU, LAES, MIGA, NAM, OAS,
OPANAL, OPCW, PCA, UN, UNCTAD, UNESCO,
UNIDO, UPU, WCL, WHO, WIPO, WMO, WTO
Diplomatic representation in the US:
chief of mission: Ambassador Lisa M. SHOMAN
chancery: 2535 Massachusetts Avenue NW,
Washington, DC 20008
telephone: [1] (202) 332-9636
FAX: [1] (202) 332-6888
consulate(s) general: Los Angeles
Diplomatic representation from the US:
chief of mission: Ambassador Robert J. DIETER
embassy: 29 Gabourel Lane, Belize City
mailing address: P. O. Box 286, Belize City
telephone: [501] 227-7161 through 7163
FAX: [501] 2-30802
Flag description: blue with a narrow red stripe along
the top and the bottom edges; centered is a large
white disk bearing the coat of arms; the coat of arms
features a shield flanked by two workers in front of a
mahogany tree with the related motto SUB UMBRA
FLOREO (I Flourish in the Shade) on a scroll at the
bottom, all encircled by a green garland
Population: 7,862,944
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected
(July 2006 est.)
Age structure:
0-14 years: 44.1% (male 1,751 ,709/female
1,719,138)
15-64 years: 53.5% (male 2,067,248/female
2,138,957)
65 years and over: 2.4% (male 75,694/female
110,198) (2006 est.)
Median age:
total: 17.6 years
male: 1 7.2 years
female: 18 years (2006 est.)
Population growth rate: 2.73% (2006 est.)
Birth rate: 38.85 births/1 ,000 population (2006 est.)
Death rate: 12.22 deaths/1 ,000 population
(2006 est.)
Net migration rate: 0.67 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.98 male(s)/female (2006 est.)
Infant mortality rate:
total: 79.56 deaths/1 ,000 live births
male: 84.09 deaths/1 ,000 live births
female: 74.88 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 53.04 years
male: 51 .9 years
female: 54.22 years (2006 est.)
Total fertility rate: 5.2 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 1 .9% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 68,000
(2003 est.)
HIV/AIDS • deaths: 5,800 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterbome diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever
vectorborne diseases: malaria, yellow fever, and
others are high risks in some locations
respiratory disease: meningococcal meningitis (2004)
Nationality:
noun: Beninese (singular and plural)
adjective: Beninese
Ethnic groups: African 99% (42 ethnic groups, most
important being Fon, Adja, Yoruba, Bariba),
Europeans 5,500
Religions: indigenous beliefs 50%, Christian 30%,
Muslim 20%
Languages: French (official), Fon and Yoruba (most
common vernaculars in south), tribal languages (at
least six major ones in north)
Literacy:
definition: age 15 and over can read and write
total population: 33.6%
male: 46.4%
female: 22.6% (2002 est.)
Population: 12,293,545 (July 2006 est.)
Age structure:
0-14 years: 41 .1% (male 2,573,359/female
2,479,098)
15-64 years: 55.5% (male 3,353,630/female
3.468,184)
65 years and over: 3.4% (male 1 94,784/female
224,490) (2006 est.)
Median age:
total: 18.9 years
male: 18.5 years
female: 19.4 years (2006 est.)
Population growth rate: 2.27% (2006 est.)
Birth rate: 29.88 births/1 ,000 population (2006 est.)
Death rate: 5.2 deaths/1 ,000 population (2006 est.)
Net migration rate: -1.94 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1. 04 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.87 male(s)/female
total population: 0.99 male(s)/female (2006 est.)
Infant mortality rate:
total: 30.94 deaths/1 ,000 live births
male: 33.55 deaths/1 ,000 live births
female: 23.2 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 69.38 years
male: 67.65 years
female: 71.18 years (2006 est.)
Total fertility rate: 3.82 children born/woman
(2006 est.)
234
Guatemala (continued)
HIV/AIDS - adult prevalence rate: 1.1% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 78,000
(2003 est.)
HIV/AIDS - deaths: 5,800 (2003 est.)
Nationality:
noun: Guatemalan(s)
adjective: Guatemalan
Ethnic groups: Mestizo (mixed Amerindian-Spanish -
in local Spanish called Ladino) and European 59.4%,
K''iche 9.1%, Kaqchikel 8.4%, Mam 7.9%, Q''eqchi 6.3%,
other Mayan 8.6%, indigenous non-Mayan 0.2%, other
0.1% (2001 census)
Religions: Roman Catholic, Protestant, indigenous
Mayan beliefs
Languages: Spanish 60%, Amerindian languages
40% (23 officially recognized Amerindian languages,
including Quiche, Cakchiquel, Kekchi, Mam, Garifuna,
and Xinca)
Literacy:
definition: age 15 and over can read and write
total population: 70.6%
male: 78%
female: 63.3% (2003 est.)','bd0e5df4d67a04a7440a63cb8d52f0f9299006b8d477f4a7dba49be3010c1dd0','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ddeedada51900fc97c339f5081fca0aad75197426b0f92c60ad82cf4c6a0f606',2007,'BM','Bermuda','people-and-society',228,'Population: 65,773 (July 2006 est.)
Age structure:
0-14 years: 18.6% (male 6,146/female 6,098)
15-64 years: 69.2% (male 22,562/female 22,954)
65 years and over: 12.2% (male 3,479/female 4,534)
(2006 est.)
Median age:
total: 40.2 years
male: 39.3 years
female: 41 years (2006 est.)
Population growth rate: 0.61% (2006 est.)
Birth rate: 1 1 .4 births/1 ,000 population (2006 est.)
Death rate: 7.74 deaths/1 ,000 population (2006 est.)
Net migration rate: 2.4 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .02 male(s)/female
under 1 5 years: 1.01 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 0.96 male(s)/female (2006 est.)
Infant mortality rate:
total: 8.3 deaths/1 ,000 live births
male: 9.85 deaths/1 ,000 live births
female: 6.73 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 77.96 years
male: 75.85 years
female: 80.1 years (2006 est.)
Total fertility rate: 1 .89 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0 297% (2005)
HIV/AIDS ■ people living with HIV/AIDS: 163
(2005)
HIV/AIDS - deaths: 392 (2005)
Nationality:
noun: Bermudian(s)
adjective: Bermudian
Ethnic groups: black 54.8%, white 34.1%. mixed
6.4%, other races 4.3%, unspecified 0.4% (2000
census)
Religions: Anglican 23%, Roman Catholic 15%,
African Methodist Episcopal 11%, other Protestant
18%, other 12%, unaffiliated 6%. unspecified I
none 14% (2000 census)
65
Bermuda (continued)
Languages: English (official), Portuguese
Literacy:
definition: age 1 5 and over can read and write
total population: 98%
male: 98%
female: 99% (2005 est.)','bf48a17cd65363431a9082b9a37504fb2dd66be1d9e88651134e877554662cef','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('18df6f1624cf41a9e9c8d08573651775947a07696a0ef408ab9024daee544093',2007,'BR','Brazil','people-and-society',236,'Population: 8,989,046 (July 2006 est.)
Age structure:
0-14 years: 35% (male 1 ,603,982/female 1 ,542,319)
15-64 years: 60.4% (male 2,660,806/female
2,771,807)
65 years and over: 4.6% (male 1 82,41 2/female
227,720) (2006 est.)
Median age:
total: 21 .8 years
male: 21 .2 years
female: 22.5 years (2006 est.)
Population growth rate: 1 .45% (2006 est.)
Birth rate: 23.3 births/1 ,000 population (2006 est.)
Death rate: 7.53 deaths/1 ,000 population (2006 est.)
Net migration rate: -1 .22 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 0.98 male(s)/female (2006 est.)
Infant mortality rate:
total: 51 .77 deaths/1 ,000 live births
male: 55.31 deaths/1 ,000 live births
female: 48.05 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 65.84 years
male: 63.21 years
female: 68.61 years (2006 est.)
Total fertility rate: 2.85 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.1% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 4,900
(2003 est.)
HIV/AIDS - deaths: less than 500 (2003 est.) ,
Nationality:
noun: Bolivian(s)
adjective: Bolivian
Ethnic groups: Quechua 30%, mestizo (mixed
white and Amerindian ancestry) 30%, Aymara 25%,
white 15%
Religions: Roman Catholic 95%, Protestant
(Evangelical Methodist) 5%
Languages: Spanish (official), Quechua (official),
Aymara (official)
Literacy:
definition: age 1 5 and over can read and write
total population:?,!. 2%
male: 93.1%
female: 81 .6% (2003 est.)','4fd7586a59e2b36f5dac1e0a9b807b47e90a4c0104586698b1fcbb5f7af50746','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cf6b4be915489aecc8d5e948b33bfe951a0b216a3a7df620ab67327aea35abf',2007,'PY','Paraguay','people-and-society',245,'Population: 4,498,976 (July 2006 est.)
Age structure:
0-14 years: 15.5% (male 359,739/female 336,978)
72
Bosnia and Herzegovina (continued)
15-64 years: 70.1% (male 1 ,590,923/female
1,564,665)
65 years and over: 14.4% (male 265,637/female
381,034) (2006 est.)
Median age:
total: 38.4 years
male: 37.2 years
female: 39.5 years (2006 est.)
Population growth rate: 1 .35% (2006 est.)
Birth rate: 8.77 births/1 ,000 population (2006 est.)
Death rate: 8.27 deaths/1 ,000 population (2006 est.)
Net migration rate: 13.01 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1 .07 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.97 male(s)/female (2006 est.)
Infant mortality rate:
total: 9.82 deaths/1,000 live births
male: 1 1 .26 deaths/1 ,000 live births
female: 8.28 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 78 years
male: 74.39 years
female: 81 .88 years (2006 est.)
Total fertility rate: 1 .22 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: less than 0.1%
(2001 est.)
HIV/AIDS - people living with HIV/AIDS: 900
(2003 est.)
HIV/AIDS - deaths: 100 (2001 est.)
Nationality:
noun: Bosnian(s), Herzegovinian(s)
adjective: Bosnian, Herzegovinian
Ethnic groups: Bosniak 48%, Serb 37.1%, Croat
14.3%, other 0.6% (2000)
note: Bosniak has replaced Muslim as an ethnic term
in part to avoid confusion with the religious term
Muslim - an adherent of Islam
Religions: Muslim 40%, Orthodox 31%, Roman
Catholic 15%, other 14%
Languages: Bosnian, Croatian, Serbian
Literacy:
definition: age 1 5 and over can read and write
total population: 94.6%
male: 98.4%
female: 91.1% (2000 est.)','25c02d831229d4ca4db766192933aea746c8285b7849fe7081701d1a13a600fa','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e72b115a1294314e034b87e735d35334fd56b0f135efdd48d8b20cde5083d38c',2007,'BW','Botswana','people-and-society',252,'Population: 1,639,833
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected
(July 2006 est.)
Age structure:
0-14 years: 38.3% (male 31 9,531 /female 309,074)
15-64 years: 57.9% (male 460,692/female 488,577)
65 years and over: 3.8% (male 23,374/female
38,585) (2006 est.)
Median age:
total: 1 9.4 years
male: 18.8 years
female: 20 years (2006 est.)
Population growth rate: -0.04% (2006 est.)
Birth rate: 23.08 births/1 ,000 population (2006 est.)
Death rate: 29.5 deaths/1 ,000 population (2006 est.)
Net migration rate: 6.07 migrant(s)/1,000
population
note: there is an increasing flow of Zimbabweans into
South Africa and Botswana in search of better
economic opportunities (2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.61 male(s)/female
total population: 0.96 male(s)/female (2006 est.)
Infant mortality rate:
total: 53.7 deaths/1 ,000 live births
male: 54.92 deaths/1 ,000 live births
female: 52.44 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 33.74 years
male: 33.9 years
female: 33.56 years (2006 est.)
Total fertility rate: 2.79 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 37.3%
(2003 est.)
HIV/AIDS - people living with HIV/AIDS: 350,000
(2003 est.)
HIV/AIDS - deaths: 33,000 (2003 est.)
Major infectious diseases:
degree of risk: high
food or waterbome diseases: bacterial diarrhea,-
hepatitis A, and typhoid fever
vectorborne disease: malaria (2004)
Nationality:
noun: Motswana (singular), Batswana (plural)
adjective: Motswana (singular), Batswana (plural)
Ethnic groups: Tswana (or Setswana) 79%,
Kalanga 1 1 %, Basarwa 3%, other, including
Kgalagadi and white 7%
Religions: Christian 71 .6%, Badimo 6%, other 1 .4%,
unspecified 0.4%, none 20.6% (2001 census)
Languages: Setswana 78.2%, Kalanga 7.9%,
Sekgalagadi 2.8%, English 2.1% (official), other 8.6%,
unspecified 0.4% (2001 census)
Literacy:
definition: age 15 and over can read and write
total population: 79.8%
male: 76.9%
female: 82.4% (2003 est.)
G o v e r n m
e n t
Country name:
conventional long form: Republic of Botswana
conventional short form: Botswana
former: Bechuanaland
Government type: parliamentary republic
Capital: Gaborone
Administrative divisions: 9 districts and 5 town
councils*; Central. Francistown*. Gaborone*. Ghanzi.
Jwaneng*. Kgalagadi. Kgatleng. Kweneng. Lobatse*.
Northeast, Northwest, Selebi-Pikwe*. Southeast.
Southern
Independence: 30 September 1966 (from UK)
National holiday: Independence Day (Botswana
Day), 30 September (1966)
Constitution: March 1965. effective 30 September
1966
Legal system: based on Roman-Dutch law and local
customary law; judicial review limited to matters of
interpretation; accepts compulsory ICJ jurisdiction,
with reservations
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Festus G. MOGAE (since
1 April 1998) and Vice President Seretse Ian KHAMA
(since 13 July 1998); note - the president is both the
chief of state and head of government
head of government: President Festus G. MOGAE
(since 1 April 1998) and Vice President Seretse Ian
KHAMA (since 13 July 1998); note - the president is
both the chief of state and head of government
cabinet: Cabinet appointed by the president
elections: president indirectly elected for a five-year
term; election last held 20 October 2004 (next to be
held in 2009); vice president appointed by the
president
election results: Festus G. MOGAE elected president;
percent of National Assembly vote - 52%
Legislative branch: bicameral Parliament consists
of the House of Chiefs (a largely advisory 15-member
body consisting of the chiefs of the 8 principal tribes, 4
elected subchiefs, and 3 members selected by the
other 12 members) and the National Assembly (61
seats, 57 members are directly elected by popular
vote and 4 are appointed by the majority party;
members serve five-year terms)
elections: National Assembly elections last held
30 October 2004 (next to be held October 2009)
election results: percent of vote by party - BDP 52%,
BNF 26%, BCP 17%, other 5%; seats by party - BDP
44, BNF12, BCP1
Judicial branch: High Court; Court of Appeal;
Magistrates'' Courts (one in each district)
Political parlies and leaders: Botswana Alliance
Movement or BAM [Ephraim Lepetu SETSHWAELO];
Botswana Congress Party or BCP [Otlaadisa
KOOSALETSE]; Botswana Democratic Party or BDP
[Festus G. MOGAE]: Botswana National Front or BNF
[Otswoletse MOUPO]
note: a number of minor parties joined forces in 1 999
to form the BAM but did not capture any parliamentary
seats - includes the United Action Party [Ephraim
Lepetu SETSHWAELO]; the Independence Freedom
Party or IFP [Motsamai MPHO]; the Botswana
Progressive Union [D. K. KWELE]
Political pressure groups and leaders: NA
International organization participation: ACP,
AfDB, AU, C, FAO. G-77, IAEA, IBRD, ICAO, ICCt,
ICFTU. ICRM, IDA, IFAD, IFC. IFRCS, ILO, IMF,
Interpol, IOC, IPU, ISO, ITU, MIGA, NAM, OPCW,
SACU, SADC, UN, UNCTAD, UNESCO, UNIDO,
UPU, WCO, WFTU, WHO, WIPO, WMO, WToO,
WTO
Diplomatic representation in the US:
chief of mission: Ambassador Lapologang Caesar
LEKOA
chancery: 1531-1533 New Hampshire Avenue NW,
Washington, DC 20036
telephone: [)} (202) 244-4990
FAX: [1] (202) 244-4164
Diplomatic representation from the US:
chief of mission: Ambassador Katherine H.
CANAVAN
embassy: address NA, Gaborone
mailing address: Embassy Enclave, P. O. Box 90,
Gaborone
telephone: [267] 353982
FAX. [267] 312782
Flag description: light blue with a horizontal
white-edged black stripe in the center
76
Botswana (continued)','4b4e614d62c11331b0a7f7de62fcdeeda2149b7ed563cef13ae604bb786ae00c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75906803fd231be4d3dc7b250c006faeeee98c8f41905180bf80e9e2ed41de3f',2007,'NO','Norway','people-and-society',266,'Population: 188,078,227
nofe: Brazil conducted a census in August 2000, which
reported a population of 169,799,170; that figure was
about 3.3% lower than projections by the US Census
Bureau, and is close to the implied underenumeration of
4.6% for the 1991 census; estimates for this country
explicitly take into account the effects of excess mortality
due to AIDS; this can result in lower life expectancy,
higher infant mortality and death rates, lower population
and growth rates, and changes in the distribution of
population by age and sex than would otherwise be
expected (July 2006 est.)
Age structure:
0-14 years: 25.8% (male 24,687,656/female
23,742,998)
15-64 years: 68.1% (male 63,548,331 /female
64,617,539)
65 years and over: 6.1% (male 4,712,675/female
6,769,028) (2006 est.)
Median age:
total: 28.2 years
male: 27.5 years
female: 29 years (2006 est.)
Population growth rate: 1 .04% (2006 est.)
Birth rate: 1 6.56 births/1 ,000 population (2006 est.)
Death rate: 6.17 deaths/1 ,000 population (2006 est.)
Net migration rate: -0.03 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 1 5 years: 1 .04 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.98 male(s)/female (2006 est.)
Infant mortality rate:
total: 28.6 deaths/1 ,000 live births
male: 32.3 deaths/1 ,000 live births
female: 24.7 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 71 .97 years
male: 68.02 years
female: 76.12 years (2006 est.)
Total fertility rate: 1.91 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.7% (2003 est.)
HIV/AIDS ■ people living with HIV/AIDS: 660,000
(2003 est.)
HIV/AIDS - deaths: 15,000 (2003 est.)
Nationality:
noun: Brazilian(s)
adjective: Brazilian
Ethnic groups: white 53.7%, mulatto (mixed white
and black) 38.5%, black 6.2%, other (includes
Japanese, Arab, Amerindian) 0.9%, unspecified 0.7%
(2000 census)
Religions: Roman Catholic (nominal) 73.6%,
Protestant 15.4%, Spiritualist 1 .3%, Bantu/voodoo
0.3%, other 1 .8%, unspecified 0.2%, none 7.4% (2000
census)
Languages: Portuguese (official), Spanish, English,
French
Literacy:
definition: age 1 5 and over can read and write
total population: 86.4%
male: 86.1%
female: 86.6% (2003 est.)
Population: no indigenous inhabitants
note: approximately 1 ,200 former agricultural workers
resident in the Chagos Archipelago, often referred to
as Chagossians or Hois, were relocated to Mauritius
and the Seychelles in the 1960s and 1970s; in
November 2000 they were granted the right of return
by a British High Court ruling, though no timetable has
been set; in November 2004, there were
approximately 4,000 UK and US military personnel
and civilian contractors living on the island of Diego
Garcia (July 2006 est.)
Population: 23,098 (July 2006 est.)
Age structure:
0-14 years: 20.5% (male 2,403/female 2,331)
15-64 years: 74.3% (male 8,81 1/female 8,340)
65 years and over: 5.3% (male 636/female 577)
(2006 est.)
Median age:
total: 31.4 years
male: 31.6 years
female: 31 .2 years (2006 est.)
Population growth rate: 1 .97% (2006 est.)
Birth rate: 14.89 births/1 ,000 population (2006 est.)
Death rate: 4.42 deaths/1 ,000 population (2006 est.)
Net migration rate: 9.22 migrant(s)/1,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 1.1 maie(s)/female
total population: 1 .05 male(s)/female (2006 est.)
Infant mortality rate:
total: 16.72 deaths/1,000 live births
male: 19.5 deaths/1 ,000 live births
female: 13.79 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 76.68 years
male: 75.56 years
female: 77.84 years (2006 est.)
Total fertility rate: 1 .72 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: British Virgin !slander(s)
adjective: British Virgin Islander
Ethnic groups: black 83%, white, Indian, Asian and
mixed
Religions: Protestant 86% (Methodist 33%,
Anglican 17%, Church of God 9%, Seventh-Day
Adventist 6%, Baptist 4%, Jehovah''s Witnesses 2%,
other 15%), Roman Catholic 10%, none 2%, other 2%
(1991)
Languages: English (official)
Literacy:
definition: age 15 and over can read and write
total population: 97 .8% (1991 est.)
male: NA%
female: NA%
Population: 4,610,820 (July 2006 est.)
Age structure:
0-14 years: 19.3% (male 455,122/female 434,009)
15-64 years: 65.9% (male 1 ,542,439/female
1,496,745)
65 years and over: 14.8% (male 288,509/female
393,996) (2006 est.)
Median age:
total: 38.4 years
male: 37.6 years
female: 39.3 years (2006 est.)
Population growth rate: 0.38% (2006 est.)
Birth rate: 1 1 .46 births/1 ,000 population (2006 est.)
Death rate: 9.4 deaths/1 ,000 population (2006 est.)
Net migration rate: 1 .73 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 0.98 male(s)/female (2006 est.)
Infant mortality rate:
total: 3.67 deaths/1 ,000 live births
male: 4.03 deaths/1 ,000 live births
female: 3.29 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 79.54 years
male: 76.91 years
female: 82.31 years (2006 est.)
Total fertility rate: 1 .78 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.1% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 2,100
(2001 est.)
HIV/AIDS - deaths: less than 1 00 (2003 est.)
Nationality:
noun: Norwegian(s)
adjective: Norwegian
Ethnic groups: Norwegian, Sami 20,000
Religions: Church of Norway 85.7%, Pentecostal
1%, Roman Catholic 1%, other Christian 2.4%,
Muslim 1.8%, other 8.1% (2004)
Languages: Bokmal Norwegian (official), Nynorsk
Norwegian (official), small Sami- and
Finnish-speaking minorities; note - Sami is official in
six municipalities
Literacy:
definition: age 1 5 and over can read and write
total population: 100%
male: 100%
female: 100%
418
Norway (continued)','98d6e353eeedee3c4e4c2e5ee97996e59e1bc75439f1676175fb61c55f56e90c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a592bffba73d7e5d1ab1ab6a466a723b476d11244c463e4e722d5d8d76879ad6',2007,'MY','Malaysia','people-and-society',274,'Population: 379,444 (July 2006 est.)
Age structure:
0-14 years: 28.1% (male 54,41 1/female 52,134)
15-64 years: 68.8% (male 138,129/female 123,017)
65 years and over: 3.1% (male 5,584/female 6,169)
(2006 est.)
Median age:
total: 27 A years
male: 28 years
female: 26.7 years (2006 est.)
Population growth rate: 1 .87% (2006 est.)
Birth rate: 18.79 births/1 ,000 population (2006 est.)
Death rate: 3.45 deaths/1 ,000 population (2006 est.)
Net migration rate: 3.31 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1. 04 male(s)/female
15-64 years: 1.12 male(s)/female
65 years and over: 0.91 male(s)/female
total population: 1 .09 male(s)/female (2006 est.)
Infant mortality rate:
total: 12.25 deaths/1 ,000 live births
male: 15.46 deaths/1,000 live births
female: 8.86 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 75.01 years
male: 72.57 years
female: 77.59 years (2006 est.)
Total fertility rate: 2.28 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: less than 0.1%
(2003 est.)
HIV/AIDS • people living with HIV/AIDS: less than
200 (2003 est.)
HIV/AIDS - deaths: less than 200 (2003 est.)
Nationality:
noun: Bruneian(s)
adjective: Bruneian
84
Brunei (continued)
Ethnic groups: Malay 67%, Chinese 1 5%,
indigenous 6%, other 12%
Religions: Muslim (official) 67%, Buddhist 13%,
Christian 10%, indigenous beliefs and other 10%
Languages: Malay (official), English, Chinese
Literacy:
definition: age 15 and over can read and write
total population: 93.9%
male: 96.3%
female: 91 .4% (2002)
Population: 64,631,595
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS; this
can result in lower life expectancy, higher infant mortality
and death rates, lower population and growth rates, and
changes in the distribution of population by age and sex
than would otherwise be expected (July 2006 est.)
Age structure:
0-14 years: 22% (male 7,284,068/female 6,958,632)
15-64 years: 70% (male 22,331 ,312/female
22,880,588)
65 years and over: 8% (male 2,355,1 90/female
2,821,805) (2006 est.)
Median age:
total: 31.9 years
ma/e:31.1 years
female: 32.8 years (2006 est.)
/
545
Thailand (continued)
Population growth rate: 0.68% (2006 est.)
Birth rate: 1 3.87 births/1 ,000 population (2006 est.)
Death rate: 7.04 deaths/1 .000 population (2006 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 0.98 male(s)/female (2006 est.)
Infant mortality rate:
total: 19.49 deaths/1 ,000 live births
male: 20.77 deaths/1 ,000 live births
female: 18.15 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 72.25 years
male: 69.95 years
female: 74.68 years (2006 est.)
Total fertility rate: 1 .64 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 1 .5% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 570,000
(2003 est.)
HIV/AIDS - deaths: 58,000 (2003 est.)
Major infectious diseases:
degree of risk: high
food or waterborne diseases: bacterial diarrhea and
hepatitis A
vectorbome diseases: dengue fever, malaria,
Japanese encephalitis, and plague are high risks in
some locations
animal contact disease: rabies
water contact disease: leptospirosis
nofe: at present, H5N1 avian influenza poses a
minimal risk; during outbreaks among birds, rare
cases could occur among US personnel who have
close contact with infected birds or poultry (2005)
Nationality:
noun: Thai (singular and plural)
adjective: Thai
Ethnic groups: Thai 75%, Chinese 14%, other 11%
Religions: Buddhist 94.6%, Muslim 4.6%, Christian
0.7%, other 0.1% (2000 census)
Languages: Thai, English (secondary language of
the elite), ethnic and regional dialects
Literacy:
definition: age 1 5 and over can read and write
total population: 92.6%
male: 94.9%
female: 90.5% (2002)
Population: 5,548,702
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS; this
can result in lower life expectancy, higher infant mortality
and death rates, lower population and growth rates, and
changes in the distribution of population by age and sex
than would otherwise be expected (July 2006 est.)
548
Togo (continued)
Age structure:
0-14 years: 42.3% (male 1,177,141/female
1,169,321)
15-64 years: 55.1% (male 1 ,485,621/female
1,570,117)
65 years and over: 2.6% (male 59,870/female
86,632) (2006 est.)
Median age:
total. 18.3 years
male. 17.8 years
female: 18.7 years (2006 est.)
Population growth rate: 2.72% (2006 est.)
Birth rate: 37.01 births/1,000 population (2006 est.)
Death rate: 9.83 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2006 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.96 male(s)/female (2006 est.)
Infant mortality rate:
total: 60.63 deaths/1 ,000 live births
male: 68.1 7 deaths/1 ,000 live births
female: 52.87 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 57.42 years
male: 55.41 years
female: 59.49 years (2006 est.)
Total fertility rate: 4.96 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 4.1% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 1 10,000
(2003 est.)
HIV/AIDS - deaths: 1 0,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever
vectorborne diseases: malaria and yellow fever are
high risks in some locations
water contact disease: schistosomiasis
respiratory disease: meningococcal meningitis (2004)
Nationality:
noun: Togolese (singular and plural)
adjective: Togolese
Ethnic groups: native African (37 tribes; largest and
most important are Ewe, Mina, and Kabre) 99%,
European and Syrian-Lebanese less than 1%
Religions: indigenous beliefs 51%, Christian 29%,
Muslim 20%
Languages: French (official and the language of
commerce), Ewe and Mina (the two major African
languages in the south), Kabye (sometimes spelled
Kabiye) and Dagomba (the two major African
languages in the north)
Literacy:
definition: age 15 and over can read and write
total population: 60.9%
male: 75.4%
female: 46.9% (2003 est.)','d0b6944f3f033ff63396737d85791bd8a5f7ab9864cf2d103443ae47c9078ad1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f120df9906dd97f9880b22e99392c2c8b99d272eb14665f4299098aeda8fd530',2007,'BG','Bulgaria','people-and-society',283,'Population: 7,385,367 (July 2006 est.)
Age structure:
0-14 years: 13.9% (male 527,881 /female 502,334)
15-64 years: 68.7% (male 2,496,054/female
2,579,680)
65 years and over: 1 7.3% (male 527,027/female
752,391) (2006 est.)
Median age:
total: 40.8 years
male: 38.7 years
female: 42.9 years (2006 est.)
Population growth rate: -0.86% (2006 est.)
Birth rate: 9.65 births/1 ,000 population (2006 est.)
Death rate: 1 4.27 deaths/1 ,000 population
(2005 est.)
Net migration rate: -4.01 migrant(s)/1,000
population (2006 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.93 male(s)/female (2006 est.)
Infant mortality rate:
total: 19.85 deaths/1 ,000 live births
male: 23.52 deaths/1 ,000 live births
female: 15.95 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 72.3 years
male: 68.68 years
female: 76.13 years (2006 est.)
Total fertility rate: 1 .38 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: less than 0.1%
(2001 est.)
HIV/AIDS - people living with HIV/AIDS: 346
(2001 est.)
HIV/AIDS - deaths: 100 (2001 est.)
Nationality:
noun: Bulgarian(s)
adjective: Bulgarian
Ethnic groups: Bulgarian 83.9%, Turk 9.4%, Roma
4.7%, other 2% (including Macedonian, Armenian,
Tatar, Circassian) (2001 census)
Religions: Bulgarian Orthodox 82.6%, Muslim
12.2%, other Christian 1 .2%, other 4% (2001 census)
Languages: Bulgarian 84.5%, Turkish 9.6%, Roma
4.1%, other and unspecified 1.8% (2001 census)
Literacy:
definition: age 15 and over can read and write
total population: 98.6%
male: 99.1%
female: 98.2% (2003 est.)','28b61e78b6a4948545963a98bd8c7b896b3110bb8d744f8ac07147410f32402e','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a2c8291b77718b6fb936e56d3b48494324030c806e279e15c01c41a45a69b20',2007,'BF','Burkina Faso','people-and-society',292,'Population: 13,902,972
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected
(July 2006 est.)
Age structure:
0-14 years: 46.8% (male 3,267,202/female
3,235,190)
15-64 years: 50.7% (male 3,513,559/female
3,538,623)
65 years and over: 2.5% (male 1 40,083/female
208,315) (2006 est.)
Median age:
total: 16.5 years
male: 16.3 years
female: 16.7 years (2006 est.)
Population growth rate: 3% (2006 est.)
Birth rate: 45.62 births/1,000 population (2006 est.)
Death rate: 1 5.6 deaths/1 ,000 population (2006 est )
Net migration rate: 0 migrant(s)/1.000 population
(2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.99 male(s)/female (2006 est.)
Infant mortality rate:
total: 91 .35 deaths/1 ,000 live births
male: 99. 1 7 deaths/1 .000 live births
female: 83.3 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 48.85 years
male: 47.33 years
female: 50.42 years (2006 est.)
Burkina Faso (continued)
Total fertility rate: 6.47 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 4.2% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 300,000
(2003 est.)
HIV/AIDS - deaths: 29,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever
vectorborne disease: malaria is a high risk in some
locations
water contact disease: schistosomiasis
respiratory disease: meningococcal meningitis (2004)
Nationality:
noun: Burkinabe (singular and plural)
adjective: Burkinabe
Ethnic groups: Mossi over 40%, Gurunsi, Senufo,
Lobi, Bobo, Mande, Fulani
Religions: Muslim 50%, indigenous beliefs 40%,
Christian (mainly Roman Catholic) 10%
Languages: French (official), native African
languages belonging to Sudanic family spoken by
90% of the population
Literacy:
definition: age 15 and over can read and write
total population: 26.6%
male: 36.9%
female: 16.6% (2003 est.)
G o v e r n m e
Country name:
conventional long form: none
conventional short form: Burkina Faso
former: Upper Volta, Republic of Upper Volta
Government type: parliamentary republic
Capital: Ouagadougou
Administrative divisions: 45 provinces; Bale, Bam,
Banwa, Bazega, Bougouriba, Boulgou, Boulkiemde,
Comoe, Ganzourgou, Gnagna, Gourma, Houet, loba,
Kadiogo, Kenedougou, Komondjari, Kompienga, Kossi,
Koulpelogo, Kouritenga, Kourweogo, Leraba, Loroum,
Mouhoun, Nahouri, Namentenga, Nayala, Noumbiel.
Oubritenga, Oudalan, Passore, Poni, Sanguie,
Sanmatenga, Seno, Sissili, Soum, Sourou, Tapoa, Tuy,
Yagha, Yatenga, Ziro, Zondoma, Zoundweogo
Independence: 5 August 1960 (from France)
National holiday: Republic Day, 1 1 December
(1958)
Constitution: 2 June 1 991 approved by referendum,
11 June 1991 formally adopted; amended April 2000
Legal system: based on French civil law system and
customary law
Suffrage: universal
Executive branch:
chief of state: President Blaise COMPAORE (since
15 October 1987)
head of government: Prime Minister Ernest
Paramanga YONLI (since 6 November 2000)
cabinet: Council of Ministers appointed by the president
on the recommendation of the prime minister
elections: president elected by popular vote for a
five-year term; election last held 13 November 2005
(next to be held in 201 0) ; in April 2000, the constitution
was amended reducing the presidential term from
seven to five years, enforceable as of 2005, and
allowing the president to be reelected only once;
prime minister appointed by the president with the
consent of the legislature
election results: Blaise COMPAORE reelected
president; percent of popular vote - Blaise
COMPAORE 80.3%, Benewende Stanislas
SANKARA 4.9%
Legislative branch: unicameral National Assembly
or Assemblee Nationale (1 1 1 seats; members are
elected by popular vote to serve five-year terms)
elections: National Assembly election last held 5 May
2002 (next to be held May 2007)
election results: percent of vote by party - NA: seats
by party - CDP 57, RDA-ADF 17. PDP/PS 10, CFD 5,
PAI5,other17
Judicial branch: Supreme Court: Appeals Court
Political parties and leaders: African Democratic
Rally-Alliance for Democracy and Federation or
RDA-ADF [Herman YAMEOGO]; Confederation for
Federation and Democracy or CFD [Amadou
Diemdioda DICKO]; Congress for Democracy and
Progress or CDP [Roch Marc-Christian KABORE];
Movement for Tolerance and Progress or MTP
[Nayabtigungou Congo KABORE]; Party for African
Independence or PAI [Philippe OUEDRAOGO]; Party
for Democracy and Progress or PDP [Joseph
KI-ZERBO]; Socialist Party or PS [leader NA]; Union
of Greens for the Development of Burkina Faso or
UVDB [Ram OVEDRAGO]
Political pressure groups and leaders: Burkinabe
General Confederation of Labor or CGTB; Burkinabe
Movement for Human Rights or MBDHP; Group of
14 February; National Confederation of Burkinabe
Workers or CNTB; National Organization of Free
Unions or ONSL; watchdog/political action groups
throughout the country in both organizations and
communities
International organization participation: ACCT,
ACP, AfDB. AU, CEMAC, ECOWAS, Entente, FAO,
FZ, G-77, IAEA, IBRD, ICAO, ICC, ICCt, ICFTU,
ICRM, IDA, IDB, IFAD, IFC, IFRCS, ILO, IMF,
Interpol, IOC, IOM, IPU, ISO (correspondent), ITU,
MIGA, MONUC, NAM, OIC, OIF, ONUB, OPCW,
PCA, UN, UNCTAD, UNESCO, UNIDO, UNOCI,
UPU, WADB (regional), WAEMU, WCL, WCO,
WFTU, WHO, WIPO, WMO, WToO. WTO
Diplomatic representation in the US:
chief of mission: Ambassador Tertius ZONGO
chancery: 2340 Massachusetts Avenue NW,
Washington, DC 20008
telephone: [1] (202) 332-5577
FAX: [1](202)667-1882
Diplomatic representation from the US:
chief of mission: Ambassador (vacant); Charge
d''Affaires Cynthia AKUETTEH
embassy: 602 Avenue Raoul Follereau, Koulouba,
Secteur 4
mailing address: 01 B. P. 35, Ouagadougou 01 ;
pouch mail -U.S. Department of State, 2440
Ouagadougou Place, Washington, DC 20521-2440
telephone: [226] 306723
FAX: [226] 303890
Flag description: two equal horizontal bands of red
(top) and green with a yellow five-pointed star in the
center; uses the popular pan-African colors of Ethiopia','31548543d12a595fd69be2b0402ef0efb9f3818b3e8121133b43fd3e36d1b018','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('188707873e049a6a048ff37d8b23880a525df79350c86882ff6ad64cb86a1409',2007,'TH','Thailand','people-and-society',299,'Population: 47,382,633
nofe: estimates for this country take into account the
effects of excess mortality due to AIDS; this can result
in lower life expectancy, higher infant mortality and
death rates, lower population growth rates, and
changes in the distribution of population by age and
sex than would otherwise be expected (July 2006 est.)
Age structure:
0-14 years: 26.4% (male 6,335,236/female
6,181,216)
15-64 years: 68.5% (male 16,01 1 ,723/female
16,449,626)
65 years and over: 5.1 % (male 1 ,035,853/female
1,368,979) (2006 est.)
Median age:
total: 27 years
male: 26.4 years
female: 27.6 years (2006 est.)
Population growth rate: 0.81% (2006 est.)
Birth rate: 17.91 births/1,000 population (2006 est.)
Death rate: 9.83 deaths/1 .000 population (2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 0.97 male(s)/female (2006 est.)
Infant mortality rate:
total: 61 .85 deaths/1 ,000 live births
male: 72.68 deaths/1 ,000 live births
female: 50.38 deaths/1.000 live births (2006 est.)
Life expectancy at birth:
total population: 60.97 years
male: 58.07 years
female: 64.03 years (2006 est.)
Total fertility rate: 1 .98 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 1 2% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 330,000
(2003 est.)
HIV/AIDS • deaths: 20.000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterbome diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever
vectorborne diseases: dengue fever and malaria are
high risks in some locations (2004)
Nationality:
noun: Burmese (singular and plural)
adjective: Burmese
Ethnic groups: Burman 68%, Shan 9%, Karen 7%,
Rakhine 4%, Chinese 3%, Indian 2%, Mon 2%. other
5%
Religions: Buddhist 89%, Christian 4% (Baptist 3%,
Roman Catholic 1%), Muslim 4%. animist 1%, other
2%
Languages: Burmese, minority ethnic groups have
their own languages
Literacy:
definition: age 1 5 and over can read and write
total population: 85.3%
male: 89.2%
female: 81 .4% (2002)
Population: 245,452,739 (July 2006 est.)
Age structure:
0-14 years: 28.8% (male 35,995,91 9/female
34,749,582)
15-64 years: 65.8% (male 80,796,794/female
80.754,238)
65 years and over: 5.4% (male 5,737,473/female
7,418,733) (2006 est.)
Median age:
total: 26.8 years
male: 26.4 years
female: 27.3 years (2006 est.)
Population growth rate: 1 .41% (2006 est.)
Birth rate: 20.34 births/1,000 population (2006 est.;
Death rate: 6.25 deaths/1 ,000 population (2006 est.
Net migration rate: 0 migrant(s)/1,000 population
(2006 est.)
Sex ratio:
affc/rtft: 1.05 male(s)/female
under 15 years:). 04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 1 male(s)/female (2006 est.)
Infant mortality rate:
total: 34.39 deaths/1 ,000 live births
male: 39.36 deaths/1 ,000 live births
female: 29.17 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 69.87 years
male: 67.42 years
female: 72.45 years (2006 est.)
Total fertility rate: 2.4 children born/woman
(2006 est.)
HIV/AIDS • adult prevalence rate: 0.1% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 1 10 000
(2003 est.)
HIV/AIDS - deaths: 2,400 (2003 est.)
Major infectious diseases:
degree of risk: high
food or waterborne diseases: bacterial and protozoal
diarrhea, hepatitis A and E, and typhoid fever
vectorbome diseases: dengue fever, malaria, and
chikungunya are high risks in some locations
note: at present, H5N1 avian influenza poses a
minimal risk; during outbreaks among birds, rare
cases could occur among US citizens who have close
contact with infected birds or poultry (2005)
Nationality:
noun: Indonesian(s)
adjective: Indonesian
Ethnic groups: Javanese 45%, Sundanese 14%,
Madurese 7.5%, coastal Malays 7.5%, other 26%
Religions: Muslim 88%, Protestant 5%, Roman
Catholic 3%, Hindu 2%, Buddhist 1%, other 1% (1998)
Languages: Bahasa Indonesia (official, modified
form of Malay), English, Dutch, local dialects, the most
widely spoken of which is Javanese
Literacy:
definition: age 15 and over can read and write
total population: 87.9%
male: 92.5%
female: 83.4% (2002 est.)
Population: 68,688,433 (July 2006 est.)
Age structure:
0-14 years: 26.1% (male 9,204,785/female
8,731,429)
15-64 years: 69% (male 24,1 33,91 9/female
23,245,255)
65 years and over: 4.9% (male 1 ,653,827/female
1,719,218) (2006 est.)
Median age:
total: 24.8 years
male: 24.6 years
female: 25 years (2006 est.)
Population growth rate: 1.1% (2006 est.)
Birth rate: 1 7 births/1 ,000 population (2006 est.)
Death rate: 5.55 deaths/1 ,000 population (2006 est.)
Net migration rate: -0.48 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.96 male(s)/female
total population: 1 .04 male(s)/female (2006 est.)
Infant mortality rate:
total: 40.3 deaths/1,000 live births
male: 40.49 deaths/1 ,000 live births
female: 40.1 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 70.26 years
male: 68.86 years
female: 71 .74 years (2006 est.)
Total fertility rate: 1 .8 children born/woman
(2006 est.)
HIV/AIDS • adult prevalence rate: less than 0.1%
(2001 est.)
HIV/AIDS - people living with HIV/AIDS: 31 ,000
(2001 est.)
HIV/AIDS - deaths: 800 (2003 est.)
Nationality:
noun: Iranian(s)
adjective: Iranian
Ethnic groups: Persian 51%, Azeri 24%, Gilaki and
Mazandarani 8%, Kurd 7%, Arab 3%, Lur 2%, Baloch
2%, Turkmen 2%, other 1%
Religions: Shi''a Muslim 89%, Sunni Muslim 9%,
Zoroastrian, Jewish, Christian, and Baha''i 2%
Languages: Persian and Persian dialects 58%,
Turkic and Turkic dialects 26%, Kurdish 9%, Luri 2%,
Balochi 1%, Arabic 1%, Turkish 1%, other 2%
Literacy:
definition: age 15 and over can read and write
total population: 79.4%
male: 85.6%
female: 73% (2003 est.)
Population: 26,783,383 (July 2006 est.)
Age structure:
0-14 years: 39.7% (male 5,398,645/female
5,231,760)
15-64 years: 57.3% (male 7,776,257/female
7,576,726)
65 years and over: 3% (male 376,700/female
423,295) (2006 est.)
Median age:
total: 19.7 years
male: 1 9.6 years
female: 19.8 years (2006 est.)
Population growth rate: 2.66% (2006 est.)
Birth rate: 31 .98 births/1 ,000 population (2006 est.)
Death rate: 5.37 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.03 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.89 male(s)/female
total population: 1 .02 male(s)/female (2006 est.)
Infant mortality rate:
total: 48.64 deaths/1 ,000 live births
male: 54.39 deaths/1 ,000 live births
female: 42.61 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 69. 01 years
male: 67.76 years
female: 70.31 years (2006 est.)
Total fertility rate: 4.18 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: less than 0.1%
(2001 est.)
HIV/AIDS - people living with HIV/AIDS: less than
500 (2003 est.)
HIV/AIDS - deaths: NA
Nationality:
noun: Iraqi(s)
adjective: Iraqi
Ethnic groups: Arab 75%-80%, Kurdish 15%-20%,
Turkoman, Assyrian or other 5%
Religions: Muslim 97% (Shi''a 60%-65%, Sunni
32%-37%), Christian or other 3%
Languages: Arabic, Kurdish (official in Kurdish
regions), Assyrian, Armenian
Literacy:
definition: age 1 5 and over can read and write
total population: 40.4%
male: 55.9%
female: 24.4% (2003 est.)
Population: 6,368,481 (July 2006 est.)
Age structure:
0-14 years: 41 .4% (male 1 ,324,207/female
1,313,454)
15-64 years: 55.4% (male 1 ,744,206/female
1,786,139)
65 years and over: 3.1% (male 89,451 /female
111,024) (2006 est.)
Median age:
total: 18.9 years
male: 18.6 years
female: 19.2 years (2006 est.)
Population growth rate: 2.39% (2006 est.)
Birth rate: 35.49 births/1 ,000 population (2006 est.)
Death rate: 1 1 .55 deaths/1 ,000 population
(2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 0.98 male(s)/female (2006 est.)
Infant mortality rate:
total: 83.31 deaths/1 ,000 live births
male: 92.95 deaths/1 ,000 live births
female: 73.26 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 55.49 years
male: 53.45 years
female: 57.61 years (2006 est.)
Total fertility rate: 4.68 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.1% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 1 ,700
(2003 est.)
HIV/AIDS - deaths: less than 200 (2003 est.)
Nationality:
noun: Lao(s) or Laotian(s)
adjective: Lao or Laotian
Ethnic groups: Lao Loum (lowland) 68%, Lao
Theung (upland) 22%, Lao Soung (highland) including
the Hmong and the Yao 9%, ethnic Vietnamese/
Chinese 1%
Religions: Buddhist 60%, animist and other 40%
(including various Christian denominations 1 .5%)
Languages: Lao (official), French, English, and
various ethnic languages
Literacy:
definition: age 15 and over can read and write
total population: 66.4%
male: 77.4%
female: 55.5% (2002)
Population: 84,402,966 (July 2006 est.)
Age structure:
0-14 years: 27% (male 1 1 ,826,457/female
10,983,069)
15-64 years: 67.1% (male 28,055,941/female
28,614,553)
65 years and over: 5.8% (male 1 ,924,562/female
2,998,384) (2006 est.)
Median age:
total: 25.9 years
male: 24.8 years
female: 27.1 years (2006 est.)
Population growth rate: 1 .02% (2006 est.)
Birth rate: 1 6.86 births/1 ,000 population (2006 est.)
Death rate: 6.22 deaths/1 ,000 population (2006 est.;
Net migration rate: -0.42 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1 .08 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.64 male(s)/female
total population: 0 98 male(s)/female (2006 est.)
Infant mortality rate:
total: 25.14 deaths/1 ,000 live births
male: 25.54 deaths/1 ,000 live births
female: 24.72 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 70.85 years
male: 68.05 years
female: 73.85 years (2006 est.)
Total fertility rate: 1 .91 children born/woman
(2006 est.)
HIV/AIDS ■ adult prevalence rate: 0.4% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 220,000
(2003 est.)
HIV/AIDS - deaths: 9,000 (2003 est.)
Major infectious diseases:
degree of risk: high
food or waterbome diseases: bacterial diarrhea,
hepatitis A, and typhoid fever
vectorborne diseases: dengue fever, malaria,
Japanese encephalitis, and plague are high risks in
some locations
animal contact disease: rabies
water contact disease: leptospirosis
note: at present, H5N1 avian influenza poses a
minimal risk; during outbreaks among birds, rare
cases could occur among US personnel who have
close contact with infected birds or poultry (2005)
Nationality:
noun: Vietnamese (singular and plural)
adjective: Vietnamese
Ethnic groups: Kinh (Viet) 86.2%, Tay 1.9%, Thai
1.7%, Muong 1.5%, Khome 1.4%, Hoa 1.1%, Nun
1.1%, Hmong 1%, others 4.1% (1999 census)
Religions: Buddhist 9.3%, Catholic 6.7%, Hoa Hao
1.5%, Cao Dai 1.1%, Protestant 0.5%, Muslim 0.1%,
none 80.8% (1999 census)
Languages: Vietnamese (official), English
(increasingly favored as a second language), some
French, Chinese, and Khmer; mountain area
languages (Mon-Khmer and Malayo-Polynesian)
Literacy:
definition: age 1 5 and over can read and write
total population: 90.3%
male: 93.9%
female: 86.9% (2002)
Population: 108,605 (July 2006 est.)
Age structure:
0-14 years: 22.4% (male 12,261/female 12,056)
15-64 years: 66.4% (male 34,174/female 37,949)
65 years and over: 1 1 .2% (male 5,385/female 6,780)
(2006 est.)
Median age:
total: 37.1 years
male: 36.2 years
female: 38 years (2006 est.)
Population growth rate: -0.12% (2006 est.)
Birth rate: 1 3.96 births/1 ,000 population (2006 est.)
Death rate: 6.43 deaths/1 ,000 population (2006 est.)
Net migration rate: -8.73 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.9 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 0.91 male(s)/female (2006 est.)
Infant mortality rate:
total: 7.86 deaths/1 ,000 live births
male: 8.93 deaths/1 ,000 live births
female: 6.72 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 79.05 years
male: 75.24 years
female: 83.09 years (2006 est.)
Total fertility rate: 2.17 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Virgin Islander(s) (US citizens)
adjective: Virgin Islander
Ethnic groups: black 76.2%, white 13.1%, Asian
1.1%, other 6.1%, mixed 3.5% (2000 census)
Religions: Baptist 42%, Roman Catholic 34%,
Episcopalian 17%, other 7%
Languages: English 74.7%, Spanish or Spanish
Creole 16.8%, French or French Creole 6.6%, other
1.9% (2000 census)
Literacy:
definition: age 1 5 and over can read and write
total population: 90-95% est.
male: NA%
female: NA% (2005 est.)
603
Virgin Islands (continued)','5a09e2faeb15f07a700f52f55445a966d58bcca144e76345d4d47b838f00620a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23362f8e785532950be0cccf601ea36b6360da6896856abfb1dd23a9ea7972cb',2007,'CG','Congo','people-and-society',310,'Population: 8,090,068
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected
(July 2006 est.)
Age structure:
0-14 years: 46.3% (male 1 ,884,825/female
1,863,200)
15-64 years: 51 .1% (male 2,051 ,451/female
2,082,017)
65 years and over: 2.6% (male 83,432/female
125,143) (2006 est.)
Median age:
total: 16.6 years
male: 16.4 years
female: 16.9 years (2006 est.)
Population growth rate: 3.7% (2006 est.)
Birth rate: 42.22 births/1 ,000 population (2006 est.)
Death rate: 13.46 deaths/1 ,000 population
(2006 est.)
Net migration rate: 8.22 migrant(s)/1,000
population (2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.99 male(s)/female (2006 est.)
Infant mortality rate:
total: 63.1 3 deaths/1 ,000 live births
male: 70.26 deaths/1 ,000 live births
female: 55.79 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 50.81 years
male: 50.07 years
female: 51 .58 years (2006 est.)
Total fertility rate: 6.55 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 6% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 250,000
(2003 est.)
HIV/AIDS - deaths: 25,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial diarrhea,
hepatitis A, and typhoid fever
vectorborne disease: malaria (2004)
Nationality:
noun: Burundian(s)
adjective: Burundian
Ethnic groups: Hutu (Bantu) 85%, Tutsi (Hamitic)
14%, Twa (Pygmy) 1%, Europeans 3,000, South
Asians 2,000
Religions: Christian 67% (Roman Catholic 62%,
Protestant 5%), indigenous beliefs 23%, Muslim 10%
Languages: Kirundi (official), French (official),
Swahili (along Lake Tanganyika and in the Bujumbura
area)
Literacy:
definition: age 15 and over can read and write
total population: 51 .6%
male: 58.5%
female: 45.2% (2003 est.)
Population: 13,881.427
note: estimates for this country take into account the
effects of excess mortality due to AIDS; this can result
in lower life expectancy, higher infant mortality and
death rates, lower population growth rates, and
changes in the distribution of population by age and
sex than would otherwise be expected (July 2006 est.)
97
Cambodia (continued)
Age structure:
0-14 years: 35.6% (male 2,497,595/female
2,447,754)
15-64 years: 61% (male 4,094,946/female 4,370, 159)
65 years and over: 3.4% (male 180,432/female
290.541) (2006 est.)
Median age:
total: 20.6 years
male: 19.9 years
female: 21 .4 years (2006 est.)
Population growth rate: 1 .78% (2006 est.)
Birth rate: 26.9 births/1 ,000 population (2006 est.)
Death rate: 9.06 deaths/1 .000 population (2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.62 male(s)/female
total population: 0.95 male(s)/female (2006 est.)
Infant mortality rate:
total: 68.78 deaths/1 ,000 live births
male: 77.35 deaths/1 ,000 live births
female: 59.84 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 59.29 years
male: 57.35 years
female: 61 .32 years (2006 est.)
Total fertility rate: 3.37 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 2.6% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 170,000
(2003 est.)
HIV/AIDS ■ deaths: 1 5,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever
vectorborne diseases: dengue fever, malaria, and
Japanese encephalitis are high risks in some
locations
note: at present, H5N1 avian influenza poses a
minimal risk; during outbreaks among birds, rare
cases could occur among US citizens who have close
contact with infected birds or poultry (2005)
Nationality:
noun: Cambodian(s)
adjective: Cambodian
Ethnic groups: Khmer 90%, Vietnamese 5%,
Chinese 1%, other 4%
Religions: Theravada Buddhist 95%, other 5%
Languages: Khmer (official) 95%, French, English
Literacy:
definition: age 1 5 and over can read and write
total population: 73.6%
male: 84.7%
female: 64.1% (2004 est.)
Population: 4,303,356
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected
(July 2006 est.)
Age structure:
0-14 years: 41 .9% (male 907,629/female 897,153)
15-64 years: 53.9% (male 1 ,146,346/female
1,173,268)
65 years and over: 4.2% (male 71 ,31 2/female
107.648) (2006 est.)
Median age:
total: 18.4 years
male: 18 years
female: 18.8 years (2006 est.)
Population growth rate: 1 .53% (2006 est.)
Birth rate: 33.91 births/1,000 population (2006 est.)
Death rate: 18.65 deaths/1 ,000 population
(2006 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2006 est.)
Sex ratio:
at birth: 1 .03 male^s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.66 male(s)/female
total population: 0.98 male(s)/female (2006 est.)
Infant mortality rate:
total: 85.63 deaths/1 ,000 live births
male: 92.44 deaths/1 ,000 live births
female: 78.61 deaths/1,000 live births (2006 est.)
110
Central African Republic (continued)
Life expectancy at birth:
total population: 43.54 years
male: 43.46 years
female: 43.62 years (2006 est.)
Total fertility rate: 4.41 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 13.5%
(2003 est.)
HIV/AIDS - people living with HIV/AIDS: 260,000
(2003 est.)
HIV/AIDS • deaths: 23,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial diarrhea,
hepatitis A, and typhoid fever
vectorborne disease: malaria
respiratory disease: meningococcal meningitis (2004)
Nationality:
noun: Central African(s)
adjective: Central African
Ethnic groups: Baya 33%, Banda 27%, Mandjia
13%, Sara 10%, Mboum 7%, M''Baka 4%, Yakoma
4%, other 2%
Religions: indigenous beliefs 35%, Protestant 25%,
Roman Catholic 25%, Muslim 15%
note: animistic beliefs and practices strongly influence
the Christian majority
Languages: French (official), Sangho (lingua franca
and national language), tribal languages
Literacy:
definition: age 15 and over can read and write
total population: 51%
male: 63.3%
female: 39.9% (2003 est.)
Population: 3,702,314
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected
(July 2006 est.)
Age structure:
0-14 years: 46.4% (male 864,407/female 853,728)
15-64 years: 50.7% (male 930,390/female 945,545)
65 years and over: 2.9% (male 44,430/female
63,814) (2006 est.)
Median age:
total: 16.6 years
male: 16.4 years
female: 16.9 years (2006 est.)
Population growth rate: 2.6% (2006 est.)
Birth rate: 42.57 births/1,000 population (2006 est.)
Death rate: 12.93 deaths/1 ,000 population (2006 est.)
Net migration rate: -3.62 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.99 male(s)/female (2006 est.)
Infant mortality rate:
total: 85.29 deatns/1 ,000 live births
mate: 91 deaths/1 ,000 live births
femaleJS.M deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 52.8 years
male: 51.65 years
female: 53.98 years (2006 est.)
Total fertility rate: 6.07 children born/woman
(2006 est.)
HIV/AIDS ■ adult prevalence rate: 4.9% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 90.000
(2003 est.)
HIV/AIDS ■ deaths: 9,700 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial diarrhea,
hepatitis A, and typhoid fever
vectorbome disease: malaria (2004)
Nationality:
noun: Congolese (singular and plural)
adjective: Congolese or Congo
Ethnic groups: Kongo 48%, Sangha 20%. M''Bochi
12%, Teke 17%, Europeans and other 3%
Religions: Christian 50%, animist 48%, Muslim 2%
Languages: French (official), Lingala and
Monokutuba (lingua franca trade languages), many
local languages and dialects (of which Kikongo is the
most widespread)
Literacy:
definition: age 1 5 and over can read and write
total population: 83.8%
male: 89.6%
female: 78.4% (2003 est.)','fca063c6a12d6c3d7bdb1958a413f78875e509f26e6b81569b546b3cf04fa671','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de23e003233077aeda30f3763f7958cfeb359d84b5236ecc167b7be06dcfb507',2007,'CM','Cameroon','people-and-society',318,'Population: 17,340,702
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected
(July 2006 est.)
Age structure:
0-14 years: 41 .2% (male 3,614,430/female
3.531,047)
15-64 years: 55.5% (male 4,835,453/female
4,796,276)
65 years and over: 3.2% (male 260,342/female
303,154) (2006 est.)
Median age:
total: 18.9 years
male: 18.7 years
female: 19 years (2006 est.)
Population growth rate: 2.04% (2006 est.)
Birth rate: 33.89 births/1 ,000 population (2006 est.)
Death rate: 1 3.47 deaths/1 ,000 population
(2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.86 male(s)/female
total population: 1 .01 male(s)/female (2006 est.)
100
Cameroon (continued)
Infant mortality rate:
total: 63.52 deaths/1 ,000 live births
male: 67.38 deaths/1 ,000 live births
female: 59.53 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 51.16 years
male: 50.98 years
female: 51 .34 years (2006 est.)
Total fertility rate: 4.39 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 6.9% (2003 est.)
HIV/AIDS • people living with HIV/AIDS: 560,000
(2003 est.)
HIV/AIDS - deaths: 49,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial diarrhea,
hepatitis A, and typhoid fever
vectorborne diseases: malaria and yellow fever are
high risks in some locations
water contact disease: schistosomiasis
respiratory disease: meningococcal meningitis (2004)
Nationality:
noun: Cameroonian(s)
adjective: Cameroonian
Ethnic groups: Cameroon Highlanders 31%,
Equatorial Bantu 19%, Kirdi 11%, Fulani 10%,
Northwestern Bantu 8%, Eastern Nigritic 7%, other
African 13%, non-African less than 1%
Religions: indigenous beliefs 40%, Christian 40%,
Muslim 20%
Languages: 24 major African language groups,
English (official), French (official)
Literacy:
definition: age 1 5 and over can read and write
total population: 79%
male: 84.7%
female: 73.4% (2003 est.)','c68a2a4638cebf1ff1d7d60e55e00bf39c6029acb4ea6358272caa867848ad34','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f8c86380ea0ee9af49e795087a6dbf036f20866072ad67ce7250d9d958165ba',2007,'CA','Canada','people-and-society',328,'Population: 33,098,932 (July 2006 est.)
Age structure:
0-14 years: 17. 6% (male 2,992,81 1 /female
2,848,388)
15-64 years: 69% (male 1 1 ,482,452/female
11,368,286)
65 years and over: 13.3% (male 1 ,883,008/female
2,523,987) (2006 est.)
Median age:
total: 38.9 years
male: 37.8 years
female: 39.9 years (2006 est.)
Population growth rate: 0.88% (2006 est.)
Birth rate: 1 0.78 births/1 ,000 population (2006 est.)
Death rate: 7.8 deaths/1 ,000 population (2006 est.)
Net migration rate: 5.85 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.98 male(s)/female (2006 est.)
Infant mortality rate:
total: 4.69 deaths/1 ,000 live births
male: 5.1 5 deaths/1 ,000 live births
female: 4.22 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 80.22 years
male: 76.86 years
female: 83.74 years (2006 est.)
Total fertility rate: 1.61 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.3% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 56.000
(2003 est.)
HIV/AIDS - deaths: 1 ,500 (2003 est.)
Nationality:
noun: Canadian(s)
adjective: Canadian
Ethnic groups: British Isles origin 28%, French
origin 23%, other European 15%. Amerindian 2%,
other, mostly Asian, African, Arab 6%, mixed
background 26%
Religions: Roman Catholic 42.6%, Protestant 23.3%
(including United Church 9.5%, Anglican 6.8%, Baptist
2.4%, Lutheran 2%), other Christian 4.4%, Muslim |
other and unspecified 1 1 .8%, none 16% (2001 census)
Languages: English (official) 59.3%, French (official)
23.2%, other 17 5%
Literacy:
definition: age 1 5 and over can read and write
total population: 99° o
male: 99%
fema/e: 99% (2003 est.)
103
Canada (continued)
Population: 420,979 (July 2006 est.)
Age structure:
0-14 years: 37.9% (male 80,594/female 79,126)
15-64 years: 55.3% (male 113,450/female 119,423)
65 years and over: 6.7% (male 1 0,542/female
17,844) (2006 est.)
Median age:
total: 19.8 years
male: 19 years
female: 20.7 years (2006 est.)
Population growth rate: 0.64% (2006 est.)
Birth rate: 24.87 births/1 ,000 population (2006 est.)
Death rate: 6.55 deaths/1 ,000 population (2006 est.)
Net migration rate: -11.91 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1. 02 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.59 male(s)/female
total population: 0.95 male(s)/female (2006 est.)
Infant mortality rate:
total: 46.52 deaths/1,000 live births
male: 51 .63 deaths/1 ,000 live births
female: 41 .26 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 70.73 years
male: 67.41 years
female: 74.15 years (2006 est.)
Total fertility rate: 3.38 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.035%
(2001 est.)
HIV/AIDS - people living with HIV/AIDS: 775
(2001)
HIV/AIDS • deaths: 225 (as of 2001)
Nationality:
noun: Cape Verdean(s)
adjective: Cape Verdean
Ethnic groups: Creole (mulatto) 71%, African 28%,
European 1%
Religions: Roman Catholic (infused with indigenous
beliefs); Protestant (mostly Church of the Nazarene)
Languages: Portuguese, Crioulo (a blend of
Portuguese and West African words)
Literacy:
definition: age 1 5 and over can read and write
total population: 76.6%
male: 85.8%
female: 69.2% (2003 est.)','29183ab1576d060db37133c6ba1c69f1957f4477655ff492c1940c5844a9bd72','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('668ab0cdfc02bb2158d83522a8d0546d831d47980d6287f01a50f0dd1173a513',2007,'JM','Jamaica','people-and-society',344,'Population: 45,436
note: most of the population lives on Grand Cayman
(July 2006 est.)
Age structure:
0-14 years: 20.7% (male 4,708/female 4,700)
15-64 years: 70.9% (male 15,707/female 16,504)
65 years and over: 8.4% (male 1 ,793/female 2,024)
(2006 est.)
Median age:
total: 37.2 years
male: 36.8 years
female: 37.5 years (2006 est.)
Population growth rate: 2.56% (2006 est.)
Birth rate: 12.74 births/1,000 population (2006 est.)
Death rate: 4.89 deaths/1 ,000 population (2006 est.)
Net migration rate: 17.78 migrant(s)/1 ,000
population
note: major destination for Cubans trying to migrate to
the US (2006 est.)
Sex ratio:
at bidh: 1 .02 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.89 male(s)/female
total population: 0.96 male(s)/female (2006 est.)
Infant mortality rate:
total: 8 deaths/1 ,000 live births
male: 9.16 deaths/1,000 live births
female: 6.81 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 80.07 years
male: 77.45 years
female: 82.74 years (2006 est.)
Total fertility rate: 1 .9 children born/woman
(2006 est.)
HIV/AIDS • adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Caymanian(s)
adjective: Caymanian
Ethnic groups: mixed 40%, white 20%, black 20%,
expatriates of various ethnic groups 20%
Religions: United Church (Presbyterian and
Congregational), Anglican, Baptist, Church of God,
other Protestant, Roman Catholic
Languages: English
108
Cayman Islands (continued)
Literacy:
definition: age 1 5 and over has ever attended school
total population: 98%
male: 98%
female: 98% (1970 est.)
Population: 2,758,124 (July 2006 est.)
Age structure:
0- 14 years: 33. 1 % (male 464,297/female 449, 1 81 )
15-64 years: 59.6% (male 808,71 8/female 835,394)
65 years and over: 7.3% (male 90,100/female
110,434) (2006 est.)
Median age:
total: 23 years
male: 22.4 years
female: 23.5 years (2006 est.)
Population growth rate: 0.8% (2006 est.)
Birth rate: 20.82 births/1 ,000 population (2006 est.)
Death rate: 6.52 deaths/1 ,000 population (2006 est.)
Net migration rate: -6.27 migrant(s)/1,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 0.98 male(s)/female (2006 est.)
285
Jamaica (continued)
Infant mortality rate:
total: 15.98 deaths/1,000 live births
male: 16.66 deaths/1 ,000 live births
female: 15.27 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 73.24 years
male: 71.54 years
female: 75.03 years (2006 est.)
Total fertility rate: 2.41 children born/woman
(2006 est.)
HIV/AIDS • adult prevalence rate: 1 .2% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 22,000
(2003 est.)
HIV/AIDS - deaths: 900 (2003 est.)
Nationality:
noun: Jamaican(s)
adjective: Jamaican
Ethnic groups: black 90.9%, East Indian 1 .3%,
white 0.2%, Chinese 0.2%, mixed 7.3%, other 0.1%
Religions: Protestant 61 .3% (Church of God 21 .2%,
Seventh-Day Adventist 9%, Baptist 8.8%, Pentecostal
7.6%, Anglican 5.5%, Methodist 2.7%, United Church
2.7%, Jehovah''s Witness 1.6%, Brethren 1.1%,
Moravian 1.1%), Roman Catholic 4%, other including
some spiritual cults 34.7%
Languages: English, patois English
Literacy:
definition: age 15 and over has ever attended school
total population: 87.9%
ma/e:84.1%
fe/na/e: 91 .6% (2003 est.)','d62336301c529d50b3af49e23d1c8740aaff1d85c0431f28df27805b8d140aaf','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2af23521353f8d246a860047a0a07af676e58280248556726dd7ebb5cc54edc4',2007,'LY','Libya','people-and-society',355,'Population: 9,944,201 (July 2006 est.)
Age structure:
0-14 years: 47.9% (male 2,396,393/female
2,369,261)
15-64 years: 49.3% (male 2,355,940/female
2,550,535)
65 years and over: 2.7% (male 1 07,665/female
164,407) (2006 est.)
Median age:
total: 16 years
male: 15.3 years
female: 16.6 years (2006 est.)
Population growth rate: 2.93% (2006 est.)
Birth rate: 45.73 births/1 ,000 population (2006 est.
Death rate: 1 6.38 deaths/1 ,000 population
(2006 est.)
Net migration rate: -0.11 migrant(s)/1,000
population (2006 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.66 male(s)/female
total population: 0.96 male(s)/female (2006 est.)
Infant mortality rate:
total: 91 .45 deaths/1 ,000 live births
male: 100.12 deaths/1 ,000 live births
female: 82.43 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 47.52 years
male: 45.88 years
female: 49.21 years (2006 est.)
Total fertility rate: 6.25 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 4.8% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 200,000
(2003 est.)
HIV/AIDS - deaths: 1 8,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterbome diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever
vectorbome disease: malaria
water contact disease: schistosomiasis
respiratory disease: meningococcal meningitis (2004)
Nationality:
noun: Chadian(s)
adjective: Chadian
Ethnic groups: 200 distinct groups; in the north and
center: Arabs, Gorane (Toubou, Daza, Kreda),
Zaghawa, Kanembou, Ouaddai, Baguirmi, Hadjerai,
Fulbe, Kotoko, Hausa, Boulala, and Maba, most of
whom are Muslim; in the south: Sara (Ngambaye,
Mbaye, Goulaye), Moundang, Moussei, Massa, most
of whom are Christian or animist; about 1 ,000 French
citizens live in Chad
Religions: Muslim 51%, Christian 35%, animist 7%,
other 7%
Languages: French (official), Arabic (official), Sara
(in south), more than 120 different languages and
dialects
Literacy:
definition: age 1 5 and over can read and write French
or Arabic
total population: 47.5%
male: 56%
female: 39.3% (2003 est.)
Population: 5,900,754
note: includes 166,510 non-nationals (July 2006 est.)
Age structure:
0-14 years: 33.6% (male 1,012,748/female 969,978)
15-64 years: 62.2% (male 1 ,891 ,643/female
1,778,621)
65 years and over: 4.2% (male 1 21 ,566/female
126,198) (2006 est.)
y
327
Libya (continued)
Median age:
total: 23 years
male: 23.1 years
female: 22.9 years (2006 est.)
Population growth rate: 2.3% (2006 est.)
Birth rate: 26.49 births/1 ,000 population (2006 est.)
Death rate: 3.48 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 0.96 male(s)/female
total population: 1 .05 male(s)/female (2006 est.)
Infant mortality rate:
total: 23.71 deaths/1,000 live births
male: 25.99 deaths/1 ,000 live births
female: 21 .32 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 76.69 years
male: 74.46 years
female: 79.02 years (2006 est.)
Total fertility rate: 3.28 children born/woman
(2006 est.)
HIV/AIDS • adult prevalence rate: 0.3% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 10,000
(2001 est.)
HIV/AIDS - deaths: NA
Major infectious diseases:
degree of risk: intermediate
food or waterborne diseases: bacterial diarrhea,
hepatitis A, and typhoid fever
vectorborne diseases: may be a significant risk in
some locations during the transmission season
(typically April through October) (2004)
Nationality:
noun: Libyan(s)
adjective: Libyan
Ethnic groups: Berber and Arab 97%, Greeks,
Maltese, Italians, Egyptians, Pakistanis, Turks,
Indians, Tunisians
Religions: Sunni Muslim 97%
Languages: Arabic, Italian, English, all are widely
understood in the major cities
Literacy:
definition: age 15 and over can read and write
total population: 82.6%
male: 92.4%
female: 72% (2003 est.)','3c86e9408c86d73708217050e6e077c7ffb530771bb1f9814c547aa80f12a363','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('13ef7559a273e8b83e43b35e796d64f7fe1fb5a8a0a83dc324ba8a3130c4cd73',2007,'CN','China','people-and-society',365,'Population: 1 ,31 3,973,71 3 (July 2006 est.)
Age structure:
0-14 years: 20.8% (male 145,461 ,833/female
128,445,739)
15-64 years: 71 .4% (male 482,439,1 15/female
455,960,489)
65 years and over: 7.7% (male 48,562,635/female
53,103,902) (2006 est.)
Median age:
total: 32.7 years
male: 32.3 years
female: 33.2 years (2006 est.)
Population growth rate: 0.59% (2006 est.)
Birth rate: 13.25 births/1 ,000 population (2006 est.)
Death rate: 6.97 deaths/1 ,000 population (2006 est.)
Net migration rate: -0.39 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1.12 male(s)/female
under 15 years: 1 .13 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 0.91 male(s)/female
total population: 1 .06 male(s)/female (2006 est.)
Infant mortality rate:
total: 23.1 2 deaths/1 ,000 live births
male: 20.6 deaths/1 ,000 live births
female: 25.94 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 72.58 years
male: 70.89 years
female: 74.46 years (2006 est.)
Total fertility rate: 1 .73 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0. 1 % (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 840,000
(2003 est.)
HIV/AIDS - deaths: 44,000 (2003 est.)
Nationality:
noun: Chinese (singular and plural)
adjective: Chinese
Ethnic groups: Han Chinese 91 .9%, Zhuang,
Uygur, Hui, Yi, Tibetan, Miao, Manchu, Mongol, Buyi,
Korean, and other nationalities 8.1%
Religions: Daoist (Taoist), Buddhist, Christian
3%-4%, Muslim 1%-2%
note: officially atheist (2002 est.)
Languages: Standard Chinese or Mandarin
(Putonghua, based on the Beijing dialect), Yue
(Cantonese), Wu (Shanghaiese), Minbei (Fuzhou),
Minnan (Hokkien-Taiwanese), Xiang, Gan, Hakka
dialects, minority languages (see Ethnic groups entry)
Literacy:
definition: age 15 and over can read and write
total population: 90.9%
male: 95.1%
female: 86.5% (2002)
v e r n m e n t
Country name:
conventional long form: People''s Republic of China
conventional short form: China
local long form: Zhonghua Renmin Gongheguo
local short form: Zhongguo
abbreviation: PRC
Government type: Communist state
Capital: Beijing
Administrative divisions: 23 pnvinces (sheng,
singular and plural), 5 autonomous regions (zizhiqu,
singular and plural), and 4 municipalities (shi, singular
and plural)
provinces: Anhui, Fujian, Gansu, Guangdong,
Guizhou, Hainan, Hebei, Heilongjiang, Henan, Hubei,
Hunan, Jiangsu, Jiangxi, Jilin, Liaoning, Qinghai,
Shaanxi, Shandong, Shanxi, Sichuan, Yunnan,
Zhejiang; (see note on Taiwan)
autonomous regions: Guangxi, Nei Mongol, Ningxia,
Xinjiang, Xizang (Tibet)
municipalities: Beijing, Chongqing, Shanghai, Tianjin
nofe: China considers Taiwan its 23rd province; see
separate entries for the special administrative regions
of Hong Kong and Macau
Independence: 221 BC (unification under the Qin or
Ch''in Dynasty); 1 January 1912 (Manchu Dynasty
replaced by a Republic); 1 October 1949 (People''s
Republic established)
National holiday: Anniversary of the Founding of the
People''s Republic of China, 1 October (1949)
Constitution: most recent promulgation 4 December
1982
Legal system: based on civil law system; derived
from Soviet and continental civil code legal principles;
legislature retains power to interpret statutes;
constitution ambiguous on judicial review of
legislation; has not accepted compulsory ICJ
jurisdiction
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President HU Jintao (since 15 March
2003) and Vice President ZENG Qinghong (since
15 March 2003)
head of government: Premier WEN Jiabao (since
16 March 2003); vice premiers HUANG Ju (since
17 March 2003), WU Yi (17 March 2003), ZENG
Peiyan (since 17 March 2003), and HUI Liangyu
(since 17 March 2003)
cabinet: State Council appointed by the National
People''s Congress (NPC)
elections: president and vice president elected by the
National People''s Congress for five-year terms;
elections last held 15-17 March 2003 (next to be held
mid-March 2008); premier nominated by the
president, confirmed by the National People''s
Congress
election results: HU Jintao elected president by the
10th National People''s Congress with a total of 2,937
votes (four delegates voted against him, four
abstained, and 38 did not vote); ZENG Qinghong
elected vice president by the 10th National People''s
Congress with a total of 2,578 votes (177 delegates
voted against him, 190 abstained, and 38 did not
vote); two seats were vacant
Legislative branch: unicameral National People''s
Congress or Quanguo Renmin Daibiao Dahui (2,985
seats; members elected by municipal, regional, and
provincial people''s congresses to serve five-year
terms)
elections: last held December 2002-February 2003
(next to be held late 2007-February 2008)
election results: percent of vote - NA; seats - NA
Judicial branch: Supreme People''s Court (judges
appointed by the National People''s Congress); Local
Peoples Courts (comprise higher, intermediate, and
local courts); Special Peoples Courts (primarily
military, maritime, and railway transport courts)
Political parties and leaders: Chinese Communist
Party or CCP [HU Jintao, general secretary of the
Central Committee]; eight registered small parties
controlled by CCP
Political pressure groups and leaders: no
substantial political opposition groups exist, although
the government has identified the Falungong spiritual
movement and the China Democracy Party as
subversive grcjps
International organization participation: AfDB.
APEC, APT, ARF, AsDB, ASEAN (dialogue partner),
BCIE, BIS, CDB, EAS, FAO, G-77, IAEA. IBRD,
ICAO, ICC, ICRM, IDA, IFAD, IFC, IFRCS. IHO. ILO.
IMF, IMO, Interpol, IOC, IOM (observer), ISO, ITU.
LAIA (observer), MIGA, MINURSO, MONUC. NAM
(observer), NSG, OAS (observer), ONUB. OPCW,
PCA, PIF (partner), SAARC (observer), SCO. UN. UN
Security Council, UNAMSIL, UNCTAD, UNESCO.
UNHCR, UNIDO, UNITAR, UNMEE, UNMIL. UNMIS.
UNMOVIC, UNOCI, UNTSO, UPU, WCO, WHO
WIPO, WMO, WToO, WTO, ZC
Diplomatic representation in the US:
chief of mission: Ambassador ZHOU Wenzhong
chancery: 2300 Connecticut Avenue NW,
Washington, DC 20008
telephone: [1] (202) 328-2500
FAX: [1](202)328-2582
consulate(s) general: Chicago, Houston, Los
Angeles, New York, San Francisco
consulate(s): Los Angeles
Diplomatic representation from the US:
chief of mission: Ambassador Clark T RANDT, Jr
embassy: Xiu Shui Bei Jie 3. 100600 Beijing
mailing address: PSC 461 , Box 50, FPO AP
96521-0002
telephone. [86] (10) 6532-3831
FAX [86] (10) 6532-3178
consulate(s) general: Chengdu, Guangzhou, Hong
Kong and Macau, Shanghai. Shenyang
Flag description: red with a large yellow
five-pointed star and four smaller yellow five-pointed
stars (arranged in a vertical arc toward the middle of
the flag) in the upper hoist-side corner
119
China (continued)
Population: 6,940,432 (Juiy 2006 est.)
Age structure:
0-14 years: 13.5% (male 488,607/female 445,593)
15-64 years: 73.7% (male 2,495,679/female
2,620,336)
65 years and over: 12.8% (male 41 3,031 /female
477,186) (2006 est.)
Median age:
total: 40.7 years
male: 40.4 years
female: 40.9 years (2006 est.)
Population growth rate: 0.59% (2006 est.)
Birth rate: 7.29 births/1 ,000 population (2006 est.)
Death rate: 6.29 deaths/1 ,000 population (2006 est.)
Net migration rate: 4.89 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .08 male(s)/female
under 15 years: 1.1 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.87 male(s)/female
total population: 0.96 male(s)/female (2006 est.)
Infant mortality rate:
total: 2.95 deaths/1 ,000 live births
male: 3.13 deaths/1 ,000 live births
female: 2.75 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 81 .59 years
male: 78.9 years
female: 84.5 years (2006 est.)
Total fertility rate: 0.95 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.1% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 2,600
(2003 est.)
HIV/AIDS • deaths: less than 200 (2003 est.)
Nationality:
noun: Chinese/Hong Konger
adjective: Chinese/Hong Kong
Ethnic groups: Chinese 95%, other 5%
Religions: eclectic mixture of local religions 90%,
Christian 10%
Languages: Chinese (Cantonese), English; both are
official
253
Hong Kong (continued)
Literacy:
definition: age 1 5 and over has ever attended school
total population: 93.5° o
male: 96. 9° o
female: 89.6% (2002)
Population: 15,233,244 (July 2006 est.)
Age structure:
0-14 years: 23% (male 1 ,792,685/female 1 ,717,294)
15-64 years: 68.8% (male 5,122,027/female
5,357,819)
65 years and over: 8.2% (male 438,541/female
804,878) (2006 est.)
Median age:
total: 28.8 years
male: 27.2 years
female: 30.5 years (2006 est.)
Population growth rate: 0.33% (2006 est.)
Birth rate: 16 births/1,000 population (2006 est.)
Death rate: 9.42 deaths/1 ,000 population (2006 est.)
Net migration rate: -3.33 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.55 male(s)/female
total population: 0.93 male(s)/female (2006 est.)
Infant mortality rate:
total: 28.3 deaths/1 ,000 live births
male: 32.88 deaths/1 ,000 live births
female: 23.45 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 66.89 years
male. 61.56 years
female: 72.52 years (2006 est.)
Total fertility rate: 1 .89 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.2% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 16,500
(2001 est.)
HIV/AIDS - deaths: less than 200 (2003 est.)
Nationality:
noun: Kazakhstani(s)
adjective: Kazakhstani
Ethnic groups: Kazakh (Qazaq) 53.4%, Russian
30%, Ukrainian 3.7%, Uzbek 2.5%, German 2.4%,
Tatar 1.7%, Uygur 1.4%, other 4.9% (1999 census)
Religions: Muslim 47%, Russian Orthodox 44%,
Protestant 2%, other 7%
Languages: Kazakh (Qazaq, state language)
64.4%, Russian (official, used in everyday business,
designated the "language of interethnic
communication") 95% (2001 est.)
Literacy:
definition: age 15 and over can read and write
total population: 98.4%
male: 99.1%
female: 97.7% (1999 est.)
Population: 5.21 3.898 (July 2006 est.)
Age structure:
0-14 years: 30.9% (male 821 ,976/female 789,687)
15-64 years: 62.9% (male 1 ,607,396/female
1,669,612)
65 years and over: 6.2% (male 126.847/female
198,380) (2006 est.)
Median age:
total: 23.6 years
male: 22.8 years
female: 24.5 years (2006 est.)
Population growth rate: 1 .32% (2006 est.)
Birth rate: 22.8 births/1 ,000 population (2006 est.)
Death rate: 7.08 deaths/1 ,000 population (2006 est.)
Net migration rate: -2.5 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.64 male(s)/female
total population: 0.96 male(s)/female (2006 est.)
Infant mortality rate:
total: 34.49 deaths/1 ,000 live births
male: 39.72 deaths/1 ,000 live births
female: 28.98 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 68.49 years
male: 64.48 years
female: 72.7 years (2006 est.)
Total fertility rate: 2.69 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: less than 0.1%
(2001 est.)
HIV/AIDS - people living with HIV/AIDS: 3,900
(2003 est.)
HIV/AIDS - deaths: less than 200 (2003 est.)
Nationality:
noun: Kyrgyzstani(s)
adjective: Kyrgyzstani
Ethnic groups: Kyrgyz 64.9%, Uzbek 13.8%,
Russian 12.5%, Dungan 1.1%, Ukrainian 1%, Uygur
1%, other 5.7% (1999 census)
Religions: Muslim 75%, Russian Orthodox 20%,
other 5%
Languages: Kyrgyz (official). Russian (official)
Literacy:
definition: age 1 5 and over can read and write
total population: 98.7° o
male: 99.3%
female: 98.1% (1999 est.)
Population: 2,832,224 (July 2006 est.)
Age structure:
0-14 years: 27.9% (male 402,448/female 387,059)
15-64 years: 68.4% (male 967,546/female 969,389)
65 years and over: 3.7% (male 45,859/female
59,923) (2006 est.)
Median age:
total: 24.6 years
male: 24.3 years
female: 25 years (2006 est.)
Population growth rate: 1 .46% (2006 est.)
Birth rate: 21 .59 births/1 ,000 population (2006 est.)
Death rate: 6.95 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1. 04 male(s)/female
75-64 years: 1 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 1 male(s)/female (2006 est.)
Infant mortality rate:
total: 52.12 deaths/1 ,000 live births
male: 55.51 deaths/1 ,000 live births
female: 48.57 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 64.89 years
male: 62.64 years
female: 67.25 years (2006 est.)
Total fertility rate: 2.25 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: less than 0.1%
(2003 est.)
HIV/AIDS - people living with HIV/AIDS: less than
500 (2003 est)
HIV/AIDS - deaths: less than 200 (2003 est.)
Nationality:
noun: Mongolian(s)
adjective: Mongolian
Ethnic groups: Mongol (mostly Khalkha) 94.9%,
Turkic (mostly Kazakh) 5%, other (including Chinese
and Russian) 0.1% (2000)
Religions: Buddhist Lamaist 50%, none 40%,
Shamanist and Christian 6%, Muslim 4% (2004)
Languages: Khalkha Mongol 90%, Turkic, Russian
(1999) *
Literacy:
definition: age 1 5 and over can read and write
total population: 97.8%
male: 98%
female: 97.5% (2002)','ee39dbc5873ceaf540f49d504bfdbd98865474249fd839b4408e25de817a2dae','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a79c3581299f7a09770496f28de9b0743d00ce189ad91fca3b5cf7e83ac8e29',2007,'CX','Christmas Island','people-and-society',372,'Population: 361 (July 2006 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA (2006 est.)
Population growth rate: 0% (2006 est.)
Birthrate: NA
Death rate: NA
Net migration rate: NA
Sex ratio: NA
Infant mortality rate:
total: NA
male: NA
female: NA
Life expectancy at birth:
total population: HA
male: NA
female: NA
Total fertility rate: NA
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Christmas Islander(s)
adjective: Christmas Island
Ethnic groups: Chinese 70%, European 20%,
Malay 10%
note: no indigenous population (2001)
Religions: Buddhist 36%. Muslim 25%, Christian
18%, other 21% (1997)
Languages: English (official). Chinese, Malay
Literacy: NA
People - note: the Australian Bureau of Statistics
reports a population of 1 ,520 as of the 2005','4b56501baf9cb6e10470f450a6cd56e9f7a85b8795ec7341224a609e5a4cf33e','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afba6071e6a42e58671778bb8a4bf834132e25dceefe0cb3711bda6c23bfee23',2007,'FR','France','people-and-society',380,'Population: 628 (July 2006 est.)
Age structure:
0-74 years: N A
15-64 years: NA
65 years and over: NA (2006 est.)
Population growth rate: 0% (2006 est.)
Birthrate: NA
Death rate: NA deaths/1 ,000 population
Net migration rate: NA
Infant mortality rate:
total: NA
male: NA
female: NA
Life expectancy at birth:
total population: NA
male: NA
female: NA
Total fertility rate: NA
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Cocos Islander(s)
adjective: Cocos Islander
Ethnic groups: Europeans, Cocos Malays
Religions: Sunni Muslim 80V other 20°o (2002 est.)
Languages: Malay (Cocos dialect), English
Literacy: NA
Population: 2,967 (July 2006 est.)
Age structure:
0-74 years: N A
15-64 years: NA
65 years and over: NA (2006 est.)
Population growth rate: 2.44% (2006 est.)
Birth rate: NA births/1 ,000 population (2006 est.)
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
(2006 est.)
Infant mortality rate:
total: NA
male: NA
female: NA
Life expectancy at birth:
total population: NA
male: NA
female: NA
Total fertility rate: NA children born/woman
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Falkland Islander(s)
adjective: Falkland Island
Ethnic groups: British
Religions: primarily Anglican, Roman Catholic,
United Free Church, Evangelist Church, Jehovah''s
Witnesses, Lutheran, Seventh-Day Adventist
Languages: English
Literacy: NA
Population: no indigenous inhabitants
note: in 2002, there were 1 45 researchers whose
numbers vary from winter (July) to summer (January)
(July 2006 est.)
Population: 10,175,014 (July 2006 est.)
Age structure:
0-14 years: 24.6% (male 1 ,293,235/female
1,212,994)
15-64 years: 68.6% (male 3,504,283/female
3,478,268)
65 years and over: 6.7% (male 327,521/female
358,713) (2006 est.)
Median age:
total: 27.8 years
male: 27.3 years
female: 28.3 years (2006 est.)
Population growth rate: 0.99% (2006 est.)
Birth rate: 1 5.52 births/1 ,000 population (2006 est.)
Death rate: 5. 13 deaths/1 ,000 population (2006 est.)
Net migration rate: -0.5 migrantfs)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.91 male(s)/female
total population: 1 .02 male(s)/female (2006 est.)
•
557
Tunisia (continued)
Infant mortality rate:
total: 23.84 deaths/1 ,000 live births
male: 26.7 deaths/1 ,000 live births
female: 20.77 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 75.12 years
male: 73.4 years
female: 76.96 years (2006 est.)
Total fertility rate: 1 .74 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: less than 0.1%
(2005 est.)
HIV/AIDS - people living with HIV/AIDS: 1 ,000
(2003 est.)
HIV/AIDS - deaths: less than 200 (2003 est.)
Major infectious diseases:
degree of risk: intermediate
food or waterbome diseases: bacterial diarrhea and
hepatitis A
vectorborne diseases: may be a significant risk in
some locations during the transmission season
(typically April through November) (2005)
Nationality:
noun: Tunisian(s)
adjective: Tunisian
Ethnic groups: Arab 98%, European 1%, Jewish
and other 1 %
Religions: Muslim 98%, Christian 1%, Jewish and
other 1%
Languages: Arabic (official and one of the
languages of commerce), French (commerce)
Literacy:
definition: age 15 and over can read and write
total population: 74.3%
male: 83.4%
female: 65.3% (2004 est.)
Population: 70,413.958 (July 2006 est.)
Age structure:
0-14 years: 25.5% (male 9,1 33,226/female
8,800,070)
15-64 years: 67.7% (male 24,21 8,277/female
23,456,761)
65 years and over: 6.8% (male 2,198,073/female
2,607,551) (2006 est.)
Median age:
total: 28.1 years
male: 27.9 years
female: 28.3 years (2006 est.)
Population growth rate: 1 .06% (2006 est.)
Birth rate: 16.62 births/1,000 population (2006 est.)
Death rate: 5.97 deaths/1 ,000 population (2006 est.
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at binh: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 1 .02 male(s)/female (2006 est.)
Infant mortality rate:
total: 39.69 deaths/1 ,000 live births
male: 43.27 deaths/1 ,000 live births
female: 35.93 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 72.62 years
mate: 70.18 years
female: 75.18 years (2006 est.)
Total fertility rate: 1 .92 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: less than 0.1% •
note - no country specific models provided (2001 est.
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
560
Turkey (continued)
Nationality:
noun: Turk(s)
adjective: Turkish
Ethnic groups: Turkish 80%, Kurdish 20% (estimated)
Religions: Muslim 99.8% (mostly Sunni), other 0.2%
(mostly Christians and Jews)
Languages: Turkish (official), Kurdish, Dimli (or
Zaza), Azeri, Kabardian
note: there is also a substantial Gagauz population in
the Europe part of Turkey
Literacy:
deiinition: age 15 and over can read and write
total population: 86.5%
male: 94.3%
female: 78.7% (2003 est.)
Population: 60,609,153 (July 2006 est.)
Age structure:
0-14 years: 17.5% (male 5,417,663/female
5,161,714)
15-64 years: 66.8% (male 20,476,571 /female
19,988,959)
65 years and over: 15.8% (male 4,087,020/female
5,477,226) (2006 est.)
Median age:
total: 39.3 years
male: 38.2 years
female: 40.4 years (2006 est.)
Population growth rate: 0.28% (2006 est.)
Birth rate: 10.71 births/1,000 population (2006 est.)
Death rate: 10.13 deaths/1 ,000 population
(2006 est.)
Net migration rate: 2.18 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.98 male(s)/female (2006 est.)
Infant mortality rate:
total: 5.08 deaths/1 ,000 live births
male: 5.67 deaths/1 ,000 live births
female: 4.47 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 78.54 years
male: 76.09 years
female: 81 .13 years (2006 est.)
Total fertility rate: 1 .66 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.2% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 51 ,000
(2001 est.)
HIV/AIDS ■ deaths: less than 500 (2003 est.)
Nationality:
noun: Briton (s), British (collective plural)
adjective: British
Ethnic groups: white (of which English 83.6%,
Scottish 8.6%, Welsh 4.9%, Northern Irish 2.9%)
92.1%, black 2%, Indian 1.8%, Pakistani 1.3%, mixed
1.2%, other 1.6% (2001 census)
Religions: Christian (Anglican. Roman Catholic,
Presbyterian, Methodist) 71.6%, Muslim 2.7%, Hindu
1%, other 1.6%, unspecified or none 23.1% (2001
census)
579
United Kingdom (continued)
Languages: English, Welsh (about 26% of the
oopulation of Wales). Scottish form of Gaelic (about
50.000 in Scotland)
Literacy:
definition: age 1 5 and over has completed five or more
years of schooling
total population: 99%
male: 99%
female: 99°o (2003 est.)','b0e33f57ffe39be568291fc59983014fb97175748d489afc731b8d2da90f1bbe','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('726d971f35f0e0b971383fde8c3bf75bb3b6f2daf4b608bc500bd256697c08b5',2007,'CO','Colombia','people-and-society',391,'Population: 43,593,035 (July 2006 est.)
Age structure:
0-14 years: 30.3% (male 6.683,079/female
6,528,563)
15-64 years: 64.5% (male 13.689.384/female
14,416,439)
65 years and over: 5.2% (male 996,022/female
1,279,548) (2006 est.)
Median age:
total. 26 3 years
male: 25.4 years
female: 27.2 years (2006 est.)
Population growth rate: 1 ,46% (2006 est )
Birth rate: 20.48 births/1.000 population (2006 I
125
Colombia (continued)
Death rate: 5.58 deaths/1 ,000 population (2006 est.)
Net migration rate: -0.3 migrant(s)/1 ,000 population
12006 est.)
Sex ratio:
at birth: 1 .03 male(s)/temale
under 15 years: 1 .02 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.78 male(s)/female
total population: 0.96 male(s)/female (2006 est.)
Infant mortality rate:
total: 20.35 deaths/1 ,000 live births
male: 24.25 deaths/1 ,000 live births
female: 16.31 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 71 .99 years
male: 68.15 years
female: 75.96 years (2006 est.)
Total fertility rate: 2.54 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.7% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 190,000
(2003 est.)
HIV/AIDS - deaths: 3,600 (2003 est.)
Nationality:
noun: Colombian(s)
adjective: Colombian
Ethnic groups: mestizo 58%, white 20%, mulatto
14%, black 4%, mixed black-Amerindian 3%,
Amerindian 1%
Religions: Roman Catholic 90%, other 10%
Languages: Spanish
Literacy:
definition: age 15 and over can read and write
total population: 92.5%
male: 92.4%
female: 92.6% (2003 est.)
Population: 3,191,319 (July 2006 est.)
Age structure:
0-14 years: 30.3% (male 492,403/female 472,996)
15-64 years: 63.4% (male 1 ,025,898/female 998,926)
65 years and over: 6.3% (male 94, 1 22/female
106,974) (2006 est.)
Median age:
tote/; 26. 1 years
male: 25.8 years
female: 26.5 years (2006 est.)
Population growth rate: 1 .6% (2006 est.)
Birth rate: 21 .74 births/1 ,000 population (2006 est.)
Death rate: 5.36 deaths/1 ,000 population (2006 est.)
Net migration rate: -0.4 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.88 male(s)/female
total population:]. 02 male(s)/female (2006 est.)
Infant mortality rate:
total: 16.37 deaths/1 ,000 live births
male: 17.75 deaths/1 ,000 live births
female: 14.92 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 75.22 years
male: 72.68 years
female: 77.87 years (2006 est.)
Total fertility rate: 2.68 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.9% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 16,000
(2003 est.)
HIV/AIDS - deaths: less than 500 (2003 est.)
Nationality:
noun: Panamanian(s)
adjective: Panamanian
Ethnic groups: mestizo (mixed Amerindian and
white) 70%, Amerindian and mixed (West Indian)
14%, white 10%, Amerindian 6%
Religions: Roman Catholic 85%, Protestant 15%
Languages: Spanish (official), English 14%: note -
many Panamanians bilingual
Literacy:
definition: age 1 5 and over can read and write
total population: 92.6%
male: 93.2%
female: 91.9% (2003 est.)','0610310b9434cba47d58d8c2f4f9eaacc6b69e50226f32f404bbc0dd0262c8f6','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a92978ee7962de4cf8bdd3dbe37ff9125d83f740a1b921fe59eed30074f6c7ff',2007,'YT','Mayotte','people-and-society',400,'Population: 690,948 (July 2006 est.)
Age structure:
0-14 years: 42.7% (male 148.009/female 147,038)
15-64 years: 54.3% (male 185,107/female 190,139)
65 years and over: 3% (male 9.672/female 10,983)
(2006 est.)
Median age:
tote/; 18.6 years
male: 18.4 years
female: 18.9 years (2006 est.)
Population growth rate: 2.87% (2006 est.)
Birth rate: 36.93 births/1,000 population (2006 est.)
Death rate: 8.2 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.88 male(s)/female
total population: 0.99 male(s)/female (2006 est.)
Infant mortality rate:
total: 72.85 deaths/1 ,000 live births
male: 81 .27 deaths/1 ,000 live births
female: 64.19 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 62.33 years
male: 60 years
female: 64.72 years (2006 est.)
Total fertility rate: 5.03 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.12%
(2001 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Comoran(s)
adjective: Comoran
Ethnic groups: Antalote, Cafre, Makoa, Oimatsaha,
Sakalava
Religions: Sunni Muslim 98%, Roman Catholic 2%
Languages: Arabic (official), French (official),
Shikomoro (a blend of Swahili and Arabic)
Literacy:
definition: age 1 5 and over can read and write
total population: 56.5%
male: 63.6%
female: 49.3% (2003 est.)
G o v e r n m e
Country name:
conventional long form: Union of the Comoros
conventional short form: Comoros
local long form: Union des Comores
local short form: Comores
Government type: independent republic
Capital: Moroni
Administrative divisions: 3 islands and 4
municipalities*; Grande Comore (Njazidja), Anjouan
(Nzwani), Domoni*, Fomboni*, Moheli (Mwali),
Moroni*, Moutsamoudou*
Independence: 6 July 1975 (from France)
National holiday: Independence Day, 6 July (1975)
Constitution: 23 December 2001
Legal system: French and Sharia (Islamic) law in a
new consolidated code
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: President AZALI Assoumani (since
26 May 2002); note - following a 1999 coup AZALI
was appointed president; in January 2002 he resigned
his position to run in the 14 April 2002 presidential
elections; Prime Minister Hamada Madi BOLERO was
appointed interim president until replaced again by
AZALI in May 2002 when BOLERO was appointed
Minister of External Defense and Territorial Security;
the president is both the chief of state and the head of
Population: 62,660,551
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS; this
can result in lower life expectancy, higher infant mortality
and death rates, lower population and growth rates, and
changes in the distribution of population by age and sex
than would otherwise be expected (July 2006 est.)
Age structure:
0-14 years: 47 .4% (male 14,906,488/female
14,798,210)
15-64 years: 50.1% (male 1 5,597,353/female
15,793,350)
65 years and over: 2.5% (male 632, 1 43/female
933,007) (2006 est.)
Median age:
total: 16.2 years
male: 16 years
female: 16.4 years (2006 est.)
Population growth rate: 3.07% (2006 est.)
Birth rate: 43.69 births/1 ,000 population (2006 est.)
Death rate: 1 3.27 deaths/1 ,000 population
(2006 est.)
Net migration rate: 0.23 migrant(s)/1,000
population
note: fighting between the Congolese Government
and Uganda- and Rwanda-backed Congolese rebels
spawned a regional war in DRC in August 1 998, which
left 2.33 million Congolese internally displaced and
caused 412,000 Congolese refugees to flee to
surrounding countries (2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.99 male(s)/female (2006 est.)
Infant mortality rate:
total: 88.62 deaths/1 ,000 live births
male: 96.9 deaths/1 ,000 live births
female: 80.1 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 51 .46 years
male: 50.01 years
female: 52.94 years (2006 est.)
Total fertility rate: 6.45 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 4.2% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 1.1 million
(2003 est.)
HIV/AIDS - deaths: 1 00,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterbome diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever
vectorborne diseases: malaria, plague, and African
trypanosomiasis (sleeping sickness) are high risks in
some locations
water contact disease: schistosomiasis (2004)
Nationality:
noun: Congolese (singular and plural)
adjective: Congolese or Congo
Ethnic groups: over 200 African ethnic groups of
which the majority are Bantu; the four largest tribes -
Mongo. Luba, Kongo (all Bantu), and the
Mangbetu-Azande (Hamitic) make up about 45% of
the population
Religions: Roman Catholic 50%, Protestant 20%,
Kimbanguist 10%, Muslim 10%, other syncretic sects
and indigenous beliefs 10%
Languages: French (official), Lingala (a lingua
franca trade language), Kingwana (a dialect of
Kiswahili or Swahili), Kikongo, Tshiluba
Literacy:
definition: age 1 5 and over can read and write French,
Lingala, Kingwana, or Tshiluba
total population: 65.5%
male: 76.2%
female: 55.1% (2003 est.)
Population: 201 ,234 (July 2006 est.)
Age structure:
0-14 years: 46% (male 46,51 2/female 46,067)
15-64 years: 52.3% (male 56,899/female 48,274)
65 years and over: 1 .7% (male 1 ,756/female 1 ,726)
(2006 est.)
Median age:
total: 1 7 years
male: 18 years
female: 16 years (2006 est.)
Population growth rate: 3.77% (2006 est.)
Birth rate: 40.95 births/1 ,000 population (2006 est.)
Death rate: 7.7 deaths/1 ,000 population (2006 est.)
Net migration rate: 4.48 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1.18 male(s)/female
65 years and over: 1 .02 male(s)/female
total population: 1 .1 male(s)/female (2006 est.)
Infant mortality rate:
total: 60.76 deaths/1 ,000 live births
male: 66.76 deaths/1 ,000 live births
female: 54.58 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 61 .76 years
male: 59.57 years
female: 64.02 years (2006 est.)
Total fertility rate: 5.79 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS • deaths: NA
Nationality:
noun: Mahorais (singular and plural)
adjective: Mahoran
Ethnic groups: NA
Religions: Muslim 97%, Christian (mostly Roman
Catholic)
Languages: Mahorian (a Swahili dialect), French
(official language) spoken by 35% of the population
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%','3d4e18d95578c735a213784a58cb90fbb161a1743062d2905db221a755db851c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fdda575b252378fe7a8637bf4e78ff66a352778298ac9daf708a68374c5dc626',2007,'CK','Cook Islands','people-and-society',411,'Population: 21 ,388 (July 2006 est.)
Age structure:
0-74 years: N A
15-64 years: NA
65 years and over: NA (2006 est.)
Population growth rate: NA
Birthrate: NA
Death rate: NA deaths/1 ,000 population
Sex ratio: NA
infant mortality rate:
total: NA
male: NA
female: NA
Life expectancy at birth:
total population: NA
male: NA
female: NA
Total fertility rate: NA children born/woman
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS ■ deaths: NA
Nationality:
noun: Cook Islander(s)
adjective: Cook Islander
Ethnic groups: Cook Island Maori (Polynesian)
87.7%, part Cook Island Maori 5.8%, other 6.5%
(2001 census)
Religions: Cook Islands Christian Church 55.9%,
Roman Catholic 16.8%, Seventh-Day Adventists
7.9%, Church of Latter Day Saints 3.8%, other
Protestant 5.8%, other 4.2%, unspecified 2.6%, none
3% (2001 census)
Languages: English (official), Maori
Literacy:
definition: NA
total population: 95%
male: NA%
female: NA%
Population: no indigenous inhabitants
note: there is a staff of three to four at the
meteorological station (2005 est.)
Population: no indigenous inhabitants
note: public entry is by special-use permit from US
Fish and Wildlife Service only and generally restricted
to scientists and educators; visited annually by US
Fish and Wildlife Service
588
United States Pacific Island
Wildlife Refuges (continued)
Johnston Atoll: in previous years, an average of 1 ,100
US military and civilian contractor personnel were
present; as of May 2005 all US government personnel
had left the island
Midway Islands: approximately 40 people make up
the staff of US Fish and Wildlife Service and their
services contractor living at the atoll
Palmyra Atoll: four to 20 Nature Conservancy and US
Fish and Wildlife staff','3687ee810aeb5b1868511ebbe2c25f0e7ef383b776e4a0466d0fe22d7c87ff8b','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bfb700610ca0d0e9ef2fa4a7ef9cd5f41902641c8146dcf47189e3fb2d6224f',2007,'CR','Costa Rica','people-and-society',420,'Population: 4,075,261 (July 2006 est.)
Age structure:
0-14 years: 28.3% (male 590,261 /female 563,196)
15-64 years: 66% (male 1 ,359,750/female 1 ,329,346)
65 years and over: 5.7% (male 1 08,041 /female
124,667) (2006 est.)
Median age:
total: 26.4 years
male: 26 years
female: 26.9 years (2006 est.)
Population growth rate: 1 .45% (2006 est.)
Birth rate: 18.32 births/1 ,000 population (2006 est.)
Death rate: 4.36 deaths/1 ,000 population (2006 est.)
Net migration rate: 0.49 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at binh: 1 .05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.87 male(s)/female
total population:]. 02 male(s)/female (2006 est.)
Infant mortality rate:
total: 9.7 deaths/1 ,000 live births
male: 10.58 deaths/1 ,000 live births
female: 8.77 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 77.02 years
male: 74.43 years
female: 79.74 years (2006 est.)
Total fertility rate: 2.24 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.6% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 12,000
(2003 est.)
138
Costa Rica (continued)
HIV/AIDS - deaths: 900 (2003 est.)
Nationality:
noun: Costa Rican(s)
adjective: Costa Rican
Ethnic groups: white (including mestizo) 94%, black
3%, Amerindian 1%, Chinese 1%, other 1%
Religions: Roman Catholic 76.3%, Evangelical
13.7%, Jehovah''s Witnesses 1 .3%, other Protestant
0.7%, other 4.8%, none 3.2%
Languages: Spanish (official), English
Literacy:
definition: age 15 and over can read and write
total population: 96%
male: 95.9%
female: 96.1% (2003 est.)
■■■■■.■ — ,
Population: 17,654,843
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected
(July 2006 est.)
Age structure:
0-14 years: 40.8% (male 3,546,674/female
3,653,990)
15-64 years: 56.4% (male 5,024,575/female
4,939,677)
65 years and over: 2.8% (male 238,793/female
251,134) (2006 est.)
Median age:
total: 19.2 years
male: 19.4 years
female: 18.9 years (2006 est.)
Population growth rate: 2.03% (2006 est.)
Birth rate: 35.1 1 births/1,000 population (2006 est.)
Death rate: 1 4.84 deaths/1 ,000 population
(2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 0.97 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.95 male(s)/female
total population: 1 male(s)/female (2006 est.)
Infant mortality rate:
total: 89.1 1 deaths/1 ,000 live births
male: 105.73 deaths/1 ,000 live births
female: 71 .99 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 48.82 years
male: 46.24 years
female: 51 .48 years (2006 est.)
Total fertility rate: 4.5 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 7% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 570,000
(2003 est.)
HIV/AIDS - deaths: 47,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial diarrhea,
hepatitis A, and typhoid fever
vectorborne diseases: malaria, yellow fever, and
others are high risks in some locations
water contact: schistosomiasis (2004)
Nationality:
noun: Ivoirian(s)
adjective: Ivoirian
Ethnic groups: Akan 42.1%, Voltaiques or Gur
17.6%, Northern Mandes 16.5%, Krous 11%,
Southern Mandes 10%, other 2.8% (includes 130,000
Lebanese and 14,000 French) (1998)
Religions: Muslim 35-40%, indigenous 25-40%,
Christian 20-30% (2001)
note: the majority of foreigners (migratory workers)
are Muslim (70%) and Christian (20%)
Languages: French (official), 60 native dialects with
Dioula the most widely spoken
Literacy:
definition: age 15 and over can read and write
total population: 50.9%
male: 57.9%
female: 43.6% (2003 est.)
r n m e
Country name:
conventional long form: Republic of Cote d''lvoire
conventional short form: Cote d''lvoire
local long form: Republique de Cote d''lvoire
local short form: Cote d''lvoire
former: Ivory Coast
Government type: republic; multiparty presidential
regime established 1 960
Capital: Yamoussoukro; note - although
Yamoussoukro has been the official capital since
1983, Abidjan remains the commercial and
administrative center; the US, like other countries,
maintains its Embassy in Abidjan
Administrative divisions: 19 regions; Agneby.
Bating, Bas-Sassandra, Denguele, Dix-Huit
Montagnes, Fromager, Haut-Sassandra, Lacs,
Lagunes, Marahoue, Moyen-Cavally, Moyen-Comoe.
N''zi-Comoe, Savanes, Sud-Bandama, Sud-Comoe,
Vallee du Bandama, Worodougou, Zanzan
Independence: 7 August 1960 (from France)
National holiday: Independence Day, 7 August
(1960)
Constitution: new constitution adopted 4 August
2000
Legal system: based on French civil law system and
customary law; judicial review in the Constitutional
Chamber of the Supreme Court; accepts compulsory
ICJ jurisdiction, with reservations
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Laurent GBAGBO (since
26 October 2000)
head of government: Transitional Prime Minister
Charles Konan BANNY (since 7 December 2005)
cabinet: Council of Ministers appointed by the
president
elections: president elected by popular vote for a
five-year term; election last held 26 October 2000
(next to be held by October 2006); prime minister
appointed by the president
election results: Laurent GBAGBO elected president.
percent of vote - Laurent GBAGBO 59.4%, Robert
GUEI 32.7%, Francis WODIE 5.7%, other 2.2%
Legislative branch: unicameral National Assembly
or Assemblee Nationale (225 seats; members are
elected in single- and multi-district elections by direct
popular vote to serve five-year terms)
elections: elections last held 10 December 2000 with
by-elections on 14 January 2001 (next to be held by
31 October 2006)
election results: percent of vote by party - NA; seats
by party - FPI 96, PDCI-RDA 94, RDR 5, PIT 4, other
2, independents 22, vacant 2
note: a Senate is scheduled to be created in the next
full election in 2006
Judicial branch: Supreme Court or Cour Supreme
consists of four chambers: Judicial Chamber for
criminal cases, Audit Chamber for financial cases,
Constitutional Chamber for judicial review cases, and
Administrative Chamber for civil cases; there is no
legal limit to the number of members
141
Cote d'' I VOire (continued)
Political parties and leaders: Citizen''s Democratic
Union or UDCY [Eg Theodore MEL]; Democratic Party
of Cote d''lvoire-African Democratic Rally or
PDCI-RDA [Henri Konan BEDIE]; Ivorian Popular
Front or FPI [Laurent GBAGBO]; Ivorian Worker''s
Party or PIT [Francis WODIE]; Rally of the
Republicans or RDR [Alassane OUATTARA]; Union
for Democracy and Peace or UDPCI [Paul Akoto
YAO]; over 20 smaller parties
Political pressure groups and leaders: NA
International organization participation: ACCT,
ACP. AfDB, AU, CEMAC, ECOWAS, Entente, FAO,
FZ. G-24, G-77, IAEA, IBRD, ICAO, ICCt (signatory),
ICFTU, ICRM, IDA, IDB, IFAD, IFC, IFRCS, ILO, IMF,
IMO, Interpol, IOC, IOM, ITU, MIGA, NAM, OIC, OIF,
OPCW, UN, UNCTAD, UNESCO, UNHCR, UNIDO,
UPU, WADB (regional), WAEMU, WCL, WCO,
WFTU, WHO, WIPO, WMO, WToO, WTO
Diplomatic representation in the US:
chief of mission: Ambassador Daouda DIABATE
chancery: 2424 Massachusetts Avenue NW,
Washington, DC 20008
telephone: [1] (202) 797-0300
FAX; [1] (202) 244-3088
Diplomatic representation from the US:
chief of mission: Ambassador Aubrey HOOKS
embassy: Riviera Golf 01 , Abidjan
mailing address: B. P. 1866, Abidjan 01
telephone: [225] 20 21 09 79
FAX: [225] 20 22 32 59
Flag description: three equal vertical bands of
orange (hoist side), white, and green; similar to the
flag of Ireland, which is longer and has the colors
reversed - green (hoist side), white, and orange; also
similar to the flag of Italy, which is green (hoist side),
white, and red; design was based on the flag of France
Population: 5,570,129 (July 2006 est.)
Age structure:
0-14 years: 36.4% (male 1 ,031 ,897/female 994,633)
15-64 years: 60.5% (male 1 ,677,633/female
1,691,353)
65 years and over: 3.1 % (male 76,758/female
97,855) (2006 est.)
Median age:
total: 20.9 years
male: 20.5 years
female: 21 .4 years (2006 est.)
Population growth rate: 1 .89% (2006 est.)
Birthrate: 24.51 births/1 ,000 population (2006 est.)
Death rate: 4.45 deaths/1 ,000 population (2006 est.)
Net migration rate: -1.17 migrant(s)/1,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.78 male(s)/female
total population: 1 male(s)/female (2006 est.)
Infant mortality rate:
total: 28.1 1 deaths/1 ,000 live births
male: 31 .51 deaths/1 ,000 live births
female: 24.54 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 70.63 years
male: 68.55 years
female: 72.81 years (2006 est.)
Total fertility rate: 2.75 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.2% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 6,400
(2003 est.)
HIV/AIDS - deaths: less than 500 (2003 est.)
Nationality:
noun: Nicaraguan(s)
adjective: Nicaraguan
Ethnic groups: mestizo (mixed Amerindian and
white) 69%, white 17%, black 9%, Amerindian 5%
Religions: Roman Catholic 72.9%, Evangelical
15.1%, Moravian 1.5%, Episcopal 0.1%, other 1.9%,
none 8.5% (1995 census)
Languages: Spanish 97.5% (official), Miskito 1.7%,
other 0.8% (1995 census)
note: English and indigenous languages on Atlantic
coast
Literacy:
definition: age 1 5 and over can read and write
total population: 67.5%
male: 67.2%
female: 67.8% (2003 est.)','39c9707f49db23c4e37702c11b7fe3e78d9610a52db25ce55b8daedcfdb0fcbc','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8aebd47445fdbb4547087028b5e591133432377d15dbd0c36a91333b45dea89b',2007,'SI','Slovenia','people-and-society',429,'Population: 4,494,749 (July 2006 est.)
Age structure:
0-14 years: 16.2% (male 373,638/female 354,261 )
15-64 years: 67% (male 1 ,497,958/female 1 ,51 5,31 4)
65 years and over: 16.8% (male 288,480/female
465,098) (2006 est.)
Median age:
total: 40.3 years
male: 38.3 years
female: 42.1 years (2006 est.)
Population growth rate: -0.03% (2006 est )
Birth rate: 9.61 births/1,000 population (2006 est.)
Death rate: 1 1 .48 deaths/1 .000 population
(2006 est.)
Net migration rate: 1 .58 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.62 male(s)/female
total population: 0.93 male(s)/female (2006 est.)
Infant mortality rate:
total: 6.72 deaths/1 000 live births
male: 6.7 deaths/1 ,000 live births
female: 6.74 deaths/1 ,000 live births (2006 est.)
143
Croatia (continued)
Life expectancy at birth:
total population: 74.68 years
male: 71 .03 years
temale: 78.53 years (2006 est.)
Total fertility rate: 1 .4 children born/woman
(2006 est.)
HIV/AIDS • adult prevalence rate: less than 0.1%
(2001 est.)
HIV/AIDS • people living with HIV/AIDS: 200
(2001 est.)
HIV/AIDS - deaths: less than 10 (2001 est.)
Nationality:
noun: Croat(s), Croatian(s)
adjective: Croatian
Ethnic groups: Croat 89.6%, Serb 4.5%, other 5.9%
(including Bosniak, Hungarian, Slovene, Czech, and
Roma) (2001 census)
Religions: Roman Catholic 87.8%, Orthodox 4.4%,
other Christian 0.4%, Muslim 1 .3%, other and
unspecified 0.9%, none 5.2% (2001 census)
Languages: Croatian 96.1%, Serbian 1%, other and
undesignated 2.9% (including Italian, Hungarian,
Czech, Slovak, and German) (2001 census)
Literacy:
definition: age 15 and over can read and write
total population: 98.5%
male: 99.4%
female: 97.8% (2003 est.)','9ae21e0bd468c9ef9723655e1ad01610b12ad2ab3cca4e26f51dd8697424abb1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e419fc696f83411029524fb2b0a708a11356ee78b47414597091c327beb4c7d8',2007,'HT','Haiti','people-and-society',440,'Population: 1 1 ,382,820 (July 2006 est.)
Age structure:
0-14 years: 1 9.1 % (male 1,11 7,677/female
1,058,512)
15-64 years: 70.3% (male 4,001 ,161/female
3,999,303)
65 years and over: 10.6% (male 554,148/female
652,019) (2006 est.)
Median age:
total: 35.9 years
male: 35.2 years
female: 36.5 years (2006 est.)
Population growth rate: 0.31% (2006 est.)
Birth rate: 1 1 .89 births/1 ,000 population (2006 est.)
Death rate: 7.22 deaths/1 ,000 population (2006 est.)
Net migration rate: -1 .57 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at binh: 1 .06 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 0.99 male(s)/female (2006 est.)
Infant mortality rate:
total: 6.22 deaths/1 ,000 live births
male: 6.99 deaths/1 ,000 live births
female: 5.41 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 71 A} years
male: 75. 11 years
female: 79.85 years (2006 est.)
Total fertility rate: 1 .66 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: less than 01%
(2003 est.)
HIV/AIDS - people living with HIV/AIDS: 3,300
(2003 est.)
HIV/AIDS - deaths: less than 200 (2003 est.)
Nationality:
noun: Cuban(s)
adjective: Cuban
Ethnic groups: mulatto 51%, white 37%, black 11%,
Chinese 1%
Religions: nominally 85% Roman Catholic prior to
CASTRO assuming power; Protestants, Jehovah''s
Witnesses, Jews, and Santeria are also represented
Languages: Spanish
Literacy:
definition: age 1 5 and over can read and write
total population: 97%
male: 97.2%
female: 96.9% (2003 est.)
146
Cuba (continued)
People - note: illicit migration is a continuing
problem; Cubans attempt to depart the island and
enter the US using homemade rafts, alien smugglers,
direct flights, or falsified visas; Cubans also use
non-maritime routes to enter the US including direct
flights to Miami and over-land via the southwest
border
Population: 9,183,984 (July 2006 est.)
Age structure:
0-14 years: 32.6% (male 1 ,531 ,145/female
1,464,076)
15-64 years: 61 .9% (male 2,902,098/female
2,782,608)
65 years and over: 5.5% (male 235,01 6/female
269,041) (2006 est.)
Median age:
total: 24.1 years
male: 24 years
female: 24.3 years (2006 est.)
Population growth rate: 1 .47% (2006 est.)
Birth rate: 23.22 births/1 ,000 population (2006 est.)
Death rate: 5.73 deaths/1 ,000 population (2006 est.)
Net migration rate: -2.79 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.87 male(s)/female
total population:). 03 male(s)/female (2006 est.)
Infant mortality rate:
total: 28.25 deaths/1 ,000 live births
male: 30.58 deaths/1 ,000 live births
female: 25.8 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 71 .73 years
male: 70.21 years
female: 73.33 years (2006 est.)
Total fertility rate: 2.83 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 1 .7% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 88,000
(2003 est.)
HIV/AIDS - deaths: 7,900 (2003 est.)
Nationality:
noun: Dominican(s)
adjective: Dominican
Ethnic groups: mixed 73%, white 16%, black 11%
Religions: Roman Catholic 95%
Languages: Spanish
Literacy:
definition: age 1 5 and over can read and write
total population: 84.7%
male: 84.6%
female: 84.8% (2003 est.)
Population: 8,308,504
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected
(July 2006 est.)
Age structure:
0-14 years: 42 4% (male 1 ,770,523/female
1,749,853)
15-64 years: 54.2% (male 2,201 ,957/female
2,301,886)
65 years and over: 3.4% (male 1 25,298/female
158,987) (2006 est.)
Median age:
total: 18.2 years
male: 1 7.8 years
female: 18.6 years (2006 est.)
Population growth rate: 2.3% (2006 est.)
Birth rate: 36.44 births/1 ,000 population (2006 est.)
Death rate: 12.17 deaths/1 ,000 population
(2006 est.)
Net migration rate: -1.31 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 0.97 male(s)/female (2006 est.)
Infant mortality rate:
total: 71 .65 deaths/1 ,000 live births
male: 78.01 deaths/1 ,000 live births
female: 65.1 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 53.23 years
male: 51.89 years
female: 54.6 years (2006 est.)
Total fertility rate: 4.94 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 5.6% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 280,000
(2003 est.)
HIV/AIDS ■ deaths: 24,000 (2003 est.)
Nationality:
noun: Haitian(s)
adjective: Haitian
Ethnic groups: black 95%, mulatto and white 5%
Religions: Roman Catholic 80%, Protestant 16%
(Baptist 10%, Pentecostal 4%, Adventist 1%, other
1%), none 1%, other 3%
note: roughly half of the population practices Voodoo
Languages: French (official), Creole (official)
Literacy:
definition: age 1 5 and over can read and write
total population: 52.9%
male: 54.8%
female: 51.2% (2003 est.)
Population: uninhabited (July 2006 est.)','28fe889cc93c29f34d0a9eed2ad8f135947d7830e4c042438b34cf7e79d285af','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c904b1692f0eb256896a708007d997ed67b73b8dbd8313b625c30595ce271bb1',2007,'CY','Cyprus','people-and-society',449,'Population: 784,301 (July 2006 est.)
Age structure:
0-14 years: 20.4% (male 81 ,776/female 78,272)
15-64 years: 68% (male 270,254/female 263,354)
65 years and over: 1 1 .6% (male 39,536/female
51,109) (2006 est.)
Median age:
total: 34.9 years
male: 33.9 years
female: 35.9 years (2006 est.)
Population growth rate: 0.53% (2006 est.)
Birth rate: 12.56 births/1 ,000 population (2006 est.)
Death rate: 7.68 deaths/1 ,000 population (2006 est.)
Net migration rate: 0.42 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 1 male(s)/female (2006 est.)
Infant mortality rate:
total: 7.04 deaths/1 ,000 live births
male: 8.74 deaths/1 ,000 live births
female: 5.25 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 77.82 years
male: 75.44 years
female: 80.31 years (2006 est.)
Total fertility rate: 1 .82 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.1% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: less than
1,000 (1999 est.)
HIV/AIDS -deaths: NA
Nationality:
noun: Cypriot(s)
adjective: Cypriot
Ethnic groups: Greek 77%, Turkish 18%, other 5%
(2001)
Religions: Greek Orthodox 78%, Muslim 18%,
Maronite, Armenian Apostolic, and other 4%
Languages: Greek, Turkish, English
Literacy:
definition: age 1 5 and over can read and write
total population: 97.6%
male: 98.9%
female: 96.3% (2003 est.)
149
Cyprus (continued)
Population: 1 0,235,455 (July 2006 est.)
Age structure:
0-14 years: 14.4% (male 755,098/female 714,703)
15-64 years: 71 .2% (male 3,656,021/female
3,629,036)
65 years and over: 14.5% (male 576,264/female
904,333) (2006 est.)
Median age:
total: 39.3 years
male: 37.5 years
fema/e: 41.1 years (2006 est.)
Population growth rate: -0.06% (2006 est.)
Birth rate: 9.02 births/1 ,000 population (2006 est.)
Death rate: 10.59 deaths/1 ,000 population (2006 est.)
Net migration rate: 0.97 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.64 male(s)/female
total population: 0.95 male(s)/female (2006 est.)
152
Czech Republic (continued)
Infant mortality rate:
total: 3.89 deaths/1 ,000 live births
male: 4.24 deaths/1 ,000 live births
temale: 3.52 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 76.22 years
male: 72.94 years
female: 79.69 years (2006 est.)
Total fertility rate: 1.21 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: less than 0.1%
(2001 est.)
HIV/AIDS - people living with HIV/AIDS: 2,500
(2001 est.)
HIV/AIDS • deaths: less than 10 (2001 est.)
Nationality:
noun: Czech (s)
adjective: Czech
Ethnic groups: Czech 90.4%, Moravian 3.7%,
Slovak 1.9%, other 4% (2001 census)
Religions: Roman Catholic 26.8%, Protestant 2.1 %,
other 3.3%, unspecified 8.8%, unaffiliated 59% (2001
census)
Languages: Czech
Literacy:
definition: NA
total population: 99%
male: 99%
female: 99% (2003 est.)','8942ef6ec1ba50c59f8c2149688516e999743d2973401810a983dfdddf6d2bc4','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc9aea2134820946e4156afdb063130565b869f28e3359503f1c087f630fa075',2007,'DK','Denmark','people-and-society',457,'Population: 5,450,661 (July 2006 est.)
Age structure:
0-14 years: 18.7% (male 523,257/female 496,697)
15-64 years: 66.1 % (male 1 ,81 5,240/female 1 ,787,406)
65 years and over: 1 5.2% (male 355,656/female
472,405) (2006 est.)
Median age:
total: 39.8 years
male: 38.9 years
female: 40.7 years (2006 est.)
Population growth rate: 0.33% (2006 est.)
Birth rate: 11.13 births/1 ,000 population (2006 est.)
Death rate: 1 0.36 deaths/1 ,000 population
(2006 est.)
Net migration rate: 2.52 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1.02 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.98 male(s)/female (2006 est.)
Infant mortality rate:
totai: 4.51 deaths/1 ,000 live births
male: 4.54 deaths/1 ,000 live births
female: 4.47 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 77.79 years
male: 75.49 years
female: 80.22 years (2006 est.)
Total fertility rate: 1 .74 children born/woman
(2006 est.)
HIV/AIDS ■ adult prevalence rate: 0.2% (2003 est.)
HIV/AIDS • people living with HIV/AIDS: 5,000
(2003 est.)
HIV/AIDS • deaths: less than 100 (2003 est.)
Nationality:
noun: Dane(s)
adjective: Danish
Ethnic groups: Scandinavian, Inuit, Faroese,
German, Turkish, Iranian, Somali
Religions: Evangelical Lutheran 95%, other
Protestant and Roman Catholic 3%, Muslim 2%
Languages: Danish, Faroese, Greenlandic (an Inuit
dialect), German (small minority)
note: English is the predominant second language
Literacy:
definition: age 1 5 and over can read and write
total population: 99%
male: 99%
fema/e:99%(2003est.)
Population: no indigenous personnel
note: approximately 2,200 military personnel are on
the base; there are another 5,000 British citizens who
are families of military personnel or civilian staff on
both the bases of Akrotiri and Dhekelia; Cyprus
citizens work on the base, but do not live there
Languages: English, Greek
157
Dhekelia (continued)
Population: 56,361 (July 2006 est.)
Age structure:
0-14 years: 24.5% (male 7,072/female 6,740)
15-64 years: 68.9% (male 20,904/female 17,919)
65 years and over: 6.6% (male 1 ,768/female 1 ,958)
(2006 est.)
Median age:
total: 34 years
male: 35.3 years
female: 32.3 years (2006 est.)
Population growth rate: -0.03% (2006 est.)
Birth rate: 15.93 births/1,000 population (2006 est.)
Death rate: 7.84 deaths/1 ,000 population (2006 est.)
Net migration rate: -8.37 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .02 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1.17 male(s)/female
65 years and over: 0.9 male(s)/female
total population: 1.12 male(s)/female (2006 est.)
Infant mortality rate:
total: 15.4 deaths/1 ,000 live births
male: 16.73 deaths/1 ,000 live births
female: 14.03 deaths/1,000 live births (2006 est.)
226
Greenland (continued)
Life expectancy at birth:
total population: 69.94 years
male: 66.36 years
female: 73.6 years (2006 est.)
Total fertility rate: 2.4 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: 100
(1999)
HIV/AIDS - deaths: NA
Nationality:
noun: Greenlander(s)
adjective: Greenlandic
Ethnic groups: Greenlander 88% (Inuit and
Greenland-bom whites), Danish and others 12% (2000)
Religions: Evangelical Lutheran
Languages: Greenlandic (East Inuit), Danish,
English
Literacy:
definition: age 1 5 and over can read and write
tote/ population: 100%
male: 100%
female: 100% (2001 est.)','00d2830dfd056d984efd4c9bad734e0b5e52ac3a990b95c5ab151604c3511538','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c772900e59f00dfb12515ea60b047d42f04b3af98ed0408902b2021937a3d5d',2007,'DJ','Djibouti','people-and-society',466,'Population: 486.530 (July 2006 est.)
Age structure:
0-14 years: 43.3% (male 105,760/female 105,068)
15-64 years: 53.3% (male 135,1 19/female 124,367)
65 years and over: 3.3% (male 8,1 83/female 8.033)
(2006 est.)
Median age:
total: 18.2 years
male: 18.7 years
female: 17.7 years (2006 est.)
Population growth rate: 2.02% (2006 est.)
Birth rate: 39.53 births/1 ,000 population (2006 est.)
Death rate: 19.31 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1 .09 male(s)/female
65 years and over: 1 .02 male(s)/female
total population: 1 .05 male(s)/female (2006 est.)
Infant mortality rate:
total: 102.44 deaths/1,000 live births
male: 1 10.07 deaths/1 ,000 live births
female: 94.58 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 43. 1 7 years
male: 41.86 years
female: 44.52 years (2006 est.)
158
Djibouti (continued)
Total fertility rate: 5.31 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 2.9% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 9,100
(2003 est.)
HIV/AIDS - deaths: 690 (2003 est.)
Major infectious diseases:
degree of risk: high
food or walerborne diseases: bacterial and protozoal
diarrhea, hepatitis A and E, and typhoid fever
vectorborne disease: malaria (2004)
Nationality:
noun: Djiboutian(s)
adjective: Djiboutian
Ethnic groups: Somali 60%, Afar 35%, French,
Arab, Ethiopian, and Italian 5%
Religions: Muslim 94%, Christian 6%
Languages: French (official), Arabic (official),
Somali, Afar
Literacy:
definition: age 15 and over can read and write
total population: 67.9%
male: 78%
female: 58.4% (2003 est.)
Population: 68,910 (July 2006 est.)
Age structure:
0-14 years: 26.1% (male 9,084/female 8,885)
15-64 years: 66% (male 23,41 9/female 22,079)
65 years and over: 7.9% (male 2,1 86/female 3,257)
(2006 est.)
Median age:
tote/: 30.1 years
male: 29.8 years
female: 30.4 years (2006 est.)
Population growth rate: -0.08% (2006 est.)
Birth rate: 1 5.27 births/1 ,000 population (2006 est.)
Death rate: 6.73 deaths/1 ,000 population (2006 est.)
Net migration rate: -9.3 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 1 .01 male(s)/female (2006 est.)
Infant mortality rate:
total: 13.71 deaths/1,000 live births
male: 18.09 deaths/1 ,000 live births
female: 9.1 1 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 74.87 years
male: 71.95 years
female: 77.93 years (2006 est.)
Total fertility rate: 1 .94 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Dominican(s)
adjective: Dominican
Ethnic groups: black, mixed black and European,
European, Syrian, Carib Amerindian
Religions: Roman Catholic 77%, Protestant 15%
(Methodist 5%, Pentecostal 3%, Seventh-Day
Adventist 3%, Baptist 2%, other 2%), other 6%,
none 2%
Languages: English (official), French patois
Literacy:
definition: age 15 and over has ever attended school
total population: 94%
male: 94%
female: 94% (2003 est.)','67e657a32d3ece5da731fa6caa3802ad7abccf13fc546a68adef2745b9c58080','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('25d7ce0a3fd9f4e3e87c87e383cc49b5f510c7e91caab8e5c54f8e365fe82ceb',2007,'PE','Peru','people-and-society',484,'Population: 13.547,510 (July 2006 est.)
Age structure:
0-14 years: 33% (male 2,281, 499/female 2,195,551)
15-64 years: 61 .9% (male 4,1 78,653/female
4,210,766)
65 years and over: 5% (male 31 9,71 9/female
361 ,322) (2006 est.)
Median age:
total: 23.6 years
mate: 23.1 years
female: 24 years (2006 est.)
Population growth rate: 1 .5% (2006 est.)
Birth rate: 22.29 births/1.000 population (2006 est.)
Death rate: 4.23 deaths/1 ,000 population (2006 est.)
Net migration rate: -3.11 migrant(s)/1,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.89 male(s)/female
total population: 1 male(s)/female (2006 est.)
Infant mortality rate:
total: 22.87 deaths/1 ,000 live births
male: 27.42 deaths/1 ,000 live births
female: 18.09 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 76.42 years
male: 73.55 years
female: 79.43 years (2006 est.)
Total fertility rate: 2.68 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.3% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 21 ,000
(2003 est.)
HIV/AIDS - deaths: 1 ,700 (2003 est.)
Nationality:
noun: Ecuadorian(s)
adjective: Ecuadorian
Ethnic groups: mestizo (mixed Amerindian and
white) 65%, Amerindian 25%, Spanish and others 7%,
black 3%
Religions: Roman Catholic 95%, other 5%
Languages: Spanish (official), Amerindian
languages (especially Quechua)
Literacy:
definition: age 1 5 and over can read and write
total population: 92.5%
male: 94%
female: 91% (2003 est.)
Population: 78,887,007 (July 2006 est.)
Age structure:
0-14 years: 32.6% (male 13,172,641/female
12,548,346)
15-64 years: 62.9% (male 25,102,754/female
24,519,698)
65 years and over: 4.5% (male 1 ,510,280/female
2,033,288) (2006 est.)
Median age:
total: 24 years
male: 23.6 years
female: 24.3 years (2006 est.)
Population growth rate: 1 .75% (2006 est.)
Birth rate: 22.94 births/1,000 population (2006 est.)
Death rate: 5.23 deaths/1 ,000 population (2006 est.)
Net migration rate: -0.21 migrant(s)/1,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.74 male(s)/female
total population: 1.02 male(s)/female (2006 est.)
Infant mortality rate:
total: 31 .33 deaths/1 ,000 live births
male: 32.04 deaths/1 ,000 live births
female: 30.58 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 71 .29 years
male: 68.77 years
female: 73.93 years (2006 est.)
Total fertility rate: 2.83 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: less than 0.1%
(2001 est.)
HIV/AIDS • people living with HIV/AIDS: 12,000
(2001 est.)
HIV/AIDS - deaths: 700 (2003 est.)
Nationality:
noun: Egyptian(s)
adjective: Egyptian
Ethnic groups: Egyptian 98%, Berber, Nubian,
Bedouin, and Beja 1%, Greek, Armenian, other
European (primarily Italian and French) 1 %
Religions: Muslim (mostly Sunni) 90%, Coptic 9%,
other Christian 1 %
Languages: Arabic (official), English and French
widely understood by educated classes
Literacy:
definition: age 1 5 and over can read and write
total population: 57.7%
male: 68.3%
female: 46.9% (2003 est.)','c90c45b1a892eab5847cf514ac295301db7e0aacdcf43a12169ec0ddcfcfd521','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4a79ca909cd111e9067c28f9c03d3f7317aed8aa8f783b6d83c18a26216961a',2007,'SV','El Salvador','people-and-society',494,'Population: 6.822.378 (July 2006 est.)
Age structure:
0-14 years: 36.3% (male 1 ,265,080/female
1,212,216)
15-64 years: 58.5% (male 1,900,372/female
2,092.251)
65 years and over: 5.2% (male 1 56.292/female
196,167) (2006 est.)
Median age:
total: 21 .8 years
male: 20.7 years
female: 22.9 years (2006 est.)
Population growth rate: 1 72% (2006 est.)
Birth rate: 26.61 births/1.000 population (2006 est.)
Death rate: 5.78 deaths/1 .000 population (2006 est.)
Net migration rate: -3.61 migrant(s)/1,000
population (2006 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.8 male(s)/female
total population: 0.95 male(s)/female (2006 est.)
Infant mortality rate:
total: 24.39 deaths/1 ,000 live births
male: 27.27 deaths/1 ,000 live births
female: 21 .37 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 71 .49 years
male: 67.88 years
female: 75.28 years (2006 est.)
Total fertility rate: 3.12 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.7% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 29,000
(2003 est.)
HIV/AIDS - deaths: 2,200 (2003 est.)
Nationality:
noun: Salvadoran(s)
adjective: Salvadoran
Ethnic groups: mestizo 90%, white 9%,
Amerindian 1%
Religions: Roman Catholic 83%, other 17%
note: there is extensive activity by Protestant groups
throughout the country; by the end of 1 992, there were
an estimated 1 million Protestant evangelicals in El
Salvador
Languages: Spanish, Nahua (among some
Amerindians)
Literacy:
definition: age 1 0 and over can read and write
total population: 80.2%
male: 82.8%
female: 77.7% (2003 est.)','969ab1eb755690f6c0e524c2989e797864500b52e3b0db13adb9f9ea30178fc3','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a39104251d1ada29fcdf60ca9665d68e97f1e41a99706ccc50188a27fef52b97',2007,'GA','Gabon','people-and-society',504,'Population: 540,109 (July 2006 est.)
Age structure:
0-14 years: 41 .7% (male 1 1 3,083/female 1 1 1 ,989)
15-64 years: 54.5% (male 141,914/female 152,645)
65 years and over: 3.8% (male 8,886/female 1 1 ,592)
(2006 est.)
Median age:
total: 18.8 years
male: 1 8.2 years
female: 19.4 years (2006 est.)
Population growth rate: 2.05% (2006 est.)
Birth rate: 35.59 births/1 ,000 population (2006 est.)
Death rate: 1 5.06 deaths/1 ,000 population
(2006 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 0.96 male(s)/female (2006 est.)
Infant mortality rate:
total: 89.21 deaths/1 ,000 live births
male: 95.22 deaths/1 ,000 live births
female: 83.02 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 49.54 years
male: 48 years
female: 51.13 years (2006 est.)
Total fertility rate: 4.55 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 3.4% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 5,900
(2001 est.)
HIV/AIDS - deaths: 370 (2001 est.)
Major infectious diseases:
degree of risk: very high
food or waterbome diseases: bacterial diarrhea,
hepatitis A, and typhoid fever
vectorborne disease: malaria (2004)
Nationality:
noun: Equatorial Guinean(s) or Equatoguinean(s)
adjective: Equatorial Guinean or Equatoguinean
Ethnic groups: Bioko (primarily Bubi, some
Fernandinos), Rio Muni (primarily Fang), Europeans
less than 1 ,000, mostly Spanish
Religions: nominally Christian and predominantly
Roman Catholic, pagan practices
Languages: Spanish (official), French (official),
pidgin English, Fang, Bubi, Ibo
Literacy:
definition: age 15 and over can read and write
total population: 85.7%
male: 93.3%
female: 78.4% (2003 est.)','ce80bee09fe78dd5d517fca42053c1e4851f393bff70a920f413a077b757e2cf','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('317501a1e9715ed5e8d6b1d353e80a23c02f34e1fd8db11045084beed262400d',2007,'ER','Eritrea','people-and-society',513,'Population: 4,786,994 (July 2006 est.)
Age structure:
0-14 years: 44% (male 1 ,059,458/female 1 ,046,955)
15-64 years: 52.5% (male 1 ,244,1 53/female
1,268,189)
65 years and over: 3.5% (male 82,1 12/female
86,127) (2006 est.)
Median age:
total: 17.8 years
male: 1 7.6 years
female: 18 years (2006 est.)
Population growth rate: 2.47% (2006 est.)
Birth rate: 34.33 births/1 ,000 population (2006 est.)
Death rate: 9.6 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 1 5 years: 1.01 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.95 male(s)/female
total population: 0.99 male(s)/female (2006 est.)
Infant mortality rate:
total: 46.3 deaths/1 ,000 live births
male: 52.22 deaths/1,000 live births
female: 40.2 deaths/1 .000 live births (2006 est.)
Life expectancy at birth:
total population: 59.03 years
male: 57.44 years
female: 60.66 years (2006 est.)
Total fertility rate: 5.08 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 2.7% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 60,000
(2003 est.)
HIV/AIDS - deaths: 6,300 (2003 est.)
Major infectious diseases:
degree of risk: high
food or waterbome diseases: bacterial diarrhea,
hepatitis A, and typhoid fever
vectorbome disease: malaria is a high risk in some
locations (2004)
Nationality:
noun: Eritrean(s)
adjective: Eritrean
Ethnic groups: ethnic Tigrinya 50%, Tigre and
Kunama 40%, Afar 4%, Saho (Red Sea coast
dwellers) 3%, other 3%
Religions: Muslim, Coptic Christian, Roman
Catholic, Protestant
Languages: Afar, Arabic, Tigre and Kunama,
Tigrinya, other Cushitic languages
Literacy:
definition: age 1 5 and over can read and write
total population: 58.6%
male: 69.9%
female: 47.6% (2003 est.)','ab6e2a832cfe7691b5a78ebf6397f9712e098bceb6e59814019f678604ea45f2','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5ca695cfdad5ca54971909f843c645134dd0b6c2964509ba37d2401cde303d7a',2007,'EE','Estonia','people-and-society',522,'Population: 1 ,324,333 (July 2006 est.)
Age structure:
0-14 years: 15.2% (male 103,367/female 97,587)
15-64 years: 67.6% (male 427,043/female 468,671 )
65 years and over: 17.2% (male 75.347/female
152.318) (2006 est.)
Median age:
total: 39.3 years
male: 35.8 years
female: 42.6 years (2006 est.)
Population growth rate: -0.64% (2006 est.)
Birth rate: 10.04 births/1,000 population (2006 est.)
Death rate: 13.25 deaths/1 ,000 population
(2006 est.)
Net migration rate: -3.2 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1.06 male(s)/female
15-64 years: 0.91 male(s)/female
65 years and over: 0.5 male(s)/female
total population: 0.84 male(s)/female (2006 est.)
Infant mortality rate:
total: 7.73 deaths/1 ,000 live births
male: 8.91 deaths/1 ,000 live births
female: 6.47 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 72.04 years
male: 66.58 years
female: 77.83 years (2006 est.)
Total fertility rate: 1 .4 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 1.1% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 7,800
(2003 est.)
HIV/AIDS - deaths: less than 200 (2003 est.)
Nationality:
noun: Estonian(s)
adjective: Estonian
Ethnic groups: Estonian 67.9%, Russian 25.6%,
Ukrainian 2.1%, Belarusian 1.3%, Finn 0.9%, other
2.2% (2000 census)
Religions: Evangelical Lutheran 13.6%, Orthodox
12.8%, other Christian (including Methodist,
Seventh-Day Adventist. Roman Catholic.
Pentecostal) 1.4%, unaffiliated 34.1%, other and
unspecified 32%. none 6.1% (2000 census)
Languages: Estonian (official) 67.3%, Russian
29.7%, other 2.3%, unknown 0.7% (2000 census)
Literacy:
definition: age 1 5 and over can read and write
total population: 99.8%
male: 99.8%
female: 99.8% (2003 est.)','ab0ebcfc197795da92e8229fc7e49a5b06182f681fb299f3b4789f7cf78c20f1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('053852e7877647d7685c91c46dd4a87c408b294e9e473e56a7ca09b63fd93b48',2007,'ET','Ethiopia','people-and-society',530,'Population: 74,777,981
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected
(July 2006 est.)
Age structure:
0-14 years: 43.7% (male 1 6,373,71 8/female
16,280,766)
15-64 years: 53.6% (male 19,999,482/female
20,077,014)
65 years and over: 2.7% (male 929,349/female
1,117,652) (2006 est.)
Median age:
total: 17.8 years
male: 17.7 years
female: 17.9 years (2006 est.)
Population growth rate: 2.31% (2006 est.)
Birth rate: 37.98 births/1 ,000 population (2006 est.)
Death rate: 1 4.86 deaths/1 ,000 population (2006 est.)
184
Ethiopia (continued)
Net migration rate: 0 migrant(s)/1 ,000 population
note: repatriation of Ethiopian refugees residing in
Sudan is expected to continue for several years; some
Sudanese, Somali, and Eritrean refugees, who fled to
Ethiopia from the fighting or famine in their own
countries, continue to return to their homes (2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 1 ma!e(s)/female (2006 est.)
Infant mortality rate:
total: 93.62 deaths/1 ,000 live births
male: 103.43 deaths/1,000 live births
female: 83.51 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 49.03 years
male: 47.86 years
female: 50.24 years (2006 est.)
Total fertility rate: 5.22 children bom/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 4.4% (2003 est.)
HIV/AIDS • people living with HIV/AIDS: 1.5 million
(2003 est.)
HIV/AIDS - deaths: 1 20,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterbome diseases: bacterial and protozoal
diarrhea, hepatitis A, typhoid fever, and hepatitis E
vectorborne diseases: malaria and cutaneous
leishmaniasis are high risks in some locations
respiratory disease: meningococcal meningitis
animal contact disease: rabies
water contact disease: schistosomiasis (2004)
Nationality:
noun: Ethiopian(s)
adjective: Ethiopian
Ethnic groups: Oromo 40%, Amhara and Tigre
32%, Sidamo 9%, Shankella 6%, Somali 6%, Afar 4%,
Gurage2%, other 1%
Religions: Muslim 45%-50%, Ethiopian Orthodox
35%-40%, animist 12%, other 3%-8%
Languages: Amharic, Tigrinya, Oromigna,
Guaragigna, Somali, Arabic, other local languages,
English (major foreign language taught in schools)
Literacy:
definition: age 15 and over can read and write
total population: 42.7%
male: 50.3%
female: 35.1% (2003 est.)','337b80d46134c8856b8f3297ccff0949c1685d3fd4cbd75261e8d9add05ea5d0','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b717da1854b3f493d4df0b034185e3da94a20fab80d992f8301ce041b822a85',2007,'MZ','Mozambique','people-and-society',539,'Population: no indigenous inhabitants
note: there is a small French military garrison and a
few meteorologists; visited by scientists
(July 2006 est.)
Population: no indigenous inhabitants
note: there is a small French military garrison along
with a few meteorologists; occasionally visited by
scientists (July 2006 est.)
Population: 18,595,469 (July 2006 est.)
Age structure:
0-14 years: 44.8% (male 4,171 ,821/female
4,158,288)
15-64 years: 52.2% (male 4,809, 173/female
4,900,675)
65 years and over: 3% (male 249,41 4/female
306,098) (2006 est.)
Median age:
total: 17.5 years
male: 1 7.3 years
female: 17.7 years (2006 est.)
Population growth rate: 3.03% (2006 est.)
Birth rate: 41.41 births/1,000 population (2006 est.)
Death rate: 11.11 deaths/1 ,000 population
(2006 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2006 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 0.99 male(s)/female (2006 est.)
Infant mortality rate:
total: 75.21 deaths/1,000 live births
male: 83.34 deaths/1 ,000 live births
female: 66.84 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 57.34 years
male: 54.93 years
female: 59.82 years (2006 est.)
Total fertility rate: 5.62 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 1 .7% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 140,000
(2003 est.)
HIV/AIDS • deaths: 7,500 (2003 est.)
Major infectious diseases:
degree of risk: high
food or waterborne diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever
vectorbome diseases: malaria and plague are high
risks in some locations
water contact disease: schistosomiasis (2004)
Nationality:
noun: Malagasy (singular and plural)
adjective: Malagasy
Ethnic groups: Malayo-lndonesian (Merina and
related Betsileo), Cotiers (mixed African,
Malayo-lndonesian, and Arab ancestry -
Betsimisaraka, Tsimihety, Antaisaka. Sakalava),
French, Indian, Creole, Comoran
Religions: indigenous beliefs 52%. Christian 41%,
Muslim 7%
Languages: French (official), Malagasy (official)
Literacy:
definition: age 1 5 and over can read and write
total population: 68.9%
male: 75.5%
female: 62.5% (2003 est.)
Population: 37,445,392
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected
(July 2006 est.)
Age structure:
0-14 years: 43.7% (male 8,204,593/female
8,176,489)
15-64 years: 53.6% (male 9,906,446/female
10,178,066)
65 years and over: 2.6% (male 422,674/female
557,124) (2006 est.)
Median age:
total: 17.7 years
male: 17.5 years
female: 18 years (2006 est.)
Population growth rate: 1 .83% (2006 est.)
Birth rate: 37.71 births/1,000 population (2006 est.)
Death rate: 1 6.39 deaths/1 ,000 population (2006 est.)
Net migration rate: -3.05 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
atbinh: 1.03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 0.98 male(s)/female (2006 est.)
Infant mortality rate:
total: 96.48 deaths/1 ,000 live births
male: 105.64 deaths/1 ,000 live births
female: 87.05 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 45.64 years
male: 44.93 years
female: 46.37 years (2006 est.)
Total fertility rate: 4.97 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 8.8% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 1 .6 million
(2003 est.)
HIV/AIDS - deaths: 160,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial diarrhea,
hepatitis A, and typhoid fever
vectorborne diseases: malaria, Rift Valley fever and
plague are high risks in some locations
water contact disease: schistosomiasis (2004)
Nationality:
noun: Tanzanian(s)
adjective: Tanzanian
Ethnic groups: mainland - native African 99% (of
which 95% are Bantu consisting of more than 1 30
tribes), other 1% (consisting of Asian, European, and
Arab); Zanzibar - Arab, native African, mixed Arab and
native African
Religions: mainland - Christian 30%, Muslim 35%,
indigenous beliefs 35%; Zanzibar - more than 99%
Muslim
Languages: Kiswahili or Swahili (official), Kiunguja
(name for Swahili in Zanzibar), English (official,
primary language of commerce, administration, and
higher education), Arabic (widely spoken in Zanzibar),
many local languages
note: Kiswahili (Swahili) is the mother tongue of the
Bantu people living in Zanzibar and nearby coastal
Tanzania; although Kiswahili is Bantu in structure and
origin, its vocabulary draws on a variety of sources,
including Arabic and English, and it has become the
lingua franca of central and eastern Africa; the first
language of most people is one of the local languages
Literacy:
definition: age 15 and over can read and write
Kiswahili (Swahili), English, or Arabic
total population: 78.2%
male: 85.9%
female: 70.7% (2003 est.)','a41876d407871c390948fe52c57fcf8304ec1c58e0ded3fad98080bf262e773c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c790a1acc4682b762287dfb1b4c1ef2afdb0816e5094ebf974a304b73535736',2007,'FO','Faroe Islands','people-and-society',546,'Population: 47,246 (July 2006 est.)
Age structure:
0-14 years: 20.9% (male 4,940/female 4,952)
15-64 years: 65.1% (male 16,247/female 14,522)
65 years and over: 13.9% (male 2,976/female 3,609)
(2006 est.)
Median age:
total: 35 years
male: 34.7 years
female: 35.5 years (2006 est.)
Population growth rate: 0.58% (2006 est.)
Birth rate: 14.05 births/1 ,000 population (2006 est.)
Death rate: 8.7 deaths/1 ,000 population (2006 est.)
Net migration rate: 0.47 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 1.12 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 1 .05 male(s)/female (2006 est.)
Infant mortality rate:
total: 6.12 deaths/1 ,000 live births
male: 7.4 deaths/1 ,000 live births
female: 4.85 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 79.35 years
male: 75.91 years
female: 82.8 years (2006 est.)
Total fertility rate: 2.17 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Faroese (singular and plural)
adjective: Faroese
Ethnic groups: Scandinavian
Religions: Evangelical Lutheran
Languages: Faroese (derived from Old Norse),
Danish
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%
note: probably 100%, the same as Denmark proper','9e5151de1ae5671434948b6d62db73883ac10f545b8299aed8c987ab3659d513','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76202546e007f48884362dc70467c89d8a4728c89b1b72dc384b6cc4e19c1561',2007,'JE','Jersey','people-and-society',556,'Population: 905,949 (July 2006 est.)
Age structure:
0-14 years: 31.1% (male 143,847/female 138,061)
15-64 years: 64.6% (male 293,072/female 292,312)
65 years and over: 4.3% (male 17,583/female
21,074) (2006 est.)
Median age:
total: 24.6 years
ma/e:24.1 years
female: 25 years (2006 est.)
Population growth rate: 1 4% (2006 est.)
Birth rate: 22.55 births/1,000 population (2006 est.)
Death rate: 5.65 deaths/1 ,000 population (2006 est.)
Net migration rate: -2.94 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 1.01 male(s)/female (2006 est.)
Infant mortality rate:
total: 12.3 deaths/1,000 live births
male: 13.63 deaths/1,000 live births
female: 10.91 deaths/1.000 live births (2006 est.)
Life expectancy at birth:
total population: 69.82 years
male: 67.32 years
female: 72.45 years (2006 est.)
Total fertility rate: 2.73 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.1% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 600
(2003 est.)
HIV/AIDS • deaths: less than 200 (2003 est.)
Nationality:
noun: Fijian(s)
adjective: Fijian
Ethnic groups: Fijian 51% (predominantly
Melanesian with a Polynesian admixture), Indian 44%,
European, other Pacific Islanders, overseas Chinese,
and other 5% (1998 est.)
Religions: Christian 52% (Methodist 37%, Roman
Catholic 9%), Hindu 38%, Muslim 8%, other 2%
note: Fijians are mainly Christian, Indians are Hindu,
and there is a Muslim minority
Languages: English (official), Fijian, Hindustani
Literacy:
definition: age 1 5 and over can read and write
total population: 93.7%
male: 95.5%
female: 91.9% (2003 est.)
Population: 6,352,117
note: includes about 187,000 Israeli settlers in the
West Bank, about 20,000 in the Israeli-occupied
Golan Heights, and fewer than 177,000 in East
Jerusalem (July 2006 est.)
Age structure:
0-14 years: 26.3% (male 855,054/female 815,619)
15-64 years: 63.9% (male 2,044, 135/female
2,016,647)
65 years and over: 9.8% (male 266,671 /female
353,991) (2006 est.)
Median age:
total: 29.6 years
male: 28.8 years
female: 30.5 years (2006 est.)
Population growth rate: 1.18% (2006 est.)
Birth rate: 17.97 births/1 ,000 population (2006 est.)
Death rate: 6.18 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.99 male(s)/female (2006 est.)
Infant mortality rate:
total: 6.89 deaths/1 ,000 live births
male: 7.61 deaths/1,000 live births
female: 6.14 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 79.46 years
male: 77.33 years
female: 81 .7 years (2006 est.)
Total fertility rate: 2.41 children born/woman
(2006 est.)
HIV/AIDS ■ adult prevalence rate: 0.1 % (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 3,000
(1999 est.)
HIV/AIDS - deaths: 100 (2001 est.)
Nationality:
noun: Israeli(s)
adjective: Israeli
279
Israel (continued)
Ethnic groups: Jewish 80. To (Europe/
America-born 32.1°o. Israel-bom 20.8%, Africa-born
14.6V Asia-born 12.6%). non-Jewish 19.9% (mostly
Arab) (1996 est.)
Religions: Jewish 76.5%, Muslim 15.9%, Arab
Christians 1.7%, other Christian 0.4%, Druze 1.6%,
unspecified 3.9% (2003)
Languages: Hebrew (official), Arabic used officially
for Arab minority, English most commonly used
foreign language
Literacy:
definition: age 15 and over can read and write
total population: 95.4%
male: 97.3%
female: 93.6% (2003 est.)
Population: 2,418,393
note: includes 1,291 ,354 non-nationals
(July 2006 est.)
Age structure:
0-14 years: 26.9% (male 331 ,768/female 319,895)
15-64 years: 70.3% (male 1 ,085,721 /female 61 3,746)
65 years and over: 2.8% (male 42,460/female
24,803) (2006 est.)
Median age:
total: 25.9 years
male: 28 years
female: 22.3 years (2006 est.)
Population growth rate: 3.52%
note: this rate reflects a return to pre-Gulf crisis
immigration of expatriates (2006 est.)
Birth rate: 21 .94 births/1 ,000 population (2006 est.)
Death rate: 2.41 deaths/1 ,000 population (2006 est.)
Net migration rate: 15.66 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .77 male(s)/female
65 years and over: 1 .71 male(s)/female
total population: 1 .52 male(s)/female (2006 est.)
Infant mortality rate:
total: 9.71 deaths/1 ,000 live births
male: 10.72 deaths/1,000 live births
female: 8.66 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 77.2 years
male: 76.13 years
female: 78.31 years (2006 est.)
Total fertility rate: 2.91 children born/woman
(2006 est.)
HIV/AIDS • adult prevalence rate: 0.12%
(2001 est.)
HIV/AIDS • people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Kuwaiti(s)
adjective: Kuwaiti
Ethnic groups: Kuwaiti 45%, other Arab 35%, South
Asian 9%, Iranian 4%, other 7%
Religions: Muslim 85% (Sunni 70%, Shi''a 30%),
Christian, Hindu, Parsi, and other 15%
Languages: Arabic (official), English widely spoken
Literacy:
definition: age 1 5 and over can read and write
fofa/popu/af/on:83.5%
male: 85.1%
female: 81 .7% (2003 est.)
Population: 219,246 (July 2006 est.)
Age structure:
0-14 years: 28.4% (male 31 ,818/female 30,503)
15-64 years: 64.9% (male 71 ,565/female 70,815)
65 years and over: 6.6% (male 6,773/female 7,772)
(2006 est.)
Median age:
total: 27.8 years
male: 27 A years
female: 28.2 years (2006 est.)
Population growth rate: 1 .24% (2006 est.)
Birth rate: 18.11 births/1,000 population (2006 est.)
Death rate: 5.69 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
nofe: there has been steady emigration from Wallis
and Futuna to New Caledonia (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.87 male(s)/female
total population: 1 .01 male(s)/female (2006 est.)
Infant mortality rate:
total: 7.57 deaths/1 ,000 live births
male: 8.27 deaths/1 ,000 live births
female: 6.83 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 74.27 years
male: 71 .29 years
female: 77.39 years (2006 est.)
Total fertility rate: 2.28 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS -deaths: NA
Nationality:
noun: New Caledonian(s)
adjective: New Caledonian
Ethnic groups: Melanesian 42.5%, European
37.1%, Wallisian 8.4%, Polynesian 3.8%, Indonesian
3.6%, Vietnamese 1 .6%, other 3%
Religions: Roman Catholic 60%, Protestant 30%,
other 10%
Languages: French (official), 33
Melanesian-Polynesian dialects
Literacy:
definition: age 1 5 and over can read and write
total population: 91%
male: 92%
female: 90% (1976 est.)
Population: 2,010,347 (July 2006 est.)
Age structure:
0-14 years: 13.8% (male 143,079/female 135,050)
15-64 years: 70.5% (male 714,393/female 702,950)
65 years and over: 1 5.7% (male 121 ,280/female
193,595) (2006 est.)
Median age:
total: 40.6 years
male: 39 years
female: 42.2 years (2006 est.)
Population growth rate: -0.05% (2006 est.)
Birth rate: 8.98 births/1 ,000 population (2006 est.)
Death rate: 10.31 deaths/1 ,000 population
(2006 est.)
Net migration rate: 0.88 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.63 male(s)/female
total population: 0.95 male(s)/female (2006 est.)
Infant mortality rate:
total: 4.4 deaths/1 ,000 live births
male: 4.99 deaths/1 ,000 live births
female: 3.77 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 76.33 years
male: 72.63 years
female: 80.29 years (2006 est.)
503
Slovenia (continued)
Total fertility rate: 1 .25 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: less than 0.1%
(2001 est.)
HIV/AIDS - people living with HIV/AIDS: 280
(2001 est.)
HIV/AIDS - deaths: less than 100 (2003 est.)
Nationality:
noun: Slovene(s)
adjective: Slovenian
Ethnic groups: Slovene 83.1%, Serb 2%, Croat
1 .8%, Bosniak 1 .1%, other or unspecified 12% (2002
census)
Religions: Catholic 57.8%, Orthodox 2.3%, other
Christian 0.9%, Muslim 2.4%, unaffiliated 3.5%, other
or unspecified 23%, none 10.1% (2002 census)
Languages: Slovenian 91.1%, Serbo-Croatian
4.5%, other or unspecified 4.4% (2002 census)
Literacy:
definition: NA
total population: 99.7%
male: 99.7%
female: 99.6% (2003 est.)
Population: 1,136,334
nofe: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected
(July 2006 est.)
Age structure:
0-14 years: 40.7% (male 233,1 69/female 229,103)
15-64 years: 55.8% (male 303,260/female 330,460)
65 years and over: 3.6% (male 1 6,071/female
24,271) (2006 est.)
Median age:
total: 18.5 years
male: 1 7.8 years
female: 19.2 years (2006 est.)
Population growth rate: -0.23% (2006 est.)
Birth rate: 27.41 births/1,000 population (2006 est.)
Death rate: 29.74 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.66 male(s)/female
total population: 0.95 male(s)/female (2006 est.)
Infant mortality rate:
total: 71 .85 deaths/1 ,000 live births
male: 75.25 deaths/1 ,000 live births
female: 68.34 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 32.62 years
male: 32.1 years
female: 33.17 years (2006 est.)
Total fertility rate: 3.53 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 38.8%
(2003 est.)
HIV/AIDS ■ people living with HIV/AIDS: 220,000
(2003 est.)
HIV/AIDS - deaths: 17,000 (2003 est.)
Nationality:
noun: Swazi(s)
adjective: Swazi
Ethnic groups: African 97%, European 3%
Religions: Zionist 40% (a blend of Christianity and
indigenous ancestral worship), Roman Catholic 20%,
Muslim 10%, Anglican, Bahai, Methodist, Mormon,
Jewish and other 30%
Languages: English (official, government business
conducted in English), siSwati (official)
Literacy:
definition: age 1 5 and over can read and write
tofa/popu/af/bn: 81.6%
male: 82.6%
female: 80.8% (2003 est.)','6d97cb1685af76e7a97ec9fa2ebe4432a8ee2a3f85bc0fd207dbfbc3c9d9239c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c47f084f0afdda4c32542f2cfbb900c79a356eaca2d554deca44692dc34637e',2007,'FI','Finland','people-and-society',566,'Population: 5,231 ,372 (July 2006 est.)
Age structure:
0-14 years: 17.1% (male 455,420/female 438,719)
15-64 years: 66.7% (male 1 ,766,674/female
1,724,858)
65 years and over: 16.2% (male 337,257/female
508,444) (2006 est.)
Median age:
total: 41.3 years
male: 39.7 years
female: 42.8 years (2006 est.)
Population growth rate: 0.14% (2006 est.)
Birth rate: 1 0.45 births/1 ,000 population (2006 est.)
Death rate: 9.86 deaths/1 ,000 population (2006 est.)
Net migration rate: 0.84 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.66 male(s)/female
total population: 0.96 male(s)/female (2006 est.)
Infant mortality rate:
total: 3.55 deaths/1 ,000 live births
male: 3.86 deaths/1 ,000 live births
female: 3.22 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 78.5 years
male: 74.99 years
female: 82.17 years (2006 est.)
Total fertility rate: 1 .73 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: less than 0.1%
(2003 est.)
HIV/AIDS - people living with HIV/AIDS: 1 ,500
(2003 est.)
HIV/AIDS - deaths: less than 100 (2003 est.)
Nationality:
noun: Finn(s)
adjective: Finnish
Ethnic groups: Finn 93.4%, Swede 5.7%, Russian
0.4%, Estonian 0.2%, Roma 0.2%, Sami 0.1%
Religions: Lutheran National Church 84.2%, Greek
Orthodox in Finland 1 .1%, other Christian 1 .1%, other
0.1%, none 13.5% (2003)
Languages: Finnish 92% (official), Swedish 5.6%
(official), other 2.4% (small Sami- and
Russian-speaking minorities) (2003)
Literacy:
definition: age 15 and over can read and write
total population: 100%
male: 100%
female: 100% (2000 est.)','c053fb29c8a3cd1e1f4b16aeb0be6a223312012c8d63826225c67cc5846eb381','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0c886ca97737557caeb8e8a6e1a75a59dcc41adec13f95daf56d59ade76cce0',2007,'GF','French Guiana','people-and-society',581,'Population: 199,509 (July 2006 est.)
Age structure:
0-14 years: 28.9% (male 29,540/female 28,210)
15-64 years: 64.8% (male 69.302/female 59,980)
65 years and over: 6.3% (male 6,350/female 6,127)
(2006 est.)
Median age:
total: 28.6 years
male: 29.6 years
female: 21 A years (2006 est.)
Population growth rate: 1 .96% (2006 est.)
Birth rate: 20.46 births/1 ,000 population (2006 est.;
Death rate: 4.88 deaths/1 ,000 population (2006 est.
Net migration rate: 4.01 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1.16 male(s)/female
65 years and over: 1 .04 male(s)/female
total population: 1 .12 male(s)/female (2006 est.)
Infant mortality rate:
total: 1 1 .76 deaths/1 ,000 live births
male: 12.58 deaths/1 ,000 live births
female: 10.89 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 77.27 years
male: 73.95 years
female: 80.75 years (2006 est.)
Total fertility rate: 2.98 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS • people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: French Guianese (singular and plural)
adjective: French Guianese
Ethnic groups: black or mulatto 66%, white 12%.
East Indian, Chinese, Amerindian 12%, other 10%
Religions: Roman Catholic
Languages: French
Literacy:
definition: age 15 and over can read and write
total population: 83%
male. 84%
female. 82% (1982 est.)','6159f2d249dd408d154e6f99ae8443809fec6f194dd4c75dba97dbb5e298ef62','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e61c0271f4ff1ceff69065c41bc92b0abc861ac1a821d20edc75e37d3aa732f',2007,'PF','French Polynesia','people-and-society',586,'Population: 274,578 (July 2006 est.)
Age structure:
0-14 years: 26.1% (male 36,541 /female 34,999)
15-64 years: 67.9% (male 96.769/female 89,593) .
65 years and over: 6.1% (male 8,428/female 8,248*)
(2006 est.)
Median age:
total: 27.9 years
male: 28.2 years
female: 27.5 years (2006 est.)
Population growth rate: 1 .48% (2006 est.)
Birth rate: 1 6.68 births/1 ,000 population (2006 est.)
Death rate: 4.69 deaths/1 ,000 population (2006 est.)
Net migration rate: 2.85 migrant(s)/1 .000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .08 male(s)/female
65 years and over: 1 .02 male(s)/female
total population: 1 .07 male(s)/female (2006 est.)
Infant mortality rate:
total: 8.29 deaths/1 ,000 live births
male: 9.55 deaths/1 .000 live births
female: 6.96 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 76.1 years
male: 73.69 years
female: 78.63 years (2006 est.)
Total fertility rate: 2.01 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: French Polynesian(s)
adjective: French Polynesian
Ethnic groups: Polynesian 78%, Chinese 12%,
local French 6%. metropolitan French 4%
Religions: Protestant 54%, Roman Catholic 30%,
other 10%, no religion 6%
Languages: French 61.1% (official), Polynesian
31.4% (official), Asian languages 1 .2%. other 0.3%,
unspecified 6% (2002 census)
Literacy:
definition: age 14 and over can read and write
total population: 98%
male: 98%
female: 98% (1977 est.)','ea18396f8fee04a06fdb89c26a528e02d87f117c8097e1cd41bec01c8e2b5282','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fe47f168f447da3895479ce88efcfdf2ce50760336dbc008757b017aace21a4',2007,'GN','Guinea','people-and-society',594,'Population: 1,424,906
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS; this
can result in lower life expectancy, higher infant mortality
and death rates, lower population and growth rates, and
changes in the distribution of population by age and sex
than would otherwise be expected (July 2006 est.)
Age structure:
0-14 years: 42.1% (male 300,91 4/female 299,141)
15-64 years: 53.9% (male 383,137/female 384,876)
65 years and over: 4% (male 23,576/female 33,262)
(2006 est.)
Median age:
total: 18.6 years
male: 18.4 years
female: 18.8 years (2006 est.)
Population growth rate: 2.13% (2006 est.)
Birth rate: 36.16 births/1,000 population (2006 est.)
Death rate: 12.25 deaths/1 ,000 population
(2006 est.)
Net migration rate: -2.65 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.99 male(s)/female (2006 est.)
Infant mortality rate:
total: 54.51 deaths/1 ,000 live births
male: 63.65 deaths/1 ,000 live births
female: 45.1 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 54.49 years
male: 53.21 years
female: 55.81 years (2006 est.)
Total fertility rate: 4.74 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 8.1% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 48,000
(2003 est.)
HIV/AIDS - deaths: 3,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial diarrhea,
hepatitis A, and typhoid fever
vectorborne disease: malaria (2004)
Nationality:
noun: Gabonese (singular and plural)
adjective: Gabonese
Ethnic groups: Bantu tribes, including four major
tribal groupings (Fang, Bapounou, Nzebi, Obamba),
other Africans and Europeans 154,000, including
10,700 French and 1 1 ,000 persons of dual nationality
Religions: Christian 55%-75%, animist, Muslim less
than 1%
Languages: French (official), Fang, Myene, Nzebi,
Bapounou/Eschira, Bandjabi
Literacy:
definition: age 1 5 and over can read and write
total population: 63.2%
male: 73.7%
female: 53.3% (1995 est.)
Population: 1 ,641 ,564 (July 2006 est.)
Age structure:
0-14 years: 44.3% (male 365,157/female 361.821)
15-64 years: 53% (male 431 ,627/female 438,159)
65 years and over: 2.7% (male 22,889/female
21,911) (2006 est.)
Median age:
total: 17.7 years
male: 17.6 years
female: 17.8 years (2006 est.)
Population growth rate: 2.84% (2006 est.)
Birth rate: 39.37 births/1 ,000 population (2006 est.)
Death rate: 12.25 deaths/ 1 .000 population
(2006 est.)
Net migration rate: 1 .29 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .01 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 1 .05 male(s)/female
total population: 1 male(s)/female (2006 est.)
Infant mortality rate:
total: 71 .58 deaths/1 ,000 live births
male: 78.06 deaths/1 ,000 live births
female: 64.9 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 54.1 4 years
male: 52.3 years
female: 56.03 years (2006 est.)
Total fertility rate: 5.3 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 1 .2% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 6,800
(2003 est.)
HIV/AIDS • deaths: 600 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever
vectorborne diseases: dengue fever, malaria,
Crimean-Congo hemorrhagic fever, yellow fever are
high risks in some locations
water contact disease: schistosomiasis
respiratory disease: meningococcal meningitis (2004)
Nationality:
noun: Gambian(s)
adjective: Gambian
Ethnic groups: African 99% (Mandinka 42%, Fula
18%, Wolof 16%, Jola 10%, Serahuli 9%, other 4%),
non-African 1 %
Religions: Muslim 90%, Christian 9%, indigenous
beliefs 1%
Languages: English (official), Mandinka, Wolof,
Fula, other indigenous vernaculars
Literacy:
definition: age 1 5 and over can read and write
total population: 40.1%
male: 47.8%
female: 32.8% (2003 est.)
Population: 9,690,222 (July 2006 est.)
Age structure:
0-14 years: 44.4% (male 2,171 ,733/female
2,128,027)
15-64 years: 52.5% (male 2,541, 140/female
2,542,847)
65 years and over: 3.2% (male 134,239/female
172,236) (2006 est.)
Median age:
total: 1 7.7 years
male: 17.4 years
female: 17.9 years (2006 est.)
Population growth rate: 2.63% (2006 est.)
Birth rate: 41.76 births/1,000 population (2006 est.)
Death rate: 1 5.48 deaths/1 ,000 population
(2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
note: as a result of conflict in neighboring countries,
Guinea is host to approximately 141 ,500 refugees
from Cote d''lvoire, Liberia, and Sierra Leone
(2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.78 male(s)/female
total population: 1 male(s)/female (2006 est.)
Infant mortality rate:
total: 90 deaths/1 ,000 live births
male: 95.1 6 deaths/1 ,000 live births
female: 84.69 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 49.5 years
male: 48.34 years
female: 50.7 years (2006 est.)
Total fertility rate: 5.79 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 3.2% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 140,000
(2003 est.)
HIV/AIDS - deaths: 9,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever
vectorborne diseases: malaria and yellow fever are
high risks in some locations
water contact disease: schistosomiasis
respiratory disease: meningococcal meningitis
aerosolized dust or soil contact disease: Lassa fever
(2004)
Nationality:
noun: Guinean(s)
adjective: Guinean
Ethnic groups: Peuhl 40%, Malinke 30%, Soussou
20%, smaller ethnic groups 10%
Religions: Muslim 85%, Christian 8%, indigenous
beliefs 7%
Languages: French (official); note - each ethnic
group has its own language
Literacy:
definition: age 1 5 and over can read and write
total population: 35.9%
male: 49.9%
female: 21 .9% (1995 est.)
Population: 193,413 (July 2006 est.)
Age structure:
0-14 years: 47.5% (male 46,478/female 45,302)
15-64 years: 48.8% (male 45,631/femaie 48,661 )
65 years and over: 3.8% (male 3,368/female 3,973)
(2006 est.)
Median age:
total: 16.2 years
male: 15.6 years
female: 16.8 years (2006 est.)
Population growth rate: 3.15% (2006 est.)
Birth rate: 40.25 births/1,000 population (2006 est.)
Death rate: 6.47 deaths/1 ,000 population (2006 est.)
Net migration rate: -2.32 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.85 male(s)/female
total population: 0.98 male(s)/female (2006 est.)
Infant mortality rate:
total: 41 .83 deaths/1 ,000 live births
male: 43.74 deaths/1 ,000 live births
female: 39.86 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 67.31 years
mate: 65.73 years
female: 68.95 years (2006 est.)
Total fertility rate: 5.62 children born/woman
(2006 est.)
HIV/AIDS • adult prevalence rate: NA
HIV/AIDS ■ people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Major infectious diseases:
degree of risk: high
food or waterborne diseases: bacterial diarrhea,
hepatitis A, and typhoid fever
vectorborne disease: malaria (2004)
Nationality:
noun: Sao Tomean(s)
adjective: Sao Tomean
Ethnic groups: mestico, angolares (descendants of
Angolan slaves), forros (descendants of freed slaves),
servicais (contract laborers from Angola, Mozambique,
and Cape Verde), tongas (children of servicais born on
the islands), Europeans (primarily Portuguese)
Religions: Catholic 70.3%, Evangelical 3.4%, New
Apostolic 2%, Adventist 1.8%, other 3.1%, none
19.4% (2001 census)
Languages: Portuguese (official)
Literacy:
definition: age 15 and over can read and write
total population: 79.3%
male: 85%
fema/e:62%(1991 est.)','33e22099031446db8a8718ad9dbd9ad1d003dd34222a89cb6e18b19537c669ad','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2bbc52159dd4f6b1b912bc297aaf6446a60b8ddd50576970cdf4c3602421b0ff',2007,'EG','Egypt','people-and-society',598,'Population: 1 ,428,757 (July 2006 est.)
Age structure:
0-14 years: 48.1% (male 351, 642/female 335,060)
15-64 years: 49.4% (male 360,147/female 345.318)
65 years and over: 2.6% (male 1 5,231 /female
21,359) (2006 est.)
210
Gaza Strip (continued)
Median age:
total: 1 5.8 years
male: 15.7 years
female. 16 years (2006 est.)
Population growth rate: 3.71% (2006 est.)
Birth rate: 39.45 births/1 ,000 population (2006 est.
Death rate: 3.8 deaths/1 ,000 population (2006 est.;
Net migration rate: 1 .48 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 1 .04 male(s)/female (2006 est.)
Infant mortality rate:
total: 22.4 deaths/1 ,000 live births
male: 23.48 deaths/1 ,000 live births
female: 21 .27 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 71 .97 years
male: 70.67 years
female: 73.34 years (2006 est.)
Total fertility rate: 5.78 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: NA
adjective: NA
Ethnic groups: Palestinian Arab and other 99.4%,
Jewish 0.6%
Religions: Muslim (predominantly Sunni) 98.7%,
Christian 0.7%, Jewish 0.6%
Languages: Arabic, Hebrew (spoken by many
Palestinians), English (widely understood)
Literacy:
definition: age 1 5 and over can read and write
total population: 91.9%
male: 96.3%
female: 87.4% (2003 est.)','3a944dd3bf13eceaebe3e14fd61524908c11e851bcd17594e8cd4492acd24536','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0e365148f097f9a68d191de43ba17face3a3e54cfd98733e2041bca35ed9511',2007,'GE','Georgia','people-and-society',607,'Population: 4,661 ,473 (July 2006 est.)
Age structure:
0-14 years: 17.3% (male 428,056/female 380,193)
15-64 years: 66.2% (male 1 ,482,908/female
1,602,064)
65 years and over: 16.5% (male 308,905/female
459,347) (2006 est.)
Median age:
total: 37.7 years
male: 35.3 years
female: 40.1 years (2006 est.)
Population growth rate: -0.34% (2006 est.)
Birth rate: 10.41 births/1,000 population (2006 est.)
Death rate: 9.23 deaths/1 ,000 population (2006 est.;
Net migration rate: -4.54 migrant(s)/1,000
population (2006 est.)
Sex ratio:
at birth: 1.15 male(s)/female
under 15 years: 1.13 male(s)/female
15-64 years: 0.93 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.91 male(s)/female (2006 est.)
Infant mortality rate:
total: 17.97 deaths/1,000 live births
male: 20.06 deaths/1 ,000 live births
female: 15.56 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 76.09 years
male: 72.8 years
female: 79.87 years (2006 est.)
Total fertility rate: 1 .42 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: less than 0.1%
(2001 est.)
HIV/AIDS - people living with HIV/AIDS: 3,000
(2003 est.)
HIV/AIDS - deaths: less than 200 (2003 est.)
Nationality:
noun: Georgian(s)
adjective: Georgian
Ethnic groups: Georgian 83.8%, Azeri 6.5%,
Armenian 5.7%, Russian 1.5%, other 2.5% (2002
census)
Religions: Orthodox Christian 83.9%, Muslim 9.9%
Armenian-Gregorian 3.9%, Catholic 0.8%, other
0.8%, none 0.7% (2002 census)
Languages: Georgian 71% (official), Russian 9%,
Armenian 7%, Azeri 6%, other 7%
note: Abkhaz is the official language in Abkhazia
Literacy:
definition: age 15 and over can read and write
total population: 100%
ma/e:100%
female: 100% (2004 est.)','20e6403b3bf4a08e9e7b222665698e9a9a043b60303a76bb1d348e0e3078113a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24bb7ff816eb0c79deb4dd19f61a121a3da3f81affddb1d474f19ee3af3e459e',2007,'GH','Ghana','people-and-society',615,'Population: 22,409,572
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected
(July 2006 est.)
Age structure:
0-14 years: 38.8% (male 4,395,744/female
4,288,720)
15-64 years: 57.7% (male 6,450,828/female
6,483,781)
65 years and over: 3.5% (male 371 ,428/female
419,071) (2006 est.)
Median age:
total: 19.9 years
male: 19.7 years
female: 20.1 years (2006 est.)
Population growth rate: 2.07% (2006 est.)
Birth rate: 30.52 births/1.000 population (2006 est.)
Death rate: 9.72 deaths/1 ,000 population (2006 est.)
Net migration rate: -0.11 migrant(s)/1 ,000
population (2006 est.)
Sex ratio.
at birth: 1 .03 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.89 male(s)/female
total population: 1 male(s)/female (2006 est.)
218
Ghana (continued)
Infant mortality rate:
total: 55.02 deaths/1 ,000 live births
male: 59.56 deaths/1 ,000 live births
female: 50.33 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 58.87 years
male: 58.07 years
female: 59.69 years (2006 est.)
Total fertility rate: 3.99 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 3. 1 % (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 350,000
(2003 est.)
HIV/AIDS - deaths: 30,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterbome diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever
vectorborne diseases: malaria and yellow fever are
high risks in some locations
water contact disease: schistosomiasis
respiratory disease: meningococcal meningitis (2004)
Nationality:
noun: Ghanaian(s)
adjective: Ghanaian
Ethnic groups: black African 98.5% (major tribes -
Akan 44%, Moshi-Dagomba 16%, Ewe 13%, Ga 8%,
Gurma 3%, Yoruba 1%), European and other 1.5%
(1998)
Religions: Christian 63%, Muslim 16%, indigenous
beliefs 21%
Languages: English (official), African languages
(including Akan, Moshi-Dagomba, Ewe, and Ga)
Literacy:
definition: age 1 5 and over can read and write
total population: 74.8%
male: 82.7%
female: 67.1% (2003 est.)','7504361adfcade76997285c095246ad4db08c32be38851c897ec1bb980fa3313','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7389a683835a7405c5f4686a2a062ad3e5be05ee8b3d6da397f562c9974e1be',2007,'GI','Gibraltar','people-and-society',625,'Population: 27,928 (July 2006 est.)
Age structure:
0-14 years: 17.5% (male 2,499/female 2,388)
15-64 years: 66% (male 9,443/female 8,999)
65 years and over: 16.5% (male 2,059/female 2,540)
(2006 est.)
Median age:
total: 39.8 years
male: 39.4 years
female: 40.1 years (2006 est.)
Population growth rate: 0.14% (2006 est.)
Birth rate: 10.74 births/1 ,000 population (2006 est.)
Death rate: 9.31 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1.05 male(s)/female
65 years and over: 0.81 male(s)/female
total population: 1 .01 male(s)/female (2006 est.)
Infant mortality rate:
total: 5.06 deaths/1 ,000 live births
male: 5.63 deaths/1 ,000 live births
female: 4.46 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 79.8 years
male: 76.92 years
female: 82.83 years (2006 est.)
Total fertility rate: 1 .65 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS • deaths: NA
Nationality:
noun: Gibraltarian(s)
adjective: Gibraltar
Ethnic groups: Spanish, Italian, English, Maltese,
Portuguese, German, North Africans
Religions: Roman Catholic 78.1%, Church of
England 7%, other Christian 3.2%, Muslim 4%, Jewish
2.1%, Hindu 1.8%, other or unspecified 0.9%, none
2.9% (2001 census)
Languages: English (used in schools and for official
purposes), Spanish, Italian, Portuguese
Literacy:
definition: NA
total population: above 80%
male: NA%
female: NA%
Population: no indigenous inhabitants
note: there is a small French military garrison along
with a few meteorologists; visited by scientists
(July 2006 est.)
Population: 33,241 ,259 (July 2006 est.)
Age structure:
0-14 years: 31 .6% (male 5,343,976/female
5,145,019)
15-64 years: 63.4% (male 1 0,505,01 8/female
10,580,599)
65 years and over: 5% (male 725, 1 1 6/female
941,531) (2006 est.)
Median age:
total: 23,9 years
male: 23.4 years
female: 24.5 years (2006 est.)
Population growth rate: 1 .55% (2006 est.)
Birth rate: 21 .98 births/1 ,000 population (2006 est.)
Death rate: 5.58 deaths/1 ,000 population (2006 est.)
Net migration rate: -0.87 migrant(s)/1 ,000
population (2006 est.)
381
MorOCCO (continued)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 0.99 male(s)/female (2006 est.)
Infant mortality rate:
total: 40.24 deaths/1 ,000 live births
male: 43.99 deaths/1 ,000 live births
female: 36.3 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 70.94 years
male: 68.62 years
female: 73.37 years (2006 est.)
Total fertility rate: 2.68 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.1% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 15,000
(2001 est.)
HIV/AIDS - deaths: NA
Major infectious diseases:
degree of risk: intermediate
food or waterbome diseases: bacterial diarrhea, and
hepatitis A
vectorbome diseases: may be a significant risk in
some locations during the transmission season
(typically April through November) (2004)
Nationality:
noun: Moroccan(s)
adjective: Moroccan
Ethnic groups: Arab-Berber 99.1%, other 0.7%,
Jewish 0.2%
Religions: Muslim 98.7%, Christian 1.1%,
Jewish 0.2%
Languages: Arabic (official), Berber dialects, French
often the language of business, government, and
diplomacy
Literacy:
definition: age 15 and over can read and write
total population: 51 .7%
mate: 64.1%
female: 39.4% (2003 est.)
Population: 19,686,505
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected; the
1997 Mozambican census reported a population of
16,099,246 (July 2006 est.)
384
Mozambique (continued)
Age structure:
0-14 years: 42.7% (male 4,229,802/female
4,177,235)
15-64 years: 54.5% (male 5,207, 149/female
5,519,291)
65 years and over: 2.8% (male 230,61 6/female
322,412) (2006 est.)
Median age:
tofa/: 18.3 years
male: 17.8 years
female. 18.8 years (2006 est.)
Population growth rate: 1 .38% (2006 est.)
Birth rate: 35.18 births/1,000 population (2006 est.)
Death rate: 21 .35 deaths/1 ,000 population
(2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.97 male(s)/female (2006 est.)
Infant mortality rate:
total: 129.24 deaths/1 ,000 live births
male: 134.31 deaths/1 ,000 live births
female: 124.02 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 39.82 years
male: 39.53 years
female: 40.13 years (2006 est.)
Total fertility rate: 4.62 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 12.2%
(2003 est.)
HIV/AIDS - people living with HIV/AIDS: 1 .3 million
(2003 est.)
HIV/AIDS - deaths: 1 10,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever
vectorborne diseases: malaria and plague are high
risks in some locations
wafer contact disease: schistosomiasis (2004)
Nationality:
noun: Mozambican(s)
adjective: Mozambican
Ethnic groups: indigenous tribal groups 99.66%
(Makhuwa, Tsonga, Lomwe, Sena, and others),
Europeans 0.06%, Euro-Africans 0.2%, Indians
0.08%
Religions: Catholic 23.8%, Muslim 17.8%, Zionist
Christian 17.5%, other 17.8%, none 23.1% (1997
census)
Languages: Emakhuwa 26. 1 %, Xichangana 1 1 .3%,
Portuguese 8.8% (official; spoken by 27% of
population as a second language), Elomwe 7.6%,
Cisena 6.8%, Echuwabo 5.8%, other Mozambican
languages 32%, other foreign languages 0.3%,
unspecified 1 .3% (1997 census)
Literacy:
definition: age 15 and over can read and write
total population: 47.8%
male: 63.5%
female: 32.7% (2003 est.)','4f6d72f48dc1d5e2f785223eb6feecdd77abc319383260580af63ccdb0ed8126','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8e2a92e132ea6d5156e0234340f2d69b1c60170cfdeb91afd78e80407ef2d18d',2007,'GR','Greece','people-and-society',634,'Population: 1 0,688,058 (July 2006 est.)
Age structure:
0-14 years: 14.3% (male 790,291 /female 742,902)
15-64 years: 66.7% (male 3,562,251 /female
3,566,097)
65 years and over: 19% (male 891 ,620/female
1,134,897) (2006 est.)
Median age:
total: 40.8 years
male: 39.7 years
female: 42 years (2006 est.)
Population growth rate: 0.18% (2006 est.)
Birth rate: 9.68 births/1 ,000 population (2006 est.)
Death rate: 10.24 deaths/1 ,000 population
(2006 est.)
Net migration rate: 2.34 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 0.96 male(s)/female (2006 est.)
Infant mortality rate:
total: 5.43 deaths/1 ,000 live births
male: 5.97 deaths/1 ,000 live births
female: 4.86 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 79.24 years
male: 76.72 years
female: 81 .91 years (2006 est.)
Total fertility rate: 1 .34 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.2% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 9,100
(2001 est.)
HIV/AIDS - deaths: less than 1 00 (2003 est.)
Nationality:
noun: Greek(s)
adjective: Greek
Ethnic groups: Greek 98%, other 2%
note: the Greek Government states there are no
ethnic divisions in Greece
Religions: Greek Orthodox 98%, Muslim 1 .3%, other
0.7%
Languages: Greek 99% (official). English. French
Literacy:
definition: age 15 and over can read and write
total population: 97.5%
male: 98.6%
female: 96.5% (2003 est.)
People - note: women, men, and children are
trafficked to and within Greece for the purposes of
sexual exploitation and forced labor','22d9d59d6abd237e7600522c205286060a52eefaa927857fafed213cb3fc69cd','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('121794db8ec026eea16c83f2171537e63d843d62a2af72a5975c14b4a6f0eeff',2007,'MQ','Martinique','people-and-society',643,'Population: 89.703 (July 2006 est.)
Age structure:
0-14 years: 33.4% (male 15,097/female 14,820)
15-64 years: 63.4% (male 30,106/female 26,764)
65 years and over: 3.3% (male 1 ,394/female 1 ,522)
(2006 est.)
Median age:
total: 21.7 years
male: 22 .1 years
female: 21.2 years (2006 est.)
Population growth rate: 0.26% (2006 est.)
Birth rate: 22.08 births/1,000 population (2006 est.)
Death rate: 6.88 deaths/1 ,000 population (2006 est.)
Net migration rate: -12.59 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 1.13 male(s)/female
65 years and over: 0.92 male(s)/female
total populations .08 male(s)/female (2006 est.)
Infant mortality rate:
total: 14.27 deaths/1 ,000 live births
male: 13.87 deaths/1 ,000 live births
female: 14.67 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 64.87 years
male: 63.06 years
female: 66.68 years (2006 est.)
228
Grenada (continued)
Total fertility rate: 2.34 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Grenadian(s)
adjective: Grenadian
Ethnic groups: black 82%, mixed black and
European 13%, European and East Indian 5%, and
trace of Arawak/Carib Amerindian
Religions: Roman Catholic 53%, Anglican 13.8%,
other Protestant 33.2%
Languages: English (official), French patois
Literacy:
definition: age 15 and over can read and write
total population: 96%
male: NA%
female: NA% (2003 est.)
Population: 436,131 (July 2006 est.)
Age structure:
0-14 years: 22.1% (male 48,988/female 47,525)
15-64 years: 67.3% (male 147,082/female 146,470)
65 years and over: 10.6% (male 20,791/female
25,275) (2006 est.)
Median age:
total: 34.1 years
male: 33.4 years
female: 34.8 years (2006 est.)
Population growth rate: 0.72% (2006 est.)
Birth rate: 1 3.74 births/1 ,000 population (2006 est.)
Death rate: 6.48 deaths/1 ,000 population (2006 est.)
Net migration rate: -0.03 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .02 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 0.99 male(s)/female (2006 est.)
Infant mortality rate:
total: 6.95 deaths/1 ,000 live births
male: 4.68 deaths/1 ,000 live births
female: 9.27 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 79. 1 8 years
male: 79.5 years
female: 78.85 years (2006 est.)
Total fertility rate: 1 .79 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Martiniquais (singular and plural)
adjective: Martiniquais
Ethnic groups: African and African-white-Indian
mixture 90%, white 5%, East Indian and Chinese less
than 5%
Religions: Roman Catholic 85%, Protestant 10.5%,
Muslim 0.5%, Hindu 0.5%, other 3.5% (1997)
Languages: French, Creole patois
Literacy:
definition: age 15 and over can read and write
total population: 97.7%
male: 97.4%
female: 98.1% (2003 est.)','6fef6e29a7514e2b08ade84e624459bdbd338ab2e8c3d367cd546edba18addeb','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54f4861df7260314c1154e690230bb80c281dcc2ff20429b9d8fb846ee0b1121',2007,'GP','Guadeloupe','people-and-society',652,'Population: 452,776 (July 2006 est.)
Age structure:
0-14 years: 23.6% (male 54,725/female 52,348)
15-64 years: 67.1% (male 150,934/female 153,094)
65 years and over: 9.2% (male 1 7,353/female
24,322) (2006 est.)
Median age:
total: 32.2 years
male: 31.3 years
female: 33.2 years (2006 est.)
Population growth rate: 0.88% (2006 est.)
Birth rate: 15.05 births/1.000 population (2006 est.)
Death rate: 6.09 deaths/1 ,000 population (2006 est.)
Net migration rate: -0.15 migrant(s)/1,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.97 male(s)/female (2006 est.)
Infant mortality rate:
total: 8.41 deaths/1 ,000 live births
male: 9.59 deaths/1 ,000 live births
female: 7.16 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 78.06 years
male: 74.91 years
female: 81 .37 years (2006 est.)
Total fertility rate: 1 .9 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS • people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Guadeloupian(s)
adjective: Guadeloupe
Ethnic groups: black or mulatto 90%, white 5%,
East Indian, Lebanese, Chinese less than 5%
Religions: Roman Catholic 95%, Hindu and pagan
African 4%, Protestant 1%
230
Guadeloupe (continued)
Languages: French (official) 99%, Creole patois
Literacy:
definition: age 15 and over can read and write
total population: 90%
male: 90%
female. 90% (1982 est.)','6f96aa4d6d495d35794a2fd712e595e9c752920cf8717ee5788cbbd54b02f7b9','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0760623372d30baf8134ed0b5f75bf1dc29ce62028777e8df48d4aeec52c0a27',2007,'GU','Guam','people-and-society',657,'Population: 1 71 ,01 9 (July 2006 est.)
Age structure:
0-14 years: 29% (male 25,703/female 23,903)
15-64 years: 64.3% (male 56,020/female 53,894)
65 years and over: 6.7% (male 5,391 /female 6,108)
(2006 est.)
Median age:
total: 28.6 years
male: 28.3 years
female: 28.8 years (2006 est.)
Population growth rate: 1 .43% (2006 est.)
Birth rate: 1 8.79 births/1 ,000 population (2006 est.)
Death rate: 4.48 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1.06 male(s)/female
under 15 years: 1 .08 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.88 male(s)/female
total population: 1 04 male(s)/female (2006 est.)
Infant mortality rate:
total: 6.81 deaths/1 ,000 live births
male: 7.48 deaths/1 ,000 live births
female: 6.1 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 78.58 years
male: 75.52 years
female: 81 .83 years (2006 est.)
Total fertility rate: 2.58 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Guamanian(s) (US citizens)
adjective: Guamanian
Ethnic groups: Chamorro 37.1%, Filipino 26.3%,
other Pacific islander 1 1 .3%. white 6.9%, other Asian
6.3%, other ethnic origin or race 2.3%, mixed 9.8%
(2000 census)
Religions: Roman Catholic 85%, other 15%
(1999 est.)
232
Guam (continued)
Languages: English 38.3%, Chamorro 22.2%,
Philippine languages 22.2%, other Pacific island
languages 6.8%, Asian languages 7%, other
languages 3.5% (2000 census)
Literacy:
definition: age 1 5 and over can read and write
total population: 99%
male: 99%
female: 99% (1990 est.)','0c414357e67561ab8ac371b576f4e85e36bdae553ada3236ce418b0e5c1e9017','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('512ff11a89f71852a8aba2205dca3c958abf34eb120a0ab82af20763b49f12b3',2007,'GG','Guernsey','people-and-society',665,'Population: 65,409 (July 2006 est.)
Age structure:
0-14 years: 15% (male 4,998/female 4,842)
15-64 years: 67.1% (male 21,752/female 22,170)
65 years and over: 1 7.8% (male 4,926/female 6,721 )
(2006 est.)
Median age:
total: 41.3 years
male: 40.4 years
female: 42.2 years (2006 est.)
Population growth rate: 0.26% (2006 est.)
Birth rate: 8.81 births/1,000 population (2006 est.)
Death rate: 10.01 deaths/1,000 population
(2006 est.)
Net migration rate: 3.82 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 0.94 male(s)/female (2006 est.)
Infant mortality rate:
total: 4.65 deaths/1 ,000 live births
male: 5.1 9 deaths/1 ,000 live births
female: 4.08 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 80.42 years
male: 77.41 years
female: 83.53 years (2006 est.)
Total fertility rate: 1 .39 children born/woman
(2006 est.)
HIV/AIDS • adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS • deaths: NA
Nationality:
noun: Channel Islander(s)
adjective: Channel Islander
Ethnic groups: UK and Norman-French descent
with small percentages from other European countries
Religions: Anglican, Roman Catholic, Presbyterian,
Baptist, Congregational, Methodist
Languages: English, French, Norman-French
dialect spoken in country districts
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%','0681ff63c8a24358103df4f0e59679f3fd768b5523e33ac964605e6a5973cbcf','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d696f6b292e96119ea21cf4e3dc679533f91e60543f03b4e22ee73ed115c0ac',2007,'GW','Guinea-Bissau','people-and-society',673,'Population: 1 ,442,029 (July 2006 est.)
Age structure:
0-14 years: 41 .4% (male 297,623/female 298,942)
15-64 years: 55.6% (male 384,559/female 417,81 1 )
65 years and over: 3% (male 1 8,048/female 25,046)
(2006 est.)
Median age:
total: 19 years
male: 18.4 years
female: 19.6 years (2006 est.)
Population growth rate: 2.07% (2006 est.)
Birth rate: 37.22 births/1,000 population (2006 est.)
Death rate: 1 6.53 deaths/1 ,000 population
(2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.94 male(s)/female (2006 est.)
Infant mortality rate:
total: 105.21 deaths/1,000 live births
male: 1 15.53 deaths/1 ,000 live births
female: 94.57 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 46.87 years
male: 45.05 years
female: 48.75 years (2006 est.)
Total fertility rate: 4.86 children born/woman
(2006 est.)
HIV/AIDS ■ adult prevalence rate: 1 0% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 17,000
(2001 est.)
HIV/AIDS - deaths: 1 ,200 (2001 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever
vectorborne diseases: malaria and yellow fever are
high risks in some locations
water contact disease: schistosomiasis
respiratory disease: meningococcal meningitis (2004)
Nationality:
noun: Guinean(s)
adjective: Guinean
Ethnic groups: African 99% (includes - Balanta
30%, Fula 20%, Manjaca 14%, Mandinga 13%, Papel
7%), European and mulatto less than 1%
Religions: indigenous beliefs 50%, Muslim 45%,
Christian 5%
Languages: Portuguese (official), Crioulo, African
languages
Literacy:
definition: age 1 5 and over can read and write
total population: 42.4%
male: 58.1%
female: 27.4% (2003 est.)','093cd6b21b90d823bd021487dd471f5ed03845a7cec6b9277f39c5f148496eb1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f2e18f0f51b8734252aa0595a5f815ca9a0012814389c8a20cdc3dd271943fa',2007,'GY','Guyana','people-and-society',676,'Population: 767,245
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS; this
can result in lower life expectancy, higher infant mortality
and death rates, lower population and growth rates, and
changes in the distribution of population by age and sex
than would otherwise be expected (July 2006 est.)
Age structure:
0-14 years: 26.2% (male 102,551/female 98,772)
15-64 years: 68.6% (male 265,193/female 260,892)
65 years and over: 5.2% (male 1 7,043/female
22,794) (2006 est.)
243
Guyana (continued)
Median age:
total: 27 A years
male: 26.9 years
female: 27.9 years (2006 est.)
Population growth rate: 0.25% (2006 est.)
Birth rate: 1 8.28 births/1 ,000 population (2006 est.)
Death rate: 8.28 deaths/1 .000 population (2006 est.)
Net migration rate: -7.49 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 rrde(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 1.01 male(s)/female (2006 est.)
Infant mortality rate:
total: 32.1 9 deaths/1 ,000 live births
male: 35.8 deaths/1 ,000 live births
female: 28 .4 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 65.86 years
male: 63.21 years
female: 68.65 years (2006 est.)
Total fertility rate: 2.04 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 2.5% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 1 1 ,000
(2003 est.)
HIV/AIDS - deaths: 1 , 1 00 (2003 est.)
Nationality:
noun: Guyanese (singular and plural)
adjective: Guyanese
Ethnic groups: East Indian 50%, black 36%,
Amerindian 7%, white, Chinese, and mixed 7%
Religions: Christian 50%, Hindu 35%, Muslim 10%,
other 5%
Languages: English, Amerindian dialects, Creole,
Hindi, Urdu
Literacy:
definition: age 15 and over has ever attended school
total population: 98.8%
male: 99.1%
female: 98.5% (2003 est.)
Population: 439,1 17 (July 2006 est.)
Age structure:
0-14 years: 29% (male 65,41 2/female 62,069)
15-64 years: 64.7% (male 145,913/female 138,076)
65 years and over: 6.3% (male 12,223/female
15,424) (2006 est.)
Median age:
total: 26.5 years
male: 26 years
female: 26.9 years (2006 est.)
Population growth rate: 0.2% (2006 est.)
Birth rate: 18.02 births/1,000 population (2006 est.)
Death rate: 7.27 deaths/1 ,000 population (2006 est.)
Net migration rate: -8.76 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
af birth: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 1 .04 male(s)/female (2006 est.)
Infant mortality rate:
total: 23.02 deaths/1 ,000 live births
male: 26.89 deaths/1 ,000 live births
female: 18.95 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 69.01 years
male: 66.66 years
female: 71 .47 years (2006 est.)
Total fertility rate: 2.32 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 1 .7% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 5,200
(2001 est.)
HIV/AIDS - deaths: less than 500 (2003 est.)
Nationality:
noun: Surinamer(s)
adjective: Surinamese
Ethnic groups: Hindustani (also known locally as
"East Indians"; their ancestors emigrated from
northern India in the latter part of the 19th century)
37%, Creole (mixed white and black) 31%, Javanese
1 5%, "Maroons" (their African ancestors were brought
to the country in the 1 7th and 1 8th centuries as slaves
and escaped to the interior) 10%, Amerindian 2%,
Chinese 2%, white 1%, other 2%
Religions: Hindu 27.4%, Protestant 25.2%
(predominantly Moravian), Roman Catholic 22.8%,
Muslim 1 9.6%, indigenous beliefs 5%
Languages: Dutch (official), English (widely
spoken), Sranang Tongo (Surinamese, sometimes
called Taki-Taki, is native language of Creoles and
much of the younger population and is lingua franca
among others), Hindustani (a dialect of Hindi),
Javanese
Literacy:
definition: age 1 5 and over can read and write
total population: 88%
male: 92.3%
female: 84.1% (2000 est.)
Population: 2,701 (July 2006 est.)
Age structure:
0-74 years: N A
15-64 years: NA
65 years and over: NA (2006 est.)
Population growth rate: -0.02% (2006 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Sex ratio: NA
Infant mortality rate:
total: NA
male: NA
female: NA
Life expectancy at birth:
total population: HA
male: NA
female: NA
Total fertility rate: NA
HIV/AIDS - adult prevalence rate: 0% (2001)
HIV/AIDS • people living with HIV/AIDS: 0 (2001)
HIV/AIDS - deaths: 0(2001)
Ethnic groups: Norwegian 55.4%, Russian and
Ukrainian 44.3%, other 0.3% (1998)
Languages: Norwegian, Russian
Literacy: NA','1d854e079b3ac226bdd9c9cde7555ded14a37853f47e30e00ea2d2f2149f68fc','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8d2a3bcfb8265739f0534715bad475f7f465967a582e543392094ba95579359',2007,'IT','Italy','people-and-society',686,'Population: 932 (July 2006 est.)
Population growth rate: 0.01% (2006 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: none
adjective: none
Ethnic groups: Italians, Swiss, other
Religions: Roman Catholic
Languages: Italian, Latin, French, various other
languages
Literacy:
definition: NA
total population: 100%
male: 100%
fema/e:100%
Population: 29,251 (July 2006 est.)
Age structure:
0-14 years: 16.8% (male 2,534/female 2,372)
15-64 years: 66.2% (male 9,316/female 10,055)
65 years and over: 1 7% (male 2,1 49/female 2,825)
(2006 est.)
Median age:
total: 40.6 years
male: 40.3 years
female: 41 years (2006 est.)
Population growth rate: 1 .26% (2006 est.)
Birth rate: 10.02 births/1 ,000 population (2006 est.)
Death rate: 8.17 deaths/1 ,000 population (2006 est.)
Net migration rate: 10.7 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .09 male(s)/female
under 15 years: 1 .07 male(s)/female
75-64 years: 0.93 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 0.92 male(s)/female (2006 est.)
Infant mortality rate:
total: 5.63 deaths/1 ,000 live births
male: 6.06 deaths/1 ,000 live births
female: 5.17 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 81.71 years
male: 78.23 years
female: 85.5 years (2006 est.)
Total fertility rate: 1 .34 children born/woman
(2006 est.)
HIV/AIDS • adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Sammarinese (singular and plural)
adjective: Sammarinese
Ethnic groups: Sammarinese, Italian
Religions: Roman Catholic
Languages: Italian
Literacy:
definition: age 10 and over can read and write
total population: 96%
male: 97%
female: 95% (1976 est.)
Population: 7,523,934 (July 2006 est.)
Age structure:
0-14 years: 16.3% (male 637,585/female 591 ,297)
15-64 years: 68.1% (male 2,585,062/female
2,539,345)
65 years and over: 1 5.6% (male 480,1 98/female
690,447) (2006 est.)
Median age:
tofa/:40.1 years
male: 39 years
female: 41.1 years (2006 est.)
Population growth rate: 0.43% (2006 est.)
Birth rate: 9.71 births/1,000 population (2006 est.)
Death rate: 8.49 deaths/1 ,000 population (2006 est.)
Net migration rate: 3.12 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
af birth: 1 .05 male(s)/female
under 15 years: 1 .08 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.97 male(s)/female (2006 est.)
Infant mortality rate:
total: 4.34 deaths/1 ,000 live births
male: 4.84 deaths/1 ,000 live births
female: 3.81 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 80.51 years
male: 77.69 years
female: 83.48 years (2006 est.)
Total fertility rate: 1 .43 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.4% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 13.000
(2001 est.)
HIV/AIDS - deaths: less than 100 (2003 est.)
Nationality:
noun: Swiss (singular and plural)
adjective: Swiss
Ethnic groups: German 65%, French 18%, Italian
10%, Romansch 1%, other 6%
Religions: Roman Catholic 41.8%, Protestant
35.3%, Orthodox 1.8%, other Christian 0.4%, Muslim
4.3%, other 1%, unspecified 4.3%, none 11.1% (2000
census)
Languages: German (official) 63.7%, French
(official) 20.4%, Italian (official) 6.5%, Serbo-Croatian
1.5%, Albanian 1.3%, Portuguese 1 .2%, Spanish
1.1%, English 1%, Romansch 0.5%, other 2.8% (2000
census)
note: German, French, Italian, and Romansch are all
national languages, but only the first three are official
languages
Literacy:
definition: age 1 5 and over can read and write
total population: 99%
male: 99%
female: 99% (2003 est.)
534
Switzerland (continued)','5f9b95d9edb565b36fae25b8029aa798056333ff7bf098f0ebe8e09af3133e81','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4db4e21f424ca3e972177ff287f55d96de21cc37a589fdece80046209fd330c',2007,'NI','Nicaragua','people-and-society',696,'Population: 7,326,496
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected
(July 2006 est.)
Age structure:
0-74 years: 39.9% (male 1 ,491 ,170/female
1,429,816)
15-64 years: 56.7% (male 2,076,727/female
2,077,975)
65 years and over: 3.4% (male 1 1 3,747/female
137,061) (2006 est.)
Median age:
total: 19.5 years
male: 19.1 years
female: 19.8 years (2006 est.)
Population growth rate: 2.16% (2006 est.)
Birth rate: 28.24 births/1,000 population (2006 est.)
Death rate: 5.28 deaths/1 ,000 population (2006 est.)
Net migration rate: -1 .39 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 1 5 years: 1.04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 1 .01 male(s)/female (2006 est.)
Infant mortality rate:
total: 25.82 deaths/1 ,000 live births
male: 29 deaths/1 ,000 live births
female: 22.47 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 69.33 years
male: 67.75 years
female: 70.98 years (2006 est.)
Total fertility rate: 3.59 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 1 .8% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 63,000
(2003 est.)
HIV/AIDS - deaths: 4,100 (2003 est.)
Nationality:
noun: Honduran(s)
adjective: Honduran
Ethnic groups: mestizo (mixed Amerindian and
European) 90%, Amerindian 7%, black 2%, white 1%
Religions: Roman Catholic 97%, Protestant 3%
Languages: Spanish, Amerindian dialects
Literacy:
definition: age 15 and over can read and write
total population: 76.2%
male: 76.1%
female: 76.3% (2003 est.)','7b2e06ef02646c839fbf9c37cadead81375fb2a225186c32156891da36a2f469','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a3d1bc7ac0b16cddb295f2fcfde1041ce50738e3015fcabce200a54d8519e03',2007,'RO','Romania','people-and-society',708,'Population: 9,981 ,334 (July 2006 est.)
Age structure:
0-14 years: 15.6% (male 799,163/female 755,389)
15-64 years: 69.2% (male 3.403,375/female
3,505,640)
65 years and over: 15.2% (male 550,297/female
967,470) (2006 est.)
Median age:
total: 38.7 years
male: 36.3 years
female: 41 .4 years (2006 est.)
Population growth rate: -0.25% (2006 est.)
Birth rate: 9.72 births/1 ,000 population (2006 est.)
Death rate: 13.11 deaths/1 ,000 population
(2006 est.)
Net migration rate: 0.86 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.57 male(s)/female
total population: 0.91 male(s)/female (2006 est.)
Infant mortality rate:
total: 8.39 deaths/1 ,000 live births
male: 9.09 deaths/1 ,000 live births
female: 7.64 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 72.66 years
male: 68.45 years
female: 77.14 years (2006 est.)
Total fertility rate: 1 .32 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.1% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 2,800
(2001 est.)
HIV/AIDS - deaths: less than 100 (2001 est.)
Nationality:
noun: Hungarian(s)
adjective: Hungarian
Ethnic groups: Hungarian 92.3%, Roma 1 .9%,
other or unknown 5.8% (2001 census)
Religions: Roman Catholic 51 .9%, Calvinist 1 5.9%,
Lutheran 3%, Greek Catholic 2.6%, other Christian
1%, other or unspecified 11.1%, unaffiliated 14.5%
(2001 census)
Languages: Hungarian 93.6%, other or unspecified
6.4% (2001 census)
Literacy:
definition: age 1 5 and over can read and write
total population: 99.4%
male: 99.5%
female: 99.3% (2003 est.)
Population: 299,388 (July 2006 est.)
Age structure:
0-14 years: 21. 7% (male 33,021 /female 32,021)
15-64 years: 66.5% (male 100,944/female 98,239)
65 years and over: 1 1 .7% (male 1 5,876/female
19,287) (2006 est.)
Median age:
total: 34.2 years
male: 33.8 years
female: 34.7 years (2006 est.)
Population growth rate: 0.87% (2006 est.)
Birth rate: 13.64 births/1,000 population (2006 est.;
Death rate: 6.72 deaths/1 ,000 population (2006 est.
Net migration rate: 1 .74 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at bidh: 1 .04 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.82 male(s)/female
total population: 1 male(s)/female (2006 est.)
Infant mortality rate:
total: 3.29 deaths/1 ,000 live births
male: 3.43 deaths/1 ,000 live births
female: 3.14 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 80.31 years
male: 78.23 years
female: 82.48 years (2006 est.)
Total fertility rate: 1 .92 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.2% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 220
(2001 est.)
HIV/AIDS - deaths: less than 100 (2003 est.)
Nationality:
noun: lcelander(s)
adjective: Icelandic
Ethnic groups: homogeneous mixture of
descendants of Norse and Celts 94%, population of
foreign origin 6%
Religions: Lutheran Church of Iceland 85.5%,
Reykjavik Free Church 2.1%, Roman Catholic Church
2%, Hafnarfjorour Free Church 1.5%, other Christian
2.7%, other or unspecified 3.8%, unaffiliated 2.4%
(2004)
Languages: Icelandic, English, Nordic languages,
German widely spoken
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (2003 est.)
Population: 4,466,706 (July 2006 est.)
Age structure:
0-14 years: 20% (male 455,673/female 438,934)
15-64 years: 69.7% (male 1 ,498,078/female
1,613,489)
65 years and over: 10.3% (male 170,456/female
290,076) (2006 est.)
Median age:
total: 32.3 years
male: 30.3 years
female: 34.3 years (2006 est.)
Population growth rate: 0.28% (2006 est.)
Birth rate: 15.7 births/1,000 population (2006 est.)
Death rate: 1 2.64 deaths/1 ,000 population (2006 est.)
Net migration rate: -0.23 migrant(s)/1,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s);female
15-64 years: 0.93 male(s)/female
65 years and over: 0.59 male(s)/female
total population: 0.91 male(s)/female (2006 est.)
Infant mortality rate:
total: 38.38 deaths/1 ,000 live births
male: 41 .44 deaths/1 ,000 live births
female: 35.17 deaths/1,000 live births (2006 est.)
372
Moldova (continued)
Life expectancy at birth:
total population: 65.65 years
male. 61.61 years
female: 69.88 years (2006 est.)
Total fertility rate: 1 .85 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.2% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 5,500
(2001 est.)
HIV/AIDS - deaths: less than 300 (2001 est.)
Nationality:
noun: Moldovan(s)
adjective: Moldovan
Ethnic groups: Moldovan/Romanian 78.2%,
Ukrainian 8.4%, Russian 5.8%, Gagauz 4.4%,
Bulgarian 1.9%, other 1.3% (2004 census)
note: internal disputes with ethnic Slavs in the
Transnistrian region
Religions: Eastern Orthodox 98%, Jewish 1.5%,
Baptist and other 0.5% (2000)
Languages: Moldovan (official, virtually the same as
the Romanian language), Russian, Gagauz (a Turkish
dialect)
Literacy:
definition: age 15 and over can read and write
total population: 99.1%
male: 99.6%
female: 98.7% (2003 est.)','9114b89bf2c9e901ad944c56001363aa54849975345dc857120c8aae3cb347e1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9be016ae8209605a9c1cd9ecdc207a8db86fe4df722f462bcd14f5bd7122b036',2007,'IN','India','people-and-society',716,'Population: 1 ,095,351 ,995 (July 2006 est.)
Age structure:
0-14 years: 30.8% (male 173,478,760/female
163,852,827)
15-64 years: 64.3% (male 363,876,21 9/female
340,181,764)
65 years and over: 4.9% (male 27,258,020/female
26,704,405) (2006 est.)
Median age:
total: 24.9 years
male: 24.9 years
female: 24.9 years (2006 est.)
Population growth rate: 1 .38% (2006 est.)
Birth rate: 22.01 births/1,000 population (2006 est.)
Death rate: 8.1 8 deaths/1 ,000 population (2006 est.)
Net migration rate: -0.07 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .07 male(s)/female
65 years and over: 1 .02 male(s)/female
total population: 1 .06 male(s)/female (2006 est.)
Infant mortality rate:
total: 54.63 deaths/1 ,000 live births
male: 55.18 deaths/1 ,000 live births
female: 54.05 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 64.71 years
male: 63.9 years
female: 65.57 years (2006 est.)
Total fertility rate: 2.73 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.9% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 5.1 million
(2001 est.)
HIV/AIDS - deaths: 310,000 (2001 est.)
Major infectious diseases:
degree of risk: high
food or waterborne diseases: bacterial diarrhea,
hepatitis A and E, and typhoid fever
vectorborne diseases: dengue fever, malaria, and
Japanese encephalitis are high risks in some
locations
animal contact disease: rabies (2004)
Nationality:
noun: Indian(s)
adjective: Indian
Ethnic groups: Indo-Aryan 72%, Dravidian 25%,
Mongoloid and other 3% (2000)
Religions: Hindu 80.5%, Muslim 13.4%, Christian
2.3%, Sikh 1.9%, other 1.8%, unspecified 0.1% (2001
census)
Languages: English enjoys associate status but is
the most important language for national, political, and
commercial communication; Hindi is the national
language and primary tongue of 30% of the people;
there are 14 other official languages: Bengali, Telugu,
Marathi, Tamil, Urdu, Gujarati, Malayalam, Kannada,
Oriya, Punjabi, Assamese, Kashmiri, Sindhi, and
Sanskrit; Hindustani is a popular variant of Hindi/Urdu
spoken widely throughout northern India but is not an
official language
Literacy:
definition: age 1 5 and over can read and write
total population: 59.5%
male: 70.2%
female: 48.3% (2003 est.)
261
India (continued)','04530d50416ca29e50841f708c319a7a75f989320a1a6a7204108afdaffb26d5','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cab8de593da24d95836d0bc4486f170952713d700471f01a24801df69595cd60',2007,'IE','Ireland','people-and-society',726,'Population: 4,062,235 (July 2006 est.)
Age structure:
0-14 years: 20.9% (male 437,903/female 409,774)
15-64 years: 67.6% (male 1 ,373,771 /female
1,370,452)
65 years and over: 1 1 .6% (male 207,859/female
262,476) (2006 est.)
Median age:
total: 34 years
male: 33.2 years
female: 34.8 years (2006 est.)
Population growth rate: 1.15% (2006 est.)
Birth rate: 1 4.45 births/1 ,000 population (2006 est.)
Death rate: 7.82 deaths/1 ,000 population (2006 est.)
Net migration rate: 4.87 migrant(s)/1,000
population (2006 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1 .07 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 0.99 male(s)/female (2006 est.)
Infant mortality rate:
total: 5.31 deaths/1 ,000 live births
male: 5.82 deaths/1 ,000 live births
female: 4.76 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 77.73 years
male: 75.11 years
female: 80.52 years (2006 est.)
Total fertility rate: 1 .86 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.1% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 2,800
(2001 est.)
HIV/AIDS - deaths: less than 1 00 (2003 est.)
Nationality:
noun: Irishman(men), Irishwoman(women), Irish
(collective plural)
adjective: Irish
Ethnic groups: Celtic, English
Religions: Roman Catholic 88.4%, Church of Ireland
3%, other Christian 1 .6%, other 1 .5%, unspecified 2%,
none 3.5% (2002 census)
Languages: English (official) is the language
generally used, Irish (official) (Gaelic or Gaeilge)
spoken mainly in areas located along the western
seaboard
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (2003 est.)','dca6d040fbcc65bdd14b0288ade905e89a2642a6dbf94fa8d3dd14d5f1e21add','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b88abb5388def3e79050e9cdde217c4d7dfdcfdd2d853e91561c76ab9f43ae5',2007,'IM','Isle of Man','people-and-society',735,'Population: 75,441 (July 2006 est.)
Age structure:
0-14 years: 17.3% (male 6,669/female 6,350)
15-64 years: 65.7% (male 24,884/female 24,678)
65 years and over: 17% (male 5,197/female 7,663)
(2006 est.)
Median age:
total: 39.6 years
male: 38.4 years
female: 41 years (2006 est.)
Population growth rate: 0.52% (2006 est.)
Birth rate: 1 1 .05 births/1 ,000 population (2006 est.)
Death rate: 11.19 deaths/1 ,000 population
(2006 est.)
Net migration rate: 5.3 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
af birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.95 male(s)/female (2006 est.)
Infant mortality rate:
total: 5.82 deaths/1 ,000 live births
male: 6.8 deaths/1 ,000 live births
female: 4.79 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 78.49 years
male: 75.14 years
female: 82.02 years (2006 est.)
Total fertility rate: 1 .65 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Manxman (men), Manxwoman (women)
adjective: Manx
Ethnic groups: Manx (Norse-Celtic descent), Briton
Religions: Anglican, Roman Catholic, Methodist,
Baptist, Presbyterian, Society of Friends
Languages: English, Manx Gaelic
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%','f029248fee9c64c73420427946493bac62f2692fd0c868ad6465adac2504e4fe','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e117527550e6a27ffb2698dc86abd921cd9004ce96bf280d22bdbd3401757257',2007,'TN','Tunisia','people-and-society',744,'Population: 58, 1 33,509 (July 2006 est.)
Age structure:
0-14 years: 13.8% (male 4,147,149/female
3,899,980)
15-64 years: 66.5% (male 1 9,530,51 2/female
19,105,841)
65 years and over: 19.7% (male 4,771 ,858/female
6,678,169) (2006 est.)
Median age:
total: 42.2 years
male: 40.7 years
female: 43.7 years (2006 est.)
282
Italy (continued)
Population growth rate: 0.04% (2006 est.)
Birth rate: 8.72 births/1 ,000 population (2006 est.)
Death rate: 1 0.4 deaths/1 ,000 population (2006 est.)
Net migration rate: 2.06 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.96 male(s)/female (2006 est.)
Infant mortality rate:
total: 5.83 deaths/1 ,000 live births
male: 6.42 deaths/1 ,000 live births
female: 5.19 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 79.81 years
male: 76.88 years
female: 82.94 years (2006 est.)
Total fertility rate: 1 .28 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.5% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 140,000
(2001 est.)
HIV/AIDS - deaths: less than 1 ,000 (2003 est.)
Nationality:
noun: Italian(s)
adjective: Italian
Ethnic groups: Italian (includes small clusters of
German-, French-, and Slovene-Italians in the north
and Albanian-Italians and Greek-Italians in the south)
Religions: predominately Roman Catholic with
mature Protestant and Jewish communities and a
growing Muslim immigrant community
Languages: Italian (official), German (parts of
Trentino-Alto Adige region are predominantly German
speaking), French (small French-speaking minority in
Valle d''Aosta region), Slovene (Slovene-speaking
minority in the Trieste-Gorizia area)
Literacy:
definition: age 1 5 and over can read and write
total population: 98.6%
male: 99%
female: 98.3% (2003 est.)
Population: uninhabited, except for visits by
scientists (July 2006 est.)','46cbe55311704a40a3d634ee8c0efb13eb5dd26d201c7cf5254357b2aa65a074','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5349eb838f28037a143c34573a1558bb31ba9252a125b96c75a71fbd3ab5477a',2007,'IS','Iceland','people-and-society',754,'Population: no indigenous inhabitants
note: personnel operate the Long Range Navigation
(Loran-C) base and the weather and coastal services
radio station (July 2006 est.)','c1a288d916e7841376196f10ccde15f3ab37e96e077b9c821589e1dcd04bbbb8','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43ff329dc586b4af1559f4b3bce5705a4700b5e0bfff63f7b140510d2d11ee36',2007,'JP','Japan','people-and-society',762,'Population: 127,463,611 (July 2006 est.)
Age structure:
0-14 years: 14.2% (male 9,309,524/female
8,849,476)
15-64 years: 65.7% (male 42,158,122/female
41,611,754)
65 years and over: 20% (male 10,762,585/female
14,772,150) (2006 est.)
Median age:
total: 42.9 years
male: 41.1 years
female: 44.7 years (2006 est.)
Population growth rate: 0 02% (2006 est.)
288
Japan (continued)
Birth rate: 9.37 births/1,000 population (2006 est.)
Death rate: 9. 16 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 0.95 male(s)/female (2006 est.)
Infant mortality rate:
total: 3.24 deaths/1 ,000 live births
male: 3.5 deaths/1 ,000 live births
female: 2.97 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 81 .25 years
male: 77.96 years
female: 84.7 years (2006 est.)
Total fertility rate: 1 .4 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: less than 0.1%
(2003 est.)
HIV/AIDS - people living with HIV/AIDS: 12,000
(2003 est.)
HIV/AIDS - deaths: 500 (2003 est.)
Nationality:
noun: Japanese (singular and plural)
adjective: Japanese
Ethnic groups: Japanese 99%, others 1% (Korean
51 1 ,262, Chinese 244,241 , Brazilian 1 82,232, Filipino
89,851, other 237,914)
note: up to 230,000 Brazilians of Japanese origin
migrated to Japan in the 1990s to work in industries;
some have returned to Brazil (2004)
Religions: observe both Shinto and Buddhist 84%,
other 16% (including Christian 0.7%)
Languages: Japanese
Literacy:
definition: age 1 5 and over can read and write
total population: 99%
male: 99%
female: 99% (2002)','8461ac4f8dd9a336bc663c46665d8ac0c821f449a7b12fb4d8c918d0a552c5a8','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cc0ad3ded1daf065885d693962bbf069d98b4e53d3520a440ebf1748447a571',2007,'KZ','Kazakhstan','people-and-society',784,'Population: 34,707,817
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected
(July 2006 est.)
Age structure:
0-14 years: 42.6% (male 7,454,765/female
7,322,130)
15-64 years: 55.1 % (male 9,631 ,488/female
9,508,068)
65 years and over: 2.3% (male 359,354/female
432,012) (2006 est.)
Median age:
total: 18.2 years
male: 18.1 years
female: 18.3 years (2006 est.)
299
Kenya (continued)
Population growth rate: 2.57% (2006 est.)
Birth rate: 39.72 births/1 ,000 population (2006 est.)
Death rate: 14.02 deaths/1 ,000 population
(2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
note: according to the UNHCR, by the end of 2005
Kenya was host to 233,778 refugees from neighboring
countries, including Somalia 153,627, Sudan 67,556,
Ethiopia 12,595 (2006 est.)
Sex ratio:
at birth: 1 .02 male(s)/female
under 15 years: 1.02 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 1 .01 male(s)/female (2006 est.)
Infant mortality rate:
total: 59.26 deaths/1 ,000 live births
male: 61 .92 deaths/1 ,000 live births
female: 56.54 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 48.93 years
male: 49.78 years
female: 48.07 years (2006 est.)
Total fertility rate: 4.91 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 6.7% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 1 .2 million
(2003 est.)
HIV/AIDS - deaths: 1 50,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever
vectorbome disease: malaria is a high risk in some
locations
wafer contact disease: schistosomiasis (2004)
Nationality:
noun: Kenyan(s)
adjective: Kenyan
Ethnic groups: Kikuyu 22%, Luhya 14%, Luo 13%,
Kalenjin 12%, Kamba 11%, Kisii 6%, Mem 6%, other
African 15%, non-African (Asian, European, and
Arab) 1%
Religions: Protestant 45%, Roman Catholic 33%,
indigenous beliefs 10%, Muslim 10%, other 2%
note: a large majority of Kenyans are Christian, but
estimates for the percentage of the population that
adheres to Islam or indigenous beliefs vary widely
Languages: English (official), Kiswahili (official),
numerous indigenous languages
Literacy:
definition: age 15 and over can read and write
total population: 85.1%
male: 90.6%
female: 79.7% (2003 est.)','ad254d63152e177a0311eb6257b6c31567648949de5f3a5ed6600e38474706ed','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1e970b6f4f1f83ea706e791f2fc43f9fd70e1938f25b4fbd39be8b92d7c9b7f',2007,'KI','Kiribati','people-and-society',790,'Population: 105,432 (July 2006 est.)
Age structure:
0-14 years: 38.6% (male 20,608/female 20,060)
15-64 years: 58.1% (male 30,21 6/female 31 ,004)
65 years and over: 3.4% (male 1 ,51 7/female 2,027)
(2006 est.)
Median age:
total: 20.2 years
male: 19.8 years
female: 20.8 years (2006 est.)
Population growth rate: 2.24% (2006 est.)
Birth rate: 30.65 births/1,000 population (2006 est.)
Death rate: 8.26 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.03 male(s)/female
75-64 years: 0.98 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.99 male(s)/female (2006 est.)
Infant mortality rate:
total: 47.27 deaths/1 ,000 live births
male: 52.34 deaths/1 .000 live births
female: 41 .95 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 62.08 years
male: 59.06 years
female: 65.24 years (2006 est.)
Total fertility rate: 4.16 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: l-Kiribati (singular and plural)
adjective: l-Kiribati
Ethnic groups: Micronesian 98.8%, other 1 .2%
(2000 census)
Religions: Roman Catholic 52%, Protestant
(Congregational) 40%, some Seventh-Day Adventist,
Muslim, Baha''i, Latter-day Saints, Church of God
(1999)
Languages: l-Kiribati, English (official)
Literacy:
definition: NA
total population: MAX
male: NA%
female: NA%
Population: 23,113,019 (July 2006 est.)
Age structure:
0-1 4 years: 23.8% (male 2,788,944/female
2,708,331)
15-64 years: 68% (male 7,762,442/female 7,955,522)
65 years and over: 8.2% (male 667,792/female
1,229,988) (2006 est.)
Median age:
total: 32 years
male: 30.7 years
female: 33.4 years (2006 est.)
Population growth rate: 0.84% (2006 est.)
Birth rate: 15.54 births/1 ,000 population (2006 est.)
Death rate: 7.1 3 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.54 male(s)/female
total population: 0.94 male(s)/female (2006 est.)
Infant mortality rate:
total: 23.29 deaths/1 ,000 live births
male: 24.97 deaths/1 ,000 live births
female: 21 .52 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 71 .65 years
male: 68.92 years
female: 74.51 years (2006 est.)
Total fertility rate: 2.1 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Korean(s)
adjective: Korean
Ethnic groups: racially homogeneous; there is a
small Chinese community and a few ethnic Japanese
304
Korea, North (continued)
Religions: traditionally Buddhist and Confucianist,
some Christian and syncretic Chondogyo (Religion of
the Heavenly Way)
note: autonomous religious activities now almost
nonexistent; government-sponsored religious groups
exist to provide illusion of religious freedom
Languages: Korean
Literacy:
definition: age 1 5 and over can read and write
total population: 99%
male: 99%
female: 99%
Population: 48,846,823 (July 2006 est.)
Age structure:
0-14 years: 18.9% (male 4,844,083/female
4,368,139)
15-64 years: 71 .9% (male 1 7,886, 148/female
17,250,862)
65 years and over: 9.2% (male 1 ,81 8,677/female
2,678,914) (2006 est.)
Median age:
total: 35.2 years
male: 34.2 years
female: 36.3 years (2006 est.)
Population growth rate: 0.42% (2006 est.)
Birth rate: 10 births/1 ,000 population (2006 est.)
Death rate: 5.85 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 mtgrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .08 male(s)/female
under 1 5 years: 1.11 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 1. 01 male(s)/female (2006 est.)
Infant mortality rate:
total: 6.16 deaths/1 ,000 live births
male: 6.54 deaths/1 ,000 live births
female: 5.75 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 77.04 years
male: 73.61 years
female: 80.75 years (2006 est.)
Total fertility rate: 1 .27 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: less than 0.1%
(2003 est.)
HIV/AIDS - people living with HIV/AIDS: 8,300
(2003 est.)
HIV/AIDS - deaths: less than 200 (2003 est.)
Nationality:
noun: Korean(s)
adjective: Korean
Ethnic groups: homogeneous (except for about
20,000 Chinese)
Religions: no affiliation 46%, Christian 26%,
Buddhist 26%, Confucianist 1%, other 1%
Languages: Korean, English widely taught in junior
high and high school
Literacy:
definition: age 1 5 and over can read and write
total population: 97.9%
male: 99.2%
female: 96.6% (2002)','29a4cf967dc33e1cba20c75dedfe23a8fa3d84352e3611d2c273810ecb642d84','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4dc6b1112e6da70c2c8ebcb7fd82cba33ad8e17c9cdc672b080f365a9b2d82a',2007,'LB','Lebanon','people-and-society',806,'Population: 3,874,050 (July 2006 est.)
Age structure:
0-14 years: 26.5% (male 523,220/female 502,372)
15-64 years: 66.6% (male 1 ,235,91 5/female
1,342,540)
65 years and over: 7% (male 122,1 55/female
147,848) (2006 est.)
Median age:
total: 27.8 years
male: 26.7 years
female: 28.9 years (2006 est.)
Population growth rate: 1 .23% (2006 est.)
Birth rate: 1 8.52 births/1 ,000 population (2006 est.)
Death rate: 6.21 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 0.94 male(s)/female (2006 est.)
Infant mortality rate:
total: 23.72 deaths/1 ,000 live births
male: 26.34 deaths/1 ,000 live births
female: 20.97 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 72.88 years
male: 70.41 years
female: 75.48 years (2006 est.)
Total fertility rate: 1 .9 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.1% (2001 est.)
HIV/AIDS • people living with HIV/AIDS: 2,800
(2003 est.)
HIV/AIDS - deaths: less than 200 (2003 est.)
Nationality:
noun: Lebanese (singular and plural)
adjective: Lebanese
Ethnic groups: Arab 95%, Armenian 4%, other 1%
Religions: Muslim 59.7% (Shi''a, Sunni, Druze,
Isma''ilite, Alawite or Nusayri), Christian 39%
(Maronite Catholic, Greek Orthodox, Melkite Catholic,
Armenian Orthodox, Syrian Catholic, Armenian
Catholic, Syrian Orthodox, Roman Catholic,
Chaldean, Assyrian, Copt, Protestant), other 1.3%
note: 17 religious sects recognized
Languages: Arabic (official), French, English,
Armenian
Literacy:
definition: age 15 and over can read and write
total population: 87.4%
male: 93.1%
female: 82.2% (2003 est.)','ef87f88b54ebb49b69345cd868407424166ceb1fde7b5b7a49de09dd43f8b7be','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b98a130345baebc0dc46cd0c0efc011f522e2fa6d2b8295e6b42fd94803303a',2007,'ZA','South Africa','people-and-society',814,'Population: 2,022,331
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected
(July 2006 est.)
Age structure:
0-14 years: 36.8% (male 374,102/female 369,527)
15-64 years: 58.3% (male 572,957/female 606,846)
65 years and over: 4.9% (male 39,461/female
59,438) (2006 est.)
Median age:
total: 20.3 years
male: 19.7 years
female: 21 years (2006 est.)
Population growth rate: -0.46% (2006 est.)
Birth rate: 24.75 births/1,000 population (2006 est.)
Death rate: 28.71 deaths/1 ,000 population
(2006 est.)
Net migration rate: -0.68 migrant(s)/1,000
population (2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under T5 years: 1 .01 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.66 male(s)/female
total population: 0.95 male(s)/female (2006 est.)
Infant mortality rate:
total: 87.24 deaths/1 ,000 live births
male: 92.04 deaftis/1 ,000 live births
female: 82.28 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 34.4 years
male: 35.55 years
female: 33.21 years (2006 est.)
Total fertility rate: 3.28 children born/woman
(2006 est.)
322
Lesotho (continued)
HIV/AIDS - adult prevalence rate: 28.9%
(2003 est.)
HIV/AIDS - people living with HIV/AIDS: 320,000
(2003 est.)
HIV/AIDS - deaths: 29,000 (2003 est.)
Nationality:
noun: Mosotho (singular), Basotho (plural)
adjective: Basotho
Ethnic groups: Sotho 99.7%, Europeans, Asians,
and other 0.3%,
Religions: Christian 80%, indigenous beliefs 20%
Languages: Sesotho (southern Sotho), English
(official), Zulu, Xhosa
Literacy:
definition: age 15 and over can read and write
total population: 84.8%
male: 74.5%
female: 94.5% (2003 est.)','d7dbf555e8b410c4ac905eae0950e963316cb4bf585a56a0781abd0ca415b1b9','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('012805e79834f538703114eb7a8b43a0831c4933a6f66a3ca20ae7916635d547',2007,'LR','Liberia','people-and-society',824,'Population: 3,042,004 (July 2006 est.)
Age structure:
0-14 years: 43.1% (male 656,01 6/female 653,734)
15-64 years: 54.2% (male 816,443/female 832,152)
65 years and over: 2.8% (male 40,591/female
43,068) (2006 est.)
Median age:
total: 18.1 years
male: 1 8 years
female: 18.3 years (2006 est.)
Population growth rate: 4.91% (2006 est.)
Birth rate: 44.77 births/1 ,000 population (2006 est.)
Death rate: 23.1 deaths/1 ,000 population (2006 est.)
Net migration rate: 27.39 migrant(s)/1 ,000
population
note: at least 238,500 Liberian refugees are in
surrounding countries; the uncertain security situation
has hindered their ability to return (2006 est.)
Sex ratio:
at bidh: 1 .03 male(s)/female
under 15 years: 1 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.94 male(s)/female
total population: 0.99 male(s)/female (2006 est.)
Infant mortality rate:
total: 155.76 deaths/1 ,000 live births
male: 1 71 .96 deaths/1 ,000 live births
female: 139.06 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 39.65 years
male: 37.99 years
female: 41 .35 years (2006 est.)
Total fertility rate: 6.02 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 5.9% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 100,000
(2003 est.)
HIV/AIDS - deaths: 7,200 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever
vectorborne diseases: malaria and yellow fever are
high risks in some locations
water contact disease: schistosomiasis
aerosolized dust or soil contact disease: Lassa fever
(2004)
Nationality:
noun: Liberian(s)
adjective: Liberian
Ethnic groups: indigenous African tribes 95%
(including Kpelle, Bassa, Gio, Kru, Grebo, Mano,
Krahn, Gola, Gbandi, Loma, Kissi, Vai, Dei, Bella,
Mandingo, and Mende), Americo-Liberians 2.5%
(descendants of immigrants from the US who had
been slaves), Congo People 2.5% (descendants of
immigrants from the Caribbean who had been slaves)
Religions: indigenous beliefs 40%, Christian 40%,
Muslim 20%
Languages: English 20% (official), some 20 ethnic
group languages, of which a few can be written and
are used in correspondence
Literacy:
definition: age 15 and over can read and write
total population: 57.5%
male: 73.3%
female: 41.6% (2003 est.)','dba55963053be291a13bc5942537cfed023bd564809bacf30a96175f750ff928','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4824ebe29f2b3bca319610b268770d07e60d7135281a2ff23d87d58fbb24af9b',2007,'CH','Switzerland','people-and-society',833,'Population: 33,987 (July 2006 est.)
Age structure:
0-14 years: 17.4% (male 2,922/female 2,988)
15-64 years: 70.2% (male 1 1 ,842/female 12,022)
65 years and over: 12.4% (male 1 ,773/female 2,440)
(2006 est.)
Median age:
total: 39.6 years
male: 39.2 years
female: 40.1 years (2006 est.)
Population growth rate: 0.78% (2006 est.)
Birth rate: 10.21 births/1,000 population (2006 est.)
Death rate: 7.1 8 deaths/1 ,000 population (2006 est.)
Net migration rate: 4.77 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .01 male(s)/female
under 15 years: 0.98 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 0.95 male(s)/female (2006 est.)
Infant mortality rate:
total: 4.64 deaths/1 ,000 live births
male: 6.24 deaths/1 ,000 live births
female: 3.04 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 79.68 years
male: 76.1 years
female: 83.28 years (2006 est.)
Total fertility rate: 1.51 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS • people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Liechtensteiner(s)
adjective: Liechtenstein
Ethnic groups: Alemannic 86%, Italian, Turkish,
and other 14%
Religions: Roman Catholic 76.2%, Protestant 7%,
unknown 10.6%, other 6.2% (June 2002)
Languages: German (official), Alemannic dialect
Literacy:
definition: age 1 0 and over can read and write
total population: 100%
male: 100%
female: 100%','5385bd62d495735aa9e65f45a69328ed808cb5abd8bc42cc574daaa4b3b797e5','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('144cbf83bf01cf6492d143cf66e9ca49f244db3c21f50a3d07e120d2b92280f1',2007,'LT','Lithuania','people-and-society',842,'Population: 3,585,906 (July 2006 est.)
Age structure:
0-14 years: 15.5% (male 284,888/female 270,458)
15-64 years: 69.1% (male 1 ,210,557/female
1 ,265,542)
65 years and over: 15.5% (male 190.496/female
363,965) (2006 est.)
Median age:
total: 38.2 years
male: 35.7 years
female: 40.8 years (2006 est.)
Population growth rate: -0.3% (2006 est.)
Birth rate: 8.75 births/1 ,000 population (2006 est.)
Death rate: 1 0.98 deaths/1 ,000 population (2006 est.)
Net migration rate: -0.71 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.52 male(s)/female
total population: 0.89 male(s)/female (2006 est.)
Infant mortality rate:
total: 6.78 deaths/1 ,000 live births
male: 8.12 deaths/1 ,000 live births
female: 5.37 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 74.2 years
male: 69.2 years
female: 79.49 years (2006 est.)
Total fertility rate: 1 .2 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.1% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 1 ,300
(2003 est.)
HIV/AIDS - deaths: less than 200 (2003 est.)
Nationality:
noun: Lithuanian(s)
adjective: Lithuanian
Ethnic groups: Lithuanian 83.4%, Polish 6.7%,
Russian 6.3%, other or unspecified 3.6% (2001
census)
Religions: Roman Catholic 79%, Russian Orthodox
4.1%, Protestant (including Lutheran and Evangelical
Christian Baptist) 1.9%, other or unspecified 5.5%,
none 9.5% (2001 census)
Languages: Lithuanian (official) 82%, Russian 8%,
Polish 5.6%, other and unspecified 4.4% (2001
census)
Literacy:
definition: age 1 5 and over can read and write
total population: 99.6%
male: 99.7%
female: 99.6% (2003 est.)','bff6b3d1cb725e9166b2fe4b2a4de273d015b81fb160607a1feffd7d1b8bc9a5','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da0142cc89881ea4509fcc4c696d1240896bd67c3cbaca7069999f32c2c9a86a',2007,'MW','Malawi','people-and-society',855,'Population: 13,013,926
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected
(July 2006 est.)
Age structure:
0-14 years: 46.5% (male 3,056,522/female
3,000,493)
15-64 years: 50.8% (male 3,277,573/female
3,332,907)
65 years and over: 2.7% (male 1 39,953/female
206,478) (2006 est.)
Median age:
total: 16.5 years
male: 16.2 years
female: 16.8 years (2006 est.)
Population growth rate: 2.38% (2006 est.)
Birth rate: 43.13 births/1 ,000 population (2006 est.)
Death rate: 1 9.33 deaths/1 ,000 population
(2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.68 male(s)/female
total population: 0.99 male(s)/female (2006 est.)
Infant mortality rate:
total: 94.37 deaths/1 ,000 live births
male: 98.66 deaths/1 ,000 live births
female: 89.96 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 41 .7 years
male: 41 .93 years
female: 41 .45 years (2006 est.)
Total fertility rate: 5.92 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 14.2%
(2003 est.)
HIV/AIDS - people living with HIV/AIDS: 900,000
(2003 est.)
HIV/AIDS - deaths: 84,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever
vectorbome diseases: malaria and plague are high
risks in some locations
water contact disease: schistosomiasis (2004)
Nationality:
noun: Malawian(s)
adjective: Malawian
Ethnic groups: Chewa, Nyanja, Tumbuka, Yao,
Lomwe, Sena, Tonga, Ngoni, Ngonde, Asian, European
Religions: Christian 79.9%, Muslim 12.8%, other
3%, none 4.3% (1998 census)
Languages: Chichewa 57.2% (official), Chinyanja
12.8%. Chiyao 10.1%, Chitumbuka 9.5%, Chisena
2.7%, Chilomwe 2.4%, Chitonga 1 .7%, other 3.6%
(1998 census)
Literacy:
definition: age 1 5 and over can read and write
total population: 62.7%
ma/e:76.1%
female: 49.8% (2003 est.)
344
Malawi (continued)','cf8208088da0b54fe2d3f66e43084765dbe061aba4421b2d49fe7f24297bd4a8','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f02ede7667fd33b841d546dbe1b8b1bcc280ab170e18b50d75ce0136fd2b57dc',2007,'MV','Maldives','people-and-society',865,'Population: 359,008 (July 2006 est.)
Age structure:
0-14 years: 43.4% (male 80,1 13/female 75,763)
15-64 years: 53.5% (male 98,040/female 94,029)
65 years and over: 3.1% (male 5,477/female 5,586)
(2006 est.)
Median age:
total: 17.9 years
male: 17.8 years
female: 18 years (2006 est.)
Population growth rate: 2.78% (2006 est.)
Birth rate: 34.81 births/1,000 population (2006 est.)
Death rate: 7.06 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.98 male(s)/female
total population: 1 .05 male(s)/female (2006 est.)
Infant mortality rate:
total: 54.89 deaths/1 ,000 live births
male: 54.01 deaths/1 ,000 live births
female: 55.8 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 64.41 years
male: 63.08 years
female: 65.8 years (2006 est.)
Total fertility rate: 4.9 children born/woman
(2006 est.)
HIV/AIDS • adult prevalence rate: 0.1% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: less than
100 (2001 est.)
HIV/AIDS - deaths: NA
Nationality:
noun: Maldivian(s)
adjective: Maldivian
350
Maldives (continued)
Ethnic groups: South Indians, Sinhalese, Arabs
Religions: Sunni Muslim
Languages: Maldivian Dhivehi (dialect of Sinhala,
script derived from Arabic), English spoken by most
government officials
Literacy:
definition: age 15 and over can read and write
total population: 97.2%
male: 97.1%
female: 97.3% (2003 est.)
Population: 11,716,829 (July 2006 est.)
Age structure:
0-14 years: 48.2% (male 2,857,670/female
2,787,506)
15-64 years: 48.8% (male 2,804,344/female
2,910,097)
65 years and over: 3% (male 146,458/female
210,754) (2006 est.)
Median age:
total: 15.8 years
male: 15.4 years
female: 16.3 years (2006 est.)
Population growth rate: 2.63% (2006 est.)
Birth rate: 49.82 births/1,000 population (2006 est.)
Death rate: 16.89 deaths/1 ,000 population
(2006 est.)
Net migration rate: -6.6 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.96 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.98 male(s)/female (2006 est.)
Infant mortality rate:
tofa/: 107.58 deaths/1 ,000 live births
male: 1 17.32 deaths/1 ,000 live births
female: 97.54 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 49 years
male: 47.05 years
female: 51.01 years (2006 est.)
352
Mali (continued)
Total fertility rate: 7.42 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 1 .9% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 140,000
(2003 est.)
HIV/AIDS - deaths: 1 2,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterbome diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever
vectorbome disease: malaria is a high risk in some
locations
wafer contact disease: schistosomiasis
respiratory disease: meningococcal meningitis (2004)
Nationality:
noun: Malian(s)
adjective: Malian
Ethnic groups: Mande 50% (Bambara, Malinke,
Soninke), Peul 17%, Voltaic 12%, Songhai 6%,
Tuareg and Moor 10%, other 5%
Religions: Muslim 90%, indigenous beliefs 9%,
Christian 1%
Languages: French (official), Bambara 80%,
numerous African languages
Literacy:
definition: age 15 and over can read and write
total population: 46.4%
male: 53.5%
female: 39.6% (2003 est.)','ef0628ff83f34901eb061d9f31b96c8c8da253c29d7c8836ce9553a6c0667f2e','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e9dfc1c24bcdd0de95cadfecba349af4970d7bfa7281c26f3edc1666f378bd70',2007,'MT','Malta','people-and-society',875,'Population: 400,214 (July 2006 est.)
Age structure:
0-14 years: 17.1% (male 35,264/female 33,368)
15-64 years: 69.1% (male 139,890/female 136,767)
65 years and over: 13.7% (male 23,554/female
31 ,371) (2006 est.)
Median age:
total: 38.7 years
male: 37.2 years
female: 40.1 years (2006 est.)
Population growth rate: 0.42% (2006 est.)
Birth rate: 10.22 births/1 ,000 population (2006 est.)
Death rate: 8.1 deaths/1,000 population (2006 est.)
Net migration rate: 2.05 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.99 male(s)/female (2006 est.)
Infant mortality rate:
total: 3.86 deaths/1 ,000 live births
male: 4.34 deaths/1 ,000 live births
female: 3.35 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 79.01 years
male: 76.83 years
female: 81 .31 years (2006 est.)
Total fertility rate: 1 .5 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.2% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: less than
500 (2003 est.)
HIV/AIDS - deaths: less than 100 (2003 est.)
Nationality:
noun: Maltese (singular and plural)
adjective: Maltese
Ethnic groups: Maltese (descendants of ancient
Carthaginians and Phoenicians, with strong elements
of Italian and other Mediterranean stock)
Religions: Roman Catholic 98%
Languages: Maltese (official), English (official)
Literacy:
definition: age 10 and over can read and write
total population: 92.8%
male: 92%
female: 93.6% (2003 est.)','4c474c93a066bae4d9ad9a9ec691dc12a1265b9325f81a3c88a76fbe4c6bab30','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('535364126bd7d657b593a934f173a24bbd275acfbe09077d8430b699e4d0036c',2007,'MH','Marshall Islands','people-and-society',884,'Population: 60,422 (July 2006 est.)
Age structure:
0-14 years: 38.1% (male 1 1 ,720/female 1 1 ,295)
15-64 years: 59.2% (male 18,305/female 17,445)
65 years and over: 2.7% (male 801/female 856)
(2006 est.)
Median age:
total: 20.3 years
male: 20.4 years
female: 20.3 years (2006 est.)
Population growth rate: 2.25% (2006 est.)
Birth rate: 33.05 births/1 ,000 population (2006 est.)
Death rate: 4.78 deaths/1 ,000 population (2006 est.)
Net migration rate: -5.78 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 0.94 male(s)/female
total population: 1 .04 male(s)/female (2006 est.)
Infant mortality rate:
total: 28.43 deaths/1 ,000 live births
male: 31 .93 deaths/1 ,000 live births
female: 24.76 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 70.31 years
male: 68.33 years
female: 72.39 years (2006 est.)
Total fertility rate: 3.85 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS ■ people living with HIV/AIDS: NA
HIV/AIDS • deaths: NA
Nationality:
noun: Marshallese (singular and plural)
adjective: Marshallese
Ethnic groups: Micronesian
Religions: Protestant 54.8%, Assembly of God
25.8%, Roman Catholic 8.4%, Bukot nan Jesus 2.8%,
Mormon 2.1%, other Christian 3.6%, other 1%, none
1.5% (1999 census)
Languages: Marshallese 98.2%, other languages
1.8% (1999 census)
note: English widely spoken as a second language;
both Marshallese and English are official languages
Literacy:
definition: age 15 and over can read and write
total population: 93.7%
male: 93.6%
female: 93.7% (1999)','190091bd032d7aa387e70d5e453476bdb2e2d68b30bdc11ee4667c1f2239fe43','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac5439514bd837bc118ec7041f9832e73439551157975d98511411885af0dc59',2007,'DZ','Algeria','people-and-society',894,'Population: 3,177,388 (July 2006 est.)
Age structure:
0-14 years: 45.6% (male 726,376/female 723,013)
15-64 years: 52.2% (male 818,408/female 839,832)
65 years and over: 2.2% (male 28,042/female
41 ,71 7) (2006 est.)
Median age:
total: 17 years
male: 1 6.8 years
female: 17.3 years (2006 est.)
Population growth rate: 2.88% (2006 est.)
Birth rate: 40.99 births/1,000 population (2006 est.)
Death rate: 12.16 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2006 est.)
Sex ratio:
at birth: 1.03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.98 male(s)/female (2006 est.)
Infant mortality rate:
total: 69.48 deaths/1 ,000 live births
male: 72.44 deaths/1 ,000 live births
female: 66.43 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 53.12 years
male: 50.88 years
female: 55.42 years (2006 est.)
Total fertility rate: 5.86 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0 6% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 9,500
(2003 est.)
HIV/AIDS - deaths: less than 500 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever
vectorborne diseases: malaria and Rift Valley fever
are high risks in some locations
respiratory disease: meningococcal meningitis (2004)
Nationality:
noun: Mauritanian(s)
adjective: Mauritanian
Ethnic groups: mixed Maur/black 40%, Moor 30%,
black 30%
Religions: Muslim 100%
Languages: Arabic (official), Pulaar, Soninke,
French, Hassaniya, Wolof
Literacy:
definition: age 1 5 and over can read and write
total population: 41.7%
male: 51 .8%
female: 31 .9% (2003 est.)
Population: 40,397,842 (July 2006 est.)
Age structure:
0-14 years: 14.4% (male 3,000,686/female
2,821,325)
15-64 years: 67.8% (male 1 3,751, 963/female
13,653,426)
65 years and over: 17.7% (male 2,993,496/female
4,176,946) (2006 est.)
Median age:
total: 39.9 years
male: 38.6 years
female: 41 .3 years (2006 est.)
Population growth rate: 0.13% (2006 est.)
Birth rate: 10.06 births/1,000 population (2006 est.)
Death rate: 9.72 deaths/1 ,000 population (2006 est.)
Net migration rate: 0.99 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.72 male(s)/female
total population: 0.96 male(s)/female (2006 est.)
Infant mortality rate:
total: 4.37 deaths/1 ,000 live births
male: 4.76 deaths/1 ,000 live births
female: 3.95 deaths/1 ,000 live births (2006 est.) •
Life expectancy at birth:
total population: 79.65 years
male: 76.32 years
female: 83.2 years (2006 est.)
Total fertility rate: 1 .28 children born/woman
(2006 est.)
HIV/AIDS • adult prevalence rate: 0.7% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 140,000
(2001 est.)
HIV/AIDS - deaths: less than 1 ,000 (2003 est.)
Nationality:
noun: Spaniard(s)
adjective: Spanish
Ethnic groups: composite of Mediterranean and
Nordic types
Religions: Roman Catholic 94%, other 6%
Languages: Castilian Spanish 74%, Catalan 17%,
Galician 7%, Basque 2%; note - Castilian is the official
language nationwide; the other languages are official
regionally
Literacy:
definition: age 15 and over can read and write
total population: 97.9%
ma/e:98.7%
female: 97.2% (2003 est.)','4f15c541b4a3940bb243c636bc93ad3803c0c7ac7db35ae10acdc64a69242c36','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b75441a5c3f2bd617d8b9e4f6b87aaeb485352610163ba46a88b88267f69d3cd',2007,'MU','Mauritius','people-and-society',904,'Population: 1 ,240,827 (July 2006 est.)
Age structure:
0-14 years: 23.9% (male 149,486/female 147,621)
15-64 years: 69.5% (male 430,288/female 431 ,753)
65 years and over: 6.6% (male 31 ,939/female
49,740) (2006 est.)
Median age:
total: 30.8 years
male: 30 years
female: 31 .8 years (2006 est.)
Population growth rate: 0.82% (2006 est.)
Birth rate: 15.43 births/1 ,000 population (2006 est.)
Death rate: 6.86 deaths/1 ,000 population (2006 est.)
Net migration rate: -0.4 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .02 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.64 male(s)/female
total population: 0.97 male(s)/female (2006 est.)
Infant mortality rate:
total: 14.59 deaths/1 ,000 live births
male: 17.23 deaths/1 ,000 live births
female: 1 1 .9 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 72.63 years
male: 68.66 years
female: 76.66 years (2006 est.)
Total fertility rate: 1 .95 children bom/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.1% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 700
(2001 est.)
HIV/AIDS • deaths: less than 100 (2001 est.)
Nationality:
noun: Mauritian(s)
adjective: Mauritian
Ethnic groups: Indo-Mauritian 68%, Creole 27%,
Sino-Mauritian 3%, Franco-Mauritian 2%
Religions: Hindu 48%, Roman Catholic 23.6%, other
Christian 8.6%, Muslim 16.6%, other 2.5%,
unspecified 0.3%, none 0.4% (2000 census)
Languages: Creole 80.5%, Bhojpuri 12.1%, French
3.4%, English (official; spoken by less than 1% of the
population), other 3.7%, unspecified 0.3% (2000 census)
Literacy:
definition: age 1 5 and over can read and write
total population: 85.6%
male: 88.6%
female: 82.7% (2003 est.)','224a106e9ea73def274bec54d8fe9514032f32e2d7ad5ad07432d9508c75f586','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('624da27acbd07a52cf2e737f3a5384465466939bc749225b4544e16f08a79eff',2007,'MC','Monaco','people-and-society',920,'Population: 32,543 (July 2006 est.)
Age structure:
0-14 years: 15.2% (male 2,539/female 2,417)
15-64 years: 62.1% (male 9,959/female 10,266)
65 years and over: 22.6% (male 3,01 5/female 4,347)
(2006 est.)
Median age:
total: 45.4 years
male: 43.3 years
female: 47.3 years (2006 est.)
Population growth rate: 0.4% (2006 est.)
Birth rate: 9.19 births/1 ,000 population (2006 est.)
Death rate: 12.91 deaths/1,000 population
(2006 est.)
Net migration rate: 7.68 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.91 male(s)/female (2006 est.)
Infant mortality rate:
total: 5.35 deaths/1 ,000 live births
male: 6.19 deaths/1 ,000 live births
female: 4.46 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 79.69 years
male: 75.85 years
female: 83.74 years (2006 est.)
Total fertility rate: 1 .76 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Monegasque(s) or Monacan(s)
adjective: Monegasque or Monacan
Ethnic groups: French 47%, Monegasque 16%,
Italian 16%, other 21%
Religions: Roman Catholic 90%
Languages: French (official), English, Italian,
Monegasque
Literacy:
definition: age 1 5 and over can read and write
total population: 99%
male: 99%
female: 99% (2003 est.)
o v e r n m e n t
Country name:
conventional long form: Principality of Monaco
conventional short form: Monaco
local long form: Principaute de Monaco
local short form: Monaco
Government type: constitutional monarchy
Capital: Monaco
Administrative divisions: none; there are no
first-order administrative divisions as defined by the
US Government, but there are four quarters
(quartiers, singular - quartier); Fontvieille, La
Condamine, Monaco-Ville, Monte-Carlo
Independence: 1419 (beginning of the rule by the
House of Grimaldi)
National holiday: National Day (Prince of Monaco
Holiday), 19 November
Constitution: 17 December 1962
Legal system: based on French law; has not
accepted compulsory ICJ jurisdiction
Suffrage: 21 years of age; universal
Executive branch:
chief of state: Prince ALBERT II (since 6 April 2005)
head of government: Minister of State Jean-Paul
PROUST (since 1 June 2005)
cabinet: Council of Government is under the authority
of the monarch
elections: none; the monarchy is hereditary; minister
of state appointed by the monarch from a list of three
French national candidates presented by the French','d53cfb10debe6de8b2c741143e08b13c0b572e8d5faf3d16de825aaef2254cc9','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fd32c5f08021ea4848349fa5fd9ae1bf59ed2c40d32050c0e3f8bdea3ab1733',2007,'AO','Angola','people-and-society',935,'Population: 2,044,147
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected
(July 2006 est.)
Age structure:
0-14 years: 38.2% (male 393,878/female 387,147)
15-64 years: 58.1% (male 596,557/female 591 ,350)
65 years and over: 3.7% (male 34,245/female
40,970) (2006 est.)
Median age:
total: 20 years
male: 1 9.8 years
female: 20.1 years (2006 est.)
Population growth rate: 0.59% (2006 est.)
Birth rate: 24.32 births/1,000 population (2006 est.)
Death rate: 1 8.86 deaths/1 ,000 population
(2006 est.)
Net migration rate: 0.47 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 1.01 male(s)/female (2006 est.)
Infant mortality rate:
total: 48.1 deaths/1 ,000 live births
male: 51 .99 deaths/1 ,000 live births
female: 44.09 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 43.39 years
male: 44.46 years
female: 42.29 years (2006 est.)
Total fertility rate: 3.06 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 21 .3%
(2003 est.)
HIV/AIDS - people living with HIV/AIDS: 210,000
(2001 est.)
HIV/AIDS - deaths: 16,000 (2003 est.)
Major infectious diseases:
degree of risk: high
food or waterbome diseases: bacterial diarrhea,
hepatitis A, and typhoid fever
vectorborne disease: malaria
water contact disease: schistosomiasis (2004)
Nationality:
noun: Namibian(s)
adjective: Namibian
Ethnic groups: black 87.5%, white 6%, mixed 6.5%
note: about 50% of the population belong to the
Ovambo tribe and 9% to the Kavangos tribe; other
ethnic groups includes Herero 7%, Damara 7%, Nama
5%, Caprivian 4%, Bushmen 3%, Baster 2%, Tswana
0.5%
Religions: Christian 80% to 90% (Lutheran 50% at
least), indigenous beliefs 10% to 20%
Languages: English 7% (official), Afrikaans common
language of most of the population and about 60% of
the white population, German 32%, indigenous
languages (Oshivambo, Herero, Nama)
Literacy:
definition: age 1 5 and over can read and write
total population: 84%
male: 84.4%
female: 83.7% (2003 est.)','c71d5106790db1c8649f8d3c33679499ba7ac50439040d353dc049d3d992642e','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d323c14e0ebc28093d5f4a86906f46eb120b16a97369c90ea43ce63b8291d110',2007,'NR','Nauru','people-and-society',944,'Population: 1 3,287 (July 2006 est.)
Age structure:
0-14 years: 36.9% (male 2,507/female 2,391)
15-64 years: 61 .2% (male 4,004/female 4,1 23)
65 years and over: 2% (male 1 39/female 1 23)
(2006 est.)
Median age:
total: 20.6 years
male: 20 years
female: 21 .2 years (2006 est.)
Population growth rate: 1 .81% (2006 est.)
Birth rate: 24.76 births/1 ,000 population (2006 est.)
Death rate: 6.7 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 1.13 male(s)/female
total population: 1 male(s)/female (2006 est.)
Infant mortality rate:
total: 9.78 deaths/1,000 live births
male: 12.29 deaths/1 ,000 live births
female: 7.14 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 63.08 years
male: 59.5 years
female: 66.84 years (2006 est.)
Total fertility rate: 3.11 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Nauruan(s)
adjective: Nauruan
Ethnic groups: Nauruan 58%, other Pacific Islander
26%, Chinese 8%, European 8%
Religions: Christian (two-thirds Protestant, one-third
Roman Catholic)
Languages: Nauruan (official, a distinct Pacific Island
language), English widely understood, spoken, and used
for most government and commercial purposes
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%
Population: uninhabited
note: transient Haitian fishermen and others camp on
the island (July 2006 est.)','d7d802d93a3575eb2251db5727e400e3d61578bab226f5bb4e2e434951b65f98','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('defa8f1588d25a3faccd50564989d5b844e4d9dbb172ad1c415ee5df5b826345',2007,'NP','Nepal','people-and-society',955,'Population: 28,287,147 (July 2006 est.)
Age structure:
0- 14 years: 38.7% (male 5,648,959/female
5,291,447)
15-64 years: 57.6% (male 8,365,526/female
7,925,941)
65 years and over: 3.7% (male 51 3,777/female
541,497) (2006 est.)
Median age:
total: 20.3 years
male: 20.1 years
female: 20.4 years (2006 est.)
Population growth rate: 2.17% (2006 est.)
Birth rate: 30.98 births/1 ,000 population (2006 est.)
Death rate: 9.31 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .07 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 0.95 male(s)/female
total population: 1 .06 male(s)/female (2006 est.)
Infant mortality rate:
total: 65.32 deaths/1 ,000 live births
male: 63.56 deaths/1 ,000 live births
female: 67.17 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 60.18 years
male: 60.43 years
female: 59.91 years (2006 est.)
Total fertility rate: 4.1 children born/woman
(2006 est.)
HIV/AIDS • adult prevalence rate: 0.5% (2001 est.)
HIV/AIDS • people living with HIV/AIDS: 61 ,000
(2001 est.)
HIV/AIDS - deaths: 3,100 (2003 est.)
Nationality:
noun: Nepalese (singular and plural)
adjective: Nepalese
Ethnic groups: Chhettri 15.5%, Brahman-Hill
12.5%, Magar 7%, Tharu 6.6%, Tamang 5.5%, Newar
5.4%, Muslim 4.2%, Kami 3.9%, Yadav 3.9%, other
32.7%, unspecified 2.8% (2001 census)
Religions: Hindu 80.6%, Buddhist 10.7%, Muslim
4.2%, Kirant 3.6%, other 0.9% (2001 census)
note: only official Hindu state in the world
Languages: Nepali 47.8%, Maithali 12.1%, Bhojpuri
7.4%, Tharu (Dagaura/Rana) 5.8%, Tamang 5.1%,
Newar 3.6%, Magar 3.3%, Awadhi 2.4%, other 10%,
unspecified 2.5% (2001 census)
note: many in government and business also speak
English
Literacy:
definition: age 15 and over can read and write
total population: 45.2%
male: 62.7%
female: 27.6% (2003 est.)
Population: 16,491,461 (July 2006 est.)
Age structure:
0-14 years: 18% (male 1, 51 5, 123/female 1,445,390)
15-64 years: 67.8% (male 5,656,448/female
5,525,481)
65 years and over: 14.2% (male 994,723/female
1,354,296) (2006 est.)
Median age:
total: 39.4 years
male: 38.6 years
female: 40.2 years (2006 est.)
Population growth rate: 0.49% (2006 est.)
Birth rate: 10.9 births/1 ,000 population (2006 est.)
Death rate: 8.68 deaths/1 ,000 population (2006 est.)
Net migration rate: 2.72 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 0.98 male(s)/female (2006 est.)
Infant mortality rate:
total: 4.96 deaths/1 ,000 live births
male: 5.52 deaths/1 ,000 live births
female: 4.38 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 78.96 years
male: 76.39 years
female: 81 .67 years (2006 est.)
Total fertility rate: 1 .66 children born/woman
(2006 est.)
HIV/AIDS ■ adult prevalence rate: 0.2% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 19,000
(2001 est.)
HIV/AIDS - deaths: less than 1 00 (2003 est.)
Nationality:
noun: Dutchman(men), Dutchwoman(women)
adjective: Dutch
Ethnic groups: Dutch 83%, other 1 7% (of which 9%
are non-Western origin mainly Turks, Moroccans,
Antilleans, Surinamese, and Indonesians) (1999 est.)
Religions: Roman Catholic 31%, Dutch Reformed
13%, Calvinist 7%, Muslim 5.5%, other 2.5%, none
41% (2002)
Languages: Dutch (official), Frisian (official)
Literacy:
definition: age 1 5 and over can read and write
total population: 99%
male: 99%
female: 99% (2003 est.)','025fdfb8d23c12aa95bef1dc447bf0bfcbd7ad346c088b4accad2520c0c1609d','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecda6a38840559455cec9aaaf228b6512161fe82dd3a2d208ccdf358c54bc041',2007,'NL','Netherlands','people-and-society',960,'Population: 221 ,736 (July 2006 est.)
Age structure:
0-14 years: 23.9% (male 27,197/female 25,886)
15-64 years: 67.3% (male 71 ,622/female 77,710)
65 years and over: 8.7% (male 7,925/female 1 1 ,396)
(2006 est.)
Median age:
total: 32.8 years
male: 31.1 years
female: 34.4 years (2006 est.)
Population growth rate: 0.79% (2006 est.)
Birth rate: 14.78 births/1,000 population (2006 est.)
Death rate: 6.45 deaths/1 ,000 population (2006 est.)
Net migration rate: -0.4 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.93 male(s)/female (2006 est.)
Infant mortality rate:
total: 9.76 deaths/1 ,000 live births
male: 10.54 deaths/1,000 live births
female: 8.93 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 76.03 years
male: 73.76 years
female: 78.41 years (2006 est.)
Total fertility rate: 1 .99 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Dutch Antillean(s)
adjective: Dutch Antillean
Ethnic groups: mixed black 85%, Carib Amerindian,
white, East Asian
Religions: Roman Catholic 72%, Pentecostal 4.9%,
Protestant 3.5%, Seventh-Day Adventist 3.1%,
Methodist 2.9%, Jehovah''s Witnesses 1 .7%, other
Christian 4.2%, Jewish 1.3%, other or unspecified
1.2%, none 5.2% (2001 census)
Languages: Papiamento 65.4% (a
Spanish-Portuguese-Dutch-English dialect), English
15.9% (widely spoken), Dutch 7.3% (official), Spanish
6.1%, Creole 1.6%, other 1.9%, unspecified 1.8%
(2001 census)
Literacy:
definition: age 15 and over can read and write1
total population: 96.7%
male: 96.7%
female: 96.8% (2003 est.)','fe6ee7c14b21ba3e2117957c875bd79e1914321a3986c698fe77b110e94773b1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('76fc20e7ff5e9dc99da42e15bdb2ebb9384170ad83f761389c4571b3f1297ea0',2007,'ML','Mali','people-and-society',969,'Population: 12,525,094 (July 2006 est.)
Age structure:
0-14 years: 46.9% (male 2,994,022/female
2,882,273)
15-64 years: 50.7% (male 3,262,1 14/female
3,083,522)
65 years and over: 2.4% (male 1 50,982/female
152,181) (2006 est.)
Median age:
total: 16.5 years
male: 16.5 years
female: 16.4 years (2006 est.)
Population growth rate: 2.92% (2006 est.)
Birth rate: 50.73 births/1,000 population (2006 est.)
Death rate: 20.91 deaths/1,000 population
(2006 est.)
Net migration rate: -0.61 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at bidh: 1 .03 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 0.99 male(s)/female
total population: 1 .05 male(s)/female (2006 est.)
Infant mortality rate:
total: 1 1 8.25 deaths/1 ,000 live births
male: 122.29 deaths/1,000 live births
female: 1 14.1 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 43.76 years
male: 43.8 years
female: 43.73 years (2006 est.)
407
Niger (continued)
Total fertility rate: 7.46 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 1 .2% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 70,000
(2003 est.)
HIV/AIDS - deaths: 4,800 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever
vectorbome disease: malaria is a high risk in some
locations
respiratory disease: meningococcal meningitis (2004)
Nationality:
noun: Nigerien(s)
adjective: Nigerien
Ethnic groups: Hausa 56%, Djerma 22%, Fula
8.5%, Tuareg 8%, Beri Beri (Kanouri) 4.3%, Arab,
Toubou, and Gourmantche 1 .2%, about 1 ,200 French
expatriates
Religions: Muslim 80%, remainder indigenous
beliefs and Christian
Languages: French (official), Hausa, Djerma
Literacy:
definition: age 15 and over can read and write
total population: 17.6%
male: 25.8%
female: 9.7% (2003 est.)','f62da1941605772c205a6a8bf3683f1ebb0ef7b7c4f412391ab8870292897972','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7582ac0da2c9d9279dc00acee675ef8576fe29cdd7c03a1d476dd679c8a539de',2007,'NE','Niger','people-and-society',979,'Population: 131,859,731
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected
(July 2006 est.)
Age structure:
0-14 years: 42.3% (male 28,089,01 7/female
27,665,212)
15-64 years: 54.6% (male 36,644,885/female
35,405,915)
65 years and over: 3. 1 % (male 1 ,930,007/female
2,124,695) (2006 est.)
Median age:
total: 18.7 years
male: 18.7 years
female: 18.6 years (2006 est.)
Population growth rate: 2.38% (2006 est.)
Birth rate: 40.43 births/1 ,000 population (2006 est.)
Death rate: 1 6.94 deaths/1 ,000 population (2006 est.)
Net migration rate: 0.27 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at bidh: 1 .03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.91 male(s)/female
total population: 1 .02 male(s)/female (2006 est.)
Infant mortality rate:
total: 97.14 deaths/1 ,000 live births
male: 104.05 deaths/1 ,000 live births
female: 90.02 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 47.08 years
male: 46.52 years
female: 47.66 years (2006 est.)
Total fertility rate: 5.49 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 5.4% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 3.6''million
(2003 est.)
HIV/AIDS - deaths: 310,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterbome diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever
vectorborne disease: malaria
respiratory disease: meningococcal meningitis
aerosolized dust or soil contact disease: one of the
most highly endemic areas for Lassa fever (2004)
Nationality:
noun: Nigerian(s)
adjective: Nigerian
Ethnic groups: Nigeria, Africa''s most populous
country, is composed of more than 250 ethnic groups;
the following are the most populous and politically
influential: Hausa and Fulani 29%, Yoruba 21%, Igbo
(Ibo) 18%, Ijaw 10%, Kanuri 4%, Ibibio 3.5%, Tiv 2.5%
Religions: Muslim 50%, Christian 40%, indigenous
beliefs 10%
Languages: English (official), Hausa, Yoruba, Igbo
(Ibo), Fulani
Literacy:
definition: age 15 and over can read and write
total population: 68%
male: 75.7%
female: 60.6% (2003 est.)','e72f233a2057fcbec43e5b3edca43ffcb92a7d2f137335e1e4b5363d32652090','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7871f6befb74175d4e6410943edd12821e15ed4b9805991cb776aebb94c7191',2007,'NU','Niue','people-and-society',985,'Population: 2,166 (July 2006 est.)
Age structure:
0-14 years: HA
15-64 years: NA
65 years and over: NA (2006 est.)
Population growth rate: 0.01% (2006 est.)
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Net migration rate: NA migrant(s)/1 ,000 population
Sex ratio: NA
Infant mortality rate:
total: NA
male: NA
female: NA
Life expectancy at birth:
total population: NA
male: NA
female: NA
Total fertility rate: NA
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Niuean(s)
adjective: Niuean
Ethnic groups: Niuen 78.2%, Pacific islander
10.2%, European 4.5%, mixed 3.9%, Asian 0.2%,
unspecified 3% (2001 census)
Religions: Ekalesia Niue (Niuean Church - a
Protestant church closely related to the London
Missionary Society) 61.1%, Latter-Day Saints 8.8%,
Roman Catholic 7.2%, Jehovah''s Witnesses 2.4%,
Seventh-Day Adventist 1 .4%, other 8.4%, unspecified
8.7%, none 1.9% (2001 census)
Languages: Niuean, a Polynesian language closely
related to Tongan and Samoan; English
Literacy:
definition: NA
total population: 95%
male: NA%
female: NA%','334439ac6a2a9187e64c12d9629aceac43e177c79bcd33e073b264c7b8cfb15b','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('882630025849c69909c4b82da90b0ecfeac3f338d165bd1e9ea4629cbd29307c',2007,'NF','Norfolk Island','people-and-society',994,'Population: 1 ,828 (July 2006 est.)
Age structure:
0-14 years. 20.2%
15-64 years: 63.9%
65 years and over: 15.9% (2006 est.)
Population growth rate: -0.01% (2006 est.)
Birthrate: NA
Death rate: NA deaths/1 ,000 population
Net migration rate: NA
Sex ratio: NA
Infant mortality rate:
total: NA
male: NA
female: NA
Life expectancy at birth:
total population: NA
male: NA
female: NA
Total fertility rate: NA
HIV/AIDS • adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Norfolk Islander(s)
adjective: Norfolk Islander(s)
Ethnic groups: descendants of the Bounty
mutineers, Australian, New Zealander, Polynesian
Religions: Anglican 34.9%, Roman Catholic 1 1.7%,
Uniting Church in Australia 11.2%, Seventh-Day
Adventist 2.8%, Australian Christian 2.4%, Jehovah''s
Witness 0.9%, other 2.7%, unspecified 15.3%, none
18.1% (2001 census)
Languages: English (official), Norfolk a mixture of
18th century English and ancient Tahitian
Literacy: NA
G o v e r n m e
Country name:
conventional long form: Territory of Norfolk Island
conventional short form: Norfolk Island
Dependency status: territory of Australia; Canberra
administers Commonwealth responsibilities on
Norfolk Island through the Department of
Environment, Sport, and Territories
Government type: NA
Capital: Kingston
Administrative divisions: none (territory of
Australia)
Independence: none (territory of Australia)
National holiday: Bounty Day (commemorates the
arrival of Pitcairn Islanders), 8 June (1856)
Constitution: Norfolk Island Act of 1979
Legal system: based on the laws of Australia, local
ordinances and acts; English common law applies in
matters not covered by either Australian or Norfolk
Island law
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II (since 6 February
1952); the UK and Australia are represented by
Administrator Grant TAMBLING (since 1 November
2003)
head of government: Assembly President and Chief
Minister Geoffrey Robert GARDNER (since
5 December 2001)
cabinet: Executive Council is made up of four of the
nine members of the Legislative Assembly; the council
devises government policy and acts as an advisor to
the administrator
elections: the monarch is hereditary; administrator
appointed by the governor general of Australia; chief
minister elected by the Legislative Assembly for a
term of not more than three years; election last held
20 October 2004 (next to be held by December 2007)
election results: Geoffrey Robert GARDNER elected
chief minister; percent of Legislative Assembly vote -
17.2%
Legislative branch: unicameral Legislative Assembly
(9 seats; members elected by electors who have nine
equal votes each but only four votes can be given to any
one candidate; members serve three-year terms)
elections: last held 20 October 2004 (next to be held
by December 2007)
election results: percent of vote - NA%; seats -
independents 9 (note - no political parties)
Judicial branch: Supreme Court; Court of Petty
Sessions
Political parties and leaders: none
Political pressure groups and leaders: none
International organization participation: UPU
Diplomatic representation in the US: none
(territory of Australia)
Diplomatic representation from the US: none
(territory of Australia)
Flag description: three vertical bands of green (hoist
side), white, and green with a large green Norfolk Island
pine tree centered in the slightly wider white band','a489d7176c29d5254b368063969ffa4ab5962079424daebc7638cf0ebae6b2f9','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2fed681c761c18d60b1fd89dc25101a11010ecebfaacf478f3f57d9d48b6c40',2007,'OM','Oman','people-and-society',1006,'Population: 3,102,229
note: includes 577,293 non-nationals (July 2006 est.)
Age structure:
0-1 4 years: 42.7% (male 675,423/female 648,963)
15-64 years: 54.7% (male 1 ,001 ,917/female 695,578)
65 years and over: 2.6% (male 44,300/female
36,048) (2006 est.)
Median age:
total: 1 9 years
male: 21.7 years
female: 16.5 years (2006 est.)
Population growth rate: 3.28% (2006 est.)
Birth rate: 36.24 births/1,000 population (2006 est.)
Death rate: 3.81 deaths/1 ,000 population (2006 est.)
Net migration rate: 0.35 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .44 male(s)/female
65 years and over: 1 .23 male(s)/female
total population: 1 .25 male(s)/female (2006 est.)
Infant mortality rate:
total: 18.89 deaths/1,000 live births
male: 21 .65 deaths/1 ,000 live births
female: 16 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 73.37 years
male: 71.14 years
female: 75.72 years (2006 est.)
Total fertility rate: 5.77 children born/woman
(2006 est.)
HIV/AIDS • adult prevalence rate: 0.1% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 1 ,300
(2001 est.)
HIV/AIDS ■ deaths: less than 200 (2003 est.)
Nationality:
noun: Omani(s)
adjective: Omani
Ethnic groups: Arab, Baluchi, South Asian (Indian,
Pakistani, Sri Lankan, Bangladeshi), African
Religions: Ibadhi Muslim 75%, Sunni Muslim, Shi''a
Muslim, Hindu
Languages: Arabic (official), English, Baluchi, Urdu,
Indian dialects
Literacy:
definition: NA
total population: 75.8%
ma/e:83.1%
female: 67.2% (2003 est.)','5ce2cf8ecf8d375ddccbf55c905cc3a9a67f9abe4fb17373a9197fe3e9a4b7a8','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c872de61c97aa4efc5fdc1fe36e37f1b89fe3f6a01d73637a058a2d67ecc53ba',2007,'PK','Pakistan','people-and-society',1015,'Population: 1 65,803,560 (July 2006 est.)
Age structure:
0-14 years: 39% (male 33,293,428/female
31,434,314)
15-64 years: 56.9% (male 48,21 4,298/female
46,062,933)
65 years and over: 4.1% (male 3,256,065/female
3,542,522) (2006 est.)
Median age:
total: 19.8 years
male: 19.7 years
female: 20 years (2006 est.)
Population growth rate: 2.09% (2006 est.)
Birth rate: 29.74 births/1,000 population (2006 est.)
Death rate: 8.23 deaths/1 ,000 population (2006 est.)
Net migration rate: -0.59 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
af birth: 1 .05 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 0.92 male(s)/female
total population: 1 .05 male(s)/female (2006 est.)
424
Pakistan (continued)
Infant mortality rate:
total: 70.45 deaths/1 ,000 live births
male: 70.84 deaths/1 ,000 live births
female: 70.04 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 63.39 years
male: 62.4 years
temale: 64.44 years (2006 est.)
Total fertility rate: 4 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.1% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 74,000
(2001 est.)
HIV/AIDS - deaths: 4,900 (2003 est.)
Major infectious diseases:
degree of risk: high
food or waterbome diseases: bacterial diarrhea,
hepatitis A and E, and typhoid fever
vectorborne diseases: dengue fever, malaria, and
cutaneous leishmaniasis are high risks depending on
location
animal contact disease: rabies (2004)
Nationality:
noun: Pakistani(s)
adjective: Pakistani
Ethnic groups: Punjabi, Sindhi, Pashtun (Pathan),
Baloch, Muhajir (immigrants from India at the time of
partition and their descendants)
Religions: Muslim 97% (Sunni 77%, Shi''a 20%),
Christian, Hindu, and other 3%
Languages: Punjabi 48%, Sindhi 12%, Siraiki (a
Punjabi variant) 10%, Pashtu 8%, Urdu (official) 8%,
Balochi 3%, Hindko 2%, Brahui 1%, English (official
and lingua franca of Pakistani elite and most
government ministries), Burushaski, and other 8%
Literacy:
definition: age 15 and over can read and write
total population: 48.7%
male: 61.7%
female: 35.2% (2004 est.)','459927ddf0795a84b29ff634ef54a835fcb4941de17748c4b57141af98bca3be','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('627aa8fe3d0083ec94b81820b21a2e88a2696b9088b3e3a5e97604cd5e03e602',2007,'PW','Palau','people-and-society',1024,'Population: 20,579 (July 2006 est.)
Age structure:
0-14 years: 26.3% (male 2,789/female 2,622)
15-64 years: 69.1% (male 7,664/female 6,549)
65 years and over: 4.6% (male 453/female 502)
(2006 est.)
Median age:
total: 31.7 years
male: 32.7 years
female: 30.7 years (2006 est.)
Population growth rate: 1 .31 % (2006 est.)
Birth rate: 18.03 births/1 ,000 population (2006 est.)
Death rate: 6.8 deaths/1 ,000 population (2006 est.)
Net migration rate: 1 .85 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1.17 male(s)/female
65 years and over: 0.9 male(s)/female
total population: 1 .13 male(s)/female (2006 est.)
Infant mortality rate:
total: 14.46 deaths/1 ,000 live births
male: 16.19 deaths/1,000 live births
female: 12.63 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 70.42 years
male: 67.26 years
female: 73.77 years (2006 est.)
Total fertility rate: 2.46 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Palauan(s)
adjective: Palauan
Ethnic groups: Palauan (Micronesian with Malayan
and Melanesian admixtures) 69.9%, Filipino 15.3%,
Chinese 4.9%, other Asian 2.4%, white 1.9%,
Carolinian 1.4%, other Micronesian 1.1%, other or
unspecified 3.2% (2000 census)
Religions: Roman Catholic 41 .6%, Protestant
23.3%, Modekngei 8.8% (indigenous to Palau),
Seventh-Day Adventist 5.3%, Jehovah''s Witness
0.9%, Latter-Day Saints 0.6%, other religion 3.1%,
unspecified or none 16.4% (2000 census)
Languages: Palauan 64.7% official in all islands
except Sonsoral (Sonsoralese and English are
official), Tobi (Tobi and English are official), and
Angaur (Angaur, Japanese, and English are official),
Filipino 13.5%, English 9.4%, Chinese 5.7%,
Carolinian 1 .5%, Japanese 1 .5%, other Asian 2.3%,
other languages 1 .5% (2000 census)
Literacy:
definition: age 1 5 and over can read and write .
total population: 92%
male: 93%
female: 90% (1980 est.)','86e6fcf2488942de3a6a910dc1a7097f1e6d5aeb96fdf613f8f2ed1c242eca00','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffc2e8398f886e37be732e09734cedbeaaf066bdea7996ad427e473446090b0d',2007,'MX','Mexico','people-and-society',1036,'Population: 38,536,869 (July 2006 est.)
Age structure:
0-14 years: 15.9% (male 3,142,81 1 /female
2,976,363)
15-64 years: 70.8% (male 13,585,306/female
13,704,763)
65 years and over: 1 3.3% (male 1 ,961 ,326/female
3,166,300) (2006 est.)
Median age:
total: 37 years
ma/e:35.1 years
female: 39 years (2006 est.)
Population growth rate: -0.05% (2006 est.)
Birth rate: 9.85 births/1 ,000 population (2006 est.)
Death rate: 9.89 deaths/1 ,000 population (2006 est.)
Net migration rate: -0.46 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.62 male(s)/female
total population: 0.94 male(s)/female (2006 est.)
Infant mortality rate:
total: 7.22 deaths/1 ,000 live births
male: 7.95 deaths/1 ,000 live births
female: 6.44 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 74.97 years
male: 70.95 years
female: 79.23 years (2006 est.)
Total fertility rate: 1 .25 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.1% ; note - no
country specific models provided (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 14,000
(2003 est.)
HIV/AIDS - deaths: 100(2001 est.)
Nationality:
noun: Pole(s)
adjective: Polish
Ethnic groups: Polish 96.7%, German 0.4%,
Belarusian 0.1%, Ukrainian 0.1%, other and
unspecified 2.7% (2002 census)
Religions: Roman Catholic 89.8% (about 75%
practicing), Eastern Orthodox 1 .3%, Protestant 0.3%,
other 0.3%, unspecified 8.3% (2002)
Languages: Polish 97.8%, other and unspecified
2.2% (2002 census)
Literacy:
definition: age 15 and over can read and write
total population: 99.8%
male: 99.8%
female: 99.7% (2003 est.)','557dbc905b942e454546a2341edb0388f46dce3da42bd2a35d7e63564286fe4a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e34ae044993ce45925d1721d70bf4375d9a5f4e0efb11e6501a1ab6a59bce2bd',2007,'PT','Portugal','people-and-society',1040,'Religions: Roman Catholic 94%, Protestant (1995)
Languages: Portuguese (official), Mirandese
(official - but locally used)
Literacy:
definition: age 15 and over can read and write
total population: 93.3%
male: 95.5%
female: 91 .3% (2003 est.)','ac8585313b934e53be4816cb281b59847c02d1853748fe4918f8fa51cfcc1c83','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('840548867365ccb51527b3746089c669cc936bb26d542679a834da108e66486c',2007,'DO','Dominican Republic','people-and-society',1042,'Population: 3,927,188 (July 2006 est.)
Age structure:
0-14 years: 21.3% (male 428,61 0/female 409,484)
15-64 years: 65.8% (male 1,239,255/female
1,345,519)
65 years and over: 12.8% (male 218,045/female
286,275) (2006 est.)
Median age:
total: 34.7 years
male: 33 years
female: 36.4 years (2006 est.)
Population growth rate: 0.4% (2006 est.)
Birth rate: 12.77 births/1 ,000 population (2006 est.)
Death rate: 7.65 deaths/1 ,000 population (2006 est.)
Net migration rate: -1 .14 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 0.92 male(s)/female (2006 est.)
Infant mortality rate:
total: 9.14 deaths/1 ,000 live births
male: 10.32 deaths/1 ,000 live births
female: 7.9 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 78.4 years
male: 74.46 years
female: 82.54 years (2006 est.)
Total fertility rate: 1 .75 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS • people living with HIV/AIDS: 7,397
(1997)
HIV/AIDS - deaths: NA
Nationality:
noun: Puerto Rican(s) (US citizens)
adjective: Puerto Rican
Ethnic groups: white (mostly Spanish origin) 80.5%,
black 8%, Amerindian 0.4%, Asian 0.2%, mixed and
other 10.9%
Religions: Roman Catholic 85%, Protestant and
other 15%
Languages: Spanish, English
Literacy:
definition: age 1 5 and over can read and write
total population: 94. 1 %
male: 93.9%
female: 94.4% (2002 est.)','0c245635dabda7fc4125f990066d27369d830753ef5cb4f9990259731c24d46d','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afa123dadb3a1c0ead44acba0662d3ef2dcdb01c390b56977517ed1b97e26c69',2007,'UA','Ukraine','people-and-society',1053,'Population: 22,303,552 (July 2006 est.)
Age structure:
0-14 years: 15.7% (male 1,799,072/female
1,708,030)
15-64 years: 69.6% (male 7,724,368/female
7,797,065)
65 years and over: 14.7% (male 1 ,347,392/female
1 ,927,625) (2006 est.)
Median age:
total: 36.6 years
male: 35.3 years
female: 37.9 years (2006 est.)
Population growth rate: -0.12% (2006 est.)
Birth rate: 10.7 births/1,000 population (2006 est.)
Death rate: 1 1 .77 deaths/1 ,000 population
(2006 est.)
Net migration rate: -0.13 migrant(s)/1,000
population (2006 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.7 male(s)/female
total population: 0.95 male(s)/female (2006 est.)
Infant mortality rate:
total: 25.5 deaths/1 ,000 live births
male: 28.64 deaths/1 ,000 live births
female: 22.16 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 71 .63 years
male: 68.14 years
female: 75.34 years (2006 est.)
Total fertility rate: 1 .37 children born/woman
(2006 est.)
HIV/AIDS ■ adult prevalence rate: less than 0.1%
(2001 est.)
HIV/AIDS - people living with HIV/AIDS: 6,500
(2001 est.)
HIV/AIDS - deaths: 350 (2001 est.)
Nationality:
noun: Romanian(s)
adjective: Romanian
Ethnic groups: Romanian 89.5%, Hungarian 6.6%,
Roma 2.5%, Ukrainian 0.3%, German 0.3%, Russian
0.2%, Turkish 0.2%, other 0.4% (2002 census)
Religions: Eastern Orthodox (including all
sub-denominations) 86.8%, Protestant (various
denominations including Reformate and Pentecostal)
7.5%, Roman Catholic 4.7%, other (mostly Muslim)
and unspecified 0.9%, none 0.1% (2002 census)
Languages: Romanian (official), Hungarian,
German
Literacy:
definition: age 15 and over can read and write
total population: 98.4%
male: 99.1%
female: 97.7% (2003 est.)
Population: 142,893,540 (July 2006 est.)
Age structure:
0-14 years: 14.2% (male 10,441, 151/female
9,921,102)
15-64 years: 71 .3% (male 49,271 ,698/female
52,679,463)
65 years and over: 14.4% (male 6.500,81 4/female
14,079,312) (2006 est.)
Median age:
total: 38.4 years
male: 35.2 years
female: 41 .3 years (2006 est.)
Population growth rate: -0.37% (2006 est.)
Birth rate: 9.95 births/1 ,000 population (2006 est.)
Death rate: 14.65 deaths/1 ,000 population
(2006 est.)
462
RuSSJa (continued)
Net migration rate: 1 .03 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.46 male(s)/female
total population: 0.86 male(s)/female (2006 est.)
Infant mortality rate:
total: 15.13 deaths/1,000 live births
male: 17.43 deaths/1,000 live births
female: 12.7 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 67.08 years
male: 60.45 years
female: 74.1 years (2006 est.)
Total fertility rate: 1 .28 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 1.1% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 860,000
(2001 est.)
HIV/AIDS - deaths: 9,000 (2001 est.)
Nationality:
noun: Russian(s)
adjective: Russian
Ethnic groups: Russian 79.8%, Tatar 3.8%,
Ukrainian 2%, Bashkir 1.2%, Chuvash 1.1%, other or
unspecified 12.1% (2002 census)
Religions: Russian Orthodox, Muslim, other
Languages: Russian, many minority languages
Literacy:
definition: age 1 5 and over can read and write
total population: 99.6%
male: 99.7%
female: 99.5% (2003 est.)
Population: 46,710,816 (July 2006 est.)
Age structure:
0-14 years: 14.1% (male 3,377,868/female
3,203,738)
15-64 years: 69.3% (male 15,559,998/female
16,831,486)
65 years and over: 16.6% (male 2,635,651 /female
5,102,075) (2006 est.)
Median age:
total: 39.2 years
male: 35.9 years
female: 42.2 years (2006 est.)
Population growth rate: -0.6% (2006 est.)
Birth rate: 8.82 births/1 ,000 population (2006 est.)
Death rate: 14.39 deaths/1 ,000 population
(2006 est.)
Net migration rate: -0.43 migrant(s)/1,000
population (2006 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.52 male(s)/female
total population: 0.86 male(s)/female (2006 est.)
Infant mortality rate:
total: 9.9 deaths/1 ,000 live births
male: 1 1 .48 deaths/1 ,000 live births
female: 8.22 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 69.98 years
male: 64.71 years
female: 75.59 years (2006 est.)
Total fertility rate: 1.17 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 1 .4% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 360,000
(2001 est.)
HIV/AIDS - deaths: 20,000 (2003 est.)
573
Ukraine (continued)
Nationality:
noun: Ukrainian(s)
adjective: Ukrainian
Ethnic groups: Ukrainian 77.8V Russian 17.3%,
Belarusian 0.6°o. Moldovan 0.5°o, Crimean Tatar
3.5%. Bulgarian 0.4°o, Hungarian 0.3%, Romanian
0.3%. Polish 0.3%, Jewish 0.2%, other 1.8% (2001
census)
Religions: Ukrainian Orthodox - Kiev Patriarchate
19%, Orthodox (no particular jurisdiction) 16%,
Ukrainian Orthodox - Moscow Patriarchate 9%,
Ukrainian Greek Catholic 6%, Ukrainian
Autocephalous Orthodox 1.7%, Protestant, Jewish,
none 38% (2004 est.)
Languages: Ukrainian (official) 67%, Russian 24%;
small Romanian-, Polish-, and Hungarian-speaking
minorities
Literacy:
definition: age 15 and over can read and write
total population: 99.7%
male: 99.8%
female: 99.6% (2003 est.)
People • note: the sex trafficking of Ukrainian
women is a serious problem that has only recently
been addressed','4d40e769335000ad20c780e7600bd779f97463cf74ab228321d0e3ae0ac993f0','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1728403895da0252bc7705b07c22710118acd63d89358b64385a4302a11fde7',2007,'RW','Rwanda','people-and-society',1063,'Population: 8,648.248
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected
(July 2006 est.)
Age structure:
0-14 years: 41 .9% (male 1.817.998/female
1,802,134)
15-64 years: 55.6% (male 2,392,778/female
2,417,467)
65 years and over: 2.5% (male 87,325/female
130,546) (2006 est.)
Median age:
total: 18.6 years
male: 18.4 years
female: 18.8 years (2006 est.)
Population growth rate: 2.43% (2006 est.)
Birth rate: 40.37 births/1,000 population (2006 est.)
Death rate: 16.09 deaths/1 ,000 population
(2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 1 5 years: 1.01 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.67 male(s)/female
total population: 0.99 male(s)/female (2006 est.)
Infant mortality rate:
total: 89.61 deaths/1 ,000 live births
male: 94.71 deaths/1 ,000 live births
female: 84.34 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 47.3 years
male: 46.26 years
female: 48.38 years (2006 est.)
Total fertility rate: 5.43 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 5.1% (2003 est.)
HIV/AIDS • people living with HIV/AIDS: 250,000
(2003 est.)
HIV/AIDS • deaths: 22,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterbome diseases: bacterial diarrhea,
hepatitis A, and typhoid fever
vectorborne disease: malaria (2004)
Nationality:
noun: Rwandan(s)
adjective: Rwandan
Ethnic groups: Hutu 84%, Tutsi 15%, Twa
(Pygmoid) 1%
Religions: Roman Catholic 56.5%, Protestant 26%,
Adventist 11.1%, Muslim 4.6%, indigenous beliefs
0.1%, none 1.7% (2001)
Languages: Kinyarwanda (official) universal Bantu
vernacular, French (official), English (official),
Kiswahili (Swahili) used in commercial centers
Literacy:
definition: age 1 5 and over can read and write
total population: 70.4%
male: 76.3%
female: 64.7% (2003 est.)
People - note: Rwanda is the most densely
populated country in Africa
Population: 7,502
note: only Saint Helena, Ascension, and Tristan da
Cunha islands are inhabited (July 2006 est.)
Age structure:
0-14 years: 18.8% (male 717/female 692)
15-64 years: 71 .2% (male 2,751 /female 2,593)
65 years and over: 10% (male 342/female 407)
(2006 est.)
Median age:
total: 36 years
male: 36.2 years
female: 35.8 years (2006 est.)
Population growth rate: 0.56% (2006 est.)
Birth rate: 12.13 births/1,000 population (2006 est.)
Death rate: 6.53 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .06 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 1 .03 male(s)/female (2006 est.)
Infant mortality rate:
total: 18.34 deaths/1 ,000 live births
male: 21 .96 deaths/1 ,000 live births
female: 14.53 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 77.93 years
male: 75.02 years
female: 80.98 years (2006 est.)
Total fertility rate: 1 .55 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS • people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Saint Helenian(s)
adjective: Saint Helenian
note: referred to locally as "Saints"
Ethnic groups: African descent 50%, white 25%,
Chinese 25%
Religions: Anglican (majority), Baptist, Seventh-Day
Adventist, Roman Catholic
Languages: English
Literacy:
definition: age 20 and over can read and write
total population: 97%
male: 97%
female: 98% (1987 est.)','db86c785c333b6f63b4d45ad7d19dc6ba79d1f41153e932b0ff0676bb5a2c9a1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44796f321553f1ba6c8e203d3f2e165d394b702a48071a7aaf4a3ee1331b75d9',2007,'TT','Trinidad and Tobago','people-and-society',1071,'Population: 39,1 29 (July 2006 est.)
Age structure:
0-14 years: 27.5% (male 5,515/female 5,263)
15-64 years: 64.3% (male 12,605/female 12,572)
65 years and over: 8. 1 % (male 1 ,31 3/female 1 ,861 )
(2006 est.)
Median age:
total: 27.8 years
male: 27 ''.1 years
female: 28.6 years (2006 est.)
Population growth rate: 0.5% (2006 est.)
Birth rate: 18.02 births/1 ,000 population (2006 est.)
Death rate: 8.33 deaths/1 ,000 population (2006 est.)
Net migration rate: -4.7 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.71 male(s)/female
total population: 0.99 male(s)/female (2006 est.)
Infant mortality rate:
total: 14.12 deaths/1 ,000 live births
male: 15.85 deaths/1 ,000 live births
female: 12.28 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 72 A years
male: 69.56 years
female: 75.42 years (2006 est.)
Total fertility rate: 2.31 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS ■ deaths: NA
Nationality:
noun: Kittitian(s), Nevisian(s)
adjective: Kittitian, Nevisian
Ethnic groups: predominantly black; some British,
Portuguese, and Lebanese
Religions: Anglican, other Protestant, Roman
Catholic
Languages: English
Literacy:
definition: age 1 5 and over has ever attended school
total population: 97.8%
male: NA%
female: NA% (2003 est.)
Population: 1 17,848 (July 2006 est.)
Age structure:
0-14 years: 26.7% (male 16,007/female 15,426)
15-64 years: 66.9% (male 40,676/female 38,155)
65 years and over: 6.4% (male 3,31 5/female 4,269)
(2006 est.)
Median age:
total: 26.9 years
male: 26.7 years
female: 27 .1 years (2006 est.)
Population growth rate: 0.26% (2006 est.)
Birth rate: 16.18 births/1,000 population (2006 est.)
Death rate: 5.98 deaths/1 ,000 population (2006 est.)
Net migration rate: -7.59 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .07 male(s)/female
65 years and over: 0.78 male(s)/female
total population: 1 .04 male(s)/female (2006 est.)
Infant mortality rate:
total: 14.4 deaths/1 ,000 live births
male: 15.67 deaths/1 ,000 live births
female: 13.08 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 73.85 years
male: 71.99 years
female: 75.77 years (2006 est.)
Total fertility rate: 1 .83 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Saint Vincentian(s) or Vincentian(s)
adjective: Saint Vincentian or Vincentian
Ethnic groups: black 66%, mixed 19%, East Indian
6%, Carib Amerindian 2%, other 7%
Religions: Anglican 47%, Methodist 28%, Roman
Catholic 13%, Hindu, Seventh-Day Adventist, other
Protestant
Languages: English, French patois
Literacy:
definition: age 1 5 and over has ever attended school
total population: 96%
male: 96%
female: 96% (1970 est.)','a6f2a33ce82bd5524af543a88ddf743b9c84e5bc7a30dadba9f5f8c39c5eec1c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77db8642e355b110433851b772a8776dea5b6022544e57a4456b59b0ff95cbb5',2007,'LC','Saint Lucia','people-and-society',1081,'Population: 168,458 (July 2006 est.)
Age structure:
0-14 years: 29.8% (male 25,941 /female 24,319)
15-64 years: 65% (male 53,91 6/female 55,582)
65 years and over: 5.2% (male 3,186/female 5,514)
(2006 est.)
Median age:
total: 25.2 years
male: 24 .4 years
female: 26.1 years (2006 est.)
Population growth rate: 1 .29% (2006 est.)
Birth rate: 19.68 births/1,000 population (2006 est.)
Death rate: 5.08 deaths/1 ,000 population (2006 est.)
Net migration rate: -1 .73 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1 .07 male(s)/female
15-64 years: 0.97 male(s)/female
65 years and over: 0.58 male(s)/female
total population: 0.97 male(s)/female (2006 est.)
Infant mortality rate:
total: 13.17 deaths/1 ,000 live births
male: 14.29 deaths/1 ,000 live births
female: 1 1 .97 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 73.84 years
male: 70.29 years
female: 77.65 years (2006 est.)
Total fertility rate: 2.18 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Saint Lucian(s)
adjective: Saint Lucian
Ethnic groups: black 90%, mixed 6%, East Indian
3%, white 1%
Religions: Roman Catholic 67.5%, Seventh Day
Adventist 8.5%, Pentecostal 5.7%, Anglican 2%,
Evangelical 2%, other Christian 5.1%, Rastafarian
2.1%, other 1 .1%, unspecified 1 .5%, none 4.5% (2001
census)
Languages: English (official), French patois
Literacy:
definition: age 1 5 and over has ever attended school
total population: 90.1%
male: 89.5%
female: 90.6% (2001 est.)
Population: 7,026 (July 2006 est.)
Age structure:
0-14 years: 23.5% (male 843/female 807)
15-64 years: 65.7% (male 2,342/female 2,272)
65 years and over: 10.8% (male 348/female 414)
(2006 est.)
Median age:
fofa/: 34.1 years
male: 33.7 years
female: 34.5 years (2006 est.)
Population growth rate: 0.17% (2006 est.)
Birth rate: 13.52 births/1,000 population (2006 est.)
Death rate: 6.83 deaths/1 ,000 population (2006 est.)
Net migration rate: -4.98 migrant(s)/1,000
population (2006 est.)
Sex ratio:
at birth: 1 .07 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 1 .01 male(s)/female (2006 est.)
Infant mortality rate:
total: 7.38 deaths/1 ,000 live births
male: 8.46 deaths/1 ,000 live births
female: 6.24 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 78.61 years
male: 76.27 years
female: 81 .06 years (2006 est.)
Total fertility rate: 2.01 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Frenchman(men), Frenchwoman(women)
adjective: French
Ethnic groups: Basques and Bretons (French
fishermen)
Religions: Roman Catholic 99%
Languages: French (official)
Literacy:
definition: age 1 5 and over can read and write
total population: 99%
male: 99%
female: 99% (1982 est.)','10750f69a5517d377144c1e3b3789560877d0bda19f5d2fa81dcaf626fe4a6a2','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('419b09c45df6cb37b8d0fa9a36bfa0001002b0d17d720f59fea01c6cf8d1592b',2007,'WS','Samoa','people-and-society',1092,'Population: 176,908 (July 2006 est.)
Age structure:
0-14 years: 26.1% (male 23,492/female 22,653)
15-64 years: 67.3% (male 74,202/female 44,894)
65 years and over: 6.6% (male 5,299/female 6,368)
(2006 est.)
Median age:
total: 25.2 years
male: 28.1 years
female: 22 years (2006 est.)
Population growth rate: -0.2% (2006 est.)
Birth rate: 16.43 births/1,000 population (2006 est.;
Death rate: 6.62 deaths/1 ,000 population (2006 est.
Net migration rate: -1 1 .76 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .65 male(s)/female
65 years and over: 0.83 male(s)/female
total population^ .39 male(s)/female (2006 est.)
Infant mortality rate:
total: 26.85 deaths/1 ,000 live births
male: 31 .7 deaths/1 ,000 live births
female: 21 .76 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 7 1 years
male: 68.2 years
female: 73.94 years (2006 est.)
Total fertility rate: 2.94 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: 12
HIV/AIDS - deaths: 3
Nationality:
noun: Samoan(s)
adjective: Samoan
Ethnic groups: Samoan 92.6%, Euronesians 7%
(persons of European and Polynesian blood),
Europeans 0.4%
Religions: Congregationalist 34.8%, Roman
Catholic 19.6%, Methodist 15%, Latter-Day Saints
12.7%, Assembly of God 6.6%, Seventh-Day
Adventist 3.5%, other Christian 4.5%, Worship Centre
1.3%, other 1.7%, unspecified 0.1% (2001 census)
Languages: Samoan (Polynesian), English
Literacy:
definition: age 1 5 and over can read and write
total population: 99.7%
male: 99.6%
female: 99.7% (2003 est.)','06717db6e61cc84d79c36b8fc468ead25ee7a125becad573d2e9adb6481f629d','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9bd6b1c84dcbd0ef2e3d5015e7917c3cfb83edc0401836f455b055a3e69a47e5',2007,'SA','Saudi Arabia','people-and-society',1102,'Population: 27,019,731
note: includes 5,576,076 non-nationals
(July 2006 est.)
Age structure:
0-14 years: 38.2% (male 5,261 ,530/female
5,059,041)
15-64 years: 59.4% (male 9,1 59,51 9/female
6,895,616)
65 years and over: 2.4% (male 342,020/female
302,005) (2006 est.)
Median age:
total: 21.4 years
male: 22.9 years
female: 19.4 years (2006 est.)
Population growth rate: 2.18% (2006 est.)
Birth rate: 29.34 births/1,000 population (2006 est.)
Death rate: 2.58 deaths/1 ,000 population (2006 est.)
Net migration rate: -4.94 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at binh: 1 .05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 1 .33 male(s)/female
65 years and over: 1.13 male(s)/female
total population:). 2 male(s)/female (2006 est.)
Infant mortality rate:
total: 12.81 deaths/1 ,000 live births
male: 14.71 deaths/1 ,000 live births
female: 10.83 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 75.67 years
male: 73.66 years
female: 77.78 years (2006 est.)
Total fertility rate: 4 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.01 %
(2001 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Saudi(s)
adjective: Saudi or Saudi Arabian
Ethnic groups: Arab 90%, Afro-Asian 10%
Religions: Muslim 100%
Languages: Arabic
Literacy:
definition: age 1 5 and over can read and write
total population: 78.8%
male: 84.7%
female: 70.8% (2003 est.)','930d84f7af1ea3e1ecac70bebb180526bcfcc97a93678c98e5ae7f40a8591d40','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36f47dec2bc151f4b32bac5edb4a97c5a5576f79a5eb50677f57077388ee9b6b',2007,'SN','Senegal','people-and-society',1110,'Population: 11,987,121 (July 2006 est.)
Age structure:
0-14 years: 40.8% (male 2,467,021 /female
2,422,385)
15-64 years: 56.1% (male 3,346,756/female
3,378,518)
65 years and over: 3. 1 % (male 1 74,399/female
198,042) (2006 est.)
Median age:
tote/: 19.1 years
male: 18.9 years
female: 19.3 years (2006 est.)
Population growth rate: 2.34% (2006 est.)
Birth rate: 32.78 births/1 ,000 population (2006 est.)
Death rate: 9.42 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.88 male(s)/female
total population: 1 male(s)/female (2006 est.)
Infant mortality rate:
total: 52.94 deaths/1 ,000 live births
male: 56.49 deaths/1 ,000 live births
female: 49.29 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 59.25 years
male: 57.7 years
female: 60.85 years (2006 est.)
Total fertility rate: 4.38 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.8% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 44,000
(2003 est.)
HIV/AIDS - deaths: 3,500 (2003 est.)
Major infectious diseases:
degree of risk: very high
foocf or waterborne diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever
vectorbome diseases: dengue fever, malaria, yellow
fever, Crimean-Congo hemorrhagic fever, and Rift
Valley fever are high risks in some locations
water contact disease: schistosomiasis
respiratory disease: meningococcal meningitis (2004)
Nationality:
noun: Senegalese (singular and plural)
adjective: Senegalese
Ethnic groups: Wolof 43.3%, Pular 23.8%, Serer
14.7%, Jola 3.7%, Mandinka 3%, Soninke 1.1%,
European and Lebanese 1%, other 9.4%
Religions: Muslim 94%, Christian 5% (mostly
Roman Catholic), indigenous beliefs 1%
Languages: French (official), Wolof, Pulaar, Jola,
Mandinka
Literacy:
definition: age 15 and over can read and write
total population: 40.2%
male: 50%
female: 30.7% (2003 est.)
G o v e r n m e
Country name:
conventional long form: Republic of Senegal
conventional short form: Senegal
local long form: Republique du Senegal
local short form: Senegal
former: Senegambia (along with The Gambia); Mali
Federation
Government type: republic under multiparty
democratic rule
Capital: Dakar
Administrative divisions: 1 1 regions (regions,
singular - region); Dakar, Diourbel, Fatick, Kaolack,
Kolda, Louga. Matam. Saint-Louis. Tambacounda,
Thies, Ziguinchor
Independence: 4 April 1960 (from France); note -
complete independence was achieved upon
dissolution of federation with Mali on 20 August 1960
National holiday: Independence Day, 4 April (1 960)
Constitution: new constitution adopted 7 January
2001
Legal system: based on French civil law system;
judicial review of legislative acts in Constitutional
Court; the Council of State audits the government''s
accounting office; accepts compulsory ICJ jurisdiction,
with reservations
Suffrage: 18 years of age; universal
Executive branch:
chief of state: President Abdoulaye WADE (since
1 April 2000)
head of government: Prime Minister Macky SALL
(since 21 April 2004)
cabinet: Council of Ministers appointed by the prime
minister in consultation with the president
elections: president elected by popular vote for a
five-year term under new constitution; election last held
under prior constitution (seven-year terms) 27 February
and 19 March 2000 (next to be held February 2007);
prime minister appointed by the president
election results: Abdoulaye WADE elected president;
percent of vote in the second round of voting -
Abdoulaye WADE (PDS) 58.49%, Abdou DIOUF (PS)
41.51%
Legislative branch: unicameral National Assembly
or Assemblee Nationale (120 seats; members are
elected by direct, popular vote to serve five-year
terms)
note: the former National Assembly, dissolved in the
spring of 2001 , had 140 seats
elections: last held 29 April 2001 (next to be held in
February 2007) note - the National Assembly in
December 2005 voted to postpone legislative
elections originally scheduled for 2006, they will now
coincide with presidential elections in 2007
election results: percent of vote by party - NA%; seats
by party - SOPI Coalition 89, AFP 1 1 , PS 1 0, other 1 0
Judicial branch: Constitutional Court; Council of
State; Court of Final Appeals or Cour de Cassation;
Court of Appeals
Political parties and leaders: African Party for
Democracy and Socialism or And Jef (also known as
PADS/AJ) [Landing SAVANE, secretary general];
African Party of Independence [Majhemout DIOP];
Alliance of Forces of Progress or AFP [Moustapha
NIASSE]; Democratic and Patriotic Convention or
CDP (also known as Garab-Gi) [Dr. Iba Der THIAM],
Democratic League-Labor Party Movement or
LD-MPT [Dr. Abdoulaye BATHILY]; Front for
Socialism and Democracy or FSD [Cheikh Abdoulaye
DIEYE]; Gainde Centrist Bloc or BGC [Jean-Paul
DIAS]; Independence and Labor Party or PIT [Amath
DANSOKHO]; National Democratic Rally or RND
[Madier DIOUF]; Senegalese Democratic Party or
PDS [Abdoulaye WADE]; Socialist Party or PS
[Ousmane Tanor DIENG]; SOPI Coalition (a coalition
led by the PDS) [Abdoulaye WADE]; Union for
Democratic Renewal or URD [Djibo Leyti KA]; other
small parties
Political pressure groups and leaders: labor;
Muslim brotherhoods; students; teachers
International organization participation: ACCT,
ACP, AfDB, AUt CEMAC, ECOWAS, FAO, FZ, G-15,
G-77, IAEA, IBRD, ICAO, ICC, ICCt, ICFTU, ICRM,
IDA, IDB, IFAD, IFC, IFRCS, ILO, IMF, IMO, Interpol,
IOC, IOM, ISO (correspondent), ITU, MIGA, MONUC,
NAM, OIC, OIF, ONUB, OPCW, PCA, UN, UNCTAD,
UNESCO, UNIDO, UNMIL, UNMOVIC, UNOCI, UPU,
WADB (regional), WAEMU, WCL, WCO, WFTU,
WHO, WIPO, WMO, WToO, WTO
488
Senegal (continued)
Diplomatic representation in the US:
chief of mission: Ambassador Amadou Lamine BA
chancery: 2112 Wyoming Avenue NW, Washington,
DC 20008
telephone: [1] (202) 234-0540
FAX: [1](202)332-6315
consulate(s) general: New York
Diplomatic representation from the US:
chief of mission: Ambassador (vacant); Charge
d''Affaires Robert P. JACKSON
embassy: Avenue Jean XXIII at the corner of Rue
Kleber, Dakar
mailing address: B. P. 49, Dakar
telephone. [221] 823-4296
FAX. [221] 822-2991
Flag description: three equal vertical bands of
green (hoist side), yellow, and red with a small green
five-pointed star centered in the yellow band; uses the
popular pan-African colors of Ethiopia','56bbdc6759b47a1b9910035a9dcec62afaad66e71a12f2db73985400d193b921','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0bcdd854bf1190e17c20a3262e011f0558ebaea92db5b3a3ad0d2affc3f2a2df',2007,'ME','Montenegro','people-and-society',1118,'Population: 10,832,545 (July 2006 est.)
Age structure:
0-14 years: 17.9% (male 1 ,003,31 3/female 932,885)
15-64 years: 67% (male 3,61 8,870/female 3,638,397)
65 years and over: 15.1% (male 702,61 8/female
936,462) (2006 est.)
Median age:
total: 37 years
male: 35.5 years
female: 38.5 years (2006 est.)
Population growth rate: 0.03% (2006 est.)
Birth rate: 12.11 births/1,000 population (2006 est.)
Death rate: 1 0.55 deaths/1 ,000 population
(2006 est.)
Net migration rate: -1 .27 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .08 male(s)/female
under 15 years: 1 .08 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.97 male(s)/female (2006 est.)
Infant mortality rate:
total: 12.52 deaths/1 ,000 live births
male: 14.13 deaths/1 ,000 live births
female: 10.76 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 74.95 years
male: 72.37 years
female: 71. IS years (2006 est.)
Total fertility rate: 1 .68 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.2% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 10,000
(2001 est.)
HIV/AIDS - deaths: less than 100 (2003 est.)
Nationality:
noun: Serb(s); Montenegrin(s)
adjective: Serbian; Montenegrin
Ethnic groups: Serb 62.6%, Albanian 16.5%,
Montenegrin 5%, Hungarian 3.3%, other 12.6% (1991)
Religions: Orthodox 65%, Muslim 19%, Roman
Catholic 4%, Protestant 1%, other 11%
Languages: Serbian 95%, Albanian 5%
Literacy:
definition: age 1 5 and over can read and write
total population: 96.4%
male: 98.9%
fema/e: 94.1% (2002 est.)
o v e r n m e n t
Country name:
conventional long form: Serbia and Montenegro
conventional shod form: none
local long form: Srbija i Crna Gora
local shod form: none
former: Federal Republic of Yugoslavia
abbreviation: SCG
Government type: republic
Capital: Belgrade
Administrative divisions: 2 republics (republike,
singular - republika); and 2 nominally autonomous
provinces (autonomn pokrajine, singular - autonomna
pokrajina)(both in the republic of Serbia)* ; Kosovo*
(temporarily under UN administration, per UN Security
Council Resolution 1244), Montenegro, Serbia,
Vojvodina*
Independence: 27 April 1992 (Federal Republic of
Yugoslavia or FRY - now Serbia and Montenegro -
formed as self-proclaimed successor to the Socialist
Federal Republic of Yugoslavia or SFRY)
National holiday: National Day, 27 April
Constitution: 4 February 2003
Legal system: based on civil law system; accepts
compulsory ICJ jurisdiction, with reservations
Suffrage: 16 years of age, if employed; 18 years of
age, universal
Executive branch:
chief of state: President Svetozar MAROVIC (since
7 March 2003); note - the president is both the chief of
state and head of government
head of government: President Svetozar MAROVIC
(since 7 March 2003); note - the president is both the
chief of state and head of government
cabinet: Federal Ministries act as Cabinet
elections: president elected by the parliament for a
four-year term; election last held 7 March 2003 (next
to be held 2007)
election results: Svetozar MAROVIC elected
president by the parliament; vote was Svetozar
MAROVIC 65, other 47
Legislative branch: unicameral Parliament (126
seats - 91 Serbian, 35 Montenegrin - filled by
nominees of the two state parliaments for the first two
years, after which the Constitutional Charter calls for
direct elections
elections: last held 25 February 2003 (next to be held
2006 in Montenegro and 2007 in Serbia)
election results: percent of vote by party - NA%; seats
by party - Serbian parties: SRS 30, DSS 20, DS 13,
G17 Plus 12, SPO-NS 8, SPS 8; Montenegrin parties:
DPS 15, SNP 9, SDP 4, DSS 3, NS 2, LSCG 2
Judicial branch: The Court of Serbia and
Montenegro; judges are elected by the Serbia and
Montenegro Parliament for six-year terms
note: since the promulgation of the 2003 Constitution,
the Federal Court has constitutional and
administrative functions; it has an equal number of
judges from each republic
Political parties and leaders: Democratic Party or
DS [Boris TADIC]; Democratic Party of Serbia or DSS
[Vojislav KOSTUNICA]; Democratic Party of Socialists
of Montenegro or DPS [Milo DJUKANOVIC];
Democratic Serbian Party of Montenegro or DSS
[Bozidar BOJOVIC]; G17 Plus [Miroljub LABUS]; New
Serbia or NS [Velimir ILIC]; Liberal Party of
Montenegro or LSCG [Miodrag ZIVKOVIC]; People''s
Party of Montenegro or NS [Predrag POPOVIC];
Power of Serbia Movement or PSS [Bogoljub KARIC);
Serbian Peoples'' Party of Montenegro or SNS [Andrija
MANDIC]; Serbian Radical Party or SRS [Tomislav
NIKOLIC]; Serbian Renewal Movement or SPO [Vuk
DRASKOVIC]; Serbian Socialist Party or SPS (former
Communist Party and party of Slobodan MILOSEVIC)
[Ivica DACIC, president of Main Board]; Social
Democratic Party of Montenegro or SDP [Ranko
KRIVOKAPIC]; Socialist People''s Party of
Montenegro or SNP [Predrag BULATOVIC]
note: the following political parties participate in
elections and institutions only in Kosovo, which has
been governed by the UN under UNSCR 1244 since
1 999: Albanian Christian Democratic Party or PSHDK
[Mark KRASNIQI]; Alliance for the Future of Kosovo or
AAK [Ramush HARADINAJ]; Citizens'' Initiative of
Gora or GIG [leader NA]; Democratic Ashkali Party of
Kosovo or PDAK [Sabit RRAHMANI]; Democratic
League of Kosovo or LDK [Ibrahim RUGOVA];
Democratic Party of Kosovo or PDK [Hashim THACI];
Justice Party or PD [Sylejman CERKEZI]; Kosovo
Democratic Turkish Party of KDTP [Mahir
YAGCILAR]; Liberal Party of Kosovo or PLK [Gjergj
DEDAJ]; Ora [Veton SURROI]; New Democratic
Initiative of Kosovo or IRDK [Bislim HOTI]; Party of
Democratic Action or SDA [Numan BALIC]; Popular
Movement of Kosovo or LPK [Emrush XHEMAJLI];
Prizren-Dragas Initiative or PDI [Ismajl
KARADOLAMI]; Serb Democratic Party or SDS
[Slavisa PETKOVIC]; Serb List for Kosovo and
Metohija or SLKM [Oliver IVANOVIC]; United Roma
Party of Kosovo or PREBK [Haxhi Zylfi MERXHA];
Vakat [leader NA]
Political pressure groups and leaders: Political
Council for Presevo, Medvedja and Bujanovac or
PCPMB [leader NA]; Group for Changes of
Montenegro or GZP [Nebojsa MEDOJEVIC]
International organization participation: BIS,
BSEC, CE, CEI, EBRD, FAO, G- 9, IAEA, IBRD,
ICAO, ICC, ICCt, ICFTU, ICRM, IDA, IFAD, IFC,
IFRCS, IHO, ILO, IMF, IMO, Interpol, IOC, IOM, ISO,
ITU, MIGA, MONUC, NAM, OAS (observer), ONUB,
OPCW, OSCE, PCA, SECI, UN, UNCTAD, UNESCO,
UNHCR, UNIDO, UNMIL, UNOCI, UPU, WCL, WCO,
WHO, WIPO, WMO, WToO, WTO (observer)
Diplomatic representation in the US:
chief of mission: Ambassador Ivan VUJACIC
chancery: 21 34 Kalorama Road NW, Washington, DC
20008
telephone: []} (202) 332-0333
FM:[1] (202) 332-3933
consulate(s) general: Chicago
491
Serbia and Montenegro (continued)
Diplomatic representation from the US:
chief of mission: Ambassador Michael C. POLT
embassy: Kneza Milosa 50. 1 1000 Belgrade
mailing address: 5070 Belgrade Place, Washington,
DC 20521-5070
telephone: [381] (11) 361-9344
FAX; [381] (11) 361-8230
consulate(s): Podgorica
nofe: there is a branch office in Pristina at 30 Nazim
Hikmet 38000 Pristina, Kosovo; telephone:
[381](38)549-516; FAX: [381](38)549-890
Flag description: three equal horizontal bands of
blue (top), white, and red','da3b87481a97f5ff13e055a1288725da482af4aa569e469db77cc0aedc23040f','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e7939350f10096f61cf8267ef05b1e028141391cacd8e55dd3f6534cfa0cffa',2007,'SC','Seychelles','people-and-society',1126,'Population: 81,541 (July 2006 est.)
Age structure:
0-14 years: 25.9% (male 10,667/female 10,440)
15-64 years: 68% (male 27,060/female 28,366)
65 years and over: 6. 1 % (male 1 ,607/female 3,401 )
(2006 est.)
Median age:
total: 28.1 years
male: 27 years
female: 29.1 years (2006 est.)
Population growth rate: 0.43% (2006 est.)
Birth rate: 16.03 births/1 ,000 population (2006 est.)
Death rate: 6.29 deaths/1 ,000 population (2006 est.)
Net migration rate: -5.4 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.47 male(s)/female
total population: 0.93 male(s)/female (2006 est.)
Infant mortality rate:
total: 15.14 deaths/1 ,000 live births
male: 19.16 deaths/1 ,000 live births
female: 10.99 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 72.08 years
male: 66.69 years
female: 77.63 years (2006 est.)
Total fertility rate: 1 .74 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS • people living with HIV/AIDS: NA
HIV/AIDS • deaths: NA
Nationality:
noun: Seychelles (singular and plural)
adjective: Seychellois
Ethnic groups: mixed French, African, Indian,
Chinese, and Arab
493
Seychelles (continued)
Religions: Roman Catholic 82. 3%, Anglican 6.4%,
Seventh Day Adventist 1.1%, other Christian 3.4%,
Hindu 2.1%, Muslim 1.1%, other non-Christian 1.5%,
unspecified 1.5%, none 0.6% (2002 census)
Languages: Creole 91.8%, English 4.9% (official),
other 3.1%, unspecified 0.2% (2002 census)
Literacy:
definition: age 1 5 and over can read and write
total population: 91.9%
male: 91 .4%
female: 92.3% (2003 est.)','20b05009a0458d874a3b28f13d29507980b40fac9d7f9c5c537edd2b71e70f51','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ababcb96775c1795d64f7e1e79e59c7dc2b5cede9fdc3eb3c2948b9e1a67fdf0',2007,'SL','Sierra Leone','people-and-society',1135,'Population: 6,005,250 (July 2006 est.)
Age structure:
0-14 years: 44.8% (male 1 ,321 ,563/female
1,370,721)
15-64 years: 52% (male 1 ,494,502/female 1 ,625,733)
65 years and over: 3.2% (male 90,958/female
101 ,773) (2006 est.)
Median age:
total: 17.4 years
male: MA years
female: 17.7 years (2006 est.)
Population growth rate: 2.3% (2006 est.)
Birth rate: 45.76 births/1,000 population (2006 est.)
Death rate: 23.03 deaths/1 ,000 population
(2006 est.)
Net migration rate: 0.23 migrant(s)/1 ,000
population
nofe: refugees currently in surrounding countries are
slowly returning (2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 0.96 male(s)/female
15-64 years: 0.92 male(s)/female
65 years and over: 0.89 male(s)/female
total population: 0.94 male(s)/female (2006 est.)
Infant mortality rate:
total: 160.39 deaths/1 ,000 live births
male: 177.47 deaths/1 ,000 live births
female: 142.8 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 40.22 years
male: 38.05 years
female: 42.46 years (2006 est.)
Total fertility rate: 6.08 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 7% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 1 70,000
(2001 est.)
HIV/AIDS - deaths: 1 1 ,000 (2001 est.)
Major infectious diseases:
degree of risk: very high
food or waterbome diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever
vectorborne diseases: malaria and yellow fever are
high risks in some locations
water contact disease: schistosomiasis
aerosolized dust or soil contact disease: Lassa fever
(2004)
Nationality:
noun: Sierra Leonean(s)
adjective: Sierra Leonean
Ethnic groups: 20 native African tribes 90% (Temne
30%, Mende 30%, other 30%), Creole (Krio) 10%
(descendants of freed Jamaican slaves who were
settled in the Freetown area in the late-18th century),
refugees from Liberia''s recent civil war, small numbers
of Europeans. Lebanese, Pakistanis, and Indians
Religions: Muslim 60%, indigenous beliefs 30%,
Christian 10%
Languages: English (official, regular use limited to
literate minority), Mende (principal vernacular in the
south), Temne (principal vernacular in the north), Krio
(English-based Creole, spoken by the descendants of
freed Jamaican slaves who were settled in the
Freetown area, a lingua franca and a first language for
10% of the population but understood by 95%)
Literacy:
definition: age 1 5 and over can read and write English,
Mende, Temne, or Arabic
total population: 29.6%
male: 39.8%
female: 20.5% (2000 est.)','2dc9434bf22767ecc392979ee86e53aed4a643198d044ac50d41241638c4ad03','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0eda3ab971ed5fa45f1997438f0cabc631a3256cb92cffb8e528c74244419b4c',2007,'SK','Slovakia','people-and-society',1141,'Population: 5,439,448 (July 2006 est.)
Age structure:
0-14 years: 16.7% (male 465,304/female 443,967)
15-64 years: 71 .3% (male 1 ,929,448/female
1,947,735)
65 years and over: 12% (male 244,609/female
408,385) (2006 est.)
Median age:
total: 35.8 years
male: 34.2 years
female: 37.6 years (2006 est.)
500
Slovakia (continued)
Population growth rate: 0.15% (2006 est.)
Birth rate: 1 0.65 births/1 ,000 population (2006 est.)
Death rate: 9.45 deaths/1 ,000 population (2006 est.)
Net migration rate: 0.3 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.6 male(s)/female
total population: 0.94 male(s)/female (2006 est.)
Infant mortality rate:
total: 7.26 deaths/1,000 live births
male: 8.48 deaths/1 ,000 live births
female: 5.98 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 74.73 years
male: 70.76 years
female: 78.89 years (2006 est.)
Total fertility rate: 1 .33 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: less than 0.1%
(2001 est.)
HIV/AIDS - people living with HIV/AIDS: less than
200 (2003 est.)
HIV/AIDS ■ deaths: less than 100 (2001 est.)
Nationality:
noun: Slovak(s)
adjective: Slovak
Ethnic groups: Slovak 85.8%, Hungarian 9.7%,
Roma 1.7%, Ruthenian/Ukrainian 1%, other and
unspecified 1.8% (2001 census)
Religions: Roman Catholic 68.9%, Protestant
10.8%, Greek Catholic 4.1%, other or unspecified
3.2%, none 13% (2001 census)
Languages: Slovak (official) 83.9%, Hungarian
10.7%, Roma 1.8%, Ukrainian 1%, other or
unspecified 2.6% (2001 census)
Literacy:
definition: age 1 5 and over can read and write
total population: 99.6%
male: 99.7%
female: 99.6% (2001 est.)','8c2da92e46365656f0ebb6f9f5d9f8b5bd333e4a857b4eabdb13c783b77b1c19','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68495bad89f58908b76fb0259fb90e265d6111fb3c19e38465d325464968cef1',2007,'VU','Vanuatu','people-and-society',1148,'Population: 552,438 (July 2006 est.)
Age structure:
0-14 years: 41 .3% (male 1 16,370/female 1 1 1 ,834)
15-64 years: 55.4% (male 154,793/female 151,308)
65 years and over: 3.3% (male 8,696/female 9,437)
(2006 est.)
Median age:
tofa/: 18.9 years
male: 18.7 years
female: 19 years (2006 est.)
Population growth rate: 2.61% (2006 est.)
Birth rate: 30.01 births/1,000 population (2006 est.)
Death rate: 3.92 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .02 male(s)/female
65 years and over: 0.92 male(s)/female
total population:]. 03 male(s)/female (2006 est.)
Infant mortality rate:
total: 20.63 deaths/1 ,000 live births
male: 23.54 deaths/1 .000 live births
female: 17.59 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 72.91 years
male: 70.4 years
female: 75.55 years (2006 est.)
Total fertility rate: 3.91 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS • people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Solomon Islander(s)
adjective: Solomon Islander
Ethnic groups: Melanesian 94.5%, Polynesian 3%,
Micronesian 1.2%, other 1.1%, unspecified 0.2%
(1999 census)
Religions: Church of Melanesia 32.8%, Roman
Catholic 19%, South Seas Evangelical 17%,
Seventh-Day Adventist 1 1 .2%, United Church 10.3%,
Christian Fellowship Church 2.4%, other Christian 4.4%,
other 2.4%, unspecified 0.3%, none 0.2% (1999 census)
Languages: Melanesian pidgin in much of the
country is lingua franca; English is official but spoken
by only 1%-2% of the population
note: 120 indigenous languages
Literacy:
definition: NA
total population: NA%
male: NA%
female: NA%
G o v e r n m e
Country name:
conventional long form: none
conventional short form: Solomon Islands
former: British Solomon Islands
Government type: parliamentary democracy
Capital: Honiara
Administrative divisions: 9 provinces and 1 capital
territory*; Central, Choiseul, Guadalcanal, Honiara*,
Isabel, Makira, Malaita, Rennell and Bellona, Temotu,
Western
Independence: 7 July 1978 (from UK)
National holiday: Independence Day, 7 July (1978)
Constitution: 7 July 1978
Legal system: English common law, which is widely
disregarded
Suffrage: 21 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II (since 6 February
1952), represented by Governor General Nathaniel
WAENA (since 7 July 2004)
head of government: Prime Minister Sir Allan
KEMAKEZA (since 17 December 2001); Deputy Prime
Minister Snyder RINI (since 1 7 December 2001 )
cabinet: Cabinet consists of 20 members appointed
by the governor general on the advice of the prime
minister from among the members of Parliament
elections: none; the monarch is hereditary; governor
general appointed by the monarch on the advice of
Parliament for up to five years; following legislative
elections, the leader of the majority party or the leader
of a majority coalition is usually elected prime minister
by Parliament; deputy prime minister appointed by the
governor general on the advice of the prime minister
from among the members of Parliament
Legislative branch: unicameral National Parliament
(50 seats; members elected from single-member
constituencies by popular vote to serve four-year terms)
elections: last held 5 December 2001 (next to be held
5 April 2006)
506
Solomon Islands (continued)
election results: percent of vote by party - PAP 40%,
SIACC 40%, PPP 20%; seats by party - PAP 16,
SIACC 13, PPP 2, SILP 1 , independents 18
Judicial branch: Court of Appeal
Political parties and leaders: Association of
Independents [Snyder RINI]; People''s Alliance Party
or PAP [Allan KEMAKEZA]; People''s Progressive
Party or PPP [Mannaseh Damukana SOGAVARE];
Solomon Islands Alliance for Change Coalition or
SIACC [Bartholomew ULUFA''ALU]; Solomon Islands
Labor Party or SILP [Joses TUHANUKU]
note: in general, Solomon Islands politics is
characterized by fluid coalitions
Political pressure groups and leaders: NA
International organization participation: ACP,
AsDB, C, ESCAP, FAO, G-77, IBRD, ICAO, ICCt
(signatory), ICRM, IDA, IFAD, IFC, IFRCS, ILO, IMF,
IMO, IOC, ITU, MIGA, OPCW, PIF, Sparteca, SPC,
UN, UNCTAD, UNESCO, UPU, WFTU, WHO, WMO,
WTO
Diplomatic representation in the US:
chief of mission: Ambassador Collin David BECK
chancery: 800 Second Avenue, Suite 400L, New
York, NY 10017
telephone: [1] (212) 599-6192, 6193
FAX: [1] (212) 661-8925
Diplomatic representation from the US: the
US does not have an embassy in Solomon Islands
(embassy closed July 1993); the ambassador to Papua
New Guinea is accredited to the Solomon Islands
Flag description: divided diagonally by a thin yellow
stripe from the lower hoist-side corner; the upper
triangle (hoist side) is blue with five white five-pointed
stars arranged in an X pattern; the lower triangle is
green
Government - note: June 2003 Prime Minister Sir
Allan KEMAKEZA sought the intervention of Australia
to aid in restoring order; parliament approved the
request for intervention in July 2003; troops from
Australia, New Zealand, Fiji, Papua New Guinea, and
Tonga arrived 24 July 2003. By the end of 2004 the
Regional Assistance Mission to the Solomon Islands
(RAMSI) had been scaled back to 302 police officers
and 120 military in addition to civilian technical
advisors.
Population: 25,730,435 (July 2006 est.)
Age structure:
0-14 years: 29.1% (male 3,860,1 16/female
3,620,440)
15-64 years: 65.7% (male 8,494,944/female
8,410,874)
65 years and over: 5.2% (male 609, 101 /female
734,960) (2006 est.)
Median age:
total: 26 years
male: 25.4 years
female: 26.6 years (2006 est.)
Population growth rate: 1 .38% (2006 est.)
Birth rate: 18.71 births/1,000 population (2006 est.)
Death rate: 4.92 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .08 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.83 male(s)/female
total population: 1 .02 male(s)/female (2006 est.)
Infant mortality rate:
total: 21 .54 deaths/1 ,000 live births
male: 24.58 deaths/1 ,000 live births
female: 18.27 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 74.54 years
male: 71.49 years
female: 77.81 years (2006 est.)
Total fertility rate: 2.23 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.7% - note - no
country specific models provided (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 1 10,000
(1999 est.)
HIV/AIDS - deaths: 4,100 (2003 est.)
Nationality:
noun: Venezuelan(s)
adjective: Venezuelan
Ethnic groups: Spanish, Italian, Portuguese, Arab,
German, African, indigenous people
Religions: nominally Roman Catholic 96%,
Protestant 2%, other 2%
Languages: Spanish (official), numerous indigenous
dialects
Literacy:
definition: age 15 and over can read and write
total population: 93.4%
male: 93.8%
female: 93.1% (2003 est.)','d9d43d742104a56b9d1ddb8645ad67ffb074ed6dcaf3d6f8a4eb15678542a057','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8288e409bdaa5aee0843109bce5eb74888bd117e14f66922998c89052b4b7680',2007,'KE','Kenya','people-and-society',1155,'Population: 8,863,338
note: this estimate was derived from an official census
taken in 1975 by the Somali Government; population
counting in Somalia is complicated by the large
number of nomads and by refugee movements in
response to famine and clan warfare (July 2006 est.)
Age structure:
0-14 years: 44.4% (male 1,973,294/female
1,961,083)
15-64 years: 53% (male 2,355,861 /female 2.342,988)
65 years and over: 2.6% (male 97,307/female
132,805) (2006 est.)
Median age:
total: 17.6 years
male: 17.5 years
female: 17. 7 years (2006 est.)
Population growth rate: 2.85% (2006 est.)
Birth rate: 45.13 births/1,000 population (2006 est.)
Death rate: 16.63 deaths/1 ,000 population
(2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 1 5 years: 1.01 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and over: 0.73 male(s)/female
total population: 1 male(s)/female (2006 est.)
Infant mortality rate''
total: 1 14.89 deaths/1 ,000 live births
male: 124.18 deaths/1,000 live births
female: 105.32 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 48.47 years
male: 46.71 years
female: 50.28 years (2006 est.)
Total fertility rate: 6.76 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 1% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 43,000
(2001 est.)
HIV/AIDS - deaths: NA
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial and protozoal
diarrhea, hepatitis A and E, and typhoid fever
vectorbome diseases: malaria and dengue fever are
high risks in some locations
water contact disease: schistosomiasis
animal contact disease: rabies (2004)
Nationality:
noun: Somali(s)
adjective: Somali
Ethnic groups: Somali 85%, Bantu and other
non-Somali 15% (including Arabs 30,000)
Religions: Sunni Muslim
Languages: Somali (official), Arabic, Italian, English
Literacy:
definition: age 1 5 and over can read and write
total population: 37.8%
male: 49.7%
female: 25.8% (2001 est.)','dc8f207ed111c34eb706bb4125ac6b62ece276a1f018710e692dece5688979e6','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ddfb68283bd703a58d21238655d06f458455a8e3440acae1a07df61e2ebfeede',2007,'PH','Philippines','people-and-society',1166,'Population: no indigenous inhabitants
note: there are scattered garrisons occupied by
personnel of several claimant states (2004)','5fd7cf153547fdde96fc491f686d33d0ce5e2cf6f9c015f6b37c199df4243435','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e1ecafbf7454bfab882b8aa954778fabcd4b0396be10f52a2b61825f394486f',2007,'LK','Sri Lanka','people-and-society',1175,'Population: 20,222,240
note: since the outbreak of hostilities between the
government and armed Tamil separatists in the
mid-1980s, several hundred thousand Tamil civilians
have fled the island and more than 200,000 Tamils
have sought refuge in the West (July 2006 est.)
Age structure:
0-14 years: 24.1% (male 2,488,689/female
2,379,233)
15-64 years: 68.6% (male 6,727,399/female
7,140,751)
65 years and over: 7.3% (male 687,842/female
798,326) (2006 est.)
Median age:
total: 29.8 years
male: 28.7 years
female: 30.9 years (2006 est.)
Population growth rate: 0.78% (2006 est.)
Birth rate: 15.51 births/1,000 population (2006 est.)
Death rate: 6.52 deaths/1 ,000 population (2006 est.)
Net migration rate: -1 .23 migrant(s)/1 ,000
population (2006 est.)
519
Sri Lanka (continued)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 0.94 male(s)/female
65 years and over: 0.86 male(s)/female
total population: 0.96 male(s)/female (2006 est.)
Infant mortality rate:
total: 13.97 deaths/1.000 live births
male: 15.18 deaths/1 ,000 live births
female: 12.7 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 73 A) years
male: 70.83 years
female: 76.12 years (2006 est.)
Total fertility rate: 1 .84 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: less than 0.1%
(2001 est.)
HIV/AIDS - people living with HIV/AIDS: 3,500
(2001 est.)
HIV/AIDS - deaths: less than 200 (2003 est.)
Nationality:
noun: Sri Lankan(s)
adjective: Sri Lankan
Ethnic groups: Sinhalese 73.8%, Sri Lankan Moors
7.2%, Indian Tamil 4.6%, Sri Lankan Tamil 3.9%,
other 0.5%, unspecified 10% (2001 census
provisional data)
Religions: Buddhist 69.1%, Muslim 7.6%, Hindu
7.1%, Christian 6.2%, unspecified 10% (2001 census
provisional data)
Languages: Sinhala (official and national language)
74%, Tamil (national language) 18%, other 8%
note: English is commonly used in government and is
spoken competently by about 10% of the population
Literacy:
definition: age 1 5 and over can read and write
total population: 92.3%
male: 94.8%
female: 90% (2003 est.)','9eb573422775def8452330237aabe7354aac23edc5e0ad502ef3873fc873d9d4','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e7948e90474fac82d6b892e20cf31083007982890d96b38078d483c80464ce5',2007,'SD','Sudan','people-and-society',1182,'Population: 41 ,236.378 (July 2006 est.)
Age structure:
0-14 years: 42.7% (male 8,993,483/female
8,614,022)
15-64 years: 54.9% (male 1 1 ,327,679/female
11,297,798)
65 years and over: 2.4% (male 536,754/female
466,642) (2006 est.)
Median age:
total: 18.3 years
male: 18.1 years
female: 18.5 years (2006 est.)
Population growth rate: 2.55% (2006 est.)
Birth rate: 34.53 births/1,000 population (2006 est.)
Death rate: 8.97 deaths/1 ,000 population (2006 est.)
Net migration rate: -0.02 migrant(s)/1,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 1.15 male(s)/female
total population: 1 .02 male(s)/female (2006 est.)
Infant mortality rate:
total: 61 .05 deaths/1 ,000 live births
male: 61 .88 deaths/1 ,000 live births
female: 60.18 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 58.92 years
male: 57.69 years
female: 60.21 years (2006 est.)
Total fertility rate: 4.72 children born/woman
(2006 est.)
HIV/AIDS ■ adult prevalence rate: 2.3% (2001 est.)
HIV/AIDS • people living with HIV/AIDS: 400,000
(2001 est.)
HIV/AIDS - deaths: 23,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever
vectorborne diseases: malaria, dengue fever, African
trypanosomiasis (sleeping sickness) are high risks in
some locations
water contact disease: schistosomiasis
respiratory disease: meningococcal meningitis (2004)
Nationality:
noun: Sudanese (singular and plural)
adjective: Sudanese
Ethnic groups: black 52%, Arab 39%, Beja 6%,
foreigners 2%. other 1%
Religions: Sunni Muslim 70% (in north), indigenous
beliefs 25%, Christian 5% (mostly in south and
Khartoum)
Languages: Arabic (official), Nubian, Ta Bedawie,
diverse dialects of Nilotic, Nilo-Hamitic, Sudanic
languages, English
note: program of "Arabization" in process
Literacy:
definition: age 1 5 and over can read and write
total population: 61.1%
male: 71 .8%
female: 50.5% (2003 est.)','fb357cc524ae1bd286c9a8c7b03a7d0413cf16dfb2ac1d4b26771c0b2f7e2361','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6de43a6ae80c5c5fd509c3ec8e425dc71a9412a3c74452e36165ba1da1330e10',2007,'UZ','Uzbekistan','people-and-society',1204,'Population: 7,320,815 (July 2006 est.)
Age structure:
0-14 years- 37.9% (male 1,396,349/female
1,375,168)
15-64 years: 57.4% (male 2,091 ,476/female
2,108,889)
65 years and over: 4.8% (male 1 54, 1 62/female
194,771) (2006 est.)
Median age:
total: 20 years
male: 19.7 years
female: 20.4 years (2006 est.)
Population growth rate: 2.19% (2006 est.)
Birth rate: 32.65 births/1 ,000 population (2006 est.)
Death rate: 8.25 deaths/1 ,000 population (2006 est.)
Net migration rate: -2.48 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.79 male(s)/female
total population: 0.99 male(s)/female (2006 est.)
Infant mortality rate:
total: 106.49 deaths/1,000 live births
male: 1 1 7.83 deaths/1 ,000 live births
female: 94.59 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 64.94 years
male: 62.03 years
female: 68 years (2006 est.)
Total fertility rate: 4 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: less than 01%
(2001 est.)
HIV/AIDS - people living with HIV/AIDS: less than
200 (2003 est.)
HIV/AIDS - deaths: less than 100 (2001 est.)
Nationality:
noun: Tajikistani(s)
adjective: Tajikistani
Ethnic groups: Tajik 79.9%, Uzbek 15.3%, Russian
1.1%, Kyrgyz 1.1%, other 2.6% (2000 census)
Religions: Sunni Muslim 85%, Shi''a Muslim 5%,
other 10% (2003 est.)
Languages: Tajik (official), Russian widely used in
government and business
Literacy:
definition: age 1 5 and over can read and write
total population: 99.4%
male: 99.6%
female: 99.1% (2003 est.)
Population: 27,307,134 (July 2006 est.)
Age structure:
0-14 years: 32.9% (male 4,572,721 /female
4,403,405)
15-64 years: 62.3% (male 8,420, 174/female
8,594,478)
65 years and over: 4.8% (male 539,336/female
777,020) (2006 est.)
592
Uzbekistan (continued)
Median age
total: 22.7 years
male: 22 years
female: 23.3 years (2006 est.)
Population growth rate: 1 .7% (2006 est.)
Birth rate: 26.36 births/1,000 population (2006 est.)
Death rate: 7.84 deaths/1 ,000 population (2006 est.)
Net migration rate: -1 .5 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.04 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.98 male(s)/female (2006 est.)
Infant mortality rate:
total: 69.99 deaths/1 ,000 live births
male: 74.14 deaths/1,000 live births
female: 65.64 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 64.58 years
male: 61.19 years
female: 68.14 years (2006 est.)
Total fertility rate: 2.91 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: less than 0.1%
(2001 est.)
HIV/AIDS - people living with HIV/AIDS: 1 1 ,000
(2003 est.)
HIV/AIDS - deaths: less than 500 (2003 est.)
Nationality:
noun: Uzbekistani
adjective: Uzbekistani
Ethnic groups: Uzbek 80%, Russian 5.5%, Tajik
5%, Kazakh 3%, Karakalpak 2.5%, Tatar 1.5%, other
2.5% (1996 est.)
Religions: Muslim 88% (mostly Sunnis), Eastern
Orthodox 9%, other 3%
Languages: Uzbek 74.3%, Russian 14.2%, Tajik
4.4%, other 7.1%
Literacy:
definition: age 15 and over can read and write
total population: 99.3%
male: 99.6%
female: 99% (2003 est.)
Population: 208,869 (July 2006 est.)
Age structure:
0-14 years: 32.6% (male 34,804/female 33,331 )
15-64 years: 63.7% (male 67,91 9/female 65,138)
65 years and over: 3.7% (male 4,027/female 3,650)
(2006 est.)
Median age:
total: 23 years
male: 23 years
female: 23 years (2006 est.)
Population growth rate: 1 .49% (2006 est.)
Birth rate: 22.72 births/1 ,000 population (2006 est.)
Death rate: 7.82 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2006 est.)
595
Vanuatu (continued)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 1.1 male(s)/female
total population: 1 .05 male(s)/female (2006 est.)
Infant mortality rate:
total: 53.8 deaths/1 ,000 live births
male: 56.35 deaths/1 ,000 live births
female: 51.13 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 62.85 years
male: 61.34 years
female: 64.44 years (2006 est.)
Total fertility rate: 2.7 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Ni-Vanuatu (singular and plural)
adjective: Ni-Vanuatu
Ethnic groups: Ni-Vanuatu 98.5%, other 1.5%
(1999 Census)
Religions: Presbyterian 31.4%, Anglican 13.4%,
Roman Catholic 13.1%, Seventh-Day Adventist
10.8%, other Christian 13.8%, indigenous beliefs
5.6% (including Jon Frum cargo cult), other 9.6%,
none 1%, unspecified 1.3% (1999 Census)
Languages: local languages (more than 1 00) 72.6%,
pidgin (known as Bislama or Bichelama) 23.1%,
English 1.9%, French 1.4%, other 0.3%, unspecified
0.7% (1999 Census)
Literacy:
definition: age 15 and over can read and write
total population: 74%
male: NA%
female: HA% (1999 est.)','1cbc96d843820bb695bf9dd934e3ec2610c784dd54e85d1ecbe942a9cc8efe95','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ddc33dac9f9611c7a84581a6203af6424338d9942f620de2797ba27bfde50125',2007,'TK','Tokelau','people-and-society',1214,'Population: 1 ,392 (July 2006 est.)
Age structure:
0-14 years: 42%
15-64 years: 53%
65 years and over: 5% (2006 est.)
Population growth rate: -0.01% (2006 est.)
Birthrate: NA
Death rate: NA deaths/1 ,000 population
Net migration rate: NA
Sex ratio: NA
Infant mortality rate:
total: NA
male: NA
female: NA
Life expectancy at birth:
total population: NA
male: NA
female: NA
Total fertility rate: NA
HIV/AIDS • adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Tokelauan(s)
adjective: Tokelauan
Ethnic groups: Polynesian
Religions: Congregational Christian Church 70%,
Roman Catholic 28%, other 2%
note: on Atafu, all Congregational Christian Church of
Samoa; on Nukunonu, all Roman Catholic; on
Fakaofo, both denominations, with the
Congregational Christian Church predominant
Languages: Tokelauan (a Polynesian language),
English
Literacy: NA','71197acc3ee7e5364aa1f67066b563a18e34c1c3e49c93a238bf51a06226a04c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56b3b92594f1a1be57141605bee3a7d80d3fd03c86458b3766cea7a915095fd7',2007,'TV','Tuvalu','people-and-society',1226,'Population: 11,810 (July 2006 est.)
Age structure:
0-14 years: 30.2% (male 1 ,81 9/female 1 ,752)
15-64 years: 64.7% (male 3,715/female 3,923)
65 years and over: 5.1 % (male 228/female 373)
(2006 est.)
Median age:
total: 24.6 years
male: 23.6 years
female: 26 years (2006 est.)
Population growth rate: 1 .51% (2006 est.)
Birth rate: 22.18 births/1,000 population (2006 est.)
Death rate: 7.1 1 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 0.95 male(s)/female
65 years and over: 0.61 male(s)/female
total population: 0.95 male(s)/female (2006 est.)
Infant mortality rate:
total: 19.47 deaths/1 ,000 live births
male: 22.27 deaths/1 ,000 live births
female: 16.52 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 68.32 years
male: 66.08 years
female: 70.66 years (2006 est.)
Total fertility rate: 2.98 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS • people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Tuvaluan(s)
adjective: Tuvaluan
Ethnic groups: Polynesian 96%, Micronesian 4%
Religions: Church of Tuvalu (Congregationalist)
97%, Seventh-Day Adventist 1 .4%, Baha''i 1%, other
0.6%
Languages: Tuvaluan, English, Samoan, Kiribati (on
the island of Nui)
Literacy: NA
G o v e r n m e
Country name:
conventional long form: none
conventional short form: Tuvalu
former: Ellice Islands
note: "Tuvalu" means "group of eight," referring to the
country''s eight traditionally inhabited islands
Government type: constitutional monarchy with a
parliamentary democracy; began debating republic
status in 1992
Capital: Funafuti; note - administrative offices are
located in Vaiaku Village on Fongafale Islet
Administrative divisions: none
Independence: 1 October 1978 (from UK)
National holiday: Independence Day, 1 October
(1978)
Constitution: 1 October 1978
Legal system: NA
Suffrage: 1 8 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II (since 6 February
1952), represented by Governor General Filoimea
TELITO (since 15 April 2005)
head of government: Prime Minister Maatia TOAFA
(since 1 1 October 2004)
cabinet: Cabinet appointed by the governor general
on the recommendation of the prime minister
elections: the monarch is hereditary; governor general
appointed by the monarch on the recommendation of
the prime minister; prime minister and deputy prime
minister elected by and from the members of
Parliament; election last held 1 1 October 2004 (next to
be held following parliamentary elections in 2006)
election results: Saufatu SOPOANGA resigned
parliamentary seat on 27 August 2004 following
no-confidence vote on 25 August 2004; succeeded by
Deputy Prime Minister Maatia TOAFA in an acting
capacity on 27 August 2004; Maatia TOAFA
confirmed Prime Minister in a Parliamentary election
(8-7 vote) on 1 1 October 2004
Legislative branch: unicameral Parliament or Fale I
Fono, also called House of Assembly (15 seats;
members elected by popular vote to serve four-year
terms)
elections: last held 25 July 2002 (next to be held in
2006)
568
Tuvalu (continued)
election results: percent of vote - NA%; seats -
independents 15
Judicial branch: High Court (a chief justice visits
twice a year to preside over its sessions; its rulings
can be appealed to the Court of Appeal in Fiji); eight
Island Courts (with limited jurisdiction)
Political parties and leaders: there are no political
parties but members of Parliament usually align
themselves in informal groupings
Political pressure groups and leaders: none
International organization participation: ACP,
AsDB, C, FAO, IFRCS (observer), IMO, ITU, OPCW,
PIF, Sparteca, SPC, UN, UNCTAD, UNESCO, UPU,
WHO
Diplomatic representation in the US: Tuvalu does
not have an embassy in the US - the country''s only
diplomatic post is in Fiji - Tuvalu does, however, have
a UN office located at 800 2nd Avenue, Suite 400D,
New York, NY 10017, telephone: [1] (212) 490-0534
Diplomatic representation from the US: the US
does not have an embassy in Tuvalu; the US
ambassador to Fiji is accredited to Tuvalu
Flag description: light blue with the flag of the UK in
the upper hoist-side quadrant; the outer half of the flag
represents a map of the country with nine yellow
five-pointed stars symbolizing the nine islands','08550bbd8ba2352abcf07858f8459e2a02db96163e3fd2608552808530895d70','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d52af44e1a8db5d24ceb96c03cc2977b9a345dc75e48bb2cf67715fc09872ae',2007,'UG','Uganda','people-and-society',1233,'Population: 28,195,754
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected
(July 2006 est.)
Age structure:
0-14 years: 50% (male 7,091 ,763/female 6,996,385)
15-64 years: 47.8% (male 6,762,071/female
6,727,230)
65 years and over: 2.2% (male 266,931 /female
351 ,374) (2006 est.)
Median age:
total: 15 years
male: 14.9 years
female: 15.1 years (2006 est.)
Population growth rate: 3.37% (2006 est.)
Birth rate: 47.35 births/1,000 population (2006 est.)
Death rate: 1 2.24 deaths/1 ,000 population (2006 est.)
Net migration rate: -1 .4 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.76 male(s)/female
total population: 1 male(s)/female (2006 est.)
Infant mortality rate:
total: 66.1 5 deaths/1 ,000 live births
male: 69.51 deaths/1 ,000 live births
female: 62.69 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 52.67 years
male: 51 .68 years
female: 53.69 years (2006 est.)
Total fertility rate: 6.71 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 4.1% (2003 est.)
HIV/AIDS - people living with HIV/AIDS: 530,000
(2001 est.)
HIV/AIDS - deaths: 78,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterborne diseases: bacterial diarrhea,
hepatitis A, and typhoid fever
vectorborne diseases: malaria and African
trypanosomiasis (sleeping sickness) are high risks in
some locations
water contact disease: schistosomiasis (2004)
Nationality:
noun: Ugandan(s)
adjective: Ugandan
Ethnic groups: Baganda 17%, Ankole 8%, Basoga
8%, Iteso 8%, Bakiga 7%, Langi 6%, Rwanda 6%,
Bagisu 5%, Acholi 4%, Lugbara 4%, Batoro 3%,
Bunyoro 3%, Alur 2%, Bagwere 2%, Bakonjo 2%,
Jopodhola 2%, Karamojong 2%, Rundi 2%,
non-African (European, Asian, Arab) 1%, other 8%
Religions: Roman Catholic 33%, Protestant 33%,
Muslim 16%, indigenous beliefs 18%
Languages: English (official national language,
taught in grade schools, used in courts of law and by
most newspapers and some radio broadcasts),
Ganda or Luganda (most widely used of the
Niger-Congo languages, preferred for native
language publications in the capital and may be taught
in school), other Niger-Congo languages,
Nilo-Saharan languages, Swahili, Arabic
Literacy:
definition: age 1 5 and over can read and write
total population: 69.9%
male: 79.5%
female: 60.4% (2003 est.)','bebf7ab2a168a2b4a60c05d0662e58cf615813ae3ddb4c92880dd8160d32f155','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17d51e8a0ef8a54caf77789dccbb999ecdd714b8225d30a62ada81d4feed59c0',2007,'QA','Qatar','people-and-society',1244,'Population: 2,602,713 (July 2006 est.)
Age structure:
0-14 years: 24.9% (male 331 ,012/female 317,643)
15-64 years: 71 .2% (male 1 ,125,286/female 726,689)
65 years and over: 3.9% (male 74,700/female
27,383) (2006 est.)
Median age:
total: 28.1 years
male: 34.8 years
female: 23.3 years (2006 est.)
Population growth rate: 1 .52% (2006 est.)
Birth rate: 18.96 births/1,000 population (2006 est.)
Death rate: 4.4 deaths/1 ,000 population (2006 est.)
Net migration rate: 0.66 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .55 male(s)/female
65 years and over: 2.73 male(s)/female
total population: \\ .43 male(s)/female (2006 est.)
576
United Arab Emirates (continued)
Infant mortality rate:
total: 14.09 deaths/ 1 ,000 live births
male: 16.57 deaths/1 ,000 live births
female: 1 1 .48 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 75.44 years
male: 72.92 years
female: 78.08 years (2006 est.)
Total fertility rate: 2.88 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.18%
(2001 est.)
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Emirati(s)
adjective: Emirati
Ethnic groups: Emirati 19%, other Arab and Iranian
23%, South Asian 50%, other expatriates (includes
Westerners and East Asians) 8% (1982)
note: less than 20% are UAE citizens (1982)
Religions: Muslim 96% (Shi''a 16%), Christian,
Hindu, and other 4%
Languages: Arabic (official), Persian, English, Hindi,
Urdu
Literacy:
definition: age 15 and over can read and write
total population: 77.9%
male: 76.1%
female: 81 .7% (2003 est.)','4fe644a826a844907cac0aee5e0affedd9ee055518d67be57219f5983e796eb6','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cb5a726e05cb48e6790c9e1b6ff6bf2b76b308f22ec0c0014235d5f8a8f7b04',2007,'UY','Uruguay','people-and-society',1253,'Population: 3,431 ,932 (July 2006 est.)
Age structure:
0-14 years: 22.9% (male 399,409/female 386,136)
15-64 years: 63.9% (male 1 ,087,1 80/female
1,104,465)
65 years and over: 13.3% (male 185,251 /female
269,491) (2006 est.)
Median age:
total: 32.7 years
male: 31 .3 years
female: 34.2 years (2006 est.)
Population growth rate: 0.46% (2006 est.)
Birth rate: 13.91 births/1,000 population (2006 est.)
Death rate: 9.05 deaths/1 ,000 population (2006 est.)
Net migration rate: -0.25 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .04 male(s)/female
under 15 years: 1 .03 male(s)/female
15-64 years: 0.98 male(s)/female
65 years and over: 0.69 male(s)/female
total population: 0.95 male(s)/female (2006 est.)
Infant mortality rate:
total: 1 1 .61 deaths/1 ,000 live births
male: 12.9 deaths/1,000 live births
female: 10.27 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 76.33 years
male: 73.1 2 years
female: 79.65 years (2006 est.)
Total fertility rate: 1 .89 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.3% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 6,000
(2001 est.)
HIV/AIDS • deaths: less than 500 (2003 est.)
Nationality:
noun: Uruguayan(s)
adjective: Uruguayan
Ethnic groups: white 88%, mestizo 8%, black 4%,
Amerindian (practically nonexistent)
Religions: Roman Catholic 66% (less than half of the
adult population attends church regularly), Protestant
2%, Jewish 1%, nonprofessing or other 31%
Languages: Spanish, Portunol, or Brazilero
(Portuguese-Spanish mix on the Brazilian frontier)
Literacy:
definition: age 15 and over can read and write
total population: 98%
male: 97.6%
female: 98.4% (2003 est.)','54bb83fe794a4c3da7ccadc5399acda51813065a205dfb86977e41259bdbaba6','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('354d1237396b67189ba14909db6e1836cde613fc4dacf7cfd8c73790be234c99',2007,'MP','Northern Mariana Islands','people-and-society',1263,'Population: no indigenous inhabitants
note: US military personnel have left the island, but
contractor personnel remain; as of October 2001 , 200
contractor personnel were present (July 2006 est.)','c78f0d885fab86b1689d1112f5e8bdb1a2782851fcaf1637e731cfe46f6e7607','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20dbc93e174273fe1b69ee5080cbe63d290e99cb34cd3a7abe126f2fdfac3628',2007,'IL','Israel','people-and-society',1268,'Population: 2,460,492
note: in addition, there are about 187,000 Israeli
settlers in the West Bank and fewer than 177,000 in
East Jerusalem (July 2004 est.)
Age structure:
0-14 years: 42.9% (male 541 ,1 10/female 515,202)
15-64 years: 53.7% (male 676,427/female 644,347)
65 years and over: 3.4% (male 35,440/female
47,966) (2006 est.)
Median age:
total: 18.3 years
male: 18.2 years
female: 18.5 years (2006 est.)
Population growth rate: 3.06% (2006 est.)
Birth rate: 31 .67 births/1 ,000 population (2006 est.)
Death rate: 3.92 deaths/1 ,000 population (2006 est.)
Net migration rate: 2.8 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .05 male(s)/female
15-64 years: 1 .05 male(s)/female
65 years and over: 0.74 male(s)/female
total population: 1 .04 male(s)/female (2006 est.)
Infant mortality rate:
total: 19.15 deaths/1,000 live births
male: 21 .1 2 deaths/1 ,000 live births
female: 17.05 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 73.27 years
male: 71 .5 years
female: 75.15 years (2006 est.)
Total fertility rate: 4.28 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: NA
adjective: NA
Ethnic groups: Palestinian Arab and other 83%,
Jewish 17%
Religions: Muslim 75% (predominantly Sunni),
Jewish 17%, Christian and other 8%
Languages: Arabic, Hebrew (spoken by Israeli
settlers and many Palestinians), English (widely
understood)
Literacy:
definition: age 1 5 and over can read and write
fofa/popu/af/on:91.9%
male: 96.3%
female: 87.4% (2003 est.)','eba33ca512a6ea3e6b45652cbcc0d94b3c98b76a0ed95ce14f898fca11e3dcc1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b1565f09a91fb914591f5953b9b37c84762b18fb3fdff981a952252d29bf41e',2007,'MR','Mauritania','people-and-society',1275,'Population: 273,008 (July 2006 est.)
Age structure:
0-14 years: NA
15-64 years: NA
65 years and over: NA (2006 est.)
Population growth rate: NA
Birth rate: NA births/1 ,000 population
Death rate: NA deaths/1 ,000 population
Sex ratio: NA
Infant mortality rate:
total: NA
male: NA
female: NA
Life expectancy at birth:
total population: NA years
male: NA years
female: NA years
Total fertility rate: NA children born/woman
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Major infectious diseases:
degree of risk: intermediate
food or waterborne diseases: bacterial and protozoal
diarrhea, hepatitis A, and typhoid fever
vectorbome diseases: may be a significant risk in
some locations during the transmission season
(typically April through November) (2004)
Nationality:
noun: Sahrawi(s), Sahraoui(s)
adjective: Sahrawi, Sahrawian, Sahraouian
Ethnic groups: Arab, Berber
Religions: Muslim
Languages: Hassaniya Arabic, Moroccan Arabic
Literacy: NA','243db0b4f314510e833356faeea717d0103a3bab06e8e1d8e8b300a67637a51c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef8919c602dfdbca82713073afbffce305bf987c26b851e2c249831e74bb11d0',2007,'SO','Somalia','people-and-society',1278,'Population: 21,456,188 (July 2006 est.)
Age structure:
0-14 years: 46.4% (male 5,067,762/female
4,881,333)
15-64 years: 51 % (male 5,568,078/female 5,375,263)
65 years and over: 2.6% (male 275,878/female
287,874) (2006 est.)
Median age:
total: 16.6 years
male: 16.6 years
female: 16.6 years (2006 est.)
Population growth rate: 3.46% (2006 est.)
Birth rate: 42.89 births/1,000 population (2006 est.)
Death rate: 8.3 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1 .04 male(s)/female
15-64 years: 1 .04 male(s)/female
65 years and over: 0.96 male(s)/female
total population: 1 .04 male(s)/female (2006 est.)
/
611
Yemen (continued)
Infant mortality rate:
total: 59.88 deaths/1 .000 live births
male: 64.55 deaths/'' 1 ,000 live births
female: 54.98 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 62. 1 2 years
male: 60.23 years
female: 64.1 1 years (2006 est.)
Total fertility rate: 6.58 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.1% (2001 est.)
HIV/AIDS • people living with HIV/AIDS: 12,000
(2001 est.)
HIV/AIDS - deaths: NA
Nationality:
noun: Yemeni(s)
adjective: Yemeni
Ethnic groups: predominantly Arab; but also
Afro-Arab, South Asians, Europeans
Religions: Muslim including Shaf''i (Sunni) and Zaydi
(Shi''a), small numbers of Jewish, Christian, and Hindu
Languages: Arabic
Literacy:
definition: age 1 5 and over can read and write
total population: 50.2%
male: 70.5%
female: 30% (2003 est.)','9bb1c4da12e9022120803cad77fff00a6b92315b499e2cc2df34c2d4da91e5b0','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ad37e89e9a235200c324e35680897d3c144dbbde28abfcd1109f0ee4ee74a6f',2007,'ZM','Zambia','people-and-society',1284,'Population: 11,502,010
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS;
this can result in lower life expectancy, higher infant
mortality and death rates, lower population and growth
rates, and changes in the distribution of population by
age and sex than would otherwise be expected
(July 2006 est.)
Age structure:
0-14 years: 46.3% (male 2.673,891 /female
2,656,268)
15-64 years: 51 .3% (male 2.925,91 0/female
2,969,324)
65 years and over: 2.4% (male 1 1 7,877/female
158,740) (2006 est.)
Median age:
tofa/: 16.5 years
male: 16.3 years
female: 16.7 years (2006 est.)
Population growth rate: 2.1 1% (2006 est.)
Birth rate: 41 births/1 ,000 population (2006 est.)
Death rate: 1 9.93 deaths/1 .000 population
(2006 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1.01 male(s)/female
15-64 years: 0.99 male(s)/female
65 years and over: 0.74 male(s)/female
total population: 0.99 male(s)/female (2006 est.)
Infant mortality rate:
total: 86.84 deaths/1 ,000 live births
male: 94.08 deaths/1 ,000 live births
female: 79.37 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 40.03 years
male: 39.76 years
female: 40.31 years (2006 est.)
Total fertility rate: 5.39 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 16.5%
(2003 est.)
HIV/AIDS • people living with HIV/AIDS: 920,000
(2003 est.)
HIV/AIDS - deaths: 89,000 (2003 est.)
Major infectious diseases:
degree of risk: very high
food or waterbome diseases: bacterial diarrhea,
hepatitis A, and typhoid fever
vectorborne diseases: malaria and plague are high
risks in some locations
water contact disease: schistosomiasis (2004)
Nationality:
noun: Zambian(s)
adjective: Zambian
Ethnic groups: African 98.7%, European 1.1%,
other 0.2%
Religions: Christian 50%-75%, Muslim and Hindu
24%-49%, indigenous beliefs 1%
Languages: English (official), major vernaculars -
Bemba, Kaonda, Lozi, Lunda, Luvale, Nyanja, Tonga,
and about 70 other indigenous languages
Literacy:
definition: age 1 5 and over can read and write English
total population: 80.6%
male: 86.8%
female: 74.8% (2003 est.)
Population: 12,236,805
note: estimates for this country explicitly take into
account the effects of excess mortality due to AIDS; this
can result in lower life expectancy, higher infant mortality
and death rates, lower population and growth rates, and
changes in the distribution of population by age and sex
than would otherwise be expected (July 2006 est.)
Age structure:
0-14 years: 37.4% (male 2,307, 170/female
2,265,298)
15-64 years: 59.1% (male 3,616,528/female
3,621,190)
65 years and over: 3.5% (male 1 99,468/female
227,151) (2006 est.)
Median age:
total: 19.9 years
male: 19.7 years
female: 20 years (2006 est.)
616
Zimbabwe (continued)
Population growth rate: 0.62% (2006 est.)
Birth rate: 28.01 births/1, 000 population (2006 est.)
Death rate: 21 .84 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1 ,000 population
note: there is an increasing flow of Zimbabweans into
South Africa and Botswana in search of better
economic opportunities (2006 est.)
Sex ratio:
at birth: 1 .03 male(s)/female
under 15 years: 1 .02 male(s)/female
15-64 years: 1 male(s)/female
65 years and over: 0.88 male(s)/female
total population: 1 male(s)/female (2006 est.)
Infant mortality rate:
total: 51 .71 deaths/1 ,000 live births
male: 54.5 deaths/1 ,000 live births
female: 48.83 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 39.29 years
male: 40.39 years
female: 38.16 years (2006 est.)
Total fertility rate: 3.13 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 24.6%
(2001 est.)
HIV/AIDS - people living with HIV/AIDS: 1 .8 million
(2001 est.)
HIV/AIDS - deaths: 1 70,000 (2003 est.)
Major infectious diseases:
degree of risk: high
food or waterborne diseases: bacterial diarrhea,
hepatitis A, and typhoid
vectorborne disease: malaria
water contact disease: schistosomiasis (2004)
Nationality:
noun: Zimbabwean(s)
adjective: Zimbabwean
Ethnic groups: African 98% (Shona 82%, Ndebele
14%, other 2%), mixed and Asian 1 %, white less than
10/
I 0
Religions: syncretic (part Christian, part indigenous
beliefs) 50%, Christian 25%, indigenous beliefs 24%,
Muslim and other 1%
Languages: English (official), Shona, Sindebele (the
language of the Ndebele, sometimes called Ndebele),
numerous but minor tribal dialects
Literacy:
definition: age 1 5 and over can read and write English
total population: 90.7%
male: 94.2%
female: 87.2% (2003 est.)
Population: 23,036,087 (July 2006 est.)
Age structure:
0-14 years: 19.4% (male 2,330,951/female
2,140,965)
15-64 years: 70.8% (male 8,269,421/female
8,040,169)
65 years and over: 9.8% (male 1 ,123,429/female
1,131,152) (2006 est.)
Median age:
total: 34.6 years
male: 34.1 years
female: 35 years (2006 est.)
Population growth rate: 0.61% (2006 est.)
Birth rate: 1 2.56 births/1 ,000 population (2006 est.)
Death rate: 6.48 deaths/1 ,000 population (2006 est.)
Net migration rate: 0 migrant(s)/1,000 population
(2006 est.)
Sex ratio:
at birth: 1 .1 male(s)/female
under 15 years: 1. 09 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.99 male(s)/female
total population: 1 .04 male(s)/female (2006 est.)
Infant mortality rate:
total: 6.29 deaths/1 ,000 live births
male: 6.97 deaths/1 ,000 live births
female: 5.55 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 77.43 years
male: 74.67 years
female: 80.47 years (2006 est.)
Total fertility rate: 1 .57 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Nationality:
noun: Taiwan (singular and plural)
note: example - he or she is from Taiwan; they are
from Taiwan
adjective: Taiwan
Ethnic groups: Taiwanese (including Hakka) 84%,
mainland Chinese 14%, aborigine 2%
Religions: mixture of Buddhist, Confucian, and
Taoist 93%, Christian 4.5%, other 2.5%
Languages: Mandarin Chinese (official), Taiwanese
(Min), Hakka dialects
Literacy:
definition: age 1 5 and over can read and write
total population: 96.1%
male: NA%
female: NA% (2003)
Population: 456,953,258 (July 2006 est.)
Age structure:
0-14 years: 16.03% (male 37,608,01 0/female
35,632,351)
15-64 years: 67.17% (male 154,439,536/female
152,479,619)
65 years and over: 1 6.81 % (male 31 ,51 5,921/female
45,277,821) (2006 est.)
Median age: NA
Population growth rate: 0.15% (2006 est.)
Birth rate: 10 births/1 ,000 population (2006 est.)
Death rate: 1 0. 1 deaths/1 ,000 population (2006 est.)
Net migration rate: 1 .5 migrant(s)/1 ,000 population
(2006 est.)
Sex ratio:
at birth: NA
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .01 male(s)/female
65 years and older: 0.69 male(s)/female
total population: 0.96 male(s)/female (2006 est.)
Infant mortality rate:
total: 5.1 deaths/1,000 live births
male: 5.6 deaths/1 ,000 live births
female: 4.5 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 78.3 years
ma/e.'' 75.1 years
female: 81. 6 years (2006 est.)
Total fertility rate: 1 .47 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: NA%
HIV/AIDS - people living with HIV/AIDS: NA
HIV/AIDS - deaths: NA
Religions: Roman Catholic, Protestant, Orthodox,
Muslim, Jewish
Languages: Czech, Danish, Dutch, English,
Estonian, Finnish, French, German, Greek,
Hungarian, Italian, Latvian, Lithuanian, Maltese,
Polish, Portuguese, Slovak, Slovene, Spanish,
Swedish; note - only official languages are listed; Irish
(Gaelic) will become the 21st language on 1 January
2007','117830c9fe44c39f63affbc64d06865d00783519883529ef5e036c59c1b7df79','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e341f615397f3b580c7e32a1edaa74e5c90c5d93eb7037e693b6da85e010a9e1',2007,'ZW','Zimbabwe','people-and-society',5,'Population
Birth rate
Death rate
Infant mortality rate
Life expectancy at birth - total
Total fertility rate
HIV/AIDS - adult prevalence rate
HIV/AIDS - people living with HIV/AIDS
HIV/AIDS - deaths
Economy Zimbabwe
Economy - overview:
The government of Zimbabwe faces a wide variety of difficult
economic problems as it struggles with an unsustainable fiscal
deficit, an overvalued exchange rate, soaring inflation, and bare
shelves. Its 1998-2002 involvement in the war in the Democratic
Republic of the Congo drained hundreds of millions of dollars from
the economy. The government''s land reform program, characterized by
chaos and violence, has badly damaged the commercial farming sector,
the traditional source of exports and foreign exchange and the
provider of 400,000 jobs, turning Zimbabwe into a net importer of
food products. Badly needed support from the IMF has been suspended
because of the government''s arrears on past loans, which it began
repaying in 2005. The official annual inflation rate rose from 32%
in 1998, to 133% in 2004, 585% in 2005, and approached 1000% in
2006, although private sector estimates put the figure much higher.
Meanwhile, the official exchange rate fell from approximately 1
(revalued) Zimbabwean dollar per US dollar in 2003 to 250 per US
dollar in August 2006.
GDP (purchasing power parity):
$25.05 billion (2006 est.)
GDP (official exchange rate):
$3.146 billion (2006 est.)
GDP - real growth rate:
-4.4% (2006 est.)
GDP - per capita (PPP):
$2,000 (2006 est.)
GDP - composition by sector:
agriculture: 17.7%
industry: 22.9%
services: 59.4% (2006 est.)
Labor force:
3.958 million (2006 est.)
Labor force - by occupation:
agriculture: 66%
industry: 10%
services: 24% (1996)
Unemployment rate:
80% (2005 est.)
Population below poverty line:
80% (2004 est.)
Household income or consumption by percentage share:
lowest 10%: 2%
highest 10%: 40.4% (1995)
Distribution of family income - Gini index:
56.8 (2003)
Inflation rate (consumer prices):
976.4% official data; private sector estimates are much higher
(2006 est.)
Investment (gross fixed):
16.1% of GDP (2006 est.)
Budget:
revenues: $1.411 billion
expenditures: $1.924 billion; including capital expenditures of $NA
(2006 est.)
Public debt:
108.4% of GDP (2006 est.)
Agriculture - products:
corn, cotton, tobacco, wheat, coffee, sugarcane, peanuts; sheep,
goats, pigs
Industries:
mining (coal, gold, platinum, copper, nickel, tin, clay, numerous
metallic and nonmetallic ores), steel; wood products, cement,
chemicals, fertilizer, clothing and footwear, foodstuffs, beverages
Industrial production growth rate:
-1.8% (2006 est.)
Electricity - production:
9.412 billion kWh (2004)
Electricity - production by source:
fossil fuel: 47%
hydro: 53%
nuclear: 0%
other: 0% (2001)
Electricity - consumption:
11 billion kWh (2004)
Electricity - exports:
0 kWh (2004)
Electricity - imports:
2.25 billion kWh (2004)
Oil - production:
0 bbl/day (2004 est.)
Oil - consumption:
22,500 bbl/day (2004 est.)
Oil - exports:
0 bbl/day (2004 est.)
Oil - imports:
23,000 bbl/day (2004 est.)
Natural gas - production:
0 cu m (2004 est.)
Natural gas - consumption:
0 cu m (2004 est.)
Current account balance:
$-264.6 million (2006 est.)
Exports:
$1.766 billion f.o.b. (2006 est.)
Exports - commodities:
cotton, tobacco, gold, ferroalloys, textiles/clothing
Exports - partners:
South Africa 27%, China 7.9%, Japan 6.8%, Zambia 5.6%, Netherlands
5.4%, US 4.9%, Italy 4.5%, Germany 4.4% (2005)
Imports:
$2.055 billion f.o.b. (2006 est.)
Imports - commodities:
machinery and transport equipment, other manufactures, chemicals,
fuels
Imports - partners:
South Africa 52.5%, China 5.7%, Botswana 4.1% (2005)
Reserves of foreign exchange and gold:
$140 million (2006 est.)
Debt - external:
$5.26 billion (2006 est.)
Economic aid - recipient:
$178 million; note - the EU and the US provide food aid on
humanitarian grounds (2000 est.)
Currency (code):
Zimbabwean dollar (ZWD)
Currency code:
ZWD
Exchange rates:
Zimbabwean dollars per US dollar - 195.107 (2006), 77.965 (2005),
5.729 (2004), 0.824 (2003), 0.055 (2002), note, these are official
exchange rates; non-official rates vary significantly
Fiscal year:
calendar year
Communications Zimbabwe
Telephones - main lines in use:
328,000 (2005)
Telephones - mobile cellular:
699,000 (2005)
Telephone system:
general assessment: system was once one of the best in Africa, but
now suffers from poor maintenance; more than 100,000 outstanding
requests for connection despite an equally large number of installed
but unused main lines
domestic: consists of microwave radio relay links, open-wire lines,
radiotelephone communication stations, fixed wireless local loop
installations, and a substantial mobile cellular network; Internet
connection is available in Harare and planned for all major towns
and for some of the smaller ones
international: country code - 263; satellite earth stations - 2
Intelsat; two international digital gateway exchanges (in Harare and
Gweru)
Radio broadcast stations:
AM 7, FM 20 (plus 17 repeater stations), shortwave 1 (1998)
Radios:
1.14 million (1997)
Television broadcast stations:
16 (1997)
Televisions:
370,000 (1997)
Internet country code:
.zw
Internet hosts:
7,954 (2006)
Internet Service Providers (ISPs):
6 (2000)
Internet users:
1 million (2005)
Transportation Zimbabwe
Airports:
403 (2006)
Airports - with paved runways:
total: 17
over 3,047 m: 3
2,438 to 3,047 m: 2
1,524 to 2,437 m: 4
914 to 1,523 m: 8 (2006)
Airports - with unpaved runways:
total: 386
1,524 to 2,437 m: 5
914 to 1,523 m: 187
under 914 m: 194 (2006)
Pipelines:
refined products 261 km (2006)
Railways:
total: 3,077 km
narrow gauge: 3,077 km 1.067-m gauge (313 km electrified) (2005)
Roadways:
total: 97,440 km
paved: 18,514 km
unpaved: 78,926 km (2002)
Waterways:
on Lake Kariba, length small (2005)
Ports and terminals:
Binga, Kariba
Military Zimbabwe
Military branches:
Zimbabwe Defense Forces (ZDF): Zimbabwe National Army, Air Force of
Zimbabwe (AFZ), Zimbabwe Republic Police (2005)
Military service age and obligation:
18 years of age (est.) (2004)
Manpower available for military service:
males age 18-49: 2,778,404
females age 18-49: 2,681,531 (2005 est.)
Manpower fit for military service:
males age 18-49: 1,304,424
females age 18-49: 1,115,096 (2005 est.)
Military expenditures - dollar figure:
$124.7 million (2005 est.)
Military expenditures - percent of GDP:
4% (2005 est.)
Transnational Issues Zimbabwe
Disputes - international:
Botswana has built electric fences and South Africa has placed
military along the border to stem the flow of thousands of
Zimbabweans fleeing to find work and escape political persecution;
Namibia has supported and in 2004 Zimbabwe dropped objections to
plans between Botswana and Zambia to build a bridge over the Zambezi
River, thereby de facto recognizing a short, but not clearly
delimited Botswana-Zambia boundary in the river
Refugees and internally displaced persons:
refugees (country of origin): 6,536 (Democratic Republic of Congo)
IDPs: 569,685 (MUGABE-led political violence, human rights
violations, land reform, and economic collapse) (2006)
Trafficking in persons:
current situation: Zimbabwe is a source, transit, and destination
country for women and children trafficked for forced labor and
sexual exploitation; children may be trafficked internally for
forced agricultural labor, domestic servitude, and sexual
exploitation; women and girls are lured out of the country to South
Africa, China, Egypt, and Zambia with false job or scholarship
promises that result in domestic servitude or commercial sexual
exploitation; there are reports of South African employers demanding
sex from undocumented Zimbabwean workers under threat of
deportation; women and children from Malawi, Zambia, and the
Democratic Republic of the Congo transit Zimbabwe en route to South
Africa; small numbers of South African girls are trafficked to
Zimbabwe for domestic labor
tier rating: Tier 3 - Zimbabwe does not fully comply with the
minimum standards for the elimination of trafficking and is not
making significant efforts to do so
Illicit drugs:
transit point for African cannabis and South Asian heroin, mandrax,
and methamphetamines destined for the South African and European
markets
This page was last updated on 8 February, 2007
======================================================================
@2001 GDP (purchasing power parity)
$25.05 billion (2006 est.)
This page was last updated on 8 February, 2007
======================================================================
@2002 Population growth rate (%)
0.62% (2006 est.)
This page was last updated on 8 February, 2007
======================================================================
@2003 GDP - real growth rate (%)
-4.4% (2006 est.)
This page was last updated on 8 February, 2007
======================================================================
@2004 GDP - per capita (PPP)
$2,000 (2006 est.)
This page was last updated on 8 February, 2007
======================================================================
@2006 Dependency status
Akrotiri
overseas territory of UK; administered by an administrator
who is also the Commander, British Forces Cyprus','79b4632bab23e08736623a751d4d43429a31f8cd35fa30dd8357400da7d0787a','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e095b1ea09ef22de5f7486f87804162195e19a1eec6c37b4dad41342b5abfead',2007,'MH','Marshall Islands','people-and-society',227,'Religions:
nominally Roman Catholic 96%, Protestant 2%, other 2%
Languages:
Spanish (official), numerous indigenous dialects
Literacy:
definition: age 15 and over can read and write
total population: 93.4%
male: 93.8%
female: 93.1% (2003 est.)
Government Venezuela
Country name:
conventional long form: Bolivarian Republic of Venezuela
conventional short form: Venezuela
local long form: Republica Bolivariana de Venezuela
local short form: Venezuela
Government type:
federal republic
Capital:
name: Caracas
geographic coordinates: 10 30 N, 66 56 W
time difference: UTC-4 (1 hour ahead of Washington, DC during
Standard Time)
Administrative divisions:
23 states (estados, singular - estado), 1 capital district*
(distrito capital), and 1 federal dependency** (dependencia
federal); Amazonas, Anzoategui, Apure, Aragua, Barinas, Bolivar,
Carabobo, Cojedes, Delta Amacuro, Dependencias Federales**, Distrito
Federal*, Falcon, Guarico, Lara, Merida, Miranda, Monagas, Nueva
Esparta, Portuguesa, Sucre, Tachira, Trujillo, Vargas, Yaracuy, Zulia
note: the federal dependency consists of 11 federally controlled
island groups with a total of 72 individual islands
Independence:
5 July 1811 (from Spain)
National holiday:
Independence Day, 5 July (1811)
Constitution:
30 December 1999
Legal system:
open, adversarial court system
Suffrage:
18 years of age; universal
Executive branch:
chief of state: President Hugo CHAVEZ Frias (since 3 February
1999); Vice President Jorge RODRIGUEZ Gomez (since 3 January 2007);
note - the president is both the chief of state and head of
$115 million (2001 est.)
2.25% (2006 est.)
3.5% (2005 est.)
$2,900 (2005 est.)','205f9567fb9e521b0edeb2e617d344abba80b8449546f684b3604ce8f6e05e20','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('693dcf90cca9276b4d84be3754cc92057286b2a01e92f7c33417bdc9f2c8e904',2007,'AF','Afghanistan','people-and-society',229,'$21.5 billion (2004 est.)
2.67% (2006 est.)
8.4% (2006 est.)
$800 (2004 est.)
chief of mission: Ambassador Ronald E. NEUMANN
embassy: The Great Masood Road, Kabul
mailing address: U.S. Embassy Kabul, APO, AE 09806
telephone: [00 93] (20) 230-0436
FAX: [00 93] (20) 230-1364
Akrotiri
none (overseas territory of the UK)','afa6b3fcedbe3dd3863ebe7ccbcf5681205151200d8c029d0610592c9c32ffd2','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1637c044b465c50139bec8c43372858311d21200c4e5f5eecb64369954eabf60',2007,'AL','Albania','people-and-society',230,'$20.21 billion
note: Albania has a large gray economy that may be as large as 50%
of official GDP (2006 est.)
0.52% (2006 est.)
5% (2006 est.)
$5,600 (2006 est.)
chief of mission: Ambassador Marcie B. RIES
embassy: Rruga e Elbasanit, Labinoti #103, Tirana
mailing address: US Department of State, 9510 Tirana Place, Dulles,
VA 20189-9510
telephone: [355] (4) 247285
FAX: [355] (4) 232222','03e0bb651194a88229539db0c38b29c178118021ac6776d9b1b36dc788cd2e28','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6bcbffe639df1b3500ee11fb5963765c188f6efb0ac46a35d39b6405e021383',2007,'DZ','Algeria','people-and-society',231,'$253.4 billion (2006 est.)
1.22% (2006 est.)
5.6% (2006 est.)
$7,700 (2006 est.)
chief of mission: Ambassador Robert S. FORD
embassy: 04 Chemin Cheikh Bachir Ibrahimi El-Biar 16030, Algiers
mailing address: B. P. 408, Alger-Gare, 16030 Algiers
telephone: [213] (021) 69-12-55
FAX: [213] (021) 69-39-79','4b7568d4e922c003e0af4241f6c7fd4f78e77a652975e21a9759ee41230fe0ed','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc7cf2166fe49509b212d99c8114554facd62204250a52debef87785b70cd900',2007,'AS','American Samoa','people-and-society',232,'$510.1 million (2003 est.)
-0.19% (2006 est.)
3% (2003)
$5,800 (2005 est.)
unincorporated and unorganized territory of the US;
administered by the Office of Insular Affairs, US Department of the
Interior
none (territory of the US)','086a771dd5cf3f0455358cf722fa7ea7108066b85aefba7e782d093c579438e1','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ce65057504bff4b3683e6236be89b97791121b8fbae0bfe168f3ebb4c3ba9eb',2007,'AD','Andorra','people-and-society',233,'$1.84 billion (2004)
0.89% (2006 est.)
4% (2004 est.)
$24,000 (2004)
the US does not have an embassy in Andorra; the US
Ambassador to Spain is accredited to Andorra; US interests in
Andorra are represented by the Consulate General''s office in
Barcelona (Spain); mailing address: Paseo Reina Elisenda de
Montcada, 23, 08034 Barcelona, Spain; telephone: [34] (3) 280-2227;
FAX: [34] (3) 205-5206','d2055186738c75bd999129c2ef08e25d3bb836e52b354fac28fd4db5ac3ef8c4','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de02270da5d2d21c00cb7dba0759f26d61df94d9662b2ae2dfcf4e00e50fc493',2007,'AO','Angola','people-and-society',234,'$51.95 billion (2006 est.)
2.45% (2006 est.)
14% (2006 est.)
$4,300 (2006 est.)
chief of mission: Ambassador Cynthia EFIRD
embassy: number 32 Rua Houari Boumedienne (in the Miramar area of
Luanda), Luanda
mailing address: international mail: Caixa Postal 6468, Luanda;
pouch: US Embassy Luanda,US Department of State, 2550 Luanda Place,
Washington, DC 20521-2550
telephone: [244] (222) 64-1000
FAX: [244] (222) 64-1232','7a158aed41fef7fbe3ed21fc1ed7f7f6eb36cd9bda4449d38851197c59461c9e','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87991a81f1f1c1656014b450dcbaf78bf5690bbea4534f2c17d3abf91b1724e7',2007,'AI','Anguilla','people-and-society',235,'$108.9 million (2004 est.)
1.57% (2006 est.)
10.2% (2004 est.)
$8,800 (2004 est.)
overseas territory of the UK
none (overseas territory of the UK)','14d55bd62fea719cb1e09f58964dc4fbf0baaa7f9663506dc6ab122a93363a27','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3acd26b4afe786359f6ae6772acadb132fc19edc9702a4903104ec774f7a2e9',2007,'AG','Antigua and Barbuda','people-and-society',236,'$750 million (2002 est.)
0.55% (2006 est.)
3.8% (2005 est.)
$10,900 (2005 est.)
the US does not have an embassy in Antigua and
Barbuda; the US Ambassador to Barbados is accredited to Antigua and
Barbuda','bb2b36cdf017b50704c0cbdb6fb1ee401956a85f29de3008df7cd390910c7640','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b83a4d21771e480747e77ba9bd1e02433a9445057963942ff5e5d6f2dd7854ce',2007,'AR','Argentina','people-and-society',237,'$599.1 billion (2006 est.)
0.96% (2006 est.)
8.5% (2006 est.)
$15,000 (2006 est.)
chief of mission: Ambassador Earl Anthony WAYNE
embassy: Avenida Colombia 4300, C1425GMN Buenos Aires
mailing address: international mail: use street address; APO
address: Unit 4334, APO AA 34034
telephone: [54] (11) 5777-4533
FAX: [54] (11) 5777-4240','66c5e62844ffdd5297c405c93c6587dcacaa4c9a327a7691199d0c73b361d549','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9883a0bd6ad9cc9ca6c82e1de6e110f58f0ba7523345bf4099d8d356babdb084',2007,'AM','Armenia','people-and-society',238,'$15.99 billion (2006 est.)
-0.19% (2006 est.)
10.5% (2006 est.)
$5,400 (2006 est.)
chief of mission: Ambassador (vacant); Charge d''Affaires
Anthony F. GODFREY
embassy: 1 American Ave., Yerevan 375082
mailing address: American Embassy Yerevan, US Department of State,
7020 Yerevan Place, Washington, DC 20521-7020
telephone: [374](10) 464-700
FAX: [374](10) 464-742','d767d883ec8c8c945c56de5d1738742d8155ed1d942c93ef6fbc99fe8b7c1aaa','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('26759f992739c63bfb646c4b8de8cb39ef787951b1f37da79bc5d94c7b87e8d9',2007,'AW','Aruba','people-and-society',239,'$2.258 billion (2005 est.)
0.44% (2006 est.)
2.4% (2005 est.)
$21,800 (2004 est.)
member country of the Kingdom of the Netherlands; full
autonomy in internal affairs obtained in 1986 upon separation from
the Netherlands Antilles; Dutch Government responsible for defense
and foreign affairs
Ashmore and Cartier Islands
territory of Australia; administered by
the Australian Department of Transport and Regional Services
Baker Island
unincorporated territory of the US; administered from
Washington, DC, by the Fish and Wildlife Service of the US
Department of the Interior as part of the National Wildlife Refuge
system
Bassas da India
possession of France; administered by the
Administrateur Superieur of the French Southern and Antarctic Lands
the US does not have an embassy in Aruba; the Consul General
to Netherlands Antilles is accredited to Aruba
Ashmore and Cartier Islands
none (territory of Australia)','51ff1bb6f43de669d5f3132ad3a3db010249a2515f2595a31a60861f8e496281','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b4cf93eaff5e427e1c0d03f4d59ab4150a6390de745be6fde85a189ed5117b6',2007,'AU','Australia','people-and-society',240,'$666.3 billion (2006 est.)
0.85% (2006 est.)
2.8% (2006 est.)
$32,900 (2006 est.)
chief of mission: Ambassador Robert D. McCALLUM, Jr.
embassy: Moonah Place, Yarralumla, Canberra, Australian Capital
Territory 2600
mailing address: APO AP 96549
telephone: [61] (02) 6214-5600
FAX: [61] (02) 6214-5970
consulate(s) general: Melbourne, Perth, Sydney','934c33b888e14ea4184cf19dcfc0d7b6fb24d0094b1d4dffbe911738b03cabe1','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8622280e04b3b3ba95e14ce20a93f5608f65fe6cb4fd01172a5c2519782836bc',2007,'AT','Austria','people-and-society',241,'$279.5 billion (2006 est.)
0.09% (2006 est.)
3.3% (2006 est.)
$34,100 (2006 est.)
chief of mission: Ambassador Susan R. McCAW
embassy: Boltzmanngasse 16, A-1090, Vienna
mailing address: use embassy street address
telephone: [43] (1) 31339-0
FAX: [43] (1) 3100682','f304429815fbfacdc1b8c780056d17833e56cc283810ef0d5b2be13a7ccd49a3','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a00c972fa72b1e0fedb7b1b6a832697b434324e9ca7dc15c4bb2d98950e9023f',2007,'AZ','Azerbaijan','people-and-society',242,'$58.1 billion (2006 est.)
Bahamas, The
$6.476 billion (2006 est.)
0.66% (2006 est.)
Bahamas, The
0.64% (2006 est.)
32.5% (2006 est.)
Bahamas, The
4% (2006 est.)
$7,300 (2006 est.)
Bahamas, The
$21,300 (2006 est.)
chief of mission: Ambassador Anne E. DERSE
embassy: 83 Azadliyg Prospecti, Baku AZ1007
mailing address: American Embassy Baku, US Department of State, 7050
Baku Place, Washington, DC 20521-7050
telephone: [994] (12) 4980-335 through 337
FAX: [994] (12) 4656-671
Bahamas, The
chief of mission: Ambassador John D. ROOD
embassy: 42 Queen Street, Nassau
mailing address: local or express mail address: P. O. Box N-8197,
Nassau; US Department of State, 3370 Nassau Place, Washington, DC
20521-3370
telephone: [1] (242) 322-1181, 328-2206 (after hours)
FAX: [1] (242) 356-0222','7029981cda7d675ed3caa40939b47b0e979e1c14d525c070fea53555c0b983ec','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2fbf60b1537355fe34af850d06775de8c0be3cdf9a95ff735fdbf426c133f0c2',2007,'BH','Bahrain','people-and-society',243,'$17.7 billion (2006 est.)
1.45% (2006 est.)
7.6% (2006 est.)
$25,300 (2006 est.)
chief of mission: Ambassador William T. MONROE
embassy: Building #979, Road 3119 (next to Al-Ahli Sports Club),
Block 331, Zinj District, Manama
mailing address: American Embassy Manama, PSC 451, FPO AE
09834-5100; international mail: American Embassy, Box 26431, Manama
telephone: [973] 1724-2700
FAX: [973] 1727-0547','715688d6aba065bd644178888b4d75551b2a192a782c6db8613f902110a41f2f','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebea20f150ea33f58cd4df1a04b4441693da3c6eb82fa8daa90d6d473e2cbb92',2007,'BD','Bangladesh','people-and-society',244,'$330.8 billion (2006 est.)
2.09% (2006 est.)
6.1% (2006 est.)
$2,200 (2006 est.)
chief of mission: Ambassador Patricia A. BUTENIS
embassy: Madani Avenue, Baridhara, Dhaka 1212
mailing address: G. P. O. Box 323, Dhaka 1000
telephone: [880] (2) 885-5500
FAX: [880] (2) 882-3744','55ffbe46cdf3d2af13617de3eb7e3196782a8f5e90611e04e3287a891115160c','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7511340ff72f8093259bccf481bf655fb824aa004b64bacd99c32f6c98f174b0',2007,'BB','Barbados','people-and-society',245,'$5.108 billion (2006 est.)
0.37% (2006 est.)
4% (2006 est.)
$18,200 (2006 est.)
chief of mission: Ambassador Mary M. OURISMAN
embassy: Canadian Imperial Bank of Commerce Building, Broad Street,
Bridgetown; (courier) ALICO Building-Cheapside, Bridgetown
mailing address: P. O. Box 302, Bridgetown; CMR 1014, APO AA 34055
telephone: [1] (246) 436-4950
FAX: [1] (246) 429-5246, 429-3379','68a5572917e0b2e39d8eed8248e0e51939f9e822d3ee61c4212d3b23d52a151b','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5dddb7a69738662e4c3395c09a4cac66737313fb89f5b1c8130d607d0c293ea',2007,'BY','Belarus','people-and-society',246,'$80.74 billion (2006 est.)
-0.06% (2006 est.)
8.3% (2006 est.)
$7,800 (2006 est.)
chief of mission: Ambassador Karen B. STEWART
embassy: 46 Starovilenskaya St., Minsk 220002
mailing address: PSC 78, Box B Minsk, APO 09723
telephone: [375] (17) 210-12-83, 217-7347, 217-7348
FAX: [375] (17) 234-7853','dd63df3ca451fc8fcd87fcdd65ecd5b1e1ed33041aaab23f515f309e8c0601f9','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89707ba6457809c24501f90658bdc385dc6679fea40955de6a9c415ccca0f903',2007,'BE','Belgium','people-and-society',247,'$330.4 billion (2006 est.)
0.13% (2006 est.)
2.5% (2006 est.)
$31,800 (2006 est.)
chief of mission: Ambassador Tom C. KOROLOGOS; note -
Ambassador-designate Sam FOX may take his place in early 2007; must
face Senate confirmation hearing
embassy: Regentlaan 27 Boulevard du Regent, B-1000 Brussels
mailing address: PSC 82, Box 002, APO AE 09710
telephone: [32] (2) 508-2111
FAX: [32] (2) 511-2725','b06b3feb581f4732f014c0633ac183a08a6bbe9cdda7cadd245d53afe657a197','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6ce39c7b673f8a9969c70d6d54c5bb995aaf6eda254514a6e5762cb4c2ec1d5',2007,'BZ','Belize','people-and-society',248,'$2.307 billion (2006 est.)
2.31% (2006 est.)
3.5% (2005 est.)
$8,400 (2006 est.)
chief of mission: Ambassador Robert J. DIETER
embassy: Floral Park Road, Belmopan City, Cayo District
mailing address: 3050 Belize Place, Washington DC 20521-3050
telephone: [501] 227-7161 through 7163
FAX: [501] 223-0802','baa2bfaeba43077cb31b10cc0138cd3e068c5abdd384a06552daa699e81bc2fb','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9fa495f08e2d8fa66ffc6b4f2920845d0871bb9509cc2daeddc845833faa407f',2007,'BJ','Benin','people-and-society',249,'$8.931 billion (2006 est.)
2.73% (2006 est.)
4% (2006 est.)
$1,100 (2006 est.)
chief of mission: Ambassador Gayleatha B. BROWN
embassy: Rue Caporal Bernard Anani, Cotonou
mailing address: 01 B. P. 2012, Cotonou
telephone: [229] 30-06-50
FAX: [229] 30-06-70','d6898fc93e9b51bf64dd44affc4cef2790fbb1bf4300dd7ed01f1bfd316492dd','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0456ec1d24aa8f80b50ccfd5050a649a9334339a5fdedfe1af06f5be944be2aa',2007,'BM','Bermuda','people-and-society',250,'$4.5 billion (2004 est.)
0.61% (2006 est.)
4.6% (2004 est.)
$69,900 (2004 est.)
overseas territory of the UK
chief of mission: Consul General Gregory W. SLAYTON
consulate(s) general: Crown Hill, 16 Middle Road, Devonshire DVO3
mailing address: P. O. Box HM325, Hamilton HMBX; American Consulate
General Hamilton, US Department of State, 5300 Hamilton Place,
Washington, DC 20520-5300
telephone: [1] (441) 295-1342
FAX: [1] (441) 295-1592, [1] (441) 296-9233','7e4d5f636d64bec7d6dda3af3f3300a119445e5d94c79167048cdf6bbf241a5b','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7aa9825123725e681828ae290de07cb5cb5598df059cd0c6918c72eac42642ee',2007,'BT','Bhutan','people-and-society',251,'$2.9 billion (2003 est.)
Bolivia
$27.21 billion (2006 est.)
2.1% (2006 est.)
Bolivia
1.45% (2006 est.)
5.9% (2005 est.)
Bolivia
3.3% (2006 est.)
$1,400 (2003 est.)
Bolivia
$3,000 (2006 est.)
the US and Bhutan have no formal diplomatic relations,
although informal contact is maintained between the Bhutanese and US
Embassy in New Delhi (India)
Bolivia
chief of mission: Ambassador Philip S. GOLDBERG
embassy: Avenida Arce 2780, La Paz
mailing address: P. O. Box 425, La Paz; APO AA 34032
telephone: [591] (2) 216-8000
FAX: [591] (2) 216-8111','cc7befbec328b9330dcb4208b8aad28b6a5146124a39361bd2e2f8395842e711','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('beb7d18e71cd04b5bab7763b11bad619d5beace4833a819c7b953697a886dfb6',2007,'BA','Bosnia and Herzegovina','people-and-society',252,'$24.8 billion
note: Bosnia has a large informal sector that could also be as much
as 50% of official GDP (2006 est.)
1.35% (2006 est.)
5.3% (2006 est.)
$5,500 (2006 est.)
chief of mission: Ambassador Douglas L.
McELHANEY
embassy: Alipasina 43, 71000 Sarajevo
mailing address: use street address
telephone: [387] (33) 445-700
FAX: [387] (33) 659-722
branch office(s): Banja Luka, Mostar','e8001e59278f83c816a3fc5567b837dffe93a16dafc0a94707d614e24fcbfc9a','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5da52ef931e1ff0985e358ef1771246975e7add5e5452b4f575de3e4c1b105f7',2007,'BW','Botswana','people-and-society',253,'$18.72 billion (2006 est.)
-0.04% (2006 est.)
4.7% (2006 est.)
$11,400 (2006 est.)
chief of mission: Ambassador Katherine H. CANAVAN
embassy: address NA, Gaborone
mailing address: Embassy Enclave, P. O. Box 90, Gaborone
telephone: [267] 353982
FAX: [267] 312782','2a24ba6e6db0909d871458274e440e80019a677eb090a7a1714510760c25739d','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f77fc1323a4c6570aa0ad4ff890d025a83cfdc7619b10345ceee4c00d252fb4f',2007,'BR','Brazil','people-and-society',254,'$1.616 trillion (2006 est.)
British Virgin Islands
$853.4 million (2004 est.)
Brunei
$6.842 billion (2003 est.)
1.04% (2006 est.)
British Virgin Islands
1.97% (2006 est.)
Brunei
1.87% (2006 est.)
3.1% (2006 est.)
British Virgin Islands
1% (2002 est.)
Brunei
1.7% (2004 est.)
$8,600 (2006 est.)
British Virgin Islands
$38,500 (2004 est.)
Brunei
$23,600 (2003 est.)
chief of mission: Ambassador Clifford M. SOBEL
embassy: Avenida das Nacoes, Quadra 801, Lote 3, Distrito Federal
Cep 70403-900, Brasilia
mailing address: Unit 3500, APO AA 34030
telephone: [55] (61) 3312-7000
FAX: [55] (61) 3225-9136
consulate(s) general: Rio de Janeiro, Sao Paulo
consulate(s): Recife','af1d31829d7f34fd1525872c31ba430645ed0b9fe7f6f09e513828675f2b8ac8','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bb80e59498664dc48ff9927badb9bcaa8af6c563afa83e7a49cc877582ce0e8',2007,'BG','Bulgaria','people-and-society',255,'$77.13 billion (2006 est.)
-0.86% (2006 est.)
5.5% (2006 est.)
$10,400 (2006 est.)
chief of mission: Ambassador John Ross BEYRLE
embassy: 16 Kozyak Street, Sofia 1407
mailing address: American Embassy Sofia, US Department of State,
5740 Sofia Place, Washington, DC 20521-5740
telephone: [359] (2) 937-5100
FAX: [359] (2) 937-5320','d7e829af2334454630895e7c51d01c2b1b7d8ddb2a4777f24bdfc0b56e7c0a0d','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49568c50575a3ad2f6ab236ecc0d1de61259b685a16602b019fa12ab7281b176',2007,'BF','Burkina Faso','people-and-society',256,'$17.87 billion (2006 est.)
Burma
$83.84 billion (2006 est.)
3% (2006 est.)
Burma
0.81% (2006 est.)
5.2% (2006 est.)
Burma
2.6% (2006 est.)
$1,300 (2006 est.)
Burma
$1,800 (2006 est.)
chief of mission: Ambassador Jeanine E. JACKSON
embassy: 602 Avenue Raoul Follereau, Koulouba, Secteur 4
mailing address: 01 B. P. 35, Ouagadougou 01; pouch mail - US
Department of State, 2440 Ouagadougou Place, Washington, DC
20521-2440
telephone: [226] 50-30-67-23
FAX: [226] 50-30-38-90, 50-31-23-68
Burma
chief of mission: Ambassador (vacant); Charge d''Affaires Shari
VILLAROSA
embassy: 581 Merchant Street, Rangoon (GPO 521)
mailing address: Box B, APO AP 96546
telephone: [95] (1) 379-880, 379-881
FAX: [95] (1) 256-018','7bebd94b83e47952649a2232baa4bc1400dd03ad066366f60601317bcc6d6a72','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67b74326da5260e42f3fb939c42543237469a7018f20eb351a6f0b5dfd284a91',2007,'BI','Burundi','people-and-society',257,'$5.744 billion (2006 est.)
3.7% (2006 est.)
5% (2006 est.)
$700 (2006 est.)
chief of mission: Ambassador Patricia Newton MOLLER
embassy: Avenue des Etats-Unis, Bujumbura
mailing address: B. P. 1720, Bujumbura
telephone: [257] 223454
FAX: [257] 222926','36a6e352944d91428fe8f409915bbe0c1c51ab4a71f78965a85491e79d7faefe','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3e77a0fa6145f84f8369d4630013c58efaaa9f2034d2a9318a81025a93f8eac',2007,'KH','Cambodia','people-and-society',258,'$36.78 billion (2006 est.)
1.78% (2006 est.)
5.8% (2006 est.)
$2,600 (2006 est.)
chief of mission: Ambassador Joseph A. MUSSOMELI
embassy: #1, Street 96, Sangkat Wat Phnom, Khan Daun Penh, Phnom Penh
mailing address: Box P, APO AP 96546
telephone: [855] (23) 728-000
FAX: [855] (23) 728-600','a1cece76e046fef21d942d77fbbd8fa2aad148434b3e61b564f92ba26b16f41a','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8c90143b8abb7b02ffd91103ed83782fcf43fe730d56b9cf10e197b108839ab',2007,'CM','Cameroon','people-and-society',259,'$42.2 billion (2006 est.)
2.04% (2006 est.)
4.1% (2006 est.)
$2,400 (2006 est.)
chief of mission: Ambassador Niels MARQUARDT
embassy: Rue Nachtigal, Yaounde
mailing address: P. O. Box 817, Yaounde; pouch: American Embassy, US
Department of State, Washington, DC 20521-2520
telephone: [237] 220 15 00; Consular: [237] 220 16 03
FAX: [237] 220 16 20; Consular FAX: [237] 220 17 52
branch office(s): Douala','35d95fe819181d95577d4a471c9584f24c6d9fe28168f1d61e52c0ccd9a205c2','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2711a660fcd6b08cc2af5fd839730e666ddd728c1f770a5b0ab8bec75b1244ce',2007,'CA','Canada','people-and-society',260,'$1.165 trillion (2006 est.)
Cape Verde
$3.129 billion (2006 est.)
0.88% (2006 est.)
Cape Verde
0.64% (2006 est.)
2.8% (2006 est.)
Cape Verde
5.5% (2005 est.)
$35,200 (2006 est.)
Cape Verde
$6,000 (2006 est.)
chief of mission: Ambassador David H. WILKINS
embassy: 490 Sussex Drive, Ottawa, Ontario K1N 1G8
mailing address: P. O. Box 5000, Ogdensburgh, NY 13669-0430
telephone: [1] (613) 238-5335, 4470
FAX: [1] (613) 688-3082
consulate(s) general: Calgary, Halifax, Montreal, Quebec, Toronto,
Vancouver, Winnipeg
Cape Verde
chief of mission: Ambassador Roger D. PIERCE
embassy: Rua Abilio Macedo n6, Praia
mailing address: C. P. 201, Praia
telephone: [238] 2-60-89-00
FAX: [238] 2-61-13-55','b4dfd87e2ccbcaf94dc4d616a5ce06aaf9502a28c725f7a232b45b1b930bd186','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e0df261e060c5d230cc1e7dc905768ada4a3dfbf87ca0b7c0920d541bc6a6d5',2007,'KY','Cayman Islands','people-and-society',261,'$1.939 billion (2004 est.)
2.56% (2006 est.)
0.9% (2004 est.)
$43,800 (2004 est.)
overseas territory of the UK
none (overseas territory of the UK)','85a92f3eba4b353adfb33dd06e48e2cf2646af240dce824f7728f4f1e717a7fe','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9a2c8f5b4f32de681d6d3893fb234dc46e9f3ca137da382890b32993112ff159',2007,'CF','Central African Republic','people-and-society',262,'$4.913 billion (2006 est.)
1.53% (2006 est.)
3% (2006 est.)
$1,100 (2006 est.)
chief of mission: Ambassador (vacant);
Charge d''Affaires James PANOS
embassy: Avenue David Dacko, Bangui
mailing address: B. P. 924, Bangui
telephone: [236] 61 02 00
FAX: [236] 61 44 94
note: the embassy is currently operating with a minimal staff','b933ac381f1c611334eb54e85b08188175f3241f3e37d86d8242be749e7218cd','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('283b8b080cdab794563fa44899e84393d58da6af4a9dd2e993aded12edc4ed4c',2007,'TD','Chad','people-and-society',263,'$15.26 billion (2006 est.)
2.93% (2006 est.)
7% (2006 est.)
$1,500 (2006 est.)
chief of mission: Ambassador Marc M. WALL
embassy: Avenue Felix Eboue, N''Djamena
mailing address: B. P. 413, N''Djamena
telephone: [235] 516-211
FAX: [235] 515-654','c27676a6205e05c4ca2ad783df66806fca8ed92e197e8fd1e78c87066e633ab4','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b699f8925ee4c6a9a5ebeaaf18a26b1c42cf3c904cbd447fa90751b800812648',2007,'CL','Chile','people-and-society',264,'$203 billion (2006 est.)
0.94% (2006 est.)
4.8% (2006 est.)
$12,600 (2006 est.)
chief of mission: Ambassador Craig A. KELLY
embassy: Avenida Andres Bello 2800, Las Condes, Santiago
mailing address: APO AA 34033
telephone: [56] (2) 232-2600
FAX: [56] (2) 330-3710','5abe58a28e5fbd029c71b9d45758c432ad311439266643396b2a4ff956eab581','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a860e05b35114b40d1d213c2e35e0c7c2032ed52568672e08f82e95126f06123',2007,'CN','China','people-and-society',265,'$10 trillion (2006 est.)
0.59% (2006 est.)
10.5% (official data) (2006 est.)
$7,600 (2006 est.)
chief of mission: Ambassador Clark T. RANDT, Jr.
embassy: Xiu Shui Bei Jie 3, 100600 Beijing
mailing address: PSC 461, Box 50, FPO AP 96521-0002
telephone: [86] (10) 6532-3831
FAX: [86] (10) 6532-3178
consulate(s) general: Chengdu, Guangzhou, Hong Kong and Macau,
Shanghai, Shenyang','3e808c4fd63d2c17aa6dbd12100dd48598ad7f52d5d9741a3f3081d91f44b7cf','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5928440a2a5c59440aeec3f2ed905e190a3e1ef2b428b98209526ff2f12ac660',2007,'CX','Christmas Island','people-and-society',266,'$NA
0% (2006 est.)
non-self governing territory of Australia;
administered by the Australian Department of Transport and Regional
Services
Clipperton Island
possession of France; administered by France from
French Polynesia by a high commissioner of the Republic
none (territory of Australia)','276f3b61b0e5f7ceed2b09329201a980574c0cfce0bba6084b6ebc35b1863a9a','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcf555bebf6aa7ff045a2240d036e82f0d002fa0a7d897ab3248ca2f4c98c2a9',2007,'CC','Cocos (Keeling) Islands','people-and-society',267,'$NA
0% (2006 est.)
non-self governing territory of Australia;
administered from Canberra by the Australian Department of Transport
and Regional Services
none (territory of Australia)','92491f61374fb4b1f395d31b15fff39f38207d61f1524b12038d2d716707c0c3','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03b5ac77eeb7e2eb71167dff04f7d0ac5f7047e56079eabbc4d3b9b06f7f0f09',2007,'CO','Colombia','people-and-society',268,'$366.7 billion (2006 est.)
1.46% (2006 est.)
5.4% (2006 est.)
$8,400 (2006 est.)
chief of mission: Ambassador William B. WOOD
embassy: Calle 22D-BIS, numbers 47-51, Apartado Aereo 3831
mailing address: Carrera 45 #22D-45, Bogota, D.C., APO AA 34038
telephone: [57] (1) 315-0811
FAX: [57] (1) 315-2197','5e7c83901132b989c62f3519682477fd70283a29a4a5a787e67b104a8efd2d45','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2455e67f7c4da1ee488e08a9ed08991037ed375739c3f22ce69ae16fee7c7acd',2007,'KM','Comoros','people-and-society',269,'$441 million (2002 est.)
Congo, Democratic Republic of the
$44.6 billion (2006 est.)
Congo, Republic of the
$4.958 billion (2006 est.)
2.87% (2006 est.)
Congo, Democratic Republic of the
3.07% (2006 est.)
Congo, Republic of the
2.6% (2006 est.)
3% (2005 est.)
Congo, Democratic Republic of the
7.5% (2006 est.)
Congo, Republic of the
6% (2006 est.)
$600 (2005 est.)
Congo, Democratic Republic of the
$700 (2006 est.)
Congo, Republic of the
$1,300 (2006 est.)
the US does not have an embassy in Comoros; the ambassador
to Madagascar is accredited to Comoros
Congo, Democratic Republic of the
chief of mission: Ambassador Roger
MEECE
embassy: 310 Avenue des Aviateurs, Kinshasa
mailing address: Unit 31550, APO AE 09828
telephone: [243] (88) 43608
FAX: [243] (88) 43467
Congo, Republic of the
chief of mission: Ambassador Robert WEISBERG
embassy: NA
mailing address: NA
telephone: [243] (88) 43608
note: the embassy is temporarily collocated with the US Embassy in
the Democratic Republic of the Congo (US Embassy Kinshasa, 310
Avenue des Aviateurs, Kinshasa)','6c1863579b33f9b11cce5d51db7df6c576035a27a719ffbfe87ea0c18260acce','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f615dde6a2b80d29370ad2d7f94cb6d6e452723e9fbfadf318a26070c07a6676',2007,'CK','Cook Islands','people-and-society',270,'$183.2 million (2005 est.)
-1.2% between 1996-2001 (2001 census)
0.1% (2005 est.)
$9,100 (2005 est.)
self-governing in free association with New Zealand;
Cook Islands is fully responsible for internal affairs; New Zealand
retains responsibility for external affairs and defense, in
consultation with the Cook Islands
Coral Sea Islands
territory of Australia; administered from Canberra
by the Department of the Transport and Regional Services
Dhekelia
overseas territory of UK; administered by an administrator
who is also the Commander, British Forces Cyprus
Europa Island
possession of France; administered by the
Administrateur Superieur of the French Southern and Antarctic Lands
Falkland Islands (Islas Malvinas)
overseas territory of the UK; also
claimed by Argentina
none (self-governing in free association with New
Zealand)
Coral Sea Islands
none (territory of Australia)','58e89c4d2f098a3898dc7fdc9d5106f0bbf5a7c572076900f89fd6221f158f48','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a61e3851ea855970dc8f7dee5ca5d5f9666fc06f7a5817a4a289c88f3349912e',2007,'CR','Costa Rica','people-and-society',271,'$48.77 billion (2006 est.)
Cote d''Ivoire
$28.47 billion (2006 est.)
1.45% (2006 est.)
Cote d''Ivoire
2.03% (2006 est.)
4.7% (2006 est.)
Cote d''Ivoire
1.2% (2006 est.)
$12,000 (2006 est.)
Cote d''Ivoire
$1,600 (2006 est.)
chief of mission: Ambassador Mark LANGDALE
embassy: Calle 120 Avenida O, Pavas, San Jose
mailing address: APO AA 34020
telephone: [506] 519-2000
FAX: [506] 519-2305
Cote d''Ivoire
chief of mission: Ambassador Aubrey HOOKS
embassy: Riviera Golf 01, Abidjan
mailing address: B. P. 1866, Abidjan 01
telephone: [225] 20 21 09 79
FAX: [225] 20 22 32 59','38c1470762fde7c56161a0dd73ba33a2bd6fc02e7e8d4cba8c9f87fb1e31c9f9','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0beac6454bf3d175f04621292cf1e2d6be5bda1e63c9997ef22cfbd792caa04',2007,'HR','Croatia','people-and-society',272,'$59.41 billion (2006 est.)
-0.03% (2006 est.)
4.4% (2006 est.)
$13,200 (2006 est.)
chief of mission: Ambassador Robert A. BRADTKE
embassy: 2 Thomas Jefferson Street, 10010 Zagreb
mailing address: use street address
telephone: [385] (1) 661-2200
FAX: [385] (1) 661-2373','dc0510ff9f46115289e815795868e3b0b9ec57fdd5958e25ad52ab2617b38ad4','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c194f2a2d1b54f502a962b0f19b11cdba1d07c7a4dfd5ad08f9d4d6e35fbb0a',2007,'CU','Cuba','people-and-society',273,'$44.54 billion (2006 est.)
0.31% (2006 est.)
7.5% (2006 est.)
$3,900 (2006 est.)
none; note - the US has an Interests Section in the Swiss
Embassy, headed by Principal Officer Michael E. PARMLY; address:
USINT, Swiss Embassy, Calzada between L and M Streets, Vedado,
Havana; telephone: [53] (7) 833-3551 through 3559 (operator
assistance required); FAX: [53] (7) 833-3700; protecting power in
Cuba is Switzerland','27afeddf0d9efc8d0848556e087f2a4ea3492e1e092ba2a17e9ef8321ffddac6','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c4d14872ddf3fb3f1b2004fa97dc4266d796a326da8aef7107de164bde7f9f3',2007,'CY','Cyprus','people-and-society',274,'Republic of Cyprus: $17.79 billion; north Cyprus: $4.54
billion (2006 est.)
Czech Republic
$221.4 billion (2006 est.)
0.53% (2006 est.)
Czech Republic
-0.06% (2006 est.)
Republic of Cyprus: 3.7%; north Cyprus: 10.6% (2006 est.)
Czech Republic
6.2% (2006 est.)
Republic of Cyprus: $22,700 (2005 est.); north Cyprus: $7,135
(2004 est.) (2006 est.)
Czech Republic
$21,600 (2006 est.)
chief of mission: Ambassador Ronald L. SCHLICHER
embassy: corner of Metochiou and Ploutarchou Streets, 2407 Engomi,
Nicosia
mailing address: P. O. Box 24536, 1385 Nicosia
telephone: [357] (22) 393939
FAX: [357] (22) 780944
Czech Republic
chief of mission: Ambassador Richard W. GRABER
embassy: Trziste 15, 11801 Prague 1
mailing address: use embassy street address
telephone: [420] 257 022 000
FAX: [420] 257 022 809','2f6d4e7f3824019b09ecc4e31fa6a78ceff22a7ac91dc941ff1ba146bb4bb7dd','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d085b19d819ce14cd6aa9518df8d44e6cd1d7ddd6a51b583987a13c7f68af66a',2007,'DK','Denmark','people-and-society',275,'$198.5 billion (2006 est.)
0.33% (2006 est.)
3% (2006 est.)
$37,000 (2006 est.)
chief of mission: Ambassador James P. CAIN
embassy: Dag Hammarskjolds Alle 24, 2100 Copenhagen
mailing address: PSC 73, APO AE 09716
telephone: [45] 33 41 71 00
FAX: [45] 35 43 02 23
Dhekelia
none (overseas territory of the UK)','ac021e850f3c718921709d86d199bd7c5669a1415f298b7c949e3699b1131396','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b01627deb39c21b3eb80894ab11358105137ae7cb83d68de8810bf20b39320b1',2007,'DJ','Djibouti','people-and-society',276,'$619 million (2002 est.)
2.02% (2006 est.)
3.2% (2005 est.)
$1,000 (2005 est.)
chief of mission: Ambassador W. Stuart SYMINGTON
embassy: Plateau du Serpent, Boulevard Marechal Joffre, Djibouti
mailing address: B. P. 185, Djibouti
telephone: [253] 35 39 95
FAX: [253] 35 39 40','03294eeb248fd51c0a9e5063435535c67f0b43411a91490f20b279ec4346475f','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a59086fd2bea9108d0830c48360e1c64a69a70f2bee0cbfe0b96c2b696d96ad9',2007,'DM','Dominica','people-and-society',277,'$384 million (2003 est.)
-0.08% (2006 est.)
3.1% (2005 est.)
$3,800 (2005 est.)
the US does not have an embassy in Dominica; the US
Ambassador to Barbados is accredited to Dominica','a5e062100d49e06479b550c585133a233769eff31d501a1fb5c87dfabc9c4f23','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8205a55ce337085d6bfaa42510924e388715f9e4b759228ac0c66604bd41650',2007,'DO','Dominican Republic','people-and-society',278,'$73.74 billion (2006 est.)
East Timor
$370 million (2004 est.)
1.47% (2006 est.)
East Timor
2.08% (2006 est.)
7.2% (2006 est.)
East Timor
1.8% (2005 est.)
$8,000 (2006 est.)
East Timor
$800 (2005 est.)
chief of mission: Ambassador Hans H. HERTELL
embassy: corner of Calle Cesar Nicolas Penson and Calle Leopoldo
Navarro, Santo Domingo
mailing address: Unit 5500, APO AA 34041-5500
telephone: [1] (809) 221-2171
FAX: [1] (809) 686-7437
East Timor
chief of mission: Ambassador (vacant); Charge d''Affaires
William Gary GRAY
embassy: Avenida de Portugal, Praia dos Conqueiros, Dili
mailing address: US Department of State, 8250 Dili Place,
Washington, DC 20521-8250
telephone: (670) 332-4684
FAX: (670) 331-3206','08e4882303f99a9d52e2a15a365d24a46dd002b569d3e51d071b40aa99ef4cf8','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ddd28a3f5da18412710105343d462bcc76a470ccd93f328d4a70e076f67f5e15',2007,'EC','Ecuador','people-and-society',279,'$60.48 billion (2006 est.)
1.5% (2006 est.)
3.6% (2006 est.)
$4,500 (2006 est.)
chief of mission: Ambassador Linda L. JEWELL
embassy: Avenida 12 de Octubre y Avenida Patria, Quito
mailing address: APO AA 34039
telephone: [593] (2) 256-2890
FAX: [593] (2) 250-2052
consulate(s) general: Guayaquil','b94789823562d195e40e35841b2cc53a3604e2263b01836aabd72763431d550c','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fd152de759e974b1e72e30165c5ef86cdd47ec01dff313510ddf9e6971c19673',2007,'EG','Egypt','people-and-society',280,'$328.1 billion (2006 est.)
1.75% (2006 est.)
5.7% (2006 est.)
$4,200 (2006 est.)
chief of mission: Ambassador Francis J. RICCIARDONE, Jr.
embassy: 8 Kamal El Din Salah St., Garden City, Cairo
mailing address: Unit 64900, Box 15, APO AE 09839-4900
telephone: [20] (2) 797-3300
FAX: [20] (2) 797-3200','1a158973753b4c6d48800ccf35128842fa52c016febf34989a80479ac2fd22a3','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03e75e463d3eb536e63a4a0489c5a660fc94d203c235d4e9b66e0856c8678b37',2007,'SV','El Salvador','people-and-society',281,'$33.2 billion (2006 est.)
1.72% (2006 est.)
4% (2006 est.)
$4,900 (2006 est.)
chief of mission: Ambassador H. Douglas BARCLAY
embassy: Final Boulevard Santa Elena Sur, Antiguo Cuscatlan, La
Libertad, San Salvador
mailing address: Unit 3116, APO AA 34023
telephone: [503] 2278-4444
FAX: [503] 2278-5522','c2b2a1ffbeff539f9b5d2464a5f0083836017b7749c6efcad92543c4116e7853','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('24925b02f1bda8c658468f4dfb7f03c304ea3c3d1c0883f25bb0c485d4831558',2007,'GQ','Equatorial Guinea','people-and-society',282,'$25.69 billion (2005 est.)
2.05% (2006 est.)
18.6% (2005 est.)
$50,200 (2005 est.)
chief of mission: Ambassador Donald C. JOHNSON
embassy: adjacent to the golf course at the base of Mont Febe; note
- relocated embassy is opened for limited functions; inquiries
should continue to be directed to the US Embassy in Yaounde, Cameroon
mailing address: B.P. 817, Yaounde, Cameroon; US Embassy Yaounde, US
Department of State, Washington, DC 20521-2520
telephone: [237] 220 15 00
FAX: [237] 220 16 20','52688a72bb619edf75ea06a31f093df5c4f7b3cedf28b1f2be8f8b8b9eec013f','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d30a13509c658a35e7c3cee5d579c34d5c47335dc65b0fc25e4a5f16fc50a328',2007,'ER','Eritrea','people-and-society',283,'$4.471 billion (2005 est.)
2.47% (2006 est.)
2% (2005 est.)
$1,000 (2005 est.)
chief of mission: Ambassador Scott H. DELISI
embassy: 179 Alaa Street, Asmara
mailing address: P. O. Box 211, Asmara
telephone: [291] (1) 120004
FAX: [291] (1) 127584','a1e6c5e77ecd4e1a3bc77c0a0aa924f6229df62b0f45b224045abef791308d7f','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1a85311a5fa21c79a4f6ce1b9d9008a318e8de3a6631c57ead167f96982e183d',2007,'EE','Estonia','people-and-society',284,'$26 billion (2006 est.)
-0.64% (2006 est.)
9.2% (2006 est.)
$19,600 (2006 est.)
chief of mission: Ambassador (vacant); Charge d''Affaires
Jeffrey GOLDSTEIN
embassy: Kentmanni 20, 15099 Tallinn
mailing address: use embassy street address
telephone: [372] 668-8100
FAX: [372] 668-8134','33df48312596e480460ceed38e727ea873197fbdfd28d3e468e52fc58a8881c1','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5ed9ad422c2cadc83175fea558849e0fc2330144f0cde56155a070ee9273e80',2007,'ET','Ethiopia','people-and-society',285,'$71.63 billion (2006 est.)
European Union
$12.82 trillion (2006 est.)
Falkland Islands (Islas Malvinas)
$75 million (2002 est.)
2.31% (2006 est.)
European Union
0.15% (2006 est.)
Falkland Islands (Islas Malvinas)
2.44% (2006 est.)
8.5% (2006 est.)
European Union
2.8% (2006 est.)
Falkland Islands (Islas Malvinas)
NA%
$1,000 (2006 est.)
European Union
$29,300 (2006 est.)
Falkland Islands (Islas Malvinas)
$25,000 (2002 est.)
chief of mission: Ambassador Donald Y. YAMAMOTO
embassy: Entoto Street, Addis Ababa
mailing address: P. O. Box 1014, Addis Ababa
telephone: [251] (1) 517-4000
FAX: [251] (1) 517-4888
European Union
chief of mission: Ambassador C. Boyden GRAY
embassy: 13 Zinnerstraat/Rue Zinner, B-1000 Brussels
mailing address: same as above
telephone: [32] (2) 508-2222
FAX: [32] (2) 512-5720
Falkland Islands (Islas Malvinas)
none (overseas territory of the
UK; also claimed by Argentina)','e0bc03c6a4af93199c89322380cf8ea5a8a67e80975bbea0bc90dad5239f3210','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f815b6ffe5f4379aedb6f817d3be1bb31dcf36c341845239738380a8afab8b1b',2007,'FO','Faroe Islands','people-and-society',286,'$1 billion (2001 est.)
0.58% (2006 est.)
10% (2001 est.)
$31,000 (2001 est.)
part of the Kingdom of Denmark; self-governing
overseas administrative division of Denmark since 1948
none (self-governing overseas administrative division
of Denmark)','b5a4143c6f0ae4b06953631c4ae26d80bf80cda42a38131332ffb663d979b792','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ccd6388101fdad57c0de4fcc915c6aa34afd070fe32fae6c2b8f20a83f8e0df8',2007,'FJ','Fiji','people-and-society',287,'$5.504 billion (2006 est.)
1.4% (2006 est.)
2.7% (2006 est.)
$6,100 (2006 est.)
chief of mission: Ambassador Larry Miles DINGER
embassy: 31 Loftus Street, Suva
mailing address: P. O. Box 218, Suva
telephone: [679] 331-4466
FAX: [679] 330-0081','375dcd863b0684cc3bf3ac58feacd05386a74b077e1e037db70ead3a5f4a8a97','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('094f047198896ae66586c003e81a46a09f376eddad41e25392a01dea27f574ce',2007,'FI','Finland','people-and-society',288,'$171.7 billion (2006 est.)
0.14% (2006 est.)
4.9% (2006 est.)
$32,800 (2006 est.)
chief of mission: Ambassador Marilyn WARE
embassy: Itainen Puistotie 14B, 00140 Helsinki
mailing address: APO AE 09723
telephone: [358] (9) 616250
FAX: [358] (9) 6162 5800','6284ec2f71cfdfb969b47de5cc3faeca3911085fe4ab73f4e0a129ee94a0bed8','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd8d5a621346d190a7d641255f4d81481944fa3510c549e9c42857da8751ce34',2007,'FR','France','people-and-society',289,'$1.871 trillion (2006 est.)
0.35% (2006 est.)
2.3% (2006 est.)
$30,100 (2006 est.)
chief of mission: Ambassador Craig R. STAPLETON
embassy: 2 Avenue Gabriel, 75382 Paris Cedex 08
mailing address: PSC 116, APO AE 09777
telephone: [33] (1) 43-12-22-22
FAX: [33] (1) 42 66 97 83
consulate(s) general: Marseille, Strasbourg','6cd17b61c692917ad6d130050919c156bc04995bcd0af6aa233a9dded7534f06','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f251af6364b270e95be36156b42ac48e5721e6075a2d40d19f38c203eef5670',2007,'PF','French Polynesia','people-and-society',290,'$4.58 billion (2003 est.)
1.48% (2006 est.)
NA% (2001 est.)
$17,500 (2003 est.)
overseas lands of France; overseas territory of
France from 1946-2004
French Southern and Antarctic Lands
overseas territory of France
since 1955; administered from Paris by Administrateur Superieur
Michel CHAMPON (since 20 December 2004), assisted by Secretary
General Jean-Yves HERMOSO (since NA)
none (overseas lands of France)
French Southern and Antarctic Lands
none (overseas territory of
France)','9548c411df1141f5989769708dfbf9c556aa96e5f083cab99eb9d7f3aa974ab4','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('efb3f8647d7071c26d85386d4bc81d9358a2af9fe791eb372304ec6dc95d06e6',2007,'GA','Gabon','people-and-society',291,'$10.21 billion (2006 est.)
Gambia, The
$3.25 billion (2006 est.)
Gaza Strip
$5.327 billion (2005 est.)
2.13% (2006 est.)
Gambia, The
2.84% (2006 est.)
Gaza Strip
3.71% (2006 est.)
2.8% (2006 est.)
Gambia, The
5% (2006 est.)
Gaza Strip
4.9% (2005 est.)
$7,200 (2006 est.)
Gambia, The
$2,000 (2006 est.)
Gaza Strip
$1,500 (2003 est.)
chief of mission: Ambassador Barrie R. WALKLEY
embassy: Boulevard du Bord de Mer, Libreville
mailing address: Centre Ville, B. P. 4000, Libreville
telephone: [241] 76 20 03 through 76 20 04, after hours - 74 34 92
FAX: [241] 74 55 07
Gambia, The
chief of mission: Ambassador Joseph D. STAFFORD, III
embassy: Kairaba Avenue, Fajara, Banjul
mailing address: P. M. B. No. 19, Banjul
telephone: [220] 439-2856, 437-6169, 437-6170
FAX: [220] 439-2475','99827c22dc0306f33967d507efb62ca0c2a5a09555a094344e69f451d90139c1','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7d4983209804cee7d24722a86ead0f9bab01b9d0d140ef53ad9f0f201a4cd1f',2007,'GE','Georgia','people-and-society',292,'$17.79 billion (2006 est.)
-0.34% (2006 est.)
8.8% (2006 est.)
$3,800 (2006 est.)
chief of mission: Ambassador John F. TEFFT
embassy: 11 George Balanchine St., T''bilisi 0131
mailing address: 7060 T''bilisi Place, Washington, DC 20521-7060
telephone: [995] (32) 27-70-00
FAX: [995] (32) 53-23-10','d117832f182e1dfc7f91c716252b892460b13d991ca17d4aa2a41e13c1ee14c5','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3de8165b58bb1ce96c402aaf8ac2b72b8758238837c59f4c5cf461bce354e131',2007,'DE','Germany','people-and-society',293,'$2.585 trillion (2006 est.)
-0.02% (2006 est.)
2.2% (2006 est.)
$31,400 (2006 est.)
chief of mission: Ambassador William R. TIMKEN, Jr.
embassy: Neustaedtische Kirchstrasse 4-5, 10117 Berlin; note - a new
embassy will be built near the Brandenburg Gate in Berlin; ground
was broken in October 2004 and completion is scheduled for 2008
mailing address: PSC 120, Box 1000, APO AE 09265
telephone: [49] (030) 8305-0
FAX: [49] (030) 8305-1215
consulate(s) general: Duesseldorf, Frankfurt am Main, Hamburg,
Leipzig, Munich','d2b9e6d8956a823120b07e5ba3fa93b087573bdfc8e5c60d175cdbb9a14c5e32','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e7c97531c783673ac728cee6402a0b8584d131b1b0cd496fce1f014bc013815',2007,'GH','Ghana','people-and-society',294,'$59.15 billion (2006 est.)
2.07% (2006 est.)
5.7% (2006 est.)
$2,600 (2006 est.)
chief of mission: Ambassador Pamela BRIDGEWATER
embassy: 6th and 10th Lanes, 798/1 Osu, Accra
mailing address: P. O. Box 194, Accra
telephone: [233] (21) 775-347, 775-348
FAX: [233] (21) 701-813','d654580a8d23c352fcca572eb43f8dc8e4450e38c25509970d891f7da9e4d5d9','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4a0c4075361591280e1b1190c11946428b055df3ab74fb0a67d9f001e813ec5',2007,'GI','Gibraltar','people-and-society',295,'$769 million (2000 est.)
0.14% (2006 est.)
NA%
$27,900 (2000 est.)
overseas territory of the UK
Glorioso Islands
possession of France; administered by the
Administrateur Superieur of the French Southern and Antarctic Lands
none (overseas territory of the UK)','76d3d9a1455d8f44e8f25f997b505cb806cda77940b114cf389190aa743f8b55','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eba550a8a37830a7204c2b58d0ccf954278eb2ef5e4ba78d6c5071c2d9b58383',2007,'GR','Greece','people-and-society',296,'$251.7 billion (2006 est.)
0.18% (2006 est.)
3.6% (2006 est.)
$23,500 (2006 est.)
chief of mission: Ambassador Charles P. RIES
embassy: 91 Vasilisis Sophias Avenue, 10160 Athens
mailing address: PSC 108, APO AE 09842-0108
telephone: [30] (210) 721-2951
FAX: [30] (210) 645-6282
consulate(s) general: Thessaloniki','7229e7d47c9d2e7aeee31616caf6c98863d4ee989880e12cef29d7e484543d4d','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6f2649bd8225ae85f23dbd7b63669a98eee080b83aa05cdc026139750cd196fd',2007,'GL','Greenland','people-and-society',297,'$1.1 billion (2001 est.)
-0.03% (2006 est.)
1.8% (2001 est.)
$20,000 (2001 est.)
part of the Kingdom of Denmark; self-governing overseas
administrative division of Denmark since 1979
none (self-governing overseas administrative division of
Denmark)','5e483b2f424582571fe2f52b8d7587fa668bf1aea5f168e2506d33fd9534a5a4','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bd0669a4a6e943d170d9e39d5d293a4c0cbc051a372bc11ae7d3fb33d66673fa',2007,'GD','Grenada','people-and-society',298,'$440 million (2002 est.)
0.26% (2006 est.)
0.9% (2005 est.)
$3,900 (2005 est.)
chief of mission: the US Ambassador to Barbados is
accredited to Grenada
embassy: Lance-aux-Epines Stretch, Saint George''s
mailing address: P. O. Box 54, Saint George''s
telephone: [1] (473) 444-1173 through 1176
FAX: [1] (473) 444-4820','8881de8696a155b7e8a65b88f32cd84f19aa65169f19ff0ca06917ae79cfae45','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48a32b685dd89df98c3e423100b488923222a0c6cd246fbb29f15c7fd0c9402a',2007,'GU','Guam','people-and-society',299,'$2.5 billion (2005 est.)
1.43% (2006 est.)
NA%
$15,000 (2005 est.)
organized, unincorporated territory of the US with policy
relations between Guam and the US under the jurisdiction of the
Office of Insular Affairs, US Department of the Interior
none (territory of the US)','384ebefba88f66532acfa166d7b5d89555ac2c88369ffd36a46b1e0661b897d4','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9b43f6e5d077759c55d97feb4c9debed00bd1f97dabbf2c7a153553949e75c7',2007,'GT','Guatemala','people-and-society',300,'$60.57 billion (2006 est.)
2.27% (2006 est.)
3.9% (2006 est.)
$4,900 (2006 est.)
chief of mission: Ambassador James M. DERHAM
embassy: 7-01 Avenida Reforma, Zone 10, Guatemala City
mailing address: APO AA 34024
telephone: [502] 2326-4000
FAX: [502] 2326-4654','ea92c2d51107d52750e37ce369e1aee2c8fb41470f1736a145eec9c37d6f0ab6','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('149932b89755c87f9d31e422a9328b1905ea4b39a387409d08c4878ad39fa3ec',2007,'GG','Guernsey','people-and-society',301,'$2.742 billion (2005)
0.26% (2006 est.)
3% (2005 est.)
$44,600 (2005)
British crown dependency
none (British crown dependency)','f4f633a9e26090287214d602758031c4b5ec4e72ad03982bd1e67726d1d4230f','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('973590ce991596159aabb2124a953936f0f609a0723aff56bfe29eeca31cf1d5',2007,'GN','Guinea','people-and-society',302,'$19.4 billion (2006 est.)
2.63% (2006 est.)
2% (2006 est.)
$2,000 (2006 est.)
chief of mission: Ambassador Jackson C. MCDONALD
embassy: Koloma, Conakry, east of Hamdallaye Circle
mailing address: B. P. 603, Transversale No. 2, Centre Administratif
de Koloma, Commune de Ratoma, Conakry
telephone: [224] 30-42-08-61
FAX: [224] 30-42-08-73','cb8e134d02a3c089cc22202cde18b0a19dd796053f5fb44ffd2563fa489dde2d','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('298090d2035e1c802b146a48ba26acb866963041e2c2f93c30c145a1008bbdc2',2007,'GW','Guinea-Bissau','people-and-society',303,'$1.244 billion (2006 est.)
2.07% (2006 est.)
2.9% (2006 est.)
$900 (2006 est.)
the US Embassy suspended operations on 14 June 1998 in
the midst of violent conflict between forces loyal to then President
VIEIRA and military-led junta; the US Ambassador to Senegal is
accredited to Guinea-Bissau','aeacaeb9cc0edee915607ce5d1dd8cc6e6b8dbdec41688aa9323e4324a67923a','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02db9ae0c2ca0915cdf7ece92c24dccd1859e0aa8db87302318e8d703ce43376',2007,'GY','Guyana','people-and-society',304,'$3.62 billion (2006 est.)
0.25% (2006 est.)
3.2% (2006 est.)
$4,700 (2006 est.)
chief of mission: Ambassador David M. ROBINSON
embassy: 100 Young and Duke Streets, Kingston, Georgetown
mailing address: P. O. Box 10507, Georgetown; US Embassy, 3170
Georgetown Place, Washington DC 20521-3170
telephone: [592] 225-4900 through 4909
FAX: [592] 225-8497','03e9e395eb0a826f8befe37e06713fc77e4343f7bfc9813f5891202698c680c7','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64ac2e73a9a3f9fb9f400c7c982119a45b8de231c3dec21458f9ebc9b0e6185a',2007,'HT','Haiti','people-and-society',305,'$14.56 billion (2006 est.)
Holy See (Vatican City)
$NA
2.3% (2006 est.)
Holy See (Vatican City)
0.01% (2006 est.)
1.8% (2006 est.)
$1,800 (2006 est.)
chief of mission: Ambassador Janet A. SANDERSON
embassy: 5 Harry S Truman Boulevard, Bicentenaire-Port-au-Prince
mailing address: P. O. Box 1761, Port-au-Prince
telephone: [509] 222-0200
FAX: [509] 223-9038','76f14f7ff0d7e18383bf85753c66af766b9eb0f4cb0bf76e0d3091f3b5bed7d4','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3bd1ab765ded0ed92b75e67e3a0cb90a273272e8940eb15e9c5d55fe585e51f2',2007,'HN','Honduras','people-and-society',306,'$22.13 billion (2006 est.)
2.16% (2006 est.)
5.2% (2006 est.)
$3,000 (2006 est.)
chief of mission: Ambassador Charles A. FORD
embassy: Avenida La Paz, Apartado Postal No. 3453, Tegucigalpa
mailing address: American Embassy, APO AA 34022, Tegucigalpa
telephone: [504] 236-9320, 238-5114
FAX: [504] 236-9037','af5a1ba30865ac901b59477cdd8dfc737c593ee18b57694610c220215ded105d','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('31d7dc980edc48fdaa4eb136100710b1e8a55b3d56c69fad766b17179c583d34',2007,'HK','Hong Kong','people-and-society',307,'$253.1 billion (2006 est.)
0.59% (2006 est.)
5.9% (2006 est.)
$36,500 (2006 est.)
special administrative region of China
Howland Island
unincorporated territory of the US; administered from
Washington, DC, by the Fish and Wildlife Service of the US
Department of the Interior as part of the National Wildlife Refuge
system
Iles Eparses
possessions of France; administered by the Senior
Administrator of the Territory of the French Southern and Antarctic
Lands (TAAF), resident in Reunion
chief of mission: Consul General James B. CUNNINGHAM
consulate(s) general: 26 Garden Road, Hong Kong
mailing address: PSC 461, Box 1, FPO AP 96521-0006
telephone: [852] 2523-9011
FAX: [852] 2845-1598','fd73e043dcfcc227c9dfdc4703ed0b3135fc3065738d4cf828d727dbc691984f','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9be2fc9e04a18b7f7b12d382aa6ac9ec9c10b2b623480429f6dc2bf253c51194',2007,'HU','Hungary','people-and-society',308,'$172.7 billion (2006 est.)
-0.25% (2006 est.)
3.8% (2006 est.)
$17,300 (2006 est.)
chief of mission: Ambassador April H. FOLEY
embassy: Szabadsag ter 12, H-1054 Budapest
mailing address: pouch: American Embassy Budapest, 5270 Budapest
Place, US Department of State, Washington, DC 20521-5270
telephone: [36] (1) 475-4400
FAX: [36] (1) 475-4764','648491a8e52733d3f0aae892f08f55389ae2373e7c03a066f37507066e76bbab','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f220651e2c34d4524755c1c6184abbd3fb8569893f08bc859ba6136f9ba9dd2',2007,'IS','Iceland','people-and-society',309,'$11.4 billion (2006 est.)
0.87% (2006 est.)
3.7% (2006 est.)
$38,100 (2006 est.)
chief of mission: Ambassador Carol VAN VOORST
embassy: Laufasvegur 21, 101 Reykjavik
mailing address: US Department of State, 5640 Reykjavik Place,
Washington, D.C. 20521-5640
telephone: [354] 562-9100
FAX: [354] 562-9118','50feaa27017ad50707df180b89b74752d6469fa8de69aa6c9897ee65e75a615e','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('151ee798677d0062296e5b7a8b955a2d5122346c423d1048cac2e179a6f6e2d4',2007,'IN','India','people-and-society',310,'$4.042 trillion (2006 est.)
1.38% (2006 est.)
8.5% (2006 est.)
$3,700 (2006 est.)
chief of mission: Ambassador David C. MULFORD
embassy: Shantipath, Chanakyapuri, New Delhi 110021
mailing address: use embassy street address
telephone: [91] (11) 2419-8000
FAX: [91] (11) 2419-0017
consulate(s) general: Chennai (Madras), Kolkata (Calcutta), Mumbai
(Bombay)','e2798c1724588a8dae7a1898d3cd7d322cfc9f0d2a27a0813479f301d05e4f84','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ad4016b8d5031915a979d687c15a2fc11a9cf029474a4e4a5b208e284ff696d',2007,'ID','Indonesia','people-and-society',311,'$935 billion (2006 est.)
Iran
$610.4 billion (2006 est.)
1.41% (2006 est.)
Iran
1.1% (2006 est.)
5.4% (2006 est.)
Iran
5% (2006 est.)
$3,800 (2006 est.)
Iran
$8,900 (2006 est.)
chief of mission: Ambassador B. Lynn PASCOE
embassy: Jalan 1 Medan Merdeka Selatan 4-5, Jakarta 10110
mailing address: Unit 8129, Box 1, FPO AP 96520
telephone: [62] (21) 3435-9000
FAX: [62] (21) 3435-9922
consulate(s) general: Surabaya
consulate(s): Medan; Denpasar (consular agency)
Iran
none; note - protecting power in Iran is Switzerland','c6a81aa1869d585cbe7015e83d887468159ee798f3db2fa55a5cb760a66f6584','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c75a065192af8a975ac3a8300a27b1d68620ed2700b3dbe50fb43b0def097983',2007,'IQ','Iraq','people-and-society',312,'$94.1 billion (2005 est.)
2.66% (2006 est.)
3.1% (2006 est.)
$1,900 (2006 est.)
chief of mission: Ambassador Zalmay KHALILZAD
embassy: Baghdad
mailing address: APO AE 09316
telephone: 00-1-240-553-0584 ext. 5340 or 5635; note - Consular
Section
FAX: NA','732e81e33064230cfe589995ae730909c0d46edc91982aa87f4f4d2f6ccef69d','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60d7d304e7f3ee14cae48c0b825a3883f93432104fc3b7064ff32432ce45a11b',2007,'IE','Ireland','people-and-society',313,'$177.2 billion (2006 est.)
1.15% (2006 est.)
5.2% (2006 est.)
$43,600 (2006 est.)
chief of mission: Ambassador Thomas C. FOLEY
embassy: 42 Elgin Road, Ballsbridge, Dublin 4
mailing address: use embassy street address
telephone: [353] (1) 668-8777
FAX: [353] (1) 668-9946','af1027ba234b2df63a04d2e81f75793a92705203a415cb63e3e260ae0c1c07b7','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09dd00ad0e5b2440493176059d1d6de71d18f808d6b10257baf045f48c416b36',2007,'IM','Isle of Man','people-and-society',314,'$2.113 billion (2003 est.)
0.52% (2006 est.)
6.3% (2003)
$27,800 (2003 est.)
British crown dependency
Jan Mayen
territory of Norway; since August 1994, administered from
Oslo through the county governor (fylkesmann) of Nordland; however,
authority has been delegated to a station commander of the Norwegian
Defense Communication Service
Jarvis Island
unincorporated territory of the US; administered from
Washington, DC, by the Fish and Wildlife Service of the US
Department of the Interior as part of the National Wildlife Refuge
system
none (British crown dependency)','82a5306d0a631cd0ac402338c0e116ba4eef641dbed6e4aec8e969c741af4c0f','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f43119ee471a92b26a921f7b79c27e4a4fcf5bc6a12d9af5fe86284e7641b9f1',2007,'IL','Israel','people-and-society',315,'$166.3 billion (2006 est.)
1.18% (2006 est.)
4.8% (2006 est.)
$26,200 (2006 est.)
chief of mission: Ambassador Richard H. JONES
embassy: 71 Hayarkon Street, Tel Aviv 63903
mailing address: PSC 98, Box 29, APO AE 09830
telephone: [972] (3) 519-7575
FAX: [972] (3) 516-4390
consulate(s) general: Jerusalem; note - an independent US mission,
established in 1928, whose members are not accredited to a foreign','4edc017ff94dc50e0d0b77bececdfa5ae941173df9f95494d8a31b81914bcc7b','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae8a15f95cf751f8a2de6979ff50030386ca4b8681bf7014f0dd51bd9b4692c7',2007,'IT','Italy','people-and-society',316,'$1.727 trillion (2006 est.)
0.04% (2006 est.)
1.6% (2006 est.)
$29,700 (2006 est.)','c5b28bd0e3b24bf203c58478fec1ccbf9767a99bcc3a1c38d317ba3d3843962c','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c038bd473a93b6fcad1b9a4ec92aee4a9b4db56553e970536571042397fe7d0',2007,'JP','Japan','people-and-society',317,'$4.22 trillion (2006 est.)
0.02% (2006 est.)
2.8% (2006 est.)
$33,100 (2006 est.)','fc0358a02f24ef3bcdd9cc585105f8a8eb91293751c88141b014b6c8b2e1014e','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fee1acdcd257ce65b84e25f2e3a7b1813ab4a0ec159a8eaf1951da3d7d2917ed',2007,'JE','Jersey','people-and-society',318,'$3.6 billion (2003 est.)
0.28% (2006 est.)
NA%
$40,000 (2003 est.)
British crown dependency
Johnston Atoll
unincorporated territory of the US; administered from
Honolulu, HI, by Pacific Air Forces, Hickam Air Force Base, and the
Fish and Wildlife Service of the US Department of the Interior as
part of the National Wildlife Refuge system
Juan de Nova Island
possession of France; administered by the
Administrateur Superieur of the French Southern and Antarctic Lands
Kingman Reef
unincorporated territory of the US; administered from
Washington, DC, by the US Fish and Wildlife Service of the
Department of the Interior
note: on 1 September 2000, the Department of the Interior accepted
restoration of its administrative jurisdiction over Kingman Reef
from the Department of the Navy; Executive Order 3223 signed 18
January 2001 established Kingman Reef National Wildlife Refuge to be
administered by the Director, US Fish and Wildlife Service; this
refuge is managed to protect the terrestrial and aquatic wildlife of
Kingman Reef out to the 12-nautical-mile territorial sea limit
Macau
special administrative region of China','0aa8d33dbe82184edb37cb9cd05438452a5e8817370a6386f1061a108bcd8e6b','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('201f67ff0a1338b20cd91bd386058621cd408831671077346d88d0f7c1686946',2007,'JO','Jordan','people-and-society',319,'$28.89 billion (2006 est.)
2.49% (2006 est.)
4.6% (2006 est.)
$4,900 (2006 est.)','e4390f77155199f54a1492cad1f0b8c0b00ddf61e05494f8385906d0dfe7b463','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77c51f9b213a8b7e60aa5176453bcfb16f5b60748cbe83db0332a77da52bf68c',2007,'KZ','Kazakhstan','people-and-society',320,'$138.7 billion (2006 est.)
0.33% (2006 est.)
8.5% (2006 est.)
$9,100 (2006 est.)','ec6953e3f251f81f44a94f90b7ba037c8e1a16b3fd50c8110d44b084f51263d6','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fed3b24354b828a4fee69bcd54c758ee6344872d0fba0c112f80ec71f0f2d994',2007,'KE','Kenya','people-and-society',321,'$40.77 billion (2006 est.)
2.57% (2006 est.)
5.5% (2006 est.)
$1,200 (2006 est.)','d92ec8835c506bc8c01e0d17e6b7285ac1f353343b2b0ef941eaa13d81312c3e','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c4413a77cdcc6f1d4a927c64968303e765dd939a4ab368235114fae059cf2d0',2007,'KI','Kiribati','people-and-society',322,'$206.4 million (2004 est.)
Korea, North
$40 billion
note: North Korea does not publish any reliable National Income
Accounts data; the datum shown here is derived from purchasing power
parity (PPP) GDP estimates for North Korea that were made by Angus
Maddison in a study conducted for the OECD; his figure for 1999 was
extrapolated to 2005 using estimated real growth rates for North
Korea''s GDP and an inflation factor based on the US GDP deflator;
the result was rounded to the nearest $10 billion (2006 est.)
Korea, South
$1.18 trillion (2006 est.)
2.24% (2006 est.)
Korea, North
0.84% (2006 est.)
Korea, South
0.42% (2006 est.)
0.3% (2005)
Korea, North
1% (2006 est.)
Korea, South
5.1% (2006 est.)
$2,700 (2004 est.)
Korea, North
$1,800 (2006 est.)
Korea, South
$24,200 (2006 est.)','61ef40193800f6d42cce3cfe8331a4a00c32fb43973ccd5b2fd61802ee53dae8','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69bdb74bbf3f466858a844c0ccc35158aea82b04730710e890101f9de385fdf7',2007,'KW','Kuwait','people-and-society',323,'$52.17 billion (2006 est.)
3.52%
note: this rate reflects a return to pre-Gulf crisis immigration of
expatriates (2006 est.)
8% (2006 est.)
$21,600 (2006 est.)','4c1d0342907ee308aa9b247cdd8b8f76281df2da658ed8b475f318e8899aa320','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca405abf002cf1682a435202bf3d79525f1c073203c3acff4396bdb165d9932d',2007,'KG','Kyrgyzstan','people-and-society',324,'$10.49 billion (2006 est.)
Laos
$13.43 billion (2006 est.)
1.32% (2006 est.)
Laos
2.39% (2006 est.)
2% (2006 est.)
Laos
7.2% (2006 est.)
$2,000 (2006 est.)
Laos
$2,100 (2006 est.)','93fbc6f1882d048bc33499f65a43e3ce7ed4d5d53f26557992a35cbb744d1840','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df9b8ffd96c145cdc3da1d5f0d2afd49ec7ecf8fdeda104c59abe91f4ebeb51a',2007,'LV','Latvia','people-and-society',325,'$35.08 billion (2006 est.)
-0.67% (2006 est.)
9.3% (2006 est.)
$15,400 (2006 est.)','5cb71eb6d7a108725199b3c151adc3618ad51ab1457cefc7e5f02fda2fc73368','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('122fa22b0b8b7bc419824651674079c7e54fc63d0508efca4e3dfa13a4a60d55',2007,'LS','Lesotho','people-and-society',326,'$5.195 billion (2006 est.)
-0.46% (2006 est.)
1.7% (2006 est.)
$2,600 (2006 est.)','e1c51d4f96b663c2e7d2a33da4e76db79db65032e06cbdb826a161abcb514eec','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fee86a8ac407076fb6f72f3147e77ffbbdebbecc13d0473bc95465066c0a867',2007,'LR','Liberia','people-and-society',327,'$2.911 billion (2006 est.)
4.91% (2006 est.)
6.7% (2006 est.)
$1,000 (2006 est.)','1c85f21a909ffbb363c0736e83b88698c4abf5c09ddd8de5b7e031abbca2ec17','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d047054a922fca5129a75d9444d3c89a0ea225dd0f5d7d40e143c714a5f8b38',2007,'LY','Libya','people-and-society',328,'$74.97 billion (2006 est.)
2.3% (2006 est.)
8.1% (2006 est.)
$12,700 (2006 est.)','b7b80ad6da19005f8e148686d8e70f6a13f3e0e0129383436b829cafd94e919c','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a60d437ef8754e5709e4c8d40fc4d1f66be653eb8a60ec615bc59e7bd755e383',2007,'LI','Liechtenstein','people-and-society',329,'$1.786 billion (2001 est.)
0.78% (2006 est.)
11% (1999 est.)
$25,000 (1999 est.)','a8ba1064f77ead0f758651481feee3c5805c704f0641c9454af842ed913a4285','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('128d9ddb6ca2a4521ddc93d55e5dc1a5c96b6d414223d1e69fea2bab78c2a40f',2007,'LT','Lithuania','people-and-society',330,'$54.03 billion (2006 est.)
-0.3% (2006 est.)
7.2% (2006 est.)
$15,100 (2006 est.)','caec651bc59580116de34b2885379d8bae72e7a6850d9778742aa6dcefad9299','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0eeb818f3120bb9fc3e3c6691dad72e181cade2e299c73457634a061e763a2f9',2007,'LU','Luxembourg','people-and-society',331,'$32.6 billion (2006 est.)
Macau
$10 billion (2004)
Macedonia
$16.91 billion
note: Macedonia has a large informal sector (2006 est.)
1.23% (2006 est.)
Macau
0.86% (2006 est.)
Macedonia
0.26% (2006 est.)
5.7% (2006 est.)
Macau
6.7% (2005)
Macedonia
4% (2006 est.)
$68,800 (2006 est.)
Macau
$24,300 (2005)
Macedonia
$8,200 (2006 est.)','c3407bf7a106b52d67dfc95542f9534d610f3afbcf59e053ed3e5e82d4efb640','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1caee46fb5c6ecbad90aa1fcbbcfe9371493edd265eed3030246b9c9c5b3619',2007,'MY','Malaysia','people-and-society',332,'$308.8 billion (2006 est.)
1.78% (2006 est.)
5.5% (2006 est.)
$12,700 (2006 est.)','bd9422406fc49fa4d7b0a8f63ed2314816f668b59ccee3a3ae3dcda93c6cbb10','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39e2ac7511dfb0432efaf9ba023ec5b04cb3171c860c84dd9ddf96699ee23d4d',2007,'MV','Maldives','people-and-society',333,'$1.25 billion (2002 est.)
2.78% (2006 est.)
-3.6% (2005 est.)
$3,900 (2002 est.)','8db9bc8a57f0cc629a0a1200156ee5c4fa6ba880bd6fb1072757b73f668f7e9d','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09f81ca32c228f616244ffff28a1bde83e492d8d5906cd680230d12472b97424',2007,'ML','Mali','people-and-society',334,'$14.59 billion (2006 est.)
2.63% (2006 est.)
5.1% (2006 est.)
$1,200 (2006 est.)','7cf4e0557215e9d6cefdf1da1138052209160347427a321127367d7b9168f4e5','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2eb074d7f713f1bbca4e06bab18e4b06d237219f9318209d80198c7f009a5d59',2007,'MT','Malta','people-and-society',335,'$8.122 billion (2006 est.)
0.42% (2006 est.)
1.3% (2006 est.)
$20,300 (2006 est.)','48c9ed19bd6618cfe2c296e73a58796c9ee91f305cf569ea0e29e03853687154','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('724634768cef4a20668caab3847c84b04d01eaa2f0802d158dcd099843e62dd1',2007,'MR','Mauritania','people-and-society',336,'$8.397 billion (2006 est.)
2.88% (2006 est.)
19.4% (2006 est.)
$2,600 (2006 est.)','0c1cee789d5ebbef426bb20018e7a70b3be7cca0d2ed8df398774738967ad8db','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7d0b92dc7e47df9026907222527f65a9ccf76d96ae5ea7af02b8740c1254a50',2007,'MU','Mauritius','people-and-society',337,'$16.72 billion (2006 est.)
0.82% (2006 est.)
4.3% (2006 est.)
$13,500 (2006 est.)','9bc162a4ab10d870a53af0c9bc153bcf72c85b6263e3ace8d27ca6442cdfabf7','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4adeb70fad3da97531787501bb4f37b3f9951dddc75e158389f26a5b9dc500b',2007,'YT','Mayotte','people-and-society',338,'$466.8 million (2003 est.)
3.77% (2006 est.)
NA%
$2,600 (2003 est.)
departmental collectivity of France
Midway Islands
unincorporated territory of the US; formerly
administered from Washington, DC, by the US Navy; on 31 October
1996, through a presidential executive order, the jurisdiction and
control of the atoll was transferred to the Fish and Wildlife
Service of the US Department of the Interior as part of the National
Wildlife Refuge system','bf94221580d32186b928bb0b5ed8a32a9a5f3220d4c1ea9add1d8c349ac54340','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d94020234ebdbada957d70c29f2bc25c3d56c10a9ec3c0fb291723234a4ae2fc',2007,'MX','Mexico','people-and-society',339,'$1.134 trillion (2006 est.)
1.16% (2006 est.)
4.5% (2006 est.)
$10,600 (2006 est.)','7a2a18d48906cfe9989da3e00ef7b090a5da733f137243a2a80d602d05095402','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e6c4cbc65719166ab3566bc5b145ea15f07ae0b17d5825e7866b70fdce85c273',2007,'FM','Micronesia, Federated States of','people-and-society',340,'$277 million; note - supplemented by
grant aid, averaging perhaps $100 million annually (2002 est.)
Moldova
$8.971 billion (2006 est.)
-0.11% (2006 est.)
Moldova
0.28% (2006 est.)
0.3% (2005 est.)
Moldova
4.6% (2006 est.)
$2,300 (2005 est.)
Moldova
$2,000 (2006 est.)','34cc6e7cb1ea7573592ecd6680b583f143b35362dd8341166b19fc3b7a133464','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6edf51f21788e14dea2ea0575a2992a2aa69d852bc1fb7a8c0b0b0b38ea620a',2007,'MC','Monaco','people-and-society',341,'$870 million
note: Monaco does not publish national income figures; the estimates
are extremely rough (2000 est.)
0.4% (2006 est.)
0.9% (2000 est.)
$27,000 (2000 est.)','983998c87c98e0cc6024f50b08da77b26c2b41aecf3b39fa3991afa8d381e4f1','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2a9a1aab4a9fec1f9d171a641f5428862524ba88fb77291f4e62dd5e33ae307',2007,'MN','Mongolia','people-and-society',342,'$5.781 billion (2006 est.)
1.46% (2006 est.)
7.5% according to official estimate (2006 est.)
$2,000 (2006 est.)','1454ef0afad6965adc3fd3f2098ce5f78cbf41eaa38f4985e7bff108d3376ee5','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c0898e170ee6fe24dcf124e9628f11e1bde9cb2c6d05d31166f41a9ec5c5f33',2007,'MS','Montserrat','people-and-society',343,'$29 million (2002 est.)
1.05% (2006 est.)
-1% (2002 est.)
$3,400 (2002 est.)
overseas territory of the UK
Navassa Island
unincorporated territory of the US; administered by
the Fish and Wildlife Service, US Department of the Interior, from
the Caribbean Islands National Wildlife Refuge in Boqueron, Puerto
Rico; in September 1996, the Coast Guard ceased operations and
maintenance of Navassa Island Light, a 46-meter-tall lighthouse on
the southern side of the island; there has also been a private claim
advanced against the island
Netherlands Antilles
an autonomous country within the Kingdom of the
Netherlands; full autonomy in internal affairs granted in 1954;
Dutch Government responsible for defense and foreign affairs','da77e9f3dbe013f9c84e9e683b9324f6be55e7818b574ef608a595417d28857f','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4ca7f85f11f9e1e5249206063b0eb06710ea55027c3631bfadbe760ecb3adbc9',2007,'MZ','Mozambique','people-and-society',344,'$29.32 billion (2006 est.)
1.38% (2006 est.)
9.8% (2006 est.)
$1,500 (2006 est.)','12d0057ce8f3bc50c5987362f19efea05e9db67dc3b949b2e93ada9f348570ad','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afd0c95e48396d49956f6027c704a18dbbf4cbdb6cbcde9b580cd963df0194e2',2007,'NA','Namibia','people-and-society',345,'$15.04 billion (2006 est.)
0.59% (2006 est.)
4.1% (2006 est.)
$7,400 (2006 est.)','3cb022e83c5992ee1e2638acbcb123835c674fc5e50da7e6aaf4f4dadcc940ea','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51246fc275b5997d359752808f45240cb6e2e0e783be883cefdd698a6ab4672d',2007,'NL','Netherlands','people-and-society',346,'$512 billion (2006 est.)
Netherlands Antilles
$2.8 billion (2004 est.)
0.49% (2006 est.)
Netherlands Antilles
0.79% (2006 est.)
2.9% (2006 est.)
Netherlands Antilles
1% (2004 est.)
$31,700 (2006 est.)
Netherlands Antilles
$16,000 (2004 est.)','c0390e6e4293332dd7b639e17a29a30c7a911640e6d809124351b9689d4caccf','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0a35e699a7d5019b2462431ed41e1bde0526df0b49234c743ee8bb7dc787a72',2007,'NC','New Caledonia','people-and-society',347,'$3.158 billion (2003 est.)
1.24% (2006 est.)
NA%
$15,000 (2003 est.)
territorial collectivity of France since 1998','f3c956b4e74781d529ff5af5180ab1f7719ba706cacc2eaf0f76bd6b364ae0de','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56159c70e581adec1c661919749f1c16b42aaf26c45d69c1119e22d6e4bce8bf',2007,'NI','Nicaragua','people-and-society',348,'$16.83 billion (2006 est.)
1.89% (2006 est.)
2.5% (2006 est.)
$3,000 (2006 est.)','39d32af5bc158f85814930e0aeb381c12593610528207bfba0807406ea0a9e03','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ab24ceed62d41b0013d8f4071792f168d7087bd8d5577e88f83206a2dda1528',2007,'NE','Niger','people-and-society',349,'$12.23 billion (2006 est.)
2.92% (2006 est.)
3.5% (2006 est.)
$1,000 (2006 est.)','45e3e2bbd4447d2b54d302859344c1fe22d4a2c94c3002da47ba36a696998411','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('056bf0d4b75543eec3f578174a379b102b89d3765ef672b29e3f453962470a19',2007,'NG','Nigeria','people-and-society',350,'$188.5 billion (2006 est.)
2.38% (2006 est.)
5.3% (2006 est.)
$1,400 (2006 est.)','60ebc7a9e77a1be7c30228004253d99cf478efd5a09a683aa273c6fe4cabb32c','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78033f24a697342aa9749e4edd6ef8bac74ff1b43331f0c16cf73669bbe66611',2007,'NU','Niue','people-and-society',351,'$7.6 million (2000 est.)
0.01% (2006 est.)
6.2% (2003 est.)
$5,800 (2003 est.)
self-governing in free association with New Zealand since 1974;
Niue fully responsible for internal affairs; New Zealand retains
responsibility for external affairs and defense; however, these
responsibilities confer no rights of control and are only exercised
at the request of the Government of Niue','90df82a014554c740a28036b87251ceffc571c76552758dc959fdf6ea78b3a65','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e23f1e9f1065134f1cf28e3107f97f178f9130afa26ef5bddcfc87349f448945',2007,'NF','Norfolk Island','people-and-society',352,'$NA
-0.01% (2006 est.)
self governing territory of Australia; Canberra
administers Commonwealth responsibilities on Norfolk Island through
the Department of Transport and Regional Services','007e539073cc3b6a06d49e5b200dd421e449a13b629b0a3e2900f4d7cedac248','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f92fdc71875a07154a367728e2d6f8a05c0ec7af42cc238a4171f3cade478e9d',2007,'MP','Northern Mariana Islands','people-and-society',353,'$900 million
note: GDP estimate includes US subsidy (2000 est.)
2.54% (2006 est.)
NA%
$12,500 (2000 est.)
commonwealth in political union with the
US; federal funds to the Commonwealth administered by the US
Department of the Interior, Office of Insular Affairs
Palmyra Atoll
incorporated territory of the US; privately owned, but
administered from Washington, DC, by the Fish and Wildlife Service
of the US Department of the Interior; the Office of Insular Affairs
of the US Department of the Interior continues to administer nine
excluded areas comprising certain tidal and submerged lands within
the 12 nm territorial sea or within the lagoon
Pitcairn Islands
overseas territory of the UK','5146c487341d4a10f459ceb9078f6ed8695eae32dc38559004d7accbd854ff3f','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f72ef7f2dc2042d647a622ba5b9c54a99b0d8513a18504053636d3837256d196',2007,'OM','Oman','people-and-society',354,'$43.88 billion (2006 est.)
3.28% (2006 est.)
6.5% (2006 est.)
$14,100 (2006 est.)','f06e8e744cf1909ed84f6c8309ae6b5aa2ad3c7736006920214d0f386724bd5e','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b380a578031573f8384e2a2579e1d3a0434e041a39ef4bf46a2a812a046c0a3e',2007,'PK','Pakistan','people-and-society',355,'$427.3 billion (2006 est.)
2.09% (2006 est.)
6.5% (2006 est.)
$2,600 (2006 est.)','6780bc58d92bc6b0c2fc417a6fcfd464f503db89a884a1429b0f052d2ccee9ad','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cac1b58b03a31be6eafe7d6d65910ab963c8c5d1170602f26faa1c7a44cb6b3',2007,'PW','Palau','people-and-society',356,'$124.5 million; note - includes US subsidy (2004 est.)
1.31% (2006 est.)
5.5% (2005 est.)
$7,600 (2005 est.)','9e69c6ebdeb14003e6aa94cc0e502c6a68a472e70d8767a8c03c8c58982e5421','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c471ff2bb0c6afa5fff9fbc5aefb103e36473c27d2542cf57365050725223a88',2007,'PG','Papua New Guinea','people-and-society',357,'$15.13 billion (2006 est.)
2.21% (2006 est.)
3.2% (2006 est.)
$2,700 (2006 est.)','2c70fe9916ea3f507715d87ee2c3ff066de6453706828b40c5720c42f11432d9','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dab94e5f56f9bd7918670ecd092702a41d41b4d26e9dd4d55e771b9bc262818c',2007,'PY','Paraguay','people-and-society',358,'$30.64 billion (2006 est.)
2.45% (2006 est.)
3.2% (2006 est.)
$4,700 (2006 est.)','cd3a1463e10832882ced12e88b47ed4017f5b687b631b647fbc9fdf35400fd4d','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e461e4d4baf84a1b8c0d78b31b4c94ecb93bf0708e8650946b1b4554e90bc2ac',2007,'PE','Peru','people-and-society',359,'$181.8 billion (2006 est.)
1.32% (2006 est.)
6.5% (2006 est.)
$6,400 (2006 est.)','ceaa0c31bd77fd211a0d51df58e5e4e909c4341d7efb0b108fc1c2c08047d29b','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7a1ebc3e2baeeb22d746268b150c52fc421da9e91fd3b0a942e4ba000f734a9',2007,'PH','Philippines','people-and-society',360,'$443.1 billion (2006 est.)
Pitcairn Islands
$NA
1.8% (2006 est.)
Pitcairn Islands
-0.01% (2006 est.)
5.3% (2006 est.)
$5,000 (2006 est.)','4315c6cfd813d8d5598e145fa7b428001633400339d770524e9a6a8b0275e6ff','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4bb16a3900300f4f310def3ef868342841aa2018bbd29b77c2ab1c63c9e96ac1',2007,'PL','Poland','people-and-society',361,'$542.6 billion (2006 est.)
-0.05% (2006 est.)
5.3% (2006 est.)
$14,100 (2006 est.)','f061855827ddf2a398b2a97ee99d78f35214342612b3f6859181703616997f28','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f1e664f2724a14c2e57dc012373856a342a2fc1da4b4852650d057c01d027b1',2007,'PT','Portugal','people-and-society',362,'$203.1 billion (2006 est.)
0.36% (2006 est.)
1.2% (2006 est.)
$19,100 (2006 est.)','a9817df7a68f6d3558fa4756f32450a768efe5d395e94081d590ff9799f9e497','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('663f88aea14a2e4733848a94d94e0c18d224c95e3ae4f887bd1b8658cc909b1a',2007,'PR','Puerto Rico','people-and-society',363,'$74.89 billion (2006 est.)
0.4% (2006 est.)
0.5% (2006 est.)
$19,100 (2006 est.)
unincorporated, organized territory of the US with
commonwealth status; policy relations between Puerto Rico and the US
conducted under the jurisdiction of the Office of the President
Saint Helena
overseas territory of the UK','3e8aa74e0395d4d6877f99d27c18c54e204810f21212e0e37701603c884d5b35','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6063ff35d7065621f8590968903ec49cb89332c2087203568e70fe2b5f51a51',2007,'QA','Qatar','people-and-society',364,'$26.05 billion (2006 est.)
2.5% (2006 est.)
7.1% (2006 est.)
$29,400 (2006 est.)','fa232c539a87185898daea100f76cd0d075db6dfab0bca9acf364b5768d25cc7','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02a1ebfde1bb6bb417cf60ed0b5fd3c26d8077293f57b1bc87ea525cdcd3fdd6',2007,'RO','Romania','people-and-society',365,'$197.3 billion (2006 est.)
Russia
$1.723 trillion (2006 est.)
-0.12% (2006 est.)
Russia
-0.37% (2006 est.)
6.4% (2006 est.)
Russia
6.6% (2006 est.)
$8,800 (2006 est.)
Russia
$12,100 (2006 est.)','65b038d1aebe32a679074edc4c4af667f229cadd4749506e8fc0f3ba260f453e','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98421912422eeec52a6ee9b7297c87d350b442b02e72015f4e38836394ccb428',2007,'RW','Rwanda','people-and-society',366,'$13.54 billion (2006 est.)
Saint Helena
$18 million (1998 est.)
2.43% (2006 est.)
Saint Helena
0.56% (2006 est.)
5.8% (2006 est.)
Saint Helena
NA%
$1,600 (2006 est.)
Saint Helena
$2,500 (1998 est.)','13ec1c755361ae691c31be62ec165c71f1f31bb276dbb1357741c6aca359d745','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e498e51b87a831e88d9ef467a316c5e5f6aac1a0dcae97f157f9de3f696c8477',2007,'PM','Saint Pierre and Miquelon','people-and-society',367,'$48.3 million
note: supplemented by annual payments from France of about $60
million (2003 est.)
0.17% (2006 est.)
NA%
$7,000 (2001 est.)
self-governing territorial overseas
collectivity of France','eadda1a2285155bbf1a41037857bbcdf4de87d4ee7ae7e8e4965fac5f3eaa645','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a08d78d7c67766371307c7c06f648f65326622cea6c21d108b49211bd3b16e5',2007,'SN','Senegal','people-and-society',368,'$22.01 billion (2006 est.)
2.34% (2006 est.)
4.9% (2006 est.)
$1,800 (2006 est.)','b394a870ae6cd857f1f33171b9db0c2cb977a72d4648afd8ff67fd4b5a3d08a9','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91f4a621b81cd1e407eea5fe035806b4080dcb374b18a7d35b8462f5899d15a6',2007,'RS','Serbia','people-and-society',369,'$44.83 billion for Serbia (including Kosovo) (2006 est.)
5.9% for Serbia alone (excluding Kosovo) (2005 est.)
$4,400 for Serbia (including Kosovo) (2005 est.)','25e328753a9dd1f4871a0ca785cf53b82513f000fd7fa2d063570171dffbba5d','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00c6e03fc46e5ed250931a48417caff9d441aa713dc0f4bfd56680dd5db408bd',2007,'SG','Singapore','people-and-society',370,'$138.6 billion (2006 est.)
1.42% (2006 est.)
7.4% (2006 est.)
$30,900 (2006 est.)','e96486249fcaf5ed47e7de2c41171927403756229b131f0d6558a4dae6145319','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ad8c18697d77df63657bf1f1926680f2d4aed83e1066801b1c04e75ccc0ef39e',2007,'SK','Slovakia','people-and-society',371,'$96.35 billion (2006 est.)
0.15% (2006 est.)
6.4% (2006 est.)
$17,700 (2006 est.)','69be57f18166c11573960f8e13a69ad0dbc06e2502ff82c25dd4239e9f8a405a','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('152ed2ac1f1494bbc2863eb743cadba2807b680c65657fbe14c86b67f00bd208',2007,'SI','Slovenia','people-and-society',372,'$46.08 billion (2006 est.)
-0.05% (2006 est.)
4.4% (2006 est.)
$22,900 (2006 est.)','62af82ae6926a98f198dc07bb4c305d76cb8c049b372e05125b4efb8baec88ff','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('518348ceecf4a0343216b304c3efb7213a67bfec143ffc2d6b4eda431f976b2f',2007,'ZA','South Africa','people-and-society',373,'$576.4 billion (2006 est.)
-0.4% (2006 est.)
4.5% (2006 est.)
$13,000 (2006 est.)','c50e92d1b87a509260d15f2742c84d22a5ad528846f6e2522c70bc16340e33fd','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9566042a6480aae42d26ea020005a840b3f5e76832306aa95b26405f33c26460',2007,'ES','Spain','people-and-society',374,'$1.07 trillion (2006 est.)
0.13% (2006 est.)
3.6% (2006 est.)
$27,000 (2006 est.)','24f2060dfcb7f2291759546419484d16e01926476041b750a28d180d3b5b130c','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30ea3b5eb7895b6fb771392a5bc6c60b08edde7e77b3dbd518564c642afb0b59',2007,'LK','Sri Lanka','people-and-society',375,'$93.33 billion (2006 est.)
0.78% (2006 est.)
6.3% (2006 est.)
$4,600 (2006 est.)','c7b5107f162b48f96a849b2cbbc639231e49f5d3da8723151ffb893199795a33','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2993cfbe92c2485a45967d9a75fd728bf76e2ca55d26994e8a9b1a0802b7b501',2007,'SD','Sudan','people-and-society',376,'$96.01 billion (2006 est.)
2.55% (2006 est.)
9.6% (2006 est.)
$2,300 (2006 est.)','fc1fd008bab076dc405a49bb687a692608cac03e166baf7753d3ed1b9cac583f','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71d7d229ef411e706fd8e8bcf2c6012899e8248a79044f3b71c3f40f7c15676e',2007,'SR','Suriname','people-and-society',377,'$3.098 billion (2006 est.)
Svalbard
$NA
Swaziland
$5.91 billion (2006 est.)
0.2% (2006 est.)
Svalbard
-0.02% (2006 est.)
Swaziland
-0.23% (2006 est.)
5% (2006 est.)
Svalbard
NA%
Swaziland
2% (2006 est.)
$7,100 (2006 est.)
Swaziland
$5,200 (2006 est.)','0ad17bfa8138554162e31901d653ca04f7a7e4b914d6f5b488681353144c2ec6','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50693ea7ee81aee690c1bb09110d43b088d301452a0812109dc621383d6ff7da',2007,'SE','Sweden','people-and-society',378,'$285.1 billion (2006 est.)
0.16% (2006 est.)
4.2% (2006 est.)
$31,600 (2006 est.)','04dfc71b8e4fd8db2e090bb5a36d44c3a5c9219ad11d5a30db8a8efa1a170fdd','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f6167170e982dc4db5efb681a3deeabd11dc90fc6e071a433d482fe8ff04e3f2',2007,'CH','Switzerland','people-and-society',379,'$252.9 billion (2006 est.)
Syria
$75.1 billion (2006 est.)
Taiwan
$668.3 billion (2006 est.)
0.43% (2006 est.)
Syria
2.3% (2006 est.)
Taiwan
0.61% (2006 est.)
2.9% (2006 est.)
Syria
2.9% (2006 est.)
Taiwan
4.4% (2006 est.)
$33,600 (2006 est.)
Syria
$4,000 (2006 est.)
Taiwan
$29,000 (2006 est.)','5013ea7b3b8e4392540cc31f9f1cb323e4af72b5179a3d350a91e9465f986f36','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab897dc20a0fa0b817ca613a955cc06e1b240fb9eef71d9e6aabedc897f1dc58',2007,'TJ','Tajikistan','people-and-society',380,'$9.405 billion (2006 est.)
Tanzania
$29.25 billion (2006 est.)
2.19% (2006 est.)
Tanzania
1.83% (2006 est.)
7% (2006 est.)
Tanzania
5.8% (2006 est.)
$1,300 (2006 est.)
Tanzania
$800 (2006 est.)','22cdd8b686e5740f06a828416af629db634c9312b6c4652f30807e359ff9143e','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cafcb6865241443ab15acd458e9610342f185d2479e0598ab4a901f4aaa699ec',2007,'TH','Thailand','people-and-society',381,'$585.9 billion (2006 est.)
0.68% (2006 est.)
4.4% (2006 est.)
$9,100 (2006 est.)','15cde98069ca169c2b4ec1d13ebc75aecc4606d00e3406cb180b57a27b0f6d04','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d190bd075c33fd222e16b67d793f25a8c402ae362f71c9f770208fde58113088',2007,'TK','Tokelau','people-and-society',382,'$1.5 million (1993 est.)
-0.01% (2006 est.)
NA%
$1,000 (1993 est.)
self-administering territory of New Zealand; note - Tokelau
and New Zealand have agreed to a draft constitution as Tokelau moves
toward free association with New Zealand; a UN sponsored referendum
on self-governance, in February 2006, did not produce the two thirds
majority vote necessary for changing the current political status
Tromelin Island
possession of France; administered by the
Administrateur Superieur of the French Southern and Antarctic Lands','f11149e644c6aa6f945b18cd1cd235c2adf581dfc03ac1de4a94034289411576','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('201c7d9bc3e951266deee47b4d47fe219595be34befcced49099c08e94c8971f',2007,'TO','Tonga','people-and-society',383,'$178.5 million (2004 est.)
2.01% (2006 est.)
2.4% (2005 est.)
$2,200 (2005 est.)','a5d45ce4b997ff4cfc636ccfb688b7fbf3183c5c04207fd74f205aeaeead6397','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a94f929cbae4459ea086bada566da8f4e687f9edc2a12ab3c78cb1633bf9102',2007,'TT','Trinidad and Tobago','people-and-society',384,'$20.99 billion (2006 est.)
-0.87% (2006 est.)
12.6% (2006 est.)
$19,700 (2006 est.)','987ba644cc20d7845a8901b6b2df5d9d43be87abd1dbfd57b1955d4ee9f11680','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0efdfe0f362bd758f196495f16e700dc9ec3b9b0f55a3fb8841c3461985f34e5',2007,'TN','Tunisia','people-and-society',385,'$87.88 billion (2006 est.)
Turkey
$627.2 billion (2006 est.)
0.99% (2006 est.)
Turkey
1.06% (2006 est.)
4% (2006 est.)
Turkey
5.2% (2006 est.)
$8,600 (2006 est.)
Turkey
$8,900 (2006 est.)','59c95c2393cbd1e51b036c1da368ff799b874df95d15bd4f5e338472d688eee6','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3e32faf82fb4eea8cea98f31872c9fc86a21cfd5b02aff90234096a0efb87591',2007,'TM','Turkmenistan','people-and-society',386,'$45.11 billion (2006 est.)
1.83% (2006 est.)
IMF estimate: 13%
note: official government statistics show 21.4% growth, but these
estimates are widely regarded as unreliable (2006 est.)
$8,900 (2006 est.)','59672ba9bbe96e29011ae619c00506203feb65090561bb3bd8c6ade5d13ed8c8','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('92250dd2d02aa1a35c05087ee746ef22c59229e318ec12f8ad8a396f19435b16',2007,'TC','Turks and Caicos Islands','people-and-society',387,'$216 million (2002 est.)
2.82% (2006 est.)
4.9% (2000 est.)
$11,500 (2002 est.)
overseas territory of the UK
United States Pacific Island Wildlife Refuges
unincorporated
territories of the US; administered from Washington, DC, by the Fish
and Wildlife Service of the US Department of the Interior as part of
the National Wildlife Refuge system
note on Palmyra Atoll: incorporated Territory of the US; partly
privately owned and partly federally owned; administered from
Washington, DC, by the Fish and Wildlife Service of the US
Department of the Interior; the Office of Insular Affairs of the US
Department of the Interior continues to administer nine excluded
areas comprising certain tidal and submerged lands within the 12 nm
territorial sea or within the lagoon
Virgin Islands
organized, unincorporated territory of the US with
policy relations between the Virgin Islands and the US under the
jurisdiction of the Office of Insular Affairs, US Department of the
Interior
Wake Island
unincorporated territory of the US; administered from
Washington, DC, by the Department of the Interior; activities on the
island are conducted by the US Air Force','ca8ed804df1066c34222da433bb4e02ce14c6aca2340108bec663d92830978f8','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fca3a9318f26681e52c530c0cfcf97c1c924a2f8b24fb77954121fe86ccb7181',2007,'TV','Tuvalu','people-and-society',388,'$14.94 million (2002 est.)
1.51% (2006 est.)
1.2% (2002 est.)
$1,600 (2002 est.)','3e4ff00db9334fbc70788af5857170506729e64c23d1e5bb25816909b2f8baed','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68d57331c68e8911b0795925aafb50f9e64028356058d920b3ae3d3f4ec0b59a',2007,'AE','United Arab Emirates','people-and-society',389,'$129.4 billion (2006 est.)
1.52% (2006 est.)
10.2% (2006 est.)
$49,700 (2006 est.)','76cd2af43691676000918b3c3b80916ce25c55e0665c7e75240aac8cf5d480f7','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3bec280c41f2bb6bc8b80b091b663995ac8c3ffb325a638b0fa8cc3652790f12',2007,'GB','United Kingdom','people-and-society',390,'$1.903 trillion (2006 est.)
0.28% (2006 est.)
2.7% (2006 est.)
$31,400 (2006 est.)','6788145fb5a14a4befa9334dd5893adf9f852979de16951d69491ea03af7ec32','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc9424a466050580fba7076a25c525772cf29914fa9b3efcd8ef8bf67a89deb5',2007,'US','United States','people-and-society',391,'$12.98 trillion (2006 est.)
0.91% (2006 est.)
3.2% (2006 est.)
$43,500 (2006 est.)','76bb429f73714145b90b72d271d3c640d75124a207461d5f4e34307b7d8fbcf9','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e543cb7594b8f82eb8bddf5eac9f26f7243dd5094c831ee20e006e357cbca1ac',2007,'VU','Vanuatu','people-and-society',392,'$276.3 million (2003 est.)
Venezuela
$176.4 billion (2006 est.)
Vietnam
$258.6 billion (2006 est.)
Virgin Islands
$1.577 billion (2004 est.)
1.49% (2006 est.)
Venezuela
1.38% (2006 est.)
Vietnam
1.02% (2006 est.)
Virgin Islands
-0.12% (2006 est.)
6.8% (2005 est.)
Venezuela
8.8% (2006 est.)
Vietnam
7.8% (2006 est.)
Virgin Islands
2% (2002 est.)
$2,900 (2003 est.)
Venezuela
$6,900 (2006 est.)
Vietnam
$3,100 (2006 est.)
Virgin Islands
$14,500 (2004 est.)','2213ce28b1d340e208c9a9453f6ebdb3f0ff75cbd4d3fa2420a7cfc200dd4d97','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dd4d886f62524d9e9bc987ae082edf3a7f70b633291cdf3f34195795606ec376',2007,'WF','Wallis and Futuna','people-and-society',393,'$60 million (2004 est.)
West Bank
$5.327 billion (2005 est.)
NA
West Bank
3.06% (2006 est.)
NA%
West Bank
4.9% (2005 est.)
$3,800 (2004 est.)
West Bank
$1,500 (2005 est.)
overseas territory of France
This page was last updated on 8 February, 2007
======================================================================
@2007 Diplomatic representation from the US','623b5c1eddf41effd17bba25ad341af808836502d05f409ba7009b9190204056','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f4053789837e6b2221b9f4f2e9c1c0c4359f49619d58c40a03c498d03675025d',2007,'EH','Western Sahara','people-and-society',394,'$NA
World
GWP (gross world product): $65 trillion (2006 est.)
NA
World
1.14% (2006 est.)
NA%
World
5.1% (2006 est.)
$NA
World
$10,000 (2006 est.)','128540688db8fab32c1e682fb3148ac5911de10cd71723c8a5aeed3e36b9ea4a','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc1267a29515d0e2abcd306d4e391efceeeb32755d8fa835827b834371736e91',2007,'BV','Bouvet Island','people-and-society',395,'territory of Norway; administered by the Polar
Department of the Ministry of Justice and Police from Oslo','a602d22c9c2afea39d62ac445c6985ef01fa76486b333f2b4b13ad104c4d49dd','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('adbc175fd3dcf0afce1338350bc9ada4938ff0b9b7015d0c223b61bc37425de9',2007,'IO','British Indian Ocean Territory','people-and-society',396,'overseas territory of the UK;
administered by a commissioner, resident in the Foreign and
Commonwealth Office in London
British Virgin Islands
overseas territory of the UK; internal
self-governing
none (overseas territory of the UK)
British Virgin Islands
none (overseas territory of the UK)
Brunei
chief of mission: Ambassador Emil SKODON
embassy: Third Floor, Teck Guan Plaza, Jalan Sultan, Bandar Seri
Begawan, BS8811
mailing address: PSC 470 (BSB), FPO AP 96507; P.O. Box 2991, Bandar
Seri Begawan BS8675, Negara Brunei Darussalam
telephone: [673] 222-0384
FAX: [673] 222-5293','d730d639e836cc29deeef52a7242fde87b12c696074a6718e2fd9d98c8946010','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85bad1cfd69a8703b4297bc238216fa97f16bc2166adb516548e44d3a348abcf',2007,'HM','Heard Island and McDonald Islands','people-and-society',397,'territory of Australia;
administered from Canberra by the Australian Antarctic Division of
the Department of the Environment and Heritage
none (territory of Australia)
Holy See (Vatican City)
chief of mission: Ambassador Francis ROONEY
embassy: Villa Domiziana, Via delle Terme Deciane 26, 00153 Rome
mailing address: PSC 59, Box 66, APO AE 09624
telephone: [39] (06) 4674-3428
FAX: [39] (06) 575-8346','2362b7b24263254347c0bcd69c37ddbce37b60461e0ed98d80a8f4bc7b31842e','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a72b8b6560a32df12bf6ec84ad84f08749bc937bc97d95c745d4a04ade7c18ba',2007,'GS','South Georgia and the South Sandwich Islands','people-and-society',398,'overseas territory of
the UK, also claimed by Argentina; administered from the Falkland
Islands by a commissioner, who is concurrently governor of the
Falkland Islands, representing Queen ELIZABETH II; Grytviken -
formerly a whaling station on South Georgia - is a scientific base
Svalbard
territory of Norway; administered by the Polar Department
of the Ministry of Justice, through a governor (sysselmann) residing
in Longyearbyen, Spitsbergen; by treaty (9 February 1920)
sovereignty was awarded to Norway','ad8c89205870ab553bc37190d4aaeb93154d7258cfd9567d8cfe19ba62751fb9','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72dd34652a78cfcbdeb1c8d28179d1ce0a1862e72ce1766d81b5c9001c19b077',2007,'EH','Western Sahara','military-and-security',21,'Military branches
Military service age and obligation
Manpower available for military service
males
females
Manpower fit for military service
males
females
Manpower reaching military service age
annually
males
females
Military expenditures - dollar figure
Military expenditures - percent of GDP
Military - note
Military expenditures - dollar figure: aggregate
real expenditure on arms worldwide in 1999 remained
at approximately the 1998 level, about three-quarters
of a trillion dollars (1999 est.)
Military expenditures - percent of GDP: roughly
2% of gross world product (1999 est.)','9344b369d4d3d4ce7794b5ed97bfd07182283bb4962dd8ab8ee604ac5c05f187','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4adf3f79e801632c8cc0020fa06ebeb695e23123d9504f5958140f9a55d3732',2007,'AF','Afghanistan','military-and-security',32,'Military branches: Afghan National Army (includes
Afghan Air Force) (2006)
Military service age and obligation: 22 years of
age; inductees are contracted into service for a 4-year
term (2005)
Manpower available for military service:
males age 22-49: 4,952,81 2 (2005 est.)
Manpower fit for military service:
males age 22-49: 2,662.946 (2005 est.)
Manpower reaching military service age
annually:
males: 275,362 (2005 est.)
Military expenditures - dollar figure: $122.4
million (2005 est.)
Military expenditures - percent of GDP: 1 .7%
(2005 est.)
Military branches: Ground Forces, Air and Air
Defense Forces (2004)
Military service age and obligation: 18 years of
age for compulsory military service; conscript service
obligation - two years (2004)
Manpower available for military service:
males age 18-49: 1,132,833 (2005 est.)
Manpower fit for military service:
males age 18-49: 759,978 (2005 est.)
Manpower reaching military service age
annually:
males: 56,532 (2005 est.)
Military expenditures • dollar figure: $90 million
(FY99)
Military expenditures - percent of GDP: 3.4%
(FY99)
565
Turkmenistan (continued)
ransnationa
Issues
Disputes - international: cotton monoculture in
Uzbekistan and Turkmenistan creates water-sharing
difficulties for Amu Darya river states; bilateral talks
continue with Azerbaijan on dividing the seabed and
contested oilfields in the middle of the Caspian;
demarcation of land boundary with Kazakhstan has
started but Caspian seabed delimitation remains
stalled
Refugees and internally displaced persons:
refugees (country of origin): 12,085 (Tajikistan) (2005)
Illicit drugs: transit country for Afghan narcotics
bound for Russian and Western European markets;
transit point for heroin precursor chemicals bound for
Turks and
Caicos Islands
(overseas territory
of the UK)
NORTH ATLANTIC
OCEAN
Kew
Providenctales
Providenctales
North
Caicos
Bottle Creek
Middle Caicos
clVc
West CAICOS ISLANDS
Caicos Cockburn
Harbour
RaiftngoHH
South
Caicos
GRAND
TURK
•
Amoergns Cays
Sail Cay
NORTH ATLANTIC
OCEAN
TURKS
ISLANDS
Seal
Cays','9f3bdec3ac0d7f6e6e0a3f427c22a4da8bfb91515a9e078de49f08f820a9a6a5','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63368593dd4ba035fd9584730a3fe35d8cc95aebce3ce7f2d58153f76c1e9621',2007,'AL','Albania','military-and-security',41,'Military branches: General Staff Headquarters,
Land Forces Command (Army), Naval Forces
Command. Air Defense Command, Logistics
Command, Training and Doctrine Command
Military service age and obligation: 19 years of
age (2004)
Manpower available for military service:
males age 19-49: 809,524 (2005 est.)
Manpower fit for military service:
males age 19-49: 668,526 (2005 est.)
Manpower reaching military service age
annually:
males: 37,407 (2005 est.)
Military expenditures - dollar figure: $56.5 million
(FY02)
Military expenditures ■ percent of GDP: 1 .49%
(FY02)','f763eca2950844a0b11d1466280292f10a07de68c49aa460d1d2cdcc4c2bcb82','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f42f1338e26059812b96ac54e993291f0f75010aaac5fe7269f019e7ba37f011',2007,'ES','Spain','military-and-security',51,'Military branches: People''s National Army (ANP;
includes Land Forces), Algerian National Navy (MRA),
Air Force (QJJ), Territorial Air Defense Force (2005)
12
Algeria (continued)
Military service age and obligation: 1 9-30 years of
age for compulsory military service; conscript service
obligation - 18 months (October 2003)
Manpower available for military service:
males age 19-49: 8,033,049 (2005 est.)
Manpower fit for military service:
males age 19-49: 6,590,079 (2005 est.)
Manpower reaching military service age
annually:
males: 374,639 (2005 est.)
Military expenditures - dollar figure: $3 billion
(2005 est.)
Military expenditures • percent of GDP: 3.2%
(2005 est.)
Military branches: no regular military forces; Royal
Montserrat Police Force (2005)
Military - note: defense is the responsibility of the
UK','93cb70d49987304a74d41bac7ca51fc8c120736c00159b490be8de71cf6031cc','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('237fbeb86c69ec09342997b4f9fc064ae33cbe3e2fcf6d47742797ace787c592',2007,'NZ','New Zealand','military-and-security',61,'Military - note: defense is the responsibility of the
US
Military branches: New Zealand Army, Royal New
Zealand Navy, Royal New Zealand Air Force
Military service age and obligation: 17 years of
age for voluntary military service; soldiers cannot be
deployed until the age of 18 (2001)
Manpower available for military service:
males age 17-49: 984,700 (2005 est.)
Manpower fit for military service:
males age 17-49: 809,519 (2005 est.)
Manpower reaching military service age
annually:
males: 29,738 (2005 est.)
Military expenditures • dollar figure: $1,147 billion
(FY03/04)
Military expenditures - percent of GDP: 1%
(FY02)
Military branches: Trinidad and Tobago Defense
Force: Ground Force, Coast Guard (includes Air
Wing) (2004)
Military service age and obligation: 1 8 years of
age for voluntary military service; no conscription
(2001)
Manpower available for military service:
males age 18-49: 293,094 (2005 est.)
Manpower fit for military service:
males age 18-49: 203,531 (2005 est.)
Military expenditures - dollar figure: $66.72
million (2003 est.)
Military expenditures - percent of GDP: 0.6%
(2003 est.)
Military - note: defense is the responsibility of','a0f4c7afa1c976a448aec5473f0adb2f73d2db5eb8d907d3d0e8ea304e95dfca','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('20aa9c4f101eced3dee87a53b8ead6eb8c72d01ac8499d0d9678574b53d509ea',2007,'NA','Namibia','military-and-security',73,'Military branches: Army, Navy (Marinha de Guerra.
MdG), Air and Air Defense Forces (FANA) (2006)
Military service age and obligation: 1 7 years of
age for compulsory military service; conscript service
obligation - two years plus time for training (2001 )
Manpower available for military service:
males age 1 7-49: 2,423,221 (2005 est.)
Manpower fit for military service:
males age 1 7-49: 1,174,548 (2005 est.)
Manpower reaching military service age
annually:
males: 121,254 (2005 est.)
Military expenditures • dollar figure: $2 billion
(2005 est.)
Military expenditures - percent of GDP: 8.8%
(2005 est.)
Military branches: South African National Defense
Force (SANDF): Army, Navy, Air Force, Joint
Operations, Joint Support, Military Intelligence,
Military Health Service (2004)
Military service age and obligation: 18 years of
age for voluntary military service; women have a long
history of military service in noncombat roles, dating
back to World War I (2004)
Manpower available for military service:
males age 18-49: 10,354,769 (2005 est.)
Manpower fit for military service:
males age 18-49: 4,927,757 (2005 est.)
Manpower reaching military service age
annually:
males: 512,407 (2005 est.)
Military expenditures • dollar figure: $3.55 billion
(2005 est.)
Military expenditures - percent of GDP: 1 .5%
(2005 est.)
Military - note: with the end of apartheid and the
establishment of majority rule, former military, black
homelands forces, and ex-opposition forces were
integrated into the South African National Defense
Force (SANDF); as of 2003 the integration process
was considered complete
Military - note: defense is the responsibility of the
UK','595e90318b3bc3bb186c39edfbc4ef5b509ae520e99d32892e9e20485a2c914f','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d9e20cbfaeadf2c446848925a505493969eaf700291e83e5d047366e2a71513',2007,'AR','Argentina','military-and-security',94,'Military - note: the Antarctic Treaty prohibits any
measures of a military nature, such as the
establishment of military bases and fortifications, the
carrying out of military maneuvers, or the testing of
any type of weapon; it permits the use of military
personnel or equipment for scientific research or for
any other peaceful purposes
Military branches: Army of the Nation. National
Navy (includes naval air, Coast Guard, and Marine
Corps), Chilean Air Force, Chilean Carabineros
(National Police)
Military service age and obligation: all male
citizens 18-45 are obligated to perform military
service; conscript service obligation - 12 mom
Army, 24 months for Navy and Air Force (2004 |
Manpower available for military service:
males age 75-49.3,815,761 (2005 est.)
Manpower fit for military service:
males age 18-49 3,123,281 (2005 est.)
Manpower reaching military service age
annually:
males: 140,084 (2005 est.)
117
Chile (continued)
Military expenditures
(2005 est.)
Military expenditures
(2005 est.)
dollar figure: S3. 91 billion
percent of GDP: 3.5%
Military branches: Army, Navy (includes Naval
Aviation, River Defense Corps, Coast Guard), Air
Force
Military service age and obligation: 18 years of
age for compulsory and voluntary military service;
conscript service obligation - 12 months for Army, 24
months for Navy (2004)
Manpower available for military service:
males age 18-49: 1 ,345,022 (2005 est.)
Manpower fit for military service:
males age 18-49: 1 ,109,166 (2005 est.)
Manpower reaching military service age
annually:
males: 63,058 (2005 est.)
Military expenditures - dollar figure: $53.1 million
(2003 est.)
Military expenditures - percent of GDP: 0.9%
(2003 est.)
Military branches: Army (Ejercito Peruano), Navy
(Marina de Guerra del Peru; includes Naval Air, Naval
Infantry, and Coast Guard), Air Force (Fuerza Aerea
del Peru; FAP)
Military service age and obligation: 18 years of
age for compulsory military service (1999)
Manpower available for military service:
males age 18-49: 6,647,874 (2005 est.)
Manpower fit for military service:
males age 18-49: 4,938,417 (2005 est.)
Manpower reaching military service age
annually:
males: 277,105 (2005 est.)
Military expenditures - dollar figure: $829.3
million (2003 est.)
Military expenditures - percent of GDP: 1 .4%
(2003 est.)','588244f5b8233bb3124a92c00e58f689c7aa82bb85a02b0b9cc939a43539a7c6','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d62d630901bee94b406162729d2ecfa695e5e032f943fe6c4c8736da9c3554e5',2007,'AG','Antigua and Barbuda','military-and-security',104,'Military branches: Royal Antigua and Barbuda
Defense Force: Infantry, Coast Guard (2004)
Military service age and obligation: 18 years of
age (est.); no conscript military service (2001)
Military expenditures - dollar figure: NA
Military expenditures - percent of GDP: NA','5de69f3b7321ffb9d1f10a1dc09dcaa982bd221ed7ce1cf7a6f20b6b67b871a3','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9ac4992e241286a14fb13bcda964a370a872b777dc4d5b7ca37bbc90c20df7bf',2007,'AQ','Antarctica','military-and-security',111,'Military branches: Argentine Army, Navy of the
Argentine Republic (includes Naval Aviation and
Naval Infantry), Argentine Air Force (Fuerza Aerea
Argentina, FAA) (2005)
Military service age and obligation: 18 years of
age for voluntary military service; no conscription
(2001)
Manpower available for military service:
males age 18-49: 8,981 ,886 (2005 est.)
Manpower fit for military service:
males age 18-49: 7,316,038 (2005 est.)
Manpower reaching military service age
annually:
males: 344,575 (2005 est.)
Military expenditures - dollar figure: $4.3 billion
(FY99)
Military expenditures - percent of GDP: 1 .3%
(FY00)
Military - note: the Argentine military is a
well-organized force constrained by the country''s
prolonged economic hardship; the country has
recently experienced a strong recovery, and the
military is now implementing "Plan 2000," aimed at
making the ground forces lighter and more responsive
(2005)','88dc468a80888df170e4197d65a179e55193e862a4d33fdf72407564f8793552','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66642b136c7f72d9587a66e8fce8641a561290d661d5b5b06cde5657f319de55',2007,'AM','Armenia','military-and-security',118,'Military branches: Army, Air Force, Air Defense
Force
Military service age and obligation: 1 8-27 years of
age for compulsory military service, conscript service
obligation - 12 months; 18 years of age for voluntary
military service (May 2004)
Manpower available for military service:
males age 18-49: 722,836 (2005 est.)
Manpower fit for military service:
males age 18-49: 551 ,938 (2005 est.)
Manpower reaching military service age
annually:
males: 31 ,774 (2005 est.)
Military expenditures - dollar figure: $135 million
(FY01)
Military expenditures • percent of GDP: 6.5%
(FY01)','3ed2e2a1a3740fb471b0a4548be505c800d11585fe75b51b1e13d63ff3598957','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3e9e936675bd40e6910c3cc1fe7a09b5acec68824f9d5d39a3b0c9c2e0bc242',2007,'AW','Aruba','military-and-security',119,'(part of the Kingdom of
the Netherlands)
Transnationa
s s u e s
Disputes ■ international: Armenia supports ethnic
Armenian secessionists in Nagorno-Karabakh and
since the early 1990s, has militarily occupied 16% of
Azerbaijan - Organization for Security and
Cooperation in Europe (OSCE) continues to mediate
dispute; over 800,000 mostly ethnic Azerbaijanis were
driven from the occupied lands and Armenia; about
230,000 ethnic Armenians were driven from their
homes in Azerbaijan into Armenia; Azerbaijan seeks
transit route through Armenia to connect to Naxcivan
exclave; border with Turkey remains closed over
Nagorno-Karabakh dispute; ethnic Armenian groups
in Javakheti region of Georgia seek greater autonomy:
tens of thousands of Armenians emigrate, primarily to
Russia, to seek employment
Refugees and internally displaced persons:
refugees (country of origin): 235,1 01 (Azerbaijan)
IDPs: 50,000 (conflict with Azerbaijan over
Nagorno-Karabakh) (2005)
Illicit drugs: illicit cultivation of small amount of
cannabis for domestic consumption; minor transit
point for illicit drugs - mostly opium and hashish -
moving from Southwest Asia to Russia and to a lesser
extent the rest of Europe
Caribbean Sea
ORANJES
* ;
ORANJESTAD V
.Santa Cruz
iBeatnx
\\^ International
Alport A^
Barcadera^^ . Jamancia
SabanetaV
Caribbean Sea
Sint
Nicolaas
CVu\\.
Colorado','6fe13fa1debe807fdeb63e61f4b39e174e6eff3394485a31ae2abbcd9d5c1e4e','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('88609b276306fbd9310cee10de605a29f573571570b6f3e940f8f2af5e783db2',2007,'NL','Netherlands','military-and-security',128,'Military branches: no regular indigenous military
forces; Royal Dutch Navy and Marines, Coast Guard
Military - note: defense is the responsibility of the
Kingdom of the Netherlands
Military branches: no regular military forces;
National Guard, Police Force (2005)
Military service age and obligation: 16 years of
age for National Guard recruitment; no conscription
(2002)
Manpower available for military service:
males age 16-49: 54,200 (2005 est.)
Manpower fit for military service:
males age 16-49: 45,273 (2005 est.)
Manpower reaching military service age
annually:
males: 1 ,720 (2005 est.)
Military - note: defense is the responsibility of the
Kingdom of the Netherlands','ded4f984bfb029343a71280fb76f495e20410b6351fc9e7eef09406e23ae08f9','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('77ca93969adca44c39ea00027e7c9f435ee462102fa5e9fd686cd654e20bb907',2007,'AU','Australia','military-and-security',135,'Military - note: defense is the responsibility of
Australia; periodic visits by the Royal Australian Navy
and Royal Australian Air Force','e7a17ba9ff3c0c781c3db10c6ed24fe4fbfcf45a4dfc1df6a5e0937f16e34f45','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d43230fd9548814fab720141f377060edaa534474aeac28ef0e9067416482896',2007,'ID','Indonesia','military-and-security',147,'Military branches: Australian Defense Force (ADF):
Australian Army, Royal Australian Navy, Royal
Australian Air Force, Special Operations Command
Military service age and obligation: 16 years of
age for voluntary service; women allowed to serve in
Army combat units in non-combat support roles
(2001)
Manpower available for military service:
males age 16-49: 4,943,676 (2005 est.)
Manpower fit for military service:
males age 16-49: 4,092,717 (2005 est.)
Manpower reaching military service age
annually:
males: 142,158 (2005 est.)
Military expenditures - dollar figure: $17.84 billion
(2005 est.)
Military expenditures - percent of GDP: 2.7%
(2005 est.)
Military branches: East Timor Defense Force
(Forcas de Defesa de Timor-L''este, FDTL): Army,
Navy (Armada) (2005)
Military service age and obligation: 18 years of
age for voluntary military service (2001)
Manpower available for military service: NA
Manpower fit for military service:
males age 18-49: NA
Manpower reaching military service age
annually: NA
Military expenditures - dollar figure: $4.4 million
(FY03)
Military expenditures - percent of GDP: NA
Military branches: Papua New Guinea Defense
Force (includes Maritime Operations Element, Air
Operations Element)
Military service age and obligation: 18 years of
age (est.); no conscription (2001)
Manpower available for military service:
males age 18-49: 1 ,264,728 (2005 est.)
Manpower fit for military service:
males age 18-49: 902,432 (2005 est.)
Military expenditures - dollar figure: $16.9 million
(2003)
Military expenditures - percent of GDP: 1 .4%
(FY02)
Military - note: occupied by China
Military branches: Armed Forces of the Philippines
(AFP): Army, Navy (including Marine Corps), Air
Force
Military service age and obligation: 18 years of
age for compulsory and voluntary military service
(2001)
Manpower available for military service:
males age 18-49: 20,131,179 (2005 est.)
Manpower fit for military service:
males age 18-49: 15,170,096 (2005 est.)
Manpower reaching military service age
annually:
males: 907,542 (2005 est.)
Military expenditures - dollar figure: $836.9
million (2005 est.)
Military expenditures • percent of GDP: 0.9%
(2005 est.)
Military - note: defense is the responsibility of the
UK
Military branches: Singapore Armed Forces: Army,
Navy, Air Force, Air Defense (2005)
Military service age and obligation: 1 8 years of
age for compulsory military service; 16 years of age
for volunteers; conscript service obligation reduced to
24 months beginning December 2004 (2004)
Manpower available for military service:
males age 18-49: 1 ,215,568 (2005 est.)
Manpower fit for military service:
males age 18-49: 982,368 (2005 est.)
Military expenditures - dollar figure: $4.47 billion
(FY01 est.)
Military expenditures - percent of GDP: 4.9%
(FY01)','ea37af5f1738ebad8204b77917c5c0924214a39c500552298c37b15d5d773cc6','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aed30dbeb4040e04e1d4d8f2d4e5da9ccec12d5db4f2639b2eb7818f64823406',2007,'DE','Germany','military-and-security',157,'Military branches: Land Forces (KdoLdSK), Air
Forces (KdoLuSK)
Military service age and obligation: 1 8 years of
age for compulsory military service; 16 years of age
for voluntary service; from 2007, at the earliest,
compulsory military service obligation will be reduced
from eight months to six (2005)
Manpower available for military service:
males age 18-49: 1 ,914,800 (2005 est.)
Manpower fit for military service:
males age 18-49: 1 ,550,441 (2005 est.)
Manpower reaching military service age
annually:
males: 48,967 (2005 est.)
Military expenditures - dollar figure: $1 .497 billion
(FY01/02)
Military expenditures - percent of GOP: 0.9%
(2004)
Military branches: Federal Armed Forces
(Bundeswehr): Army (Heer), Navy (Deutsche Marine,
includes naval air arm), Air Force (Luftwaffe), Joint
Support Service, Central Medical Service
Military service age and obligation: 18 years of
age (conscripts serve a nine-month tour of
compulsory military service) (2004)
Manpower available for military service:
males age 18-49: 18,917,537 (2005 est.)
Manpower fit for military service:
males age 18-49: 15,258,931 (2005 est.)
Manpower reaching military service age
annually:
males: 497,048 (2005 est.)
Military expenditures - dollar figure: $35,063
billion (2003)
Military expenditures - percent of GDP: 1 .5%
(2003)
Military branches: Army
Military service age and obligation: a 1967 law
made the Army an all-volunteer force; 1 7 years of age
for voluntary military service; soldiers under 18 are not
deployed into combat or with peacekeeping missions
(2004)
Manpower available for military service:
males age 17-49: 1 10,867 (2005 est.)
Manpower fit for military service:
males age 17-49: 90,279 (2005 est.)
Manpower reaching military service age
annually:
males: 2,775 (2005 est.)
Military expenditures - dollar figure: $231 6
million (2003)
Military expenditures - percent of GDP: 0.9%
(2003)
Military branches: China''s People''s Revolutionary
Army (PLA) constitutes the only armed force in
Macau; several police forces constitute the Security
Forces of Macau (SFM) that are subordinate to the
General Secretariat of Security, a body comparable to
a ministry of interior (2004)
Manpower available for military service:
males age 18-49: 1 12,744 (2005 est.)
Manpower fit for military service:
males age 18-49: 91 ,299 (2005 est.)
Military branches: Army of the Republic of
Macedonia (ARM; includes Joint Operational
Command, with subordinate Air Wing); Special Force
Command (2006)
Military service age and obligation: conscription
to be phased out by 2007; current tour of conscript
duty is six months; 18 years of age for voluntary
military service (2005)
Manpower available for military service:
males age 18-49: 498,259 (2005 est.)
Manpower fit for military service:
males age 18-49: 41 1 ,1 56 (2005 est.)
Manpower reaching military service age
annually:
males: 16,686 (2005 est.)
Military expenditures - dollar figure: $200 million
(FY01/02est.)
Military expenditures - percent of GDP: 6%
(FY01/02 est.)','981a782e54bace3a3a6fb187be2206ebef75a5cb9445dcdf799da1a622cb30b8','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7834c6afe191fb7e80863a3c81a567cf1aa409e26183e223ba34ef4e7d7b8d16',2007,'AZ','Azerbaijan','military-and-security',165,'Military branches: Army, Navy, Air and Air Defense
Forces
Military service age and obligation: 1 8 years of
age for compulsory and voluntary military service; law
passed December 2001 raises maximum conscription
age from 28 to 35 (December 2001)
Manpower available for military service:
males age 18-49: 1 ,961 ,973 (2005 est.)
Manpower fit for military service:
males age 18-49: 1 ,314,955 (2005 est.)
Manpower reaching military service age
annually:
males: 82,358 (2005 est.)
Military expenditures ■ dollar figure: $121 million
(FY99)
Military expenditures - percent of GDP: 2.6%
(FY99)','5f3dd5de1994b695bf1fe2122f0d48e4a806b26ba59848f75879440db8b7bc9c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d9fe4934442703b8b22d64d99f3d3ee11be0aa63246608e9865dbcb4b12dfb76',2007,'BS','Bahamas','military-and-security',174,'Military branches: Royal Bahamaian Defense
Force (naval forces) (2004)
Military service age and obligation: 18 years of
age (est.); no conscription (2001)
Military expenditures - dollar figure: NA
Military expenditures - percent of GDP: NA','d432f649b83d272c6ec571f32356d22e274f9906a832f7d9e2fb5881e10fbc10','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('358a7ae0e9090e293874398c6fe027a3f2bdc0dfa013c4c8b44f0ac5758ff925',2007,'BH','Bahrain','military-and-security',183,'Military branches: Bahrain Defense Forces (BDF):
Ground Force (includes Air Defense), Navy, Air Force,
National Guard
Military service age and obligation: 18 years of
age for voluntary military service (2001)
Manpower available for military service:
males age 18-49: 202,126 (2005 est.)
Manpower fit for military service:
males age 1 8-49: 161,372 (2005 est.)
Manpower reaching military service age
annually:
ma/es: 6,013 (2005 est.)
Military expenditures - dollar figure: $627.7
million (2005 est.)
Military expenditures - percent of GDP: 4.9%
(2005 est.)
Military branches: Qatari Amiri Land Force (QALF),
Qatari Amiri Navy (QAN), Qatari Amiri Air Force
(QAAF)
Military service age and obligation: 18 years of
age for voluntary military service; land forces enlisted
personnel are largely unprofessional foreign nationals
(2005)
Manpower available for military service:
males age 18-49: 302,873
note: includes non-nationals (2005 est.)
Manpower fit for military service:
males age 18-49: 238,566 (2005 est.)
Manpower reaching military service age
annually:
males: 7,851 (2005 est.)
Military expenditures - dollar figure: $723 million
(FY00)
Military expenditures - percent of GDP: 1 0%
(FY00)','0fa80c5f47e18dadbf9876f209ef5e9eaa79bc07e89a1da3189e26ab99281a05','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('911bd1f31a733c9ec0640f1c1e2f283037f431dffce3a6eb8e4de8371e9ddf96',2007,'BD','Bangladesh','military-and-security',194,'Military branches: Army, Navy, Air Force
Military service age and obligation: 18 years of
age for voluntary military service; no conscription
(2005)
Manpower available for military service:
males age 18-49: 35,170,019 (2005 est.)
Manpower fit for military service:
males age 18-49: 26,841 ,255 (2005 est.)
Military expenditures • dollar figure: $1 .01 billion
(2005 est.)
Military expenditures - percent of GDP: 1 .8%
(2005 est.)
Military branches: Royal Barbados Defense Force:
Troops Command and Coast Guard (2005)
Military service age and obligation: 18 years of
age for voluntary military service; volunteers at earlier
age with parental consent; no conscription (2001)
Manpower available for military service:
males age 18-49: 71 ,330 (2005 est.)
Manpower fit for military service:
males age 18-49: 51 ,298 (2005 est.)
Military expenditures - dollar figure: NA
Military expenditures - percent of GDP: NA
Military - note: the Royal Barbados Defense Force
includes a land-based Troop Command and a small
Coast Guard; the primary role of the land element is to
defend the island against external aggression, the
Command consists of a single, part-time battalion with
a small regular cadre that is deployed throughout the
island; it increasingly supports the police in patrolling
the coastline to prevent smuggling and other illicit
activities (2005)
53
Barbados (continued)
Military • note: defense is the responsibility of
Military branches: Royal Bhutan Army (includes
Royal Bodyguard and Royal Bhutan Police) (2005)
Military service age and obligation: 18 years of
age for voluntary military service; no conscription
(2001)
Manpower available for military service:
males age 18-49: 483,860 (2005 est.)
Manpower fit for military service:
males age 18-49: 314,975 (2005 est.)
Manpower reaching military service age
annually:
males: 23,939 (2005 est.)
Military expenditures • dollar figure: $8.29 million
(2005 est.)
Military expenditures - percent of GDP: 1 %
(2005 est.)','08f808b87482afca5662fdf207a9d87b7c679ccd2637fe0663339a2b18838344','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c73d7ed2346248e7bc1196390f8821e54b3267670ba06dea9e081914119f2459',2007,'BE','Belgium','military-and-security',214,'Military branches: Land, Naval, and Air
Components (2005)
Military service age and obligation: 16 years of
age for voluntary military service; women comprise
approx. 7% of the Belgian armed forces (2001)
Manpower available for military service:
males age 16-49: 2,436,736 (2005 est.)
Manpower fit for military service:
males age 16-49: 1,998,003 (2005 est.)
Manpower reaching military service age
annually:
males: 64,263 (2005 est.)
Military expenditures - dollar figure: S3. 999 billion
(2003)
Military expenditures - percent of GDP: 1 .3%
(2003)','6b9f4c07ae231cf761672afc7c63c64d19951b688448472189c30d43f5fe3cbf','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e723c0b094f7631546500fa1a997f7c0cfa75e10bcd43c6b4dfdcf1b100a63b6',2007,'GT','Guatemala','military-and-security',224,'Military branches: Army, Navy, Air Force
Military service age and obligation: 21 years of
age for compulsory and voluntary military service; in
practice, volunteers may be taken at the age of 18;
both sexes are eligible for military service; conscript
tour of duty -18 months (2004)
Manpower available for military service:
males age 21-49: 1,207,071
females age 27-49: 1,216,180 (2005 est.)
64
Benin (continued)
Manpower fit for military service:
males age 21 -49: 670,170
females age 21-49: 630,078 (2005 est.)
Manpower reaching military service age
annually:
males: 72,841
females: 71,428 (2005 est.)
Military expenditures - dollar figure: $1 00.9
million (2005 est.)
Military expenditures - percent of GDP: 2.3%
(2005 est.)
Military branches: Army, Navy (includes Marines),
Air Force
Military service age and obligation: all male
citizens between the ages of 18 and 50 are liable for
military service; conscript service obligation varies
from 12 to 24 months (2005)
Manpower available for military service:
males age 18-49: 3,020,292 (2005 est.)
Manpower fit for military service:
males age 18-49: 2,106,847 (2005 est.)
Manpower reaching military service age
annually:
males: 161 ,964 (2005 est.)
Military expenditures - dollar figure: $169.8
million (2005 est.)
Military expenditures - percent of GDP: 0.5%
(2005 est.)','0e387d3f793c4bd62c4b0bf296a3ffe35dc11df6dbf49398021cb852f8538b1c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb5eebf4a406b0f8d90a8657e3d63b829790609dd209b8801694fed5a62f432e',2007,'BM','Bermuda','military-and-security',233,'Military branches: Bermuda Regiment
Military expenditures - dollar figure: $4.03 million
(2001)
Military expenditures - percent of GDP: 0.1 1%
(FY00/01)
Military - note: defense is the responsibility of the
UK','5775cd2df334267ab08ce3b3bffbe03db2a6fc936f86ddc84d95d14bedf019aa','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d71ecc50bfd44997326c2eb93e8e4f17b49c6e2608394513844bac0d373f7ed9',2007,'PY','Paraguay','military-and-security',241,'Military branches: Army (Ejercito Boliviano), Navy
(Fuerza Naval; includes Marines), Air Force (Fuerza
Aerea Boliviana) (2004)
Military service age and obligation: 18 years of
age for voluntary military service; when annual
number of volunteers falls short of goal, compulsory
recruitment is effected, including conscription of boys
as young as 14; one estimate holds that 40% of the
armed forces are under the age of 1 8, with 50% of
those under the age of 16; conscript tour of duty - 12
months (2002)
Manpower available for military service:
males age 18-49: 1 ,923,234 (2005 est.)
Manpower fit for military service:
males age 18-49: 1 ,31 1 ,414 (2005 est.)
Manpower reaching military service age
annually:
males: 101, 101 (2005 est.)
Military expenditures - dollar figure: $1 30 million
(2005 est.)
Military expenditures - percent of GDP: 1 .4%
(2005 est.)
Military branches: VF Army (the air and air defense
forces are subordinate commands within the Army),
VRS Army (the air and air defense forces are
subordinate commands within the Army)
Military service age and obligation: 18 years of
age for compulsory military service in the Federation
of Bosnia and Herzegovina; 16 years of age in times
of war; 1 8 years of age for Republika Srpska; 1 7 years
of age for voluntary military service in the Federation
and in the Republika Srpska; by law, military
obligations cover all healthy men between the ages of
1 8 and 60, and all women between the ages of 1 8 and
55; service obligation is four months (July 2004)
Manpower available for military service:
males age 18-49: 1 ,034,367 (2005 est.)
Manpower fit for military service:
males age 18-49: 829,530 (2005 est.)
Manpower reaching military service age
annually:
males: 31 ,264 (2005 est.)
Military expenditures - dollar figure: $234.3
million (FY02)
Military expenditures - percent of GDP: 4.5%
(FY02)','4187f2c6a78e9ae03d439defe92b7220c24e40fbfda8f316b83c5d7097fd9246','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cac69dbc4edf77559548c591e93608cdc289d0334e92729e7053fdff83b909a',2007,'BW','Botswana','military-and-security',256,'Military branches: Botswana Defense Force
(includes an Air Wing)
Military service age and obligation: 18 is the
apparent age of voluntary military service; the official
qualifications for determining minimum age are
unknown (2001)
Manpower available for military service:
males age 18-49: 350,649 (2005 est.)
Manpower fit for military service:
males age 18-49: 136,322 (2005 est.)
Manpower reaching military service age
annually:
males: 21,103 (2005 est.)
Military expenditures - dollar figure: $325.5
million (2005 est.)
Military expenditures - percent of GDP: 3.4%
(2005 est.)','223073dab7909e843ef3c0e2bc1cc2aa128d4081aa8dc2c37539f2f95665f2f4','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7bed1bb8bd9f172650ac6bbd5a45f3c74c878004875197292d3b769b5df448b',2007,'NO','Norway','military-and-security',263,'note:
defense is the responsibility of
Tr!
i n s
national Issues
Disputes - international: none
NORTH ATLANTIC
OCEAN
Sao Luis
FortaTeza>
Teresina*
Salvador
Natal.
Recife^
Macei6*
PACIFIC
OCEAN
Honzonte fubarao
Sao *Vit6ria
Paulo .R''° de Janeir0
%San''to7k?eP6tib?
Terminal
SOUTH ATLANTIC
OCEAN
Military - note: defense is the responsibility of the
UK; the US lease on Diego Garcia expires in 2016
UK
note:
defense is the responsibility of the
T r a n s n a t i
o n a I
Issues
Disputes - international: none
Illicit drugs: transshipment point for South American
narcotics destined for the US and Europe; large
offshore financial center makes it vulnerable to money
laundering
BANDAR Muara _
South China
"^ Bay SOO''-
note:
defense is the responsibility of
Transnational
Issues
Sea of
Military branches: Norwegian Army (Haeren),
Royal Norwegian Navy (Kongelige Norske
Sjoeforsvaret, RNoN; includes Coastal Rangers and
Coast Guard (Kystvakt)), Royal Norwegian Air Force
(Kongelige Norske Luftforsvaret, RNoAF), Home
Guard (Heimevernet, HV) (2006)
Military service age and obligation: 18 years of
age for compulsory military service; 1 6 years of age in
wartime; 1 7 years of age for male volunteers; 1 8 years
of age for women; 1 6 years of age for volunteers to the
Home Guard; conscript service obligation - 12 months
(2004)
Manpower available for military service:
males age 18-49: 1 ,014,592 (2005 est.)
Manpower fit for military service:
males age 18-49: 827,016 (2005 est.)
Manpower reaching military service age
annually:
males: 29, 179 (2005 est.)
Military expenditures - dollar figure: $4,033.5
million (2003)
Military expenditures - percent of GDP: 1 .9%
(2003)','f6dc7ee609e32ce95ba367a2aa14c159b2b26e79c4d7e0b51f19792d90f2d696','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ead0debc5b7a6ad4ac133e653b0ca898033097bb4b60486874837da5e1210118',2007,'MY','Malaysia','military-and-security',279,'Military branches: Royal Brunei Armed Forces:
Royal Brunei Land Forces, Royal Brunei Navy, Royal
Brunei Air Force (Tentera Udara Diraja Brunei) (2005)
Military service age and obligation: 18 years of
age (est.) (2004)
Manpower available for military service:
males age 18-49: 103,885 (2005 est.)
Manpower fit for military service:
males age 18-49: approx. 85,045 (2005 est.)
Manpower reaching military service age
annually:
males: 3,478 (2005 est.)
Military expenditures • dollar figure: $290.7
million (2003 est.)
Military expenditures - percent of GDP: 5.1%
(2003 est.)
Military branches: Royal Thai Army, Royal Thai
Navy (includes Royal Thai Marine Corps), Royal Thai
Air Force
Military service age and obligation: 21 years of
age for compulsory military service; males are
registered at 1 8 years of age; conscript service
obligation - two years; 1 8 years of age for voluntary
military service (2004)
Manpower available for military service:
males age 21-49: 14.984 million (2005 est.)
Manpower fit for military service:
males age 21-49: 10,342,337 (2005 est.)
Manpower reaching military service age
annually:
males: 530,493 (2005 est.)
547
Thailand (continued)
Military expenditures - dollar figure: $1 .775 billion
(FYOO)
Military expenditures - percent of GDP: 1 .8%
(2003)
Military branches: Togolese Armed Forces (FAT):
Army, Navy, Air Force, Gendarmerie (2005)
Military service age and obligation: 18 years of
age for voluntary and compulsory military service
(2001)
Manpower available for military service:
males age 18-49: 1 .148,890 (2005 est.)
Manpower fit for military service:
males age 18-49: 629,933 (2005 est.)
Military expenditures - dollar figure: $29.98
million (2005 est.)
Military expenditures - percent of GDP: 1 .6%
(2005 est.)','c615cfab9d2aaf674a52d34bfc0595ff3689399700eefe2be0bf78605ce56cdc','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9922b76a3339e7217a9fffb6f66a0adbd97f46e97e5febc16678518f9f2be281',2007,'BG','Bulgaria','military-and-security',288,'Military branches: Ground Forces, Naval Forces,
Air and Air Defense Forces
Military service age and obligation: 1 8 years of
age for compulsory and voluntary military service;
conscript service obligation - 9 months; plans call for
fully professionalizing the army by the end of 2007
when conscription will terminate; air force and navy
will become fully professional by end of 2006 (2005)
Manpower available for military service:
males age 18-49: 1 ,661 ,21 1 (2005 est.)
Manpower fit for military service:
males age 18-49: 1 ,302,037 (2005 est.)
Manpower reaching military service age
annually:
males: 51,023 (2005 est.)
Military expenditures - dollar figure: $356 million
(FY02)
Military expenditures - percent of GDP: 2.6%
(2003)','6d45b561da2d1c5c1a03b04c7284e6df14cbbfebb319fb8c8bb5c10b5f341e0c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d2f244b0e0abaf44877d416e8321364812ad3b326e15c0428b95c6913dfa6a1',2007,'TH','Thailand','military-and-security',306,'Military branches: Myanmar Armed Forces
(Tatmadaw): Army, Navy, Air Force (2005)
Military service age and obligation: 18 years of
age for voluntary military service for both sexes
(May 2002)
Manpower available for military service:
males age 18-49: 11,254,374
females age 18-49: 1 1 ,303,100 (2005 est.)
Manpower fit for military service:
males age 18-49: 6,51 2,923
females age 18-49: 6,789,720 (2005 est.)
Manpower reaching military service age
annually:
males: 440,914
females: 427,382 (2005 est.)
Military expenditures - dollar figure: $39 million
(FY97)
Military expenditures - percent of GDP: 21%
(FY97)
Military branches: Indonesia Armed Forces
(Tentara Nasional Indonesia, TNI): Army (TNI-AD),
Navy (TNI-AL, includes Marines, naval air arm), Air
Force (TNI-AU)
note: The TNI is directly subordinate to the president
but the government is making efforts to incorporate it
into the Department of Defense
Military service age and obligation: 18 years of
age for compulsory and voluntary military service;
conscript service obligation - two years (2002)
Manpower available for military service:
males age 18-49: 60,543,028 (2005 est.)
Manpower fit for military service:
males age 18-49: 48,687,234 (2005 est.)
Manpower reaching military service age
annually:
males: 2,201 ,047 (2005 est.)
Military expenditures - dollar figure: $1 .3 billion
(2004)
Military expenditures - percent of GDP: 3%
(2004)
Military branches: Islamic Republic of Iran Regular
Forces (Artesh): Ground Forces, Navy, Air Force
(includes Air Defense); Islamic Revolutionary Guard
Corps (Sepah-e Pasdaran-e Enqelab-e Eslami,
IRGC): Ground Forces, Navy, Air Force, Qods Force
(special operations), and Basij Force (Popular
Mobilization Army); Law Enforcement Forces (2004)
Military service age and obligation: 18 years of
age for compulsory military service; 16 years of age
for volunteers; soldiers as young as 9 were recruited
extensively during the Iran-Iraq War; conscript service
obligation - 18 months (2004)
Manpower available for military service:
males age 18-49: 18,319,545 (2005 est.)
Manpower fit for military service:
males age 18-49: 15,665,725 (2005 est.)
Manpower reaching military service age
annually:
males: 862,056 (2005 est.)
Military expenditures - dollar figure: $4.3 billion
(2003 est.)
Military expenditures - percent of GDP: 3.3%
(2003 est.)
Military branches: Iraqi Armed Forces: Iraqi
Regular Army (includes Iraqi Special Operations
Force, Iraqi Intervention Force), Iraqi Navy (former
Iraqi Coastal Defense Force), Iraqi Air Force (former
Iraqi Army Air Corps) (2005)
Military service age and obligation: 1 8 years of
age; the Iraqi Interim Government is creating a new
professional Iraqi military force of men aged 18 to 40
to defend Iraq from external threats and the current
insurgency (2004)
Manpower available for military service:
males age 18-49: 5,870,640 (2005 est.)
Manpower fit for military service:
males age 18-49: 4,930,074 (2005 est.)
Manpower reaching military service age
annually:
males: 298,51 8 (2005 est.)
Military expenditures - dollar figure: $1 .34 billion
(2005 est.)
Military expenditures • percent of GDP: NA
Military branches: People''s Army of Vietnam
(PAVN): Ground Forces, People''s Navy Command
(including Naval Infantry), Air and Air Defense Force,
Coast Guard
Military service age and obligation: 1 8 years of
age for compulsory military service; conscript service
obligation - two years (three-four years in the navy)
(2004)
Manpower available for military service:
males age 18-49: 21 ,341 ,813 (2005 est.)
Manpower fit for military service:
males age 18-49: 16,032,358 (2005 est.)
602
Vietnam (continued)
Manpower reaching military service age
annually:
males: 915,572 (2005 est.)
Military expenditures - dollar figure: $650 million
(FY98)
Military expenditures - percent of GDP: 2.5%
(FY98)
Military - note: defense is the responsibility of the
US','d0ade9f383b34a15f7e35c48e60621ed58873da2b2c105dc6cd7e03a991061c5','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21aa4ec8457138b6eb643d128f9502ea082cd15917eff997944be05866d4d6b0',2007,'CG','Congo','military-and-security',315,'Military branches: National Defense Force (Forces
de Defense Nationales, FDN): Army (includes Naval
Detachment and Air Wing), National Gendarmerie
(disbanding begun in 2004) (2005)
Military service age and obligation: 16 years of
age for compulsory and voluntary military service
(2001)
Manpower available for military service:
males age 16-49: 1 ,379,793 (2005 est.)
Manpower fit for military service:
males age 16-49: 693,956 (2005 est.)
Manpower reaching military service age
annually:
males: 84,597 (2005 est.)
Military expenditures - dollar figure: $43.9 million
(2005 est.)
Military expenditures - percent of GDP: 5.6%
(2005 est.)
96
Burundi (continued)
Military branches: Royal Cambodian Armed
Forces: Army, Royal Khmer Navy, Royal Cambodian
Air Force (2005)
Military service age and obligation: 1 8-30 years of
age for compulsory military service for all males;
conscription law passed September 2004; service
obligation is 18 months (September 2004)
Manpower available for military service:
males age 18-49: 2,981 ,823 (2005 est.)
Manpower fit for military service:
males age 18-49: 1,844,144 (2005 est )
Manpower reaching military service age
annually:
males: 175,305 (2005 est.)
Military expenditures - dollar figure: $112 million
(FY01 est.)
Military expenditures - percent of GDP:
(FY01 est.)
99
Cambodia (continued)
Military branches: Central African Armed Forces
(FACA): Ground Forces, Air Force; General
Directorate of Gendarmerie Inspection (DGIG),
Republican Guard (2004)
Military service age and obligation: 1 8 years of
age for voluntary and compulsory military service;
conscript service obligation is two years (2005)
Manpower available for military service:
males age 18-49: 758,103 (2005 est.)
Manpower fit for military service:
males age 18-49: 330,255 (2005 est.)
Military expenditures - dollar figure: $16.37
million (2005 est.)
Military expenditures - percent of GDP: 1%
(2005 est.)
Military branches: Army, Navy, Air Force
Manpower available for military service:
males age 18-49: 1 1 ,052,696 (2005 est.)
Manpower fit for military service:
males age 18-49: 5,851 ,292 (2005 est.)
Military expenditures - dollar figure: $103.7
million (2005 est.)
Military expenditures - percent of GDP: 1 .5%
(2005 est.)
Military branches: Congolese Armed Forces (FAC):
Army, Air Force (Armee de I''Air Congolaise), Navy,
Gendarmerie, Republican Guard (2005)
Military service age and obligation: 18 years of
age for voluntary military service (2001)
Manpower available for military service:
males age 18-49: 686,123 (2005 est.)
Manpower fit for military service:
males age 18-49: 360,492 (2005 est.)
Manpower reaching military service age
annually:
males: 34,281 (2005 est.)
Military expenditures - dollar figure: $85.22
million (2005 est.)
Military expenditures • percent of GDP: 1 .4%
(2005 est.)','b64baf5768f9b36d91d4556dc1c6c90b7827c68c310ab69e7bd184b59a7747eb','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8ccbd578cb5646ee7834f2999c7dc053ee2a0f0e03048e229e449a9b23b6ef5',2007,'CM','Cameroon','military-and-security',323,'Military branches: Cameroon Armed Forces: Army,
Navy (includes Naval Infantry), Air Force (Armee de
I''Air du Cameroun, AAC) (2006)
Military service age and obligation: 18 years of
age for voluntary military service; no conscription
(1999)
Manpower available for military service:
males age 18-49: 3,410,440 (2005 est.)
Manpower fit for military service:
males age 18-49: 1 ,720,385 (2005 est.)
Manpower reaching military service age
annually:
males: 188,662 (2005 est.)
Military expenditures - dollar figure: $230.2
million (2005 est.)
Military expenditures - percent of GDP: 1 5%
(2005 est.)
''. EQUATORIAL','28a3228cbfdf7de3013d72e15fdd94ebea85c3352985d96d18e853b321ee9887','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5795dbbb9c34c6d47ba7266a56667834403dccea0439617fd080e8ee31d1e23',2007,'CA','Canada','military-and-security',333,'Military branches: Canadian Forces: Land Forces
Command, Maritime Command, Air Command,
Canada Command (homeland security) (2006)
Military service age and obligation: 16 years of
age for voluntary military service; women comprise
approximately i 1% of Canada''s armed forces (2001 )
Manpower available for military service:
males age 16-49: 8,216,510 (2005 est.)
Manpower fit for military service:
males age 16-49: 6,740,490 (2005 est.)
Manpower reaching military service age
annually:
males: 223,821 (2005 est.)
Military expenditures - dollar figure: S9.801 .7
million (2003)
Military expenditures - percent of GDP: 1.1%
(2003)','6aeed769369e57289c8d9fb598bd259bf0c3f04615015c32e7979a40b536695a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48e20d491c26f17018d6bd6d4c45b986ed28594867863f2aa50660e84f5390a1',2007,'PT','Portugal','military-and-security',338,'Military branches: People''s Revolutionary Armed
Forces (FARP): Army, Coast Guard (includes
maritime air wing)
Manpower available for military service:
males age 78-49:84,641 (2005 est.)
Manpower fit for military service:
males age 18-49: 65,614 (2005 est.)
Military expenditures - dollar figure: $7.18 million
(2005 est.)
Military expenditures - percent of GDP: 0.7%
(2005 est.)
Military branches: Army, Navy (Marinha
Portuguesa; includes Marine Corps), Air Force (Forca
Aerea Portuguesa, FAP), National Republican Guard
(Guarda Nacional Republicana) (2005)
Military service age and obligation: 18 years of
age for voluntary military service; compulsory military
service was ended in 2004; women serve in the armed
forces, on naval ships since 1993, but are prohibited
from serving in some combatant specialties (2005)
Manpower available for military service:
males age 18-49: 2,435,042 (2005 est.)
Manpower fit for military service:
males age 75-49: 1,952,819 (2005 est.)
Manpower reaching military service age
annually:
males: 67,189 (2005 est.)
Military expenditures - dollar figure: $3,497.8
million (2003)
Military expenditures - percent of GDP: 2.3%
(2003)','7dde839b39356e11809fb8b4b8c90f43611e52b037b7e3d04d3a610d6df2ca46','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45ace550a7024a2de253e162daf0d89b658e15eb91f60f62fe9464fb16631baf',2007,'JM','Jamaica','military-and-security',349,'Military branches: no regular military forces; Royal
Cayman Islands Police Force
Military - note: defense is the responsibility of the
UK
Military branches: Jamaica Defense Force: Ground
Forces, Coast Guard, Air Wing
Military service age and obligation: 1 8 years of
age for voluntary military service; younger recruits
may be conscripted with parental consent (2001)
Manpower available for military service:
males age 18-49: 696,900 (2005 est.)
Manpower fit for military service:
males age 18-49: 587,006 (2005 est.)
Manpower reaching military service age
annually:
males: 26,080 (2005 est.)
Military expenditures - dollar figure: $31.17
million (2003 est.)
Military expenditures - percent of GDP: 0.4%
(2003 est.)','0d4c015807bc36b8b0ea2800d70277776d35bc6445bf8ac98c29a79e6df9359b','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e7af74d3d08ad73b34457531445f6e3cd905d5c900abbc76d4703a450494fd1d',2007,'LY','Libya','military-and-security',360,'Military branches: Chadian National Army (Armee
Nationale Tchadienne, ANT), Air Force, Gendarmerie
(2004)
Military service age and obligation: 20 years of
age for conscripts, with three-year service obligation;
18 years of age for volunteers; no minimum age
restriction for volunteers with consent from a guardian;
women are subject to one year of compulsory military
or civic service at age of 21 (2004)
Manpower available for military service:
males age 20-49: 1 ,559,382 (2005 est.)
114
Chad (continued)
Manpower fit for military service:
males age 20-49: 834,695 (2005 est.)
Manpower reaching military service age
annually:
males: 95,228 (2005 est.)
Military expenditures - dollar figure: $68.95
million (2005 est.)
Military expenditures - percent of GDP: 1%
(2005 est.)','6b0fccc9aa17a17a5bb112f665d23b97200836d62032855719915ac5373a1783','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e0a175d3d01bc483fe96c831e3df8249ac972501f3be850b341fbad5f3629a50',2007,'CN','China','military-and-security',361,'(also see separate Hong Kong, Macau, and Taiwan entries)
Military branches: People''s Liberation Army (PLA):
Ground Forces, Navy (includes marines and naval
aviation), Air Force (includes Airborne Forces), and II
Artillery Corps (strategic missile force); People''s
Armed Police (PAP); Reserve and Militia Forces
(2006)
Military service age and obligation: 1 8-22 years of
age for compulsory military service, with 24-month
service obligation; no minimum age for voluntary
service (all officers are volunteers); 1 7 years of age for
women who meet requirements for specific military
jobs (2004)
Manpower available for military service:
males age 18-49: 342,956,265 (2005 est.)
Manpower fit for military service:
males age 18-49: 281 ,240,272 (2005 est.)
Manpower reaching military service age
annually:
males: 13,186,433 (2005 est.)
Military expenditures - dollar figure: $81 .48 billion
(2005 est.)
Military expenditures - percent of GDP: 4.3%
(2005 est.)
Military branches: no regular indigenous military
forces; Hong Kong garrison of China''s People''s
Liberation Army (PLA) includes elements of the PLA
Ground Forces, PLA Navy, and PLA Air Force; these
forces are under the direct leadership of the Central
Military Commission in Beijing and under
administrative control of the adjacent Guangzhou
Military Region
Military service age and obligation: 18 years of
age (2004)
Manpower available for military service:
males age 18-49: 1 ,743,972 (2005 est.)
Manpower fit for military service:
males age 18-49: 1 ,403,088 (2005 est.)
Manpower reaching military service age
annually:
males: 40,343 (2005 est.)
Military expenditures - dollar figure: Hong Kong
garrison is funded by China; figures are NA
Military expenditures - percent of GDP: NA
Military • note: defense is the responsibility of China
O 100 200 km
m 0 100 200 mi
Military branches: Army, Air Force, National Guard
(2004)
Military service age and obligation: 18 years of
age for compulsory military service (2001 )
Manpower available for military service:
males age 18-49: 1 ,193,529 (2005 est.)
Manpower fit for military service:
males age 18-49: 871 ,493 (2005 est.)
Manpower reaching military service age
annually:
males: 61 ,091 (2005 est.)
Military expenditures • dollar figure: $19.2 million
(FY01)
Military expenditures • percent of GDP: 1 .4%
(FY01)','1c76f73a51caa587f1eddb074a21fa35582bdae291f71b66d2c308a1e910a537','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecddb7bb75d0c649a694327415ae79f877a9f68e75f38abb5af0b55e5170db25',2007,'FR','France','military-and-security',387,'Military - note: defense is the responsibility of
Australia; the territory has a five-person police force
Military branches: no regular military forces
Military expenditures - dollar figure: NA
Military expenditures - percent of GDP: NA
Military - note: defense is the responsibility of the
UK
Military branches: no regular military forces;
Gendarmerie
Manpower available for military service:
males age 18-49: 47,809 (2005 est.)
Manpower fit for military service:
males age 18-49: 38,676 (2005 est.)
Military expenditures • dollar figure: NA
Military expenditures - percent of GDP: NA
Military - note: defense is the responsibility of
note:
defense is the
responsibility of
T r a n s n a t
i o n a
1 Issues
Disputes - international: French claim to "Adelie
Land" in Antarctica is not recognized by the US
204
s
Military branches: no regular military forces
Military - note: defense is the responsibility of
note:
defense is the
responsibility of
T r a n s n a t
i o n a
Issues
Disputes - international: claimed by Madagascar
Military branches: no regular indigenous military
forces; French forces (includes Army. Navy, Air Force,
and Gendarmerie) (2005)
Military service age and obligation: 1 8 years of
age (2004)
Manpower available for military service:
males age 1 8-49: 183,421 (2005 est.)
Manpower fit for military service:
males age 18-49: 142,578 (2005 est.)
Manpower reaching military service age
annually:
males: 7,339 (2005 est.)
Military - note: defense is the responsibility of
defense is the responsibility of
Military branches: Army, Navy, Air Force (2003)
Military service age and obligation: 20 years of
age for compulsory military service; conscript service
obligation - 12 months; 18 years of age for voluntary
military service (2004)
Manpower available for military service:
males age 20-49: 2,441 ,741 (2005 est.)
Manpower fit for military service:
males age 20-49: 2,035,431 (2005 est.)
Manpower reaching military service age
annually:
males: 108,817 (2005 est.)
Military expenditures - dollar figure: $356 million
(FY99)
Military expenditures - percent of GDP: 1 .5%
(FY99)
Military branches: Turkish Armed Forces (TSK):
Land Forces, Naval Forces (includes Naval Air and
Naval Infantry), Air Force
Military service age and obligation: 20 years of
age (2004)
Manpower available for military service:
males age 20-49: 16,756,323 (2005 est.)
Manpower fit for military service:
males age 20-49: 13,905,901 (2005 est.)
562
Turkey (continued)
Manpower reaching military service age
annually:
males: 679,734 (2005 est.)
Military expenditures - dollar figure: $12,155
billion (2003)
Military expenditures - percent of GDP: 5.3%
(2003)
Military - note: in the early 1990s, the Turkish Land
Force was a large but badly equipped infantry force;
there were 14 infantry divisions, but only one was
mechanized, and out of 16 infantry brigades, only six
were mechanized; the overhaul that has taken place
since has produced highly mobile forces with greatly
enhanced firepower in accordance with NATO''s new
strategic concept (2005)
100 m','4d2712ffd52259fcd8301fa16d890255f3a79dd9f8b7806188a8ea4f3f92b167','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('423ded3ba0e405af403f8a5743bf05773756d8d49932549ad6bfba5d9d1c1cde',2007,'CO','Colombia','military-and-security',396,'Military branches: Army (Ejercito Nacional). Navy
(Armada Nacional, includes Naval Aviation, Marines,
and Coast Guard), Air Force (Fuerza Aerea
Colombiana)
Military service age and obligation: 1 8 years of
age for compulsory and voluntary military service;
conscript service obligation - 24 months (2004)
Manpower available for military service:
males age 18-49: 10,212,456 (2005 est.)
Manpower fit for military service:
males age 18-49: 6,986,228 (2005 est.)
Manpower reaching military service age
annually:
males: 389,735 (2005 est.)
Military expenditures - dollar figure: S3. 3 billion
(FY01)
Military expenditures - percent of GDP: 3.4%
(FY01)','b8db684f481bf85369df517101fbc591253b1d84e25318157d0b94dedeb5b31b','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70863ffddc4afd4f959133cd4a79c0bfe00006be46f02f3bcf4458ace6514122',2007,'YT','Mayotte','military-and-security',405,'Military branches: Comoran Security Force
Manpower available for military service:
males age 18-49: 138,940 (2005 est.)
Manpower fit for military service:
males age 18-49: 98792 (2005 est.)
Military expenditures - dollar figure: $12.87
million (2005 est.)
Military expenditures - percent of GDP: 3%
(2005 est.)
Military - note: defense is the responsibility of
France; small contingent of French forces stationed
on the island','fd46574f9fb39c540645b9ba6bc0cbceb820458155766f4290f49c194ba657eb','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b54c0041c67a7a6b36cbbab7a2c1cec743119ffd9f3caa7bc736b4226595fcc5',2007,'CK','Cook Islands','military-and-security',416,'Military branches: no regular military forces;
Ministry of Police and Disaster Management (2004)
Military • note: defense is the responsibility of New
Zealand, in consultation with the Cook Islands and at
its request
Military - note: defense is the responsibility of
Australia; visited regularly by the Royal Australian
Navy; Australia has control over the activities of
visitors
Military - note: defense is the responsibility of the
US','3a5dc11467c4b6780c5abe18b6943404ad73082daba23bd54791dffe1bd21c1d','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d1d52154f33d2e6eba2245df4f0aefd93862f9fa21ddcdeae90e37f3b2027f55',2007,'CR','Costa Rica','military-and-security',425,'Military branches: no regular military forces;
Ministry of Public Security, Government, and Police
Military service age and obligation: 1 8 years of
age (2004)
Manpower available for military service:
males age 18-49: 997.690 (2005 est.)
Manpower fit for military service:
males age 18-49: 829,874 (2005 est.)
Manpower reaching military service age
annually:
males: 41,097 (2005 est.)
Military expenditures - dollar figure: $83.46
million (2005 est.)
Military expenditures - percent of GDP: 0.4%
(2005 est.)
Military branches: Army, Navy, Air Force
Military service age and obligation: 18 years of
age for compulsory and voluntary military service;
conscript service obligation - 18 months (2004)
Manpower available for military service:
males age 18-49: 3,696,106 (2005 est.)
Manpower fit for military service:
males age 18-49: 1 ,973,265 (2005 est.)
Manpower reaching military service age
annually:
males: 189,354 (2005 est.)
Military expenditures - dollar figure: $246.6
million (2005 est.)
Military expenditures - percent of GDP: 1 .6%
(2005 est.)
Military branches: Army (includes Navy, Air Force)
Military service age and obligation: 1 7 years of
age for voluntary military service (2001 )
Manpower available for military service:
males age 17-49: 1 ,309,970 (2005 est.)
Manpower fit for military service:
males age 17-49: 1 ,051 ,425 (2005 est.)
Manpower reaching military service age
annually:
males: 65,170 (2005 est.)
Military expenditures - dollar figure: $32.27
million (2005 est.)
Military expenditures - percent of GDP: 0.7%
(2005 est.)','41e073c569bf319d74423f8f4766e9346bf9e02e99dfb66a8aa95db42f0e62b2','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a4c7c0a569f7101ae700b17add779c8d30418a9d01610e967285759d8be791e',2007,'SI','Slovenia','military-and-security',434,'Military branches: Ground Forces (Hrvatska
Kopnena Vojska, HKoV), Naval Forces (Hrvatska
Ratna Mornarica, HRM), Air and Air Defense Forces
(Hrvatsko Ratno Zrakoplovstvo i Protuzrakoplovna
Obrana, HRZiPZO), Joint Education and Training
Command, Logistics Command; Military Police Force
supports each of the three Croatian military forces
(2006)
Military service age and obligation: 1 8 years of
age for compulsory military service, with six-month
service obligation; 16 years of age with consent for
voluntary service (December 2004)
Manpower available for military service:
males age 75-49; 1,005,058 (2005 est.)
Manpower fit for military service:
males age 18-49- 725,914 (2005 est.)
Manpower reaching military service age
annually:
males: 29,020 (2005 est.)
Military expenditures • dollar figure: $620 million
(2004)
Military expenditures - percent of GDP: 2.39%
(2002 est.)','ed9debdca0ab74acd6aaec560a3948cebd674db1cfbdb0ffcacfd390622674fa','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3ef39f2881b58dedf61d3cfa092135a2af0234eb3ad026eed6e8ff52e9a932c',2007,'HT','Haiti','military-and-security',445,'Military branches: Revolutionary Armed Forces
(FAR): Revolutionary Army (ER), Revolutionary Navy
(MGR), Air and Air Defense Force (DAAFAR),
Territorial Militia Troops (MTT), Youth Labor Army
(EJT)
Military service age and obligation: 17 years of
age; both sexes are eligible for military service (2004)
Manpower available for military service:
males age 1 7-49: 2,967,865
females age 17-49: 2,913,559 (2005 est.)
Manpower fit for military service:
males age 77-49:2,441,927
females age 77-49:2,396,741 (2005 est.)
Manpower reaching military service age
annually:
males: 91,901
females: 87,500 (2005 est.)
Military expenditures - dollar figure: $694 million
(2005 est.)
Military expenditures - percent of GDP: 1 .8%
(2005 est.)
Military - note: Moscow, for decades the key military
supporter and supplier of Cuba, cut off almost all
military aid by 1993
Military branches: Army, Navy, Air Force
Military service age and obligation: 18 years of
age for voluntary military service (2001)
Manpower available for military service:
males age 18-49: 2,108,197 (2005 est.)
Manpower fit for military service:
males age 18-49: 1 ,420,693 (2005 est.)
Manpower reaching military service age
annually:
males: 91 ,597 (2005 est.)
164
Dominican Republic (continued)
Military expenditures - dollar figure: $0
(2002 est.)
Military expenditures - percent of GDP: 0%
(2002 est.)
Military branches: the regular Haitian Armed
Forces (FAdH) - Army, Navy, and Air Force - have
been demobilized but still exist on paper unless they
are constitutionally abolished
Military service age and obligation: 18 years of
age for voluntary recruitment into the police force
(2001)
Manpower available for military service:
males age 18-49: 1 ,626,491 (2005 est.)
Manpower fit for military service:
males age 18-49: 948,320 (2005 est.)
Manpower reaching military service age
annually:
males: 98,554 (2005 est.)
Military expenditures - dollar figure: $25.96
million (2003 est.)
Military expenditures - percent of GDP: 0.9%
(2003 est.)','a963b68771e0fa6fa2d0395e7a3d04f16c24a2b9b0cc49bf8cb5e22e6dc550ec','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aed3f32be40a730ff1e5a6291fa3257996848b0b2abd9691dc9a391012515e1c',2007,'CY','Cyprus','military-and-security',454,'Military branches: Army of the Czech Republic
(ACR): Joint Forces Command, Support and Training
Forces Command (2005)
Military service age and obligation: 1 8-50 years of
age for voluntary military service; on-going
transformation of military service into a fully
professional, all-volunteer force no longer dependent
on conscription began in January 2004 and is
scheduled to be completed by 2007 (2005)
Manpower available for military service:
males age 18-49: 2,414,728 (2005 est.)
Manpower fit for military service:
males age 78-49; 1 ,996.631 (2005 est.)
Manpower reaching military service age
annually:
males: 66,583 (2005 est.)
Military expenditures - dollar figure: $2.17 billion
(2004)
Military expenditures - percent of GDP: 1 .81 %
FY05','7b5449e075e9d50de453d3500e6283c14910d7a605cccbf21304a68f99c2cf22','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b72c2fdb4c0cecea6741ddb52a5accdfef7b51bd355261b4a8082aad4c68d9d2',2007,'DK','Denmark','military-and-security',462,'Military branches: Defense Command: Army
Operational Command, Admiral Danish Fleet, Tactical
Air Command, Home Guard (Hjemmevaernet) (2005)
Military service age and obligation: 18 years of
age for compulsory and volunteer military service;
conscripts serve an initial training period that varies
from four to 12 months according to specialization;
reservists are assigned to mobilization units following
completion of their conscript service; women eligible
to volunteer for military service (2004)
Manpower available for military service:
males age 18-49: 1 ,175,108 (2005 est.)
Manpower fit for military service:
males age 18-49: 955,168 (2005 est.)
Manpower reaching military service age
annually:
males: 31 ,31 7 (2005 est.)
Military expenditures - dollar figure: $3,271 .6
million (2003)
Military expenditures • percent of GDP: 1 .5%
(2004)
Military ■ note: includes Dheklia Garrison and Ayios
Nikolaos Station connected by a roadway','d62c014beba23cbbb5c96eb6fbb956b5c98cf341fcf35076b0200b44a5b7eee8','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('15d197d0927361862efffedbf397a1f5d647984dac407b09e1c9d551ae6bba0c',2007,'DJ','Djibouti','military-and-security',471,'Military branches: Djibouti National Army (includes
Navy and Air Force)
Military service age and obligation: 18 years of
age (est.); no conscription (2001)
Manpower available for military service:
males age 18-49: 95,328 (2005 est.)
Manpower fit for military service:
males age 18-49: 46,020 (2005 est.)
Military expenditures - dollar figure: 829.05
million (2005 est.)
Military expenditures - percent of GDP: 4.3%
(2005 est.)
Military branches: Army (includes Special Forces),
Naval Forces and Coastal Defenses (includes
Marines), Air Force (includes Air Defense Forces),
Republican Guard (2002)
Military service age and obligation: in May 2001 ,
Yemen''s National Defense Council abolished
compulsory military service and authorized a
voluntary program for military service (2004)
Manpower available for military service:
males age 18-49: 4,058,223 (2005 est.)
Manpower fit for military service:
males age 18-49: 2,790,705 (2005 est.)
Manpower reaching military service age
annually:
males: 236,51 7 (2005 est.)
Military expenditures - dollar figure: $992.2
million (2005 est.)
Military expenditures - percent of GDP: 6.4%
(2005 est.)
Military • note: a Coast Guard was established in
2002','4e7c12b2d245d698003593a478622ee85b445deaa28a16b8e0fd7c9a0512e258','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5775bc6c124f6ae2c02c2e8e44fef8ff06b95d5541f97dd3f92051841556e24',2007,'LC','Saint Lucia','military-and-security',475,'Military branches: no regular military forces;
Commonwealth of Dominica Police Force (includes
Coast Guard)
Military expenditures - dollar figure: NA
Military expenditures • percent of GDP: NA
Military branches: no regular military forces; Royal
Saint Lucia Police Force (includes Special Service
Unit, Coast Guard) (2003)
Military expenditures - dollar figure: NA
Military expenditures - percent of GDP: NA
Military branches: no regular military forces; Royal
Saint Vincent and the Grenadines Police Force
(includes Special Service Unit), Coast Guard
Military expenditures - dollar figure: NA
Military expenditures - percent of GDP: NA','7a180e7c6485ceac43850ddb70dbabdfee8a7feb0d8177167a0bd9e9953ff1b7','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3abb40c19eed9893c0c4cc74e4c7dcb75ed8e82b70479810f11386cb5cc73ebb',2007,'PE','Peru','military-and-security',489,'Military branches: Army, Navy (includes Naval
Infantry, Naval Aviation, Coast Guard), Air Force
(Fuerza Aerea Ecuatoriana, FAE)
Military service age and obligation: 20 years of
age for conscript military service; 12-month service
obligation (2004)
Manpower available for military service:
males age 20-49: 2,792,770 (2005 est.)
Manpower fit for military service:
males age 20-49: 2,338,428 (2005 est.)
Manpower reaching military service age
annually:
males: 133,922 (2005 est.)
Military expenditures - dollar figure: $650 million
(2005 est.)
Military expenditures • percent of GDP: 2%
(2005 est.)
Military branches: Army, Navy, Air Force, Air
Defense Command
Military service age and obligation: 18 years of
age for conscript military service; three-year service
obligation (2001)
Manpower available for military service:
males age 18-49: 18,347,560 (2005 est.)
Manpower fit for military service:
males age 18-49: 15,540,234 (2005 est.)
Manpower reaching military service age
annually:
males: 802,920 (2005 est.)
Military expenditures • dollar figure: $2.44 billion
(2003)
Military expenditures - percent of GDP: 3.4%
(2004)','7baf09f4e7b0a081b21343f85aad620c82a65c63b3198f10254b291365c81e1a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('738ca79230493db1b43952bec2e2c7111acaa0fbb210f2fb455c8e2a3566b585',2007,'SV','El Salvador','military-and-security',499,'Military branches: Army, Navy (FNES), Air Force
(FAS)
Military service age and obligation: 18 years of
age for compulsory military service, with 12-month
service obligation; 16 years of age for volunteers
(2002)
Manpower available for military service:
males age 18-49: 1 ,391 ,278 (2005 est.)
Manpower fit for military service:
males age 18-49: 960,315 (2005 est.)
Manpower reaching military service age
annually:
males: 70,286 (2005 est.)
Military expenditures - dollar figure: $1 61 .7
million (2005 est.)
Military expenditures - percent of GDP: 1%
(2005 est.)','8db55a7dc8e093cb5e9df8f6d0a4d0c49f00414b83ecb97882ac9d0aecc0950b','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b50cb78b4aa8c9d4c1b1b8487e6eebe28d30b97bd60ea6bbb9cc3920d8435797',2007,'GN','Guinea','military-and-security',509,'Military branches: Army, Navy, Air Force (2005)
Military service age and obligation: 18 years of
age (est.) (2004)
Manpower available for military service:
males age 18-49: 106,571 (2005 est.)
Manpower fit for military service:
males age 18-49: 66.379 (2005 est.)
Military expenditures • dollar figure: $152.2
million (2005 est.)
Military expenditures - percent of GDP: 2 .1%
(2005 est.)
LIBREVILLE
*Owendo
*Kango
Bitam
*Oyem
Ctp i Booud
Loptt
fVrt-Gentil ,*Lambarene
y~ Koulamoutou
Mouila
Gamba* Tchibanga
SOUTH ATLANTIC^
OCEAN
Lucina .
Terminal
Military branches: Army, Navy, Air Force, National
Gendarmerie, National Police
Military service age and obligation: 18 years of
age for compulsory and voluntary military service (2001 )
Manpower available for military service:
males age 18-49: 276,310 (2005 est.)
Manpower fit for military service:
males age 18-49: 156,632 (2005 est.)
Manpower reaching military service age
annually:
males: 15,150 (2005 est.)
Military expenditures - dollar figure: $253.5
million (2005 est.)
Military expenditures - percent of GDP: 3.4%
(2005 est.)
Military branches: Gambian National Army (GNA),
Gambian Navy (GN), Presidential Guard, National
Guard
Military service age and obligation: 18 years of
age for voluntary military service: no conscription
(2001)
Manpower available for military service:
males age 18-49: 309,279 (2005 est.)
Manpower fit for military service:
males age 18-49: 188,1 17 (2005 est.)
Military expenditures • dollar figure: $1 .55 million
(2005 est.)
Military expenditures - percent of GDP: 0.4%
(2005 est.)','1719f54d1486bd7fb0e7d5e128ec3b9ba53b780881000e65a3fd4185ed7063b3','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e24b95228d7b94bbf8ee040966a78626286006fc3aa884a83f42c09d7307d441',2007,'ER','Eritrea','military-and-security',518,'Military branches: Army, Navy, Air Force
Military service age and obligation: 1 8 years of
age for voluntary and compulsory military service;
conscript service obligation - 16 months (2004)
Manpower fit for military service:
males age 18-49: NA (2005)
Military expenditures - dollar figure: $220.1
million (2005 est.)
Military expenditures - percent of GDP: 17.7%
(2005 est.)','a5e8914a424c32b6722ab46844f32b2314ea0c4a3d7fa868ed0ba2c5cd68e626','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('69456a3db2e574ce0dc45b0007a400c87b3798f6911dfcf0a64351eac87a4efa',2007,'EE','Estonia','military-and-security',527,'Military branches: Estonian Defense Forces:
Ground Forces, Navy, Air Force and Air Defense
Staff, Republic Security Forces (internal and border
troops), Volunteer Defense League (Kaitseliit),
Maritime Border Guard, Coast Guard; note - Border
Guards and Ministry of Internal Affairs become part of
the Estonian Defense Forces in wartime; the Coast
Guard is subordinate to the Ministry of Defense in
peacetime and the Estonian Navy in wartime
Military service age and obligation: 1 8 years of
age for compulsory military service for all male citizens,
with eight-month service obligation for conscripts and
183
Estonia (continued)
1 1 months for sergeants and reserve officers; Estonia
has committed to retaining conscription for men and
women up to 2010 and, unlike Latvia and Lithuania, has
no plan to transition to a contract armed forces; 17
years of age for volunteers; reserve commitment up to
the age of 60 (2005)
Manpower available for military service:
males age 18-49: 291 ,696 (2005 est.)
Manpower fit for military service:
males age 18-49: 200,382 (2005 est.)
note: in 2004, 51% of the young men called up for
service were determined to be unfit; main obstacles to
conscription were psychiatric and behavioral
Manpower reaching military service age
annually:
males: 11,146 (2005 est.)
Military expenditures - dollar figure: $155 million
(2002 est.)
Military expenditures - percent of GDP: 2%
(2002 est.)','75a1334a1c2cf5ae5813c904ac11e0de48daba8f446283dce69b0dbc279a8bb1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43c9ce7e2ff18ae2162c8cb047221f78af594a95c7097764f098cf8c9ba65d01',2007,'ET','Ethiopia','military-and-security',535,'Military branches: Ethiopian National Defense
Force (ENDF): Ground Forces. Air Force
note: Ethiopia is landlocked and has no navy;
following the secession of Eritrea, Ethiopian naval
facilities remained in Eritrean possession
Military service age and obligation: 18 years of
age for compulsory and voluntary military service
(2001)
Manpower available for military service:
males age 18-49: 14,568,277 (2005 est.)
Manpower fit for military service:
males age 18-49: 8.072,755 (2005 est.)
Manpower reaching military service age
annually:
males. 803,777 (2005 est.)
Military expenditures - dollar figure: $295.9
million (2005 est.)
Military expenditures - percent of GDP: 3.4%
(2005 est.)
Military branches: People''s Revolutionary Armed
Force (FARP; includes Army, Navy, and Air Force),
paramilitary force
Military service age and obligation: 18 years of
age for compulsory military service (2001)
Manpower available for military service:
males age 18-49: 288,770 (2005 est.)
Manpower fit for military service:
males age 18-49: 152,760 (2005 est.)
Military expenditures - dollar figure: $9.46 million
(2005 est.)
Military expenditures - percent of GDP: 3.1%
(2005 est.)
Military branches: Armed Forces of Sao Tome and
Principe (FASTP): Army, Coast Guard. Presidential
Guard (2004)
Military service age and obligation: 1 8 years of
age (est.) (2004)
Manpower available for military service:
males age 18-49: 33.438 (2005 est.)
Manpower fit for military service:
males age 18-49: 25,950 (2005 est.)
Military expenditures - dollar figure: $581 ,729
(2005 est.)
Military expenditures - percent of GDP: 0.8%
(2005 est.)
Military - note: Sao Tome and Principe''s army is a
tiny force with almost no resources at its disposal and
would be wholly ineffective operating unilaterally;
infantry equipment is considered simple to operate
and maintain but may require refurbishment or
replacement after 25 years in tropical climates; poor
pay and conditions have been a problem in the past,
as has alleged nepotism in the promotion of officers,
as reflected in the 1995 and 2003 coups; these issues
are being addressed with foreign assistance as initial
steps towards the improvement of the army and its
focus on realistic security concerns; command is
exercised from the president, through the Minister of
Defense, to the Chief of the Armed Forces staff (2005)','ad5bb0d01c34f08cabe574c85be43aa9b4fc46f4ec4a8bd1c6799715941930d1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f978794a2a4fe2c3e4a2472ceb5c69b9d8c2b88b68e90b5ff7faff0b03ee8781',2007,'FO','Faroe Islands','military-and-security',551,'Military branches: no regular military forces
Military expenditures - dollar figure: NA
Military expenditures - percent of GDP: NA
Military - note: defense is the responsibility of','9689342f383f70d68204250893c96766c9ecb551732f18988a828573bceece2c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dacafa2533552b6f4164aa87c075a09568edd6504838e484bffa7582ea7f73e4',2007,'JE','Jersey','military-and-security',562,'Military branches: Republic of Fiji Military Forces
(RFMF): Land Forces, Naval Division (2005)
Military service age and obligation: 18 years of
age for voluntary military service (2001)
Manpower available for military service:
males age 18-49: 215,104 (2005 est.)
Manpower fit for military service:
males age 18-49: 1 63,960 (2005 est.)
Manpower reaching military service age
annually:
males: 9,266 (2005 est.)
Military expenditures - dollar figure: $36 million
(2004)
Military expenditures - percent of GDP: 2.2%
(FY02)
Military branches: Israel Defense Forces (IDF):
Ground Corps, Navy, Air and Space Force (includes
Air Defense Forces); historically there have been no
separate Israeli military services
Military service age and obligation: 1 7 years of
age for compulsory (Jews, Druzes) and voluntary
(Christians, Muslims, Circassians) military service;
both sexes are eligible for military service; conscript
service obligation - 36 months for men, 21 months for
women (2004)
Manpower available for military service:
males age 77-49: 1,492,125
females age 1 7-49: 1,443,916 (2005 est.)
Manpower fit for military service:
males age 77-49:1,255,902
females age 77-49:1.212,394 (2005 est.)
Manpower reaching military service age
annually:
males: 53,760
females: 51 ,293 (2005 est.)
Military expenditures - dollar figure: $9.45 billion
(2005 est.)
Military expenditures - percent of GDP: 7.7%
(2005 est.)
Military branches: Land Forces, Navy, Air Force
(includes Air Defense Force), National Guard (2002)
Military service age and obligation: 18 years of
age for compulsory and voluntary military service;
since 1 999 women have served in police forces
(2001)
Manpower available for military service:
males age 18-49: 864,745 (2005 est.)
Manpower fit for military service:
males age 18-49: 737,292 (2005 est.)
Manpower reaching military service age
annually:
males: 18,743 (2005 est.)
Military expenditures - dollar figure: $3.01 billion
(2005 est.)
Military expenditures - percent of GDP: 4.2%
(2005 est.)
Military branches: no regular indigenous military
forces; French Armed Forces (includes Army, Navy,
Air Force, Gendarmerie); Police Force
Military expenditures - dollar figure: NA
Military expenditures - percent of GDP: NA
Military - note: defense is the responsibility of
Military branches: Slovenian Army (includes Air
and Naval Forces)
Military service age and obligation: 17 years of
age for voluntary military service; conscription
abolished in 2003 (2004)
Manpower available for military service:
males age 17-49: 496,929 (2005 est.)
Manpower fit for military service:
males age 17-49: 405,593 (2005 est.)
Manpower reaching military service age
annually:
males: 12,816 (2005 est.)
Military expenditures - dollar figure: $370 million
(FY00)
Military expenditures - percent of GDP: 1 .7%
(FY00)
Military branches: Umbutfo Swaziland Defense
Force (USDF): Ground Force (includes Air Wing),
Royal Swaziland Police Force (RSPF) (2005)
Military service age and obligation: 1 8-30 years of
age for voluntary military service; both sexes are
eligible for military service (2005)
Manpower available for military service:
males age 18-49: 248,676 (2005 est.)
Manpower fit for military service:
males age 18-49: 98.530 (2005 est.)
Military expenditures - dollar figure: $41 .6 million
(2005 est.)
Military expenditures - percent of GDP: 1 .4%
(2005 est.)','0857078838315ea95e3fc29b0b63ff73a6a8df89d445d56a86335d5bc560c98d','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8921bff88b8ac156dc6c69225a64facdcf5a71ee28dfcd598b6439c56af36e31',2007,'FI','Finland','military-and-security',571,'Military branches: Finnish Defense Forces: Army,
Navy (includes Coastal Defense Forces), Air Force
(2003)
Military service age and obligation: 18 years of
age for voluntary and compulsory military service
(October 2004)
Manpower available for military service:
males age 18-49: 1 ,121 ,275 (2005 est.)
Manpower fit for military service:
males age 18-49: 913,617 (2005 est.)
Manpower reaching military service age
annually:
males: 32,040 (2005 est.)
Military expenditures - dollar figure: $1 .8 billion
(FY98/99)
Military expenditures - percent of GDP: 2%
(FY98/99)','7ce6aeb72b4bebd1c284c7df53ab751d8db855e294b1bb6196f94df0b4210b16','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4825e5de94ebd45bb8c7df79f88cd7b31906e84a7280e4b8429fc53d707c9d2b',2007,'WF','Wallis and Futuna','military-and-security',577,'Military branches: Army (includes Marines, Foreign
Legion, Army Light Aviation), Navy (includes naval
air), Air Force (includes Air Defense), National
Gendarmerie
Military service age and obligation: 1 7 years of
age for voluntary military service; conscription ended
in the 1990s; women serve in non-combat military
posts (2001)
Manpower available for military service:
males age 17-49: 13,676,509 (2005 est.)
Manpower fit for military service:
males age 1 7-49: 11,262,661 (2005 est.)
Manpower reaching military service age
annually:
males: 389,204 (2005 est.)
Military expenditures - dollar figure: $45 billion
FY06 (2005)
Military expenditures - percent of GDP: 2.6%
FY06 (2005 est.)
(overseas territory of France)
O 25 50km
25 50 r
lies
Wallis
MATA-UTU
he Uvea
''*
South Pacific Ocean
lies de Home
he Futuna
.Sigave (Leava)
He Aloft','35c5355662acf0b6177ceb4f8d5361ddbe98b6d19430cb64a3c23aed07d8152c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5663ba01f28755746f3f97bf1c6d392c3f8b6d6b63e0a245da5c65a28b9b31ab',2007,'PF','French Polynesia','military-and-security',591,'Military branches: no regular military forces;
Gendarmerie and National Police Force
Military - note: defense is the responsibility of','72bafc3ba58d233bef6401e198a0c2e160ee88b35db72e399d3667401f1fde1f','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6652c0953de56cd31f5ca233d3be04497436871a944a8e3846f23471a1843e19',2007,'EG','Egypt','military-and-security',603,'Military branches: in accordance with the peace
agreement, the Palestinian Authority is not permitted
conventional military forces; there are, however,
public security forces (2002)
Military expenditures - dollar figure: NA
Military expenditures - percent of GDP: NA
211
Gaza Strip (continued)','ae1d1631dbb7040a047800ec42d809dd6910e9733312069ccd29a457400ee449','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b85557a3fb5ac7dca1df5577d64d93f2cec7def22673b6774246e4ea3cedf84',2007,'GE','Georgia','military-and-security',612,'Military branches: Ground Forces (includes
National Guard), Air and Air Defense Forces, Navy
(2006)
Military service age and obligation: 1 8 to 34 years
of age for compulsory and voluntary active duty
military service; conscript service obligation - 18
months (2005)
Manpower available for military service:
males age 18-49: 1 ,038,736 (2005 est.)
Manpower fit for military service:
males age 18-49: 827,281 (2005 est.)
Manpower reaching military service age
annually:
males. 38,857 (2005 est.)
Military expenditures - dollar figure: $23 million
(FY00)
Military expenditures - percent of GDP: 0.59%
(FY00)
Military - note: a CIS peacekeeping force of Russian
troops is deployed in the Abkhazia region of Georgia
together with a UN military observer group; a Russian
peacekeeping battalion is deployed in South Ossetia','77897248b64c46e95eb758bb9d804ca7d56b0ff13706ab3d435e0f8232f00cc7','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcb10c964258eed0365b018cf82266df4f0f6f3b988f99974e02fd9f96efdbc3',2007,'GH','Ghana','military-and-security',620,'Military branches: Army, Navy, Air Force
Military service age and obligation: 1 8 years of
age for compulsory and volunteer military service
(2001)
Manpower available for military service:
males age 18-49: 4,761 ,226 (2005 est.)
Manpower fit for military service:
males age 18-49: 2,721 ,239 (2005 est.)
Manpower reaching military service age
annually:
males: 250,782 (2005 est.)
Military expenditures - dollar figure: $83.65
million (2005 est.)
Military expenditures - percent of GDP: 0.8%
(2005 est.)','e21fca90c4e36c49764723d93ecd47a37d53680da363222e1b6c1acf44ce4e8a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('889f96e8bc4f9de6f18384bd5b6e176e06cae6aceae43e6c6385d059d992e642',2007,'GI','Gibraltar','military-and-security',630,'Military branches: Royal Gibraltar Regiment
Military - note: defense is the responsibility of the
UK; the last British regular infantry forces left Gibraltar
in 1992, replaced by the Royal Gibraltar Regiment
Military - note: defense is the responsibility of
Military branches: Royal Armed Forces: includes
Army, Navy, Air Force (Force Aerienne Royale
Marocaine)
Military service age and obligation: 18 years of
age for compulsory and voluntary military service;
conscript service obligation - 18 months (2004)
Manpower available for military service:
males age 18-49: 7,908,864 (2005 est.)
Manpower fit for military service:
males age 18-49: 6,484,787 (2005 est.)
383
MorOCCO (continued)
Manpower reaching military service age
annually:
males: 353.377 (2005 est.)
Military expenditures - dollar figure: $2.31 billion
(2003 est.)
Military expenditures - percent of GDP: 5%
(2003 est.)','da31d759fb5850c057a61b4ddae4ae3475e1a0c8cf61c8265c5edce358d554b3','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63f7e3f2091572b7e5aea470af8c13ce24e1671501a54ddbcf244282f7182930',2007,'GR','Greece','military-and-security',639,'Military branches: Hellenic Army (Ellinikos Stratos,
ES), Hellenic Navy (Ellinikos Polemiko Navtiko, EPN),
Hellenic Air Force (Ellinikos Polemiki Aeroporia, EPA)
(2006)
Military service age and obligation: 18 years of
age for compulsory military service; during wartime
the law allows for recruitment beginning January of
the year of inductee''s 18th birthday, thus including 17
year olds; 17 years of age for volunteers; conscript
service obligation - 1 2 months for the Army, Air Force;
15 months for Navy; women are eligible for military
service (2005)
Manpower available for military service:
males age 18-49: 2,459,988 (2005 est.)
Manpower fit for military service:
males age 18-49: 2,018,557 (2005 est.)
Manpower reaching military service age
annually:
males: 58,399 (2005 est.)
Military expenditures - dollar figure: $5.89 billion
(2004)
Military expenditures - percent of GDP: 4.3%
(2003)','b0e0a893486bc7f801ffc27895143789e3c7cd7164905e84fe3d7319df97e0d7','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('180ae0ede21e5db540fd63208c748894850d1b7f8ee7ece7114aefe85755a3a2',2007,'MQ','Martinique','military-and-security',647,'Military branches: no regular military forces; Royal
Grenada Police Force
Military expenditures • dollar figure: NA
Military expenditures - percent of GDP: NA','561a60889056b0366774ba13ec1c784393f17baae3938d3cc1b64fd5a3c2546c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('628fa3303b6260413a345a858ac985abf35d8c3ed6fb4a8e619e822fe2b7da64',2007,'GY','Guyana','military-and-security',681,'Military branches: Guyana Defense Force: Ground
Forces, Coast Guard, Air Corps, Guyana People''s
Militia
Manpower available for military service:
males age 18-49: 206,098 (2005 est.)
Manpower fit for military service:
males age 18-49: 137,964 (2005 est.)
Military expenditures - dollar figure: $6.48 million
(2003 est.)
Military expenditures - percent of GDP: 0.9%
(2003 est.)
Military branches: National Army (includes small
Navy and Air Force elements)
Military service age and obligation: 18 years of
age (est.); no conscription
Manpower available for military service:
males age 18-49: 1 1 1 ,582 (2005 est.)
Manpower fit for military service:
males age 18-49: 77,793 (2005 est.)
Military expenditures - dollar figure: $7.5 million
(2003 est.)
Military expenditures - percent of GDP: 0.7%
(2003 est.)
Military • note: demilitarized by treaty on 9 February
1920','95a1fb6da50fc70ff0008726feddc1b81fc70227b84bff5bd8391683c010a9b2','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75e221bd6d8b260f52f4263d2f1f99e7881348bc676bc3480cdec56b2772694f',2007,'IT','Italy','military-and-security',691,'Military branches: Pontifical Swiss Guard (Corpo
della Guardia Svizzera Pontificia)
Military ■ note: defense is the responsibility of Italy;
ceremonial and limited security duties performed by
Pontifical Swiss Guard
Military branches: Land Forces, Swiss Air Force
(Schweizer Luftwaffe)
Military service age and obligation: the Swiss
Constitution states that "every Swiss male is obliged
to do military service"; every Swiss male has to serve
for at least 260 days in the armed forces; 19 years of
age for compulsory military service; 17 years of age
for voluntary military service; conscripts receive 15
weeks of compulsory training, followed by 10
intermittent recalls for training over the next 22 years;
women are accepted on a voluntary basis but are not
drafted (2005)
Manpower available for military service:
males age 19-49: 1 ,707,694 (2005 est.)
Manpower fit for military service:
males age 19-49: 1 ,375,889 (2005 est.)
Manpower reaching military service age
annually:
males: 46,319 (2005 est.)
Military expenditures - dollar figure: $2,548 billion
(FY01)
Military expenditures - percent of GDP: 1%
(FY01)
Military branches: Syrian Arab Army, Syrian Arab
Navy, Syrian Arab Air and Air Defense Force (includes
Air Defense Command) (2005)
Military service age and obligation: 18 years of
age for compulsory military service; conscript service
obligation - 30 months (18 months in the Syrian Arab
Navy); women are not conscripted but may volunteer
to serve (2004)
Manpower available for military service:
males age 18-49: 4,356,413 (2005 est.)
Manpower fit for military service:
males age 18-49: 3,453,888 (2005 est.)
Manpower reaching military service age
annually:
males: 225,1 13 (2005 est.)
Military expenditures • dollar figure: $858 million
(FY00 est.); note - based on official budget data that
may understate actual spending
Military expenditures - percent of GDP: 5.9%
(FY00)','e7d49f9cfdc44db90b6dcdf85d109527003d7eb9f8c6ba406756bd7bc8c42f49','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4b45c7939bc8455b6803afbec2ccf50836ff7066b477c44e3ba77a485b824cf',2007,'NI','Nicaragua','military-and-security',701,'Military branches: Army, Navy (includes Naval
Infantry), Air Force
Military service age and obligation: 18 years of
age for voluntary two-three year military service
(2004)
Manpower available for military service:
males age 18-49: 1 ,448,369 (2005 est.)
Manpower fit for military service:
males age 18-49: 955,019 (2005 est.)
Manpower reaching military service age
annually:
males: 77,399 (2005 est.)
Military expenditures - dollar figure: $52.8 million
(2005 est.)
Military expenditures - percent of GDP: 2.55%
(2005 est.)
252
Honduras (continued)','f4a1ff3ed6d9ba879dde703a7433fc34232e74bb3c953b53d2991537b8a0d3bb','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7378d52b67fbb141d0d0cb3aa30a8cffb4e20c28b22833464b2d9f473ac03bf3',2007,'RO','Romania','military-and-security',713,'Military branches: Ground Forces, Air Forces
Military service age and obligation: 18 years of
age for voluntary military service: conscription
abolished in June 2004 (2004)
Manpower available for military service:
males age 18-49: 2,303,1 16 (2005 est.)
Manpower fit for military service:
males age 18-49: 1 ,780,51 3 (2005 est.)
Manpower reaching military service age
annually:
males: 63,847 (2005 est.)
Military expenditures - dollar figure: $1 .08 billion
(2002 est.)
Military expenditures - percent of GDP: 1 .75%
(2002 est.)
Transnationa
s s u e s
Disputes ■ international: in 2004. Hungary
amended the status law extending special social and
cultural benefits - and voted down a referendum to
extend dual citizenship - to ethnic Hungarians living in
neighboring states, which have objected to such
measures: consultations continue between Slovakia
and Hungary over Hungary''s completion of its portion
the Gabcikovo-Nagymaros hydroelectric dam project
along the Danube; as a member state that forms part
of the EU''s external border, Hungary must implement
the strict Schengen border rules
Illicit drugs: transshipment point for Southwest
Asian heroin and cannabis and for South American
cocaine destined for Western Europe; limited
producer of precursor chemicals, particularly for
amphetamine and methamphetamine; improving, but
remains vulnerable to money laundering related to
organized crime and drug trafficking
Greenland Sea
— .Raufartiefn
IsafjcrflH^;
% Straurrfewk
\\j£ REYKJAVIK
Keflavik^jjg&sajfjordhur
Vestmannaeyjar,
Surtsey
North Atlantic Ocean
Military branches: no regular armed forces;
Icelandic National Police, Icelandic Coast Guard
(Islenska Landhelgisgaeslan)
Manpower available for military service:
males age 18-49: 69,038 (2005 est.)
Manpower fit for military service:
males age 18-49: 56,777 (2005 est.)
Military expenditures - dollar figure: 0
Military expenditures - percent of GDP: 0%
Military • note: defense is provided by the
US-manned Icelandic Defense Force (IDF)
headquartered at Keflavik
Military branches: National Army (includes Ground
Forces. Rapid Reaction Forces, Air and Air Defense
Forces) (2006)
Military service age and obligation: 1 8 years of
age for compulsory military service; national service
obligation -12 months (2004)
Manpower available for military service:
males age 18-49: 1 ,066,459 (2005 est.)
Manpower fit for military service:
males age 18-49: 693,913 (2005 est.)
Manpower reaching military service age
annually:
males: 43,729 (2005 est.)
Military expenditures • dollar figure: $8.7 million
(2004)
Military expenditures - percent of GDP: 0.4%
(FY02)','555114fc0546d1494a2a326a22db2ec35cbef8771d3405ccf72a067be895c94d','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4d64b209f9dc36726fc004b22f962fccc3be60e961ad6b86baa0e771cbceb956',2007,'IN','India','military-and-security',721,'Military branches: Army, Navy (includes naval air
arm), Air Force, Coast Guard, various security or
paramilitary forces (includes Border Security Force,
Assam Rifles. National Security Guards, Indo-Tibetan
Border Police, Special Frontier Force, Central
Reserve Police Force, Central Industrial Security
Force. Railway Protection Force, and Defense
Security Corps)
Military service age and obligation: 1 6 years of
age for voluntary military service (2001)
Manpower available for military service:
males age 16-49: 287,551 ,1 1 1 (2005 est.)
Manpower fit for military service:
males age 16-49: 21 9,471 ,999 (2005 est.)
Manpower reaching military service age
annually:
males: 11,446,452 (2005 est.)
Military expenditures - dollar figure: $1 9.04 billion
(2005 est.)
Military expenditures - percent of GDP: 2.5%
(2005 est.)','c2893553540703cb6ae9c0fb64b6a92af247be3e508dfad9c756821feeb37f16','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('237a02cbab325c797eb30f1e413d152e9574f0ed2590a0821282a08f2c50191b',2007,'IE','Ireland','military-and-security',731,'Military branches: Irish Defense Forces (Oglaigh na
h-Eireann): Army (includes Naval Service and Air
Corps) (2006)
Military service age and obligation: 17 years of
age for voluntary military service; enlistees under the
age of 17 can be recruited for specialist positions
(2001)
276
Ireland (continued)
Manpower available for military service:
males age 17-49: 977,092 (2005 est.)
Manpower fit for military service:
males age 17-49: 814,768 (2005 est.)
Manpower reaching military service age
annually:
males: 29,327 (2005 est.)
Military expenditures - dollar figure: $700 million
(FY00/01)
Military expenditures - percent of GDP: 0.9%
(FY00/01)','1d8f10baaba66d2051e35bfb35cf8fb697d45632df8ccc8a77d5c865f86e0128','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f5a513ba8fb40ba159a5600ca18f7d61d73078f636cc16accaed0bb876bb4a5',2007,'TN','Tunisia','military-and-security',749,'Military branches: Army (Esercito Italiano, El),
Navy (Marina Militare Italiana, MMI), Air Force
(Aeronautica Militare Italiana, AMI), Carabinieri Corps
(Corpo dei Carabinieri, CC) (2005)
Military service age and obligation: 1 8 years of
age (2004)
Manpower available for military service:
males age 18-49: 13,491,260 (2005 est.)
Manpower fit for military service:
males age 18-49: 10,963,513 (2005 est.)
Manpower reaching military service age
annually:
males: 286,344 (2005 est.)
Military expenditures - dollar figure: $28,182.8
million (2003)
Military expenditures - percent of GDP: 1 .8%
(2004)
Military - note: defense is the responsibility of','f7ebe0949c8832db3f9505f1cdffcf1a2bb180ee18f5a3485890eecf4295dcea','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66b0a0e5092a34c3bab2301962b59bb229f8ec1b213eb395fb2c1386890177d9',2007,'JP','Japan','military-and-security',759,'La Fr-c-jse Sfra.
Hokkaido
Sapporo,
Tsunanr ■ .
Hachiro-—
''Sendai
TOKYO Honshu
..-KORtft F +
H,r0Shi6£fe^^0k0ha™
Fuki
aka"
Kyushu
NORTH"
1 PACIFIC
~*\\ OCEAN
o
in
Philippine
Sea
,vO*
OMTO-
SHOW
Disputes • international: none
Military branches: Japanese Defense Agency
(JDA): Ground Self-Defense Force (Rikujou Jietai,
GSDF), Maritime Self-Defense Force (Kaijou Jietai,
MSDF), Air Self-Defense Force (Koukuu Jietai, ASDF)
(2006)
Military service age and obligation: 1 8 years of
age for voluntary military service (2001)
Manpower available for military service:
males age 18-49: 27,003,1 12 (2005 est.)
Manpower fit for military service:
males age 18-49: 22,234,663 (2005 est.)
Manpower reaching military service age
annually:
males: 683,147 (2005 est.)
Military expenditures - dollar figure: $44.31 billion
(2005 est.)
Military expenditures - percent of GDP: 1 %
(2005 est.)','47bbb3091799a4df900f2a0b0b8e7707637875c0fe01d9f1b7ddf20f58b8e6ad','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('98fa7b4394b4af79d6913f2a4e0b8c1b16a6ff2a387113616350439271b91bbd',2007,'US','United States','military-and-security',771,'Military ■ note: defense is the responsibility of the
UK
Disputes - international: none
Johnston Atoll
(territory of the US)
Description under
Pacific Island
Wildlife Refuges
292
Military branches: Army. Navy and Marine Corps,
Air Force, and Coast Guard; note - Coast Guard
administered in peacetime by the Department of
Homeland Security, but in wartime reports to the
Department of the Navy
Military service age and obligation: 18 years of
age (2004)
Manpower available for military service:
males age 18-49: 67,742,879
females age 18-49: 67,070,144 (2005 est.)
Manpower fit for military service:
males age 18-49: 54,609,050
females age 18-49: 54,696,706 (2005 est.)
Manpower reaching military service age
annually:
males: 2,143,873
females: 2,036,201 (2005 est.)
Military expenditures - dollar figure: $518.1 billion
(FY04 est.) (2005 est.)
Military expenditures - percent of GDP: 4.06%
(FY03 est.) (2005 est.)','f177dec0f6dcac51c1f4c709a8b55c2d2e0c29b2be804d3a04ce78c4d5f49234','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b89a4a61808900d3b92363aeea68e556adc2a255856d5cbb551a27f60985ed7',2007,'JO','Jordan','military-and-security',776,'Military branches: Jordanian Armed Forces (JAF):
Royal Jordanian Land Force, Royal Jordanian Navy,
Royal Jordanian Air Force, and Special Operations
Command (SOCOM); note - Public Security
Directorate normally falls under Ministry of Interior but
comes under JAF in wartime or crisis situations
Military service age and obligation: 17 years of
age for voluntary military service; conscription at age
18 was suspended in 1999, although all males under
age 37 are required to register; women not subject to
conscription, but can volunteer to serve in non-combat
military positions (2004)
Manpower available for military service:
males age 17-49: 1 ,573,995 (2005 est.)
Manpower fit for military service:
males age 17-49: 1 ,348,076 (2005 est.)
Manpower reaching military service age
annually:
males: 60,625 (2005 est.)
Military expenditures - dollar figure: $1 .4 billion
(2005 est.)
Military expenditures - percent of GDP: 1 1 .4%
(2005 est.)','b5e95afeacb84cc24f19eefe02615e50cfb0a6d7279887043a7895d3272e07f1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ffa46083d6073d5aef1506ea81398f2f60f74159c2b892afcdf67d69cbe9405b',2007,'KZ','Kazakhstan','military-and-security',780,'Military branches: Ground Forces, Air and Air
Defense Forces, Naval Force, Republican Guard
Military service age and obligation: 18 years of
age for compulsory military service; conscript service
obligation - two years; minimum age for volunteers NA
(2004)
Manpower available for military service:
males age 18-49: 3,758,255 (2005 est.)
Manpower fit for military service:
males age 18-49: 2,473,529 (2005 est.)
Manpower reaching military service age
annually:
males: 173,129 (2005 est.)
Military expenditures - dollar figure: $221 .8
million (Ministry of Defense expenditures) (FY02)
Military expenditures - percent of GDP: 0.9%
(Ministry of Defense expenditures) (FY02)
Military branches: Army, Navy, Air Force
Military service age and obligation: 18 years of
age (est.) (2004)
Manpower available for military service:
males age 18-49: 7,303,153 (2005 est.)
Manpower fit for military service:
males age 18-49: 3,963,532 (2005 est.)
Military expenditures - dollar figure: $280.5
million (2005 est.)
Military expenditures - percent of GDP: 1 .6%
(2005 est.)','dc9f367397d701dad17446646000d36de886b2dfa677b321b41f0b483e2694fb','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae59cbc9f1e9c6a1ec900bd13b3947667fb2aef34056cae66adc6a6572a89b56',2007,'KI','Kiribati','military-and-security',795,'Military branches: no regular military forces; Police
Force (carries out law enforcement functions and
paramilitary duties; small police posts are on all
islands)
Military expenditures - dollar figure: NA
Military expenditures - percent of GDP: NA
Military • note: Kiribati does not have military forces;
defense assistance is provided by Australia and NZ
Military branches: North Korean People''s Army:
Ground Force, Navy, Air Force; Civil Security Forces
(2005)
Military service age and obligation: 1 7 years of
age (2004)
Manpower available for military service:
males age 17-49: 5,851 ,801 (2005 est.)
Manpower fit for military service:
males age 77-49:4,810.831 (2005 est.)
Manpower reaching military service age
annually:
males: 194,605 (2005 est.)
Military expenditures - dollar figure: $5 billion
(FY02)
Military expenditures - percent of GDP: NA
Military branches: Army, Navy, Air Force, Marine
Corps, National Maritime Police (Coast Guard)
Military service age and obligation: 20-30 years of
age for compulsory military service; conscript service
obligation - 24-28 months, depending on the military
branch involved; 1 8 years of age for voluntary military
service; some 4,000 women serve as commissioned
and noncommissioned officers, approx. 2.3% of all
officers; women, in service since 1 950, are admitted to
seven service branches, including infantry, but
excluded from artillery, armor, anti-air, and chaplaincy
corps (2005)
Manpower available for military service:
males age 20-49: 12,458,257 (2005 est.)
Manpower fit for military service:
males age 20-49: 9,932,026 (2005 est.)
Manpower reaching military service age
annually:
males: 344,723 (2005 est.)
Military expenditures - dollar figure: $21 .06 billion
FY05 (2005 est.)
Military expenditures - percent of GDP: 2.6%
FY05 (2005 est.)','01f17f6cc485e0feb348531d2479a5579c21160119203b9e6af90079c0dc5121','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfb79ad11e592d1bc76c334c8b637ee694dd2e214937f87f8d6aa33958415fca',2007,'LB','Lebanon','military-and-security',811,'Military branches: Lebanese Armed Forces (LAF):
Army, Navy, and Air Force
Military service age and obligation: 18-30 years of
age for compulsory and voluntary military service;
conscript service obligation - 12 months (2004)
Manpower available for military service:
males age 18-49: 974,363 (2005 est.)
Manpower fit for military service:
males age 18-49: 821,762 (2005 est.)
Military expenditures - dollar figure: $540.6
million (2004)
Military expenditures - percent of GDP: 3.1%
(2004)','2d5305471c91f4ec0a4029801d081cb1e5e08d8ca65cbfdaa8d583f98ee908ec','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91797e388c287f6082346c3786ae008d67e1c1c20bb41dd0c3432b7ec883ee6d',2007,'ZA','South Africa','military-and-security',819,'Military branches: Lesotho Defense Force (LDF):
Army and Air Wing
Military service age and obligation: 18 years of
age (est.); no conscription (2001)
Manpower available for military service:
males age 18-49: 400,457 (2005 est.)
Manpower fit for military service:
males age 78-49: 162,857 (2005 est.)
Military expenditures - dollar figure: $41 .1 million
(2005 est.)
Military expenditures • percent of GDP: 2.1%
(2005 est.)
Military - note: the Lesotho Government in 1999
began an open debate on the future structure, size,
and role of the armed forces, especially considering
the Lesotho Defense Force''s (LDF) history of
intervening in political affairs','bbe3a4e1ce0237a8e7b6314700248e6d07d749da802115b4707343f9b3d57197','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1de94c842685b617f63218cb73d0bbdab5d902647f8d9263f724b6d4fedf66f8',2007,'LR','Liberia','military-and-security',829,'Military branches: Armed Forces of Liberia (AFL):
Army, Navy, Air Force
Military service age and obligation: 18 years of
age for voluntary military service; no conscription
(2001)
Manpower available for military service:
males age 18-49: 659,795 (2005 est.)
Manpower fit for military service:
males age 18-49: 360,373 (2005 est.)
Military expenditures - dollar figure: $67.4 million
(2005 est.)
Military expenditures - percent of GDP: 7.5%
(2005 est.)
326
Liberia (continued)','8ad94aa8dd6c63011b61277b79740ab006d9a58bac50fb3ef41a6cde6e83ce63','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f3f16537105fbcc1500322f6d51295c5298bbf1a696c7dc7d3b67ba4fabcbdf0',2007,'LT','Lithuania','military-and-security',847,'Military branches: Ground Forces, Navy,
Lithuanian Military Air Forces, National Defense
Volunteer Forces (SKAT) (2005)
Military service age and obligation: 1 9-45 years of
age for compulsory military service, conscript service
obligation - 12 months; 18 years of age for volunteers
(2004)
Manpower available for military service:
males age 19-49: 830,368 (2005 est.)
Manpower fit for military service:
males age 19-49: 590,606 (2005 est.)
Manpower reaching military service age
annually:
males: 29,689 (2005 est.)
Military expenditures - dollar figure: $230.8
million (FY01)
Military expenditures - percent of GDP: 1 .9%
(FY01)','f6d537c2cdf2fc7617fca4724bca421f44797d23b12f7e17cc58e9b9cb594938','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('128fb7edf3d33e039935a779f4227075469d0703d6da9395b2a658e2c81285f8',2007,'MZ','Mozambique','military-and-security',851,'Military branches: People''s Armed Forces:
Intervention Force, Development Force, and
Aeronaval (Navy and Air) Force; National
Gendarmerie
Military service age and obligation: 1 8-50 years of
age; conscript service obligation - 18 months (either
military or equivalent civil service) (2004)
Manpower available for military service:
males age 18-49: 3,542,797 (2005 est.)
Manpower fit for military service:
males age 18-49: 2,218,662 (2005 est.)
Manpower reaching military service age
annually:
males: 187,000 (2005 est.)
Military expenditures • dollar figure: $329 million
(2005 est.)
Military expenditures - percent of GDP: 7.2%
(2005 est.)
Military branches: Tanzanian People''s Defense
Force (JWTZ): Army, Naval Wing, Air Defense
Command (includes Air Wing), National Service
Military service age and obligation: 15 years of
age for voluntary military service; 18 years of age for
compulsory military service upon graduation from
secondary school; conscript service obligation - two
years (2004)
Manpower available for military service:
males age 18-49: 7,422,869 (2005 est.)
Manpower fit for military service:
males age 18-49: 3,879,630 (2005 est.)
Military expenditures - dollar figure: $21 .2 million
(2005 est.)
Military expenditures - percent of GDP: 0.2%
(2005 est.)','8f6acc71fcc92831411b82e42671539b522ec9cae3d07f587a6997db5fe02017','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70461631a48e951122ad826b236aaa93cd76339309bb54bf3560e965306b3ad9',2007,'MW','Malawi','military-and-security',860,'Military branches: Malawi Armed Forces: Army
(includes Air Wing and Naval Detachment), Police
(includes Mobile Force Unit)
Military service age and obligation: 1 8 years of
age for voluntary military service; no conscription (2001 )
Manpower available for military service:
males age 18-49: 2,320,190 (2005 est.)
Manpower fit for military service:
males age 18-49: 995,084 (2005 est.)
Military expenditures - dollar figure: $15.81
million (2005 est.)
Military expenditures - percent of GDP: 0.8%
(2005 est.)','eb605b8f768ab0f9a316d8bc0ca9c3bae10781112c622351d1c5b3c4f01a19ce','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ece91a1f8b0755b74636c01788f9926d5c6c08bbc852f219e1e86ae91b05ea11',2007,'MV','Maldives','military-and-security',870,'Military branches: National Security Service
includes Security Branch (ground forces), Air
Element, Coast Guard
Military service age and obligation: 18 years of
age (est.) (2004)
Manpower available for military service:
males age 18-49: 71,774 (2005 est.)
Manpower fit for military service:
males age 18-49: 56,687 (2005 est.)
Military expenditures - dollar figure: $45.07
million (2005 est.)
Military expenditures • percent of GDP: 5.5%
(2005 est.)
Military branches: Army, Air Force, National Guard
Military service age and obligation: 18 years of
age for compulsory and voluntary military service;
conscript service obligation - two years (2004)
Manpower available for military service:
males age 18-49: 2,206,728 (2005 est.)
Manpower fit for military service:
males age 18-49: 1 ,231 ,930 (2005 est.)
Military expenditures - dollar figure: $1 06.3
million (2005 est.)
Military expenditures - percent of GDP: 1 .9%
(2005 est.)','f5d6023ef6d4865449e364116094e1e6bdaba7dfa8767e431dab8a9d159a85e3','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95bb01500bd03f49d93e8c35c0c6dcbb50d866514d58dbecfd879e71a94f33a6',2007,'MT','Malta','military-and-security',880,'Military branches: Armed Forces of Malta (AFM:
includes air and maritime elements) (2005)
Military service age and obligation: 18 years of
age for voluntary military service; no conscription
(2001)
Manpower available for military service:
males age 18-49: 90,651 (2005 est.)
Manpower fit for military service:
males age 18-49: 74,525 (2005 est.)
Military expenditures ■ dollar figure: $38 1 68
million (2005 est.)
Military expenditures - percent of GDP: 1%
(2005 est.)','27f43de6b99985d136dff6131f3dda0ea2c86751eadda2a50c20d4ede409e0bf','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cdf9969efecb7202c59c2924da939e14cf899f085b5f1f6465c51f90d57ff04e',2007,'MH','Marshall Islands','military-and-security',889,'Military branches: no regular military forces;
Marshall Islands Police
Military expenditures - dollar figure: NA
Military expenditures • percent of GDP: NA
Military - note: defense is the responsibility of the
US','22ffea71dd7d5c82bed673163b3c66323db6a4da574295629bd815c0bf10fb2d','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('963a55e1200009b75a63db1b5e4da763b81c983ebd6314dd82f5c4a673b7e11c',2007,'MR','Mauritania','military-and-security',891,'Military branches: no regular military forces;
Gendarmerie
Military - note: defense is the responsibility of
Military branches: Mauritanian Armed Forces:
Army, Navy (Marine Mauritanienne; includes Naval
Infantry), Air Force (Force Aerienne Islamique de
Mauritanie, FAIM) (2005)
Military service age and obligation: 18 years of
age (est.); conscript service obligation - two years;
majority of servicemen believed to be volunteers;
service in Air Force and Navy is voluntary (April 2005)
Manpower available for military service:
males age 18-49: 606,463 (2005 est.)
Manpower fit for military service:
males age 18-49: 370,513 (2005 est.)
Military expenditures - dollar figure: $1 9.32
million (2005 est.)
Military expenditures - percent of GDP: 1 .4%
(2005 est.)','7fd87926326c0c2c2f0b35a8a674bc1228fb31f0b2715475400ad3fb235e8353','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a7f737dda31db4ed28ffe07c7cb5e094ced757b13835f44f60dc07ee4426af55',2007,'MU','Mauritius','military-and-security',909,'Military branches: National Police Force (includes
the paramilitary Special Mobile Force or SMF and
National Coast Guard)
Manpower available for military service:
males age 76-49:313.271 (2005 est.)
Manpower fit for military service:
males age 18-49: 248,659 (2005 est.)
-:
$
364
Mauritius (continued)
Military expenditures - dollar figure: $12.04
million (2005 est.)
Military expenditures - percent of GDP: 0.2%
(2005 est.)','5cbe54cb7eff66c48486271964ee8d76d50e98b29fc8223470e5dc6fa96fb520','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b30b7c76708ad86a5c549ffe7cd07f475ab630f931f0b7185ddfae2cfc37fcc6',2007,'CU','Cuba','military-and-security',914,'Military branches: Secretariat of National Defense
(Sedena): Army and Air Force (FAM); Secretariat of
the Navy (Semar): Naval Air and Marines (2004)
Military service age and obligation: 1 8 years of
age for compulsory military service, conscript service
obligation - 12 months; 16 years of age with consent
for voluntary enlistment (2004)
Manpower available for military service:
males age 18-49: 24,488,008 (2005 est.)
Manpower fit for military service:
males age 18-49: 19,058,337 (2005 est.)
Manpower reaching military service age
annually:
males: 1 ,063,233 (2005 est.)
Military expenditures - dollar figure: $6.07 billion
(2005 est.)
Military expenditures - percent of GDP: 0.8%
(2005 est.)','b5377b2b7d85e91af0c3ce67811d2a75012444e0627705885afe19eb614d5310','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6bd3acbe128b6c3be7ed3624508ce8e1587015c926072c82f480d8408f2b4f8',2007,'MC','Monaco','military-and-security',925,'Military - note: defense is the responsibility of
France; the Palace Guard performs ceremonial duties
(2003)','39eedd7ddb77d7c2e1a4103f5ecfa62903c83d9861c32376621ed4e7d0f9514f','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b9f09a320a8ea14e305bff116ba4fe1bab056b4396af3dbe3a66a01f5bb1449',2007,'AO','Angola','military-and-security',940,'Military branches: Namibian Defense Force: Army
(includes Air Wing), Navy, Police
Military service age and obligation: 18 years of
age for voluntary military service (2001)
Manpower available for military service:
males age 18-49: 441 ,293 (2005 est.)
Manpower fit for military service:
males age 18-49: 217,1 18 (2005 est.)
Military expenditures - dollar figure: $149.5
million (2005 est.)
Military expenditures - percent of GDP: 2.3%
(2005 est.)','714c62efb285e92b24e9168bbb8f7c331b0284ab3809e00c898f2e52013b6ce8','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('438e3893f750e070c5c3b10e4add26e082a61bb8cd714f9982a68184e733056b',2007,'NR','Nauru','military-and-security',949,'Military branches: no regular military forces; Nauru
Police Force
Manpower available for military service:
males age 18-49: 2,874 (2005 est.)
Manpower fit for military service:
males age 18-49: 1 ,963 (2005 est.)
Military expenditures - dollar figure: NA
Military expenditures - percent of GDP: NA
Military - note: Nauru maintains no defense forces;
under an informal agreement, defense is the
responsibility of Australia','f94880afe83d26a5edf50121b990bad658c6f0416e1299c81c1bdd38d6e7264d','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7148280343c70f2f6b1188511d379d6e56e010f278812a1f302e7f557d3b3c5',2007,'NP','Nepal','military-and-security',957,'Military branches: Royal Nepalese Army (includes
Royal Nepalese Army Air Service); Nepalese Police
Force
Military service age and obligation: 18 years of
age for voluntary military service (2001)
Manpower available for military service:
males age 18-49: 6,107,091 (2005 est.)
Manpower fit for military service:
males age 18-49: 4.193 million (2005 est.)
Manpower reaching military service age
annually:
males: 308,031 (2005 est.)
Military expenditures • dollar figure: $1 04.9
million (2005 est.)
Military expenditures - percent of GDP: 1 .5%
(2005 est.)
_ ...
Military branches: Royal Netherlands Army, Royal
Netherlands Navy (includes Naval Air Service and
Marine Corps), Royal Netherlands Air Force
(Koninklijke Luchtmacht or KLu), Royal Military Police,
Defense Interservice Command (DICO) (2004)
Military service age and obligation: 20 years of
age for an all-volunteer force (2004)
Manpower available for military service:
males age 20-49: 3,557,91 8 (2005 est.)
Manpower fit for military service:
males age 20-49: 2,856,691 (2005 est.)
Manpower reaching military service age
annually:
males: 99,934 (2005 est.)
Military expenditures - dollar figure: $9,408 billion
(2004)
Military expenditures - percent of GDP: 1 .6%
(2004)','e5dedcd28bf1ef8a9983c78180c690be6a2163db8c3a71554cdd5d0a72336240','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86ab76092ff1db1c3ea17a50767cc0dd099e884ed5ceb4ae70506a2acfa15af9',2007,'NE','Niger','military-and-security',975,'Military branches: Niger Armed Forces (Forces
Armees Nigeriennes, FAN): Army, National Air Force
(2005)
Military service age and obligation: 1 8 years of
age for compulsory military service; conscript service
obligation - two years (2004)
Manpower available for military service:
males age 18-49: 2,135,680 (2005 est.)
Manpower fit for military service:
males age 78-49: 1,180,027 (2005 est.)
Manpower reaching military service age
annually:
males: 126,719 (2005 est.)
Military expenditures - dollar figure: $44.78
million (2005 est.)
Military expenditures - percent of GDP: 1 .4%
(2005 est.)
Military branches: Army, Navy, Air Force
Military service age and obligation: 18 years of
age for voluntary military service (2001)
Manpower available for military service:
males age 18-49: 26,804,314 (2005 est.)
Manpower fit for military service:
males age 78-45/ 15,053,936 (2005 est.)
Manpower reaching military service age
annually:
males: 1,353,161 (2005 est.)
Military expenditures - dollar figure: $737.6
million (2005 est.)
Military expenditures - percent of GDP: 0.8%
(2005 est.)','9e33f454c56314253b73fa5075ee327c735369ac878a1ec5da023e771ac99346','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e079066f0611fee53a36f964ae4f505586c358619ea256cec6c77305554e14be',2007,'NU','Niue','military-and-security',990,'Military branches: no regular indigenous military-
forces; Police Force
Military - note: defense is the responsibility of New
Zealand','3072e6c7d2953977e922102c98df20b3ed0f85e31d717d95c627eda427d3a076','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b6a1dac8ffb40d3c6b14e95e9f1eb6e2b3cc64de86a2b59fd0ed87ac6feac09f',2007,'MP','Northern Mariana Islands','military-and-security',1002,'Military - note: defense is the responsibility of the
US
Military - note: defense is the responsibility of the
US; launch support facility is part of the Ronald
Reagan Ballistic Missile Defense Test Site (RTS)
administered by US Army Space and Missile Defense
Command (SMDC)
Transnationa
s s u e s
Disputes - international: claimed by Marshall
Islands
605','0795bce9bd4a5dc088a374c45203b139aa93eeb977cc552ece09d3bcd432026e','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b21fb0fe162b541cfdc0620e17c6e1d1b565ca52898915d8fa6f477b2afa0f0',2007,'OM','Oman','military-and-security',1011,'Military branches: Royal Omani Armed Forces:
Royal Army ol Oman, Royal Navy ol Oman, Royal Air
Force ol Oman (RAFO) (2005)
Military service age and obligation: 1 8 years of
age for voluntary military service (2001)
Manpower available for military service:
males age 18-49: 719,871 (2005 est.)
Manpower fit for military service:
males age 18-49: 581 ,444 (2005 est.)
Manpower reaching military service age
annually:
males: 26,391 (2005 est.)
Military expenditures - dollar figure: $252.99
million (2004)
Military expenditures - percent of GDP: 1 1 .4%
(2003)','128d5219dcdf889eb8e99e84e39abb0e4776f227afa198e07230b561fb8c7189','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ace66918fa325aac57badb8923ede0af36726c3d0dae67db62c1b5b4901b871',2007,'PK','Pakistan','military-and-security',1020,'Military branches: Army (includes National Guard),
Navy (includes Marines), Air Force (2006)
Military service age and obligation: 16 years of
age for voluntary military service; soldiers cannot be
deployed for combat until age of 18 (2001)
Manpower available for military service:
males age 16-49: 39,028,014 (2005 est.)
Manpower fit for military service:
males age 16-49: 29,428,747 (2005 est.)
Manpower reaching military service age
annually:
males: 1,969,055 (2005 est.)
Military expenditures - dollar figure: $4.26 billion
(2005 est.)
Military expenditures - percent of GDP: 3.9%
(2005 est.)','14f4d5fde1d16baae482b220e89adeef1c91525a2b8840950891c722213cc07d','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e69b45e495a4b382590b66bc444820d7bd58984f6d0b4258da408afa2066515',2007,'PW','Palau','military-and-security',1029,'Military branches: no regular military forces; Police
Force
Military expenditures • dollar figure: NA
Military expenditures • percent of GDP: NA
Military - note: defense is the responsibility of the
US; under a Compact of Free Association between
Palau and the US, the US military is granted access to
the islands for 50 years','8af15175f8865f3291b21cf8d26e9d407f99160b113c93fca87d6f0393d101d8','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b76b47017914fed4cd619376c29d66827dc55f6b5779e60739dd7e2c7b8dcde',2007,'DO','Dominican Republic','military-and-security',1047,'Military branches: no regular indigenous military
forces; paramilitary National Guard, Police Force
Military - note: defense is the responsibility of the
US','40d94241fa74da21c3d6d212fe669b3b51ffca68d8fb7edd6576e40238a0785a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e34206514adbf872abfda149478b3b6ad5faae220181fce0a6c323e25176d15',2007,'UA','Ukraine','military-and-security',1058,'Military branches: Land Forces, Naval Forces, Air
and Air Defense Forces (AMR), Special Operations,
Civil Defense (2005)
Military service age and obligation: after
1 January 2007 conscription will no longer be basis for
military service; all military inductees (including
women) will be volunteers who contract for an initial
five-year term of service; subsequent voluntary
service contracts would be for successive three-year
long terms; minimum age for voluntary military service
is 18; currently minimum age is 20 for compulsory
military service, 18 years of age in wartime; conscript
service obligation is for 12 months (2004)
Manpower available for military service:
males age 20-49: 5,061 ,984 (2005 est.)
Manpower fit for military service:
males age 20-49: 3,932,579 (2005 est.)
Manpower reaching military service age
annually:
males: 172,093 (2005 est.)
Military expenditures • dollar figure: $985 million
(2002)
Military expenditures - percent of GDP: 2.47%
(2002)
Military branches: Ground Forces (SV), Navy
(VMF), Air Forces (VVS); Airborne Troops (VDV),
Strategic Rocket Troops (RVSN), and Space Troops
(KV) are independent "combat arms," not subordinate
to any of the three branches
Military service age and obligation: Russia has
adopted a mixed conscript-contract force; 1 8-27 years
of age; males are registered for the draft at 17 years
of age; length of compulsory military service is two
years; plans as of November 2005 call for reduction in
mandatory service to one year by 2008; 30% of
Russian army personnel were contract servicemen at
the end of 2005; planning calls for volunteer
servicemen to compose 70% of armed forces by
2010, with the remaining servicemen consisting of
conscripts; at the end of 2005, the Army had 40
all-volunteer permanent-readiness units, with another
20 permanent-readiness units to be formed in 2006;
88 MoD units have been designated as permanent
readiness units and are expected to become
all-volunteer by end 2007; these include most air
force, naval, and nuclear arms units, as well as all
airborne and naval infantry units, most motorized rifle
brigades, and all special forces detachments (2005)
Manpower available for military service:
males age 18-49: 35,247,049 (2005 est.)
Manpower fit for military service:
males age 78-49:21,049,651 (2005 est.)
Manpower reaching military service age
annually:
males: 1,286,069 (2005 est.)
Military expenditures - dollar figure: NA
Military expenditures - percent of GDP: NA
Military branches: Ground Forces, Naval Forces,
Air Forces (Viyskovo-Povitryani Syly), Air Defense
Forces (2002)
Military service age and obligation: 18-27 years of
age for compulsory and voluntary military service;
conscript service obligation - 1 8 months for Army and
Air Force, 24 months for Navy (2004)
Manpower available for military service:
males age 18-49: 1 1,067,239 (2005 est.)
Manpower fit for military service:
males age 18-49: 7,1 14,337 (2005 est.)
Manpower reaching military service age
annually:
males: 378,176 (2005 est.)
Military expenditures - dollar figure: $61 7.9
million (FY02)
Military expenditures - percent of GDP: 1 .4%
(FY02)','2d3b45869817c62a2d732bb4b25d02c84c255f143fa0d05c94c6a968e0090fb4','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7cc023e57a13f09f4224fc0c5775b5c40e1a0cb2007f8a641fbb6cf494d8388d',2007,'RW','Rwanda','military-and-security',1068,'Military branches: Rwandan Defense Forces:
Army, Air Force
Military service age and obligation: 16 years of
age for voluntary military service; no conscription
(2001)
Manpower available for military service:
males age 16-49: 2,004,750 (2005 est.)
Manpower fit for military service:
males age 16-49: 1 ,103,823 (2005 est.)
Military expenditures - dollar figure: $53.66
million (2005 est.)
Military expenditures • percent of GDP: 2.9%
(2005 est.)
Military - note: defense is the responsibility of the
UK','9257c799a580cebd5eefb2ddbb43e7b4795e3215298a7df9b0bf71a66d9c4a5f','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9aa46393248409629bebc9bc8b8cbc560757c690765c6b6f11c28f3861250019',2007,'KN','Saint Kitts and Nevis','military-and-security',1077,'Military branches: Saint Kitts and Nevis Defense
Force (includes Coast Guard), Royal Saint Kitts and
Nevis Police Force
Military service age and obligation: 18 years of
age (est.) (2004)
Military expenditures - dollar figure: NA
Military expenditures - percent of GDP: NA','36039699647248c5b50c176f21983615de7d2686800b050ce70052f63ffeeba2','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0ce6aa7e21541c725cddf5f8f6f039483ad0f9e4cd25faf2ad3d43b68f2f9ea',2007,'WS','Samoa','military-and-security',1097,'Military branches: no regular armed services;
Samoa Police Force
Military expenditures - dollar figure: NA
Military expenditures - percent of GDP: NA
Military - note: Samoa has no formal defense
structure or regular armed forces; informal defense
ties exist with NZ, which is required to consider any
Samoan request for assistance under the 1 962 Treaty
of Friendship','0306845ab4c19b8f73270573a1e97a3dc30344af541e96c9903e898a93b51cd1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1413b8ac875d0f88c8d15f71b147b621468ee3d23a48eacbb48a87ea076f5740',2007,'SA','Saudi Arabia','military-and-security',1107,'Military branches: Land Forces (Army), Navy, Air
Force, Air Defense Force, National Guard, Ministry of
Interior Forces (paramilitary)
Military service age and obligation: 18 years of
age (est.); no conscription (2004)
Manpower available for military service:
males age 18-49: 7,648,999 (2005 est.)
Manpower fit for military service:
males age 18-49: 6,592,709 (2005 est.)
Manpower reaching military service age
annually:
males: 247,334 (2005 est.)
Military expenditures - dollar figure: $18 billion
(2002)
Military expenditures - percent of GDP: 10%
(2002)','02201b4cc4e06bbff9943d301642f05d22a978091256a333007087dbd67f3f8e','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f5e139547639d55062f23eadd257fe93e8b4e01c77a495ac47e68c7d410de207',2007,'SN','Senegal','military-and-security',1114,'Military branches: Army, Navy (Marine
Senegalaise), Air Force (2005)
Military service age and obligation: 1 8 years of
age for compulsory and voluntary military service;
conscript service obligation - two years (2004)
Manpower available for military service:
males age 18-49: 2,183,343 (2005 est.)
Manpower fit for military service:
males age 18-49: 1,300,502 (2005 est.)
Manpower reaching military service age
annually:
males: 124,096 (2005 est.)
Military expenditures - dollar figure: $1 1 7.3
million (2005 est.)
Military expenditures - percent of GDP: 1 .4%
(2005 est.)
489
Senegal (continued)','a24c2a9d912a88a4fcbca62af30ddb7759df6708e778b477216bacff376bc3a6','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8ecb8a93f71ea899ba91a6f318590d32db1b885a2bc9d53e0d732eb85002ef6d',2007,'ME','Montenegro','military-and-security',1122,'Military branches: Serbian and Montenegrin Armed
Forces (Vojska Srbije i Crne Gore, VSCG): Ground
Forces, Air and Air Defense Forces, Naval Forces
(2005)
Military service age and obligation: 1 9 years of
age (nine months compulsory service) (2004)
Manpower available for military service:
males age 19-49: 2,389,729 (2005 est.)
Manpower fit for military service:
males age 19-49: 1 ,959,166 (2005 est.)
Manpower reaching military service age
annually:
males: 81 ,033 (2005 est.)
Military expenditures - dollar figure: $654 million
(2002)
Military expenditures - percent of GDP: NA','085bb083cc6bf2515c99d3176ef288104ef65affefd16c6111dd169ed2f9c2c0','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f259771c5431b2afc8b44764d549477ddf7738838c39972dd1d41915a784b068',2007,'SL','Sierra Leone','military-and-security',1132,'Military branches: Seychelles Defense Force:
Army, Coast Guard (includes Navy Wing, Air Wing),
National Guard (2005)
Military service age and obligation: 1 8 years of
age (est.); no conscription (2001)
Manpower available for military service:
males age 18-49: 21 ,612 (2005 est.)
Manpower fit for military service:
males age 18-49: 16,122 (2005 est.)
Military branches: Republic of Sierra Leone Armed
Forces (RSLAF): Army (includes Air Wing, Maritime
Wing)
Military service age and obligation: 1 8 years of
age (est.); no conscription (2001)
Manpower available for military service:
males age 18-49: 1 ,1 10,077 (2005 est.)
Manpower fit for military service:
males age 18-49: 552,785 (2005 est.)
Military expenditures • dollar figure: $1 4.25
million (2005 est.)
Military expenditures - percent of GDP: 1 .7%
(2005 est.)','9821f5a8d26b8533313bd772eda572646c1bb5cc318dd2bb3a3ff5d352996a83','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a76aa66c155af7414a5227f1b82775275bd3d075855b8264257ac001720eac12',2007,'SK','Slovakia','military-and-security',1146,'Military branches: Armed Forces of the Slovak
Republic (Ozbrojene Sily Slovenskej Republiky): Land
Forces (Pozemne Sily), Air Forces (Vzdusne Sily),
Training and Support Forces (Vycviku a Podpory Sily)
(2005)
Military service age and obligation: complete
transition to an all-volunteer professional force went
into effect at the beginning of 2006 after 140 years of
mandatory army service; volunteers include women,
with minimum age of 17 years (2005)
Manpower available for military service:
males age 18-49: 1 ,351 ,848 (2005 est.)
Manpower fit for military service:
males age 18-49: 1 ,089,645 (2005 est.)
Manpower reaching military service age
annually:
males: 41 ,544 (2005 est.)
Military expenditures - dollar figure: $406 million
(2002)
Military expenditures - percent of GDP: 1 .87%
FY05 (2005)
502
Slovakia (continued)','8b0a10a7c5ef7fa1cc6d4e9ba433d984b273610f305da6cdcdde6a20fd933989','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a95ad48ca44db7537ff39f3a72eb3a447493457baabe3d08a76d15db6c3ea86',2007,'KE','Kenya','military-and-security',1160,'Military branches: a Somali National Army was
attempted under the interim government; numerous
factions and clans maintain independent militias, and
the Somaliland and Puntland regional governments
maintain their own security and police forces
Military service age and obligation: 18 years of
age (est.) (2001)
Manpower available for military service:
males age 18-49: 1 ,787,727 (2005 est.)
Manpower fit for military service:
males age 18-49: 1 ,022,360 (2005 est.)
Military expenditures - dollar figure: $22.34
million (2005 est.)
Military expenditures - percent of GDP: 0.9%
(2005 est.)','88b60a75d083839829f9c7f1ec55726094ea7841ded7aedf6a1541e1d7fb5022','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c57d57686859465e44ba99a94cec3c2e178d90df160ae4e231c00c631b2ba83a',2007,'DZ','Algeria','military-and-security',1164,'Military branches: Army, Navy (Armada Espariola,
AE; includes Marine Corps). Air Force (Ejercito del
Aire, EdA) (2006)
Military service age and obligation: 20 years of
age (2004)
Manpower available for military service:
males age 20-49: 9,366,588 (2005 est.)
Manpower fit for military service:
males age 20-49: 7,623,356 (2005 est.)
Manpower reaching military service age
annually:
males: 233,384 (2005 est.)
Military expenditures - dollar figure: S9.906.5
million (2003)
Military expenditures - percent of GDP: 1 .2%
(2003)','bf37138bb60940119329f2b67a24c951eb754adf178102374d6c9745bf78191e','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('293020dae53fa214392ae198b3053cc3c01a09e65fda840418d463878ef861ce',2007,'PH','Philippines','military-and-security',1170,'Military - note: Spratly Islands consist of more than
100 small islands or reefs, of which about 45 are
claimed and occupied by China, Malaysia, the
Philippines, Taiwan, and Vietnam','ecda69000321996e57142a134a2c77ab4881593125ec002cab19991c6e0fb428','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1dfc4d3883b6d974a8c8bf6e9becdd76c7d8e7673b86c0f91b8d2f5beca5b87',2007,'LK','Sri Lanka','military-and-security',1171,'£
Military branches: Army, Navy, Air Force, Police
Force
Military service age and obligation: 18 years of
age for voluntary military service (2001 )
Manpower available for military service:
males age 18-49: 4,933,217 (2005 est.)
Manpower fit for military service:
males age 18-49: 3,789,627 (2005 est.)
Manpower reaching military service age
annually:
males: 174,049 (2005 est.)
Military expenditures - dollar figure: $606.2
million (2005 est.)
Military expenditures ■ percent of GDP: 2.6%
(2005 est.)
/','3cc5932a2d0af50d77f557e930bdae18a7933e67c1019d7d03c03c0e27ceed3f','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58652c1a76f142cafcf8bdea84632d1dc1ba86387051525f7cc2ece4862b793f',2007,'SD','Sudan','military-and-security',1187,'Military branches: Sudanese People''s Armed Forces
(SPAF): Army, Navy, Air Force, Popular Defense Force
Military service age and obligation: 1 8-30 years of
age for compulsory military service; conscript service
obligation - three years (August 2004)
Manpower available for military service:
males age 18-49: 8,291 ,695 (2005 est.)
Manpower fit for military service:
males age 18-49: 5,427,474 (2005 est.)
Manpower reaching military service age
annually:
males: 442,91 5 (2005 est.)
Military expenditures - dollar figure: $587 million
(2001 est.) (2004)
Military expenditures
(1999) (2004)
percent of GDP: 3%','7ecc34a83ee84506e6cc6ae7235f6662b843c336b718d5578bfba4d407f84ba8','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d7f31aa232cbc3ad7de916ce2c6d1191f9950d369072a9d04e55146970448eb',2007,'SE','Sweden','military-and-security',1198,'Military branches: Army, Royal Swedish Navy
(RSwN), Air Force (Flygvapnet)
Military service age and obligation: 19 years of
age for compulsory military service; conscript service
obligation - 7-17 months depending on conscript role;
after completing initial service, soldiers have a reserve
commitment until age of 47 (2004)
Manpower available for military service:
males age 19-49: 1 ,838,427 (2005 est.)
Manpower fit for military service:
males age 19-49: 1 ,493,668 (2005 est.)
Manpower reaching military service age
annually:
males: 58,724 (2005 est.)
Military expenditures - dollar figure: $5.51 billion
(2005 est.)
Military expenditures - percent of GOP: 1 .5%
(2005 est.)','8d06096e23f386885a85ff8719195b149107f44426fb7226a83abab091112da1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('02cd028a7e311cca84986688a50a15cd890ac1a0a88cf54a85eb565b0a28677f',2007,'UZ','Uzbekistan','military-and-security',1209,'Military branches: Ground Troops, Air and Air
Defense Troops, Mobile Troops (2005)
Military service age and obligation: 18 years of
age for compulsory military service; conscript service
obligation - two years (2004)
Manpower available for military service:
males age 18-49: 1 ,556,41 5 (2005 est.)
Manpower fit for military service:
males age 18-49: 1 ,244,941 (2005 est.)
Manpower reaching military service age
annually:
males: 87,846 (2005 est.)
Military expenditures - dollar figure: $35.4 million
(FY01)
Military expenditures - percent of GDP: 3.9%
(FY01)
Military branches: Army, Air and Air Defense
Forces, National Guard
Military service age and obligation: 18 years of
age for compulsory military service; conscript service
obligation -12 months (2004)
Manpower available for military service:
males age 18-49: 6,340,220 (2005 est.)
Manpower fit for military service:
males age 78-49:4,609,621 (2005 est.)
Manpower reaching military service age
annually:
males: 324,722 (2005 est.)
Military expenditures - dollar figure: $200 million
(FY97)
Military expenditures - percent of GDP: 2%
(FY97)','6deee5f4d64c5a0920a75201cb1e5b7141bf25ba6bfe86c95471dbf1e8d8c06c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03b43c4523287c03cb939904ea9bd88f53c8a65303cfc215a62aece28e842b94',2007,'TK','Tokelau','military-and-security',1219,'Zealand
note:
defense is the responsibility of New
Tr
a n s n a t
i o n a 1
Issues
Disputes - international: none','03c360e51fd5223e094e863be34003c0dd7fd0d34212f592757b6b80b4a8e235','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9375d42e8ec5ea4704db809e9e57ab8fc12a4ab679f41109d58d2fd7000403b6',2007,'TO','Tonga','military-and-security',1220,'. Niuafo''ou
Talahi
Niuatoputapu ''
South Pacific Ocean
Vava''u
Group
Vava''u
*Neialu
Kao island
Ha''apai Group
-Pangai
.NUKUALOFA
Tongatapu
Group
Minwva Reef not shown','24bafbd5315cdded129b0aebee4d779cc152a1b2f10bde1965eb532209c4ab1c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06f7e4ab071460969bf4d55d3dafd8b7617181c7fb359697aaeb30a1c631af03',2007,'TV','Tuvalu','military-and-security',1230,'Military branches: no regular military forces;
national police force
Military expenditures • dollar figure: NA
Military expenditures - percent of GDP: NA','fb41fd4471b6e43e09accac84409c42be8c60ed3c1074677307b3cb43eec6844','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1f759a162327488bc322742a194f66779b425f2aebd2c0542e7e6e31d14fb0b0',2007,'UG','Uganda','military-and-security',1238,'Military branches: Ugandan Peoples'' Defense
Force (UPDF): Army, Marine Unit, Air Wing
Military service age and obligation: 18 years of
age for compulsory and voluntary military duty; the
government has stated that recruitment below that
age could occur with proper consent and that "no
person under the apparent age of 13 years shall be
enrolled in the armed forces"
Manpower available for military service:
males age 18-49: 5,012,620 (2005 est.)
Manpower fit for military service:
males age 18-49: 2,889,808 (2005 est.)
Military expenditures - dollar figure: $192.8
million (2005 est.)
Military expenditures - percent of GDP: 2.2%
(2005 est.)','8442fcfdb148246173b3991705e586d8c1312928567882f5690817dd4d72cab9','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70ad22d2934b59ed1499e6a6121c017ee0ee861ebfedcbbc9fb0485397e9a500',2007,'QA','Qatar','military-and-security',1249,'Military branches: Army, Navy (includes Marines
and Coast Guard), Air and Air Defense Force,
paramilitary forces (includes Federal Police Force)
Military service age and obligation: 1 8 years of
age (est.); no conscription (2001)
578','a092841201941a154b2181f9159c4762314c3e22f29ff02e60e08d576404c74e','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43956f8b087f37ebe0607a150d8322af61bd255386eada024c04bdd02a1a19de',2007,'GB','United Kingdom','military-and-security',1250,'1 lio inland ol Rockan
la not ihown
NOHTH
ATLANTIC
OCEAN
Sullom I
Terminal"
n,,ll |/
ORKNEY «A
ISLANDS
''JrSScapa
.erwick
SHETLAND
ISLANDS
J Scotland
t^Bon Nevis
Dundee.
igemoutr\\ -
• "Edinburgh
Glasgow
Peterhead
^Aberdeen
North
Sea
.ondonderry
Ireland /h » M
Bella:
Newcastle
upon Tyne. \\
as^ Middlesbrough
Kingston
IsJaolMan , .....uji
Irish
Sea
Isle ol M
iu>
¥
Kingston
upon Hul^
'' Manchester ~*
*tiverpool
Sea ''
y The Fens .
r .Birmingham
Wab6
Felixstowe^,
. Cardiff '' LONDON jT
* -Bristol * Do\\;er<
Southampton^ Portsmouth " ''
'' Channel,
PlyiTrOuth, / Tunnel I
"Falmouth -^e','1f94565d1c03527ad87a605d8048fd6cd3043e08062cfc6fe8fb55213e2d05cc','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('33b753d7ed7caaed6cefd35527b41d53ac57e8b206cbe9a32d53b667db6c25d5',2007,'UY','Uruguay','military-and-security',1258,'Military branches: Army, Navy (includes Naval Air
Arm, Marines, Maritime Prefecture in wartime), Air
Force
Military service age and obligation: 18 years of
age for voluntary and compulsory military service
(2001)
Manpower available for military service:
males age 18-49: 764,408 (2005 est.)
Manpower fit for military service:
males age 18-49: 637,445 (2005 est.)
Military expenditures - dollar figure: $371 .2
million (2005 est.)
Military expenditures - percent of GDP: 2.1%
(2005 est.)','6748217682edc110866ddfbf185d0aa8b636a7bd5e559553b91a9b507f332404','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('81edf377455bc889cf0b33bed44bbaaebb462dc23ee276c314869fdb725bb59c',2007,'VU','Vanuatu','military-and-security',1260,'Military branches: no regular military forces;
security forces comprise the Vanuatu Police Force
(VPF) and paramilitary Vanuatu Mobile Force (VMF),
which includes Vanuatu''s naval force, known as the
Police Maritime Wing (PMW); border security in
Vanuatu is the joint responsibility of the Customs and
Inland Revenue Service, VPF, VMF, and PMW (2003)
Military expenditures - dollar figure: NA
Military expenditures - percent of GDP: NA
Military branches: National Armed Forces (Fuerzas
Armadas Nacionales or FAN) - includes Ground
Forces or Army (Fuerzas Terrestres or Ejercito),
Naval Forces (Fuerzas Navales or Armada; includes
Marines. Coast Guard), Air Force (Fuerzas Aereas or
Aviacion), Armed Forces of Cooperation or National
Guard (Fuerzas Armadas de Cooperacion or Guardia
Nacional)
Military service age and obligation: 18 years of
age for compulsory and voluntary military service;
conscript service obligation - 30 months (2004)
Manpower available for military service:
males age 18-49: 6,236,012 (2005 est.)
Manpower fit for military service:
males age 18-49: 4,907,947 (2005 est.)
Manpower reaching military service age
annually:
males: 252,396 (2005 est.)
Military expenditures • dollar figure: $1 .61 billion
(2005 est.)
Military expenditures ■ percent of GDP: 1 .2%
(2005 est.)','fcb85569827496aa73a96204525cda8758e71e5a245f76ea7909608c1b9de37c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('332c62d074c14806a2469e5fc91c9fbc2d2b2f4c76a1765eee4bda8db363f3df',2007,'IL','Israel','military-and-security',1272,'Military expenditures - dollar figure: NA
Military expenditures - percent of GDP: NA','d2acefa3fd457ad957d735b2c25cb20415066f5b328cda632300f4829a0aa076','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7e76d851b8e1e80600ac78211c12582e3439910fba4583024f86663eb59302a',2007,'ZM','Zambia','military-and-security',1289,'Military branches: Zambian National Defense
Force (ZNDF): Army, Air Force, Police, National
Service
Military service age and obligation: 18 years of
age (est.) (2004)
Manpower available for military service:
males age 18-49: 2,219,739 (2005 est.)
Manpower fit for military service:
males age 18-49: 1 ,043,702 (2005 est.)
Military expenditures • dollar figure: $121.7
million (2005 est.)
Military expenditures - percent of GDP: 1 .8%
(2005 est.)
Military branches: Zimbabwe Defense Forces
(ZDF): Zimbabwe National Army, Air Force of
Zimbabwe (AFZ), Zimbabwe Republic Police (2005)
Military service age and obligation: 1 8 years of
age (est.) (2004)
Manpower available for military service:
males age 18-49: 2,840,053 (2005 est.)
Manpower fit for military service:
males age 18-49: 1,148,590 (2005 est.)
Military expenditures - dollar figure: $124.7
million (2005 est.)
Military expenditures - percent of GDP: 4%
(2005 est.)
Military branches: Army, Navy (includes Marine
Corps), Air Force, Coast Guard Administration, Armed
Forces Reserve Command, Combined Service
Forces Command, Armed Forces Police Command
Military service age and obligation: 1 9-35 years of
age for military service; service obligation 16 months
(to be shortened to 12 months in 2008); women in Air
Force service are restricted to noncombat roles (2005)
Manpower available for military service:
males age 19-49: 5,883,828 (2005 est.)
Manpower fit for military service:
males age 19-49: 4,749,537 (2005 est.)
Manpower reaching military service age
annually:
males: 174,173 (2005 est.)
Military expenditures ■ dollar figure: $7.93 billion
(2005 est.)
Military expenditures - percent of GDP: 2.4%
(2005 est.)
Military - note: In November 2004, the European
Union heads of government signed a "Treaty
Establishing a Constitution lor Europe" that offers
possibilities - with some limits - for increased defense
and security cooperation. If ratified, in a process that
may take some two years, this treaty will in effect
make operational the European Security and Defense
Policy (ESDP) approved in the 2000 Nice Treaty.
Despite limits of cooperation for some EU members,
development of a European military planning unit is
likely to continue. So is creation of a rapid-reaction
military force and a humanitarian aid system, which
the planning unit will support. France, Germany,
Belgium, Netherlands, Luxembourg, and Italy
continue to press for wider coordination. The
iive-nation Eurocorps - created in 1 992 by France,
Germany, Belgium, Spain, and Luxembourg - has
already deployed troops and police on peacekeeping
missions to Bosnia and Herzegovina, Macedonia, and
the Democratic Republic of Congo and assumed
command of the International Security Assistance
Force (ISAF) in Afghanistan in August 2004.
Eurocorps directly commands the 5,000-man
Franco-German Brigade, the Multinational Command
Support Brigade, and EUFOR, which took over from
SFOR in Bosnia in December 2004. Other troop
contributions are under national command -
commitments to provide 67,100 troops were made at
the Helsinki EU session in 2000. Some 56,000 EU
troops were actually deployed in 2003. In
August 2004, the new European Defense Agency,
tasked with promoting cooperative European defense
capabilities, began operations. In November 2004, the
EU Council of Ministers formally committed to creating
thirteen 1 ,500-man "battle groups" by the end of 2007,
to respond to international crises on a rotating basis.
Twenty-two of the EU''s 25 nations have agreed to
supply troops. France, Italy, and the UK are to form
the first three battle groups in 2005, with Spain to
follow. In May 2005, Norway, Sweden, and Finland
agreed to establish one of the battle groups, possibly
to include Estonian forces. The remaining groups are
to be formed by 2007. (2005)','b778c42533433d75705d1202b6ef4b4a5dbbaadf904fc3d62c86c604a40dc860','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d3a6c999be949c13643fd55dd8a555ac41f3aae97eff91676a0dea94c7351a3',2007,'ZW','Zimbabwe','military-and-security',20,'Military expenditures - dollar figure
Military expenditures - percent of GDP
Factbook fields with Rank Order pages are easily identified with a
small bar chart icon to the right of the data field title.
Not all Rank Order pages include the same number of entries because
information for a particular field is not available for all countries.
In addition, not all data fields are suitable for displaying as Rank
Order pages, such as those containing textual information. Textual
information is more readily viewed by clicking on the Field Listing
icon next to the Data field title. The other icon next to the data
field title provides the definition of the field.
All of the ''Rank Order'' pages can be downloaded as tab-delimited data
files and can be opened in other applications such as spreadsheets and
databases. To save a Rank Order page in a spreadsheet, first click on
the ''Download Datafile'' choice above the Rank Order page you selected;
then, at the top of your browser window, click on ''File'' and ''Save As''.
After saving the file, open the spreadsheet, find the saved file, and
''Open'' it.
Additional Rank Order pages being considered for future updates of the
Factbook Web site include:
Median age
Literacy
Population below the poverty line
This page was last updated on 4 April, 2006
=====================================================================
Appendixes
Appendix A - Abbreviations
Appendix B - International Organizations and Groups
Appendix C - Selected International Environmental Agreements
Appendix D - Cross-Reference list of Country Data Codes
Appendix E - Cross-Reference List of Hydrographic Data Codes
Appendix F - Cross-Reference List of Geographic Names
Appendix G - Weights and Measures
======================================================================
Notes and Definitions
Along with regular information updates, The World Factbook features
several new or revised fields. In the Government category, the
"Capital" entry has been greatly expanded and now contains up to four
subfields, including significant new information having to do with
time. The subfields consist of the name of the capital itself, its
geographic coordinates, the time difference at the capital from
coordinated universal time (UTC), and, if applicable, information on
daylight saving time (DST). Where appropriate, a special note has been
added to highlight those countries that have multiple time zones. The
Transnational issues category now has a "Trafficking in persons" entry.
Human trafficking connotes modern-day slavery and this important new
field will include information on the most egregious countries (Tier 2
Watch List and Tier 3) as listed in the US State Department''s annual
report.
Abbreviations: This information is included in Appendix A:
Abbreviations, which includes all abbreviations and acronyms used in
the Factbook, with their expansions.
Acronyms: An acronym is an abbreviation coined from the initial letter
of each successive word in a term or phrase. In general, an acronym
made up solely from the first letter of the major words in the expanded
form is rendered in all capital letters (NATO from North Atlantic
Treaty Organization; an exception would be ASEAN for Association of
Southeast Asian Nations). In general, an acronym made up of more than
the first letter of the major words in the expanded form is rendered
with only an initial capital letter (Comsat from Communications
Satellite Corporation; an exception would be NAM from Nonaligned
Movement). Hybrid forms are sometimes used to distinguish between
initially identical terms (WTO: for World Trade Organization and WToO
for World Tourism Organization.)
Administrative divisions: This entry generally gives the numbers,
designatory terms, and first-order administrative divisions as approved
by the US Board on Geographic Names (BGN). Changes that have been
reported but not yet acted on by BGN are noted.
Age structure: This entry provides the distribution of the population
according to age. Information is included by sex and age group (0-14
years, 15-64 years, 65 years and over). The age structure of a
population affects a nation''s key socioeconomic issues. Countries with
young populations (high percentage under age 15) need to invest more in
schools, while countries with older populations (high percentage ages
65 and over) need to invest more in the health sector. The age
structure can also be used to help predict potential political issues.
For example, the rapid growth of a young adult population unable to
find employment can lead to unrest.
Agriculture - products: This entry is an ordered listing of major
crops and products starting with the most important.
Airports: This entry gives the total number of airports or airfields
recognizable from the air. The runway(s) may be paved (concrete or
asphalt surfaces) or unpaved (grass, earth, sand, or gravel surfaces)
but may include closed or abandoned installations. Airports or
airfields that are no longer recognizable (overgrown, no facilities,
etc.) are not included. Note that not all airports have accomodations
for refueling, maintenance, or air traffic control.
Airports - with paved runways: This entry gives the total number of
airports with paved runways (concrete or asphalt surfaces) by length.
For airports with more than one runway, only the longest runway is
included according to the following five groups - (1) over 3,047 m, (2)
2,438 to 3,047 m, (3) 1,524 to 2,437 m, (4) 914 to 1,523 m, and (5)
under 914 m. Only airports with usable runways are included in this
listing. Not all airports have facilities for refueling, maintenance,
or air traffic control.
Airports - with unpaved runways: This entry gives the total number of
airports with unpaved runways (grass, dirt, sand, or gravel surfaces)
by length. For airports with more than one runway, only the longest
runway is included according to the following five groups - (1) over
3,047 m, (2) 2,438 to 3,047 m, (3) 1,524 to 2,437 m, (4) 914 to 1,523
m, and (5) under 914 m. Only airports with usable runways are included
in this listing. Not all airports have facilities for refueling,
maintenance, or air traffic control.
Appendixes: This section includes Factbook-related material by topic.
Area: This entry includes three subfields. Total area is the sum of
all land and water areas delimited by international boundaries and/or
coastlines. Land area is the aggregate of all surfaces delimited by
international boundaries and/or coastlines, excluding inland water
bodies (lakes, reservoirs, rivers). Water area is the sum of the
surfaces of all inland water bodies, such as lakes, reservoirs, or
rivers, as delimited by international boundaries and/or coastlines.
Area - comparative: This entry provides an area comparison based on
total area equivalents. Most entities are compared with the entire US
or one of the 50 states based on area measurements (1990 revised)
provided by the US Bureau of the Census. The smaller entities are
compared with Washington, DC (178 sq km, 69 sq mi) or The Mall in
Washington, DC (0.59 sq km, 0.23 sq mi, 146 acres).
Background: This entry usually highlights major historic events and
current issues and may include a statement about one or two key future
trends.
Birth rate: This entry gives the average annual number of births
during a year per 1,000 persons in the population at midyear; also
known as crude birth rate. The birth rate is usually the dominant
factor in determining the rate of population growth. It depends on both
the level of fertility and the age structure of the population.
Budget: This entry includes revenues, expenditures, and capital
expenditures. These figures are calculated on an exchange rate basis,
i.e., not in purchasing power parity (PPP) terms.
Capital: This entry gives the name of the seat of government, its
geographic coordinates, the time difference relative to Coordinated
Universal Time (UTC) and the time observed in Washington, DC, and, if
applicable, information on daylight saving time (DST). Where
appropriate, a special note has been added to highlight those countries
that have multiple time zones.
Climate: This entry includes a brief description of typical weather
regimes throughout the year.
Coastline: This entry gives the total length of the boundary between
the land area (including islands) and the sea.
Communications: This category deals with the means of exchanging
information and includes the telephone, radio, television, and Internet
host entries.
Communications - note: This entry includes miscellaneous
communications information of significance not included elsewhere.
Constitution: This entry includes the dates of adoption, revisions,
and major amendments.
Coordinated Universal Time (UTC): UTC is the international atomic time
scale that serves as the basis of timekeeping for most of the world.
The hours, minutes, and seconds expressed by UTC represent the time of
day at the Prime Meridian (0 deg. longitude) located near Greenwich,
England as reckoned from midnight. UTC is calculated by the Bureau
International des Poids et Measures (BIPM) in Sevres, France. The BIPM
averages data collected from more than 200 atomic time and frequency
standards located at about 50 laboratories worldwide. UTC is the basis
for all civil time with the Earth divided into time zones expressed as
positive or negative differences from UTC. UTC is also referred to as
"Zulu time." See the Standard Time Zones of the World map included with
the Reference Maps.
Country data codes: see Data codes
Country map: Most versions of the Factbook provide a country map in
color. The maps were produced from the best information available at
the time of preparation. Names and/or boundaries may have changed
subsequently.
Country name: This entry includes all forms of the country''s name
approved by the US Board on Geographic Names (Italy is used as an
example): conventional long form (Italian Republic), conventional short
form (Italy), local long form (Repubblica Italiana), local short form
(Italia), former (Kingdom of Italy), as well as the abbreviation. Also
see the Terminology note.
Crude oil: See entry for oil.
Currency (code): This entry identifies the national medium of exchange
and, in parenthesis, gives the International Organization for
Standardization (ISO) 4217 alphabetic currency code for each country.
Current account balance: This entry records a country''s net trade in
goods and services, plus net earnings from rents, interest, profits,
and dividends, and net transfer payments (such as pension funds and
worker remittances) to and from the rest of the world during the period
specified. These figures are calculated on an exchange rate basis,
i.e., not in purchasing power parity (PPP) terms.
Data codes: This information is presented in Appendix D: Cross-
Reference List of Country Data Codes and Appendix E: Cross-Reference
List of Hydrographic Data Codes.
Date of information: In general, information available as of 1 January
2007, was used in the preparation of this edition.
Daylight Saving Time (DST): This entry is included for those entities
that have adopted a policy of adjusting the official local time
forward, usually one hour, from Standard Time during summer months.
Such policies are most common in mid-latitude regions.
Death rate: This entry gives the average annual number of deaths
during a year per 1,000 population at midyear; also known as crude
death rate. The death rate, while only a rough indicator of the
mortality situation in a country, accurately indicates the current
mortality impact on population growth. This indicator is significantly
affected by age distribution, and most countries will eventually show a
rise in the overall death rate, in spite of continued decline in
mortality at all ages, as declining fertility results in an aging
population.
Debt - external: This entry gives the total public and private debt
owed to nonresidents repayable in foreign currency, goods, or services.
These figures are calculated on an exchange rate basis, i.e., not in
purchasing power parity (PPP) terms.
Dependency status: This entry describes the formal relationship
between a particular nonindependent entity and an independent state.
Dependent areas: This entry contains an alphabetical listing of all
nonindependent entities associated in some way with a particular
independent state.
Diplomatic representation: The US Government has diplomatic relations
with 188 independent states, including 187 of the 192 UN members
(excluded UN members are Bhutan, Cuba, Iran, North Korea, and the US
itself). In addition, the US has diplomatic relations with 1
independent state that is not in the UN, the Holy See, as well as with
the EU.
Diplomatic representation from the US: This entry includes the chief
of mission, embassy address, mailing address, telephone number, FAX
number, branch office locations, consulate general locations, and
consulate locations.
Diplomatic representation in the US: This entry includes the chief of
mission, chancery, telephone, FAX, consulate general locations, and
consulate locations.
Disputes - international: This entry includes a wide variety of
situations that range from traditional bilateral boundary disputes to
unilateral claims of one sort or another. Information regarding
disputes over international terrestrial and maritime boundaries has
been reviewed by the US Department of State. References to other
situations involving borders or frontiers may also be included, such as
resource disputes, geopolitical questions, or irredentist issues;
however, inclusion does not necessarily constitute official acceptance
or recognition by the US Government.
Distribution of family income - Gini index: This index measures the
degree of inequality in the distribution of family income in a country.
The index is calculated from the Lorenz curve, in which cumulative
family income is plotted against the number of families arranged from
the poorest to the richest. The index is the ratio of (a) the area
between a country''s Lorenz curve and the 45 degree helping line to (b)
the entire triangular area under the 45 degree line. The more nearly
equal a country''s income distribution, the closer its Lorenz curve to
the 45 degree line and the lower its Gini index, e.g., a Scandinavian
country with an index of 25. The more unequal a country''s income
distribution, the farther its Lorenz curve from the 45 degree line and
the higher its Gini index, e.g., a Sub-Saharan country with an index of
50. If income were distributed with perfect equality, the Lorenz curve
would coincide with the 45 degree line and the index would be zero; if
income were distributed with perfect inequality, the Lorenz curve would
coincide with the horizontal axis and the right vertical axis and the
index would be 100.
Economic aid - donor: This entry refers to net official development
assistance (ODA) from Organization for Economic Cooperation and
Development (OECD) nations to developing countries and multilateral
organizations. ODA is defined as financial assistance that is
concessional in character, has the main objective to promote economic
development and welfare of the less developed countries (LDCs), and
contains a grant element of at least 25%. The entry does not cover
other official flows (OOF) or private flows. These figures are
calculated on an exchange rate basis, i.e., not in purchasing power
parity (PPP) terms.
Economic aid - recipient: This entry, which is subject to major
problems of definition and statistical coverage, refers to the net
inflow of Official Development Finance (ODF) to recipient countries.
The figure includes assistance from the World Bank, the IMF, and other
international organizations and from individual nation donors. Formal
commitments of aid are included in the data. Omitted from the data are
grants by private organizations. Aid comes in various forms including
outright grants and loans. The entry thus is the difference between new
inflows and repayments. These figures are calculated on an exchange
rate basis, i.e., not in purchasing power parity (PPP) terms.
Economy: This category includes the entries dealing with the size,
development, and management of productive resources, i.e., land, labor,
and capital.
Economy - overview: This entry briefly describes the type of economy,
including the degree of market orientation, the level of economic
development, the most important natural resources, and the unique areas
of specialization. It also characterizes major economic events and
policy changes in the most recent 12 months and may include a statement
about one or two key future macroeconomic trends.
Electricity - consumption: This entry consists of total electricity
generated annually plus imports and minus exports, expressed in
kilowatt-hours. The discrepancy between the amount of electricity
generated and/or imported and the amount consumed and/or exported is
accounted for as loss in transmission and distribution.
Electricity - exports: This entry is the total exported electricity in
kilowatt-hours.
Electricity - imports: This entry is the total imported electricity in
kilowatt-hours.
Electricity - production: This entry is the annual electricity
generated expressed in kilowatt-hours. The discrepancy between the
amount of electricity generated and/or imported and the amount consumed
and/or exported is accounted for as loss in transmission and
distribution.
Elevation extremes: This entry includes both the highest point and the
lowest point.
Entities: Some of the independent states, dependencies, areas of
special sovereignty, and governments included in this publication are
not independent, and others are not officially recognized by the US
Government. "Independent state" refers to a people politically
organized into a sovereign state with a definite territory.
"Dependencies" and "areas of special sovereignty" refer to a broad
category of political entities that are associated in some way with an
independent state. "Country" names used in the table of contents or for
page headings are usually the short-form names as approved by the US
Board on Geographic Names and may include independent states,
dependencies, and areas of special sovereignty, or other geographic
entities. There are a total of 268 separate geographic entities in The
World Factbook that may be categorized as follows:
INDEPENDENT STATES
193 Afghanistan, Albania, Algeria, Andorra, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, East Timor,
Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia,
Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany,
Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Haiti, Holy See, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania,
Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali,
Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated
States of Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
OTHER
2 Taiwan, European Union
DEPENDENCIES AND AREAS OF SPECIAL SOVEREIGNTY
6 Australia - Ashmore and Cartier Islands, Christmas Island, Cocos
(Keeling) Islands, Coral Sea Islands, Heard Island and McDonald
Islands, Norfolk Island
2 China - Hong Kong, Macau
2 Denmark - Faroe Islands, Greenland
12 France - Bassas da India*, Clipperton Island, Europa Island*, French
Polynesia, French Southern and Antarctic Lands, Glorioso Islands*, Juan
de Nova Island*, Mayotte, New Caledonia, Saint Pierre and Miquelon,
Tromelin Island*, Wallis and Futuna (* consolidated in Iles Eparses
entry)
2 Netherlands - Aruba, Netherlands Antilles
3 New Zealand - Cook Islands, Niue, Tokelau
3 Norway - Bouvet Island, Jan Mayen, Svalbard
17 UK - Akrotiri, Anguilla, Bermuda, British Indian Ocean Territory,
British Virgin Islands, Cayman Islands, Dhekelia, Falkland Islands,
Gibraltar, Guernsey, Jersey, Isle of Man, Montserrat, Pitcairn Islands,
Saint Helena, South Georgia and the South Sandwich Islands, Turks and
Caicos Islands
14 US - American Samoa, Baker Island*, Guam, Howland Island*, Jarvis
Island*, Johnston Atoll*, Kingman Reef*, Midway Islands*, Navassa
Island, Northern Mariana Islands, Palmyra Atoll*, Puerto Rico, Virgin
Islands, Wake Island (* consolidated in United States Pacific Island
Wildlife Refuges entry)
MISCELLANEOUS
6 Antarctica, Gaza Strip, Paracel Islands, Spratly Islands, West Bank,','649810cba89579551850fc85b786b976a8773b599fdc82c3efde2b3a6c4c98fb','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f870b40283aeb6df1ac80b40ce8ab350276fc413cda70cb30d543a63824a5c1f',2007,'EH','Western Sahara','military-and-security',21,'OTHER ENTITIES
5 oceans - Arctic Ocean, Atlantic Ocean, Indian Ocean, Pacific Ocean,
Southern Ocean
1 World
268 total
Environment - current issues: This entry lists the most pressing and
important environmental problems. The following terms and abbreviations
are used throughout the entry:
Acidification - the lowering of soil and water pH due to acid
precipitation and deposition usually through precipitation; this
process disrupts ecosystem nutrient flows and may kill freshwater fish
and plants dependent on more neutral or alkaline conditions (see acid
rain).
Acid rain - characterized as containing harmful levels of sulfur
dioxide or nitrogen oxide; acid rain is damaging and potentially deadly
to the earth''s fragile ecosystems; acidity is measured using the pH
scale where 7 is neutral, values greater than 7 are considered
alkaline, and values below 5.6 are considered acid precipitation; note
- a pH of 2.4 (the acidity of vinegar) has been measured in rainfall in
New England.
Aerosol - a collection of airborne particles dispersed in a gas, smoke,
or fog.
Afforestation - converting a bare or agricultural space by planting
trees and plants; reforestation involves replanting trees on areas that
have been cut or destroyed by fire.
Asbestos - a naturally occurring soft fibrous mineral commonly used in
fireproofing materials and considered to be highly carcinogenic in
particulate form.
Biodiversity - also biological diversity; the relative number of
species, diverse in form and function, at the genetic, organism,
community, and ecosystem level; loss of biodiversity reduces an
ecosystem''s ability to recover from natural or man-induced disruption.
Bio-indicators - a plant or animal species whose presence, abundance,
and health reveal the general condition of its habitat.
Biomass - the total weight or volume of living matter in a given area
or volume.
Carbon cycle - the term used to describe the exchange of carbon (in
various forms, e.g., as carbon dioxide) between the atmosphere, ocean,
terrestrial biosphere, and geological deposits.
Catchments - assemblages used to capture and retain rainwater and
runoff; an important water management technique in areas with limited
freshwater resources, such as Gibraltar.
DDT (dichloro-diphenyl-trichloro-ethane) - a colorless, odorless
insecticide that has toxic effects on most animals; the use of DDT was
banned in the US in 1972.
Defoliants - chemicals which cause plants to lose their leaves
artificially; often used in agricultural practices for weed control,
and may have detrimental impacts on human and ecosystem health.
Deforestation - the destruction of vast areas of forest (e.g.,
unsustainable forestry practices, agricultural and range land clearing,
and the over exploitation of wood products for use as fuel) without
planting new growth.
Desertification - the spread of desert-like conditions in arid or semi-
arid areas, due to overgrazing, loss of agriculturally productive
soils, or climate change.
Dredging - the practice of deepening an existing waterway; also, a
technique used for collecting bottom-dwelling marine organisms (e.g.,
shellfish) or harvesting coral, often causing significant destruction
of reef and ocean-floor ecosystems.
Drift-net fishing - done with a net, miles in extent, that is generally
anchored to a boat and left to float with the tide; often results in an
over harvesting and waste of large populations of non-commercial marine
species (by-catch) by its effect of "sweeping the ocean clean".
Ecosystems - ecological units comprised of complex communities of
organisms and their specific environments.
Effluents - waste materials, such as smoke, sewage, or industrial waste
which are released into the environment, subsequently polluting it.
Endangered species - a species that is threatened with extinction
either by direct hunting or habitat destruction.
Freshwater - water with very low soluble mineral content; sources
include lakes, streams, rivers, glaciers, and underground aquifers.
Greenhouse gas - a gas that "traps" infrared radiation in the lower
atmosphere causing surface warming; water vapor, carbon dioxide,
nitrous oxide, methane, hydrofluorocarbons, and ozone are the primary
greenhouse gases in the Earth''s atmosphere.
Groundwater - water sources found below the surface of the earth often
in naturally occurring reservoirs in permeable rock strata; the source
for wells and natural springs.
Highlands Water Project - a series of dams constructed jointly by
Lesotho and South Africa to redirect Lesotho''s abundant water supply
into a rapidly growing area in South Africa; while it is the largest
infrastructure project in southern Africa, it is also the most costly
and controversial; objections to the project include claims that it
forces people from their homes, submerges farmlands, and squanders
economic resources.
Inuit Circumpolar Conference (ICC) - represents the 145,000 Inuits of
Russia, Alaska, Canada, and Greenland in international environmental
issues; a General Assembly convenes every three years to determine the
focus of the ICC; the most current concerns are long-range transport of
pollutants, sustainable development, and climate change.
Metallurgical plants - industries which specialize in the science,
technology, and processing of metals; these plants produce highly
concentrated and toxic wastes which can contribute to pollution of
ground water and air when not properly disposed.
Noxious substances - injurious, very harmful to living beings.
Overgrazing - the grazing of animals on plant material faster than it
can naturally regrow leading to the permanent loss of plant cover, a
common effect of too many animals grazing limited range land.
Ozone shield - a layer of the atmosphere composed of ozone gas (O3)
that resides approximately 25 miles above the Earth''s surface and
absorbs solar ultraviolet radiation that can be harmful to living
organisms.
Poaching - the illegal killing of animals or fish, a great concern with
respect to endangered or threatened species.
Pollution - the contamination of a healthy environment by man-made
waste.
Potable water - water that is drinkable, safe to be consumed.
Salination - the process through which fresh (drinkable) water becomes
salt (undrinkable) water; hence, desalination is the reverse process;
also involves the accumulation of salts in topsoil caused by
evaporation of excessive irrigation water, a process that can
eventually render soil incapable of supporting crops.
Siltation - occurs when water channels and reservoirs become clotted
with silt and mud, a side effect of deforestation and soil erosion.
Slash-and-burn agriculture - a rotating cultivation technique in which
trees are cut down and burned in order to clear land for temporary
agriculture; the land is used until its productivity declines at which
point a new plot is selected and the process repeats; this practice is
sustainable while population levels are low and time is permitted for
regrowth of natural vegetation; conversely, where these conditions do
not exist, the practice can have disastrous consequences for the','8c644920af5eef866aa5c8bd873ddb24185a1d7be7d836c6601611924de9f43f','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

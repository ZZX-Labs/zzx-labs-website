SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ab0e88b9de3eeb65e084bff71303ebcd3d81abf33f4c21e489c478d5971d90f7',2007,'EH','Western Sahara','environment',13,'Soil degradation - damage to the land''s productive capacity because of poor
agricultural practices such as the excessive use of pesticides or fertilizers, soil
compaction from heavy equipment, or erosion of topsoil. eventually resulting in
reduced ability to produce agricultural products.
Soil erosion - the removal of soil by the action of water or wind, compounded
by poor agricultural practices, deforestation, overgrazing, and desertification.
Ultraviolet (UV) radiation - a portion of the electromagnetic energy emitted by
the sun and naturally filtered in the upper atmosphere by the ozone layer; UV
radiation can be harmful to living organisms and has been linked to increasing
rates of skin cancer in humans.
Water-born diseases - those in which bacteria survive in, and are transmitted
through, water; always a serious threat in areas with an untreated water supply.
Environment - international agreements: This entry separates country
participation in international environmental agreements into two levels - party to
and signed, but not ratified. Agreements are listed in alphabetical order by the
abbreviated form of the full name.
XIV
Notes and Definitions (continued)
Environmental agreements: This information is presented in Appendix C:
Selected International Environmental Agreements, which includes the name,
abbreviation, date opened for signature, date entered into force, objective, and
parties by category.
Ethnic groups: This entry provides an ordered listing of ethnic groups starting
with the largest and normally includes the percent of total population.
Exchange rates: This entry provides the official value of a country''s monetary unit
at a given date or over a given period of time, as expressed in units of local
currency per US dollar and as determined by international market forces or official
fiat.
Executive branch: This entry includes several subfields. Chief of state includes
the name and title of the titular leader of the country who represents the state at
official and ceremonial functions but may not be involved with the day-to-day
activities of the government. Head of government includes the name and title of
the top administrative leader who is designated to manage the day-to-day activities
of the government. For example, in the UK, the monarch is the chief of state, and
the prime minister is the head of government. In the US, the president is both the
chief of state and the head of government. Cabinet includes the official name for
this body of high-ranking advisers and the method for selection of members.
Elections includes the nature of election process or accession to power, date of the
last election, and date of the next election. Election results includes the percent of
vote for each candidate in the last election.
Exports: This entry provides the total US dollar amount of merchandise exports
on an f.o.b. (free on board) basis. These figures are calculated on an exchange
rate basis, i.e., not in purchasing power parity (PPP) terms.
Exports - commodities: This entry provides a rank ordering of exported products
starting with the most important; it sometimes includes the percent of total dollar
value.
Exports - partners: This entry provides a rank ordering of trading partners
starting with the most important; it sometimes includes the percent of total dollar
value.
Fiscal year: This entry identifies the beginning and ending months for a country''s
accounting period of 12 months, which often is the calendar year but which may
begin in any month. All yearly references are for the calendar year (CY) unless
indicated as a noncalendar fiscal year (FY).
Flag description: This entry provides a written flag description produced from
actual flags or the best information available at the time the entry was written. The
flags of independent states are used by their dependencies unless there is an
officially recognized local flag. Some disputed and other areas do not have flags.
Flag graphic: Most versions of the Factbook include a color flag at the beginning
of the country profile. The flag graphics were produced from actual flags or the best
information available at the time of preparation. The flags of independent states
are used by their dependencies unless there is an officially recognized local flag.
Some disputed and other areas do not have flags.
GDP - composition by sector: This entry gives the percentage contribution of
agriculture, industry, and services to total GDP. The distribution will total less than
100 percent if the data are incomplete.
xv
Notes and Definitions (continued)
GDP - per capita: This entry shows GDP on a purchasing power parity basis
divided by population as of 1 July for the same year.
GDP - real growth rate: This entry gives GDP growth on an annual basis adjusted
for inflation and expressed as a percent.
GDP (official exchange rate): This entry gives the gross domestic product (GDP)
or value of all final goods and services produced within a nation in a given year. A
nation''s GDP at official exchange rates (OER) is the home-currency-denominated
annual GDP figure divided by the bilateral average US exchange rate with that
country in that year. The measure is simple to compute and gives a precise
measure of the value of output. Many economists prefer this measure when
gauging the economic power an economy maintains vis-a-vis its neighbors,
judging that an exchange rate captures the purchasing power a nation enjoys in
the international marketplace. Official exchange rates, however, can be artificially
fixed and/or subject to manipulation - resulting in claims of the country having an
under- or over-valued currency - and are not necessarily the equivalent of a
market-determined exchange rate. Moreover, even if the official exchange rate is
market-determined, market exchange rates are frequently established by a
relatively small set of goods and services (the ones the country trades) and may
not capture the value of the larger set of goods the country produces. Furthermore,
OER-converted GDP is not well suited to comparing domestic GDP over time,
since appreciation/depreciation from one year to the next will make the OER GDP
value rise/fall regardless of whether home-currency-denominated GDP changed.
GDP (purchasing power parity): This entry gives the gross domestic product
(GDP) or value of all final goods and services produced within a nation in a given
year. A nation''s GDP at purchasing power parity (PPP) exchange rates is the sum
value of all goods and services produced in the country valued at prices prevailing
in the United States. This is the measure most economists prefer when looking at
per-capita welfare and when comparing living conditions or use of resources
across countries. The measure is difficult to compute, as a US dollar value has to
be assigned to all goods and services in the country regardless of whether these
goods and services have a direct equivalent in the United States (for example, the
value of an ox-cart or non-US military equipment); as a result, PPP estimates for
some countries are based on a small and sometimes different set of goods and
services. In addition, many countries do not formally participate in the World
Bank''s PPP project that calculates these measures, so the resulting GDP
estimates for these countries may lack precision. For many developing countries,
PPP-based GDP measures are multiples of the official exchange rate (OER)
measure. The difference between the OER- and PPP-denominated GDP values
for most of the wealthy industrialized countries are generally much smaller.
GDP methodology: In the Economy category, GDP dollar estimates for countries
are reported both on an official exchange rate (OER) and a purchasing power
parity (PPP) basis. Both measures contain information that is useful to the reader.
The PPP method involves ihe use of standardized international dollar price
weights, which are applied to the quantities of final goods and services produced
in a given economy. The data derived from the PPP method probably provides the
best available starting point for comparisons of economic strength and well-being
between countries. In contrast, the currency exchange rate method involves a
variety of international and domestic financial forces that may not capture the value
of domestic output. Furthermore, exchange rates may suddenly go up or down by
10°o or more because of market forces or official fiat whereas real output has
remained unchanged. On 12 January 1994, for example, the 14 countries of the
XVI
Notes and Definitions (continued)
African Financial Community (whose currencies are tied to the French franc)
devalued their currencies by 50%. This move, of course, did not cut the real output
of these countries by half. Whereas PPP estimates for OECD countries are quite
reliable, PPP estimates for developing countries are often rough approximations.
In developing countries with weak currencies, the exchange rate estimate of GDP
in dollars is typically one-fourth to one-half the PPP estimate. Most of the GDP
estimates for developing countries are based on extrapolation of PPP numbers
published by the UN International Comparison Program (UNICP) and by
Professors Robert Summers and Alan Heston of the University of Pennsylvania
and their colleagues. GDP derived using the OER method should be used for the
purpose of calculating the share of items such as exports, imports, military
expenditures, external debt, or the current account balance, because the dollar
values presented in the Factbook tor these items have been converted at official
exchange rates, not at PPP. One should use the OER GDP figure to calculate the
proportion of, say, Chinese defense expenditures in GDP, because that share will
be the same as one calculated in local currency units. Comparison of OER GDP
with PPP GDP may also indicate whether a currency is over- or under-valued. If
OER GDP is smaller than PPP GDP, the official exchange rate may be
undervalued, and vice versa. However, there is no strong historical evidence that
market exchange rates move in the direction implied by the PPP rate, at least not
in the short- or medium-term. Note: the numbers for GDP and other economic data
should not be chained together from successive volumes of the Factbook because
of changes in the US dollar measuring rod, revisions of data by statistical
agencies, use of new or different sources of information, and changes in national
statistical methods and practices.
Geographic coordinates: This entry includes rounded latitude and longitude
figures for the purpose of finding the approximate geographic center of an entity
and is based on the Gazetteer of Conventional Names, Third Edition, August 1 938,
US Board on Geographic Names and on other sources.
Geographic names: This information is presented in Appendix F:
Cross-Reference List of Geographic Names. It includes a listing of various
alternate names, former names, local names, and regional names referenced to
one or more related Factbook entries. Spellings are normally, but not always, those
approved by the US Board on Geographic Names (BGN). Alternate names and
additional information are included in parentheses.
Geography: This category includes the entries dealing with the natural
environment and the effects of human activity.
Geography - note: This entry includes miscellaneous geographic information of
significance not included elsewhere.
Gini index: See entry for Distribution of family income - Gini index
GNP: Gross national product (GNP) is the value of all final goods and services
produced within a nation in a given year, plus income earned by its citizens abroad,
minus income earned by foreigners from domestic production. The Factbook,
following current practice, uses GDP rather than GNP to measure national
production. However, the user must realize that in certain countries net
remittances from citizens working abroad may be important to national well-being
Government: This category includes the entries dealing with the system for the
adoption and administration of public policy.
XVII
Notes and Definitions (continued)
Government - note: This entry includes miscellaneous government information of
significance not included elsewhere.
Government type: This entry gives the basic form of government. Definitions of
the major governmental terms are as follows:
Anarchy - a condition of lawlessness or political disorder brought about by the
absence of governmental authority.
Commonwealth - a nation, state, or other political entity founded on law and
united by a compact of the people for the common good.
Communism - a system of government in which the state plans and controls
the economy and a single - often authoritarian - party holds power; state controls
are imposed with the elimination of private ownership of property or capital while
claiming to make progress toward a higher social order in which all goods are
equally shared by the people (i.e., a classless society).
Confederacy (Confederation) - a union by compact or treaty between states,
provinces, or territories, that creates a central government with limited powers; the
constituent entities retain supreme authority over all matters except those
delegated to the central government.
Constitutional - a government by or operating under an authoritative document
(constitution) that sets forth the system of fundamental laws and principles that
determines the nature, functions, and limits of that government.
Constitutional democracy - a form of government in which the sovereign power
of the people is spelled out in a governing constitution.
Constitutional monarchy - a system of government in which a monarch is
guided by a constitution whereby his/her rights, duties, and responsibilities are
spelled out in written law or by custom.
Democracy - a form of government in which the supreme power is retained by
the people, but which is usually exercised indirectly through a system of
representation and delegated authority periodically renewed.
Democratic republic - a state in which the supreme power rests in the body of
citizens entitled to vote for officers and representatives responsible to them.
Dictatorship - a form of government in which a ruler or small clique wield
absolute power (not restricted by a constitution or laws).
Ecclesiastical - a government administrated by a church.
Federal (Federative) - a form of government in which sovereign power is
formally divided - usually by means of a constitution - between a central authority
and a number of constituent regions (states, colonies, or provinces) so that each
region retains some management of its internal affairs; differs from a confederacy
in that the central government exerts influence directly upon both individuals as
well as upon the regional units
Federal republic - a state in which the powers of the central government are
restricted and in which the component parts (states, colonies, or provinces) retain
a degree of self-government; ultimate sovereign power rests with the voters who
chose their governmental representatives.
Islamic republic - a particular form of government adopted by some Muslim
states; although such a state is, in theory, a theocracy, it remains a republic, but its
laws are required to be compatible with the laws of Islam.
Maoism - the theory and practice of Marxism-Leninism developed in China by
Mao Zedong (Mao Tse-tung), which states that a continuous revolution is
necessary if the leaders of a communist state are to keep in touch with the people.
Marxism - the political, economic, and social principles espoused by 19th
century economist Karl Marx; he viewed the struggle of workers as a progression
of historical forces that would proceed from a class struggle of the proletariat
(workers) exploited by capitalists (business owners), to a socialist "dictatorship of
the proletariat," to, finally, a classless society - Communism.
XVIII
Notes and Definitions (continued)
Marxism-Leninism - an expanded form of communism developed by Lenin
from doctrines of Karl Marx; Lenin saw imperialism as the final stage of capitalism
and shifted the focus of workers'' struggle from developed to underdeveloped
countries.
Monarchy - a government in which the supreme power is lodged in the hands
of a monarch who reigns over a state or territory, usually for life and by hereditary
right; the monarch may be either a sole absolute ruler or a sovereign - such as a
king, queen, or prince - with constitutionally limited authority.
Oligarchy - a government in which control is exercised by a small group of
individuals whose authority generally is based on wealth or power.
Parliamentary democracy - a political system in which the legislature
(parliament) selects the government - a prime minister, premier, or chancellor
along with the cabinet ministers - according to party strength as expressed in
elections; by this system, the government acquires a dual responsibility: to the
people as well as to the parliament.
Parliamentary government (Cabinet-Parliamentary government) - a
government in which members of an executive branch (the cabinet and its leader
- a prime minister, premier, or chancellor) are nominated to their positions by a
legislature or parliament, and are directly responsible to it; this type of government
can be dissolved at will by the parliament (legislature) by means of a no confidence
vote or the leader of the cabinet may dissolve the parliament if it can no longer
function.
Parliamentary monarchy - a state headed by a monarch who is not actively
involved in policy formation or implementation (i.e., the exercise of sovereign
powers by a monarch in a ceremonial capacity); true governmental leadership is
carried out by a cabinet and its head - a prime minister, premier, or chancellor -
who are drawn from a legislature (parliament).
Republic - a representative democracy in which the people''s elected deputies
(representatives), not the people themselves, vote on legislation.
Socialism - a government in which the means of planning, producing, and
distributing goods is controlled by a central government that theoretically seeks a
more just and equitable distribution of property and labor; in actuality, most
socialist governments have ended up being no more than dictatorships over
workers by a ruling elite.
Sultanate - similar to a monarchy, but a government in which the supreme
power is in the hands of a sultan (the head of a Muslim state); the sultan may be
an absolute ruler or a sovereign with constitutionally limited authority.
Theocracy - a form of government in which a Deity is recognized as the
supreme civil ruler, but the Deity''s laws are interpreted by ecclesiastical authorities
(bishops, mullahs, etc.); a government subject to religious authority.
Totalitarian - a government that seeks to subordinate the individual to the state
by controlling not only all political and economic matters, but also the attitudes,
values, and beliefs of its population.
Gross domestic product: see GDP
Gross national product: see GNP
Gross world product: see GWP
GWP: This entry gives the gross world product (GWP) or aggregate value of all
final goods and services produced worldwide in a given year.
Heliports: This entry gives the total number of heliports with hard-surface
runways, helipads, or landing areas that support routine sustained helicopter
operations exclusively and have support facilities including one or more of the
XIX
Notes and Definitions (continued)
following facilities: lighting, fuel, passenger handling, or maintenance. It includes
former airports used exclusively for helicopter operations but excludes heliports
limited to day operations and natural clearings that could support helicopter
landings and takeoffs.
HIV/AIDS - adult prevalence rate: This entry gives an estimate of the percentage
of adults (aged 1 5-49) living with HIV/AIDS. The adult prevalence rate is calculated
by dividing the estimated number of adults living with HIV/AIDS at yearend by the
total adult population at yearend.
HIV/AIDS - deaths: This entry gives an estimate of the number of adults and
children who died of AIDS during a given calendar year.
HIV/AIDS - people living with HIV/AIDS: This entry gives an estimate of all
people (adults and children) alive at yearend with HIV infection, whether or not they
have developed symptoms of AIDS.
Household income or consumption by percentage share: Data on household
income or consumption come from household surveys, the results adjusted for
household size. Nations use different standards and procedures in collecting and
adjusting the data. Surveys based on income will normally show a more unequal
distribution than surveys based on consumption. The quality of surveys is
improving with time, yet caution is still necessary in making inter-country
comparisons.
Hydrographic data codes: see Data codes
Illicit drugs: This entry gives information on the five categories of illicit drugs -
narcotics, stimulants, depressants (sedatives), hallucinogens, and cannabis.
These categories include many drugs legally produced and prescribed by doctors
as well as those illegally produced and sold outside of medical channels.
Cannabis (Cannabis sativa) is the common hemp plant, which provides
hallucinogens with some sedative properties, and includes marijuana (pot,
Acapulco gold, grass, reefer), tetrahydrocannabinol (THC. Marinol), hashish
(hash), and hashish oil (hash oil).
Coca (mostly Erythroxylum coca) is a bush with leaves that contain the
stimulant used to make cocaine. Coca is not to be confused with cocoa, which
comes from cacao seeds and is used in making chocolate, cocoa, and cocoa
butter.
Cocaine is a stimulant derived from the leaves of the coca bush.
Depressants (sedatives) are drugs that reduce tension and anxiety and include
chloral hydrate, barbiturates (Amytal, Nembutal, Seconal, phenobarbital),
benzodiazepines (Librium, Valium), methaqualone (Quaalude), glutethimide
(Doriden), and others (Equanil, Placidyl, Valmid).
Drugs are any chemical substances that effect a physical, mental, emotional,
or behavioral change in an individual.
Drug abuse is the use of any licit or illicit chemical substance that results in
physical, mental, emotional, or behavioral impairment in an individual.
Hallucinogens are drugs that affect sensation, thinking, self-awareness, and
emotion. Hallucinogens include LSD (acid, microdot), mescaline and peyote
(mexc, buttons, cactus), amphetamine variants (PMA, STP, DOB), phencyclidine
(PCP, angel dust, hog), phencyclidine analogues (PCE, PCPy, TCP), and others
(psilocybin, psilocyn).
Hashish is the resinous exudate of the cannabis or hemp plant (Cannabis
sativa).
Heroin is a semisynthetic derivative of morphine.
xx
Notes and Definitions (continued)
Mandrax is a trade name for methaqualone, a pharmaceutical depressant.
Marijuana is the dried leaf of the cannabis or hemp plant (Cannabis sativa).
Methaqualone is a pharmaceutical depressant, referred to as mandrax in
Southwest Asia and Africa.
Narcotics are drugs that relieve pain, often induce sleep, and refer to opium,
opium derivatives, and synthetic substitutes. Natural narcotics include opium
(paregoric, parepectolin), morphine (MS-Contin, Roxanol), codeine (Tylenol with
codeine, Empirin with codeine, Robitussan AC), and thebaine. Semisynthetic
narcotics include heroin (horse, smack), and hydromorphone (Dilaudid). Synthetic
narcotics include meperidine or Pethidine (Demerol, Mepergan), methadone
(Dolophine, Methadose), and others (Darvon, Lomotil).
Opium is the brown, gummy exudate of the incised, unripe seedpod of the
opium poppy.
Opium poppy (Papaver somniferum) is the source for the natural and
semisynthetic narcotics.
Poppy straw is the entire cut and dried opium poppy-plant material, other than
the seeds. Opium is extracted from poppy straw in commercial operations that
produce the drug for medical use.
Qat (kat, khat) is a stimulant from the buds or leaves','782f30846dc99b17eb353d1653db68e71f77f36564e79d1cb2adc99c8cd7577d','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4956b0a947f4c8b92128b64c1f5ce1d3cbe10bf20509cf9352d1c25aa50b18ea',2007,'EH','Western Sahara','environment',14,'of Catha edulis that is
chewed or drunk as tea.
Quaaludes is the North American slang term for methaqualone, a
pharmaceutical depressant.
Stimulants are drugs that relieve mild depression, increase energy and activity,
and include cocaine (coke, snow, crack), amphetamines (Desoxyn, Dexedrine),
ephedrine, ecstasy (clarity, essence, doctor, Adam), phenmetrazine (Preludin),
methylphenidate (Ritalin), and others (Cylert, Sanorex, Tenuate).
Imports: This entry provides the total US dollar amount of merchandise imports
on a c.i.f. (cost, insurance, and freight) or f.o.b. (free on board) basis. These figures
are calculated on an exchange rate basis, i.e., not in purchasing power parity
(PPP) terms.
Imports - commodities: This entry provides a rank ordering of imported products
starting with the most important; it sometimes includes the percent of total dollar
value.
Imports - partners: This entry provides a rank ordering of trading partners
starting with the most important; it sometimes includes the percent of total dollar
value.
Independence: For most countries, this entry gives the date that sovereignty was
achieved and from which nation, empire, or trusteeship. For the other countries,
the date given may not represent "independence" in the strict sense, but rather
some significant nationhood event such as the traditional founding date or the date
of unification, federation, confederation, establishment, fundamental change in the
form of government, or state succession. Dependent areas include the notation
"none" followed by the nature of their dependency status. Also see the
Terminology note.
Industrial production growth rate: This entry gives the annual percentage
increase in industrial production (includes manufacturing, mining, and
construction).
Industries: This entry provides a rank ordering of industries starting with the
largest by value of annual output.
XXI
Notes and Definitions (continued)
Infant mortality rate: This entry gives the number of deaths of infants under one
year old in a given year per 1 ,000 live births in the same year; included is the total
death rate, and deaths by sex, male and female. This rate is often used as an
indicator of the level of health in a country,
Inflation rate (consumer prices): This entry furnishes the annual percent change
in consumer prices compared with the previou6 year''s consumer prices.
International disputes: see Disputes - international
International organization participation: This entry lists in alphabetical order by
abbreviation those international organizations in which the subject country is a
member or participates in some other way.
International organizations: This information is presented in Appendix B:
International Organizations and Groups which includes the name, abbreviation,
date established, aim, and members by category.
Internet country code: This entry includes the two-letter codes maintained by the
International Organization for Standardization (ISO) in the ISO 3166 Alpha-2 list
and used by the Internet Assigned Numbers Authority (IANA) to establish
country-coded top-level domains (ccTLDs).
Internet hosts: This entry lists the number of Internet hosts available within a
country. An Internet host is a computer connected directly to the Internet; normally
an Internet Service Provider''s (ISP) computer is a host. Internet users may use
either a hard-wired terminal, at an institution with a mainframe computer
connected directly to the Internet, or may connect remotely by way of a modem via
telephone line, cable, or satellite to the Internet Service Provider''s host computer.
The number of hosts is one indicator of the extent of Internet connectivity.
Internet users: This entry gives the number of users within a country that access
the Internet. Statistics vary from country to country and may include users who
access the Internet at least several times a week to those who access it only once
within a period of several months.
Introduction: This category includes one entry, Background.
Investment (gross fixed): This entry records total business spending on fixed
assets, such as factories, machinery, equipment, dwellings, and inventories of raw
materials, which provide the basis for future production. It is measured gross of the
depreciation of the assets, i.e., it includes investment that merely replaces
worn-out or scrapped capital.
Irrigated land: This entry gives the number of square kilometers of land area that
is artificially supplied with water.
Judicial branch: This entry contains the name(s) of the highest court(s) and a
brief description of the selection process for members.
Labor force: This entry contains the total labor force figure.
Labor force - by occupation: This entry lists the percentage distribution of the
labor force by occupation. The distribution will total less than 100 percent if the
data are incomplete.
Land boundaries: This entry contains the total length of all land boundaries and
the individual lengths for each of the contiguous border countries.
XXII
Notes and Definitions (continued)
Land use: This entry contains the percentage shares of total land area for three
different types of land use: arable land cultivated for crops like wheat, maize, and
rice that are replanted after each harvest; permanent crops - land cultivated for
crops like citrus, coffee, and rubber that are not replanted after each harvest;
includes land under flowering shrubs, fruit trees, nut trees, and vines, but excludes
land under trees grown for wood or timber; other- any land not arable or under
permanent crops; includes permanent meadows and pastures, forests and
woodlands, built-on areas, roads, barren land, etc.
Languages: This entry provides a rank ordering of languages starting with the
largest and sometimes includes the percent of total population speaking that
language.
Legal system: This entry contains a brief description of the legal system''s
historical roots, role in government, and acceptance of International Court of
Justice (IC J) jurisdiction.
Legislative branch: This entry contains information on the structure (unicameral,
bicameral, tricameral), formal name, number of seats, and tei m of office. Elections
includes the nature of election process or accession to power, aate of the last
election, and date of the next election. Election results includes the percent of vote
and/or number of seats held by each party in the last election.
Life expectancy at birth: This entry contains the average number of years to be
lived by a group of people born in the same year, if mortality at each age remains
constant in the future. The entry includes total population as well as the male and
female components. Life expectancy at birth is also a measure of overall quality of
life in a country and summarizes the mortality at all ages. It can also be thought of
as indicating the potential return on investment in human capital and is necessory
for the calculation of various actuarial measures.
Literacy: This entry includes a definition of literacy and Census Bureau
percentages for the total population, males, and females. There are no universal
definitions and standards of literacy. Unless otherwise specified, all rates are
based on the most common definition - the ability to read and write at a specified
age. Detailing the standards that individual countries use to assess the ability to
read and write is beyond the scope of the Factbook. Information on literacy, while
not a perfect measure of educational results, is probably the most easily available
and valid for international comparisons. Low levels of literacy, and education in
general, can impede the economic development of a country in the current rapidly
changing, technology-driven world.
Location: This entry identifies the country''s regional location, neighboring
countries, and adjacent bodies of water.
Major infectious diseases: This entry lists major infectious diseases likely to be
encountered in countries where the risk of such diseases is assessed to be very
high as compared to the United States. These infectious diseases represent risks
to US government personnel traveling to the specified country for a period of less
than three years. The degree of risk is assessed by considering the foreign nature
of these infectious diseases, their severity, and the probability of being affected by
the diseases present. The diseases listed do not necessarily represent the total
disease burden experienced by the local population. The risk to an individual
traveler varies considerably by the specific location, visit duration, type of activities,
XXIII
Notes and Definitions (continued)
type of accommodations, time of year, and other factors. Consultation with a travel
medicine physician is needed to evaluate individual risk and recommend
appropriate preventive measures such as vaccines.
Diseases are organized into the following six exposure categories shown in
italics and listed in typical descending order of risk. Note - The sequence of
exposure categories listed in individual country entries may vary according to local
conditions.
food or waterbome diseases acquired through eating or drinking on the local','7ef64b7282786a100ae7747ab67dd2a168d519db6d7cabd208b2932dc0f8b81d','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7bc9a7e8862ae79b66f9be7d179cd723bab4c63968ebb70e76d5e75ab4144881',2007,'TH','Thailand','environment',1261,'GDP (purchasing power parity): $2.5 billion
(2002 est.)
GDP (official exchange rate): NA
GDP ■ real growth rate: 2% (2002 est.)
GDP - per capita (PPP): $17,200 (2002 est.)
GDP - composition by sector:
agriculture: \\%
industry: 19%
services: 80% (2003 est.)
Labor force: 48,900 (2003 est.)
Labor force • by occupation: agriculture 1%,
industry 19%, services 80% (2003 est.)
Unemployment rate: 9.3% (2003 est.)
Population below poverty line: NA%
Household income or consumption by percentage
share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices): 2.2% (2003)
Budget:
revenues: $NA
expenditures: $NA
Agriculture • products: fruit, vegetables, sorghum;
Senepol cattle
Industries: tourism, petroleum refining, watch
assembly, rum distilling, construction,
pharmaceuticals, textiles, electronics
Industrial production growth rate: NA%
Electricity - production: 1 .04 billion kWh (2003)
Electricity - consumption: 967.3 million kWh
(2003)
Electricity - exports: 0 kWh (2003)
Electricity - imports: 0 kWh (2003)
Oil • production: 14,650 bbl/day (2003 est.)
Oil ■ consumption: 105,000 bbl/day (2003 est.)
Oil -exports: NA bbl/day
Oil -imports: NA bbl/day
Natural gas - production: 0 cu m (2003 est.)
Natural gas - consumption: 0 cu m (2003 est.)
Exports: $NA
Exports - commodities: refined petroleum products
Exports - partners: US, Puerto Rico (2004)
Imports: $NA
Imports - commodities: crude oil, foodstuffs,
consumer goods, building materials
Imports - partners: US, Puerto Rico (2004)
Debt - external: SNA
Economic aid - recipient: SNA
Currency (code): US dollar (USD)
Exchange rates: the US dollar is used
Fiscal year: 1 October - 30 September','a046a504a5babc2ab2d4dac611977dd14c3fc08c071d40b83e681764d2fde9e8','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51acc2b37f57869b4eeda76c99058adc52d0f87c4a17f1aad9be31e9755a1afc',2007,'EH','Western Sahara','environment',22,'Soil degradation - damage to the land''s productive capacity because of
poor agricultural practices such as the excessive use of pesticides or
fertilizers, soil compaction from heavy equipment, or erosion of
topsoil, eventually resulting in reduced ability to produce
agricultural products.
Soil erosion - the removal of soil by the action of water or wind,
compounded by poor agricultural practices, deforestation, overgrazing,
and desertification.
Ultraviolet (UV) radiation - a portion of the electromagnetic energy
emitted by the sun and naturally filtered in the upper atmosphere by
the ozone layer; UV radiation can be harmful to living organisms and
has been linked to increasing rates of skin cancer in humans.
Water-born diseases - those in which bacteria survive in, and are
transmitted through, water; always a serious threat in areas with an
untreated water supply.
Environment - international agreements: This entry separates country
participation in international environmental agreements into two levels
- party to and signed, but not ratified. Agreements are listed in
alphabetical order by the abbreviated form of the full name.
Environmental agreements: This information is presented in Appendix C:
Selected International Environmental Agreements, which includes the
name, abbreviation, date opened for signature, date entered into force,
objective, and parties by category.
Ethnic groups: This entry provides an ordered listing of ethnic groups
starting with the largest and normally includes the percent of total
population.
Exchange rates: This entry provides the official value of a country''s
monetary unit at a given date or over a given period of time, as
expressed in units of local currency per US dollar and as determined by
international market forces or official fiat.
Executive branch: This entry includes several subfields. Chief of
state includes the name and title of the titular leader of the country
who represents the state at official and ceremonial functions but may
not be involved with the day-to-day activities of the government. Head
of government includes the name and title of the top administrative
leader who is designated to manage the day-to-day activities of the
government. For example, in the UK, the monarch is the chief of state,
and the prime minister is the head of government. In the US, the
president is both the chief of state and the head of government.
Cabinet includes the official name for this body of high-ranking
advisers and the method for selection of members. Elections includes
the nature of election process or accession to power, date of the last
election, and date of the next election. Election results includes the
percent of vote for each candidate in the last election.
Exports: This entry provides the total US dollar amount of merchandise
exports on an f.o.b. (free on board) basis. These figures are
calculated on an exchange rate basis, i.e., not in purchasing power
parity (PPP) terms.
Exports - commodities: This entry provides a rank ordering of exported
products starting with the most important; it sometimes includes the
percent of total dollar value.
Exports - partners: This entry provides a rank ordering of trading
partners starting with the most important; it sometimes includes the
percent of total dollar value.
Fiscal year: This entry identifies the beginning and ending months for
a country''s accounting period of 12 months, which often is the calendar
year but which may begin in any month. All yearly references are for
the calendar year (CY) unless indicated as a noncalendar fiscal year
(FY).
Flag description: This entry provides a written flag description
produced from actual flags or the best information available at the
time the entry was written. The flags of independent states are used by
their dependencies unless there is an officially recognized local flag.
Some disputed and other areas do not have flags.
Flag graphic: Most versions of the Factbook include a color flag at
the beginning of the country profile. The flag graphics were produced
from actual flags or the best information available at the time of
preparation. The flags of independent states are used by their
dependencies unless there is an officially recognized local flag. Some
disputed and other areas do not have flags.
GDP (official exchange rate): This entry gives the gross domestic
product (GDP) or value of all final goods and services produced within
a nation in a given year. A nation''s GDP at offical exchange rates
(OER) is the home-currency-denominated annual GDP figure divided by the
bilateral average US exchange rate with that country in that year. The
measure is simple to compute and gives a precise measure of the value
of output. Many economists prefer this measure when gauging the
economic power an economy maintains vis-a-vis its neighbors, judging
that an exchange rate captures the purchasing power a nation enjoys in
the international marketplace. Official exchange rates, however, can be
artifically fixed and/or subject to manipulation - resulting in claims
of the country having an under- or over-valued currency - and are not
necessarily the equivalent of a market-determined exchange rate.
Moreover, even if the official exchange rate is market-determined,
market exchange rates are frequently established by a relatively small
set of goods and services (the ones the country trades) and may not
capture the value of the larger set of goods the country produces.
Furthermore, OER-converted GDP is not well suited to comparing domestic
GDP over time, since appreciation/depreciation from one year to the
next will make the OER GDP value rise/fall regardless of whether home-
currency-denominated GDP changed.
GDP (purchasing power parity): This entry gives the gross domestic
product (GDP) or value of all final goods and services produced within
a nation in a given year. A nation''s GDP at purchasing power parity
(PPP) exchange rates is the sum value of all goods and services
produced in the country valued at prices prevailing in the United
States. This is the measure most economists prefer when looking at per-
capita welfare and when comparing living conditions or use of resources
across countries. The measure is difficult to compute, as a US dollar
value has to be assigned to all goods and services in the country
regardless of whether these goods and services have a direct equivalent
in the United States (for example, the value of an ox-cart or non-US
military equipment); as a result, PPP estimates for some countries are
based on a small and sometimes different set of goods and services. In
addition, many countries do not formally participate in the World
Bank''s PPP project that calculates these measures, so the resulting GDP
estimates for these countries may lack precision. For many developing
countries, PPP-based GDP measures are multiples of the official
exchange rate (OER) measure. The difference between the OER- and PPP-
denominated GDP values for most of the weathly industrialized countries
are generally much smaller.
GDP - composition by sector: This entry gives the percentage
contribution of agriculture, industry, and services to total GDP. The
distribution will total less than 100 percent if the data are
incomplete.
GDP - per capita (PPP): This entry shows GDP on a purchasing power
parity basis divided by population as of 1 July for the same year.
GDP - real growth rate: This entry gives GDP growth on an annual basis
adjusted for inflation and expressed as a percent.
GDP methodology: In the Economy category, GDP dollar estimates for
countries are reported both on an official exchange rate (OER) and a
purchasing power parity (PPP) basis. Both measures contain information
that is useful to the reader. The PPP method involves the use of
standardized international dollar price weights, which are applied to
the quantities of final goods and services produced in a given economy.
The data derived from the PPP method probably provides the best
available starting point for comparisons of economic strength and well-
being between countries. In contrast, the currency exchange rate method
involves a variety of international and domestic financial forces that
may not capture the value of domestic output. Furthermore, exchange
rates may suddenly go up or down by 10% or more because of market
forces or official fiat whereas real output has remained unchanged. On
12 January 1994, for example, the 14 countries of the African Financial
Community (whose currencies are tied to the French franc) devalued
their currencies by 50%. This move, of course, did not cut the real
output of these countries by half. Whereas PPP estimates for OECD
countries are quite reliable, PPP estimates for developing countries
are often rough approximations. In developing countries with weak
currencies, the exchange rate estimate of GDP in dollars is typically
one-fourth to one-half the PPP estimate. Most of the GDP estimates for
developing countries are based on extrapolation of PPP numbers
published by the UN International Comparison Program (UNICP) and by
Professors Robert Summers and Alan Heston of the University of
Pennsylvania and their colleagues. GDP derived using the OER method
should be used for the purpose of calculating the share of items such
as exports, imports, military expenditures, external debt, or the
current account balance, because the dollar values presented in the
Factbook for these items have been converted at official exchange
rates, not at PPP. One should use the OER GDP figure to calculate the
proportion of, say, Chinese defense expenditures in GDP, because that
share will be the same as one calculated in local currency units.
Comparison of OER GDP with PPP GDP may also indicate whether a currency
is over- or under-valued. If OER GDP is smaller than PPP GDP, the
official exchange rate may be undervalued, and vice versa. However,
there is no strong historical evidence that market exchange rates move
in the direction implied by the PPP rate, at least not in the short- or
medium-term. Note: the numbers for GDP and other economic data should
not be chained together from successive volumes of the Factbook because
of changes in the US dollar measuring rod, revisions of data by
statistical agencies, use of new or different sources of information,
and changes in national statistical methods and practices.
GNP: Gross national product (GNP) is the value of all final goods and
services produced within a nation in a given year, plus income earned
by its citizens abroad, minus income earned by foreigners from domestic
production. The Factbook, following current practice, uses GDP rather
than GNP to measure national production. However, the user must realize
that in certain countries net remittances from citizens working abroad
may be important to national well-being.
GWP: This entry gives the gross world product (GWP) or aggregate value
of all final goods and services produced worldwide in a given year.
Geographic coordinates: This entry includes rounded latitude and
longitude figures for the purpose of finding the approximate geographic
center of an entity and is based on the Gazetteer of Conventional
Names, Third Edition, August 1988, US Board on Geographic Names and on
other sources.
Geographic names: This information is presented in Appendix F: Cross-
Reference List of Geographic Names. It includes a listing of various
alternate names, former names, local names, and regional names
referenced to one or more related Factbook entries. Spellings are
normally, but not always, those approved by the US Board on Geographic
Names (BGN). Alternate names and additional information are included in
parentheses.
Geography: This category includes the entries dealing with the natural
environment and the effects of human activity.
Geography - note: This entry includes miscellaneous geographic
information of significance not included elsewhere.
Gini index: See entry for Distribution of family income - Gini index
Government: This category includes the entries dealing with the system
for the adoption and administration of public policy.
Government - note: This entry includes miscellaneous government
information of significance not included elsewhere.
Government type: This entry gives the basic form of government.
Definitions of the major governmental terms are as follows:
Anarchy - a condition of lawlessness or political disorder brought
about by the absence of governmental authority.
Commonwealth - a nation, state, or other political entity founded on
law and united by a compact of the people for the common good.
Communism - a system of government in which the state plans and
controls the economy and a single - often authoritarian - party holds
power; state controls are imposed with the elimination of private
ownership of property or capital while claiming to make progress toward
a higher social order in which all goods are equally shared by the
people (i.e., a classless society).
Confederacy (Confederation) - a union by compact or treaty between
states, provinces, or territories, that creates a central government
with limited powers; the constituent entities retain supreme authority
over all matters except those delegated to the central government.
Constitutional - a government by or operating under an authoritative
document (constitution) that sets forth the system of fundamental laws
and principles that determines the nature, functions, and limits of
that government.
Constitutional democracy - a form of government in which the sovereign
power of the people is spelled out in a governing constitution.
Constitutional monarchy - a system of government in which a monarch is
guided by a constitution whereby his/her rights, duties, and
responsibilities are spelled out in written law or by custom.
Democracy - a form of government in which the supreme power is retained
by the people, but which is usually exercised indirectly through a
system of representation and delegated authority periodically renewed.
Democratic republic - a state in which the supreme power rests in the
body of citizens entitled to vote for officers and representatives
responsible to them.
Dictatorship - a form of government in which a ruler or small clique
wield absolute power (not restricted by a constitution or laws).
Ecclesiastical - a government administrated by a church.
Emirate - similar to a monarchy or sultanate, but a government in which
the supreme power is in the hands of an emir (the ruler of a Muslim
state); the emir may be an absolute overlord or a sovereign with
constitutionally limited authority.
Federal (Federative) - a form of government in which sovereign power is
formally divided - usually by means of a constitution - between a
central authority and a number of constituent regions (states,
colonies, or provinces) so that each region retains some management of
its internal affairs; differs from a confederacy in that the central
government exerts influence directly upon both individuals as well as
upon the regional units.
Federal republic - a state in which the powers of the central
government are restricted and in which the component parts (states,
colonies, or provinces) retain a degree of self-government; ultimate
sovereign power rests with the voters who chose their governmental
representatives.
Islamic republic - a particular form of government adoped by some
Muslim states; although such a state is, in theory, a theocracy, it
remains a republic, but its laws are required to be compatible with the
laws of Islam.
Maoism - the theory and practice of Marxism-Leninism developed in China
by Mao Zedong (Mao Tse-tung), which states that a continuous revolution
is necessary if the leaders of a communist state are to keep in touch
with the people.
Marxism - the political, economic, and social principles espoused by
19th century economist Karl Marx; he viewed the struggle of workers as
a progression of historical forces that would proceed from a class
struggle of the proletariat (workers) exploited by capitalists
(business owners), to a socialist "dictatorship of the proletariat,"
to, finally, a classless society - Communism.
Marxism-Leninism - an expanded form of communism developed by Lenin
from doctrines of Karl Marx; Lenin saw imperialism as the final stage
of capitalism and shifted the focus of workers'' struggle from developed
to underdeveloped countries.
Monarchy - a government in which the supreme power is lodged in the
hands of a monarch who reigns over a state or territory, usually for
life and by hereditary right; the monarch may be either a sole absolute
ruler or a sovereign - such as a king, queen, or prince - with
constitutionally limited authority.
Oligarchy - a government in which control is exercised by a small group
of individuals whose authority generally is based on wealth or power.
Parliamentary democracy - a political system in which the legislature
(parliament) selects the government - a prime minister, premier, or
chancellor along with the cabinet ministers - according to party
strength as expressed in elections; by this system, the government
acquires a dual responsibility: to the people as well as to the
parliament.
Parliamentary government (Cabinet-Parliamentary government) - a
government in which members of an executive branch (the cabinet and its
leader - a prime minister, premier, or chancellor) are nominated to
their positions by a legislature or parliament, and are directly
responsible to it; this type of government can be dissolved at will by
the parliament (legislature) by means of a no confidence vote or the
leader of the cabinet may dissolve the parliament if it can no longer
function.
Parliamentary monarchy - a state headed by a monarch who is not
actively involved in policy formation or implementation (i.e., the
exercise of sovereign powers by a monarch in a ceremonial capacity);
true governmental leadership is carried out by a cabinet and its head -
a prime minister, premier, or chancellor - who are drawn from a
legislature (parliament).
Republic - a representative democracy in which the people''s elected
deputies (representatives), not the people themselves, vote on
legislation.
Socialism - a government in which the means of planning, producing, and
distributing goods is controlled by a central government that
theoretically seeks a more just and equitable distribution of property
and labor; in actuality, most socialist governments have ended up being
no more than dictatorships over workers by a ruling elite.
Sultanate - similar to a monarchy, but a government in which the
supreme power is in the hands of a sultan (the head of a Muslim state);
the sultan may be an absolute ruler or a sovereign with
constitutionally limited authority.
Theocracy - a form of government in which a Deity is recognized as the
supreme civil ruler, but the Deity''s laws are interpreted by
ecclesiastical authorities (bishops, mullahs, etc.); a government
subject to religious authority.
Totalitarian - a government that seeks to subordinate the individual to
the state by controlling not only all political and economic matters,
but also the attitudes, values, and beliefs of its population.
Greenwich Mean Time (GMT): The mean solar time at the Greenwich
Meridian, Greenwich, England, with the hours and days, since 1925,
reckoned from midnight. GMT is now a historical term having been
replaced by UTC on 1 January 1972. See Coordinated Universal Time.
Gross domestic product: see GDP
Gross national product: see GNP
Gross world product: see GWP
HIV/AIDS - adult prevalence rate: This entry gives an estimate of the
percentage of adults (aged 15-49) living with HIV/AIDS. The adult
prevalence rate is calculated by dividing the estimated number of
adults living with HIV/AIDS at yearend by the total adult population at
yearend.
HIV/AIDS - deaths: This entry gives an estimate of the number of
adults and children who died of AIDS during a given calendar year.
HIV/AIDS - people living with HIV/AIDS: This entry gives an estimate
of all people (adults and children) alive at yearend with HIV
infection, whether or not they have developed symptoms of AIDS.
Heliports: This entry gives the total number of heliports with hard-
surface runways, helipads, or landing areas that support routine
sustained helicopter operations exclusively and have support facilities
including one or more of the following facilities: lighting, fuel,
passenger handling, or maintenance. It includes former airports used
exclusively for helicopter operations but excludes heliports limited to
day operations and natural clearings that could support helicopter
landings and takeoffs.
Household income or consumption by percentage share: Data on household
income or consumption come from household surveys, the results adjusted
for household size. Nations use different standards and procedures in
collecting and adjusting the data. Surveys based on income will
normally show a more unequal distribution than surveys based on
consumption. The quality of surveys is improving with time, yet caution
is still necessary in making inter-country comparisons.
Hydrographic data codes: see Data codes
Illicit drugs: This entry gives information on the five categories of
illicit drugs - narcotics, stimulants, depressants (sedatives),
hallucinogens, and cannabis. These categories include many drugs
legally produced and prescribed by doctors as well as those illegally
produced and sold outside of medical channels.
Cannabis (Cannabis sativa) is the common hemp plant, which provides
hallucinogens with some sedative properties, and includes marijuana
(pot, Acapulco gold, grass, reefer), tetrahydrocannabinol (THC,
Marinol), hashish (hash), and hashish oil (hash oil).
Coca (mostly Erythroxylum coca) is a bush with leaves that contain the
stimulant used to make cocaine. Coca is not to be confused with cocoa,
which comes from cacao seeds and is used in making chocolate, cocoa,
and cocoa butter.
Cocaine is a stimulant derived from the leaves of the coca bush.
Depressants (sedatives) are drugs that reduce tension and anxiety and
include chloral hydrate, barbiturates (Amytal, Nembutal, Seconal,
phenobarbital), benzodiazepines (Librium, Valium), methaqualone
(Quaalude), glutethimide (Doriden), and others (Equanil, Placidyl,
Valmid).
Drugs are any chemical substances that effect a physical, mental,
emotional, or behavioral change in an individual.
Drug abuse is the use of any licit or illicit chemical substance that
results in physical, mental, emotional, or behavioral impairment in an
individual.
Hallucinogens are drugs that affect sensation, thinking, self-
awareness, and emotion. Hallucinogens include LSD (acid, microdot),
mescaline and peyote (mexc, buttons, cactus), amphetamine variants
(PMA, STP, DOB), phencyclidine (PCP, angel dust, hog), phencyclidine
analogues (PCE, PCPy, TCP), and others (psilocybin, psilocyn).
Hashish is the resinous exudate of the cannabis or hemp plant (Cannabis
sativa).
Heroin is a semisynthetic derivative of morphine.
Mandrax is a trade name for methaqualone, a pharmaceutical depressant.
Marijuana is the dried leaf of the cannabis or hemp plant (Cannabis
sativa).
Methaqualone is a pharmaceutical depressant, referred to as mandrax in
Southwest Asia and Africa.
Narcotics are drugs that relieve pain, often induce sleep, and refer to
opium, opium derivatives, and synthetic substitutes. Natural narcotics
include opium (paregoric, parepectolin), morphine (MS-Contin, Roxanol),
codeine (Tylenol with codeine, Empirin with codeine, Robitussan AC),
and thebaine. Semisynthetic narcotics include heroin (horse, smack),
and hydromorphone (Dilaudid). Synthetic narcotics include meperidine or
Pethidine (Demerol, Mepergan), methadone (Dolophine, Methadose), and
others (Darvon, Lomotil).
Opium is the brown, gummy exudate of the incised, unripe seedpod of the
opium poppy.
Opium poppy (Papaver somniferum) is the source for the natural and
semisynthetic narcotics.','a27ee44f37d0be1d23dec2f84ec46df80e43a0aa32da5f727c6d1bf65123b1e2','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95d99207ef6ecf61aedd32c7b0f8da0bdfb7c56822d96142b7e0bfc54b37b6be',2007,'EH','Western Sahara','environment',23,'Poppy straw is the entire cut and dried opium poppy-plant material,
other than the seeds. Opium is extracted from poppy straw in commercial
operations that produce the drug for medical use.
Qat (kat, khat) is a stimulant from the buds or leaves of Catha edulis
that is chewed or drunk as tea.
Quaaludes is the North American slang term for methaqualone, a
pharmaceutical depressant.
Stimulants are drugs that relieve mild depression, increase energy and
activity, and include cocaine (coke, snow, crack), amphetamines
(Desoxyn, Dexedrine), ephedrine, ecstasy (clarity, essence, doctor,
Adam), phenmetrazine (Preludin), methylphenidate (Ritalin), and others
(Cylert, Sanorex, Tenuate).
Imports: This entry provides the total US dollar amount of merchandise
imports on a c.i.f. (cost, insurance, and freight) or f.o.b. (free on
board) basis. These figures are calculated on an exchange rate basis,
i.e., not in purchasing power parity (PPP) terms.
Imports - commodities: This entry provides a rank ordering of imported
products starting with the most important; it sometimes includes the
percent of total dollar value.
Imports - partners: This entry provides a rank ordering of trading
partners starting with the most important; it sometimes includes the
percent of total dollar value.
Independence: For most countries, this entry gives the date that
sovereignty was achieved and from which nation, empire, or trusteeship.
For the other countries, the date given may not represent
"independence" in the strict sense, but rather some significant
nationhood event such as the traditional founding date or the date of
unification, federation, confederation, establishment, fundamental
change in the form of government, or state succession. Dependent areas
include the notation "none" followed by the nature of their dependency
status. Also see the Terminology note.
Industrial production growth rate: This entry gives the annual
percentage increase in industrial production (includes manufacturing,
mining, and construction).
Industries: This entry provides a rank ordering of industries starting
with the largest by value of annual output.
Infant mortality rate: This entry gives the number of deaths of
infants under one year old in a given year per 1,000 live births in the
same year; included is the total death rate, and deaths by sex, male
and female. This rate is often used as an indicator of the level of
health in a country.
Inflation rate (consumer prices): This entry furnishes the annual
percent change in consumer prices compared with the previous year''s
consumer prices.
International disputes: see Disputes - international
International organization participation: This entry lists in
alphabetical order by abbreviation those international organizations in
which the subject country is a member or participates in some other
way.
International organizations: This information is presented in Appendix
B: International Organizations and Groups which includes the name,
abbreviation, date established, aim, and members by category.
Internet country code: This entry includes the two-letter codes
maintained by the International Organization for Standardization (ISO)
in the ISO 3166 Alpha-2 list and used by the Internet Assigned Numbers
Authority (IANA) to establish country-coded top-level domains (ccTLDs).
Internet hosts: This entry lists the number of Internet hosts
available within a country. An Internet host is a computer connected
directly to the Internet; normally an Internet Service Provider''s (ISP)
computer is a host. Internet users may use either a hard-wired
terminal, at an institution with a mainframe computer connected
directly to the Internet, or may connect remotely by way of a modem via
telephone line, cable, or satellite to the Internet Service Provider''s
host computer. The number of hosts is one indicator of the extent of
Internet connectivity.
Internet users: This entry gives the number of users within a country
that access the Internet. Statistics vary from country to country and
may include users who access the Internet at least several times a week
to those who access it only once within a period of several months.
Introduction: This category includes one entry, Background.
Investment (gross fixed): This entry records total business spending
on fixed assets, such as factories, machinery, equipment, dwellings,
and inventories of raw materials, which provide the basis for future
production. It is measured gross of the depreciation of the assets,
i.e., it includes invesment that merely replaces worn-out or scrapped
capital.
Irrigated land: This entry gives the number of square kilometers of
land area that is artificially supplied with water.
Judicial branch: This entry contains the name(s) of the highest
court(s) and a brief description of the selection process for members.
Labor force: This entry contains the total labor force figure.
Labor force - by occupation: This entry lists the percentage
distribution of the labor force by occupation. The distribution will
total less than 100 percent if the data are incomplete.
Land boundaries: This entry contains the total length of all land
boundaries and the individual lengths for each of the contiguous border
countries. When available, official lengths published by national
statistical agencies are used. Because surveying methods may differ,
country border lengths reported by contiguous countries may differ.
Land use: This entry contains the percentage shares of total land area
for three different types of land use: arable land - land cultivated
for crops like wheat, maize, and rice that are replanted after each
harvest; permanent crops - land cultivated for crops like citrus,
coffee, and rubber that are not replanted after each harvest; includes
land under flowering shrubs, fruit trees, nut trees, and vines, but
excludes land under trees grown for wood or timber; other - any land
not arable or under permanent crops; includes permanent meadows and
pastures, forests and woodlands, built-on areas, roads, barren land,
etc.
Languages: This entry provides a rank ordering of languages starting
with the largest and sometimes includes the percent of total population
speaking that language.
Legal system: This entry contains a brief description of the legal
system''s historical roots, role in government, and acceptance of
International Court of Justice (ICJ) jurisdiction.
Legislative branch: This entry contains information on the structure
(unicameral, bicameral, tricameral), formal name, number of seats, and
term of office. Elections includes the nature of election process or
accession to power, date of the last election, and date of the next
election. Election results includes the percent of vote and/or number
of seats held by each party in the last election.
Life expectancy at birth: This entry contains the average number of
years to be lived by a group of people born in the same year, if
mortality at each age remains constant in the future. The entry
includes total population as well as the male and female components.
Life expectancy at birth is also a measure of overall quality of life
in a country and summarizes the mortality at all ages. It can also be
thought of as indicating the potential return on investment in human
capital and is necessary for the calculation of various actuarial
measures.
Literacy: This entry includes a definition of literacy and Census
Bureau percentages for the total population, males, and females. There
are no universal definitions and standards of literacy. Unless
otherwise specified, all rates are based on the most common definition
- the ability to read and write at a specified age. Detailing the
standards that individual countries use to assess the ability to read
and write is beyond the scope of the Factbook. Information on literacy,
while not a perfect measure of educational results, is probably the
most easily available and valid for international comparisons. Low
levels of literacy, and education in general, can impede the economic
development of a country in the current rapidly changing, technology-
driven world.
Location: This entry identifies the country''s regional location,
neighboring countries, and adjacent bodies of water.
Major infectious diseases: This entry lists major infectious diseases
likely to be encountered in countries where the risk of such diseases
is assessed to be very high as compared to the United States. These
infectious diseases represent risks to US government personnel
traveling to the specified country for a period of less than three
years. The degree of risk is assessed by considering the foreign nature
of these infectious diseases, their severity, and the probability of
being affected by the diseases present. The diseases listed do not
necessarily represent the total disease burden experienced by the local
population.
The risk to an individual traveler varies considerably by the specific
location, visit duration, type of activities, type of accommodations,
time of year, and other factors. Consultation with a travel medicine
physician is needed to evaluate individual risk and recommend
appropriate preventive measures such as vaccines.
Diseases are organized into the following six exposure categories shown
in italics and listed in typical descending order of risk. Note - The
sequence of exposure categories listed in individual country entries
may vary according to local conditions.
food or waterborne diseases acquired through eating or drinking on the
local economy:
Hepatitis A - viral disease that interferes with the functioning of the
liver; spread through consumption of food or water contaminated with
fecal matter, principally in areas of poor sanitation; victims exhibit
fever, jaundice, and diarrhea; 15% of victims will experience prolonged
symptoms over 6-9 months; vaccine available.
Hepatitis E - water-borne viral disease that interferes with the
functioning of the liver; most commonly spread through fecal
contamination of drinking water; victims exhibit jaundice, fatigue,
abdominal pain, and dark colored urine.
Typhoid fever - bacterial disease spread through contact with food or
water contaminated by fecal matter or sewage; victims exhibit sustained
high fevers; left untreated, mortality rates can reach 20%.
vectorborne diseases acquired through the bite of an infected
arthropod:
Malaria - caused by single-cell parasitic protozoa Plasmodium;
transmitted to humans via the bite of the female Anopheles mosquito;
parasites multiply in the liver attacking red blood cells resulting in
cycles of fever, chills, and sweats accompanied by anemia; death due to
damage to vital organs and interruption of blood supply to the brain;
endemic in 100, mostly tropical, countries with 90% of cases and the
majority of 1.5-2.5 million estimated annual deaths occurring in sub-
Saharan Africa.
Dengue fever - mosquito-borne (Aedes aegypti) viral disease associated
with urban environments; manifests as sudden onset of fever and severe
headache; occasionally produces shock and hemorrhage leading to death
in 5% of cases.
Yellow fever - mosquito-borne viral disease; severity ranges from
influenza-like symptoms to severe hepatitis and hemorrhagic fever;
occurs only in tropical South America and sub-Saharan Africa, where
most cases are reported; fatality rate is less than 20%.
Japanese Encephalitis - mosquito-borne (Culex tritaeniorhynchus) viral
disease associated with rural areas in Asia; acute encephalitis can
progress to paralysis, coma, and death; fatality rates 30%.
African Trypanosomiasis - caused by the parasitic protozoa Trypanosoma;
transmitted to humans via the bite of bloodsucking Tsetse flies;
infection leads to malaise and irregular fevers and, in advanced cases
when the parasites invade the central nervous system, coma and death;
endemic in 36 countries of sub-Saharan Africa; cattle and wild animals
act as reservoir hosts for the parasites.
Cutaneous Leishmaniasis - caused by the parasitic protozoa leishmania;
transmitted to humans via the bite of sandflies; results in skin
lesions that may become chronic; endemic in 88 countries; 90% of cases
occur in Iran, Afghanistan, Syria, Saudi Arabia, Brazil, and Peru; wild
and domesticated animals as well as humans can act as reservoirs of
infection.
Plague - bacterial disease transmitted by fleas normally associated
with rats; person-to-person airborne transmission also possible; recent
plague epidemics occurred in areas of Asia, Africa, and South America
associated with rural areas or small towns and villages; manifests as
fever, headache, and painfully swollen lymph nodes; disease progresses
rapidly and without antibiotic treatment leads to pneumonic form with a
death rate in excess of 50%.
Crimean-Congo hemorrhagic fever - tick-borne viral disease; infection
may also result from exposure to infected animal blood or tissue;
geographic distribution includes Africa, Asia, the Middle East, and
Eastern Europe; sudden onset of fever, headache, and muscle aches
followed by hemorrhaging in the bowels, urine, nose, and gums;
mortality rate is approximately 30%.
Rift Valley fever - viral disease affecting domesticated animals and
humans; transmission is by mosquito and other biting insects; infection
may also occur through handling of infected meat or contact with blood;
geographic distribution includes eastern and southern Africa where
cattle and sheep are raised; symptoms are generally mild with fever and
some liver abnormalities, but the disease may progress to hemorrhagic
fever, encephalitis, or ocular disease; fatality rates are low at about
1% of cases.
Chikungunya - mosquito-borne (Aedes aegypti) viral disease associated
with urban environments, similar to Dengue Fever; characterized by
sudden onset of fever, rash, and severe joint pain usually lasting 3-7
days, some cases result in persistent arthritis.
water contact diseases acquired through swimming or wading in
freshwater lakes, streams, and rivers:
Leptospirosis - bacterial disease that affects animals and humans;
infection occurs through contact with water, food, or soil contaminated
by animal urine; symptoms include high fever, severe headache,
vomiting, jaundice, and diarrhea; untreated, the disease can result in
kidney damage, liver failure, meningitis, or respiratory distress;
fatality rates are low but left untreated recovery can take months.
Schistosomiasis - caused by parasitic trematode flatworm Schistosoma;
fresh water snails act as intermediate host and release larval form of
parasite that penetrates the skin of people exposed to contaminated
water; worms mature and reproduce in the blood vessels, liver, kidneys,
and intestines releasing eggs, which become trapped in tissues
triggering an immune response; may manifest as either urinary or
intestinal disease resulting in decreased work or learning capacity;
mortality, while generally low, may occur in advanced cases usually due
to bladder cancer; endemic in 74 developing countries with 80% of
infected people living in sub-Saharan Africa; humans act as the
reservoir for this parasite.
aerosolized dust or soil contact disease acquired through inhalation of
aerosols contaminated with rodent urine:
Lassa fever - viral disease carried by rats of the genus Mastomys;
endemic in portions of West Africa; infection occurs through direct
contact with or consumption of food contaminated by rodent urine or
fecal matter containing virus particles; fatality rate can reach 50% in
epidemic outbreaks.
respiratory disease acquired through close contact with an infectious
person:
Meningococcal meningitis - bacterial disease causing an inflammation of
the lining of the brain and spinal cord; one of the most important
bacterial pathogens is Neisseria meningitidis because of its potential
to cause epidemics; symptoms include stiff neck, high fever, headaches,
and vomiting; bacteria are transmitted from person to person by
respiratory droplets and facilitated by close and prolonged contact
resulting from crowded living conditions, often with a seasonal
distribution; death occurs in 5-15% of cases, typically within 24-48
hours of onset of symptoms; highest burden of meningococcal disease
occurs in the hyperendemic region of sub-Saharan Africa known as the
"Meningitis Belt" which stretches from Senegal east to Ethiopia.
animal contact disease acquired through direct contact with local
animals:
Rabies - viral disease of mammals usually transmitted through the bite
of an infected animal, most commonly dogs; virus affects the central
nervous system causing brain alteration and death; symptoms initially
are non-specific fever and headache progressing to neurological
symptoms; death occurs within days of the onset of symptoms.
Manpower available for military service: This entry gives the number
of males and females falling in the military age range for the country
and assumes that every individual is fit to serve.
Manpower fit for military service: This entry gives the number of
males and females falling in the military age range for the country and
who are not otherwise disqualified for health reasons; accounts for the
health situation in the country and provides a more realistic estimate
of the actual number fit to serve.
Manpower reaching military service age annually: This entry gives the
number of draft-age males and females entering the military manpower
pool in any given year and is a measure of the availability of draft-
age young adults.
Map references: This entry includes the name of the Factbook reference
map on which a country may be found. The entry on Geographic
coordinates may be helpful in finding some smaller countries.
Maritime claims: This entry includes the following claims, the
definitions of which are excerpted from the United Nations Convention
on the Law of the Sea (UNCLOS), which alone contains the full and
definitive descriptions:
territorial sea - the sovereignty of a coastal state extends beyond its
land territory and internal waters to an adjacent belt of sea,
described as the territorial sea in the UNCLOS (Part II); this
sovereignty extends to the air space over the territorial sea as well
as its underlying seabed and subsoil; every state has the right to
establish the breadth of its territorial sea up to a limit not
exceeding 12 nautical miles; the normal baseline for measuring the
breadth of the territorial sea is the low-water line along the coast as
marked on large-scale charts officially recognized by the coastal
state; the UNCLOS describes specific rules for archipelagic states.
contiguous zone - according to the UNCLOS (Article 33), this is a zone
contiguous to a coastal state''s territorial sea, over which it may
exercise the control necessary to: prevent infringement of its customs,
fiscal, immigration, or sanitary laws and regulations within its
territory or territorial sea; punish infringement of the above laws and
regulations committed within its territory or territorial sea; the
contiguous zone may not extend beyond 24 nautical miles from the
baselines from which the breadth of the territorial sea is measured
(e.g. the US has claimed a 12-nautical mile contiguous zone in addition
to its 12-nautical mile territorial sea).
exclusive economic zone (EEZ) - the UNCLOS (Part V) defines the EEZ as
a zone beyond and adjacent to the territorial sea in which a coastal
state has: sovereign rights for the purpose of exploring and
exploiting, conserving and managing the natural resources, whether
living or non-living, of the waters superjacent to the seabed and of
the seabed and its subsoil, and with regard to other activities for the
economic exploitation and exploration of the zone, such as the
production of energy from the water, currents, and winds; jurisdiction
with regard to the establishment and use of artificial islands,
installations, and structures; marine scientific research; the
protection and preservation of the marine environment; the outer limit
of the exclusive economic zone shall not exceed 200 nautical miles from
the baselines from which the breadth of the territorial sea is
measured.
continental shelf - the UNCLOS (Article 76) defines the continental
shelf of a coastal state as comprising the seabed and subsoil of the
submarine areas that extend beyond its territorial sea throughout the
natural prolongation of its land territory to the outer edge of the
continental margin, or to a distance of 200 nautical miles from the
baselines from which the breadth of the territorial sea is measured
where the outer edge of the continental margin does not extend up to
that distance; the continental margin comprises the submerged
prolongation of the landmass of the coastal state, and consists of the
seabed and subsoil of the shelf, the slope and the rise; wherever the
continental margin extends beyond 200 nautical miles from the baseline,
coastal states may extend their claim to a distance not to exceed 350
nautical miles from the baseline or 100 nautical miles from the 2500
meter isobath; it does not include the deep ocean floor with its
oceanic ridges or the subsoil thereof.
exclusive fishing zone - while this term is not used in the UNCLOS,
some states (e.g., the United Kingdom) have chosen not to claim an EEZ,
but rather to claim jurisdiction over the living resources off their
coast; in such cases, the term exclusive fishing zone is often used;
the breadth of this zone is normally the same as the EEZ or 200
nautical miles.
Median age: This entry is the age that divides a population into two
numerically equal groups; that is, half the people are younger than
this age and half are older. It is a single index that summarizes the
age distribution of a population. Currently, the median age ranges from
a low of about 15 in Uganda and Gaza Strip to 40 or more in several
European countries and Japan. See the entry for "Age structure" for the
importance of a young versus an older age structure and, by
implication, a low versus a higher median age.
Merchant marine: Merchant marine may be defined as all ships engaged
in the carriage of goods; or all commercial vessels (as opposed to all
nonmilitary ships), which excludes tugs, fishing vessels, offshore oil
rigs, etc. This entry contains information in four fields - total,
ships by type, foreign-owned, and registered in other countries.
Total includes the number of ships (1,000 GRT or over), total DWT for
those ships, and total GRT for those ships. DWT or dead weight tonnage
is the total weight of cargo, plus bunkers, stores, etc., that a ship
can carry when immersed to the appropriate load line. GRT or gross
register tonnage is a figure obtained by measuring the entire sheltered
volume of a ship available for cargo and passengers and converting it
to tons on the basis of 100 cubic feet per ton; there is no stable
relationship between GRT and DWT.
Ships by type includes a listing of barge carriers, bulk cargo ships,
cargo ships, chemical tankers, combination bulk carriers, combination
ore/oil carriers, container ships, liquefied gas tankers, livestock
carriers, multifunctional large-load carriers, petroleum tankers,
passenger ships, passenger/cargo ships, railcar carriers, refrigerated
cargo ships, roll-on/roll-off cargo ships, short-sea passenger ships,
specialized tankers, and vehicle carriers.
Foreign-owned are ships that fly the flag of one country but belong to
owners in another.
Registered in other countries are ships that belong to owners in one
country but fly the flag of another.
Military: This category includes the entries dealing with a country''s
military structure, manpower, and expenditures.
Military - note: This entry includes miscellaneous military
information of significance not included elsewhere.
Military branches: This entry lists the service branches subordinate
to defense ministries or the equivalent (typically ground, naval, air,
and marine forces).
Military expenditures - dollar figure: This entry gives spending on
defense programs in US dollars f','eb8d7f87804e22fc444c65fa7b457d6785f586057e9000c88934de087bb99475','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('455ab1410af163f92174f3af134c13fb6a43e11c72afa73457d9d10ee629b54e',2007,'EH','Western Sahara','environment',24,'or the most recent year available;
dollar figures for military expenditures should be treated with caution
because of different price patterns and accounting methods among
nations, as well as wide variations in the strength of different
currencies.
Military expenditures - percent of GDP: This entry gives spending on
defense programs for the most recent year available as a percent of
gross domestic product (GDP); the GDP is calculated on an exchange rate
basis, i.e., not in terms of purchasing power parity (PPP).
Military service age and obligation: This entry gives the required
ages for voluntary or conscript military service and the length of
sevice obligation.
Money figures: All money figures are expressed in contemporaneous US
dollars unless otherwise indicated.
National holiday: This entry gives the primary national day of
celebration - usually independence day.
Nationality: This entry provides the identifying terms for citizens -
noun and adjective.
Natural gas - consumption: This entry is the total natural gas
consumed in cubic meters (cu m). The discrepancy between the amount of
natural gas produced and/or imported and the amount consumed and/or
exported is due to the omission of stock changes and other complicating
factors.
Natural gas - exports: This entry is the total natural gas exported in
cubic meters (cu m).
Natural gas - imports: This entry is the total natural gas imported in
cubic meters (cu m).
Natural gas - production: This entry is the total natural gas produced
in cubic meters (cu m). The discrepancy between the amount of natural
gas produced and/or imported and the amount consumed and/or exported is
due to the omission of stock changes and other complicating factors.
Natural gas - proved reserves: This entry is the stock of proved
reserves of natural gas in cubic meters (cu m). Proved reserves are
those quantities of natural gas, which, by analysis of geological and
engineering data, can be estimated with a high degree of confidence to
be commercially recoverable from a given date forward, from known
reservoirs and under current economic conditions.
Natural hazards: This entry lists potential natural disasters.
Natural resources: This entry lists a country''s mineral, petroleum,
hydropower, and other resources of commercial importance.
Net migration rate: This entry includes the figure for the difference
between the number of persons entering and leaving a country during the
year per 1,000 persons (based on midyear population). An excess of
persons entering the country is referred to as net immigration (e.g.,
3.56 migrants/1,000 population); an excess of persons leaving the
country as net emigration (e.g., -9.26 migrants/1,000 population). The
net migration rate indicates the contribution of migration to the
overall level of population change. High levels of migration can cause
problems such as increasing unemployment and potential ethnic strife
(if people are coming in) or a reduction in the labor force, perhaps in
certain key sectors (if people are leaving).
Oil - consumption: This entry is the total oil consumed in barrels per
day (bbl/day). The discrepancy between the amount of oil produced
and/or imported and the amount consumed and/or exported is due to the
omission of stock changes, refinery gains, and other complicating
factors.
Oil - exports: This entry is the total oil exported in barrels per day
(bbl/day), including both crude oil and oil products.
Oil - imports: This entry is the total oil imported in barrels per day
(bbl/day), including both crude oil and oil products.
Oil - production: This entry is the total oil produced in barrels per
day (bbl/day). The discrepancy between the amount of oil produced
and/or imported and the amount consumed and/or exported is due to the
omission of stock changes, refinery gains, and other complicating
factors.
Oil - proved reserves: This entry is the stock of proved reserves of
crude oil in barrels (bbl). Proved reserves are those quantities of
petroleum which, by analysis of geological and engineering data, can be
estimated with a high degree of confidence to be commercially
recoverable from a given date forward, from known reservoirs and under
current economic conditions.
People: This category includes the entries dealing with the
characteristics of the people and their society.
People - note: This entry includes miscellaneous demographic
information of significance not included elsewhere.
Personal Names - Capitalization: The Factbook capitalizes the surname
or family name of individuals for the convenience of our users who are
faced with a world of different cultures and naming conventions. The
need for capitalization, bold type, underlining, italics, or some other
indicator of the individual''s surname is apparent in the following
examples: MAO Zedong, Fidel CASTRO Ruz, George W. BUSH, and TUNKU
SALAHUDDIN Abdul Aziz Shah ibni Al-Marhum Sultan Hisammuddin Alam Shah.
By knowing the surname, a short form without all capital letters can be
used with confidence as in President Castro, Chairman Mao, President
Bush, or Sultan Tunku Salahuddin. The same system of capitalization is
extended to the names of leaders with surnames that are not commonly
used such as Queen ELIZABETH II. For Vietnamese names, the given name
is capitalized because officials are referred to by their given name
rather than by their surname. For example, the president of Vietnam is
Tran Duc LUONG. His surname is Tran, but he is referred to by his given
name - President LUONG.
Personal Names - Spelling: The romanization of personal names in the
Factbook normally follows the same transliteration system used by the
US Board on Geographic Names for spelling place names. At times,
however, a foreign leader expressly indicates a preference for, or the
media or official documents regularly use, a romanized spelling that
differs from the transliteration derived from the US Government
standard. In such cases, the Factbook uses the alternative spelling.
Personal Names - Titles: The Factbook capitalizes any valid title (or
short form of it) immediately preceding a person''s name. A title
standing alone is not capitalized. Examples: President PUTIN and
President BUSH are chiefs of state. In Russia, the president is chief
of state and the premier is the head of the government, while in the
US, the president is both chief of state and head of government.
Petroleum: See entries under Oil.
Petroleum products: See entries under Oil.
Pipelines: This entry gives the lengths and types of pipelines for
transporting products like natural gas, crude oil, or petroleum
products.
Political parties and leaders: This entry includes a listing of
significant political organizations and their leaders.
Political pressure groups and leaders: This entry includes a listing
of organizations with leaders involved in politics, but not standing
for legislative election.
Population: This entry gives an estimate from the US Bureau of the
Census based on statistics from population censuses, vital statistics
registration systems, or sample surveys pertaining to the recent past
and on assumptions about future trends. The total population presents
one overall measure of the potential impact of the country on the world
and within its region. Note: starting with the 1993 Factbook,
demographic estimates for some countries (mostly African) have
explicitly taken into account the effects of the growing impact of the
HIV/AIDS epidemic. These countries are currently: The Bahamas, Benin,
Botswana, Brazil, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Central African Republic, Democratic Republic of the Congo, Republic of
the Congo, Cote d''Ivoire, Ethiopia, Gabon, Ghana, Guyana, Haiti,
Honduras, Kenya, Lesotho, Malawi, Mozambique, Namibia, Nigeria, Rwanda,
South Africa, Swaziland, Tanzania, Thailand, Togo, Uganda, Zambia, and
Zimbabwe.
Population below poverty line: National estimates of the percentage of
the population falling below the poverty line are based on surveys of
sub-groups, with the results weighted by the number of people in each
group. Definitions of poverty vary considerably among nations. For
example, rich nations generally employ more generous standards of
poverty than poor nations.
Population growth rate: The average annual percent change in the
population, resulting from a surplus (or deficit) of births over deaths
and the balance of migrants entering and leaving a country. The rate
may be positive or negative. The growth rate is a factor in determining
how great a burden would be imposed on a country by the changing needs
of its people for infrastructure (e.g., schools, hospitals, housing,
roads), resources (e.g., food, water, electricity), and jobs. Rapid
population growth can be seen as threatening by neighboring countries.
Ports and terminals: This entry lists major ports and terminals
primarily on the basis of the amount of cargo tonnage shipped through
the facilities on an annual basis. In some instances, the number of
containers handled or ship visits were also considered.
Public debt: This entry records the cumulatiive total of all
government borrowings less repayments that are denominated in a
country''s home currency. Public debt should not be confused with
external debt, which reflects the foreign currency liabilities of both
the private and public sector and must be financed out of foreign
exchange earnings.
Radio broadcast stations: This entry includes the total number of AM,
FM, and shortwave broadcast stations.
Railways: This entry states the total route length of the railway
network and of its component parts by gauge: broad, standard, narrow,
and dual. Other gauges are listed under note.
Reference maps: This section includes world and regional maps.
Refugees and internally displaced persons: This entry includes those
persons residing in a country as refugees or internally displaced
persons (IDPs). The definition of a refugee according to a United
Nations Convention is "a person who is outside his/her country of
nationality or habitual residence; has a well-founded fear of
persecution because of his/her race, religion, nationality, membership
in a particular social group or political opinion; and is unable or
unwilling to avail himself/herself of the protection of that country,
or to return there, for fear of persecution." The UN established the
Office of the UN High Commissioner for Refugees (UNHCR) in 1950 to
handle refugee matters worldwide. The UN Relief and Works Agency for
Palestine Refugees in the Near East (UNRWA) has a different,
operational definition for a Palestinian refugee: "a person whose
normal place of residence was Palestine during the period 1 June 1946
to 15 May 1948 and who lost both home and means of livelihood as a
result of the 1948 conflict." However, UNHCR also assists some 400,000
Palestinian refugees not covered under the UNRWA definition. The term
"internally displaced person" is not specifically covered in the UN
Convention; it is used to describe people who have fled their homes for
reasons similar to refugees, but who remain within their own national
territory and are subject to the laws of that state.
Religions: This entry is an ordered listing of religions by adherents
starting with the largest group and sometimes includes the percent of
total population.
Reserves of foreign exchange and gold: This entry gives the dollar
value for the stock of all financial assets that are available to the
central monetary authority for use in meeting a country''s balance of
payments needs as of the end-date of the period specified. This
category includes not only foreign currency and gold, but also a
country''s holdings of Special Drawing Rights in the International
Monetary Fund, and its reserve position in the Fund.
Roadways: This entry gives the total length of the road network and
includes the length of the paved and unpaved portions.
Sex ratio: This entry includes the number of males for each female in
five age groups - at birth, under 15 years, 15-64 years, 65 years and
over, and for the total population. Sex ratio at birth has recently
emerged as an indicator of certain kinds of sex discrimination in some
countries. For instance, high sex ratios at birth in some Asian
countries are now attributed to sex-selective abortion and infanticide
due to a strong preference for sons. This will affect future marriage
patterns and fertility patterns. Eventually, it could cause unrest
among young adult males who are unable to find partners.
Suffrage: This entry gives the age at enfranchisement and whether the
right to vote is universal or restricted.
Telephone numbers: All telephone numbers in The World Factbook consist
of the country code in brackets, the city or area code (where required)
in parentheses, and the local number. The one component that is not
presented is the international access code, which varies from country
to country. For example, an international direct dial telephone call
placed from the US to Madrid, Spain, would be as follows: 011 [34] (1)
577-xxxx, where 011 is the international access code for station-to-
station calls; 01 is for calls other than station-to-station calls,
[34] is the country code for Spain, (1) is the city code for Madrid,
577 is the local exchange, and xxxx is the local telephone number. An
international direct dial telephone call placed from another country to
the US would be as follows: international access code + [1] (202) 939-
xxxx, where [ 1] is the country code for the US, (202) is the area code
for Washington, DC, 939 is the local exchange, and xxxx is the local
telephone number.
Telephone system: This entry includes a brief general assessment of
the system with details on the domestic and international components.
The following terms and abbreviations are used throughout the entry:
Arabsat - Arab Satellite Communications Organization (Riyadh, Saudi
Arabia).
Autodin - Automatic Digital Network (US Department of Defense).
CB - citizen''s band mobile radio communications.
Cellular telephone system - the telephones in this system are radio
transceivers, with each instrument having its own private radio
frequency and sufficient radiated power to reach the booster station in
its area (cell), from which the telephone signal is fed to a telephone
exchange.
Central American Microwave System - a trunk microwave radio relay
system that links the countries of Central America and Mexico with each
other.
Coaxial cable - a multichannel communication cable consisting of a
central conducting wire, surrounded by and insulated from a cylindrical
conducting shell; a large number of telephone channels can be made
available within the insulated space by the use of a large number of
carrier frequencies.
Comsat - Communications Satellite Corporation (US).
DSN - Defense Switched Network (formerly Automatic Voice Network or
Autovon); basic general-purpose, switched voice network of the Defense
Communications System (US Department of Defense).
Eutelsat - European Telecommunications Satellite Organization (Paris).
Fiber-optic cable - a multichannel communications cable using a thread
of optical glass fibers as a transmission medium in which the signal
(voice, video, etc.) is in the form of a coded pulse of light.
GSM - a global system for mobile (cellular) communications devised by
the Groupe Special Mobile of the pan-European standardization
organization, Conference Europeanne des Posts et Telecommunications
(CEPT) in 1982.
HF - high frequency; any radio frequency in the 3,000- to 30,000-kHz
range.
Inmarsat - International Maritime Satellite Organization (London);
provider of global mobile satellite communications for commercial,
distress, and safety applications at sea, in the air, and on land.
Intelsat - International Telecommunications Satellite Organization
(Washington, DC).
Intersputnik - International Organization of Space Communications
(Moscow); first established in the former Soviet Union and the East
European countries, it is now marketing its services worldwide with
earth stations in North America, Africa, and East Asia.
Landline - communication wire or cable of any sort that is installed on
poles or buried in the ground.
Marecs - Maritime European Communications Satellite used in the
Inmarsat system on lease from the European Space Agency.
Marisat - satellites of the Comsat Corporation that participate in the
Inmarsat system.
Medarabtel - the Middle East Telecommunications Project of the
International Telecommunications Union (ITU) providing a modern
telecommunications network, primarily by microwave radio relay, linking
Algeria, Djibouti, Egypt, Jordan, Libya, Morocco, Saudi Arabia,
Somalia, Sudan, Syria, Tunisia, and Yemen; it was initially started in
Morocco in 1970 by the Arab Telecommunications Union (ATU) and was
known at that time as the Middle East Mediterranean Telecommunications
Network.
Microwave radio relay - transmission of long distance telephone calls
and television programs by highly directional radio microwaves that are
received and sent on from one booster station to another on an optical
path.
NMT - Nordic Mobile Telephone; an analog cellular telephone system that
was developed jointly by the national telecommunications authorities of
the Nordic countries (Denmark, Finland, Iceland, Norway, and Sweden).
Orbita - a Russian television service; also the trade name of a packet-
switched digital telephone network.
Radiotelephone communications - the two-way transmission and reception
of sounds by broadcast radio on authorized frequencies using telephone
handsets.
PanAmSat - PanAmSat Corporation (Greenwich, CT).
SAFE - South African Far East Cable
Satellite communication system - a communication system consisting of
two or more earth stations and at least one satellite that provide long
distance transmission of voice, data, and television; the system
usually serves as a trunk connection between telephone exchanges; if
the earth stations are in the same country, it is a domestic system.
Satellite earth station - a communications facility with a microwave
radio transmitting and receiving antenna and required receiving and
transmitting equipment for communicating with satellites.
Satellite link - a radio connection between a satellite and an earth
station permitting communication between them, either one-way (down
link from satellite to earth station - television receive-only
transmission) or two-way (telephone channels).
SHF - super high frequency; any radio frequency in the 3,000- to
30,000-MHz range.
Shortwave - radio frequencies (from 1.605 to 30 MHz) that fall above
the commercial broadcast band and are used for communication over long
distances.
Solidaridad - geosynchronous satellites in Mexico''s system of
international telecommunications in the Western Hemisphere.
Statsionar - Russia''s geostationary system for satellite
telecommunications.
Submarine cable - a cable designed for service under water.
TAT - Trans-Atlantic Telephone; any of a number of high-capacity
submarine coaxial telephone cables linking Europe with North America.
Telefax - facsimile service between subscriber stations via the public
switched telephone network or the international Datel network.
Telegraph - a telecommunications system designed for unmodulated
electric impulse transmission.
Telex - a communication service involving teletypewriters connected by
wire through automatic exchanges.
Tropospheric scatter - a form of microwave radio transmission in which
the troposphere is used to scatter and reflect a fraction of the
incident radio waves back to earth; powerful, highly directional
antennas are used to transmit and receive the microwave signals;
reliable over-the-horizon communications are realized for distances up
to 600 miles in a single hop; additional hops can extend the range of
this system for very long distances.
Trunk network - a network of switching centers, connected by
multichannel trunk lines.
UHF - ultra high frequency; any radio frequency in the 300- to 3,000-
MHz range.
VHF - very high frequency; any radio frequency in the 30- to 300-MHz
range.
Telephones - main lines in use: This entry gives the total number of
main telephone lines in use.
Telephones - mobile cellular: This entry gives the total number of
mobile cellular telephone subscribers.
Television broadcast stations: This entry gives the total number of
separate broadcast stations plus any repeater stations.
Terminology: Due to the highly structured nature of the Factbook
database, some collective generic terms have to be used. For example,
the word Country in the Country name entry refers to a wide variety of
dependencies, areas of special sovereignty, uninhabited islands, and
other entities in addition to the traditional countries or independent
states. Military is also used as an umbrella term for various civil
defense, security, and defense activities in many entries. The
Independence entry includes the usual colonial independence dates and
former ruling states as well as other significant nationhood dates such
as the traditional founding date or the date of unification,
federation, confederation, establishment, or state succession that are
not strictly independence dates. Dependent areas have the nature of
their dependency status noted in this same entry.
Terrain: This entry contains a brief description of the topography.
Time Difference: This entry is expressed in The World Factbook in two
ways. First, it is stated as the difference in hours between the
capital of an entity and Coordinated Universal Time (UTC) during
Standard Time. Additionally, the difference in time between the capital
of an entity and that observed in Washington, D.C. is also provided.
Note that the time difference assumes both locations are simultaneously
observing Standard Time or Daylight Saving Time.
Time zones: Ten countries (Australia, Brazil, Canada, Indonesia,
Kazakhstan, Mexico, New Zealand, Russia, Spain, and the United States)
and the island of Greenland observe more than one official time
depending on the number of designated time zones within their
boundaries. An illustration of time zones throughout the world and
within countries can be seen in the Standard Time Zones of the World
map included in the Reference Maps section of The World Factbook.
Total fertility rate: This entry gives a figure for the average number
of children that would be born per woman if all women lived to the end
of their childbearing years and bore children according to a given
fertility rate at each age. The total fertility rate (TFR) is a more
direct measure of the level of fertility than the crude birth rate,
since it refers to births per woman. This indicator shows the potential
for population change in the country. A rate of two children per woman
is considered the replacement rate for a population, resulting in
relative stability in terms of total numbers. Rates above two children
indicate populations growing in size and whose median age is declining.
Higher rates may also indicate difficulties for families, in some
situations, to feed and educate their children and for women to enter
the labor force. Rates below two children indicate populations
decreasing in size and growing older. Global fertility rates are in
general decline and this trend is most pronounced in industrialized
countries, especially Western Europe, where populations are projected
to decline dramatically over the next 50 years.
Trafficking in persons: Trafficking in persons is modern-day slavery,
involving victims who are forced, defrauded, or coerced into labor or
sexual exploitation. The International Labor Organization (ILO), the UN
agency charged with addressing labor standards, employment, and social
protection issues, estimates that 12.3 million people worldwide are
enslaved in forced labor, bonded labor, forced child labor, sexual
servitude, and involuntary servitude at any given time. Human
trafficking is a multi-dimensional threat, depriving people of their
human','92cd2391ef87c9cdb559eac767a4bfd3c52b5bcb61931767592757b28e6d79b3','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f629c35d21d4c513f14a4df8d3c53f4aee687647d596a8e2fabc785cd4408b93',2007,'EH','Western Sahara','environment',25,'rights and freedoms, risking global health, promoting social
breakdown, inhibiting development by depriving countries of their human
capital, and helping fuel the growth of organized crime. In 2000, the
US Congress passed the Trafficking Victims Protection Act (TVPA),
reauthorized in 2003 and 2005, which provides tools for the US to
combat trafficking in persons, both domestically and abroad. One of the
law''s key components is the creation of the US Department of State''s
annual Trafficking in Persons Report, which assesses the government
response in some 150 countries with a significant number of victims
trafficked across their borders who are recruited, harbored,
transported, provided, or obtained for forced labor or sexual
exploitation. Countries in the annual report are rated in three tiers,
based on government efforts to combat trafficking. The countries
identified in this entry are those listed in the 2006 Trafficking in
Persons Report as Tier 2 Watch List or Tier 3 based on the following
definitions:
Tier 2 Watch List countries do not fully comply with the minimum
standards for the elimination of trafficking but are making significant
efforts to do so, and meet one of the following criteria:
1. they display a high or significantly increasing number victims,
2. they have failed to provide evidence of increasing efforts to combat
trafficking in persons, or,
3. they have committed to take action over the next year.
Tier 3 countries neither satisfy the minimum standards for the
elimination of trafficking nor demonstrate a significant effort to do
so. Countries in this tier are subject to potential non-humanitarian
and non-trade sanctions.
Transnational issues: This category includes four entries - Disputes -
international, Refugees and internally displaced persons, Trafficking
in persons, and Illicit drugs - that deal with current issues going
beyond national boundaries.
Transportation: This category includes the entries dealing with the
means for movement of people and goods.
Transportation - note: This entry includes miscellaneous
transportation information of significance not included elsewhere.
UTC (Coordinated Universal Time): See entry for Coordinated Universal
Time.
Unemployment rate: This entry contains the percent of the labor force
that is without jobs. Substantial underemployment might be noted.
Waterways: This entry gives the total length of navigable rivers,
canals, and other inland bodies of water.
Weights and Measures: This information is presented in Appendix G:
Weights and Measures and includes mathematical notations (mathematical
powers and names), metric interrelationships (prefix; symbol; length,
weight, or capacity; area; volume), and standard conversion factors.
Years: All year references are for the calendar year (CY) unless
indicated as fiscal year (FY). The calendar year is an accounting
period of 12 months from 1 January to 31 December. The fiscal year is
an accounting period of 12 months other than 1 January to 31 December.
Note: Information for the US and US dependencies was compiled from
material in the public domain and does not represent Intelligence
Community estimates.
This page was last updated on 8 February 2007
=====================================================================
CIA - The World Factbook -- History
A Brief History of Basic Intelligence and The World Factbook
The Intelligence Cycle is the process by which information is
acquired, converted into intelligence, and made available to
policymakers. Information is raw data from any source, data that may
be fragmentary, contradictory, unreliable, ambiguous, deceptive, or
wrong. Intelligence is information that has been collected,
integrated, evaluated, analyzed, and interpreted. Finished
intelligence is the final product of the Intelligence Cycle ready to
be delivered to the policymaker.
The three types of finished intelligence are: basic, current, and
estimative. Basic intelligence provides the fundamental and factual
reference material on a country or issue. Current intelligence
reports on new developments. Estimative intelligence judges probable
outcomes. The three are mutually supportive: basic intelligence is
the foundation on which the other two are constructed; current
intelligence continually updates the inventory of knowledge; and
estimative intelligence revises overall interpretations of country
and issue prospects for guidance of basic and current intelligence.
The World Factbook, The President''s Daily Brief, and the National
Intelligence Estimates are examples of the three types of finished
intelligence.
The United States has carried on foreign intelligence activities
since the days of George Washington but only since World War II have
they been coordinated on a government-wide basis. Three programs
have highlighted the development of coordinated basic intelligence
since that time: (1 ) the Joint Army Navy Intelligence Studies
(JANIS), (2 ) the National Intelligence Survey (NIS), and (3) The
World Factbook.
During World War II, intelligence consumers realized that the
production of basic intelligence by different components of the US
Government resulted in a great duplication of effort and conflicting
information. The Japanese attack on Pearl Harbor in 1941 brought
home to leaders in Congress and the executive branch the need for
integrating departmental reports to national policymakers. Detailed
and coordinated information was needed not only on such major powers
as Germany and Japan, but also on places of little previous
interest. In the Pacific Theater, for example, the Navy and Marines
had to launch amphibious operations against many islands about which
information was unconfirmed or nonexistent. Intelligence authorities
resolved that the United States should never again be caught
unprepared.
In 1943, Gen. George B. Strong (G-2), Adm. H. C. Train (Office of
Naval Intelligence - ONI), and Gen. William J. Donovan (Director of
the Office of Strategic Services - OSS) decided that a joint effort
should be initiated. A steering committee was appointed on 27 April
1943 that recommended the formation of a Joint Intelligence Study
Publishing Board to assemble, edit, coordinate, and publish the
Joint Army Navy Intelligence Studies (JANIS). JANIS was the first
interdepartmental basic intelligence program to fulfill the needs of
the US Government for an authoritative and coordinated appraisal of
strategic basic intelligence. Between April 1943 and July 1947, the
board published 34 JANIS studies. JANIS performed well in the war
effort, and numerous letters of commendation were received,
including a statement from Adm. Forrest Sherman, Chief of Staff,
Pacific Ocean Areas, which said, "JANIS has become the indispensable
reference work for the shore-based planners."
The need for more comprehensive basic intelligence in the postwar
world was well expressed in 1946 by George S. Pettee, a noted author
on national security. He wrote in The Future of American Secret
Intelligence (Infantry Journal Press, 1946, page 46) that world
leadership in peace requires even more elaborate intelligence than
in war. "The conduct of peace involves all countries, all human
activities - not just the enemy and his war production."
The Central Intelligence Agency was established on 26 July 1947 and
officially began operating on 18 September 1947. Effective 1 October
1947, the Director of Central Intelligence assumed operational
responsibility for JANIS. On 13 January 1948, the National Security
Council issued Intelligence Directive (NSCID) No. 3, which
authorized the National Intelligence Survey (NIS) program as a
peacetime replacement for the wartime JANIS program. Before adequate
NIS country sections could be produced, government agencies had to
develop more comprehensive gazetteers and better maps. The US Board
on Geographic Names (BGN) compiled the names; the Department of the
Interior produced the gazetteers; and CIA produced the maps.
The Hoover Commission''s Clark Committee, set up in 1954 to study the
structure and administration of the CIA, reported to Congress in
1955 that: "The National Intelligence Survey is an invaluable
publication which provides the essential elements of basic
intelligence on all areas of the world. There will always be a
continuing requirement for keeping the Survey up-to-date." The
Factbook was created as an annual summary and update to the
encyclopedic NIS studies. The first classified Factbook was
published in August 1962, and the first unclassified version was
published in June 1971. The NIS program was terminated in 1973
except for the Factbook, map, and gazetteer components. The 1975
Factbook was the first to be made available to the public with sales
through the US Government Printing Office (GPO). The Factbook was
first made available on the Internet in June 1997. The year 2007
marks the 60th anniversary of the establishment of the Central
Intelligence Agency and the 64th year of continuous basic
intelligence support to the US Government by The World Factbook and
its two predecessor programs.
The Evolution of The World Factbook
National Basic Intelligence Factbook produced semiannually until
1980. Country entries include sections on Land, Water, People,
Government, Economy, Communications, and Defense Forces.
1981 - Publication becomes an annual product and is renamed The
World Factbook. A total of 165 nations are covered on 225 pages.
1983 - Appendices (Conversion Factors, International Organizations)
first introduced.
1984 - Appendices expanded; now include: A. The United Nations, B.
Selected United Nations Organizations, C. Selected International
Organizations, D. Country Membership in Selected Organizations, E.
Conversion Factors.
1987 - A new Geography section replaces the former separate Land and
Water sections. UN Organizations and Selected International
Organizations appendices merged into a new International
Organizations appendix. First multi-color-cover Factbook.
1988 - More than 40 new geographic entities added to provide
complete world coverage without overlap or omission. Among the new
entities are Antarctica, oceans (Arctic, Atlantic, Indian, Pacific),
and the World. The front-of-the-book explanatory introduction
expanded and retitled to Notes, Definitions, and Abbreviations. Two
new Appendices added: Weights and Measures (in place of Conversion
Factors) and a Cross-Reference List of Geographic Names. Factbook
size reaches 300 pages.
1989 - Economy section completely revised and now includes an
Overview briefly describing a country''s economy. New entries added
under People, Government, and Communications.
1990 - The Government section revised and considerably expanded with
new entries.
1991 - A new International Organizations and Groups appendix added.
Factbook size reaches 405 pages.
1992 - Twenty new successor state entries replace those of the
Soviet Union and Yugoslavia. New countries are respectively:
Armenia, Azerbaijan, Belarus, Estonia, Georgia, Kazakhstan,
Kyrgyzstan, Latvia, Lithuania, Moldova, Russia, Tajikistan,
Turkmenistan, Ukraine, Uzbekistan; and Bosnia and Hercegovina,
Croatia, Macedonia, Serbia and Montenegro, Slovenia. Number of
nations in the Factbook rises to 188.
1993 - Czechoslovakia''s split necessitates new Czech Republic and
Slovakia entries. New Eritrea entry added after it secedes from
Ethiopia. Substantial enhancements made to Geography section.
1994 - Two new appendices address Selected International
Environmental Agreements. The gross domestic product (GDP) of most
developing countries changed to a purchasing power parity (PPP)
basis rather than an exchange rate basis. Factbook size up to 512
pages.
1995 - The GDP of all countries now presented on a PPP basis. New
appendix lists estimates of GDP on an exchange rate basis.
Communications category split; Railroads, Highways, Inland
waterways, Pipelines, Merchant marine, and Airports entries now make
up a new Transportation category. The World Factbook is first
produced on CD-ROM.
1996 - Maps accompanying each entry now present more detail. Flags
also introduced for nearly all entities. Various new entries appear
under Geography and Communications. Factbook abbreviations
consolidated into a new Appendix A. Two new appendices present a
Cross-Reference List of Country Data Codes and a Cross-Reference
List of Hydrogeographic Data Codes. Geographic coordinates added to
Appendix H, Cross-Reference List of Geographic Names. Factbook size
expands by 95 pages in one year to reach 652.
1997 - A special edition for the CIA''s 50 th anniversary. A schema
or Guide to Country Profiles introduced. New color maps and flags
now accompany each country profile. Category headings distinguished
by shaded backgrounds. Number of categories expanded to nine - the
current number - with the addition of an Introduction (for only a
few countries) and Transnational Issues (which includes
Disputes-international and Illicit drugs). The World Factbook
introduced onto the Internet.
1998 - The Introduction category with two entries, Current issues
and Historical perspective, expanded to more countries. Last year
for the production of CD-ROM versions of the Factbook.
1999 - Historical perspective and Current issues entries in the
Introduction category combined into a new Background statement.
Several new Economy entries introduced. A new physical map of the
world added to the back-of-the-book reference maps.
2000 - A new "country profile" added on the Southern Ocean. The
Background statements dramatically expanded to over 200 countries
and possessions. A number of new Communications entries added.
2001 - Background entries completed for all 267 entities in the
Factbook. Several new HIV/AIDS entries introduced under the People
category. Revision begun on individual country maps to include
elevation extremes and a partial geographic grid. Weights and
Measures appendix deleted.
2002 - New entry on Distribution of Family income - Gini index
added. Revision of individual country maps continued (process still
ongoing as of 2007).
2003 - In the Economy category, petroleum entries added for oil
production, consumption, exports, imports, and proved reserves, as
well as natural gas proved reserves.
2004 - Additional petroleum entries included for natural gas
production, consumption, exports, and imports. In the Transportation
category, under Merchant marine, subfields added for foreign-owned
vessels and those registered in other countries. Descriptions of the
many forms of government mentioned in the Factbook incorporated into
the Notes and Definitions.
2005 - In the People category, a Major infectious diseases field
added for countries deemed to pose a higher risk for travelers. In
the Economy category, entries included for Current account balance,
Investment, Public debt, and Reserves of foreign exchange and gold.
The Transnational issues category expanded to include Refugees and
internally displaced persons. Category headings receive distinctive
colored backgrounds. These distinguishing colors are used in both
the printed and online versions of the Factbook. Size of the printed
Factbook reaches 702 pages.
2006 - In the Economy category, national GDP figures now presented
at Official Exchange Rates (OER) in addition to GDP at purchasing
power parity (PPP).
2007 - In the Government category, the Capital entry significantly
expanded with up to four subfields, including new information having
to do with time. The subfields consist of the name of the capital
itself, its geographic coordinates, the time difference at the
capital from coordinated universal time (UTC), and, if applicable,
information on daylight saving time (DST). Where appropriate, a
special note is added to highlight those countries with multiple
time zones. A Trafficking in persons entry added to the
Transnational issues category. A new appendix, Weights and Measures,
(re)introduced to the online version of the Factbook.
=====================================================================
CIA - The World Factbook -- Contributors and Copyright Information
The World Factbook is prepared by the Central Intelligence Agency
for the use of US Government officials, and the style, format,
coverage, and content are designed to meet their specific
requirements. Information is provided by Antarctic Information
Program (National Science Foundation), Armed Forces Medical
Intelligence Center (Department of Defense), Bureau of the Census
(Department of Commerce), Bureau of Labor Statistics (Department of
Labor), Central Intelligence Agency, Council of Managers of National
Antarctic Programs, Defense Intelligence Agency (Department of
Defense), Department of Energy, Department of State, Fish and
Wildlife Service (Department of the Interior), Maritime
Administration (Department of Transportation), National
Geospatial-Intelligence Agency (Department of Defense), Naval
Facilities Engineering Command (Department of Defense), Office of
Insular Affairs (Department of the Interior), Office of Naval
Intelligence (Department of Defense), US Board on Geographic Names
(Department of the Interior), US Transportation Command (Department
of Defense), Oil & Gas Journal, and other public and private sources.
The Factbook is in the public domain. Accordingly, it may be copied
freely without permission of the Central Intelligence Agency (CIA).
The official seal of the CIA, however, may NOT be copied without
permission as required by the CIA Act of 1949 (50 U.S.C. section
403m). Misuse of the official seal of the CIA could result in civil
and criminal penalties.
Comments and queries are welcome and may be addressed to:
Central Intelligence Agency
Attn.: Office of Public Affairs
Washington, DC 20505
Hours: Monday-Friday 8:00 AM-4:30 PM Eastern Standard Time
Telephone: [1] (703) 482-0623
FAX: [1] (703) 482-1739
=====================================================================
CIA - The World Factbook -- Purchasing Information
The Central Intelligence Agency (CIA) publishes The World Factbook
in printed and Internet versions. US Government officials may obtain
information about availability of the Factbook from their
organizations or through liaison channels to the CIA. Other users
may obtain sales information about printed copies from the following:
Superintendent of Documents
P. O. Box 371954
Pittsburgh, PA 15250-7954
Hours: Monday-Friday 7:30 AM-9:00 PM Eastern Standard Time (EST)
Telephone: [1] (202) 512-1800; toll free: [1] (866) 512-1800
FAX: [1] (202) 512-2104
http://bookstore.gpo.gov/
National Technical Information Service
5285 Port Royal Road
Springfield, VA 22161
Hours: Monday-Friday 8:00 AM-6:00 PM Eastern Standard Time (EST)
Telephone: [1] (800) 553-6847 (only in the US);
[1] (703) 605-6000 (for outside US)
FAX: [1] (703) 605-6900
http://www.ntis.gov/
The World Factbook can be accessed on the Internet at:
http://www.cia.gov/cia/publications/factbook/index.html
=====================================================================
CIA - The World Factbook -- FAQs
Frequently Asked Questions
The World Factbook staff thanks you for your comments, suggestions,
updates, kudos, and corrections over the past years. The willingness
of readers from around the world to share their observations and
specialized knowledge is very helpful as we try to produce the best
possible publications. Please feel free to continue to write and
e-mail e-mail us. When submitting corrections or updates to the
Factbook, please include your source(s) of information. At least two
Factbook staffers review every submitted item. The sheer volume of
correspondence precludes detailed personal replies, but we sincerely
appreciate your time and interest in the Factbook. If you include
your e-mail address we will at least acknowledge your note. Thank
you again.
Answers to many frequently asked questions (FAQs) are explained in
the Notes and Definitions section in The World Factbook. Please
review this section to see if your question is already answered
there. In addition, we have compiled the following list of FAQs to
answer other common questions. Select from the following categories
to narrow your search:
General','77efab3b9f22172ff283a7beadaee50e9860a4ebc400bd50efce5c69d76897d6','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cebdae03923f4ecabcb4aef060dcab294491884f4c74b9372ff13378c1a1b95b',2007,'TG','Togo','environment',65,'Geography Canada
Location:
Northern North America, bordering the North Atlantic Ocean on the
east, North Pacific Ocean on the west, and the Arctic Ocean on the
north, north of the conterminous US
Geographic coordinates:
60 00 N, 95 00 W
Map references:
North America
Area:
total: 9,984,670 sq km
land: 9,093,507 sq km
water: 891,163 sq km
Area - comparative:
somewhat larger than the US
Land boundaries:
total: 8,893 km
border countries: US 8,893 km (includes 2,477 km with Alaska)
Coastline:
202,080 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the continental margin
Climate:
varies from temperate in south to subarctic and arctic in north
Terrain:
mostly plains with mountains in west and lowlands in southeast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Logan 5,959 m
Natural resources:
iron ore, nickel, zinc, copper, gold, lead, molybdenum, potash,
diamonds, silver, fish, timber, wildlife, coal, petroleum, natural
gas, hydropower
Land use:
arable land: 4.57%
permanent crops: 0.65%
other: 94.78% (2005)
Irrigated land:
7,850 sq km (2003)
Natural hazards:
continuous permafrost in north is a serious obstacle to
development; cyclonic storms form east of the Rocky Mountains, a
result of the mixing of air masses from the Arctic, Pacific, and
North American interior, and produce most of the country''s rain and
snow east of the mountains
Environment - current issues:
air pollution and resulting acid rain severely affecting lakes and
damaging forests; metal smelting, coal-burning utilities, and
vehicle emissions impacting on agricultural and forest productivity;
ocean waters becoming contaminated due to agricultural, industrial,
mining, and forestry activities
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air Pollution-Sulfur 85,
Air Pollution-Sulfur 94, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals, Antarctic
Treaty, Biodiversity, Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: Air Pollution-Volatile Organic Compounds,
Marine Life Conservation
Geography - note:
second-largest country in world (after Russia); strategic location
between Russia and US via north polar route; approximately 90% of
the population is concentrated within 160 km of the US border
People Canada
Population:
33,098,932 (July 2006 est.)
Age structure:
0-14 years: 17.6% (male 2,992,811/female 2,848,388)
15-64 years: 69% (male 11,482,452/female 11,368,286)
65 years and over: 13.3% (male 1,883,008/female 2,523,987) (2006
est.)
Median age:
total: 38.9 years
male: 37.8 years
female: 39.9 years (2006 est.)
Population growth rate:
0.88% (2006 est.)
Birth rate:
10.78 births/1,000 population (2006 est.)
Death rate:
7.8 deaths/1,000 population (2006 est.)
Net migration rate:
5.85 migrant(s)/1,000 population (2006 est.)
Sex ratio:
at birth: 1.05 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.01 male(s)/female
65 years and over: 0.75 male(s)/female
total population: 0.98 male(s)/female (2006 est.)
Infant mortality rate:
total: 4.69 deaths/1,000 live births
male: 5.15 deaths/1,000 live births
female: 4.22 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 80.22 years
male: 76.86 years
female: 83.74 years (2006 est.)
Total fertility rate:
1.61 children born/woman (2006 est.)
HIV/AIDS - adult prevalence rate:
0.3% (2003 est.)
HIV/AIDS - people living with HIV/AIDS:
56,000 (2003 est.)
HIV/AIDS - deaths:
1,500 (2003 est.)
Nationality:
noun: Canadian(s)
adjective: Canadian
Ethnic groups:
British Isles origin 28%, French origin 23%, other European 15%,
Amerindian 2%, other, mostly Asian, African, Arab 6%, mixed
background 26%
Religions:
Roman Catholic 42.6%, Protestant 23.3% (including United Church
9.5%, Anglican 6.8%, Baptist 2.4%, Lutheran 2%), other Christian
4.4%, Muslim 1.9%, other and unspecified 11.8%, none 16% (2001
census)
Languages:
English (official) 59.3%, French (official) 23.2%, other 17.5%
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (2003 est.)
Government Canada
Country name:
conventional long form: none
conventional short form: Canada
Government type:
constitutional monarchy that is also a parliamentary democracy and
a federation
Capital:
name: Ottawa
geographic coordinates: 45 25 N, 75 40 W
time difference: UTC-5 (same time as Washington, DC during Standard
Time)
daylight saving time: +1hr, begins second Sunday in March; ends
first Sunday in November
note: Canada is divided into six time zones
Administrative divisions:
10 provinces and 3 territories*; Alberta, British Columbia,
Manitoba, New Brunswick, Newfoundland and Labrador, Northwest
Territories*, Nova Scotia, Nunavut*, Ontario, Prince Edward Island,
Quebec, Saskatchewan, Yukon Territory*
Independence:
1 July 1867 (union of British North American colonies); 11 December
1931 (independence recognized)
National holiday:
Canada Day, 1 July (1867)
Constitution:
made up of unwritten and written acts, customs, judicial decisions,
and traditions; the written part of the constitution consists of the
Constitution Act of 29 March 1867, which created a federation of
four provinces, and the Constitution Act of 17 April 1982, which
transferred formal control over the constitution from Britain to
Canada, and added a Canadian Charter of Rights and Freedoms as well
as procedures for constitutional amendments
Legal system:
based on English common law, except in Quebec, where civil law
system based on French law prevails; accepts compulsory ICJ
jurisdiction, with reservations
Suffrage:
18 years of age; universal
Executive branch:
chief of state: Queen ELIZABETH II (since 6 February 1952),
represented by Governor General Michaelle JEAN (since 27 September
2005)
head of government: Prime Minister Stephen HARPER (since 6 February
2006)
cabinet: Federal Ministry chosen by the prime minister usually from
among the members of his own party sitting in Parliament
elections: none; the monarchy is hereditary; governor general
appointed by the monarch on the advice of the prime minister for a
five-year term; following legislative elections, the leader of the
majority party or the leader of the majority coalition in the House
of Commons is automatically designated prime minister by the
governor general
Legislative branch:
bicameral Parliament or Parlement consists of the Senate or Senat
(members appointed by the governor general with the advice of the
prime minister and serve until reaching 75 years of age; its normal
limit is 105 senators) and the House of Commons or Chambre des
Communes (308 seats; members elected by direct, popular vote to
serve for up to five-year terms)
elections: House of Commons - last held 23 January 2006 (next to be
held in 2011)
election results: House of Commons - percent of vote by party -
Conservative Party 36.3%, Liberal Party 30.2%, New Democratic Party
17.5%, Bloc Quebecois 10.5%, Greens 4.5%, other 1%; seats by party -
Conservative Party 124, Liberal Party 102, New Democratic Party 29,
Bloc Quebecois 51, other 2; seats by party as of February 2007 -
Conservative Party 125, Liberal Party 100, New Democratic Party 29,
Bloc Quebecois 51, other 2
Judicial branch:
Supreme Court of Canada (judges are appointed by the prime minister
through the governor general); Federal Court of Canada; Federal
Court of Appeal; Provincial Courts (these are named variously Court
of Appeal, Court of Queens Bench, Superior Court, Supreme Court, and
Court of Justice)
Political parties and leaders:
Bloc Quebecois [Gilles DUCEPPE]; Conservative Party of Canada (a
merger of the Canadian Alliance and the Progressive Conservative
Party) [Stephen HARPER]; Green Party [Elizabeth MAY]; Liberal Party
[Stephane DION]; New Democratic Party [Jack LAYTON]
Political pressure groups and leaders:
NA
International organization participation:
ACCT, AfDB, APEC, Arctic Council, ARF, AsDB, ASEAN (dialogue
partner), Australia Group, BIS, C, CDB, CE (observer), EAPC, EBRD,
ESA (cooperating state), FAO, G-7, G-8, G-10, IADB, IAEA, IBRD,
ICAO, ICC, ICCt, ICRM, IDA, IEA, IFAD, IFC, IFRCS, IHO, ILO, IMF,
IMO, Interpol, IOC, IOM, IPU, ISO, ITU, ITUC, MIGA, MINUSTAH, MONUC,
NAFTA, NAM (guest), NATO, NEA, NSG, OAS, OECD, OIF, OPCW, OSCE,
Paris Club, PCA, PIF (partner), SECI (observer), UN, UNAMSIL,
UNCTAD, UNDOF, UNESCO, UNHCR, UNMOVIC, UNRWA, UNTSO, UNWTO, UPU,
WCL, WCO, WFTU, WHO, WIPO, WMO, WTO, ZC
Diplomatic representation in the US:
chief of mission: Ambassador Michael WILSON
chancery: 501 Pennsylvania Avenue NW, Washington, DC 20001
telephone: [1] (202) 682-1740
FAX: [1] (202) 682-7701
consulate(s) general: Atlanta, Boston, Buffalo, Chicago, Dallas,
Denver, Detroit, Los Angeles, Miami, Minneapolis, New York, Phoenix,
San Diego, San Francisco, Seattle, Tucson
consulate(s): Anchorage, Houston, Philadelphia, Princeton (New
Jersey), Raleigh, San Jose (California)
Diplomatic representation from the US:
chief of mission: Ambassador David H. WILKINS
embassy: 490 Sussex Drive, Ottawa, Ontario K1N 1G8
mailing address: P. O. Box 5000, Ogdensburgh, NY 13669-0430
telephone: [1] (613) 238-5335, 4470
FAX: [1] (613) 688-3082
consulate(s) general: Calgary, Halifax, Montreal, Quebec, Toronto,
Vancouver, Winnipeg
Flag description:
two vertical bands of red (hoist and fly side, half width), with
white square between them; an 11-pointed red maple leaf is centered
in the white square; the official colors of Canada are red and white
Economy Canada
Economy - overview:
As an affluent, high-tech industrial society in the trillion dollar
class, Canada resembles the US in its market-oriented economic
system, pattern of production, and affluent living standards. Since
World War II, the impressive growth of the manufacturing, mining,
and service sectors has transformed the nation from a largely rural
economy into one primarily industrial and urban. The 1989 US-Canada
Free Trade Agreement (FTA) and the 1994 North American Free Trade
Agreement (NAFTA) (which includes Mexico) touched off a dramatic
increase in trade and economic integration with the US. Given its
great natural resources, skilled labor force, and modern capital
plant, Canada enjoys solid economic prospects. Top-notch fiscal
management has produced consecutive balanced budgets since 1997,
although public debate continues over how to manage the rising cost
of the publicly funded healthcare system. Exports account for
roughly a third of GDP. Canada enjoys a substantial trade surplus
with its principal trading partner, the US, which absorbs about 85%
of Canadian exports. Canada is the US'' largest foreign supplier of
energy, including oil, gas, uranium, and electric power.
GDP (purchasing power parity):
$1.165 trillion (2006 est.)
GDP (official exchange rate):
$1.089 trillion (2006 est.)
GDP - real growth rate:
2.8% (2006 est.)
GDP - per capita (PPP):
$35,200 (2006 est.)
GDP - composition by sector:
agriculture: 2.3%
industry: 29.2%
services: 68.5% (2006 est.)
Labor force:
17.59 million (2006 est.)
Labor force - by occupation:
agriculture 2%, manufacturing 14%, construction 5%, services 75%,
other 3% (2004)
Unemployment rate:
6.4% (2006 est.)
Population below poverty line:
15.9%; note - this figure is the Low Income Cut-Off (LICO), a
calculation that results in higher figures than found in many
comparable economies; Canada does not have an official poverty line
(2003)
Household income or consumption by percentage share:
lowest 10%: 2.8%
highest 10%: 23.8% (1994)
Distribution of family income - Gini index:
33.1 (1998)
Inflation rate (consumer prices):
2% (2006 est.)
Investment (gross fixed):
21.3% of GDP (2006 est.)
Budget:
revenues: $183.5 billion
expenditures: $181.8 billion; including capital expenditures of $NA
(2005 est.)
Public debt:
65.4% of GDP (2006 est.)
Agriculture - products:
wheat, barley, oilseed, tobacco, fruits, vegetables; dairy
products; forest products; fish
Industries:
transportation equipment, chemicals, processed and unprocessed
minerals, food products, wood and paper products, fish products,
petroleum and natural gas
Industrial production growth rate:
0.7% (2006 est.)
Electricity - production:
573 billion kWh (2004)
Electricity - production by source:
fossil fuel: 28%
hydro: 57.9%
nuclear: 12.9%
other: 1.3% (2001)
Electricity - consumption:
522.4 billion kWh (2004)
Electricity - exports:
33.01 billion kWh (2004)
Electricity - imports:
22.48 billion kWh (2004)
Oil - production:
3.135 million bbl/day (2004)
Oil - consumption:
2.294 million bbl/day (2004)
Oil - exports:
1.6 million bbl/day (2004)
Oil - imports:
963,000 bbl/day (2004)
Oil - proved reserves:
178.9 billion bbl
note: includes oil sands (2004 est.)
Natural gas - production:
183.6 billion cu m (2004 est.)
Natural gas - consumption:
95.85 billion cu m (2004 est.)
Natural gas - exports:
104 billion cu m (2004 est.)
Natural gas - imports:
10.86 billion cu m (2004 est.)
Natural gas - proved reserves:
1.603 trillion cu m (1 January 2005 est.)
Current account balance:
$20.56 billion (2006 est.)
Exports:
$405 billion f.o.b. (2006 est.)
Exports - commodities:
motor vehicles and parts, industrial machinery, aircraft,
telecommunications equipment; chemicals, plastics, fertilizers; wood
pulp, timber, crude petroleum, natural gas, electricity, aluminum
Exports - partners:
US 84.2%, Japan 2.1%, UK 1.8% (2005)
Imports:
$353.2 billion f.o.b. (2006 est.)
Imports - commodities:
machinery and equipment, motor vehicles and parts, crude oil,
chemicals, electricity, durable consumer goods
Imports - partners:
US 56.7%, China 7.8%, Mexico 3.8% (2005)
Reserves of foreign exchange and gold:
$35.79 billion (August 2006 est.)
Debt - external:
$684.7 billion (30 June 2006)
Economic aid - donor:
ODA, $2.6 billion (2004)
Currency (code):
Canadian dollar (CAD)
Currency code:
CAD
Exchange rates:
Canadian dollars per US dollar - 1.13186 (2006), 1.2118 (2005),
1.301 (2004), 1.4011 (2003), 1.5693 (2002)
Fiscal year:
1 April - 31 March
Communications Canada
Telephones - main lines in use:
18.276 million (2005)
Telephones - mobile cellular:
16.6 million (2005)
Telephone system:
general assessment: excellent service provided by modern technology
domestic: domestic satellite system with about 300 earth stations
international: country code - 1-xxx; 5 coaxial submarine cables;
satellite earth stations - 5 Intelsat (4 Atlantic Ocean and 1
Pacific Ocean) and 2 Intersputnik (Atlantic Ocean region)
Radio broadcast stations:
AM 245, FM 582, shortwave 6 (2004)
Radios:
32.3 million (1997)
Television broadcast stations:
80 (plus many repeaters) (1997)
Televisions:
21.5 million (1997)
Internet country code:
.ca
Internet hosts:
3,934,223 (2006)
Internet Service Providers (ISPs):
760 (2000 est.)
Internet users:
21.9 million (2005)
Transportation Canada
Airports:
1,337 (2006)
Airports - with paved runways:
total: 509
over 3,047 m: 18
2,438 to 3,047 m: 15
1,524 to 2,437 m: 151
914 to 1,523 m: 248
under 914 m: 77 (2006)
Airports - with unpaved runways:
total: 828
1,524 to 2,437 m: 66
914 to 1,523 m: 355
under 914 m: 407 (2006)
Heliports:
12 (2006)
Pipelines:
crude and refined oil 23,564 km; liquid petroleum gas 74,980 km
(2005)
Railways:
total: 48,467 km
standard gauge: 48,467 km 1.435-m gauge (2005)
Roadways:
total: 1,042,300 km
paved: 415,600 km (including 17,000 km of expressways)
unpaved: 626,700 km (2005)
Waterways:
631 km
note: Saint Lawrence Seaway of 3,769 km, including the Saint
Lawrence River of 3,058 km, shared with United States (2003)
Merchant marine:
total: 173 ships (1000 GRT or over) 2,129,243 GRT/2,716,340 DWT
by type: bulk carrier 62, cargo 10, chemical tanker 9, container 2,
passenger 6, passenger/cargo 63, petroleum tanker 13, roll on/roll
off 8
foreign-owned: 7 (Germany 3, Netherlands 1, Norway 1, US 2)
registered in other countries: 111 (Australia 1, Bahamas 18,
Barbados 8, Cambodia 6, Cyprus 2, Denmark 1, Honduras 1, Hong Kong
28, Liberia 2, Malta 18, Marshall Islands 6, Panama 4, Russia 1,
Saint Vincent and the Grenadines 6, US 4, Vanuatu 5) (2006)
Ports and terminals:
Fraser River Port, Halifax, Montreal, Port Cartier, Quebec, Saint
John''s (Newfoundland), Sept Isles, Vancouver
Military Canada
Military branches:
Canadian Forces: Land Forces Command, Maritime Command, Air
Command, Canada Command (homeland security) (2006)
Military service age and obligation:
16 years of age for voluntary military service; women comprise
approximately 11% of Canada''s armed forces (2001)
Manpower available for military service:
males age 16-49: 8,216,510
females age 16-49: 8,034,939 (2005 est.)
Manpower fit for military service:
males age 16-49: 6,740,490
females age 16-49: 6,580,868 (2005 est.)
Manpower reaching military service age annually:
males age 18-49: 223,821
females age 16-49: 212,900 (2005 est.)
Military expenditures - dollar figure:
$9,801.7 million (2003)
Military expenditures - percent of GDP:
1.1% (2003)
Transnational Issues Canada
Disputes - international:
managed maritime boundary disputes with the US at Dixon Entrance,
Beaufort Sea, Strait of Juan de Fuca, and around the disputed
Machias Seal Island and North Rock; working toward greater
cooperation with US in monitoring people and commodities crossing
the border; uncontested sovereignty dispute with Denmark over Hans
Island in the Kennedy Channel between Ellesmere Island and Greenland
Illicit drugs:
illicit producer of cannabis for the domestic drug market and
export to US; use of hydroponics technology permits growers to plant
large quantities of high-quality marijuana indoors; transit point
for ecstasy entering the US market; vulnerable to narcotics money
laundering because of its mature financial services sector
This page was last updated on 8 February, 2007
======================================================================
@Cape Verde
Introduction Cape Verde','a441a45948eef59ec2b3de01a2f0b09ff913c78ed0dbf0fb3941a5edc8a096dd','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94afd2a07002a1be4606cc38bbec9fe3dc1c45b85e2bf2a96f0c8ea1c43abeb7',2007,'UA','Ukraine','environment',182,'Geography - note:
vegetation scanty
People Saint Pierre and Miquelon
Population:
7,026 (July 2006 est.)
Age structure:
0-14 years: 23.5% (male 843/female 807)
15-64 years: 65.7% (male 2,342/female 2,272)
65 years and over: 10.8% (male 348/female 414) (2006 est.)
Median age:
total: 34.1 years
male: 33.7 years
female: 34.5 years (2006 est.)
Population growth rate:
0.17% (2006 est.)
Birth rate:
13.52 births/1,000 population (2006 est.)
Death rate:
6.83 deaths/1,000 population (2006 est.)
Net migration rate:
-4.98 migrant(s)/1,000 population (2006 est.)
Sex ratio:
at birth: 1.07 male(s)/female
under 15 years: 1.05 male(s)/female
15-64 years: 1.03 male(s)/female
65 years and over: 0.84 male(s)/female
total population: 1.01 male(s)/female (2006 est.)
Infant mortality rate:
total: 7.38 deaths/1,000 live births
male: 8.46 deaths/1,000 live births
female: 6.24 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 78.61 years
male: 76.27 years
female: 81.06 years (2006 est.)
Total fertility rate:
2.01 children born/woman (2006 est.)
HIV/AIDS - adult prevalence rate:
NA
HIV/AIDS - people living with HIV/AIDS:
NA
HIV/AIDS - deaths:
NA
Nationality:
noun: Frenchman(men), Frenchwoman(women)
adjective: French
Ethnic groups:
Basques and Bretons (French fishermen)
Religions:
Roman Catholic 99%
Languages:
French (official)
Literacy:
definition: age 15 and over can read and write
total population: 99%
male: 99%
female: 99% (1982 est.)
Government Saint Pierre and Miquelon
Country name:
conventional long form: Territorial Collectivity of Saint Pierre
and Miquelon
conventional short form: Saint Pierre and Miquelon
local long form: Departement de Saint-Pierre et Miquelon
local short form: Saint-Pierre et Miquelon
Dependency status:
self-governing territorial overseas collectivity of France
Government type:
NA
Capital:
name: Saint-Pierre
geographic coordinates: 46 46 N, 56 11 W
time difference: UTC-3 (2 hours ahead of Washington, DC during
Standard Time)
daylight saving time: +1hr, begins second Sunday in March; ends
first Sunday in November
Administrative divisions:
none (territorial overseas collectivity of France); note - there
are no first-order administrative divisions as defined by the US
Government, but there are two communes - Saint Pierre, Miquelon at
the second order
Independence:
none (territorial collectivity of France; has been under French
control since 1763)
National holiday:
Bastille Day, 14 July (1789)
Constitution:
4 October 1958 (French Constitution)
Legal system:
French law with special adaptations for local conditions, such as
housing and taxation
Suffrage:
18 years of age; universal
Executive branch:
chief of state: President Jacques CHIRAC of France (since 17 May
1995), represented by Prefect Yves FAUQUEUR (since 28 August 2006)
head of government: President of the General Council Marc
PLANTAGENEST (since NA)
cabinet: NA
elections: French president elected by popular vote for a five-year
term; election last held, 21 April 2002 (first round) and 5 May 2002
(second round) (next to be held in 2007); prefect appointed by the
French president on the advice of the French Ministry of Interior;
president of the General Council is elected by the members of the
council
Legislative branch:
unicameral General Council or Conseil General (19 seats - 15 from
Saint Pierre and 4 from Miquelon; members are elected by popular
vote to serve six-year terms)
elections: elections last held 19 and 26 March 2000 (next to be held
in April 2006)
election results: percent of vote by party - NA%; seats by party -
PS 12, PRG 2, UDF-RPR 5
note: Saint Pierre and Miquelon elect 1 seat to the French Senate;
elections last held 26 September 2004 (next to be held in September
2013); results - percent of vote by party - NA; seats by party - UMP
1; Saint Pierre and Miquelon also elects 1 seat to the French
National Assembly; elections last held, first round - 9 June 2002,
second round - 16 June 2002 (next to be held NA 2007); results -
percent of vote by party - NA; seats by party - UDF 1
Judicial branch:
Superior Tribunal of Appeals or Tribunal Superieur d''Appel
Political parties and leaders:
Left Radical Party or PRG; Rassemblement pour la Republique or RPR
(now UMP); Socialist Party or PS; Union pour la Democratie Francaise
or UDF
Political pressure groups and leaders:
NA
International organization participation:
UPU, WFTU
Diplomatic representation in the US:
none (territorial overseas collectivity of France)
Diplomatic representation from the US:
none (territorial overseas collectivity of France)
Flag description:
a yellow sailing ship facing the hoist side rides on a dark blue
background with yellow wavy lines under the ship; on the hoist side,
a vertical band is divided into three parts: the top part (called
ikkurina) is red with a green diagonal cross extending to the
corners overlaid by a white cross dividing the rectangle into four
sections; the middle part has a white background with an ermine
pattern; the third part has a red background with two stylized
yellow lions outlined in black, one above the other; these three
heraldic arms represent settlement by colonists from the Basque
Country (top), Brittany, and Normandy; the flag of France is used
for official occasions
Economy Saint Pierre and Miquelon
Economy - overview:
The inhabitants have traditionally earned their livelihood by
fishing and by servicing fishing fleets operating off the coast of
Newfoundland. The economy has been declining, however, because of
disputes with Canada over fishing quotas and a steady decline in the
number of ships stopping at Saint Pierre. In 1992, an arbitration
panel awarded the islands an exclusive economic zone of 12,348 sq km
to settle a longstanding territorial dispute with Canada, although
it represents only 25% of what France had sought. The islands are
heavily subsidized by France to the great betterment of living
standards. The government hopes an expansion of tourism will boost
economic prospects. Recent test drilling for oil may pave the way
for development of the energy sector.
GDP (purchasing power parity):
$48.3 million
note: supplemented by annual payments from France of about $60
million (2003 est.)
GDP (official exchange rate):
NA
GDP - real growth rate:
NA%
GDP - per capita (PPP):
$7,000 (2001 est.)
GDP - composition by sector:
agriculture: NA%
industry: NA%
services: NA%
Labor force:
3,261 (1999)
Labor force - by occupation:
agriculture: 18%
industry: 41%
services: 41% (1996 est.)
Unemployment rate:
10.3% (1999)
Population below poverty line:
NA%
Household income or consumption by percentage share:
lowest 10%: NA%
highest 10%: NA%
Inflation rate (consumer prices):
2.1% (1991-96 average)
Budget:
revenues: $70 million
expenditures: $60 million; including capital expenditures of $24
million (1996 est.)
Agriculture - products:
vegetables; poultry, cattle, sheep, pigs; fish
Industries:
fish processing and supply base for fishing fleets; tourism
Industrial production growth rate:
NA%
Electricity - production:
50 million kWh (2004)
Electricity - production by source:
fossil fuel: 100%
hydro: 0%
nuclear: 0%
other: 0% (2001)
Electricity - consumption:
46.5 million kWh (2004)
Electricity - exports:
0 kWh (2004)
Electricity - imports:
0 kWh (2004)
Oil - production:
0 bbl/day (2004 est.)
Oil - consumption:
500 bbl/day (2004 est.)
Oil - exports:
NA bbl/day (2001)
Oil - imports:
NA bbl/day (2001)
Natural gas - production:
0 cu m (2004 est.)
Natural gas - consumption:
0 cu m (2004 est.)
Exports:
$5.5 million f.o.b. (2005 est.)
Exports - commodities:
fish and fish products, soybeans, animal feed, mollusks and
crustaceans, fox and mink pelts
Exports - partners:
Spain 33.6%, Belgium 21.8%, India 18.3%, France 9.4%, US 7.5% (2005)
Imports:
$68.2 million f.o.b. (2005 est.)
Imports - commodities:
meat, clothing, fuel, electrical equipment, machinery, building
materials
Imports - partners:
France 51.3%, Canada 31.8%, Belgium 4.1% (2005)
Debt - external:
$NA
Economic aid - recipient:
approximately $60 million in annual grants from France
Currency (code):
euro (EUR)
Currency code:
EUR
Exchange rates:
euros per US dollar - 0.79669 (2006), 0.8041 (2005), 0.8054 (2004),
0.886 (2003), 1.0626 (2002)
Fiscal year:
calendar year
Communications Saint Pierre and Miquelon
Telephones - main lines in use:
4,800 (2002)
Telephones - mobile cellular:
NA
Telephone system:
general assessment: adequate
domestic: NA
international: country code - 508; radiotelephone communication with
most countries in the world; 1 earth station in French domestic
satellite system
Radio broadcast stations:
AM 1, FM 4, shortwave 0 (1998)
Radios:
4,000 (1997)
Television broadcast stations:
0 (there are, however, two repeaters which rebroadcast programs
from France, Canada, and the US) (1997)
Televisions:
4,000 (1997)
Internet country code:
.pm
Internet hosts:
0 (2006)
Internet Service Providers (ISPs):
1 (2000)
Internet users:
NA
Transportation Saint Pierre and Miquelon
Airports:
2 (2006)
Airports - with paved runways:
total: 2
1,524 to 2,437 m: 1
914 to 1,523 m: 1 (2006)
Ports and terminals:
Saint-Pierre
Military Saint Pierre and Miquelon
Military - note:
defense is the responsibility of France
Transnational Issues Saint Pierre and Miquelon
Disputes - international:
none
This page was last updated on 8 February, 2007
======================================================================
@Saint Vincent and the Grenadines
Introduction Saint Vincent and the Grenadines
International Red Cross and Red Crescent Movement (ICRM): established
- 1928
aim - to promote worldwide humanitarian aid through the International
Committee of the Red Cross (ICRC) in wartime, and International
Federation of Red Cross and Red Crescent Societies (IFRCS; formerly
League of Red Cross and Red Crescent Societies or LORCS) in peacetime
National Societies - (182 countries); note - same as membership for
International Federation of Red Cross and Red Crescent Societies
(IFRCS)
International Telecommunication Union (ITU): established - 17 May 1865
set up as the International Telegraph Union; 9 December 1932 adopted
present name; effective - 1 January 1934; affiliated with the UN - 15
November 1947
aim - to deal with world telecommunications issues; a UN specialized
agency
members - (191) includes all UN member countries except East Timor,
Palau (190 total); plus Holy See
International Trade Union Confederation (ITUC): note - its
predecessors were the Confederation of Free Trade Unions (ICFTU) and
the World Confederation of Labor (WCL)
established - 3 November 2006
aim - to promote the trade union movement
members - (306 affiliated organizations in the following 153 countries)
Albania, Algeria, Angola, Antigua and Barbuda, Aruba, Argentina,
Australia, Austria, Azerbaijan, Bahrain, Bangladesh, Barbados, Belarus,
Belgium, Belize, Benin, Bermuda, Bonaire, Bosnia and Herzegovina,
Brazil, Bulgaria, Burkina Faso, Burundi, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, Colombia, Democratic Republic of
the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote
d''Ivoire, Croatia, Curacao, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, El Salvador, Eritrea, Estonia,
Ethiopia, Fiji, Finland, France, French Polynesia, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-
Bissau, Guyana, Haiti, Holy See, Honduras, Hong Kong, Hungary, Iceland,
India, Indonesia, Israel, Italy, Japan, Jordan, Kenya, Kiribati, South
Korea, Kuwait, Latvia, Liberia, Lithuania, Luxembourg, Macedonia,
Madagascar, Malawi, Malaysia, Mali, Malta, Mauritania, Mauritius,
Mexico, Moldova, Mongolia, Montenegro, Morocco, Mozambique, Nepal,
Netherlands, New Caledonia, NZ, Nicaragua, Niger, Nigeria, Norway,
Pakistan, Panama, Paraguay, Peru, Philippines, Poland, Portugal, Puerto
Rico, Romania, Russia, Rwanda, Saint Helena, Saint Lucia, Saint Vincent
and the Grenadines, Samoa, San Marino, Sao Tome and Principe, Senegal,
Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, South Africa,
Spain, Sri Lanka, Suriname, Swaziland, Sweden, Switzerland, Taiwan,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Uganda, Ukraine, UK, US, Vanuatu, Venezuela, Yemen, Zambia, Zimbabwe
Islamic Development Bank (IDB): established - 15 December 1973 by
declaration of intent; effective - 12 August 1974
aim - to promote Islamic economic aid and social development
members - (55 plus the Palestine Liberation Organization) Afghanistan,
Albania, Algeria, Azerbaijan, Bahrain, Bangladesh, Benin, Brunei,
Burkina Faso, Cameroon, Chad, Comoros, Cote d''Ivoire, Djibouti, Egypt,
Gabon, The Gambia, Guinea, Guinea-Bissau, Indonesia, Iran, Iraq,
Jordan, Kazakhstan, Kuwait, Kyrgyzstan, Lebanon, Libya, Malaysia,
Maldives, Mali, Mauritania, Morocco, Mozambique, Niger, Nigeria, Oman,
Pakistan, Qatar, Saudi Arabia, Senegal, Sierra Leone, Somalia, Sudan,
Suriname, Syria, Tajikistan, Togo, Tunisia, Turkey, Turkmenistan,
Uganda, UAE, Uzbekistan, Yemen, Palestine Liberation Organization
Latin American Economic System (LAES): note - also known as Sistema
Economico Latinoamericana (SELA)
established - 17 October 1975
aim - to promote economic and social development through regional
cooperation
members - (27) Argentina, Barbados, Belize, Bolivia, Brazil, Chile,
Colombia, Costa Rica, Cuba, Dominican Republic, Ecuador, El Salvador,
Grenada, Guatemala, Guyana, Haiti, Honduras, Jamaica, Mexico,
Nicaragua, Panama, Paraguay, Peru, Suriname, Trinidad and Tobago,
Uruguay, Venezuela
Latin American Integration Association (LAIA): note - also known as
Asociacion Latinoamericana de Integracion (ALADI)
established - 12 August 1980; effective - 18 March 1981
aim - to promote freer regional trade
members - (12) Argentina, Bolivia, Brazil, Chile, Colombia, Cuba,
Ecuador, Mexico, Paraguay, Peru, Uruguay, Venezuela
observers - (26) China, Corporacion Andina de Fomento, Costa Rica,
Dominican Republic, EC, El Salvador, Guatemala, Honduras, Inter-
American Development Bank, Inter-American Institute for Cooperation on
Agriculture, Italy, Japan, South Korea, Latin America Economic System,
Nicaragua, Organization of American States, Panama, Pan-American Health
Organization, Portugal, Romania, Russia, Spain, Switzerland, Ukraine,
United Nations Development Program, United Nations Economic Commission
for Latin America and the Caribbean
League of Arab States (LAS): note - also known as Arab League (AL)
established - 22 March 1945
aim - aim - to promote economic, social, political, and military
cooperation
members - (21 plus the Palestine Liberation Organization) Algeria,
Bahrain, Comoros, Djibouti, Egypt, Iraq, Jordan, Kuwait, Lebanon,
Libya, Mauritania, Morocco, Oman, Qatar, Saudi Arabia, Somalia, Sudan,
Syria, Tunisia, UAE, Yemen, Palestine Liberation Organization
least developed countries (LLDCs): that subgroup of the less developed
countries (LDCs) initially identified by the UN General Assembly in
1971 as having no significant economic growth, per capita GDPs normally
less than $1,000, and low literacy rates; also known as the undeveloped
countries; the 42 LLDCs are: Afghanistan, Bangladesh, Benin, Bhutan,
Botswana, Burkina Faso, Burma, Burundi, Cape Verde, Central African
Republic, Chad, Comoros, Djibouti, Equatorial Guinea, Eritrea,
Ethiopia, The Gambia, Guinea, Guinea-Bissau, Haiti, Kiribati, Laos,
Lesotho, Malawi, Maldives, Mali, Mauritania, Mozambique, Nepal, Niger,
Rwanda, Samoa, Sao Tome and Principe, Sierra Leone, Somalia, Sudan,
Tanzania, Togo, Tuvalu, Uganda, Vanuatu, Yemen
less developed countries (LDCs): the bottom group in the hierarchy of
developed countries (DCs), former USSR/Eastern Europe (former USSR/EE),
and less developed countries (LDCs); mainly countries and dependent
areas with low levels of output, living standards, and technology; per
capita GDPs are generally below $5,000 and often less than $1,500;
however, the group also includes a number of countries with high per
capita incomes, areas of advanced technology, and rapid rates of
growth; includes the advanced developing countries, developing
countries, Four Dragons (Four Tigers), least developed countries
(LLDCs), low-income countries, middle-income countries, newly
industrializing economies (NIEs), the South, Third World,
underdeveloped countries, undeveloped countries; the 172 LDCs are:
Afghanistan, Algeria, American Samoa, Angola, Anguilla, Antigua and
Barbuda, Argentina, Aruba, The Bahamas, Bahrain, Bangladesh, Barbados,
Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, British Virgin
Islands, Brunei, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape
Verde, Cayman Islands, Central African Republic, Chad, Chile, China,
Christmas Island, Cocos Islands, Colombia, Comoros, Democratic Republic
of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote
d''Ivoire, Cuba, Cyprus, Djibouti, Dominica, Dominican Republic,
Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Ethiopia,
Falkland Islands, Fiji, French Guiana, French Polynesia, Gabon, The
Gambia, Gaza Strip, Ghana, Gibraltar, Greenland, Grenada, Guadeloupe,
Guam, Guatemala, Guernsey, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hong Kong, India, Indonesia, Iran, Iraq, Isle of Man,
Jamaica, Jersey, Jordan, Kenya, Kiribati, North Korea, South Korea,
Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya, Macau, Madagascar,
Malawi, Malaysia, Maldives, Mali, Marshall Islands, Martinique,
Mauritania, Mauritius, Mayotte, Federated States of Micronesia,
Mongolia, Montserrat, Morocco, Mozambique, Namibia, Nauru, Nepal,
Netherlands Antilles, New Caledonia, Nicaragua, Niger, Nigeria, Niue,
Norfolk Island, Northern Mariana Islands, Oman, Palau, Pakistan,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Pitcairn
Islands, Puerto Rico, Qatar, Reunion, Rwanda, Saint Helena, Saint Kitts
and Nevis, Saint Lucia, Saint Pierre and Miquelon, Saint Vincent and
the Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal,
Seychelles, Sierra Leone, Singapore, Solomon Islands, Somalia, Sri
Lanka, Sudan, Suriname, Swaziland, Syria, Taiwan, Tanzania, Thailand,
Togo, Tokelau, Tonga, Trinidad and Tobago, Tunisia, Turks and Caicos
Islands, Tuvalu, UAE, Uganda, Uruguay, Vanuatu, Venezuela, Vietnam,
Virgin Islands, Wallis and Futuna, West Bank, Western Sahara, Yemen,
Zambia, Zimbabwe; note - similar to the new International Monetary Fund
(IMF) term "developing countries" which adds Malta, Mexico, South
Africa, and Turkey but omits in its recently published statistics
American Samoa, Anguilla, British Virgin Islands, Brunei, Cayman
Islands, Christmas Island, Cocos Islands, Cook Islands, Cuba, Eritrea,
Falkland Islands, French Guiana, French Polynesia, Gaza Strip,
Gibraltar, Greenland, Grenada, Guadeloupe, Guam, Guernsey, Isle of Man,
Jersey, North Korea, Macau, Martinique, Mayotte, Montserrat, Nauru, New
Caledonia, Niue, Norfolk Island, Northern Mariana Islands, Palau,
Pitcairn Islands, Puerto Rico, Reunion, Saint Helena, Saint Pierre and
Miquelon, Tokelau, Tonga, Turks and Caicos Islands, Tuvalu, Virgin
Islands, Wallis and Futuna, West Bank, Western Sahara
low-income countries: another term for those less developed countries
with below-average per capita GDPs; see less developed countries (LDCs)
middle-income countries: another term for those less developed
countries with above-average per capita GDPs; see less developed
countries (LDCs)
Multilateral Investment Guarantee Agency (MIGA): established - 12
April 1988
aim - encourages flow of foreign direct investment among member
countries by offering investment insurance, consultation, and
negotiation on conditions for foreign investment and technical
assistance; a UN specialized agency
members - (168) includes all UN member countries except Andorra,
Bhutan, Brunei, Burma, Comoros, Cuba, Djibouti, Iraq, Kirabati, North
Korea, Liberia, Liechtenstein, Marshall Islands, Mexico, Monaco,
Montenegro, Nauru, NZ, Niger, San Marino, Sao Tome and Principe,
Somalia, Tonga, Tuvalu
Near Abroad: Russian term for the 14 non-Russian successor states of
the USSR, in which 25 million ethnic Russians live and in which Moscow
has expressed a strong national security interest; the 14 countries are
Armenia, Azerbaijan, Belarus, Estonia, Georgia, Kazakhstan, Kyrgyzstan,
Latvia, Lithuania, Moldova, Tajikistan, Turkmenistan, Ukraine,
Bharat (local name for India 20 00 N 77 00 E
India)
Bhopal (city) India 23 16 N 77 24 E
Biafra (region) Nigeria 5 30 N 7 30 E
Big Diomede Island Russia 65 46 N 169 06 W
Bijagos, Arquipelago dos Guinea-Bissau 11 25 N 16 20 W
(island group)
Bikini Atoll Marshall Islands 11 35 N 165 23 E
Bilbao (city) Spain 43 15 N 2 58 W
Bioko (island) Equatorial Guinea 3 30 N 8 42 E
Biscay, Bay of Atlantic Ocean 44 00 N 4 00 W
Bishkek (capital) Kyrgyzstan 42 54 N 74 36 E
Bishop Rock United Kingdom 49 52 N 6 27 W
Bismarck Archipelago Papua New Guinea 5 00 S 150 00 E
(island group)
Bismarck Sea Pacific Ocean 4 00 S 148 00 E
Bissau (capital) Guinea-Bissau 11 51 N 15 35 W
Bjornoya (Bear Island) Svalbard 74 26 N 19 05 E
Black Forest (region) Germany 48 00 N 8 15 E
Black Rock (island) South Georgia and 53 39 S 41 48 W
the South Sandwich
Islands
Black Sea Atlantic Ocean 43 00 N 35 00 E
Bloemfontein (judicial South Africa 29 12 S 26 07 E
capital)
Bo Hai (gulf) Pacific Ocean 38 00 N 120 00 E
Boa Vista (island) Cape Verde 16 05 N 22 50 W
Bogota (capital) Colombia 4 36 N 74 05 W
Bohemia (region) Czech Republic 50 00 N 14 30 E
Bombay (city; see Mumbai) India 18 58 N 72 50 E
Bonaire (island) Netherlands 12 10 N 68 15 W
Antilles
Bonifacio, Strait of Atlantic Ocean 41 01 N 14 00 E
Bonin Islands Japan 27 00 N 142 10 E
Bonn (former capital) Germany 50 44 N 7 05 E
Bophuthatswana (region; South Africa 26 30 S 25 30 E
enclave)
Bora-Bora (island) French Polynesia 16 30 S 151 45 W
Bordeaux (city) France 44 50 N 0 34 W
Borneo (island) Brunei, Indonesia, 0 30 N 114 00 E','3ec661b867e8dfd8b2137139f4e5864fd3fc45b4b64da94d89e51c2f61cff0ef','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6bd4e5aeea2c1d265644143501f0251dea555cfbde9d8c091b73c6092896084b',2007,'CA','Canada','environment',594,'Cape Verde
The uninhabited islands were discovered and colonized by
the Portuguese in the 15th century; Cape Verde subsequently became a
trading center for African slaves and later an important coaling and
resupply stop for whaling and transatlantic shipping. Following
independence in 1975, and a tentative interest in unification with
Guinea-Bissau, a one-party system was established and maintained
until multi-party elections were held in 1990. Cape Verde continues
to exhibit one of Africa''s most stable democratic governments.
Repeated droughts during the second half of the 20th century caused
significant hardship and prompted heavy emigration. As a result,
Cape Verde''s expatriate population is greater than its domestic one.
Most Cape Verdeans have both African and Portuguese antecedents.','4c35c4f2feffe4dc04eae5190c09ac59b469691cd05fd0055d8fb42a8a245ce7','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6909bf0d6340ad3b11258250a862cb93ed694dedacdd584095e0bae392b2cd68',2007,'KY','Cayman Islands','environment',595,'The Cayman Islands were colonized from Jamaica by the
British during the 18th and 19th centuries, and were administered by
Jamaica after 1863. In 1959, the islands became a territory within
the Federation of the West Indies, but when the Federation dissolved
in 1962, the Cayman Islands chose to remain a British dependency.','a03779c641a06d589045f6d53f13f415240fcd8bb7c824e1f0f76583e0ef434e','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5dc56772d9cdcaaf2bb7de97759bcbea69cd3e54a3daa628362e20b5de353981',2007,'CF','Central African Republic','environment',596,'The former French colony of Ubangi-Shari
became the Central African Republic upon independence in 1960. After
three tumultuous decades of misrule - mostly by military governments
- civilian rule was established in 1993 and lasted for one decade.
President Ange-Felix PATASSE''s civilian government was plagued by
unrest, and in March 2003 he was deposed in a military coup led by
General Francois BOZIZE, who established a transitional government.
Though the government has the tacit support of civil society groups
and the main parties, a wide field of candidates contested the
municipal, legislative, and presidential elections held in March and
May of 2005 in which General BOZIZE was affirmed as president. The
government still does not fully control the countryside, where
pockets of lawlessness persist.','6ebe4697d9c3fec3110025995ea4820f9a1c305c12a81382fb269b6251d55fcd','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('611073c5f913dc5281cf66d18cf2abbdbfb114b69c48d162c03a4da6d1b310c1',2007,'TD','Chad','environment',597,'Chad, part of France''s African holdings until 1960, endured
three decades of civil warfare as well as invasions by Libya before
a semblance of peace was finally restored in 1990. The government
eventually drafted a democratic constitution, and held flawed
presidential elections in 1996 and 2001. In 1998, a rebellion broke
out in northern Chad, which sporadically flares up despite several
peace agreements between the government and the rebels. In 2005 new
rebel groups emerged in western Sudan and have made probing attacks
into eastern Chad. Power remains in the hands of an ethnic minority.
In June 2005, President Idriss DEBY held a referendum successfully
removing constitutional term limits.','7864b902eedd481e798f179b59b8d64629b8f698205493560422d264b497e942','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('717430da2af24bc791e87551aea966235d5d46283c81d2c2652d75c5c480388b',2007,'CL','Chile','environment',598,'Prior to the coming of the Spanish in the 16th century,
northern Chile was under Inca rule while Araucanian Indians
inhabited central and southern Chile; the latter were not completely
subjugated by Spain until the early 1880s. Although Chile declared
its independence in 1810, decisive victory over the Spanish was not
achieved until 1818. In the War of the Pacific (1879-84), Chile
defeated Peru and Bolivia and won its present northern lands. A
three-year-old Marxist government of Salvador ALLENDE was overthrown
in 1973 by a dictatorial military regime led by Augusto PINOCHET,
who ruled until a freely elected president was installed in 1990.
Sound economic policies, maintained consistently since the 1980s,
have contributed to steady growth and have helped secure the
country''s commitment to democratic and representative government.
Chile has increasingly assumed regional and international leadership
roles befitting its status as a stable, democratic nation.','e16f7ae47032a1f369883c4dbe81178359a81a559d6cc65615fabef01acfee94','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('678759aac3dd6cd00f5ac6db52a54429b48b91dfdefac663b6fa1405c121ae25',2007,'CN','China','environment',599,'For centuries China stood as a leading civilization, outpacing
the rest of the world in the arts and sciences, but in the 19th and
early 20th centuries, the country was beset by civil unrest, major
famines, military defeats, and foreign occupation. After World War
II, the Communists under MAO Zedong established an autocratic
socialist system that, while ensuring China''s sovereignty, imposed
strict controls over everyday life and cost the lives of tens of
millions of people. After 1978, his successor DENG Xiaoping and
other leaders focused on market-oriented economic development and by
2000 output had quadrupled. For much of the population, living
standards have improved dramatically and the room for personal
choice has expanded, yet political controls remain tight.
West African Economic and Monetary Union (WAEMU): note - also known as
Union Economique et Monetaire Ouest Africaine (UEMOA)
established - 1 August 1994
aim - to increase competitiveness of members'' economic markets; to
create a common market
members - (8) Benin, Burkina Faso, Cote d''Ivoire, Guinea-Bissau, Mali,
Niger, Senegal, Togo
Western European Union (WEU): established - 23 October 1954; effective
- 6 May 1955
aim - to provide mutual defense and to move toward political
unification
members - (10) Belgium, France, Germany, Greece, Italy, Luxembourg,
Netherlands, Portugal, Spain, UK
associate members - (6) Czech Republic, Hungary, Iceland, Norway,
Poland, Turkey
associate partners - (7) Bulgaria, Estonia, Latvia, Lithuania, Romania,
Slovakia, Slovenia
observers - (5) Austria, Denmark, Finland, Ireland, Sweden
World Bank Group: includes International Bank for Reconstruction and
Development (IBRD), International Development Association (IDA),
International Finance Corporation (IFC), and Multilateral Investment
Guarantee Agency (MIGA)
World Confederation of Labor (WCL): established - 19 June 1920 as the
International Federation of Christian Trade Unions (IFCTU), renamed 4
October 1968
aim - to promote the trade union movement
members - (105 national organizations) Antigua and Barbuda, Argentina,
Aruba, Austria, Bangladesh, Belgium, Belize, Benin, Bolivia, Brazil,
Bulgaria, Burkina Faso, Cameroon, Canada, Central African Republic,
Chad, Chile, Colombia, Democratic Republic of the Congo, Republic of
the Congo, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Czech Republic,
Denmark, Dominica, Dominican Republic, Ecuador, El Salvador, France,
French Guiana, Gabon, The Gambia, Ghana, Guadeloupe, Guatemala, Guinea,
Guyana, Haiti, Honduras, Hong Kong, Hungary, India, Indonesia, Iran,
Italy, Japan, Kazakhstan, South Korea, Liberia, Libya, Liechtenstein,
Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Malta,
Martinique, Mauritania, Mauritius, Mexico, Morocco, Namibia, Nepal,
Netherlands, Netherlands Antilles, Nicaragua, Niger, Pakistan, Panama,
Paraguay, Peru, Philippines, Poland, Portugal, Puerto Rico, Romania,
Rwanda, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and
Principe, Senegal, Serbia, Sierra Leone, Singapore, Slovakia, South
Africa, Spain, Sri Lanka, Suriname, Switzerland, Taiwan, Thailand,
Togo, Trinidad and Tobago, Ukraine, US, Uruguay, Venezuela, Vietnam,
Zambia, Zimbabwe
World Customs Organization (WCO): note - began as the Customs
Cooperation Council (CCC)
established - 15 December 1950
aim - to promote international cooperation in customs matters
members - (171) Afghanistan, Albania, Algeria, Andorra, Angola,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Benin, Bermuda,
Bhutan, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso,
Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of
the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia,
Cuba, Cyprus, Czech Republic, Denmark, Dominican Republic, East Timor,
Ecuador, Egypt, El Salvador, Eritrea, Estonia, Ethiopia, Fiji, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Guatemala,
Guinea, Guyana, Haiti, Honduras, Hong Kong, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia,
Lebanon, Lesotho, Liberia, Libya, Lithuania, Luxembourg, Macau,
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Mauritania, Mauritius, Mexico, Moldova, Mongolia, Montenegro, Morocco,
Mozambique, Namibia, Nepal, Netherlands, Netherlands Antilles, NZ,
Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Rwanda, Saint Lucia, Samoa, Saudi Arabia, Senegal, Serbia,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, South Africa,
Spain, Sri Lanka, Sudan, Swaziland, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
World Federation of Trade Unions (WFTU): established - 3 October 1945
aim - to promote the trade union movement
members - (125 and the Palestine Liberation Organization) Afghanistan,
Albania, Angola, Antigua and Barbuda, Argentina, Armenia, Australia,
Austria, Azerbaijan, Bahrain, Bangladesh, Barbados, Belarus, Benin,
Bolivia, Botswana, Brazil, Bulgaria, Burkina Faso, Cambodia, Cameroon,
Canada, Chile, Colombia, Democratic Republic of the Congo, Republic of
the Congo, Costa Rica, Cote d''Ivoire, Cuba, Cyprus, Czech Republic,
Djibouti, Dominican Republic, Ecuador, Egypt, El Salvador, Eritrea,
Ethiopia, Fiji, Finland, France, French Guiana, The Gambia, Ghana,
Greece, Guadeloupe, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hungary, India, Indonesia, Iran, Iraq, Jamaica, Japan,
Jordan, Kazakhstan, North Korea, Kuwait, Kyrgyzstan, Laos, Lebanon,
Lesotho, Liberia, Libya, Madagascar, Malawi, Malaysia, Mali,
Martinique, Mauritius, Mexico, Mozambique, Nepal, New Caledonia, NZ,
Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Peru,
Philippines, Poland, Portugal, Puerto Rico, Reunion, Romania, Russia,
Saint Lucia, Saint Pierre and Miquelon, Saint Vincent and the
Grenadines, Saudi Arabia, Senegal, Sierra Leone, Slovakia, Solomon
Islands, Somalia, South Africa, Sri Lanka, Sudan, Sweden, Syria,
Tajikistan, Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia,
Turkey, Turkmenistan, Uganda, Ukraine, Uruguay, Uzbekistan, Vanuatu,
Venezuela, Vietnam, Yemen, Zimbabwe, Palestine Liberation Organization
World Food Program (WFP): established - 24 November 1961
aim - to provide food aid in support of economic development or
disaster relief; an ECOSOC organization
members - (36) selected on a rotating basis from all regions
World Health Organization (WHO): established - 22 July 1946; effective
- 7 April 1948
aim - to deal with health matters worldwide; a UN specialized agency
members - (193) includes all UN member countries except Liechtenstein
(191 total); plus Cook Islands and Niue
World Intellectual Property Organization (WIPO): established - 14 July
1967; effective - 26 April 1970
aim - to furnish protection for literary, artistic, and scientific
works; a UN specialized agency
members - (184) includes all UN member countries except East Timor,
Kiribati, Marshall Islands, Federated States of Micronesia, Nauru,
Palau, Solomon Islands, Tuvalu, Vanuatu (182 total); plus Holy See
World Meteorological Organization (WMO): established - 11 October
1947; effective - 4 April 1951
aim - to sponsor meteorological cooperation; a UN specialized agency
members - (188) includes all UN member countries except Andorra, East
Timor, Equatorial Guinea, Grenada, Liechtenstein, Marshall Islands,
Montenegro, Nauru, Palau, Saint Kitts and Nevis, Saint Vincent and the
Grenadines, San Marino, Tuvalu (179 total); plus Aruba, British
Caribbean Territories, Cook Islands, French Polynesia, Hong Kong,
Macau, Netherlands Antilles, New Caledonia, and Niue
World Tourism Organization (UNWTO): established - 2 January 1975
aim - to promote tourism as a means of contributing to economic
development, international understanding, and peace
members - (150) Afghanistan, Albania, Algeria, Andorra, Angola,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Belarus, Benin, Bhutan, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic, Chad,
Chile, China, Colombia, Democratic Republic of the Congo, Republic of
the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Djibouti, Dominican Republic, East Timor, Ecuador, Egypt, El
Salvador, Equatorial Guinea, Eritrea, Ethiopia, Fiji, France, Gabon,
The Gambia, Georgia, Germany, Ghana, Greece, Guatemala, Guinea, Guinea-
Bissau, Haiti, Honduras, Hungary, India, Indonesia, Iran, Iraq, Israel,
Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea, South
Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Libya,
Lithuania, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali,
Malta, Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia,
Morocco, Mozambique, Namibia, Nepal, Netherlands, Nicaragua, Niger,
Nigeria, Oman, Pakistan, Panama, Papua New Guinea, Paraguay, Peru,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Rwanda, San
Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia,
Seychelles, Sierra Leone, Slovakia, Slovenia, South Africa, Spain, Sri
Lanka, Sudan, Swaziland, Switzerland, Syria, Tanzania, Thailand, Togo,
Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UK, Uruguay,
Uzbekistan, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
associate members - (7) Aruba, Flanders, Hong Kong, Macau, Madeira
Islands, Netherlands Antilles, Puerto Rico
observers - (1 plus Palestine Liberation Organization) Holy See,
Palestine Liberation Organization
World Trade Organization (WTO): note - succeeded General Agreement on
Tariff and Trade (GATT)
established - 15 April 1994; effective - 1 January 1995
aim - to provide a forum to resolve trade conflicts between members and
to carry on negotiations with the goal of further lowering and/or
eliminating tariffs and other trade barriers
members - (150) Albania, Angola, Antigua and Barbuda, Argentina,
Armenia, Australia, Austria, Bahrain, Bangladesh, Barbados, Belgium,
Belize, Benin, Bolivia, Botswana, Brazil, Brunei, Bulgaria, Burkina
Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Central African
Republic, Chad, Chile, China, Colombia, Democratic Republic of the
Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Estonia, EC, Fiji, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hong Kong,
Hungary, Iceland, India, Indonesia, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kenya, South Korea, Kuwait, Kyrgyzstan, Latvia, Lesotho,
Liechtenstein, Lithuania, Luxembourg, Macau, Macedonia, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Mauritania, Mauritius, Mexico,
Moldova, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands,
NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and
the Grenadines, Saudi Arabia, Senegal, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka,
Suriname, Swaziland, Sweden, Switzerland, Taiwan, Tanzania, Thailand,
Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda, UAE, UK, US,
Uruguay, Venezuela, Vietnam, Zambia, Zimbabwe
observers - (31) Afghanistan, Algeria, Andorra, Azerbaijan, The
Bahamas, Belarus, Bhutan, Bosnia and Herzegovina, Cape Verde,
Equatorial Guinea, Ethiopia, Holy See, Iran, Iraq, Kazakhstan, Laos,
Lebanon, Libya, Montenegro, Russia, Samoa, Sao Tome and Principe,
Serbia, Seychelles, Sudan, Tajikistan, Tonga, Ukraine, Uzbekistan,
Vanuatu, Yemen; note - with the exception of the Holy See, an observer
must start accession negotiations within five years of becoming
observers; Montenegro and Serbia each sent observers
Zangger Committee (ZC): established - early 1970s
aim - to establish guidelines for the export control provisions of the
Nonproliferation of Nuclear Weapons Treaty (NPT)
members - (36) Argentina, Australia, Austria, Belgium, Bulgaria,
Canada, China, Croatia, Czech Republic, Denmark, Finland, France,
Germany, Greece, Hungary, Ireland, Italy, Japan, South Korea,
Luxembourg, Netherlands, Norway, Poland, Portugal, Romania, Russia,
Slovakia, Slovenia, South Africa, Spain, Sweden, Switzerland, Turkey,
Ukraine, UK, US
observers - (1) EC
This page was last updated on 8 February, 2007
=====================================================================
Appendix C - Selected International Environmental Agreements
Air Pollution
see Convention on Long-Range Transboundary Air Pollution
Air Pollution-Nitrogen Oxides
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution Concerning the Control of Emissions of Nitrogen Oxides or
Their Transboundary Fluxes
Air Pollution-Persistent Organic Pollutants
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on Persistent Organic Pollutants
Air Pollution-Sulphur 85
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on the Reduction of Sulphur Emissions or Their
Transboundary Fluxes by at least 30%
Air Pollution-Sulphur 94
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on Further Reduction of Sulphur Emissions
Air Pollution-Volatile Organic Compounds
see Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution Concerning the Control of Emissions of Volatile Organic
Compounds or Their Transboundary Fluxes
Antarctic - Environmental Protocol
see Protocol on Environmental Protection to the Antarctic Treaty
Antarctic Treaty
opened for signature - 1 December 1959
entered into force - 23 June 1961
objective - to ensure that Antarctica is used for peaceful purposes
only (such as international cooperation in scientific research); to
defer the question of territorial claims asserted by some nations
and not recognized by others; to provide an international forum for
management of the region; applies to land and ice shelves south of
60 degrees south latitude
parties - (45) Argentina, Australia, Austria, Belgium, Brazil,
Bulgaria, Canada, Chile, China, Colombia, Cuba, Czech Republic,
Denmark, Ecuador, Estonia, Finland, France, Germany, Greece,
Guatemala, Hungary, India, Italy, Japan, North Korea, South Korea,
Netherlands, NZ, Norway, Papua New Guinea, Peru, Poland, Romania,
Russia, Slovakia, South Africa, Spain, Sweden, Switzerland, Turkey,
Ukraine, UK, US, Uruguay, Venezuela
Basel Convention on the Control of Transboundary Movements of
Hazardous Wastes and Their Disposal note - abbreviated as Hazardous
Wastes
opened for signature - 22 March 1989
entered into force - 5 May 1992
objective - to reduce transboundary movements of wastes subject to
the Convention to a minimum consistent with the environmentally
sound and efficient management of such wastes; to minimize the
amount and toxicity of wastes generated and ensure their
environmentally sound management as closely as possible to the
source of generation; and to assist LDCs in environmentally sound
management of the hazardous and other wastes they generate
parties - (149) Albania, Algeria, Andorra, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria,
Burkina Faso, Burundi, Cambodia, Cameroon, Canada, Cape Verde,
Central African Republic, Chad, Chile, China, Colombia, Comoros,
Democratic Republic of the Congo, Cook Islands, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Estonia, Ethiopia, EU, Finland, France,
The Gambia, Georgia, Germany, Greece, Guatemala, Guinea, Guyana,
Honduras, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel,
Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, Kiribati, South
Korea, Kuwait, Kyrgyzstan, Latvia, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi,
Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco,
Mongolia, Montenegro, Morocco, Mozambique, Namibia, Nauru, Nepal,
Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Saudi Arabia, Senegal,
Serbia, Seychelles, Singapore, Slovakia, Slovenia, South Africa,
Spain, Sri Lanka, Sudan, Swaziland, Sweden, Switzerland, Syria,
Tanzania, Thailand, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UAE, UK, Uruguay, Uzbekistan,
Venezuela, Vietnam, Yemen, Zambia
countries that have signed, but not yet ratified - (3) Afghanistan,
Haiti, US
Biodiversity
see Convention on Biological Diversity
Climate Change
see United Nations Framework Convention on Climate Change
Climate Change-Kyoto Protocol
see Kyoto Protocol to the United Nations Framework Convention on
Climate Change
Convention for the Conservation of Antarctic Seals note -
abbreviated as Antarctic Seals
opened for signature - 1 June 1972
entered into force - 11 March 1978
objective - to promote and achieve the protection, scientific study,
and rational use of Antarctic seals, and to maintain a satisfactory
balance within the ecological system of Antarctica
parties - (16) Argentina, Australia, Belgium, Brazil, Canada, Chile,
France, Germany, Italy, Japan, Norway, Poland, Russia, South Africa,
UK, US
countries that have signed, but not yet ratified - (1) NZ
Convention on Biological Diversity note - abbreviated as Biodiversity
opened for signature - 5 June 1992
entered into force - 29 December 1993
objective - to develop national strategies for the conservation and
sustainable use of biological diversity
parties - (182) Albania, Algeria, Andora, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Estonia, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea,
Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi,
Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands,
NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman, Pakistan, Palau,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino,
Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles,
Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands,
Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu,
Uganda, Ukraine, UAE, UK, Uruguay, Uzbekistan, Vanuatu, Venezuela,
Vietnam, Yemen, Zambia, Zimbabwe
countries that have signed, but not yet ratified - (6) Afghanistan,
Kuwait, Serbia, Thailand, Tuvalu, US
Convention on Fishing and Conservation of Living Resources of the
High Seas note - abbreviated as Marine Life Conservation
opened for signature - 29 April 1958
entered into force - 20 March 1966
objective - to solve through international cooperation the problems
involved in the conservation of living resources of the high seas,
considering that because of the development of modern technology
some of these resources are in danger of being overexploited
parties - (37) Australia, Belgium, Bosnia and Herzegovina, Burkina
Faso, Cambodia, Colombia, Denmark, Dominican Republic, Fiji,
Finland, France, Haiti, Indonesia, Jamaica, Kenya, Lesotho,
Madagascar, Malawi, Malaysia, Mauritius, Mexico, Netherlands,
Nigeria, Portugal, Senegal, Serbia, Sierra Leone, Solomon Islands,
South Africa, Spain, Switzerland, Thailand, Tonga, Trinidad and
Tobago, Uganda, UK, US, Venezuela
countries that have signed, but not yet ratified - (21) Afghanistan,
Argentina, Bolivia, Canada, Costa Rica, Cuba, Ghana, Iceland, Iran,
Ireland, Israel, Lebanon, Liberia, Nepal, NZ, Pakistan, Panama, Sri
Lanka, Tunisia, Uruguay
Convention on Long-Range Transboundary Air Pollution note -
abbreviated as Air Pollution
opened for signature - 13 November 1979
entered into force - 16 March 1983
objective - to protect the human environment against air pollution
and to gradually reduce and prevent air pollution, including
long-range transboundary air pollution
parties - (48) Armenia, Austria, Belarus, Belgium, Bosnia and
Herzegovina, Bulgaria, Canada, Croatia, Cyprus, Czech Republic,
Denmark, Estonia, EU, Finland, France, Georgia, Germany, Greece,
Hungary, Iceland, Ireland, Italy, Kazakhstan, Kyrgyzstan, Latvia,
Liechtenstein, Lithuania, Luxembourg, Macedonia, Malta, Moldova,
Monaco, Netherlands, Norway, Poland, Portugal, Romania, Russia,
Serbia, Slovakia, Slovenia, Spain, Sweden, Switzerland, Turkey,
Ukraine, UK, US
countries that have signed, but not yet ratified - (2) Holy See, San
Marino
Convention on Wetlands of International Importance Especially as
Waterfowl Habitat (Ramsar) note - abbreviated as Wetlands
opened for signature - 2 February 1971
entered into force - 21 December 1975
objective - to stem the progressive encroachment on and loss of
wetlands now and in the future, recognizing the fundamental
ecological functions of wetlands and their economic, cultural,
scientific, and recreational value
parties - (125) Albania, Algeria, Antigua and Barbuda, Argentina,
Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia,
Bosnia and Herzegovina, Botswana, Brazil, Bulgaria, Burkina Faso,
Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic
of the Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire,
Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Estonia,
Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana,
Greece, Guatemala, Guinea, Guinea-Bissau, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kazakstan, Kenya, South Korea, Kyrgyzstan, Latvia,
Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania,
Luxembourg, Macedonia, Madagascar, Malawi, Malay','0dfbf067f921a32c21d6f6a10d1a7a551c306dd02663bdc7c9706d2ce892b1a9','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d507d9ba2c17fcf50ebf57749fd13c89085b15bc012f299545497738c3c2127e',2007,'CN','China','environment',600,'sia, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nieria, Norway, Pakistan, Palau, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Romania,
Russia, Rwanda, Saint Lucia, Samoa, Sao Tome and Principe, Senegal,
Serbia, Seychelles, Sierra Leone, Slovakia, Slovenia, South Africa,
Spain, Sri Lanka, Sudan, Suriname, Sweden, Switzerland, Syria,
Tanzania, Tajikistan, Thailand, Togo, Trinidad and Tobago, Tunisia,
Turkey, Uganda, Ukraine, UK, US, Uruguay, Uzbekistan, Venezuela,
Vietnam, Zambia
Convention on the Conservation of Antarctic Marine Living Resources no
te - abbreviated as Antarctic-Marine Living Resources
opened for signature - 5 May 1980
entered into force - 7 April 1982
objective - to safeguard the environment and protect the integrity
of the ecosystem of the seas surrounding Antarctica, and to conserve
Antarctic marine living resources
parties - (31) Argentina, Australia, Belgium, Brazil, Bulgaria,
Canada, Chile, EU, Finland, France, Germany, Greece, India, Italy,
Japan, South Korea, Mauritius, Namibia, Netherlands, NZ, Norway,
Peru, Poland, Russia, South Africa, Spain, Sweden, Ukraine, UK, US,
Uruguay, Vanuatu
Convention on the International Trade in Endangered Species of Wild
Flora and Fauna (CITES) note - abbreviated as Endangered Species
opened for signature - 3 March 1973
entered into force - 1 July 1975
objective - to protect certain endangered species from
overexploitation by means of a system of import/export permits
parties - (156) Afghanistan, Algeria, Antigua and Barbuda,
Argentina, Australia, Austria, Azerbaijan, The Bahamas, Bangladesh,
Barbados, Belarus, Belgium, Belize, Benin, Bhutan, Bolivia,
Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Canada, Cape Verde, Central African Republic,
Chad, Chile, China, Colombia, Comoros, Democratic Republic of the
Congo, Republic of the Congo, Costa Rica, Cote d''Ivoire, Croatia,
Cuba, Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Honduras, Hungary, Iceland, India, Indonesia,
Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, South Korea, Kuwait, Latvia, Lesotho, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi,
Malaysia, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova,
Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands,
NZ, Nicaragua, Niger, Nigeria, Norway, Pakistan, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Palau, Saint Lucia,
Saint Vincent and the Grenadines, Sao Tome and Principe, Saudi
Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Somalia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Syria, Tanzania, Thailand,
Togo, Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine, UAE,
UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen,
Zambia, Zimbabwe
Convention on the Prevention of Marine Pollution by Dumping Wastes
and Other Matter (London Convention) note - abbreviated as Marine
Dumping
opened for signature - 29 December 1972
entered into force - 30 August 1975
objective - to control pollution of the sea by dumping and to
encourage regional agreements supplementary to the Convention; the
London Convention came into force in 1996
parties - (78) Afghanistan, Angola, Antigua and Barbuda, Argentina,
Australia, Azerbaijan, Barbados, Belarus, Belgium, Bolivia, Brazil,
Bulgaria, Canada, Cape Verde, Chile, China, Democratic Republic of
the Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus,
Denmark, Dominican Republic, Egypt, Equatorial Guinea, Finland,
France, Gabon, Germany, Greece, Guatemala, Haiti, Honduras, Hong
Kong (associate member), Hungary, Iceland, Iran, Ireland, Italy,
Jamaica, Japan, Jordan, Kenya, Kiribati, South Korea, Libya,
Luxembourg, Malta, Mexico, Monaco, Montenegro, Morocco, Nauru,
Netherlands, NZ, Nigeria, Norway, Oman, Pakistan, Panama, Papua New
Guinea, Philippines, Poland, Portugal, Russia, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Saudi Arabia,
Serbia, Seychelles, Slovenia, Solomon Islands, South Africa, Spain,
Suriname, Sweden, Switzerland, Tonga, Trinidad and Tobago, Tunisia,
Ukraine, UAE, UK, US, Vanuatu
associate members to the London Convention - (2) Faroe Islands, Macau
Convention on the Prohibition of Military or Any Other Hostile Use
of Environmental Modification Techniques note - abbreviated as
Environmental Modification
opened for signature - 10 December 1976
entered into force - 5 October 1978
objective - to prohibit the military or other hostile use of
environmental modification techniques in order to further world
peace and trust among nations
parties - (66) Afghanistan, Algeria, Antigua and Barbuda, Argentina,
Australia, Austria, Bangladesh, Belarus, Belgium, Benin, Brazil,
Brunei, Bulgaria, Canada, Cape Verde, Chile, Costa Rica, Cuba,
Cyprus, Czech Republic, Denmark, Dominica, Egypt, Finland, Germany,
Ghana, Greece, Guatemala, Hungary, India, Ireland, Italy, Japan,
North Korea, South Korea, Kuwait, Laos, Malawi, Mauritius, Mongolia,
Netherlands, NZ, Niger, Norway, Pakistan, Papua New Guinea, Poland,
Romania, Russia, Saint Lucia, Saint Vincent and the Grenadines, Sao
Tome and Principe, Slovakia, Solomon Islands, Spain, Sri Lanka,
Sweden, Switzerland, Tajikistan, Tunisia, Ukraine, UK, US, Uruguay,
Uzbekistan, Vietnam, Yemen
countries that have signed, but not yet ratified - (17) Bolivia,
Democratic Republic of the Congo, Ethiopia, Holy See, Iceland, Iran,
Iraq, Lebanon, Liberia, Luxembourg, Morocco, Nicaragua, Portugal,
Sierra Leone, Syria, Turkey, Uganda
Desertification
see United Nations Convention to Combat Desertification in those
Countries Experiencing Serious Drought and/or Desertification,
Particularly in Africa
Endangered Species
see Convention on the International Trade in Endangered Species of
Wild Flora and Fauna (CITES)
Environmental Modification
see Convention on the Prohibition of Military or Any Other Hostile
Use of Environmental Modification Techniques
Hazardous Wastes
see Basel Convention on the Control of Transboundary Movements of
Hazardous Wastes and Their Disposal
International Convention for the Regulation of Whaling note -
abbreviated as Whaling
opened for signature - 2 December 1946
entered into force - 10 November 1948
objective - to protect all species of whales from overhunting; to
establish a system of international regulation for the whale
fisheries to ensure proper conservation and development of whale
stocks; and to safeguard for future generations the great natural
resources represented by whale stocks
parties - (42) Antigua and Barbuda, Argentina, Australia, Austria,
Brazil, Chile, China, Costa Rica, Denmark, Dominica, Finland,
France, Germany, Grenada, Guinea, India, Ireland, Italy, Japan,
Kenya, South Korea, Mexico, Monaco, Morocco, Netherlands, NZ,
Norway, Oman, Panama, Peru, Russia, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, Senegal, Solomon Islands,
South Africa, Spain, Sweden, Switzerland, UK, US
International Tropical Timber Agreement, 1983 note - abbreviated as
Tropical Timber 83
opened for signature - 18 November 1983
entered into force - 1 April 1985; this agreement expired when the
International Tropical Timber Agreement, 1994, went into force
objective - to provide an effective framework for cooperation
between tropical timber producers and consumers and to encourage the
development of national policies aimed at sustainable utilization
and conservation of tropical forests and their genetic resources
parties - (54) Australia, Austria, Belgium, Bolivia, Brazil, Burma,
Cameroon, Canada, China, Colombia, Democratic Republic of the Congo,
Republic of the Congo, Cote d''Ivoire, Denmark, Ecuador, Egypt, EU,
Fiji, Finland, France, Gabon, Germany, Ghana, Greece, Guyana,
Honduras, India, Indonesia, Ireland, Italy, Japan, South Korea,
Liberia, Luxembourg, Malaysia, Nepal, Netherlands, NZ, Norway,
Panama, Papua New Guinea, Peru, Philippines, Portugal, Russia,
Spain, Sweden, Switzerland, Thailand, Togo, Trinidad and Tobago, UK,
US, Venezuela
International Tropical Timber Agreement, 1994 note - abbreviated as
Tropical Timber 94
opened for signature - 26 January 1994
entered into force - 1 January 1997
objective - to ensure that by the year 2000 exports of tropical
timber originate from sustainably managed sources; to establish a
fund to assist tropical timber producers in obtaining the resources
necessary to reach this objective
parties - (58) Australia, Austria, Belgium, Bolivia, Brazil, Burma,
Cambodia, Cameroon, Canada, Central African Republic, China,
Colombia, Democratic Republic of the Congo, Republic of the Congo,
Cote d''Ivoire, Denmark, Ecuador, Egypt, EU, Fiji, Finland, France,
Gabon, Germany, Ghana, Greece, Guyana, Honduras, India, Indonesia,
Ireland, Italy, Japan, South Korea, Liberia, Luxembourg, Malaysia,
Nepal, Netherlands, NZ, Norway, Panama, Papua New Guinea, Peru,
Philippines, Portugal, Spain, Suriname, Sweden, Switzerland,
Thailand, Togo, Trinidad and Tobago, UK, US, Uruguay, Vanuatu,
Venezuela
countries that have signed, but not yet ratified - (1) Ireland
Kyoto Protocol to the United Nations Framework Convention on Climate
Change note - abbreviated as Climate Change-Kyoto Protocol
opened for signature - 16 March 1998
entered into force - 23 February 2005
objective - to further reduce greenhouse gas emissions by enhancing
the national programs of developed countries aimed at this goal and
by establishing percentage reduction targets for the developed
countries
parties - (144) Algeria, Antigua and Barbuda, Argentina, Armenia,
Austria, Azerbaijan, The Bahamas, Bangladesh, Barbados, Belgium,
Belize, Benin, Bhutan, Bolivia, Botswana, Brazil, Bulgaria, Burma,
Burundi, Cambodia, Cameroon, Canada, Chile, China, Colombia, Cook
Island, Costa Rica, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Estonia, EU, Fiji, Finland, France, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guyana,
Honduras, Hungary, Iceland, India, Indonesia, Ireland, Israel,
Italy, Jamaica, Japan, Jordan, Kenya, Kiribati, South Korea,
Kyrgyzstan, Laos, Latvia, Lesotho, Liberia, Liechtenstein,
Lithuania, Luxembourg, Macedonia, Madagascar, Malawi, Malaysia,
Maldives, Mali, Malta, Marshall Islands, Mauritius, Mexico,
Federated States of Micronesia, Moldova, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, Saudi Arabia, Senegal, Seychelles, Slovakia,
Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka, Sudan,
Sweden, Switzerland, Tanzania, Thailand, Togo, Trinidad and Tobago,
Tunisia, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen
countries that have signed, but not yet ratified - (6) Australia,
Croatia, Kazakhstan, Monaco, US, Zambia
Law of the Sea
see United Nations Convention on the Law of the Sea (LOS)
Marine Dumping
see Convention on the Prevention of Marine Pollution by Dumping
Wastes and Other Matter (London Convention)
Marine Life Conservation
see Convention on Fishing and Conservation of Living Resources of
the High Seas
Montreal Protocol on Substances That Deplete the Ozone Layer note -
abbreviated as Ozone Layer Protection
opened for signature - 16 September 1987
entered into force - 1 January 1989
objective - to protect the ozone layer by controlling emissions of
substances that deplete it
parties - (183) Albania, Algeria, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, Azerbaijan, The Bahamas,
Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize, Benin,
Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Brunei, Bulgaria,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada, Cape
Verde, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo,
Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic,
Denmark, Djibouti, Dominica, Dominican Republic, Ecuador, Egypt, El
Salvador, Estonia, Ethiopia, EU, Fiji, Finland, France, Gabon, The
Gambia, Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya,
Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania,
Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali,
Malta, Marshall Islands, Mauritania, Mauritius, Mexico, Federated
States of Micronesia, Moldova, Monaco, Mongolia, Morocco,
Mozambique, Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua,
Niger, Nigeria, Norway, Oman, Pakistan, Palau, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Samoa, Sao Tome and Principe, Saudi
Arabia, Senegal, Serbia, Seychelles, Sierra Leone, Singapore,
Slovakia, Slovenia, Solomon Islands, Somalia, South Africa, Spain,
Sri Lanka, Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US,
Uruguay, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia,','754e246edb3172d663166d83f0f01bbdb0152f5bacb374cbb2ea5f8e8b369aaf','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7135346e1432178cb173862f61cca8b5ba7a6ba19832971031cb2b56d6634b6f',2007,'CX','Christmas Island','environment',601,'Named in 1643 for the day of its discovery, the
island was annexed and settlement began by the UK in 1888. Phosphate
mining began in the 1890s. The UK transferred sovereignty to
Australia in 1958. Almost two-thirds of the island has been declared
a national park.
Clipperton Island
This isolated island was named for John
CLIPPERTON, a pirate who made it his hideout early in the 18th
century. Annexed by France in 1855, it was seized by Mexico in 1897.
Arbitration eventually awarded the island to France, which took
possession in 1935.','3da2825344a9c8e79045198f4e0f0bebac960e9230b2b20eed9436fbb4fb05a9','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('423be16fd03955211d3722353d52e4fc764c2b356239e33ab42b51452a988365',2007,'CC','Cocos (Keeling) Islands','environment',602,'There are 27 coral islands in the group.
Captain William KEELING discovered the islands in 1609, but they
remained uninhabited until the 19th century. Annexed by the UK in
1857, they were transferred to the Australian Government in 1955.
The population on the two inhabited islands generally is split
between the ethnic Europeans on West Island and the ethnic Malays on
Home Island.','0e828a890afd753a03438ad1c94e44f9fde0130656cd1f44499f6eb56dda38b3','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0e28bbc7e4819587cb2be9e6da21704de5f610637f8cddfb60f47ea02120a419',2007,'CO','Colombia','environment',603,'Colombia was one of the three countries that emerged from
the collapse of Gran Colombia in 1830 (the others are Ecuador and
Venezuela). A 40-year conflict between government forces and
anti-government insurgent groups and illegal paramilitary groups -
both heavily funded by the drug trade - escalated during the 1990s.
The insurgents lack the military or popular support necessary to
overthrow the government, and violence has been decreasing since
about 2002, but insurgents continue attacks against civilians and
large swaths of the countryside are under guerrilla influence.
Paramilitary groups challenge the insurgents for control of
territory and the drug trade. Most paramilitary members have
demobilized since 2002 in an ongoing peace process, although their
commitment to ceasing illicit activity is unclear. The Colombian
Government has stepped up efforts to reassert government control
throughout the country, and now has a presence in every one of its
municipalities. However, neighboring countries worry about the
violence spilling over their borders.','c0be27b82901ffac3ec5f87c26353c4faaf536258d8b1827dc2c43d8f3c08100','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b406b0d5d03f8cbf17ab9bbcc680ab341eb22b46573fd7738e0b50acf580a6f3',2007,'KM','Comoros','environment',604,'Comoros has endured 19 coups or attempted coups since
gaining independence from France in 1975. In 1997, the islands of
Anjouan and Moheli declared independence from Comoros. In 1999,
military chief Col. AZALI seized power. He pledged to resolve the
secessionist crisis through a confederal arrangement named the 2000
Fomboni Accord. In December 2001, voters approved a new constitution
and presidential elections took place in the spring of 2002. Each
island in the archipelago elected its own president and a new union
president took office in May 2002.
Congo, Democratic Republic of the
Established as a Belgian colony in
1908, the Republic of the Congo gained its independence in 1960, but
its early years were marred by political and social instability.
Col. Joseph MOBUTU seized power and declared himself president in a
November 1965 coup. He subsequently changed his name - to MOBUTU
Sese Seko - as well as that of the country - to Zaire. MOBUTU
retained his position for 32 years through several subsequent sham
elections, as well as through the use of brutal force. Ethnic strife
and civil war, touched off by a massive inflow of refugees in 1994
from fighting in Rwanda and Burundi, led in May 1997 to the toppling
of the MOBUTU regime by a rebellion led by Laurent KABILA. He
renamed the country the Democratic Republic of the Congo (DRC), but
in August 1998 his regime was itself challenged by an insurrection
backed by Rwanda and Uganda. Troops from Angola, Chad, Namibia,
Sudan, and Zimbabwe intervened to support the Kinshasa regime. A
cease-fire was signed in July 1999 by the DRC, Congolese armed rebel
groups, Angola, Namibia, Rwanda, Uganda, and Zimbabwe but sporadic
fighting continued. Laurent KABILA was assassinated in January 2001
and his son, Joseph KABILA, was named head of state. In October
2002, the new president was successful in negotiating the withdrawal
of Rwandan forces occupying eastern Congo; two months later, the
Pretoria Accord was signed by all remaining warring parties to end
the fighting and establish a government of national unity. A
transitional government was set up in July 2003; with Joseph KABILA
as president and joined by four vice presidents representing the
former government, former rebel groups, and the political
opposition. The transitional government held a successful
constitutional referendum in December 2005 and elections for the
presidency, National Assembly, and provincial legislatures in 2006.
KABILA was inaugurated president in December 2006.
Congo, Republic of the
Upon independence in 1960, the former French
region of Middle Congo became the Republic of the Congo. A quarter
century of experimentation with Marxism was abandoned in 1990 and a
democratically elected government took office in 1992. A brief civil
war in 1997 restored former Marxist President Denis SASSOU-NGUESSO,
and ushered in a period of ethnic and political unrest.
Southern-based rebel groups agreed to a final peace accord in March
2003, but the calm is tenuous and refugees continue to present a
humanitarian crisis. The Republic of Congo was once one of Africa''s
largest petroleum producers, but with declining production it will
need to hope for new offshore oil finds to sustain its oil earnings
over the long term.','12e66b25862d4c173b2c9b91828516e702c144a5151c28585a112cf3155d8b6b','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa3d6246128f0043175af3297f6b19839330ff06a21888399f49aabb59269e2b',2007,'CK','Cook Islands','environment',605,'Named after Captain COOK, who sighted them in 1770, the
islands became a British protectorate in 1888. By 1900,
administrative control was transferred to New Zealand; in 1965
residents chose self-government in free association with New
Zealand. The emigration of skilled workers to New Zealand and
government deficits are continuing problems.
Coral Sea Islands
Scattered over more than three-quarters of a
million square kilometers of ocean, the Coral Sea Islands were
declared a territory of Australia in 1969. They are uninhabited
except for a small meteorological staff on the Willis Islets.
Automated weather stations, beacons, and a lighthouse occupy many
other islands and reefs.','5aa2f8440655f2502609a9d38c45fd91b29a4297d07e944369ca7852900160f9','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fe370e130482ae95ee1a2e40dedeca75d305277badf4a9c5293fd60f0c78bec',2007,'CR','Costa Rica','environment',606,'Although explored by the Spanish early in the 16th
century, initial attempts at colonizing Costa Rica proved
unsuccessful due to a combination of factors, including: disease
from mosquito-infested swamps, brutal heat, resistance by natives,
and pirate raids. It was not until 1563 that a permanent settlement
of Cartago was established in the cooler, fertile central highlands.
The area remained a colony for some two and a half centuries. In
1821, Costa Rica became one of several Central American provinces
that jointly declared their independence from Spain. Two years later
it joined the United Provinces of Central America, but this
federation disintegrated in 1838, at which time Costa Rica
proclaimed its sovereignty and independence. Since the late 19th
century, only two brief periods of violence have marred the
country''s democratic development. Although it still maintains a
large agricultural sector, Costa Rica has expanded its economy to
include strong technology and tourism industries. The standard of
living is relatively high. Land ownership is widespread.
Cote d''Ivoire
Close ties to France since independence in 1960, the
development of cocoa production for export, and foreign investment
made Cote d''Ivoire one of the most prosperous of the tropical
African states, but did not protect it from political turmoil. In
December 1999, a military coup - the first ever in Cote d''Ivoire''s
history - overthrew the government. Junta leader Robert GUEI
blatantly rigged elections held in late 2000 and declared himself
the winner. Popular protest forced him to step aside and brought
runner-up Laurent GBAGBO into power. Ivorian dissidents and
disaffected members of the military launched a failed coup attempt
in September 2002. Rebel forces claimed the northern half of the
country, and in January 2003 were granted ministerial positions in a
unity government under the auspices of the Linas-Marcoussis Peace
Accord. President GBAGBO and rebel forces resumed implementation of
the peace accord in December 2003 after a three-month stalemate, but
issues that sparked the civil war, such as land reform and grounds
for citizenship, remain unresolved. The central government has yet
to exert control over the northern regions and tensions remain high
between GBAGBO and opposition leaders. Several thousand French and
West African troops remain in Cote d''Ivoire to maintain peace and
facilitate the disarmament, demobilization, and rehabilitation
process.','08867ede056befa38d9e28f66ba5a4ec5e49e2dd92277e817d74b3b8c1d01dc7','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7df3d02d740338590b321fa40203f572a88e8415fcb40146838055f2f2866d69',2007,'HR','Croatia','environment',607,'The lands that today comprise Croatia were part of the
Austro-Hungarian Empire until the close of World War I. In 1918, the
Croats, Serbs, and Slovenes formed a kingdom known after 1929 as
Yugoslavia. Following World War II, Yugoslavia became a federal
independent Communist state under the strong hand of Marshal TITO.
Although Croatia declared its independence from Yugoslavia in 1991,
it took four years of sporadic, but often bitter, fighting before
occupying Serb armies were mostly cleared from Croatian lands. Under
UN supervision, the last Serb-held enclave in eastern Slavonia was
returned to Croatia in 1998.','1f45c542fd5c08a82c2885808128cf813b9efa09d18ad696b0c4743a9800303a','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e108fc0407bd89810d2196bd1db94692084f2a7e7c3f16f050f4f0ef6e655b01',2007,'CU','Cuba','environment',608,'The native Amerindian population of Cuba began to decline after
the European discovery of the island by Christopher COLUMBUS in 1492
and following its development as a Spanish colony during the next
several centuries. Large numbers of African slaves were imported to
work the coffee and sugar plantations, and Havana became the
launching point for the annual treasure fleets bound for Spain from
Mexico and Peru. Spanish rule, marked initially by neglect, became
increasingly repressive, provoking an independence movement and
occasional rebellions that were harshly suppressed. It was US
intervention during the Spanish-American War in 1898 that finally
overthrew Spanish rule. The subsequent Treaty of Paris established
Cuban independence, which was granted in 1902 after a three-year
transition period. Fidel CASTRO led a rebel army to victory in 1959;
his iron rule has held the regime together since then. Cuba''s
Communist revolution, with Soviet support, was exported throughout
Latin America and Africa during the 1960s, 1970s, and 1980s. The
country is now slowly recovering from a severe economic recession in
1990, following the withdrawal of former Soviet subsidies, worth $4
billion to $6 billion annually. Cuba portrays its difficulties as
the result of the US embargo in place since 1961. Illicit migration
to the US - using homemade rafts, alien smugglers, air flights, or
via the southwest border - is a continuing problem. The US Coast
Guard intercepted 2,810 individuals attempting to cross the Straits
of Florida in fiscal year 2006.','2e594fc04cf999197340581899541ac62610e30128816a648d26098be3b4ca46','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c9e700743a869b3290390a2d3378e14301f9e6b6e932a269cb71353c07638602',2007,'CY','Cyprus','environment',609,'A former British colony, Cyprus became independent in 1960
following years of resistance to British rule. Tensions between the
Greek Cypriot majority and Turkish Cypriot minority came to a head
in December 1963, when violence broke out in the capital of Nicosia.
Despite the deployment of UN peacekeepers in 1964, sporadic
intercommunal violence continued forcing most Turkish Cypriots into
enclaves throughout the island. In 1974, a Greek
Government-sponsored attempt to seize control of Cyprus was met by
military intervention from Turkey, which soon controlled more than a
third of the island. In 1983, the Turkish-held area declared itself
the "Turkish Republic of Northern Cyprus," but it is recognized only
by Turkey. The latest two-year round of UN-brokered talks - between
the leaders of the Greek Cypriot and Turkish Cypriot communities to
reach an agreement to reunite the divided island - ended when the
Greek Cypriots rejected the UN settlement plan in an April 2004
referendum. The entire island entered the EU on 1 May 2004, although
the EU acquis - the body of common rights and obligations - applies
only to the areas under direct Republic of Cyprus control, and is
suspended in the areas administered by Turkish Cypriots. However,
individual Turkish Cypriots able to document their eligibility for
Republic of Cyprus citizenship legally enjoy the same rights
accorded to other citizens of European Union states. Nicosia
continues to oppose EU efforts to establish direct trade and
economic links to north Cyprus as a way of encouraging the Turkish
Cypriot community to continue to support reunification.
Czech Republic
Following the First World War, the closely related
Czechs and Slovaks of the former Austro-Hungarian Empire merged to
form Czechoslovakia. During the interwar years, the new country''s
leaders were frequently preoccupied with meeting the demands of
other ethnic minorities within the republic, most notably the
Sudeten Germans and the Ruthenians (Ukrainians). After World War II,
a truncated Czechoslovakia fell within the Soviet sphere of
influence. In 1968, an invasion by Warsaw Pact troops ended the
efforts of the country''s leaders to liberalize Communist party rule
and create "socialism with a human face." Anti-Soviet demonstrations
the following year ushered in a period of harsh repression. With the
collapse of Soviet authority in 1989, Czechoslovakia regained its
freedom through a peaceful "Velvet Revolution." On 1 January 1993,
the country underwent a "velvet divorce" into its two national
components, the Czech Republic and Slovakia. The Czech Republic
joined NATO in 1999 and the European Union in 2004.','4a23ae34d858ddc7f63200a97682b776c509aa3cb30c706c831e6da1197c6a10','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b7051f56307d252b114e95321526f78e15c96f90a2126f02b19269b3a766f7d',2007,'DK','Denmark','environment',610,'Once the seat of Viking raiders and later a major north
European power, Denmark has evolved into a modern, prosperous nation
that is participating in the general political and economic
integration of Europe. It joined NATO in 1949 and the EEC (now the
EU) in 1973. However, the country has opted out of certain elements
of the European Union''s Maastricht Treaty, including the European
Economic and Monetary Union (EMU), European defense cooperation, and
issues concerning certain justice and home affairs.
Dhekelia
By terms of the 1960 Treaty of Establishment that created
the independent Republic of Cyprus, the UK retained full sovereignty
and jurisdiction over two areas of almost 254 square kilometers -
Akrotiri and Dhekelia. The larger of these is the Dhekelia Sovereign
Base Area, which is also referred to as the Eastern Sovereign Base
Area.','27006cb67b6c427cc87249989397da76c94a8d40c193c5086d934fb052b5280c','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01f84bae721b8176915c303d806ac5a00429557ebc10b6759c98b683ad6977e9',2007,'DJ','Djibouti','environment',611,'The French Territory of the Afars and the Issas became
Djibouti in 1977. Hassan Gouled APTIDON installed an authoritarian
one-party state and proceeded to serve as president until 1999.
Unrest among the Afars minority during the 1990s led to a civil war
that ended in 2001 following the conclusion of a peace accord
between Afar rebels and the Issa-dominated government. In 1999,
Djibouti''s first multi-party presidential elections resulted in the
election of Ismail Omar GUELLEH; he was re-elected to a second and
final term in 2005. Djibouti occupies a strategic geographic
location at the mouth of the Red Sea and serves as an important
transshipment location for goods entering and leaving the east
African highlands. The present leadership favors close ties to
France, which maintains a significant military presence in the
country, but is also developing stronger ties with the US. Djibouti
hosts the only US military base in sub-Saharan Africa and is a
front-line state in the global war on terrorism.','9556c99ca60e18b82ac01472270de59a15dd7181f73c898a2937a6dfbc0aed04','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e51b89246bde243216aabcbf617ea3bc4d9171425d9c18692c37650b894df207',2007,'DM','Dominica','environment',612,'Dominica was the last of the Caribbean islands to be
colonized by Europeans due chiefly to the fierce resistance of the
native Caribs. France ceded possession to Great Britain in 1763,
which made the island a colony in 1805. In 1980, two years after
independence, Dominica''s fortunes improved when a corrupt and
tyrannical administration was replaced by that of Mary Eugenia
CHARLES, the first female prime minister in the Caribbean, who
remained in office for 15 years. Some 3,000 Carib Indians still
living on Dominica are the only pre-Columbian population remaining
in the eastern Caribbean.','8fb48636b06fe26582435d226239ca79d44206ab565df0106508f4011372b0e8','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec2b0ebf6c7b15330e20bfb7bf04dd4cabb19b43f2f81cead06a913c50e5e509',2007,'DO','Dominican Republic','environment',613,'Explored and claimed by Christopher COLUMBUS on
his first voyage in 1492, the island of Hispaniola became a
springboard for Spanish conquest of the Caribbean and the American
mainland. In 1697, Spain recognized French dominion over the western
third of the island, which in 1804 became Haiti. The remainder of
the island, by then known as Santo Domingo, sought to gain its own
independence in 1821, but was conquered and ruled by the Haitians
for 22 years; it finally attained independence as the Dominican
Republic in 1844. In 1861, the Dominicans voluntarily returned to
the Spanish Empire, but two years later they launched a war that
restored independence in 1865. A legacy of unsettled, mostly
non-representative rule followed, capped by the dictatorship of
Rafael Leonidas TRUJILLO from 1930-1961. Juan BOSCH was elected
president in 1962, but was deposed in a military coup in 1963. In
1965, the United States led an intervention in the midst of a civil
war sparked by an uprising to restore BOSCH. In 1966, Joaquin
BALAGUER defeated BOSCH in an election to become president. BALAGUER
maintained a tight grip on power for most of the next 30 years when
international reaction to flawed elections forced him to curtail his
term in 1996. Since then, regular competitive elections have been
held in which opposition candidates have won the presidency. Former
President (1996-2000) Leonel FERNANDEZ Reyna won election to a
second term in 2004 following a constitutional amendment allowing
presidents to serve more than one term.
East Timor
The Portuguese began to trade with the island of Timor in
the early 16th century and colonized it in mid-century. Skirmishing
with the Dutch in the region eventually resulted in an 1859 treaty
in which Portugal ceded the western portion of the island. Imperial
Japan occupied East Timor from 1942 to 1945, but Portugal resumed
colonial authority after the Japanese defeat in World War II. East
Timor declared itself independent from Portugal on 28 November 1975
and was invaded and occupied by Indonesian forces nine days later.
It was incorporated into Indonesia in July 1976 as the province of
East Timor. An unsuccessful campaign of pacification followed over
the next two decades, during which an estimated 100,000 to 250,000
individuals lost their lives. On 30 August 1999, in a UN-supervised
popular referendum, an overwhelming majority of the people of East
Timor voted for independence from Indonesia. Between the referendum
and the arrival of a multinational peacekeeping force in late
September 1999, anti-independence Timorese militias - organized and
supported by the Indonesian military - commenced a large-scale,
scorched-earth campaign of retribution. The militias killed
approximately 1,400 Timorese and forcibly pushed 300,000 people into
West Timor as refugees. The majority of the country''s
infrastructure, including homes, irrigation systems, water supply
systems, and schools, and nearly 100% of the country''s electrical
grid were destroyed. On 20 September 1999 the Australian-led
peacekeeping troops of the International Force for East Timor
(INTERFET) deployed to the country and brought the violence to an
end. On 20 May 2002, East Timor was internationally recognized as an
independent state. In March of 2006, a military strike led to
violence and a near breakdown of law and order. Over 2,000
Australian, New Zealand, and Portuguese police and peacekeepers
deployed to East Timor in late May. Although many of the
peacekeepers were replaced by UN police officers, 850 Australian
soldiers remained as of 1 January 2007.','39ce179ce9f46fdbf9641bd1c7018661e962ab0725c1f7424b2037bc0cc2cd07','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('634cccbc7bb1cd0a1bf66a91f7a600f97b294e7dcde67bd814bb0df1b438510a',2007,'EC','Ecuador','environment',614,'What is now Ecuador formed part of the northern Inca Empire
until the Spanish conquest in 1533. Quito became a seat of Spanish
colonial government in 1563 and part of the Viceroyalty of New
Granada in 1717. The territories of the Viceroyalty - New Granada
(Colombia), Venezuela, and Quito - gained their independence by 1819
and formed a federation known as Gran Colombia. When Quito withdrew
in 1830, the traditional name was changed in favor of the "Republic
of the Equator." Between 1904 and 1942, Ecuador lost territories in
a series of conflicts with its neighbors. A border war with Peru
that flared in 1995 was resolved in 1999. Although Ecuador marked 25
years of civilian governance in 2004, the period has been marred by
political instability. Protests in Quito have contributed to the
mid-term ouster of Ecuador''s last three democratically elected
Presidents.','5a9bc84ecaf9873faf7e3b412b18fd52f44037d47f3b5973f8677042f7160b40','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72a228ca26dcdac07166af2de8855ec95f66ec7fca37341fc12474a7e2f08835',2007,'EG','Egypt','environment',615,'The regularity and richness of the annual Nile River flood,
coupled with semi-isolation provided by deserts to the east and
west, allowed for the development of one of the world''s great
civilizations. A unified kingdom arose circa 3200 B.C., and a series
of dynasties ruled in Egypt for the next three millennia. The last
native dynasty fell to the Persians in 341 B.C., who in turn were
replaced by the Greeks, Romans, and Byzantines. It was the Arabs who
introduced Islam and the Arabic language in the 7th century and who
ruled for the next six centuries. A local military caste, the
Mamluks took control about 1250 and continued to govern after the
conquest of Egypt by the Ottoman Turks in 1517. Following the
completion of the Suez Canal in 1869, Egypt became an important
world transportation hub, but also fell heavily into debt.
Ostensibly to protect its investments, Britain seized control of
Egypt''s government in 1882, but nominal allegiance to the Ottoman
Empire continued until 1914. Partially independent from the UK in
1922, Egypt acquired full sovereignty following World War II. The
completion of the Aswan High Dam in 1971 and the resultant Lake
Nasser have altered the time-honored place of the Nile River in the
agriculture and ecology of Egypt. A rapidly growing population (the
largest in the Arab world), limited arable land, and dependence on
the Nile all continue to overtax resources and stress society. The
government has struggled to ready the economy for the new millennium
through economic reform and massive investment in communications and
physical infrastructure.','17c7fd6a3171260e4286a9a8b4c352b918c1da1dc110d61111cd4dce3a8b500f','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fdcc9ec7a09f8de53a6553674d41d60154cc5ba0ac1c019957ce97e5171bae2d',2007,'SV','El Salvador','environment',616,'El Salvador achieved independence from Spain in 1821 and
from the Central American Federation in 1839. A 12-year civil war,
which cost about 75,000 lives, was brought to a close in 1992 when
the government and leftist rebels signed a treaty that provided for
military and political reforms.','8e33e3680de0cf02f8c43b7c56e1c7216b8adcfc704897c26c7f2a5a583a650a','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a3ee114a1c0d9259493d50e29d6ca1ea48ac92ba922ed66d1d66aba546377e5',2007,'GQ','Equatorial Guinea','environment',617,'Equatorial Guinea gained independence in 1968
after 190 years of Spanish rule. This tiny country, composed of a
mainland portion plus five inhabited islands, is one of the smallest
on the African continent. President Teodoro OBIANG NGUEMA MBASOGO
has ruled the country since 1979 when he seized power in a coup.
Although nominally a constitutional democracy since 1991, the 1996
and 2002 presidential elections - as well as the 1999 and 2004
legislative elections - were widely seen as flawed. The president
exerts almost total control over the political system and has
discouraged political opposition. Equatorial Guinea has experienced
rapid economic growth due to the discovery of large offshore oil
reserves, and in the last decade has become Sub-Saharan Africa''s
third largest oil exporter. Despite the country''s economic windfall
from oil production resulting in a massive increase in government
revenue in recent years, there have been few improvements in the
population''s living standards.','ba526b519f2ca394ab08490a6b0c19678f006ff96cf0e68c3fb7fdad0e99313f','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bca02adf837012c3f1cb598affeb1818d5a5cf30267b9691d0e70c42f24f5218',2007,'ER','Eritrea','environment',618,'Eritrea was awarded to Ethiopia in 1952 as part of a
federation. Ethiopia''s annexation of Eritrea as a province 10 years
later sparked a 30-year struggle for independence that ended in 1991
with Eritrean rebels defeating governmental forces; independence was
overwhelmingly approved in a 1993 referendum. A two-and-a-half-year
border war with Ethiopia that erupted in 1998 ended under UN
auspices in December 2000. Eritrea currently hosts a UN peacekeeping
operation that is monitoring a 25 km-wide Temporary Security Zone on
the border with Ethiopia. An international commission, organized to
resolve the border dispute, posted its findings in 2002 but final
demarcation is on hold due to Ethiopian objections.','b80560d73c2a50a6632ccaf6213e05bac6ae4e923360b18de7b467dfed55d9c9','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23f94735a52e238758cfdc44bca0234e6519957388c3824a46043a315a6d741e',2007,'EE','Estonia','environment',619,'After centuries of Danish, Swedish, German, and Russian
rule, Estonia attained independence in 1918. Forcibly incorporated
into the USSR in 1940 - an action never recognized by the US - it
regained its freedom in 1991, with the collapse of the Soviet Union.
Since the last Russian troops left in 1994, Estonia has been free to
promote economic and political ties with Western Europe. It joined
both NATO and the EU in the spring of 2004.','a20c22c4291aef8f67c8ac8c195f9d1da1a75838b360e0b05228717322fbff14','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ad211def7791ebf5617b56049b2e040a7216386928e96d56dbcdbc360605aa7',2007,'ET','Ethiopia','environment',620,'Unique among African countries, the ancient Ethiopian
monarchy maintained its freedom from colonial rule with the
exception of the 1936-41 Italian occupation during World War II. In
1974, a military junta, the Derg, deposed Emperor Haile SELASSIE
(who had ruled since 1930) and established a socialist state. Torn
by bloody coups, uprisings, wide-scale drought, and massive refugee
problems, the regime was finally toppled in 1991 by a coalition of
rebel forces, the Ethiopian People''s Revolutionary Democratic Front
(EPRDF). A constitution was adopted in 1994, and Ethiopia''s first
multiparty elections were held in 1995. A border war with Eritrea
late in the 1990''s ended with a peace treaty in December 2000. Final
demarcation of the boundary is currently on hold due to Ethiopian
objections to an international commission''s finding requiring it to
surrender territory considered sensitive to Ethiopia.
Europa Island
A French possession since 1897, the island is heavily
wooded; it is the site of a small military garrison that staffs a
weather station.
European Union
Following the two devastating World Wars of the first
half of the 20th century, a number of European leaders in the late
1940s became convinced that the only way to establish a lasting
peace was to unite the two chief belligerent nations - France and
Germany - both economically and politically. In 1950, the French
Foreign Minister Robert SCHUMAN proposed an eventual union of all
Europe, the first step of which would be the integration of the coal
and steel industries of Western Europe. The following year the
European Coal and Steel Community (ECSC) was set up when six
members, Belgium, France, West Germany, Italy, Luxembourg, and the
Netherlands, signed the Treaty of Paris. The ECSC was so successful
that within a few years the decision was made to integrate other
parts of the countries'' economies. In 1957, the Treaties of Rome
created the European Economic Community (EEC) and the European
Atomic Energy Community (Euratom), and the six member states
undertook to eliminate trade barriers among themselves by forming a
common market. In 1967, the institutions of all three communities
were formally merged into the European Community (EC), creating a
single Commission, a single Council of Ministers, and the European
Parliament. Members of the European Parliament were initially
selected by national parliaments, but in 1979 the first direct
elections were undertaken and they have been held every five years
since. In 1973, the first enlargement of the EC took place with the
addition of Denmark, Ireland, and the United Kingdom. The 1980s saw
further membership expansion with Greece joining in 1981 and Spain
and Portugal in 1986. The 1992 Treaty of Maastricht laid the basis
for further forms of cooperation in foreign and defense policy, in
judicial and internal affairs, and in the creation of an economic
and monetary union - including a common currency. This further
integration created the European Union (EU). In 1995, Austria,
Finland, and Sweden joined the EU, raising the membership total to
15. A new currency, the euro, was launched in world money markets on
1 January 1999; it became the unit of exchange for all of the EU
states except the United Kingdom, Sweden, and Denmark. In 2002,
citizens of the 12 euro-area countries began using the euro
banknotes and coins. Ten new countries joined the EU in 2004 -
Cyprus, the Czech Republic, Estonia, Hungary, Latvia, Lithuania,
Malta, Poland, Slovakia, and Slovenia - and in 2007 Bulgaria and
Romania joined, bringing the current membership to 27. In order to
ensure that the EU can continue to function efficiently with an
expanded membership, the Treaty of Nice (in force as of 1 February
2003) set forth rules streamlining the size and procedures of EU
institutions. An EU Constitutional Treaty, signed in Rome on 29
October 2004, gave member states two years to ratify the document
before it was scheduled to take effect on 1 November 2006. Referenda
held in France and the Netherlands in May-June 2005 rejected the
proposed constitution. This development set back the ratification
effort and left the longer-term political integration of the EU in
limbo.
Falkland Islands (Islas Malvinas)
Although first sighted by an
English navigator in 1592, the first landing (English) did not occur
until almost a century later in 1690, and the first settlement
(French) was not established until 1764. The colony was turned over
to Spain two years later and the islands have since been the subject
of a territorial dispute, first between Britain and Spain, then
between Britain and Argentina. The UK asserted its claim to the
islands by establishing a naval garrison there in 1833. Argentina
invaded the islands on 2 April 1982. The British responded with an
expeditionary force that landed seven weeks later and after fierce
fighting forced Argentine surrender on 14 June 1982.','7c43cfa19ca46f645bfceae10be3355d9ada817e5842d146f6d94bc54d95658b','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('59e1459ba048896b8c3002260046e7a89ec5e9c461d6b9e64a8e565143c0e5bc',2007,'FO','Faroe Islands','environment',621,'The population of the Faroe Islands is largely
descended from Viking settlers who arrived in the 9th century. The
islands have been connected politically to Denmark since the 14th
century. A high degree of self government was attained in 1948.','0b5e07365559068cb2144858c9fe77dd2d67ac61068619741f09fcf756875efd','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d2dd9494a6d39933cf54785015fbadbdae638bd1b942674a4f8755e6e8261b85',2007,'FJ','Fiji','environment',622,'Fiji became independent in 1970, after nearly a century as a
British colony. Democratic rule was interrupted by two military
coups in 1987, caused by concern over a government perceived as
dominated by the Indian community (descendants of contract laborers
brought to the islands by the British in the 19th century). The
coups and a 1990 constitution that cemented native Melanesian
control of Fiji, led to heavy Indian emigration; the population loss
resulted in economic difficulties, but ensured that Melanesians
became the majority. A new constitution enacted in 1997 was more
equitable. Free and peaceful elections in 1999 resulted in a
government led by an Indo-Fijian, but a civilian-led coup in May
2000 ushered in a prolonged period of political turmoil.
Parliamentary elections held in August 2001 provided Fiji with a
democratically elected government led by Prime Minister Laisenia
QARASE. Re-elected in May 2006, QARASE was ousted in a December 2006
military coup led by Commodore Voreqe BAINIMARAMA, who initially
appointed himself acting president. In January 2007, BAINIMARAMA was
appointed interim prime minister.','0d6146a977287c10925e16676f5d26b87731f80c903dadc4fbe08f4b66f1efd9','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1e5b578bc93df54899dc3fee0c7ccbe6aa0156712e4082f0bae202b44d1429bf',2007,'FI','Finland','environment',623,'Finland was a province and then a grand duchy under Sweden
from the 12th to the 19th centuries and an autonomous grand duchy of
Russia after 1809. It won its complete independence in 1917. During
World War II, it was able to successfully defend its freedom and
resist invasions by the Soviet Union - albeit with some loss of
territory. In the subsequent half century, the Finns made a
remarkable transformation from a farm/forest economy to a
diversified modern industrial economy; per capita income is now on
par with Western Europe. A member of the European Union since 1995,
Finland was the only Nordic state to join the euro system at its
initiation in January 1999.','ef218ed262c851f11b80ff336b53a9250504704502fb15f8db5f39273df87fea','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b5d712f9278b1f0c125917310427e78c6473eaa79444910242644d4466a31db',2007,'FR','France','environment',624,'Although ultimately a victor in World Wars I and II, France
suffered extensive losses in its empire, wealth, manpower, and rank
as a dominant nation-state. Nevertheless, France today is one of the
most modern countries in the world and is a leader among European
nations. Since 1958, it has constructed a presidential democracy
resistant to the instabilities experienced in earlier parliamentary
democracies. In recent years, its reconciliation and cooperation
with Germany have proved central to the economic integration of
Europe, including the introduction of a common exchange currency,
the euro, in January 1999. At present, France is at the forefront of
efforts to develop the EU''s military capabilities to supplement
progress toward an EU foreign policy.','d7dbcaa062d60a8d91c3c4526dd863a8bf48dbfbb09b866f6bf1b6b91815628c','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('60c7d66e652181282ed88d4be644a123449ffc6363c50f16ed2d4a936fbee8f7',2007,'PF','French Polynesia','environment',625,'The French annexed various Polynesian island groups
during the 19th century. In September 1995, France stirred up
widespread protests by resuming nuclear testing on the Mururoa atoll
after a three-year moratorium. The tests were suspended in January
1996. In recent years, French Polynesia''s autonomy has been
considerably expanded.
French Southern and Antarctic Lands
The Southern Lands consist of
two archipelagos, Iles Crozet and Iles Kerguelen, and two volcanic
islands, Ile Amsterdam and Ile Saint-Paul. They contain no permanent
inhabitants and are visited only by researchers studying the native
fauna. The Antarctic portion consists of "Adelie Land," a thin slice
of the Antarctic continent discovered and claimed by the French in
1840.','d3aef7a2134bee0cc37405aa0fb59eec13665c0806911ed1a6548b7d14dc948d','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7e90cc17b7ca4eb7c0541f1c23840f95a3f980aa40f3d88e481c3c12504a6391',2007,'GA','Gabon','environment',626,'Only two autocratic presidents have ruled Gabon since
independence from France in 1960. The current president of Gabon, El
Hadj Omar BONGO Ondimba - one of the longest-serving heads of state
in the world - has dominated the country''s political scene for
almost four decades. President BONGO introduced a nominal multiparty
system and a new constitution in the early 1990s. However,
allegations of electoral fraud during local elections in 2002-03 and
the presidential elections in 2005 have exposed the weaknesses of
formal political structures in Gabon. Gabon''s political opposition
remains weak, divided, and financially dependent on the current
regime. Despite political conditions, a small population, abundant
natural resources, and considerable foreign support have helped make
Gabon one of the more prosperous and stable African countries.
Gambia, The
The Gambia gained its independence from the UK in 1965.
Geographically surrounded by Senegal, it formed a short-lived
federation of Senegambia between 1982 and 1989. In 1991 the two
nations signed a friendship and cooperation treaty, but tensions
have flared up intermittently since then. Yahya A. J. J. JAMMEH led
a military coup in 1994 that overthrew the president and banned
political activity. A new constitution and presidential elections in
1996, followed by parliamentary balloting in 1997, completed a
nominal return to civilian rule. JAMMEH has been elected president
in all subsequent elections, including most recently in late 2006.
Gaza Strip
The Israel-PLO Declaration of Principles on Interim
Self-Government Arrangements (the DOP), signed in Washington in
September 1993, provided for a transitional period of Palestinian
interim self-government in the Gaza Strip and the West Bank. A
transfer of authority to the Palestinian Authority (PA) for the Gaza
Strip and Jericho took place pursuant to the Israel-PLO 4 May 1994
Cairo Agreement on the Gaza Strip and the Jericho Area and, in
additional areas of the West Bank, pursuant to the Israel-PLO 28
September 1995 Interim Agreement, the Israel-PLO 15 January 1997
Protocol Concerning Redeployment in Hebron, the Israel-PLO 23
October 1998 Wye River Memorandum, and the 4 September 1999 Sharm
el-Sheikh Agreement. Direct negotiations to determine the permanent
status of Gaza and the West Bank began in September 1999 after a
three-year hiatus, but were derailed by a second intifadah that
broke out a year later. In April 2003, the Quartet (US, EU, UN, and
Russia) presented a roadmap to a final settlement of the conflict by
2005 based on reciprocal steps by the two parties leading to two
states, Israel and a democratic Palestine. The proposed date for a
permanent status agreement has been postponed indefinitely due to
violence and accusations that both sides have not followed through
on their commitments. Following Palestinian leader Yasir ARAFAT''s
death in late 2004, Mahmud ABBAS was elected PA president in January
2005. A month later, Israel and the PA agreed to the Sharm el-Sheikh
Commitments in an effort to move the peace process forward. In
September 2005, Israel withdrew all its settlers and soldiers and
dismantled its military facilities in the Gaza Strip and four
northern West Bank settlements. Nonetheless, Israel controls
maritime, airspace, and most access to the Gaza Strip. A November
2005 PA-Israeli agreement authorized the reopening of the Rafah
border crossing between the Gaza Strip and Egypt under joint PA and
Egyptian control. In January 2006, the Islamic Resistance Movement,
HAMAS, won control of the Palestinian Legislative Council (PLC). The
international community has refused to accept the HAMAS-led
government because it does not recognize Israel, will not renounce
violence, and refuses to honor previous peace agreements between
Israel and the PA. Since March 2006, President Abbas has had little
success negotiating with HAMAS to present a political platform
acceptable to the international community so as to lift the economic
siege on Palestinians. The PLC was unable to convene in late 2006 as
a result of Israel''s detention of many HAMAS PLC members and
Israeli-imposed travel restrictions on other PLC members.','24dfdba6ac07e22db2a37ec3d2891a7e16c31c0e4dd3ce7f643736236ff34b73','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef61f7049280e14465a8af5fe8c3eeb85c448bb8f58c6c0a6fd0c89f55dbea9e',2007,'GE','Georgia','environment',627,'The region of present-day Georgia contained the ancient
kingdoms of Colchis and Kartli-Iberia. The area came under Roman
influence in the first centuries A.D. and Christianity became the
state religion in the 330s. Domination by Persians, Arabs, and Turks
was followed by a Georgian golden age (11th-13th centuries) that was
cut short by the Mongol invasion of 1236. Subsequently, the Ottoman
and Persian empires competed for influence in the region. Georgia
was absorbed into the Russian Empire in the 19th century.
Independent for three years (1918-1921) following the Russian
revolution, it was forcibly incorporated into the USSR until the
Soviet Union dissolved in 1991. An attempt by the incumbent Georgian
government to manipulate national legislative elections in November
2003 touched off widespread protests that led to the resignation of
Eduard SHEVARDNADZE, president since 1995. New elections in early
2004 swept Mikheil SAAKASHVILI into power along with his National
Movement Party. Progress on market reforms and democratization has
been made in the years since independence, but this progress has
been complicated by two civil conflicts in the breakaway regions of
Abkhazia and South Ossetia. These two territories remain outside the
control of the central government and are ruled by de facto,
unrecognized governments, supported by Russia. Russian-led
peacekeeping operations continue in both regions. The Georgian
Government put forward a new peace initiative for the peaceful
resolution of the status of South Ossetia in 2005.','ae6b52e7f459b1ae75a5403b403d8eaf6341cc66c7c394eb7d7cf2af84484f7c','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ce9ba3a13c93855cede95efd70a84ecb24b331e57013910c9dce51be639e048b',2007,'DE','Germany','environment',628,'As Europe''s largest economy and second most populous nation,
Germany is a key member of the continent''s economic, political, and
defense organizations. European power struggles immersed Germany in
two devastating World Wars in the first half of the 20th century and
left the country occupied by the victorious Allied powers of the US,
UK, France, and the Soviet Union in 1945. With the advent of the
Cold War, two German states were formed in 1949: the western Federal
Republic of Germany (FRG) and the eastern German Democratic Republic
(GDR). The democratic FRG embedded itself in key Western economic
and security organizations, the EC, which became the EU, and NATO,
while the Communist GDR was on the front line of the Soviet-led
Warsaw Pact. The decline of the USSR and the end of the Cold War
allowed for German unification in 1990. Since then, Germany has
expended considerable funds to bring Eastern productivity and wages
up to Western standards. In January 1999, Germany and 10 other EU
countries introduced a common European exchange currency, the euro.','c096e7cc3ea24581fa6d412a31a99a637a45b3a458ecdecd779fc2561e9587fa','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45eae80052537bffa234d43e1e93cebf40a2d4a56f9ce51f2d9705a516fbe882',2007,'GH','Ghana','environment',629,'Formed from the merger of the British colony of the Gold Coast
and the Togoland trust territory, Ghana in 1957 became the first
sub-Saharan country in colonial Africa to gain its independence. A
long series of coups resulted in the suspension of the constitution
in 1981 and a ban on political parties. A new constitution,
restoring multiparty politics, was approved in 1992. Lt. Jerry
RAWLINGS, head of state since 1981, won presidential elections in
1992 and 1996, but was constitutionally prevented from running for a
third term in 2000. John KUFUOR, who defeated former Vice President
John ATTA-MILLS in a free and fair election, succeeded him.','9fdc821a2e262e7f343701b79e14662d9249f699bf5f52a9e04065e7a495b45a','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('49a00a3f1c569052b3839a1924be0c4bb4e766cb457c172ff17c0c53f46f8125',2007,'GI','Gibraltar','environment',630,'Strategically important, Gibraltar was reluctantly ceded
to Great Britain by Spain in the 1713 Treaty of Utrecht; the British
garrison was formally declared a colony in 1830. In a referendum
held in 1967, Gibraltarians voted overwhelmingly to remain a British
dependency. Although the current 1969 Constitution for Gibraltar
states that the British government will never allow the people of
Gibraltar to pass under the sovereignty of another state against
their freely and democratically expressed wishes, a series of talks
were held by the UK and Spain between 1997 and 2002 on establishing
temporary joint sovereignty over Gibraltar. In response to these
talks, the Gibraltarian Government set up a referendum in late 2002
in which a majority of the citizens voted overwhelmingly against any
sharing of sovereignty with Spain. Since the referendum, tripartite
talks have been held with Spain, the UK, and Gibraltar, and in
September 2006 a three-way agreement was signed. Spain agreed to
allow airlines other than British to serve Gibraltar, to speed up
customs procedures, and to add more telephone lines into Gibraltar.
Britain agreed to pay pensions to Spaniards who had been employed in
Gibraltar before the border closed in 1969. Spain will be allowed to
open a cultural institute from which the Spanish flag will fly.
Glorioso Islands
A French possession since 1892, the Glorioso
Islands are composed of two lushly vegetated coral islands (Ile
Glorieuse and Ile du Lys) and three rock islets. A military garrison
operates a weather and radio station on Ile Glorieuse.','ef0cde1c392d8f38ea597a31e38d3bb22059da46ca6dc2459484a366540f3365','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5a67dee8ab998b1f83fc9d5b7b39411540c2a165e512a36e9599143fd36ba572',2007,'GR','Greece','environment',631,'Greece achieved independence from the Ottoman Empire in 1829.
During the second half of the 19th century and the first half of the
20th century, it gradually added neighboring islands and
territories, most with Greek-speaking populations. In World War II,
Greece was first invaded by Italy (1940) and subsequently occupied
by Germany (1941-44); fighting endured in a protracted civil war
between supporters of the king and Communist rebels. Following the
latter''s defeat in 1949, Greece joined NATO in 1952. A military
dictatorship, which in 1967 suspended many political liberties and
forced the king to flee the country, lasted seven years. The 1974
democratic elections and a referendum created a parliamentary
republic and abolished the monarchy. In 1981 Greece joined the EC
(now the EU); it became the 12th member of the euro zone in 2001.','92e99ab3ccc617b5efe1dc7e53033f40ec690e8aa3dc994d682bfd502e657ba0','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('446c75048d229704338ce24953dd1231675056e641bb914400b692f35fecc363',2007,'GL','Greenland','environment',632,'Greenland, the world''s largest island, is about 81%
ice-capped. Vikings reached the island in the 10th century from
Iceland; Danish colonization began in the 18th century, and
Greenland was made an integral part of Denmark in 1953. It joined
the European Community (now the EU) with Denmark in 1973, but
withdrew in 1985 over a dispute centered on stringent fishing
quotas. Greenland was granted self-government in 1979 by the Danish
parliament; the law went into effect the following year. Denmark
continues to exercise control of Greenland''s foreign affairs in
consultation with Greenland''s Home Rule Government.','d00217b5fd8c77e25d27808e9d1f4cfdfe65dd4c6758aee51a087eda4ad696b0','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7756198a1696fccb7757717f54b56a625105c49ef9a3f0d2a60bce5116c6e68d',2007,'GD','Grenada','environment',633,'Carib Indians inhabited Grenada when COLUMBUS discovered the
island in 1498, but it remained uncolonized for more than a century.
The French settled Grenada in the 17th century, established sugar
estates, and imported large numbers of African slaves. Britain took
the island in 1762 and vigorously expanded sugar production. In the
19th century, cacao eventually surpassed sugar as the main export
crop; in the 20th century, nutmeg became the leading export. In
1967, Britain gave Grenada autonomy over its internal affairs. Full
independence was attained in 1974 making Grenada one of the smallest
independent countries in the Western Hemisphere. Grenada was seized
by a Marxist military council on 19 October 1983. Six days later the
island was invaded by US forces and those of six other Caribbean
nations, which quickly captured the ringleaders and their hundreds
of Cuban advisers. Free elections were reinstituted the following
year and have continued since that time. Hurricane Ivan struck
Grenada in September of 2004 causing severe damage.','4ec255bfd0628535dad8d11feca9f1ec7d11d28e52fddfbb267f5dbab27d6195','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fb1fe3008e0fd09e84cf02400e0ed733cb16194f054387a1507644ea071f396',2007,'GU','Guam','environment',634,'Guam was ceded to the US by Spain in 1898. Captured by the
Japanese in 1941, it was retaken by the US three years later. The
military installation on the island is one of the most strategically
important US bases in the Pacific.','da7db403deb738419725b54a45cfd64321f41f1bc7e75103a33f124587538047','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('721ee85d8c933571e63895ed593ffe4ba2ecf08fbe0dd76b9642c6b319dcd5ff',2007,'GT','Guatemala','environment',635,'The Maya civilization flourished in Guatemala and
surrounding regions during the first millennium A.D. After almost
three centuries as a Spanish colony, Guatemala won its independence
in 1821. During the second half of the 20th century, it experienced
a variety of military and civilian governments, as well as a 36-year
guerrilla war. In 1996, the government signed a peace agreement
formally ending the conflict, which had left more than 100,000
people dead and had created some 1 million refugees.','94724c3a49200ae9321b3b4e8301e265c13f21edb16712b15c2eedf133e301b9','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4f6d588f119991c0307215b3a606cfd801cfae8aaa7ccb6703a2911606cb1be5',2007,'GG','Guernsey','environment',636,'Guernsey and the other Channel Islands represent the last
remnants of the medieval Dukedom of Normandy, which held sway in
both France and England. The islands were the only British soil
occupied by German troops in World War II. Guernsey is a British
crown dependency, but is not part of the UK. However, the UK
Government is constitutionally responsible for defense and
international representation.','d1b3c85b0a9eafc72b4049a5954646a2bf14194f099b100169a643346326d66d','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5271b3dea36575250b7b8f1a696acd3f73c9042ebb3433199ca6a8e1652993f',2007,'GN','Guinea','environment',637,'Guinea has had only two presidents since gaining its
independence from France in 1958. Lansana CONTE came to power in
1984 when the military seized the government after the death of the
first president, Sekou TOURE. Guinea did not hold democratic
elections until 1993 when Gen. CONTE (head of the military
government) was elected president of the civilian government. He was
reelected in 1998 and again in 2003. Unrest in Sierra Leone and
Liberia has spilled over into Guinea on several occasions over the
past decade, threatening stability and creating humanitarian
emergencies. In 2006, declining economic conditions prompted two
massive strikes that sparked urban unrest in many Guinean cities.','87c5141ff9d9ea56144d3cf6b2e3d302aa7637c71a836035f32e290a059db576','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('74a4e99154ee6e64d557fa76ef9a8cba0b2aafdfe2defc582b313bb2846ed0db',2007,'GW','Guinea-Bissau','environment',638,'Since independence from Portugal in 1974,
Guinea-Bissau has experienced considerable political and military
upheaval. In 1980, a military coup established authoritarian
dictator Joao Bernardo ''Nino'' VIEIRA as president. Despite setting a
path to a market economy and multiparty system, VIEIRA''s regime was
characterized by the suppression of political opposition and the
purging of political rivals. Several coup attempts through the 1980s
and early 1990s failed to unseat him. In 1994 VIEIRA was elected
president in the country''s first free elections. A military mutiny
and resulting civil war in 1998 eventually led to VIEIRA''s ouster in
May 1999. In February 2000, a transitional government turned over
power to opposition leader Kumba YALA, after he was elected
president in transparent polling. In September 2003, after only
three years in office, YALA was ousted by the military in a
bloodless coup, and businessman Henrique ROSA was sworn in as
interim president. In 2005, former President VIEIRA was re-elected
president pledging to pursue economic development and national
reconciliation.','53e611e5378bcb4b290ac74cc361d009872a0d23cff8eec243367caac04eba8b','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a17f461c81cdff6857e6a7474d830f74485cdc088afe44915713d852d3d9448',2007,'GY','Guyana','environment',639,'Originally a Dutch colony in the 17th century, by 1815 Guyana
had become a British possession. The abolition of slavery led to
black settlement of urban areas and the importation of indentured
servants from India to work the sugar plantations. This
ethnocultural divide has persisted and has led to turbulent
politics. Guyana achieved independence from the UK in 1966, and
since then it has been ruled mostly by socialist-oriented
governments. In 1992, Cheddi JAGAN was elected president in what is
considered the country''s first free and fair election since
independence. After his death five years later, his wife, Jane
JAGAN, became president but resigned in 1999 due to poor health. Her
successor, Bharrat JAGDEO, was reelected in 2001 and again in 2006.','356df44732f65a5f5e3babebf655f33ac1d9f985c62b9b90dcc4db71f2be6d61','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a51a2e1264d22c516b21f2779db7eea0a0a6ee19c6b33c02f020b2f929d65f9a',2007,'HT','Haiti','environment',640,'The native Taino Amerindians - who inhabited the island of
Hispaniola when it was discovered by COLUMBUS in 1492 - were
virtually annihilated by Spanish settlers within 25 years. In the
early 17th century, the French established a presence on Hispaniola,
and in 1697, Spain ceded to the French the western third of the
island, which later became Haiti. The French colony, based on
forestry and sugar-related industries, became one of the wealthiest
in the Caribbean, but only through the heavy importation of African
slaves and considerable environmental degradation. In the late 18th
century, Haiti''s nearly half million slaves revolted under Toussaint
L''OUVERTURE. After a prolonged struggle, Haiti became the first
black republic to declare its independence in 1804. The poorest
country in the Western Hemisphere, Haiti has been plagued by
political violence for most of its history. After an armed rebellion
led to the departure of President Jean-Betrand ARISTIDE in February
2004, an interim government took office to organize new elections
under the auspices of the United Nations Stabilization Mission in
Haiti (MINUSTAH). Continued violence and technical delays prompted
repeated postponements, but Haiti finally did inaugurate a
democratically elected president and parliament in May of 2006.','ac49578a959533d456c7de79028209956c5c9e60e6e3419532e01f8d1eccf837','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de61bf6751d39d0635f053bc0c77a90cfd10fb526618dfbaee21965074d15590',2007,'HM','Heard Island and McDonald Islands','environment',641,'These uninhabited, barren,
sub-Antarctic islands were transferred from the UK to Australia in
1947. Populated by large numbers of seal and bird species, the
islands have been designated a nature preserve.
Holy See (Vatican City)
Popes in their secular role ruled portions
of the Italian peninsula for more than a thousand years until the
mid 19th century, when many of the Papal States were seized by the
newly united Kingdom of Italy. In 1870, the pope''s holdings were
further circumscribed when Rome itself was annexed. Disputes between
a series of "prisoner" popes and Italy were resolved in 1929 by
three Lateran Treaties, which established the independent state of
Vatican City and granted Roman Catholicism special status in Italy.
In 1984, a concordat between the Holy See and Italy modified certain
of the earlier treaty provisions, including the primacy of Roman
Catholicism as the Italian state religion. Present concerns of the
Holy See include religious freedom, international development, the
Middle East, terrorism, interreligious dialogue and reconciliation,
and the application of church doctrine in an era of rapid change and
globalization. About 1 billion people worldwide profess the Catholic
faith.','b9233ba6ada0d60966885ca77d5b7673527ae7ec7d90c29a22de2cb5075dcb3f','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae3df62452c4e904b4f2eaceb7207bfe52a22907f85fbd613847665e090cd4e9',2007,'HN','Honduras','environment',642,'Once part of Spain''s vast empire in the New World, Honduras
became an independent nation in 1821. After two and a half decades
of mostly military rule, a freely elected civilian government came
to power in 1982. During the 1980s, Honduras proved a haven for
anti-Sandinista contras fighting the Marxist Nicaraguan Government
and an ally to Salvadoran Government forces fighting leftist
guerrillas. The country was devastated by Hurricane Mitch in 1998,
which killed about 5,600 people and caused approximately $2 billion
in damage.','4f42dd3345b337f13828b4a7a881c263cf37bef1e9ebd92d47fb0ccd23c165d7','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d3f8825dd27f3062ad94fa90e5c132fad40b7c154e0d04476b08cf2b2795e07a',2007,'HK','Hong Kong','environment',643,'Occupied by the UK in 1841, Hong Kong was formally ceded
by China the following year; various adjacent lands were added later
in the 19th century. Pursuant to an agreement signed by China and
the UK on 19 December 1984, Hong Kong became the Hong Kong Special
Administrative Region (SAR) of China on 1 July 1997. In this
agreement, China has promised that, under its "one country, two
systems" formula, China''s socialist economic system will not be
imposed on Hong Kong and that Hong Kong will enjoy a high degree of
autonomy in all matters except foreign and defense affairs for the
next 50 years.
Howland Island
Discovered by the US early in the 19th century, the
island was officially claimed by the US in 1857. Both US and British
companies mined for guano until about 1890. Earhart Light is a day
beacon near the middle of the west coast that was partially
destroyed during World War II, but has since been rebuilt; it is
named in memory of the famed aviatrix Amelia EARHART. The island is
administered by the US Department of the Interior as a National
Wildlife Refuge.','0607fa9f5a4d0fa3f03b9604bd03ec9cc02cfdd5950d6acb3482167afb803a1c','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bcfe0481dcda70b1b555c41149b98e4e61ea28713a663de278033b5722dcb1dd',2007,'HU','Hungary','environment',644,'Hungary was part of the polyglot Austro-Hungarian Empire,
which collapsed during World War I. The country fell under Communist
rule following World War II. In 1956, a revolt and announced
withdrawal from the Warsaw Pact were met with a massive military
intervention by Moscow. Under the leadership of Janos KADAR in 1968,
Hungary began liberalizing its economy, introducing so-called
"Goulash Communism." Hungary held its first multiparty elections in
1990 and initiated a free market economy. It joined NATO in 1999 and
the EU in 2004.','4b00750e5bef6dccb86bcc5a19bfd0c0494f97de427185fa6fa8fdf9a1156252','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2ef716c16deb2ab5120aa7da7779fecaceb32d5a6685c9f8e9b77b15daecadb5',2007,'IS','Iceland','environment',645,'Settled by Norwegian and Celtic (Scottish and Irish)
immigrants during the late 9th and 10th centuries A.D., Iceland
boasts the world''s oldest functioning legislative assembly, the
Althing, established in 930. Independent for over 300 years, Iceland
was subsequently ruled by Norway and Denmark. Fallout from the Askja
volcano of 1875 devastated the Icelandic economy and caused
widespread famine. Over the next quarter century, 20% of the
island''s population emigrated, mostly to Canada and the US. Limited
home rule from Denmark was granted in 1874 and complete independence
attained in 1944. Literacy, longevity, income, and social cohesion
are first-rate by world standards.
Iles Eparses
The Iles Eparses, or scattered islands, are a group of
five French entities - Bassas da India, Europa Island, Glorioso
Islands, Juan de Nova Island, and Tromelin Island - which on 1 April
1960 came under the authority of the Minister in charge of overseas
possessions. On 19 September 1960 by decree, the islands were
transferred to the charge of the Prefet of Reunion where they
remained until 3 January 2005 when they were transferred by another
decree to the Senior Administrator of the Territory of the French
Southern and Antarctic Lands (TAAF).
Bassas da India: A French possession since 1897, this atoll is a
volcanic seamount surrounded by reefs and awash at high tide.
Europa Island: A French possession since 1897, the island is heavily
wooded; it is the site of a small military garrison that staffs a
weather station.
Glorioso Islands: A French possession since 1892, the Glorioso
Islands are composed of two lushly vegetated coral islands (Ile
Glorieuse and Ile du Lys) and three rock islets. A military garrison
operates a weather and radio station on Ile Glorieuse.
Juan de Nova Island: Named after a famous 15th century Spanish
navigator and explorer, the island has been a French possession
since 1897. It has been exploited for its guano and phosphate.
Presently a small military garrison oversees a meteorological
station.
Tromelin Island: First explored by the French in 1776, the island
came under the jurisdiction of Reunion in 1814. At present, it
serves as a sea turtle sanctuary and is the site of an important
meteorological station.','0e073f492e3452bdf6b28e81a3002acf45863acf7bf2fe2692db6b0248a6ea6e','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3dd993a24eac5047a41dc71a3636ed4bfbf26433c514f7f685bac9025456ff56',2007,'IN','India','environment',646,'The Indus Valley civilization, one of the oldest in the world,
dates back at least 5,000 years. Aryan tribes from the northwest
infiltrated onto Indian lands about 1500 B.C.; their merger with the
earlier Dravidian inhabitants created the classical Indian culture.
Arab incursions starting in the 8th century and Turkish in the 12th
were followed by those of European traders, beginning in the late
15th century. By the 19th century, Britain had assumed political
control of virtually all Indian lands. Indian armed forces in the
British army played a vital role in both World Wars. Nonviolent
resistance to British colonialism led by Mohandas GANDHI and
Jawaharlal NEHRU brought independence in 1947. The subcontinent was
divided into the secular state of India and the smaller Muslim state
of Pakistan. A third war between the two countries in 1971 resulted
in East Pakistan becoming the separate nation of Bangladesh. Despite
impressive gains in economic investment and output, India faces
pressing problems such as the ongoing dispute with Pakistan over
Kashmir, massive overpopulation, environmental degradation,
extensive poverty, and ethnic and religious strife.
Indian Ocean
The Indian Ocean is the third largest of the world''s
five oceans (after the Pacific Ocean and Atlantic Ocean, but larger
than the Southern Ocean and Arctic Ocean). Four critically important
access waterways are the Suez Canal (Egypt), Bab el Mandeb
(Djibouti-Yemen), Strait of Hormuz (Iran-Oman), and Strait of
Malacca (Indonesia-Malaysia). The decision by the International
Hydrographic Organization in the spring of 2000 to delimit a fifth
ocean, the Southern Ocean, removed the portion of the Indian Ocean
south of 60 degrees south latitude.','9a4a62b5a459c795c47645d8583b18cff6e6ccab4f7cc71148d1dbaab36332ea','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bccbf7be32500ef9a90204b19da4a4f24f0dfdcb60433c6fde2e9298dd2f1658',2007,'ID','Indonesia','environment',647,'The Dutch began to colonize Indonesia in the early 17th
century; the islands were occupied by Japan from 1942 to 1945.
Indonesia declared its independence after Japan''s surrender, but it
required four years of intermittent negotiations, recurring
hostilities, and UN mediation before the Netherlands agreed to
relinquish its colony. Indonesia is the world''s largest archipelagic
state and home to the world''s largest Muslim population. Current
issues include: alleviating poverty, preventing terrorism,
consolidating democracy after four decades of authoritarianism,
implementing financial sector reforms, stemming corruption, and
holding the military and police accountable for human rights
violations. Indonesia was the nation worst hit by the December 2004
tsunami, which particularly affected Aceh province causing over
100,000 deaths and over $4 billion in damage. An additional
earthquake in March 2005 created heavy destruction on the island of
Nias. Reconstruction in these areas may take up to a decade. In
2005, Indonesia reached a historic peace agreement with armed
separatists in Aceh, but it continues to face a low intensity
separatist guerilla movement in Papua.
Iran
Known as Persia until 1935, Iran became an Islamic republic in
1979 after the ruling monarchy was overthrown and the shah was
forced into exile. Conservative clerical forces established a
theocratic system of government with ultimate political authority
nominally vested in a learned religious scholar. Iranian-US
relations have been strained since a group of Iranian students
seized the US Embassy in Tehran on 4 November 1979 and held it until
20 January 1981. During 1980-88, Iran fought a bloody, indecisive
war with Iraq that eventually expanded into the Persian Gulf and led
to clashes between US Navy and Iranian military forces between
1987-1988. Iran has been designated a state sponsor of terrorism for
its activities in Lebanon and elsewhere in the world and remains
subject to US economic sanctions and export controls because of its
continued involvement. Following the elections of a reformist
president and Majlis in the late 1990s, attempts to foster political
reform in response to popular dissatisfaction floundered as
conservative politicians prevented reform measures from being
enacted, increased repressive measures, and made electoral gains
against reformers. Parliamentary elections in 2004 and the August
2005 inauguration of a conservative stalwart as president, completed
the reconsolidation of conservative power in Iran''s government.','d5b59fe16a02b1aafcf6f0d0f9cf96c0432e77bb4d43a94b4e80616314a6c2c4','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c75aa2abd98daddae9b6d615e4c88f35f922bc4ccbb4e1a136c2fe3c5c594a8d',2007,'IQ','Iraq','environment',648,'Formerly part of the Ottoman Empire, Iraq was occupied by
Britain during the course of World War I; in 1920, it was declared a
League of Nations mandate under UK administration. In stages over
the next dozen years, Iraq attained its independence as a kingdom in
1932. A "republic" was proclaimed in 1958, but in actuality a series
of military strongmen ruled the country until 2003, the last was
SADDAM Husayn. Territorial disputes with Iran led to an inconclusive
and costly eight-year war (1980-88). In August 1990, Iraq seized
Kuwait, but was expelled by US-led, UN coalition forces during the
Gulf War of January-February 1991. Following Kuwait''s liberation,
the UN Security Council (UNSC) required Iraq to scrap all weapons of
mass destruction and long-range missiles and to allow UN
verification inspections. Continued Iraqi noncompliance with UNSC
resolutions over a period of 12 years led to the US-led invasion of
Iraq in March 2003 and the ouster of the SADDAM Husayn regime.
Coalition forces remain in Iraq under a UNSC mandate, helping to
provide security and to support the freely elected government. The
Coalition Provisional Authority, which temporarily administered Iraq
after the invasion, transferred full governmental authority on 28
June 2004 to the Iraqi Interim Government, which governed under the
Transitional Administrative Law for Iraq (TAL). Under the TAL,
elections for a 275-member Transitional National Assembly (TNA) were
held in Iraq on 30 January 2005. Following these elections, the
Iraqi Transitional Government (ITG) assumed office. The TNA was
charged with drafting Iraq''s permanent constitution, which was
approved in a 15 October 2005 constitutional referendum. An election
under the constitution for a 275-member Council of Representatives
(CoR) was held on 15 December 2005. The CoR approval in the
selection of most of the cabinet ministers on 20 May 2006 marked the
transition from the ITG to Iraq''s first constitutional government in
nearly a half-century.','0f29337ff3bcea8232ee6674f5f05093f0063c6e8566b117f752857ff579a849','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b42aa7ded2b59a0fa07d9e648bc7356ea1205ef0be032b5b0e290f3f357bd1d',2007,'IE','Ireland','environment',649,'Celtic tribes arrived on the island between 600-150 B.C.
Invasions by Norsemen that began in the late 8th century were
finally ended when King Brian BORU defeated the Danes in 1014.
English invasions began in the 12th century and set off more than
seven centuries of Anglo-Irish struggle marked by fierce rebellions
and harsh repressions. A failed 1916 Easter Monday Rebellion touched
off several years of guerrilla warfare that in 1921 resulted in
independence from the UK for 26 southern counties; six northern
(Ulster) counties remained part of the UK. In 1948 Ireland withdrew
from the British Commonwealth; it joined the European Community in
1973. Irish governments have sought the peaceful unification of
Ireland and have cooperated with Britain against terrorist groups. A
peace settlement for Northern Ireland is being implemented with some
difficulties. In 2006, the Irish and British governments developed
and began working to implement the St. Andrew''s Agreement, building
on the Good Friday Agreement approved in 1998.','8f289f7c3ed36f150f5dbe317c8b158359a30132e043d7d043356c9d9d40226b','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a310fba3ee7d35302b75ed97475905fdacaed08405fa81090a9940126e8d9df4',2007,'IM','Isle of Man','environment',650,'Part of the Norwegian Kingdom of the Hebrides until the
13th century when it was ceded to Scotland, the isle came under the
British crown in 1765. Current concerns include reviving the almost
extinct Manx Gaelic language. Isle of Man is a British crown
dependency, but is not part of the UK. However, the UK Government
remains constitutionally responsible for defense and international
representation.','8383e7850a70fb9688a7addd786520535a0636ab03a1be123769949ba14ec33d','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a6cd10bb031497aff5ae3bc29875e51e9e15e1baa9848fe840b8a793e57ca0b',2007,'IL','Israel','environment',651,'Following World War II, the British withdrew from their
mandate of Palestine, and the UN partitioned the area into Arab and
Jewish states, an arrangement rejected by the Arabs. Subsequently,
the Israelis defeated the Arabs in a series of wars without ending
the deep tensions between the two sides. The territories Israel
occupied since the 1967 war are not included in the Israel country
profile, unless otherwise noted. On 25 April 1982, Israel withdrew
from the Sinai pursuant to the 1979 Israel-Egypt Peace Treaty.
Israel and Palestinian officials signed on 13 September 1993 a
Declaration of Principles (also known as the "Oslo Accords") guiding
an interim period of Palestinian self-rule. Outstanding territorial
and other disputes with Jordan were resolved in the 26 October 1994
Israel-Jordan Treaty of Peace. In addition, on 25 May 2000, Israel
withdrew unilaterally from southern Lebanon, which it had occupied
since 1982. In keeping with the framework established at the Madrid
Conference in October 1991, bilateral negotiations were conducted
between Israel and Palestinian representatives and Syria to achieve
a permanent settlement. In April 2003, US President BUSH, working in
conjunction with the EU, UN, and Russia - the "Quartet" - took the
lead in laying out a roadmap to a final settlement of the conflict
by 2005, based on reciprocal steps by the two parties leading to two
states, Israel and a democratic Palestine. However, progress toward
a permanent status agreement was undermined by Israeli-Palestinian
violence between September 2003 and February 2005. An
Israeli-Palestinian agreement reached at Sharm al-Sheikh in February
2005, along with an internally-brokered Palestinian ceasefire,
significantly reduced the violence. In the summer of 2005, Israel
unilaterally disengaged from the Gaza Strip, evacuating settlers and
its military. The election of HAMAS in January 2006 to head the
Palestinian Legislative Council froze relations between Israel and
the Palestinian Authority. Ehud OLMERT became prime minister in
March 2006; following an Israeli military operation in Gaza in
June-July 2006, he shelved plans to unilaterally evacuate from most
of the West Bank. The kidnapping of two Israeli soldiers by Lebanese
Hizballah led to a 34-day conflict in Lebanon in June-August 2006.','800d2336004c655409322c31a28d6719125c5d3ff9c29ace05ba365b5bd7798b','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aaa5999ad08f032ede52fca64335c05fc39338342881174ff7ad013de07435c4',2007,'IT','Italy','environment',652,'Italy became a nation-state in 1861 when the regional states
of the peninsula, along with Sardinia and Sicily, were united under
King Victor EMMANUEL II. An era of parliamentary government came to
a close in the early 1920s when Benito MUSSOLINI established a
Fascist dictatorship. His disastrous alliance with Nazi Germany led
to Italy''s defeat in World War II. A democratic republic replaced
the monarchy in 1946 and economic revival followed. Italy was a
charter member of NATO and the European Economic Community (EEC). It
has been at the forefront of European economic and political
unification, joining the Economic and Monetary Union in 1999.
Persistent problems include illegal immigration, organized crime,
corruption, high unemployment, sluggish economic growth, and the low
incomes and technical standards of southern Italy compared with the
prosperous north.','6ac04d36f80b17db9632307945e76031f5b3a98e1da3c0b3fc5192e40d441b66','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35cf3d49bdfcfc0fce1ded06d3a0d39256a686bf95c02541908c0243ba7ea1cb',2007,'JM','Jamaica','environment',653,'The island - discovered by Christopher COLUMBUS in 1494 -
was settled by the Spanish early in the 16th century. The native
Taino Indians, who had inhabited Jamaica for centuries, were
gradually exterminated, replaced by African slaves. England siezed
the island in 1655 and a plantation economy - based on sugar, cocoa,
and coffee - was established. The abolition of slavery in 1834 freed
a quarter million slaves, many of which became small farmers.
Jamaica gradually obtained increasing independence from Britain, and
in 1958 it joined other British Caribbean colonies in forming the
Federation of the West Indies. Jamaica gained full independence when
it withdrew from the federation in 1962. Deteriorating economic
conditions during the 1970s led to recurrent violence as rival gangs
created by the major political parties evolved into powerful
organized crime networks involved in international drug smuggling
and money laundering. The cycle of violence, drugs, and poverty has
served to impoverish large sectors of the populace. Nonetheless,
many rural and resort areas remain relatively safe and contribute
substantially to the economy.
Jan Mayen
This desolate, mountainous island was named after a Dutch
whaling captain who indisputably discovered it in 1614 (earlier
claims are inconclusive). Visited only occasionally by seal hunters
and trappers over the following centuries, the island came under
Norwegian sovereignty in 1929. The long dormant Haakon VII
Toppen/Beerenberg volcano resumed activity in 1970; it is the
northernmost active volcano on earth.','dc355399380194aa8ceba814f8f1485d1f965099534edea2da48c91a91a61aa1','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f943dc113f46d2ff91b8edf91a0aaaadf4f171a176d8d08bdbfce5c2c3490554',2007,'JP','Japan','environment',654,'In 1603, a Tokugawa shogunate (military dictatorship) ushered
in a long period of isolation from foreign influence in order to
secure its power. For 250 years this policy enabled Japan to enjoy
stability and a flowering of its indigenous culture. Following the
Treaty of Kanagawa with the US in 1854, Japan opened its ports and
began to intensively modernize and industrialize. During the late
19th and early 20th centuries, Japan became a regional power that
was able to defeat the forces of both China and Russia. It occupied
Korea, Formosa (Taiwan), and southern Sakhalin Island. In 1931-32
Japan occupied Manchuria, and in 1937 it launched a full-scale
invasion of China. Japan attacked US forces in 1941 - triggering
America''s entry into World War II - and soon occupied much of East
and Southeast Asia. After its defeat in World War II, Japan
recovered to become an economic power and a staunch ally of the US.
While the emperor retains his throne as a symbol of national unity,
actual power rests in networks of powerful politicians, bureaucrats,
and business executives. The economy experienced a major slowdown
starting in the 1990s following three decades of unprecedented
growth, but Japan still remains a major economic power, both in Asia
and globally.
Jarvis Island
First discovered by the British in 1821, the
uninhabited island was annexed by the US in 1858, but abandoned in
1879 after tons of guano had been removed. The UK annexed the island
in 1889, but never carried out plans for further exploitation. The
US occupied and reclaimed the island in 1935. Abandoned after World
War II, the island is currently a National Wildlife Refuge
administered by the US Department of the Interior.','b2e8bfe69be4950385bf09b83c8425c92d1ba15f2fef2375483d52c41cd82576','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c11aa2bbc48596adc676556ca717ce99579182e69fb9e80b8a55248abf2efc14',2007,'JE','Jersey','environment',655,'Jersey and the other Channel Islands represent the last
remnants of the medieval Dukedom of Normandy that held sway in both
France and England. These islands were the only British soil
occupied by German troops in World War II. Jersey is a British crown
dependency, but is not part of the UK. However, the UK Government is
constitutionally responsible for defense and international
representation.
Johnston Atoll
Both the US and the Kingdom of Hawaii annexed
Johnston Atoll in 1858, but it was the US that mined the guano
deposits until the late 1880s. Johnston and Sand Islands were
designated wildlife refuges in 1926. The US Navy took over the atoll
in 1934, and subsequently the US Air Force assumed control in 1948.
The site was used for high-altitude nuclear tests in the 1950s and
1960s, and until late in 2000 the atoll was maintained as a storage
and disposal site for chemical weapons. Munitions destruction is now
complete. Cleanup and closure of the facility was completed by May
2005.','34db61d9ca19feb8f3780795ecc1ad70d71cd1c72f409578836096265ea232f4','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39935ea4ed89432f2c29a40e6b871db96c6dc7fc2d3720aed33d3600ac836642',2007,'JO','Jordan','environment',656,'Following World War I and the dissolution of the Ottoman
Empire, the UK received a mandate to govern much of the Middle East.
Britain separated out a semi-autonomous region of Transjordan from
Palestine in the early 1920s, and the area gained its independence
in 1946; it adopted the name of Jordan in 1950. The country''s
long-time ruler was King HUSSEIN (1953-99). A pragmatic leader, he
successfully navigated competing pressures from the major powers
(US, USSR, and UK), various Arab states, Israel, and a large
internal Palestinian population, despite several wars and coup
attempts. In 1989 he reinstituted parliamentary elections and
gradual political liberalization; in 1994 he signed a peace treaty
with Israel. King ABDALLAH II, the son of King HUSSEIN, assumed the
throne following his father''s death in February 1999. Since then, he
has consolidated his power and undertaken an aggressive economic
reform program. Jordan acceded to the World Trade Organization in
2000, and began to participate in the European Free Trade
Association in 2001. After a two-year delay, parliamentary and
municipal elections took place in the summer of 2003. The prime
minister appointed in November 2005 stated the government would
focus on political reforms, improving conditions for the poor, and
fighting corruption.
Juan de Nova Island
Named after a famous 15th century Spanish
navigator and explorer, the island has been a French possession
since 1897. It has been exploited for its guano and phosphate.
Presently a small military garrison oversees a meteorological
station.','e40f53c8b74c843f20a41f2c3564dcc19d00896b8abe1be95d59e738a4e9e6d4','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('de7d14047770cd50804cfc72d29c9b84eaf1f982a939fd9638395e41423abf1f',2007,'KZ','Kazakhstan','environment',657,'Native Kazakhs, a mix of Turkic and Mongol nomadic tribes
who migrated into the region in the 13th century, were rarely united
as a single nation. The area was conquered by Russia in the 18th
century, and Kazakhstan became a Soviet Republic in 1936. During the
1950s and 1960s agricultural "Virgin Lands" program, Soviet citizens
were encouraged to help cultivate Kazakhstan''s northern pastures.
This influx of immigrants (mostly Russians, but also some other
deported nationalities) skewed the ethnic mixture and enabled
non-Kazakhs to outnumber natives. Independence in 1991 caused many
of these newcomers to emigrate. Current issues include: developing a
cohesive national identity; expanding the development of the
country''s vast energy resources and exporting them to world markets;
achieving a sustainable economic growth outside the oil, gas, and
mining sectors; and strengthening relations with neighboring states
and other foreign powers.','69902ae3e230ca38e6b6a467aa303e8f83eaf9400095c379bed69cf06816cb95','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc9d1574eaca2e7f75381b4965f2b717699c93734aa28b38895a4404977381fc',2007,'KE','Kenya','environment',658,'Founding president and liberation struggle icon Jomo KENYATTA
led Kenya from independence in 1963 until his death in 1978, when
President Daniel Toroitich arap MOI took power in a constitutional
succession. The country was a de facto one-party state from 1969
until 1982 when the ruling Kenya African National Union (KANU) made
itself the sole legal party in Kenya. MOI acceded to internal and
external pressure for political liberalization in late 1991. The
ethnically fractured opposition failed to dislodge KANU from power
in elections in 1992 and 1997, which were marred by violence and
fraud, but were viewed as having generally reflected the will of the
Kenyan people. President MOI stepped down in December 2002 following
fair and peaceful elections. Mwai KIBAKI, running as the candidate
of the multiethnic, united opposition group, the National Rainbow
Coalition (NARC), defeated KANU candidate Uhuru KENYATTA and assumed
the presidency following a campaign centered on an anticorruption
platform. KIBAKI''s NARC coalition splintered in 2005 over the
constitutional review process. Government defectors joined with KANU
to form a new opposition coalition, the Orange Democratic Movement,
which defeated the government''s draft constitution in a popular
referendum in November 2005.
Kingman Reef
The US annexed the reef in 1922. Its sheltered lagoon
served as a way station for flying boats on Hawaii-to-American Samoa
flights during the late 1930s. There are no terrestrial plants on
the reef, which is frequently awash, but it does support abundant
and diverse marine fauna and flora. In 2001, the waters surrounding
the reef out to 12 nm were designated a US National Wildlife Refuge.','1beccc526666a11e0c025ba21b68d98ef94726b2d237f3c5ffb39b4481c3f2f5','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2fd70c3a3cc6f0aef7ae555e25beadcbb28e08a3986bfb1164c013c04f8cdf4',2007,'KI','Kiribati','environment',659,'The Gilbert Islands were granted self-rule by the UK in
1971 and complete independence in 1979 under the new name of
Kiribati. The US relinquished all claims to the sparsely inhabited
Phoenix and Line Island groups in a 1979 treaty of friendship with
Kiribati.
Korea, North
An independent kingdom for much of its long history,
Korea was occupied by Japan in 1905 following the Russo-Japanese
War. Five years later, Japan formally annexed the entire peninsula.
Following World War II, Korea was split with the northern half
coming under Soviet-sponsored Communist domination. After failing in
the Korean War (1950-53) to conquer the US-backed Republic of Korea
(ROK) in the southern portion by force, North Korea (DPRK), under
its founder President KIM Il-so''ng, adopted a policy of ostensible
diplomatic and economic "self-reliance" as a check against excessive
Soviet or Communist Chinese influence. The DPRK demonized the US as
the ultimate threat to its social system through state-funded
propaganda, and molded political, economic, and military policies
around the core ideological objective of eventual unification of
Korea under Pyongyang''s control. KIM''s son, the current ruler KIM
Jong Il, was officially designated as his father''s successor in
1980, assuming a growing political and managerial role until the
elder KIM''s death in 1994. After decades of economic mismanagement
and resource misallocation, the DPRK since the mid-1990s has relied
heavily on international aid to feed its population while continuing
to expend resources to maintain an army of 1 million. North Korea''s
long-range missile development, as well as its nuclear, chemical,
and biological weapons programs and massive conventional armed
forces, are of major concern to the international community. In
December 2002, following revelations that the DPRK was pursuing a
nuclear weapons program based on enriched uranium in violation of a
1994 agreement with the US to freeze and ultimately dismantle its
existing plutonium-based program, North Korea expelled monitors from
the International Atomic Energy Agency (IAEA). In January 2003, it
declared its withdrawal from the international Non-Proliferation
Treaty. In mid-2003 Pyongyang announced it had completed the
reprocessing of spent nuclear fuel rods (to extract weapons-grade
plutonium) and was developing a "nuclear deterrent." Since August
2003, North Korea has participated in the Six-Party Talks with
China, Japan, Russia, South Korea, and the US designed to resolve
the stalemate over its nuclear programs. The fourth round of
Six-Party Talks were held in Beijing during July-September 2005. All
parties agreed to a Joint Statement of Principles in which, among
other things, the six parties unanimously reaffirmed the goal of
verifiable denuclearization of the Korean Peninsula in a peaceful
manner. In the Joint Statement, the DPRK committed to "abandoning
all nuclear weapons and existing nuclear programs and returning, at
an early date, to the Treaty on the Non-Proliferation of Nuclear
Weapons and to IAEA safeguards." The Joint Statement also commits
the US and other parties to certain actions as the DPRK
denuclearizes. The US offered a security assurance, specifying that
it had no nuclear weapons on ROK territory and no intention to
attack or invade the DPRK with nuclear or other weapons. The US and
DPRK will take steps to normalize relations, subject to the DPRK''s
implementing its denuclearization pledge and resolving other
longstanding concerns. While the Joint Statement provides a vision
of the end-point of the Six-Party process, much work lies ahead to
implement the elements of the agreement.
Korea, South
An independent Korean state or collection of states has
existed almost continuously for several millennia. Between its
initial unification in the 7th century - from three predecessor
Korean states - until the 20th century, Korea existed as a single
independent country. In 1905, following the Russo-Japanese War,
Korea became a protectorate of imperial Japan, and in 1910 it was
annexed as a colony. Korea regained its independence following
Japan''s surrender to the United States in 1945. After World War II,
a Republic of Korea (ROK) was set up in the southern half of the
Korean Peninsula while a Communist-style government was installed in
the north (the DPRK). During the Korean War (1950-53), US troops and
UN forces fought alongside soldiers from the ROK to defend South
Korea from DPRK attacks supported by China and the Soviet Union. An
armistice was signed in 1953, splitting the peninsula along a
demilitarized zone at about the 38th parallel. Thereafter, South
Korea achieved rapid economic growth with per capita income rising
to roughly 14 times the level of North Korea. In 1993, KIM Yo''ng-sam
became South Korea''s first civilian president following 32 years of
military rule. South Korea today is a fully functioning modern
democracy. In June 2000, a historic first North-South summit took
place between the South''s President KIM Tae-chung and the North''s
leader KIM Jong Il.','ccf64b52e2b0b9d1670036cdb430a2cc9db99901a4d484c6951a822efc32672f','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1930bf2398c4058fecb1d4df9a037036b53591f11f5dce65401407aaafef0ab',2007,'KW','Kuwait','environment',660,'Britain oversaw foreign relations and defense for the ruling
Kuwaiti AL-SABAH dynasty from 1899 until independence in 1961.
Kuwait was attacked and overrun by Iraq on 2 August 1990. Following
several weeks of aerial bombardment, a US-led, UN coalition began a
ground assault on 23 February 1991 that liberated Kuwait in four
days. Kuwait spent more than $5 billion to repair oil infrastructure
damaged during 1990-91. The AL-SABAH family has ruled since
returning to power in 1991, and reestablished an elected legislature
that in recent years has become increasingly assertive.','6240a509d8805a7e407ecc12df793a54a41406daf5e6d19d58443dc313e582c3','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16a78968f2ebe67b83fc66d9a587de3a207b2148c5c1f0f3350083801be3f0f7',2007,'KG','Kyrgyzstan','environment',661,'A Central Asian country of incredible natural beauty and
proud nomadic traditions, Kyrgyzstan was annexed by Russia in 1864;
it achieved independence from the Soviet Union in 1991. Nationwide
demonstrations in the spring of 2005 resulted in the ouster of
President Askar AKAYEV, who had run the country since 1990.
Subsequent presidential elections in July 2005 were won
overwhelmingly by former prime minister Kurmanbek BAKIYEV. The
political opposition organized demonstrations in Bishkek in in
April, May, and November 2006 resulting in the adoption of new
constitution that transfered some of the president''s powers to
parliament and the government. Current concerns include:
privatization of state-owned enterprises, expansion of democracy and
political freedoms, reduction of corruption, improving interethnic
relations, and combating terrorism.
Laos
Modern-day Laos has its roots in the ancient Lao kingdom of Lan
Xang, established in the 14th Century under King FA NGUM. For three
hundred years Lan Xang included large parts of present-day Cambodia
and Thailand, as well as all of what is now Laos. After centuries of
gradual decline, Laos came under the control of Siam (Thailand) from
the late 18th century until the late 19th century when it became
part of French Indochina. The Franco-Siamese Treaty of 1907 defined
the current Lao border with Thailand. In 1975, the Communist Pathet
Lao took control of the government ending a six-century-old monarchy
and instituting a strict socialist regime closely aligned to
Vietnam. A gradual return to private enterprise and the
liberalization of foreign investment laws began in 1986. Laos became
a member of ASEAN in 1997.','eb08552942893203781eda5e0a8a5420d4a28aa000705608d17f8cb073558bfc','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('55186eb261d17fd87268b4d7ecd0bdea43106d9c7408c19957547a3182a1134b',2007,'LV','Latvia','environment',662,'After a brief period of independence between the two World
Wars, Latvia was annexed by the USSR in 1940 - an action never
recognized by the US and many other countries. It reestablished its
independence in 1991 following the breakup of the Soviet Union.
Although the last Russian troops left in 1994, the status of the
Russian minority (some 30% of the population) remains of concern to
Moscow. Latvia joined both NATO and the EU in the spring of 2004.','dec7f67a5b589877c66136656f168057b1d36f77e0dbde807eab74f836ef80c2','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16575498cb9ec44af4ef18a82d8193d03a327ab99c6ecb86a53375b14fedd6d8',2007,'LB','Lebanon','environment',663,'Following the capture of Syria from the Ottoman Empire by
Anglo-French forces in 1918, France received a mandate over this
territory and separated out a region of Lebanon in 1920. France
granted this area independence in 1943. A 15-year civil war
(1976-1991) devastated the country, but Lebanon has since made
progress toward rebuilding its political institutions. Under the
Ta''if Accord - the blueprint for national reconciliation - the
Lebanese established a more equitable political system, particularly
by giving Muslims a greater voice in the political process while
institutionalizing sectarian divisions in the government. Since the
end of the war, Lebanon has conducted several successful elections,
most militias have been disbanded, and the Lebanese Armed Forces
(LAF) have extended authority over about two-thirds of the country.
Hizballah, a radical Shi''a organization listed by the US State
Department as a Foreign Terrorist Organization, retains its weapons.
During Lebanon''s civil war, the Arab League legitimized in the Ta''if
Accord Syria''s troop deployment, numbering about 16,000 based mainly
east of Beirut and in the Bekaa Valley. Damascus justified its
continued military presence in Lebanon by citing Beirut''s requests
and the failure of the Lebanese Government to implement all of the
constitutional reforms in the Ta''if Accord. Israel''s withdrawal from
southern Lebanon in May 2000, however, encouraged some Lebanese
groups to demand that Syria withdraw its forces as well. The passage
of UNSCR 1559 in early October 2004 - a resolution calling for Syria
to withdraw from Lebanon and end its interference in Lebanese
affairs - further emboldened Lebanese groups opposed to Syria''s
presence in Lebanon. The assassination of former Prime Minister
Rafiq HARIRI and 20 others in February 2005 led to massive
demonstrations in Beirut against the Syrian presence ("the Cedar
Revolution"). Syria finally withdrew the remainder of its military
forces from Lebanon in April 2005. In May-June 2005, Lebanon held
its first legislative elections since the end of the civil war free
of foreign interference, handing a majority to the bloc led by Saad
HARIRI, the slain prime minister''s son. Hizballah kidnapped two
Israeli soldiers in July 2006 leading to a 34-day conflict with
Israel. UNSCR 1701, which passed in August 2006, called for the
disarmament of Hizballah.','728c8dbf3d6235824de56f9095c859d682d3043db6e0219cc58dff6182df7897','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8327ff8cb392ebd022a7c6783dd0766e1b80e0479d0ef8483133c9034fffb2ec',2007,'LS','Lesotho','environment',664,'Basutoland was renamed the Kingdom of Lesotho upon
independence from the UK in 1966. The Basuto National Party ruled
for the first two decades. King MOSHOESHOE was exiled in 1990, but
returned to Lesotho in 1992 and reinstated in 1995. Constitutional
government was restored in 1993 after 7 years of military rule. In
1998, violent protests and a military mutiny following a contentious
election prompted a brief but bloody intervention by South African
and Botswanan military forces under the aegis of the Southern
African Development Community. Constitutional reforms have since
restored political stability; peaceful parliamentary elections were
held in 2002.','87cd40c19f1406979e46f59f9b190970326b843d4b77432a23118b500f0ce00a','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1b12fbac5880649f63fd9c6f5d555d8bd23b9659bb783a2a2bdc20ead135f702',2007,'LR','Liberia','environment',665,'Settlement of freed slaves from the US in what is today
Liberia began in 1822; by 1847, the Americo-Liberians were able to
establish a republic. William TUBMAN, president from 1944-71, did
much to promote foreign investment and to bridge the economic,
social, and political gaps between the descendents of the original
settlers and the inhabitants of the interior. In 1980, a military
coup led by Samuel DOE ushered in a decade of authoritarian rule. In
December 1989, Charles TAYLOR launched a rebellion against DOE''s
regime that led to a prolonged civil war in which DOE himself was
killed. A period of relative peace in 1997 allowed for elections
that brought TAYLOR to power, but major fighting resumed in 2000. An
August 2003, peace agreement ended the war and prompted the
resignation of former president Charles TAYLOR, who was exiled to
Nigeria. After two years of rule by a transitional government,
democratic elections in late 2005 brought President Ellen JOHNSON
SIRLEAF to power. The UN Mission in Liberia (UNMIL), which maintains
a strong presence throughout the country, completed a disarmament
program for former combatants in late 2004, but the security
situation is still volatile and the process of rebuilding the social
and economic structure of this war-torn country remains sluggish.','d572f21b57fe566e0c37593e3a144759625c4579e6f7645a4206d092b2bfe539','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0931b0dd961d025ed51ffc778b302f6c332eacd33be9cf57ec964044a436c30',2007,'LY','Libya','environment',666,'The Italians supplanted the Ottoman Turks from the area around
Tripoli in 1911 and did not relinquish their hold until 1943 when
defeated in World War II. Libya then passed to UN administration and
achieved independence in 1951. Following a 1969 military coup, Col.
Muammar Abu Minyar al-QADHAFI began to espouse his own political
system, the Third Universal Theory. The system is a combination of
socialism and Islam derived in part from tribal practices and is
supposed to be implemented by the Libyan people themselves in a
unique form of "direct democracy." QADHAFI has always seen himself
as a revolutionary and visionary leader. He used oil funds during
the 1970s and 1980s to promote his ideology outside Libya,
supporting subversives and terrorists abroad to hasten the end of
Marxism and capitalism. In addition, beginning in 1973, he engaged
in military operations in northern Chad''s Aozou Strip - to gain
access to minerals and to use as a base of influence in Chadian
politics - but was forced to retreat in 1987. UN sanctions in 1992
isolated QADHAFI politically following the downing of Pan AM Flight
103 over Lockerbie, Scotland. Libyan support for terrorism appeared
to have decreased after the imposition of sanctions. During the
1990s, QADHAFI also began to rebuild his relationships with Europe.
UN sanctions were suspended in April 1999 and finally lifted in
September 2003 after Libya resolved the Lockerbie case. In December
2003, Libya announced that it had agreed to reveal and end its
programs to develop weapons of mass destruction, and QADHAFI has
made significant strides in normalizing relations with western
nations since then. He has received various Western European leaders
as well as many working-level and commercial delegations, and made
his first trip to Western Europe in 15 years when he traveled to
Brussels in April 2004. QADHAFI also resolved in 2004 some of the
outstanding cases against his government for terrorist activities in
the 1980s by compensating some families of victims of the Pan Am
103, French airliner UTA, and La Belle disco bombings. The US
resumed full diplomatic relations with Libya in May 2006 and
rescinded Libya''s designation as a state sponsor of terrorism in
June.','61babbd85635bd57c2e7270b54ecdcf40193e65deac7e151b45896df7b52fcb8','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('577ef18fa2a6919fd5f7ec6761bc0fce301cb34cece068c0e3c0f1895d9f7d4a',2007,'LI','Liechtenstein','environment',667,'The Principality of Liechtenstein was established
within the Holy Roman Empire in 1719; it became a sovereign state in
1806. Until the end of World War I, it was closely tied to Austria,
but the economic devastation caused by that conflict forced
Liechtenstein to enter into a customs and monetary union with
Switzerland. Since World War II (in which Liechtenstein remained
neutral), the country''s low taxes have spurred outstanding economic
growth. Shortcomings in banking regulatory oversight resulted in
concerns about the use of financial institutions for money
laundering. However, Liechtenstein implemented anti-money-laundering
legislation over the past several years and a Mutual Legal
Assistance Treaty with the US went into effect in 2003.','e0f9ec8531b1a0c06d78760b97222ece409e4c2edb300d8d88d7519ac0996fd8','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fff0889ef1571acb547260f56f2522e9971628426c60e3ae5b4cd24b0429dda',2007,'LT','Lithuania','environment',668,'Independent between the two World Wars, Lithuania was
annexed by the USSR in 1940 - an action never recognized by the US.
On 11 March 1990, Lithuania became the first of the Soviet republics
to declare its independence, but Moscow did not recognize this
proclamation until September of 1991 (following the abortive coup in
Moscow). The last Russian troops withdrew in 1993. Lithuania
subsequently restructured its economy for integration into Western
European institutions; it joined both NATO and the EU in the spring
of 2004.','0a20226999d535d209f2b2f62fbbb10b11f42143fe2fc213d4ceb63863627d02','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45d8e1ef86feef9864a13b420a214e691acad3f55df48c4f6c04b353033e55c8',2007,'LU','Luxembourg','environment',669,'Founded in 963, Luxembourg became a grand duchy in 1815
and an independent state under the Netherlands. It lost more than
half of its territory to Belgium in 1839, but gained a larger
measure of autonomy. Full independence was attained in 1867. Overrun
by Germany in both World Wars, it ended its neutrality in 1948 when
it entered into the Benelux Customs Union and when it joined NATO
the following year. In 1957, Luxembourg became one of the six
founding countries of the European Economic Community (later the
European Union), and in 1999 it joined the euro currency area.
Macau
Colonized by the Portuguese in the 16th century, Macau was the
first European settlement in the Far East. Pursuant to an agreement
signed by China and Portugal on 13 April 1987, Macau became the
Macau Special Administrative Region (SAR) of China on 20 December
1999. China has promised that, under its "one country, two systems"
formula, China''s socialist economic system will not be practiced in
Macau, and that Macau will enjoy a high degree of autonomy in all
matters except foreign and defense affairs for the next 50 years.
Macedonia
Macedonia gained its independence peacefully from
Yugoslavia in 1991, but Greece''s objection to the new state''s use of
what it considered a Hellenic name and symbols delayed international
recognition, which occurred under the provisional designation of
"the Former Yugoslav Republic of Macedonia." In 1995, Greece lifted
a 20-month trade embargo and the two countries agreed to normalize
relations. The United States began referring to Macedonia by its
constitutional name, Republic of Macedonia, in 2004 and negotiations
continue between Greece and Macedonia to resolve the name issue.
Some ethnic Albanians, angered by perceived political and economic
inequities, launched an insurgency in 2001 that eventually won the
support of the majority of Macedonia''s Albanian population and led
to the internationally-brokered Framework Agreement, which ended the
fighting by establishing a set of new laws enhancing the rights of
minorities. The undetermined status of neighboring Kosovo,
implementation of the Framework Agreement, and a weak economy
continue to be challenges for Macedonia.','a9c921464069f3ad519befc9c8cac166ad924847644728f0a1822c0d78719549','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c14f3590bf6320f0e7cd7a4dfe3a88da0749024f067b81251bd28ae64151d439',2007,'MG','Madagascar','environment',670,'Formerly an independent kingdom, Madagascar became a
French colony in 1896, but regained its independence in 1960. During
1992-93, free presidential and National Assembly elections were
held, ending 17 years of single-party rule. In 1997, in the second
presidential race, Didier RATSIRAKA, the leader during the 1970s and
1980s, was returned to the presidency. The 2001 presidential
election was contested between the followers of Didier RATSIRAKA and
Marc RAVALOMANANA, nearly causing secession of half of the country.
In April 2002, the High Constitutional Court announced RAVALOMANANA
the winner.','ab1cf6416c1d6d71e7e5f034dacc2f25ca7ed671537b66933fa022b7198a1771','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed8d830e1c67f67db3bc38a31ebde951213f7b1f588489cfea813e279d87ae3b',2007,'MW','Malawi','environment',671,'Established in 1891, the British protectorate of Nyasaland
became the independent nation of Malawi in 1964. After three decades
of one-party rule under President Hastings Kamuzu BANDA the country
held multiparty elections in 1994, under a provisional constitution
which came into full effect the following year. Current President
Bingu wa MUTHARIKA, elected in May 2004 after a failed attempt by
the previous president to amend the constitution to permit another
term, has struggled to assert his authority against his predecessor,
who still leads their shared political party. MUTHARIKA''s
anti-corruption efforts have led to several high-level arrests and
one prominent conviction. Increasing corruption, population growth,
increasing pressure on agricultural lands, and the spread of
HIV/AIDS pose major problems for the country.','e7b88fe19c00ea3e08001a04d02f6b53e4ee2bbbb3116609c9074915bcb8586a','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5d9969353ab2d7a0a7c425479d4564199e8d061c73d903350af51b148c318848',2007,'MY','Malaysia','environment',672,'During the late 18th and 19th centuries, Great Britain
established colonies and protectorates in the area of current
Malaysia; these were occupied by Japan from 1942 to 1945. In 1948,
the British-ruled territories on the Malay Peninsula formed the
Federation of Malaya, which became independent in 1957. Malaysia was
formed in 1963 when the former British colonies of Singapore and the
East Malaysian states of Sabah and Sarawak on the northern coast of
Borneo joined the Federation. The first several years of the
country''s history were marred by Indonesian efforts to control
Malaysia, Philippine claims to Sabah, and Singapore''s secession from
the Federation in 1965. During the 22-year term of Prime Minister
MAHATHIR bin Mohamad (1981-2003), Malaysia was successful in
diversifying its economy from dependence on exports of raw
materials, to expansion in manufacturing, services, and tourism.
Bornholm (island) Denmark 55 10 N 15 00 E
Bosna i Hercegovina Bosnia and 44 00 N 18 00 E
(local name for Bosnia Herzegovina
and Herzegovina)
Bosnia (political region) Bosnia and 44 00 N 18 00 E
Herzegovina
Bosporus (strait) Atlantic Ocean 41 00 N 29 00 E
Bothnia, Gulf of Atlantic Ocean 63 00 N 20 00 E
Bougainville (island) Papua New Guinea 6 00 S 155 00 E
Bougainville Strait Pacific Ocean 6 40 S 156 10 E
Bounty Islands New Zealand 47 43 S 174 00 E
Bourbon Island (former Reunion 21 06 S 55 36 E
name of Reunion)
Brasilia (capital) Brazil 15 47 S 47 55 W
Bratislava (capital) Slovakia 48 09 N 17 07 E
Brazzaville (capital) Republic of the 4 16 S 15 17 E
Green Islands Papua New Guinea 4 30 S 154 10 E
Greenland Sea Arctic Ocean 79 00 N 5 00 W
Grenadines, Northern Saint Vincent and 13 15 N 61 12 W
(island group) the Grenadines
Grenadines, Southern Grenada 12 07 N 61 40 W
(island group)
Grytviken (town; on South South Georgia and 54 15 S 36 45 W
Georgia) the South Sandwich
Islands
Guadalahara (city) Mexico 20 40 N 103 24 W
Guadalcanal (island) Solomon Islands 9 32 S 160 12 E
Guadalupe, Isla de Mexico 29 11 N 118 17 W
(island)
Guangzhou (city; also China 23 09 N 113 21 E
Canton)
Guantanamo Bay (US Naval Cuba 20 00 N 75 08 W
Base)
Guatemala (capital) Guatemala 14 38 N 90 31 W
Guine-Bissau (local name Guinea-Bissau 12 00 N 15 00 W
for Guinea-Bissau)
Guinea Ecuatorial (local Equatorial Guinea 2 00 N 10 00 E
name for Equatorial
Guinea)
Guinea, Gulf of Atlantic Ocean 3 00 N 2 30 E
Guinee (local name for Guinea 11 00 N 10 00 W
Guinea)
Guyane Francaise (local French Guiana 4 00 N 53 00 W
name for French Guiana)
Ha''apai Group (island Tonga 19 42 S 174 29 W
group)
Habomai Islands Russia (de facto) 43 30 N 146 10 E
Hadhramaut (region) Yemen 15 00 N 50 00 E
Hagatna (capital; Guam 13 28 N 144 45 E
formerly Agana)
Hague, The (seat of Netherlands 52 05 N 4 18 E','45b44c06089b2f143e544e23faf479da132aed8a785ec6cf79dc1060c00cb37b','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4bfaea5443fb3ef8ab1138ee9823755adba9ebaeccd86e1de23cd3be6960f44b',2007,'MV','Maldives','environment',673,'The Maldives was long a sultanate, first under Dutch and
then under British protection. It became a republic in 1968, three
years after independence. Since 1978, President Maumoon Abdul GAYOOM
- currently in his sixth term in office - has dominated the islands''
political scene. Following riots in the capital Male in August 2004,
the president and his government pledged to embark upon democratic
reforms, including a more representative political system and
expanded political freedoms. Progress has been slow, however, and
many promised reforms have been delayed indefinitely. Tourism and
fishing are being developed on the archipelago.','3def9a5a1b998dd18e0be6c6b4436ab915d459cf27d1660278218463f1029136','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a7aca0128b49e5ad2a092b004b27eae9be5f17ee1fbe89f6d851454304eeac8',2007,'ML','Mali','environment',674,'The Sudanese Republic and Senegal became independent of France
in 1960 as the Mali Federation. When Senegal withdrew after only a
few months, what formerly made up the Sudanese Republic was renamed
Mali. Rule by dictatorship was brought to a close in 1991 by a coup
that ushered in democratic government. President Alpha KONARE won
Mali''s first democratic presidential election in 1992 and was
reelected in 1997. In keeping with Mali''s two-term constitutional
limit, KONARE stepped down in 2002 and was succeeded by Amadou TOURE.','2cabb0338691f6863afdd40a8b57b8d8fef4b655f4890e8724791a609eb2f660','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('876a3676d2755c1bed292084b4d14dc3fdc4c5bb7f46037c697b726b4c2a79df',2007,'MT','Malta','environment',675,'Great Britain formally acquired possession of Malta in 1814.
The island staunchly supported the UK through both World Wars and
remained in the Commonwealth when it became independent in 1964. A
decade later Malta became a republic. Since about the mid-1980s, the
island has transformed itself into a freight transshipment point, a
financial center, and a tourist destination. Malta became an EU
member in May 2004.','a515c9c9fd8f5bb4631fd300f965941f56bb282cbe9cfc588d3eb382969a4bbc','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1eef4ed0d9ef343719fdcdfc4cb6db778fe838f65e82f73e7b282e8176fdea86',2007,'MH','Marshall Islands','environment',676,'After almost four decades under US administration
as the easternmost part of the UN Trust Territory of the Pacific
Islands, the Marshall Islands attained independence in 1986 under a
Compact of Free Association. Compensation claims continue as a
result of US nuclear testing on some of the atolls between 1947 and
1962. The Marshall Islands hosts the US Army Kwajalein Atoll (USAKA)
Reagan Missile Test Site, a key installation in the US missile
defense network.','12912db99d92d2e61493e5f85acf0d95f32f3f3af848df84854d2ab36ed6b148','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e1e0d7611e1a013fa0a7bcf1b37b215f9fcc164e8b00670ab2193a2d85da5e91',2007,'MR','Mauritania','environment',677,'Independent from France in 1960, Mauritania annexed the
southern third of the former Spanish Sahara (now Western Sahara) in
1976, but relinquished it after three years of raids by the
Polisario guerrilla front seeking independence for the territory.
Maaouya Ould Sid Ahmed TAYA seized power in a coup in 1984.
Opposition parties were legalized and a new constitution approved in
1991. Two multiparty presidential elections since then were widely
seen as flawed, but October 2001 legislative and municipal elections
were generally free and open. A bloodless coup in August 2005
deposed President TAYA and ushered in a military council headed by
Col. Ely Ould Mohamed VALL, which declared it would remain in power
for up to two years while it created conditions for genuine
democratic institutions and organized elections. Accordingly,
parliamentary elections were held in December of 2006 and senatorial
and presidential elections will follow (January and March 2007
respectively). The newly-elected legislature is expected to assume
power following the inauguration of the new president. For now,
however, Mauritania remains an autocratic state, and the country
continues to experience ethnic tensions among its black population
and different Moor (Arab-Berber) communities.','6087900cfd7aafae99ccfa4a09fae65cca32739162b9912e33b05c6befeb5166','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('867ae4ec1938552de1cbd237f237e5907432ee8c173811d726554f05fc852ce7',2007,'MU','Mauritius','environment',678,'Although known to Arab and Malay sailors as early as the
10th century, Mauritius was first explored by the Portuguese in
1505; it was subsequently held by the Dutch, French, and British
before independence was attained in 1968. A stable democracy with
regular free elections and a positive human rights record, the
country has attracted considerable foreign investment and has earned
one of Africa''s highest per capita incomes. Recent poor weather and
declining sugar prices have slowed economic growth, leading to some
protests over standards of living in the Creole community.','190b279fd5e3be07d835bba0828f9686998867eb1723cf1c25e8db1088c81266','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('12bc54f0cb5994c104da7f7fd98a6de79b2d866e19a876168ec1709a2a20fc96',2007,'YT','Mayotte','environment',679,'Mayotte was ceded to France along with the other islands of
the Comoros group in 1843. It was the only island in the archipelago
that voted in 1974 to retain its link with France and forego
independence.','fd8ff2154910ddd53ab3fab61dfe4e608676b4de482cd0e092d75c03e1cc6fa6','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ae34a6457f0f707e915c9ea876d55aecd9373481cd15c6e2f27e580b4971d11',2007,'MX','Mexico','environment',680,'The site of advanced Amerindian civilizations, Mexico came
under Spanish rule for three centuries before achieving independence
early in the 19th century. A devaluation of the peso in late 1994
threw Mexico into economic turmoil, triggering the worst recession
in over half a century. The nation continues to make an impressive
recovery. Ongoing economic and social concerns include low real
wages, underemployment for a large segment of the population,
inequitable income distribution, and few advancement opportunities
for the largely Amerindian population in the impoverished southern
states. Elections held in July 2000 marked the first time since the
1910 Mexican Revolution that the opposition defeated the party in
government, the Institutional Revolutionary Party (PRI). Vicente FOX
of the National Action Party (PAN) was sworn in on 1 December 2000
as the first chief executive elected in free and fair elections.','a0acfc65fe2c712985eb49080bb6361a97e2f12105f233af4fb1dd5ae7a6ce4d','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e61df1cb09b88d394692b1e589251432e9cabdc2bbd5aa6f3063478fdf4b494b',2007,'FM','Micronesia, Federated States of','environment',681,'In 1979 the Federated States of
Micronesia, a UN Trust Territory under US administration, adopted a
constitution. In 1986 independence was attained under a Compact of
Free Association with the US, which was amended and renewed in 2004.
Present concerns include large-scale unemployment, overfishing, and
overdependence on US aid.
Midway Islands
The US took formal possession of the islands in 1867.
The laying of the trans-Pacific cable, which passed through the
islands, brought the first residents in 1903. Between 1935 and 1947,
Midway was used as a refueling stop for trans-Pacific flights. The
US naval victory over a Japanese fleet off Midway in 1942 was one of
the turning points of World War II. The islands continued to serve
as a naval station until closed in 1993. Today the islands are a
national wildlife refuge. From 1996 to 2001 the refuge was open to
the public; it is now temporarily closed.
Moldova
Formerly part of Romania, Moldova was incorporated into the
Soviet Union at the close of World War II. Although independent from
the USSR since 1991, Russian forces have remained on Moldovan
territory east of the Dniester River supporting the Slavic majority
population, mostly Ukrainians and Russians, who have proclaimed a
"Transnistria" republic. The poorest nation in Europe, Moldova
became the first former Soviet state to elect a Communist as its
president in 2001.','030dd19949b10e3c567045f0c3ab4f853c2c7a183d248a48f06fa45398afcdc8','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f35bf106ed445b4a613c810de695e6befb2f28dc9d260c0ae29d98162c466b70',2007,'MC','Monaco','environment',682,'The Genoese built a fortress on the site of present-day
Monaco in 1215. The current ruling Grimaldi family secured control
in the late 13th century, and a principality was established in
1338. Economic development was spurred in the late 19th century with
a railroad linkup to France and the opening of a casino. Since then,
the principality''s mild climate, splendid scenery, and gambling
facilities have made Monaco world famous as a tourist and recreation
center.','378260615b08fec103b3918142abd41d6336d90ed5dc7e12398f79230e332580','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f8190b1147e0d32e373592895806c79820fb2d8e853c2bec2ef285fd2ed4591',2007,'MN','Mongolia','environment',683,'The Mongols gained fame in the 13th century when under
Chinggis KHAN they conquered a huge Eurasian empire. After his death
the empire was divided into several powerful Mongol states, but
these broke apart in the 14th century. The Mongols eventually
retired to their original steppe homelands and later came under
Chinese rule. Mongolia won its independence in 1921 with Soviet
backing. A Communist regime was installed in 1924. The ex-Communist
Mongolian People''s Revolutionary Party (MPRP) won elections in 1990
and 1992, but was defeated by the Democratic Union Coalition (DUC)
in the 1996 parliamentary election. Since then, parliamentary
elections returned the MPRP overwhelmingly to power in 2000 and
produced a coalition government in 2004.','3fb2d0b53f4861bb3e1abe5f9b6cb24a5123afb4b42c2c086c0fe61b905e5dd6','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('989c1650237b5e3a1c8d728c6e740e1041b2687fe1c52d3132d180234d882df8',2007,'ME','Montenegro','environment',684,'The use of the name Montenegro began in the 15th century
when the Crnojevic dynasty began to rule the Serbian principality of
Zeta; over subsequent centuries Montenegro was able to maintain its
independence from the Ottoman Empire. From the 16th to 19th
centuries, Montenegro became a theocracy ruled by a series of bishop
princes; in 1852, it was transformed into a secular principality.
After World War I, Montenegro was absorbed by the Kingdom of Serbs,
Croats, and Slovenes, which became the Kingdom of Yugoslavia in
1929; at the conclusion of World War II, it became a constituent
republic of the Socialist Federal Republic of Yugoslavia. When the
latter dissolved in 1992, Montenegro federated with Serbia, first as
the Federal Republic of Yugoslavia and, after 2003, in a looser
union of Serbia and Montenegro. In May 2006, Montenegro invoked its
right under the Constitutional Charter of Serbia and Montenegro to
hold a referendum on independence from the state union. The vote for
severing ties with Serbia exceeded 55% - the threshold set by the EU
- allowing Montenegro to formally declare its independence on 3 June
2006.','49096cd8d8cb99aea23d81efaad014d41483ded60adba9f63e2b743b5f66d156','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('86261ad0e540833e8fcebf4801aaca87f01f96fd42d1b739d7d4064e44790e03',2007,'MS','Montserrat','environment',685,'English and Irish colonists from St. Kitts first settled
on Montserrat in 1632; the first African slaves arrived three
decades later. The British and French fought for possesion of the
island for most of the 18th century, but it finally was confirmed as
a British possession in 1783. The island''s sugar plantation economy
was converted to small farm landholdings in the mid 19th century.
Much of this island was devastated and two-thirds of the population
fled abroad because of the eruption of the Soufriere Hills Volcano
that began on 18 July 1995. Montserrat has endured volcanic activity
since, with the last eruption occurring in July 2003.','00f13c05886d2ffc8f360d3e6a3e66c578926dac73c69fafc1516bd47bbd3d9a','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8bec2324ac3901d1eca95ab039c5eacdc3403e49a5e1dfdc8f63b6143f4c69ff',2007,'MA','Morocco','environment',686,'In 788, about a century after the Arab conquest of North
Africa, successive Moorish dynasties began to rule in Morocco. In
the 16th century, the Sa''adi monarchy, particularly under Ahmad
AL-MANSUR (1578-1603), repelled foreign invaders and inaugurated a
golden age. In 1860, Spain occupied northern Morocco and ushered in
a half century of trade rivalry among European powers that saw
Morocco''s sovereignty steadily erode; in 1912, the French imposed a
protectorate over the country. A protracted independence struggle
with France ended successfully in 1956. The internationalized city
of Tangier and most Spanish possessions were turned over to the new
country that same year. Morocco virtually annexed Western Sahara
during the late 1970s, but final resolution on the status of the
territory remains unresolved. Gradual political reforms in the 1990s
resulted in the establishment of a bicameral legislature, which
first met in 1997. Lower house elections were last held held in
September 2002 and upper house elections were last held in September
2006.','2ef16c65fae768de3d04cb9cfd3418984401f6298e192c03d5e197247ef3661a','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('afa273be8df1146932fc82f1df06dbf178c77b42572babe7b9af88b8cc0f60f5',2007,'MZ','Mozambique','environment',687,'Almost five centuries as a Portuguese colony came to a
close with independence in 1975. Large-scale emigration by whites,
economic dependence on South Africa, a severe drought, and a
prolonged civil war hindered the country''s development. The ruling
Front for the Liberation of Mozambique (FRELIMO) party formally
abandoned Marxism in 1989, and a new constitution the following year
provided for multiparty elections and a free market economy. A
UN-negotiated peace agreement between FRELIMO and rebel Mozambique
National Resistance (RENAMO) forces ended the fighting in 1992. In
December 2004, Mozambique underwent a delicate transition as Joaquim
CHISSANO stepped down after 18 years in office. His newly elected
successor, Armando Emilio GUEBUZA, has promised to continue the
sound economic policies that have encouraged foreign investment.','05e03da63777d3877e60463a9e12ca258683b2a36c68c3cc4810c3450996e24d','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb3c92f004f62afb35ce35105c1eac65636b97284badda5902a3d463ac863bb1',2007,'NA','Namibia','environment',688,'South Africa occupied the German colony of South-West Africa
during World War I and administered it as a mandate until after
World War II, when it annexed the territory. In 1966 the Marxist
South-West Africa People''s Organization (SWAPO) guerrilla group
launched a war of independence for the area that was soon named
Namibia, but it was not until 1988 that South Africa agreed to end
its administration in accordance with a UN peace plan for the entire
region. Namibia won its independence in 1990 and has been governed
by SWAPO since. Hifikepunye POHAMBA was elected president in
November 2004 in a landslide victory replacing Sam NUJOMA who led
the country during its first 14 years of self rule.','571a87e14f42194cd8da3fe5526b7dcc8ba0669d7720b1e9172fc44453de9d81','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4b40bd0747c7cdb336bd9dcdfabfd9b43568a0c0e31c0611dccb6de7a792220a',2007,'NR','Nauru','environment',689,'The exact origins of the Nauruans are unclear, since their
language does not resemble any other in the Pacific. The island was
annexed by Germany in 1888 and its phosphate deposits began to be
mined early in the 20th century by a German-British consortium.
Nauru was occupied by Australian forces in World War I and
subsequently became a League of Nations mandate. After the Second
World War - and a brutal occupation by Japan - Nauru became a UN
trust territory. It achieved its independence in 1968 and joined the
UN in 1999 as the world''s smallest independent republic.
Navassa Island
This uninhabited island was claimed by the US in 1857
for its guano. Mining took place between 1865 and 1898. The
lighthouse, built in 1917, was shut down in 1996 and administration
of Navassa Island transferred from the Coast Guard to the Department
of the Interior. A 1998 scientific expedition to the island
described it as a unique preserve of Caribbean biodiversity; the
following year it became a National Wildlife Refuge and annual
scientific expeditions have continued.','a64511dff9891c55ed6845e85846dfd841d1fb9e59c75a188c603dd4eb49038b','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7c574ba571d759c0f6f6a709111e21e4e658b6dbffe384bcecd7616782d5df82',2007,'NP','Nepal','environment',690,'In 1951, the Nepalese monarch ended the century-old system of
rule by hereditary premiers and instituted a cabinet system of
government. Reforms in 1990 established a multiparty democracy
within the framework of a constitutional monarchy. A Maoist
insurgency, launched in 1996, gained traction and threatened to
bring down the regime, especially after a negotiated cease-fire
between the Maoists and government forces broke down in August 2003.
In 2001, the crown prince massacred ten members of the royal family,
including the king and queen, and then took his own life. In October
2002, the new king dismissed the prime minister and his cabinet for
"incompetence" after they dissolved the parliament and were
subsequently unable to hold elections because of the ongoing
insurgency. While stopping short of reestablishing parliament, the
king in June 2004 reinstated the most recently elected prime
minister who formed a four-party coalition government. Citing
dissatisfaction with the government''s lack of progress in addressing
the Maoist insurgency and corruption, the king in February 2005
dissolved the government, declared a state of emergency, imprisoned
party leaders, and assumed power. The king''s government subsequently
released party leaders and officially ended the state of emergency
in May 2005, but the monarch retained absolute power until April
2006. After nearly three weeks of mass protests organized by the
seven-party opposition and the Maoists, the king allowed parliament
to reconvene on 28 April 2006. In November 2006, the government and
Maoists signed the Comprehensive Peace Accord to end the ten-year
insurgency.','ac1a9a0dfa4f2e412d923df16f1a27b48cd23a6af6932e62e8dc31e8568f1f81','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a839e516250045d089dda5b8f03e1aacede2430b14cc2c209a0e434aa7c3c17',2007,'NL','Netherlands','environment',691,'The Dutch United Provinces declared their independence
from Spain in 1579; during the 17th century, they became a leading
seafaring and commercial power, with settlements and colonies around
the world. After a 20-year French occupation, a Kingdom of the
Netherlands was formed in 1815. In 1830 Belgium seceded and formed a
separate kingdom. The Netherlands remained neutral in World War I,
but suffered invasion and occupation by Germany in World War II. A
modern, industrialized nation, the Netherlands is also a large
exporter of agricultural products. The country was a founding member
of NATO and the EEC (now the EU), and participated in the
introduction of the euro in 1999.
Netherlands Antilles
Once the center of the Caribbean slave trade,
the island of Curacao was hard hit by the abolition of slavery in
1863. Its prosperity (and that of neighboring Aruba) was restored in
the early 20th century with the construction of oil refineries to
service the newly discovered Venezuelan oil fields. The island of
Saint Martin is shared with France; its southern portion is named
Sint Maarten and is part of the Netherlands Antilles; its northern
portion is called Saint-Martin and is part of Guadeloupe (France).
Antilles NT AN ANT 530 .an
New Caledonia NC NC NCL 540 .nc
New Zealand NZ NZ NZL 554 .nz
Nicaragua NU NI NIC 558 .ni
Niger NG NE NER 562 .ne
Nigeria NI NG NGA 566 .ng
Niue NE NU NIU 570 .nu
Norfolk Island NF NF NFK 574 .nf
Northern
Mariana Islands CQ MP MNP 580 .mp
Norway NO NO NOR 578 .no
Oman MU OM OMN 512 .om
Pakistan PK PK PAK 586 .pk
Palau PS PW PLW 585 .pw
Palmyra Atoll LQ - - - ISO
includes with the US Minor Outlying Islands
Panama PM PA PAN 591 .pa
Papua New Guinea PP PG PNG 598 .pg
Paracel Islands PF - - -
Paraguay PA PY PRY 600 .py
Peru PE PE PER 604 .pe
Philippines RP PH PHL 608 .ph
Pitcairn Islands PC PN PCN 612 .pn
Poland PL PL POL 616 .pl
Portugal PO PT PRT 620 .pt
Puerto Rico RQ PR PRI 630 .pr
Qatar QA QA QAT 634 .qa
Reunion RE RE REU 638 .re
Romania RO RO ROU 642 .ro
Russia RS RU RUS 643 .ru
Rwanda RW RW RWA 646 .rw
Saint Helena SH SH SHN 654 .sh
Saint Kitts
and Nevis SC KN KNA 659 .kn
Saint Lucia ST LC LCA 662 .lc
Saint Pierre
and Miquelon SB PM SPM 666 .pm
Saint Vincent
and the
Grenadines VC VC VCT 670 .vc
Samoa WS WS WSM 882 .ws
San Marino SM SM SMR 674 .sm
Sao Tome and
Principe TP ST STP 678 .st
Saudi Arabia SA SA SAU 682 .sa
Senegal SG SN SEN 686 .sn
Serbia RB RS SRB 688 .rs
Seychelles SE SC SYC 690 .sc
Sierra Leone SL SL SLE 694 .sl
Singapore SN SG SGP 702 .sg
Slovakia LO SK SVK 703 .sk
Slovenia SI SI SVN 705 .si
Solomon Islands BP SB SLB 090 .sb
Somalia SO SO SOM 706 .so
South Africa SF ZA ZAF 710 .za
South Georgia
and the Islands SX GS SGS 239 .gs
Spain SP ES ESP 724 .es
Spratly Islands PG - - -
Sri Lanka CE LK LKA 144 .lk
Sudan SU SD SDN 736 .sd
Suriname NS SR SUR 740 .sr
Svalbard SV SJ SJM 744 .sj
ISO includes Jan Mayen
Swaziland WZ SZ SWZ 748 .sz
Sweden SW SE SWE 752 .se
Switzerland SZ CH CHE 756 .ch
Syria SY SY SYR 760 .sy
Taiwan TW TW TWN 158 .tw
Tajikistan TI TJ TJK 762 .tj
Tanzania TZ TZ TZA 834 .tz
Thailand TH TH THA 764 .th
Togo TO TG TGO 768 .tg
Tokelau TL TK TKL 772 .tk
Tonga TN TO TON 776 .to
Trinidad
and Tobago TD TT TTO 780 .tt
Tromelin Island TE - - - -
administered as part of French Southern and Antarctic Lands;
no ISO codes assigned
Tunisia TS TN TUN 788 .tn
Turkey TU TR TUR 792 .tr
Turkmenistan TX TM TKM 795 .tm
Turks and
Caicos Islands TK TC TCA 796 .tc
Tuvalu TV TV TUV 798 .tv
Uganda UG UG UGA 800 .ug
Ukraine UP UA UKR 804 .ua
United Arab
Emirates AE AE ARE 784 .ae
United Kingdom UK GB GBR 826 .uk
United States US US USA 840 .us
Frunze (city; former name Kyrgyzstan 42 54 N 74 36 E
for Bishkek)
Funafuti (capital, atoll) Tuvalu 8 30 S 179 12 E
Fundy, Bay of Atlantic Ocean 45 00 N 66 00 W
Futuna Islands (Hoorn Wallis and Futuna 14 19 S 178 05 W
Islands/Iles de Horne)
Fyn (island) Denmark 55 20 N 10 25 E
Gaborone (capital) Botswana 24 45 S 25 55 E
Galapagos Islands Ecuador 0 00 N 90 30 W
(Archipielago de Colon)
Galicia (region) Poland, Ukraine 49 30 N 23 00 E
Galicia (region) Spain 42 45 N 8 10 E
Galilee (region) Israel 32 54 N 35 20 E
Galleons Passage Atlantic Ocean 11 00 N 60 55 W
Gambier Islands (Iles French Polynesia 23 09 S 134 58 W
Gambier)
Gaspar Strait Pacific Ocean 3 00 S 107 00 E
Gdansk (city; formerly Poland 54 23 N 18 40 E
Danzig)
Geneva (city) Switzerland 46 12 N 6 10 E
Genoa (city) Italy 44 25 N 8 57 E
George Town (capital) Cayman Islands 19 20 N 81 23 W
George Town (city) Malaysia 5 26 N 100 16 E
George Town (city) The Bahamas 23 30 N 75 46 W
Georgetown (capital) Guyana 6 48 N 58 10 W
Georgetown (city) The Gambia 13 30 N 14 47 W
German Democratic Germany 52 00 N 13 00 E
Republic (East Germany;
former name for eastern
portion of Germany)
German Southwest Africa Namibia 22 00 S 17 00 E
(former name for Namibia)
Germany, Federal Republic Germany 51 00 N 9 00 E
of
Gibraltar (city, Gibraltar 36 11 N 5 22 W
peninsula)
Gibraltar, Strait of Atlantic Ocean 35 57 N 5 36 W
Gidi Pass Egypt 30 13 N 33 09 E
Gilbert Islands Kiribati 1 25 N 173 00 E
Goa (state) India 15 20 N 74 00 E
Gobi (desert) China, Mongolia 42 30 N 107 00 E
Godthab (capital; also Greenland 64 11 N 51 44 W
Nuuk)
Golan Heights (region) Syria 33 00 N 35 45 E
Gold Coast (former name Ghana 8 00 N 2 00 W
for Ghana)
Golfo San Jorge (gulf) Atlantic Ocean 46 00 S 66 00 W
Golfo San Matias (gulf) Atlantic Ocean 41 30 S 64 00 W
Good Hope, Cape of South Africa 34 24 S 18 30 E
Goteborg (city) Sweden 57 43 N 11 58 E
Gotland (island) Sweden 57 30 N 18 33 E
Gough Island Saint Helena 40 20 S 9 55 W
Graham Land (region) Antarctica 65 00 S 64 00 W
Gran Chaco (region) Argentina, Paraguay 24 00 S 60 00 W
Grand Bahama (island) The Bahamas 26 40 N 78 35 W
Grand Banks (fishing Atlantic Ocean 47 06 N 55 48 W
ground)
Grand Cayman (island) Cayman Islands 19 20 N 81 20 W
Grand Turk (capital; also Turks and Caicos 21 28 N 71 08 W
Cockburn Town) Islands
Great Australian Bight Indian Ocean 35 00 S 130 00 E
Great Belt (strait; also Atlantic Ocean 55 30 N 11 00 E
Store Baelt)
Great Bitter Lake Egypt 30 20 N 32 23 E
Great Britain (island) United Kingdom 54 00 N 2 00 W
Great Channel Indian Ocean 6 25 N 94 20 E
Great Inagua (island) The Bahamas 21 00 N 73 20 W
Great Rift Valley Ethiopia, Kenya 0 30 N 36 00 E
Greater Sunda Islands Brunei, Indonesia, 2 00 S 110 00 E','f54425f96c382e7ba917056b59d5ae98430ae320a1ff7ffd0455f46d157c95fc','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('065002c47c0c543eafc33370e804051d526002f10f441456314ab81c8d1bbd3c',2007,'NC','New Caledonia','environment',692,'Settled by both Britain and France during the first
half of the 19th century, the island was made a French possession in
1853. It served as a penal colony for four decades after 1864.
Agitation for independence during the 1980s and early 1990s ended in
the 1998 Noumea Accord, which over a period of 15 to 20 years will
transfer an increasing amount of governing responsibility from
France to New Caledonia. The agreement also commits France to
conduct as many as three referenda between 2013 and 2018, to decide
whether New Caledonia should assume full sovereignty and
independence.','fa503e1aba84c2a64b9655b24e191edc12fdf5878e3aa1d18c20e8102848b788','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3ca4e00597cd06fcf15a3fea32b37c7037fb3534e3e10063c66621b129cabc68',2007,'NZ','New Zealand','environment',693,'The Polynesian Maori reached New Zealand in about A.D.
800. In 1840, their chieftains entered into a compact with Britain,
the Treaty of Waitangi, in which they ceded sovereignty to Queen
Victoria while retaining territorial rights. In that same year, the
British began the first organized colonial settlement. A series of
land wars between 1843 and 1872 ended with the defeat of the native
peoples. The British colony of New Zealand became an independent
dominion in 1907 and supported the UK militarily in both World Wars.
New Zealand''s full participation in a number of defense alliances
lapsed by the 1980s. In recent years, the government has sought to
address longstanding Maori grievances.','ec6b4b39d110b05252376bb4fce9bc44b3e3953c94f405f20c831c64845904a0','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3844e31b153ffc0b63e8ecad502d904e4b02dfb61febdfc4449933015f9a8e97',2007,'NI','Nicaragua','environment',694,'The Pacific coast of Nicaragua was settled as a Spanish
colony from Panama in the early 16th century. Independence from
Spain was declared in 1821 and the country became an independent
republic in 1838. Britain occupied the Caribbean Coast in the first
half of the 19th century, but gradually ceded control of the region
in subsequent decades. Violent opposition to governmental
manipulation and corruption spread to all classes by 1978 and
resulted in a short-lived civil war that brought the Marxist
Sandinista guerrillas to power in 1979. Nicaraguan aid to leftist
rebels in El Salvador caused the US to sponsor anti-Sandinista
contra guerrillas through much of the 1980s. Free elections in 1990,
1996, and 2001, saw the Sandinistas defeated, but voting in 2006
announced the return of former Sandinista President Daniel ORTEGA
Saavedra. Nicaragua''s infrastructure and economy - hard hit by the
earlier civil war and by Hurricane Mitch in 1998 - are slowly being
rebuilt.','dfc93b76854499146646da0fa730f69460aa524dc3e38f1dc6cac9cf59555801','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6b70c58bdba4554f103326a4f6c0443a8fc90669bb3123b03e971d36c537cec',2007,'NE','Niger','environment',695,'Niger became independent from France in 1960 and experienced
single-party and military rule until 1991, when Gen. Ali SAIBOU was
forced by public pressure to allow multiparty elections, which
resulted in a democratic government in 1993. Political infighting
brought the government to a standstill and in 1996 led to a coup by
Col. Ibrahim BARE. In 1999 BARE was killed in a coup by military
officers who promptly restored democratic rule and held elections
that brought Mamadou TANDJA to power in December of that year.
TANDJA was reelected in 2004. Niger is one of the poorest countries
in the world with minimal government services and insufficient funds
to develop its resource base. The largely agrarian and
subsistence-based economy is frequently disrupted by extended
droughts common to the Sahel region of Africa.','5b426751b17e0508542c373acee6cc6246a3bd1fc4db948aad2cf54153eb88be','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08282e0419c841660dcda456999520f8b17776790d8b33f2abbc06028ffde148',2007,'NG','Nigeria','environment',696,'British influence and control over what would become Nigeria
grew through the 19th century. A series of constitutions after World
War II granted Nigeria greater autonomy; independence came in 1960.
Following nearly 16 years of military rule, a new constitution was
adopted in 1999, and a peaceful transition to civilian government
was completed. The president faces the daunting task of reforming a
petroleum-based economy, whose revenues have been squandered through
corruption and mismanagement, and institutionalizing democracy. In
addition, the OBASANJO administration must defuse longstanding
ethnic and religious tensions, if it is to build a sound foundation
for economic growth and political stability. Although the April 2003
elections were marred by some irregularities, Nigeria is currently
experiencing its longest period of civilian rule since independence.
The general elections set for April 2007 would mark the first
civilian-to-civilian transfer of power in the country''s history.','19a18ac2a3750911ed0e71e77ff459a3c2c200cc576ce01c1c0ce15e856840ac','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0f6c14a6d647b0bd813de5e37cb235df99e0b182a26638940a08b8ba2a0e03c',2007,'NU','Niue','environment',697,'Niue''s remoteness, as well as cultural and linguistic
differences between its Polynesian inhabitants and those of the rest
of the Cook Islands, have caused it to be separately administered.
The population of the island continues to drop (from a peak of 5,200
in 1966 to about 2,166 in 2006), with substantial emigration to New
Zealand, 2,400 km to the southwest.','8c7e7b4506700b7d40ac516c63d8f91b208d37e63a3e9e6ddfc982b79d225fe2','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('609b7789f91fce3d7ec85d8a4acfa45f25010332dc54f3c62305267f60396bf4',2007,'NF','Norfolk Island','environment',698,'Two British attempts at establishing the island as a
penal colony (1788-1814 and 1825-55) were ultimately abandoned. In
1856, the island was resettled by Pitcairn Islanders, descendants of
the Bounty mutineers and their Tahitian companions.','b5792bea0eb28cdfdc5f9f5704d371bddacd77e91ad4b00110d29f885329c4e0','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10ebb5e0d0908292353e13b54afbf4c26b7049553d1a5ce63e75620c7b783fa8',2007,'MP','Northern Mariana Islands','environment',699,'Under US administration as part of the UN
Trust Territory of the Pacific, the people of the Northern Mariana
Islands decided in the 1970s not to seek independence but instead to
forge closer links with the US. Negotiations for territorial status
began in 1972. A covenant to establish a commonwealth in political
union with the US was approved in 1975, and came into force on 24
March 1976. A new government and constitution went into effect in
1978.','097823873fce1b00b1e7ff1f676632ee6c2ac4b24002720ce349a5dd19d2957c','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('10dc900d229ce801de86b375d6bde4897e86d463946b391ec9c0d7254c67f57d',2007,'NO','Norway','environment',700,'Two centuries of Viking raids into Europe tapered off
following the adoption of Christianity by King Olav TRYGGVASON in
994. Conversion of the Norwegian kingdom occurred over the next
several decades. In 1397, Norway was absorbed into a union with
Denmark that lasted more than four centuries. In 1814, Norwegians
resisted the cession of their country to Sweden and adopted a new
constitution. Sweden then invaded Norway but agreed to let Norway
keep its constitution in return for accepting the union under a
Swedish king. Rising nationalism throughout the 19th century led to
a 1905 referendum granting Norway independence. Although Norway
remained neutral in World War I, it suffered heavy losses to its
shipping. Norway proclaimed its neutrality at the outset of World
War II, but was nonetheless occupied for five years by Nazi Germany
(1940-45). In 1949, neutrality was abandoned and Norway became a
member of NATO. Discovery of oil and gas in adjacent waters in the
late 1960s boosted Norway''s economic fortunes. The current focus is
on containing spending on the extensive welfare system and planning
for the time when petroleum reserves are depleted. In referenda held
in 1972 and 1994, Norway rejected joining the EU.','3b188284c85937567f6cf887b8aec50231251bb85b0163f6d3039170e9a34654','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('314a686f44078e892aee008a175db57f13a72cf5bb1d22f91648a99fa1b29672',2007,'OM','Oman','environment',701,'The inhabitants of the area of Oman have long prospered on
Indian Ocean trade. In the late 18th century, a newly established
sultanate in Muscat signed the first in a series of friendship
treaties with Britain. Over time, Oman''s dependence on British
political and military advisors increased, but it never became a
British colony. In 1970, QABOOS bin Said al-Said overthrew the
restrictive rule of his father; he has ruled as sultan ever since.
His extensive modernization program has opened the country to the
outside world while preserving the longstanding close ties with the
UK. Oman''s moderate, independent foreign policy has sought to
maintain good relations with all Middle Eastern countries.
Pacific Ocean
The Pacific Ocean is the largest of the world''s five
oceans (followed by the Atlantic Ocean, Indian Ocean, Southern
Ocean, and Arctic Ocean). Strategically important access waterways
include the La Perouse, Tsugaru, Tsushima, Taiwan, Singapore, and
Torres Straits. The decision by the International Hydrographic
Organization in the spring of 2000 to delimit a fifth ocean, the
Southern Ocean, removed the portion of the Pacific Ocean south of 60
degrees south.','b0d111f3a9047d20412529aeedd14037cd421064c615e9b31395a2032cb191ff','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6dce488527f486b5d9584dcd1324f2caf2a7d6316ae05c2b78f6eedb01baa3af',2007,'PK','Pakistan','environment',702,'The separation in 1947 of British India into the Muslim
state of Pakistan (with two sections West and East) and largely
Hindu India was never satisfactorily resolved, and India and
Pakistan fought two wars - in 1947-48 and 1965 - over the disputed
Kashmir territory. A third war between these countries in 1971 - in
which India capitalized on Islamabad''s marginalization of Bengalis
in Pakistani politics - resulted in East Pakistan becoming the
separate nation of Bangladesh. In response to Indian nuclear weapons
testing, Pakistan conducted its own tests in 1998. The dispute over
the state of Kashmir is ongoing, but discussions and
confidence-building measures have led to decreased tensions since
2002.','af50a6379cc49dae716e75cb5e1db01105fb8e5425607cccec48bc790233f290','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8f2daf14c8e09d5f667e60a122fcad06c3037751355092f33a6000eb548f4e7',2007,'PW','Palau','environment',703,'After three decades as part of the UN Trust Territory of the
Pacific under US administration, this westernmost cluster of the
Caroline Islands opted for independence in 1978 rather than join the
Federated States of Micronesia. A Compact of Free Association with
the US was approved in 1986, but not ratified until 1993. It entered
into force the following year, when the islands gained independence.
Palmyra Atoll
The Kingdom of Hawaii claimed the atoll in 1862, and
the US included it among the Hawaiian Islands when it annexed the
archipelago in 1898. The Hawaii Statehood Act of 1959 did not
include Palmyra Atoll, which is now privately owned by the Nature
Conservancy. This organization is managing the atoll as a nature
preserve. The lagoons and surrounding waters within the 12 nautical
mile US territorial seas were transferred to the US Fish and
Wildlife Service and were designated a National Wildlife Refuge in
January 2001.','2e6286d55cd2bf3cbdeb70218a078f2f0ada04bfc33a045cb59e34f4d0c5c04d','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('df180105d6e647c11b96306f83eddc988edb5e3d3e141e2e603a57c5f7e15162',2007,'PA','Panama','environment',704,'Explored and settled by the Spanish in the 16th century,
Panama broke with Spain in 1821 and joined a union of Colombia,
Venezuela, and Ecuador - named the Republic of Gran Colombia. When
the latter dissolved in 1830, Panama remained part of Colombia. With
US backing, Panama seceded from Colombia in 1903 and promptly signed
a treaty with the US allowing for the construction of a canal and US
sovereignty over a strip of land on either side of the structure
(the Panama Canal Zone). The Panama Canal was built by the US Army
Corps of Engineers between 1904 and 1914. In 1977, an agreement was
signed for the complete transfer of the Canal from the US to Panama
by the end of the century. Certain portions of the Zone and
increasing responsibility over the Canal were turned over in the
subsequent decades. With US help, dictator Manuel NORIEGA was
deposed in 1989. The entire Panama Canal, the area supporting the
Canal, and remaining US military bases were transfered to Panama by
the end of 1999. In October 2006, Panamanians approved an ambitious
plan to expand the Canal. The project, which is to begin in 2007 and
could double the Canal''s capacity, is expected to be completed in
2014-15.','9bcd0f8c29820419d6a427d94b0a8c82de1dfe1cf7a4ecd9fc363cdeb57967db','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fc7d922070af06ee71ad442106a9353f6d1191532dcb4c3fada2389f7ee24091',2007,'PG','Papua New Guinea','environment',705,'The eastern half of the island of New Guinea -
second largest in the world - was divided between Germany (north)
and the UK (south) in 1885. The latter area was transferred to
Australia in 1902, which occupied the northern portion during World
War I and continued to administer the combined areas until
independence in 1975. A nine-year secessionist revolt on the island
of Bougainville ended in 1997 after claiming some 20,000 lives.
Paracel Islands
The Paracel Islands are surrounded by productive
fishing grounds and by potential oil and gas reserves. In 1932,
French Indochina annexed the islands and set up a weather station on
Pattle Island; maintenance was continued by its successor, Vietnam.
China has occupied the Paracel Islands since 1974, when its troops
seized a South Vietnamese garrison occupying the western islands.
The islands are claimed by Taiwan and Vietnam.','5f3ed9f413b85c6ba29da1b4c9bd28c30e485cd28a4a7b06df39cd02b655b4de','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c3ebdd57d25dec37f2e7f6f2ffc088f559a3b7ebfc57774f68a9b2881754cc4',2007,'PY','Paraguay','environment',706,'In the disastrous War of the Triple Alliance (1865-70),
Paraguay lost two-thirds of all adult males and much of its
territory. It stagnated economically for the next half century. In
the Chaco War of 1932-35, large, economically important areas were
won from Bolivia. The 35-year military dictatorship of Alfredo
STROESSNER was overthrown in 1989, and, despite a marked increase in
political infighting in recent years, relatively free and regular
presidential elections have been held since then.','8f6166fde83f362a6051a1d488f0b4696689dc67246a400e4a9c96ec29a45df4','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('511919f706ec3fbc5575194468b0ba94f25de01119aa386d2beadbc7796e7229',2007,'PE','Peru','environment',707,'Ancient Peru was the seat of several prominent Andean
civilizations, most notably that of the Incas whose empire was
captured by the Spanish conquistadors in 1533. Peruvian independence
was declared in 1821, and remaining Spanish forces defeated in 1824.
After a dozen years of military rule, Peru returned to democratic
leadership in 1980, but experienced economic problems and the growth
of a violent insurgency. President Alberto FUJIMORI''s election in
1990 ushered in a decade that saw a dramatic turnaround in the
economy and significant progress in curtailing guerrilla activity.
Nevertheless, the president''s increasing reliance on authoritarian
measures and an economic slump in the late 1990s generated mounting
dissatisfaction with his regime, which led to his ouster in 2000. A
caretaker government oversaw new elections in the spring of 2001,
which ushered in Alejandro TOLEDO as the new head of government -
Peru''s first democratically elected president of Native American
ethnicity. The presidential election of 2006 saw the return of Alan
GARCIA who, after a disappointing presidential term from 1985 to
1990, returned to the presidency with promises to improve social
conditions and maintain fiscal responsibility.','ab3bd3d74aea4d74d509d5d430fa62051676d9c1987146261bfd297b45f6f4d4','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7a5fedd067917535c9f2bc29bcee47ef3607cf27399d9c9e3c847bbf2787b517',2007,'PH','Philippines','environment',708,'The Philippine Islands became a Spanish colony during
the 16th century; they were ceded to the US in 1898 following the
Spanish-American War. In 1935 the Philippines became a
self-governing commonwealth. Manuel QUEZON was elected President and
was tasked with preparing the country for independence after a
10-year transition. In 1942 the islands fell under Japanese
occupation during WWII, and US forces and Filipinos fought together
during 1944-45 to regain control. On 4 July 1946 the Philippines
attained their independence. The 20-year rule of Ferdinand MARCOS
ended in 1986, when a widespread popular rebellion forced him into
exile and installed Corazon AQUINO as president. Her presidency was
hampered by several coup attempts, which prevented a return to full
political stability and economic development. Fidel RAMOS was
elected president in 1992 and his administration was marked by
greater stability and progress on economic reforms. In 1992, the US
closed its last military bases on the islands. Joseph ESTRADA was
elected president in 1998, but was succeeded by his vice-president,
Gloria MACAPAGAL-ARROYO, in January 2001 after ESTRADA''s stormy
impeachment trial on corruption charges broke down and widespread
demonstrations led to his ouster. MACAPAGAL-ARROYO was elected to a
six-year term in May 2004. The Philippine Government faces threats
from an armed Communist insurgency and from Muslim separatists in
the south, as well as from impeachment attempts by political elites
and civil groups unhappy with the current administration.
Pitcairn Islands
Pitcairn Island was discovered in 1767 by the
British and settled in 1790 by the Bounty mutineers and their
Tahitian companions. Pitcairn was the first Pacific island to become
a British colony (in 1838) and today remains the last vestige of
that empire in the South Pacific. Outmigration, primarily to New
Zealand, has thinned the population from a peak of 233 in 1937 to
less than 50 today.','b39dba2662ee63d1918e94856a0e0a61b6f6c49bfe764e07015340aca66d252f','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f9db6a3bd074092f2d5e4399584c00c5f7fb1d741a490f9085f2b64e0e07f250',2007,'PL','Poland','environment',709,'Poland is an ancient nation that was conceived near the
middle of the 10th century. Its golden age occurred in the 16th
century. During the following century, the strengthening of the
gentry and internal disorders weakened the nation. In a series of
agreements between 1772 and 1795, Russia, Prussia, and Austria
partitioned Poland amongst themselves. Poland regained its
independence in 1918 only to be overrun by Germany and the Soviet
Union in World War II. It became a Soviet satellite state following
the war, but its government was comparatively tolerant and
progressive. Labor turmoil in 1980 led to the formation of the
independent trade union "Solidarity" that over time became a
political force and by 1990 had swept parliamentary elections and
the presidency. A "shock therapy" program during the early 1990s
enabled the country to transform its economy into one of the most
robust in Central Europe, but Poland still faces the lingering
challenges of high unemployment, underdeveloped and dilapidated
infrastructure, and a poor rural underclass. Solidarity suffered a
major defeat in the 2001 parliamentary elections when it failed to
elect a single deputy to the lower house of Parliament, and the new
leaders of the Solidarity Trade Union subsequently pledged to reduce
the Trade Union''s political role. Poland joined NATO in 1999 and the
European Union in 2004. With its transformation to a democratic,
market-oriented country largely completed, Poland is an increasingly
active member of Euro-Atlantic organizations.','aae5bc64086c560fb4a4765f65dd2e8e9f8af5b03fec69bd95152d439434c066','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('648308776ed44409bcd6fa21c87e08a5d7eb586642ffe5887a49cd3cdcb9a4a4',2007,'PT','Portugal','environment',710,'Following its heyday as a world power during the 15th and
16th centuries, Portugal lost much of its wealth and status with the
destruction of Lisbon in a 1755 earthquake, occupation during the
Napoleonic Wars, and the independence in 1822 of Brazil as a colony.
A 1910 revolution deposed the monarchy; for most of the next six
decades, repressive governments ran the country. In 1974, a
left-wing military coup installed broad democratic reforms. The
following year, Portugal granted independence to all of its African
colonies. Portugal is a founding member of NATO and entered the EC
(now the EU) in 1986.','ac6431d58f560d688d68cdb163f115916c3244228eac2ec56453997c48901eef','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da50828bad68ef52484e0c00abe90abc918bc1f66383d98cb39c758166974d2d',2007,'PR','Puerto Rico','environment',711,'Populated for centuries by aboriginal peoples, the
island was claimed by the Spanish Crown in 1493 following COLUMBUS''
second voyage to the Americas. In 1898, after 400 years of colonial
rule that saw the indigenous population nearly exterminated and
African slave labor introduced, Puerto Rico was ceded to the US as a
result of the Spanish-American War. Puerto Ricans were granted US
citizenship in 1917. Popularly-elected governors have served since
1948. In 1952, a constitution was enacted providing for internal
self government. In plebiscites held in 1967, 1993, and 1998, voters
chose not to alter the existing political status.','c2b510c5c6b3816d97ce087a048dd6200cd75dae2f6bb2ceff49e5c726be4aee','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b8693a42157c2c625c8ced3704bbfca9e2cc83062c16baa049c5852845fe0c9e',2007,'QA','Qatar','environment',712,'Ruled by the al-Thani family since the mid-1800s, Qatar
transformed itself from a poor British protectorate noted mainly for
pearling into an independent state with significant oil and natural
gas revenues. During the late 1980s and early 1990s, the Qatari
economy was crippled by a continuous siphoning off of petroleum
revenues by the amir, who had ruled the country since 1972. His son,
the current Amir HAMAD bin Khalifa al-Thani, overthrew him in a
bloodless coup in 1995. In 2001, Qatar resolved its longstanding
border disputes with both Bahrain and Saudi Arabia. Oil and natural
gas revenues enable Qatar to have one of the highest per capita
incomes in the world.','a1342c60ed19566739b2b51027d197a0b225b345bd6d700962ed342649e8971d','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec08fc57f93a6007f958e48114fdb3be4b292d758b2b3943b7902f4a0e71b302',2007,'RO','Romania','environment',713,'The principalities of Wallachia and Moldavia - for centuries
under the suzerainty of the Turkish Ottoman Empire - secured their
autonomy in 1856; they united in 1859 and a few years later adopted
the new name of Romania. The country gained recognition of its
independence in 1878. It joined the Allied Powers in World War I and
acquired new territories - most notably Transylvania - following the
conflict. In 1940, Romania allied with the Axis powers and
participated in the 1941 German invasion of the USSR. Three years
later, overrun by the Soviets, Romania signed an armistice. The
post-war Soviet occupation led to the formation of a Communist
"people''s republic" in 1947 and the abdication of the king. The
decades-long rule of dictator Nicolae CEAUSESCU, who took power in
1965, and his Securitate police state became increasingly oppressive
and draconian through the 1980s. CEAUSESCU was overthrown and
executed in late 1989. Former Communists dominated the government
until 1996 when they were swept from power. Romania joined NATO in
2004 and the EU in 2007.
Russia
Founded in the 12th century, the Principality of Muscovy, was
able to emerge from over 200 years of Mongol domination (13th-15th
centuries) and to gradually conquer and absorb surrounding
principalities. In the early 17th century, a new Romanov Dynasty
continued this policy of expansion across Siberia to the Pacific.
Under PETER I (ruled 1682-1725), hegemony was extended to the Baltic
Sea and the country was renamed the Russian Empire. During the 19th
century, more territorial acquisitions were made in Europe and Asia.
Defeat in the Russo-Japanese War of 1904-1905 contributed to the
Revolution of 1905, which resulted in the formation of a parliament
and other reforms. Repeated devastating defeats of the Russian army
in World War I led to widespread rioting in the major cities of the
Russian Empire and to the overthrow in 1917 of the imperial
household. The Communists under Vladimir LENIN seized power soon
after and formed the USSR. The brutal rule of Iosif STALIN (1928-53)
strengthened Communist rule and Russian dominance of the Soviet
Union at a cost of tens of millions of lives. The Soviet economy and
society stagnated in the following decades until General Secretary
Mikhail GORBACHEV (1985-91) introduced glasnost (openness) and
perestroika (restructuring) in an attempt to modernize Communism,
but his initiatives inadvertently released forces that by December
1991 splintered the USSR into Russia and 14 other independent
republics. Since then, Russia has struggled in its efforts to build
a democratic political system and market economy to replace the
social, political, and economic controls of the Communist period.
While some progress has been made on the economic front, and
Russia''s management of its windfall oil wealth has improved its
financial standing, recent years have seen a recentralization of
power under Vladimir PUTIN and democratic institutions remain weak.
Russia has severely disabled the Chechen rebel movement, although
sporadic violence still occurs throughout the North Caucusus.','94ce0eb595bc9423b581b92989d69bd4d178cca500fb3714ee7f8478f3e86848','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb00056757960e1739e1441597a15bd9b0d9a9aba10eb6bf0e2c785b7fbf3fa7',2007,'RW','Rwanda','environment',714,'In 1959, three years before independence from Belgium, the
majority ethnic group, the Hutus, overthrew the ruling Tutsi king.
Over the next several years, thousands of Tutsis were killed, and
some 150,000 driven into exile in neighboring countries. The
children of these exiles later formed a rebel group, the Rwandan
Patriotic Front (RPF), and began a civil war in 1990. The war, along
with several political and economic upheavals, exacerbated ethnic
tensions, culminating in April 1994 in the genocide of roughly
800,000 Tutsis and moderate Hutus. The Tutsi rebels defeated the
Hutu regime and ended the killing in July 1994, but approximately 2
million Hutu refugees - many fearing Tutsi retribution - fled to
neighboring Burundi, Tanzania, Uganda, and the former Zaire. Since
then, most of the refugees have returned to Rwanda, but several
thousand remain in neighboring Democratic Republic of the Congo and
formed an extremist insurgency bent on retaking Rwanda, much as the
RPF tried in 1990. Despite substantial international assistance and
political reforms - including Rwanda''s first local elections in
March 1999 and its first post-genocide presidential and legislative
elections in August and September 2003 - the country continues to
struggle to boost investment and agricultural output, and ethnic
reconciliation is complicated by the real and perceived Tutsi
political dominance. Kigali''s increasing centralization and
intolerance of dissent, the nagging Hutu extremist insurgency across
the border, and Rwandan involvement in two wars in recent years in
the neighboring Democratic Republic of the Congo continue to hinder
Rwanda''s efforts to escape its bloody legacy.
Saint Helena
Saint Helena is a British Overseas Territory consisting
of Saint Helena and Ascension Islands, and the island group of
Tristan da Cunha.
Saint Helena: Uninhabited when first discovered by the Portuguese in
1502, Saint Helena was garrisoned by the British during the 17th
century. It acquired fame as the place of Napoleon BONAPARTE''s
exile, from 1815 until his death in 1821, but its importance as a
port of call declined after the opening of the Suez Canal in 1869.
During the Anglo-Boer War in South Africa, several thousand Boer
prisoners were confined on the island between 1900 and 1903.
Ascension Island: This barren and uninhabited island was discovered
and named by the Portuguese in 1503. The British garrisoned the
island in 1815 to prevent a rescue of Napoleon from Saint Helena and
it served as a provisioning station for the Royal Navy''s West Africa
Squadron on anti-slavery patrol. The island remained under Admiralty
control until 1922, when it became a dependency of Saint Helena.
During World War II, the UK permitted the US to construct an
airfield on Ascension in support of trans-Atlantic flights to Africa
and anti-submarine operations in the South Atlantic. In the 1960s
the island became an important space tracking station for the US. In
1982, Ascension was an essential staging area for British forces
during the Falklands War, and it remains a critical refueling point
in the air-bridge from the UK to the South Atlantic.
Tristan da Cunha: The island group consists of the islands of
Tristan da Cunha, Nightingale, Inaccessible, and Gough. Tristan da
Cunha is named after its Portuguese discoverer (1506); it was
garrisoned by the British in 1816 to prevent any attempt to rescue
Napoleon from Saint Helena. Gough and Inaccessible Islands have been
designated World Heritage Sites. South Africa leases the site for a
meteorological station on Gough Island.','43581a4973269bfe0ce682a6e6c59ac659cc20e46784ed8f1dbd2a237e6470b9','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf69c1316d75f7bc1d585d490f1e6296726287c6af4b5d2b00898f56a8fd54b6',2007,'KN','Saint Kitts and Nevis','environment',715,'First settled by the British in 1623, the
islands became an associated state with full internal autonomy in
1967. The island of Anguilla rebelled and was allowed to secede in
1971. Saint Kitts and Nevis achieved independence in 1983. In 1998,
a vote in Nevis on a referendum to separate from Saint Kitts fell
short of the two-thirds majority needed. Nevis continues in its
efforts to try and separate from Saint Kitts.','4005e955303a2a1611e7d4fd16c69ed6335e1d66de67413974b9c828c441d5db','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3766d1b13838a19b1ca891e5929aed4c2e02e0f1f7c078c18dff9d3026624060',2007,'LC','Saint Lucia','environment',716,'The island, with its fine natural harbor at Castries,
was contested between England and France throughout the 17th and
early 18th centuries (changing possession 14 times); it was finally
ceded to the UK in 1814. Even after the abolition of slavery on its
plantations in 1834, Saint Lucia remained an agricultural island,
dedicated to producing tropical commodity crops. Self-government was
granted in 1967 and independence in 1979.','1d0c32d42a8afd12001c64a8677d89280a046eec72aa32997d28e71bf6dbc96c','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2b089b4e6efca2f1afaee778a801277fce8d9d32b850c3fd2774525ba6d1f220',2007,'PM','Saint Pierre and Miquelon','environment',717,'First settled by the French in the early
17th century, the islands represent the sole remaining vestige of
France''s once vast North American possessions.','0c4731b8b8baef8e3a5f7d92166fbbf2ec715ba52a3e8e1e4d4b4c33a5de317f','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f167350aa78c081c4375aad1b9e47d9a39bcfd630780636d6571692f8d7e4d8b',2007,'VC','Saint Vincent and the Grenadines','environment',718,'Resistance by native Caribs
prevented colonization on St. Vincent until 1719. Disputed between
France and the United Kingdom for most of the 18th century, the
island was ceded to the latter in 1783. Between 1960 and 1962, Saint
Vincent and the Grenadines was a separate administrative unit of the
Federation of the West Indies. Autonomy was granted in 1969 and
independence in 1979.','ee85408415b9cd563d4a124b6e6c47872add6b5a631f5f18a7a3bbc3ed94d720','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b94987638595a33d81eca838a108be42f435d56c7f046ae57ef2103945cb3a1',2007,'WS','Samoa','environment',719,'New Zealand occupied the German protectorate of Western Samoa
at the outbreak of World War I in 1914. It continued to administer
the islands as a mandate and then as a trust territory until 1962,
when the islands became the first Polynesian nation to reestablish
independence in the 20th century. The country dropped the "Western"
from its name in 1997.
World - - - -
the Factbook uses the W data code from DIAM 65-18 Geopolitical Data
Elements and Related Features, Data Standard No. 3, December 1994,
published by the Defense Intelligence Agency
Yemen YM YE YEM 887 .ye
Zaire - - - -
see Democratic Republic of the Congo
Zambia ZA ZM ZMB 894 .zm
Zimbabwe ZI ZW ZWE 716 .zw
This page was last updated on 8 February, 2007
=====================================================================
Appendix E - Cross-Reference List of Hydrographic Data Codes
IHO 23-4th: Limits of Oceans and Seas, Special Publication 23, Draft
4th Edition 1986, published by the International Hydrographic Bureau of
the International Hydrographic Organization; note - this document has
not yet been ratified and only the 3rd Edition (1953) remains in force
IHO 23-3rd: Limits of Oceans and Seas, Special Publication 23, 3rd
Edition 1953, published by the International Hydrographic Organization
ACIC M 49-1: Chart of Limits of Seas and Oceans, revised January 1958,
published by the Aeronautical Chart and Information Center (ACIC),
United States Air Force; note - ACIC is now part of the National
Imagery and Mapping Agency (NIMA)
DIAM 65-18: Geopolitical Data Elements and Related Features, Data
Standard No. 4, Defense Intelligence Agency Manual 65-18, December
1994, published by the Defense Intelligence Agency
The US Government has not yet adopted a standard for hydrographic codes
similar to the Federal Information Processing Standards (FIPS) 10-4
country codes. The names and limits of the following oceans and seas
are not always directly comparable because of differences in the
customers, needs, and requirements of the individual organizations.
Even the number of principal water bodies varies from organization to
organization. Factbook users, for example, find the Atlantic Ocean and
Pacific Ocean entries useful, but none of the following standards
include those oceans in their entirety. Nor is there any provision for
combining codes or overcodes to aggregate water bodies. The recently
delimited Southern Ocean is not included.
Principal Oceans and Seas of the World
With Hydrographic Codes by Institution
IHO 23-4th IHO 23-3rd* ACIC M 49-1 DIAM 65-18
Arctic Ocean 9 17 A 5A
Atlantic Ocean - - - -
Baltic Sea 2 1 B26 7B
Eastern Mediterranean 3.1.2 28 B - 8E
Indian Ocean 5 45 F 6A
Mediterranean Sea 3.1 28 B11 -
North Atlantic Ocean 1 23 B 1A
North Pacific Ocean 7 57 D 3A
Pacific Ocean - - - -
South Atlantic Ocean 4 32 C 2A
South China and Eastern
Archipelagic Seas 6 49, 48 D18 plus 3U plus
others others
South Pacific Ocean 8 61 E 4A
Western Mediterranean 3.1.1 28 A - 8W
*The letters after the numbers are subdivisions, not footnotes.
This page was last updated on 8 February, 2007
=====================================================================
Appendix F - Cross-Reference List of Geographic Names
Name Entry in The World Latitude Longitude
Factbook (deg min) (deg min)
Abidjan (capital) Cote d''Ivoire 5 19 N 4 02 W
Abkhazia (region) Georgia 43 00 N 41 00 E
Abu Dhabi (capital) United Arab 24 28 N 54 22 E
Emirates
Abu Musa (island) Iran 25 52 N 55 03 E
Abuja (capital) Nigeria 9 12 N 7 11 E
Abyssinia (former name Ethiopia 8 00 N 38 00 E
for Ethiopia)
Acapulco (city) Mexico 16 51 N 99 55 W
Accra (capital) Ghana 5 33 N 0 13 W
Adamstown (capital) Pitcairn Islands 25 04 S 130 05 W
Addis Ababa (capital) Ethiopia 9 02 N 38 42 E
Adelie Land (claimed by Antarctica 66 30 S 139 00 E
France; also Terre
Adelie)
Aden (city) Yemen 12 46 N 45 01 E
Aden, Gulf of Indian Ocean 12 30 N 48 00 E
Admiralty Island United States 57 44 N 134 20 W
(Alaska)
Admiralty Islands Papua New Guinea 2 10 S 147 00 E
Adriatic Sea Atlantic Ocean 42 30 N 16 00 E
Adygey (region) Russia 44 30 N 40 10 E
Aegean Islands Greece 38 00 N 25 00 E
Aegean Sea Atlantic Ocean 38 30 N 25 00 E
Afars and Issas, French Djibouti 11 30 N 43 00 E
Territory of the (or
FTAI; former name for
Djibouti)
Afghanestan (local name Afghanistan 33 00 N 65 00 E
for Afghanistan)
Agalega Islands Mauritius 10 25 S 56 40 E
Agana (city; former name Guam 13 28 N 144 45 E
for Hagatna)
Ajaccio (city) France (Corsica) 41 55 N 8 44 E
Ajaria (region) Georgia 41 45 N 42 10 E
Akmola (city; former name Kazakhstan 51 10 N 71 30 E
for Astana)
Aksai Chin (region) China (de facto), 35 00 N 79 00 E
India (claimed)
Al Arabiyah as Suudiyah Saudi Arabia 25 00 N 45 00 E
(local name for Saudi
Arabia)
Al Bahrayn (local name Bahrain 26 00 N 50 33 E
for Bahrain)
Al Imarat al Arabiyah al United Arab 24 00 N 54 00 E
Muttahidah (local name Emirates
for the United Arab
Emirates)
Al Iraq (local name for Iraq 33 00 N 44 00 E
Iraq)
Al Jaza''ir (local name Algeria 28 00 N 3 00 E
for Algeria)
Al Kuwayt (local name for Kuwait 29 30 N 45 45 E
Kuwait)
Al Maghrib (local name Morocco 32 00 N 5 00 W
for Morocco)
Al Urdun (local name for Jordan 31 00 N 36 00 E
Jordan)
Al Yaman (local name for Yemen 15 00 N 48 00 E
Yemen)
Aland Islands Finland 60 15 N 20 00 E
Alaska (state) United States 65 00 N 153 00 W
Alaska, Gulf of Pacific Ocean 58 00 N 145 00 W
Alboran Sea Atlantic Ocean 36 00 N 2 30 W
Aldabra Islands (Groupe Seychelles 9 25 S 46 22 E
d''Aldabra)
Alderney (island) Guernsey 49 43 N 2 12 W
Aleutian Islands United States 52 00 N 176 00 W
(Alaska)
Alexander Archipelago United States 57 00 N 134 00 W
(island group) (Alaska)
Alexander Island Antarctica 71 00 S 70 00 W
Alexandretta (region; Turkey 36 34 N 36 08 E
former name for
Iskenderun)
Alexandria (city) Egypt 31 12 N 29 54 E
Algiers (capital) Algeria 36 47 N 2 03 E
Alhucemas, Penon de Spain 35 13 N 3 53 W
(island group)
Alma-Ata (city; former Kazakhstan 43 15 N 76 57 E
name for Almaty)
Almaty (former capital) Kazakhstan 43 15 N 76 57 E
Alofi (capital) Niue 19 01 S 169 55 W
Alphonse Island Seychelles 7 01 S 52 45 E
Alsace (region) France 48 30 N 7 20 E
Amami Strait Pacific Ocean 28 40 N 129 30 E
Amindivi Islands (former India 11 30 N 72 30 E
name for Laccadive
Islands)
Amirante Isles (island Seychelles 6 00 S 53 10 E
group; also Les
Amirantes)
Amman (capital) Jordan 31 57 N 35 56 E
Amsterdam (capital) Netherlands 52 23 N 4 54 E
Amsterdam Island (Ile French Southern and 37 52 S 77 32 E
Amsterdam) Antarctic Lands
Amundsen Sea Southern Ocean 72 30 S 112 00 W
Amur River China, Russia 52 56 N 141 10 E
Amurskiy Liman (strait) Pacific Ocean 53 00 N 141 30 E
Anadyrskiy Zaliv (gulf) Pacific Ocean 64 00 N 177 00 E
Anatolia (region) Turkey 39 00 N 35 00 E
Andaman Islands India 12 00 N 92 45 E
Andaman Sea Indian Ocean 10 00 N 95 00 E
Andorra la Vella Andorra 42 30 N 1 30 E
(capital)
Andros (island) Greece 37 45 N 24 42 E
Andros Island The Bahamas 24 26 N 77 57 W
Anegada Passage Atlantic Ocean 18 30 N 63 40 W
Angkor Wat (ruins) Cambodia 13 26 N 103 50 E
Anglo-Egyptian Sudan Sudan 15 00 N 30 00 E
(former name for Sudan)
Anjouan (island) Comoros 12 15 S 44 25 E
Ankara (capital) Turkey 39 56 N 32 52 E
Annobon (island) Equatorial Guinea 1 25 S 5 36 E
Antananarivo (capital) Madagascar 18 52 S 47 30 E
Antigua (island) Antigua and Barbuda 14 34 N 90 44 W
Antipodes Islands New Zealand 49 41 S 178 43 E
Antwerp (city) Belgium 51 13 N 4 25 E
Aomen (local Chinese Macau 22 10 N 113 33 E
short-form name for
Macau)
Aozou Strip (region) Chad 22 00 N 18 00 E
Apia (capital) Samoa 13 50 S 171 45W
Aqaba, Gulf of Indian Ocean 29 00 N 34 30 E
Arab, Shatt al (river) Iran, Iraq 29 57 N 48 34 E
Arabian Sea Indian Ocean 15 00 N 65 00 E
Arafura Sea Pacific Ocean 9 00 S 133 00 E
Aral Sea Kazakhstan, 45 00 N 60 00 E','283041f62588bb52beb72ab803b97f7fb83d76b0a2e406f18bd4c08cdbc5a10f','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87da0939b0386ccd8425a6d195efd317ec54b11c63ff72d886e11336c42299cf',2007,'SM','San Marino','environment',720,'The third smallest state in Europe (after the Holy See
and Monaco), San Marino also claims to be the world''s oldest
republic. According to tradition, it was founded by a Christian
stonemason named Marino in A.D. 301. San Marino''s foreign policy is
aligned with that of Italy; social and political trends in the
republic also track closely with those of its larger neighbor.','71b1b235553d7ee37d2303f76507e904f73a6cd2dfc74d0928ede05d62f98524','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1e0213f5a25d6334ae123c8d091283866c1e7529899960d7f317a44a7c7b3f0',2007,'ST','Sao Tome and Principe','environment',721,'Discovered and claimed by Portugal in the late
15th century, the islands'' sugar-based economy gave way to coffee
and cocoa in the 19th century - all grown with plantation slave
labor, a form of which lingered into the 20th century. Although
independence was achieved in 1975, democratic reforms were not
instituted until the late 1980s. Though the first free elections
were held in 1991, the political environment has been one of
continued instability with frequent changes in leadership and coup
attempts in 1995 and 2003. The recent discovery of oil in the Gulf
of Guinea is likely to have a significant impact on the country''s','c7abdf867474f5215a782bb1137b71703cb7232f18beffced176bdf4e6129e0f','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dfb522d1d54b75da382fb7ca09e858bbd8478d0b52e988f33be74ddcdf6d2825',2007,'ZW','Zimbabwe','environment',1121,'members - (8) Canada, Denmark (Greenland, Faroe Islands), Finland,
Iceland, Norway, Russia, Sweden, US
permanent participants - (6) Aleut International Association, Arctic
Athabaskan Council, Gurch''in Council International, Inuit Circumpolar
Conference, Russian Association of Indigenous People of the North,
Saami Council
observers - (5) France, Germany, Netherlands, Poland, UK
ASEAN Regional Forum (ARF): established - 25 July 1994
aim - to foster constructive dialogue and consultation on political and
security issues of common interest and concern
members - (26) Australia, Bangladesh, Brunei, Burma, Cambodia, Canada,
China, East Timor, EU, India, Indonesia, Japan, North Korea, South
Korea, Laos, Malaysia, Mongolia, NZ, Pakistan, Papua New Guinea,
Philippines, Russia, Singapore, Thailand, US, Vietnam
Asian Development Bank (AsDB): established - 19 December 1966
aim - to promote regional economic cooperation
members - (47) Afghanistan, Armenia, Australia, Azerbaijan, Bangladesh,
Bhutan, Brunei, Burma, Cambodia, China, Cook Islands, East Timor, Fiji,
Hong Kong, India, Indonesia, Japan, Kazakhstan, Kiribati, South Korea,
Kyrgyzstan, Laos, Malaysia, Maldives, Marshall Islands, Federated
States of Micronesia, Mongolia, Nauru, Nepal, NZ, Pakistan, Palau,
Papua New Guinea, Philippines, Samoa, Singapore, Solomon Islands, Sri
Lanka, Taiwan, Tajikistan, Thailand, Tonga, Turkmenistan, Tuvalu,
Uzbekistan, Vanuatu, Vietnam
nonregional members - (19) Austria, Belgium, Canada, Denmark, Finland,
France, Germany, Ireland, Italy, Luxembourg, Netherlands, Norway,
Portugal, Spain, Sweden, Switzerland, Turkey, UK, US
Asia-Pacific Economic Cooperation (APEC): established - 7 November
1989
aim - to promote trade and investment in the Pacific basin
members - (21) Australia, Brunei, Canada, Chile, China, Hong Kong,
Indonesia, Japan, South Korea, Malaysia, Mexico, NZ, Papua New Guinea,
Peru, Philippines, Russia, Singapore, Taiwan, Thailand, US, Vietnam
observers - (3) Association of Southeast Asian Nations, Pacific
Economic Cooperation Council, Pacific Islands Forum Secretariat
Association of Southeast Asian Nations (ASEAN): established - 8 August
1967
aim - to encourage regional economic, social, and cultural cooperation
among the non-Communist countries of Southeast Asia
members - (10) Brunei, Burma, Cambodia, Indonesia, Laos, Malaysia,
Philippines, Singapore, Thailand, Vietnam
dialogue partners - (12) Australia, Canada, China, EU, India, Japan,
South Korea, NZ, Pakistan, Russia, US, UNDP
observers - (1) Papua New Guinea
Australia Group: established - June 1985
aim - to consult on and coordinate export controls related to chemical
and biological weapons
members - (40) Argentina, Australia, Austria, Belgium, Bulgaria,
Canada, Cyprus, Czech Republic, Denmark, Estonia, European Commission,
Finland, France, Germany, Greece, Hungary, Iceland, Ireland, Italy,
Japan, South Korea, Latvia, Lithuania, Luxembourg, Malta, Netherlands,
NZ, Norway, Poland, Portugal, Romania, Slovakia, Slovenia, Spain,
Sweden, Switzerland, Turkey, Ukraine, UK, US
Australia-New Zealand-United States Security Treaty (ANZUS):
established - 1 September 1951; effective - 29 April 1952
aim - to implement a trilateral mutual security agreement, although the
US suspended security obligations to NZ on 11 August 1986; Australia
and the US continue to hold annual meetings
members - (3) Australia, NZ, US
Baltic Assembly (BA): established - 12 May 1990
aim - to thoroughly discuss various cooperation issues between Baltic
states
members - (3) Estonia, Latvia, Lithuania
Bay of Bengal Iniative for Multisectoral Technical and Economic
Coopertion (BIMSTEC): established - June 1997
aim - to foster socio-economic cooperation among members
members - (7) Bangladesh, Bhutan, Burma, India, Nepal, Sri Lanka,
International Bank for Reconstruction and Development (IBRD): note -
also known as the World Bank
established - 22 July 1944; effective - 27 December 1945
aim - to provide economic development loans; a UN specialized agency
members - (185) includes all UN member countries except Andorra, Cuba,
North Korea, Liechtenstein, Monaco, Nauru, and Tuvalu
International Chamber of Commerce (ICC): established - 1919
aim - to promote free trade and private enterprise and to represent
business interests at national and international levels
members - (91 national committees) Algeria, Argentina, Australia,
Austria, Bahrain, Bangladesh, Belgium, Brazil, Burkina Faso, Cameroon,
Canada, Caribbean, Chile, China, Colombia, Costa Rica, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Dominican Republic, Ecuador, Egypt, El
Salvador, Finland, France, Georgia, Germany, Ghana, Greece, Guatemala,
Hong Kong, Hungary, Iceland, India, Indonesia, Iran, Ireland, Israel,
Italy, Japan, Jordan, South Korea, Kuwait, Lebanon, Lithuania,
Luxembourg, Madagascar, Malaysia, Mexico, Monaco, Morocco, Nepal,
Netherlands, NZ, Nigeria, Norway, Pakistan, Panama, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Saudi Arabia, Senegal,
Serbia, Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka,
Sweden, Switzerland, Syria, Taiwan, Tanzania, Thailand, Togo, Tunisia,
Turkey, Ukraine, UAE, UK, US, Uruguay, Venezuela
International Civil Aviation Organization (ICAO): established - 7
December 1944; effective - 4 April 1947
aim - to promote international cooperation in civil aviation; a UN
specialized agency
members - (189) includes all UN member countries except Dominica,
Liechtenstein, Montenegro, and Tuvalu (188 total); plus Cook Islands
International Civilian Support Mission in Haiti (MICAH): established
17 December 1999 to promote respect for human rights; members included
Argentina, Benin, Canada, France, India, Mali, Niger, Senegal, Togo,
Tunisia, US; closed 2001
International Committee of the Red Cross (ICRC): established - 17
February 1863
aim - to provide humanitarian aid in wartime
members - (15-25 individuals) all Swiss nationals
International Court of Justice (ICJ): note - also known as the World
Court
established - 3 February 1946 superseded Permanent Court of
International Justice
aim - primary judicial organ of the UN
members - (15 judges) elected by the UN General Assembly and Security
Council to represent all principal legal systems
International Criminal Court (ICCt): established - 11 April 2002
aim - to hold all individuals and countries accountable to
international laws of conduct; to specify international standards of
conduct; to provide an important mechanism for implementing these
standards; to ensure that perpetrators are brought to justice
members (countries that have ratified the treaty) - (104) Afghanistan,
Albania, Andorra, Antigua and Barbuda, Argentina, Australia, Austria,
Barbados, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Bulgaria, Burkina Faso, Burundi, Cambodia, Canada,
Central African Republic, Chad, Colombia, Comoros, Democratic Republic
of the Congo, Republic of the Congo, Costa Rica, Croatia, Cyprus,
Denmark, Djibouti, Dominica, Dominican Republic, East Timor, Ecuador,
Estonia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany,
Ghana, Greece, Guinea, Guyana, Honduras, Hungary, Iceland, Ireland,
Italy, Jordan, Kenya, South Korea, Latvia, Lesotho, Liberia,
Liechtenstein, Lithuania, Luxembourg, Macedonia, Malawi, Mali, Malta,
Marshall Islands, Mauritius, Mexico, Mongolia, Montenegro, Namibia,
Nauru, Netherlands, NZ, Niger, Nigeria, Norway, Panama, Paraguay, Peru,
Poland, Portugal, Romania, Saint Vincent and the Grenadines, Saint
Kitts and Nevis, Samoa, San Marino, Senegal, Serbia, Sierra Leone,
Slovakia, Slovenia, South Africa, Spain, Sweden, Switzerland,
Tajikistan, Tanzania, Trinidad and Tobago, Uganda, UK, Uruguay,
Venezuela, Zambia; note - Comoros and Saint Kitts and Nevis became full
members on 1 November 2006
signatory states (countries that have signed, but not ratified, the
treaty) - (39) Algeria, Angola, Armenia, The Bahamas, Bahrain,
Bangladesh, Cameroon, Cape Verde, Chile, Cote d''Ivoire, Czech Republic,
Egypt, Eritrea, Guinea-Bissau, Haiti, Iran, Jamaica, Kuwait,
Kyrgyzstan, Madagascar, Moldova, Monaco, Morocco, Mozambique, Oman,
Philippines, Russia, Saint Lucia, Sao Tome and Principe, Seychelles,
Solomon Islands, Sudan, Syria, Thailand, Ukraine, UAE, Uzbekistan,
Yemen, Zimbabwe
International Criminal Police Organization (Interpol): established -
September 1923 set up as the International Criminal Police Commission;
13 June 1956 constitution modified and present name adopted
aim - to promote international cooperation among police authorities in
fighting crime
members - (186) Afghanistan, Albania, Algeria, Andorra, Angola, Antigua
and Barbuda, Argentina, Armenia, Aruba, Australia, Austria, Azerbaijan,
The Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Djibouti, Dominica, Dominican Republic, East Timor,
Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea, Estonia,
Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia, Germany,
Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Haiti, Honduras, Hungary, Iceland, India, Indonesia, Iran, Iraq,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya,
South Korea, Kuwait, Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho,
Liberia, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia,
Madagascar, Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia, Montenegro,
Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands, Netherlands
Antilles, NZ, Nicaragua, Niger, Nigeria, Norway, Oman, Pakistan,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis, Saint
Lucia, Saint Vincent and the Grenadines, San Marino, Sao Tome and
Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra Leone,
Singapore, Slovakia, Slovenia, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Tajikistan,
Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
subbureaus - (11) American Samoa, Anguilla, Bermuda, British Virgin
Islands, Cayman Islands, Gibraltar, Hong Kong, Macau, Montserrat,
Puerto Rico, Turks and Caicos Islands
International Development Association (IDA): established - 26 January
1960; effective - 24 September 1960
aim - to provide economic loans for low-income countries; UN
specialized agency and IBRD affiliate
members - (166)
Part I - (27 developed countries) Australia, Austria, Belgium, Canada,
Denmark, EU, Finland, France, Germany, Iceland, Ireland, Italy, Japan,
Kuwait, Luxembourg, Netherlands, NZ, Norway, Portugal, Russia, South
Africa, Spain, Sweden, Switzerland, UAE, UK, US
Part II - (139 less developed countries) Afghanistan, Albania, Algeria,
Angola, Argentina, Armenia, Azerbaijan, Bangladesh, Barbados, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central
African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote
d''Ivoire, Croatia, Cyprus, Czech Republic, Djibouti, Dominica,
Dominican Republic, East Timor, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Ethiopia, Fiji, Gabon, The Gambia, Georgia, Ghana,
Greece, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti,
Honduras, Hungary, India, Indonesia, Iran, Iraq, Israel, Jordan,
Kazakhstan, Kenya, Kiribati, South Korea, Kyrgyzstan, Laos, Latvia,
Lebanon, Lesotho, Liberia, Libya, Macedonia, Madagascar, Malawi,
Malaysia, Maldives, Mali, Marshall Islands, Mauritania, Mauritius,
Mexico, Federated States of Micronesia, Moldova, Mongolia, Morocco,
Mozambique, Nepal, Nicaragua, Niger, Nigeria, Oman, Pakistan, Palau,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland, Rwanda,
Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Sierra
Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia, Sri
Lanka, Sudan, Swaziland, Syria, Tajikistan, Tanzania, Thailand, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, Ukraine,
Uzbekistan, Vanuatu, Vietnam, Yemen, Zambia, Zimbabwe
International Energy Agency (IEA): established - 15 November 1974
aim - to promote cooperation on energy matters, especially emergency
oil sharing and relations between oil consumers and oil producers;
established by the OECD
members - (27) Australia, Austria, Belgium, Canada, Czech Republic,
Denmark, Finland, France, Germany, Greece, Hungary, Ireland, Italy,
Japan, South Korea, Luxembourg, Netherlands, NZ, Norway, Portugal,
Slovakia, Spain, Sweden, Switzerland, Turkey, UK, US
International Federation of Red Cross and Red Crescent Societies
(IFRCS): note - formerly known as League of Red Cross and Red Crescent
Societies (LORCS)
established - 5 May 1919
aim - to organize, coordinate, and direct international relief actions;
to promote humanitarian activities; to represent and encourage the
development of National Societies; to bring help to victims of armed
conflicts, refugees, and displaced people; to reduce the vulnerability
of people through development programs
members - (185 plus the Palestine Liberation Organization) Afghanistan,
Albania, Algeria, Andorra, Angola, Antigua and Barbuda, Argentina,
Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bahrain,
Bangladesh, Barbados, Belarus, Belgium, Belize, Benin, Bolivia, Bosnia
and Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso,
Burma, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic of
the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Czech Republic, Denmark, Djibouti, Dominica,
Dominican Republic, East Timor, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea, Guinea-
Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India, Indonesia,
Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan,
Kenya, Kiribati, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lebanon, Lesotho, Liberia, Libya, Liechtenstein, Lithuania,
Luxembourg, Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta,
Mauritania, Mauritius, Mexico, Federated States of Micronesia, Moldova,
Monaco, Mongolia, Morocco, Mozambique, Namibia, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Pakistan, Palau, Panama, Papua New
Guinea, Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania,
Russia, Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and
the Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, Solomon Islands, Somalia, South Africa, Spain, Sri Lanka,
Sudan, Suriname, Swaziland, Sweden, Switzerland, Syria, Taiwan,
Tajikistan, Tanzania, Thailand, Togo, Tonga, Trinidad and Tobago,
Tunisia, Turkey, Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe,
Palestine Liberation Organization
observers - (2) Eritrea and Tuvalu
International Finance Corporation (IFC): established - 25 May 1955;
effective - 24 July 1956
aim - to support private enterprise in international economic
development; a UN specialized agency and IBRD affiliate
members - (177) includes all UN member countries except Andorra,
Brunei, Cuba, Guinea, North Korea, Liechtenstein, Monaco, Montenegro,
Nauru, Qatar, Saint Vincent and the Grenadines, San Marino, Sao Tome
and Principe, Suriname, Tuvalu
International Fund for Agricultural Development (IFAD): established -
November 1974
aim - to promote agricultural development; a UN specialized agency
members - (165)
Category I - (23 industrialized aid contributors) Australia, Austria,
Belgium, Canada, Denmark, Finland, France, Germany, Greece, Iceland,
Ireland, Italy, Japan, Luxembourg, Netherlands, NZ, Norway, Portugal,
Spain, Sweden, Switzerland, UK, US
Category II - (12 petroleum-exporting aid contributors) Algeria, Gabon,
Indonesia, Iran, Iraq, Kuwait, Libya, Nigeria, Qatar, Saudi Arabia,
UAE, Venezuela
Category III - (130 aid recipients) Afghanistan, Albania, Angola,
Antigua and Barbuda, Argentina, Armenia, Azerbaijan, Bangladesh,
Barbados, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Cape Verde, Central African Republic, Chad, Chile, China, Colombia,
Comoros, Democratic Republic of the Congo, Republic of the Congo, Cook
Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Djibouti,
Dominica, Dominican Republic, East Timor, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Ethiopia, Fiji, The Gambia, Georgia, Ghana,
Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras,
India, Israel, Jamaica, Jordan, Kazakhstan, Kenya, Kiribati, North
Korea, South Korea, Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia,
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Mauritania, Mauritius, Mexico, Moldova, Mongolia, Morocco, Mozambique,
Namibia, Nepal, Nicaragua, Niger, Niue, Oman, Pakistan, Panama, Papua
New Guinea, Paraguay, Peru, Philippines, Romania, Rwanda, Saint Kitts
and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao
Tome and Principe, Senegal, Serbia (suspended since 1992), Seychelles,
Sierra Leone, Solomon Islands, Somalia, South Africa, Sri Lanka, Sudan,
Suriname, Swaziland, Syria, Tajikistan, Tanzania, Thailand, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Uganda, Uruguay, Vietnam,
Yemen, Zambia, Zimbabwe
International Hydrographic Organization (IHO): note - name changed
from International Hydrographic Bureau on 22 September 1970
established - June 1919; effective - June 1921
aim - to train hydrographic surveyors and nautical cartographers to
achieve standardization in nautical charts and electronic chart
displays; to provide advice on nautical cartography and hydrography; to
develop the sciences in the field of hydrography and techniques used
for descriptive oceanograrphy
members - (76) Algeria, Argentina, Australia, Bahrain, Bangladesh,
Belgium, Brazil, Burma, Canada, Chile, China (including Hong Kong and
Macau), Colombia, Democratic Republic of the Congo (suspended),
Croatia, Cuba, Cyprus, Denmark, Dominican Republic (suspended),
Ecuador, Egypt, Estonia, Fiji, Finland, France, Germany, Greece,
Guatemala, Iceland, India, Indonesia, Iran, Italy, Jamaica, Japan,
North Korea, South Korea, Kuwait, Latvia, Malaysia, Mauritius, Mexico,
Monaco, Morocco, Mozambique, Netherlands, NZ, Nigeria, Norway, Oman,
Pakistan, Papua New Guinea, Peru, Philippines, Poland, Portugal,
Russia, Serbia, Singapore, Slovenia, South Africa, Spain, Sri Lanka,
Suriname (suspended), Sweden, Syria, Thailand, Tonga, Trinidad and
Tobago, Tunisia, Turkey, Ukraine, UAE, UK, US, Uruguay, Venezuela
International Labor Organization (ILO): established - 28 June 1919 set
up as part of Treaty of Versailles; 11 April 1919 became operative; 14
December 1946 affiliated with the UN
aim - to deal with world labor issues; a UN specialized agency
members - (179) includes all UN member countries except Andorra,
Bhutan, Brunei, North Korea, Liechtenstein, Maldives, Marshall Islands,
Federated States of Micronesia, Monaco, Nauru, Palau, Tonga, and
Tuvalu; note - includes the following dependencies: Netherlands
(Netherlands Antilles and Aruba)
International Maritime Organization (IMO): note - name changed from
Intergovernmental Maritime Consultative Organization (IMCO) on 22 May
1982
established - 6 March 1948 set up as the Inter-Governmental Maritime
Consultative Organization; effective - 17 March 1958
aim - to deal with international maritime affairs; a UN specialized
agency
members - (167) includes all UN member countries except Afghanistan,
Andorra, Armenia, Belarus, Bhutan, Botswana, Burkina Faso, Burundi,
Central African Republic, Chad, Kyrgyzstan, Laos, Lesotho,
Liechtenstein, Mali, Federated States of Micronesia, Montenegro, Nauru,
Niger, Palau, Rwanda, Tajikistan, Uganda, Uzbekistan, Zambia
associate members - (3) Faroe Islands, Hong Kong, Macau
International Monetary Fund (IMF): established - 22 July 1944;
effective - 27 December 1945
aim - to promote world monetary stability and economic development; a
UN specialized agency
members - (184) includes all UN member countries except Andorra, Cuba,
North Korea, Liechtenstein, Monaco, Nauru, Tuvalu; note - includes the
following dependencies or areas of special interest: China (Hong Kong
and Macau), Netherlands (Netherlands Antilles and Aruba)
International Olympic Committee (IOC): established - 23 June 1894
aim - to promote the Olympic ideals and administer the Olympic games:
2006 Winter Olympics in Turin, Italy; 2008 Summer Olympics in Beijing,
China; 2010 Winter Olympics in Vancouver, Canada; 2012 Summer Olympics
in London, UK
National Olympic Committees - (201 and the Palestine Liberation
Organization) Afghanistan, Albania, Algeria, American Samoa, Andorra,
Angola, Antigua and Barbuda, Argentina, Armenia, Aruba, Australia,
Austria, Azerbaijan, The Bahamas, Bahrain, Bangladesh, Barbados,
Belarus, Belgium, Belize, Benin, Bermuda, Bhutan, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil, British Virgin Islands, Brunei,
Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Canada,
Cape Verde, Cayman Islands, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of
the Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, East Timor, Ecuador, Egypt, El Salvador, Equatorial Guinea,
Eritrea, Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guam, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hong Kong, Hungary, Iceland,
India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi,
Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands,
Netherlands Antilles, NZ, Nicaragua, Niger, Nigeria, Norway, Oman,
Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Puerto Rico, Qatar, Romania, Russia, Rwanda, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa,
San Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon
Islands, Somalia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Taiwan, Tajikistan, Tanzania,
Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Uganda, Ukraine, UAE, UK, US, Uruguay, Uzbekistan,
Vanuatu, Venezuela, Vietnam, Virgin Islands, Yemen, Zambia, Zimbabwe,
Palestine Liberation Organization
International Organization for Migration (IOM): note - established as
Provisional Intergovernmental Committee for the Movement of Migrants
from Europe; renamed Intergovernmental Committee for','a3b9b36fa634cc83a48f85eed9ed977479abf2008b6e9d22f3ed99776eeb36c4','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e71a07c06ae576e4d89921ffc8ebeed92e10d62c582998dc4d4157ced98d03e3',2007,'ZW','Zimbabwe','environment',1122,'European Migration
(ICEM) on 15 November 1952; renamed Intergovernmental Committee for
Migration (ICM) in November 1980; current name adopted 14 November 1989
established - 5 December 1951
aim - to facilitate orderly international emigration and immigration
members - (120) Afghanistan, Albania, Algeria, Angola, Argentina,
Armenia, Australia, Austria, Azerbaijan, The Bahamas, Bangladesh,
Belarus, Belgium, Belize, Benin, Bolivia, Bosnia and Herzegovina,
Brazil, Bulgaria, Burkina Faso, Cambodia, Cameroon, Canada, Cape Verde,
Chile, Colombia, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cyprus, Czech Republic,
Denmark, Dominican Republic, Ecuador, Egypt, El Salvador, Estonia,
Finland, France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Guatemala, Guinea, Guinea-Bissau, Haiti, Honduras, Hungary, Iran,
Ireland, Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya,
South Korea, Kyrgyzstan, Latvia, Liberia, Libya, Lithuania, Luxembourg,
Madagascar, Mali, Malta, Mauritania, Mauritius, Mexico, Moldova,
Montenegro, Morocco, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria,
Norway, Pakistan, Panama, Paraguay, Peru, Philippines, Poland,
Portugal, Romania, Rwanda, Senegal, Serbia, Sierra Leone, Slovakia,
Slovenia, South Africa, Spain, Sri Lanka, Sudan, Sweden, Switzerland,
Tajikistan, Tanzania, Thailand, Togo, Tunisia, Turkey, Uganda, Ukraine,
UK, US, Uruguay, Venezuela, Yemen, Zambia, Zimbabwe
observers - (19) Bhutan, Burundi, China, Cuba, Ethiopia, Guyana, Holy
See, India, Indonesia, Macedonia, Mozambique, Namibia, Papua New
Guinea, Russia, San Marino, Sao Tome and Principe, Somalia,
Turkmenistan, Vietnam
International Organization for Standardization (ISO): established -
February 1947
aim - to promote the development of international standards with a view
to facilitating international exchange of goods and services and to
developing cooperation in the sphere of intellectual, scientific,
technological and economic activity
members - (103 national standards organizations) Algeria, Argentina,
Armenia, Australia, Austria, Azerbaijan, Bahrain, Bangladesh, Barbados,
Belarus, Belgium, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria,
Canada, Chile, China, Colombia, Democratic Republic of the Congo, Costa
Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark,
Ecuador, Egypt, Ethiopia, Fiji, Finland, France, Germany, Ghana,
Greece, Hungary, Iceland, India, Indonesia, Iran, Iraq, Ireland,
Israel, Italy, Jamaica, Japan, Jordan, Kazakhstan, Kenya, North Korea,
South Korea, Kuwait, Lebanon, Libya, Luxembourg, Macedonia, Malaysia,
Malta, Mauritius, Mexico, Mongolia, Morocco, Netherlands, NZ, Nigeria,
Norway, Oman, Pakistan, Panama, Philippines, Poland, Portugal, Qatar,
Romania, Russia, Saint Lucia, Saudi Arabia, Serbia, Singapore,
Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan, Sweden,
Switzerland, Syria, Tanzania, Thailand, Trinidad and Tobago, Tunisia,
Turkey, Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam,
correspondent members - (43 plus the Palestine Liberation Organization)
Afghanistan, Albania, Angola, Benin, Bhutan, Bolivia, Brunei, Burkina
Faso, Burma, Dominican Republic, El Salvador, Eritrea, Estonia,
Georgia, Guatemala, Guinea, Guinea-Bissau, Hong Kong, Kyrgyzstan,
Latvia, Lithuania, Macau, Madagascar, Malawi, Mali, Moldova,
Mozambique, Namibia, Nepal, Nicaragua, Niger, Papua New Guinea,
Paraguay, Peru, Rwanda, Senegal, Seychelles, Swaziland, Togo,
Turkmenistan, Uganda, Yemen, Zambia, Palestine Liberation Organization
subscriber members - (9) Antigua and Barbuda, Burundi, Cambodia,
Dominica, Grenada, Guyana, Honduras, Lesotho, Saint Vincent and the
Grenadines
International Organization of the French-speaking World (OIF): note -
name changed from Agency of Cultural and Technical Cooperation (ACCT)
in 1997
established - 20 March 1970
aim - founded around a common language to promote and spread the
cultures of its members and to reinforce cultural and technical
cooperation between them
members - (55) Albania, Andorra, Belgium, Benin, Bulgaria, Burkina
Faso, Burundi, Cambodia, Cameroon, Canada, Canada - New Brunswick,
Canada - Quebec, Cape Verde, Central African Republic, Chad, Comoros,
Democratic Republic of Congo, Republic of Congo, Cote d''Ivoire, Cyprus,
Djibouti, Dominica, Egypt, Equatorial Guinea, France, French Community
of Belgium, Gabon, Ghana, Greece, Guinea, Guinea-Bissau, Haiti, Laos,
Lebanon, Luxembourg, Macedonia, Madagascar, Mali, Mauritania,
Mauritius, Moldova, Monaco, Morocco, Niger, Romania, Rwanda, Saint
Lucia, Sao Tome and Principe, Senegal, Seychelles, Switzerland, Togo,
Tunisia, Vanuatu, Vietnam
observers - (13) Armenia, Austria, Croatia, Czech Republic, Georgia,
Hungary, Lithuania, Mozambique, Poland, Serbia, Slovakia, Slovenia,
Nuclear Test Ban
see Treaty Banning Nuclear Weapons Tests in the Atmosphere, in Outer
Space, and Under Water
Ozone Layer Protection
see Montreal Protocol on Substances That Deplete the Ozone Layer
Protocol of 1978 Relating to the International Convention for the
Prevention of Pollution From Ships, 1973 (MARPOL) note - abbreviated
as Ship Pollution
opened for signature - 17 February 1978
entered into force - 2 October 1983
objective - to preserve the marine environment through the complete
elimination of pollution by oil and other harmful substances and the
minimization of accidental discharge of such substances
parties - (119) Algeria, Angola, Antigua and Barbuda, Argentina,
Australia, Austria, The Bahamas, Barbados, Belarus, Belgium, Belize,
Benin, Bolivia, Brazil, Brunei, Bulgaria, Burma, Cambodia, Canada,
Chile, China, Colombia, Comoros, Cote d''Ivoire, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, Equatorial Guinea, Estonia, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece,
Guatemala, Guyana, Honduras, Hungary, Iceland, India, Indonesia,
Ireland, Israel, Italy, Jamaica, Japan, Kazakhstan, Kenya, North
Korea, South Korea, Latvia, Lebanon, Liberia, Lithuania, Luxembourg,
Malawi, Malaysia, Malta, Marshall Islands, Mauritania, Mauritius,
Mexico, Monaco, Morocco, Netherlands, NZ, Nicaragua, Norway, Oman,
Pakistan, Panama, Papua New Guinea, Peru, Philippines, Poland,
Portugal, Romania, Russia, Saint Kitts and Nevis, Saint Lucia, Saint
Vincent and the Grenadines, Sao Tome and Principe, Senegal, Serbia,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, South
Africa, Spain, Sri Lanka, Suriname, Sweden, Switzerland, Syria,
Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey, Tuvalu, Ukraine,
UK, US, Uruguay, Vanuatu, Venezuela, Vietnam
Protocol on Environmental Protection to the Antarctic Treaty note -
abbreviated as Antarctic-Environmental Protocol
opened for signature - 4 October 1991
entered into force - 14 January 1998
objective - to provide for comprehensive protection of the Antarctic
environment and dependent and associated ecosystems; applies to the
area covered by the Antarctic Treaty
consultative parties - (27) Argentina, Australia, Belgium, Brazil,
Bulgaria, Chile, China, Ecuador, Finland, France, Germany, India,
Italy, Japan, South Korea, Netherlands, NZ, Norway, Peru, Poland,
Russia, South Africa, Spain, Sweden, UK, US, Uruguay
non consultative parties - (16) Austria, Canada, Colombia, Cuba,
Czech Republic, Denmark, Greece, Guatemala, Hungary, North Korea,
Papua New Guinea, Romania, Slovakia, Switzerland, Turkey, Ukraine
Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution Concerning the Control of Emissions of Nitrogen Oxides or
Their Transboundary Fluxes note - abbreviated as Air
Pollution-Nitrogen Oxides
opened for signature - 31 October 1988
entered into force - 14 February 1991
objective - to provide for the control or reduction of nitrogen
oxides and their transboundary fluxes
parties - (28) Austria, Belarus, Belgium, Bulgaria, Canada, Czech
Republic, Denmark, Estonia, EU, Finland, France, Germany, Greece,
Hungary, Ireland, Italy, Liechtenstein, Luxembourg, Netherlands,
Norway, Russia, Slovakia, Spain, Sweden, Switzerland, Ukraine, UK, US
countries that have signed, but not yet ratified - (1) Poland
Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution Concerning the Control of Emissions of Volatile Organic
Compounds or Their Transboundary Fluxes note - abbreviated as Air
Pollution-Volatile Organic Compounds
opened for signature - 18 November 1991
entered into force - 29 September 1997
objective - to provide for the control and reduction of emissions of
volatile organic compounds in order to reduce their transboundary
fluxes so as to protect human health and the environment from
adverse effects
parties - (21) Austria, Belgium, Bulgaria, Czech Republic, Denmark,
Estonia, Finland, France, Germany, Hungary, Italy, Liechtenstein,
Luxembourg, Monaco, Netherlands, Norway, Slovakia, Spain, Sweden,
Switzerland, UK
countries that have signed, but not yet ratified - (6) Canada, EU,
Greece, Portugal, Ukraine, US
Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on Further Reduction of Sulphur Emissions note -
abbreviated as Air Pollution-Sulphur 94
opened for signature - 14 June 1994
entered into force - 5 August 1998
objective - to provide for a further reduction in sulfur emissions
or transboundary fluxes
parties - (23) Austria, Belgium, Canada, Croatia, Czech Republic,
Denmark, EU, Finland, France, Germany, Greece, Ireland, Italy,
Liechtenstein, Luxembourg, Netherlands, Norway, Slovakia, Slovenia,
Spain, Sweden, Switzerland, UK
countries that have signed, but not yet ratified - (5) Bulgaria,
Hungary, Poland, Russia, Ukraine
Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on Persistent Organic Pollutants note - abbreviated as Air
Pollution-Persistent Organic Pollutants
opened for signature - 24 June 1998
entered into force - 23 October 2003
objective - to provide for the control and reduction of emissions of
persistent organic pollutants in order to reduce their transboundary
fluxes so as to protect human health and the environment from
adverse effects
parties - (22) Austria, Bulgaria, Canada, Cyprus, Czech Republic,
Denmark, EU, Finland, France, Germany, Hungary, Iceland, Latvia,
Liechtenstein, Luxembourg, Moldova, Netherlands, Norway, Romania,
Slovakia, Sweden, Switzerland
countries that have signed, but not yet ratified - (14) Armenia,
Belgium, Croatia, Greece, Ireland, Italy, Lithuania, Poland,
Portugal, Slovenia, Spain, Ukraine, UK, US
Protocol to the 1979 Convention on Long-Range Transboundary Air
Pollution on the Reduction of Sulphur Emissions or Their
Transboundary Fluxes by at Least 30% note - abbreviated as Air
Pollution-Sulphur 85
opened for signature - 8 July 1985
entered into force - 2 September 1987
objective - to provide for a 30% reduction in sulfur emissions or
transboundary fluxes by 1993
parties - (22) Austria, Belarus, Belgium, Bulgaria, Canada, Czech
Republic, Denmark, Estonia, Finland, France, Germany, Hungary,
Italy, Liechtenstein, Luxembourg, Netherlands, Norway, Russia,
Slovakia, Sweden, Switzerland, Ukraine
Ship Pollution
see Protocol of 1978 Relating to the International Convention for
the Prevention of Pollution From Ships, 1973 (MARPOL)
Treaty Banning Nuclear Weapon Tests in the Atmosphere, in Outer
Space, and Under Water note - abbreviated as Nuclear Test Ban
opened for signature - 5 August 1963
entered into force - 10 October 1963
objective - to obtain an agreement on general and complete
disarmament under strict international control in accordance with
the objectives of the United Nations; to put an end to the armaments
race and eliminate incentives for the production and testing of all
kinds of weapons, including nuclear weapons
parties - (113) Afghanistan, Antigua and Barbuda, Argentina,
Armenia, Australia, Austria, The Bahamas, Bangladesh, Belgium,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Bulgaria, Burma, Canada, Central African Republic, Chad, China,
Colombia, Democratic Republic of the Congo, Costa Rica, Cote
d''Ivoire, Croatia, Cyprus, Czech Republic, Denmark, Dominican
Republic, Ecuador, Egypt, El Salvador, Fiji, Finland, Gabon, The
Gambia, Germany, Ghana, Greece, Guatemala, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Iraq, Ireland, Israel, Italy,
Jamaica, Japan, Jordan, Kenya, South Korea, Kuwait, Laos, Lebanon,
Liberia, Luxembourg, Madagascar, Malawi, Malaysia, Malta,
Mauritania, Mauritius, Mexico, Morocco, Nepal, Netherlands, NZ,
Nicaragua, Niger, Nigeria, Norway, Panama, Papua New Guinea, Peru,
Philippines, Poland, Romania, Russia, Rwanda, Samoa, San Marino,
Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, South Africa, Spain, Sri Lanka, Sudan, Suriname,
Swaziland, Sweden, Switzerland, Syria, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Uganda, UK, US, Venezuela,','10f14072512a99721c0babe39c263347924f38ad0835ebe85052a4a2b532d9e4','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('78bb6da53efdee9dbc5167945d41f16f29525aababadefa2f1b1f30b5c472bf8',2007,'TH','Thailand','environment',1123,'Bank for International Settlements (BIS): established - 20 January
1930; effective - 17 March 1930
aim - to promote cooperation among central banks in international
financial settlements
members - (55) Algeria, Argentina, Australia, Austria, Belgium, Bosnia
and Herzegovina, Brazil, Bulgaria, Canada, Chile, China, Croatia, Czech
Republic, Denmark, Estonia, European Central Bank, Finland, France,
Germany, Greece, Hong Kong, Hungary, Iceland, India, Indonesia,
Ireland, Israel, Italy, Japan, South Korea, Latvia, Lithuania,
Macedonia, Malaysia, Mexico, Netherlands, NZ, Norway, Philippines,
Poland, Portugal, Romania, Russia, Saudi Arabia, Serbia, Singapore,
Slovakia, Slovenia, South Africa, Spain, Sweden, Switzerland, Thailand,
Turkey, UK, US; note - Serbia and Montenegro have separate central
banks; their links with BIS are currently under review
Benelux Economic Union (Benelux): note - acronym from Belgium,
Netherlands, and Luxembourg
established - 3 February 1958; effective - 1 November 1960
aim - to develop closer economic cooperation and integration
members - (3) Belgium, Luxembourg, Netherlands
Big Seven: note - membership is the same as the Group of 7
established - 1975
aim - to discuss and coordinate major economic policies
members - (7) Big Six (Canada, France, Germany, Italy, Japan, UK) plus
the US
Black Sea Economic Cooperation Zone (BSEC): established - 25 June 1992
aim - to enhance regional stability through economic cooperation
members - (12) Albania, Armenia, Azerbaijan, Bulgaria, Georgia, Greece,
Moldova, Romania, Russia, Serbia, Turkey, Ukraine; note - Macedonia is
in the process of joining
observers - (16) Austria, Belarus, Black Sea Commission, Croatia, Czech
Republic, Egypt, Energy Charter Secretariat, France, Germany,
International Black Sea Club, Israel, Italy, Poland, Slovakia, Tunisia,
US; note - Bosnia and Herzegovina and Slovenia have applied for
observer status
Caribbean Community and Common Market (Caricom): established - 4 July
1973; effective - 1 August 1973
aim - to promote economic integration and development, especially among
the less developed countries
members - (15) Antigua and Barbuda, The Bahamas, Barbados, Belize,
Dominica, Grenada, Guyana, Haiti, Jamaica, Montserrat, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Suriname,','f067fd6d7a525cc6042b08944282f73fa99d99ee820d3583ac58b1105cb131b7','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a43b48e553a2c8b82c5349aeed69e6af589f10fe027804e0fca9181d112a9c52',2007,'TT','Trinidad and Tobago','environment',1124,'associate members - (5) Anguilla, Bermuda, British Virgin Islands,
Cayman Islands, Turks and Caicos Islands
Caribbean Development Bank (CDB): established - 18 October 1969;
effective - 26 January 1970
aim - to promote economic development and cooperation
regional members - (20) Anguilla, Antigua and Barbuda, The Bahamas,
Barbados, Belize, British Virgin Islands, Cayman Islands, Colombia,
Dominica, Grenada, Guyana, Jamaica, Mexico, Montserrat, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Trinidad and
Tobago, Turks and Caicos Islands, Venezuela
nonregional members - (5) Canada, China, Germany, Italy, UK
Central African Customs and Economic Union (UDEAC): see Monetary and
Economic Community of Central Africa (CEMAC)
Central African States Development Bank (BDEAC): note - acronym from
Banque de Developpement des Etats de l''Afrique Centrale
established - 3 December 1975
aim - to provide loans for economic development
members - (10) African Development Bank (AfDB), Cameroon, Central
African States Bank (BEAC), Central African Republic, Chad, Republic of
the Congo, Equatorial Guinea, France, Gabon, Kuwait
Central American Bank for Economic Integration (BCIE): note - acronym
from Banco Centroamericano de Integracion Economico
established - 13 December 1960 signature of Articles of Agreement; 31
May 1961 began operations
aim - to promote economic integration and development
members - (5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua
nonregional members - (5) Argentina, China, Colombia, Mexico, Spain
Central American Common Market (CACM): established - 13 December 1960,
collapsed in 1969, reinstated in 1991
aim - to promote establishment of a Central American Common Market
members - (5) Costa Rica, El Salvador, Guatemala, Honduras, Nicaragua;
note - Panama, although not a member, pursues full regional cooperation
Central European Initiative (CEI): note - evolved from the
Quadrilateral Initiative and the Hexagonal Initiative
established - 11 November 1989 as the Quadrilateral Initiative, 27 July
1991 became the Hexagonal Initiative, July 1992 its present name was
adopted
aim - to form an economic and political cooperation group for the
region between the Adriatic and the Baltic Seas
members - (18) Albania, Austria, Belarus, Bosnia and Herzegovina,
Bulgaria, Croatia, Czech Republic, Hungary, Italy, Macedonia, Moldova,
Montenegro, Poland, Romania, Serbia, Slovakia, Slovenia, Ukraine
centrally planned economies: a term applied mainly to the
traditionally Communist states that looked to the former USSR for
leadership; most are now evolving toward more democratic and market-
oriented systems; also known formerly as the Second World or as as the
Communist countries; through the 1980s, this group included Albania,
Bulgaria, Cambodia, China, Cuba, Czechoslovakia, German Democratic
Republic, Hungary, North Korea, Laos, Mongolia, Montenegro, Poland,
Romania, Serbia, USSR, Vietnam
Colombo Plan (CP): established - May 1950 proposal was adopted; 1 July
1951 commenced full operations
aim - to promote economic and social development in Asia and the
Pacific
members - (25) Afghanistan, Australia, Bangladesh, Bhutan, Burma, Fiji,
India, Indonesia, Iran, Japan, South Korea, Laos, Malaysia, Maldives,
Mongolia, Nepal, NZ, Pakistan, Papua New Guinea, Philippines,
Singapore, Sri Lanka, Thailand, US, Vietnam
Common Market for Eastern and Southern Africa (COMESA): note -
formerly known as Preferential Trade Area for Eastern and Southern
Africa (PTA)
established - 5 November 1993
aim - recognizing, promoting and protecting fundamental human rights,
commitment to the principles of liberty and rule of law, maintaining
peace and stability through the promotion and strengthening of good
neighborliness, commitment to peaceful settlement of disputes among
member states
members - (20) Angola, Burundi, Comoros, Democratic Republic of the
Congo, Djibouti, Egypt, Eritrea, Ethiopia, Kenya, Libya, Madagascar,
Malawi, Mauritius, Rwanda, Seychelles, Sudan, Swaziland, Uganda,
Zambia, Zimbabwe
Commonwealth (C): note - also known as Commonwealth of Nations
established - 31 December 1931
aim - to foster multinational cooperation and assistance, as a
voluntary association that evolved from the British Empire
members - (53) Antigua and Barbuda, Australia, The Bahamas, Bangladesh,
Barbados, Belize, Botswana, Brunei, Cameroon, Canada, Cyprus, Dominica,
Fiji, The Gambia, Ghana, Grenada, Guyana, India, Jamaica, Kenya,
Kiribati, Lesotho, Malawi, Malaysia, Maldives, Malta, Mauritius,
Mozambique, Namibia, Nauru, NZ, Nigeria, Pakistan (suspended), Papua
New Guinea, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, Seychelles, Sierra Leone, Singapore, Solomon
Islands, South Africa, Sri Lanka, Swaziland, Tanzania, Tonga, Trinidad
and Tobago, Tuvalu, Uganda, UK, Vanuatu, Zambia; note - on 7 December
2003 Zimbabwe withdrew its membership from the Commonwealth
Commonwealth of Independent States (CIS): established - 8 December
1991; effective - 21 December 1991
aim - to coordinate intercommonwealth relations and to provide a
mechanism for the orderly dissolution of the USSR
members - (12) Armenia, Azerbaijan, Belarus, Georgia, Kazakhstan,
Kyrgyzstan, Moldova, Russia, Tajikistan, Turkmenistan, Ukraine,','d5b8b2cf62edaf19ffb558ec7d2c39871ccfa09dbe22e8f36a462a6a178fe71d','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc027f2d4955b410a8cea8b63c7e396013fdff874e554f3c097575b8e9bca747',2007,'UZ','Uzbekistan','environment',1125,'Communist countries: traditionally the Marxist-Leninist states with
authoritarian governments and command economies based on the Soviet
model; most of the original and the successor states are no longer
Communist; see centrally planned economies
Coordinating Committee on Export Controls (COCOM): established in 1949
to control the export of strategic products and technical data from
member countries to proscribed destinations; members were: Australia,
Belgium, Canada, Denmark, France, Germany, Greece, Italy, Japan,
Luxembourg, Netherlands, Norway, Portugal, Spain, Turkey, UK, US;
abolished 31 March 1994; COCOM members established a new organization,
the Wassenaar Arrangement, with expanded membership on 12 July 1996
that focuses on nonproliferation export controls as opposed to East-
West control of advanced technology
Council for Mutual Economic Assistance (CEMA): note - also known as
CMEA or Comecon
established 25 January 1949 to promote the development of socialist
economies and abolished 1 January 1991; members included Afghanistan
(observer), Albania (had not participated since 1961 break with USSR),
Angola (observer), Bulgaria, Cuba, Czechoslovakia, Ethiopia (observer),
GDR, Hungary, Laos (observer), Mongolia, Mozambique (observer),
Nicaragua (observer), Poland, Romania, USSR, Vietnam, Yemen (observer),
Yugoslavia (associate)
Council of Arab Economic Unity (CAEU): established - 3 June 1957;
effective - 30 May 1964
aim - to promote economic integration among Arab nations
members - (10 plus the Palestine Liberation Organization) Egypt, Iraq,
Jordan, Kuwait, Libya, Mauritania, Somalia, Sudan, Syria, Yemen,
Palestine Liberation Organization
Council of Europe (CE): established - 5 May 1949; effective - 3 August
1949
aim - to promote increased unity and quality of life in Europe
members - (46) Albania, Andorra, Armenia, Austria, Azerbaijan, Belgium,
Bosnia and Herzegovina, Bulgaria, Croatia, Cyprus, Czech Republic,
Denmark, Estonia, Finland, France, Georgia, Germany, Greece, Hungary,
Iceland, Ireland, Italy, Latvia, Liechtenstein, Lithuania, Luxembourg,
Macedonia, Malta, Moldova, Monaco, Netherlands, Norway, Poland,
Portugal, Romania, Russia, San Marino, Serbia, Slovakia, Slovenia,
Spain, Sweden, Switzerland, Turkey, Ukraine, UK
observers - (5) Canada, Holy See, Japan, Mexico, US
Council of the Baltic Sea States (CBSS): established - 6 March 1992
aim - to promote cooperation among the Baltic Sea states in the areas
of aid to new democratic institutions, economic development,
humanitarian aid, energy and the environment, cultural programs and
education, and transportation and communication
members - (12) Denmark, Estonia, EC, Finland, Germany, Iceland, Latvia,
Lithuania, Norway, Poland, Russia, Sweden
observers - (7) France, Italy, Netherlands, Slovakia, Ukraine, UK, US
Council of the Entente (Entente): established - 29 May 1959
aim - to promote economic, social, and political coordination
members - (5) Benin, Burkina Faso, Cote d''Ivoire, Niger, Togo
countries in transition: a term used by the International Monetary
Fund (IMF) for the middle group in its hierarchy of advanced economies,
countries in transition, and developing countries; IMF statistics
include the following 28 countries in transition: Albania, Armenia,
Azerbaijan, Belarus, Bosnia and Herzegovina, Bulgaria, Croatia, Czech
Republic, Estonia, Georgia, Hungary, Kazakhstan, Kyrgyzstan, Latvia,
Lithuania, Macedonia, Moldova, Mongolia, Montenegro, Poland, Romania,
Russia, Serbia, Slovakia, Slovenia, Tajikistan, Turkmenistan, Ukraine,
Uzbekistan; note - this group is identical to the group traditionally
referred to as the "former USSR/Eastern Europe" except for the addition
of Mongolia
Customs Cooperation Council (CCC): note - see World Customs
Organization (WCO)
developed countries (DCs): the top group in the hierarchy of developed
countries (DCs), former USSR/Eastern Europe (former USSR/EE), and less
developed countries (LDCs); includes the market-oriented economies of
the mainly democratic nations in the Organization for Economic
Cooperation and Development (OECD), Bermuda, Israel, South Africa, and
the European ministates; also known as the First World, high-income
countries, the North, industrial countries; generally have a per capita
GDP in excess of $10,000 although four OECD countries and South Africa
have figures well under $10,000 and two of the excluded OPEC countries
have figures of more than $10,000; the 34 DCs are: Andorra, Australia,
Austria, Belgium, Bermuda, Canada, Denmark, Faroe Islands, Finland,
France, Germany, Greece, Holy See, Iceland, Ireland, Israel, Italy,
Japan, Liechtenstein, Luxembourg, Malta, Monaco, Netherlands, NZ,
Norway, Portugal, San Marino, South Africa, Spain, Sweden, Switzerland,
Turkey, UK, US; note - similar to the new International Monetary Fund
(IMF) term "advanced economies" that adds Hong Kong, South Korea,
Singapore, and Taiwan but drops Malta, Mexico, South Africa, and Turkey
developing countries: a term used by the International Monetary Fund
(IMF) for the bottom group in its hierarchy of advanced economies,
countries in transition, and developing countries; IMF statistics
include the following 126 developing countries: Afghanistan, Algeria,
Angola, Antigua and Barbuda, Argentina, Aruba, The Bahamas, Bahrain,
Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Botswana, Brazil,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central
African Republic, Chad, Chile, China, Colombia, Comoros, Democratic
Republic of the Congo, Republic of the Congo, Costa Rica, Cote
d''Ivoire, Cyprus, Djibouti, Dominica, Dominican Republic, Ecuador,
Egypt, El Salvador, Equatorial Guinea, Ethiopia, Fiji, Gabon, The
Gambia, Ghana, Grenada, Guatemala, Guinea, Guinea-Bissau, Guyana,
Haiti, Honduras, India, Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya,
Kiribati, Kuwait, Laos, Lebanon, Lesotho, Liberia, Libya, Madagascar,
Malawi, Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Morocco, Mozambique,
Namibia, Nepal, Netherlands Antilles, Nicaragua, Niger, Nigeria, Oman,
Pakistan, Panama, Papua New Guinea, Paraguay, Peru, Philippines, Qatar,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, Sao Tome and Principe, Saudi Arabia, Senegal,
Seychelles, Sierra Leone, Solomon Islands, Somalia, South Africa, Sri
Lanka, Sudan, Suriname, Swaziland, Syria, Tanzania, Thailand, Togo,
Trinidad and Tobago, Tunisia, Turkey, UAE, Uganda, Uruguay, Vanuatu,
Venezuela, Vietnam, Yemen, Zambia, Zimbabwe; note - this category would
presumably also cover the following 46 other countries that are
traditionally included in the more comprehensive group of "less
developed countries": American Samoa, Anguilla, British Virgin Islands,
Brunei, Cayman Islands, Christmas Island, Cocos Islands, Cook Islands,
Cuba, Eritrea, Falkland Islands, French Guiana, French Polynesia, Gaza
Strip, Gibraltar, Greenland, Grenada, Guadeloupe, Guam, Guernsey, Isle
of Man, Jersey, North Korea, Macau, Martinique, Mayotte, Montserrat,
Nauru, New Caledonia, Niue, Norfolk Island, Northern Mariana Islands,
Palau, Pitcairn Islands, Puerto Rico, Reunion, Saint Helena, Saint
Pierre and Miquelon, Tokelau, Tonga, Turks and Caicos Islands, Tuvalu,
Virgin Islands, Wallis and Futuna, West Bank, Western Sahara
East African Development Bank (EADB): established - 6 June 1967;
effective - 1 December 1967
aim - to promote economic development
members - (3) Kenya, Tanzania, Uganda
East Asia Summit (EAS): established - 14 December 2005
aim - to promote cooperation in political and security issues; to
promote development, financial stability, energy security, economic
integration and growth; to eradicate poverty and narrow the development
gap in East Asia, and to promote deeper cultural understanding
members - (16) Australia, Brunei, Burma, Cambodia, China, India,
Indonesia, Japan, South Korea, Laos, Malaysia, NZ, Philippines,
Singapore, Thailand, Vietnam
Economic and Monetary Community of Central Africa (CEMAC): note - was
formerly the Central African Customs and Economic Union (UDEAC)
established - 8 December 1964; effective - 1 January 1966
aim - to promote the establishment of a Central African Common Market
members - (6) Cameroon, Central African Republic, Chad, Republic of the
Congo, Equatorial Guinea, Gabon
Economic and Monetary Union (EMU): note - an integral part of the
European Union; also known as the European Economic and Monetary Union
established - 1-2 December 1969 (proposed at summit conference of heads
of government; 7 February 1992 (Maastricht Treaty signed)
aim - to promote a single market by creating a single currency, the
euro; timetable - 2 May 1998: European exchange rates fixed for 1
January 1999; 1 January 1999: all banks and stock exchanges begin using
euros; 1 January 2002: the euro goes into circulation; 1 July 2002
local currencies no longer accepted
members - (12) Austria, Belgium, Finland, France, Germany, Greece,
Ireland, Italy, Luxembourg, Netherlands, Portugal, Spain
Economic and Social Council (ECOSOC): established - 26 June 1945;
effective - 24 October 1945
aim - to coordinate the economic and social work of the UN; includes
five regional commissions (Economic Commission for Africa, Economic
Commission for Europe, Economic Commission for Latin America and the
Caribbean, Economic and Social Commission for Asia and the Pacific,
Economic and Social Commission for Western Asia) and nine functional
commissions (Commission for Social Development, Commission on Human
Rights, Commission on Narcotic Drugs, Commission on the Status of
Women, Commission on Population and Development, Statistical
Commission, Commission on Science and Technology for Development,
Commission on Sustainable Development, and Commission on Crime
Prevention and Criminal Justice)
members - (54) selected on a rotating basis from all regions
Economic Community of the Great Lakes Countries (CEPGL): note -
acronym from Communaute Economique des Pays des Grands Lacs
established - 20 September 1976
aim - to promote regional economic cooperation and integration
members - (3) Burundi, Democratic Republic of the Congo, Rwanda; note -
organization collapsed because of fighting in 1998; reactivated in 2006
Economic Community of West African States (ECOWAS): established - 28
May 1975
aim - to promote regional economic cooperation
members - (15) Benin, Burkina Faso, Cape Verde, Cote d''Ivoire, The
Gambia, Ghana, Guinea, Guinea-Bissau, Liberia, Mali, Niger, Nigeria,
Senegal, Sierra Leone, Togo
Economic Cooperation Organization (ECO): established - 27-29 January
1985
aim - to promote regional cooperation in trade, transportation,
communications, tourism, cultural affairs, and economic development
members - (10) Afghanistan, Azerbaijan, Iran, Kazakhstan, Kyrgyzstan,
Pakistan, Tajikistan, Turkey, Turkmenistan, Uzbekistan
Euro-Atlantic Partnership Council (EAPC): note - began as the North
Atlantic Cooperation Council (NACC); an extension of NATO
established - 8 November 1991; effective - 20 December 1991
aim - to discuss cooperation on mutual political and security issues
members - (46) Albania, Armenia, Austria, Azerbaijan, Belarus, Belgium,
Bulgaria, Canada, Croatia, Czech Republic, Denmark, Estonia, Finland,
France, Georgia, Germany, Greece, Hungary, Iceland, Ireland, Italy,
Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Luxembourg, Macedonia,
Moldova, Netherlands, Norway, Poland, Portugal, Romania, Russia,
Slovakia, Slovenia, Spain, Sweden, Switzerland, Tajikistan, Turkey,
Turkmenistan, Ukraine, UK, US, Uzbekistan
Eurasian Economic Community (EAEC): established - May 2001
European Bank for Reconstruction and Development (EBRD): established -
8-9 January 1990 (proposals made); 15 April 1991 (bank inaugurated)
aim - to facilitate the transition of seven centrally planned economies
in Europe (Bulgaria, former Czechoslovakia, Hungary, Poland, Romania,
former USSR, and former Yugoslavia) to market economies by committing
60% of its loans to privatization
members - (63) Albania, Armenia, Australia, Austria, Azerbaijan,
Belarus, Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia,
Cyprus, Czech Republic, Denmark, Egypt, EC, European Investment Bank
(EIB), Estonia, Finland, France, Georgia, Germany, Greece, Hungary,
Iceland, Ireland, Israel, Italy, Japan, Kazakhstan, South Korea,
Kyrgyzstan, Latvia, Liechtenstein, Lithuania, Luxembourg, Macedonia,
Malta, Mexico, Moldova, Mongolia, Montenegro, Morocco, Netherlands, NZ,
Norway, Poland, Portugal, Romania, Russia, Serbia, Slovakia, Slovenia,
Spain, Sweden, Switzerland, Tajikistan, Turkey, Turkmenistan, Ukraine,
UK, US, Uzbekistan
European Community (or European Communities, EC): established 8 April
1965 to integrate the European Atomic Energy Community (Euratom), the
European Coal and Steel Community (ECSC), the European Economic
Community (EEC or Common Market), and to establish a completely
integrated common market and an eventual federation of Europe; merged
into the European Union (EU) on 7 February 1992; member states at the
time of merger were Belgium, Denmark, France, Germany, Greece, Ireland,
Italy, Luxembourg, Netherlands, Portugal, Spain, UK
European Free Trade Association (EFTA): established - 4 January 1960;
effective - 3 May 1960
aim - to promote expansion of free trade
members - (4) Iceland, Liechtenstein, Norway, Switzerland
European Investment Bank (EIB): established - 25 March 1957; effective
- 1 January 1958
aim - to promote economic development of the EU and its predecessors,
the EEC and the EC
members - (25) Austria, Belgium, Cyprus, Czech Republic, Denmark,
Estonia, Finland, France, Germany, Greece, Hungary, Ireland, Italy,
Latvia, Lithuania, Luxembourg, Malta, Netherlands, Poland, Portugal,
Slovakia, Slovenia, Spain, Sweden, UK
European Organization for Nuclear Research (CERN): note - acronym
retained from the predecessor organization Conseil Europeenne pour la
Recherche Nucleaire
established - 1 July 1953; effective - 29 September 1954
aim - to foster nuclear research for peaceful purposes only
members - (20) Austria, Belgium, Bulgaria, Czech Republic, Denmark,
Finland, France, Germany, Greece, Hungary, Italy, Netherlands, Norway,
Poland, Portugal, Slovakia, Spain, Sweden, Switzerland, UK
observers - (8) European Commission, India, Israel, Japan, Russia,
Turkey, United Nations Educational, Scientific, and Cultural
Organization (UNESCO), US
European Space Agency (ESA): established - 31 May 1975
aim - to promote peaceful cooperation in space research and technology
members - (17) Austria, Belgium, Denmark, Finland, France, Germany,
Greece, Ireland, Italy, Luxembourg, Netherlands, Norway, Portugal,
Spain, Sweden, Switzerland, UK
cooperating states - (4) Canada, Czech Republic, Hungary, Romania
European Union (EU): note - see European Union entry at the end of the
"country" listings
First World: another term for countries with advanced, industrialized
economies; this term is fading from use; see developed countries (DCs)
Food and Agriculture Organization (FAO): established - 16 October 1945
aim - to raise living standards and increase availability of
agricultural products; a UN specialized agency
members - (190) includes all UN member countries except Andorra,
Brunei, Liechtenstein, Montenegro, and Singapore (187 total); plus Cook
Islands, EC, and Niue
former Soviet Union (FSU): former term often used to identify as a
group the successor nations to the Soviet Union or USSR; this group of
15 countries consists of: Armenia, Azerbaijan, Belarus, Estonia,
Georgia, Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Moldova, Russia,
Tajikistan, Turkmenistan, Ukraine, Uzbekistan
former USSR/Eastern Europe (former USSR/EE): the middle group in the
hierarchy of developed countries (DCs), former USSR/Eastern Europe
(former USSR/EE), and less developed countries (LDCs); these countries
are in political and economic transition and may well be grouped
differently in the near future; this group of 27 countries consists of:
Albania, Armenia, Azerbaijan, Belarus, Bosnia and Herzegovina,
Bulgaria, Croatia, Czech Republic, Estonia, Georgia, Hungary,
Kazakhstan, Kyrgyzstan, Latvia, Lithuania, Macedonia, Moldova, Poland,
Romania, Russia, Slovakia, Slovenia, Tajikistan, Turkmenistan, Ukraine,
Uzbekistan, Yugoslavia; this group is identical to the IMF group
"countries in transition" except for the IMF''s inclusion of Mongolia
Four Dragons: the four small Asian less developed countries (LDCs)
that have experienced unusually rapid economic growth; also known as
the Four Tigers; this group consists of Hong Kong, South Korea,
Singapore, Taiwan; these countries are included in the IMF''s "advanced
economies" group
Franc Zone (FZ): note - also known as Conference des Ministres des
Finances des Pays de la Zone Franc
established - 1964
aim - to form a monetary union among countries whose currencies
were0000000 linked to the French franc
members - (16) Benin, Burkina Faso, Cameroon, Central African Republic,
Chad, Comoros, Republic of the Congo, Cote d''Ivoire, Equatorial Guinea,
France, Gabon, Guinea-Bissau, Mali, Niger, Senegal, Togo
Front Line States (FLS): established to achieve black majority rule in
South Africa; has since gone out of existence; members included Angola,
Botswana, Mozambique, Namibia, Tanzania, Zambia, Zimbabwe
General Agreement on Tariffs and Trade (GATT): see the World Trade
Organization (WTO)
General Confederation of Trade Unions (GFTU): established - 16 April
1992
aim - to consolidate trade union actions to protect citizens'' social
and labor rights and interests, to help secure trade unions'' rights and
guarantees, and to strengthen international trade union solidarity
members - (11) Armenia, Azerbaijan, Belarus, Georgia, Kazakhstan,
Kyrgyzstan, Moldova, Russia, Tajikistan, Ukraine, Uzbekistan
Group of 2 (G-2): informal term that came into use about 1986; to
facilitate bilateral economic cooperation between the two most powerful
economic giants; members were Japan, US
Group of 3 (G-3): established - September 1990
aim - mechanism for policy coordination
members - (3) Colombia, Mexico, Venezuela
Group of 5 (G-5): established - 22 September 1985
aim - to coordinate the economic policies of five major noncommunist
economic powers
members - (5) France, Germany, Japan, UK, US
Group of 6 (G-6): note - also known as Groupe des Six Sur le
Desarmement; not to be confused with the Big Six
established - 22 May 1984
aim - to achieve nuclear disarmament
members - (6) Argentina, Greece, India, Mexico, Sweden, Tanzania
Group of 7 (G-7): note - membership is the same as the Big Seven
established - 22 September 1985
aim - to facilitate economic cooperation among the seven major
noncommunist economic powers
members - (7) Group of 5 (France, Germany, Japan, UK, US) plus Canada
and Italy
Group of 8 (G-8): established - October 1975
aim - to facilitate economic cooperation among the developed countries
(DCs) that participated in the Conference on International Economic
Cooperation (CIEC), held in several sessions between December 1975 and
3 June 1977
members - (8) Canada, France, Germany, Italy, Japan, Russia, UK, US
Group of 9 (G-9): established - NA
aim - to discuss matters of mutual interest on an informal basis
members - (9) Austria, Belgium, Bulgaria, Denmark, Finland, Hungary,
Romania, Serbia, Sweden
Group of 10 (G-10): note - also known as the Paris Club; includes the
wealthiest members of the IMF who provide most of the money to be
loaned and act as the informal steering committee; name persists
despite increased membership
established - October 1962
aim - to coordinate credit policy
members - (11) Belgium, Canada, France, Germany, Italy, Japan,
Netherlands, Sweden, Switzerland, UK, US
observers - (4) BIS, EU, IMF, OECD
Group of 11 (G-11): note - also known as the Cartagena Group
established in 21-22 June 1984, in Cartagena, Colombia, aim was to
provide a forum for largest debtor nations in Latin America; members
were: Argentina, Bolivia, Brazil, Chile, Colombia, Dominican Republic,
Ecuador, Mexico, Peru, Uruguay, Venezuela
Group of 15 (G-15): note - byproduct of the Nonaligned Movement; name
persists despite increased membership
established - September 1989
aim - to promote economic cooperation among developing nations; to act
as the main political organ for the Nonaligned Movement
members - (19) Algeria, Argentina, Brazil, Chile, Colombia, Egypt,
India, Indonesia, Iran, Jamaica, Kenya, Malaysia, Mexico, Nigeria,
Peru, Senegal, Sri Lanka, Venezuela, Zimbabwe
Group of 24 (G-24): established - 1 August 1989
aim - to promote the interests of developing countries in Africa, Asia,
and Latin America within the IMF
members - (24) Algeria, Argentina, Brazil, Colombia, Democratic
Republic of the Congo, Cote d''Ivoire, Egypt, Ethiopia, Gabon, Ghana,
Guatemala, India, Iran, Lebanon, Mexico, Nigeria, Pakistan, Peru,
Philippines, South Africa, Sri Lanka, Syria, Trinidad and Tobago,
Venezuela
observers - (1) China
Group of 77 (G-77): established - 15 June1964; October 1967 first
ministerial meeting
aim - to promote economic cooperation among developing countries; name
persists in spite of increased membership
members - (130 plus the Palestine Liberation Organization) Afghanistan,
Algeria, Angola, Antigua and Barbuda, Argentina, The Bahamas, Bahrain,
Bangladesh, Barbados, Belize, Benin, Bhutan, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil, Brunei, Burkina Faso, Burma, Burundi,
Cambodia, Cameroon, Cape Verde, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Republic of
the Congo, Costa Rica, Cote d''Ivoire, Cuba, Djibouti, Dominica,
Dominican Republic, East Timor, Ecuador, Egypt, El Salvador, Equatorial
Guinea, Eritrea, Ethiopia, Fiji, Gabon, The Gambia, Ghana, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, India,
Indonesia, Iran, Iraq, Jamaica, Jordan, Kenya, North Korea, Kuwait,
Laos, Lebanon, Lesotho, Liberia, Libya, Madagascar, Malawi, Malaysia,
Maldives, Mali, Marshall Islands, Mauritania, Mauritius, Federated
States of Micronesia, Mongolia, Morocco, Mozambique, Namibia, Nepal,
Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Qatar, Romania, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao Tome
and Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone,
Singapore, Solomon Islands, Somalia, South Africa, Sri Lanka, Sudan,
Suriname, Swaziland, Syria, Tanzania, Thailand, Togo, Tonga, Trinidad
and Tobago, Tunisia, Turkmenistan, Uganda, UAE, Uruguay, Vanuatu,
Venezuela, Vietnam, Yemen, Zambia, Zimbabwe, Palestine Liberation
Organization
Gulf Cooperation Council (GCC): note - also known as the Cooperation
Council for the Arab States of the Gulf
established - 25 May 1981
aim - to promote regional cooperation in economic, social, political,
and military affairs
members - (6) Bahrain, Kuwait, Oman, Qatar, Saudi Arabia, UAE
Organization for Democracy and Economic Development (GUAM): note-
acronym standing for the member countries, Georgia, Ukraine,
Azerbaijan, Moldova; formerly known as GUUAM before Uzbekistan withdrew
in 5 May 2005
established - 7 June 2001
aim - commits the countries to cooperation and assistance in social and
economic development, the strengthening and broadening of trade and
economic relations, and the development and effective use of transport
and communications, highways, and related infrastructure crossing the
boundaries of the member states
members - (4) Azerbaijan, Georgia, Moldova, Ukraine
high income countries: another term for the industrialized countries
with high per capita GDPs; see developed countries (DCs)
Indian Ocean Commission (InOC): established - 21 December 1982
aim - to organize and promote regional cooperation in all sectors,
especially economic
members - (5) Comoros, France (for Reunion), Madagascar, Mauritius,
new indep','b7a1635b17dc77fa53e37a86bb69c3e461cdbaba53a8fa1bc55d6702f2123530','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58600347fec2c450eacb84a3837c19625f134a03a00cf72ed877076eb8d6854a',2007,'UZ','Uzbekistan','environment',1126,'endent states (NIS): a term referring to all the countries of
the FSU except the Baltic countries (Estonia, Latvia, Lithuania)
newly industrializing countries (NICs): former term for the newly
industrializing economies; see newly industrializing economies (NIEs)
newly industrializing economies (NIEs): that subgroup of the less
developed countries (LDCs) that has experienced particularly rapid
industrialization of their economies; formerly known as the newly
industrializing countries (NICs); also known as advanced developing
countries; usually includes the Four Dragons (Hong Kong, South Korea,
Singapore, Taiwan), and Brazil
Nonaligned Movement (NAM): established - 1-6 September 1961
aim - to establish political and military cooperation apart from the
traditional East or West blocs
members - (116 plus the Palestine Liberation Organization) Afghanistan,
Algeria, Angola, Antigua and Barbuda,The Bahamas, Bahrain, Bangladesh,
Barbados, Belarus, Belize, Benin, Bhutan, Bolivia, Botswana, Brunei,
Burkina Faso, Burma, Burundi, Cambodia, Cameroon, Cape Verde, Central
African Republic, Chad, Chile, Colombia, Comoros, Democratic Republic
of the Congo, Republic of the Congo, Cote d''Ivoire, Cuba, Djibouti,
Dominica, Dominican Republic, East Timor, Ecuador, Egypt, Equatorial
Guinea, Eritrea, Ethiopia, Gabon, The Gambia, Ghana, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, India,
Indonesia, Iran, Iraq, Jamaica, Kenya, North Korea, Kuwait, Laos,
Lebanon, Lesotho, Liberia, Libya, Madagascar, Malawi, Malaysia,
Maldives, Mali, Mauritania, Mauritius, Mongolia, Morocco, Mozambique,
Namibia, Nepal, Nicaragua, Niger, Nigeria, Oman, Pakistan, Panama,
Papua New Guinea, Peru, Philippines, Qatar, Rwanda, Saint Kitts and
Nevis, Saint Lucia, Saint Vincent and the Grenadines, Sao Tome and
Principe, Saudi Arabia, Senegal, Seychelles, Sierra Leone, Singapore,
Somalia, South Africa, Sri Lanka, Sudan, Suriname, Swaziland, Syria,
Tanzania, Thailand, Togo, Trinidad and Tobago, Tunisia, Turkmenistan,
Uganda, UAE, Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia,
Zimbabwe, Palestine Liberation Organization
observers - (15) Armenia, Azerbaijan, Bosnia and Herzegovina, Brazil,
China, Costa Rica, Croatia, El Salvadore, Kazakhstan, Kyrgyzstan,
Mexico, Paraguay, Serbia, Ukraine, Uruguay
guests - (23) Australia, Austria, Bulgaria, Canada, Czech Republic,
Finland, Germany, Greece, Holy See, Hungary, Italy, Netherlands, NZ,
Norway, Poland, Portugal, Romania, Russia, Slovakia, Slovenia, Spain,
Sweden, Switzerland
Nordic Council (NC): established - 16 March 1952; effective - 12
February 1953
aim - to promote regional economic, cultural, and environmental
cooperation
members - (5) Denmark (including Faroe Islands and Greenland), Finland
(including Aland Islands), Iceland, Norway, Sweden
observers - (3) the Sami (Lapp) local parliaments of Finland, Norway,
and Sweden
Nordic Investment Bank (NIB): established - 4 December 1975; effective
- 1 June 1976
aim - to promote economic cooperation and development
members - (8) Denmark (including Faroe Islands and Greenland), Estonia,
Finland (including Aland Islands), Iceland, Latvia, Lithuania, Norway,
observer - (4) India, Iran, Mongolia, Pakistan
socialist countries: in general, countries in which the government
owns and plans the use of the major factors of production; note - the
term is sometimes used incorrectly as a synonym for Communist countries
South: a popular term for the poorer, less industrialized countries
generally located south of the developed countries; the counterpart of
the North; see less developed countries (LDCs)
South American Community of Nations (CSN): established - 9 December
2004
aim - to coordinate common policies regarding multilateral
organizations, to integrate physical infrastructure, and to consolidate
the merger of CAN and Mercosur
members - (12) Argentina, Bolivia, Brazil, Chile, Colombia, Ecuador,
Guyana, Paraguay, Peru, Surinam, Uruguay, Venezuela
observers - (2) Mexico, Panama
South Asia Co-operative Environment Program (SACEP): established -
January 1983
aim - to promote regional cooperation in South Asia in the field of
environment, both natural and human, and on issues of economic and
social development; to support conservation and management of natural
resources of the region
members - (7) Bangladesh, Bhutan, India, Maldives, Nepal, Pakistan, Sri
Lanka
South Asian Association for Regional Cooperation (SAARC): established
- 8 December 1985
aim - to promote economic, social, and cultural cooperation
members - (7) Bangladesh, Bhutan, India, Maldives, Nepal, Pakistan, Sri
Lanka
observers - (5) China, EC, Japan, South Korea, US
South Pacific Forum (SPF): note - see Pacific Island Forum
South Pacific Regional Trade and Economic Cooperation Agreement
(Sparteca): established - 1981
aim - to redress unequal trade relationships of Australia and New
Zealand with small island economies in the Pacific region
members - (16) Australia, Cook Islands, Fiji, Kiribati, Marshall
Islands, Federated States of Micronesia, Nauru, NZ, Niue, Palau, Papua
New Guinea, Samoa, Solomon Islands, Tonga, Tuvalu, Vanuatu
Southeast European Cooperative Initiative (SECI): established - 6
December 1996
aim - to encourage cooperation among participating states and to
facilitate their integration into European structures
members - (12) Albania, Bosnia and Herzegovina, Bulgaria, Croatia,
Greece, Hungary, Macedonia, Moldova, Romania, Serbia, Slovenia, Turkey
observers - (15) Austria, Azerbaijan, Belgium, Canada, France, Georgia,
Germany, Italy, Japan, Netherlands, Portugal, Spain, Ukraine, UK, US
Southern African Customs Union (SACU): established - 11 December 1969
aim - to promote free trade and cooperation in customs matters
members - (5) Botswana, Lesotho, Namibia, South Africa, Swaziland
Southern African Development Community (SADC): note - evolved from the
Southern African Development Coordination Conference (SADCC)
established - 17 August 1992
aim - to promote regional economic development and integration
members - (14) Angola, Botswana, Democratic Republic of the Congo,
Lesotho, Madagascar, Malawi, Mauritius, Mozambique, Namibia, South
Africa, Swaziland, Tanzania, Zambia, Zimbabwe
Southern Cone Common Market (Mercosur) or Southern Common Market: note
- also known as Mercado Comun del Cono Sur (Mercosur)
established - 26 March 1991
aim - to increase regional economic cooperation
members - (5) Argentina, Brazil, Paraguay, Uruguay, Venezuela
associate members - (5) Bolivia, Chile, Colombia, Ecuador, Peru; note -
Mexico is to become an associate member by the end of 2006
Third World: another term for the less developed countries; the term
is obsolescent; see less developed countries (LDCs)
underdeveloped countries: refers to those less developed countries
with the potential for above-average economic growth; see less
developed countries (LDCs)
undeveloped countries: refers to those extremely poor less developed
countries (LDCs) with little prospect for economic growth; see least
developed countries (LLDCs)
United Nations (UN): established - 26 June 1945; effective - 24
October 1945
aim - to maintain international peace and security and to promote
cooperation involving economic, social, cultural, and humanitarian
problems
constituent organizations - the UN is composed of six principal organs
and numerous subordinate agencies and bodies as follows:
1) Secretariat
2) General Assembly: Joint United Nations Program on HIV/AIDS (UN
AIDS), International Research and Training Institute for the
Advancement of Women (INSTRAW), Office of the United Nations High
Commissioner for Human Rights (OHCHR), Organization for the Prohibition
of Chemical Weapons (OPCW), Preparation Commission for the Nuclear-Ban-
Treaty Operation ((CTBTU), United Nations Center for Human Settlements
(UN-Habitat), United Nations Children''s Fund (UNICEF), United Nations
Conference on Trade and Development (UNCTAD), United Nations
Development Program (UNDP), United Nations Drug Control Program
(UNDCP), United Nations Environment Program (UNEP), United Nations High
Commissioner for Refugees (UNHCR), United Nations Institute for
Disarmament Research (UNIDIR), United Nations Institute for Training
and Research (UNITAR), United Nations Interregional Crime and Justice
Research Institute (UNICRI), United Nations Population Fund (UNFPA),
United Nations Office of Project Services (UNOPS), United Nations
Relief and Works Agency for Palestine Refugees in the Near East
(UNRWA), United Nations Research Institute for Social Development
(UNRISD), United Nations System Staff College (UNSSC), United Nations
University (UNU), World Food Program (WFP)
3) Security Council: International Criminal Tribunal for the Former
Yugoslavia (ICTY), International Criminal Tribunal for Rwanda (ICTR),
United Nations Compensation Commission, United Nations Disengagement
Observer Force (UNDOF), United Nations Integrated Mission in Timor-
Leste (UNMIT), United Nations Interim Administration Mission in Kosovo
(UNMIK), United Nations Interim Force in Lebanon (UNIFIL), United
Nations Mission in Liberia (UNMIL), United Nations Military Observer
Group in India and Pakistan (UNMOGIP), United Nations Operation in
Burundi (ONUB), United Nations Operation in Cote d''Ivoire (UNOCI),
United Nations Mission for the Referendum in Western Sahara (MINURSO),
United Nations Mission in Ethiopia and Eritrea (UNMEE), United Nations
Mission in the Sudan (UNMIS), United Nations Monitoring and
Verification Commission (UNMOVIC), United Nations Observer Mission in
Georgia (UNOMIG), United Nations Organization Mission in the Democratic
Republic of the Congo (MONUC), United Nations Peace-Keeping Force in
Cyprus (UNFICYP), United Nations Stabilization Mission in Haiti
(MINUSTAH), and United Nations Truce Supervision Organization (UNTSO)
4) Economic and Social Council (ECOSOC): Commission for Social
Development, Commission on Crime Prevention and Criminal Justice,
Commission on Narcotics Drugs, Commission on Population and
Development, Commission on Science and Technology for Development,
Commission on Sustainable Development, Commission on the Status of
Women, Economic and Social Commission for Asia and the Pacific (ESCAP),
Economic and Social Commission for Western Asia (ESCWA), Economic
Commission for Africa (ECA), Economic Commission for Europe (ECE),
Economic Commission for Latin America and the Caribbean (ECLAC), Food
and Agriculture Organization of the United Nations (FAO), International
Atomic Energy Agency (IAEA), International Bank for Reconstruction and
Development (IBRD), International Center for Secretariat of Investment
Disputes (ICSID), International Civil Aviation Organization (ICAO),
International Development Association (IDA), International Finance
Corporation (IFC), International Fund for Agricultural Development
(IFAD), International Labor Organization (ILO), International Maritime
Organization (IMO), International Monetary Fund (IMF), International
Telecommunication Union (ITU), Multilateral Investment Geographic
Agency (MIGA), Statistical Commission, United Nations Educational,
Scientific, and Cultural Organization (UNESCO), United Nations Forum on
Forests, United Nations Industrial Development Organization (UNIDO),
Universal Postal Union (UPU), World Health Organization (WHO), World
Intellectual Property Organization (WIPO), World Meteorological
Organization (WMO), World Tourism Organization (WToO), and World Trade
Organization (WTO)
5) Trusteeship Council (inactive; no trusteeships at this time)
6) International Court of Justice (ICJ)
United Nations Children''s Fund (UNICEF): note - acronym retained from
the predecessor organization, UN International Children''s Emergency
Fund
established - 11 December 1946
aim - to help establish child health and welfare services
members - (36) selected on a rotating basis from all regions
United Nations Conference on Trade and Development (UNCTAD):
established - 30 December 1964
aim - to promote international trade
members - (193) all UN members plus Holy See
United Nations Development Program (UNDP): established - 22 November
1965
aim - to provide technical assistance to stimulate economic and social
development
members (executive board) - (36) selected on a rotating basis from all
regions
United Nations Disengagement Observer Force (UNDOF): established - 31
May 1974
aim - to observe the 1973 Arab-Israeli cease-fire; established by the
UN Security Council
members - (7) Austria, Canada, India, Japan, Nepal, Poland, Slovakia
United Nations Educational, Scientific, and Cultural Organization
(UNESCO): established - 16 November 1945; effective - 4 November 1946
aim - to promote cooperation in education, science, and culture
members - (191) includes all UN member countries except Liechtenstein,
Montenegro, and Singapore (188 total); plus Cook Islands and Niue
associate members - (6) Aruba, British Virgin Islands, Cayman Islands,
Macau, Netherlands Antilles, Tokelau
United Nations Environment Program (UNEP): established - 15 December
1972
aim - to promote international cooperation on all environmental matters
members - (58) selected on a rotating basis from all regions
United Nations General Assembly: established - 26 June 1945; effective
- 24 October 1945
aim - to function as the primary deliberative organ of the UN
members - (192) all UN members are represented in the General Assembly
United Nations High Commissioner for Refugees (UNHCR): established - 3
December 1949; effective - 1 January 1951
aim - to ensure the humanitarian treatment of refugees and find
permanent solutions to refugee problems
members (executive committee) - (70) Algeria, Argentina, Australia,
Austria, Bangladesh, Belgium, Brazil, Canada, Chile, China, Colombia,
Democratic Republic of the Congo, Cote d''Ivoire, Cyprus, Denmark,
Ecuador, Egypt, Ethiopia, Finland, France, Germany, Ghana, Greece,
Guinea, Holy See, Hungary, India, Iran, Ireland, Israel, Italy, Japan,
Jordan, Kenya, South Korea, Lebanon, Lesotho, Madagascar, Mexico,
Morocco, Mozambique, Namibia, Netherlands, NZ, Nicaragua, Nigeria,
Norway, Pakistan, Philippines, Poland, Portugal, Romania, Russia,
Serbia, Somalia, South Africa, Spain, Sudan, Sweden, Switzerland,
Tanzania, Thailand, Tunisia, Turkey, Uganda, UK, US, Venezuela, Yemen,
Argun River China, Russia 53 20 N 121 28 E
Aru Sea Pacific Ocean 6 15 S 135 00 E
As-Sudan (local name for Sudan 15 00 N 30 00 E
Sudan)
Ascension Island Saint Helena 7 57 S 14 22 W
Ashgabat, Ashkhabad Turkmenistan 37 57 N 58 23 E
(capital)
Asmara, Asmera (capital) Eritrea 15 20 N 38 53 E
Assumption Island Seychelles 9 46 S 46 34 E
Astana (capital; formerly Kazakhstan 51 10 N 71 30 E
Akmola)
Asuncion (capital) Paraguay 25 16 S 57 40 W
Asuncion Island Northern Mariana 19 40 N 145 24 E
Islands
Atacama (desert) Chile 23 00 S 70 10 W
Atacama (region) Chile 24 30 S 69 15 W
Athens (capital) Greece 37 59 N 23 44 E
Attu Island United States 52 55 N 172 57 E
Auckland (city) New Zealand 36 52 S 174 46 E
Auckland Islands New Zealand 51 00 S 166 30 E
Australes, Iles (island French Polynesia 23 20 S 151 00 W
group; also Iles Tubuai)
Avarua (capital) Cook Islands 21 12 S 159 46 W
Axel Heiberg Island Canada 79 30 N 90 00 W
Azad Kashmir (region) Pakistan 34 30 N 74 00 E
Azarbaycan, Azerbaidzhan Azerbaijan 40 30 N 47 30 E
(local name for
Azerbaijan)
Azores (islands) Portugal 38 30 N 28 00 W
Azov, Sea of Atlantic Ocean 49 00 N 36 00 E
Bab el Mandeb (strait) Indian Ocean 12 40 N 43 20 E
Babuyan Channel Pacific Ocean 18 44 N 121 40 E
Babuyan Islands Philippines 19 10 N 121 40 E
Baffin Bay Arctic Ocean 73 00 N 66 00 W
Baffin Island Canada 68 00 N 70 00 W
Baghdad (capital) Iraq 33 21 N 44 25 E
Baku (capital; also Baki, Azerbaijan 40 23 N 49 51 E
Baky)
Balabac Strait Pacific Ocean 7 35 N 117 00 E
Balearic Islands Spain 39 30 N 3 00 E
Balearic Sea (Iberian Atlantic Ocean 40 30 N 2 00 E
Sea)
Bali (island) Indonesia 8 20 S 115 00 E
Bali Sea Indian Ocean 7 45 S 115 30 E
Balintang Channel Pacific Ocean 19 49 N 121 40 E
Balintang Islands Philippines 19 55 N 122 10 E
Balkan Peninsula Albania, Bosnia and 42 00 N 23 00 E
Herzegovina,
Bulgaria, Croatia,
Greece, Macedonia,
Montenegro,
Romania, Serbia,
Slovenia, Turkey
(European part)
Balleny Islands Antarctica 67 00 S 163 00 E
Balochistan (region) Pakistan 28 00 N 63 00 E
Baltic Sea Atlantic Ocean 57 00 N 19 00 E
Bamako (capital) Mali 12 39 N 8 00 W
Banaba (Ocean Island) Kiribati 0 52 S 169 35 E
Banat (region) Hungary, Romania, 45 30 N 21 00 E
Fernando Po (island; see Equatorial Guinea 3 30 N 8 42 E
Bioko)
Fernando de Noronha Brazil 3 51 S 32 25 W
(island group)
Filipinas (local name for Philippines 13 00 N 122 00 E
the Philippines; also
Pilipinas)
Finland, Gulf of Atlantic Ocean 60 00 N 27 00 E
Florence (city) Italy 43 46 N 11 16 E
Flores (island) Indonesia 8 45 S 121 00 E
Flores Sea Pacific Ocean 7 40 S 119 45 E
Florida, Straits of Atlantic Ocean 25 00 N 79 45 W
Fongafale (largest island Tuvalu 8 30 S 179 12 E
of Funafuti)
Former Soviet Union (FSU) Armenia,
Azerbaijan,
Belarus, Estonia,
Georgia,
Kazakhstan,
Kyrgyzstan, Latvia,
Lithuania, Moldova,
Russia, Tajikistan,
Turkmenistan,
Ukraine, Uzbekistan
Formosa (island) Taiwan 23 30 N 121 00 E
Formosa Strait (see Pacific Ocean 24 00 N 119 00 E
Taiwan Strait)
Foroyar (local name for Faroe Islands 62 00 N 7 00 W
Faroe Islands)
Fort-de-France (capital) Martinique 14 36 N 61 05 W
Frankfurt am Main (city) Germany 50 07 N 8 41 E
Franz Josef Land (island Russia 81 00 N 55 00 E
group)
Freetown (capital) Sierra Leone 8 30 N 13 15 W
French Cameroon (former Cameroon 6 00 N 12 00 E
name for Cameroon)
French Guinea (former Guinea 11 00 N 10 00 W
name for Guinea)
French Indochina (former Cambodia, Laos, 15 00 N 107 00 E
name for French Vietnam
possessions in southeast
Asia)
French Morocco (former Morocco 32 00 N 5 00 W
name for Morocco)
French Somaliland (former Djibouti 11 30 N 43 00 E
name for Djibouti)
French Sudan (former name Mali 17 00 N 4 00 W
for Mali)
French Territory of the Djibouti 11 30 N 43 00 E
Afars and Issas (or FTAI;
former name for Djibouti)
French Togoland (former Togo 8 00 N 1 10 E
name for Togo)
French West Indies Guadeloupe, 16 30 N 62 00 W
(former name for French Martinique
possessions in the West
Indies)
Friendly Islands Tonga 20 00 S 175 00 W
Frisian Islands Denmark, Germany, 53 35 N 6 40 E','b861643fab44f8ea901e89615405d6055da0ff9b80317883ec2a4641e8f6b30a','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2946743e655b8ef8b7f9e974142b8e8393106af6112f9b833b11b6e73fcf2025',2007,'SC','Seychelles','environment',1127,'industrial countries: another term for the developed countries; see
developed countries (DCs)
Inter-American Development Bank (IADB): note - also known as Banco
Interamericano de Desarrollo (BID)
established - 8 April 1959; effective - 30 December 1959
aim - to promote economic and social development in Latin America
members - (47) Argentina, Austria, The Bahamas, Barbados, Belgium,
Belize, Bolivia, Brazil, Canada, Chile, Colombia, Costa Rica, Croatia,
Denmark, Dominican Republic, Ecuador, El Salvador, Finland, France,
Germany, Guatemala, Guyana, Haiti, Honduras, Israel, Italy, Jamaica,
Japan, South Korea, Mexico, Netherlands, Nicaragua, Norway, Panama,
Paraguay, Peru, Portugal, Slovenia, Spain, Suriname, Sweden,
Switzerland, Trinidad and Tobago, UK, US, Uruguay, Venezuela
Inter-Governmental Authority on Development (IGAD): note - formerly
known as Inter-Governmental Authority on Drought and Development
(IGADD)
established - 15-16 January 1986 as the Inter-Governmental Authority on
Drought and Development; revitalized - 21 March 1996 as the Inter-
Governmental Authority on Development
aim - to promote a social, economic, and scientific community among its
members
members - (7) Djibouti, Eritrea, Ethiopia, Kenya, Somalia, Sudan,','89669f58c13351f14781bb88e9186bb72751c05809dcbe8c4100700d03cafcfa','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fa286210b8f1af313ea4a680cc4f3cbd78eeb57cbaba827d9517db524318211c',2007,'UG','Uganda','environment',1128,'Inter-Parliamentary Union (IPU): established - 1889
aim - fosters contacts among parliamentarians, considers and expresses
views of international interest and concern with the purpose of
bringing about action by parliaments and parliamentarians, contributes
to the defense and promotion of human rights, contributes to better
knowledge of representative institutions
members - (148) Albania, Algeria, Andorra, Angola, Argentina, Armenia,
Australia, Austria, Azerbaijan, Bahrain, Bangladesh, Belarus, Belgium,
Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil, Bulgaria,
Burkina Faso, Burundi, Cambodia, Cameroon, Canada, Cape Verde, Chile,
China, Colombia, Democratic Republic of the Congo, Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador,
Estonia, Ethiopia, Fiji, Finland, France, Gabon, The Gambia, Georgia,
Germany, Ghana, Greece, Guatemala, Guinea, Hungary, Iceland, India,
Indonesia, Iran, Ireland, Israel, Italy, Japan, Jordan, Kazahstan,
Kenya, North Korea, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia,
Lebanon, Liberia, Libya, Lichtenstein, Lithuania, Luxembourg,
Macedonia, Madagascar, Malaysia, Maldives, Mali, Malta, Mauritius,
Mexico, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique,
Namibia, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Norway,
Pakistan, Palau, Panama, Papua New Guinea, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Rwanda, Somalia, Samoa, San
Marino, Sao Tome and Principe, Saudi Arabia, Senegal, Serbia,
Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Sweden, Switzerland, Syria, Tanzania, Tajikistan, Thailand,
Togo, Tunisia, Turkey, Uganda, Ukraine, UAE, UK, Uruguay, Uzbekistan,
Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
associate members - (7) Andean Parliament, Central American Parliament,
Community Parliament of the Economic Community of West African States,
East African Legislative Assembly, European Parliament, Latin American
Parliament, Parliamentary Assembly of the Council of Europe
International Atomic Energy Agency (IAEA): established - 26 October
1956; effective - 29 July 1957
aim - to promote peaceful uses of atomic energy
members - (145) Afghanistan, Albania, Algeria, Angola, Argentina,
Armenia, Australia, Austria, Azerbaijan, Bangladesh, Belarus, Belgium,
Belize, Benin, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Bulgaria, Burkina Faso, Burma, Cameroon, Canada, Central African
Republic, Chad, Chile, China, Colombia, Democratic Republic of the
Congo, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Dominican Republic, Ecuador, Egypt, El Salvador,
Eritrea, Estonia, Ethiopia, Finland, France, Gabon, Georgia, Germany,
Ghana, Greece, Guatemala, Haiti, Holy See, Honduras, Hungary, Iceland,
India, Indonesia, Iran, Iraq, Ireland, Israel, Italy, Jamaica, Japan,
Jordan, Kazakhstan, Kenya, South Korea, Kuwait, Kyrgyzstan, Latvia,
Lebanon, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg,
Macedonia, Madagascar, Malawi, Malaysia, Mali, Malta, Marshall Islands,
Mauritania, Mauritius, Mexico, Moldova, Monaco, Mongolia, Montenegro,
Morocco, Mozambique, Namibia, Netherlands, NZ, Nicaragua, Niger,
Nigeria, Norway, Pakistan, Palau, Panama, Paraguay, Peru, Philippines,
Poland, Portugal, Qatar, Romania, Russia, Saudi Arabia, Senegal,
Serbia, Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, South
Africa, Spain, Sri Lanka, Sudan, Sweden, Switzerland, Syria,
Tajikistan, Tanzania, Thailand, Togo, Tunisia, Turkey, Uganda, Ukraine,
UAE, UK, US, Uruguay, Uzbekistan, Venezuela, Vietnam, Yemen, Zambia,','fea779b7ff678fb704857b624e7eba6b0dc687ed082d64679755257f563bf917','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0369c6bb1d9579461a3b34c4ac495829960a037b93fc517ff015ba31de29dff3',2007,'SE','Sweden','environment',1129,'North: a popular term for the rich industrialized countries generally
located in the northern portion of the Northern Hemisphere; the
counterpart of the South; see developed countries (DCs)
North American Free Trade Agreement (NAFTA): established - 17 December
1992
aim - to eliminate trade barriers, promote fair competition, increase
investment opportunities, provide protection of intellectual property
rights, and create procedures to settle disputes
members - (3) Canada, Mexico, US
North Atlantic Treaty Organization (NATO): established - 4 April 1949
aim - to promote mutual defense and cooperation
members - (26) Belgium, Bulgaria, Canada, Czech Republic, Denmark,
Estonia, France, Germany, Greece, Hungary, Iceland, Italy, Latvia,
Lithuania, Luxembourg, Netherlands, Norway, Poland, Portugal, Romania,
Slovakia, Slovenia, Spain, Turkey, UK, US
Nuclear Energy Agency (NEA): note - also known as OECD Nuclear Energy
Agency
established - 1 February 1958
aim - to promote the peaceful uses of nuclear energy; associated with
OECD
members - (28) Australia, Austria, Belgium, Canada, Czech Republic,
Denmark, Finland, France, Germany, Greece, Hungary, Iceland, Ireland,
Italy, Japan, South Korea, Luxembourg, Mexico, Netherlands, Norway,
Portugal, Slovakia, Spain, Sweden, Switzerland, Turkey, UK, US
Nuclear Suppliers Group (NSG): note - also known as the London
Suppliers Group or the London Group
established - 1974; effective - 1975
aim - to establish guidelines for exports of nuclear materials,
processing equipment for uranium enrichment, and technical information
to countries of proliferation concern and regions of conflict and
instability
members - (45) Argentina, Australia, Austria, Belarus, Belgium, Brazil,
Bulgaria, Canada, China, Croatia, Cyprus, Czech Republic, Denmark,
Estonia, Finland, France, Germany, Greece, Hungary, Ireland, Italy,
Japan, Kazakhstan, South Korea, Latvia, Lithuania, Luxembourg, Malta,
Netherlands, NZ, Norway, Poland, Portugal, Romania, Russia, Slovakia,
Slovenia, South Africa, Spain, Sweden, Switzerland, Turkey, Ukraine,
UK, US
observer - (1) European Commission (a policy-planning body for the EU)
Organization for Economic Cooperation and Development (OECD):
established - 14 December 1960; effective - 30 September 1961
aim - to promote economic cooperation and development
members - (30) Australia, Austria, Belgium, Canada, Czech Republic,
Denmark, Finland, France, Germany, Greece, Hungary, Iceland, Ireland,
Italy, Japan, South Korea, Luxembourg, Mexico, Netherlands, NZ, Norway,
Poland, Portugal, Slovakia, Spain, Sweden, Switzerland, Turkey, UK, US
special member - (1) EC
Organization for Security and Cooperation in Europe (OSCE): note -
formerly the Conference on Security and Cooperation in Europe (CSCE)
established 3 July 1975
established - 1 January 1995
aim - to foster the implementation of human rights, fundamental
freedoms, democracy, and the rule of law; to act as an instrument of
early warning, conflict prevention, and crisis management; and to serve
as a framework for conventional arms control and confidence building
measures
members - (56) Albania, Andorra, Armenia, Austria, Azerbaijan, Belarus,
Belgium, Bosnia and Herzegovina, Bulgaria, Canada, Croatia, Cyprus,
Czech Republic, Denmark, Estonia, Finland, France, Georgia, Germany,
Greece, Holy See, Hungary, Iceland, Ireland, Italy, Kazakhstan,
Kyrgyzstan, Latvia, Liechtenstein, Lithuania, Luxembourg, Macedonia,
Malta, Moldova, Monaco, Montenegro, Netherlands, Norway, Poland,
Portugal, Romania, Russia, San Marino, Serbia, Slovakia, Slovenia,
Spain, Sweden, Switzerland, Tajikistan, Turkey, Turkmenistan, Ukraine,
UK, US, Uzbekistan
partners for cooperation - (11) Afghanistan, Algeria, Egypt, Israel,
Japan, Jordan, South Korea, Mongolia, Morocco, Thailand, Tunisia
Organization for the Prohibition of Chemical Weapons (OPCW):
established - 29 April 1997
aim - to enforce the Convention on the Prohibition of the Development,
Production, Stockpiling, and Use of Chemical Weapons and on Their
Destruction; to provide a forum for consultation and cooperation among
the signatories of the Convention
members (countries that have ratified the Convention) - (181)
Afghanistan, Albania, Algeria, Andorra, Antigua and Barbuda, Argentina,
Armenia, Australia, Austria, Azerbaijan, Bahrain, Bangladesh, Belarus,
Belgium, Belize, Benin, Bhutan, Bolivia, Bosnia and Herzegovina,
Botswana, Brazil, Brunei, Bulgaria, Burkina Faso, Burundi, Cambodia,
Cameroon, Canada, Cape Verde, Central African Republic, Chad, Chile,
China, Colombia, Comoros, Democratic Republic of the Congo, Cook
Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba, Cyprus, Czech
Republic, Denmark, Dominica, Djibouti, East Timor, Ecuador, El
Salvador, Equatorial Guinea, Eritrea, Estonia, Ethiopia, Fiji, Finland,
France, Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guyana, Haiti, Holy See, Honduras, Hungary, Iceland,
India, Indonesia, Iran, Ireland, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, Kiribati, South Korea, Kuwait, Kyrgyzstan, Laos,
Latvia, Lesotho, Liberia, Libya, Liechtenstein, Lithuania, Luxembourg,
Macedonia, Madagascar, Malawi, Malaysia, Maldives, Mali, Malta,
Marshall Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Montenegro, Morocco, Mozambique,
Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria,
Niue, Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea,
Paraguay, Peru, Philippines, Poland, Portugal, Qatar, Romania, Russia,
Rwanda, Saint Kitts and Nevis, Saint Lucia, Saint Vincent and the
Grenadines, Samoa, San Marino, Sao Tome and Principe, Saudi Arabia,
Senegal, Serbia, Seychelles, Sierra Leone, Singapore, Slovakia,
Slovenia, Solomon Islands, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Tajikistan, Tanzania,
Thailand, Togo, Tonga, Trinidad and Tobago, Tunisia, Turkey,
Turkmenistan, Tuvalu, Uganda, Ukraine, UAE, UK, US, Uruguay,
Uzbekistan, Vanuatu, Venezuela, Vietnam, Yemen, Zambia, Zimbabwe
signatory states (countries that have signed, but not ratified, the
Convention) - (6) The Bahamas, Burma, Republic of the Congo, Dominican
Republic, Guinea-Bissau, Israel
Organization of African Unity (OAU): see African Union
Organization of American States (OAS): established - 14 April 1890 as
the International Union of American Republics; 30 April 1948 adopted
present charter; effective - 13 December 1951
aim - to promote regional peace and security as well as economic and
social development
members - (35) Antigua and Barbuda, Argentina, The Bahamas, Barbados,
Belize, Bolivia, Brazil, Canada, Chile, Colombia, Costa Rica, Cuba
(excluded from formal participation since 1962), Dominica, Dominican
Republic, Ecuador, El Salvador, Grenada, Guatemala, Guyana, Haiti,
Honduras, Jamaica, Mexico, Nicaragua, Panama, Paraguay, Peru, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Suriname, Trinidad and Tobago, US, Uruguay, Venezuela
observers - (60) Algeria, Angola, Armenia, Austria, Azerbaijan,
Belgium, Bosnia and Herzegovina, Bulgaria, China, Croatia, Cyprus,
Czech Republic, Denmark, Egypt, Equatorial Guinea, Estonia, EU,
Finland, France, Georgia, Germany, Ghana, Greece, Holy See, Hungary,
India, Ireland, Israel, Italy, Japan, Kazakhstan, South Korea, Latvia,
Lebanon, Luxembourg, Morocco, Netherlands, Nigeria, Norway, Pakistan,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Saudi Arabia,
Serbia, Slovakia, Slovenia, Spain, Sri Lanka, Sweden, Switzerland,
Thailand, Tunisia, Turkey, Ukraine, UK, Yemen
Organization of Arab Petroleum Exporting Countries (OAPEC):
established - 9 January 1968
aim - to promote cooperation in the petroleum industry
members - (11) Algeria, Bahrain, Egypt, Iraq, Kuwait, Libya, Qatar,
Saudi Arabia, Syria, Tunisia (suspended), UAE
Organization of Eastern Caribbean States (OECS): established - 18 June
1981; effective - 4 July 1981
aim - to promote political, economic, and defense cooperation
members - (7) Antigua and Barbuda, Dominica, Grenada, Montserrat, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines
associate member - (2) Anguilla, British Virgin Islands
Organization of Petroleum Exporting Countries (OPEC): established - 14
September 1960
aim - to coordinate petroleum policies
members - (11) Algeria, Indonesia, Iran, Iraq, Kuwait, Libya, Nigeria,
Qatar, Saudi Arabia, UAE, Venezuela
Organization of the Islamic Conference (OIC): established - 22-25
September 1969
aim - to promote Islamic solidarity in economic, social, cultural, and
political affairs
members - (56 plus the Palestine Liberation Organization) Afghanistan,
Albania, Algeria, Azerbaijan, Bahrain, Bangladesh, Benin, Brunei,
Burkina Faso, Cameroon, Chad, Comoros, Cote d''Ivoire, Djibouti, Egypt,
Gabon, The Gambia, Guinea, Guinea-Bissau, Guyana, Indonesia, Iran,
Iraq, Jordan, Kazakhstan, Kuwait, Kyrgyzstan, Lebanon, Libya, Malaysia,
Maldives, Mali, Mauritania, Morocco, Mozambique, Niger, Nigeria, Oman,
Pakistan, Qatar, Saudi Arabia, Senegal, Sierra Leone, Somalia, Sudan,
Suriname, Syria, Tajikistan, Togo, Tunisia, Turkey, Turkmenistan,
Uganda, UAE, Uzbekistan, Yemen, Palestine Liberation Organization
observers - (11) AU, Bosnia and Herzegovina, Central African Republic,
ECO, LAS, Moro National Liberation Front, NAM, Russia, Thailand,
Turkish Muslim Community of Kibris, UN
Pacific Community (SPC): note - formerly known as the South Pacific
Commission (SPC)
established - 6 February 1947; effective - 29 July 1948
aim - to promote regional cooperation in economic and social matters
members - (26) American Samoa, Australia, Cook Islands, Fiji, France,
French Polynesia, Guam, Kiribati, Marshall Islands, Federated States of
Micronesia, Nauru, New Caledonia, NZ, Niue, Northern Mariana Islands,
Palau, Papua New Guinea, Pitcairn Islands, Samoa, Solomon Islands,
Tokelau, Tonga, Tuvalu, US, Vanuatu, Wallis and Futuna; note - UK
withdrew in January 2005
Pacific Islands Forum (PIF): note - formerly known as South Pacific
Forum (SPF)
established - 5 August 1971
aim - to promote regional cooperation in political matters
members - (16) Australia, Cook Islands, Fiji, Kiribati, Marshall
Islands, Federated States of Micronesia, Nauru, NZ, Niue, Palau, Papua
New Guinea, Samoa, Solomon Islands, Tonga, Tuvalu, Vanuatu
observers - (4) East Timor, French Polynesia, New Caledonia, Tokelau
Paris Club: established - 1956
aim - to provide a forum for debtor countries to negotiate rescheduling
of debt service payments or loans extended by governments or official
agencies of participating countries; to help restore normal trade and
project finance to debtor countries
members - (19) Australia, Austria, Belgium, Canada, Denmark, Finland,
France, Germany, Ireland, Italy, Japan, Netherlands, Norway, Russia,
Spain, Sweden, Switzerland, UK, US
Partnership for Peace (PFP): established - 10-11 January 1994
aim - to expand and intensify political and military cooperation
throughout Europe, increase stability, diminish threats to peace, and
build relationships by promoting the spirit of practical cooperation
and commitment to democratic principles that underpin NATO; program
under the auspices of NATO
members - (23) Albania, Armenia, Austria, Azerbaijan, Belarus, Bosnia
and Herzegovina, Croatia, Finland, Georgia, Ireland, Kazakhstan,
Kyrgyzstan, Macedonia, Moldova, Montenegro, Russia, Serbia, Sweden,
Switzerland, Tajikistan, Turkmenistan, Ukraine, Uzbekistan; note - a
nation that becomes a member of NATO is no longer a member of PFP
Permanent Court of Arbitration (PCA): established - 29 July 1899
aim - to facilitate the settlement of international disputes
members - (105) Argentina, Australia, Austria, Belarus, Belgium,
Belize, Bolivia, Brazil, Bulgaria, Burkina Faso, Cambodia, Cameroon,
Canada, Chile, China, Colombia, Democratic Republic of the Congo, Costa
Rica, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Dominican
Republic, Ecuador, Egypt, El Salvador, Eritrea, Estonia, Ethiopia,
Fiji, Finland, France, Germany, Greece, Guatemala, Guyana, Haiti,
Honduras, Hungary, Iceland, India, Iran, Iraq, Ireland, Israel, Italy,
Japan, Jordan, Kenya, South Korea, Kuwait, Kyrgyzstan, Laos, Latvia,
Lebanon, Libya, Liechtenstein, Lithuania, Luxembourg, Macedonia,
Malaysia, Malta, Mauritius, Mexico, Morocco, Netherlands, NZ,
Nicaragua, Nigeria, Norway, Pakistan, Panama, Paraguay, Peru, Poland,
Portugal, Qatar, Romania, Russia, Saudi Arabia, Senegal, Serbia,
Singapore, Slovakia, Slovenia, South Africa, Spain, Sri Lanka, Sudan,
Suriname, Swaziland, Sweden, Switzerland, Thailand, Togo, Turkey,
Uganda, Ukraine, UK, US, Uruguay, Venezuela, Zambia, Zimbabwe
Rio Group (RG): note - formerly known as Grupo de los Ocho,
established NA December 1986; composed of the Contadora Group and the
Lima Group
established - 1988
aim - to consult on regional Latin American issues
members - (20) Argentina, Bolivia, Brazil, CARICOM, Chile, Colombia,
Costa Rica, Dominican Republic, Ecuador, El Salvador, Guatemala,
Guyana, Honduras, Mexico, Nicaragua, Panama, Paraguay, Peru, Uruguay,
Venezuela
Second World: another term for the traditionally Marxist-Leninist
states of the USSR and Eastern Europe, with authoritarian governments
and command economies based on the Soviet model; the term is fading
from use; see centrally planned economies
Secretariat of the Pacific Communities (SPC): established - 6 February
1947
aim - to serve island development in 22 Pacific countries; to develop
technical assistance and professional, scientific, and research
support; to build planning and management capability
members - (26) America Samoa, Australia, Cook Islands, Fiji, France,
French Polynesia, Guam, Kiribati, Marshall Islands, Federated States of
Micronesia, Nauru, New Caledonia, Niue, Northern Mariana Islands, NZ,
Palau, Papua New Guinea, Pitcairn Islands, Samoa, Solomon Islands,
Tokelau, Tonga, Tuvalu, Vanuatu, US, Wallis and Futuna
Shanghai Cooperation Organization (SCO): established - 15 June 2001
aim - to combat terrorism, extremism, and separatism; to safeguard
regional security through mutual trust, disarmament, and cooperative
security; and to increase cooperation in political, trade, economic,
scientific and technological, cultural, and educational fields
members - (6) China, Kazakhstan, Kyrgyzstan, Russia, Tajikistan,','d0e114a542e1ce213a98c12d026949f39a2b5a7a91a6034907033d058ccce1db','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2e9759b3a1df680b4c8340d7678f27f47d3226ffd634683586dd1186283ff45',2007,'ZM','Zambia','environment',1130,'United Nations Industrial Development Organization (UNIDO):
established - 17 November 1966; effective - 1 January 1967
aim - UN specialized agency that promotes industrial development
especially among the members
members - (172) includes all UN member countries except Andorra,
Antigua and Barbuda, Australia, Brunei, Canada, Estonia, Iceland,
Kiribati, Latvia, Liechtenstein, Marshall Islands, Federated States of
Micronesia, Nauru, Palau, Samoa, San Marino, Singapore, Solomon
Islands, Tuvalu, US
United Nations Institute for Training and Research (UNITAR):
established - 11 December 1963 adoption of the resolution establishing
the Institute; effective - 24 March 1965
aim - to help the UN become more effective through training and
research
members (Board of Trustees) - (18) Belgium, Brazil, China, Czech
Republic, Egypt, France, Ghana, Japan, Kuwait, Mexico, Monaco, Morocco,
Nigeria, Pakistan, Russia, South Africa, Switzerland, US; note - the UN
Secretary General can appoint up to 30 members
United Nations Interim Administration Mission in Kosovo (UNMIK):
established - 10 June 1999
aim - to promote the establishment of substantial autonomy and self-
government in Kosovo; to perform basic civilian administrative
functions; to support the reconstruction of key infrastructure and
humanitarian and disaster relief
note - gives civilian support only; works closely with NATO Kosovo
Force (KFOR)
United Nations Interim Force in Lebanon (UNIFIL): established - 19
March 1978
aim - to confirm the withdrawal of Israeli forces, and assist in
reestablishing Lebanese authority in southern Lebanon; established by
the UN Security Council
members - (11) Belgium, China, Finland, France, Ghana, India, Ireland,
Italy, Norway, Poland, Spain
United Nations Military Observer Group in India and Pakistan (UNMOGIP):
established - 24 January 1949
aim - to observe the 1949 India-Pakistan cease-fire; established by the
UN Security Council
members - (8) Chile, Croatia, Denmark, Finland, Italy, South Korea,
Sweden, Uruguay
United Nations Mission for the Referendum in Western Sahara (MINURSO):
established - 29 April 1991
aim - to supervise the cease-fire and conduct a referendum in Western
Sahara; established by the UN Security Council
members - (25) Argentina, Austria, Bangladesh, China, Croatia, Denmark,
Egypt, El Slavador, France, Ghana, Greece, Guinea, Honduras, Hungary,
Ireland, Italy, Kenya, Malaysia, Mongolia, Nigeria, Pakistan, Poland,
Russia, Sri Lanka, Uruguay
United Nations Mission in Ethiopia and Eritrea (UNMEE): established -
31 July 2000
aim - to monitor the cessation of hostilities
members - (39) Algeria, Austria, Bangladesh, Bosnia and Herzegovina,
Bulgaria, China, Croatia, Czech Republic, Denmark, Finland, France,
Germany, Ghana, Greece, Guatemala, India, Iran, Jordan, Kenya,
Malaysia, Namibia, Nepal, Nigeria, Norway, Paraguay, Peru, Poland,
Romania, Russia, South Africa, Spain, Sweden, Switzerland, Tanzania,
Tunisia, Ukraine, US, Uruguay, Zambia
United Nations Mission in Liberia (UNMIL): established - 19 September
2003
aim - to support the cease-fire agreement and peace process, protect UN
facilities and people, support humanitarian activities, and assist in
national security reform
Bangladesh, Benin, Bolivia, Brazil, Bulgaria, China, Croatia, Czech
Republic, Denmark, Ecuador, Egypt, El Salvador, Ethiopia, Finland,
France, The Gambia, Germany, Ghana, Indonesia, Ireland, Jordan, Kenya,
South Korea, Kyrgyzstan, Malawi, Malaysia, Mali, Moldova, Mongolia,
Namibia, Nepal, Niger, Nigeria, Pakistan, Paraguay, Peru, Philippines,
Poland, Romania, Russia, Senegal, Serbia, Sweden, Togo, Ukraine, UK,
US, Zambia
United Nations Mission in Sierra Leone (UNAMSIL): established on 22
October 1999; aim was to to cooperate with the Government of Sierra
Leone and the other parties to the Peace Agreement in the
implementation of the agreement; to monitor the military and security
situation in Sierra Leone; to monitor the disarmament and
demobilization of combatants and members of the Civil Defense Forces
(CFD); to assist in monitoring respect for international humanitarian
law; mandate ended 31 December 2005; members were Bangladesh, Bolivia,
China, Croatia, Czech Republic, Egypt, The Gambia, Germany, Ghana,
Guinea, Indonesia, Jordan, Kenya, Kyrgyzstan, Malaysia, Nepal, Nigeria,
Pakistan, Russia, Slovakia, Sweden, Tanzania, Thailand, Ukraine, UK,
Uruguay, Zambia
United Nations Mission in the Sudan (UNMIS): established - March 2005
aim - to support implementation of the comprehensive Peace Agreement by
Monitoring and verifying the implementation of the Cease Fire
Agreement, by observing and monitoring movements of armed groups, and
by helping disarm, demobilizing and reintegrating armed bands
members - (59) Australia, Bangladesh, Benin, Bolivia, Botswana, Brazil,
Burkina Faso, Cambodia, Canada, China, Croatia, Denmark, Ecuador,
Egypt, El Salvador, Fiji, Finland, Gabon, Germany, Greece, Guatemala,
Guinea, India, Indonesia, Jordan, Kenya, South Korea, Kyrgyzstan,
Malawi, Malaysia, Mali, Moldova, Mongolia, Mozambique, Namibia, Nepal,
Netherland, NZ, Nigeria, Norway, Pakistan, Paraguay, Peru, Philippines,
Poland, Romania, Russia, Rwanda, Sri Lanka, Sweden, Tanzania, Thailand,
Turkey, Uganda, Ukraine, UK, Yemen, Zambia, Zimbabwe
United Nations Mission of Support in East Timor (UNMISET): established
on 17 May 2002 to provide assistance to structures critical to public
security and to assist in the development of law enforcement agencies;
to contribute to extenal security; members were Australia, Bangladesh,
Bolivia, Brazil, Denmark, Fiji, Jordan, Malaysia, Mozambique, Nepal,
NZ, Pakistan, Philippines, Portugal, Russia, Sweden; completed its
mandate 20 May 2005
United Nations Monitoring, Verification, and Inspection Commission
(UNMOVIC): note - formerly known as United Nations Special Commission
for the Elimination of Iraq''s Weapons of Mass Destruction (UNSCOM)
established - December 1999
aim - to identify, account for, and eliminate Iraq''s weapons of mass
destruction and the capacity to produce them
commissioners - (16) Argentina, Brazil, Canada, China, UN Department
for Disarmament Affairs, France, Germany, India, Japan, Mexico,
Nigeria, Russia, Senegal, Ukraine, UK, US
United Nations Operation in Burundi (ONUB): established - 21 May 2004
aim - to support and help implement the efforts undertaken by
Burundians to restore lasting peace and bring about national
reconciliation
members - (30) Algeria, Belgium, Benin, Burkina Faso, Chad, Egypt,
Ethiopia, The Gambia, Ghana, Guatemala, India, Jordan, Kenya, South
Korea, Malawi, Mali, Nambia, Nepal, Niger, Nigeria, Pakistan,
Philippines, Portugal, Russia, Senegal, South Africa, Thailand, Togo,
Tunisia, Yemen
United Nations Observer Mission in Georgia (UNOMIG): established - 24
August 1993
aim - to verify compliance with the cease-fire agreement, to monitor
weapons exclusion zone, and to supervise CIS peacekeeping force for
Abkhazia; established by the UN Security Council
members - (26) Albania, Austria, Bangladesh, Croatia, Czech Republic,
Denmark, Egypt, France, Germany, Greece, Hungary, India, Indonesia,
Jordan, South Korea, Pakistan, Poland, Romania, Russia, Sweden,
Switzerland, Turkey, Ukraine, UK, US, Uruguay
United Nations Organization Mission in the Democratic Republic of the
Congo (MONUC): established - 30 November 1999
aim - to establish contacts with the signatories to the cease-fire
agreement and to plan for the observation of the cease-fire and
disengagement of forces
members - (51) Algeria, Bangladesh, Belgium, Benin, Bolivia, Bosnia and
Herzegovina, Burkina Faso, Cameroon, Canada, China, Czech Republic,
Denmark, Egypt, France, Ghana, Guatemala, Guinea, India, Indonesia,
Ireland, Jordan, Kenya, Malawi, Malaysia, Mali, Mongolia, Morocco,
Mozambique, Nepal, Netherlands, Niger, Nigeria, Pakistan, Paraguay,
Peru, Poland, Romania, Russia, Senegal, Serbia, South Africa, Spain,
Sri Lanka, Sweden, Switzerland, Togo, Tunisia, Ukraine, UK, Uruguay,
United Nations Operation in Cote d''Ivoire (UNOCI): established - 27
February 2004
aim - to facilitate the implementation by the Ivorian parties of the
peace agreement signed by them in January 2003
members - (41) Bangladesh, Benin, Bolivia, Brazil, Chad, China,
Croatia, Dominican Republic, Ecuador, El Salvador, Ethiopia, France,
The Gambia, Ghana, Guatemala, Guinea, India, Ireland, Jordan, Kenya,
Moldova, Morocco, Namibia, Nepal, Niger, Nigeria, Pakistan, Paraguay,
Peru, Philippines, Poland, Romania, Russia, Senegal, Serbia, Tanzania,
Togo, Turkey, Uruguay, Vanuatu, Yemen
United Nations Peace-keeping Force in Cyprus (UNFICYP): established -
4 March 1964
aim - to serve as a peacekeeping force between Greek Cypriots and
Turkish Cypriots in Cyprus; established by the UN Security Council
members - (7) Argentina, Austria, Croatia, Hungary, Slovakia, UK,
countries that have signed, but not yet ratified - (17) Algeria,
Burkina Faso, Burundi, Cameroon, Chile, Ethiopia, Haiti, Libya,
Mali, Pakistan, Paraguay, Portugal, Somalia, Tanzania, Uruguay,
Vietnam, Yemen
Tropical Timber 83
see International Tropical Timber Agreement, 1983
Tropical Timber 94
see International Tropical Timber Agreement, 1994
United Nations Convention on the Law of the Sea (LOS) note -
abbreviated as Law of the Sea
opened for signature - 10 December 1982
entered into force - 16 November 1994
objective - to set up a comprehensive new legal regime for the sea
and oceans; to include rules concerning environmental standards as
well as enforcement provisions dealing with pollution of the marine
parties - (148) Albania, Algeria, Angola, Antigua and Barbuda,
Argentina, Armenia, Australia, Austria, The Bahamas, Bahrain,
Bangladesh, Barbados, Belgium, Belize, Benin, Bolivia, Bosnia and
Herzegovina, Botswana, Brazil, Brunei, Bulgaria, Burkina Faso,
Burma, Cameroon, Canada, Cape Verde, Chile, China, Comoros,
Democratic Republic of the Congo, Cook Islands, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Egypt, Equatorial Guinea, EU, Fiji, Finland, France,
Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary,
Iceland, India, Indonesia, Iraq, Ireland, Italy, Jamaica, Japan,
Jordan, Kenya, Kiribati, South Korea, Kuwait, Laos, Latvia, Lebanon,
Lithuania, Luxembourg, Macedonia, Madagascar, Malaysia, Maldives,
Mali, Malta, Marshall Islands, Mauritania, Mauritius, Mexico,
Federated States of Micronesia, Monaco, Mongolia, Mozambique,
Namibia, Nauru, Nepal, Netherlands, NZ, Nicaragua, Nigeria, Norway,
Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay,
Philippines, Poland, Portugal, Qatar, Romania, Russia, Saint Kitts
and Nevis, Saint Lucia, Saint Vincent and the Grenadines, Samoa, Sao
Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles, Sierra
Leone, Singapore, Slovakia, Slovenia, Solomon Islands, Somalia,
South Africa, Spain, Sri Lanka, Sudan, Suriname, Sweden, Tanzania,
Togo, Tonga, Trinidad and Tobago, Tunisia, Tuvalu, Uganda, Ukraine,
UK, Uruguay, Vanuatu, Vietnam, Yemen, Zambia, Zimbabwe
countries that have signed, but not yet ratified - (29) Afghanistan,
Bangladesh, Belarus, Bhutan, Burundi, Cambodia, Central African
Republic, Chad, Colombia, Republic of the Congo, Dominican Republic,
El Salvador, Ethiopia, Iran, North Korea, Lesotho, Liberia, Libya,
Liechtenstein, Madagascar, Malawi, Morocco, Niger, Niue, Rwanda,
Swaziland, Switzerland, Thailand, UAE
United Nations Convention to Combat Desertification in Those
Countries Experiencing Serious Drought and/or Desertification,
Particularly in Africa note - abbreviated as Desertification
opened for signature - 14 October 1994
entered into force - 26 December 1996
objective - to combat desertification and mitigate the effects of
drought through national action programs that incorporate long-term
strategies supported by international cooperation and partnership
arrangements
parties - (178) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bolivia, Botswana, Brazil, Bulgaria, Burkina Faso, Burma,
Burundi, Cambodia, Cameroon, Canada, Cape Verde, Central African
Republic, Chad, Chile, China, Colombia, Comoros, Democratic Republic
of the Congo, Republic of the Congo, Cook Islands, Costa Rica, Cote
d''Ivoire, Croatia, Cuba, Cyprus, Czech Republic, Denmark, Djibouti,
Dominica, Dominican Republic, Ecuador, Egypt, El Salvador,
Equatorial Guinea, Eritrea, Ethiopia, EU, Fiji, Finland, France,
Gabon, The Gambia, Georgia, Germany, Ghana, Greece, Grenada,
Guatemala, Guinea, Guinea-Bissau, Guyana, Haiti, Honduras, Hungary,
Iceland, India, Indonesia, Iran, Ireland, Israel, Italy, Jamaica,
Japan, Jordan, Kazakhstan, Kenya, Kiribati, South Korea, Kuwait,
Kyrgyzstan, Laos, Lebanon, Lesotho, Liberia, Libya, Liechtenstein,
Luxembourg, Madagascar, Malawi, Malaysia, Mali, Malta, Marshall
Islands, Mauritania, Mauritius, Mexico, Federated States of
Micronesia, Moldova, Monaco, Mongolia, Morocco, Mozambique, Namibia,
Nauru, Nepal, Netherlands, NZ, Nicaragua, Niger, Nigeria, Niue,
Norway, Oman, Pakistan, Palau, Panama, Papua New Guinea, Paraguay,
Peru, Philippines, Poland, Portugal, Qatar, Romania, Rwanda, Saint
Kitts and Nevis, Saint Lucia, Saint Vincent and the Grenadines,
Samoa, San Marino, Sao Tome and Principe, Saudi Arabia, Senegal,
Seychelles, Sierra Leone, Singapore, Slovakia, Slovenia, Solomon
Islands, South Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland,
Sweden, Switzerland, Syria, Thailand, Tajikistan, Tanzania, Togo,
Tonga, Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu,
Uganda, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela,
Vietnam, Yemen, Zambia, Zimbabwe
United Nations Framework Convention on Climate Change note -
abbreviated as Climate Change
opened for signature - 9 May 1992
entered into force - 21 March 1994
objective - to achieve stabilization of greenhouse gas
concentrations in the atmosphere at a low enough level to prevent
dangerous anthropogenic interference with the climate system
parties - (189) Afghanistan, Albania, Algeria, Angola, Antigua and
Barbuda, Argentina, Armenia, Australia, Austria, Azerbaijan, The
Bahamas, Bahrain, Bangladesh, Barbados, Belarus, Belgium, Belize,
Benin, Bhutan, Bolivia, Bosnia and Herzegovina, Botswana, Brazil,
Brunei, Bulgaria, Burkina Faso, Burma, Burundi, Cambodia, Cameroon,
Canada, Cape Verde, Central African Republic, Chad, Chile, China,
Colombia, Comoros, Democratic Republic of the Congo, Republic of the
Congo, Cook Islands, Costa Rica, Cote d''Ivoire, Croatia, Cuba,
Cyprus, Czech Republic, Denmark, Djibouti, Dominica, Dominican
Republic, Ecuador, Egypt, El Salvador, Equatorial Guinea, Eritrea,
Estonia, Ethiopia, EU, Fiji, Finland, France, Gabon, The Gambia,
Georgia, Germany, Ghana, Greece, Grenada, Guatemala, Guinea,
Guinea-Bissau, Guyana, Haiti, Honduras, Hungary, Iceland, India,
Indonesia, Iran, Ireland, Israel, Italy, Jamaica, Japan, Jordan,
Kazakhstan, Kenya, Kiribati, North Korea, South Korea, Kuwait,
Kyrgyzstan, Laos, Latvia, Lebanon, Lesotho, Liberia, Libya,
Liechtenstein, Lithuania, Luxembourg, Macedonia, Madagascar, Malawi,
Malaysia, Maldives, Mali, Malta, Marshall Islands, Mauritania,
Mauritius, Mexico, Federated States of Micronesia, Moldova, Monaco,
Mongolia, Morocco, Mozambique, Namibia, Nauru, Nepal, Netherlands,
NZ, Nicaragua, Niger, Nigeria, Niue, Norway, Oman, Pakistan, Palau,
Panama, Papua New Guinea, Paraguay, Peru, Philippines, Poland,
Portugal, Qatar, Romania, Russia, Rwanda, Saint Kitts and Nevis,
Saint Lucia, Saint Vincent and the Grenadines, Samoa, San Marino,
Sao Tome and Principe, Saudi Arabia, Senegal, Serbia, Seychelles,
Sierra Leone, Singapore, Slovakia, Slovenia, Solomon Islands, South
Africa, Spain, Sri Lanka, Sudan, Suriname, Swaziland, Sweden,
Switzerland, Syria, Tajikistan, Tanzania, Thailand, Togo, Tonga,
Trinidad and Tobago, Tunisia, Turkey, Turkmenistan, Tuvalu, Uganda,
Ukraine, UAE, UK, US, Uruguay, Uzbekistan, Vanuatu, Venezuela,
Vietnam, Yemen, Zambia, Zimbabwe
Wetlands
see Convention on Wetlands of International Importance Especially As
Waterfowl Habitat (Ramsar)
Whaling
see International Convention for the Regulation of Whaling
This page was last updated on 8 February, 2007
=====================================================================
Appendix D - Cross-Reference list of Country Data Codes
FIPS 10: Countries, Dependencies, Areas of Special Sovereignty, and
Their Principal Administrative Divisions (FIPS 10) is maintained by the
Office of Targeting and Transnational Issues, National Geospatial-
Intelligence Agency, and published by the National Institute of
Standards and Technology (Department of Commerce). FIPS 10 codes are
intended for general use throughout the US Government, especially in
activities associated with the mission of the Department of State and
national defense programs.
ISO 3166: Codes for the Representation of Names of Countries (ISO 3166)
is prepared by the International Organization for Standardization. ISO
3166 includes two- and three-character alphabetic codes and three-digit
numeric codes that may be needed for activities involving exchange of
data with international organizations that have adopted that standard.
Except for the numeric codes, ISO 3166 codes have been adopted in the
US as FIPS 104-1: American National Standard Codes for the
Representation of Names of Countries, Dependencies, and Areas of
Special Sovereignty for Information Interchange.
Internet: The Internet country code is the two-letter digraph
maintained by the International Organization for Standardization (ISO)
in the ISO 3166 Alpha-2 list and used by the Internet Assigned Numbers
Authority (IANA) to establish country-coded top-level domains (ccTLDs).
Entity FIPS 10 | ISO 3166 | Internet Comment
Afghanistan AF AF AFG 004 .af
Albania AL AL ALB 008 .al
Algeria AG DZ DZA 012 .dz
American Samoa AQ AS ASM 016 .as
Andorra AN AD AND 020 .ad
Angola AO AO AGO 024 .ao
Anguilla AV AI AIA 660 .ai
Antarctica AY AQ ATA 010 .aq
ISO defines as the territory south of 60 degrees south latitude
Antigua and
Barbuda AC AG ATG 028 .ag
Argentina AR AR ARG 032 .ar
Armenia AM AM ARM 051 .am
Aruba AA AW ABW 533 .aw
Ashmore and
Cartier Islands AT - - -
ISO includes with Australia
Australia AS AU AUS 036 .au
ISO includes Ashmore and Cartier Islands, Coral Sea Islands
Austria AU AT AUT 040 .at
Azerbaijan AJ AZ AZE 031 .az
Bahamas, The BF BS BHS 044 .bs
Bahrain BA BH BHR 048 .bh
Baker Island FQ - - -
ISO includes with the US Minor Outlying Islands
Bangladesh BG BD BGD 050 .bd
Barbados BB BB BRB 052 .bb
Bassas da
India BS - - - -
administered as part of French Southern and Antarctic Lands;
no ISO codes assigned
Belarus BO BY BLR 112 .by
Belgium BE BE BEL 056 .be
Belize BH BZ BLZ 084 .bz
Benin BN BJ BEN 204 .bj
Bermuda BD BM BMU 060 .bm
Bhutan BT BT BTN 064 .bt
Bolivia BL BO BOL 068 .bo
Bosnia and
Herzegovina BK BA BIH 070 .ba
Botswana BC BW BWA 072 .bw
Bouvet Island BV BV BVT 074 .bv
Brazil BR BR BRA 076 .br
British Indian
Ocean Territory IO IO IOT 086 .io
British
Virgin Islands VI VG VGB 092 .vg
Brunei BX BN BRN 096 .bn
Bulgaria BU BG BGR 100 .bg
Burkina Faso UV BF BFA 854 .bf
Burma BM MM MMR 104 .mm
ISO uses the name Myanmar
Burundi BY BI BDI 108 .bi
Cambodia CB KH KHM 116 .kh
Cameroon CM CM CMR 120 .cm
Canada CA CA CAN 124 .ca
Cape Verde CV CV CPV 132 .cv
Cayman Islands CJ KY CYM 136 .ky
Central African
Republic CT CF CAF 140 .cf
Chad CD TD TCD 148 .td
Chile CI CL CHL 152 .cl
China CH CN CHN 156 .cn
see also Taiwan
Christmas Island KT CX CXR 162 .cx
Clipperton Island IP - - -
ISO includes with French Polynesia
Cocos (Keeling)
Islands CK CC CCK 166 .cc
Colombia CO CO COL 170 .co
Comoros CN KM COM 174 .km
Congo, Democratic
Republic of the CG CD COD 180 .cd
formerly Zaire
Congo,
Republic of the CF CG COG 178 .cg
Cook Islands CW CK COK 184 .ck
Coral Sea Islands CR - - -
ISO includes with Australia
Costa Rica CS CR CRI 188 .cr
Cote d''Ivoire IV CI CIV 384 .ci
Croatia HR HR HRV 191 .hr
Cuba CU CU CUB 192 .cu
Cyprus CY CY CYP 196 .cy
Czech Republic EZ CZ CZE 203 .cz
Denmark DA DK DNK 208 .dk
Djibouti DJ DJ DJI 262 .dj
Dominica DO DM DMA 212 .dm
Dominican Republic DR DO DOM 214 .do
East Timor TT TL TLS 626 .tl
Ecuador EC EC ECU 218 .ec
Egypt EG EG EGY 818 .eg
El Salvador ES SV SLV 222 .sv
Equatorial Guinea EK GQ GNQ 226 .gq
Eritrea ER ER ERI 232 .er
Estonia EN EE EST 233 .ee
Ethiopia ET ET ETH 231 .et
Europa Island EU - - - -
administered as part of French Southern and Antarctic Lands;
no ISO codes assigned
Falkland Islands
(Islas Malvinas) FK FK FLK 238 .fk
Faroe Islands FO FO FRO 234 .fo
Fiji FJ FJ FJI 242 .fj
Finland FI FI FIN 246 .fi
France FR FR FRA 250 .fr
France,
Metropolitan - FX FXX 249 .fx
ISO limits to the European part of France, excluding French
Guiana, French Polynesia, French Southern and Antarctic Lands,
Guadeloupe, Martinique, Mayotte, New Caledonia, Reunion, Saint
Pierre and Miquelon, Wallis and Futuna
French Guiana FG GF GUF 254 .gf
French Polynesia FP PF PYF 258 .pf
ISO includes Clipperton Island
French
Southern and
Antarctic Lands FS TF ATF 260 .tf
FIPS 10-4 does not include the French-claimed portion of Antarctica
(Terre Adelie)
Gabon GB GA GAB 266 .ga
Gambia, The GA GM GMB 270 .gm
Gaza Strip GZ PS PSE 275 .ps
ISO identifies as Occupied Palestinian Territory
Georgia GG GE GEO 268 .ge
Germany GM DE DEU 276 .de
Ghana GH GH GHA 288 .gh
Gibraltar GI GI GIB 292 .gi
Glorioso Islands GO - - - -
administered as part of French Southern and Antarctic Lands;
no ISO codes assigned
Greece GR GR GRC 300 .gr
Greenland GL GL GRL 304 .gl
Grenada GJ GD GRD 308 .gd
Guadeloupe GP GP GLP 312 .gp
Guam GQ GU GUM 316 .gu
Guatemala GT GT GTM 320 .gt
Guernsey GK GG GGY 831 .gg
Guinea GV GN GIN 324 .gn
Guinea-Bissau PU GW GNB 624 .gw
Guyana GY GY GUY 328 .gy
Haiti HA HT HTI 332 .ht
Heard Island and
McDonald Islands HM HM HMD 334 .hm
Holy See
(Vatican City) VT VA VAT 336 .va
Honduras HO HN HND 340 .hn
Hong Kong HK HK HKG 344 .hk
Howland Island HQ - - - ISO
includes with the US Minor Outlying Islands
Hungary HU HU HUN 348 .hu
Iceland IC IS ISL 352 .is
India IN IN IND 356 .in
Indonesia ID ID IDN 360 .id
Iran IR IR IRN 364 .ir
Iraq IZ IQ IRQ 368 .iq
Ireland EI IE IRL 372 .ie
Isle of Man IM IM IMN 833 .im
Israel IS IL ISR 376 .il
Italy IT IT ITA 380 .it
Jamaica JM JM JAM 388 .jm
Jan Mayen JN - - - ISO
includes with Svalbard
Japan JA JP JPN 392 .jp
Jarvis Island DQ - - - ISO
includes with the US Minor Outlying Islands
Jersey JE JE JEY 832 .je
Johnston Atoll JQ - - - ISO
includes with the US Minor Outlying Islands
Jordan JO JO JOR 400 .jo
Juan de
Nova Island JU - - - -
administered as part of French Southern and Antarctic Lands;
no ISO codes assigned
Kazakhstan KZ KZ KAZ 398 .kz
Kenya KE KE KEN 404 .ke
Kingman Reef KQ - - - ISO
includes with the US Minor Outlying Islands
Kiribati KR KI KIR 296 .ki
Korea, North KN KP PRK 408 .kp
Korea, South KS KR KOR 410 .kr
Kuwait KU KW KWT 414 .kw
Kyrgyzstan KG KG KGZ 417 .kg
Laos LA LA LAO 418 .la
Latvia LG LV LVA 428 .lv
Lebanon LE LB LBN 422 .lb
Lesotho LT LS LSO 426 .ls
Liberia LI LR LBR 430 .lr
Libya LY LY LBY 434 .ly
Liechtenstein LS LI LIE 438 .li
Lithuania LH LT LTU 440 .lt
Luxembourg LU LU LUX 442 .lu
Macau MC MO MAC 446 .mo
Macedonia MK MK MKD 807 .mk
Madagascar MA MG MDG 450 .mg
Malawi MI MW MWI 454 .mw
Malaysia MY MY MYS 458 .my
Maldives MV MV MDV 462 .mv
Mali ML ML MLI 466 .ml
Malta MT MT MLT 470 .mt
Marshall Islands RM MH MHL 584 .mh
Martinique MB MQ MTQ 474 .mq
Mauritania MR MR MRT 478 .mr
Mauritius MP MU MUS 480 .mu
Mayotte MF YT MYT 175 .yt
Mexico MX MX MEX 484 .mx
Micronesia,
Federated
States of FM FM FSM 583 .fm
Midway Islands MQ - - - ISO
includes with the US Minor Outlying Islands
Moldova MD MD MDA 498 .md
Monaco MN MC MCO 492 .mc
Mongolia MG MN MNG 496 .mn
Montenegro MJ ME MNE 499 .me
Montserrat MH MS MSR 500 .ms
Morocco MO M','2ddbe9a09dc1ff2ed92d3a85ae10f2bd5e874f817f14d605ae7dda47a2107911','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('231aa07909d0dfd77fc9d011f2993bf19b86bcabd3354fa32e40565379ee1b3e',2007,'ZM','Zambia','environment',1131,'A MAR 504 .ma
Mozambique MZ MZ MOZ 508 .mz
Myanmar - - - -
see Burma
Namibia WA NA NAM 516 .na
Nauru NR NR NRU 520 .nr
Navassa Island BQ - - - -
ISO includes with the US Minor Outlying Islands
Nepal NP NP NPL 524 .np
Netherlands NL NL NLD 528 .nl','1ff31113d21e5d671f7bef55e59a5f5b178166fafa8706e08dd7926945a78241','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f53ab6cfe7030a4e0c4e79521963005801ffbf65088bb26f980076d4998aeef3',2007,'UY','Uruguay','environment',1132,'United Nations Population Fund (UNFPA): note - acronym retained from
predecessor organization UN Fund for Population Activities
established - July 1967
aim - to assist both developed and developing countries to deal with
their population problems
members (executive board ) - (36) selected on a rotating basis from all
regions
United Nations Relief and Works Agency for Palestine Refugees in the
Near East (UNRWA): established - 8 December 1949
aim - to provide assistance to Palestinian refugees
members (advisory commission) - (22) Australia, Belgium, Canada,
Denmark, EC, Egypt, France, Germany, Italy, Japan, Jordan, Lebanon,
Netherlands, Norway, Saudi Arabia, Spain, Sweden, Switzerland, Syria,
Turkey, UK, US
United Nations Research Institute for Social Development (UNRISD):
established - 1963
aim - to conduct research into the problems of economic development
during different phases of economic growth
members - no country members, but a Board of Directors consisting of a
chairman appointed by the UN secretary general and 10 individual
members
United Nations Secretariat: established - 26 June 1945; effective - 24
October 1945
aim - to serve as the primary administrative organ of the UN; a
Secretary General is appointed for a five-year term by the General
Assembly on the recommendation of the Security Council
members - the UN Secretary General and staff
United Nations Security Council (UNSC): established - 26 June 1945;
effective - 24 October 1945
aim - to maintain international peace and security
permanent members - (5) China, France, Russia, UK, US
nonpermanent members - (10) elected for two-year terms by the UN
General Assembly; Belgium (2007-08), Republic of the Congo (2006-07),
Ghana (2006-07), Indonesia (2007-08), Italy (2007-08), Panama (2007-
08), Peru (2006-07), Qatar (2006-07), Slovakia (2006-07), South Africa
(2007-08)
United Nations Stabilization Mission in Haiti (MINUSTAH): established
- 30 April 2004
aim - to stabilize Haiti in many areas for at least six months
members - (19) Argentina, Bolivia, Brazil, Canada, Chile, Croatia,
Ecuador, France, Guatemala, Jordan, Morocco, Nepal, Pakistan, Paraguay,
Peru, Philippines, Sri Lanka, US, Uruguay
United Nations Truce Supervision Organization (UNTSO): established -
June 1948
aim - to supervise the 1948 Arab-Israeli cease-fire; currently supports
timely deployment of reinforcements to other peacekeeping operations in
the region as needed; initially established by the UN Security Council
members - (23) Argentina, Australia, Austria, Belgium, Canada, Chile,
China, Denmark, Estonia, Finland, France, Ireland, Italy, Nepal,
Netherlands, NZ, Norway, Russia, Slovakia, Slovenia, Sweden,
Switzerland, US
United Nations Trusteeship Council: established on 26 June 1945,
effective on 24 October 1945, to supervise the administration of the 11
UN trust territories; members were China, France, Russia, UK, US; it
formally suspended operations 1 November 1995 after the Trust Territory
of the Pacific Islands (Palau) became the Republic of Palau, a
constitutional government in free association with the US; the
Trusteeship Council was not dissolved
United Nations University (UNU): established - 3 December 1973
aim - to conduct research in development, welfare, and human survival
and to train scholars
members - (24 members of UNU Council and the Rector are appointed by
the Secretary General of the United Nations and the Director General of
UNESCO)
Universal Postal Union (UPU): established - 9 October 1874, affiliated
with the UN 15 November 1947; effective - 1 July 1948
aim - to promote international postal cooperation; a UN specialized
agency
members - (189) includes all UN member countries except Andorra,
Marshall Islands, Federated States of Micronesia, and Palau (188
total); plus Holy See; note - includes the following dependencies or
areas of special interest: Australia (Norfolk Island), China (Hong
Kong, Macau), Denmark (Faroe Islands, Greenland), France (French
Guiana, French Polynesia, French Southern and Antarctic Lands,
Guadeloupe, Iles Eparses, Martinique, Mayotte, New Caledonia, Reunion,
Saint Pierre and Miquelon, Wallis and Futuna), Netherlands (Aruba,
Netherlands Antilles), NZ (Cook Island, Niue, Tokelau), UK (Guernsey,
Isle of Man, Jersey; Anguilla, Bermuda, British Indian Ocean Territory,
British Virgin Islands, Cayman Islands, Falkland Islands, Gibraltar,
Montserrat, Pitcairn, Saint Helena, Turks and Caicos), US (American
Samoa, Guam, Northern Mariana Islands, Puerto Rico, South Georgia and
South Sandwich Islands, Virgin Islands)
Warsaw Pact (WP): established 14 May 1955 to promote mutual defense;
members met 1 July 1991 to dissolve the alliance; member states at the
time of dissolution were: Bulgaria, Czechoslovakia, Hungary, Poland,
Romania, and the USSR; earlier members included German Democratic
Republic (GDR) and Albania
West African Development Bank (WADB): note - also known as Banque
Ouest-Africaine de Developpement (BOAD); is a financial institution of
WAEMU
established - 14 November 1973
aim - to promote regional economic development and integration
regional members - (9) Central Bank of West African States, Benin,
Burkina Faso, Cote d''Ivoire, Guinea-Bissau, Mali, Niger, Senegal, Togo
international/nonregional members - (6) African Development Bank,
Belgium, European Investment Bank, France, Germany, People''s Bank of','7f42b7c12042495651f1a681ab7aa90663df4bacfbf212a8db1672f4234607a1','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('130cc5534856c9c6e67fbfac3fd99cf11d896f7f8cbccb68399fd96e134cecfa',2007,'US','United States','environment',1133,'Minor Outlying
Islands - UM UMI 581 .um
ISO includes Baker Island, Howland Island, Jarvis Island,
Johnston Atoll, Kingman Reef, Midway Islands, Navassa Island,
Palmyra Atoll, Wake Island
Uruguay UY UY URY 858 .uy
Uzbekistan UZ UZ UZB 860 .uz
Vanuatu NH VU VUT 548 .vu
Venezuela VE VE VEN 862 .ve
Vietnam VM VN VNM 704 .vn
Virgin Islands VQ VI VIR 850 .vi
Virgin Islands (UK) - - - .vg
see British Virgin Islands
Virgin Islands (US) - - - .vi
see Virgin Islands
Wake Island WQ - - - -
ISO includes with the US Minor Outlying Islands
Wallis
and Futuna WF WF WLF 876 .wf
West Bank WE PS PSE 275 .ps
ISO identifies as Occupied Palestinian Territory
Western Sahara WI EH ESH 732 .eh
Western Samoa - - - .ws see','77a029bb06c8a3f89742da39c4b201abe461f0b16434aa39e2a39cfb7d2f7ce2','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6313a4309d87618ed2f984e11275e4980999b7ebd1260560f74849047bb19832',2007,'RS','Serbia','environment',1134,'Banda Sea Pacific Ocean 5 00 S 128 00 E
Bandar Seri Begawan Brunei 4 52 S 114 55 E
(capital)
Bangka (island) Indonesia 2 30 S 106 00 E
Bangkok (capital) Thailand 13 45 N 100 31 E
Bangui (capital) Central African 4 22 N 18 35 E
Republic
Banjul (capital) The Gambia 13 28 N 16 39 W
Banks Island Australia 10 12 S 142 16 E
Banks Island Canada 75 15 N 121 30 W
Banks Islands (Iles Vanuatu 14 00 S 167 30 E
Banks)
Barbuda (island) Antigua and Barbuda 17 38 N 61 48 W
Barcelona (city) Spain 41 25 N 2 13 E
Barents Sea Arctic Ocean 74 00 N 36 00 E
Barranquilla (city) Colombia 10 59 N 74 48 W
Bashi Channel Pacific Ocean 22 00 N 121 00 E
Basilan Strait Pacific Ocean 6 49 N 122 05 E
Basque Provinces Spain 43 00 N 2 30 W
Bass Strait Pacific Ocean 39 20 S 145 30 E
Basse-Terre (capital) Guadeloupe 16 00 N 61 44 W
Basseterre (capital) Saint Kitts and 17 18 N 62 43 W
Nevis
Bastia (city) France (Corsica) 42 42 N 9 27 E
Basutoland (former name Lesotho 29 30 S 28 30 E
for Lesotho)
Batan Islands Philippines 20 30 N 121 50 E
Bavaria (region; also Germany 48 30 N 11 30 E
Bayern)
Beagle Channel Atlantic Ocean 54 53 S 68 10 W
Bear Island (see Svalbard 74 26 N 19 05 E
Bjornoya)
Beaufort Sea Arctic Ocean 73 00 N 140 00 W
Bechuanaland (former name Botswana 22 00 S 24 00 E
for Botswana)
Beijing (capital) China 39 56 N 116 24 E
Beirut (capital) Lebanon 33 53 N 35 30 E
Bekaa Valley Lebanon 34 00 N 36 05 E
Belau (Palau Islands) Palau 7 30 N 134 30 E
Belep Islands (Iles New Caledonia 19 45 S 163 40 E
Belep)
Belfast (city) United Kingdom 54 36 N 5 55 W
Belgian Congo (former Democratic Republic 0 00 N 25 00 E
name for Democratic of the Congo
Republic of the Congo)
Belgie, Belgique (local Belgium 50 50 N 4 00 E
name for Belgium)
Belgrade (capital) Serbia 44 50 N 20 30 E
Belize City Belize 17 30 N 88 12 W
Belle Isle, Strait of Atlantic Ocean 51 35 N 56 30 W
Bellingshausen Sea Southern Ocean 71 00 S 85 00 W
Belmopan (capital) Belize 17 15 N 88 46 W
Belorussia (former name Belarus 53 00 N 28 00 E
for Belarus)
Benadir (region; former Somalia 4 00 N 46 00 E
name of Italian
Somaliland)
Bengal, Bay of Indian Ocean 15 00 N 90 00 E
Berau, Gulf of Pacific Ocean 2 30 S 132 30 E
Bering Island Russia 55 00 N 166 30 E
Bering Sea Pacific Ocean 60 00 N 175 00 W
Bering Strait Pacific Ocean 65 30 N 169 00 W
Berkner Island Antarctica 79 30 S 49 30 W
Berlin (capital) Germany 52 31 N 13 24 E
Berlin, East (former name Germany 52 30 N 13 33 E
for eastern sector of
Berlin)
Berlin, West (former name Germany 52 30 N 13 20 E
for western sector of
Berlin)
Bern (capital) Switzerland 46 57 N 7 26 E
Bessarabia (region) Moldova, Romania, 47 00 N 28 30 E','8160bb48be8d6d9b5aa385dc993a3505a6ac0238bb19d9138175efaef0f33c4c','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4aaa4de012df3dcc1a9e2706bc5cf2b7c97bcb6b2093ea57269406128ec598f',2007,'CG','Congo','environment',1135,'Bridgetown (capital) Barbados 13 06 N 59 37 W
Brisbane (city) Australia 27 28 S 153 02 E
Bristol Bay Pacific Ocean 57 00 N 160 00 W
Bristol Channel Atlantic Ocean 51 18 N 3 30 W
Britain (see Great United Kingdom 54 00 N 2 00 W
Britain)
British Bechuanaland South Africa 27 30 S 23 30 E
(region; former name for
northwest South Africa)
British Central African Malawi 13 30 S 34 00 E
Protectorate (former name
of Nyasaland)
British East Africa Kenya, Tanzania, 1 00 N 38 00 E
(former name for British Uganda
possessions in eastern
Africa)
British Guiana (former Guyana 5 00 N 59 00 W
name for Guyana)
British Honduras (former Belize 17 15 N 88 45 W
name for Belize)
British Solomon Islands Solomon Islands 8 00 S 159 00 E
(former name for Solomon
Islands)
British Somaliland Somalia 10 00 N 49 00 E
(former name for northern
Somalia)
Brussels (capital) Belgium 50 50 N 4 20 E
Bubiyan (island) Kuwait 29 47 N 48 10 E
Bucharest (capital) Romania 44 26 N 26 06 E
Budapest (capital) Hungary 47 30 N 19 05 E
Buenos Aires (capital) Argentina 34 36 S 58 27 W
Bujumbura (capital) Burundi 3 23 S 29 22 E
Bukovina (region) Romania, Ukraine 48 00 N 26 00 E
Byelarus (local name for Belarus 53 00 N 28 00 E
Belarus)
Byelorussia (former name Belarus 53 00 N 28 00 E
for Belarus)
Cabinda (province) Angola 5 33 S 12 12 E
Cabo Verde (local name Cape Verde 16 00 N 24 00 W
for Cape Verde)
Cabot Strait Atlantic Ocean 47 20 N 59 30 W
Caicos Islands Turks and Caicos 21 56 N 71 58 W
Islands
Cairo (capital) Egypt 30 03 N 31 15 E
Calcutta (city) India 22 32 N 88 21 E
Calgary (city) Canada 51 02 N 114 04 W
California, Gulf of Pacific Ocean 28 00 N 112 00 W
Cameroun (local name for Cameroon 6 00 N 12 00 E
Cameroon)
Campbell Island New Zealand 52 33 S 169 09 E
Campeche, Bay of Atlantic Ocean 20 00 N 94 00 W
Canal Zone (former name Panama 9 00 N 79 45 W
for US possessions in
Panama)
Canarias Sea Atlantic Ocean 28 00 N 16 00 W
Canary Islands Spain 28 00 N 15 30 W
Canberra (capital) Australia 35 17 S 149 08 E
Cancun (city) Mexico 21 10 N 86 50 W
Canton (city; now China 23 06 N 113 16 E
Guangzhou)
Canton Island (Kanton Kiribati 2 49 S 171 40 W
Island)
Cape Juby (region; former Morocco 27 53 N 12 58 W
name for Southern
Morocco)
Cape Province (region; South Africa 31 30 S 22 30 E
former name for Northern,
Western, and Eastern Cape
Provinces of South
Africa)
Cape Town (legislative South Africa 33 57 S 18 25 E
capital)
Cape of Good Hope (cape; South Africa 34 15 S 18 20 E
also alternate name for
Cape Province of South
Africa)
Caracas (capital) Venezuela 10 30 N 66 56 W
Cargados Carajos Shoals Mauritius 16 25 S 59 38 E
Caribbean Sea Atlantic Ocean 15 00 N 73 00 W
Caroline Islands Federated States of 7 30 N 148 00 E
Micronesia, Palau
Carpatho-Ukraine (region; Ukraine 48 22 N 23 32 E
former name for
Zakarpats''ka oblast'')
Carpentaria, Gulf of Pacific Ocean 14 00 S 139 00 E
Casablanca (city) Morocco 33 35 N 7 34 W
Castries (capital) Saint Lucia 14 01 N 61 00 W
Catalonia (region) Spain 42 00 N 2 00 E
Cato Island Australia 23 15 S 155 32 E
Caucasus (region) Russia 42 00 N 45 00 E
Cayenne (capital) French Guiana 4 56 N 52 20 W
Celebes (island) Indonesia 2 00 S 121 00 E
Celebes Sea Pacific Ocean 3 00 N 122 00 E
Celtic Sea Atlantic Ocean 51 00 N 6 30 W
Central African Empire Central African 7 00 N 21 00 E
(former name for Central Republic
African Republic)
Ceram (Seram) Sea Pacific Ocean 2 30 S 129 30 E
Ceska Republika (local Czech Republic 49 45 N 15 30 E
name for Czech Republic)
Ceskoslovensko (former Czech Republic, 49 00 N 17 30 E
local name for Slovakia
Czechoslovakia)
Cetinje (capital city) Montenegro 42 24 N 18 55 E
Ceuta (city) Spain 35 53 N 5 19 W
Ceylon (former name for Sri Lanka 7 00 N 81 00 E
Sri Lanka)
Chafarinas, Islas Spain 35 12 N 2 26 W
(island)
Chagos Archipelago (Oil British Indian 6 00 S 71 30 E
Islands) Ocean Territory
Challenger Deep (Mariana Pacific Ocean 11 22 N 142 36 E
Trench)
Channel Islands Guernsey, Jersey 49 20 N 2 20 W
Charlotte Amalie Virgin Islands 18 21 N 64 56 W
(capital)
Chatham Islands New Zealand 44 00 S 176 30 W
Chechnya (region; also Russia 43 15 N 45 40 E
Chechnia)
Cheju Strait Pacific Ocean 34 00 N 126 30 E
Cheju-do (island) Korea, South 33 20 N 126 30 E
Chengdu (city) China 30 43 N 104 04 E
Chennai (city; also India 13 04 N 80 16 E
Madras)
Chesterfield Islands New Caledonia 19 52 S 158 15 E
(Iles Chesterfield)
Chihli, Gulf of (see Bo Pacific Ocean 38 30 N 120 00 E
Hai)
Chiloe (island) Chile 42 50 S 74 00 W
China, People''s Republic China 35 00 N 105 00 E
of
China, Republic of Taiwan 23 30 N 121 00 E
Chisinau (capital; also Moldova 47 00 N 28 50 E
Kishinev)
Choiseul (island) Solomon Islands 7 05 S 121 00 E
Choson (local name for North Korea 40 00 N 127 00 E
North Korea)
Christmas Island (Indian Australia 10 25 S 105 39 E
Ocean)
Christmas Island (Pacific Kiribati 1 52 N 157 20 W
Ocean; also Kiritimati)
Chukchi Sea Arctic Ocean 69 00 N 171 00 W
Chuuk Islands (Truk Federated States of 7 25 N 151 47 W
Islands) Micronesia
Cilicia (region) Turkey 36 50 N 34 30 E
Ciskei (enclave) South Africa 33 00 S 27 00 E
Citta del Vaticano (local Holy See 41 54 N 12 27 E
name for Vatican City)
Cochin China (region) Vietnam 11 00 N 107 00 E
Coco, Isla del (island) Costa Rica 5 32 N 87 04 W
Cocos Islands Cocos (Keeling) 12 30 S 96 50 E
Islands
Colombo (capital) Sri Lanka 6 56 N 79 51 E
Colon, Archipielago de Ecuador 0 00 N 90 30 W
(Galapagos Islands)
Commander Islands Russia 55 00 N 167 00 E
(Komandorskiye Ostrova)
Comores (local name for Comoros 12 10 S 44 15 E
Comoros)
Con Son (islands) Vietnam 8 43 N 106 36 E
Conakry (capital) Guinea 9 31 N 13 43 W
Confederatio Helvetica Switzerland 47 00 N 8 00 E
(local name for
Switzerland)
Congo (Brazzaville) Republic of the 1 00 S 15 00 E
(former name for Republic Congo
of the Congo)
Congo (Leopoldville) Democratic Republic 0 00 N 25 00 E
(former name for the of the Congo
Democratic Republic of
the Congo)
Constantinople (city; Turkey 41 01 N 28 58 E
former name for Istanbul)
Cook Strait Pacific Ocean 41 15 S 174 30 E
Copenhagen (capital) Denmark 55 40 N 12 35 E
Coral Sea Pacific Ocean 15 00 S 150 00 E
Corfu (island) Greece 39 40 N 19 45 E
Corinth (region) Greece 37 56 N 22 56 E
Corisco (island) Equatorial Guinea 0 55 N 9 19 E
Corn Islands (Islas del Nicaragua 12 15 N 83 00 W
Maiz)
Corocoro Island Guyana, Venezuela 3 38 N 66 50 W
Corsica (island; also France 42 00 N 9 00 E
Corse)
Cosmoledo Group (island Seychelles 9 43 S 47 35 E
group; also Atoll de
Cosmoledo)
Cotonou (former capital) Benin 6 21 N 2 26 E
Cotopaxi (volcano) Ecuador 0 39 S 78 26 W
Courantyne River Guyana, Suriname 5 57 N 57 06 W
Cozumel (island) Mexico 20 30 N 86 55 W
Crete (island) Greece 35 15 N 24 45 E
Crimea (region) Ukraine 45 00 N 34 00 E
Crimean Peninsula Ukraine 45 00 N 34 00 E
Crooked Island Passage Atlantic Ocean 22 55 N 74 35 W
Crozet Islands (Iles French Southern and 46 30 S 51 00 E
Crozet) Antarctic Lands
Cyclades (island group) Greece 37 00 N 25 10 E
Cyrenaica (region) Libya 31 00 N 22 00 E
Czechoslovakia (former Czech Republic, 49 00 N 18 00 E
name for the entity that Slovakia
subsequently split into
the Czech Republic and
Slovakia)
D''Entrecasteaux Islands Papua New Guinea 9 30 S 150 40 E
Dagestan (region) Russia 43 00 N 47 00 E
Dahomey (former name for Benin 9 30 N 2 15 E
Benin)
Daito Islands Japan 43 00 N 17 00 E
Dakar (capital) Senegal 14 40 N 17 26 W
Dalmatia (region) Croatia 43 00 N 17 00 E
Daman (city; also Damao) India 20 10 N 73 00 E
Damascus (capital) Syria 33 30 N 36 18 E
Danger Islands (see Cook Islands 10 53 S 165 49 W
Pukapuka Atoll)
Danish Straits Atlantic Ocean 58 00 N 11 00 E
Danish West Indies Virgin Islands 18 20 N 64 50 W
(former name for the
Virgin Islands)
Danmark (local name) Denmark 56 00 N 10 00 E
Danzig (city; former name Poland 54 23 N 18 40 E
for Gdansk)
Dao Bach Long Vi (island) Vietnam 20 08 N 107 44 E
Dar es Salaam (capital) Tanzania 6 48 S 39 17 E
Dardanelles (strait) Atlantic Ocean 40 15 N 26 25 E
Davis Strait Atlantic Ocean 67 00 N 57 00 W
Dead Sea Israel, Jordan, 32 30 N 35 30 E
West Bank
Deception Island Antarctica 62 56 S 60 34 W
Denmark Strait Atlantic Ocean 67 00 N 24 00 W
Desolation Islands (Isles French Southern and 49 30 S 69 30 E
Kerguelen) Antarctic Lands
Deutschland (local name Germany 51 00 N 9 00 E
for Germany)
Devils Island (Ile du French Guiana 5 17 N 52 35 W
Diable)
Devon Island Canada 76 00 N 87 00 W
Dhaka (capital) Bangladesh 23 43 N 90 25 E
Dhivehi Raajje (local Maldives 3 15 N 73 00 E
name for Maldives)
Dhofar (region) Oman 17 00 N 54 10 E
Diego Garcia (island) British Indian 7 20 S 72 25 E
Ocean Territory
Diego Ramirez (islands) Chile 56 30 S 68 43 W
Dili (capital) East Timor 8 35 S 125 36 E
Dilmun (former name for Bahrain 7 00 N 81 00 E
Bahrain)
Diomede Islands Russia (Big 65 47 N 169 00 W
Diomede), United
States (Little
Diomede)
Diu (region) India 20 42 N 70 59 E
Djibouti (capital) Djibouti 11 30 N 43 15 E
Dnieper (river) Belarus, Russia, 46 30 N 32 18 E
Ukraine (Dnyapro,
Dnepr, Dnipro)
Dniester (river) Moldova, Ukraine 46 18 N 30 17 E
(Nistru, Dnister)
Dobruja (region) Bulgaria, Romania 43 30 N 28 00 E
Dodecanese (island group) Greece 36 00 N 27 05 E
Dodoma (city) Tanzania 6 11 S 35 45 E
Doha (capital) Qatar 25 17 N 51 32 E
Donets Basin Russia, Ukraine 48 15 N 38 30 E
Douala (city) Cameroon 4 03 N 9 42 E
Douglas (capital) Man, Isle of 54 09 N 4 28 W
Dover, Strait of Atlantic Ocean 51 00 N 1 30 E
Drake Passage Atlantic Ocean, 60 00 S 60 00 W
Southern Ocean
Druk Yul (local name for Bhutan 27 30 N 90 30 E
Bhutan)
Dubai, Dubayy (city) United Arab 25 18 N 55 18 E
Emirates
Dublin (capital) Ireland 53 20 N 6 15 W
Duesseldorf (city) Germany 51 13 N 6 47 E
Durban (city) South Africa 29 51 S 31 02 E
Dushanbe (capital) Tajikistan 38 35 N 68 48 E
Dutch Antilles (former Netherlands 12 10 N 68 30 W
name for the Netherlands Antilles
Antilles)
Dutch East Indies (former Indonesia 5 00 S 120 00 E
name for Indonesia)
Dutch Guiana (former name Suriname 4 00 N 56 00 W
for Suriname)
Dutch West Indies (former Netherlands 12 10 N 68 30 W
name for the Netherlands Antilles
Antilles)
Dzungarian Gate (valley) China, Kazakhstan 45 25 N 82 25 E
East China Sea Pacific Ocean 30 00 N 126 00 E
East Frisian Islands Germany 53 44 N 7 25 E
East Germany (German Germany 52 00 N 13 00 E
Democratic Republic;
former name for eastern
portion of Germany)
East Korea Strait Pacific Ocean 34 00 N 129 00 E
(Eastern Channel or
Tsushima Strait)
East Pakistan (former Bangladesh 24 00 N 90 00 E
name for Bangladesh)
East Siberian Sea Arctic Ocean 74 00 N 166 00 E
Easter Island (Isla de Chile 27 07 S 109 22 W
Pascua)
Eastern Channel (East Pacific Ocean 34 00 N 129 00 E
Korea Strait or Tsushima
Strait)
Eastern Samoa (former American Samoa 14 20 S 170 00 W
name for American Samoa)
Edinburgh (city) United Kingdom 55 57 N 3 11 W
Eesti (local name for Estonia 59 00 N 26 00 E
Estonia)
Eire (local name for Ireland 53 00 N 8 00 W
Ireland)
Elba (island) Italy 42 46 N 10 17 E
Elemi Triangle (region) Ethiopia (claimed), 5 00 N 35 30 E
Kenya (de facto),
Sudan (claimed)
Ellada, Ellas (local name Greece 39 00 N 22 00 E
for Greece)
Ellef Ringnes Island Canada 78 00 N 103 00 W
Ellesmere Island Canada 81 00 N 80 00 W
Ellice Islands Tuvalu 8 00 S 178 00 E
Ellsworth Land (region) Antarctica 75 00 S 92 00 W
Elobey, Islas de (island Equatorial Guinea 0 59 N 9 33 E
group)
Enderbury Island Kiribati 3 08 S 171 05 W
Enewetak Atoll (Eniwetok Marshall Islands 11 30 N 162 15 E
Atoll)
England (region) United Kingdom 52 30 N 1 30 W
English Channel Atlantic Ocean 50 20 N 1 00 W
Eniwetok Atoll (see Marshall Islands 11 30 N 162 15 E
Enewetak Atoll)
Eolie, Isole (island Italy 38 30 N 15 00 E
group)
Epirus, Northern (region) Albania, Greece 40 00 N 20 30 E
Episkopi Cantonment Akrotiri, Dhekelia 34 40 N 32 51 E
(capital)
Ertra (local name for Eritrea 15 00 N 39 00 E
Eritrea)
Espana Spain 40 00 N 4 00 W
Essequibo (region; Guyana 6 59 N 58 23 W
claimed by Venezuela)
Etorofu (island; also Russia (de facto) 44 55 N 147 40 E
Iturup)
Farquhar Group (island Seychelles 10 10 S 51 10 E
group; also Atoll de
Farquhar)
Fergana Valley Kyrgyzstan, 41 00 N 72 00 E
Tajikistan,','0374741e9e107f933e7901db038bf6c0cac9d98589602880e2e81e0607113789','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6eb86bfc48f35302a5e97ccaad2d6e8b79579d93810596d8ef1530cdb1c5ee8d',2007,'EH','Western Sahara','geography',17,'Location
Geographic coordinates
Map references
Area
total
land
water
Area - comparative
Land boundaries
total
border countries
Coastline
Maritime claims
territorial sea
contiguous zone
exclusive economic zone
continental shelf
exclusive fishing zone
Climate
Terrain
Elevation extremes
toivesr point
highest point
Natural resources
Land use
arable land
permanent crops
other
Irrigated land
Natural hazards
Environment - current issues
Environment - international agreements
party to
signed, but not ratified
Geography • note
Peopl
Population
Age structure
0-14 years
15-64 years
65 years and over
Median age
total population
male
female
Population growth rate
Birth rate
Death rate
Net migration rate
Sex ratio
at birth
under 15 years
15-64 years
65 years and over
total population
Infant mortality rate
total
male
female
Life expectancy at birth
total population
male
female
e
Total fertility rate
HIV/AIDS - adult prevalence rate
HIV/AIDS - people living with HIV/AIDS
HIV/AIDS - deaths
Major infectious diseases
degree of risk
food or waterborne diseases
vectorbome diseases
water contact diseases
aerosolized dust or soil contact disease
respiratory disease
animal contact disease
Nationality
noun
adjective
Ethnic groups
Religions
Languages
Literacy
definition
total population
male
female
People - note
Map references: Physical Map of the World , Political
Map of the World, Standard Time Zones of the World
Area:
total: 510.072 million sq km
land: 148.94 million sq km
water: 361 .132 million sq km
note: 70.8% of the world''s surface is water, 29.2% is
land
Area - comparative: land area about 16 times the
size of the US
Land boundaries: the land boundaries in the world
total 250,472 km (not counting shared boundaries
twice); two nations, China and Russia, each border 14
other countries
note: 43 nations and other areas are landlocked,
these include: Afghanistan, Andorra, Armenia,
Austria, Azerbaijan, Belarus, Bhutan, Bolivia,
Botswana, Burkina Faso, Burundi, Central African
Republic, Chad, Czech Republic, Ethiopia, Holy See
(Vatican City), Hungary, Kazakhstan, Kyrgyzstan,
Laos, Lesotho, Liechtenstein, Luxembourg,
Macedonia, Malawi, Mali, Moldova, Mongolia, Nepal,
Niger, Paraguay, Rwanda, San Marino, Slovakia,
Swaziland, Switzerland, Tajikistan, Turkmenistan,
Uganda, Uzbekistan, West Bank, Zambia, Zimbabwe;
two of these, Liechtenstein and Uzbekistan, are
doubly landlocked
Coastline: 356,000 km
note: 98 nations and other entities are islands that
border no other countries, they include: American
Samoa, Anguilla, Antigua and Barbuda, Aruba,
Ashmore and Cartier Islands, The Bahamas, Bahrain,
Baker Island, Barbados, Bassas da India, Bermuda,
Bouvet Island, British Indian Ocean Territory, British
Virgin Islands, Cape Verde, Cayman Islands,
Christmas Island, Clipperton Island, Cocos (Keeling)
Islands, Comoros, Cook Islands, Coral Sea Islands,
Cuba, Cyprus, Dominica, Europa Island, Falkland
Islands (Islas Malvinas), Faroe Islands, Fiji, French
Polynesia, French Southern and Antarctic Lands,
Glorioso Islands, Greenland, Grenada, Guam,
Guernsey, Heard Island and McDonald Islands,
Howland Island, Iceland, Isle of Man, Jamaica, Jan
Mayen, Japan, Jarvis Island, Jersey, Johnston Atoll,
Juan de Nova Island, Kingman Reef, Kiribati,
Madagascar, Maldives, Malta, Marshall Islands,
Martinique, Mauritius, Mayotte, Federated States of
Micronesia, Midway Islands, Montserrat, Nauru,
Navassa Island, New Caledonia, New Zealand, Niue,
Norfolk Island, Northern Mariana Islands, Palau,
Palmyra Atoll, Paracel Islands, Philippines, Pitcairn
Islands, Puerto Rico, Reunion, Saint Helena, Saint
Kitts and Nevis, Saint Lucia, Saint Pierre and
Miquelon, Saint Vincent and the Grenadines, Samoa,
Sao Tome and Principe, Seychelles, Singapore,
Solomon Islands, South Georgia and the South
Sandwich Islands, Spratly Islands, Sri Lanka,
Svalbard, Tokelau, Tonga. Trinidad and Tobago.
Tromelin Island, Turks and Caicos Islands, Tuvalu,
Vanuatu, Virgin Islands, Wake Island, Wallis and
Futuna, Taiwan
Maritime claims: a variety of situations exist, but in
general, most countries make the following claims
measured from the mean low-tide baseline as
described in the 1982 UN Convention on the Law of
the Sea: territorial sea - 12 nm, contiguous zone -
24 nm, and exclusive economic zone - 200 nm:
additional zones provide for exploitation of continental
shelf resources and an exclusive fishing zone;
boundary situations with neighboring states prevent
many countries from extending their fishing or
economic zones to a full 200nm
Climate: two large areas of polar climates separated
by two rather narrow temperate zones form a wide
equatorial band of tropical to subtropical climates
Terrain: the greatest ocean depth is the Mariana
Trench at 10,924 m in the Pacific Ocean
Elevation extremes:
lowest point: Bentley Subglacial Trench -2,540 m
note: in the oceanic realm, Challenger Deep in the
Mariana Trench is the lowest point, lying -10,924 m
below the surface of the Pacific Ocean
highest point: Mount Everest 8,850 m
Natural resources: the rapid depletion of
nonrenewable mineral resources, the depletion of
forest areas and wetlands, the extinction of animal
and plant species, and the deterioration in air and
water quality (especially in Eastern Europe, the former
USSR, and China) pose serious long-term problems
that governments and peoples are only beginning to
address
Land use:
arable land: 13.31%
permanent crops: 4.71%
otoe/7 81 .98% (2005)
Irrigated land: 2,714,320 sq km (1998 est.)
Natural hazards: large areas subject to severe
weather (tropical cyclones), natural disasters
(earthquakes, landslides, tsunamis, volcanic
eruptions)
Environment - current issues: large areas subject
to overpopulation, industrial disasters, pollution (air.
water, acid rain, toxic substances), loss of vegetation
(overgrazing, deforestation, desertification), lossol
wildlife, soil degradation, soil depletion, erosion
Geography - note: the world is now thought to be
about 4.55 billion years old. just about one-third of the
13-billion-year age estimated for the universe','e11dee59437e63f65b7db250f6c06c6d558a2c5bde2f5c2cd7a09eb2dd0523d4','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4bd50b390efc5aded71a6e59edb3550ef406b46378305e919f432fef5f7aa90b',2007,'AF','Afghanistan','geography',26,'Location: Southern Asia, north and west of Pakistan.
east of Iran
Geographic coordinates: 33 00 N, 65 00 E
Map references: Asia
Area:
total: 647,500 sq km
land: 647,500 sq km
water: 0 sq km
Area - comparative: slightly smaller than Texas
Afghanistan (continued)
Land boundaries:
total: 5.529 km
border countries: China 76 km, Iran 936 km, Pakistan
2,430 km, Tajikistan 1 ,206 km, Turkmenistan 744 km,
Uzbekistan 137 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: arid to semiarid; cold winters and hot
summers
Terrain: mostly rugged mountains; plains in north
and southwest
Elevation extremes:
lowest point: Amu Darya 258 m
highest point: Nowshak 7,485 m
Natural resources: natural gas, petroleum, coal,
copper, chromite, talc, barites, sulfur, lead, zinc, iron
ore, salt, precious and semiprecious stones
Land use:
arable land: 12.13%
permanent crops: 0.21%
other: 87.66% (2005)
Irrigated land: 23,860 sq km (1998 est.)
Natural hazards: damaging earthquakes occur in
Hindu Kush mountains; flooding; droughts
Environment - current issues: limited natural fresh
water resources; inadequate supplies of potable
water; soil degradation; overgrazing; deforestation
(much of the remaining forests are being cut down for
fuel and building materials); desertification; air and
water pollution
Environment • international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Marine Dumping
signed, but not ratified: Hazardous Wastes, Law of
the Sea, Marine Life Conservation
Geography - note: landlocked; the Hindu Kush
mountains that run northeast to southwest divide the
northern provinces from the rest of the country; the
highest peaks are in the northern Vakhan (Wakhan
Corridor)
Location: Central Asia, bordering the Caspian Sea,
between Iran and Kazakhstan
Geographic coordinates: 40 00 N. 60 00 E
Map references: Asia
Area:
tofa/:488,100sqkm
land: 488,100 sq km
water: NEGL
Area - comparative: slightly larger than California
Land boundaries:
total: 3,736 km
border countries: Afghanistan 744 km, Iran 992 km,
Kazakhstan 379 km, Uzbekistan 1,621 km
Coastline: 0 km; note - Turkmenistan borders the
Caspian Sea (1,768 km)
Maritime claims: none (landlocked)
Climate: subtropical desert
Terrain: flat-to-rolling sandy desert with dunes rising
to mountains in the south; low mountains along border
with Iran; borders Caspian Sea in west
Elevation extremes:
lowest point: Vpadina Akchanaya -81 m; note -
Sarygamysh Koli is a lake in northern Turkmenistan
with a water level that fluctuates above and below the
elevation of Vpadina Akchanaya (the lake has
dropped as low as -110 m)
note: Sarygamysh Koli is a lake in northern
Turkmenistan with a water level that fluctuates above
and below the elevation of Vpadina Akchanaya (the
lake has dropped as low as -1 10 m)
highest point: Gora Ayribaba 3,139 m
Natural resources: petroleum, natural gas, sulfur,
salt
Land use:
arable land: 4.51%
permanent crops: 0.1 4%
other: 95.35% (2005)
Irrigated land: 17,500 sq km (2003 est.)
Natural hazards: NA
Environment - current issues: contamination of
soil and groundwater with agricultural chemicals,
pesticides; salination, water-logging of soil due to poor
irrigation methods; Caspian Sea pollution; diversion of
a large share of the flow of the Amu Darya into
irrigation contributes to that river''s inability to replenish
the Aral Sea; desertification
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazardous
Wastes, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography ■ note: landlocked; the western and
central low-lying, desolate portions of the country
make up the great Garagum (Kara-Kum) desert,
which occupies over 80% of the country; eastern part
is plateau
Location: Caribbean, two island groups in the North
Atlantic Ocean, southeast of The Bahamas, north of Haiti
Geographic coordinates: 21 45 N. 71 35 W
Map references: Central America and the
Caribbean
Area:
total: 430 sq km
land: 430 sq km
water: 0 sq km
Area - comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 389 km
Maritime claims:
territorial sea: 1 2 nm
exclusive fishing zone: 200 nm
Climate: tropical; marine; moderated by trade winds;
sunny and relatively dry
Terrain: low, flat limestone; extensive marshes and
mangrove swamps
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Blue Hills 49 m
Natural resources: spiny lobster, conch
Land use:
arable land: 2.33°o
permanent crops: 0°o
other: 97.67% (2005)
Irrigated land: NA sq km
Natural hazards: frequent hurricanes
Environment • current issues: limited natural fresh
water resources, private cisterns collect rainwater
Geography - note: about 40 islands (eight
inhabited)','9b5251e56506c14018a5b87e77038fe360453b7e227a65e769737adb274690a0','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1c36b1fd8d910d52c91cf28e2937a2d338784e079882ca6e81a4482db5796757',2007,'AL','Albania','geography',35,'Location: peninsula on the southwest coast of Cyprus
Geographic coordinates: 34 37 N, 32 58 E
Map references: Middle East
Area:
tote/: 123 sq km
note: includes a salt lake and wetlands
Area - comparative: about 0.7 times the size of
Washington, DC
Land boundaries:
total: 47.4 km
border countries: Cyprus 47.4 km
Coastline: 56.3 km
Climate: temperate; Mediterranean with hot, dry
summers and cool winters
Environment - current issues: shooting around the
salt lake; note - breeding place for loggerhead and
green turtles; only remaining colony of griffon vultures
is on the base
Geography - note: British extraterritorial rights also
extended to several small off-post sites scattered
across Cyprus
Location: Southeastern Europe, bordering the
Adriatic Sea and Ionian Sea, between Greece and
Serbia and Montenegro
Geographic coordinates: 41 00 N, 20 00 E
Map references: Europe
Albania (continued)
Area:
total: 28,748 sq km
land: 27,398 sq km
water: 1 ,350 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries:
total: 720 km
border countries: Greece 282 km, Macedonia 1 51 km,
Serbia and Montenegro 287 km
Coastline: 362 km
Maritime claims:
territorial sea: 1 2 nm
continental shelf: 200-m depth or to the depth of
exploitation
Climate: mild temperate; cool, cloudy, wet winters;
hot, clear, dry summers; interior is cooler and wetter
Terrain: mostly mountains and hills; small plains
along coast
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Maja e Korabit (Golem Korab) 2,764 m
Natural resources: petroleum, natural gas, coal,
bauxite, chromite, copper, iron ore, nickel, salt, timber,
hydropower
Land use:
arable land: 20.1%
permanent crops: 4.21 %
other: 75.69% (2005)
Irrigated land: 3,400 sq km (1998 est.)
Natural hazards: destructive earthquakes; tsunamis
occur along southwestern coast; floods; drought
Environment - current issues: deforestation; soil
erosion; water pollution from industrial and domestic
effluents
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location along Strait of
Otranto (links Adriatic Sea to Ionian Sea and
Mediterranean Sea)','79df896f156c4dd4cd52b5aac3ffaf77f48bd1cae9f3c76084d241dde282bd8e','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d95def6e7760b07ad7ac949ff9973f669643c0c1663d5b85aceb4feb53b84909',2007,'ES','Spain','geography',45,'Location: Northern Africa, bordering the
Mediterranean Sea, between Morocco and Tunisia
Geographic coordinates: 28 00 N, 3 00 E
Map references: Africa
Area:
total: 2,381 ,740 sq km
land: 2,381 ,740 sq km
water: 0 sq km
Area - comparative: slightly less than 3.5 times the
size of Texas
Land boundaries:
total: 6,343 km
border countries: Libya 982 km, Mali 1,376 km,
Mauritania 463 km, Morocco 1 .559 km, Niger 956 km,
Tunisia 965 km, Western Sahara 42 km
Coastline: 998 km
Maritime claims:
territorial sea: 12 nm
exclusive fishing zone: 32-52 nm
Climate: arid to semiarid; mild, wet winters with hot,
dry summers along coast; drier with cold winters and
hot summers on high plateau; sirocco is a hot, dust/
sand-laden wind especially common in summer
Terrain: mostly high plateau and desert; some
mountains: narrow, discontinuous coastal plain
Elevation extremes:
lowest point: Chott Melrhir -40 m
highest point: Tahat 3,003 m
Natural resources: petroleum, natural gas, iron ore,
phosphates, uranium, lead, zinc
Land use:
arable land: 3.17%
permanent crops: 0.28%
other: 96.55% (2005)
Irrigated land: 5,600 sq km (1998 est.)
Natural hazards: mountainous areas subject to
severe earthquakes; mudslides and floods in rainy
season
Environment • current issues: soil erosion from
overgrazing and other poor farming practices;
desertification; dumping of raw sewage, petroleum
refining wastes, and other industrial effluents is
leading to the pollution of rivers and coastal waters;
Mediterranean Sea, in particular, becoming polluted
from oil wastes, soil erosion, and fertilizer runoff;
inadequate supplies of potable water
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: second-largest country in Africa
(after Sudan)
10
Algeria (continued)
Location: Southwestern Europe, between France
and Spain
Geographic coordinates: 42 30 N, 1 30 E
Map references: Europe
Area:
total: 468 sq km
land: 468 sq km
water: 0 sq km
Area - comparative: 2.5 times the size of
Washington, DC
Land boundaries:
total: 120.3 km
border countries: France 56.6 km, Spain 63.7 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; snowy, cold winters and warm,
dry summers
Terrain: rugged mountains dissected by narrow
valleys
Elevation extremes:
lowest point: Riu Runer 840 m
highest point: Coma Pedrosa 2,946 m
Natural resources: hydropower, mineral water,
timber, iron ore, lead
Land use:
arable land: 2.13%
permanent crops: 0%
other: 97.87% (2005)
Irrigated land: NA sq km
Natural hazards: avalanches
Environment - current issues: deforestation;
overgrazing of mountain meadows contributes to soil
erosion; air pollution; wastewater treatment and soiid
waste disposal
Environment - international agreements:
party to: Hazardous Wastes
signed, but not ratified: none of the selected
agreements
Geography • note: landlocked; straddles a number
of important crossroads in the Pyrenees
Location: Southwestern Europe, bordering the
North Atlantic Ocean, west of Spain
Geographic coordinates: 39 30 N, 8 00 W
Map references: Europe
Area:
total: 92,391 sq km
land: 91 ,951 sqkm
wafer: 440 sq km
note: includes Azores and Madeira Islands
Area - comparative: slightly smaller than Indiana
Land boundaries:
total: 1,214 km
border countries: Spain 1 ,214 km
Coastline: 1,793 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200-m depth or to the depth of
exploitation
Climate: maritime temperate; cool and rainy in north,
warmer and drier in south
Terrain: mountainous north of the Tagus River,
rolling plains in south
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Ponta do Pico (Pico or Pico Alto) on Una
do Pico in the Azores 2,351 m
Natural resources: fish, forests (cork), iron ore,
copper, zinc, tin, tungsten, silver, gold, uranium,
marble, clay, gypsum, salt, arable land, hydropower
Land use:
arable land: 17.29%
permanent crops: 7.84%
other: 74.87% (2005)
Irrigated land: 6,320 sq km (1998 est.)
Natural hazards: Azores subject to severe
earthquakes
Environment - current issues: soil erosion; air
pollution caused by industrial and vehicle emissions;
water pollution, especially in coastal areas
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Air Pollution-Volatile Organic
Compounds, Environmental Modification
Geography • note: Azores and Madeira Islands
occupy strategic locations along western sea
approaches to Strait of Gibraltar','58e1d1fb4ce4a38e2cd8cd0970f88f515a5c721bd838927b614faab649808933','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1551666bd22da1ac95c55d6a3348bd3d6c20b276dba89e9f1b740e7bd46dbc1',2007,'AS','American Samoa','geography',54,'Location: Oceania, group of islands in the South
Pacific Ocean, about half way between Hawaii and','b14f2300783241adb4fb59b3019b9fb19f99dbda143f99f4909718a8f0149bc0','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('048a302021a309e7a38d7354eff879c530a75a982cae9f9b4f740e9bcb66f2f1',2007,'NZ','New Zealand','geography',55,'Geographic coordinates: 14 20 S, 170 00 W
Map references: Oceania
Area:
tofa/:199sqkm
land: 199 sq km
water: 0 sq km
note: includes Rose Island and Swains Island
Area - comparative: slightly larger than
Washington, DC
Land boundaries: 0 km
Coastline: 116 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical marine, moderated by southeast
trade winds; annual rainfall averages about 3 m; rainy
season (November to April), dry season (May to
October); little seasonal temperature variation
Terrain: five volcanic islands with rugged peaks and
limited coastal plains, two coral atolls (Rose Island,
Swains Island)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Lata 966 m
Natural resources: pumice, pumicite
Land use:
arable land: 10%
permanent crops: 15%
other: 75% (2005)
Irrigated land: NA
Natural hazards: typhoons common from December
to March
Environment - current issues: limited natural fresh
water resources; the water division of the government
has spent substantial funds in the past few years to
improve water catchments and pipelines
Geography - note: Pago Pago has one of the best
natural deepwater harbors in the South Pacific Ocean.
sheltered by shape from rough seas and protected by
peripheral mountains from high winds; strategic
location in the South Pacific Ocean
Geographic coordinates: 18 00 S, 175 00 E
Map references: Oceania
Area:
tofa/:1 8,270 sq km
land: 18,270 sq km
water: 0 sq km
Area - comparative: slightly smaller than New
Location: Oceania, islands in the South Pacific
Ocean, southeast of Australia
Geographic coordinates: 41 00 S, 174 00 E
Map references: Oceania
Area:
total: 268,680 sq km
land: 268,021 sq km
water: NA
note: includes Antipodes Islands, Auckland Islands,
Bounty Islands, Campbell Island, Chatham Islands,
and Kermadec Islands
Area - comparative: about the size of Colorado
Land boundaries: 0 km
Coastline: 15,134 km
Maritime claims:
territorial sea: 1 2 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: temperate with sharp regional contrasts
Terrain: predominately mountainous with some
large coastal plains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Aoraki-Mount Cook 3,754 m
Natural resources: natural gas, iron ore, sand, coal,
timber, hydropower, gold, limestone
Land use:
arable land: 5.54%
permanent crops: 6.92%
other: 87.54% (2005)
Irrigated land: 2,850 sq km (1998 est.)
Natural hazards: earthquakes are common, though
usually not severe; volcanic activity
Environment - current issues: deforestation; soil
erosion; native flora and fauna hard-hit by invasive
species
Environment - international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Treaty,
Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification. Endangered Species,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Marine Dumping, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber
94, Wetlands, Whaling
signed, but not ratified: Antarctic Seals, Marine Life
Conservation
Geography - note: about 80% of the population lives
in cities; Wellington is the southernmost national
capital in the world
Geographic coordinates: 20 00 S, 175 00 W
Map references: Oceania
Area:
total: 748 sq km
land: 71 8 sq km
water: 30 sq km
Area • comparative: four times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 419 km
Maritime claims:
territorial sea: 1 2 nm
exclusive economic zone: 200 nm
continental shelf: 200-m depth or to the depth of
exploitation
Climate: tropical; modified by trade winds; warm
season (December to May), cool season (May to
December)
Terrain: most islands have limestone base formed
from uplifted coral formation; others have limestone
overlying volcanic base
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Kao Island 1 ,033
m
Natural resources: fish, fertile soil
Land use:
arable land: 20%
permanent crops: 14.67%
other: 65.33% (2005)
Irrigated land: NA
Natural hazards: cyclones (October to April);
earthquakes and volcanic activity on Fonuafo''ou
Environment • current issues: deforestation
results as more and more land is being cleared for
agriculture and settlement; some damage to coral
reefs from starfish and indiscriminate coral and shell
collectors; overhunting threatens native sea turtle
populations
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Law of the Sea, Marine Dumping,
Marine Life Conservation, Ozone Layer Protection,
Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography • note: archipelago of 169 islands (36
inhabited)
Location: Caribbean, islands between the
Caribbean Sea and the North Atlantic Ocean,
northeast of Venezuela
Geographic coordinates: 1 1 00 N, 61 00 W
Map references: Central America and the
Caribbean
Area:
total: 5,128 sq km
land: 5,128 sq km
water: 0 sq km
Area • comparative: slightly smaller than Delaware
Land boundaries: 0 km
Coastline: 362 km
Maritime claims: measured from claimed
archipelagic baselines
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelt: 200 nm or to the outer edge of the
continental margin
Climate: tropical; rainy season (June to December)
Terrain: mostly plains with some hills and low
mountains
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: El Cerro del Aripo 940 m
Natural resources: petroleum, natural gas, asphalt
Land use:
arable land: 14.62%
permanent crops: 9. 1 6%
other: 76.22% (2005)
Irrigated land: 30 sq km (1998 est.)
Natural hazards: outside usual path of hurricanes
and other tropical storms
Environment - current issues: water pollution from
agricultural chemicals, industrial wastes, and raw
sewage; oil pollution of beaches; deforestation; soil
erosion
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Life Conservation, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: Pitch Lake, on Trinidad''s
southwestern coast, is the world''s largest natural
reservoir of asphalt
Location: Southern Africa, island in the Indian
Ocean, east of Madagascar
Geographic coordinates: 15 52 S, 54 25 E
Map references: Africa
Area:
total: 1 sq km
land: 1 sq km
water: 0 sq km
Area • comparative: about 1 .7 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 3.7 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200-m depth or to the depth of
exploitation
Climate: tropical
Terrain: low, flat, and sandy; likely volcanic
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 7 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (grasses; scattered bushes) (2005)
Irrigated land: Osq km (1998 est.)
Natural hazards: NA
Environment - current issues: NA
Geography - note: climatologically important
location for forecasting cyclones; wildlife sanctuary
(seabirds, tortoises)
556
Tromelin Island (continued)
Geographic coordinates: 13 18 S, 176 12 W
Map references: Oceania
Area:
total: 21 A sq km
land: 274 sq km
water: 0 sq km
note: includes He Uvea (Wallis Island), He Futuna
(Futuna Island), He Alofi, and 20 islets
Area - comparative: 1 .5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 129 km
Maritime claims:
territorial sea: 1 2 nm
exclusive economic zone: 200 nm
Climate: tropical; hot, rainy season (November to
April); cool, dry season (May to October); rains
2,500-3,000 mm per year (80% humidity); average
temperature 26.6 degrees C
Terrain: volcanic origin; low hills
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mont Singavi 765 m
Natural resources: NEGL
Land use:
arable land: 7.14%
permanent crops: 35.71%
other: 57.15% (2005)
Irrigated land: NA sq km
Natural hazards: NA
Environment - current issues: deforestation (only
small portions of the original forests remain) largely as
a result of the continued use of wood as the main fuel
source; as a consequence of cutting down the forests,
the mountainous terrain of Futuna is particularly prone
to erosion; there are no permanent settlements on
Alcfi because of the lack of natural fresh water
resources
Geography - note: both island groups have fringing
reefs','00ffc63b4662a2b5e296cc1942e6391a8760d33db00f930d270a55ca41abead3','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87332c3fac1d493a67a9f3b67b34d28252f51cb5dc4158bc3895bd4645443710',2007,'NA','Namibia','geography',67,'Location: Southern Africa, bordering the South
Atlantic Ocean, between Namibia and Democratic
Republic of the Congo
Geographic coordinates: 12 30 S, 18 30 E
Map references: Africa
Area:
total: 1 ,246,700 sq km
land: 1,246,700 sq km
water: 0 sq km
Area - comparative: slightly less than twice the size
of Texas
Land boundaries:
total: 5,198 km
border countries: Democratic Republic of the Congo
2,51 1 km (of which 225 km is the boundary of
discontiguous Cabinda Province), Republic of the
Congo 201 km, Namibia 1,376 km, Zambia 1,110 km
Coastline: 1,600 km
Maritime claims:
territorial sea: 1 2 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: semiarid in south and along coast to
Luanda; north has cool, dry season (May to October)
and hot, rainy season (November to April)
Terrain: narrow coastal plain rises abruptly to vast
interior plateau
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Morro de Moco 2,620 m
Natural resources: petroleum, diamonds, iron ore.
phosphates, copper, feldspar, gold, bauxite, uranium
Land use:
arable land: 2.65%
permanent crops: 0.23%
other: 97.12% (2005)
Irrigated land: 750 sq km (1998 est.)
Natural hazards: locally heavy rainfall causes
periodic flooding on the plateau
Environment - current issues: overuse of pastures
and subsequent soil erosion attributable to population
pressures; desertification; deforestation of tropical
rain forest, in response to both international demand
for tropical timber and to domestic use as fuel,
resulting in loss of biodiversity; soil erosion
contributing to water pollution and siltation of rivers
and dams; inadequate supplies of potable water
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Law of the Sea, Ozone Layer
Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: the province of Cabinda is an
exclave, separated from the rest of the country by the
Democratic Republic of the Congo
Location: Southern Africa, at the southern tip of the
continent of Africa
Geographic coordinates: 29 00 S, 24 00 E
Map references: Africa
Area:
total: 1,219,912 sq km
land: 1,219,912 sq km
water: 0 sq km
note: includes Prince Edward Islands (Marion Island
and Prince Edward Island)
Area - comparative: slightly less than twice the size
of Texas
Land boundaries:
total: 4,862 km
border countries: Botswana 1 ,840 km, Lesotho 909
km, Mozambique 491 km, Namibia 967 km, Swaziland
430 km, Zimbabwe 225 km
Coastline: 2,798 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to edge of the continental
margin
Climate: mostly semiarid: subtropical along east
coast; sunny days, cool nights
510
South Africa (continued)
Terrain: vast interior plateau rimmed by rugged hills
and narrow coastal plain
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Njesuthi 3,408 m
Natural resources: gold, chromium, antimony, coal,
iron ore, manganese, nickel, phosphates, tin,
uranium, gem diamonds, platinum, copper, vanadium,
salt, natural gas
Land use:
arable land: 12.1%
permanent crops: 0.79%
other 87.11% (2005)
Irrigated land: 13,500 sq km (1998 est.)
Natural hazards: prolonged droughts
Environment - current issues: lack of important
arterial rivers or lakes requires extensive water
conservation and control measures; growth in water
usage outpacing supply; pollution of rivers from
agricultural runoff and urban discharge; air pollution
resulting in acid rain; soil erosion; desertification
Environment - international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution, Wetlands,
Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: South Africa completely
surrounds Lesotho and almost completely surrounds
Swaziland
Location: Southern South America, islands in the
South Atlantic Ocean, east of the tip of South America
Geographic coordinates: 54 30 S, 37 00 W
Map references: Antarctic Region
Area:
total: 3,903 sq km
land: 3,903 sq km
water: 0 sq km
note: includes Shag Rocks, Black Rock, Clerke
Rocks, South Georgia Island, Bird Island, and the
South Sandwich Islands, which consist of some nine
islands
Area - comparative: slightly larger than Rhode
Island
Land boundaries: 0 km
Coastline: NAkm
Maritime claims:
territorial sea: 12 nm
exclusive fishing zone: 200 nm
Climate: variable, with mostly westerly winds
throughout the year interspersed with periods of calm;
nearly all precipitation falls as snow
Terrain: most of the islands, rising steeply from the
sea, are rugged and mountainous; South Georgia is
largely barren and has steep, glacier-covered
mountains; the South Sandwich Islands are of
volcanic origin with some active volcanoes
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Paget (South Georgia) 2,934 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (largely covered by permanent ice and .
snow with some sparse vegetation consisting of
grass, moss, and lichen) (2005)
Irrigated land: 0 sq km (1998 est.)
Natural hazards: the South Sandwich Islands have
prevailing weather conditions that generally make
them difficult to approach by ship; they are also
subject to active volcanism
Environment - current issues: NA
Geography - note: the north coast of South Georgia
has several large bays, which provide good
anchorage; reindeer, introduced early in the 20th
century, live on South Georgia
S
Location: body of water between 60 degrees south
latitude and Antarctica
Geographic coordinates: 60 00 S, 90 00 E
(nominally), but the Southern Ocean has the unique
distinction of being a large circumpolar body of water
totally encircling the continent of Antarctica; this ring of
water lies between 60 degrees south latitude and the
coast of Antarctica and encompasses 360 degrees of
longitude
Map references: Antarctic Region
Area:
total: 20.327 million sq km
note: includes Amundsen Sea. Bellingshausen Sea,
part of the Drake Passage, Ross Sea, a small part of
the Scotia Sea, Weddell Sea, and other tributary water
bodies
Area - comparative: slightly more than twice the
size of the US
Coastline: 17,968 km
Climate: sea temperatures vary from about 10
degrees Celsius to -2 degrees Celsius; cyclonic
storms travel eastward around the continent and
frequently are intense because of the temperature
contrast between ice and open ocean; the ocean area
from about latitude 40 south to the Antarctic Circle has
the strongest average winds found anywhere on
Earth; in winter the ocean freezes outward to 65
degrees south latitude in the Pacific sector and 55
degrees south latitude in the Atlantic sector, lowering
surface temperatures well below 0 degrees Celsius; at
some coastal points intense persistent drainage winds
from the interior keep the shoreline ice-free
throughout the winter
Terrain: the Southern Ocean is deep, 4,000 to 5,000
meters over most of its extent with only limited areas
of shallow water; the Antarctic continental shelf is
generally narrow and unusually deep, its edge lying at
depths of 400 to 800 meters (the global mean is 133
meters); the Antarctic icepack grows from an average
minimum of 2.6 million square kilometers in March to
about 18.8 million square kilometers in September,
better than a sixfold increase in area; the Antarctic
Circumpolar Current (21,000 km in length) moves
perpetually eastward; it is the world''s largest ocean
current, transporting 1 30 million cubic meters of water
per second - 100 times the flow of all the world''s rivers
Elevation extremes:
lowest point: -7,235 m at the southern end of the
South Sandwich Trench
highest point: sea level 0 m
Natural resources: probable large and possible
giant oil and gas fields on the continental margin,
manganese nodules, possible placer deposits, sand
and gravel, fresh water as icebergs; squid, whales,
and seals - none exploited; krill, fishes
Natural hazards: huge icebergs with drafts up to
several hundred meters; smaller bergs and iceberg
fragments; sea ice (generally 0.5 to 1 meter thick) with
sometimes dynamic short-term variations and with
large annual and interannual variations; deep
continental shelf floored by glacial deposits varying
widely over short distances; high winds and large
waves much of the year; ship icing, especially
May-October; most of region is remote from sources
of search and rescue
Environment - current issues: increased solar
ultraviolet radiation resulting from the Antarctic ozone
hole in recent years, reducing marine primary
productivity (phytoplankton) by as much as 15% and
damaging the DNA of some fish; illegal, unreported,
and unregulated fishing in recent years, especially the
514
Southern Ocean (continued)
landing of an estimated five to six times more
Patagonian toothfish than the regulated fishery, which
is likely to affect the sustainability of the stock; large
I amount of incidental mortality of seabirds resulting
from long-line fishing for toothfish
note: the now-protected fur seal population is making
a strong comeback after severe overexploitation in the
18th and 19th centuries
Environment - international agreements: the
Southern Ocean is subject to all international
agreements regarding the world''s oceans; in addition,
it is subject to these agreements specific to the
Antarctic region: International Whaling Commission
(prohibits commercial whaling south of 40 degrees
south [south of 60 degrees south between 50 degrees
and 130 degrees west]); Convention on the
Conservation of Antarctic Seals (limits sealing);
Convention on the Conservation of Antarctic Marine
Living Resources (regulates fishing)
note: many nations (including the US) prohibit mineral
resource exploration and exploitation south of the
fluctuating Polar Front (Antarctic Convergence) which
is in the middle of the Antarctic Circumpolar Current
and serves as the dividing line between the very cold
polar surface waters to the south and the warmer
waters to the north
Geography - note: the major chokepoint is the
Drake Passage between South America and
Antarctica; the Polar Front (Antarctic Convergence) is
the best natural definition of the northern extent of the
Southern Ocean; it is a distinct region at the middle of
the Antarctic Circumpolar Current that separates the
very cold polar surface waters to the south from the
warmer waters to the north; the Front and the Current
extend entirely around Antarctica, reaching south of
60 degrees south near New Zealand and near 48
degrees south in the far South Atlantic coinciding with
the path of the maximum westerly winds','cdb3db3a168078da6d3a262b61ffd7264098b3895a5d6a07f6584b8fb4bab398','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('027916704ba678c8c73fdc2f911dee66ee1463cb9c6218a31cef590e686b6451',2007,'AI','Anguilla','geography',77,'Location: Caribbean, islands between the
Caribbean Sea and North Atlantic Ocean, east of','91e6c458ede138a3fbbcbed3ed6703edaf5c9c288abeb7849a9acc904f0743c7','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('51d38b3b53bdab60dd50fd337737eb6f4e28256fc7bf134d6156f63112d0e40b',2007,'PR','Puerto Rico','geography',78,'Geographic coordinates: 18 15 N, 63 10 W
Map references: Central America and the
Caribbean
Area:
tofa/:102sqkm
land: 102 sq km
water: 0 sq km
Area • comparative: about half the size of
Washington, DC
Land boundaries: 0 km
Coastline: 61 km
Maritime claims:
territorial sea: 3 nm
exclusive fishing zone: 200 nm
Climate: tropical; moderated by northeast trade
winds
Terrain: flat and low-lying island of coral and
limestone
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Crocus Hill 65 m
Natural resources: salt, fish, lobster
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (mostly rock with sparse scrub oak, few
trees, some commercial salt ponds) (2005)
Irrigated land: NA
Natural hazards: frequent hurricanes and other
tropical storms (July to October)
Environment - current issues: supplies of potable
water sometimes cannot meet increasing demand
largely because of poor distribution system
Geography - note: the most northerly of the
Leeward Islands in the Lesser Antilles
Location: Caribbean, island between the Caribbean
Sea and the North Atlantic Ocean, east of the','0b3ac3ec773acdd73414695e1038f866a7dcd779a21cc4b0f66bc0787b022936','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a9e29c7663213ce60c7e480eeec266acf9e411c00dd3caae498b9395b365276',2007,'AQ','Antarctica','geography',87,'Location: continent mostly south of the Antarctic
Circle
Geographic coordinates: 90 00 S, 0 00 E
Map references: Antarctic Region
Area:
fora/: 14 million sq km
land: 14 million sq km (280,000 sq km ice-free, 13.72
million sq km ice-covered) (est.)
note: fifth-largest continent, following Asia, Africa,
North America, and South America, but larger than
Australia and the subcontinent of Europe
Area - comparative: slightly less than 1 .5 times the
size of the US
Land boundaries: 0 km
note: see entry on Disputes - international
Coastline: 17,968 km
21
Antarctica (continued)
Maritime claims: Australia, Chile, and Argentina
claim Exclusive Economic Zone (EEZ) rights or similar
over 200 nm extensions seaward from their continental
claims, but like the claims themselves, these zones are
not accepted by other countries; 21 of 28 Antarctic
consultative nations have made no claims to Antarctic
territory (although Russia and the US have reserved the
right to do so) and do not recognize the claims of the
other nations; also see the Disputes - international entry
Climate: severe low temperatures vary with latitude,
elevation, and distance from the ocean; East Antarctica
is colder than West Antarctica because of its higher
elevation; Antarctic Peninsula has the most moderate
climate; higher temperatures occur in January along the
coast and average slightly below freezing
Terrain: about 98% thick continental ice sheet and
2% barren rock, with average elevations between
2,000 and 4,000 meters; mountain ranges up to nearly
5,000 meters; ice-free coastal areas include parts of
southern Victoria Land, Wilkes Land, the Antarctic
Peninsula area, and parts of Ross Island on McMurdo
Sound; glaciers form ice shelves along about half of
the coastline, and floating ice shelves constitute 11%
of the area of the continent
Elevation extremes:
lowest point: Bentley Subglacial Trench -2,555 m
highest point: Vinson Massif 4,897 m
note: the lowest known land point in Antarctica is
hidden in the Bentley Subglacial Trench; at its surface
is the deepest ice yet discovered and the world''s
lowest elevation not under seawater
Natural resources: iron ore, chromium, copper,
gold, nickel, platinum and other minerals, and coal
and hydrocarbons have been found in small
uncommercial quantities; none presently exploited;
krill, finfish, and crab have been taken by commercial
fisheries
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (ice 98%, barren rock 2%) (2005)
Natural hazards: katabatic (gravity-driven) winds
blow coastward from the high interior; frequent
blizzards form near the foot of the plateau; cyclonic
storms form over the ocean and move clockwise along
the coast; volcanism on Deception Island and isolated
areas of West Antarctica; other seismic activity rare
and weak; large icebergs may calve from ice shelf
Environment - current issues: in 1998, NASA
satellite data showed that the Antarctic ozone hole was
the largest on record, covering 27 million square
kilometers; researchers in 1997 found that increased
ultraviolet light passing through the hole damages the
DNA of icefish, an Antarctic fish lacking hemoglobin;
ozone depletion earlier was shown to harm one-celled
Antarctic marine plants; in 2002, significant areas of ice
shelves disintegrated in response to regional warming
Geography - note: the coldest, windiest, highest (on
average), and driest continent; during summer, more
solar radiation reaches the surface at the South Pole
than is received at the Equator in an equivalent period;
mostly uninhabitable','a6a52c3c0fcaebd12eab13be67c6dbe35e6bc7090aa5f772024bbbd4e153ba5c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('96479c1bc7e466d4fdea63fa8558640030f2bec2c14340dab41786e32650404d',2007,'AG','Antigua and Barbuda','geography',98,'Location: Caribbean, islands between the
Caribbean Sea and the North Atlantic Ocean,
east-southeast of Puerto Rico
Geographic coordinates: 17 03 N, 61 48 W
Map references: Central America and the
Caribbean
Area:
total: 442.6 sq km (Antigua 280 sq km; Barbuda 161
sqkm)
land: 442.6 sq km
water: 0 sq km
note: includes Redonda, 1.6 sq km
Area - comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 153 km
Maritime claims:
territorial sea: 1 2 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: tropical maritime; little seasonal
temperature variation
Terrain: mostly low-lying limestone and coral
islands, with some higher volcanic areas
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Boggy Peak 402 m
Natural resources: NEGL; pleasant climate fosters
tourism
Land use:
arable fend: 18.18%
permanent crops: 4.55%
other: 77.27% (2005)
Irrigated land: NA
Natural hazards: hurricanes and tropical storms
(July to October); periodic droughts
Environment ■ current issues: water
management - a major concern because of limited
natural fresh water resources - is further hampered by
the clearing of trees to increase crop production,
causing rainfall to run off quickly
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: Antigua has a deeply indented
shoreline with many natural harbors and beaches;
Barbuda has a very large western harbor
Location: body of water between Europe, Asia, and
North America, mostly north of the Arctic Circle
Geographic coordinates: 90 00 N, 0 00 E
Map references: Arctic Region
Area:
total: 14.056 million sq km
note: includes Baffin Bay, Barents Sea, Beaufort Sea,
Chukchi Sea. East Siberian Sea, Greenland Sea,
Hudson Bay, Hudson Strait, Kara Sea, Laptev Sea,
Northwest Passage, and other tributary water bodies
Area - comparative: slightly less than 1 .5 times the
size of the US
Coastline: 45,389 km
Climate: polar climate characterized by persistent
cold and relatively narrow annual temperature ranges;
winters characterized by continuous darkness, cold
and stable weather conditions, and clear skies;
summers characterized by continuous daylight, damp
and foggy weather, and weak cyclones with rain or
snow
Terrain: central surface covered by a perennial
drifting polar icepack that, on average, is about 3
meters thick, although pressure ridges may be three
times that thickness; clockwise drift pattern in the
Beaufort Gyral Stream, but nearly straight-line
movement from the New Siberian Islands (Russia) to
Denmark Strait (between Greenland and Iceland); the
icepack is surrounded by open seas during the
summer, but more than doubles in size during the
winter and extends to the encircling landmasses; the
ocean floor is about 50% continental shelf (highest
percentage of any ocean) with the remainder a central
basin interrupted by three submarine ridges (Alpha
Cordillera, Nansen Cordillera, and Lomonosov Ridge)
Elevation extremes:
lowest point: Fram Basin -4,665 m
highest point: sea level 0 m
Natural resources: sand and gravel aggregates,
placer deposits, polymetallic nodules, oil and gas
fields, fish, marine mammals (seals and whales)
Natural hazards: ice islands occasionally break
away from northern Ellesmere Island; icebergs calved
from glaciers in western Greenland and extreme
northeastern Canada; permafrost in islands; virtually
ice locked from October to June; ships subject to
superstructure icing from October to May
Environment - current issues: endangered marine
species include walruses and whales; fragile
ecosystem slow to change and slow to recover from
disruptions or damage; thinning polar icepack
Geography - note: major chokepoint is the southern
Chukchi Sea (northern access to the Pacific Ocean
via the Bering Strait); strategic location between North
America and Russia; shortest marine link between the
extremes of eastern and western Russia; floating
research stations operated by the US and Russia;
maximum snow cover in March or April about 20 to 50
centimeters over the frozen ocean; snow cover lasts
about 10 months','9a163d6beebce8ef6ef28ed2e28df61f623e902c9b27876f8a9ad7203006c690','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8589b0c609292fafdfcea200ac565acf08f2c2ce1e64e2c3af0a79ce55bdaa30',2007,'AR','Argentina','geography',106,'Location: Southern South America, bordering the
South Atlantic Ocean, between Chile and Uruguay
Geographic coordinates: 34 00 S, 64 00 W
Map references: South America
Area:
total: 2,766,890 sq km
land: 2,736,690 sq km
water: 30,200 sq km
Area - comparative: slightly less than three-tenths
the size of the US
Land boundaries:
total: 9,665 km
border countries: Bolivia 832 km, Brazil 1 ,224 km,
Chile 5,150 km, Paraguay 1 ,880 km, Uruguay 579 km
Coastline: 4,989 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: mostly temperate; arid in southeast;
subantarctic in southwest
Terrain: rich plains of the Pampas in northern half,
flat to rolling plateau of Patagonia in south, rugged
Andes along western border
Elevation extremes:
lowest point: Laguna del Carbon -105 m (located
between Puerto San Julian and Comandante Luis
Piedra Buena in the province of Santa Cruz)
highest point: Cerro Aconcagua 6,960 m (located in
the northwestern corner of the province of Mendoza)
Natural resources: fertile plains of the pampas,
lead, zinc, tin, copper, iron ore, manganese,
petroleum, uranium
Land use:
arable land: 10.03%
permanent crops: 0.36%
other: 89.61% (2005)
Irrigated land: 15,610 sq km (1998 est.)
Natural hazards: San Miguel de Tucuman and
Mendoza areas in the Andes subject to earthquakes;
pamperos are violent windstorms that can strike the
pampas and northeast; heavy flooding
Environment - current issues: environmental
problems (urban and rural) typical of an industrializing
economy such as deforestation, soil degradation,
desertification, air pollution, and water pollution
note: Argentina is a world leader in setting voluntary
greenhouse gas targets
Environment - international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Wetlands,
Whaling
signed, but not ratified: Marine Life Conservation
Geography - note: second-largest country in South
America (after Brazil); strategic location relative to sea
lanes between the South Atlantic and the South
Pacific Oceans (Strait of Magellan, Beagle Channel,
Drake Passage); Cerro Aconcagua is South
America''s tallest mountain, while Laguna del Carbon
is the lowest point in the Western Hemisphere
Location: Southern South America, bordering the
South Pacific Ocean, between Argentina and Peru
Geographic coordinates: 30 00 S, 71 00 W
Map references: South America
Area:
total: 756,950 sq km
land: 748,800 sq km
wafer:8,150sqkm
note: includes Easter Island (Isla de Pascua) and Isla
Sala y Gomez
Area - comparative: slightly smaller than twice the
size of Montana
Land boundaries:
total: 6,171 km
border countries: Argentina 5, 150 km, Bolivia 861 km.
Peru 160 km
Coastline: 6,435 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200/350 nm
Climate: temptiate; desert in north; Mediterranean
in central region; cool and damp in south
Terrain: low coastal mountains; fertile central valley;
rugged Andes in east
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Nevado Ojos del Salado 6,880 m
Natural resources: copper, timber, iron ore,
nitrates, precious metals, molybdenum, hydropower
Land use:
arable land: 2.62%
permanent crops: 0.43%
other: 96.95% (2005)
Irrigated land: 18,000 sq km (1998 est.)
Natural hazards: severe earthquakes; active
volcanism; tsunamis
Environment - current issues: widespread
deforestation and mining threaten natural resources;
air pollution from industrial and vehicle emissions;
water pollution from raw sewage
Environment - international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Wetlands,
Whaling
signed, but not ratified none of the selected
agreements
Geography - note: strategic location relative to sea
lanes between Atlantic and Pacific Oceans (Strait ot
Magellan, Beagle Channel, Drake Passage), Atacama
Desert is one of world''s driest regions
115
Chile (continued)
/villeta ''Villarrica Jj
1 v^ \\
.{Pilar As$ I
^ _ Encarnacibnjr^pio J
/
Location: Central South America, northeast of
Geographic coordinates: 23 00 S, 58 00 W
Map references: South America
Area:
total: 406,750 sq km
land: 397,300 sq km
water: 9,450 sq km
Area - comparative: slightly smaller than California
Land boundaries:
total: 3,920 km
border countries: Argentina 1 ,880 km, Bolivia 750 km,
Brazil 1 ,290 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: subtropical to temperate; substantial rainfall
in the eastern portions, becoming semiarid in the far
west
Terrain: grassy plains and wooded hills east of Rio
Paraguay; Gran Chaco region west of Rio Paraguay
mostly low, marshy plain near the river, and dry forest
and thorny scrub elsewhere
Elevation extremes:
lowest point: junction of Rio Paraguay and Rio Parana
46 m
highest point: Cerro Pero (Cerro Tres Kandu) 842 m
Natural resources: hydropower, timber, iron ore,
manganese, limestone
Land use:
arable land: 7.47%
permanent crops: 0.24%
other: 92.29% (2005)
Irrigated land: 670 sq km (1998 est.)
Natural hazards: local flooding in southeast (early
September to June); poorly drained plains may
become boggy (early October to June)
Environment - current issues: deforestation; water
pollution; inadequate means for waste disposal pose
health risks for many urban residents; loss of wetlands
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography ■ note: landlocked; lies between
Argentina, Bolivia, and Brazil; population
concentrated in southern part of country
Location: Western South America, bordering the
South Pacific Ocean, between Chile and Ecuador
Geographic coordinates: 10 00 S, 76 00 W
Map references: South America
Area:
total: 1 ,285,220 sq km
land: 1 .28 million sq km
water: 5,220 sq km
Area - comparative: slightly smaller than Alaska
Land boundaries:
total: 5,536 km
border countries: Bolivia 900 km, Brazil 1,560 km,
Chile 160 km, Colombia 1,496 km (est.), Ecuador
1,420 km
438
Peru (continued)
Coastline: 2,414 km
Maritime claims:
territorial sea: 200 nm
continental shelf: 200 nm
Climate: varies from tropical in east to dry desert in
west; temperate to frigid in Andes
Terrain: western coastal plain (costa), high and
rugged Andes in center (sierra), eastern lowland
jungle of Amazon Basin (selva)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Nevado Huascaran 6,768 m
Natural resources: copper, silver, gold, petroleum,
timber, fish, iron ore, coal, phosphate, potash,
hydropower, natural gas
Land use:
arable land: 2.88%
permanent crops: 0.47%
other 96.65% (2005)
Irrigated land: 11,950 sq km (1998 est.)
Natural hazards: earthquakes, tsunamis, flooding,
landslides, mild volcanic activity
Environment - current issues: deforestation (some
the result of illegal logging); overgrazing of the slopes
of the costa and sierra leading to soil erosion;
desertification; air pollution in Lima; pollution of rivers
and coastal waters from municipal and mining wastes
Environment - international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Treaty,
Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species,
Hazardous Wastes, Marine Dumping, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: shares control of Lago Titicaca,
world''s highest navigable lake, with Bolivia; a remote
slope of Nevado Mismi, a 5,31 6 m peak, is the ultimate
source of the Amazon River','11371421586a9d4186b007a048b11db994f588ae1b3daca7ae492c7311df3e8e','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91d5dfdf2eb22f96c9d87c12e48bdd8ab6fcbc2a49b2322b64564d5b236d72f8',2007,'AM','Armenia','geography',113,'Location: Southwestern Asia, east of Turkey
Geographic coordinates: 40 00 N, 45 00 E
Map references: Asia
Area:
total: 29,800 sq km
land: 28,400 sq km
water: 1 ,400 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries:
total: 1,254 km
border countries: Azerbaijan-proper 566 km,
Azerbaijan-Naxcivan exclave 221 km, Georgia 164
km, Iran 35 km, Turkey 268 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: highland continental, hot summers, cold
winters
Terrain: Armenian Highland with mountains; little
forest land; fast flowing rivers; good soil in Aras River
valley
Elevation extremes:
lowest point: Debed River 400 m
highest point: Aragats Lerrnagagat'' 4,090 m
Natural resources: small deposits of gold, copper,
molybdenum, zinc, alumina
Land use:
arable land: 16.78%
permanent crops: 2.01 %
other 81 .21% (2005)
Irrigated land: 2,870 sq km (1998 est.)
Natural hazards: occasionally severe earthquakes;
droughts
Environment - current issues: soil pollution from
toxic chemicals such as DDT; the energy crisis of the
1 990s led to deforestation when citizens scavenged
for firewood; pollution of Hrazdan (Razdan) and Aras
Rivers; the draining of Sevana Lich (Lake Sevan), a
result of its use as a source for hydropower, threatens
drinking water supplies; restart of Metsamor nuclear
power plant in spite of its location in a seismically
active zone
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Hazardous Wastes, Law of the Sea, Ozone Layer
Protection. Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants
Geography - note: landlocked in the Lesser
Caucasus Mountains; Sevana Lich (Lake Sevan) is
the largest lake in this mountain range','e1fce75944149953aaa72e02d9a277fad253db2845182860893c74519471458a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2aa282424627e0977a21a89fe735ca97c6327fb9d8c3e27421432c1f30105ce9',2007,'AW','Aruba','geography',121,'Location: Caribbean, island in the Caribbean Sea.
north of Venezuela
Geographic coordinates: 12 30 N. 69 58 W
Map references: Central America and the
Caribbean
Area:
tofa/: 193 sq km
land: 1 93 sq km
water: 0 sq km
Area - comparative: slightly larger than
Washington, DC
Land boundaries: 0 km
Coastline: 68.5 km
Maritime claims:
territorial sea: 12 nm
Climate: tropical marine; little seasonal temperature
variation
Terrain: flat with a few hills; scant vegetation
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Jamanota 188 m
Natural resources: NEGL; white sandy beaches
Land use:
arable land. 10.53%
permanent crops: 0%
other: 89.47% (2005)
32
Aruba (continued)
Irrigated land: 0.01 sq km (1998 est.)
Natural hazards: lies outside the Caribbean
hurricane belt
Environment - current issues: NA
Geography - note: a flat, riverless island renowned
tor its white sand beaches; its tropical climate is
moderated by constant trade winds from the Atlantic
Ocean; the temperature is almost constant at about 27
degrees Celsius (81 degrees Fahrenheit)','a96f1a0b7b9f8ba7ea3fbae74fb22b3a728a4f853f0ec98e7ad04404494f552c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ca489d265ad1fd5df0aa5fb5ddbad53d6db679c4ddc5a201cee322b6c1f8bd21',2007,'AU','Australia','geography',132,'Location: Southeastern Asia, islands in the Indian
Ocean, midway between northwestern Australia and
Timor island
Geographic coordinates: 12 14 S, 123 05 E
Map references: Southeast Asia
Area:
total: 5 sq km
land: 5 sq km
water: 0 sq km
note: includes Ashmore Reef (West, Middle, and East
Islets) and Cartier Island
Area - comparative: about eight times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 74.1 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 12 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive fishing zone: 200 nm
Climate: tropical
Terrain: low with sand and coral
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 3 m
Natural resources: fish
34
Ashmore and Cartier Islands (continued)
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (all grass and sand) (2005)
Irrigated land: 0 sq km (1998 est.)
Natural hazards: surrounded by shoals and reefs
that can pose maritime hazards
Environment - current issues: NA
Geography - note: Ashmore Reef National Nature
Reserve established in August 1 983
Location: body of water between Africa, Europe, the
Southern Ocean, and the Western Hemisphere
Geographic coordinates: 0 00 N, 25 00 W
Map references: Political Map of the World
Area:
total: 76.762 million sq km
note: includes Baltic Sea, Black Sea, Caribbean Sea,
Davis Strait, Denmark Strait, part of the Drake
Passage, Gulf of Mexico, Labrador Sea,
Mediterranean Sea, North Sea, Norwegian Sea,
almost all of the Scotia Sea, and other tributary water
bodies
Area - comparative: slightly less than 6.5 times the
size of the US
Coastline: 111,866 km
Climate: tropical cyclones (hurricanes) develop off
the coast of Africa near Cape Verde and move
westward into the Caribbean Sea; hurricanes can
occur from May to December, but are most frequent
from August to November
Terrain: surface usually covered with sea ice in
Labrador Sea, Denmark Strait, and coastal portions of
the Baltic Sea from October to June; clockwise
warm-water gyre (broad, circular system of currents)
in the northern Atlantic, counterclockwise warm-water
gyre in the southern Atlantic; the ocean floor is
dominated by the Mid-Atlantic Ridge, a rugged
north-south centerline for the entire Atlantic basin
Elevation extremes:
lowest point: Milwaukee Deep in the Puerto Rico
Trench -8,605 m
highest point: sea level 0 m
Natural resources: oil and gas fields, fish, marine
mammals (seals and whales), sand and gravel
aggregates, placer deposits, polymetallic nodules,
precious stones
Natural hazards: icebergs common in Davis Strait,
Denmark Strait, and the northwestern Atlantic Ocean
from February to August and have been spotted as far
south as Bermuda and the Madeira Islands; ships
subject to superstructure icing in extreme northern
Atlantic from October to May; persistent fog can be a
maritime hazard from May to September; hurricanes
;May to December)
Environment - current issues: endangered marine
species include the manatee, seals, sea lions, turtles,
and whales; drift net fishing is hastening the decline of
fish stocks and contributing to international disputes;
municipal sludge pollution off eastern US, southern
Brazil, and eastern Argentina; oil pollution in
Caribbean Sea, Gulf of Mexico, Lake Maracaibo,
Mediterranean Sea, and North Sea; industrial waste
and municipal sewage pollution in Baltic Sea, North
Sea, and Mediterranean Sea
Geography - note: major chokepoints include the
Dardanelles, Strait of Gibraltar, access to the Panama
and Suez Canals; strategic straits include the Strait of
Dover, Straits of Florida, Mona Passage, The Sound
(Oresund), and Windward Passage; the Equator
divides the Atlantic Ocean into the North Atlantic
Ocean and South Atlantic Ocean
Location: Middle America, atoll in the North Pacific
Ocean, 1,120 km southwest of Mexico
Geographic coordinates: 1 0 1 7 N, 1 09 1 3 W
Map references: Political Map of the World
Area:
total: 6 sq km
land: 6 sq km
water: 0 sq km
Area - comparative: about 1 2 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 11.1 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; humid, average temperature 20-32
degrees 0 wet season (May to October)
Terrain: coral atoll
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Rocher Clipperton 29 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (all coral) (2005)
Irrigated land: Osq km (1998 est.)
Natural hazards: NA
Environment - current issues: NA
Geography - note: reef 12 km in circumference
Location: Oceania, islands in the North Pacific
Ocean, about three-quarters of the way from Hawaii to
the Philippines
Geographic coordinates: 15 12 N, 145 45 E
Map references: Oceania
Area:
total: Ml sq km
land: 477 sq km
water: 0 sq km
note: includes 14 islands including Saipan, Rota, and
Tinian
Area - comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 1,482 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical marine; moderated by northeast trade
winds, little seasonal temperature variation; dry season
December to June, rainy season July to October
Terrain: southern islands are limestone with level
terraces and fringing coral reefs; northern islands are
volcanic
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Agrihan 965 m
Natural resources: arable land, fish
Land use:
arable land: 13.04%
permanent crops: 4.35%
other: 82.61% (2005)
Irrigated land: NA
Natural hazards: active volcanoes on Pagan and
Agrihan; typhoons (especially August to November)
Environment - current issues: contamination of
groundwater on Saipan may contribute to disease;
clean-up of landfill; protection of endangered species
conflicts with development
Geography - note: strategic location in the North
Pacific Ocean
Location: Oceania, group of islands including the
eastern half of the island of New Guinea between the
Coral Sea and the South Pacific Ocean, east of','07dc165f2dc4f15bba7f166da1124a5723aff14846affac7e78ed3b6543fbde4','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0b3c9254b8e7c733f9376e1b4fd44da74394f112bbbf360894bb5720f053b58',2007,'ID','Indonesia','geography',139,'Location: Oceania, continent between the Indian
Ocean and the South Pacific Ocean
Geographic coordinates: 27 00 S, 133 00 E
Map references: Oceania
Area:
total: 7,686.850 sq km
land: 7,617,930 sq km
water: 68,920 sq km
note: includes Lord Howe Island and Macquarie
Island
Area • comparative: slightly smaller than the US
contiguous 48 states
Land boundaries: 0 km
Coastline: 25,760 km
Maritime claims:
territorial sea: 1 2 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: generally arid to semiarid; temperate in
south and east; tropical in north
Terrain: mostly low plateau with deserts; fertile plain
in southeast
Elevation extremes:
lowest point: Lake Eyre -15 m
highest point: Mount Kosciuszko 2.229 m
Natural resources: bauxite, coal, iron ore, copper,
tin, gold, silver, uranium, nickel, tungsten, mineral
sands, lead, zinc, diamonds, natural gas, petroleum
Land use:
arable land: 6.15% (includes about 27 million
hectares of cultivated grassland)
permanent crops: 0.04%
other: 93.81% (2005)
Irrigated land: 24,000 sq km (1998 est.)
Natural hazards: cyclones along the coast; severe
droughts; forest fires
Environment • current issues: soil erosion from
overgrazing, industrial development, urbanization,
and poor farming practices; soil salinity rising due to
the use of poor quality water; desertification; clearing
for agricultural purposes threatens the natural habitat
of many unique animal and plant species; the Great
Barrier Reef off the northeast coast, the largest coral
reef in the world, is threatened by increased shipping
and its popularity as a tourist site; limited natural fresh
water resources
Environment - international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Marine Life Conservation, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: world''s smallest continent but
sixth-largest country; population concentrated along
the eastern and southeastern coasts; the invigorating
tropical sea breeze known as the "Fremantle Doctor"
affects the city of Perth on the west coast, and is one
of the most consistent winds in the world
Location: Southeastern Asia, northwest of Australia
in the Lesser Sunda Islands at the eastern end of the
Indonesian archipelago; note - East Timor includes
the eastern half of the island of Timor, the Oecussi
(Ambeno) region on the northwest portion of the island
of Timor, and the islands of Pulau Atauro and Pulau
Jaco
Geographic coordinates: 8 50 S, 125 55 E
Map references: Southeast Asia
Area:
total. 15,007 sq km
land: NA sq km
water. NA sq km
Area - comparative: slightly larger than Connecticut
Land boundaries:
total: 228 km
border countries: Indonesia 228 km
Coastline: 706 km
Maritime claims:
territorial sea: NA
exclusive economic zone: NA
continental shelf: NA
exclusive fishing zone: NA
Climate: tropical; hot, humid; distinct rainy and dry
seasons
Terrain: mountainous
Elevation extremes:
lowest point: Timor Sea, Savu Sea, and
Banda Sea 0 m
highest point: Foho Tatamailau 2,963 m
Natural resources: gold, petroleum, natural gas,
manganese, marble
Land use:
arable land: 8.2%
permanent crops: 4.57%
other: 87.23% (2005)
Irrigated land: 1 ,065 sq km (est.)
Natural hazards: floods and landslides are
common; earthquakes, tsunamis, tropical cyclones
Environment - current issues: widespread use of
slash and burn agriculture has led to deforestation and
soil erosion
Environment - international agreements: NA
Geography - note: Timor comes from the Malay
word for "East"; the island of Timor is part of the Malay
Archipelago and is the largest and easternmost of the
Lesser Sunda Islands
Location: Southeastern Asia, peninsula bordering
Thailand and northern one-third of the island of
Borneo, bordering Indonesia, Brunei, and the South
China Sea, south of Vietnam
Geographic coordinates: 2 30 N, 1 12 30 E
Map references: Southeast Asia
Area:
total: 329,750 sq km
land: 328,550 sq km
water. 1 ,200 sq km
Area - comparative: slightly larger than New Mexico
Land boundaries:
total: 2,669 km
border countries: Brunei 381 km, Indonesia 1 ,782 km,
Thailand 506 km
Coastline: 4,675 km (Peninsular Malaysia 2,068 km,
East Malaysia 2,607 km)
Maritime claims:
territoi ial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200-m depth or to the depth of
exploitation; specified boundary in the South China
Sea
Climate: tropical; annual southwest (April to October)
and northeast (October to February) monsoons
Terrain: coastal plains rising to hills and mountains
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Gunung Kinabalu 4,100 m
Natural resources: tin, petroleum, timber, copper,
iron ore, natural gas, bauxite
Land use:
arable land: 5.46%
permanent crops: 1 7.54%
other: 77% (2005)
Irrigated land: 3,650 sq km (1998 est.)
Natural hazards: flooding, landslides, forest fires
Environment - current issues: air pollution from
industrial and vehicular emissions; water pollution
from raw sewage; deforestation; smoke/haze from
Indonesian forest fires
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Life Conservation, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
Geography - note: strategic location along Strait of
Malacca and southern South China Sea
Geographic coordinates: 6 55 N, 158 15 E
Map references: Oceania
Area:
total: 702 sq km
land: 702 sq km
water: 0 sq km (fresh water only)
note: includes Pohnpei (Ponape), Chuuk (Truk)
Islands, Yap Islands, and Kosrae (Kosaie)
Area - comparative: four times the size of
Washington, DC (land area only)
Land boundaries: 0 km
Coastline: 6,112 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; heavy year-round rainfall, especially
in the eastern islands; located on southern edge of the
typhoon belt with occasionally severe damage
Terrain: islands vary geologically from high
mountainous islands to low, coral atolls; volcanic
outcroppings on Pohnpei, Kosrae, and Chuuk
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Dolohmwar (Totolom) 791 m
Natural resources: forests, marine products,
deep-seabed minerals, phosphate
Land use:
arable land: 5.71%
permanent crops: 45.71 %
other: 48.58% (2005)
Irrigated land: NA
Natural hazards: typhoons (June to December)
Environment - current issues: overfishing, climate
change, pollution
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: four major island groups totaling
607 islands
Geographic coordinates: 6 00 S, 147 00 E
Map references: Oceania
Area:
total: 462,840 sq km
land: 452,860 sq km
water: 9,980 sq km
Area - comparative: slightly larger than California
Land boundaries:
tofa/: 820 km
border countries: Indonesia 820 km
Coastline: 5,152 km
Maritime claims: measured from claimed
archipelagic baselines
territorial sea: 12 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive fishing zone: 200 nm
Climate: tropical; northwest monsoon (December to
March), southeast monsoon (May to October); slight
seasonal temperature variation
Terrain: mostly mountains with coastal lowlands and
rolling foothills
432
Papua New Guinea (continued)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Wilhelm 4,509 m
Natural resources: gold, copper, silver, natural gas,
timber, oil, fisheries
Land use:
arable land: 0.49%
permanent crops: 1 .4%
other: 98.11% (2005)
Irrigated land: NA sq km
Natural hazards: active volcanism; situated along
the Pacific "Ring of Fire"; the country is subject to
frequent and sometimes severe earthquakes; mud
slides; tsunamis
Environment - current issues: rain forest subject to
deforestation as a result of growing commercial
demand for tropical timber; pollution from mining
projects; severe drought
Environment - international agreements:
party to: Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: none of the selected
agreements
Geography • note: shares island of New Guinea
with Indonesia; one of world''s largest swamps along
southwest coast
Location: Southeastern Asia, group of small islands
and reefs in the South China Sea, about one-third of the
way from central Vietnam to the northern Philippines
Geographic coordinates: 16 30 N, 1 12 00 E
Map references: Southeast Asia
Area:
total: NA sq km
land: NA sq km
water: 0 sq km
Area - comparative: NA
Land boundaries: 0 km
Coastline: 518 km
Maritime claims: NA
Climate: tropical
Terrain: mostly low and flat
Elevation extremes:
lowest point: South China Sea 0 m
highest point: unnamed location on Rocky Island 14
m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: Osq km (1998 est.)
Natural hazards: typhoons
Environment - current issues: NA
Geography - note: composed of 130 small coral
islands and reefs divided into the northeast Amphitrite
Group and the western Crescent Group
435
Location: Southeastern Asia, archipelago between
the Philippine Sea and the South China Sea, east of
Vietnam
Geographic coordinates: 13 00 N, 122 00 E
Map references: Southeast Asia
Area:
total: 300,000 sq km
/and:298,170sqkm
water: 1,830 sq km
Area - comparative: slightly larger than Arizona
Land boundaries: 0 km
Coastline: 36,289 km
Maritime claims:
territorial sea: irregular polygon extending up to 100
nm from coastline as defined by 1 898 treaty; since late
1970s has also claimed polygonal-shaped area in
South China Sea up to 285 nm in breadth
exclusive economic zone: 200 nm
continental shelf: to depth of exploitation
Climate: tropical marine; northeast monsoon
(November to April); southwest monsoon (May to
October)
Terrain: mostly mountains with narrow to extensive
coastal lowlands
Elevation extremes:
lowest point: Philippine Sea 0 m
highest point: Mount Apo 2,954 m
Natural resources: timber, petroleum, nickel,
cobalt, silver, gold, salt, copper
Land use:
arable land: 19%
permanent crops: 1 6.67%
other: 64.33% (2005)
Irrigated land: 15,500 sq km (1998 est.)
Natural hazards: astride typhoon belt, usually
affected by 1 5 and struck by five to six cyclonic storms
per year; landslides; active volcanoes; destructive
earthquakes; tsunamis
Environment • current issues: uncontrolled
deforestation especially in watershed areas; soil
erosion; air and water pollution in major urban centers;
coral reef degradation; increasing pollution of coastal
mangrove swamps that are important fish breeding
grounds
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants
441
Philippines (continued)
Geography - note: the Philippine archipelago is
made up of 7,107 islands; favorably located in relation
to many of Southeast Asia''s main water bodies: the
South China Sea, Philippine Sea, Sulu Sea, Celebes
Sea, and Luzon Strait
Location: Oceania, islands in the South Pacific
Ocean, about midway between Peru and New
Zealand
Geographic coordinates: 25 04 S, 130 06 W
Map references: Oceania
Area:
total: 47 sq km
land: 47 sq km
water: 0 sq km
Area - comparative: about 0.3 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 51 km
Maritime claims:
territorial sea: 3 nm
exclusive economic zone: 200 nm
Climate: tropical; hot and humid; modified by
southeast trade winds; rainy season (November to
March)
Terrain: rugged volcanic formation; rocky coastline
with cliffs
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Pawala Valley Ridge 347 m
Natural resources: miro trees (used for
handicrafts), fish
note: manganese, iron, copper, gold, silver, and zinc
have been discovered offshore
Land use:
arable land: NA%
permanent crops: NA%
other: NA%
Irrigated land: NA
Natural hazards: typhoons (especially November to
March)
Environment - current issues: deforestation (only
a small portion of the original forest remains because
of burning and clearing for settlement)
Geography - note: Britain''s most isolated
dependency; only the larger island of Pitcairn is
inhabited but it has no port or natural harbor; supplies
must be transported by rowed longboat from larger
ships stationed offshore
Environment - international agreements: ■
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous^
Wastes, Law of the Sea, Ozone Layer Protection,
Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: focal point for Southeast Asian
sea routes','fd647938eafe50c0110bd06019da6e43342214c57bc422f2ef3a851e81b42dd3','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61c10ffaab6d4541d0259d4ce5521aa50218d9d9425217bcdb023f9d6da524b8',2007,'AZ','Azerbaijan','geography',159,'Location: Southwestern Asia, bordering the Caspian
Sea, between Iran and Russia, with a small European
portion north of the Caucasus range
Geographic coordinates: 40 30 N, 47 30 E
Map references: Asia
Area:
total: 86,600 sq km
land: 86,100 sq km
water: 500 sq km
note: includes the exclave of Naxcivan Autonomous
Republic and the Nagorno-Karabakh region; the
region''s autonomy was abolished by Azerbaijani
Supreme Soviet on 26 November 1991
Area - comparative: slightly smaller than Maine
Land boundaries:
total: 2,013 km
border countries: Armenia (with Azerbaijan-proper)
566 km, Armenia (with Azerbaijan-Naxcivan exclave)
221 km, Georgia 322 km, Iran (with
Azerbaijan-proper) 432 km, Iran (with
Azerbaijan-Naxcivan exclave) 179 km, Russia 284
km, Turkey 9 km
Coastline: 0 km (landlocked); note • Azerbaijan
borders the Caspian Sea (800 km est.)
41
Azerbaijan (continued)
Maritime claims: none (landlocked)
Climate: dry, semiarid steppe
Terrain: large, flat Kur-Araz Ovaligi (Kura-Araks
Lowland) (much of it below sea level) with Great
Caucasus Mountains to the north, Qarabag Yaylasi
(Karabakh Upland) in west; Baku lies on Abseron
Yasaqligi (Apsheron Peninsula) that juts into Caspian
Sea
Elevation extremes:
lowest point: Caspian Sea -28 m
highest point: Bazarduzu Dagi 4,485 m
Natural resources: petroleum, natural gas, iron ore,
nonferrous metals, alumina
Land use:
arable land: 20.62%
permanent crops: 2.61%
other: 76.77% (2005)
Irrigated land: 14,550 sq km (1998 est.)
Natural hazards: droughts
Environment - current issues: local scientists
consider the Abseron Yasaqligi (Apsheron Peninsula)
(including Baku and Sumqayit) and the Caspian Sea
to be the ecologically most devastated area in the
world because of severe air, soil, and water pollution;
soil pollution results from oil spills, from the use of
DDT as a pesticide, and from toxic defoliants used in
the production of cotton
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes, Marine
Dumping, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: both the main area of the country
and the Naxcivan exclave are landlocked
Location: Caribbean, chain of islands in the North
Atlantic Ocean, southeast of Florida, northeast of','ec3fd10e9752ea663fc66b77f7308874c1e7d9a20c22f2a243439f7c2b5cb3bf','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f7a0269fc22b6556f6b6b16a68653edd29106117301d9a863a44c8d2fde2816',2007,'CU','Cuba','geography',167,'Geographic coordinates: 24 15 N, 76 00 W
Map references: Central America and the
Caribbean
Area:
total: 13,940 sq km
land: 10,070 sq km
water: 3,870 sq km
Area - comparative: slightly smaller than
Connecticut
Land boundaries: 0 km
Coastline: 3,542 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical marine; moderated by warm waters
of Gulf Stream
Terrain: long, flat coral formations with some low
rounded hills
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Alvernia, on Cat Island 63 m
44
Bahamas, The (continued)
Natural resources: salt, aragonite, timber, arable
land
Land use:
arable land: 0.58%
permanent crops: 0.29%
other: 99.13% (2005)
Irrigated land: NA
Natural hazards: hurricanes and other tropical
storms cause extensive flood and wind damage
Environment - current issues: coral reef decay;
solid waste disposal
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location adjacent to US
and Cuba; extensive island chain of which 30 are
inhabited
Location: Middle America, bordering the Caribbean
Sea and the Gulf of Mexico, between Belize and the
US and bordering the North Pacific Ocean, between
Guatemala and the US
Geographic coordinates: 23 00 N, 102 00 W
Map references: North America
Area:
total: 1 ,972,550 sq km
land: 1,923,040 sq km
wafer: 49,510 sq km
Area - comparative: slightly less than three times
the size of Texas
Land boundaries:
total: 4,353 km
border countries: Belize 250 km, Guatemala 962 km,
US 3, 141 km
Coastline: 9,330 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: varies from tropical to desert
Terrain: high, rugged mountains; low coastal plains;
high plateaus; desert
Elevation extremes:
lowest point: Laguna Salada -10 m
highest point: Volcan Pico de Orizaba 5,700 m
Natural resources: petroleum, silver, copper, gold,
lead, zinc, natural gas, timber
Land use:
arable land: 12.66%
permanent crops: 1 .28%
other: 86.06% (2005)
Irrigated land: 65,000 sq km (1998 est.)
Natural hazards: tsunamis aiong the Pacific coast,
volcanoes and destructive earthquakes in the center
and south, and hurricanes on the Pacific, Gulf of
Mexico, and Caribbean coasts
Environment • current issues: scarcity of hazardous
waste disposal facilities; rural to urban migration; natural
fresh water resources scarce and polluted in north,
inaccessible and poor quality in center and extreme
southeast: raw sewage and industrial effluents polluting
rivers in urban areas; deforestation; widespread erosion;
desertification; deteriorating agricultural lands; serious air
and water pollution in the national capital and urban
centers along US-Mexico border; land subsidence in
Valley of Mexico caused by groundwater depletion
note: the government considers the lack of clean
water and deforestation national security issues
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location on southern
border of US; corn (maize), one of the world''s major
grain crops, is thought to have originated in Mexico','a62d6f6e9d777a0374673d13d8601b62a4d2ee3992d33c7416bd7b23478f9d78','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b1fbe8675447967b23e4fddac0cce53618e2d6ed6fbd994d86000ed849f2bcc',2007,'US','United States','geography',187,'Location: Southern Asia, bordering the Bay of
Bengal, between Burma and India
Geographic coordinates: 24 00 N, 90 00 E
Map references: Asia
Area:
total: 144,000 sq km
land: 133,910 sq km
water: 10,090 sq km
Area - comparative: slightly smaller than Iowa
Land boundaries:
total: 4,246 km
border countries: Burma 193 km, India 4,053 km
Coastline: 580 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 1 8 nm
exclusive economic zone: 200 nm
continental shelf: up to the outer limits of the
continental margin
Climate: tropical; mild winter (October to March); hot,
humid summer (March to June); humid, warm rainy
monsoon (June to October)
Terrain: mostly flat alluvial plain; hilly in southeast
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Keokradong 1,230 m
Natural resources: natural gas, arable land, timber,
coal
Land use:
arable land: 55.39%
permanent crops: 3.08%
of/?er: 41 .53% (2005)
Irrigated land: 38,440 sq km (1998 est.)
Natural hazards: droughts, cyclones; much of the
country routinely inundated during the summer
monsoon season
Environment - current issues: many people are
landless and forced to live on and cultivate
flood-prone land; water-borne diseases prevalent in
surface water; water pollution, especially of fishing
areas, results from the use of commercial pesticides;
ground water contaminated by naturally occurring
arsenic; intermittent water shortages because of
falling water tables in the northern and central parts of
the country; soil degradation and erosion;
deforestation; severe overpopulation
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: most of the country is situated on
deltas of large rivers flowing from the Himalayas: the
Ganges unites with the Jamuna (main channel of the
Brahmaputra) and later joins the Meghna to eventually
empty into the Bay of Bengal
Location: Western Europe, island in the English
Channel, northwest of France
Geographic coordinates: 49 15 N, 2 10 W
Map references: Europe
Area:
total: 116 sq km
land: 116 sq km
water: 0 sq km
Area • comparative: about two-thirds the size of
Washington, DC
Land boundaries: 0 km
Coastline: 70 km
Maritime claims:
territorial sea: 3 nm
exclusive fishing zone: 1 2 nm
Climate: temperate; mild winters and cool summers
Terrain: gently rolling plain with low, rugged hills
along north coast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location 143 m
Natural resources: arable land
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: NA
Natural hazards: NA
Environment - current issues: NA
Geography - note: largest and southernmost of
Channel Islands; about 30% of population
concentrated in Saint Helier
Location: Middle East, northwest of Saudi Arabia
Geographic coordinates: 31 00 N, 36 00 E
Map references: Middle East
Area:
total: 92,300 sq km
land: 91 ,971 sq km
water. 329 sq km
Area • comparative: slightly smaller than Indiana
Land boundaries:
total: 1,635 km
border countries: Iraq 181 km, Israel 238 km, Saudi
Arabia 744 km, Syria 375 km, West Bank 97 km
Coastline: 26 km
Maritime claims:
territorial sea: 3 nm
Climate: mostly arid desert; rainy season in west
(November to April)
Terrain: mostly desert plateau in east, highland area
in west; Great Rift Valley separates East and West
Banks of the Jordan River
Elevation extremes:
lowest point: Dead Sea -408 m
highest point: Jabal Ram 1 ,734 m
Natural resources: phosphates, potash, shale oil
Land use:
arable land: 3.32%
permanent crops: 1 .18%
other: 95.5% (2005)
Irrigated land: 750 sq km (1998 est.)
Natural hazards: droughts; periodic earthquakes
Environment - current issues: limited natural fresh
water resources; deforestation; overgrazing; soil
erosion; desertification
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography • note: strategic location at the head of
the Gulf of Aqaba and as the Arab country that shares
the longest border with Israel and the occupied West
Bank
Location: North America, bordering both the North
Atlantic Ocean and the North Pacific Ocean, between
Canada and Mexico
Geographic coordinates: 38 00 N, 97 00 W
Map references: North America
Area:
total: 9,631,418 sq km
land: 9,161,923 sq km
water: 469,495 sq km
note: includes only the 50 states and District of
Columbia
Area ■ comparative: about half the size of Russia;
about three-tenths the size of Africa; about half the
size of South America (or slightly larger than Brazil);
slightly larger than China; almost two and a half times
the size of the European Union
Land boundaries:
total: 12,034 km
border countries: Canada 8,893 km (including 2,477
km with Alaska), Mexico 3,141 km
note: US Naval Base at Guantanamo Bay, Cuba is
leased by the US and is part of Cuba; the base
boundary is 29 km
Coastline: 19,924 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: not specified
Climate: mostly temperate, but tropical in Hawaii and
Florida, arctic in Alaska, semiarid in the great plains
west of the Mississippi River, and arid in the Great
Basin of the southwest; low winter temperatures in the
northwest are ameliorated occasionally in January
and February by warm Chinook winds from the eastern
slopes of the Rocky Mountains
Terrain: vast central plain, mountains in west, hills
and low mountains in east; rugged mountains and
broad river valleys in Alaska; rugged, volcanic
topography in Hawaii
Elevation extremes:
lowest point: Death Valley -86 m
highest point: Mount McKinley 6,194 m
Natural resources: coal, copper, lead,
molybdenum, phosphates, uranium, bauxite, gold,
iron, mercury, nickel, potash, silver, tungsten, zinc,
petroleum, natural gas, timber
Land use:
arable land: 18.01%
permanent crops: 0.21 %
other: 81 .78% (2005)
Irrigated land: 214,000 sq km (1998 est.)
Natural hazards: tsunamis, volcanoes, and
earthquake activity around Pacific Basin; hurricanes
along the Atlantic and Gulf of Mexico coasts;
tornadoes in the midwest and southeast; mud slides in
California; forest fires in the west; flooding; permafrost
in northern Alaska, a major impediment to
development
Environment - current issues: air pollution
resulting in acid rain in both the US and Canada; the
US is the largest single emitter of carbon dioxide from
the burning of fossil fuels; water pollution from runoff
of pesticides and fertilizers; limited natural fresh water
resources in much of the western part of the country
require careful management; desertification
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals, Antarctic Treaty,
Climate Change, Desertification, Endangered
Species, Environmental Modification, Marine
Dumping, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Air Pollution-Volatile Organic
Compounds, Biodiversity, Climate Change-Kyoto
Protocol, Hazardous Wastes
Geography - note: world''s third-largest country by
size (after Russia and Canada) and by population
(after China and India); Mt. McKinley is highest point
in North America and Death Valley the lowest point on
the continent','7bd204baafbced615d2c1b5253ce1863896f1017ab520f0044f8e5e373dec016','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6e6b1073c7d62c9ba7df45d9d0d8c988dc6ba8aa4bf4618426f309f8b6e35c0',2007,'BD','Bangladesh','geography',196,'Location: Caribbean, island in the North Atlantic
Ocean, northeast of Venezuela
Geographic coordinates: 13 10 N, 59 32 W
Map references: Central America and the
Caribbean
Area:
total: 431 sq km
land: 431 sq km
water: 0 sq km
Area - comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 97 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; rainy season (June to October)
Terrain: relatively flat; rises gently to central highland
region
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Hillaby 336 m
Natural resources: petroleum, fish, natural gas
Land use:
arable land: 37.21%
permanent crops: 2.33%
other: 60.46% (2005)
Irrigated land: 10 sq km (1998 est.)
Natural hazards: infrequent hurricanes; periodic
landslides
Environment ■ current issues: pollution of coastal
waters from waste disposal by ships; soil erosion;
illegal solid waste disposal threatens contamination of
aquifers
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: easternmost Caribbean island
Location: Southern Africa, islands in the southern
Mozambique Channel, about one-half of the way from
Madagascar to Mozambique
Geographic coordinates: 21 30 S. 39 50 E
Map references: Africa
Area:
total: 0.2 sq km
land: 0.2 sq km
water: 0 sq km
Area • comparative: about one-third the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 35.2 km
Maritime claims:
territorial sea: 1 2 nm
exclusive economic zone: 200 nm
Climate: tropical
Terrain: volcanic rock
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point, unnamed location 2.4 m
Natural resources: none
Land use:
arable land: 0°o
permanent crops: 0°o
of/ier: 100°o (all rock) (2005)
Irrigated land: Osq km (1998 est.)
Natural hazards: maritime hazard since it is usually
under water during high tide and surrounded by reefs;
subject to periodic cyclones
Environment • current issues: NA
Geography - note: the islands emerge from a
circular reef that sits atop a long-extinct, submerged
volcano
Location: Southern Asia, between China and India
Geographic coordinates: 27 30 N, 90 30 E
Map references: Asia
Area:
total: 47,000 sq km
land: 47,000 sq km
water: 0 sq km
Area - comparative: about half the size of Indiana
Land boundaries:
total: 1,075 km
border countries: China 470 km, India 605 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: varies; tropical in southern plains; cool
winters and hot summers in central valleys; severe
winters and cool summers in Himalayas
Terrain: mostly mountainous with some fertile
valleys and savanna
Elevation extremes:
lowest point: Drangme Chhu 97 m
highest point: Kula Kangri 7,553 m
Natural resources: timber, hydropower, gypsum,
calcium carbonate
Land use:
arable land: 2.3%
permanent crops: 0.43%
other: 97.27% (2005)
Irrigated land: 400 sq km (1998 est.)
Natural hazards: violent storms from the Himalayas
are the source of the country''s name, which translates
as Land of the Thunder Dragon; frequent landslides
during the rainy season
Environment - current issues: soil erosion; limited
access to potable water
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Endangered Species,
Hazardous Wastes
signed, but not ratified: Law of the Sea
Geography - note: landlocked; strategic location
between China and India; controls several key
Himalayan mountain passes
Population: 2,279,723
note: other estimates range as low as 810,000
(July 2006 est.)
Age structure:
0-14 years: 38.9% (male 458,801/female 426,947)
15-64 years: 57.1% (male 671 ,057/female 631 ,078)
65 years and over: 4% (male 46,21 7/female 45,623)
(2006 est.)
Median age:
total: 20.4 years
male: 20.2 years
female: 20.6 years (2006 est.)
Population growth rate: 2.1% (2006 est )
Birth rate: 33.65 births/1 ,000 population (2006 est )
Death rate: 1 2. 7 deaths/1, 000 population (2006 est )
Net migration rate: 0 migrant(s)/1,000 population
(2006 est.)
Sex ratio:
at birth: 1 .05 male(s)/female
under 15 years: 1.07 male(s)/female
15-64 years: 1 06 male(s)/female
65 years and over: 1 .01 male(s)/female
total population: 1.07 male(s)/female (2006 est |
Infant mortality rate:
total: 98.41 deaths/1 ,000 live births
male: 96.14 deaths/1 ,000 live births
female: 100.79 deaths/1,000 live births (2006 est.)
Life expectancy at birth:
total population: 54.78 years
male: 55.02 years
female: 54.53 years (2006 est.)
67
Bhutan (continued)
Total fertility rate: 4.74 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: less than 0.1%
(2001 est.)
HIV/AIDS - people living with HIV/AIDS: less than
100 (1999 est.)
HIV/AIDS - deaths: NA
Nationality:
noun: Bhutanese (singular and plural)
adjective: Bhutanese
Ethnic groups: Bhote 50%, ethnic Nepalese 35%
(includes Lhotsampas - one of several Nepalese
ethnic groups), indigenous or migrant tribes 15%
Religions: Lamaistic Buddhist 75%, Indian- and
Nepalese-influenced Hinduism 25%
Languages: Dzongkha (official), Bhotes speak
various Tibetan dialects, Nepalese speak various
Nepalese dialects
Literacy:
definition: age 1 5 and over can read and write
total population: 47%
male: 60%
female: 34% (2003 est.)
Location: Central South America, southwest of','00f3b3457ccbb64b19808dd84ba6688f9c7efdc9a527408a539e3f9c1ac51eef','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64fffe408ee26cd94a21e379b5fd9e4638ecb16e3818f6adcc5c8a82dc1e4de0',2007,'BY','Belarus','geography',200,'Location: Eastern Europe, east of Poland
Geographic coordinates: 53 00 N, 28 00 E
Map references: Europe
Area:
total: 207,600 sq km
land: 207,600 sq km
water: 0 sq km
Area - comparative: slightly smaller than Kansas
Land boundaries:
total: 2,900 km
border countries: Latvia 141 km, Lithuania 502 km,
Poland 407 km, Russia 959 km, Ukraine 891 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: cold winters, cool and moist summers;
transitional between continental and maritime
Terrain: generally flat and contains much marshland
Elevation extremes:
lowest point: Nyoman River 90 m
highest point: Dzyarzhynskaya Hara 346 m
Natural resources: forests, peat deposits, small
quantities of oil and natural gas, granite, dolomitic
limestone, marl, chalk, sand, gravel, clay
Land use:
arable land: 26.77%
permanent crops: 0.6%
other: 72.63% (2005)
Irrigated land: 1,150 sq km (1998 est.)
Natural hazards: NA
Environment - current issues: soil pollution from
pesticide use; southern part of the country
contaminated with fallout from 1 986 nuclear reactor
accident at Chornobyl'' in northern Ukraine
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulfur 85, Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Law of the Sea
Geography - note: landlocked; glacial scouring
accounts for the flatness of Belarusian terrain and for
its 1 1 ,000 lakes','ed58febb1e4b1967255d8bf389a37e0b74384adf8de46f5a14383ff1bd076942','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2c17f70c41fad7534f5356affb1403ea2a440a914b70b8225f7c9463f6f5888',2007,'BE','Belgium','geography',208,'Location: Western Europe, bordering the North Sea,
between France and the Netherlands
Geographic coordinates: 50 50 N, 4 00 E
Map references: Europe
Area:
total: 30,528 sq km
land: 30,278 sq km
water: 250 sq km
Area - comparative: about the size of Maryland
Land boundaries:
total: 1,385 km
border countries: France 620 km, Germany 167 km,
Luxembourg 148 km, Netherlands 450 km
Coastline: 66.5 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: geographic coordinates
define outer limit
continental shelf: median line with neighbors
Climate: temperate; mild winters, cool summers,
rainy, humid, cloudy
Terrain: flat coastal plains in northwest, central
rolling hills, rugged mountains of Ardennes Forest in
southeast
Elevation extremes:
lowest point: North Sea 0 m
highest point: Signal de Botrange 694 m
57
Belgium (continued)
Natural resources: construction materials, silica
sand, carbonates
Land use:
arable land: 27.42%
permanent crops: 0.69%
other: 71.89%
note: includes Luxembourg (2005)
Irrigated land: 40 sq km (includes Luxembourg)
(1998 est.)
Natural hazards: flooding is a threat along rivers and
in areas of reclaimed coastal land, protected from the
sea by concrete dikes
Environment - current issues: the environment is
exposed to intense pressures from human activities:
urbanization, dense transportation network, industry,
extensive animal breeding and crop cultivation; air
and water pollution also have repercussions for
neighboring countries; uncertainties regarding federal
and regional responsibilities (now resolved) have
slowed progress in tackling environmental challenges
Environment • international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulfur 85, Air Pollution-Sulfur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals, Antarctic Treaty,
Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Marine Dumping, Marine Life
Conservation, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants
Geography - note: crossroads of Western Europe;
majority of West European capitals within 1 ,000 km of
Brussels, the seat of both the European Union and
NATO','7438d09807ba7e564819eba9933ef327fbe7fdc8e4c60f3e06e2d025986a059f','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('183f7638e9b474ea03b1af40c7c0674030abe70fc7ab1e8909fa68bbd83cc71e',2007,'GT','Guatemala','geography',218,'Location: Central America, bordering the Caribbean
Sea, between Guatemala and Mexico
Geographic coordinates: 17 15 N, 88 45 W
Map references: Central America and the
Caribbean
Area:
total: 22,966 sq km
land: 22,806 sq km
wafer 160 sq km
Area - comparative: slightly smaller than
Massachusetts
Land boundaries:
total: 516 km
border countries: Guatemala 266 km, Mexico 250 km
Coastline: 386 km
Maritime claims:
territorial sea: 12 nm in the north, 3 nm in the south;
note - from the mouth of the Sarstoon River to
Ranguana Cay, Belize''s territorial sea is 3 nm;
according to Belize''s Maritime Areas Act, 1992, the
purpose of this limitation is to provide a framework for
negotiating a definitive agreement on territorial
differences with Guatemala
exclusive economic zone: 200 nm
Climate: tropical; very hot and humid; rainy season
(May to November); dry season (February to May)
Terrain: flat, swampy coastal plain; low mountains in
south
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Victoria Peak 1 ,160 m
Natural resources: arable land potential, timber,
fish, hydropower
Land use:
arable land: 3.05%
permanent crops: 1 .39%
other: 95.56% (2005)
Irrigated land: 30 sq km (1998 est.)
Natural hazards: frequent, devastating hurricanes
(June to November) and coastal flooding (especially in
south)
Environment - current issues: deforestation; water
pollution from sewage, industrial effluents, agricultural
runoff; solid and sewage waste disposal
Environment - international agreements:
parry to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: only country in Central America
without a coastline on the North Pacific Ocean
Location: Central America, bordering the North
Pacific Ocean, between El Salvador and Mexico, and
bordering the Gulf of Honduras (Caribbean Sea)
between Honduras and Belize
Geographic coordinates: 15 30 N, 90 15 W
Map references: Central America and the
Caribbean
Area:
total: 108,890 sq km
land: 108,430 sq km
water. 460 sq km
Area • comparative: slightly smaller than
Tennessee
Land boundaries:
total: 1,687 km
border countries: Belize 266 km, El Salvador 203 km,
Honduras 256 km, Mexico 962 km
Coastline: 400 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200-m depth or to the depth of
exploitation
Climate: tropical; hot, humid in lowlands; cooler in
highlands
Terrain: mostly mountains with narrow coastal plains
and rolling limestone plateau
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Volcan Tajumulco 4,21 1 m
Natural resources: petroleum, nickel, rare woods,
fish, chicle, hydropower
Land use:
arable land: 13.22%
permanent crops: 5.6%
other: 81. 18% (2005)
Irrigated land: 1 ,250 sq km (1998 est.)
Natural hazards: numerous volcanoes in
mountains, with occasional violent earthquakes;
Caribbean coast extremely susceptible to hurricanes
and other tropical storms
Environment - current issues: deforestation in the
Peten rainforest; soil erosion; water pollution
Environment - international agreements:
party to: Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography • note: no natural harbors on west coast','767a93c285ebf872fa08d7d3825e02ebc9175376dd66d29096b93318d2ccb48a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4f277998d0b3f5b3884b5f6d4a9ecaa4e8bfee43ccc6f4dde4fdeb108b9664f',2007,'BM','Bermuda','geography',227,'Location: North America, group of islands in the
North Atlantic Ocean, east of South Carolina (US)
Geographic coordinates: 32 20 N, 64 45 W
Map references: North America
Area:
total: 53.3 sq km
land: 53.3 sq km
water: 0 sq km
Area - comparative: about one-third the size of
Washington, DC
Land boundaries: 0 km
Coastline: 103 km
Maritime claims:
territorial sea: 12 nm
exclusive fishing zone: 200 nm
Climate: subtropical; mild, humid; gales, strong
winds common in winter
Terrain: low hills separated by fertile depressions
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Town Hill 76 m
Natural resources: limestone, pleasant climate
fostering tourism
Land use:
arable land: 20%
permanent crops: 0%
other: 80% (55% developed, 45% rural/open space)
(2005)
Irrigated land: NA
Natural hazards: hurricanes (June to November)
Environment - current issues: sustainable
development
Geography - note: consists of about 138 coral
islands and islets with ample rainfall, but no rivers or
freshwater lakes; some land was leased by US
Government from 1941 to 1995','4c3ae1a1d90e3e928e263afbad74e52c2001890e5e183bc7a4290ecb0da3030c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ec468d9804d27dfff8153f46ee69c61a4f9b68b8e24abdaccddd159d593f62bb',2007,'BR','Brazil','geography',235,'Geographic coordinates: 1 7 00 S, 65 00 W
Map references: South America
Area:
total: 1,098,580 sq km
land: 1 ,084,390 sq km
water: 14,190 sq km
Area - comparative: slightly less than three times
the size of Montana
Land boundaries:
total: 6,743 km
border countries: Argentina 832 km, Brazil 3,400 km.
Chile 861 km, Paraguay 750 km, Peru 900 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: varies with altitude; humid and tropical to
cold and semiarid
Terrain: rugged Andes Mountains with a highland
plateau (Altiplano), hills, lowland plains of the Amazon
Basin
69
Bolivia (continued)
Elevation extremes:
lowest point: Rio Paraguay 90 m
highest point: Nevado Sajama 6,542 m
Natural resources: tin, natural gas, petroleum, zinc,
tungsten, antimony, silver, iron, lead, gold, timber,
hydropower
Land use:
arable land: 2.78%
permanent crops: 0.1 9%
other: 97.03% (2005)
Irrigated land: 1 ,280 sq km (1998 est.)
Natural hazards: flooding in the northeast
(March-April)
Environment - current issues: the clearing of land
for agricultural purposes and the international demand
for tropical timber are contributing to deforestation;
soil erosion from overgrazing and poor cultivation
methods (including slash-and-bum agriculture);
desertification; loss of biodiversity; industrial pollution
of water supplies used for drinking and irrigation
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Environmental Modification,
Marine Life Conservation, Ozone Layer Protection
Geography - note: landlocked; shares control of
Lago Titicaca, world''s highest navigable lake
(elevation 3,805 m), with Peru','4d1f5b78324dfdff09e4cf63896dcb96dac06ed3ddaa9fa8bf012fd48bc5cd20','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('775ffcdb5be3a45057af5ebd4585b2c79d410ef597a3e2b3df5f6acbd0e66eac',2007,'PY','Paraguay','geography',244,'Location: Southeastern Europe, bordering the
Adriatic Sea and Croatia
Geographic coordinates: 44 00 N, 18 00 E
Map references: Europe
Area:
total: 51,129 sq km
land: 51,129 sq km
water: 0 sq km
Area - comparative: slightly smaller than West
Virginia
Land boundaries:
total: 1,459 km
border countries: Croatia 932 km, Serbia and
Montenegro 527 km
Coastline: 20 km
Maritime claims: no data available
Climate: hot summers and cold winters; areas of
high elevation have short, cool summers and long,
severe winters; mild, rainy winters along coast
Terrain: mountains and valleys
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Maglic 2,386 m
Natural resources: coal, iron ore, bauxite, copper,
lead, zinc, chromite, cobalt, manganese, nickel, clay,
gypsum, salt, sand, forests, hydropower
Land use:
arable land: 19.61%
permanent crops: 1 .89%
other: 78.5% (2005)
Irrigated land: 20 sq km (1998 est.)
Natural hazards: destructive earthquakes
Environment - current issues: air pollution from
metallurgical plants; sites for disposing of urban waste
are limited; water shortages and destruction of
infrastructure because of the 1992-95 civil strife;
deforestation
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Hazardous Wastes, Law of the Sea, Marine Life
Conservation. Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: within Bosnia and Herzegovina''s
recognized borders, the country is divided into a joint
Bosniak/Croat Federation (about 51% of the territory)
and the Bosnian Serb-led Republika Srpska or RS
(about 49% of the territory); the region called
Herzegovina is contiguous to Croatia and Serbia and
Montenegro (Montenegro), and traditionally has been
settled by an ethnic Croat majority in the west and an
ethnic Serb majority in the east
BOLIVI/\\__^^ /
1 Capitan Pablo^V
J '' Lagerenza r^
0 100 200 km
0 100 200 mi
Fuerte} BRAZIL
OlimpoJ
/ Doctor
~V/ Pedro P. Pena
o ^-*-— ^V_
\\ 0
0 Pedro Juan \\
Caballero (
Concepcion" I ff
. San Pedro- SallodelT
^^^ Guaira • "£
6
^/Xv^asunci6n "j*
T Ciudad del Es\\ejT\\','83f7cca0be30c6a2addbe6a23480231ec0501c3df48aeae5b03cd1319f5b5671','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('09da6aa2dea7212aac3ee45306455d90ac4762ceacf80883d24ebfe82315fbb3',2007,'BW','Botswana','geography',251,'Location: Southern Africa, north of South Africa
Geographic coordinates: 22 00 S, 24 00 E
Map references: Africa
Area:
total: 600,370 sq km
land: 585,370 sq km
water: 15,000 sq km
Area - comparative: slightly smaller than Texas
Land boundaries:
total: 4.013 km
border countries: Namibia 1 ,360 km. South Africa
1,840 km, Zimbabwe 813 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: semiarid; warm winters and hot summers
Terrain: predominantly flat to gently rolling tabJeland;
Kalahari Desert in southwest
Elevation extremes.
lowest point: junction of the Limpopo and Shashe
Rivers 513 m
highest point: Tsodilo Hills 1 ,489 m
Natural resources: diamonds, copper, nickel, salt,
soda ash, potash, coal, iron ore, silver
75
Botswana (continued)
Land use:
arable land: 0.65°o
permanent crops: 0.01%
other: 99.34% (2005)
Irrigated land: 10 sq km (1998 est.)
Natural hazards: periodic droughts: seasonal
August winds blow from the west, carrying sand and
dust across the country, which can obscure visibility
Environment - current issues: overgrazing;
desertification; limited fresh water resources
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography • note: landlocked; population
concentrated in eastern part of the country','b9e5a20896c9f9423960504f51e7aa118f7ac2c695c8cf412967629d3e1806d1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('594d3c74ba78f37957ab4c105ef1bd9b851810003a18661f42b6ed00647a2a38',2007,'BV','Bouvet Island','geography',260,'Location: island in the South Atlantic Ocean,
southwest of the Cape of Good Hope (South Africa)
Geographic coordinates: 54 26 S, 3 24 E
Map references: Antarctic Region
Area:
total: 58.5 sq km
land: 58.5 sq km
water: 0 sq km
Area - comparative: about 0.3 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 29.6 km
Maritime claims:
territorial sea: 4 nm
Climate: antarctic
Terrain: volcanic; coast is mostly inaccessible
Elevation extremes:
lowest point: South Atlantic Ocean 0 m
highest point: Olav Peak 935 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (93% ice) (2005)
Irrigated land: Osq km (1998 est.)
Natural hazards: NA
Environment - current issues: NA
Geography - note: covered by glacial ice; declared
a nature reserve','7c06b193800034491ec1c73ec33dff5e5029bf73f8a769279842b694fc0e13e6','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('839118b657dbc2743cbc58e9ddec156f2ade52ac48fee3916de63a00bc61c6af',2007,'NO','Norway','geography',265,'Location: Eastern South America, bordering the
Atlantic Ocean
Geographic coordinates: 1 0 00 S, 55 00 W
Map references: South America
Area:
total: 8,511 ,965 sq km
land: 8,456,510 sq km
water: 55,455 sq km
note: includes Arquipelago de Fernando de Noronha,
Atol das Rocas, llha da Trindade, llhas Martin Vaz,
and Penedos de Sao Pedro e Sao Paulo
Area - comparative: slightly smaller than the US
Land boundaries:
rora/. 14,691 km
border countries: Argentina 1,224 km, Bolivia 3,400
km, Colombia 1,643 km, French Guiana 673 km,
Guyana 1,119 km, Paraguay 1,290 km, Peru 1,560
km, Suriname 597 km, Uruguay 985 km, Venezuela
2,200 km
Coastline: 7,491 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
78
Brazil (continued)
exclusive economic zone: 200 nm
continental shelf: 200 nm or to edge of the continental
margin
Climate: mostly tropical, but temperate in south
Terrain: mostly flat to rolling lowlands in north; some
plains, hills, mountains, and narrow coastal belt
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pico da Neblina 3,014 m
Natural resources: bauxite, gold, iron ore,
manganese, nickel, phosphates, platinum, tin,
uranium, petroleum, hydropower, timber
Land use:
arable land: 6.93%
permanent crops: 0.89%
other: 92. 18% (2005)
Irrigated land: 26,560 sq km (1998 est.)
Natural hazards: recurring droughts in northeast;
floods and occasional frost in south
Environment • current issues: deforestation in
Amazon Basin destroys the habitat and endangers a
multitude of plant and animal species indigenous to
the area; there is a lucrative illegal wildlife trade; air
and water pollution in Rio de Janeiro, Sao Paulo, and
several other large cities; land degradation and water
pollution caused by improper mining activities;
wetland degradation; severe oil spills
Environment - international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate Change,
Climate Channe-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: largest country in South
America; shares common boundaries with every
South American country except Chile and Ecuador
Location: archipelago in the Indian Ocean, south of
India, about one-half the way from Africa to Indonesia
Geographic coordinates: 6 00 S, 71 30 E; note -
Diego Garcia 7 20 S, 72 25 E
Map references: Political Map of the World
Area:
total: 54,400 sq km
land: 60 sq km; Diego Garcia 44 sq km
water: 54,340 sq km
note: includes the entire Chagos Archipelago of 55
islands
Area - comparative: land area is about 0.3 times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 698 km
Maritime claims:
territorial sea: 3 nm
exclusive fishing zone: 200 nm
81
British Indian Ocean Territory (continued)
Climate: tropical marine; hot, humid, moderated by
trade winds
Terrain: flat and low (most areas do not exceed two
meters in elevation)
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location on Diego Garcia 15
m
Natural resources: coconuts, fish, sugarcane
Land use:
arable land: 0%
permanent crops: 0%
other. 100% (2005)
Irrigated land: Osq km (1998 est.)
Natural hazards: NA
Environment - current issues: NA
Geography - note: archipelago of 55 islands; Diego
Garcia, largest and southernmost island, occupies
strategic location in central Indian Ocean; island is site
of joint US-UK military facility
Location: Caribbean, between the Caribbean Sea
and the North Atlantic Ocean, east of Puerto Rico
Geographic coordinates: 18 30 N, 64 30 W
Map references: Central America and the
Caribbean
Area:
fofa/:153sq km
land: 1 53 sq km
water: 0 sq km
note: comprised of 16 inhabited and more than 20
uninhabited islands; includes the island of Anegada
Area - comparative: about 0.9 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 80 km
Maritime claims:
territorial sea: 3 nm
exclusive fishing zone: 200 nm
Climate: subtropical; humid; temperatures
moderated by trade winds
Terrain: coral islands relatively flat; volcanic islands
steep, hilly
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Sage 521 m
Natural resources: NEGL
Land use:
arable land: 20%
permanent crops: 6.67°o
other: 73.33% (2005)
82
British Virgin Islands (continued)
Irrigated land: NA
Natural hazards: hurricanes and tropical storms
(July to October)
Environment - current issues: limited natural fresh
water resources (except for a few seasonal streams
and springs on Tortola, most of the islands'' water
supply comes from wells and rainwater catchments)
Geography - note: strong ties to nearby US Virgin
Islands and Puerto Rico
Location: Northern Europe, bordering the North Sea
and the North Atlantic Ocean, west of Sweden
Geographic coordinates: 62 00 N, 10 00 E
Map references: Europe
Area:
total: 324,220 sq km
land: 307,860 sq km
water. 16,360 sq km
Area • comparative: slightly larger than New Mexico
Land boundaries:
total: 2,542 km
border countries: Finland 727 km, Sweden 1 ,619 km,
Russia 196 km
Coastline: 25,148 km (includes mainland 2,650 km,
as well as long fjords, numerous small islands, and
minor indentations 22,498 km; length of island
coastlines 58,133 km)
Maritime claims:
territorial sea: 1 2 nm
contiguous zone: 10 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm
Climate: temperate along coast, modified by North
Atlantic Current; colder interior with increased
precipitation and colder summers; rainy year-round on
west coast
Terrain: glaciated; mostly high plateaus and rugged
mountains broken by fertile valleys; small, scattered
plains; coastline deeply indented by fjords; arctic
tundra in north
Elevation extremes:
lowest point: Norwegian Sea 0 m
highest point: Galdhopiggen 2,469 m
Natural resources: petroleum, natural gas, iron ore,
copper, lead, zinc, titanium, pyrites, nickel, fish,
timber, hydropower
Land use:
arable land: 2.7%
permanent crops: 0%
other: 97.3% (2005)
Irrigated land: 1,270 sq km (1998 est.)
Natural hazards: rockslides, avalanches
Environment - current issues: water pollution;
acid rain damaging forests and adversely affecting
lakes, threatening fish stocks; air pollution from
vehicle emissions
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulfur 85, Air Pollution-Sulfur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals, Antarctic Treaty,
Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Marine Dumping, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber
94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: about two-thirds mountains;
some 50,000 islands off its much indented coastline;
strategic location adjacent to sea lanes and air routes
in North Atlantic; one of most rugged and longest
coastlines in the world','636ebefd54957135d75777b76a06e32b8afbb52120a3362509d69e4fcefc81ab','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68256164153fdf52c27a54785edb017b1140813dc97fc2b859406f5203418352',2007,'MY','Malaysia','geography',273,'Location: Southeastern Asia, bordering the South
China Sea and Malaysia
Geographic coordinates: 4 30 N. 1 14 40 E
Map references: Southeast Asia
Area:
total: 5,770 sq km
land: 5.270 sq km
water: 500 sq km
Area • comparative: slightly smaller than Delaware
Land boundaries:
total: 381 km
border countries: Malaysia 381 km
Coastline: 161 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm or to median line
Climate: tropical; hot, humid, rainy
Terrain: flat coastal plain rises to mountains in east;
hilly lowland in west
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Bukit Pagon 1 ,850 m
Natural resources: petroleum, natural gas, timber
Land use:
arable land: 2.08%
permanent crops: 0.87%
other: 97.05% (2005)
Irrigated land: 10 sq km (1998 est.)
Natural hazards: typhoons, earthquakes, and
severe flooding are rare
Environment - current issues: seasonal smoke/
haze resulting from forest fires in Indonesia
Environment - international agreements:
party to: Endangered Species, Hazardous Wastes,
Law of the Sea, Ozone Layer Protection, Ship
Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: close to vital sea lanes through
South China Sea linking Indian and Pacific Oceans;
two parts physically separated by Malaysia; almost an
enclave within Malaysia
Location: Southeastern Asia, bordering the
Andaman Sea and the Gulf of Thailand, southeast of
Burma
Geographic coordinates: 15 00 N, 100 00 E
Map references: Southeast Asia
Area:
total: 514,000 sq km
land: 511 ,770 sq km
water: 2,230 sq km
Area - comparative: slightly more than twice the
size of Wyoming
Land boundaries:
total: 4,863 km
border countries: Burma 1,800 km, Cambodia 803
km, Laos 1,754 km, Malaysia 506 km
Coastline: 3,219 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200-m depth or to the depth of
exploitation
Climate: tropical; rainy, warm, cloudy southwest
monsoon (mid-May to September); dry, cool northeast
monsoon (November to mid-March); southern isthmus
always hot and humid
Terrain: central plain; Khorat Plateau in the east;
mountains elsewhere
Elevation extremes:
lowest point: Gulf of Thailand 0 m
highest point: Doi Inthanon 2,576 m
Natural resources: tin, rubber, natural gas,
tungsten, tantalum, timber, lead, fish, gypsum, lignite,
fluorite, arable land
Land use:
arable land: 27.54%
permanent crops: 6.93%
other: 65.53% (2005)
Irrigated land: 47,490 sq km (1998 est.)
Natural hazards: land subsidence in Bangkok area
resulting from the depletion of the water table; droughts
Environment - current issues: air pollution from
vehicle emissions; water pollution from organic and
factory wastes; deforestation; soil erosion; wildlife
populations threatened by illegal hunting
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Marine Life
Conservation, Ozone Layer Protection, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Law of the Sea
Geography - note: controls only land route from
Asia to Malaysia and Singapore
Location: Western Africa, bordering the Bight of
Benin, between Benin and Ghana
Geographic coordinates: 8 00 N, 1 10 E
Map references: Africa
Area:
total: 56,785 sq km
land: 54,385 sq km
water: 2,400 sq km
Area - comparative: slightly smaller than West
Virginia
Land boundaries:
total: 1,647 km
border countries: Benin 644 km, Burkina Faso 126
km, Ghana 877 km
Coastline: 56 km
Maritime claims:
territorial sea: 30 nm
exclusive economic zone: 200 nm
Climate: tropical; hot, humid in south; semiarid in north
Terrain: gently rolling savanna in north; central hills;
southern plateau; low coastal plain with extensive
lagoons and marshes
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mont Agou 986 m
Natural resources: phosphates, limestone, marble,
arable land
Land use:
arable land: 44.2%
permanent crops: 2.11%
ofhen 53.69% (2005)
Irrigated land: 70 sq km (1998 est.)
Natural hazards: hot, dry harmattan wind can reduce
visibility in north during winter periodic droughts
Environment - current issues: deforestation
attributable to slash-and-burn agriculture and the use
of wood for fuel; water pollution presents health
hazards and hinders the fishing industry; air pollution
increasing in urban areas
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Endangered Species, Law of the Sea, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
Geography • note: the country''s length allows it to
stretch through six distinct geographic regions;
climate varies from tropical to savanna','303ddb8a8128c60937badc558c2cae8ae52740cff3a8a09223a2459cd371744a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2743c0abaae87fd2d135a62a8fea9e57542fece64f2797465926627041e18a4',2007,'BG','Bulgaria','geography',282,'Location: Southeastern Europe, bordering the Black
Sea, between Romania and Turkey
Geographic coordinates: 43 00 N, 25 00 E
Map references: Europe
Area:
tofa/:1 10,910 sq km
land: 11 0,550 sq km
water: 360 sq km
Area - comparative: slightly larger than Tennessee
Land boundaries:
total: 1 ,808 km
border countries: Greece 494 km, Macedonia 1 48 km,
Romania 608 km, Serbia and Montenegro 318 km,
Turkey 240 km
Coastline: 354 km
86
Bulgaria (continued)
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: temperate; cold, damp winters; hot, dry
summers
Terrain: mostly mountains with lowlands in north and
southeast
Elevation extremes:
lowest point: Black Sea 0 m
highest point: Musala 2,925 m
Natural resources: bauxite, copper, lead, zinc, coal,
timber, arable land
Land use:
arable land: 29.94%
permanent crops: 1 .9%
other: 68.16% (2005)
Irrigated land: 8,000 sq km (1998 est.)
Natural hazards: earthquakes, landslides
Environment - current issues: air pollution from
industrial emissions; rivers polluted from raw sewage,
heavy metals, detergents; deforestation; forest
damage from air pollution and resulting acid rain; soil
contamination from heavy metals from metallurgical
plants and industrial wastes
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulfur 85, Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Treaty,
Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Ozone Layer Protection, Ship Pollution,
Wetlands
signed, but not ratified: Air Pollution-Sulfur 94
Geography - note: strategic location near Turkish
Straits; controls key land routes from Europe to Middle
East and Asia','eba7bb6977dfda2721de7f1f8df098d272b02892074ae63b9200d294eb8bf0f1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0fa6fb25fd8f36ff82f7ae46771fb56206bd84621a274b542030f16457d4d775',2007,'BF','Burkina Faso','geography',291,'Location: Western Africa, north of Ghana
Geographic coordinates: 1 3 00 N, 2 00 W
Map references: Africa
Area:
total: 274,200 sq km
land: 273,800 sq km
water: 400 sq km
Area - comparative: slightly larger than Colorado
Land boundaries:
total: 3,193 km
border countries: Benin 306 km, Cote d''lvoire 584 km,
Ghana 549 km, Mali 1,000 km, Niger 628 km, Togo
126 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; warm, dry winters; hot, wet
summers
Terrain: mostly flat to dissected, undulating plains;
hills in west and southeast
Elevation extremes:
lowest point: Mouhoun (Black Volta) River 200 m
highest point: Tena Kourou 749 m
Natural resources: manganese, limestone, marble;
small deposits of gold, phosphates, pumice, salt
Land use:
arable land: 17.66%
permanent crops: 0.22%
other: 82.12% (2005)
Irrigated land: 250 sq km (1998 est.)
Natural hazards: recurring droughts
Environment - current issues: recent droughts and
desertification severely affecting agricultural activities.
population distribution, and the economy;
overgrazing; soil degradation; deforestation
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Life Conservation,
Ozone Layer Protection. Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked savanna cut by the
thr^e principal rivers of the Black, Red, and White
Voltas','ae5f31c21cd6ee0e8676afc0db1391b1baf5ee448debbef919cde5a6b94bf4c0','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1873947beed1ee17d57078930d088d4f1e3c94a3e28b79d05569fb595caf927',2007,'TH','Thailand','geography',298,'Location: Southeastern Asia, bordering the
Andaman Sea and the Bay of Bengal, between
Bangladesh and Thailand
Geographic coordinates: 22 00 N, 98 00 E
Map references: Southeast Asia
Area:
total: 678,500 sq km
land: 657,740 sq km
water: 20,760 sq km
Area - comparative: slightly smaller than Texas
Land boundaries:
total: 5,876 km
border countries: Bangladesh 193 km, China 2,185
km, India 1 ,463 km, Laos 235 km, Thailand 1 ,800 km
Coastline: 1,930 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: tropical monsoon; cloudy, rainy, hot, humid
summers (southwest monsoon, June to September);
less cloudy, scant rainfall, mild temperatures, lower
humidity during winter (northeast monsoon,
December to April)
Terrain: central lowlands ringed by steep, rugged
highlands
Elevation extremes:
lowest point: Andaman Sea 0 m
highest point: Hkakabo Razi 5,881 m
Natural resources: petroleum, timber, tin, antimony,
zinc, copper, tungsten, lead, coal, some marble,
limestone, precious stones, natural gas, hydropower
Land use:
arable land: 14.92%
permanent crops: 1 .31 %
other: 83.77% (2005)
Irrigated land: 15,920 sq km (1998 est.)
Natural hazards: destructive earthquakes and
cyclones; flooding and landslides common during
rainy season (June to September); periodic droughts
Environment - current issues: deforestation;
industrial pollution of air, soil, and water; inadequate
sanitation and water treatment contribute to disease
Environment • international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Law of the Sea, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber 94
signed, but not ratified: none of the selected
agreements
Geography ■ note: strategic location near major
Indian Ocean shipping lanes
Location: Southeastern Asia, archipelago between
the Indian Ocean and the Pacific Ocean
Geographic coordinates: 5 00 S, 120 00 E
Map references: Southeast Asia
Area:
total: 1,919,440 sq km
land: 1 ,826,440 sq km
water. 93,000 sq km
Area - comparative: slightly less than three times
the size of Texas
Land boundaries:
total: 2,830 km
border countries: East Timor 228 km, Malaysia 1 ,782
km, Papua New Guinea 820 km
Coastline: 54,716 km
Maritime claims: measured from claimed
archipelagic straight baselines
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; hot, humid; more moderate in
highlands
Terrain: mostly coastal lowlands; larger islands have
interior mountains
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Puncak Jaya 5,030 m
Natural resources: petroleum, tin, natural gas,
nickel, timber, bauxite, copper, fertile soils, coal, gold,
silver
Land use:
arable land: 11.03%
permanent crops: 7.04%
other: 81.93% (2005)
Irrigated land: 48,150 sq km (1998 est.)
Natural hazards: occasional floods, severe
droughts, tsunamis, earthquakes, volcanoes, forest
fires
Environment - current issues: deforestation; water
pollution from industrial wastes, sewage; air pollution
in urban areas; smoke and haze from forest fires
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: Marine Life Conservation
Geography - note: archipelago of 17,508 islands
(6,000 inhabited); straddles equator; strategic location
astride or along major sea lanes from Indian Ocean to
Pacific Ocean
265
Indonesia (continued)
Location: Middle East, bordering the Gulf of Oman,
the Persian Gulf, and the Caspian Sea, between Iraq
and Pakistan
Geographic coordinates: 32 00 N, 53 00 E
Map references: Middle East
Area:
total: 1 .648 million sq km
land: 1 .636 million sq km
water: 12,000 sq km
268
Iran (continued)
Area - comparative: slightly larger than Alaska
Land boundaries:
total: 5,440 km
border countries: Afghanistan 936 km, Armenia 35
km, Azerbaijan-proper 432 km, Azerbaijan-Naxcivan
exclave 179 km, Iraq 1,458 km, Pakistan 909 km,
Turkey 499 km, Turkmenistan 992 km
Coastline: 2,440 km; note - Iran also borders the
Caspian Sea (740 km)
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: bilateral agreements or
median lines in the Persian Gulf
continental shelf: natural prolongation
Climate: mostly arid or semiarid, subtropical along
Caspian coast
Terrain: rugged, mountainous rim; high, central
basin with deserts, mountains; small, discontinuous
plains along both coasts
Elevation extremes:
lowest point: Caspian Sea -28 m
highest point: Kuh-e Damavand 5,671 m
Natural resources: petroleum, natural gas, coal,
chromium, copper, iron ore, lead, manganese, zinc,
sulfur
Land use:
arable land: 9.78%
permanent crops: 1 .29%
other: 88.93% (2005)
Irrigated land: 75,620 sq km (1998 est.)
Natural hazards: periodic droughts, floods; dust
storms, sandstorms; earthquakes
Environment - current issues: air pollution,
especially in urban areas, from vehicle emissions,
refinery operations, and industrial effluents;
deforestation; overgrazing; desertification; oil pollution
in the Persian Gulf; wetland losses from drought; soil
degradation (salination); inadequate supplies of
potable water; water pollution from raw sewage and
industrial waste; urbanization
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Marine Dumping, Ozone Layer Protection,
Wetlands
signed, but not ratified: Environmental Modification,
Law of the Sea, Marine Life Conservation
Geography - note: strategic location on the Persian
Gulf and Strait of Hormuz, which are vital maritime
pathways for crude oil transport
Location: Middle East, bordering the Persian Gulf,
between Iran and Kuwait
Geographic coordinates: 33 00 N, 44 00 E
Map references: Middle East
Area:
total: 437,072 sq km
/and:432,162sqkm
water: 4,91 Osq km
Area - comparative: slightly more than twice the
size of Idaho
Land boundaries:
total: 3,650 km
border countries: Iran 1,458 km, Jordan 181 km,
Kuwait 240 km, Saudi Arabia 814 km, Syria 605 km,
Turkey 352 km
Coastline: 58 km
Maritime claims:
territorial sea: 1 2 nm
continental shelf: not specified
Climate: mostly desert; mild to cool winters with dry,
hot, cloudless summers; northern mountainous
regions along Iranian and Turkish borders experience
cold winters with occasionally heavy snows that melt
in early spring, sometimes causing extensive flooding
in central and southern Iraq
Terrain: mostly broad plains; reedy marshes along
Iranian border in south with large flooded areas;
mountains along borders with Iran and Turkey
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: unnamed peak; 3,61 1 m; note - this
peak is not Gundah Zhur 3,607 m or Kuh-e
Hajji-Ebrahim 3,595 m
Natural resources: petroleum, natural gas,
phosphates, sulfur
Land use:
arable land: 13.12%
permanent crops: 0.61%
other: 86.27% (2005)
Irrigated land: 35,250 sq km (1998 est.)
Natural hazards: dust storms, sandstorms, floods
Environment - current issues: government water
control projects have drained most of the inhabited
marsh areas east of An Nasiriyah by drying up or
diverting the feeder streams and rivers; a once sizable
population of Marsh Arabs, who inhabited these areas
for thousands of years, has been displaced;
furthermore, the destruction of the natural habitat
poses serious threats to the area''s wildlife
populations; inadequate supplies of potable water;
development of the Tigris and Euphrates rivers
system contingent upon agreements with upstream
riparian Turkey; air and water pollution; soil
degradation (salination) and erosion; desertification
Environment • international agreements:
party to: Law of the Sea
signed, but not ratified: Environmental Modification
Geography - note: strategic location on Shaft al
Arab waterway and at the head of the Persian Gulf
Location: Southeastern Asia, bordering the Gulf of
Thailand, Gulf of Tonkin, and South China Sea,
alongside China, Laos, and Cambodia
Geographic coordinates: 16 00 N, 106 00 E
Map references: Southeast Asia
Area:
total: 329,560 sq km
land: 325,360 sq km
water: 4,200 sq km
Area - comparative: slightly larger than New Mexico
Land boundaries:
total: 4,639 km
border countries: Cambodia 1 ,228 km, China 1,281
km, Laos 2,130 km
Coastline: 3,444 km (excludes islands)
Maritime claims:
territorial sea: 12 nm
contiguous zone: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: tropical in south; monsoonal in north with
hot, rainy season (May to September) and warm, dry
season (October to March)
Terrain: low, flat delta in south and north; central
highlands; hilly, mountainous in far north and northwest
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Fan Si Pan 3,144 m
Natural resources: phosphates, coal, manganese,
bauxite, chromate, offshore oil and gas deposits,
forests, hydropower
Land use:
arable land: 20.14%
permanent crops: 6.93%
other: 72.93% (2005)
Irrigated land: 30,000 sq km (1998 est.)
Natural hazards: occasional typhoons (May to
January) with extensive flooding, especially in the
Mekong River delta
Environment - current issues: logging and
slash-and-bum agricultural practices contribute to
deforestation and soil degradation; water pollution and
overfishing threaten marine life populations; groundwater
contamination limits potable water supply; growing urban
industrialization and population migration are rapidly
degrading environment in Hanoi and Ho Chi Minh City
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
600
Vietnam (continued)
Geography - note: extending 1 ,650 km north to
south, the country is only 50 km across at its
narrowest point
Location: Caribbean, islands between the Caribbean
Sea and the North Atlantic Ocean, east of Puerto Rico
Geographic coordinates: 18 20 N, 64 50 W
Map references: Central America and the
Caribbean
Area:
total: 352 sq km
land: 349 sq km
water: 3 sq km
Area - comparative: twice the size of Washington,
DC
Land boundaries: 0 km
Coastline: 188 km
Maritime claims:
territorial sea: 1 2 nm
exclusive economic zone: 200 nm
Climate: subtropical, tempered by easterly trade
winds, relatively low humidity, little seasonal
temperature variation; rainy season September to
November
Terrain: mostly hilly to rugged and mountainous with
little level land
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Crown Mountain 474 m
Natural resources: sun, sand, sea, surf
Land use:
arable land: 5.71%
permanent crops: 2.86%
ofher:91.43%(2005)
Irrigated land: NA
Natural hazards: several hurricanes in recent years;
frequent and severe droughts and floods; occasional
earthquakes
Environment - current issues: lack of natural
freshwater resources
Geography - note: important location along the
Anegada Passage - a key shipping lane for the
Panama Canal; Saint Thomas has one of the best
natural deepwater harbors in the Caribbean','b0372bd203a17c558d1dbe3b30dbfb17508780d87e880dad4af9f4859f9fb058','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8b70c231a8cfd53739410f48e520624254d76b09416657b00d3a5af839145a5',2007,'CG','Congo','geography',309,'Location: Central Africa, east of Democratic
Republic of the Congo
Geographic coordinates: 3 30 S, 30 00 E
Map references: Africa
Area:
total: 27,830 sq km
land: 25,650 sq km
water: 2,180 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries:
total: 974 km
border countnes: Democratic Republic of the Congo
233 km, Rwanda 290 km, Tanzania 451 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: equatorial; high plateau with considerable
altitude variation (772 m to 2,670 m above sea level);
average annual temperature varies with altitude from 23
94
Burundi (continued)
to 17 degrees centigrade but is generally moderate as
the average altitude is about 1 ,700 m; average annual
rainfall is about 150 cm; two wet seasons (February to
May and September to November), and two dry
seasons (June to August and December to January)
Terrain: hilly and mountainous, dropping to a plateau
in east, some plains
Elevation extremes:
lowest point: Lake Tanganyika 772 m
highest point: Heha 2,670 m
Natural resources: nickel, uranium, rare earth
oxides, peat, cobalt, copper, platinum, vanadium,
arable land, hydropower, niobium, tantalum, gold, tin,
tungsten, kaolin, limestone
Land use:
arable land: 35.57%
permanent crops: 1 3. 1 2%
other: 51.31% (2005)
Irrigated land: 740 sq km (1998 est.)
Natural hazards: flooding, landslides, drought
Environment - current issues: soil erosion as a
result of overgrazing and the expansion of agriculture
into marginal lands; deforestation (little forested land
remains because of uncontrolled cutting of trees for
fuel); habitat loss threatens wildlife populations
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Ozone Layer Protection
signed, but not ratified: Law of the Sea
Geography - note: landlocked; straddles crest of the
Nile-Congo watershed; the Kagera, which drains into
Lake Victoria, is the most remote headstream of the
White Nile
Location: Southeastern Asia, bordering the Gulf of
Thailand, between Thailand, Vietnam, and Laos
Geographic coordinates: 13 00 N, 105 00 E
Map references: Southeast Asia
Area:
total: 181 ,040 sq km
land: 176,520 sq km
water: 4,520 sq km
Area - comparative: slightly smaller than Oklahoma
Land boundaries:
total: 2,572 km
border countries: Laos 541 km, Thailand 803 km,
Vietnam 1 ,228 km
Coastline: 443 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm
Climate: tropical; rainy, monsoon season (May to
November); dry season (December to April); little
seasonal temperature variation
Terrain: mostly low, flat plains; mountains in
southwest and north
Elevation extremes:
lowest point: Gulf of Thailand 0 m
highest point: Phuum Aoral 1 ,810 m
Natural resources: oil and gas, timber, gemstones,
some iron ore, manganese, phosphates, hydropower
potential
Land use:
arable land: 20.44%
permanent crops: 0.59%
other 78.97% (2005)
Irrigated land: 2,700 sq km (1998 est.)
Natural hazards: monsoonal rains (June to
November); flooding; occasional droughts
Environment - current issues: illegal logging
activities throughout the country and strip mining for
gems in the western region along the border with
Thailand have resulted in habitat loss and declining
biodiversity (in particular, destruction of mangrove
swamps threatens natural fisheries); soil erosion: in
rural areas, most of the population does not have
access to potable water; declining fish stocks because
of illegal fishing and overfishing
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Marine Life
Conservation, Ozone Layer Protection, Ship Pollution.
Tropical Timber 94, Wetlands
signed, but not ratified: Law of the Sea
Geography - note: a land of paddies and forests
dominated by the Mekong Rivei and Tonle Sap
Location: Central Africa, north of Democratic
Republic of the Congo
Geographic coordinates: 7 00 N, 21 00 E
Map references: Africa
Area:
total: 622,984 sq km
land: 622.984 sq km
water: 0 sq km
Area - comparative: slightly smaller than Texas
Land boundaries:
total: 5,203 km
border countries: Cameroon 797 km, Chad 1 ,1 97 km,
Democratic Republic of the Congo 1 ,577 km, Republic
of the Congo 467 km, Sudan 1 , 1 65 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; hot, dry winters; mild to hot, wet
summers
Terrain: vast, flat to rolling, monotonous plateau;
scattered hills in northeast and southwest
Elevation extremes:
lowest point: Oubangui River 335 m
highest point: Mont Ngaoui 1 ,420 m
Natural resources: diamonds, uranium, timber,
gold, oil, hydropower
Land use:
arable land: 3A%
permanent crops: 0. 1 5%
other: 96.75% (2005)
Irrigated land: NA sq km
Natural hazards: hot, dry, dusty harmattan winds
affect northern areas; floods are common
Environment - current issues: tap water is not
potable; poaching has diminished the country''s
reputation as one of the last great wildlife refuges;
desertification; deforestation
Environment • international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Ozone Layer
Protection, Tropical Timber 94
signed, but not ratified: Law of the Sea
Geography - note: landlocked; almost the precise
center of Africa','0da40c8e6afebed0eb53ca2c48cd21616ffd1c57a2c73994ebac59657fa1d1d8','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('95de63841e0752922ad646776c5cd1dc1f8d01e46789f2a56dd9dd20c8a316bf',2007,'CA','Canada','geography',327,'Location: Northern North America, bordering the
North Atlantic Ocean on the east, North Pacific Ocean
on the west, and the Arctic Ocean on the north, north
of the conterminous US
Geographic coordinates: 60 00 N, 95 00 W
Map references: North America
Area:
total: 9,984,670 sq km
land: 9,093,507 sq km
water. 891,163 sq km
Area - comparative: somewhat larger than the US
Land boundaries:
total: 8,893 km
border countries: US 8,893 km (includes 2,477 km
with Alaska)
Coastline: 202,080 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: varies from temperate in south to subarctic
and arctic in north
Terrain: mostly plains with mountains in west and
lowlands in southeast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Logan 5,959 m
Natural resources: iron ore, nickel, zinc, copper,
gold, lead, molybdenum, potash, diamonds, silver,
fish, timber, wildlife, coal, petroleum, natural gas,
hydropower
Land use:
arable land: 4.57%
permanent crops: 0.65%
other: 94.78% (2005)
Irrigated land: 7,200 sq km (1998 est.)
Natural hazards: continuous permafrost in north is a
serious obstacle to development; cyclonic storms form
east of the Rocky Mountains, a result of the mixing of
air masses from the Arctic, Pacific, and North
American interior, and produce most of the country''s
rain and snow east of the mountains
Environment - current issues: air pollution and
resulting acid rain severely affecting lakes and
damaging forests; metal smelting, coal-burning
utilities, and vehicle emissions impacting on
agricultural and forest productivity; ocean waters
becoming contaminated due to agricultural, industrial,
mining, and forestry activities
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulfur 85, Air Pollution-Sulfur 94,
Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals, Antarctic Treaty,
Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Marine Dumping, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber
94, Wetlands
signed, but not ratified: Air Pollution-Volatile Organic
Compounds, Marine Life Conservation
Geography - note: second-largest country in world
(after Russia); strategic location between Russia and
US via north polar route; approximately 90% of the
population is concentrated within 160 km of the US
border
Location: Western Africa, group of islands in the
North Atlantic Ocean, west of Senegal
Geographic coordinates: 16 00 N, 24 00 W
Map references: Political Map of the World
Area:
total: 4,033 sq km
land: 4,033 sq km
water. 0 sq km
Area • comparative: slightly larger than Rhode
Island
Land boundaries: 0 km
Coastline: 965 km
Maritime claims: measured from claimed
archipelagic baselines
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: temperate; warm, dry summer; precipitation
meager and very erratic
Terrain: steep, rugged, rocky, volcanic
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mt. Fogo 2,829 m (a volcano on Fogo
Island)
Natural resources: salt, basalt rock, limestone,
kaolin, fish, clay, gypsum
Land use:
arable land: 11.41%
permanent crops: 0.74%
other: 87.85% (2005)
Irrigated land: 30 sq km (1998 est.)
Natural hazards: prolonged droughts; seasonal
harmattan wind produces obscuring dust; volcanically
and seismically active
Environment - current issues: soil erosion;
deforestation due to demand for wood used as fuel;
desertification; environmental damage has threatened
several species of birds and reptiles; illegal beach
sand extraction; overfishing
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location 500 km from
west coast of Africa near major north-south sea
routes; important communications station; important
sea and air refueling site','ebbaf923ff522013080089fcc7bcef5fe51c3aafbd8b81a73af135211818a748','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ea236d7a094c28ae65ac42112686024a69bd1fcd9104aa675ad08a1934c00187',2007,'KY','Cayman Islands','geography',342,'Location: Caribbean, three island (Grand Cayman,
Cayman Brae, Little Cayman) group in Caribbean
Sea, 240 km south of Cuba and 268 km northwest of','1bdc23d46db191acd588b5a6a022f91c996d6f5f5fd8d96041edd214afbf5e7f','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7f7167d6117f2f94bd1ac1cc5d4a49836a0ca6272402b745544b9b7d073ac4f2',2007,'JM','Jamaica','geography',343,'Geographic coordinates: 19 30 N. 80 30 W
Map references: Central America and the
Caribbean
Area:
total: 262 sq km
land: 262 sq km
water: 0 sq km
Area - comparative: 1 .5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 160 km
Maritime claims:
territorial sea: 12 nm
exclusive fishing zone: 200 nm
Climate: tropical marine; warm, rainy summers (May
to October) and cool, relatively dry winters (November
to April)
Terrain: low-lying limestone base surrounded by
coral reefs
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: The Bluff (Cayman Brae) 43 m
Natural resources: fish, climate and beaches that
foster tourism
Land use:
arable land: 3.85%
permanent crops: 0%
other: 96.15% (2005)
Irrigated land: NA sq km
Natural hazards: hurricanes (July to November)
Environment - current issues: no natural fresh
water resources; drinking water supplies must be met
by rainwater catchments
Geography - note: important location between
Cuba and Central America
Location: Caribbean, island in the Caribbean Sea,
south of Cuba
Geographic coordinates: 18 15 N, 77 30 W
Map references: Central America and the
Caribbean
Area:
total: 10,991 sqkm
/and: 10,831 sqkm
water: 1 60 sq km
Area - comparative: slightly smaller than
Connecticut
Land boundaries: 0 km
Coastline: 1,022 km
Maritime claims: measured from claimed
archipelagic straight baselines
territorial sea: 1 2 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to edge of the continental
margin
Climate: tropical; hot, humid; temperate interior
Terrain: mostly mountains, with narrow,
discontinuous coastal plain
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Blue Mountain Peak 2,256 m
Natural resources: bauxite, gypsum, limestone
Land use:
arable land: 15.83%
permanent crops: 1 0.01 %
ofher 74.1 6% (2005)
Irrigated land: 250 sqkm (1998 est.)
Natural hazards: hurricanes (especially July to
November)
Environment - current issues: heavy rates of
deforestation; coastal waters polluted by industrial
waste, sewage, and oil spills; damage to coral reefs;
air pollution in Kingston results from vehicle emissions
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography ■ note: strategic location between
Cayman Trench and Jamaica Channel, the main sea
lanes for the Panama Canal','d96cde38b78635822a925c9439484c83e40add46a7486c8cd8296d6c51d0a065','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('35626b3faf68fecde3423ca2e9ed140659b9e2a42d2928c8689592e99d30a284',2007,'LY','Libya','geography',354,'Location: Central Africa, south of Libya
Geographic coordinates: 15 00 N, 19 00 E
Map references: Africa
112
Chad (continued)
Area:
total: 1 .284 million sq km
land: 1 ,259,200 sq km
water: 24,800 sq km
Area - comparative: slightly more than three times
the size of California
Land boundaries:
total: 5,968 km
border countries: Cameroon 1,094 km, Central
African Republic 1,197 km, Libya 1,055 km, Niger
1,175 km, Nigeria 87 km, Sudan 1,360 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical in south, desert in north
Terrain: broad, arid plains in center, desert in north,
mountains in northwest, lowlands in south
Elevation extremes:
lowest point: Djourab Depression 160 m
highest point: Emi Koussi 3,415 m
Natural resources: petroleum, uranium, natron,
kaolin, fish (Lake Chad), gold, limestone, sand and
gravel, salt
Land use:
arable land: 2.8%
permanent crops: 0.02%
other: 97.18% (2005)
Irrigated land: 200 sq km (1998 est.)
Natural hazards: hot, dry, dusty harmattan winds
occur in north; periodic droughts; locust plagues
Environment ■ current issues: inadequate supplies
of potable water; improper waste disposal in rural
areas contributes to soil and water pollution;
desertification
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Ozone Layer
Protection, Wetlands
signed, but not ratified: Law of the Sea, Marine
Dumping
Geography - note: landlocked; Lake Chad is the
most significant water body in the Sahel
Location: Northern Africa, bordering the
Mediterranean Sea, between Egypt and Tunisia
Geographic coordinates: 25 00 N, 17 00 E
Map references: Africa
Area:
total: 1,759,540 sq km
land: 1 ,759,540 sq km
water: 0 sq km
Area - comparative: slightly larger than Alaska
Land boundaries:
total: 4,348 km
border countries: Algeria 982 km, Chad 1 ,055 km,
Egypt 1 ,1 1 5 km, Niger 354 km, Sudan 383 km, Tunisia
459 km
Coastline: 1 ,770 km
Maritime claims:
territorial sea: 12 nm
note: Gulf of Sidra closing line - 32 degrees, 30
minutes north
Climate: Mediterranean along coast; dry, extreme
desert interior
Terrain: mostly barren, flat to undulating plains,
plateaus, depressions
Elevation extremes:
lowest point: Sabkhat Ghuzayyil -47 m
highest point: Bikku Bitti 2,267 m
Natural resources: petroleum, natural gas, gypsum
Land use:
arable land: 1 .03%
permanent crops: 0.1 9%
other: 98.78% (2005)
Irrigated land: 4,700 sq km (1998 est.)
Natural hazards: hot, dry, dust-laden ghibli is a
southern wind lasting one to four days in spring and
fall; dust storms, sandstorms
Environment - current issues: desertification; very
limited natural fresh water resources; the Great
Manmade River Project, the largest water
development scheme in the world, is being built to
bring water from large aquifers under the Sahara to
coastal cities
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Marine Dumping, Ozone Layer Protection
signed, but not ratified: Law of the Sea
Geography - note: more than 90% of the country is
desert or semidesert','a6e5a4d955c7610de03b9e5994dc31f8093435c6b3bcf37dd1450557db435bce','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ecc6418c543ac8efd191c5c4a304d209959ae1742718226a77f8daa6a0cf37a',2007,'CN','China','geography',364,'Location: Eastern Asia, bordering the East China
Sea. Korea Bay, Yellow Sea, and South China Sea,
between North Korea and Vietnam
Geographic coordinates: 35 00 N, 105 00 E
Map references: Asia
Area:
total: 9,596,960 sq km
land: 9,326,41 Osq km
water: 270.550 sq km
Area - comparative: slightly smaller than the US
Land boundaries:
tofa/:22,117km
border countries: Afghanistan 76 km. Bhutan 470 km,
Burma 2.1 85 km, India 3,380 km. Kazakhstan 1,533 km.
North Korea 1 ,41 6 km, Kyrgyzstan 858 km, Laos 423 km,
Mongolia 4,677 km, Nepal 1 ,236 km, Pakistan 523 km,
Russia (northeast) 3.605 km, Russia (northwest) 40 km,
Tajikistan 414 km, Vietnam 1,281 km
regional borders: Hong Kong 30 km. Macau 0.34 km
Coastline: 14.500 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: extremely diverse; tropical in south to
subarctic in north
Terrain: mostly mountains, high plateaus, deserts in
west; plains, deltas, and hills in east
Elevation extremes:
lowest point: Turpan Pendi -154 m
highest point: Mount Everest 8,850 m
Natural resources: coal, iron ore, petroleum, natural
gas. mercury, tin, tungsten, antimony, manganese,
molybdenum, vanadium, magnetite, aluminum, lead,
zinc, uranium, hydropower potential (world''s largest)
Land use:
arable land: 14.86%
permanent crops: 1 .27%
other: 83.87% (2005)
Irrigated land: 525.800 sq km (1998 est.)
Natural hazards: frequent typhoons (about five per
year along southern and eastern coasts); damaging
floods; tsunamis; earthquakes; droughts; land
subsidence
Environment - current issues: air pollution
(greenhouse gases, sulfur dioxide particulates) from
reliance on coal produces acid rain; water shortages,
particularly in the north; water pollution from untreated
wastes; deforestation; estimated loss of one-fifth of
agricultural land since 1949 to soil erosion and
economic development; desertification; trade in
endangered species
Environment - international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: none of the selected
agreements
118
China (continued)
Geography - note: world''s fourth largest country
(after Russia, Canada, and US); Mount Everest on the
border with Nepal is the world''s tallest peak
Location: Eastern Asia, bordering the South China
Sea and China
Geographic coordinates: 22 15 N, 114 10 E
Map references: Southeast Asia
Area:
total: 1,092 sq km
land: 1 ,042 sq km
water: 50 sq km
Area - comparative: six times the size of
Washington, DC
Land boundaries:
total: 30 km
regional border: China 30 km
Coastline: 733 km
Maritime claims:
territorial sea: 3 nm
Climate: subtropical monsoon; cool and humid in
winter, hot and rainy from spring through summer,
warm and sunny in fall
Terrain: hilly to mountainous with steep slopes;
lowlands in north
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Tai Mo Shan 958 m
Natural resources: outstanding deepwater harbor,
feldspar
Land use:
arable land: 5.05% .
permanent crops: 1 .01 %
other: 93.94% (2001)
Irrigated land: 20 sq km (1998 est.)
Natural hazards: occasional typhoons
Environment - current issues: air and water
pollution from rapid urbanization
Environment - international agreements:
party to: Marine Dumping (associate member)
Geography - note: more than 200 islands
Location: Central Asia, northwest of China; a small
portion west of the Ural River in eastern-most Europe
Geographic coordinates: 48 00 N, 68 00 E
Map references: Asia
Area:
total: 2,71 7,300 sq km
land: 2,669,800 sq km
water 47.500 sq km
Area • comparative: slightly less than four times the
size of Texas
Land boundaries:
total: 12,012 km
border countnes: China 1,533 km, Kyrgyzstan 1,051
km, Russia 6,846 km, Turkmenistan 379 km,
Uzbekistan 2,203 km
Coastline: 0 km (landlocked); note - Kazakhstan
borders the Aral Sea, now split into two bodies of
water (1 ,070 km), and the Caspian Sea (1 ,894 km)
Maritime claims: none (landlocked)
Climate: continental, cold winters and hot summers,
arid and semiarid
Terrain: extends from the Volga to the Altai
Mountains and from the plains in western Siberia to
oases and desert in Central Asia
Elevation extremes:
lowest point: Vpadina Kaundy -132 m
highest point: Khan Tangiri Shyngy (Pik Khan-Tengri)
6,995 m
Natural resources: major deposits of petroleum,
natural gas, coal, iron ore, manganese, chrome ore,
nickel, cobalt, copper, molybdenum, lead, zinc,
bauxite, gold, uranium
Land use:
arable land: 8.28%
permanent crops: 0.05%
other: 91.67% (2005)
Irrigated land: 23,320 sq km (1998 est.)
Natural hazards: earthquakes in the south,
mudslides around Almaty
Environment - current issues: radioactive or toxic
chemical sites associated with former defense
industries and test ranges scattered throughout the
country pose health risks for humans and animals;
industrial pollution is severe in some cities; because
the two main rivers which flowed into the Aral Sea
have been diverted for irrigation, it is drying up and
leaving behind a harmful layer of chemical pesticides
and natural salts; these substances are then picked
up by the wind and blown into noxious dust storms;
pollution in the Caspian Sea; soil pollution from
overuse of agricultural chemicals and salination from
poor infrastructure and wasteful irrigation practices
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Ozone Layer Protection, Ship Pollution
signed, but not ratified: Climate Change-Kyoto
Protocol
296
Kazakhstan (continued)
Geography - note: landlocked; Russia leases
approximately 6,000 sq km of territory enclosing the
Baykonur Cosmodrome; in January 2004, Kazakhstan
and Russia extended the lease to 2050
Location: Central Asia, west of China
Geographic coordinates: 41 00 N, 75 00 E
Map references: Asia
Area:
total: 198,500 sq km
land: 191,300 sq km
water: 7,200 sq km
Area - comparative: slightly smaller than South
Dakota
Land boundaries:
total: 3,878 km
border countries: China 858 km, Kazakhstan 1 ,051
km, Tajikistan 870 km, Uzbekistan 1,099 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: dry continental to polar in high Tien Shan;
subtropical in southwest (Fergana Valley); temperate
in northern foothill zone
Terrain: peaks of Tien Shan and associated valleys
and basins encompass entire nation
Elevation extremes:
lowest point: Kara-Daryya (Karadar''ya) 132 m
highest point: Jengish Chokusu (Pik Pobedy) 7,439 m
Natural resources: abundant hydropower;
significant deposits of gold and rare earth metals;
locally exploitable coal, oil, and natural gas; other
deposits of nepheline, mercury, bismuth, lead, and
zinc
Land use:
arable land: 6.55%
permanent crops: 0.28%
other: 93.17%
note: Kyrgyzstan has the world''s largest natural
growth walnut forest (2005)
Irrigated land: 10,740 sq km (1998 est.)
Natural hazards: NA
Environment - current issues: water pollution;
many people get their water directly from
contaminated streams and wells; as a result,
water-borne diseases are prevalent; increasing soil
salinity from faulty irrigation practices
Environment - international agreements:
party to: Air Pollution. Biodiversity, Climate Change.
Climate Change-Kyoto Protocol, Desertification,
Hazardous Wastes. Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography • note: landlocked; entirely
mountainous, dominated by the Tien Shan range;
many tall peaks, glaciers, and high-altitude lakes
Location: Southeastern Asia, northeast of Thailand,
west of Vietnam
Geographic coordinates: 18 00 N, 105 00 E
Map references: Southeast Asia
Area:
total: 236,800 sq km
land: 230,800 sq km
water: 6,000 sq km
Area - comparative: slightly larger than Utah
Land boundaries:
total: 5,083 km
border countries: Burma 235 km, Cambodia 541 km,
China 423 km, Thailand 1 ,754 km, Vietnam 2,1 30 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical monsoon; rainy season (May to
November); dry season (December to April)
Terrain: mostly rugged mountains; some plains and
plateaus
314
LaOS (continued)
Elevation extremes:
lowest point: Mekong River 70 m
highest point: Phou Bia 2,817 m
Natural resources: timber, hydropower, gypsum,
tin, gold, gemstones
Land use:
arable land: 4.01%
permanent crops: 0.34%
other: 95.65% (2005)
Irrigated land: 1,640 sq km
note: rainy season irrigation - 2,169 sq km; dry season
irrigation - 750 sq km (1998 est.)
Natural hazards: floods, droughts
Environment - current issues: unexploded
ordnance; deforestation; soil erosion; most of the
population does not have access to potable water
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Law of the Sea,
Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked; most of the country
is mountainous and thickly forested; the Mekong River
forms a large part of the western boundary with
Location: Northern Asia, between China and Russia
Geographic coordinates: 46 00 N, 105 00 E
Map references: Asia
Area:
total: 1,564,1 16 sq km
Area - comparative: slightly smaller than Alaska
Land boundaries:
total: 8,220 km
border countries: China 4,677 km, Russia 3,543 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: desert; continental (large daily and
seasonal temperature ranges)
Terrain: vast semidesert and desert plains, grassy
steppe, mountains in west and southwest; Gobi
Desert in south-central
Elevation extremes:
lowest point: Hoh Nuur 518 m
highest point: Nayramadlin Orgil (Huyten Orgil) 4,374 m
Natural resources: oil, coal, copper, molybdenum,
tungsten, phosphates, tin, nickel, zinc, fluorspar, gold,
silver, iron
Land use:
arable land: 0.76%
permanent crops: 0%
other: 99.24% (2005)
Irrigated land: 840 sq km (1998 est.)
Natural hazards: dust storms, grassland and forest
fires, drought, and "zud," which is harsh winter
conditions
Environment - current issues: limited natural fresh
water resources in some areas; the policies of former
Communist regimes promoted rapid urbanization and
industrial growth that had negative effects on the
environment; the burning of soft coal in power plants
and the lack of enforcement of environmental laws
severely polluted the air in Ulaanbaatar; deforestation,
overgrazing, and the converting of virgin land to
agricultural production increased soil erosion from
wind and rain; desertification and mining activities had
a deleterious effect on the environment
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Wetlands
signed, but not ratified: none of the selected
agreements
Geography • note: landlocked; strategic location
between China and Russia
Location: Southeastern Asia, group of reefs and
islands in the South China Sea, about two-thirds of the
way from southern Vietnam to the southern','7f858c212bf58c158f7e90614238f4a7ac5c7a92733640bb11da4747da826784','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eeff90cdd85fed9ed05f4a39e974d28031c30320d1fbefd1a1ff7233fb04f225',2007,'FR','France','geography',379,'Location: Southeastern Asia, group of islands in the
Indian Ocean, southwest of Indonesia, about halfway
from Australia to Sri Lanka
Geographic coordinates: 12 30 S, 96 50 E
Map references: Southeast Asia
Area:
tote/: 14 sq km
land: 14 sq km
water: 0 sq km
note: includes the two main islands of West Island and
Home Island
Area - comparative: about 24 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 26 km
Maritime claims:
territorial sea: 12 nm
exclusive fishing zone: 200 nm
Climate: tropical with high humidity, moderated by the
southeast trade winds for about nine months of the year
Terrain: flat, low-lying coral atolls
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 5 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: NA sq km
Natural hazards: cyclone season is October to April
Environment - current issues: fresh water
resources are limited to rainwater accumulations in
natural underground reservoirs
Geography - note: islands are thickly covered with
coconut palms and other vegetation
Location: Southern South America, islands in the
South Atlantic Ocean, east of southern Argentina
Geographic coordinates: 51 45 S, 59 00 W
Map references: South America
Area:
total: 12,173 sq km
land: 12,173 sq km
wafer: 0 sq km
note: includes the two main islands of East and West
Falkland and about 200 small islands
Area - comparative: slightly smaller than
Connecticut
Land boundaries: 0 km
Coastline: 1,288 km
Maritime claims:
territorial sea: 1 2 nm
continental shelf: 200 nm
exclusive fishing zone: 200 nm
Climate: cold marine; strong westerly winds, cloudy,
humid; rain occurs on more than half of days in year;
average annual rainfall is 24 inches in Stanley;
occasional snow all year, except in January and
February, but does not accumulate
Terrain: rocky, hilly, mountainous with some boggy,
undulating plains
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Usborne 705 m
Natural resources: fish, squid, wildlife, calcified
seaweed, sphagnum moss
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (99% permanent pastures, 1% other)
(2005)
Irrigated land: NA
Natural hazards: strong winds persist throughout
the year
Environment - current issues: overfishing by
unlicensed vessels is a problem; reindeer were
introduced to the islands in 2001 for commercial
reasons; this is the only commercial reindeer herd in
the world unaffected by the Chornobyl disaster
Geography - note: deeply indented coast provides
good natural harbors; short growing season
Location: southeast of Africa, islands in the southern
Indian Ocean, about equidistant between Africa,
Antarctica, and Australia; note - French Southern and
Antarctic Lands include He Amsterdam, He Saint-Paul,
lies Crozet, and lies Kergueien in the southern Indian
Ocean, along with the French-claimed sector of
Antarctica, "Adelie Land"; the US does not recognize
the French claim to "Adelie Land"
Geographic coordinates: 43 00 S, 67 00 E
Map references: Antarctic Region
Area:
total: 7,829 sq km
land: 7,829 sq km
water: 0 sq km
note: includes He Amsterdam, He Saint-Paul, lies
Crozet, and lies Kergueien; excludes "Adelie Land"
claim of about 500,000 sq km in Antarctica that is not
recognized by the US
Area - comparative: slightly less than 1 .3 times the
size of Delaware
Land boundaries: 0 km
Coastline: 1,232 km
Maritime claims:
territorial sea: 1 2 nm
exclusive economic zone: 200 nm from lies
Kergueien (does not include the rest of French
Southern and Antarctic Lands)
Climate: antarctic
Terrain: volcanic
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Mont Ross on lies Kergueien 1 ,850 m
Natural resources: fish, crayfish
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: 0 sq km (1998 est.)
Natural hazards: lie Amsterdam and lie Saint-Paul
are extinct volcanoes
Environment - current issues: NA
Geography - note: islands component is widely
scattered across remote locations in the southern
Indian Ocean
Location: Northern Africa, bordering the
Mediterranean Sea, between Algeria and Libya
Geographic coordinates: 34 00 N, 9 00 E
Map references: Africa
Area:
total: 163,610 sq km
land: 155,360 sq km
water: 8,250 sq km
Area - comparative: slightly larger than Georgia
Land boundaries:
total: 1,424 km
border countries: Algeria 965 km, Libya 459 km
Coastline: 1,148 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
Climate: temperate in north with mild, rainy winters
and hot, dry summers; desert in south
Terrain: mountains in north; hot, dry central plain;
semiarid south merges into the Sahara
Elevation extremes:
lowest point: Shaft al Gharsah -17 m
highest point: Jebel ech Chambi 1 ,544 m
Natural resources: petroleum, phosphates, iron
ore, lead, zinc, salt
Land use:
arable land: 17.05%
permanent crops: 1 3.08%
other: 69.87% (2005)
Irrigated land: 3,800 sq km (1998 est.)
Natural hazards: NA
Environment - current issues: toxic and hazardous
waste disposal is ineffective and poses health risks;
water pollution from raw sewage; limited natural fresh
water resources; deforestation; overgrazing; soil
erosion; desertification
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
Geography - note: strategic location in central
Mediterranean; Malta and Tunisia are discussing the
commercial exploitation of the continental shelf
between their countries, particularly for oil exploration
Location: Southeastern Europe and Southwestern
Asia (that portion of Turkey west of the Bosporus is
geographically part of Europe), bordering the Black
Sea, between Bulgaria and Georgia, and bordering
the Aegean Sea and the Mediterranean Sea. between
Greece and Syria
Geographic coordinates: 39 00 N, 35 00 E
Map references: Middle East
Area:
total: 780,580 sq km
land: 770,760 sq km
water: 9,820 sq km
Area - comparative: slightly larger than Texas
Land boundaries:
total: 2,648 km
border countries: Armenia 268 km, Azerbaijan 9 km.
Bulgaria 240 km, Georgia 252 km, Greece 206 km,
Iran 499 km, Iraq 352 km, Syria 822 km
Coastline: 7,200 km
Maritime claims:
territorial sea: 6 nm in the Aegean Sea; 12 nm in Black
Sea and in Mediterranean Sea
exclusive economic zone: in Black Sea only: to the
maritime boundary agreed upon with the former
USSR
Climate: temperate; hot, dry summers with mild, wet
winters; harsher in interior
Terrain: high central plateau (Anatolia); narrow
coastal plain; several mountain ranges
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Mount Ararat 5,166 m
Natural resources: coal, iron ore, copper,
chromium, antimony, mercury, gold, barite, borate,
celestite (strontium), emery, feldspar, limestone,
magnesite, marble, perlite, pumice, pyrites (sulfur),
clay, arable land, hydropower
Land use:
arable land: 29.81%
permanent crops: 3.39%
other: 66.8% (2005)
Irrigated land: 42,000 sq km (1998 est.)
Natural hazards: severe earthquakes, especially in
northern Turkey, along an arc extending from the Sea
of Marmara to Lake Van
Environment - current issues: water pollution from
dumping of chemicals and detergents; air pollution,
particularly in urban areas; deforestation; concern for
oil spills from increasing Bosporus ship traffic
Environment - international agreements:
party to: Air Pollution, Antarctic Treaty, Biodiversity,
Climate Change, Desertification, Endangered
Species, Hazardous Wastes, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: Environmental Modification
Geography - note: strategic location controlling the
Turkish Straits (Bosporus, Sea of Marmara,
Dardanelles) that link Black and Aegean Seas; Mount
Ararat, the legendary landing place of Noah''s Ark, is in
the far eastern portion of the country
Location: Western Europe, islands including the
northern one-sixth of the island of Ireland between the
North Atlantic Ocean and the North Sea, northwest of
Geographic coordinates: 54 00 N, 2 00 W
Map references: Europe
Area:
total: 244,820 sq km
tend: 241 ,590 sq km
water: 3,230 sq km
note: includes Rockall and Shetland Islands
Area - comparative: slightly smaller than Oregon
Land boundaries:
total: 360 km
border countries: Ireland 360 km
Coastline: 12,429 km
Maritime claims:
territorial sea: 12 nm
exclusive fishing zone: 200 nm
continental shelf: as defined in continental shelf
orders or in accordance with agreed upon boundaries
Climate: temperate; moderated by prevailing
southwest winds over the North Atlantic Current; more
than one-half of the days are overcast
Terrain: mostly rugged hills and low mountains; level
to rolling plains in east and southeast
Elevation extremes:
lowest point: The Fens -4 m
highest point: Ben Nevis 1,343 m
Natural resources: coal, petroleum, natural gas,
iron ore, lead, zinc, gold, tin, limestone, salt, clay,
chalk, gypsum, potash, silica sand, slate, arable land
Land use:
arable land: 23.23%
permanent crops: 0.2%
other: 76.57% (2005)
Irrigated land: 1,080 sq km (1998 est.)
Natural hazards: winter windstorms; floods
Environment - current issues: continues to reduce
greenhouse gas emissions (has met Kyoto Protocol
target of a 12.5% reduction from 1990 levels and
intends to meet the legally binding target and move
toward a domestic goal of a 20% cut in emissions by
2010); by 2005 the government aims to reduce the
amount of industrial and commercial waste disposed
of in landfill sites to 85% of 1 998 levels and to recycle
or compost at least 25% of household waste,
increasing to 33% by 2015; between 1998-99 and
1999-2000, household recycling increased from 8.8%
to 10.3%
Environment • international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulfur 94, Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Endangered Species. Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Marine Life Conservation, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber
94, Wetlands, Whaling
signed, but not ratified: Mr Pollution-Persistent
Organic Pollutants
Geography - note: lies near vital North Atlantic sea
lanes; only 35 km from'' France and linked by tunnel
under the English Channel; because of heavily
indented coastline, no location is more than 125 km
from tidal waters','67643f55b7d506adfce2c37b5dd05cf2199c0b1a010f6000c250867daa32c95f','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0ad15787d69d8a1a6f334585b2fd73665487a598be79151ae41347d411a8c8db',2007,'CO','Colombia','geography',390,'Location: Northern South America, bordering the
Caribbean Sea, between Panama and Venezuela,
and bordering the North Pacific Ocean, between
Ecuador and Panama
Geographic coordinates: 4 00 N, 72 00 W
Map references: South America
Area:
total: 1,138,910 sq km
land: 1,038,700 sq km
water: 100,210 sq km
note: includes Isla de Malpelo, Roncador Cay,
Serrana Bank, and Serranilla Bank
Area - comparative: slightly less than three times
the size of Montana
Land boundaries:
total: 6,004 km
border countries: Brazil 1 .643 km, Ecuador 590 km.
Panama 225 km, Peru 1,496 km (est.). Venezuela
2,050 km
Coastline: 3,208 km (Caribbean Sea 1 ,760 km,
North Pacific Ocean 1 ,448 km)
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200-m depth or to the depth of
exploitation
Climate: tropical along coast and eastern plains;
cooler in highlands
Terrain: flat coastal lowlands, central highlands, high
Andes Mountains, eastern lowland plains
Elevation extremes:
lowest point: Pacific Ocean 0 m
hghest point: Pico Cristobal Colon 5,775 m
note: nearby Pico Simon Bolivar also has the same
elevation
Natural resources: petroleum, natural gas, coal.
iron ore, nickel, gold, copper, emeralds, hydropower
Land use:
arable land: 2.01%
permanent crops: 1 .37%
other: 96.62% (2005)
Irrigated land: 8,500 sq km (1998 est.)
Natural hazards: highlands subject to volcanic
eruptions; occasional earthquakes; periodic droughts
Environment - current issues: deforestation; soil
and water quality damage from overuse of pesticides;
air pollution, especially in Bogota, from vehicle
emissions
Environment - international agreements:
party to: Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Hazardous
Wastes, Marine Life Conservation. Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: Law of the Sea
Geography - note: only South American country
with coastlines on both the North Pacific Ocean and
Caribbean Sea
Location: Central America, bordering both the
Caribbean Sea and the North Pacific Ocean, between
Colombia and Costa Rica
Geographic coordinates: 9 00 N, 80 00 W
Map references: Central America and the
Caribbean
Area:
total: 78,200 sq km
land: 75,990 sq km
water: 2,21 Osq km
Area - comparative: slightly smaller than South
Carolina
Land boundaries:
total: 555 km
border countries: Colombia 225 km, Costa Rica 330
km
Coastline: 2,490 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical maritime; hot, humid, cloudy;
prolonged rainy season (May to January), short dry
season (January to May)
Terrain: interior mostly steep, rugged mountains and
dissected, upland plains; coastal areas largely plains
and rolling hills
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Volcan de Chiriqui 3,475 m
Natural resources: copper, mahogany forests,
shrimp, hydropower
Land use:
arable land: 7.26%
permanent crops: 1 .95%
other: 90.79% (2005)
Irrigated land: 320 sq km (1998 est.)
Natural hazards: occasional severe storms and
forest fires in the Darien area
Environment • current issues: water pollution from
agricultural runoff threatens fishery resources;
deforestation of tropical rain forest; land degradation
and soil erosion threatens siltation of Panama Canal;
air pollution in urban areas; mining threatens natural
resources
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: Marine Life Conservation
Geography - note: strategic location on eastern end
of isthmus forming land bridge connecting North and
South America; controls Panama Canal that links
North Atlantic Ocean via Caribbean Sea with North
Pacific Ocean','4f687e8a0e23ba9c8f89550c62e721f398374827fdf267c78dd5beaf6467679b','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c0c7e451573ff7a9127377b42e4dca11aeb3315cfa4d4cda1a5a801b46157a4d',2007,'YT','Mayotte','geography',406,'Location: Central Africa, northeast of Angola
Geographic coordinates: 0 00 N, 25 00 E
Map references: Africa
Area:
total: 2,345,410 sq km
land: 2,267,600 sq km
water: 77,810 sq km
Area - comparative: slightly less than one-fourth the
size of the US
Land boundaries:
total: 10,730 km
border countries: Angola 2,51 1 km (of which 225 km
is the boundary of Angola''s discontiguous Cabinda
Province), Burundi 233 km, Central African Republic
1 ,577 km, Republic of the Congo 2,41 0 km, Rwanda
217 km, Sudan 628 km, Tanzania 459 km, Uganda
765 km, Zambia 1,930 km
Coastline: 37 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: boundaries with neighbors
Climate: tropical; hot and humid in equatorial river
basin; cooler and drier in southern highlands; cooler
and wetter in eastern highlands; north of Equator - wet
season (April to October), dry season (December to
February); south of Equator - wet season (November
to March), dry season (April to October)
Terrain: vast central basin is a low-lying plateau;
mountains in east
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pic Marguerite on Mont Ngaliema
(Mount Stanley) 5,110 m
Natural resources: cobalt, copper, niobium,
tantalum, petroleum, industrial and gem diamonds,
gold, silver, zinc, manganese, tin, uranium, coal,
hydropower, timber
Land use:
arable land: 2.86%
permanent crops: 0.47%
other: 96.67% (2005)
Irrigated land: 1 10 sq km (1998 est.)
Natural hazards: periodic droughts in south; Congo
River floods (seasonal); in the east, in the Great Rift
Valley, there are active volcanoes
Environment - current issues: poaching threatens
wildlife populations; water pollution; deforestation;
refugees responsible for significant deforestation, soil
erosion, and wildlife poaching; mining of minerals
(coltan - a mineral used in creating capacitors,
diamonds, and gold) causing environmental damage
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Tropical Timber 83, Tropical Timber
94, Wetlands
signed, but not ratified: Environmental Modification
130
Congo, Democratic Republic of the (continued)
Geography • note: straddles equator; has very
narrow strip of land that controls the lower Congo
River and is only outlet to South Atlantic Ocean; dense
tropical rain forest in central river basin and eastern
highlands
Location: Southern Africa, island in the Mozambique
Channel, about one-half of the way from northern
Madagascar to northern Mozambique
Geographic coordinates: 12 50 S, 45 10 E
Map references: Africa
Area:
total: 374 sq km
land: 374 sq km
water: 0 sq km
Area - comparative: slightly more than twice the
size of Washington, DC
Land boundaries: 0 km
Coastline: 185.2 km
Maritime claims:
territorial sea: 1 2 nm
exclusive economic zone: 200 nm
Climate: tropical; marine; hot, humid, rainy season
during northeastern monsoon (November to May); dry
season is cooler (May to November)
Terrain: generally undulating, with deep ravines and
ancient volcanic peaks
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Benara 660 m
Natural resources: NEGL
Land use:
arable land: NA%
permanent crops: NA%
other: NA%
Irrigated land: NA sq km
Natural hazards: cyclones during rainy season
Environment - current issues: NA
Geography - note: part of Comoro Archipelago; 1 8
islands','cceba3dd6e30d0cd8fd6b149626329c51f702d11036cf80c130bb001ed9e862d','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d37e20b6fe5cefd1e81a9494620f8a9e5f383100c4341c48f70613f31b5873d',2007,'CK','Cook Islands','geography',410,'Location: Oceania, group of islands in the South
Pacific Ocean, about one-half of the way from Hawaii
to New Zealand
Geographic coordinates: 21 14 S, 159 46 W
Map references: Oceania
Area:
total: 240 sq km
land: 240 sq km
water: 0 sq km
Area - comparative: 1 .3 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 120 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: tropical; moderated by trade winds
Terrain: low coral atolls in north; volcanic, hilly
islands in south
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Te Manga 652 m
Natural resources: NEGL
Land use:
arable land. 16.67°o
permanent crops: 8 33°o
other: 75°o (2005)
135
Cook Islands (continued)
Irrigated land: NA
Natural hazards: typhoons (November to March)
Environment - current issues: NA
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Law of the
Sea
signed, but not ratified: none of the selected
agreements
Geography - note: the northern Cook Islands are
seven low-lying, sparsely populated, coral atolls; the
southern Cook Islands consist of eight elevated,
fertile, volcanic isles where most of the populace lives
Location: Oceania, islands in the Coral Sea,
northeast of Australia
Geographic coordinates: 18 00 S, 152 00 E
Map references: Oceania
Area:
total: less than 3 sq km
land: less than 3 sq km
water: 0 sq km
note: includes numerous small islands and reefs
scattered over a sea area of about 780,000 sq km.
with the Willis Islets the most important
Area - comparative: NA
Land boundaries: 0 km
Coastline: 3,095 km
Maritime claims:
territorial sea: 3 nm
exclusive fishing zone: 200 nm
Climate: tropical
Terrain: sand and coral reefs and islands (or cays)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Cato Island 6 m
Natural resources: NEGL
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (mostly grass or scrub cover) (2005)
Irrigated land: 0 sq km
Natural hazards: occasional tropical cyclones
Environment - current issues: no permanent fresh
water resources
137
Coral Sea Islands (continued)
Geography - note: important nesting area for birds
and turtles
Location: Oceania
Baker Island: atoll in the North Pacific Ocean 1 ,830
nm (3,389 km) southwest of Honolulu, about half way
between Hawaii and Australia
Howland Island: island in the North Pacific Ocean
1.815 nm (3,361 km) southwest of Honolulu, about
half way between Hawaii and Australia
Jarvis Island: island in the South Pacific Ocean 1 ,305
nm (2,417 km) south of Honolulu, about half way
between Hawaii and the Cook Islands
Johnston Atoll: atoll in the North Pacific Ocean 717
nm (1 ,328 km) southwest of Honolulu, about one-third
of the way from Hawaii to the Marshall Islands
Kingman Reef: reef in the North Pacific Ocean 930
nm (1 ,722 km) south of Honolulu, about half way
between Hawaii and American Samoa
Midway Islands: atoll in the North Pacific Ocean 1 ,260
nm (2,334 km) northwest of Honolulu near the end of
the Hawaiian Archipelago, about one-third of the way
from Honolulu to Tokyo
Palmyra Atoll: atoll in the North Pacific Ocean 960 nm
(1 .778 km) south of Honolulu, about half way between
Hawaii and American Samoa
Geographic coordinates:
Baker Island: 0 13 N, 176 28 W
Howland Island: 0 48 N, 176 38 W
Jarvis Island: 0 23 S, 160 01 W
Johnston Atoll: 16 45 N, 169 31 W
Kingman Reef: 6 23 N, 162 25 W
Midway Islands: 28 1 2 N, 1 77 22 W
Palmyra Atoll: 5 53 N, 162 05 W
Map references: Oceania
Area: total - 6,959.41 sq km; emergent land -
22.41 sq km; submerged - 6,937 sq km
Baker Island: total - 129 sq km; emergent land -
2.1 sq km; submerged - 127 sq km
Howland Island: total - 139 sq km; emergent land -
2.6 sq km; submerged - 136 sq km
Jarvis Island: total - 152 sq km; emergent land -
5 sq km; submerged - 147 sq km
Johnston Atoll: total - 276.6 sq km; emergent land -
2.6 sq km; submerged - 274 sq km
Kingman Reef: total - 1 ,958.01 sq km; emergent
land - 0.01 sq km; submerged - 1 ,958 sq km
Midway Islands: total - 2,355.2 sq km; emergent land -
6.2 sq km; submerged - 2,349 sq km
Palmyra Atoll: total - 1 ,949.9 sq km; emergent land -
3.9 sq km; submerged - 1,946 sq km
Area - comparative:
Baker Island: about two and a half times the size of
The Mall in Washington, DC
Howland Island: about three times the size of The Mall
in Washington, DC
Jarvis Island: about eight times the size of The Mall in
Washington, DC
Johnston Atoll: about four and a half times the size of
The Mall in Washington, DC
Kingman Reef: a little more than one and a half times
the size of The Mall in Washington, DC
Midway Islands: about nine times the size of The Mall
in Washington, DC
Palmyra Atoll: about 20 times the size of The Mall in
Washington, DC
Land boundaries: none
Coastline:
Baker Island: 4.8 km
Howland Island: 6.4 km
Jarvis Island: 8 km
Johnston Atoll: 34 km
Kingman Reef: 3 km
Midway Islands: 15 km
Palmyra Atoll: 14.5 km
Maritime claims:
territorial sea: 1 2 nm
exclusive economic zone: 200 nm
Climate:
Baker, Howland, and Jarvis Islands: equatorial; scant
rainfall, constant wind, burning sun
Johnston Atoll and Kingman Reef: tropical, but
generally dry; consistent northeast trade winds with
little seasonal temperature variation
Midway Islands: subtropical with cool, moist winters
(December to February) and warm, dry summers
(May to October); moderated by prevailing easterly
winds; most of the 1 ,067 mm (42 in) of annual rainfall
occurs during the winter
Palmyra Atoll: equatorial, hot; located within the low
pressure area of the Intertropical Convergence Zone
(ITCZ) where the northeast and southeast trade winds
meet, it is extremely wet with between 4,000-5,000 mm
(160-200 in) of rainfall each year
Terrain: low and nearly level sandy coral islands with
narrow fringing reefs that have developed at the top of
submerged volcanic mountains, which in most cases
rise steeply from the ocean floor
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Baker Island, unnamed location - 8 m;
Howland Island, unnamed location - 3 m; Jarvis
Island, unnamed location - 7 m; Johnston Atoll, Sand
Island -10 m; Kingman Reef, unnamed location - less
than 1 m; Midway Islands, unnamed location -13 m;
Palmyra Atoll, unnamed location - 2 m
Natural resources: terrestrial and aquatic wildlife
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (2005)
Natural hazards:
Baker, Howland, and Jarvis Islands: the narrow
fringing reef surrounding the island can be a maritime
hazard
Kingman Reef: wet or awash most of the time,
maximum elevation of less than 1 m makes Kingman
Reef a maritime hazard
Midway Islands, Johnston, and Palmyra Atolis: NA
Environment - current issues:
Baker, Howland, and Jarvis Islands, and Johnston
Atoll: no natural fresh water resources
Kingman Reef: none
Midway Islands and Palmyra Atoll: NA
Geography - note:
Baker. Howland, and Jarvis Islands: scattered
vegetation consisting of grasses, prostrate vines, and
low growing shrubs; primarily a nesting, roosting, and
foraging habitat for seabirds, shorebirds, and marine
wildlife
Johnston Atoll: Johnston Island and Sand Island are
natural islands, which have been expanded by coral
dredging; North Island (Akau) and East Island (Hikina)
are manmade islands formed from coral dredging; the
egg-shaped reef is 34 km in circumference
Kingman Reef: barren coral atoll with deep interior
lagoon; closed to the public
Midway Islands: a coral atoll managed as a national
wildlife refuge and open to the public for
wildlife-related recreation in the form of wildlife
observation and photography
Palmyra Atoll: the high rainfall and resulting lush
vegetation make the environment of this atoll unique
among the US Pacific Island territories; it supports one
of the largest remaining undisturbed stands of Pisonia
beach forest in the Pacific','2d6642e316acfc7b5a37eb23e079a71576fd94b7bdc45234ed5c29f00bd167c7','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b80d7d0108452fc441544f9b7b2eb35201f55cbd3d7ba5a1b789530f29ae400',2007,'CR','Costa Rica','geography',419,'Location: Central America, bordering both the
Caribbean Sea and the North Pacific Ocean, between
Nicaragua and Panama
Geographic coordinates: 10 00 N, 84 00 W
Map references: Central America and the Canbbean
Area:
total: 51,100 sq km
land: 50,660 sq km
water: 440 sq km
note: includes Isla del Coco
Area - comparative: slightly smaller than West
Virginia
Land boundaries:
total: 639 km
border countries: Nicaragua 309 km, Panama 330 km
Coastline: 1,290 km
Maritime claims:
territorial sea: 1 2 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm
Climate: tropical and subtropical; dry season
(December to April); rainy season (May to November);
cooler in highlands
Terrain: coastal plains separated by rugged
mountains including over 1 00 volcanic cones, of which
several are major volcanoes
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Cerro Chirripo 3,810 m
Natural resources: hydropower
Land use:
arable land: 4.4%
permanent crops: 5.87%
other: 89.73% (2005)
Irrigated land: 1 ,260 sq km (1 998 est.)
Natural hazards: occasional earthquakes, hurricanes
along Atlantic coast; frequent flooding of lowlands at
onset of rainy season and landslides; active volcanoes
Environment - current issues: deforestation and
land use change, largely a result of the clearing of land
for cattle ranching and agriculture; soil erosion;
coastal marine pollution; fisheries protection; solid
waste management; air pollution
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Wetlands, Whaling
signed, but not ratified: Marine Life Conservation
Geography - note: four volcanoes, two of them
active, rise near the capital of San Jose in the center
of the country; one of the volcanoes, Irazu, erupted
destructively in 1963-65
Location: Western Africa, bordering the North
Atlantic Ocean, between Ghana and Liberia
Geographic coordinates: 8 00 N, 5 00 W
Map references: Africa
140
Cote d''lvoire (continued)
Area:
total: 322,460 sq km
land: 318,000 sq km
water: 4,460 sq km
Area ■ comparative: slightly larger than New Mexico
Land boundaries:
total: 3,1 10 km
border countries: Burkina Faso 584 km, Ghana 668
km, Guinea 610 km, Liberia 716 km, Mali 532 km
Coastline: 515 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm
Climate: tropical along coast, semiarid in far north;
three seasons - warm and dry (November to March),
hot and dry (March to May), hot and wet (June to
October)
Terrain: mostly flat to undulating plains; mountains in
northwest
Elevation extremes:
lowest point: Gulf of Guinea 0 m
highest point: Mont Nimba 1 ,752 m
Natural resources: petroleum, natural gas,
diamonds, manganese, iron ore, cobalt, bauxite,
copper, gold, nickel, tantalum, silica sand, clay, cocoa
beans, coffee, palm oil, hydropower
Land use:
arable land: 10.23%
permanent crops: 11.1 6%
other: 78.61% (2005)
Irrigated land: 730 sq km (1998 est.)
Natural hazards: coast has heavy surf and no
natural harbors; during the rainy season torrential
flooding is possible
Environment ■ current issues: deforestation (most
of the country''s forests - once the largest in West
Africa - have been heavily logged); water pollution
from sewage and industrial and agricultural effluents
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: most of the inhabitants live along
the sandy coastal region; apart from the capital area,
the forested interior is sparsely populated
Location: Central America, bordering both the
Caribbean Sea and the North Pacific Ocean, between
Costa Rica and Honduras
Geographic coordinates: 13 00 N, 85 00 W
Map references: Central America and the
Caribbean
Area:
rote/. 1 29,494 sq km
land: 1 20,254 sq km
water: 9,240 sq km
Area • comparative: slightly smaller than the state of
New York
Land boundaries:
total: 1,231 km
border countries: Costa Rica 309 km, Honduras 922
km
Coastline: 910 km
404
Nicaragua (continued)
Maritime claims:
territorial sea: 200 nm
continental shelf: natural prolongation
Climate: tropical in lowlands, cooler in highlands
Terrain: extensive Atlantic coastal plains rising to
central interior mountains; narrow Pacific coastal plain
interrupted by volcanoes
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mogoton 2,438 m
Natural resources: gold, silver, copper, tungsten,
lead, zinc, timber, fish
Land use:
arable land: 14.81%
permanent crops: 1 .82%
other: 83.37% (2005)
Irrigated land: 880 sq km (1998 est.)
Natural hazards: destructive earthquakes,
volcanoes, landslides; extremely susceptible to
hurricanes
Environment - current issues: deforestation; soil
erosion; water pollution
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Environmental Modification
Geography • note: largest country in Central
America; contains the largest freshwater body in
Central America, Lago de Nicaragua','5a4e56d778eb7f2d824cf780483591aebe351f158327188cf5984ec20aa09d86','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0d2e77086b8bc953b97d2b4eb8231dbd3011fd11b281d042aa3cb4a539f929c',2007,'HR','Croatia','geography',427,'Location: Southeastern Europe, bordering the
Adriatic Sea, between Bosnia and Herzegovina and','dd25f49f3f904cfc69aed669a490fdf40878eb2b6589ed15c86f747c1783095e','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6b3dd0614c30b90719084a809b7249c567484507757e91a2da4bc807beeb326b',2007,'SI','Slovenia','geography',428,'Geographic coordinates: 45 10 N, 15 30 E
Map references: Europe
Area:
total: 56,542 sq km
land: 56,414 sq km
water: 128 sq km
Area - comparative: slightly smaller than West
Virginia
Land boundaries:
total: 2,197 km
border countries: Bosnia and Herzegovina 932 km,
Hungary 329 km, Serbia and Montenegro (north) 241
km, Serbia and Montenegro (south) 25 km, Slovenia
670 km
Coastline: 5,835 km (mainland 1,777 km, islands
4,058 km)
Maritime claims:
territorial sea: 12 nm
continental shelf: 200-m depth or to the depth of
exploitation
Climate: Mediterranean and continental; continental
climate predominant with hot summers and cold
winters; mild winters, dry summers along coast
Terrain: geographically diverse; flat plains along
Hungarian border, low mountains and highlands near
Adriatic coastline and islands
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Dinara 1 ,830 m
Natural resources: oil, some coal, bauxite,
low-grade iron ore, calcium, gypsum, natural asphalt,
silica, mica, clays, salt, hydropower
Land use:
arable land: 25.82%
permanent crops: 2. 1 9%
other: 71 .99% (2005)
Irrigated land: 30 sq km (1998 est.)
Natural hazards: destructive earthquakes
Environment - current issues: air pollution (from
metallurgical plants) and resulting acid rain is
damaging the forests; coastal pollution from industrial
and domestic waste; landmine removal and
reconstruction of infrastructure consequent to
1992-95 civil strife
Environment - international agreements:
party to: Air Pollution, Air Pollution-Sulfur 94,
Biodiversity, Climate Change, Desertification,
Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Climate Change-Kyoto Protocol
Geography - note: controls most land routes from
Western Europe to Aegean Sea and Turkish Straits','6094bd575dce8a1d67b1e3c69ffde0e7b59b75619f4d5c97eaaebad74e18b61a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('50c13b16225cd82a2aad32297fa1919bcf47597988847f2a2d5f6b01897cf770',2007,'HT','Haiti','geography',439,'Location: Caribbean, island between the Caribbean
Sea and the North Atlantic Ocean, 150 km south of
Key West, Florida
Geographic coordinates: 21 30 N, 80 00 W
Map references: Central America and the
Caribbean
Area:
total: 110,860 sq km
land: 110,860 sq km
water: 0 sq km
Area - comparative: slightly smaller than
Pennsylvania
Land boundaries:
total: 29 km
border countries: US Naval Base at Guantanamo Bay
29 km
note: Guantanamo Naval Base is leased by the US
and remains part of Cuba
Coastline: 3,735 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; moderated by trade winds; dry
season (November to April); rainy season (May to
October)
Terrain: mostly flat to rolling plains, with rugged hills
and mountains in the southeast
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Pico Turquino 2,005 m
Natural resources: cobalt, nickel, iron ore,
chromium, copper, salt, timber, silica, petroleum,
arable land
Land use:
arable land: 27.63°o
permanent crops: 6.54°0
ofner; 65.83°o (2005)
Irrigated land: 870 sq km (1998 est.)
Natural hazards: the east coast is subject to
hurricanes from August to November (in general, the
country averages about one hurricane every other
year); droughts are common
Environment - current issues: air and water
pollution; biodiversity loss; deforestation
Environment - international agreements:
party to: Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
Geography • note: largest country in Caribbean and
westernmost island of the Greater Antilles
Location: Caribbean, western one-third of the island
of Hispaniola, between the Caribbean Sea and the
North Atlantic Ocean, west of the Dominican Republic
Geographic coordinates: 19 00 N, 72 25 W
Map references: Central America and the
Caribbean
Area:
total: 27,750 sq km
land: 27,560 sq km
water: 190 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries:
total: 360 km
border countries: Dominican Republic 360 km
Coastline: 1,771 km
Maritime claims:
territorial sea: 1 2 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: to depth of exploitation
Climate: tropical; semiarid where mountains in east
cut off trade winds
Terrain: mostly rough and mountainous
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Chaine de la Selle 2,680 m
Natural resources: bauxite, copper, calcium
carbonate, gold, marble, hydropower
Land use:
arable land: 28.11%
permanent crops: 1 1 .53%
other: 60.36% (2005)
Irrigated land: 750 sq km (1998 est.)
Natural hazards: lies in the middle of the hurricane
belt and subject to severe storms from June to
October; occasional flooding and earthquakes;
periodic droughts
Environment • current issues: extensive
deforestation (much of the remaining forested land is
being cleared for agriculture and used as fuel); soil
erosion; inadequate supplies of potable water
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Law of the Sea, Marine Dumping,
Marine Life Conservation, Ozone Layer Protection
signed, but not ratified: Hazardous Wastes
Geography - note: shares island of Hispaniola with
Dominican Republic (western one-third is Haiti.
eastern two-thirds is the Dominican Republic)
Location: islands in the Indian Ocean, about
two-thirds of the way from Madagascar to Antarctica
Geographic coordinates: 53 06 S, 72 31 E
Map references: Antarctic Region
Area:
tofa/:412sq km
land: 412 sq km
water: 0 sq km
Area - comparative: slightly more than two times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 101.9 km
Maritime claims:
territorial sea: 12 nm
exclusive fishing zone: 200 nm
Climate: antarctic
Terrain: Heard Island - 80% ice-covered, bleak and
mountainous, dominated by a large massif (Big Ben)
and an active volcano (Mawson Peak); McDonald
Islands - small and rocky
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Mawson Peak, on Big Ben 2,745 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (2005)
248
Heard Island and McDonald
Islands (continued)
Irrigated land: 0 sq km
Natural hazards: Mawson Peak, an active volcano,
is on Heard Island
Environment - current issues: NA','da448546e40d271536fada798ee2985fe49549654b85140bfb5af713af088c2a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e58ea3554c0cae4cef697b3d25676b0078faad390232762e9a4c20585d86fb80',2007,'CY','Cyprus','geography',448,'Location: Middle East, island in the Mediterranean
Sea, south of Turkey
Geographic coordinates: 35 00 N, 33 00 E
Map references: Middle East
Area:
total: 9,250 sq km (of which 3,355 sq km are in north
Cyprus)
land: 9,240 sq km
wafer: 1 0 sq km
Area - comparative: about 0.6 times the size of
Connecticut
Land boundaries:
total: NA; note - boundary with Dhekelia is being
resurveyed
border countries: Akrotiri 47.4 km, Dhekelia NA
Coastline: 648 km
Maritime claims:
territorial sea: 12 nm
continental shelf: 200-m depth or to the depth of
exploitation
Climate: temperate; Mediterranean with hot, dry
summers and cool winters
Terrain: central plain with mountains to north and
south; scattered but significant plains along southern
coast
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Mount Olympus 1 ,951 m
Natural resources: copper, pyrites, asbestos,
gypsum, timber, salt, marble, clay earth pigment
Land use:
arable land: 10.81%
permanent crops: 4.32%
other 84.87% (2005)
Irrigated land: 382 sq km (2001 est.)
Natural hazards: moderate earthquake activity;
droughts
Environment - current issues: water resource
problems (no natural reservoir catchments, seasonal
disparity in rainfall, sea water intrusion to island''s
largest aquifer, increased salination in the north);
water pollution from sewage and industrial wastes;
coastal degradation; loss of wildlife habitats from
urbanization
Environment - international agreements:
party to: Air Pollution, Air Pollution-Persistent Organic
Pollutants, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: the third largest island in the
Mediterranean Sea (after Sicily and Sardinia)
Location: Central Europe, southeast of Germany
Geographic coordinates: 49 45 N, 15 30 E
Map references: Europe
Area:
total: 78,866 sq km
land: 77,276 sq km
water: 1 ,590 sq km
Area - comparative: slightly smaller than South
Carolina
Land boundaries:
total: 1,881 km
border countries: Austria 362 km, Germany 646 km,
Poland 658 km, Slovakia 215 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cool summers; cold, cloudy,
humid winters
Terrain: Bohemia in the west consists of rolling
plains, hills, and plateaus surrounded by low
mountains; Moravia in the east consists of very hilly
country
Elevation extremes:
lowest point: Elbe River 115 m
highest point: Snezka 1 ,602 m
Natural resources: hard coal, soft coal, kaolin, clay,
graphite, timber
Land use:
arable land: 38.82%
permanent crops: 3%
other: 58.1 8% (2005)
Irrigated land: 240 sq km (1998 est.)
Natural hazards: flooding
Environment - current issues: air and water
pollution in areas of northwest Bohemia and in
northern Moravia around Ostrava present health risks;
acid rain damaging forests; efforts to bring industry up
to EU code should improve domestic pollution
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulfur 85, Air Pollution-Sulfur 94, Air
Pollution-Volatile Organic Compounds, Antarctic
Treaty, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked; strategically located
astride some of oldest and most significant land routes
in Europe; Moravian Gate is a traditional military
corridor between the North European Plain and the
Danube in central Europe','445c33bac93ea19ea0db360b57389115b5613bf2534e875612aa5ba6a3da035a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a75ff5578333252bba0fec1d145456780b8b89306b6dc8454952c1a6836a5c0c',2007,'DK','Denmark','geography',456,'Location: Northern Europe, bordering the Baltic Sea
and the North Sea, on a peninsula north of Germany
(Jutland); also includes two major islands (Sjaelland
and Fyn)
Geographic coordinates: 56 00 N, 10 00 E
Map references: Europe
Area:
total: 43,094 sq km
land: 42,394 sq km
water: 700 sq km
note: includes the island of Bornholm in the Baltic Sea
and the rest of metropolitan Denmark (the Jutland
Peninsula, and the major islands of Sjaelland and
Fyn), but excludes the Faroe Islands and Greenland
Area - comparative: slightly less than twice the size
of Massachusetts
Land boundaries:
total: 68 km
border countries: Germany 68 km
Coastline: 7,314 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200-m depth or to the depth of
exploitation
Climate: temperate; humid and overcast; mild, windy
winters and cool summers
Terrain: low and flat to gently rolling plains
Elevation extremes:
lowest point: Lammefjord -7 m
highest point: Y ding Skovhoej 173 m
Natural resources: petroleum, natural gas, fish,
salt, limestone, chalk, stone, gravel and sand
Land use:
arable land: 52.59%
permanent crops: 0. 1 9%
other: 47.22% (2005)
Irrigated land: 4,760 sq km (1998 est.)
Natural hazards: flooding is a threat in some areas
of the country (e.g., parts of Jutland, along the
southern coast of the island of Lolland) that are
protected from the sea by a system of dikes
Environment - current issues: air pollution,
principally from vehicle and power plant emissions;
nitrogen and phosphorus pollution of the North Sea;
drinking and surface water becoming polluted from
animal wastes and pesticides
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides, Air
Pollution-Persistent Organic Pollutants, Air
Pollution-Sulfur 85, Air Pollution-Sulfur 94, Air
Pollution- Volatile Organic Compounds, Antarctic Treaty,
Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law of
the Sea, Marine Dumping, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution, Tropical Timber
83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography ■ note: controls Danish Straits
(Skagerrak and Kattegat) linking Baltic and North
Seas; about one-quarter of the population lives in
greater Copenhagen
Location: on the southeast coast of Cyprus near
Famagusta
Geographic coordinates: 34 59 N, 33 45 E
Map references: Middle East
Area:
total: 130.8 sq km
note: area surrounds three Cypriot enclaves
Area - comparative: about three-quarters the size of
Washington, DC
Land boundaries:
total: NA; note - boundary with Cyprus is being
resurveyed
Coastline: 27.5 km
Climate: temperate; Mediterranean with hot, dry
summers and cool winters
Environment - current issues: netting and trapping
of small migrant songbirds in the spring and autumn
Geography • note: British extraterritorial rights also
extended to several small off-post sites scattered
across Cyprus
Location: Northern North America, island between
the Arctic Ocean and the North Atlantic Ocean,
northeast of Canada
Geographic coordinates: 72 00 N, 40 00 W
Map references: Arctic Region
Area:
to/a/:2,166,086sqkm
land: 2,166,086 sq km (410,449 sq km ice-free,
1,755,637 sq km ice-covered) (2000 est.)
Area - comparative: slightly more than three times
the size of Texas
Land boundaries: 0 km
Coastline: 44,087 km
Maritime claims:
territorial sea: 3 nm
continental shelf: 200 nm or agreed boundaries or
median line
exclusive fishing zone: 200 nm or agreed boundaries
or median line
Climate: arctic to subarctic; cool summers, cold
winters
Terrain: flat to gradually sloping icecap covers all but
a narrow, mountainous, barren, rocky coast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Gunnbjorn 3,700 m
Natural resources: coal, iron ore, lead, zinc,
molybdenum, gold, platinum, uranium, fish, seals,
whales, hydropower, possible oil and gas
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: NA
Natural hazards: continuous permafrost over
northern two-thirds of the island
Environment • current issues: protection of the
arctic environment; preservation of the Inuit traditional
way of life, including whaling and seal hunting
Geography ■ note: dominates North Atlantic Ocean
between North America and Europe; sparse
population confined to small settlements along coast,
but close to one-quarter of the population lives in the
capital, Nuuk; world''s second largest ice cap','526e0c4222e001092e98d5bcd9b9740dc2773a86014ca3a5847f6dba802ba39b','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3b842f06a2a77a19fef8654c3c84ae17d8817e9b90878f4c3f6af6e746a3bc6d',2007,'DJ','Djibouti','geography',465,'Location: Eastern Africa, bordering the Gulf of Aden
and the Red Sea, between Eritrea and Somalia
Geographic coordinates: 1 1 30 N, 43 00 E
Map references: Africa
Area:
total: 23,000 sq km
land: 22,980 sq km
water: 20 sq km
Area - comparative: slightly smaller than
Massachusetts
Land boundaries:
tofa/:516km
border countries: Eritrea 109 km, Ethiopia 349 km,
Somalia 58 km
Coastline: 314 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: desert; torrid, dry
Terrain: coastal plain and plateau separated by
central mountains
Elevation extremes:
lowest point: Lac Assal -155 m
highest point: Moussa Ali 2,028 m
Natural resources: geothermal areas, gold, clay,
granite, limestone, marble, salt, diatomite, gypsum,
pumice, petroleum
Land use:
arable land: 0.04%
permanent crops: 0%
other: 99.96% (2005)
Irrigated land: 10 sq km (1998 est.)
Natural hazards: earthquakes; droughts; occasional
cyclonic disturbances from the Indian Ocean bring
heavy rains and flash floods
Environment - current issues: inadequate supplies
of potable water; limited arable land; desertification;
endangered species
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location near world''s
busiest shipping lanes and close to Arabian oilfields;
terminus of rail traffic into Ethiopia; mostly wasteland;
Lac Assal (Lake Assal) is the lowest point in Africa
Location: Caribbean, island between the Caribbean
Sea and the North Atlantic Ocean, about one-half of
the way from Puerto Rico to Trinidad and Tobago
Geographic coordinates: 15 25 N, 61 20 W
Map references: Central America and the
Caribbean
Area:
total: 754 sq km
land: 754 sq km
water: 0 sq km
Area - comparative: slightly more than four times
the size of Washington, DC
Land boundaries: 0 km
Coastline: 148 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical; moderated by northeast trade
winds; heavy rainfall
Terrain: rugged mountains of volcanic origin
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Morne Diablatins 1 ,447 m
160
Dominica (continued)
Natural resources: timber, hydropower, arable land
Land use:
arable land: 6.67%
permanent crops: 21 .33%
other: 72% (2005)
Irrigated land: NA sq km
Natural hazards: flash floods are a constant threat;
destructive hurricanes can be expected during the late
summer months
Environment ■ current issues: NA
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Ship Pollution, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: known as "The Nature Island of
the Caribbean" due to its spectacular, lush, and varied
flora and fauna, which are protected by an extensive
natural park system; the most mountainous of the
Lesser Antilles, its volcanic peaks are cones of lava
craters and include Boiling Lake, the second-largest,
thermally active lake in the world','305c4fb6a5f49844691418fa4db48b2c7fe176f1b36e6dbb24b1f95c2aecf89f','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4c38be451d6b1ff2a6147472ab6139923056eeebb047e412b1029d744c88352d',2007,'DO','Dominican Republic','geography',479,'Location: Caribbean, eastern two-thirds of the island
of Hispaniola, between the Caribbean Sea and the
North Atlantic Ocean, east of Haiti
162
Dominican Republic (continued)
Geographic coordinates: 1 9 00 N, 70 40 W
Map references: Central America and the
Caribbean
Area:
total: 48,730 sq km
land: 48,380 sq km
water: 350 sq km
Area - comparative: slightly more than twice the
size of New Hampshire
Land boundaries:
total: 360 km
border countries: Haiti 360 km
Coastline: 1,288 km
Maritime claims:
territorial sea: 6 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: tropical maritime; little seasonal
temperature variation; seasonal variation in rainfall
Terrain: rugged highlands and mountains with fertile
valleys interspersed
Elevation extremes:
lowest point: Lago Enriquillo -46 m
highest point: Pico Duarte 3,175 m
Natural resources: nickel, bauxite, gold, silver
Land use:
arable land: 22.49%
permanent crops: 10.26%
other: 67.25% (2005)
Irrigated land: 2,590 sq km (1998 est.)
Natural hazards: lies in the middle of the hurricane
belt and subject to severe storms from June to
October; occasional flooding; periodic droughts
Environment - current issues: water shortages;
soil eroding into the sea damages coral reefs;
deforestation
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Marine Dumping,
Marine Life Conservation, Ozone Layer Protection,
Ship Pollution
signed, but not ratified: Law of the Sea
Geography - note: shares island of Hispaniola with
Geographic coordinates: 18 15 N, 66 30 W
Map references: Central America and the
Caribbean
Area:
total: 9,104 sq km
land: 8,959 sq km
wafer: 145 sq km
Area - comparative: slightly less than three times
the size of Rhode Island
Land boundaries: 0 km
Coastline: 501 km
Maritime claims:
territorial sea: 1 2 nm
exclusive economic zone: 200 nm
Climate: tropical marine, mild; little seasonal
temperature variation
Terrain: mostly mountains with coastal plain belt in
north; mountains precipitous to sea on west coast;
sandy beaches along most coastal areas
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Cerro de Punta 1 ,338 m
Natural resources: some copper and nickel;
potential for onshore and offshore oil
Land use:
arable land: 3.69%
permanent crops: 5.59%
other: 90.72% (2005)
Irrigated land: 400 sq km (1998 est.)
Natural hazards: periodic droughts; hurricanes
Environment - current issues: erosion; occasional
drought causing water shortages
Geography ■ note: important location along the
Mona Passage - a key shipping lane to the Panama
Canal; San Juan is one of the biggest and best natural
harbors in the Caribbean; many small rivers and high
central mountains ensure land is well watered; south
coast relatively dry; fertile coastal plain belt in north','14cf103d65bfb92d8bc13c8e3331fb8fbc153295dd527af8ea51da8937ee144b','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c191602deae8bf3f06814593770b9a4eec8d4ce187c2abaa67323be85ca8ff1',2007,'EC','Ecuador','geography',482,'Location: Western South America, bordering the
Pacific Ocean at the Equator, between Colombia and','6f81f4caf710e1a80364348cc3688b4555fbaf0835db1d4b6e3deaaf7c758e31','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f34c4fbf85271f6e4d5593e93d604664302d70887609404e40829c0d2a0f719',2007,'PE','Peru','geography',483,'Geographic coordinates: 2 00 S, 77 30 W
Map references: South America
Area:
total: 283,560 sq km
land: 276,840 sq km
water: 6,720 sq km
note: includes Galapagos Islands
Area - comparative: slightly smaller than Nevada
Land boundaries:
total: 2,01 0 km
border countries: Colombia 590 km, Peru 1 ,420 km
Coastline: 2,237 km
Maritime claims:
territorial sea: 200 nm
continental shelf: 1 00 nm from 2,500 meter isobath
Climate: tropical along coast, becoming cooler
inland at higher elevations; tropical in Amazonian
jungle lowlands
Terrain: coastal plain (costa), inter-Andean central
highlands (sierra), and flat to rolling eastern jungle
(oriente)
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Chimborazo 6,267 m
Natural resources: petroleum, fish, timber,
hydropower
Land use:
arable land: 5 .71%
permanent crops: 4.81 %
ofher: 89.48% (2005)
Irrigated land: 8,650 sq km (1998 est.)
Natural hazards: frequent earthquakes, landslides,
volcanic activity; floods; periodic droughts
Environment - current issues: deforestation; soil
erosion; desertification; water pollution; pollution from
oil production wastes in ecologically sensitive areas of
the Amazon Basin and Galapagos Islands
Environment - international agreements:
party to: Antarctic-Environmental Protocol, Antarctic
Treaty, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber
94, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: Cotopaxi in Andes is highest
active volcano in world
Location: Northern Africa, bordering the
Mediterranean Sea, between Libya and the Gaza
Strip, and the Red Sea north of Sudan, and includes
the Asian Sinai Peninsula
Geographic coordinates: 27 00 N, 30 00 E
Map references: Africa
Area:
total: 1,001,450 sq km
land: 995,450 sq km
water: 6,000 sq km
Area - comparative: slightly more than three times
the size of New Mexico
Land boundaries:
total: 2,665 km
border countries: Gaza Strip 1 1 km, Israel 266 km,
Libya 1 , 1 1 5 km, Sudan 1 ,273 km
Coastline: 2,450 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200-m depth or to the depth of
exploitation
Climate: desert; hot, dry summers with moderate
winters
Terrain: vast desert plateau interrupted by Nile valley
and delta
Elevation extremes:
lowest point: Qattara Depression -133 m
highest point: Mount Catherine 2,629 m
Natural resources: petroleum, natural gas, iron ore,
phosphates, manganese, limestone, gypsum, talc,
asbestos, lead, zinc
Land use:
arable land: 2.92%
permanent crops: 0.5%
other: 96.58% (2005)
Irrigated land: 33,000 sq km (1998 est.)
Natural hazards: periodic droughts; frequent
earthquakes, flash floods, landslides; hot, driving
windstorm called khamsin occurs in spring; dust
storms, sandstorms
Environment - current issues: agricultural land
being lost to urbanization and windblown sands;
increasing soil salination below Aswan High Dam;
desertification; oil pollution threatening coral reefs,
beaches, and marine habitats; other water pollution
from agricultural pesticides, raw sewage, and
industrial effluents; very limited natural fresh water
resources away from the Nile, which is the only
perennial water source; rapid growth in population
overstraining the Nile and natural resources
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: controls Sinai Peninsula, only
land bridge between Africa and remainder of Eastern
Hemisphere; controls Suez Canal, a sea link between
Indian Ocean and Mediterranean Sea; size, and
juxtaposition to Israel, establish its major role in
Middle Eastern geopolitics; dependence on upstream
neighbors; dominance of Nile basin issues; prone to
influxes of refugees','260204b3fdaeb702a0969cbabcd4e74ab00e92d08c71914a6af7e5fae675a621','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5950c3f223b10ca6a454291a5e58b938a3fa0c2ee98b1b883cb9a9ebbea2efe8',2007,'SV','El Salvador','geography',493,'Location: Central America, bordering the North
Pacific Ocean, between Guatemala and Honduras
Geographic coordinates: 13 50 N, 88 55 W
Map references: Central America and the
Caribbean
Area:
total: 21 ,040 sq km
land: 20,720 sq km
water: 320 sq km
Area - comparative: slightly smaller than
Massachusetts
Land boundaries:
total: 545 km
border countries: Guatemala 203 km, Honduras 342
km
Coastline: 307 km
Maritime claims:
territorial sea: 200 nm
Climate: tropical; rainy season (May to October); dry
season (November to April); tropical on coast;
temperate in uplands
Terrain: mostly mountains with narrow coastal belt
and central plateau
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Cerro El Pital 2,730 m
Natural resources: hydropower, geothermal power,
petroleum, arable land
Land use:
arable land: 31.37%
permanent crops: 1 1 .88°o
other: 56.75% (2005)
Irrigated land: 360 sq km (1998 est.)
Natural hazards: known as the Land of Volcanoes;
frequent and sometimes destructive earthquakes and
volcanic activity; extremely susceptible to hurricanes
Environment - current issues: deforestation: soil
erosion; water pollution; contamination of soils from
disposal of toxic wastes
Environment - international agreements:
party to: Biodiversity. Climate Change, Climate
Change-Kyoto Protocol. Desertification, Endangered
Species, Hazardous Wastes. Ozone Layer Protection.
Wetlands
signed, but not ratified: Law of the Sea
Geography - note: smallest Central American
country and only one without a coastline on Caribbean
Sea','6cd3c1dfc9ba3fd1faaa4aece0c8eca4100572a31b4befa20996685cc05e414d','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fcc2faaf73c9d3db34c9808a5506973b7b0104eb8712e11ed62aa02800410367',2007,'GA','Gabon','geography',503,'Location: Western Africa, bordering the Bight of
Biafra, between Cameroon and Gabon
Geographic coordinates: 2 00 N, 10 00 E
Map references: Africa
Area:
total: 28,051 sq km
land: 28,051 sqkm
water: 0 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries:
total: 539 km
border countries: Cameroon 189 km, Gabon 350 km
176
Equatorial Guinea (continued)
Coastline: 296 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; always hot, humid
Terrain: coastal plains rise to interior hills; islands
are volcanic
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pico Basile 3,008 m
Natural resources: petroleum, natural gas, timber,
gold, bauxite, diamonds, tantalum, sand and gravel,
clay
Land use:
arable land: 4.63%
permanent crops: 3.57%
other: 91 .8% (2005)
Irrigated land: NA sq km
Natural hazards: violent windstorms, flash floods
Environment - current issues: tap water is not
potable; deforestation
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Ship
Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: insular and continental regions
widely separated','f6a807983d1a750f13d71e27935697894e35f3cf0e6552f4d0e1a5522f2f1753','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e532b10fc16bbed79723875b107429b0213d49330a59210703d19e35160ae898',2007,'ER','Eritrea','geography',512,'Location: Eastern Africa, bordering the Red Sea,
between Djibouti and Sudan
Geographic coordinates: 15 00 N, 39 00 E
Map references: Africa
Area:
total: 121,320 sq km
land: 121 ,320 sq km
water: 0 sq km
Area - comparative: slightly larger than
Pennsylvania
Land boundaries:
total: 1,626 km
border countries: Djibouti 109 km. Ethiopia 912 km,
Sudan 605 km
Coastline: 2,234 km (mainland on Red Sea 1,151
km, islands in Red Sea 1,083 km)
Maritime claims:
territorial sea: 12 nm
Climate: hot, dry desert strip along Red Sea coast;
cooler and wetter in the central highlands (up to 61 cm
of rainfall annually, heaviest June to September);
semiarid in western hills and lowlands
Terrain: dominated by extension of Ethiopian
north-south trending highlands, descending on the
east to a coastal desert plain, on the northwest to hilly
terrain and on the southwest to flat-to-rolling plains
Elevation extremes:
lowest point: near Kulul within the Denakil depression
-75 m
highest point: Soira 3,018 m
Natural resources: gold, potash, zinc, copper, salt,
possibly oil and natural gas, fish
Land use:
arable land: 4.78%
permanent crops: 0.03%
other: 95. 19% (2005)
Irrigated land: 220 sq km (1998 est.)
Natural hazards: frequent droughts; locust swarms
Environment - current issues: deforestation;
desertification; soil erosion; overgrazing; loss of
infrastructure from civil warfare
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species
signed, but not ratified: none of the selected
agreements
Geography • note: strategic geopolitical position
along world''s busiest shipping lanes; Eritrea retained
the entire coastline of Ethiopia along the Red Sea
upon de jure independence from Ethiopia on 24 May
1993','c11a1aa6eb6aed3eeedf9064021615ec4a797459ce48684d8a0e052000974ab9','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5510f0dc6e37410e4e9e28caafdb59f708a39c843b2431bcdf941bd3b03a6ce',2007,'ET','Ethiopia','geography',529,'Location: Eastern Africa, west of Somalia
Geographic coordinates: 8 00 N, 38 00 E
Map references: Africa
Area:
total: 1,127,127 sq km
land: 1,1 19,683 sq km
water: 7.444 sq km
Area - comparative: slightly less than twice the size
of Texas
Land boundaries:
total: 5,328 km
border countries: Djibouti 349 km, Eritrea 912 km,
Kenya 861 km, Somalia 1,600 km, Sudan 1,606 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical monsoon with wide
topographic-induced variation
Terrain: high plateau with central mountain range
divided by Great Rift Valley
Elevation extremes:
lowest point: Denakil Depression -125 m
highest point: Ras Dejen 4,620 m
Natural resources: small reserves of gold, platinum,
copper, potash, natural gas, hydropower
Land use:
arable land: 10.01%
permanent crops: 0.65%
other: 89.34% (2005)
Irrigated land: 1,900 sq km (1998 est.)
Natural hazards: geologically active Great Rift
Valley susceptible to earthquakes, volcanic eruptions;
frequent droughts
Environment - current issues: deforestation;
overgrazing; soil erosion; desertification; water
shortages in some areas from water-intensive farming
and poor management
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Ozone Layer Protection
signed, but not ratified: Environmental Modification,
Law of the Sea
Geography - note: landlocked - entire coastline
along the Red Sea was lost with the de jure
independence of Eritrea on 24 May 1993; the Blue
Nile, the chief headstream of the Nile by water volume,
rises in T''ana Hayk (Lake Tana) in northwest Ethiopia;
three major crops are believed to have originated in
Ethiopia: coffee, grain sorghum, and castor bean','41819d36fcbc0ba6fbb443d6ec103f5f91afc854d6c46bb1b3e51f8af58646a2','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d8b64d0c8192e2dc09ca69eb53fa7704f19263394bb2fa6b6d54b2e44d5ed134',2007,'MZ','Mozambique','geography',538,'Location: Southern Africa, island in the Mozambique
Channel, about half way between southern
Madagascar and southern Mozambique
Geographic coordinates: 22 20 S, 40 22 E
Map references: Africa
Area:
total: 28 sq km
land: 28 sq km
water: 0 sq km
Area • comparative: about 0.16 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 22.2 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical
Terrain: low and flat
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 24 m
Natural resources: NEGL
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (mangrove forests and woodlands)
(2005)
Irrigated land: Osq km (1998 est.)
Natural hazards: NA
Environment - current issues: NA
Geography - note: wildlife sanctuary
Location: Southern Africa, island in the Mozambique
Channel, about one-third of the way between
Madagascar and Mozambique
Geographic coordinates: 17 03 S, 42 45 E
Map references: Africa
Area:
total: 4.4 sq km
land: 4.4 sq km
water: 0 sq km
Area - comparative: about seven times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 24.1 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200-m depth or to the depth of
exploitation
Climate: tropical
Terrain: low and flat
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 10 m
Natural resources: guano deposits and other
fertilizers
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (90% forest) (2005)
295
Juan de Nova Island (continued)
Irrigated land: Osq km (1998 est.)
Natural hazards: periodic cyclones
Environment - current issues: NA
Geography • note: wildlife sanctuary
Location: Southern Africa, island in the Indian
Ocean, east of Mozambique
Geographic coordinates: 20 00 S, 47 00 E
Map references: Africa
Area:
total: 587,040 sq km
land: 581 ,540 sq km
water: 5,500 sq km
341
Madagascar (continued)
Area - comparative: slightly less than twice the size
of Arizona
Land boundaries: 0 km
Coastline: 4,828 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or 100 nm from the 2,500-m
deep isobath
Climate: tropical along coast, temperate inland, arid
in south
Terrain: narrow coastal plain, high plateau and
mountains in center
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Maromokotro 2,876 m
Natural resources: graphite, chromite, coal,
bauxite, salt, quartz, tar sands, semiprecious stones,
mica, fish, hydropower
Land use:
arable land: 5.03%
permanent crops: 1 .02%
other: 93.95% (2005)
Irrigated land: 10,900 sq km (2000 est.)
Natural hazards: periodic cyclones, drought, and
locust infestation
Environment - current issues: soil erosion results
from deforestation and overgrazing; desertification;
surface water contaminated with raw sewage and
other organic wastes; several endangered species of
flora and fauna unique to the island
Environment • international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Life Conservation, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography • note: world''s fourth-largest island;
strategic location along Mozambique Channel
Location: Eastern Africa, bordering the Indian
Ocean, between Kenya and Mozambique
Geographic coordinates: 6 00 S, 35 00 E
Map references: Africa
Area:
total: 945,087 sq km
land: 886,037 sq km
water: 59,050 sq km
note: includes the islands of Mafia, Pemba, and
Zanzibar
Area - comparative: slightly larger than twice the
size of California
Land boundaries:
total: 3,861 km
border countries: Burundi 451 km, Democratic
Republic of the Congo 459 km, Kenya 769 km, Malawi
475 km, Mozambique 756 km, Rwanda 217 km,
Uganda 396 km, Zambia 338 km
Coastline: 1,424 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: varies from tropical along coast to
temperate in highlands
Terrain: plains along coast; central plateau;
highlands in north, south
542
Tanzania (continued)
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Kilimanjaro 5,895 m
Natural resources: hydropower, tin, phosphates, iron
ore, coal, diamonds, gemstones, gold, natural gas, nickel
Land use:
arable land: 4.23%
permanent crops: 1 . 1 6%
9ther 94.61% (2005)
Irrigated land: 1 ,550 sq km (1998 est.)
Natural hazards: flooding on the central plateau
during the rainy season; drought
Environment - current issues: soil degradation;
deforestation; desertification; destruction of coral
reefs threatens marine habitats; recent droughts
affected marginal agriculture; wildlife threatened by
illegal hunting and trade, especially for ivory
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: Kilimanjaro is highest point in
Africa; bordered by three of the largest lakes on the
continent: Lake Victoria (the world''s second-largest
freshwater lake) in the north, Lake Tanganyika (the
world''s second deepest) in the west, and Lake Nyasa
in the southwest','89655ee741696559066962f3801967428bfcb35856a965ed6a6e57e7eff7e20a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4f72a34fd9332a2d8bec7c2cfc914c9f54e6ad62ef5a28ab06fe2ad2ae6cfcf',2007,'FJ','Fiji','geography',554,'Location: Oceania, island group in the South Pacific
Ocean, about two-thirds of the way from Hawaii to','e4bf86faedb95c188cd8b877abaff33408d71932965d126d08fa01fe98478278','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb380d09243fc4eb51f1d84bf70179aa313b41ea87abfd36da6cea91017abbef',2007,'JE','Jersey','geography',555,'Land boundaries: 0 km
Coastline: 1,129 km
Maritime claims: measured from claimed
archipelagic straight baselines
territorial sea: 1 2 nm
exclusive economic zone: 200 nm
continental shelf: 200-m depth or to the depth of
exploitation; rectilinear shelf claim added
Climate: tropical marine; only slight seasonal
temperature variation
Terrain: mostly mountains of volcanic origin
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Tomanivi 1,324 m
Natural resources: timber, fish, gold, copper,
offshore oil potential, hydropower
Land use:
arable land: 10.95%
permanent crops: 4.65%
other: 84.4% (2005)
Irrigated land: 30 sq km (1998 est.)
Natural hazards: cyclonic storms can occur from
November to January
Environment - current issues: deforestation; soil
erosion
Environment • international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Law of the Sea, Marine Life Conservation,
Ozone Layer Protection, Tropical Timber 83, Tropical
Timber 94
signed, but not ratified: none of the selected
agreements
Geography - note: includes 332 islands;
approximately 110 are inhabited
Land boundaries:
total: 1,017 km
border countries: Egypt 266 km, Gaza Strip 51 km,
Jordan 238 km, Lebanon 79 km, Syria 76 km, West
Bank 307 km
Coastline: 273 km
Maritime claims:
territorial sea: 12 nm
continental shelf: to depth of exploitation
Climate: temperate; hot and dry in southern and
eastern desert areas
Terrain: Negev desert in the south; low coastal plain;
central mountains; Jordan Rift Valley
Elevation extremes:
lowest point: Dead Sea -408 m
highest point: Har Meron 1 ,208 m
Natural resources: timber, potash, copper ore,
natural gas, phosphate rock, magnesium bromide,
clays, sand
Land use:
arable land: 15.45%
permanent crops: 3.88%
other: 80.67% (2005)
Irrigated land: 1 ,990 sq km (1 998 est.)
Natural hazards: sandstorms may occur during
spring and summer; droughts; periodic earthquakes
Environment - current issues: limited arable land
and natural fresh water resources pose serious
constraints; desertification; air pollution from industrial
and vehicle emissions; groundwater pollution from
industrial and domestic waste, chemical fertilizers,
and pesticides
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
Geography - note: there are 242 Israeli settlements
and civilian land use sites in the West Bank, 42 in the
Israeli-occupied Golan Heights, 0 in the Gaza Strip,
and 29 in East Jerusalem (August 2005 est.); Sea of
Galilee is an important freshwater source
Land boundaries:
total: 462 km
border countries: Iraq 240 km, Saudi Arabia 222 km
Coastline: 499 km
Maritime claims:
territorial sea: 12 nm
Climate: dry desert; intensely hot summers; short,
cool winters
Terrain: flat to slightly undulating desert plain
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: unnamed location 306 m
Natural resources: petroleum, fish, shrimp, natural
gas
Land use:
arable land: 0.84%
permanent crops: 0.17%
other: 98.99% (2005)
309
Kuwait (continued)
Irrigated land: 60 sq km (1 998 est.)
Natural hazards: sudden cloudbursts are common
from October to April and bring heavy rain, which can
damage roads and houses; sandstorms and dust
storms occur throughout the year, but are most
common between March and August
Environment - current issues: limited natural fresh
water resources; some of world''s largest and most
sophisticated desalination facilities provide much of
the water; air and water pollution; desertification
Environment • international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection
signed, but not ratified: Marine Dumping
Geography - note: strategic location at head of
Persian Gulf
Land boundaries: 0 km
Coastline: 2,254 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; modified by southeast trade winds;
hot, humid
Terrain: coastal plains with interior mountains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mont Panie 1 ,628 m
Natural resources: nickel, chrome, iron, cobalt,
manganese, silver, gold, lead, copper
Land use:
arable land: 0.32%
permanent crops: 0.22%
other: 99.46% (2005)
Irrigated land: 160 sq km (1991)
Natural hazards: cyclones, most frequent from
November to March
Environment - current issues: erosion caused by
mining exploitation and forest fires
Geography • note: consists of the main island of
New Caledonia (one of the largest in the Pacific
Ocean), the archipelago of lies Loyaute, and
numerous small, sparsely populated islands and atolls
Land boundaries:
total: 535 km
border countries: Mozambique 105 km, South Africa
430 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: varies from tropical to near temperate
Terrain: mostly mountains and hills; some
moderately sloping plains
Elevation extremes:
lowest point: Great Usutu River 21 m
highest point: Emlembe 1 ,862 m
Natural resources: asbestos, coal, clay, cassiterite,
hydropower, forests, small gold and diamond
deposits, quarry stone, and talc
Land use:
arable land: 10.25%
permanent crops: 0.81 %
other: 88.94% (2005)
Irrigated land: 690 sq km (1998 est.)
Natural hazards: drought
Environment - current issues: limited supplies of
potable water; wildlife populations being depleted
because of excessive hunting; overgrazing; soil
degradation; soil erosion
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Ozone Layer
Protection
signed, but not ratified: Law of the Sea
Geography - note: landlocked; almost completely
surrounded by South Africa','e498b15ac187e5c7348bc3e9d9b08bcf5ab8ccb1ed954cfc4aba759260007687','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6372d94a9a25ca57e70ea9c1bde490b525e2b38b0ccdffcc1fe252f6e98e54aa',2007,'FI','Finland','geography',565,'Location: Northern Europe, bordering the Baltic
Sea, Gulf of Bothnia, and Gulf of Finland, between
Sweden and Russia
Geographic coordinates: 64 00 N, 26 00 E
Map references: Europe
Area:
total: 338,145 sq km
land: 304,473 sq km
water: 33,672 sq km
Area - comparative: slightly smaller than Montana
Land boundaries:
total: 2,681 km
border countries: Norway 727 km, Sweden 614 km,
Russia 1 ,340 km
Coastline: 1,250 km
Maritime claims:
territorial sea: 12 nm (in the Gulf of Finland - 3 nm)
continental shelf: 200-m depth or to the depth of
exploitation
exclusive fishing zone: 12 nm; extends to continental
shelf boundary with Sweden
Climate: cold temperate; potentially subarctic but
comparatively mild because of moderating influence
of the North Atlantic Current, Baltic Sea, and more
than 60,000 lakes
Terrain: mostly low, flat to rolling plains interspersed
with lakes and low hills
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Haltiatunturi 1,328 m
Natural resources: timber, iron ore, copper, lead,
zinc, chromite, nickel, gold, silver, limestone
Land use:
arable land: 6.54%
permanent crops: 0.02%
other: 93.44% (2005)
Irrigated land: 640 sq km (1998 est.)
Natural hazards: NA
Environment - current issues: air pollution from
manufacturing and power plants contributing to acid
rain; water pollution from industrial wastes,
agricultural chemicals; habitat loss threatens wildlife
populations
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulfur 85, Air Pollution-Sulfur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Marine Life Conservation, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: long boundary with Russia;
Helsinki is northernmost national capital on European
continent; population concentrated on small
southwestern coastal plain
194
Finland (continued)','224c62d112cd037cc27c5f0f5b1997a718d835bee3814fe14090061f31f415a1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3736792e647a4b4e9c70e1c81fb747f8764f23af80da6b1dce14425171aaf264',2007,'GF','French Guiana','geography',580,'Location: Northern South America, bordering the
North Atlantic Ocean, between Brazil and Suriname
Geographic coordinates: 4 00 N, 53 00 W
Map references: South America
Area:
total: 91 ,000 sq km
land: 89,150 sq km
water: 1 ,850 sq km
Area - comparative: slightly smaller than Indiana
Land boundaries:
total: 1,183 km
border countries: Brazil 673 km, Suriname 510 km
Coastline: 378 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; hot, humid; little seasonal
temperature variation
Terrain: low-lying coastal plains rising to hills and
small mountains
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Bellevue de I''lnini 851 m
Natural resources: bauxite, timber, gold (widely
scattered), petroleum, kaolin, fish, niobium, tantalum,
clay
Land use:
arable land: 0.13%
permanent crops: 0.04%
other: 99.83% (90% forest, 10% other) (2005)
Irrigated land: 20 sq km (1998 est.)
Natural hazards: high frequency of heavy showers
and severe thunderstorms: flooding
Environment • current issues: NA
Geography - note: mostly an unsettled wilderness;
the only non-independent portion of the South
American continent','25d179cee720b21fe0d0f2a5207d056f90703081a6e85b8d1ab4027b60ef286a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('705f5993e6764d5767b6f91169ced778696aa9a7db4c79bd6378ae9a0b8550d6',2007,'PF','French Polynesia','geography',585,'Location: Oceania, archipelagoes in the South
Pacific Ocean about one-half of the way from South
America to Australia
Geographic coordinates: 15 00 S, 140 00 W
Map references: Oceania
Area:
total: 4,167 sq km (118 islands and atolls)
land: 3,660 sq km
water: 507 sq km
Area - comparative: slightly less than one-third the
size of Connecticut
Land boundaries: 0 km
Coastline: 2,525 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical, but moderate
Terrain: mixture of rugged high islands and low
islands with reefs
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mont Orohena 2,241 m
Natural resources: timber, fish, cobalt, hydropower
Land use:
arable land: 0.75%
permanent crops: 5.5%
other: 93.75% (2005)
Irrigated land: NA
Natural hazards: occasional cyclonic storms in
January
Environment - current issues: NA
Geography - note: includes five archipelagoes (4
volcanic, 1 coral); Makatea in French Polynesia is one
of the three great phosphate rock islands in the Pacific
Ocean - the others are Banaba (Ocean Island) in
Kiribati and Nauru','7472dcf8cc5c6b2c319439b3564edf69509c184c62bfd838cd4170ff43fab3d6','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1db76cea3a06b26a9caea78e3c4226c7e667b250c85efcc4c001df2407b21c9',2007,'GN','Guinea','geography',593,'Location: Western Africa, bordering the Atlantic
Ocean at the Equator, between Republic of the Congo
and Equatorial Guinea
Geographic coordinates: 1 00 S, 1 1 45 E
Map references: Africa
Area:
total: 267,667 sq km
land: 257,667 sq km
wafer: 10,000 sq km
Area - comparative: slightly smaller than Colorado
Land boundaries:
total: 2,551 km
border countries: Cameroon 298 km, Republic of the
Congo 1 ,903 km, Equatorial Guinea 350 km
Coastline: 885 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical; always hot, humid
Terrain: narrow coastal plain; hilly interior; savanna
in east and south
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mont Iboundji 1,575 m
Natural resources: petroleum, natural gas,
diamond, niobium, manganese, uranium, gold, timber,
iron ore, hydropower
Land use:
arable land: 1.21%
permanent crops: 0.64%
other: 98. 15% (2005)
Irrigated land: 150 sq km (1998 est.)
Natural hazards: NA
Environment - current issues: deforestation;
poaching
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands
signed, but not ratified: none of the selected
agreements
Geography • note: a small population and oil and
mineral reserves have helped Gabon become one of
Africa''s wealthier countries; in general, these
circumstances have allowed the country to maintain
and conserve its pristine rain forest and rich
biodiversity
Location: Western Africa, bordering the North
Atlantic Ocean, between Guinea-Bissau and Sierra
Leone
Geographic coordinates: 1 1 00 N, 10 00 W
Map references: Africa
Area:
total: 245,857 sq km
land: 245,857 sq km
wafer: 0 sq km
Area • comparative: slightly smaller than Oregon
Land boundaries:
total: 3,399 km
border countries: Cote d''lvoire 610 km,
Guinea-Bissau 386 km, Liberia 563 km, Mali 858 km,
Senegal 330 km, Sierra Leone 652 km
Coastline: 320 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: generally hot and humid; monsoonal-type
rainy season (June to November) with southwesterly
winds; dry season (December to May) with
northeasterly harmattan winds
Terrain: generally flat coastal plain, hilly to
mountainous interior
238
Guinea (continued)
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mont Nimba 1 ,752 m
Natural resources: bauxite, iron ore, diamonds,
gold, uranium, hydropower, fish, salt
Land use:
arable land: 4 .47%
permanent crops: 2.64%
other: 92.89% (2005)
Irrigated land: 950 sq km (1998 est.)
Natural hazards: hot, dry, dusty harmattan haze
may reduce visibility during dry season
Environment - current issues: deforestation;
inadequate supplies of potable water; desertification;
soil contamination and erosion; overfishing,
overpopulation in forest region; poor mining practices
have led to environmental damage
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: the Niger and its important
tributary the Milo have their sources in the Guinean
highlands
Location: Western Africa, islands in the Gulf of
Guinea, straddling the Equator, west of Gabon
Geographic coordinates: 1 00 N, 7 00 E
Map references: Africa
Area:
tote/: 1 .001 sqkm
land: 1,001 sqkm
water: 0 sq km
Area - comparative: more than five times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 209 km
Maritime claims: measured from claimed
archipelagic baselines
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; hot, humid; one rainy season
(October to May)
Terrain: volcanic, mountainous
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pico de Sao Tome 2.024 m
Natural resources: fish, hydropower
482
Sao Tome and Principe (continued)
Land use:
arable land: 8.33%
permanent crops: 48.96%
other 42.71% (2005)
Irrigated land: 100 sq km (1998 est.)
Natural hazards: NA
Environment - current issues: deforestation; soil
erosion and exhaustion
Environment - international agreements:
parly to: Biodiversity, Climate Change, Desertification,
Endangered Species, Environmental Modification, Law
of the Sea, Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: the smallest country in Africa; the
two main islands form part of a chain of extinct
volcanoes and both are fairly mountainous','e02dbd7b23cdd0ea838867fdb0528648abaabf2eb3b0950bcd6885325fe73a54','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ac5a6d76c4a98ecb31a55f00b97cf601138c3ba8f3d1c2e1f1560ebdba497847',2007,'GE','Georgia','geography',606,'Location: Southwestern Asia, bordering the Black
Sea, between Turkey and Russia
Geographic coordinates: 42 00 N, 43 30 E
Map references: Asia
Area:
total: 69,700 sq km
land: 69,700 sq km
wafer: 0 sq km
Area - comparative: slightly smaller than South
Carolina
Land boundaries:
total: 1,461 km
border countries: Armenia 164 km, Azerbaijan 322
km, Russia 723 km, Turkey 252 km
Coastline: 310 km
Maritime claims: NA
Climate: warm and pleasant; Mediterranean-like on
Black Sea coast
Terrain: largely mountainous with Great Caucasus
Mountains in the north and Lesser Caucasus
Mountains in the south; Kolkhet''is Dablobi (Kolkhida
Lowland) opens to the Black Sea in the west; Mtkvari
River Basin in the east; good soils in river valley flood
plains, foothills of Kolkhida Lowland
Elevation extremes:
lowest point: Black Sea 0 m
highest point: Mt''a Shkhara 5,201 m
Natural resources: forests, hydropower,
manganese deposits, iron ore, copper, minor coal
and oil deposits; coastal climate and soils allow for
important tea and citrus growth
Land use:
arable land: 11.51%
permanent crops: 3.79%
ofner: 84.7% (2005)
Irrigated land: 4,700 sq km (1998 est.)
Natural hazards: earthquakes
Environment - current issues: air pollution,
particularly in Rust''avi; heavy pollution of Mtkvari
River and the Black Sea; inadequate supplies of
potable water; soil pollution from toxic chemicals
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes, Law of the
Sea, Ozone Layer Protection, Ship Pollution, Wetlands
212
Georgia (continued)
signed, but not ratified: none of the selected
agreements
Geography - note: strategically located east of the
Black Sea; Georgia controls much of the Caucasus
Mountains and the routes through them','30c34db0f8322fc5ae79a3ce78981451aea3be14f42eb49d8785baafad1d457f','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8c49f8ce342cc6392f8143322773af3a6b61637abf78f8e483a37a31bcb124ec',2007,'GH','Ghana','geography',614,'Location: Western Africa, bordering the Gulf of
Guinea, between Cote d''lvoire and Togo
Geographic coordinates: 8 00 N, 2 00 W
Map references: Africa
Area:
total: 239,460 sq km
land: 230.940 sq km
water: 8,520 sq km
Area - comparative: slightly smaller than Oregon
Land boundaries:
total: 2.094 km
border countries: Burkina Faso 549 km, Cote d''lvoire
668 km, Togo 877 km
Coastline: 539 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shell: 200 nm
Climate: tropical; warm and comparatively dry along
southeast coast; hot and humid in southwest; hot and
dry in north
Terrain: mostly low plains with dissected plateau in
south-central area
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Mount Afadjato 880 m
Natural resources: gold, timber, industrial
diamonds, bauxite, manganese, fish, rubber,
hydropower, petroleum, silver, salt, limestone
Land use:
arable land: 17.54%
permanent crops: 9.22%
other: 73.24% (2005)
Irrigated land: 1 10 sq km (1998 est.)
Natural hazards: dry, dusty, northeastern harmattan
winds occur from January to March; droughts
Environment - current issues: recurrent drought in
north severely affects agricultural activities;
deforestation; overgrazing; soil erosion; poaching and
habitat destruction threatens wildlife populations;
water pollution; inadequate supplies of potable water
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber
94, Wetlands
signed, but not ratified: Marine Life Conservation
Geography - note: Lake Volta is the world''s iargest
artificial lake','586f23d01a019be06468a5cbbd81ba70b7993c3b8356833efdc063c6eb1847c7','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('42ebc7932b1663759c27256d2453aaa531d4a9e6365c56e5f2760e325be28b31',2007,'GI','Gibraltar','geography',624,'Location: Southwestern Europe, bordering the Strait
of Gibraltar, which links the Mediterranean Sea and the
North Atlantic Ocean, on the southern coast of Spain
Geographic coordinates: 36 8 N, 5 21 W
Map references: Europe
Area:
total: 6.5 sq km
land: 6.5 sq km
water: 0 sq km
Area - comparative: about 1 1 times the size of The
Mall in Washington, DC
Land boundaries:
total: 1.2 km
border countries: Spain 1 .2 km
Coastline: 12 km
Maritime claims:
territorial sea: 3 nm
Climate: Mediterranean with mild winters and warm
summers
Terrain: a narrow coastal lowland borders the Rock
of Gibraltar
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Rock of Gibraltar 426 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: NA
Natural hazards: NA
Environment • current issues: limited natural
freshwater resources: large concrete or natural rock
water catchments collect rainwater (no longer used for
drinking water) and adequate desalination plant
Geography - note: strategic location on Strait of
Gibraltar that links the North Atlantic Ocean and
Mediterranean Sea
Location: Southern Africa, group of islands in the
Indian Ocean, northwest of Madagascar
Geographic coordinates: 11 30 S, 47 20 E
Map references: Africa
Area:
total: 5 sq km
land: 5 sq km
water: 0 sq km
note: includes lie Glorieuse, He du Lys, Verte Rocks,
Wreck Rock, and South Rock
Area - comparative: about eight times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 35.2 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical
Terrain: low and flat
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: unnamed location 12 m
Natural resources: guano, coconuts
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (all lush vegetation and coconut palms)
(2005)
Irrigated land: Osq km (1998 est.)
Natural hazards: periodic cyclones
Environment - current issues: NA
Geography - note: the islands and rocks are
surrounded by an extensive reef system
Location: Southeastern Africa, bordering the
Mozambique Channel, between South Africa and
Tanzania
Geographic coordinates: 18 15 S, 35 00 E
Map references: Africa
Area:
total: 801 ,590 sq km
land: 784,090 sq km
water. 17,500 sq km
Area - comparative: slightly less than twice the size
of California
Land boundaries:
total: 4,571 km
border countries: Malawi 1,569 km, South Africa 491
km, Swaziland 105 km, Tanzania 756 km, Zambia 419
km, Zimbabwe 1,231 km
Coastline: 2,470 km
Maritime claims:
territorial sea: 1 2 nm
exclusive economic zone: 200 nm
Climate: tropical to subtropical
Terrain: mostly coastal lowlands, uplands in center,
high plateaus in northwest, mountains in west
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Monte Binga 2,436 m
Natural resources: coal, titanium, natural gas,
hydropower, tantalum, graphite
Land use:
arable land: 5.43%
permanent crops: 0.29%
other: 94.28% (2005)
Irrigated land: 1 ,070 sq km (1 998 est.)
Natural hazards: severe droughts; devastating
cyclones and floods in central and southern provinces
Environment - current issues: a long civil war and
recurrent drought in the hinterlands have resulted in
increased migration of the population to urban and
coastal areas with adverse environmental
consequences; desertification; pollution of surface
and coastal waters; elephant poaching for ivory is a
problem
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: the Zambezi flows through the
north-central and most fertile part of the country','2a36abe3109db168bcb843e69aa99e889877a05411c092d82e9d722d41ea23f1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30ad0d38b104da2ee7299da1a2808bebd4ca4288634a4cfac3b360df49b394e4',2007,'GR','Greece','geography',633,'Location: Southern Europe, bordering the Aegean
Sea, Ionian Sea, and the Mediterranean Sea,
between Albania and Turkey
Geographic coordinates: 39 00 N, 22 00 E
Map references: Europe
Area:
total: 131 ,940 sq km
land: 130,800 sq km
water: 1,140 sq km
Area - comparative: slightly smaller than Alabama
Land boundaries:
total: 1,228 km
border countries: Albania 282 km, Bulgaria 494 km,
Turkey 206 km, Macedonia 246 km
Coastline: 13,676 km
Maritime claims:
territorial sea: 12 nm
continental shelf: 200-m depth or to the depth of
exploitation
223
Greece (continued)
Climate: temperate; mild, wet winters; hot, dry
■ummers
"errain: mostly mountains with ranges extending
ito the sea as peninsulas or chains of islands
•levation extremes:
owest point: Mediterranean Sea 0 m
vghest point: Mount Olympus 2,917 m
Natural resources: lignite, petroleum, iron ore,
)auxite, lead, zinc, nickel, magnesite, marble, salt,
lydropower potential
.and use:
irable land: 20.45%
permanent crops: 8.59%
other: 70.96% (2005)
rrigated land: 14,220 sq km (1998 est.)
Matural hazards: severe earthquakes
Environment - current issues: air pollution; water
pollution
Environment - international agreements:
oarty to: Air Pollution, Air Pollution-Nitrogen Oxides,
^ir Pollution-Sulfur 94, Antarctic-Environmental
Protocol, Antarctic-Marine Living Resources,
Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Air Pollution-Volatile Organic
Compounds
Geography - note: strategic location dominating the
Aegean Sea and southern approach to Turkish
Straits; a peninsular country, possessing an
archipelago of about 2,000 islands','0c3cfbb11c723bd7e60a691b112abb56551b6419f9934b8397d37f3573820c00','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14c336730f60e4ac61a67f0ba6bdb1984631a5451be7a9a74ae93763c3457213',2007,'MQ','Martinique','geography',642,'Location: Caribbean, island between the Caribbean
Sea and Atlantic Ocean, north of Trinidad and Tobago
Geographic coordinates: 12 07 N. 61 40 W
Map references: Central America and the
Caribbean
Area:
total: 344 sq km
land: 344 sq km
water: 0 sq km
Area - comparative: twice the size of Washington,
DC
Land boundaries: 0 km
Coastline: 121 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; tempered by northeast trade winds
Terrain: volcanic in origin with central mountains
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Saint Catherine 840 m
Natural resources: timber, tropical fruit, deepwater
harbors
Land use:
arable land: 5.88%
permanent crops: 29.41 %
other: 64.71% (2005)
Irrigated land: NA sq km
Natural hazards: lies on edge of hurricane belt;
hurricane season lasts from June to November
Environment - current issues: NA
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Law of the Sea, Ozone Layer Protection,
Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: the administration of the islands
of the Grenadines group is divided between Saint
Vincent and the Grenadines and Grenada
Location: Caribbean, island between the Caribbean
Sea and North Atlantic Ocean, north of Trinidad and
Tobago
Geographic coordinates: 14 40 N, 61 00 W
Map references: Central America and the
Caribbean
Area:
total: 1,100 sq km
land: 1 ,060 sq km
water: 40 sq km
Area - comparative: slightly more than six times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 350 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; moderated by trade winds: rainy
season (June to October); vulnerable to devastating
cyclones (hurricanes) every eight years on average;
average temperature 17.3 degrees C; humid
Terrain: mountainous with indented coastline;
dormant volcano
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Montagne Pelee 1 ,397 m
Natural resources: coastal scenery and beaches,
cultivable land
Land use:
arable land: 9.09%
permanent crops: 10%
other: 80.91% (2005)
358
Martinique (continued)
Irrigated land: 30 sq km (1998 est.)
Natural hazards: hurricanes, flooding, and volcanic
activity (an average of one major natural disaster
every five years)
Environment - current issues: NA
Geography - note: the island is dominated by Mount
Pelee, which on 8 May 1902 erupted and completely
destroyed the city of Saint Pierre, killing 30,000
inhabitants','affbf83fd943f37ccec1c83a0dc5c69f89575f2e4c77c4f32c3c65c30865c1df','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8207e2b5acf93e096817d8c652075215e9b68a5a5866aae1d25d413cbce3f821',2007,'GP','Guadeloupe','geography',651,'Location: Caribbean, islands between the
Caribbean Sea and the North Atlantic Ocean,
southeast of Puerto Rico
Geographic coordinates: 16 15 N, 61 35 W
Map references: Central America and the
Caribbean
Area:
total: 1,780 sq km
land: 1 ,706 sq km
water: 74 sq km
note: Guadeloupe is an archipelago of nine inhabited
islands, including Basse-Terre, Grande-Terre,
Marie-Galante, La Desirade, lies des Saintes (2),
Saint-Barthelemy. lies de la Petite Terre, and
Saint-Martin (French part of the island of Saint Martin)
Area • comparative: 10 times the size of
Washington, DC
Land boundaries:
tofa/:10.2km
border countries: Netherlands Antilles (Sint Maarten)
10.2 km
Coastline: 306 km
Maritime claims:
territorial sea: 1 2 nm
exclusive economic zone: 200 nm
Climate: subtropical tempered by trade winds;
moderately high humidity
Terrain: Basse-Terre is volcanic in origin with interior
mountains; Grande-Terre is low limestone formation;
most of the seven other islands are volcanic in origin
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest po/nf: Soufriere 1,484 m
Natural resources: cultivable land, beaches and
climate that foster tourism
Land use:
araWe land: 1 1 .7%
permanent crops: 2.92%
ofher: 85.38% (2005)
Irrigated land: 20 sq km (1998 est.)
Natural hazards: hurricanes (June to October);
Soufriere de Guadeloupe is an active volcano
Environment - current issues: NA
Geography - note: a narrow channel, the Riviere
Salee. divides Guadeloupe proper into two islands:
the larger, western Basse-Terre and the smaller,
eastern Grande-Terre','35ffa98eeb46d1326ecf548c52fba254afc1ac9ad1d96eaa5e2066685c28fc1c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cf434f1df359982a9eec12f375271eb7395d3f3814f6c7acf32c9281f6a1850',2007,'GU','Guam','geography',656,'Location: Oceania, island in the North Pacific
Ocean, about three-quarters of the way from Hawaii to
the Philippines
Geographic coordinates: 1 3 28 N, 1 44 47 E
Map references: Oceania
Area:
total: 549 sq km
land: 549 sq km
water: 0 sq km
Area ■ comparative: three times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 125.5 km
Maritime claims:
territorial sea: 1 2 nm
exclusive economic zone: 200 nm
Climate: tropical marine; generally warm and humid,
moderated by northeast trade winds; dry season
(January to June), rainy season (July to December);
little seasonal temperature variation
Terrain: volcanic origin, surrounded by coral reefs;
relatively flat coralline limestone plateau (source of most
fresh water), with steep coastal cliffs and narrow coastal
plains in north, low hills in center, mountains in south
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Lamlam 406 m
Natural resources: fishing (largely undeveloped),
tourism (especially from Japan)
Land use:
arable land: 3.64%
permanent crops: 18.1 8%
other: 78.18% (2005)
Irrigated land: NA
Natural hazards: frequent squalls during rainy
season; relatively rare, but potentially very destructive
typhoons (June - December)
Environment - current issues: extirpation of native
bird population by the rapid proliferation of the brown
tree snake, an exotic, invasive species
Geography - note: largest and southernmost island
in the Mariana Islands archipelago; strategic location
in western North Pacific Ocean','5d3d0b89531e00dd43fe06a04b4f30d44f5cf419647856433e681255ec081935','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('aa077a8864a2b489c6748c44491607afa43ce30874c0e16146d2ff8cbada9fcc',2007,'GG','Guernsey','geography',664,'Location: Western Europe, islands in the English
Channel, northwest of France
Geographic coordinates: 49 28 N, 2 35 W
Map references: Europe
Area:
total: 78 sq km
land: 78 sq km
water: 0 sq km
note: includes Alderney, Guernsey, Herm, Sark, and
some other smaller islands
Area - comparative: about one-half the size of
Washington, DC
Land boundaries: 0 km
Coastline: 50 km
Maritime claims:
territorial sea: 3 nm
exclusive fishing zone: 12 nm
Climate: temperate with mild winters and cool
summers; about 50% of days are overcast
Terrain: mostly level with low hills in southwest
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location on Sark 114 m
Natural resources: cropland
Land use:
arable land: NA%
permanent crops: NA%
other: NA%
Irrigated land: NA
Natural hazards: NA','557f5bce9e78803a1e43989e5b299aad16a3299609563ab020d0af93f3a03004','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8f467a7370e183268a4741ecc1e7649da45a0ba849f4cb5f4c4867a171be6d9',2007,'GW','Guinea-Bissau','geography',672,'Location: Western Africa, bordering the North
Atlantic Ocean, between Guinea and Senegal
Geographic coordinates: 12 00 N, 15 00 W
Map references: Africa
Area:
total: 36,120 sq km
land: 28,000 sq km
water: 8,120 sq km
Area - comparative: slightly less than three times
the size of Connecticut
Land boundaries:
total: 724 km
border countries: Guinea 386 km, Senegal 338 km
Coastline: 350 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; generally hot and humid;
monsoonal-type rainy season (June to November)
with southwesterly winds; dry season (December to
May) with northeasterly harmattan winds
Terrain: mostly low coastal plain rising to savanna in
east
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed location in the northeast
corner of the country 300 m
Natural resources: fish, timber, phosphates,
bauxite, clay, granite, limestone, unexploited deposits
of petroleum
Land use:
arable land: 8.31%
permanent crops: 6.92%
other: 84.77% (2005)
Irrigated land : 1 70 sq km ( 1 998 est.)
Natural hazards: hot, dry, dusty harmattan haze
may reduce visibility during dry season; brush fires
Environment - current issues: deforestation; soil
erosion; overgrazing; overfishing
Environment - international agreements:
party to: Biodiversity, Climate Change, Desertification,
Endangered Species, Law of the Sea, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: this small country is swampy
along its western coast and low-lying further inland','5a29aa45f2c3628e7fab0ad934f9dedcce4e9baa7e19af9334d63c6d89ff2274','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a064cf7a349749dd957bea469940ad7622e0f1635e4b40fd8c8dfdab447732d8',2007,'IT','Italy','geography',685,'Location: Southern Europe, an enclave of Rome
(Italy)
Geographic coordinates: 41 54 N, 12 27 E
Map references: Europe
Area:
total: 0.44 sq km
land: 0.44 sq km
water. 0 sq km
Area - comparative: about 0.7 times the size of The
Mall in Washington, DC
Land boundaries:
total: 3.2 km
border countries: Italy 3.2 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; mild, rainy winters (September
to May) with hot, dry summers (May to September)
Terrain: urban; low hill
Elevation extremes:
lowest point: unnamed location 19 m
highest point: unnamed location 75 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (urban area) (2005)
Irrigated land: Osq km (1998 est.)
Natural hazards: NA
Environment - current issues: NA
Environment - international agreements:
party to: none of the selected agreements
signed, but not ratified: Air Pollution, Environmental
Modification
Geography - note: landlocked; enclave in Rome,
Italy; world''s smallest state; beyond the territorial
boundary of Vatican City, the Lateran Treaty of 1929
grants the Holy See extraterritorial authority over 23
sites in Rome and five outside of Rome, including the
Pontifical Palace at Castel Gandolfo (the Pope''s
summer residence)
Location: Southern Europe, an enclave in central
Geographic coordinates: 43 46 N, 12 25 E
Map references: Europe
Area:
total: 61 .2 sq km
land: 61.2 sq km
water. 0 sq km
Area - comparative: about 0.3 times the size of
Washington, DC
Land boundaries:
total: 39 km
border countries: Italy 39 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: Mediterranean; mild to cool winters; warm,
sunny summers
Terrain: rugged mountains
Elevation extremes:
lowest point: Torrente Ausa 55 m
highest point: Monte Titano 755 m
Natural resources: building stone
Land use:
arable land: 16.67%
permanent crops: 0%
other: 83.33% (2005)
Irrigated land: NA sq km
Natural hazards: NA
Environment • current issues: NA
Environment - international agreements:
party to: Biodiversity, Climate Change, Desertification
signed, but not ratified: Air Pollution
Geography - note: landlocked; smallest
independent state in Europe after the Holy See and
Monaco; dominated by the Apennines','4b2086ed492804ab2b7b227f852fbefc36a16028e21131acbcb9e1cb31fed94b','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75ff89cf5721c84fb45146e391f62939e4f20bc8a54761fd04ac2208c000ac3b',2007,'NI','Nicaragua','geography',695,'Location: Central America, bordering the Caribbean
Sea, between Guatemala and Nicaragua and
bordering the Gulf of Fonseca (North Pacific Ocean),
between El Salvador and Nicaragua
Geographic coordinates: 1 5 00 N, 86 30 W
Map references: Central America and the Caribbean
Area:
total: 112,090 sq km
land: 1 1 1 ,890 sq km
water: 200 sq km
Area - comparative: slightly larger than Tennessee
Land boundaries:
total: 1 ,520 km
border countries: Guatemala 256 km, El Salvador 342
km, Nicaragua 922 km
Coastline: 820 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: natural extension of territory or to
200 nm
Climate: subtropical in lowlands, temperate in
mountains
Terrain: mostly mountains in interior, narrow coastal
plains
250
Honduras (continued)
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Cerro Las Minas 2,870 m
Natural resources: timber, gold, silver, copper,
lead, zinc, iron ore, antimony, coal, fish, hydropower
Land use:
arable land: 9.53%
permanent crops: 3.21%
other: 87.26% (2005)
Irrigated land: 760 sq km (1998 est.)
Natural hazards: frequent, but generally mild,
earthquakes; extremely susceptible to damaging
hurricanes and floods along the Caribbean coast
Environment - current issues: urban population
expanding; deforestation results from logging and the
clearing of land for agricultural purposes; further land
degradation and soil erosion hastened by uncontrolled
development and improper land use practices such as
farming of marginal lands; mining activities polluting
Lago de Yojoa (the country''s largest source of fresh
water), as well as several rivers and streams, with
heavy metals
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: has only a short Pacific coast but
a long Caribbean shoreline, including the virtually
uninhabited eastern Mosquito Coast','b0e817a65c827e2ebe7d059e2a3ba52c8d293db20de9ccd29bbf7061a1d083b7','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b0619cecd1f5ac6dd94ce699d3a3549f1f537ff03c7fe2a8cca93a47cbe88090',2007,'RO','Romania','geography',707,'Location: Central Europe, northwest of Romania
Geographic coordinates: 47 00 N, 20 00 E
Map references: Europe
Area:
total: 93,030 sq km
land: 92,340 sq km
water: 690 sq km
Area - comparative: slightly smaller than Indiana
Land boundaries:
total: 2,171 km
border countries: Austria 366 km, Croatia 329 km,
Romania 443 km, Serbia and Montenegro 151 km,
Slovakia 677 km, Slovenia 102 km, Ukraine 103 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cold, cloudy, humid winters;
warm summers
Terrain: mostly flat to rolling plains; hills and low
mountains on the Slovakian border
Elevation extremes:
lowest point: Tisza River 78 m
highest point: Kekes 1 ,01 4 m
Natural resources: bauxite, coal, natural gas, fertile
soils, arable land
Land use:
arable land: 49.58%
permanent crops: 2.06%
other: 48.36% (2005)
Irrigated land: 2,100 sq km (1998 est.)
Environment - current issues: the upgrading of
Hungary''s standards in waste management, energy
efficiency, and air, soil, and water pollution to meet EU
requirements will require large investments
Environment • international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulfur 85, Air Pollution-Volatile Organic
Compounds. Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping. Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: Air Pollution-Sulfur 94
Geography • note: landlocked; strategic location
astride main land routes between Western Europe
and Balkan Peninsula as well as between Ukraine and
Mediterranean basin; the north-south flowing Duna
(Danube) and Tisza Rivers divide the country into
three large regions
Location: Northern Europe, island between the
Greenland Sea and the North Atlantic Ocean,
northwest of the UK
Geographic coordinates: 65 00 N, 18 00 W
Map references: Arctic Region
Area:
total: 103,000 sq km
land: 100,250 sq km
water: 2,750 sq km
Area - comparative: slightly smaller than Kentucky
Land boundaries: 0 km
Coastline: 4,970 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: temperate; moderated by North Atlantic
Current; mild, windy winters; damp, cool summers
Terrain: mostly plateau interspersed with mountain
peaks, icefields; coast deeply indented by bays and
fiords
258
Iceland (continued)
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Hvannadalshnukur 2,1 10 m (at
Vatnajokull glacier)
Natural resources: fish, hydropower, geothermal
power, diatomite
Land use:
arable land: 0.07%
permanent crops: 0%
other: 99.93% (2005)
Irrigated land: NA
Natural hazards: earthquakes and volcanic activity
Environment - current issues: water pollution from
fertilizer runoff; inadequate wastewater treatment
Environment - international agreements:
pady to: Air Pollution, Air Pollution-Persistent Organic
Pollutants, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Kyoto Protocol, Law of
the Sea, Marine Dumping, Ozone Layer Protection,
Ship Pollution, Transboundary Air Pollution, Wetlands
signed, but not ratified: Environmental Modification,
Marine Life Conservation
Geography - note: strategic location between
Greenland and Europe; westernmost European
country; Reykjavik is the northernmost national capital
in the world; more land covered by glaciers than in all
of continental Europe
Location: Eastern Europe, northeast of Romania
Geographic coordinates: 47 00 N, 29 00 E
Map references: Europe
Area:
total: 33,843 sq km
land: 33,371 sq km
water: 472 sq km
Area - comparative: slightly larger than Maryland
Land boundaries:
total: 1 ,389 km
border countries: Romania 450 km, Ukraine 939 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: moderate winters, warm summers
Terrain: rolling steppe, gradual slope south to Black
Sea
Elevation extremes:
lowest point: Dniester River 2 m
highest point: Dealul Balanesti 430 m
Natural resources: lignite, phosphorites, gypsum,
arable land, limestone
Land use:
arable land: 54.52%
permanent crops: 8.81%
other: 36.67% (2005)
Irrigated land: 3,070 sq km (1998 est.)
Natural hazards: landslides (57 cases in 1998)
Environment - current issues: heavy use of
agricultural chemicals, including banned pesticides
such as DDT, has contaminated soil and groundwater;
extensive soil erosion from poor farming methods
Environment - international agreements:
party to: Air Pollution, Air Pollution-Persistent Organic
Pollutants, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography ■ note: landlocked; well endowed with
various sedimentary rocks and minerals including
sand, gravel, gypsum, and limestone','63fef4b34d491cb3faadc50c3a31328034f691213303e0c817b0c8c4d00abd67','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1d7be9a143b66b13a8c6af38aa2989fe187589635b254002ccbc6aefc0131b30',2007,'IN','India','geography',722,'Location: body of water between Africa, the
Southern Ocean, Asia, and Australia
Geographic coordinates: 20 00 S, 80 00 E
Map references: Political Map of the World
Area:
total: 68.556 million sq km
note: includes Andaman Sea, Arabian Sea, Bay of
Bengal, Flores Sea, Great Australian Bight, Gulf of
Aden, Gulf of Oman, Java Sea, Mozambique
Channel, Persian Gulf, Red Sea, Savu Sea, Strait of
Malacca, Timor Sea, and other tributary water bodies
Area - comparative: about 5.5 times the size of the
US
Coastline: 66,526 km
Climate: northeast monsoon (December to April),
southwest monsoon (June to October); tropical
cyclones occur during May/June and October/
November in the northern Indian Ocean and January/
February in the southern Indian Ocean
Terrain: surface dominated by counterclockwise
gyre (broad, circular system of currents) in the
southern Indian Ocean; unique reversal of surface
currents in the northern Indian Ocean; low
atmospheric pressure over southwest Asia from hot,
rising, summer air results in the southwest monsoon
264
Indian Ocean (continued)
and southwest-to-northeast winds and currents, while
high pressure over northern Asia from cold, falling,
winter air results in the northeast monsoon and
northeast-to-southwest winds and currents; ocean
floor is dominated by the Mid-Indian Ocean Ridge and
subdividea by the Southeast Indian Ocean Ridge,
Southwest Indian Ocean Ridge, and Ninetyeast Ridge
Elevation extremes:
lowest point: Java Trench -7,258 m
highest point: sea level 0 m
Natural resources: oil and gas fields, fish, shrimp,
sand and gravel aggregates, placer deposits,
polymetallic nodules
Natural hazards: occasional icebergs pose
navigational hazard in southern reaches
Environment - current issues: endangered marine
species include the dugong, seals, turtles, and
whales; oil pollution in the Arabian Sea, Persian Gulf,
and Red Sea
Geography - note: major chokepoints include Bab
el Mandeb, Strait of Hormuz, Strait of Malacca,
southern access to the Suez Canal, and the Lombok
Strait','7656f5ebd621e73aca16c18fd9d3e3b74c71e64e533942fa8970c845100b2575','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f1d3f1052f43318bf83629a703c42e95ba149df4f28c07d78e446178dc10265',2007,'IE','Ireland','geography',725,'Location: Western Europe, occupying five-sixths of
the island of Ireland in the North Atlantic Ocean, west
of Great Britain
Geographic coordinates: 53 00 N, 8 00 W
Map references: Europe
Area:
total: 70,280 sq km
land: 68,890 sq km
water: 1 ,390 sq km
Area - comparative: slightly larger than West
Virginia
Land boundaries:
total: 360 km
border countries: UK 360 km
Coastline: 1,448 km
Maritime claims:
territorial sea: 12 nm
exclusive fishing zone: 200 nm
274
Ireland (continued)
Climate: temperate maritime; modified by North
Atlantic Current; mild winters, cool summers;
consistently humid; overcast about half the time
Terrain: mostly level to rolling interior plain
surrounded by rugged hills and low mountains; sea
cliffs on west coast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
/i/gnesfpo/nf: Carrauntoohil 1,041 m
Natural resources: natural gas, peat, copper, lead,
zinc, silver, barite, gypsum, limestone, dolomite
Land use:
arable land: 16.82%
permanent crops: 0.03%
other: 83.15% (2005)
Irrigated land: NA
Natural hazards: NA
Environment - current issues: water pollution,
especially of lakes, from agricultural runoff
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulfur 94, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Marine Life Conservation
Geography - note: strategic location on major air
and sea routes between North America and northern
Europe; over 40% of the population resides within 1 00
km of Dublin','c3532236c7f2f5a42a794dd2f5ac262cbf7a5bce55003cd02549da2c32715bb3','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('722c685d4000873c15833153d68f672f75ccda16e3eb7f0a7347546eb17ddcf2',2007,'IM','Isle of Man','geography',734,'Location: Western Europe, island in the Irish Sea,
between Great Britain and Ireland
Geographic coordinates: 54 15 N, 4 30 W
Map references: Europe
Area:
total: 572 sq km
land: 572 sq km
water: 0 sq km
Area - comparative: slightly more than three times
the size of Washington, DC
Land boundaries: 0 km
Coastline: 160 km
Maritime claims:
territorial sea: 12 nm
exclusive fishing zone: 1 2 nm
Climate: temperate; cool summers and mild winters;
overcast about one-third of the time
Terrain: hills in north and south bisected by central
valley
Elevation extremes:
lowest point: Irish Sea 0 m
/7/g/iesfpoinf:Snaefell621 m
Natural resources: none
Land use:
arable land: 9%
permanent crops: 0%
other: 91% (permanent pastures, forests, mountain,
and heathland) (2002)
Irrigated land: 0 sq km (1998 est.)
Natural hazards: NA
Environment - current issues: waste disposal
(both household and industrial); transboundary air
pollution
Geography - note: one small islet, the Calf of Man,
lies to the southwest, and is a bird sanctuary','ec4a210da8d802063d8d87cdae7919fbaa18dacceedfd7cb8922975bf0b7bf6b','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fb943d8a839a99d853c75ddd4202dd443e6d8e8cc0fdc41ce180881b373b073b',2007,'EG','Egypt','geography',740,'Location: Middle East, bordering the Mediterranean
Sea, between Egypt and Lebanon
Geographic coordinates: 31 30 N, 34 45 E
Map references: Middle East
Area:
total: 20,770 sq km
land: 20,330 sq km
water: 440 sq km
Area - comparative: slightly smaller than New','067af7be49194c421341f892c0a622582ee8969d2538391daaba8afc786d62d4','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6dfab94e24067661208bafd588cc7c7090dbe1d72d201555cf7ac446727762ea',2007,'TN','Tunisia','geography',743,'Location: Southern Europe, a peninsula extending
into the central Mediterranean Sea, northeast of
Geographic coordinates: 42 50 N, 12 50 E
Map references: Europe
Area:
total: 301 ,230 sq km
land: 294,020 sq km
water: 7.210 sq km
note: includes Sardinia and Sicily
Area - comparative: slightly larger than Arizona
Land boundaries:
total: 1,932.2 km
border countries: Austria 430 km, France 488 km,
Holy See (Vatican City) 3.2 km, San Marino 39 km,
Slovenia 232 km, Switzerland 740 km
Coastline: 7,600 km
Maritime claims:
territorial sea: 12 nm
continental shelf: 200-m depth or to the depth of
exploitation
Climate: predominantly Mediterranean; Alpine in far
north; hot, dry in south
Terrain: mostly rugged and mountainous; some
plains, coastal lowlands
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Mont Blanc (Monte Bianco) de
Courmayeur 4,748 m (a secondary peak of Mont Blanc)
Natural resources: coal, mercury, zinc, potash,
marble, barite, asbestos, pumice, fluorospar, feldspar,
pyrite (sulfur), natural gas and crude oil reserves, fish,
arable land
Land use:
arable land: 26.41%
permanent crops: 9.09%
other: 64.5% (2005)
Irrigated land: 26,980 sq km (1998 est.)
Natural hazards: regional risks include landslides,
mudflows, avalanches, earthquakes, volcanic
eruptions, flooding; land subsidence in Venice
Environment • current issues: air pollution from
industrial emissions such as sulfur dioxide; coastal and
inland rivers polluted from industrial and agricultural
effluents; acid rain damaging lakes; inadequate industrial
waste treatment and disposal facilities
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulfur 85, Air Pollution-Sulfur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Seals, Antarctic Treaty,
Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Marine Dumping, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber
94, Wetlands, Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants
Geography - note: strategic location dominating
central Mediterranean as well as southern sea and air
approaches to Western Europe','18238fd82705a80b0d5e41b77a89e3ade00c525beb246a1f74874cc9d4762e5e','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c67c3141cbadaecb3e48462fcf8a1ed1a85820ffe6701e53c4e2141a32daf332',2007,'GL','Greenland','geography',752,'Location: Northern Europe, island between the
Greenland Sea and the Norwegian Sea, northeast of','50f44fb6f37a1c0aaa4390a0598cb2ce7d45d1cd92639a4de9f58f1f32f2d273','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('72af09c4bf135cc22928d17f02a7dc4e25704507d9257d90d29b0b1b131213b8',2007,'IS','Iceland','geography',753,'Geographic coordinates: 71 00 N, 8 00 W
Map references: Arctic Region
Area:
total: 373 sq km
land: 373 sq km
water: 0 sq km
Area - comparative: slightly more than twice the
size of Washington, DC
Land boundaries: 0 km
Coastline: 124.1 km
Maritime claims:
territorial sea: 4 nm
contiguous zone: 10 nm
exclusive economic zone: 200 nm
continental shelf: 200-m depth or to the depth of
exploitation
Climate: arctic maritime with frequent storms and
persistent fog
Terrain: volcanic island, partly covered by glaciers
Elevation extremes:
lowest point: Norwegian Sea 0 m
highest point: Haakon VII Toppen/Beerenberg
2,277 m
287
Jan Mayen (continued)
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
other. 100% (2005)
Irrigated land: Osq km (1998 est.)
Natural hazards: dominated by the volcano Haakon
VII Toppen/Beerenberg; volcanic activity resumed in
1970
Environment - current issues: NA
Geography - note: barren volcanic island with some
moss and grass','51f066e1d27758177e0013c036e8ac35f4603525488af515e728fbf0f1b91ecf','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe731b0e6859f8db106c68fff38707ac22decc389d6876e22498cea95fa75842',2007,'JP','Japan','geography',761,'Location: Eastern Asia, island chain between the
North Pacific Ocean and the Sea of Japan, east of the
Korean Peninsula
Geographic coordinates: 36 00 N, 138 00 E
Map references: Asia
Area:
total: 377,835 sq km
land: 374,744 sq km
water: 3,091 sq km
note: includes Bonin Islands (Ogasawara-gunto),
Daito-shoto, Minami-jima, Okino-tori-shima, Ryukyu
Islands (Nansei-shoto), and Volcano Islands
(Kazan-retto)
Area - comparative: slightly smaller than California
Land boundaries: 0 km
Coastline: 29,751 km
Maritime claims:
territorial sea: 1 2 nm; between 3 nm and 1 2 nm in the
international straits - La Perouse or Soya, Tsugaru,
Osumi, and Eastern and Western Channels of the
Korea or Tsushima Strait
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: varies from tropical in south to cool
temperate in north
Terrain: mostly rugged and mountainous
Elevation extremes:
lowest point: Hachiro-gata -4 m
highest point: Mount Fuji 3,776 m
Natural resources: negligible mineral resources,
fish
Land use:
arable land: 1 1 .64%
permanent crops: 0.9%
other: 87.46% (2005)
Irrigated land: 26,790 sq km (1998 est.)
Natural hazards: many dormant and some active
volcanoes; about 1,500 seismic occurrences (mostly
tremors) every year; tsunamis; typhoons
Environment - current issues: air pollution from
power plant emissions results in acid rain; acidification of
lakes and reservoirs degrading water quality and
threatening aquatic life; Japan is one of the largest
consumers of fish and tropical timber, contributing to the
depletion of these resources in Asia and elsewhere
Environment - international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Seals,
Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Environmental Modification,
Hazardous Wastes, Law of the Sea, Marine Dumping,
Ozone Layer Protection, Ship Pollution, Tropical
Timber 83, Tropical Timber 94, Wetlands, Whaling
Geography - note: strategic location in northeast
Asia','ca66b8086edcf4e3ca4a526e8ed1a5314f5ce9c4b12ebc029d48117f662ec4d3','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70aeb876b390017225e1bd7717685a03645c49df811930edca6f11b7c1a20030',2007,'KZ','Kazakhstan','geography',783,'Location: Eastern Africa, bordering the Indian
Ocean, between Somalia and Tanzania
Geographic coordinates: 1 00 N, 38 00 E
Map references: Africa
Area:
total: 582,650 sq km
land: 569,250 sq km
water: 1 3,400 sq km
Area - comparative: slightly more than twice the
size of Nevada
Land boundaries:
total: 3,477 km
border countries: Ethiopia 861 km, Somalia 682 km,
Sudan 232 km, Tanzania 769 km, Uganda 933 km
Coastline: 536 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 m depth or to the depth of
exploitation
Climate: varies from tropical along coast to arid in
interior
Terrain: low plains rise to central highlands bisected
by Great Rift Valley; fertile plateau in west
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Mount Kenya 5,199 m
Natural resources: limestone, soda ash, salt,
gemstones, fluorspar, zinc, diatomite, gypsum,
wildlife, hydropower
Land use:
arable land: 8.01%
permanent crops: 0.97%
other: 91 .02% (2005)
Irrigated land: 670 sq km (1998 est.)
Natural hazards: recurring drought; flooding during
rainy seasons
Environment - current issues: water pollution from
urban and industrial wastes; degradation of water
quality from increased use of pesticides and fertilizers;
water hyacinth infestation in Lake Victoria;
deforestation; soil erosion; desertification; poaching
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: the Kenyan Highlands comprise
one of the most successful agricultural production
regions in Africa; glaciers are found on Mount Kenya,
Africa''s second highest peak; unique physiography
supports abundant and varied wildlife of scientific and
economic value','b0a44157c6f55afb21139701db808b15dfee5a6a1fd7af7eb08cea3246b16001','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('46976e82c87b7409e11d8e668aa8de4ad33141b9827d67a275df348ffe324334',2007,'KI','Kiribati','geography',789,'Location: Oceania, group of 33 coral atolls in the
Pacific Ocean, straddling the Equator; the capital
Tarawa is about one-half of the way from Hawaii to
Australia; note - on 1 January 1995, Kiribati
proclaimed that all of its territory lies in the same time
zone as its Gilbert Islands group (GMT +12) even
though the Phoenix Islands and the Line Islands under
its jurisdiction lie on the other side of the International
Date Line
Geographic coordinates: 1 25 N, 173 00 E
Map references: Oceania
Area:
total: 811 sq km
land: 81 1 sq km
water: 0 sq km
note: includes three island groups - Gilbert Islands,
Line Islands, Phoenix Islands
Area ■ comparative: four times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 1,143 km
Maritime claims:
territorial sea: 1 2 nm
exclusive economic zone: 200 nm
Climate: tropical; marine, hot and humid, moderated
by trade winds
Terrain: mostly low-lying coral atolls surrounded by
extensive reefs
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Banaba 81 m
Natural resources: phosphate (production
discontinued in 1979)
Land use:
arable land: 2.74%
permanent crops: 47.95%
other. 49.31% (2005)
Irrigated land: NA
Natural hazards: typhoons can occur any time, but
usually November to March; occasional tornadoes;
low level of some of the islands make them very
sensitive to changes in sea level
Environment - current issues: heavy pollution in
lagoon of south Tarawa atoll due to heavy migration
mixed with traditional practices such as lagoon
latrines and open-pit dumping; ground water at risk
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: 21 of the 33 islands are
inhabited; Banaba (Ocean Island) in Kiribati is one of
the three great phosphate rock islands in the Pacific
Ocean - the others are Makatea in French Polynesia,
and Nauru
Location: Eastern Asia, southern half of the Korean
Peninsula bordering the Sea of Japan and the Yellow
Sea
Geographic coordinates: 37 00 N, 127 30 E
Map references: Asia
Area:
total: 98,480 sq km
land: 98,190 sq km
water: 290 sq km
Area - comparative: slightly larger than Indiana
Land boundaries:
total: 238 km
border countries: North Korea 238 km
Coastline: 2,413 km
Maritime claims:
territorial sea: 1 2 nm; between 3 nm and 1 2 nm in the
Korea Strait
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: not specified
Climate: temperate, with rainfall heavier in summer
than winter
Terrain: mostly hills and mountains; wide coastal
plains in west and south
Elevation extremes:
lowest point: Sea of Japan 0 m
highest point: Halla-san 1 ,950 m
Natural resources: coal, tungsten, graphite,
molybdenum, lead, hydropower potential
Land use:
arable land: 16.58%
permanent crops: 2.01 %
other: 81.41% (2005)
Irrigated land: 11,590 sq km (1998 est.)
Natural hazards: occasional typhoons bring high
winds and floods; low-level seismic activity common in
southwest
Environment - current issues: air pollution in large
cities; acid rain; water pollution from the discharge of
sewage and industrial effluents; drift net fishing
Environment - international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Treaty,
Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Marine Dumping, Ozone Layer Protection,
Ship Pollution, Tropical Timber 83, Tropical Timber
94, Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location on Korea Strait','68a1289a3219c7752039fe7f54ae1e4cec9f73a1b55eaccaf763366de76bc374','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0c80751dec1d7d51cac1c855139f0dc94fc08fffd8476c3a5448df0e12a9a40b',2007,'KW','Kuwait','geography',799,'Location: Middle East, bordering the Persian Gulf,
between Iraq and Saudi Arabia
Geographic coordinates: 29 30 N, 45 45 E
Map references: Middle East
Area:
total: 17,820 sq km
land: 17,820 sq km
water: 0 sq km
Area - comparative: slightly smaller than New','1d33f8e537ae7e8b208d44343102de6c6f8aa9429dbd960b8764d739dc820ba9','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14d7a72f8ecd0f50348473fc36cf869ca026659f0e0cc9bd4e92b026500f8cd5',2007,'LB','Lebanon','geography',805,'Location: Middle East, bordering the Mediterranean
Sea, between Israel and Syria
Geographic coordinates: 33 50 N, 35 50 E
Map references: Middle East
Area:
total: 10,400 sq km
land: 10,230 sq km
wafer: 170 sq km
Area - comparative: about 0.7 times the size of
Connecticut
Land boundaries:
total: 454 km
border countries: Israel 79 km, Syria 375 km
Coastline: 225 km
Maritime claims:
territorial sea: 1 2 nm
Climate: Mediterranean; mild to cool, wet winters
with hot, dry summers; Lebanon mountains
experience heavy winter snows
Terrain: narrow coastal plain; El Beqaa (Bekaa
Valley) separates Lebanon and Anti-Lebanon
Mountains
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Qurnat as Sawda'' 3,088 m
Natural resources: limestone, iron ore, salt,
water-surplus state in a water-deficit region, arable
land
Land use:
arable land: 16.35%
permanent crops: 1 3.75%
other: 69.9% (2005)
Irrigated land: 1 ,200 sq km (1998 est.)
Natural hazards: dust storms, sandstorms
Environment - current issues: deforestation; soil
erosion; desertification; air pollution in Beirut from
vehicular traffic and the burning of industrial wastes;
pollution of coastal waters from raw sewage and oil
spills
Environment • international agreements:
party to: Biodiversity, Climate Change,
Desertification, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Environmental Modification,
Marine Life Conservation
Geography - note: Nahr el Litani is the only major
river in Near East not crossing an international
boundary; rugged terrain historically helped isolate,
protect, and develop numerous factional groups
based on religion, clan, and ethnicity','a2538a2f32687f11fa6371f00c58878c233ef24430348843528bc252e1b01894','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('75eb72a6a45aa3805501a62a849a0ff4befd62edf80ddc9e5d0f485afb180a28',2007,'ZA','South Africa','geography',813,'Location: Southern Africa, an enclave of South
Africa
Geographic coordinates: 29 30 S, 28 30 E
Map references: Africa
Area:
total: 30,355 sq km
land: 30,355 sq km
water: 0 sq km
Area • comparative: slightly smaller than Maryland
Land boundaries:
total: 909 km
border countries: South Africa 909 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cool to cold, dry winters; hot,
wet summers
Terrain: mostly highland with plateaus, hills, and
mountains
Elevation extremes:
lowest point: junction of the Orange and Makhaleng
Rivers 1 ,400 m
highest point: Thabana Ntlenyana 3,482 m
Natural resources: water, agricultural and grazing
land, diamonds, sand, clay, building stone
Land use:
arable land: 10.87%
permanent crops: 0. 1 3%
other: 89% (2005)
Irrigated land: 10 sq km (1998 est.)
Natural hazards: periodic droughts
Environment - current issues: population pressure
forcing settlement in marginal areas results in
overgrazing, severe soil erosion, and soil exhaustion;
desertification; Highlands Water Project controls,
stores, and redirects water to South Africa
Environment • international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Marine Life
Conservation, Ozone Layer Protection
signed, but not ratified: Law of the Sea
Geography - note: landlocked, completely
surrounded by South Africa; mountainous, more than
80% of the country is 1 ,800 meters above sea level','8b1a39164e970025853e063735bf76ab448e7e79e4622939886197be43d986ad','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('504b0a9ed546c7b4e06c60cfe69c5935d27da04dce063b49be53d9c440a9d002',2007,'LR','Liberia','geography',823,'Location: Western Africa, bordering the North Atlantic
Ocean, between Cote d''lvoire and Sierra Leone
Geographic coordinates: 6 30 N, 9 30 W
Map references: Africa
Area:
total: 111,370 sq km
land: 96,320 sq km
water: 15,050 sq km
Area • comparative: slightly larger than Tennessee
Land boundaries:
total: 1,585 km
border countries: Guinea 563 km, Cote d''lvoire 716
km, Sierra Leone 306 km
Coastline: 579 km
Maritime claims:
territorial sea: 200 nm
Climate: tropical; hot, humid; dry winters with hot
days and cool to cold nights; wet, cloudy summers
with frequent heavy showers
Terrain: mostly flat to rolling coastal plains rising to
rolling plateau and low mountains in northeast
324
Liberia (continued)
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point Mount Wuteve 1 ,380 m
Natural resources: iron ore, timber, diamonds, gold,
hydropower
Land use:
arable land: 3.43%
permanent crops: 1 .98%
other: 94.59% (2005)
Irrigated land: 30 sq km (1998 est.)
Natural hazards: dust-laden harmattan winds blow
from the Sahara (December to March)
Environment - current issues: tropical rain forest
deforestation; soil erosion; loss of biodiversity;
pollution of coastal waters from oil residue and raw
sewage
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94
signed, but not ratified: Environmental Modification,
Law of the Sea, Marine Life Conservation
Geography • note: facing the Atlantic Ocean, the
coastline is characterized by lagoons, mangrove
swamps, and river-deposited sandbars; the inland
grassy plateau supports limited agriculture','931a3c5318aa3115552e2af17eb37d97a682eff2b74db71e2f14d8b526eb0638','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3e620b110d522f965f037c9c84f73c1da51a01980841850ab284141c41c2cc7',2007,'CH','Switzerland','geography',832,'Geographic coordinates: 47 16 N, 9 32 E
Map references: Europe
Area:
fofa/:160sqkm
land: 160 sq km
water: 0 sq km
Area - comparative: about 0.9 times the size of
Washington, DC
Land boundaries:
total: 76 km
border countries: Austria 34.9 km, Switzerland
41.1 km
Coastline: 0 km (doubly landlocked)
Maritime claims: none (landlocked)
Climate: continental; cold, cloudy winters with
frequent snow or rain; cool to moderately warm,
cloudy, humid summers
Terrain: mostly mountainous (Alps) with Rhine
Valley in western third
Elevation extremes:
lowest point: Ruggeller Riet 430 m
highest point: Vorder-Grauspitz 2,599 m
Natural resources: hydroelectric potential, arable
land
Land use:
arable land: 25%
permanent crops: 0%
other: 75% (2005)
Irrigated land: NA sq km
Natural hazards: NA
Environment - current issues: NA
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulfur 85, Air Pollution-Sulfur 94, Air
Pollution-Volatile Organic Compounds, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Hazardous
Wastes, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea
Geography - note: along with Uzbekistan, one of
only two doubly landlocked countries in the world;
variety of microclimatic variations based on elevation','aff83c0d079a20ff49f6587d5df5e3863f81cacb1535780c04e3abd3c7e09e6c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0157f022571820adb2643905e49d3e3c40a1388f6f1235e244f4f7ffd20391f6',2007,'LT','Lithuania','geography',841,'Location: Eastern Europe, bordering the Baltic Sea,
between Latvia and Russia
Geographic coordinates: 56 00 N, 24 00 E
Map references: Europe
Area:
total: 65,200 sq km
land: NA sq km
water: NA sq km
Area - comparative: slightly larger than West
Virginia
Land boundaries:
total: 1,273 km
border countries: Belarus 502 km, Latvia 453 km,
Poland 91 km, Russia (Kaliningrad) 227 km
Coastline: 99 km
Maritime claims:
territorial sea: 12 nm
Climate: transitional, between maritime and
continental; wet, moderate winters and summers
Terrain: lowland, many scattered small lakes, fertile
soil
Elevation extremes:
lowest point: Baltic Sea 0 m
highest point: Juozapines Kalnas 292 m
Natural resources: peat, arable land, amber
Land use:
arable land: 44.81%
permanent crops: 0.9%
other: 54.29% (2005)
Irrigated land: 90 sq km (1998 est.)
Natural hazards: NA
Environment - current issues: contamination of
soil and groundwater with petroleum products and
chemicals at military bases
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol. Endangered
Species, Hazardous Wastes, Law of the Sea, Qzone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: An Pollution-Persistent
Organic Pollutants
Geography - note: fertile central plains are
separated by hilly uplands that are ancient glacial
deposits','b2f73114dc065db04b033cbff29431547bcffdf6c36a673cca8b291410064701','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e60c7d4481a676bd977bb207898a9506f879bd495cb741f3bfe60e2532756dc',2007,'DE','Germany','geography',849,'Location: Western Europe, between France and
Geographic coordinates: 49 45 N, 6 10 E
Map references: Europe
Area:
total: 2,586 sq km
land: 2,586 sq km
water: 0 sq km
Area - comparative: slightly smaller than Rhode
Island
Land boundaries:
total: 359 km
border countries: Belgium 148 km, France 73 km,
Germany 138 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: modified continental with mild winters, cool
summers
Terrain: mostly gently rolling uplands with broad,
shallow valleys; uplands to slightly mountainous in the
north; steep slope down to Moselle flood plain in the
southeast
Elevation extremes:
lowest point: Moselle River 133 m
highest point: Buurgplaatz 559 m
334
Luxembourg (continued)
Natural resources: iron ore (no longer exploited),
arable land
Land use:
arable land: 23.94%
permanent crops: 0.39%
other: 75.67% (includes Belgium) (2005)
Irrigated land: 40 sq km (includes Belgium)
(1998 est.)
Natural hazards: NA
Environment - current issues: air and water
pollution in urban areas, soil pollution of farmland
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulfur 85, Air Pollution-Sulfur 94, Air
Pollution-Volatile Organic Compounds, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed, but not ratified: Environmental Modification
Geography - note: landlocked; the only Grand
Duchy in the world
Location: Eastern Asia, bordering the South China
Sea and China
Geographic coordinates: 22 10 N, 1 13 33 E
Map references: Southeast Asia
Area:
total: 25.4 sq km
land: 25.4 sq km
wafer: 0 sq km
Area - comparative: about 0.1 times the size of
Washington, DC
Land boundaries:
total: 0.34 km
regional border: China 0.34 km
Coastline: 41 km
Maritime claims: not specified
Climate: subtropical; marine with cool winters, warm
summers
Terrain: generally flat
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Coloane Alto 172.4 m
Natural resources: NEGL
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: NA sq km
Natural hazards: typhoons
Environment - current issues: NA
Geography - note: essentially urban; one causeway
and two bridges connect the two islands of Coloane
and Taipa to the peninsula on mainland
Location: Southeastern Europe, north of Greece
Geographic coordinates: 41 50 N, 22 00 E
Map references: Europe
Area:
total: 25,333 sq km
land: 24,856 sq km
water: 477 sq km
Area • comparative: slightly larger than Vermont
Land boundaries:
total: 766 km
border countries: Albania 151 km, Bulgaria 148 km,
Greece 246 km, Serbia and Montenegro 221 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: warm, dry summers and autumns; relatively
cold winters with heavy snowfall
Terrain: mountainous territory covered with deep
basins and valleys; three large lakes, each divided by
a frontier line; country bisected by the Vardar River
Elevation extremes:
lowest point: Vardar River 50 m
highest point: Golem Korab (Maja e Korabit) 2,764 m
Natural resources: low-grade iron ore, copper, lead,
zinc, chromite, manganese, nickel, tungsten, gold,
silver, asbestos, gypsum, timber, arable land
Land use:
arable land: 22.01%
permanent crops: 1 .79%
other: 76.2% (2005)
Irrigated land: 550 sq km (1998 est.)
Natural hazards: high seismic risks
Environment - current issues: air pollution from
metallurgical plants
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Endangered
Species, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked; major transportation
corridor from Western and Central Europe to Aegean
Sea and Southern Europe to Western Europe','3cacee714a2651bed7626e8ae0f563db0083ef92438ac8a13bccbbc08c89e643','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d162f52f2f2731f9119b11d0d13d17fcda3d4cb49f5c0d65fd0a2b8568654db',2007,'MW','Malawi','geography',854,'Location: Southern Africa, east of Zambia
Geographic coordinates: 13 30 S. 34 00 E
Map references: Africa
Area:
total: 11 8,480 sq km
land: 94,080 sq km
water: 24,400 sq km
Area - comparative: slightly smaller than
Pennsylvania
Land boundaries:
tote/: 2,881 km
border countries: Mozambique 1 ,569 km, Tanzania
475 km, Zambia 837 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: sub-tropical; rainy season (November to
May); dry season (May to November)
Terrain: narrow elongated plateau with rolling plains,
rounded hills, some mountains
Elevation extremes:
lowest point: junction of the Shire River and
international boundary with Mozambique 37 m
highest point: Sapitwa (Mount Mlanje) 3,002 m
Natural resources: limestone, arable land,
hydropower, unexploited deposits of uranium, coal,
and bauxite
Land use:
arable land: 20.68%
permanent crops: 1 . 1 8%
other: 78.1 4% (2005)
Irrigated land: 280 sq km (1998 est.)
Natural hazards: NA
Environment - current issues: deforestation; land
degradation; water pollution from agricultural runoff,
sewage, industrial wastes; siltation of spawning
grounds endangers fish populations
Environment - international agreements:
party to: Biodiversity. Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Wetlands
signed, but not ratified: Law of the Sea
Geography - note: landlocked; Lake Nyasa, some
580 km long, is the country''s most prominent physical
feature','7f66a8b8a2de26380435b4f671e458a083c76ed0926de95272f3eca7dd608561','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16af4f23d333179066b9a981894a4260a4200d650d35654de7650adc7768e3c0',2007,'MV','Maldives','geography',871,'Location: Western Africa, southwest of Algeria
Geographic coordinates: 1 7 00 N, 4 00 W
Map references: Africa
Area:
total: 1 .24 million sq km
land: 1 .22 million sq km
water: 20,000 sq km
Area - comparative: slightly less than twice the size
of Texas
Land boundaries:
total: 7,243 km
border countries: Algeria 1,376 km, Burkina Faso
1,000 km, Guinea 858 km, Cote d''lvoire 532 km,
Mauritania 2,237 km, Niger 821 km, Senegal 419 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: subtropical to arid; hot and dry (February to
June); rainy, humid, and mild (June to November);
cool and dry (November to February)
Terrain: mostly flat to rolling northern plains covered
by sand; savanna in south, rugged hills in northeast
Elevation extremes:
lowest point: Senegal River 23 m
highest point: Hombori Tondo 1,155m
Natural resources: gold, phosphates, kaolin, salt,
limestone, uranium, gypsum, granite, hydropower
note: bauxite, iron ore, manganese, tin, and copper
deposits are known but not exploited
Land use:
arable land: 3.76%
permanent crops: 0.03%
other: 96.21% (2005)
Irrigated land: 1,380 sq km (1998 est.)
Natural hazards: hot, dust-laden harmattan haze
common during dry seasons; recurring droughts;
occasional Niger River flooding
Environment • current issues: deforestation; soil
erosion; desertification; inadequate supplies of
potable water; poaching
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked; divided into three
natural zones: the southern, cultivated Sudanese; the
central, semiarid Sahelian; and the northern, arid
Saharan','209d7fdca02f0f84a254351a1b693d2a95e9e77cd4c4ca5572226bb81885efbb','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f8a0496774634378fc4e813d9d14c0e93d84f35dbfe8ba3da613ddc4ea9feba3',2007,'MT','Malta','geography',874,'Location: Southern Europe, islands in the
Mediterranean Sea, south of Sicily (Italy)
Geographic coordinates: 35 50 N, 14 35 E
Map references: Europe
Area:
tote/:316sqkm
land: 316 sq km
water: 0 sq km
Area - comparative: slightly less than twice the size
of Washington, DC
Land boundaries: 0 km
Coastline: 196.8 km (does not include 56.01 km for
the island of Gozo)
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
continental shelf: 200-m depth or to the depth of
exploitation
exclusive fishing zone: 25 nm
Climate: Mediterranean; mild, rainy winters; hot, dry
summers
Terrain: mostly low, rocky, flat to dissected plains;
many coastal cliffs
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest po/''nf: Ta''Dmejrek 253 m (near Dingli)
Natural resources: limestone, salt, arable land
354
Malta (continued)
Land use:
arable land: 31.25%
permanent crops: 3. 1 3%
other: 65.62% (2005)
Irrigated land: 20 sq km (1998 est.)
Natural hazards: NA
Environment - current issues: very limited natural
fresh water resources; increasing reliance on
desalination
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Desertification,
Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Ozone Layer Protection, Ship
Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: the country comprises an
archipelago, with only the three largest islands (Malta,
Ghawdex or Gozo, and Kemmuna or Comino) being
inhabited; numerous bays provide good harbors;
Malta and Tunisia are discussing the commercial
exploitation of the continental shelf between their
countries, particularly for oil exploration','991bba19d11f65fd72b96bc17ab2413e415a18ad8b6f34f2430537fb7046a290','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2e4e66cfe9ac75145d341aff6c2508f80f53112ff584d420216d21c7396f8eed',2007,'MH','Marshall Islands','geography',883,'Location: Oceania, group of atolls and reefs in the
North Pacific Ocean, about one-half of the way from
Hawaii to Australia
Geographic coordinates: 9 00 N, 168 00 E
Map references: Oceania
Area:
total: 181 .3 sq km
land: 181 .3 sq km
water: 0 sq km
note: includes the atolls of Bikini, Enewetak,
Kwajalein, Majuro, Rongelap, and Utirik
Area - comparative: about the size of Washington,
DC
Land boundaries: 0 km
Coastline: 370.4 km
Maritime claims:
terhtohal sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical; hot and humid; wet season May to
November; islands border typhoon belt
Terrain: low coral limestone and sand islands
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location on Likiep 10 m
Natural resources: coconut products, marine
products, deep seabed minerals
356
Marshall Islands (continued)
Land use:
amble land: 11.11%
permanent crops: 44.44%
other: 44.45% (2005)
Irrigated land: 0 sq km
Natural hazards: infrequent typhoons
Environment - current issues: inadequate supplies
of potable water; pollution of Majuro lagoon from
household waste and discharges from fishing vessels
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: two archipelagic island chains of
30 atolls and 1,152 islands; Bikini and Enewetak are
former US nuclear test sites; Kwajalein, the famous
World War II battleground, is used as a US missile test
range','3f8e45558c433ac3baddec7bafe32745627fe82d5ade8c44fccaf4e8061a1f44','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e954d51282afc61f05f2a5c0e341421e35751076f447d0edda3f1d79946bd294',2007,'DZ','Algeria','geography',893,'Location: Northern Africa, bordering the North
Atlantic Ocean, between Senegal and Western
Sahara
Geographic coordinates: 20 00 N, 12 00 W
Map references: Africa
Area:
total: 1 ,030,700 sq km
land: 1,030,400 sq km
water: 300 sq km
Area - comparative: slightly larger than three times
the size of New Mexico
Land boundaries:
total: 5,074 km
border countries: Algeria 463 km, Mali 2,237 km,
Senegal 813 km, Western Sahara 1,561 km
360
Mauritania (continued)
Coastline: 754 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: desert; constantly hot, dry, dusty
Terrain: mostly barren, flat plains of the Sahara;
some central hills
Elevation extremes:
lowest point: Sebkhet Te-n-Dghamcha -5 m
highest point: Kediet Ijill 915 m
Natural resources: iron ore, gypsum, copper,
phosphate, diamonds, gold, oil, fish
Land use:
arable land: 0.2%
permanent crops: 0.01 %
other: 99.79% (2005)
Irrigated land: 490 sq km (1998 est.)
Natural hazards: hot, dry, dust/sand-laden sirocco
wind blows primarily in March and April; periodic droughts
Environment • current issues: overgrazing,
deforestation, and soil erosion aggravated by drought
are contributing to desertification; very limited natural
fresh water resources away from the Senegal, which
is the only perennial river; locust infestation
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: most of the population
concentrated in the cities of Nouakchott and
Nouadhibou and along the Senegal River in the
southern part of the country
Location: Southwestern Europe, bordering the Bay
of Biscay, Mediterranean Sea, North Atlantic Ocean,
and Pyrenees Mountains, southwest of France
Geographic coordinates: 40 00 N, 4 00 W
Map references: Europe
Area:
total: 504,782 sq km
land: 499,542 sq km
water. 5,240 sq km
note: there are 2 autonomous cities - Ceuta and
Melilla - and 17 autonomous communities including
Balearic Islands and Canary Islands, and three small
Spanish possessions off the coast of Morocco - Islas
Chafarinas, Penon de Alhucemas, and Penon de
Velez de la Gomera
Area ■ comparative: slightly more than twice the
size of Oregon
Land boundaries:
total: 1,917.8 km
border countries: Andorra 63.7 km, France 623 km,
Gibraltar 1 .2 km, Portugal 1 ,21 4 km, Morocco (Ceuta)
6.3 km, Morocco (Melilla) 9.6 km
515
Spain (continued)
Coastline: 4.964 km
Maritime claims:
territorial sea: 1 2 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm (applies only to the
Atlantic Ocean)
Climate: temperate; clear, hot summers in interior,
more moderate and cloudy along coast; cloudy, cold
winters in interior, partly cloudy and cool along coast
Terrain: large, flat to dissected plateau surrounded
by rugged hills; Pyrenees in north
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Pico de Teide (Tenerife) on Canary
Islands 3,718 m
Natural resources: coal, lignite, iron ore, copper,
lead, zinc, uranium, tungsten, mercury, pyrites,
magnesite, fluorspar, gypsum, sepiolite, kaolin,
potash, hydropower, arable land
Land use:
arable land: 27.1 8%
permanent crops: 9.85%
other: 62.97% (2005)
Irrigated land: 36,400 sq km (1998 est.)
Natural hazards: periodic droughts
Environment - current issues: pollution of the
Mediterranean Sea from raw sewage and effluents
from the offshore production of oil and gas; water
quality and quantity nationwide; air pollution;
deforestation; desertification
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulfur 94, Air Pollution-Volatile Organic
Compounds, Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Treaty,
Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Marine Dumping, Marine Life
Conservation, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants
Geography - note: strategic location along
approaches to Strait of Gibraltar','80fa1126819d04c81ace140a6ae0bd35ca9f1f8dc7d36ec9c9c1839cc1e06d7e','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a4802c5141ff861be299da1ece149a7b22cd7b2d68c25cefc845ea9c0751489',2007,'MU','Mauritius','geography',903,'Location: Southern Africa, island in the Indian
Ocean, east of Madagascar
Geographic coordinates: 20 17 S, 57 33 E
Map references: Political Map of the World
Area:
total: 2,040 sq km
land: 2,030 sq km
water: 1 0 sq km
note: includes Agalega Islands, Cargados Carajos
Shoals (Saint Brandon), and Rodrigues
Area • comparative: almost 1 1 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 177 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: tropical, modified by southeast trade winds;
warm, dry winter (May to November); hot, wet, humid
summer (November to May)
Terrain: small coastal plain rising to discontinuous
mountains encircling central plateau
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Mont Piton 828 m
Natural resources: arable land, fish
Land use:
arable land: 49.02%
permanent crops: 2.94%
other: 48.04% (2005)
Irrigated land: 200 sq km (2000 est.)
Natural hazards: cyclones (November to April);
almost completely surrounded by reefs that may pose
maritime hazards
Environment - current issues: water pollution,
degradation of coral reefs
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: the main island, from which the
country derives its name, is of volcanic origin and is
almost entirely surrounded by coral reefs','11f4798849fa7aaf362db31b8c9b4f318b2a2a8fa9e5f520f13e3e2caeddf318','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('05f322def09333e90236a5bf65b2806377446452ac47077a4224561c2aa35554',2007,'PG','Papua New Guinea','geography',917,'Location: Oceania, island group in the North Pacific
Ocean, about three-quarters of the way from Hawaii to','bb5de8daf4414d160591801165a3ec94490159265b6f5efa6a1bd8d10f8969a9','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf0e3e4fbddba1937fe2e4001215e00ba744e8c1b7858ba3696068da55e11c35',2007,'MC','Monaco','geography',919,'Location: Western Europe, bordering the
Mediterranean Sea on the southern coast of France,
near the border with Italy
Geographic coordinates: 43 44 N, 7 24 E
Map references: Europe
Area:
total: 1.95 sq km
land: 1.95 sq km
water: 0 sq km
Area - comparative: about three times the size of
The Mall in Washington, DC
Land boundaries:
total: 4.4 km
border countries: France 4.4 km
Coastline: 4.1 km
Maritime claims:
territorial sea: 12 nm
Climate: Mediterranean with mild, wet winters and
hot, dry summers
Terrain: hilly, rugged, rocky
Elevation extremes:
lowest point: Mediterranean Sea 0 m
highest point: Mont Agel 140 m
Natural resources: none
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (urban area) (2005)
Irrigated land: NA sq km
Natural hazards: NA
Environment ■ current issues: NA
Environment - international agreements:
party to: Air Pollution, Air Pollution-Volatile Organic
Compounds, Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: Climate Change-Kyoto
Protocol
Geography - note: second-smallest independent
state in the world (after Holy See); almost entirely
urban','b85702a12cad030bd63c6e5cb11fad76f099c1e4320b763054751965dd795431','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('308498efcba49f0eee39418fee02efbff23f24702bf7f9c04edb1e7475055906',2007,'MS','Montserrat','geography',932,'Location: Northern Africa, bordering the North
Atlantic Ocean and the Mediterranean Sea, between
Algeria and Western Sahara
Geographic coordinates: 32 00 N, 5 00 W
Map references: Africa
Area:
total: 446,550 sq km
land: 446,300 sq km
water: 250 sq km
Area • comparative: slightly larger than California
Land boundaries:
fofa/:2,017.9km
border countries: Algeria 1,559 km, Western Sahara
443 km, Spain (Ceuta) 6.3 km, Spain (Melilla) 9.6 km
Coastline: 1,835 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200-m depth or to the depth of
exploitation
Climate: Mediterranean, becoming more extreme in
the interior
Terrain: northern coast and interior are mountainous
with large areas of bordering plateaus, intermontane
valleys, and rich coastal plains
Elevation extremes:
lowest point: Sebkha Tah -55 m
highest point: Jebel Toubkal 4,165 m
Natural resources: phosphates, iron ore,
manganese, lead, zinc, fish, salt
Land use:
arable land: 19%
permanent crops: 2%
other: 79% (2005)
Irrigated land: 12,910 sq km (1998 est.)
Natural hazards: northern mountains geologically
unstable and subject to earthquakes; periodic
droughts
Environment - current issues: land degradation/
desertification (soil erosion resulting from farming of
marginal areas, overgrazing, destruction of
vegetation); water supplies contaminated by raw
sewage; siltation of reservoirs; oil pollution of coastal
waters
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Wetlands, Whaling
signed, but not ratified: Environmental Modification,
Law of the Sea
Geography - note: strategic location along Strait of','97a9b7f38d9f30cad350afc06607e3203de8d7d6c3d40abf8764b8977d8b8d37','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('032e9b7228f3e3a315be88a9b73a1a404573edf61a960278219dd04c6be55ac0',2007,'AO','Angola','geography',934,'Location: Southern Africa, bordering the South
Atlantic Ocean, between Angola and South Africa
Geographic coordinates: 22 00 S, 17 00 E
Map references: Africa
Area:
tote/: 825,41 8 sq km
land: 825,418 sq km
water: 0 sq km
Area - comparative: slightly more than half the size
of Alaska
Land boundaries:
total: 3,936 km
border countries: Angola 1,376 km, Botswana 1,360
km, South Africa 967 km, Zambia 233 km
Coastline: 1,572 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: desert; hot, dry; rainfall sparse and erratic
Terrain: mostly high plateau; Namib Desert along
coast; Kalahari Desert in east
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Konigstein 2,606 m
Natural resources: diamonds, copper, uranium,
gold, lead, tin, lithium, cadmium, zinc, salt,
hydropower, fish
note: suspected deposits of oil, coal, and iron ore
Land use:
arable land: 0.99%
permanent crops: 0.01 %
other: 99% (2005)
Irrigated land: 70 sq km (1998 est )
Natural hazards: prolonged periods of drought
Environment - current issues: very limited natural
fresh water resources; desertification; wildlife
poaching; land degradation has led to few
conservation areas
Environment - international agreements:
party to: Antarctic-Marine Living Resources,
Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species,
Hazardous Wastes, Law of the Sea, Ozone Layer
Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: first country in the world to
incorporate the protection of the environment into
its constitution; some 14% of the land is protected,
including virtually the entire Namib Desert coastal
strip','9fd02115b0e98b03c07d0934233ec101c82d381b63f412f0b8e579a5e4729694','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bfe175b93c92eade06726caadd26e013630e77d307fb670e5926b1cbc9b43742',2007,'NR','Nauru','geography',943,'Location: Oceania, island in the South Pacific
Ocean, south of the Marshall Islands
Geographic coordinates: 0 32 S, 166 55 E
Map references: Oceania
Area:
total: 21 sq km
land: 21 sq km
water: 0 sq km
Area • comparative: about 0.1 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 30 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical with a monsoonal pattern; rainy
season (November to February)
Terrain: sandy beach rises to fertile ring around
raised coral reefs with phosphate plateau in center
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location along plateau rim
61m
Natural resources: phosphates, fish
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: NA
Natural hazards: periodic droughts
389
Nauru (continued)
Environment - current issues: limited natural fresh
water resources, roof storage tanks collect rainwater,
but mostly dependent on a single, aging desalination
plant; intensive phosphate mining during the past 90
years - mainly by a UK, Australia, and NZ consortium -
has left the central 90% of Nauru a wasteland and
threatens limited remaining land resources
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: Nauru is one of the three great
phosphate rock islands in the Pacific Ocean - the others
are Banaba (Ocean Island) in Kiribati and Makatea in
French Polynesia; only 53 km south of Equator
Location: Caribbean, island in the Caribbean Sea,
35 miles west of Tiburon Peninsula of Haiti
Geographic coordinates: 18 25 N, 75 02 W
Map references: Central America and the
Caribbean
Area:
total: 5.4 sq km
land: 5.4 sq km
water: 0 sq km
Area - comparative: about nine times the size of
The Mall in Washington, DC
Land boundaries: 0 km
Coastline: 8 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: marine, tropical
Terrain: raised coral and limestone plateau, flat to
undulating; ringed by vertical white cliffs (9 to 15 m
high)
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: unnamed location on southwest side
77 m
Natural resources: guano
391
Navassa Island (continued)
Land use:
arable land: 0%
permanent crops: 0%
other 100% (2005)
Irrigated land: 0 sq km (1998 est.)
Natural hazards: hurricanes
Environment • current issues: NA
Geography - note: strategic location 160 km south
of the US Naval Base at Guantanamo Bay, Cuba;
mostly exposed rock but with enough grassland to
support goat herds; dense stands of fig-like trees,
scattered cactus','a3c995a491adb1634a782b1d49bb3a74a8f80f556320fbce835f90e627f1a201','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('401dbccef9f92cb40e7ea6e1b7a037af7b8d83c75a03e15d002e2ad9e8c76a8f',2007,'NP','Nepal','geography',954,'Location: Southern Asia, between China and India
Geographic coordinates: 28 00 N, 84 00 E
Map references: Asia
Area:
total: 140,800 sq km
land: 136,800 sq km
water: 4,000 sq km
Area - comparative: slightly larger than Arkansas
Land boundaries:
total: 2,926 km
border countries: China 1 ,236 km. India 1 .690 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: varies from cool summers and severe
winters in north to subtropical summers and mild
winters in south
Terrain: Tarai or flat river plain of the Ganges in
south, central hill region, rugged Himalayas in north
Elevation extremes:
lowest point: Kanchan Kalan 70 m
highest point: Mount Everest 8,850 m
Natural resources: quartz, water, timber,
hydropower, scenic beauty, small deposits of lignite,
copper, cobalt, iron ore
Land use:
arable land: 16.07%
permanent crops: 0.85%
other: 83.08% (2005)
Irrigated land: 1 1 ,350 sq km (1998 est.)
Natural hazards: severe thunderstorms, flooding,
landslides, drought, and famine depending on the
timing, intensity, and duration of the summer
monsoons
Environment • current issues: deforestation
(overuse of wood for fuel and lack of alternatives);
contaminated water (with human and animal wastes,
agricultural runoff, and industrial effluents); wildlife
conservation; vehicular emissions
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Tropical Timber 83, Tropical Timber 94, Wetlands
signed, but not ratified: Marine Life Conservation
Geography - note: landlocked; strategic location
between China and India; contains eight of world''s 10
highest peaks, including Mount Everest - the world''s
tallest - on the border with China
392
Nepal (continued)
Location: Western Europe, bordering the North Sea,
between Belgium and Germany
Geographic coordinates: 52 30 N, 5 45 E
Map references: Europe
Area:
total: 41,526 sq km
land: 33,883 sq km
water: 7,643 sq km
Area - comparative: slightly less than twice the size
of New Jersey
Land boundaries:
total: 1,027 km
border countries: Belgium 450 km, Germany 577 km
Coastline: 451 km
Maritime claims:
territorial sea: 12 nm
exclusive fishing zone: 200 nm
Climate: temperate; marine; cool summers and mild
winters
Terrain: mostly coastal lowland and reclaimed land
(polders); some hills in southeast
Elevation extremes:
lowest point: Zuidplaspolder -7 m
highest point: Vaalserberg 322 m
Natural resources: natural gas, petroleum, peat,
limestone, salt, sand and gravel, arable ''and
Land use:
arable land: 21.96%
permanent crops: 0.77%
other: 77.27% (2005)
Irrigated land: 5,650 sq km (1998 est.)
Natural hazards: flooding
Environment - current issues: water pollution in
the form of heavy metals, organic compounds, and
nutrients such as nitrates and phosphates; air
pollution from vehicles and refining activities; acid rain
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulfur 85, Air Pollution-Sulfur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Kyoto Protocol, Law
of the Sea, Marine Dumping, Marine Life
Conservation, Ozone Layer Protection, Ship Pollution,
Tropical Timber 83, Tropical Timber 94, Wetlands,
Whaling
Geography - note: located at mouths of three major
European rivers (Rhine, Maas or Meuse, and
Schelde)','98807dd9636f16bd44edc07fb2fa050d410b5f924f29829e86bac652d5a2fd49','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fd90d84ab9bf5b2505805c0a346854422e9668024bb95f902c14a9dc34b582e',2007,'VU','Vanuatu','geography',964,'Location: Oceania, islands in the South Pacific
Ocean, east of Australia
Geographic coordinates: 21 30 S, 165 30 E
Map references: Oceania
Area:
total: 19,060 sq km
land: 18,575 sq km
water: 485 sq km
Area - comparative: slightly smaller than New
Location: Oceania, group of islands in the South
Pacific Ocean, east of Papua New Guinea
Geographic coordinates: 8 00 S, 159 00 E
Map references: Oceania
Area:
total: 28,450 sq km
land: 27,540 sq km
water: 91 Osq km
Area - comparative: slightly smaller than Maryland
Land boundaries: 0 km
Coastline: 5,313 km
Maritime claims: measured from claimed
archipelagic baselines
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelt: 200 nm
Climate: tropical monsoon; few extremes of
temperature and weather
Terrain: mostly rugged mountains with some low
coral atolls
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Makarakomburu 2,447 m
Natural resources: fish, forests, gold, bauxite,
phosphates, lead, zinc, nickel
Land use:
arable land: 0.62%
permanent crops: 2.04%
other: 97.34% (2005)
Irrigated land: NA
Natural hazards: typhoons, but rarely destructive;
geologically active region with frequent earth tremors;
volcanic activity
Environment - current issues: deforestation; soil
erosion; many of the surrounding coral reefs are dead
or dying
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification,
Environmental Modification, Law of the Sea, Marine
Dumping, Marine Life Conservation, Ozone Layer
Protection, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location on sea routes
between the South Pacific Ocean, the Solomon Sea,
and the Coral Sea
Location: Northern South America, bordering the
Caribbean Sea and the North Atlantic Ocean,
between Colombia and Guyana
Geographic coordinates: 8 00 N, 66 00 W
Map references: South America
Area:
total: 912,050 sq km
land: 882,050 sq km
water: 30,000 sq km
Area ■ comparative: slightly more than twice the
size of California
Land boundaries:
total: 4,993 km
border countries: Brazil 2,200 km, Colombia 2,050
km, Guyana 743 km
Coastline: 2,800 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 15 nm
exclusive economic zone: 200 nm
continental shelf: 200-m depth or to the depth of
exploitation
597
Venezuela (continued)
Climate: tropical; hot, humid; more moderate in
highlands
Terrain: Andes Mountains and Maracaibo Lowlands
m northwest; central plains (llanos); Guiana Highlands
in southeast
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Pico Bolivar (La Columna) 5,007 m
Natural resources: petroleum, natural gas, iron ore,
gold, bauxite, other minerals, hydropower, diamonds
Land use:
arable land: 2.85%
permanent crops: 0.88%
other: 96.27% (2005)
Irrigated land: 540 sq km (1998 est.)
Natural hazards: subject to floods, rockslides,
mudslides; periodic droughts
Environment - current issues: sewage pollution of
Lago de Valencia; oil and urban pollution of Lago de
Maracaibo; deforestation; soil degradation; urban and
industrial pollution, especially along the Caribbean
coast; threat to the rainforest ecosystem from
irresponsible mining operations
Environment - international agreements:
party to: Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Hazardous
Wastes, Marine Life Conservation, Ozone Layer
Protection, Ship Pollution, Tropical Timber 83,
Tropical Timber 94, Wetlands
signed but not ratified: none of the selected
agreements
Geography - note: on major sea and air routes
linking North and South America; Angel Falls in the
Guiana Highlands is the world''s highest waterfall','c7c97c4009522b4dd3a07608cbd6bb015d785b6a76995752a557547ec989ded2','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('766a323f319ab45e40d5378097a8cc51eed2b63d111f58bffecebed38160ca45',2007,'ML','Mali','geography',968,'Location: Western Africa, southeast of Algeria
Geographic coordinates: 16 00 N, 8 00 E
Map references: Africa
Area:
total: 1 .267 million sq km
land: 1 ,266,700 sq km
water: 300 sq km
Area - comparative: slightly less than twice the size
of Texas
Land boundaries:
total: 5,697 km
border countries: Algeria 956 km, Benin 266 km,
Burkina Faso 628 km, Chad 1 ,1 75 km, Libya 354 km,
Mali 821 km, Nigeria 1,497 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: desert; mostly hot, dry, dusty; tropical in
extreme south
Terrain: predominately desert plains and sand
dunes; flat to rolling plains in south; hills in north
Elevation extremes:
lowest point: Niger River 200 m
highest point: Mont Bagzane 2,022 m
Natural resources: uranium, coal, iron ore, tin,
phosphates, gold, molybdenum, gypsum, salt,
petroleum
Land use:
arable land: 1 1 .43%
permanent crops: 0.01 %
other: 88.56% (2005)
Irrigated land: 660 sq km (1998 est.)
Natural hazards: recurring droughts
Environment • current issues: overgrazing; soil
erosion; deforestation; desertification; wildlife
populations (such as elephant, hippopotamus, giraffe,
and lion) threatened because of poaching and habitat
destruction
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Ozone Layer Protection, Wetlands
signed, but not ratified: Law of the Sea
Geography - note: landlocked; one of the hottest
countries in the world; northern four-fifths is desert,
southern one-fifth is savanna, suitable for livestock
and limited agriculture','f25cbe6c1db669fd658fd9cc95d6a79b84fd5194b209d9e72d847b81254638e5','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('11dc812876823d430067a7d7cfa2e988bd856029cc0e075dbfc6e286cda2e4ec',2007,'NE','Niger','geography',978,'Location: Western Africa, bordering the Gulf of
Guinea, between Benin and Cameroon
Geographic coordinates: 10 00 N, 8 00 E
Map references: Africa
Area:
total: 923,768 sq km
land: 91 0,768 sq km
water: 13,000 sq km
Area - comparative: slightly more than twice the
size of California
Land boundaries:
total: 4,047 km
border countries: Benin 773 km, Cameroon 1 ,690 km,
Chad 87 km, Niger 1,497 km
Coastline: 853 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
continental shelf: 200-m depth or to the depth of
exploitation
Climate: varies; equatorial in south, tropical in
center, arid in north
409
Nigeria (continued)
Terrain: southern lowlands merge into central hills
and plateaus; mountains in southeast, plains in north
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Chappal Waddi 2,419 m
Natural resources: natural gas, petroleum, tin, iron
ore, coal, limestone, niobium, lead, zinc, arable land
Land use:
arable land: 33.02%
permanent crops: 3.14%
other: 63.84% (2005)
Irrigated land: 2,330 sq km (1998 est.)
Natural hazards: periodic droughts; flooding
Environment - current issues: soil degradation;
rapid deforestation; urban air and water pollution;
desertification; oil pollution - water, air, and soil; has
suffered serious damage from oil spills; loss of arable
land; rapid urbanization
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Marine Life Conservation, Ozone Layer
Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: the Niger enters the country in the
northwest and flows southward through tropical rain
forests and swamps to its delta in the Gulf of Guinea','082764d32327938526b4173bac0b0cc9ff8706d3d13ad6e3640a7dc0095b48b7','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d90670694dfced34affb3b2c0700dfeb7f3b2af5ef548313d0e7439a2cf3bf35',2007,'NU','Niue','geography',984,'Location: Oceania, island in the South Pacific
Ocean, east of Tonga
Geographic coordinates: 19 02 S, 169 52 W
Map references: Oceania
Area:
total: 260 sq km
land: 260 sq km
water: 0 sq km
Area - comparative: 1 .5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 64 km
Maritime claims:
territorial sea: 1 2 nm
exclusive economic zone: 200 nm
Climate: tropical; modified by southeast trade winds
Terrain: steep limestone cliffs along coast, central
plateau
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location near Mutalau
settlement 68 m
Natural resources: fish, arable land
Land use:
arable land: 1 1 .54%
permanent crops: 15.38%
other: 73.08% (2005)
412
Niue (continued)
Irrigated land: NA
Natural hazards: typhoons
Environment - current issues: increasing attention
to conservationist practices to counter loss of soil
fertility from traditional slash and burn agriculture
Environment - international agreements:
parly to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification
signed, but not ratified: Law of the Sea
Geography - note: one of world''s largest coral
islands','703e84bc07e13bd51f5d6a79c382c0b7ffb1a88f66d202d156fc12049f59a4ce','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a543d60acf39b89af67ef1e1085fde232421538119c9180d88c81e7031cf6db',2007,'NF','Norfolk Island','geography',993,'Location: Oceania, island in the South Pacific
Ocean, east of Australia
Geographic coordinates: 29 02 S, 167 57 E
Map references: Oceania
Area:
total: 34.6 sq km
land: 34.6 sq km
water: 0 sq km
Area - comparative: about 0.2 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 32 km
Maritime claims:
territorial sea: 1 2 nm
exclusive fishing zone: 200 nm
Climate: subtropical; mild, little seasonal
temperature variation
Terrain: volcanic formation with mostly rolling plains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Bates 319 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (2005)
Irrigated land: NA
Natural hazards: typhoons (especially May to July)
Environment - current issues: NA
Geography - note: most of the 32 km coastline
consists of almost inaccessible cliffs, but the land
slopes down to the sea in one small southern area on
Sydney Bay, where the capital of Kingston is situated
414
Norfolk Island (continued)','cbe9e0c6600d88861c67d01d9fb2da9303cb83ff66dcc51712e48dec284688e8','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e14ab4afac743b8e0765234d02c837ad4e3ca65929d52df50b934979ec5954cc',2007,'OM','Oman','geography',1005,'Location: Middle East, bordering the Arabian Sea,
Gulf of Oman, and Persian Gulf, between Yemen and
UAE
Geographic coordinates: 21 00 N, 57 00 E
Map references: Middle East
Area:
total: 212,460 sq km
land: 212,460 sq km
water: 0 sq km
Area - comparative: slightly smaller than Kansas
Land boundaries:
total: 1 ,374 km
border countries: Saudi Arabia 676 km, UAE 410 km,
Yemen 288 km
Coastline: 2,092 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: dry desert; hot, humid along coast; hot, dry
interior; strong southwest summer monsoon (May to
September) in far south
Terrain: central desert plain, rugged mountains in
north and south
Elevation extremes:
lowest point: Arabian Sea 0 m
highest point: Jabal Shams 2,980 m
Natural resources: petroleum, copper, asbestos,
some marble, limestone, chromium, gypsum, natural gas
Land use:
arable land: 0.12%
permanent crops: 0. 1 4%
other: 99.74% (2005)
Irrigated land: 620 sq km (1998 est.)
Natural hazards: summer winds often raise large
sandstorms and dust storms in interior; periodic droughts
Environment - current issues: rising soil salinity;
beach pollution from oil spills; very limited natural
fresh water resources
Environment • international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location on Musandam
Peninsula adjacent to Strait of Hormuz, a vital transit
point for world crude oil','8f18afb5205174d666e3412444b8985389ab74291dcc874edbfb955a91d20a63','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b74e24bdcf85bb5d408b19447b6ab36050fb3ee13748bb2fa6e0098fc5ba5152',2007,'PK','Pakistan','geography',1014,'Location: Southern Asia, bordering the Arabian Sea,
between India on the east and Iran and Afghanistan
on the west and China in the north
Geographic coordinates: 30 00 N, 70 00 E
Map references: Asia
Area:
total: 803,940 sq km
land: 778,720 sq km
water: 25,220 sq km
Area • comparative: slightly less than twice the size
of California
Land boundaries:
total: 6,774 km
border countries: Afghanistan 2,430 km, China 523
km, India 2,912 km, Iran 909 km
Coastline: 1,046 km
Maritime claims:
territorial sea: 1 2 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: mostly hot, dry desert; temperate in
northwest; arctic in north
Terrain: flat Indus plain in east; mountains in north
and northwest; Balochistan plateau in west
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: K2 (Mt. Godwin-Austen) 8,61 1 m
Natural resources: land, extensive natural gas
reserves, limited petroleum, poor quality coal, iron ore,
copper, salt, limestone
Land use:
arable land: 24.44%
permanent crops: 0.84%
other: 74.72% (2005)
Irrigated land: 180,000 sq km (1998 est.)
Natural hazards: frequent earthquakes,
occasionally severe especially in north and west;
flooding along the Indus after heavy rains (July and
August)
Environment - current issues: water pollution from
raw sewage, industrial wastes, and agricultural runoff;
limited natural fresh water resources; a majority of the
population does not have access to potable water;
deforestation; soil erosion; desertification
Environment • international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
Geography - note: controls Khyber Pass and Bolan
Pass, traditional invasion routes between Central Asia
and the Indian Subcontinent','c8afb74dec6dde1137381b0010e4b093f7a9ae41b4cf6a3dc3d605c7ada6c452','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6af82513a4038a18c1b96131774a0a33f82b2737364a0abbb1464bda7d9cd17a',2007,'PW','Palau','geography',1023,'Location: Oceania, group of islands in the North
Pacific Ocean, southeast of the Philippines
Geographic coordinates: 7 30 N, 134 30 E
Map references: Oceania
Area:
total: 458 sq km
land: 458 sq km
water: 0 sq km
Area - comparative: slightly more than 2.5 times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 1,519 km
Maritime claims:
territorial sea: 3 nm
exclusive fishing zone: 200 nm
Climate: tropical; hot and humid; wet season May to
November
Terrain: varying geologically from the high,
mountainous main island of Babelthuap to low, coral
islands usually fringed by large barrier reefs
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mount Ngerchelchuus 242 m
Natural resources: forests, minerals (especially
gold), marine products, deep-seabed minerals
Land use:
arable land: 8.7%
permanent crops: 4.35%
other: 86.95% (2005)
427
Palau (continued)
Irrigated land: NA
Natural hazards: typhoons (June to December)
Environment - current issues: inadequate facilities
for disposal of solid waste; threats to the marine
ecosystem from sand and coral dredging, illegal
fishing practices, and overfishing
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Law of the
Sea. Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: westernmost archipelago in the
Caroline chain, consists of six island groups totaling
more than 300 islands; includes World War II
battleground of Beliliou (Peleliu) and world-famous
rock islands','4eb9d6839a167a817d6c541c13617c8e2347a6cebc60399e6e8bc3e3612d9a33','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f648fed39af2faf49e34926b2712fe0b7af0309265c1dda6f82cebed8ddf197',2007,'PL','Poland','geography',1033,'Location: Central Europe, east of Germany
Geographic coordinates: 52 00 N, 20 00 E
Map references: Europe
Area:
tote/:312,685sqkm
land: 304,465 sq km
water: 8,220 sq km
Area - comparative: slightly smaller than New','5535986909c076e76c830a18454708e76a719d6f31621b355ab713cf35964f6b','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f68f6c425dfd3877cb4c76a2a172189b01aae834ef7242da90908db304b854f',2007,'MX','Mexico','geography',1034,'Land boundaries:
total: 2,788 km
border countries: Belarus 407 km, Czech Republic
658 km, Germany 456 km, Lithuania 91 km, Russia
(Kaliningrad Oblast) 206 km, Slovakia 444 km,
Ukraine 526 km
Coastline: 491 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: defined by international
treaties
Climate: temperate with cold, cloudy, moderately
severe winters with frequent precipitation; mild
summers with frequent showers and
thundershowers
Terrain: mostly flat plain; mountains along southern
border
Elevation extremes:
lowest point: near Raczki Elblaskie -2 m
highest point: Rysy 2,499 m
Natural resources: coal, sulfur, copper, natural gas,
silver, lead, salt, amber, arable land
Land use:
arable land: 40.25%
permanent crops: 1%
other: 58.75% (2005)
Irrigated land: 1 ,000 sq km (1998 est.)
Natural hazards: flooding
Environment - current issues: situation has
improved since 1 989 due to decline in heavy industry
and increased environmental concern by
post-Communist governments; air pollution
nonetheless remains serious because of sulfur
dioxide emissions from coal-fired power plants, and
the resulting acid rain has caused forest damage;
water pollution from industrial and municipal sources
is also a problem, as is disposal of hazardous wastes;
pollution levels should continue to decrease as
industrial establishments bring their facilities up to EU
code, but at substantial cost to business and the','6588dc04b24f1c12cac12737fb85bdd87ad739e37e8c8fdcae71636ad1cfdda3','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('246ae44464d70db2b32d710895f0093594e5b089b947665c7693892afb3291c4',2007,'BH','Bahrain','geography',1049,'Location: Middle East, peninsula bordering the
Persian Gulf and Saudi Arabia
Geographic coordinates: 25 30 N, 51 15 E
Map references: Middle East
Area:
total: 1 1,437 sq km
land: 1 1,437 sq km
water: 0 sq km
Area - comparative: slightly smaller than
Connecticut
Land boundaries:
total: 60 km
border countries: Saudi Arabia 60 km
Coastline: 563 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: as determined by bilateral
agreements or the median line
Climate: arid; mild, pleasant winters; very hot, humid
summers
Terrain: mostly flat and barren desert covered with
loose sand and gravel
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Qurayn Abu al Bawl 103 m
Natural resources: petroleum, natural gas, fish
Land use:
arable land: 1 .64%
permanent crops: 0.27%
other: 98.09% (2005)
Irrigated land: 130 sq km (1998 est.)
Natural hazards: haze, dust storms, sandstorms
common
Environment - current issues: limited natural fresh
water resources are increasing dependence on
large-scale desalination facilities
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species. Hazardous Wastes, Law of the Sea, Ozone
Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location in central
Persian Gulf near major petroleum deposits
Location: Southern Africa, island in the Indian
Ocean, east of Madagascar
Geographic coordinates: 21 06 S, 55 36 E
Map references: World
Area:
tote/: 2,51 7 sq km
land: 2,507 sq km
water: 10 sq km
Area - comparative: slightly smaller than Rhode
Island
Land boundaries: 0 km
Coastline: 207 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical, but temperature moderates with
elevation; cool and dry (May to November), hot and
rainy (November to April)
Terrain: mostly rugged and mountainous; fertile
lowlands along coast
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Piton des Neiges 3,069 m
Natural resources: fish, arable land, hydropower
Land use:
arable land: 13.94%
permanent crops: 1 .59%
other: 84.47% (2005)
Irrigated land: 120 sq km (1998 est.)
456
Reunion (continued)
Natural hazards: periodic, devastating cyclones
(December to April); Piton de la Foumaise on the
southeastern coast is an active volcano
Environment -current issues: NA
Geography - note: this mountainous, volcanic
island has an active volcano, Piton de la Foumaise;
there is a tropical cyclone center at Saint-Denis, which
is the monitoring station for the whole of the Indian
Ocean','907d98cd9de3e30b5792d67a011168cee63f2aefbb64be180da7dff26d297163','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fe619b3d163d6b6716e75e15ea9fa6b83eff101120e12027f78440e48355ca22',2007,'SK','Slovakia','geography',1052,'Location: Southeastern Europe, bordering the Black
Sea, between Bulgaria and Ukraine
Geographic coordinates: 46 00 N, 25 00 E
Map references: Europe
Area:
total: 237,500 sq km
land: 230,340 sq km
water: 7,160 sq km
Area - comparative: slightly smaller than Oregon
Land boundaries:
total: 2,508 km
border countries: Bulgaria 608 km, Hungary 443 km,
Moldova 450 km, Serbia and Montenegro 476 km,
Ukraine (north) 362 km, Ukraine (east) 169 km
Coastline: 225 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200-m depth or to the depth of
exploitation
Climate: temperate; cold, cloudy winters with
frequent snow and fog; sunny summers with frequent
showers and thunderstorms
Terrain: central Transylvanian Basin is separated
from the Plain of Moldavia on the east by the
Carpathian Mountains and separated from the
Walachian Plain on the south by the Transylvanian
Alps
Elevation extremes:
lowest point: Black Sea 0 m
highest point: Moldoveanu 2,544 m
Natural resources: petroleum (reserves declining),
timber, natural gas, coal, iron ore, salt, arable land,
hydropower
Land use:
arable land: 39.49%
permanent crops: 1 .92%
other: 58.59% (2005)
Irrigated land: 28,800 sq km (1998 est.)
Natural hazards: earthquakes, most severe in south
and southwest; geologic structure and climate
promote landslides
Environment - current issues: soil erosion and
degradation; water pollution; air pollution in south from
industrial effluents; contamination of Danube delta
wetlands
Environment - international agreements:
party to: Air Pollution, Air Pollution-Persistent Organic
Pollutants, Antarctic Treaty, Biodiversity, Climate
Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: controls most easily traversable
land route between the Balkans, Moldova, and
Location: Central Europe, south of Poland
Geographic coordinates: 48 40 N, 19 30 E
Map references: Europe
Area:
total: 48,845 sq km
land: 48,800 sq km
water: 45 sq km
Area - comparative: about twice the size of New
Hampshire
Land boundaries:
total: 1,524 km
border countries: Austria 91 km, Czech Republic 215
km, Hungary 677 km, Poland 444 km, Ukraine 97 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; cool summers; cold, cloudy,
humid winters
Terrain: rugged mountains in the central and
northern part and lowlands in the south
Elevation extremes:
lowest point: Bodrok River 94 m
highest point: Gerlachovsky Stit 2,655 m
Natural resources: brown coal and lignite; small
amounts of iron ore, copper and manganese ore; salt;
arable land
Land use:
arable land: 29.23%
permanent crops: 2.67%
other: 68.1% (2005)
Irrigated land: 1 ,740 sq km (1998 est.)
Natural hazards: NA
Environment - current issues: air pollution from
metallurgical plants presents human health risks; acid
rain damaging forests
Environment • international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulfur 85, Air Pollution-Sulfur 94, Air
Pollution-Volatile Organic Compounds, Antarctic
Treaty, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked; most of the country
is rugged and mountainous; the Tatra Mountains in
the north are interspersed with many scenic lakes and
valleys','f6032ba6fd2ee94e1037528f006b9b8a99685ba88f17557b7de6ad9e6b00816e','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c7c819b0d3f6e9b7c5407082892064996751675fda29bea0418062678c3e32ec',2007,'RW','Rwanda','geography',1062,'Location: Central Africa, east of Democratic
Republic of the Congo
Geographic coordinates: 2 00 S, 30 00 E
Map references: Africa
Area:
total: 26,338 sq km
land: 24,948 sq km
water. 1 ,390 sq km
Area - comparative: slightly smaller than Maryland
Land boundaries:
total. 893 km
border countries: Burundi 290 km, Democratic
Republic of the Congo 217 km, Tanzania 217 km,
Uganda 169 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; two rainy seasons (February4o
April, November to January); mild in mountains with
frost and snow possible
Terrain: mostly grassy uplands and hills; relief is
mountainous with altitude declining from west to east
Elevation extremes:
lowest point: Rusizi River 950 m
highest point: Volcan Karisimbi 4,519 m
Natural resources: gold, cassiterite (tin ore),
wolframite (tungsten ore), methane, hydropower,
arable land
Land use:
arable land: 45.56%
permanent crops: 10.25%
of/ier:44.19%(2005)
Irrigated land: 40 sq km (1998 est.)
Natural hazards: periodic droughts; the volcanic
Virunga mountains are in the northwest along the
border with Democratic Republic of the Congo
Environment ■ current issues: deforestation
results from uncontrolled cutting of trees for fuel;
overgrazing; soil exhaustion; soil erosion; widespread
poaching
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Ozone Layer Protection
signed, but not ratified: Law of the Sea
Geography - note: landlocked; most of the country
is savanna grassland with the population
predominantly rural
Location: islands in the South Atlantic Ocean, about
midway between South America and Africa;
Ascension Island lies 700 nm northwest of Saint
Helena; Tristan da Cunha lies 2300 nm southwest of
Saint Helena
Geographic coordinates:
Saint Helena: 15 57 S 5 42 W
Ascension Island: 7 57 S 14 22 W
Tristan da Cunha island group: 37 1 5 S 1 2 30 W
Map references: Africa
Area:
fofa/:413sqkm
land: Saint Helena Island 122 sq km; Ascension
Island 90 sq km; Tristan da Cunha island group 201 sq
km
water: 0 sq km
Area - comparative: slightly more than twice the
size of Washington, DC
Land boundaries: 0 km
Coastline:
Saint Helena: 60 km
Ascension Island: NA
Tristan da Cunha: 40 km
Maritime claims:
territorial sea: 1 2 nm
exclusive fishing zone: 200 nm
Climate:
Saint Helena: tropical marine; mild, tempered by trade
winds
Ascension Island: tropical marine; mild, semi-arid
Tristan da Cunha: temperate marine; mild, tempered
by trade winds (tends to be cooler than Saint Helena)
Terrain: the islands of this group result from volcanic
activity associated with the Atlantic Mid-Ocean Ridge
Saint Helena: rugged, volcanic; small scattered
plateaus and plains
Ascension: surface covered by lava flows and cinder
cones of 44 dormant volcanoes; ground rises to the
east
Tristan da Cunha: sheer cliffs line the coastline of the
nearly circular island; the flanks of the central volcanic
peak are deeply dissected; narrow coastal plain lies
between The Peak and the coastal cliffs
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Queen Mary''s Peak on Tristan da
Cunha 2,062 m; Green Mountain on Ascension Island
859 m; Mount Actaeon on Saint Helena Island 818 m
Natural resources: fish, lobster
Land use:
arable land: 12.9%
permanent crops: 0%
other: 87.1% (2005)
Irrigated land: NA sq km
Natural hazards: active volcanism on Tristan da
Cunha, last eruption in 1961
Environment - current issues: NA
Geography - note: Saint Helena harbors at least 40
species of plants unknown anywhere else in the world;
Ascension is a breeding ground for sea turtles and
sooty terns; Queen Mary''s Peak on Tristan da Cunha
is the highest island mountain in the South Atlantic
and a prominent landmark on the sea lanes around
southern Africa
Location: Caribbean, islands in the Caribbean Sea,
about one-third of the way from Puerto Rico to','44f684507a2cc3481ece4a7dc078a94227a80aff3062f05fc258ed3876b3df16','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3aa4810f21acc1a8d9f644538cbeff78dad1c6bfd0b83472ca6a385361d49c0',2007,'TT','Trinidad and Tobago','geography',1070,'Geographic coordinates: 17 20 N, 62 45 W
Map references: Central America and the
Caribbean
Area:
total: 261 sq km (Saint Kitts 168 sq km; Nevis 93 sq
km)
land: 261 sq km
water: 0 sq km
Area - comparative: 1 .5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 135 km
Maritime claims:
territorial sea: 1 2 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: tropical, tempered by constant sea breezes;
little seasonal temperature variation; rainy season
(May to November)
Terrain: volcanic with mountainous interiors
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Liamuiga 1,156 m
Natural resources: arable land
Land use:
arable land: 19.44%
permanent crops: 2.78%
other: 77.78% (2005)
Irrigated land: NA sq km
Natural hazards: hurricanes (July to October)
Environment - current issues: NA
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Ship Pollution, Whaling
signed, but not ratified: none of the selected
agreements
Geography ■ note: with coastlines in the shape of a
baseball bat and ball, the two volcanic islands are
separated by a three-km-wide channel called The
Narrows; on the southern tip of long, baseball bat-shaped
Saint Kitts lies the Great Salt Pond; Nevis Peak sits in the
center of its almost circular namesake island and its ball
shape complements that of its sister island
Geographic coordinates: 13 15 N, 61 12 W
Map references: Central America and the
Caribbean
Area:
total: 389 sq km (Saint Vincent 344 sq km)
land: 389 sq km
water: 0 sq km
Area - comparative: twice the size of Washington,
DC
Land boundaries: 0 km
Coastline: 84 km
Maritime claims:
territorial sea: 1 2 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm
Climate: tropical; little seasonal temperature
variation; rainy season (May to November)
Terrain: volcanic, mountainous
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: La Soufriere 1 ,234 m
Natural resources: hydropower, cropland
Land use:
arable land: 17.95%
permanent crops: 1 7.95%
other: 64.1% (2005)
Irrigated land: 10 sq km (1998 est.)
Natural hazards: hurricanes; Soufriere volcano on
the island of Saint Vincent is a constant threat
Environment - current issues: pollution of coastal
waters and shorelines from discharges by pleasure
yachts and other effluents; in some areas, pollution is
severe enough to make swimming prohibitive
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected
agreements
Geography • note: the administration of the islands
of the Grenadines group is divided between Saint
Vincent and the Grenadines and Grenada; Saint
Vincent and the Grenadines is comprised of 32
islands and cays','92d1829d4a60ed152acbe4e52a2cc1548dc83fda9570ecb7da0a0074173c0860','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ed778eadfa3d78daacfb140286c74b00a124c2c796a868dede76910a4015c0a',2007,'LC','Saint Lucia','geography',1080,'Location: Caribbean, island between the Caribbean
Sea and North Atlantic Ocean, north of Trinidad and
Tobago
Geographic coordinates: 1 3 53 N, 60 68 W
Map references: Central America and the
Caribbean
Area:
tofa/:616sqkm
land: 606 sq km
water: 10 sq km
Area - comparative: 3.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 158 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: tropical, moderated by northeast trade
winds; dry season January to April, rainy season May
to August
Terrain: volcanic and mountainous with some broad,
fertile valleys
Elevation extremes:
lowest point: Caribbean Sea 0 m
highest point: Mount Gimie 950 m
Natural resources: forests, sandy beaches,
minerals (pumice), mineral springs, geothermal
potential
Land use:
arable land: 6.45%
permanent crops: 22.58%
other: 70.97% (2005)
Irrigated land: 30 sq km (1998 est.)
Natural hazards: hurricanes and volcanic activity
Environment - current issues: deforestation; soil
erosion, particularly in the northern region
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: the twin Pitons (Gros Piton and
Petit Piton), striking cone-shaped peaks south of
Soufriere, are one of the scenic natural highlights of
the Caribbean
Location: Northern North America, islands in the
North Atlantic Ocean, south of Newfoundland
(Canada)
Geographic coordinates: 46 50 N, 56 20 W
Map references: North America
Area:
total: 242 sq km
land: 242 sq km
water: 0 sq km
nofe: includes eight small islands in the Saint Pierre
and the Miquelon groups
Area - comparative: 1 .5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 120 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: cold and wet, with much mist and fog;
spring and autumn are windy
Terrain: mostly barren rock
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Morne de la Grande Montagne 240 m
Natural resources: fish, deepwater ports
Land use:
arable land: 12.5%
permanent crops: 0%
ofher: 87.5% (2005)
Irrigated land: NA sq km
Natural hazards: persistent fog throughout the year
can be a maritime hazard
Environment - current issues: recent test drilling
for oil in waters around Saint Pierre and Miquelon may
bring future development that would impact the','f0184b3e574c33ab116f7ce4dc7f55cc39e0a2d529e79e38bcdf619574706df1','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('970f4c665cca5981b3a4e2fb6796680aa6a71fdcc8df5a2ada0ceaa2da708d05',2007,'GD','Grenada','geography',1086,'Location: Caribbean, islands between the
Caribbean Sea and North Atlantic Ocean, north of','334ce5ffd9ada7d21ee16b82bc79323e1134530f8353196e27a21aefa5cc8bf0','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d6969cf3474ed1096ff075af0d16538bfb21a8ba944067f5c4dc0ea9aac8d05f',2007,'WS','Samoa','geography',1091,'Location: Oceania, group of islands in the South
Pacific Ocean, about one-half of the way from Hawaii
to New Zealand
Geographic coordinates: 13 35 S, 172 20 W
Map references: Oceania
Area:
total: 2,944 sq km
land: 2,934 sq km
wafer: 10 sq km
Area - comparative: slightly smaller than Rhode
Island
Land boundaries: 0 km
Coastline: 403 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; rainy season (November to April),
dry season (May to October)
Terrain: two main islands (Savaii, Upolu) and several
smaller islands and uninhabited islets; narrow coastal
plain with volcanic, rocky, rugged mountains in interior
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Mauga Silisili (Savaii) 1,857 m
Natural resources: hardwood forests, fish,
hydropower
Land use:
arable land: 21.13%
permanent crops: 24.3%
other: 54.57% (2005)
Irrigated land: NA
Natural hazards: occasional typhoons; active
volcanism
Environment - current issues: soil erosion,
deforestation, invasive species, overfishing
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: occupies an almost central
position within Polynesia','bc78042666b22aaa132bc2b773b72029dab440cf6e7ac5977bce91ab321824da','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b1a3188b2cf00bb2ed17bd3fff1f57688c44a52944ef11fc8d904c9e417c0cfe',2007,'SA','Saudi Arabia','geography',1101,'Location: Middle East, bordering the Persian Gulf
and the Red Sea, north of Yemen
Geographic coordinates: 25 00 N, 45 00 E
Map references: Middle East
Area:
total: 1 ,960,582 sq km
land: 1 ,960,582 sq km
water: 0 sq km
Area - comparative: slightly more than one-fifth the
size of the US
Land boundaries:
total: 4,431 km
border countries: Iraq 814 km, Jordan 744 km, Kuwait
222 km, Oman 676 km, Qatar 60 km, UAE 457 km,
Yemen 1 ,458 km
Coastline: 2,640 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 1 8 nm
continental shelf: not specified
Climate: harsh, dry desert with great temperature
extremes
Terrain: mostly uninhabited, sandy desert
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Jabal Sawda'' 3,133 m
Natural resources: petroleum, natural gas, iron ore,
gold, copper
Land use:
arable land: 1 .67%
permanent crops: 0.09%
other: 98.24% (2005)
Irrigated land: 16,200 sq km (1998 est.)
Natural hazards: frequent sand and dust storms
Environment - current issues: desertification;
depletion of underground water resources; the lack of
perennial rivers or permanent water bodies has
prompted the development of extensive seawater
desalination facilities; coastal pollution from oil spills
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Ozone
Layer Protection
signed, but not ratified: none of the selected
agreements
Geography ■ note: extensive coastlines on Persian
Gulf and Red Sea provide great leverage on shipping
(especially crude oil) through Persian Gulf and Suez
Canal','94109d1956a06309d371485944e58007d28bf31beed336d9a4775ee84a448ed6','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dac291565aa1b5222f1768c212018af2bdcc302be4232ec3eb0da2cd8acb6e1d',2007,'SN','Senegal','geography',1109,'Location: Western Africa, bordering the North Atlantic
Ocean, between Guinea-Bissau and Mauritania
Geographic coordinates: 14 00 N, 14 00 W
Map references: Africa
Area:
total: 196,190 sq km
land: 1 92,000 sq km
water: 4,1 90 sq km
Area - comparative: slightly smaller than South
Dakota
Land boundaries:
total: 2,640 km
border countries: The Gambia 740 km, Guinea 330
km, Guinea-Bissau 338 km, Mali 419 km, Mauritania
813 km
Coastline: 531 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: tropical; hot, humid; rainy season (May to
November) has strong southeast winds; dry season
(December to April) dominated by hot, dry, harmattan
wind
487
Senegal (continued)
Terrain: generally low, rolling, plains rising tofoothills
in southeast
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: unnamed feature near Nepen Diakha
581 m
Natural resources: fish, phosphates, iron ore
Land use:
arable land: 12.51%
permanent crops: 0.24%
other: 87.25% (2005)
Irrigated land: 710 sq km (1998 est.)
Natural hazards: lowlands seasonally flooded;
periodic droughts
Environment • current issues: wildlife populations
threatened by poaching; deforestation; overgrazing;
soil erosion; desertification; overfishing
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Life Conservation, Ozone Layer Protection, Ship
Pollution, Wetlands, Whaling
Geography - note: westernmost country on the
African continent; The Gambia is almost an enclave
within Senegal','8faf6fe118d351d5dd10eeb6dc7179d67bbb3e6b8209b11c4c2ecaab8f344a2b','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2797fddf600f0ce8b06fbd765f045c2131a6ca18c2d00679741de24545b78430',2007,'ME','Montenegro','geography',1117,'Location: Southeastern Europe, bordering the
Adriatic Sea, between Albania and Bosnia and
Herzegovina
Geographic coordinates: 44 00 N, 21 00 E
Map references: Europe
Area:
total: 102,350 sq km
land: 102,136 sq km
wafer 21 4 sq km
Area - comparative: slightly smaller than Kentucky
Land boundaries:
total: 2,246 km
border countries: Albania 287 km, Bosnia and
Herzegovina 527 km, Bulgaria 318 km, Croatia (north)
241 km, Croatia (south) 25 km, Hungary 151 km,
Macedonia 221 km, Romania 476 km
Coastline: 199 km
Maritime claims: NA
Climate: in the north, continental climate (cold
winters and hot, humid summers with well distributed
rainfall); central portion, continental and
Mediterranean climate; to the south, Adriatic climate
along the coast, hot, dry summers and autumns and
relatively cold winters with heavy snowfall inland
Terrain: extremely varied; to the north, rich fertile
plains; to the east, limestone ranges and basins; to the
southeast, ancient mountains and hills; to the
southwest, extremely high shoreline with no islands
off the coast
Elevation extremes:
lowest point: Adriatic Sea 0 m
highest point: Daravica 2,656 m
Natural resources: oil, gas, coal, iron ore, bauxite,
copper, lead, zinc, antimony, chromite, nickel, gold,
silver, magnesium, pyrite, limestone, marble, salt,
hydropower, arable land
Land use:
arable land: 33.18%
permanent crops: 3.2%
other: 63.62% (2005)
Irrigated land: 570 sq km
Natural hazards: destructive earthquakes
Environment - current issues: pollution of coastal
waters from sewage outlets, especially in
tourist-related areas such as Kotor; air pollution
around Belgrade and other industrial cities; water
pollution from industrial wastes dumped into the Sava
which flows into the Danube
490
Serbia and Montenegro (continued)
Environment - international agreements:
party to: Air Pollution, Biodiversity, Climate Change,
Endangered Species, Hazardous Wastes, Law of the
Sea, Marine Dumping, Marine Life Conservation,
Ozone Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: controls one of the major land
routes from Western Europe to Turkey and the Near
East; strategic location along the Adriatic coast','cd6ee17f414027085eb53a2068a979f901c6a10bbd97ab8c671f3cde3e5037a3','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('30a125a154379a90b8436dc4dc611a3a05ddbe03ab4be4adefa710a7bf693753',2007,'SC','Seychelles','geography',1125,'Location: archipelago in the Indian Ocean, northeast
of Madagascar
Geographic coordinates: 4 35 S, 55 40 E
Map references: Africa
Area:
total: 455 sq km
land: 455 sq km
water: 0 sq km
Area - comparative: 2.5 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 491 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: tropical marine; humid; cooler season
during southeast monsoon (late May to September);
warmer season during northwest monsoon (March to
May)
Terrain: Mahe Group is granitic, narrow coastal strip,
rocky, hilly; others are coral, flat, elevated reefs
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Morne Seychelles 905 m
Natural resources: fish, copra, cinnamon trees
Land use:
arable land: 2.17%
permanent crops: 13.04%
other: 84.79% (2005)
Irrigated land: NA sq km
Natural hazards: lies outside the cyclone belt, so
severe storms are rare; short droughts possible
Environment - current issues: water supply
depends on catchments to collect rainwater
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Dumping, Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: 41 granitic and about 75 coralline
islands','d65c38afd52a701c57be3b5635395631632054912751fc2e3a5d4315598eea7a','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('84cedab396fd2f581d7153c66b33f8535c796d596fa79c8e12be658eec3955e5',2007,'SL','Sierra Leone','geography',1134,'Location: Western Africa, bordering the North
Atlantic Ocean, between Guinea and Liberia
Geographic coordinates: 8 30 N, 1 1 30 W
Map references: Africa
Area:
total: 71,740 sq km
land: 71 ,620 sq km
wafer: 120 sq km
Area - comparative: slightly smaller than South
Carolina
Land boundaries:
total: 958 km
border countries: Guinea 652 km, Liberia 306 km
Coastline: 402 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm
Climate: tropical; hot, humid; summer rainy season
(May to December); winter dry season (December to
April)
495
Sierra Leone (continued)
Terrain: coastal belt of mangrove swamps, wooded
hill country, upland plateau, mountains in east
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Loma Mansa (Bintimani) 1,948 m
Natural resources: diamonds, titanium ore, bauxite,
iron ore, gold, chromite
Land use:
arable land: 7.95%
permanent crops: 1 .05%
other: 91% (2005)
Irrigated land: 290 sq km (1998 est.)
Natural hazards: dry, sand-laden harmattan winds
blow from the Sahara (December to February);
sandstorms, dust storms
Environment - current issues: rapid population
growth pressuring the environment; overharvesting of
timber, expansion of cattle grazing, and
slash-and-burn agriculture have resulted in
deforestation and soil exhaustion; civil war depleting
natural resources; overfishing
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Marine Life Conservation, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: Environmental Modification
Geography - note: rainfall along the coast can reach
495 cm (195 inches) a year, making it one of the
wettest places along coastal, western Africa','dfd75b3e506bba7363ce761e9d411ab520e9e8ab85fb746d10b1186f5f24bdd0','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b763025e43db22b35f3fc985bde5f07a2b40092f08886f50b1f048059f36b22e',2007,'SG','Singapore','geography',1140,'Location: Southeastern Asia, islands between
Malaysia and Indonesia
Geographic coordinates: 1 22 N, 103 48 E
Map references: Southeast Asia
Area:
total: 692.7 sq km
land: 682.7 sq km
water: 10 sq km
Area - comparative: slightly more than 3.5 times the
size of Washington, DC
Land boundaries: 0 km
Coastline: 193 km
Maritime claims:
territorial sea: 3 nm
exclusive fishing zone: within and beyond territorial
sea, as defined in treaties and practice
Climate: tropical; hot, humid, rainy; two distinct
monsoon seasons - Northeastern monsoon
(December to March) and Southwestern monsoon
(June to September); inter-monsoon - frequent
afternoon and early evening thunderstorms
Terrain: lowland; gently undulating central plateau
contains water catchment area and nature preserve
Elevation extremes:
lowest point: Singapore Strait 0 m
highest point: Bukit Timah 166 m
Natural resources: fish, deepwater ports
Land use:
arable land: 1 .47%
permanent crops: 1 .47%
other: 97.06% (2005)
Irrigated land: NA sq km
Natural hazards: NA
Environment - current issues: industrial pollution;
limited natural fresh water resources; limited land
availability presents waste disposal problems;
seasonal smoke/haze resulting from forest fires in','a033d8dba31a9b31155fb5bc7be26eced2b78fb35547ee6ce47e39a23b18992f','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6bd577d789756323ae8e27647f401fb9fc5e30db537cd529ebb392ae66a4dcf3',2007,'PH','Philippines','geography',1165,'Geographic coordinates: 8 38 N, 1 1 1 55 E
Map references: Southeast Asia
Area:
total: less than 5 sq km
land: less than 5 sq km
water: 0 sq km
note: includes 100 or so islets, coral reefs, and sea
mounts scattered over an area of nearly 410,000 sq
km of the central South China Sea
Area - comparative: NA
Land boundaries: 0 km
Coastline: 926 km
Maritime claims: NA
Climate: tropical
Terrain: flat
Elevation extremes:
lowest point: South China Sea 0 m
highest point: unnamed location on Southwest Cay 4 m
Natural resources: fish, guano, undetermined oil
and natural gas potential
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (2005)
518
Spratly Islands (continued)
Irrigated land: Osq km (1998 est.)
Natural hazards: typhoons; numerous reefs and
shoals pose a serious maritime hazard
Environment - current issues: NA
Geography - note: strategically located near several
primary shipping lanes in the central South China Sea;
includes numerous small islands, atolls, shoals, and
coral reefs','0d6035acc16a1a716ff6c99558f40700b2ad0a63a68d5024f03d0624c5445c4e','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8a7229f888fd4281f122959bc3efdeea2693b549542a79ef6f41c5d9feaaef8a',2007,'LK','Sri Lanka','geography',1174,'Location: Southern Asia, island in the Indian Ocean,
south of India
Geographic coordinates: 7 00 N, 81 00 E
Map references: Asia
Area:
total: 65,610 sq km
land: 64,740 sq km
water: 870 sq km
Area - comparative: slightly larger than West
Virginia
Land boundaries: 0 km
Coastline: 1,340 km
Maritime claims:
territorial sea: 1 2 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: tropical monsoon; northeast monsoon
(December to March); southwest monsoon (June to
October)
Terrain: mostly low, flat to rolling plain; mountains in
south-central interior
Elevation extremes:
lowest point: Indian Ocean 0 m
highest point: Pidurutalagala 2,524 m
Natural resources: limestone, graphite, mineral
sands, gems, phosphates, clay, hydropower
Land use:
arable land: 13.96%
permanent crops: 1 5.24%
other: 70.8% (2005)
Irrigated land: 6,510 sq km (1998 est.)
Natural hazards: occasional cyclones and
tornadoes
Environment - current issues: deforestation; soil
erosion; wildlife populations threatened by poaching
and urbanization; coastal degradation from mining
activities and increased pollution; freshwater
resources being polluted by industrial wastes and
sewage runoff; waste disposal; air pollution in
Colombo
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Ship Pollution, Wetlands
signed, but not ratified: Marine Life Conservation
Geography ■ note: strategic location near major
Indian Ocean sea lanes','c681512ff46e71a323424197fdd43301007b81bd02c97f2b6892eab4718f3ec8','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bf487069658d95df718feb6c02d07269d4a9315f90f9271f0a9ef56d4189bf87',2007,'SD','Sudan','geography',1181,'Location: Northern Africa, bordering the Red Sea,
between Egypt and Eritrea
Geographic coordinates: 15 00 N, 30 00 E
Map references: Africa
Area:
total: 2,505,810 sq km
land: 2.376 million sq km
water: 129,810 sq km
Area - comparative: slightly more than one-quarter
the size of the US
Land boundaries:
total: 7,687 km
border countries: Central African Republic 1 ,165 km,
Chad 1 ,360 km, Democratic Republic of the Congo 628
km, Egypt 1 ,273 km, Eritrea 605 km, Ethiopia 1 ,606 km,
Kenya 232 km, Libya 383 km, Uganda 435 km
Coastline: 853 km
Maritime claims:
territorial sea: 1 2 nm
contiguous zone: 18 nm
continental shelf: 200-m depth or to the depth of
exploitation
Climate: tropical in south; arid desert in north; rainy
season varies by region (April to November)
Terrain: generally flat, featureless plain; mountains
in far south, northeast and west; desert dominates the
north
Elevation extremes:
lowest point: Red Sea 0 m
highest point: Kinyeti 3,187 m
Natural resources: petroleum; small reserves of
iron ore, copper, chromium ore, zinc, tungsten, mica,
silver, gold, hydropower
Land use:
arable land: 6.78%
permanent crops: 0.1 7%
other: 93.05% (2005)
Irrigated land: 19,500 sq km (1998 est.)
Natural hazards: dust storms and periodic
persistent droughts
Environment - current issues: inadequate supplies
of potable water: wildlife populations threatened by
excessive hunting; soil erosion; desertification;
periodic drought
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography • note: largest country in Africa;
dominated by the Nile and its tributaries','4c0431c1c7cfc2295e116bcee83422adbc0ac136500a30380e4a5ef00bf9b7cd','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('712ddd86c3c2fff919aba676e845957bb2e820c8e08afda97935be102ad56d3e',2007,'SR','Suriname','geography',1189,'Location: Northern South America, bordering the
North Atlantic Ocean, between French Guiana and','c0a0885b01b1a745b37f8ab18e10fdb72d8d2d07eb19f2951d3d194c03e6aa71','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('214639cbf1975924e4c49fd8c0ca88bb7d6456e0a343ef827ad8df1244afde04',2007,'GY','Guyana','geography',1190,'Geographic coordinates: 4 00 N, 56 00 W
Map references: South America
Area:
total: 163,270 sq km
land: 161 ,470 sq km
wafer: 1,800 sq km
Area - comparative: slightly larger than Georgia
Land boundaries:
total: 1,707 km
border countries: Brazil 597 km, French Guiana 510
km, Guyana 600 km
Coastline: 386 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; moderated by trade winds
Terrain: mostly rolling hills; narrow coastal plain with
swamps
Elevation extremes:
lowest point: unnamed location in the coastal plain -2
m
highest point: Juliana Top 1 ,230 m
Natural resources: timber, hydropower, fish, kaolin,
shrimp, bauxite, gold, and small amounts of nickel,
copper, platinum, iron ore
Land use:
arable land: 0.36%
permanent crops: 0.06%
other: 99.58% (2005)
Irrigated land: 490 sq km (1998 est.)
Natural hazards: NA
Environment - current issues: deforestation as
timber is cut for export; pollution of inland waterways
by small-scale mining activities
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 94, Wetlands
signed, but not ratified: none of the selected
agreements
Geography • note: smallest independent country on
South American continent; mostly tropical rain forest;
great diversity of flora and fauna that, for the most
part, is increasingly threatened by new development;
relatively small population, mostly along the coast
Location: Northern Europe, islands between the
Arctic Ocean, Barents Sea, Greenland Sea, and
Norwegian Sea, north of Norway
Geographic coordinates: 78 00 N, 20 00 E
Map references: Arctic Region
Area:
total: 62,049 sq km
land: 62,049 sq km
water: 0 sq km
note: includes Spitsbergen and Bjornoya (Bear
Island)
Area - comparative: slightly smaller than West
Virginia
Land boundaries: 0 km
Coastline: 3,587 km
Maritime claims:
territorial sea: 4 nm
exclusive fishing zone: 200 nm unilaterally claimed by
Norway but not recognized by Russia
Climate: arctic, tempered by warm North Atlantic
Current; cool summers, cold winters; North Atlantic
Current flows along west and north coasts of
Spitsbergen, keeping water open and navigable most
of the year
Terrain: wild, rugged mountains; much of high land
ice covered; west coast clear of ice about one-half of
the year; fjords along west and north coasts
527
Svalbard (continued)
Elevation extremes:
lowest point: Arctic Ocean 0 m
highest point: Newtontoppen 1,717m
Natural resources: coal, iron ore, copper, zinc,
phosphate, wildlife, fish
Land use:
arable land: 0%
permanent crops: 0%
other: 100% (no trees, and the only bushes are
crowberry and cloudberry) (2005)
Irrigated land: NA
Natural hazards: ice floes often block the entrance
to Bellsund (a transit point for coal export) on the west
coast and occasionally make parts of the northeastern
coast inaccessible to maritime traffic
Environment • current issues: NA
Geography - note: northernmost part of the
Kingdom of Norway; consists of nine main islands;
glaciers and snowfields cover 60% of the total area
Location: Southern Africa, between Mozambique
and South Africa
Geographic coordinates: 26 30 S, 31 30 E
Map references: Africa
Area:
total: 17,363 sq km
land: 17,203 sq km
water: 160 sq km
Area - comparative: slightly smaller than New','501c0fb9dc7c79ea4bfaa8b2d627826b1206655caf730b3c429e81721707e093','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('68c89b4fdcf6edabd13c02083c2649ff11e9151af749129e564eb5e67cd4fd98',2007,'SE','Sweden','geography',1193,'Location: Northern Europe, bordering the Baltic
Sea, Gulf of Bothnia, Kattegat, and Skagerrak,
between Finland and Norway
Geographic coordinates: 62 00 N, 15 00 E
Map references: Europe
Area:
total: 449,964 sq km
land. 410,934 sq km
water: 39,030 sq km
Area - comparative: slightly larger than California
Land boundaries:
total: 2,233 km
border countries: Finland 614 km, Norway 1,619 km
Coastline: 3,218 km
Maritime claims:
territorial sea: 12 nm (adjustments made to return a
portion of straits to high seas)
exclusive economic zone: agreed boundaries or
midlines
continental shelf: 200-m depth or to the depth of
exploitation
Climate: temperate in south with cold, cloudy winters
and cool, partly cloudy summers; subarctic in north
Terrain: mostly flat or gently rolling lowlands;
mountains in west
Elevation extremes:
lowest point: reclaimed bay of Lake Hammarsjon,
near Kristianstad -2.41 m
highest point: Kebnekaise 2,1 1 1 m
Natural resources: iron ore, copper, lead, zinc, gold,
silver, tungsten, uranium, arsenic, feldspar, timber,
hydropower
Land use:
arable land: 5.93%
permanent crops: 0.01%
other: 94.06% (2005)
Irrigated land: 1,150 sq km (1998 est.)
Natural hazards: ice floes in the surrounding waters,
especially in the Gulf of Bothnia, can interfere with
maritime traffic
Environment - current issues: acid rain damage to
soils and lakes; pollution of the North Sea and the
Baltic Sea
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulfur 85, Air Pollution-Sulfur 94, Air
Pollution-Volatile Organic Compounds,
Antarctic-Environmental Protocol, Antarctic-Marine
Living Resources, Antarctic Treaty, Biodiversity,
Climate Change, Climate Change-Kyoto Protocol,
Desertification, Endangered Species, Environmental
Modification, Hazardous Wastes, Law of the Sea,
Marine Dumping, Ozone Layer Protection, Ship
Pollution, Tropical Timber 83, Tropical Timber 94,
Wetlands, Whaling
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location along Danish
Straits linking Baltic and North Seas
Population: 9,016,596 (July 2006 est.)
Age structure:
0-14 years: 16.7% (male 775,433/female 732,773)
15-64 years: 65.7% (male 3,001 ,928/female
2,918,242)
65 years and over: 17.6% (male 689,756/female
898,464) (2006 est.)
Median age:
total: 40.9 years
male: 39.8 years
female: 42 years (2006 est.)
Population growth rate: 0.16% (2006 est.)
Birth rate: 10.27 births/1 ,000 population (2006 est.)
Death rate: 10.31 deaths/1,000 population
(2006 est.)
Net migration rate: 1 .66 migrant(s)/1 ,000
population (2006 est.)
Sex ratio:
at birth: 1 .06 male(s)/female
under 15 years: 1 .06 male(s)/female
15-64 years: 1 .03 male(s)/female
65 years and over: 0.77 male(s)/female
total population: 0.98 male(s)/female (2006 est.)
Infant mortality rate:
total: 2.76 deaths/1 ,000 live births
male: 2.92 deaths/1 ,000 live births
female: 2.59 deaths/1 ,000 live births (2006 est.)
Life expectancy at birth:
total population: 80.51 years
male: 78.29 years
female: 82.87 years (2006 est.)
Total fertility rate: T.66 children born/woman
(2006 est.)
HIV/AIDS - adult prevalence rate: 0.1% (2001 est.)
HIV/AIDS - people living with HIV/AIDS: 3,600
(2001 est.)
HIV/AIDS - deaths: less than 100 (2003 est.)
Nationality:
noun: Swede(s)
adjective: Swedish
Ethnic groups: indigenous population: Swedes with
Finnish and Sami minorities; foreign-born or
first-generation immigrants: Finns, Yugoslavs, Danes,
Norwegians, Greeks, Turks
Religions: Lutheran 87%, Roman Catholic,
Orthodox, Baptist, Muslim, Jewish, Buddhist
Languages: Swedish, small Sami- and
Finnish-speaking minorities
Literacy:
definition: age 1 5 and over can read and write
total population: 99%
male: 99%
female: 99% (2003 est.)
/','2dfdb0e1b1b87b0c9f5b917872777a7d6b25f38a4ba1465eafbb30a432b725af','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dc44cd09667dfba298188792bee7e851d9670238cf0ab55f9c2b6f3dfcb77e28',2007,'UZ','Uzbekistan','geography',1203,'Location: Central Asia, west of China
Geographic coordinates: 39 00 N, 71 00 E
Map references: Asia
Area:
total: 143,100 sq km
land: 142,700 sq km
water: 400 sq km
Area - comparative: slightly smaller than Wisconsin
Land boundaries:
tote/; 3,651 km
border countries: Afghanistan 1 ,206 km, China 414
km, Kyrgyzstan 870 km, Uzbekistan 1,161 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: midlatitude continental, hot summers, mild
winters; semiarid to polar in Pamir Mountains
Terrain: Pamir and Alay Mountains dominate
landscape; western Fergana Valley in north,
Kofarnihon and Vakhsh Valleys in southwest
Elevation extremes:
lowest point: Syr Darya (Sirdaryo) 300 m
highest point: Qullai Ismoili Somoni 7,495 m
Natural resources: hydropower, some petroleum,
uranium, mercury, brown coal, lead, zinc, antimony,
tungsten, silver, gold
Land use:
arable land: 6.52%
permanent crops: 0.89%
other: 92.59% (2005)
Irrigated land: 7,200 sq km (1998 est.)
Natural hazards: earthquakes and floods
Environment - current issues: inadequate
sanitation facilities; increasing levels of soil salinity;
industrial pollution; excessive pesticides
Environment • international agreements:
party to: Biodiversity. Climate Change,
Desertification, Environmental Modification, Ozone
Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: landlocked; mountainous region
dominated by the Trans-Alay Range in the north and
the Pamirs in the southeast; highest point, Qullai
Ismoili Somoni (formerly Communism Peak), was the
tallest mountain in the former USSR
Location: Central Asia, north of Afghanistan
Geographic coordinates: 41 00 N, 64 00 E
Map references: Asia
Area:
total: 447,400 sq km
land: 425,400 sq km
water: 22,000 sq km
Area - comparative: slightly larger than California
Land boundaries:
total: 6,221 km
border countries: Afghanistan 137 km, Kazakhstan
2,203 km, Kyrgyzstan 1,099 km, Tajikistan 1,161 km,
Turkmenistan 1,621 km
Coastline: 0 km (doubly landlocked); note -
Uzbekistan includes the southern portion of the Aral
Sea with a 420 km shoreline
Maritime claims: none (doubly landlocked)
Climate: mostly midlatitude desert, long, hot
summers, mild winters; semiarid grassland in east
Terrain: mostly flat-to-rolling sandy desert with dunes;
broad, flat intensely irrigated river valleys along course of
Amu Darya, Syr Darya (Sirdaryo), and Zarafshon;
Fergana Valley in east surrounded by mountainous
Tajikistan and Kyrgyzstan; shrinking Aral Sea in west
Elevation extremes:
lowest point: Sariqarnish Kuli -12 m
highest point: Adelunga Toghi 4,301 m
Natural resources: natural gas, petroleum, coal,
gold, uranium, silver, copper, lead and zinc, tungsten,
molybdenum
Land use:
arable land: 10.51%
permanent crops: 0.76%
other: 88.73% (2005)
Irrigated land: 42,810 sq km (1998 est.)
Natural hazards: NA
Environment - current issues: shrinkage of the
Aral Sea is resulting in growing concentrations of
chemical pesticides and natural salts; these
substances are then blown from the increasingly
exposed lake bed and contribute to desertification;
water pollution from industrial wastes and the heavy
use of fertilizers and pesticides is the cause of many
human health disorders; increasing soil salination; soil
contamination from buried nuclear processing and
agricultural chemicals, including DDT
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Ozone Layer Protection, Wetlands
signed, but not ratified: none of the selected
agreements
Geography - note: along with Liechtenstein, one of
the only two doubly landlocked countries in the world
Location: Oceania, group of islands in the South
Pacific Ocean, about three-quarters of the way from
Hawaii to Australia
Geographic coordinates: 16 00 S, 167 00 E
Map references: Oceania
Area:
total: 12,200 sq km
land: 12,200 sq km
water: 0 sq km
note: includes more than 80 islands, about 65 of which
are inhabited
Area - comparative: slightly larger than Connecticut
Land boundaries: 0 km
Coastline: 2,528 km
Maritime claims: measured from claimed
archipelagic baselines
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: tropical; moderated by southeast trade
winds from May to October; moderate rainfall from
November to April; may be affected by cyclones from
December to April
Terrain: mostly mountainous islands of volcanic
origin; narrow coastal plains
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: Tabwemasana 1 ,877 m
Natural resources: manganese, hardwood forests,
fish
Land use:
arable land: 1.64%
permanent crops: 6.97%
ofher:91.39%(2005)
Irrigated land: NA
Natural hazards: tropical cyclones or typhoons
(January to April); volcanic eruption on Aoba (Ambae)
island began 27 November 2005, volcanism also
causes minor earthquakes; tsunamis
Environment - current issues: a majority of the
population does not have access to a reliable supply
of potable water; deforestation
Environment - international agreements:
party to: Antarctic-Marine Living Resources,
Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species, Law of
the Sea, Marine Dumping, Ozone Layer Protection,
Ship Pollution, Tropical Timber 94
signed, but not ratified: none of the selected
agreements
Geography - note: a Y-shaped chain of four main
islands and 80 smaller islands; several of the islands
have active volcanoes','61a86c2dfaa9dae47989e6cebd51636931939a9266e08540199b8a89d52a00c6','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da997a52630edb43983d2f873f417b750462ea95d14dcccf3cc1befc147acbdf',2007,'TK','Tokelau','geography',1213,'Location: Oceania, group of three atolls in the South
Pacific Ocean, about one-half of the way from Hawaii
to New Zealand
Geographic coordinates: 9 00 S, 172 00 W
Map references: Oceania
Area:
total: 1 0 sq km
land: 10 sq km
water: 0 sq km
Area - comparative: about 1 7 times the size of The
Mall in Washington, DC
Land boundaries: 0 km
Coastline: 101 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; moderated by trade winds (April to
November)
Terrain: low-lying coral atolls enclosing large
lagoons
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 5 m
Natural resources: NEGL
Land use:
arable land: 0% (soil is thin and infertile)
permanent crops: 0%
other: 100% (2005)
Irrigated land: NA sq km
Natural hazards: lies in Pacific typhoon belt
550
Tokelau (continued)
Environment - current issues: very limited natural
resources and overcrowding are contributing to
emigration to New Zealand
Geography - note: consists of three atolls, each with
a lagoon surrounded by a number of reef-bound islets
of varying length and rising to over three meters above
sea level','f30cc0675735cdc200e82c923ad50d5bbd89254250146890423556944dd264a3','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f0a991d2b2f31eebad15b85e81c8f602fa74c73b4bb4f5796e6272f3e9f92f20',2007,'TO','Tonga','geography',1222,'Location: Oceania, archipelago in the South Pacific
Ocean, about two-thirds of the way from Hawaii to','dba2c3f5cc9763816183b4cbb380a2ba67479dfface76994e5a899d532e5e760','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6cd9a9b03e4bc7a3f6564f626cbe9949d53707774c7f17461c5ed8500548a180',2007,'TV','Tuvalu','geography',1225,'Location: Oceania, island group consisting of nine
coral atolls in the South Pacific Ocean, about one-half
of the way from Hawaii to Australia
Geographic coordinates: 8 00 S, 178 00 E
Map references: Oceania
Area:
total: 26 sq km
land: 26 sq km
water: 0 sq km
Area - comparative: 0.1 times the size of
Washington, DC
Land boundaries: 0 km
Coastline: 24 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
Climate: tropical; moderated by easterly trade winds
(March to November); westerly gales and heavy rain
(November to March)
Terrain: very low-lying and narrow coral atolls
Elevation extremes:
lowest point: Pacific Ocean 0 m
highest point: unnamed location 5 m
Natural resources: fish
Land use:
arable land: 0%
permanent crops: 66.67%
other: 33.33% (2005)
Irrigated land: NA
Natural hazards: severe tropical storms are usually
rare, but, in 1997, there were three cyclones; low level
of islands make them sensitive to changes in sea level
Environment - current issues: since there are no
streams or rivers and groundwater is not potable,
most water needs must be met by catchment systems
with storage facilities (the Japanese Government has
built one desalination plant and plans to build one
other); beachhead erosion because of the use of sand
tor building materials; excessive clearance of forest
undergrowth for use as fuel; damage to coral reefs
from the spread of the Crown of Thorns starfish;
Tuvalu is concerned about global increases in
greenhouse gas emissions and their effect on rising
sea levels, which threaten the country''s underground
water table; in 2000, the government appealed to
Australia and New Zealand to take in Tuvaluans if
rising sea levels should make evacuation necessary
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Law of the
Sea, Ozone Layer Protection, Ship Pollution
signed, but not ratified: none of the selected
agreements
Geography - note: one of the smallest and most
remote countries on Earth; six of the coral atolls -
Nanumea, Nui, Vaitupu, Nukufetau, Funafuti, and
Nukulaelae - have lagoons open to the ocean;
Nanumaya and Niutao have landlocked lagoons;
Niulakita does not have a lagoon','297dc83b430699cc42fd3ae108c130a75f582deabf6a002701f57f644d142b17','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('61308e666fb38c6bff34f5d91794d0e3dd46444a699ae3b42a8170fb4d114345',2007,'UG','Uganda','geography',1232,'Location: Eastern Africa, west of Kenya
Geographic coordinates: 1 00 N, 32 00 E
Map references: Africa
Area:
total: 236,040 sq km
land: 199,710 sq km
water: 36,330 sq km
Area - comparative: slightly smaller than Oregon
Land boundaries:
total: 2,698 km
border countries: Democratic Republic of the Congo
765 km, Kenya 933 km, Rwanda 169 km, Sudan 435
km, Tanzania 396 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; generally rainy with two dry
seasons (December to February, June to August);
semiarid in northeast
Terrain: mostly plateau with rim of mountains
Elevation extremes:
lowest point: Lake Albert 621 m
highest point: Margherita Peak on Mount Stanley
5,110 m
Natural resources: copper, cobalt, hydropower,
limestone, salt, arable land
Land use:
arable land: 21 .57%
permanent crops: 8.92%
other: 69.51% (2005)
Irrigated land: 90 sq km (1998 est.)
Natural hazards: NA
Environment • current issues: draining of wetlands
for agricultural use; deforestation; overgrazing; soil
erosion; water hyacinth infestation in Lake Victoria;
poaching is widespread
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes, Law of the Sea, Marine
Life Conservation, Ozone Layer Protection, Wetlands
signed, but not ratified: Environmental Modification
Geography - note: landlocked; fertile, well-watered
country with many lakes and rivers','6347fb49f747ebc2a6906e46fd6ddb17f6b22824d2a40e3a83515f6b64ccbb94','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06aaff06d3b874dfdb5eca0505d1dd919033e6549fbe6d211025f0e065926d03',2007,'UA','Ukraine','geography',1240,'Location: Eastern Europe, bordering the Black Sea,
between Poland, Romania, and Moldova in the west
and Russia in the east
Geographic coordinates: 49 00 N, 32 00 E
Map references: Asia, Europe
Area:
total: 603,700 sq km
land: 603,700 sq km
water: 0 sq km
Area • comparative: slightly smaller than Texas
Land boundaries:
total: 4,663 km
border countries: Belarus 891 km, Hungary 103 km,
Moldova 939 km, Poland 526 km, Romania (south)
169 km, Romania (west) 362 km, Russia 1,576 km,
Slovakia 97 km
Coastline: 2,782 km
Maritime claims:
territorial sea: 1 2 nm
exclusive economic zone: 200 nm
continental shelf: 200-m or to the depth of exploitation
Climate: temperate continental; Mediterranean only
on the southern Crimean coast; precipitation
disproportionately distributed, highest in west and
north, lesser in east and southeast; winters vary from
cool along the Black Sea to cold farther inland;
summers are warm across the greater part of the
country, hot in the south
Terrain: most of Ukraine consists of fertile plains
(steppes) and plateaus, mountains being found only in
the west (the Carpathians), and in the Crimean
Peninsula in the extreme south
Elevation extremes:
lowest point: Black Sea 0 m
highest point: Hora Hoverla 2,061 m
Natural resources: iron ore, coal, manganese,
natural gas, oil, salt, sulfur, graphite, titanium,
magnesium, kaolin, nickel, mercury, timber, arable
land
Land use:
arable land: 53.8%
permanent crops: 1 .5%
other: 44.7% (2005)
Irrigated land: 24,540 sq km (1998 est.)
Natural hazards: NA
Environment - current issues: inadequate supplies
of potable water; air and water pollution; deforestation;
radiation contamination in the northeast from 1986
accident at Chornobyl'' Nuclear Power Plant
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Sulfur 85, Antarctic-Environmental
Protocol, Antarctic-Marine Living Resources,
Antarctic Treaty, Biodiversity, Climate Change,
Climate Change-Kyoto Protocol, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Marine Dumping, Ozone
Layer Protection, Ship Pollution, Wetlands
signed, but not ratified: Air Pollution-Persistent
Organic Pollutants, Air Pollution-Sulfur 94, Air
Pollution-Volatile Organic Compounds
Geography - note: strategic position at the
crossroads between Europe and Asia; second-largest
country in Europe','ba71e400ce2b8b67d00a9b5c12ce461928cfab44ae084d5c57696298ce569666','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4b661cbf8c8999961677978996b2a5abce6942d3ea432949059a1af7e415be2',2007,'QA','Qatar','geography',1243,'Location: Middle East, bordering the Gulf of Oman and
the Persian Gulf, between Oman and Saudi Arabia
Geographic coordinates: 24 00 N, 54 00 E
Map references: Middle East
Area:
total: 82,880 sq km
land: 82,880 sq km
water: 0 sq km
Area - comparative: slightly smaller than Maine
Land boundaries:
total: 867 km
border countries: Oman 41 0 km, Saudi Arabia 457 km
Coastline: 1,318 km
Maritime claims:
territorial sea: 1 2 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: desert; cooler in eastern mountains
Terrain: flat, barren coastal plain merging into rolling
sand dunes of vast desert wasteland; mountains in east
Elevation extremes:
lowest point: Persian Gulf 0 m
highest point: Jabal Yibir 1 ,527 m
Natural resources: petroleum, natural gas
Land use:
arable land: 0.77%
permanent crops: 2.27%
other: 96.96% (2005)
Irrigated land: 720 sq km (1998 est.)
Natural hazards: frequent sand and dust storms
Environment - current issues: lack of natural
freshwater resources compensated by desalination
plants; desertification; beach pollution from oil spills
Environment • international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Hazardous Wastes. Marine Dumping, Ozone
Layer Protection
signed, but not ratified: Law of the Sea
Geography - note: strategic location along southern
approaches to Strait of Hormuz, a vital transit point for
world crude oil','47eb5ba246fd7ab1f9c450fa7c504412c518ef187b9e84e0a128d4a22e78c9de','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('57c2ccb736a2a1704561b14ef93930dce41362d0649b421b3cc149d56877131b',2007,'UY','Uruguay','geography',1252,'Location: Southern South America, bordering the
South Atlantic Ocean, between Argentina and Brazil
Geographic coordinates: 33 00 S, 56 00 W
Map references: South America
Area:
total: 176,220 sq km
land: 173,620 sq km
water: 2,600 sq km
Area - comparative: slightly smaller than the state of
Washington
Land boundaries:
total: 1,564 km
border countries: Argentina 579 km, Brazil 985 km
Coastline: 660 km
589
Uruguay (continued)
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200-m depth or to the depth of
exploitation
Climate: warm temperate; freezing temperatures
almost unknown
Terrain: mostly rolling plains and low hills; fertile
coastal lowland
Elevation extremes:
lowest point: Atlantic Ocean 0 m
highest point: Cerro Catedral 514 m
Natural resources: arable land, hydropower, minor
minerals, fisheries
Land use:
arable land: 7.77%
permanent crops: 0.24%
other: 91.99% (2005)
Irrigated land: 1,800 sq km (1998 est.)
Natural hazards: seasonally high winds (the
pampero is a chilly and occasional violent wind that
blows north from the Argentine pampas), droughts,
floods; because of the absence of mountains, which
act as weather barriers, all locations are particularly
vulnerable to rapid changes from weather fronts
Environment - current issues: water pollution from
meat packing/tannery industry; inadequate solid/
hazardous waste disposal
Environment - international agreements:
party to: Antarctic-Environmental Protocol,
Antarctic-Marine Living Resources, Antarctic Treaty,
Biodiversity, Climate Change, Climate Change-Kyoto
Protocol, Desertification, Endangered Species,
Environmental Modification, Hazardous Wastes, Law
of the Sea, Ozone Layer Protection, Ship Pollution,
Tropical Timber 94, Wetlands
signed, but not ratified: Marine Dumping, Marine Life
Conservation
Geography - note: second-smallest South
American country (after Suriname); most of the
low-lying landscape (three-quarters of the country) is
grassland, ideal for cattle and sheep raising','1ad235afb25c522258a0d674ccd6dbfce1a927238c77a91c70a4f9dcd03a012f','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d743df257fe42eb71cb5bd961715297004346ba1881c081a155a74500552ab47',2007,'WF','Wallis and Futuna','geography',1265,'Location: Oceania, islands in the South Pacific
Ocean, about two-thirds of the way from Hawaii to','e0b14fbea7a6600686b865ca0f5eac39b8c110a5a9fda69667701ce167afead3','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44a3b56e1ac1934967a5f03db32f9ffd4bb9f8952529c917a2300a940c4ec1c7',2007,'IL','Israel','geography',1267,'Location: Middle East, west of Jordan
Geographic coordinates: 32 00 N, 35 15 E
Map references: Middle East
Area:
total: 5,860 sq km
land: 5,640 sq km
water: 220 sq km
note: includes West Bank, Latrun Salient, and the
northwest quarter of the Dead Sea, but excludes Mt.
Scopus; East Jerusalem and Jerusalem No Man''s
Land are also included only as a means of depicting
the entire area occupied by Israel in 1967
Area - comparative: slightly smaller than Delaware
Land boundaries:
total: 404 km
border countries: Israel 307 km, Jordan 97 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: temperate; temperature and precipitation
vary with altitude, warm to hot summers, cool to mild
winters
Terrain: mostly rugged dissected upland, some
vegetation in west, but barren in east
Elevation extremes:
lowest point: Dead Sea -408 m
highest point: Tall Asur 1 ,022 m
Natural resources: arable land
Land use:
arable land: 16.9%
permanent crops: 18.97%
other: 64.13% (2001)
Irrigated land: NA sq km
Natural hazards: droughts
Environment - current issues: adequacy of fresh
water supply; sewage treatment
Geography - note: landlocked; highlands are main
recharge area for Israel''s coastal aquifers; there are
242 West Bank settlements and 29 East Jerusalem
settlements in addition to at least 20 occupied
outposts (August 2005 est.)','f12e0b017ccafbd127ab41c01a15ed405e4bea1dc6c6762c9c33a25573ee3c5b','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9cb9447c3c7dde1826abf52f3d9bef288c7730bd6ff8d4b0c8925e0543b38aab',2007,'MR','Mauritania','geography',1274,'Location: Northern Africa, bordering the North
Atlantic Ocean, between Mauritania and Morocco
Geographic coordinates: 24 30 N, 13 00 W
Map references: Africa
Area:
total: 266,000 sq km
land: 266,000 sq km
water: 0 sq km
Area - comparative: about the size of Colorado
Land boundaries:
total: 2,046 km
border countries: Algeria 42 km, Mauritania 1 ,561 km,
Morocco 443 km
Coastline: 1,110 km
Maritime claims: contingent upon resolution of
sovereignty issue
Climate: hot, dry desert; rain is rare; cold offshore air
currents produce fog and heavy dew
Terrain: mostly low, flat desert with large areas of
rocky or sandy surfaces rising to small mountains in
south and northeast
Elevation extremes:
lowest point: Sebjet Tah -55 m
highest point: unnamed location 463 m
Natural resources: phosphates, iron ore
Land use:
arable land: 0.02%
permanent crops: 0%
other: 99.98% (2005)
609
Western Sahara (continued)
rrigated land: NA sq km
Natural hazards: hot, dry, dust/sand-laden sirocco
A/ind can occur during winter and spring; widespread
larmattan haze exists 60°o of time, often severely
estricting visibility
Environment - current issues: sparse water and
ack of arable land
Environment - international agreements:
oarty to: none of the selected agreements
signed, but not ratified: none of the selected
agreements
Geography • note: the waters off the coast are
particularly rich fishing areas','2a23c1f94e901967b292b88d78a49103707b99f85db600e859f6f513dd14b55c','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('83ef3e5b83ac0e963db2739b32fd24fdf0ab8aa4f647f97faa9d8c048c80a279',2007,'SO','Somalia','geography',1277,'Location: Middle East, bordering the Arabian Sea,
Gulf of Aden, and Red Sea, between Oman and Saudi
Arabia
Geographic coordinates: 15 00 N, 48 00 E
Map references: Middle East
Area:
total: 527,970 sq km
land: 527,970 sq km
water: 0 sq km
note: includes Perim, Socotra, the former Yemen Arab
Republic (YAR or North Yemen), and the former
People''s Democratic Republic of Yemen (PDRY or
South Yemen)
Area - comparative: slightly larger than twice the
size of Wyoming
Land boundaries:
total: 1,746 km
border countries: Oman 288 km, Saudi Arabia
1 ,458 km
Coastline: 1,906 km
Maritime claims:
territorial sea: 12 nm
contiguous zone: 24 nm
exclusive economic zone: 200 nm
continental shelf: 200 nm or to the edge of the
continental margin
Climate: mostly desert; hot and humid along west
coast; temperate in western mountains affected by
seasonal monsoon; extraordinarily hot, dry, harsh
desert in east
Terrain: narrow coastal''plain backed by flat-topped
hills and rugged mountains; dissected upland desert
plains in center slope into the desert interior of the
Arabian Peninsula
Elevation extremes:
lowest point: Arabian Sea 0 m
highest point: Jabal an Nabi Shu''ayb 3,760 m
Natural resources: petroleum, fish, rock salt,
marble; small deposits of coal, gold, lead, nickel, and
copper; fertile soil in west
Land use:
arable land: 2.91%
permanent crops: 0.25%
other: 96.84% (2005)
Irrigated land: 4,900 sq km (1998 est.)
Natural hazards: sandstorms and dust storms in
summer
Environment - current issues: very limited natural
fresh water resources; inadequate supplies of potable
water; overgrazing; soil erosion; desertification
Environment - international agreements:
party to: Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Endangered
Species, Environmental Modification, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography - note: strategic location on Bab el
Mandeb, the strait linking the Red Sea and the Gulf of
Aden, one of world''s most active shipping lanes','cf763611cfb25daa334dd899e0bfc79d72f1f859b08dd40f7820bf7259064c6b','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7526e6ea17bd720a1f79113630f3abbbc0a64f442a5e499ce5dd8c548f37d474',2007,'ZM','Zambia','geography',1283,'Location: Southern Africa, east of Angola
Geographic coordinates: 1 5 00 S, 30 00 E
Map references: Africa
Area:
total: 752,614 sq km
land: 740,724 sq km
water: 1 1 ,890 sq km
Area - comparative: slightly larger than Texas
Land boundaries:
total: 5,664 km
border countries: Angola 1,110 km, Democratic
Republic of the Congo 1 ,930 km, Malawi 837 km,
Mozambique 419 km, Namibia 233 km, Tanzania 338
km, Zimbabwe 797 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; modified by altitude; rainy season
(October to April)
Terrain: mostly high plateau with some hills and
mountains
Elevation extremes:
lowest point: Zambezi river 329 m
highest point: unnamed location in Mafinga Hills
2,301 m
Natural resources: copper, cobalt, zinc, lead, coal,
emeralds, gold, silver, uranium, hydropower
Land use:
arable land: 6.99%
permanent crops: 0.04%
other: 92.97% (2005)
Irrigated land: 460 sq km (1998 est.)
Natural hazards: periodic drought, tropical storms
(November to April)
Environment • current issues: air pollution and
resulting acid rain in the mineral extraction and
refining region; chemical runoff into watersheds;
poaching seriously threatens rhinoceros, elephant,
antelope, and large cat populations; deforestation; soil
erosion; desertification; lack of adequate water
treatment presents human health risks
Environment - international agreements:
party to: Biodiversity. Climate Change,
Desertification, Endangered Species, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Wetlands
signed, but not ratified: Climate Change-Kyoto Protocol
Geography - note: landlocked; the Zambezi forms a
natural riverine boundary with Zimbabwe
Location: Southern Africa, between South Africa
and Zambia
Geographic coordinates: 20 00 S, 30 00 E
Map references: Africa
Area:
total: 390.580 sq km
land: 386,670 sq km
water: 3,910 sq km
Area - comparative: slightly larger than Montana
Land boundaries:
total: 3,066 km
border countries: Botswana 813 km, Mozambique
1 ,231 km, South Africa 225 km, Zambia 797 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: tropical; moderated by altitude; rainy
season (November to March)
Terrain: mostly high plateau with higher central
plateau (high veld); mountains in east
Elevation extremes:
lowest point: junction of the Runde and Save rivers
162 m
highest point: Inyangani 2,592 m
Natural resources: coal, chromium ore, asbestos,
gold, nickel, copper, iron ore, vanadium, lithium, tin,
platinum group metals
Land use:
arable land: 8.24%
permanent crops: 0.33%
ofner:91.43%(2005)
Irrigated land: 1,170 sq km (1998 est.)
Natural hazards: recurring droughts; floods and
severe storms are rare
Environment - current issues: deforestation; soil
erosion; land degradation; air and water pollution; the
black rhinoceros herd - once the largest concentration
of the species in the world - has been significantly
reduced by poaching; poor mining practices have led
to toxic waste and heavy metal pollution
Environment - international agreements:
party to: Biodiversity, Climate Change,
Desertification, Endangered Species, Law of the Sea,
Ozone Layer Protection
signed, but not ratified: none of the selected
agreements
Geography ■ note: landlocked; the Zambezi forms a
natural riverine boundary with Zambia; in full flood
(February-April) the massive Victoria Falls on the river
forms the world''s largest curtain of falling water
Location: Eastern Asia, islands bordering the East
China Sea, Philippine Sea, South China Sea, and
Taiwan Strait, north of the Philippines, off the
southeastern coast of China
Geographic coordinates: 23 30 N, 121 00 E
Map references: Southeast Asia
Area:
total: 35,980 sq km
land: 32,260 sq km
water: 3,720 sq km
note: includes the Pescadores, Matsu, and Quemoy
Area - comparative: slightly smaller than Maryland
and Delaware combined
Land boundaries: 0 km
Coastline: 1,566.3 km
Maritime claims:
territorial sea: 12 nm
exclusive economic zone: 200 nm
Climate: tropical; marine; rainy season during
southwest monsoon (June to August); cloudiness is
persistent and extensive all year
Terrain: eastern two-thirds mostly rugged
mountains; flat to gently rolling plains in west
Elevation extremes:
lowest point: South China Sea 0 m
highest point: Yu Shan 3,952 m
Natural resources: small deposits of coal, natural
gas, limestone, marble, and asbestos
Land use:
arable land: 24%
permanent crops: 1%
otoe/7 75% (2001)
Irrigated land: NA sq km
Natural hazards: earthquakes and typhoons
Environment - current issues: air pollution; water
pollution from industrial emissions, raw sewage;
contamination of drinking water supplies; trade in
endangered species; low-level radioactive waste
disposal
Environment - international agreements:
party to: none of the selected agreements because of
Taiwan''s international status
signed, but not ratified: none of the selected
agreements because of Taiwan''s international status
Geography - note: strategic location adjacent to
both the Taiwan Strait and the Luzon Strait
Location: Europe between Belarus, Ukraine,
Russia, southeastern Europe, and the North Atlantic
Ocean
Map references: Europe
Area:
total: 3,976,372 sq km
Area - comparative: less than one-half the size of
the US
Land boundaries:
total: 11,214.8 km
border countries: Albania 282 km, Andorra 120.3 km,
Belarus 1,050 km. Bulgaria 494 km, Croatia 999 km,
Holy See 3.2 km, Liechtenstein 34.9 km, Macedonia
246 km, Monaco 4.4 km, Norway 2,348 km, Romania
443 km, Russia 2,257 km, San Marino 39 km, Serbia
and Montenegro 151 km, Switzerland 1,811 km,
Turkey 206 km, Ukraine 726 km
note: data for European Continent only
622
European Union (continued)
Coastline: 65,413.9 km
Maritime claims: NA
Climate: cold temperate; potentially subarctic in the
north to temperate; mild wet winters; hot dry summers
in the south
Terrain: fairly flat along the Baltic and Atlantic coast;
mountainous in the central and southern areas
Elevation extremes:
lowest point: Lammefjord, Denmark -7 m;
Zuidplaspolder, Netherlands -7 m
highest point: Mont Blanc, France 4,807 m
Natural resources: iron ore, arable land, natural
gas, petroleum, coal, copper, lead, zinc, hydropower,
uranium, potash, fish
Land use:
arable land: NA%
permanent crops: NA%
other: NA%
Irrigated land: 1 15,807 sq km
Natural hazards: flooding along coasts; avalanches
in mountainous area; earthquakes in the south;
volcanic eruptions in Italy; periodic droughts in Spain;
ice floes in the Baltic
Environment - current issues: NA
Environment - international agreements:
party to: Air Pollution, Air Pollution-Nitrogen Oxides,
Air Pollution-Persistent Organic Pollutants, Air
Pollution-Sulphur 94, Antarctic-Marine Living
Resources, Biodiversity, Climate Change, Climate
Change-Kyoto Protocol, Desertification, Hazardous
Wastes, Law of the Sea, Ozone Layer Protection,
Tropical Timber 82, Tropical Timber 94
signed but not ratified: Air Pollution-Volatile Organic
Compounds','4cc98d766f96c9c5f507f1def389b732da35342eb98b9f7b9f2e1927e9263118','internet-archive','worldfactbook20000cent','txt','977ecc78a5ad7834e545e808f01fd2581ebaf5e6e33bc79c41064c0735f7f25b','https://archive.org/download/worldfactbook20000cent/worldfactbook20000cent_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0b58f9780fe532aea50156f13100652277343151e20fc92ab8404ffe0af58e17',2007,'EH','Western Sahara','geography',26,'Spelling and Pronunciation
Policies and Procedures
Technical
General
Can you provide additional information for a specific country?
The staff cannot provide data beyond what appears in The World
Factbook. The format and information in the Factbook are tailored to
the specific requirements of US Government officials and content is
focused on their current and anticipated needs. The staff welcomes
suggestions for new entries.
How often is The World Factbook updated?
Formerly our Web site (and the published Factbook) were only updated
annually. Beginning in November 2001 we instituted a new system of
more frequent online updates. The World Factbook is currently
updated every two weeks.
The annual printed version of the Factbook is usually released about
midyear. US Government officials may obtain information about
Factbook availability from their own organizations or through
liaison channels to the CIA. Other users may obtain sales
information through the following channels:
Superintendent of Documents
P. O. Box 371954 Pittsburgh, PA 15250-7954
Telephone: [1] (202) 512-1800
FAX: [1] (202) 512-2250
http://bookstore.gpo.gov
National Technical Information Service
5285 Port Royal Road Springfield, VA 22161
Telephone: [1] (800) 553-6847 (only in the US);
[1] (703) 605-6000 (for outside US)
FAX: [1] (703) 605-6900
http://www.ntis.gov
Can I use some or all of The World Factbook for my Web site (book,
research project, homework, etc.)?
The World Factbook is in the public domain and may be used freely by
anyone at anytime without seeking permission. However, US Code
prohibits use of the CIA seal in a manner which implies that the CIA
approved, endorsed, or authorized such use. If you have any
questions about your intended use, you should consult with legal
counsel. Further information on The World Factbook''s use is
described on the Contributors and Copyright Information page. As a
courtesy, please cite The World Factbook when used.
Why doesn''t The World Factbook include information on states,
departments, provinces, etc., in the country format?
The World Factbook provides national-level information on countries,
territories, and dependencies, but not subnational administrative
units within a country. A good encyclopedia should provide
state/province-level information.
Is it possible to access older editions of The World Factbook to do
comparative research and trend analysis?
Previous versions of the Factbook, beginning with the 2000 edition,
are available for downloading - but not browsing - on the CIA Web
site. Hardcopy editions for earlier years are available from
libraries.
Would it be possible to set up a partnership or collaboration
between the producers of The World Factbook and other organizations
or individuals?
The World Factbook does not partner with other organizations or
individuals, but we do welcome comments and suggestions that such
groups or persons choose to provide.
I can''t find a geographic name for a particular country. Why not?
The World Factbook is not a gazetteer (a dictionary or index of
places, usually with descriptive or statistical information) and
cannot provide more than the names of the administrative divisions
(in the Government category) and major cities/towns (on the country
maps). Our expanded Cross-Reference List of Geographic Names,
however, includes many of the world''s major geographic features as
well as historic (former) names of countries and cities mentioned in
The World Factbook.
Why are Taiwan and the European Union listed out of alphabetical
order at the end of the Factbook entries?
Taiwan is listed after the regular entries because even though the
mainland People''s Republic of China claims Taiwan, elected Taiwanese
authorities de facto administer the island and reject mainland
sovereignty claims. With the establishment of diplomatic relations
with China on January 1, 1979, the US Government recognized the
People''s Republic of China as the sole legal government of China,
acknowledging the Chinese position that there is only one China and
that Taiwan is part of China.
The European Union (EU) is not a country, but it has taken on many
nation-like attributes and these are likely to be expanded in the
future. A more complete explanation on the inclusion of the EU into
the Factbook may be found in the Preliminary statement.
Since we have an ambassador who represents the US at the Vatican,
why is this entity not listed in the Factbook?
Vatican City is found under Holy See. The term "Holy See" refers to
the authority, jurisdiction, and sovereignty vested in the Pope and
his advisors to direct the worldwide Catholic Church. The Holy See
has a legal personality that allows it to enter into treaties as the
juridical equal of a state and to send and receive diplomatic
representatives. Vatican City, created in 1929 to administer
properties belonging to the Holy See in Rome, is recognized under
international law as a sovereign state, but it does not send or
receive diplomatic representatives. Consequently, Holy See is
included as a Factbook entry, with Vatican City cross-referenced in
the Geographic Names appendix.
Why is Palestine not listed in The World Factbook?
The areas that could potentially form a future Palestinian state --
the West Bank and Gaza Strip -- do appear in the Factbook. These
areas are presently Israeli-occupied with current status subject to
the Israeli-Palestinian 1995 Interim Agreement; their permanent
status is to be determined through further negotiation.
Why are the Golan Heights not shown as part of Israel or Northern
Cyprus with Turkey?
Territorial occupations/annexations not recognized by the United
States Government are not shown on US Government maps.
Why don''t you include information on entities such as Tibet,
Kashmir, or Kosovo?
The World Factbook provides information on the administrative
divisions of a country as recommended by the United States Board on
Geographic Names (BGN). The BGN is a component of the US Government
that develops policies, principles, and procedures governing the
spelling, use, and application of geographic names--domestic,
foreign, Antarctic, and undersea. Its decisions enable all
departments and agencies of the US Government to have access to
uniform names of geographic features.
Also included in the Factbook are entries on parts of the world
whose status has not yet been resolved (e.g., West Bank, Spratly
Islands). Specific regions within a country or areas in dispute
among countries are not covered.
What do you mean when you say that a country is "doubly landlocked"?
A doubly landlocked country is one that is separated from an ocean
or an ocean-accessible sea by two intervening countries. Uzbekistan
and Liechtenstein are the only countries that fit this definition.
Why is the area of the United States described as "slightly larger
than China" in the Factbook, while other sources list China as
larger in area than the United States?
It all depends on whether one is looking at total area (land and
water) when making the comparison (which is the criterion used by
the Factbook) or just land area (which excludes inland water
features such as rivers or lakes).
Total area (combining land and water)
United States = 9,631,418 sq km
China = 9,596,960 sq km
Land only (without any water features)
United States = 9,161,923 sq km
China = 9,326,410 sq km
Why has The World Factbook dropped the four French departments of
Guadeloupe, Martinique, Reunion, and French Guiana?
The reason the four entities are no longer in The World Factbook is
because their status has changed. While they are overseas
departments of France, they are also now recognized as French
regions, having equal status to the 22 metropolitan regions that
make up European France. In other words, they are now recognized as
being part of France proper. Their status is somewhat analogous to
Alaska and Hawaii vis-a-vis the contiguous United States. Although
separated from the larger geographic entity, they are still
considered to be an integral part of it.
Spelling and Pronunciation
Why is the spelling of proper names such as rulers, presidents, and
prime ministers in The World Factbook different than their spelling
in my country?
The Factbook staff applies the names and spellings from the Chiefs
of State link on the CIA Web site. The World Factbook is prepared
using the standard American English computer keyboard and does not
use any special characters, symbols, or most diacritical markings in
its spellings. Surnames are always spelled with capital letters;
they may appear first in some cultures.
The spelling of geographic names, features, cities, administrative
divisions, etc. in the Factbook differs from those used in my
country. Why is this?
The United States Board on Geographic Names (BGN) recommends and
approves names and spellings. The BGN is the component of the United
States Government that develops policies, principles, and procedures
governing the spelling, use, and application of geographic
names--domestic, foreign, Antarctic, and undersea. Its decisions
enable all departments and agencies of the US Government to use
uniform names of geographic features. (A note is usually included
where changes may have occurred but have not yet been approved by
the BGN). The World Factbook is prepared using the standard American
English computer keyboard and does not use any special characters,
symbols, or most diacritical markings in its spellings.
Why doesn''t The World Factbook include pronunciations of country or
leader names?
There are too many variations in pronunciation among
English-speaking countries, not to mention English renditions of
non-English names, for pronunciations to be included. American
English pronunciations are included for some countries like Qatar
and Kiribati.
Why is the name of the Labour party misspelled?
When American and British spellings of common English words differ,
The World Factbook always uses the American spelling, even when
these common words form part of a proper name in British English.
Policies and Procedures
What is The World Factbook''s source for a specific subject field?
The Factbook staff uses many different sources to publish what we
judge are the most reliable and consistent data for any particular
category. Space considerations preclude a listing of these various
sources.
The names of some geographic features provided in the Factbook
differ from those used in other publications. For example, in Asia
the Factbook has Burma as the country name, but in other
publications Myanmar is used; also, the Factbook uses Sea of Japan
whereas other publications label it East Sea. What is your policy on
naming geographic features?
The Factbook staff follows the guidance of the United States Board
on Geographic Names (BGN). The BGN is the component of the United
States Government that develops policies, principles, and procedures
governing the spelling, use, and application of geographic
names--domestic, foreign, Antarctic, and undersea. Its decisions
enable all departments and agencies of the US Government to have
access to uniform names of geographic features. The position of the
BGN is that the names Burma and Sea of Japan be used in official US
Government maps and publications.
Why is most of the statistical information in the Factbook given in
metric units, rather than the units standard to US measure?
US Federal agencies are required by the Metric Conversion Act of
1975 (Public Law 94-168) and by Executive Order 12770 of July 1991
to use the International System of Units, commonly referred to as
the metric system or SI. In addition, the metric system is used by
over 95 percent of the world''s population.
Why don''t you include information on minimum and maximum temperature
extremes?
The Factbook staff judges that this information would only be useful
for some (generally smaller) countries. Larger countries can have
large temperature extremes that do not represent the landmass as a
whole. In the future, such a category may be adopted listing the
extremes, but also adding a normal temperature range found
throughout most of a country''s territory.
What information sources are used for the country flags?
Flag designs used in The World Factbook are those recognized by the
protocol office of the US Department of State.
Why do your GDP (Gross Domestic Product) statistics differ from
other sources?
We have two sets of GDP dollar estimates in The World Factbook, one
derived from purchasing power parity (PPP) calculations and the
other derived using official exchange rates (OER). Other sources
probably use one of the two. See the Notes and Definitions section
on GDP and GDP methodology for more information.
On the CIA Web site, Chiefs of State is updated weekly, but the last
update for the Factbook was an earlier date. Why the discrepancy?
Although Chiefs of State and The World Factbook both appear on the
CIA Web site, they are produced and updated by separate staffs.
Chiefs of State includes fewer countries but more leaders, and is
updated more frequently than The World Factbook, which has a much
larger database, and includes all countries.
Some percentage distributions do not add to 100. Why not?
Because of rounding, percentage distributions do not always add
precisely to 100%. Rounding of numbers always results in a loss of
precision--i.e., error. This error becomes apparent when percentage
data are totaled, as the following two examples show:
Original Data Rounded to whole integer
Example 1 43.2 43
30.4 30
26.4 26
---- --
100.0 99
Example 2 42.8 43
31.6 32
25.6 26
---- --
100.0 101
When this occurs, we do not force the numbers to add exactly to 100,
because doing so would introduce additional error into the
distribution.
What rounding convention does The World Factbook use?
In deciding on the number of digits to present, the Factbook staff
assesses the accuracy of the original data and the needs of US
Government officials. All of the economic data are processed by
computer--either at the source or by the Factbook staff. The economic
data presented in The Factbook, therefore, follow the rounding
convention used by virtually all numerical software applications,
namely, any digit followed by a "5" is rounded up to the next higher
digit, no matter whether the original digit is even or odd. Thus,
for example, when rounded to the nearest integer, 2.5 becomes 3,
rather than 2, as occurred in some pre-computer rounding systems.
Why do you list "Independence" dates for countries like France,
Germany, and the United Kingdom?
For most countries, this entry presents the date that sovereignty
was achieved and from which nation, empire, or trusteeship. For
other countries, the date may be some other significant nationhood
event such as the traditional founding date or the date of
unification, federation, confederation, establishment, or state
succession and so may not strictly be an "Independence" date.
Dependent entities have the nature of their dependency status noted
in this same entry.
Technical
Does The World Factbook comply with Section 508 of the
Rehabilitation Act regarding accessibility of Web pages?
The World Factbook home page has a link entitled "Text/Low Bandwidth
Version." The country data in the text version is fully accessible.
We believe The World Factbook is compliant with the Section 508 law
in both fact and spirit. If you are experiencing difficulty, please
use our comment form to provide us details of the specific problem
you are experiencing and the assistive software and/or hardware that
you are using so that we can work with our technical support staff
to find and implement a solution. We welcome visitors'' suggestions
to improve accessibility of The World Factbook and the CIA Web site.
I am using the Factbook online and it is not working. What is wrong?
Hundreds of "Factbook" look-alikes exist on the Internet. The
Factbook site at: www.cia.gov is the only official site.
When I attempt to download a PDF (Portable Document Format) map file
(or some other map) the file has no image. Can you fix this?
Some of the files on The World Factbook Web site are large and could
take several minutes to download on a dial-up connection. The screen
might be blank during the download process.
When I open a map on The World Factbook site, it is fuzzy or
granular, or too big or too small. Why?
Adjusting the resolution setting on your monitor should correct this
problem.
Is The World Factbook country data available in machine-readable
format? All I can find is HTML, but I''m looking for simple tabular
data.
The Factbook Web site now features "Rank Order" pages for selected
Factbook entries. "Rank Order" pages are available for those data
fields identified with a small bar chart icon located next to the
title of the data entry. In addition, all of the "Rank Order" pages
can be downloaded as tab-delimited data files that can be opened in
other applications such as spreadsheets and databases.
=====================================================================
@Afghanistan
Introduction Afghanistan','31166b3ffd27f074781afd6815aaccf3c51d130f9a1218f96599e2fac54cc757','internet-archive','theciaworldfactb27348gut','txt','aee2edbfef16285f559658e34614520215cc5cca0177247f40ade321a7dbb175','https://archive.org/download/theciaworldfactb27348gut/27348.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

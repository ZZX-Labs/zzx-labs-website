SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d542fe1b438ffca23db14dfb2f84a55693e843f8b2adc5c38bc571ac4ff4c867',1964,'','','raw',1,'iP eae ma
WW | Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
d sawIvuary 2£yugfT J ''
erro amen ll
ee
rile dey
Ploase aokun to FIFCT Book STAFE
a
ee Sine OS
6Z6T Asenuest - YOOSLOVA 22uUsdHy 19}; D1ISeg JEUONeN
_National. Basic Intelligence
FACTBOOK
ea Saisie nan sh! eT Set oak Sake ale dared
: GC BIF 79-001
January 1979
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
NUN
. FOREWORD
The National Basic Intelligence Factbook, a compilation of
basic data on political entities worldwide, is coordinated and .
published semiannually by the Central Intelligence Agency. The
data are prepared by components of the Central Intelligence
Agency, the Defense Intelligence Agency, and the Department
of State. Comments and suggestions regarding the contents
should be addressed to the Office of Geographic and Carto-
graphic Research (Att: Factbook) Central: Intelligence Agency,
Washington, D.C. 20505. :
The publication is prepared for the use of U.S. Government E
officials. The format, coverage and contents of the publication
are designed to meet the specific requirements of those users.
U.S. Government officials may obtain additional copies of this
document directly or through liaison channels from the Central
Intelligence Agency.
Non-U.S. Government users may obtain this along with
similar CIA publications on a subscription basis by addressing
inquiries to:
Document Expediting (DOCEX) Project
Exchange and Gifts Division
Library of Congress
Washington, D.C. 20540
Non-U.S. Government users not interested in the DOCEX
Project subscription service may purchase reproductions of
. specific publications on an individual basis from:
Photoduplication Service
Library of Congress
Washington, D.C. 20540
Non-U.S. Government users may also purchase hard copies
of this publication from:
Superintendent of Documents
US. Government Printing Office
Washington, D.C. 20402
Stock Number 041-015-00103-5
\\ -___ Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
i oie, ie
i tien) oe ae
pet
PO snc
aaceth ot eile
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
National Basic Intelligence
FACTBOOK
January 1979
Supersedes the July. 1978 ‘issuance of this
Factbook, copies of which should be destroyed.
For sale by the Superintendent of Documents, U.S. Government Printing Office
- Washington, D.C. 20402
Stock: Number ''041-015-00103-5.
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
TABLE OF CONTENTS
Entries in all capital letters refer to
basic data sheets included in this Factbook
Page
Abbreviations for International Organizations 20.0.0... ccc cece c cette nreee tees xX
United Nations (U.N.): Structure and Related Agencies ........0...0.:0.cccceeetees xii
po oe
Abu Dhabi (see UNITED ARAB EMIRATES)
AFGHANISTAN: tess cte hese there OM cotta s dah sleMaacn lane lin facie eat mnet Bs ids 3h ke ]
‘Ajman (see UNITED ARAB EMIRATES)
ALBANIA \\ vescccseeestectigosceceteaeveevectea ie eeevie. f uh Bfact Woveseledee.dviaed is ae MW aed 2
ALGERIA: st tcsnaraaniotves taritatarventete ps earl Batt vite feu eOi ec Sh eancet Mt Gnas 6 leila dE Rea ds 3
ANDORRA ooccccscccsssscsssssesesssvesssseetesseee ets De hes Dace 0 ite jan ocd hie iacaare 4
ANGOLA ones Sala aid AL OP anaes nudes 5
Anguilla (see ST. CHRISTOPHER-NEVIS) oe
ANTIGUAS ois ett met alece ete ok Daath dd rated Sansome eaten a eee 6
ARGENTINA | 055: betssdiiech 82) oa oat ek eythananlicht leh sd Stren tde boule salt alee ist dalla tal ty Mian 7
AUSTRALIA © 2205-9, Fa cy wees co ses cavegs ndeseenbanaannd diced tedesdatsal goa dedeter sveglvnedds -Pipany sea santteesoetes 9
AUSTRIA. ssesieccesiua ceorthic adedidsn obser dag tulad Meeddate aoage hawt gy soonhehaghet esta ta nadtteek isi estas 10
Azores (see PORTUGAL)
—B—
BAHAMAS; THE? <2. advo ene a ese) AR eh air tate de as VW
BAHRAIN | (2ctec ios fn ete eenerlesientatidees Ancatlin gal cable alert danetind bbs hithna ian tna agee Rte 12
Balearic Islands (see SPAIN)
BANGLADESH. ...... Be ha Na uN eat hatin eo aad tea teat An Ds aon bonne SE aoe Beats alt a eat tet as 13
BARBADOS ©0020 cee SSaedetes spas Sha thn Mec tase oh eee escent aia lteh Shenae 15
BELGIUM ooo... Colts sendin aah nasal ce Spegiash stggu san uae sagt soea ne e-moase op ese onee 16
BELIZE peer ieMte sinter ihacy cnt Most hate taa tah aete Macscutael dk hance te Rae eet eaa tues anas Re 17
BENING giiesetes carla ch ate rt eon aoe sat eG iue anal os eur Batten atic geet a2 Bat Mods Su lasat sh ents 18
BERMUDA 4.520 utios cht Oe eet eho ad cpt ght oh ATOM eects heh ne fh al ih vnaeo te 19
BHUTAN ser eh Res tel ION SUG code Bal ads ie san atiyn even cicero nes sensed oleate ee 20
BOLIVIA: - cs.cveistcentiie dh deed chti we haeeny Ae Ae iA eae Plan Bie eed 21
BOTS WANA is cies iettett lat lel ai Se ald eee Ace ediead otto ah Ge a ees ithe 23
BRA Zs cee ated rate raatliiee cedectlgst sstcse osteo vstaual diem aie ateains Ooies ao eceton eatstonies soy Pas oo saab mbeohe take teeh ales 24
British Honduras (see BELIZE)
British Solomon Islands (see SOLOMON ISLANDS)
BRUNE | 26205 6 Sanauetipeecs age Pe i aesad ashe cues ent et end eens 25
BULGARIA. sscs23scesecaed eiadectes le tedaennnes Au eves anes viadatts anaes ae Fauey ane acamaeene dees Se beatae 26
BURMA 3:30.55 825 tied igen vis abecta cbt bi dette basil eaaeans ah awted ema chad paaeeses eee vals 28
BURUNDI: esos sot etl oe eterna netsh aad by deer atialh ane Satteasasent weemna Rt sade see steeds de 29
pen geet
Cabinda (see ANGOLA)
Cambodia (see KAMPUCHEA)
CAMEROON) cee Norcet a Sot Bo creatine de talelel Aitd eda ek edi i he tat oes Jed, aelraciowns 30
CANA DAT sips ctesss ct ra otaceatinaa naa Reese is areas tnt ee ee dare coaset a cay ate 31
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
iil
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
{
January 1979
ie Page
Canary Islands (see SrAIN)
CAPE: VERDE? oi see a A ah ea cy cana ali eons dhe catia deedbeades aiaay dai geiauala® 33
CENTRAL AFRICAN EMPIRE 0000.00.00. cece ceeceeceee cee ceeteeeceeeesetesesenstescsteteeseees 34
Ceylon (see SRI LANKA)
CHAD.............. sheet cele had ea Ne AN ants Pace tleta Coaches la bathe Cateye ME 35
CHILE: ttc Nahi tatu a inet ttre shred at NR i dec he cunts tetnetas dents Ataitt 36
GEINA® ocseecestisceaestiesteries acetal analeney onal alt old dead cat obhcand tie a, Oe ONG ae A eatin il et at 38
COLOMBIA 0s. cists cottons toe anandshae tum idee od ened dive otha dasr alee Malate 40
COMOROS 8 hs 8.2. Sinaia se ce oth atures Uaretoentts, crtvacetas ately ecdtenareneontautt Glee nt oe 42
CONGO (Brazzaville) oo cccccec cece tees t eee tices eesetcescasesteseesettesteetcereeeteres 43
Congo (Kinshasa) (see ZAIRE)
COOK ISLANDS: 2s ssa te eee tres rd teaeevnsencnbeal’ qidelincetehiseecdadis San aedtven alice 44
COSTA RICA: 2.3 chat ne ate oliteie et cake Adios reenter at ee inet ee ehttates & onmenatstalaieied 45
CUBA. si.) tisraestccat nateiyan dint vesw tale sale e Mee oy al atane ttle De Saris aaluinesteddeaieat es 46
CYPRUS sc cases tsetse tesa Seah Seen a estauling Goh a Ee desi ease eat htt teen atatty Ca A oa 47
CZECHOSLOVAKIA. sectscsttectissectacrevtalte teltneats ivesete Nie aise dane. dseie gles teitaev oie hana 49
—D—
Dahomey (see BENIN)
DENMARK). c0o.0 sinensis elcid Se eat scaraedea leh oe eeenns nts dead auetcad ab ideas 51
DJIBOUTI (formerly French Territory of the Afars and Issas) ..0..000.00. 52
DOMINICA ig cotielet SOM Ae oe autveswelatdusdasl fala ldure ensued bis glues tout db etbaicomeriubenemetetthe 53
DOMINICAN REPUBLIC ooo. cece eeeetenenseeceseeeetsetesnesetsetestesieeeiittsteeteniees 54
Dubai (see UNITED ARAB EMIRATES)
—E—
ECUADOR » css. ses. center Myernto teeta inabh eb tagenthanss Lente) niin Mie et: Advosecaeitivian tsvean asta ets 55
BON PT cs itacsttes tecdecesinauages chee faeaapanoreraiekase er Pale calves eed at asthe, Niudttdy Moot als 57
Ellice Islands (see TUVALU)
DiEL= SALVADOR ais ooo cd sate ie Maleacds, mode taecs catch teguaternsatdtann chdabie agian muutande alten ay 58
EQUATORIAL “GUINEA fo scsieet isidincasin tear Setonp mniisiecaniomedediadeddath dies ue 59
ETHIOPIA) fein) AOA Se idly 2 leh, Sead Sum ten oad Sti ole ak ha ta te lea bat Ul tase 60
a a
FALKLAND ISLANDS (MALVINAS) 000.00... ccc eer teteteeetenees Sot ciletiatoes tt 62
FAROE “ISLANDS 25 icc.tee cities saved ceyies ak ade aoe iit ate ais oat, SOA leeds 63
Fernando Po {see EQUATORIAL GUINEA)
BUI scittat set Shs a ace an vies en Ad Cetetecting Pay Ged cere lees ica stat angst day ocot Sees Cll athsselnr ea 64
65
66
68
69
Frénch Territory of the Afars and Issas (see DJIBOUTI)
Fujairah (see UNITED ARAB EMIRATES)
=G-—
GABON. «5 cecoss hilt dso uiintiaiass bs vb ettaeeU vel sasdass cog aeena ek ua ataACoe aM atau eR a ed yeteetoshiendeedse IS 70
GAMBIA, “THE: «2: co es3¢s 60, 8 vsosen atte tania io) heal ved pallens peak rapide dade pete or lands Meade 71
GERMAN DEMOCRATIC REPUBLIC ooo... tee ects ceee tee betesttitettttteneen 72
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
_ Page
GERMANY, FEDERAL REPUBLIC OF ooo... cce ents ccceceteeeeesenenieerens 74
GHANA. | e623: oh eradicating sscsdeceom dutta teens Hoes fogs heuskec eatin Maun Mic « Sereda igeuds aaadbear artes tied anna 75
GIBRALTAR scsi ceccocc Get oh ie Sd he Et th ae Mh CEL Beat oa ''ot lo caine halite, 76
GILBERT: ISLANDS tise 1a, hater arn Mies a es Sat Nia Ala d ules Sess Sta 77
GREECE ico 25 ion cae ten ale lA S belts filles veal sete Ads wpa ietides Seen shl ah kuiesbealt 78
GREENLAND» g23 cceneetan ey inl cree Aa at No eats Ananth at Ie 80
GRENADA: sti ie hi eM ag a Me Ngee A A a eh Sage Seti aa ted At hecho 81
GUADELOUPE® a. dcesscsecerdcitotncectanei mt ect ga steettenenta thoes acinde Me i ea or 82
GUATEMALA sesso heeceectheeghat Skee decors aves olette wtiaae ews alae eh dace cy el Ohl et hg, 83
GUINEAS: ssa a cesta lil nical a ehende iia oe 8s Mle eal Sahiess trl uM fucks flat kes Me us 84
GUINEA-BISSAU! 2 foie d ris oc aren once aia anced eA A ented 85
Guinea, Portuguese (see GUINEA-BISSAU)
GUYANA oes MLN ae, earl 200 otal con Set Ms oleh eS laa See Sol alas a eat Se 86
—H—
PHAT oes scsi ates eA ln A Me eid oe eM oil, Bansal lak A ek Gah ates at en Sale 88
HONDURAS whe cesescss te aoded Weseibartalaceltee Meat hice alt absageady vt shneeraetedatatantaestvh reek haat ds 89
HONG” KONG §o5.0 scl ot ose antettent ts dates tote eerie ald. Sag veda Aides Jucoddnduntiidl otugedveidas Souls 90
HUNGARY, once caresses ios id ce ie Arrested eth eta OO aha cies fo Fas 91
ye
PETRI te tara ict ete eerie etcneesene e e Tit ck atl, 93
IN DIAS? oslecesescetctl neg el tet cause hacen see Dalle Bal tae tel A onal Je ne tne as 94
INDONESIAS sie:8.82.cechiistote ccs rita tate aden en odeaG Molen hd tn dette eels 95
VRAIN ish oF sa ctee Ph ettet ladies eld Mactan sail oclecotentean tes teelev ale tns Delta cea os Taw ean urge chasuetucn dite 97
NRA QS a ecaicistcctashuces stat cette awn cecleneatantieeerie id Mubuce alot hated ta weuta lan att tie cadets 98
IRELAND yc iectre ct scceh ted clic tte cr ned Sis vata a cuc don fats ain sac shemales tnt hea ehcp us Gas el dat 99
ISRAEL, ~oeicsg ce scien cocecunt evetsn tate eed con de da adn aren ee wears aeauae ee Aeine 101
VEAL s soc ho oan reve aera narsaee tant odd adi tact cee eyes Me testa hate oe RSE ate A Packs Ys be 102
IVORY SCOAS Terncstis ceteris sek ai aie ee ei lest rte i teens tet Al on tases da eel ad 104
ee ae
JAMAICA 6 crises techs tat Sele teal tll tc ad th UCM CN oe atte detec tin eect ol 105
JAPAN gsshecees a speeeeste ates ieactorend sialyl, Me dedi ta cien died lew tad NO aed cude cess saetttvaeceldiaamuanenaites 107
JORDAN cis 55 ocho peas ha socaceceantect ens cs saat teerens dade Mets adt dbl eet tin satle ia atdal eben hte 108
an ae
KAMPUCHEA (formerly Cambodia) 00.00.0000. cccccccccccccccccccccceeeseeetensttuctserevenseeees 109
KENYA ost hal lei tne cute Legh ae eR! iS hialn bh oN chk ch bate leet nthe alls Mac, 110
KOREAS. “NORTH: sides 220% inchs Bais caked eeesec tetas lat cn hedheca tet cansl gullhc Sl data tn iaae 112
KOREA SOUT sie oc eg soda Be ened lS screnutdald cust dep mies oee eh Gaia Leos 113
KU WADE is teases ec d nar emettenle, tthe okt tah TS, ot hile SIM oPalenrpns Mats wa wea cee Mk 114
p=
EA OS +2 resonant neal sated a cates Sock ey ee ane teeh uct naden Soceiehs Alan Ai ha ie hee cnet aE, 115
LEBANON i! essstiac alice gai actntalee MN aol Cale peas deeleg oie wet ai hd, ONG da ARAM AAD aol 117
ESOT Oct eA RG taste sta aici Prd Sacto f MRE EE eR A Ae 118
LIBERIA S c0ts i425 27, Casei a mira tiacl stax neve aes mega Mateos hae Ne eo 119
PAY ikeShict ihe atin cyt tele cbt eclectic hah Mode eh col clon tendadt 120
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Sofi Page
LIEGHTENSTIEIN: crete seats eis 8 i gS finacaleiennctaars peat dy lne dv aveh to slams cont dane és 122
LUXEMBOURG ideo ee ee ERA Ged a ih da ld of dhe wad eee bi ata Mog 123
Me
MACAO sie Second otingtauidess cack cdc oen fess nt obs cela rest aoeie ect dead eg etait Sarah Ae ont sett aad Be 124
MADAGASCAR: <stehcchit Wont ANS ac islet lata Ek, oe case He Mee a eal eas, a 125
Madeira Islands (see PORTUGAL)
Malagasy Republic (see MADAGASCAR)
MALAWI he oA ecieek ea oe Oe ia, ald te ehh ie duty watie al alee ah CN oh 8 od Dates ia 127
MALAY STA. ei vgeticscs aCe 8 te hese Naat t ia) Rees Mae a Ee eee tha ciate 9 dah ete bent nl oa 128
MALDIVES :< gectrssonencsteitenvndteaidile becdainn Qs Didnt stem dH vielen Gramagie vant medi ne ted nraeon sens 130
IA BRED, oasis he ee ee cn tencoe ase atts aed ns Rae ca Ves Peels ek eat es dk A OM Soke cles Pentlcaetace ante Sea 131
MALTA: 2 oe naher ds es ee peaball inten ae ces Masta teat amauta Maevthh tl adswetutatundt a taste uel es Se 132
MARTINIQUE. cote loci inteiash Aah cestiih dais ed ehh Mle iene cel ahd A a a en sh elie aaa 134
(MAURITANIA 005.050 .s0e-get peed aceaereaibes beaten at cavanseesi eciedtouneas dase EE aR erent ee 135
MAURITIUS rt cca ten eel od ace ddl hae hast Mokau Lat teed ol | ele bth ot oadad Stud hand os 136
MEXICO seis cnet siectis ei veraa one desc stv eye ou bach ec cesat (Al aceres aber te heater hae clcteae DANIEL 2 137
MONACO esseolctetee tins tesa habatestincs nah des Wheaten ocsis nasctaa th irsityn cana auditlas ta adeeme tes oacuennaads 139
TAOS QUA eres Nahe rah rea taleculiyn Sunnah Mie A caleta en te hema ead 140
MOROCCO™ oa gei etch tec tavicnco laters beds cas bite buasebh ayd Sdoeatephcat ualdolenduansiayeteexiatlin bAietsats 14]
MOZAMBIQUE 3: 3 cre Boch tasies Bee taes tenia dee ox visage wabehiudl esnptan satel Geaednade uae aabeieerronsss 142
—N—
NAMIBIA (South-West Africa) ......cccccccsssssssssssssssssvsssssivesstvevtssssssessevsesevesessveeseeee 143
NA UR sore: aon naan tats uscmesincnattlan scbteaw sobbing eos! ecause trae add uns svatengtieeal tea edies wletenncayse 145
INE PAD Foor oiteen te Oi eacten Sena eideenta cowl a de AEN i dR ten SNe aac AE re cl fe ht an So Nek 145
NETHERLANDS ©6035 ca tec8 cs eeaesapaa deca viet Quebec vce eee Se cir ov ened cetsghe Reveomaeleatedn 147
NETHERLANDS ANTILLES 200i ccecennteeercivapeeveneteesenetecenrateess 148
NEW: :CALEDONIA®: 35-c.detenaa citer vleeten ected sta Aad dedeatuedi us en teh kN es 150
NEW HEBRIDES: je) be chu nee clltaktd waa heel oh wo Stash Ne lay evuoneuagda baat Rates 151
NEW ZEALAND uu Sea teh es dae stoop estes hain Rae kadai cea tha hte 151
NICARAGUA 4) sce casasere creshontntsaele hdl Obie, os Se tdaatds gud iudia nye mea alesinma ne beevaatenaes 153
IER fia as easier see careee sanity tc Aevaceit pace Deena tea ea natal aes matted rs acon dh 154
NIGERIA ooo. Soa hiteath dauslnsts bem teu eden Medtids ten netneenierotdan Men ads. 155
Northern Rhodesia (see ZAMBIA)
BUA asst relies yt Caceres ee SOO et hte een eh alae eah 157
—o—
OMAN 95 ccse aise aoaereisteaviet dette ecraeed cence alates dae eae eauented dl aeaetitan iota cin aie 158
—p—
PPAKISTANG: dices. t5e copped oceiaa cde niu te sna press tghian dues seisdewcensastiete na @iaspeegs Seuinbbre Gadseanthsaenandasheene 159
PANAMA «2th cichictteitats tie 9 Ed eee Mel a eo AG Se cua eiys Mnonadense stegttaces audios 160
pa
PAPUA NEW GUINEA. ooo occcccccccccccccccecsecceceseceevessevevtnevevivsvevesevetevebevevevetbeevees 162
PARAGUAY © ec ccdcecsltet ences Reaphioat Seon veatia cable eh verghtiesleh hfs deleediebSla ie Louledes aevedeeaguauanbetecn cubes 163
Pemba (see TANZANIA) ge
PER ae ee ee rehce a cna ured RN coh Saat Mera et Meter tiued: Tasaand alt Maceo tOtudy Gholi 164
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
ips Page
PHILIPPINE Sic ccsocsees su ssneyn cactereeaeh ete ene sauennere that eounald sh tats he i aee ln a Relate cvs edieaaats 166
PORAIN Di sreestcisesss55. nase aap des Oost neg ih Gasca pce eee esata eer cla ltt 167°
PORTUGAL ccc Mentors a tunnie Bea id le neti a Rote Sane ete Pa atecbe ss 168
Portuguese Guinea (see GUINEA- -BISSAU)
Portuguese Timor (see INDONESIA)
GO
RT ceca epee anaes ee agers aN aetae taelaes 170
ip
Ras al Khaimah (see UNITED ARAB EMIRATES) _
RECRUON 2.3 matdvssiteacenrna isin tecncaun Gaeee YAN il dl beast vasenmnamnlal alacant hay 171
RHODESIA? 32. ccbswsennes eee RSet lek ae Ste Mag sed eae aie ig baad hic densete nee Mula eeieciens 172
Rio Muni (see EQUATORIAL GUINEA)
ROMANIA 2 derhs referee ete ete ieee cota Seances ate een nee 173
RWANDA ci, fulinntrairsneliainauet cineca ada he Baa tant Beads 175 —
—s—
ST. CHRISTOPHER-NEVIS-ANGUILLA ooo... ect e te vtetetetttenetetes 176
és STs LU CIA. te A tiacke Saag cere iia G cxevec hina ee avila kaa ean Gace Pccanetech aerbeoncltclnl DS, ‘177.
Sie MIINGENT sigetnsttiasinabas oldie taa sa lacey eden tere irae aeeheneati tha vananiedigaeabtsytecestes 178
SAN: MARINO? soecctcscklenes.cerlvac et ueavaese deere Madi ected tbnatrddy eek Wass bet es Mea 178
SAO TOME and PRINCIPE oo... tec et cect teeter ct tteteesfetcteritsttterneeee 180
SAUDY ARABIA 2 S echcciess taazases ae atts greta cuithl ashe chisiehz ts beaais ined lur hotasei is “181
SEINE GA scien eae uest akg tas nes Mea ee Teed naeats feasted mqsoh occ td eslog sna soot co ensta asad apenc Bae 182
SEV. CHELLES: ei, Fe tectaud cnc auctiiay doacle ttt pt Riad au2t veins selma diene staal satdv ent ta votanaescbamertaat eaten 183
Sharjah (see UNITED ARAB EMIRATES)
SIERRA LEONE Seat : 184
SINGAPORE: 535 sores secdrnsipet alent Bhareshtyiatonicstuadn del iaaueeneana sa es : ce “186 |
SOLOMON ISLANDS (formerly British Solomon Islands) © .0.2!2.0000 oh. .. 187
SOA IA aoe eet Os GB a Sl dete veg ue Me naurtena iarnigr on Geer snenetiees Se One ee 188°
SOUTH ABRIGCA coerce cused Mhe haath Batu coheed amt Lak 4 den ha fod, and deb Galt dee 188
Southern Rhodesia (see RHODESIA)
South-West Africa (see Ee ca
SPAIN 2c: Sevccehacnaisaageceoneaadivechegete diced alan oh A ie MP a1 loot aes es totaled a tae -191
Spanish Sahara (see WESTERN SAHARA) : vey,
SRI LANKA (formerly Ceylon) oo... ccc ccc cece ette ete ee ee ceececteeetesecnsesteentiesteectees 193
SUDAN © 2eccds sswin nadine, daidqubetticimiss teeta odintes dee Rnd cde ena rasa Mas eedbaeiio ma? - 194
SURINAME 665. ddessSdavrsnaden nbn Te ended GGG UNO se Pe Sa opt 196
SWAZILAND rsa secassca tes i veatay esses hen aah ahve stars Leen opsictaacts Soy ceelle haces sven
SWEDEN? fee cnineiieraceatciei aoe eran Aad eaens Datel ne eesctuds eee 198
SWITZERLAND: ete tet cone ath hed did Se ad foe pa uated a amet abate ah .... 200
SYIRUA 15.2255 fabccnsica sgt setae eae areas ga dS ooalgas tek aakyaetee Haass ea detaaeeetaa elite M eddn papemaaaneeeAneeaniares seace: 201
a
TELIA WINE soe treo tcacsadea es ok Ecce ae, Saati dotcent ane aN leat od aaa ees 202
Tanganyika (see TANZANIA)
TAINZANIAS ono re tice te tet 8a ads Oe hae csc ln 2 Cac das Wee aR Nia aes tc aa a 202
Tasmania (see AUSTRALIA)
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
pa cae Page
THAILAND ® ec toed ese slchte des eta hdgils BOdriahs Pea awed ag ifs te ae heeded ti oh caine se aeneecnens 204
TOGO serena hiieets asthanneiaie at Be ees 2iar elena lh ial, tt AEN at cul At ule Gic ON kel dalle lea te Et 205
TONGA? seine ciety a bPentag ces hemes pec te te dR Cant Ste wie fa Mah 206
Transkei (see SOUTH AFRICA)
TRINIDAD “AND: TOBAGO: gros. cc sn ssteterncteanntearies etashsdideed eeaaetl ive dhdeaaturedtads 207
TONS IA ch sash sta ay Cte ciae ane nee ah yee aa geri epancaes pele wee eee 208
TORRE tbl rut ca ssten sitet etna Maeno tin tht Sa shad UM toe deed Ide ant ee Ciath de a A AA 210
TUVALU (formerly Ellice Islands) 2.0.00... eeeeeetecsseteepenseeettenteetecnsenes 211
—y—
UGANDA? osc5 Zonta sd Sate atte net gs te ca cate ata ttl ae an cantinedbenten: 212
Umm al Qaiwain (see UNITED ARAB EMIRATES)
USS eRe chao sean a anatt southern ateite decid Ran apni Ne weet Mts lahat anil eR i Uae, bee da 213
UNITED ARAB EMIRATES: Abu Dhabi, ‘Ajman, Dubai, Fujairah,
Ras al Khaimah, Sharjah, Umm al Qaiwain ooo... ccc 214
United Arab Republic (see EGYPT)
WINITED: KIBIGDOMG sccscaas ht slasatts-cctstaa ly adees dayashe teacnemnutmne eo eamenends 215
UNITED: “STATES, 2233s toh acts eeect aries lee dev aie Nenths iee cern aed ea hae dent 231
UPPERS VOLTA istic Ws Te lode 1 PSR oat deta oie ht ED Akl ais 217
WRUGUAY® cs ctttesieat nec teenie ain oat Sea PAU celine nee SR deca saasi dol eedeteen ton 218
—Vv—
VATICAN ES CITY = Shcgs xectates tenis atta a ea ied athale, Bea arcs canon 219
VENEZUELA 3, -45.}ocsagasdsacepstochacatsctencdteaihotsent da obanvesidGhee ple baiuetiushvals daadeetesla td eoeieton tls 220
VIETNAM o.cccccceeeeeeteeeerees Tate heat ies estteee cases Oa CARNAL A ad 221
—w—
WALLIS: arid? FUTUNA: soccccsincseecsosneesias scales Causudeegesnatansenierseninncduencanasdeatendeveevuseanspacengs 223
Walvis Bay (see SOUTH AFRICA)
WESTERN SAHARA (formerly Spanish Sahara) .......0..0.. ccc eeteeeeee 223
“WESTERN = SAMOA: 3205.20: 8so.onincces ew are ten Pelee Oe ota betes aia Sedpaesne aed: 224
a
NEMEN:= (Aden) ossescssc:.acr3: ausuace snots coetsentery feeaaauetenaae ce eeah eta le pe ate Dl bl all 225
YEMEN (Sanna) © 9) cotse5- Soren lie ee eet aden ur Ta an tu eeneecaataien hee 226
YUGOSLAVIA? os asia het ere cehtel eh, ial ue MRA te a Racal uta aed det lets A 227
—7=5
LAIRE oe, isc 2st ster ithe tect al ih Salse MLS itde ht RAIN Leg, cal tdires ot events Seas rte thai 228
ZAMBIA cceicsecciter a tate rencncidi eld ee ie ee ee 08 aioe ee ease eects 230
Zanzibar (see TANZANIA)
Vili
ee ee ee ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Se eee eS ee ne EO ey eee 6a 8
Oe et ee gee Oe Se oie SA ee ee ee Se ee ee
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Vill
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
MAPS','fc55bb8284f3122e48f2449d5b97d3eb204b50cbba30635e185ddd78b07ad7db','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bba564385bec458f76db427f0ed9fb4439a6d3931cb73474a69e913fb6541061',1964,'CA','Canada','raw',2,'. MIDDLE AMERICA
SOUTH AMERICA
EUROPE
THE MIDDLE EAST
AFRICA
U.S.S.R. and ASIA
OCEANIA
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
AAPSO
ADB
AFDB
ANZUS
ASEAN
ASPAC
BENELUX
BLEU
CACM
CARICOM
CARIFTA
CEAO
CEMA
CENTO
DAC
EAMA
EC
ECOWAS
ECSC
EEC
EFTA
EIB
ELDO
EMA
ENTENTE
ESRO
EURATOM
G-77
{ADB
ICES
IDB
IEA
IHO
IPU
IRC
LAFTA
LICROSS
NAM
NATO
OAS
OAU
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS
Afro-Asian People’s Solidarity Organization
Asian Development Bank
African Development Bank
ANZUS Council; treaty signed by Australia, New Zealand, and the','9615eaeba672b95a00c73cb071438af636e2d49a0ddf519274f8e8b75e040f56','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c43ec2618ceb5ee413998b7f49a1a3001c965d3cfab144092bcbc053b3a01530',1964,'US','United States','raw',3,'Association of Southeast Asian Nations
Asian and Pacific Council
Belgium, Netherlands, Luxembourg Economic Union
Belgium-Luxembourg Economic Union
Central American Common Market
Caribbean Common Market *
Caribbean Free Trade Association
West African Economic Community
Council for Economic Mutual Assistance
Central Treaty Organization
Colombo Plan
Council of Europe
Development Assistance Committee (OECD)
African States associated with the EEC
European Communities (EEC, ECSC, EURATOM)
Economic Community of West African States
European Coal and Steel Community
European Economic Community (Common Market)
European Free Trade Association
European Investment Bank
European Space Vehicle Launcher Development Organization
European Monetary Agreement
Political-Economic Association of Ivory Coast, Dahomey, Niger, Upper
Volta, and Togo :
European Space Research Organization
European Atomic Energy Community
Group of 77
Inter-American Defense Board
International Cooperation in Ocean Exploration
Inter-American Development Bank
International Energy Agency (Associated with OECD)
International Hydrographic Organization
Inter-Parliamentary Union
International Red Cross
Latin American Free Trade Association
League of Red Cross Societies
Non-Aligned Movement
North Atlantic Treaty Organization
Organization of American States
Organization of African Unity
January 1979
Declassified and Approved For Release 2012/09/02 : CIA-RDP0O8-00534R000100140001-7
Pe on
|
EE ME Ee a eg
Ee Oe Oe a eee ee er ee EN ee See, a ae ae ee, oe
a pe ae es
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
ABBREVIATIONS FOR INTERNATIONAL ORGANIZATIONS (Cont.)
OCAM
ODECA
OECD
SELA
UDEAC
UEAC
WEU |
wPC
WTO
AIOEC
* ANRPC
APC
ASSIMER
CIPEC
IATP
IBA
ICAC
IcCCO
ICO
1IOOC
ISO
ITC
IwC
IwC
OAPEC
OPEC
UPEB
WSG
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Afro-Malagasy and Mauritian Common Organization
Organization of Central American States —
Organization for Economic Cooperation and Development
Latin American Economic System
Economic and Customs Union of Central Africa
Union of Central African States
Western European Union
World Peace Council
World Tourism Organization
!
‘COMMODITY ORGANIZATIONS
Association of Iron .Ore Exporting Countries
Association of Natural’ Rubber Producing Countries
African Peanut (Groundnut) Council
International Mercury Producers Association
Intergovernmental Council of Copper Exporting Countries
International Association of Tungsten Producers
International
International
International
International
International
International
International
International
International
International
Bauxite Association
Cotton Advisory Committee
Cocoa Council
Coffee Organization
lead and Zinc ‘Study Group
Olive Oil Council
Sugar Organization
Tin Council .
Whaling Commission
Wheat Council
Organization of Arab Petroleum Exporting Countries
Organization of Petroleum Exporting Countries
Union of Banana Exporting Countries
International
Wool Study Group .—
xi
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
UNITED NATIONS (U.N.): STRUCTURE AND RELATED AGENCIES
Principal Organs:
sc Security Council
GA General Assembly
ECOSOC Economic and Social Council
Tc Trusteeship Council
ICJ International Court of Justice
oe ales Secretariat
Operating Bodies:
UNCTAD U.N. Conference on Trade and Development
TDB Trade and Development Board
UNDP U.N. Development Program
UNICEF U.N. Children’s Fund
UNIDO U.N. Industrial Development Organization
Regional Economic Commissions:
ECA Economic Commission for Africa
ECE ‘Economic Commission for Europe
ECLA Economic Commission for Latin America
ECWA Economic Commission for Western Asia
ESCAP Economic and Social Commission for Asia and the Pacific
Intergovernmental Agencies Related to the U.N.:
FAO Food and Agriculture Organization |
GATT General Agreement on Tariffs and Trade
IBRD International Bank for Reconstruction and Development (World Bank)
ICAO International Civil Aviation Organization
IDA | International Development Association (IBRD Affiliate)
IFAD International Fund for Agricultural Development
IFC International Finance Corporation (IBRD Affiliate)
ILO International Labor Organization
IMCO Inter-Governmental Maritime Consultative Organization
IMF (FUND) International Monetary Fund
ITU International Telecommunication Union
UNESCO United Nations Educational, Scientific, and Cultural Organization
-UPU Universal Postal Union
WFC World Food Council
WHO World Health Organization
WIPO World Intellectual Property Organization
WMO World Meteorological Organization
Autonomous Organization Under the U.N.:
IAEA International Atomic Energy Agency
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
Ne alt
ALK i te OR LT ce eR Nh lh
ea ee ee
AL
ee er ees
Se =e
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979
Political, sociological, and economic data, including monetary conversion rates, generally
reflect information through mid-October 1978, except for population estimates, which have
been projected to 1 January 1979. Military manpower estimates are as of 1 July 1978 except .
for average number of males reaching military age, which are projected averages for the 5-
year period 1978-82. Military and communications data are as of 31 October 1978 unless
otherwise indicated.
Most of the land utilization estimates are rough approximations, and most of the
statistical data are rounded (thousands and millions). Figures for ‘arable’ may reflect only
the area actually under crops rather than the potential cultivable. Fishing limits are included
only when they differ from the territorial limits.
For some countries GDP, rather than GNP, is shown. The difference between the two is
in the addition or subtraction of the value of return on foreign investment. GDP equals GNP
plus income earned in the country but sent abroad, minus income earned abroad but sent into
the country. GDP thus tends to exceed GNP in debtor countries, and the reverse is true in
creditor countries.
Mogijor ports are the largest maritime ports of the country, relative to other ports of the
"same country, on the basis of estimated port capacity, alongside berthing accommodations,
Declassified and Approved For Release 2012/09/02
and commercial or naval importance. Minor ports are the remaining ports of a country which
have, relative to the major ports, significantly lower estimated capacity, fewer alongside
berthing accommodations, are of less commercial or naval importance. Major transport
aircraft are those weighing over 20,000 pounds. Military budgets are in U.S. dollar
equivalents. The dollar sign refers to U.S. dollars unless otherwise stated. The abbreviation FY
stands for U.S. fiscal year; all years are calendar years unless otherwise indicated.
Approximate Metric Conversions
Symbol When You Know Multiply by To Find Symbol Symbol When You Know Multiply by To Find Symbol
LENGTH LENGTH
mm millimeters 0.04 inches in in inches 2.5 centimeters om
cm centimeters 0.4 inches in ft feet 30 centimeters em
m meters 3.3 feet ft yd yards 0.9 meters m
m meters 11 yards yd mi miles 1.6 kilometers ken
km kilometers 0.6 miles mri AREA .
AREA in? square inches 6.5 squate centimeters cm?
cm? = square centimeters 0.16 = square inches in? 1? square feet 0.09 = square meters m?
m? square meters 1.2 square yards yd? yd? square yards 0.8 square meters m?
km? — square_ kilometers 0.4 square miles mi? mi? square miles 2.6 square kilometers km?
ha ___hectares (10,000 m?) 2.5 acres acres A hectores ht
MASS (weight) MASS (weight)
qa gram 0.035 ounces oz oz ounces 28 grams 9
kg kilograms 2.2 pounds Ib fb pounds 0.45 kilograms kg
t tonnes (1000 kg) Ww short tons short tons 09 tonnes t
VOLUME ; (2000 _Ib)
vi
mi milliliters 0.03 fluid ounces fl oz OLUME
'' liters 2.1 pints pt tsp teaspoons 5 millititers ml
t liters 1.06 quarts qt Tbsp tablespoons 5 milliliters mi
{ liters 0.26 — gallons gal fl oz fluid ounces 30 milliliters mi!
m cubic meters 35 cubic feet fr? c cups 0.24 liters t
m? cubic meters 1.3 cubic yards y@? pt pints 0.47 liters i
qt quarts 0.95 liters |
gol gallons 3.8 liters t
fr cubic feet 0.03 — cubic_ meters m
yd —cubic_ yards 0.76 — cubic_meters m
: CIA-RDPO8-00534R000100140001-7
a Fe 7
a a a A at al ot i a ee el a el cre i a er tiene En i ae lial
Declassified and Approved For Release 2012/09/02 : CIA-RDP08-00534R000100140001-7
January 1979','a32968c870199c289b3b271d5fa240e1933f518df63a3c7b90d1e4f7661a5b6a','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5c0935719e1c1e905138d4d627ebcf5ff2ff0a5714b00a4d0a23afa562f2c63b',1964,'AF','Afghanistan','raw',4,'Arabian Sea
(See reference map Vil}
LAND
647,500 km*; 22% arable (12% cultivated, 10% pasture),
75% desert, waste, or urban, 3% forested
Land boundaries: 5,510 km','f60ee5b8a2b1360e99c3a106ddecf009d8afe9f6e38cc5b49468403ba0922e7e','internet-archive','cia-readingroom-document-cia-rdp08-00534r000100140001-7','txt','ec9beace7e7e9527fb3293528dda839e591ff16e6de2bc0a5ac6d5f13abc719e','https://archive.org/download/cia-readingroom-document-cia-rdp08-00534r000100140001-7/cia-rdp08-00534r000100140001-7_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('56e92d6c34204e14dd6a30aaea3c768f4a15b540910dbee18daefb36edb52662',2002,'AU','Australia','military-and-security',24,'Military branches
Military manpower - military age
Military manpower - availability
males age 15-49
females age 15-49
Military manpower - fit for military service
males age 15-49
females age 15-49
Military manpower • reaching military age
annually
males
females
Military expenditures - dollar figure
Military expenditures - percent of GDP
Military -note
Military branches: NA; note - the December 2001
Bonn Agreement calls for all militia forces to come
under Afghan Interim Authority (AIA) control, but
formation of a national army is likely to be a gradual
process; Afghanistan''s forces continue to be
factionalized largely along ethnic lines
Military manpower - military age: 22 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 6,896,623 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 3,696,379 (2002 est.)
Military manpower - reaching military age
annually:
ma/es: 252,869 (2002 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: Army, Navy, Air and Air Defense
Forces, Interior Ministry Troops, Border Guards
Military manpower • military age: 1 9 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 888,086 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 727,406 (2002 est.)
Military manpower - reaching military age
annually:
males: 35,792 (2002 est.)
Military expenditures - dollar figure: $56.5 million
(FY02)
Military expenditures - percent of GDP: 1 .49%
(FY02)
Military branches: Peoples National Army (ANP),
Algerian National Navy (ANN), Air Force, Territorial
Air Defense, National Gendarmerie
Military manpower - military age: 19 years of age
(2002 est.)
Military manpower - availability:
mates age 15-49: 9,01 6,048 (2002 est.)
Military manpower - fit for military service:
mates age 15-49: 5,513,317 (2002 est.)
Military manpower • reaching military age
annually:
mates: 388,939 (2002 est.)
Military expenditures - dollar figure: $1.87 billion
(FY99)
Military expenditures - percent of GDP: 4.1%
(FY99)
Military branches: Royal Australian Army, Royal
Australian Navy, Royal Australian Air Force
Military manpower - military age: 17 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 5,013,406 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 4,321 ,387 (2002 est.)
Military manpower - reaching military age
annually:
males: 142,686 (2002 est.)
Military expenditures - dollar figure: $9.3 billion
(FY01/02 est.)
Military expenditures * percent of GDP: 2%
(FY01/02)
32
Australia (continued)
Military - note: defense is the responsibility of
Military branches: no regular indigenous military
forces; Police Force
Military - note: defense is the responsibility of New
Zealand','b656fc6f0ec893f4ad33718de3c0f308900559371534952ba57fb8f009c95bdb','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3a941238b12dda58bc7706a9822a9b0a84346aec6dc96d5f38fb0733e3d09a11',2002,'NZ','New Zealand','military-and-security',34,'Military - note: defense is the responsibility of the
US
Military branches: New Zealand Army, Royal New
Zealand Navy, Royal New Zealand Air Force
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1,010,316 (2002 est)
Military manpower - fit for military service:
males age 1549: 850,185 (2002 est.)
Military manpower • reaching military age
annually:
males: 26,480 (2002 est.)
Military expenditures - dollar figure: $515.6
million (2002 est.)
Military expenditures - percent of GDP: 1 .2%
(FY2001/02)
o ir, acm. Tobago
Scarborough ,
Military branches: Tonga Defense Services (made
up of three operational command components and
two support elements, including the Royal Marines,
Royal Guards, Maritime Force, a support/logistics
group, and a training group), Police; note - a new air
wing that will be subordinate to the Ministry of Defense
is being developed
Military expenditures - dollar figure: SNA
Military expenditures - percent of GDP: NA%
Cuiil.l r-.-tr.
Joco
PORT-OF-SPAIN ''
. ♦Arima
Tunapuna , * ^ j
C,;;jf Sangre Grande
Trinidad
''Point Lisas '', Noril:
Pointe-a-Pierre . SL Ali.tn I i C
San Fernando. * . Oco~n
Military branches: Trinidad and Tobago Defense
Force (including Ground Force, Coast Guard, and Air
Wing), Trinidad and Tobago Police Service
Military manpower - availability:
males age 1 549: 347,831 (2002 est.)
Military manpower * fit for military service:
males age 15-49: 248,324 (2002 est.)
Military expenditures - dollar figure: $90 million
(1999)
Military expenditures • percent of GDP: 1 .4%
(1999)
Military - note: defense is the responsibility of
Military - note: defense is the responsibility of','37be87fe476cf95a2e9de3d54b03b65c95df774f3e3fd4a4f9e52e533661964c','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3c2be9c08b135febf78f1b4204b4a42b7960d3c584ab9a560cf9f359aceea62d',2002,'ES','Spain','military-and-security',43,'Military branches: no regular military forces, but
there is a police force
Military ■ note: defense is the responsibility of
France and Spain
Military branches: no regular indigenous military
forces; British Army, Royal Navy, Royal Air Force
Military - note: defense is the responsibility of the
UK
Military - note: defense is the responsibility of
Military branches: Army, Navy, Air Force, Marines,
Civil Guard, National Police, Coastal Civil Guard
Military manpower • military age: 20 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 10,520,561 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 8,403,430 (2002 est.)
Military manpower - reaching military age
annually:
males: 281 ,043 (2002 est.)
Military expenditures - dollar figure: $8.6 billion
(2002)
Military expenditures - percent of GDP: 1 .1 5%
(2002)','a9cd6242caf0f8d234facbdbbcd17c465a4cd98d70512ea160651fe5163c9241','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb25fcc7e6641a80f439edef74e27da92163cfb1396a8d3551bbacfda835b22a',2002,'AO','Angola','military-and-security',52,'Military branches: Army, Navy, Air and Air Defense
Forces, National Police Force
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 2,532,469 (2002 est.)
Military manpower - fit for military service:
mates age 15-49: 1 ,272,509 (2002 est.)
Military manpower - reaching military age
annually:
males: 103,807 (2002 est.)
Military expenditures - dollar figure: $1.2 billion
(FY97)
Military expenditures - percent of GDP: 22%
(1999)','d99113cab11ab1fd4bd012d7aa9187545452b918bba129d14a749844278b599c','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2d071525949cffd210a09acae2f05db244cb90329382f063164ef3600fffc4cd',2002,'AQ','Antarctica','military-and-security',70,'Military - note: the Antarctic Treaty prohibits any
measures of a military nature, such as the
establishment of military bases and fortifications, the
carrying out of military maneuvers, or the testing of
any type of weapon; it permits the use of military
personnel or equipment for scientific research or for
any other peaceful purposes
Military branches: Argentine Army, Navy of the
Argentine Republic (includes naval aviation and
Marines), Coast Guard, Argentine Air Force, National
Gendarmerie, National Aeronautical Police Force
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower - availability:
ma/es age 15-49: 9,521 ,633 (2002 est.)
Military manpower - fit for military service:
mates age 15-49: 7,721,219 (2002 est.)
Military manpower - reaching military age
annually:
males: 335,085 (2002 est.)
Military expenditures - dollar figure: $4.3 billion
(FY99)
Military expenditures - percent of GDP: 1 .3%
(FY00)','9aec0a70c91b763bb2cead3bf2e8e3c146e4b3ddabc4cdd7aeb5f9b1b9d12336','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('01c8e8d02470ad817fc2783d95dfefcb943275446fb7537d7a973d82938efa53',2002,'GP','Guadeloupe','military-and-security',80,'Military branches: Royal Antigua and Barbuda
Defense Force, Royal Antigua and Barbuda Police
Force (including the Coast Guard)
Military expenditures • dollar figure: SNA
Military expenditures - percent of GDP: NA%','fa889a43cd7cbefe2aae91b9000b71060e314d049de9f6cc1b2cf7e0835ad76e','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d36a7adc3f52199c936021c6e954cf7bd58f76849d05888c0a3292a46f1ae02',2002,'AM','Armenia','military-and-security',89,'■''• GEORGIA ^S.
''■"""''Alaverdu ^\\-J
ljevar\\^*V ......
) *Gyumri
*Vanadzor ^
j? Aragat*
:: Hrazdan \\A2ERBAIJAN
\\ Ejmiatsin#
* • f
YEREVAN Vafdeniy
TURKEY
'' \\ A2ER. L C
YtNax^ivan) X Kapan A
IRAN ^^A^V
O 20 40mi
Military branches: Army, Air and Air Defense
Forces, Border Guards
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 912,650 (2002 est)
Military manpower - fit for military service:
males age 15-49: 722,035 (2002 est.)
Military manpower - reaching military age
annually:
males: 34,998 (2002 est.)
Military expenditures - dollar figure: $135 million
(FY01)
Military expenditures - percent of GDP: 6.5%
(FY01)
Military branches: no regular indigenous military
forces; Royal Dutch Navy and Marines, Coast Guard
Military - note: defense is the responsibility of the
Kingdom of the Netherlands
Military - note: defense is the responsibility of
Australia; periodic visits by the Royal Australian Navy
and Royal Australian Air Force
Atlantic Ocean','682077d91966a8439511fa0f9508e3e4d71c13929f38e59c4d1e406ddc919e00','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e2cbfc4bd2c9827aabd9c3cc5c59ee9f70e0e34067071b8c73e4f3b26e33ef0a',2002,'AZ','Azerbaijan','military-and-security',98,'C" 0 50 100km
Military branches: Army, Navy, Air and Air Defense
Forces
Military manpower * military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49:2,131,331 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1,706,325 (2002 est.)
Military manpower - reaching military age
annually:
males: 77,099 (2002 est.)
Military expenditures -dollar figure: $121 million
(FY99)
Military expenditures - percent of GDP: 2.6%
(FY99)','57dfe401cf929119ccd36df15e4694d96a97808e401da3b3f54529320780150b','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('91d444e97c7a3208c96149fff2b347ecb6ddc6dfcb1f7ebec3259129cdea30bd',2002,'BS','Bahamas','military-and-security',111,'Military branches: Royal Bahamas Defense Force
(Coast Guard only), Royal Bahamas Police Force
Military expenditures - dollar figure: $20 million
(FY95/96)
Military expenditures - percent of GDP: 0.7%
(FY99)','a82ff68f830f7bab0df4eed8e3962877740ac46f3eddc0470f3ba1164d6fe1a5','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6d1ba76e16c72b4d4788d231badf3f6e30e638e357dbf6d07c7429c5a8b93162',2002,'BH','Bahrain','military-and-security',121,'Military branches: Bahrain Defense Forces (BDF)
comprising Ground Force (includes Air Defense),
Navy, Air Force, Coast Guard, Police Force, Amiri
Guards, National Guard
Military manpower - military age: 15 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 222,572 (2002 est.)
Military manpower - fit for military service:
males age 1549: 121,955 (2002 est.)
Military manpower - reaching military age
annually:
males: 5,926 (2002 est.)
Military expenditures - dollar figure: $526.2
million (FY01)
Military expenditures - percent of GDP: 6.7%
(FY01)
Military - note: defense is the responsibility of the
US; visited annually by the US Coast Guard','1d57092470cf2616750b1412105939356640e56ed8e446937c5f5829f294f026','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('08fbc5a56bd497ee31ff519ef2ff0b9fd7e2dbe65577f529882a9c9c0dd17e8a',2002,'BD','Bangladesh','military-and-security',126,'Military branches: Army, Navy, Air Force, Coast
Guard, paramilitary forces (includes Bangladesh
Rifles, Bangladesh Ansars, Village Defense Parties,
Armed Police Battalions, National Cadet Corps)
Military manpower - availability:
males age 15-49: 37,303,372 (2002 est.)
Military manpower - fit for military service:
males age 1549: 22,1 39,736 (2002 est.)
Military expenditures - dollar figure: $559 million
(FY96/97)
Military expenditures - percent of GDP: 1 .8%
(FY96/97)','c7bccac73494b181c6793fc3026f5a54ef213f523850eeea1d23b577f8df1b7c','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('950dfcc008710a552d2a4f85735d9f3cfe298f787f95333fb47ac8f662a41eb7',2002,'LC','Saint Lucia','military-and-security',137,'Military branches: Royal Barbados Defense Force
(including Ground Forces and Coast Guard), Royal
Barbados Police Force
Military manpower - availability:
males age 1549: 78,132 (2002 est.)
Military manpower - fit for military service:
males age 15-49; 53,532 (2002 est,)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','ce076f2526a0d6dd4d60a7384ac32d6e9376f2da45aad88f2b8d87a72b93df81','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e3f32f84684a214227e847a461f67b4f869992b3e92875a71be0eb6141062768',2002,'MZ','Mozambique','military-and-security',146,'Military - note: defense is the responsibility of
Military branches: Comoran Security Force
Military manpower - availability:
males age 15-49: 145,509 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 86,455 (2002 est.)
Military expenditures - dollar figure: $6 million
(FY01)
117
ComorOS (continued)
Military expenditures - percent of GDP: 3%
(FY01)
Military - note: defense is the responsibility of
Military - note: defense is the responsibility of
Military branches: Zimbabwe National Army, Air
Force of Zimbabwe, Zimbabwe Republic Police
(includes Police Support Unit, Paramilitary Police)
Military manpower - availability:
males age 15-49: 3,057,381 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1,898,383 (2002 est.)
Military expenditures - dollar figure: $350.6
million (FY01)
Military expenditures - percent of GDP: 3.8%
(FY01)
Military branches: Army, Navy (including Marine
Corps), Air Force, Coast Guard Administration, Armed
Forces Reserve Command, Combined Service
Forces Command
Military manpower - military age: 19 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 6,575,625 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 5,018,882 (2002 est.)
Military manpower - reaching military age
annually:
males: 198,766 (2002 est.)
Military expenditures - dollar figure:
$8,041,200,000 (FY01)
Military expenditures - percent of GDP: 2.8%
(FY01)','81b9f0fb144b236cb0d1ec9e1c76c61de3354a244239093fee2f1467d05c8680','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0850d7a27894454ecf1c1d62105d0478a3bd2444b533bbfa9adc928f55182205',2002,'FR','France','military-and-security',158,'Military branches: Army, Air Force (including air
defense), Interior Ministry Troops, Border Guards
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 2,744,267 (2002 est.)
Military manpower - fit for military service:
mates age 15-49: 2,149,873 (2002 est.)
Military manpower - reaching military age
annually:
males: 86,396 (2002 est.)
Military expenditures - dot lar figure: $1 56 million
(FY98)
Military expenditures - percent of GDP: 1%
(FY01)
Military branches: Army, Navy, Air Components,
National Gendarmerie
Military manpower - military age: 1 9 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 2,508,557 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 2,070,016 (2002 est.)
Military manpower - reaching military age
annually:
males: 63,247 (2002 est.)
Military expenditures - dollar figure:
$3,076,500,000 (FY01/02)
Military expenditures - percent of GDP: 1 .4%
(FY01/02)
Military branches: Belize Defense Force (includes
Army, Maritime Wing, Air Wing, and Volunteer Guard)
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 64,909 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 38,472 (2002 est.)
Military manpower - reaching military age
annually:
males: 2,847 (2002 est.)
Military expenditures - dollar figure: $7.7 million
(FYOO/01)
Military expenditures - percent of GDP: 1 .87%
(FY00/01)
Military - note: defense is the responsibility of
Australia; the territory does have a five-person police
force
Military branches: Army, Navy, Air Force,
paramilitary Gendarmerie, Republican Guard
(includes Presidential Guard)
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 1549: 3,963,166 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 2,071 ,01 1 (2002 est.)
Military manpower - reaching military age
annually:
males: 188,41 1 (2002 est.)
Military expenditures - dollar figure: $1277
million (FY01)
Military expenditures * percent of GDP: 1 .3%
(FY01)
Military branches: British Forces Falkland Islands
no regular indigenous military forces; (includes Army,
Royal Air Force, and Royal Navy), Police Force
Military expenditures - dollar figure: SNA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of the UK
Military branches: no regular indigenous military
forces; French Forces, Gendarmerie
Military manpower - availability:
males age 15-49: 50,504 (2002 est.)
Military manpower - fit for military service:
males age 75-49:32,720 (2002 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of
Military • note: defense is the responsibility of
Military branches: Army, Navy, Air Force,
Presidential (Republican) Guard (charged with
protecting the president and other senior officials),
National Gendarmerie, National Police
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 284,358 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 146,908 (2002 est.)
Military manpower - reaching military age
annually:
males: 11,304 (2002 est.)
Military expenditures - dollar figure: $70.8 million
(FY01)
Military expenditures - percent of GDP: 2%
(FY01)
Military branches: no regular indigenous military
forces; French Forces, Gendarmerie
Military ■ note: defense is the responsibility of
Military branches: no regular indigenous military
forces; French Forces (Army, Navy, Air Force),
Gendarmerie
. Military - note; defense is the responsibility of
Military branches: Mongolian Armed Forces
(includes General Purpose Forces, Air and Air
Defense Forces, Civil Defense Troops); note - Border
Troops are under Ministry of Justice and Home Affairs
in peacetime
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 75-49. 772,619 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 501 ,493 (2002 est.)
Military manpower - reaching military age
annually:
mates: 30,230 (2002 est.)
Military expenditures - dollar figure: $24.3 million
(FY01)
Military expenditures - percent of GDP: 2.5%
(FY01)
Military branches: no regular indigenous military
forces; Police Force
Military • note: defense is the responsibility of the
UK
Military branches: no regular indigenous military
forces; French forces (including Army, Navy, Air
Force, and Gendarmerie)
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 194,485 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 99,251 (2002 est.)
Military manpower - reaching military age
annually:
males: 6,243 (2002 est.)
Military - note: defense is the responsibility of
Military branches: Army, Royal Navy (including
Royal Marines), Royal Air Force
Military manpower - availability:
males age 15-49: 14,632,418 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 12,151 ,734 (2002 est.)
Military expenditures - dollar figure: $31 .7 billion
(2002)
Military expenditures - percent of GDP: 2.32%
(2002)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','a19a9796fc404801910b91dd36b0787816645f8a2025d39dc4607d51d7444c46','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('38105f39f88d6ea8729426c886a0ebb4fbffd2632a017981fa773d3790c3a3d0',2002,'TG','Togo','military-and-security',168,'Military branches: Armed Forces (including Army,
Navy, Air Force), National Gendarmerie
Military manpower • military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1,509,760
females age 1 5-49: 1,536,036
note: both sexes are liable for military service
(2002 est.)
Military manpower - fit for military service:
males age 15-49: 771 ,373
females age 15-49: 778,730 (2002 est.)
Military manpower - reaching military age
annually:
males: 71 ,278
females: 70,088 (2002 est.)
Military expenditures - dollar figure: $27 million
(FY96)
Military expenditures - percent of GDP: 1 .2%
(FY96)','5e3d0c7e7f7cc73e8e6c461948b5ba3da16b26d0ddba2c06737f64e713b13fa1','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b085d1fa1020f3ae8553e9c241905b3a15724bb28bed72b3bc5ba4388d81f8b1',2002,'BM','Bermuda','military-and-security',177,'Military branches: no regular indigenous military
forces; Bermuda Regiment, Bermuda Police Force,
Bermuda Reserve Constabulary
Military expenditures - dollar figure: $4,027,970
(January 2002)
Military expenditures - percent of GDP: 0.1 1 %
(FY00/01)
Military - note: defense is the responsibility of the
UK','e33613c99b34c251c3e1ca8abda83affae13f66c42ba0e6541734e223ed570e7','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae0ac29707c01ec44f5812717b09955f4ad3b862a191302bfe765d902492f3c3',2002,'CN','China','military-and-security',187,'Military branches: Royal Bhutan Army, Royal
Bodyguard, National Militia, Royal Bhutan Police,
Forest Guards
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 517,470 (2002 est,)
Military manpower - fit for military service:
males age 15-49: 276,303 (2002 est.)
Military manpower - reaching military age
annually:
mates; 21, 167 (2002 est.)
Military expenditures - dollar figure: $9.3 million
(FY01)
Military expenditures - percent of GDP: 1 .9%
(FY01)
Military branches: People''s Liberation Army (PLA):
comprises ground forces, Navy (including naval
infantry and naval aviation), Air Force, and II Artillery
Corps (strategic missile force), People''s Armed Police
Force (internal security troops, nominally a state
security body but included by the Chinese as part of
the "armed forces" and considered to be an adjunct to
the PLA), militia
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 370,087,489 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 203,003,036 (2002 est.)
Military manpower - reaching military age
annually:
males: 10,089,458 (2002 est.)
Military expenditures -dollar figure: $20,048
billion (2002); note - this is the officially announced
figure, but actual defense spending more likely ranges
from $45 billion to $65 billion for 2002
Military expenditures - percent of GDP: 1 .6%
(2002); note - this is the officially announced figure,
but actual defense spending is more likely between
3.5% to 5.0% of GDP for 2002
Military branches: no regular indigenous military
forces; Hong Kong garrison of China''s People''s
Liberation Army (PLA) including elements of the PLA
Ground Forces, PLA Navy, and PLA Air Force; these
forces are under the direct leadership of the Central
Military Commission in Beijing and under
administrative control of the adjacent Guangzhou
Military Region
Military manpower * military age: 18 years of age
(2002 est:)
Military manpower - availability:
males age 15-49: 2,028,208 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,523,378 (2002 est.)
Military manpower - reaching military age
annually:
mates: 47,139 (2002 est.)
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of China
Howland Island
(territory of the US)
Military - note: defense is the responsibility of the
US; visited annually by the US Coast Guard
Military branches: Ground Forces, Air Forces
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 2,559,260 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 2,039,710 (2002 est.)
Military manpower - reaching military age
annually:
males: 64,121 (2002 est.)
Military expenditures - dollar figure: $1 .08 billion
(2002 est.)
Military expenditures - percent of GDP: 1 .75%
(2002 est.)
Military branches: Jordanian Armed Forces (JAF)
Royal Jordanian Land Force, Royal Naval Force,
Royal Jordanian Air Force, and Special Operations
Command or Socom); note • Public Security
Directorate normally falls under Ministry of Interior but
comes under JAF in wartime or crisis situations
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 ,51 7,751 (2002 est.)
Military manpower - fit tor military service:
males age 15-49: 1 ,073,991 (2002 est.)
Military manpower - reaching military age 1
annually:
males: 57,131 (2002 est.)
Military expenditures - dollar figure: $757.5
million (FY01)
Military expenditures - percent of GDP: 8.6%
(FY01)
Military branches: Army, Air and Air Defense,
Security Forces, Border Troops
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 1549: 1 ,234,457 (2002 est.)
Military manpower - fit for military service:
males age 1549: 1 ,001 ,274 (2002 est.)
Military manpower - reaching military age
annually:
males: 50,590 (2002 est.)
Military expenditures ■ dollar figure: $19.2 million
(FY01)
Military expenditures - percent of GDP: 1 .4%
(FY01)
Military branches: no regular indigenous military
forces; responsibility for defense reverted to China on
20 December 1999; there is a local police force
Military manpower - availability:
males age 15-49: 128,005 (2002 est.)
Military manpower - fit for military service:
males age 1 5-49: 70,508 (2002 est.)
Military - note: responsibility for defense reverted to
China on 20 December 1999
Military branches: Army (ARM), Air and Air Defense
Forces, Police Force
Military manpower - military age: 1 9 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 551,523 (2002 est.)
Military manpower • fit for military service:
males age 15-49: 444,575 (2002 est.)
Military manpower - reaching military age
annually:
males: 17,905 (2002 est.)
Military expenditures -dollar figure: $200 million
(FY01/02est.)
Military expenditures • percent of GDP: 6%
(FY01/02 est.)
Military » note: Spratly Islands consist of more than
100 small islands or reefs, of which about 45 are
claimed and occupied by China, Malaysia, the
Philippines, Taiwan, and Vietnam','98254dc3ea8b171cfe7343ea95dc2e6847878aac1966b227633c849799796da2','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('946952ff3c32270c72c42f1d7f6b849a0b1a850e9eb510bb5c05795cbe77b009',2002,'PY','Paraguay','military-and-security',198,'Military branches: Army (Ejercito Boliviano), Navy
(Fuerza Naval, includes Marines), Air Force (Fuerza
Aerea Boliviana), National Police Force (Policia
Nacional de Bolivia)
Military manpower - military age: 1 9 years of age
(2002 est.)
Military manpower - availability:
males age 75-49:2,062.321 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,343,755 (2002 est.)
Military manpower - reaching military age
annually:
males: 90. 120 (2002 est.)
Military expenditures - dollar figure: $147 million
(FY99)
Military expenditures - percent of GDP: 1 .8%
(FY99)','ed04638058a50e9493550cfa633565910bb9ba63be616fe3f86aeb5fae8b6030','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('32e22954225c962cc0a8e5c4935092fa5fb16418e54adc5a0ed043319ac3c318',2002,'IT','Italy','military-and-security',209,'Military branches: VF Army (the air and air defense
forces are subordinate commands within the Army),
VRS Army (the air and air defense forces are
subordinate commands within the Army)
Military manpower - military age: 1 9 years of age
(2002 est.)
Military manpower - availability:
males age 1549: 1 ,131 ,537 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 898,1 17 (2002 est.)
Military manpower - reaching military age
annually:
males: 29,757 (2002 est.)
Military expenditures - dollar figure: $NA
Military expenditures ■ percent of GDP: NA%
Military branches: Botswana Defense Force
(including Army and Air Wing), Botswana National
Police
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 384,888 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 202,685 (2002 est.)
Military manpower - reaching military age
annually:
males: 19,479 (2002 est.)
Military expenditures - dollar figure: $135 million
(FY01/02)
Military expenditures - percent of GDP: 3.5%
(FY01/02)
Military branches: Swiss Guards Corps (Corpo
della Guardia Svizzera)
Military - note: defense is the responsibility of Italy;
Swiss Papal Guards are posted at entrances to the
Vatican City to provide security and protect the Pope
Military branches: Army, Navy (including marines),
Air Force
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 ,563,174 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 930,718 (2002 est.)
Military manpower - reaching military age
annually:
males: 72,335 (2002 est.)
Military expenditures - dollar figure: $35 million
(FY99)
Military expenditures - percent of GDP: 0.6%
(FY99)
231
Honduras (continued)
Military branches: Voluntary Military Force (Corpi
Militari Voluntar), Gendarmerie; note - the Voluntary
Military Force performs ceremonial duties and limited
police assistance
Military expenditures -dollar figure: $700,000
(FYOO/01)
Military expenditures - percent of GDP: NA%
Military branches: Army, Air Force, Frontier
Guards, Fortification Guards
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 ,841 ,867 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,561 ,689 (2002 est.)
Military manpower - reaching military age
annually:
males: 42,597 (2002 est.)
Military expenditures - dollar figure: $2,548 billion
(FY01)
Military expenditures - percent of GDP: 1%
(FY01)
Military branches: Syrian Arab Army, Syrian Arab
Navy, Syrian Arab Air Force (includes Air Defense
Forces), Police and Security Force
Military manpower - military age: 19 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 4,550,496 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 2,539,342 (2002 est.)
Military manpower - reaching military age
annually:
males: 200,859 (2002 est)
Military expenditures -dollar figure: $921 million
(FY00 est); note - based on official budget data that
may understate actual spending
Military expenditures - percent of GDP: 5.9%
(FY98)','9861e9906296b4e2c6a8183bfcac38b5006e34827404e05d90030c8e19bcf23f','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0cb51bdcd5ab61d59ea26296da8347973f4d75cf4d4177654cd94cf43459ae13',2002,'CO','Colombia','military-and-security',229,'Military branches: Brazilian Army, Brazilian Navy
(includes naval air and marines), Brazilian Air Force,
Federal Police (paramilitary)
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 48,859,610 (2002 est.)
Military manpower - fit for military service:
males age 15*49: 32,743,504 (2002 est.)
Military manpower - reaching military age
annually:
males: t ,762,740 (2002 est.)
Military expenditures - dollar figure: $13,408
billion (FY99)
Military expenditures - percent of GDP; 1 .9%
(FV99)
Military branches: Army (Ejercito Nacional), Navy
(Armada Nacional, including Marines and Coast
Guard), Air Force (Fuerza Aerea Colombiana),
National Police (Policia Nacional)
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 0,946,932 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 7,308,703 (2002 est.)
Military manpower - reaching military age
annually:
males: 379,295 (2002 est.)
Military expenditures - dollar figure: $3.3 billion
(FY01)
Military expenditures - percent of GDP: 3.4%
(FY01)
Military branches: an amendment to the
Constitution abolished the armed forces, but there are
security forces (Panamanian Public Forces or PPF
includes the Panamanian National Police, National
Maritime Service, and National Air Service)
Military manpower - availability:
males age 15-49:789,973 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 540,052 (2002 est.)
Military expenditures - dollar figure: $128 million
(FY99)
Military expenditures - percent of GDP: 1 .3%
(FY99)
Military - note: on 10 February 1990, the
government of then President ENDARA abolished
Panama''s military and reformed the security
apparatus by creating the Panamanian Public Forces;
in October 1994, Panama''s Legislative Assembly
approved a constitutional amendment prohibiting the
creation of a standing military force, but allowing the
temporary establishment of special police units to
counter acts of "external aggression"','3c0a3e86b9ecf4a8fe342496ce7456018b7a8745ce35549559027f5492c36c03','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ee9b1ec303c82983c993509cc9f1c2b3902afba4b391eb8892cb170b70024794',2002,'IO','British Indian Ocean Territory','military-and-security',238,'Military • note: defense is the responsibility of the
UK; the US lease on Diego Garcia expires in 2016
Military - note: defense is the responsibility of the
UK','39ef36f9c2c5f5464b78652b85dfcfcf999ebae3259da4b4a340594fc7c39cf5','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b012cc2509b3116e3d4de08fee6a1fcea487ee42b4199177545300fe5d924852',2002,'MY','Malaysia','military-and-security',251,'Military branches: Land Forces, Navy, Air Force,
Royal Brunei Police
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 108,921 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 62,864 (2002 est.)
Military manpower - reaching military age
annually:
males: 3,005 (2002 est.)
Military expenditures - dollar figure: $343 million
(FY98)
Military expenditures - percent of GDP: 5.1%
(FY98)
77
Brunei (continued)''','f020d00238109bdefb142ae14207ba7e97e03d6828a39197bbbc640ff61d2129','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6e0b7b71ba08e014051275c4aa8131f8efcc44e146b890fa8236912a688a063a',2002,'BG','Bulgaria','military-and-security',260,'Military branches: Army, Navy, Air and Air Defense
Forces (subordinate to Ministry of Defense), Internal
Forces (subordinate to Ministry of Interior), Civil
Defense Forces (subordinate to the president)
Military manpower - military age: 19 years of age
(2002 est.)
Military manpower • availability:
males age 15-49: 1 ,873,052 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,566,81 6 (2002 est.)
Military manpower - reaching military age
annually:
males: 56,1 04 (2002 est.)
Military expenditures - dollar figure: $356 million
(FY02)
Military expenditures - percent of GDP: 2.7%
(FY02)','bfbbbc9ac808b057d3a349bc14be683b34d0165a3fad0d933b73ed5b64e53c4c','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7325c3026034dcb0418669b2d9d9346a6eda41332069eda4ec5d3721c070a09',2002,'ET','Ethiopia','military-and-security',264,'Military branches: Army, Air Force, National
Gendarmerie, National Police, People''s Militia
Military manpower - availability:
males age 15-49: 2,688,072 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1,379,010 (2002 est.)
Military expenditures -dollar figure: $40.1 million
(FY01)
Military expenditures - percent of GDP: 1 .4%
(FY01)
Military branches: People''s Revolutionary Armed
Force (FARP; includes Army, Navy, and Air Force),
paramilitary force
Military manpower - availability:
males age 15-49: 313,573 (2002 est.)
Military manpower - fit for military service:
males age 1549: 178,404 (2002 est.)
Military expenditures - dollar figure: $5.6 million
(FY01)
Military expenditures - percent of GDP: 2.8%
(FY01)
Military branches: Army, Navy, Security Police
Military manpower - availability:
males age 15-49: 35,524 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 18,727 (2002 est.)
Military expenditures - dollar figure: $400,000
(FY01)
Military expenditures - percent of GDP: 0.8%
(FY01)
Military branches: Land Force (Army), Navy, Air
Force, Air Defense Force, National Guard, Ministry of
Interior Forces (paramilitary)
Military manpower * military age: 17 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 6,007,635 (2002 est,)
Military manpower - fit for military service:
males age 15-49: 3,359,849 (2002 est.)
Military manpower - reaching military age
annually:
males: 233,402 (2002 est.)
Military expenditures - dollar figure: $1 8.3 billion
(FY00)
Military expenditures - percent of GDP: 1 3%
(FY0O)','b9a532dfd79291dbc5f574258f0d808f209f39cf3f4508177c77a890d900da79','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('80175e04bb536cdb8455e93e1da2bdaabb8d3a7f0f0860a2d8dfd76372af4c1b',2002,'TH','Thailand','military-and-security',273,'Military branches: Army, Navy, Air Force
Military manpower - military age: 18 years of age
(2002 est)
Military manpower - availability:
males a$re /5*40; 12,211 ,144
females age 1549: 12,223,069
note: both sexes liable for military service (2002 est)
Military manpower - fit for military service:
males age 15-49: 6,502,01 3
females age 15-49: 6,491 ,732 (2002 est)
Military manpower - reaching military age
annually:
males: 486,432
fema/es: 470,667 (2002 est)
Military expenditures - dollar figure: $39 million
(FY97/98)
Military expenditures - percent of GDP: 2.1%
(FY97/98)
Military branches: Army (including naval and air
units), Gendarmerie
Military manpower - military age: 16 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 ,439,032 (2002 est.)
Military manpower - fit for military service:
mates age 15-49: 752.584 (2002 est.)
Military manpower - reaching military age
annually:
mates: 79,360 (2002 est.)
Military expenditures - dollar figure: $36.9 million
(FY01)
Military expenditures - percent of GDP: 5.3%
(FY01)
Military branches: Lao People''s Army (LPA;
including Riverine Force), Air Force, National Police
Department
Military manpower - military age: 18 years of age
(2002 est)
Military manpower - availability:
males age 15-49: 1 ,365,027 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 734,945 (2002 est.)
Military manpower ■ reaching military age
annually:
males: 64,437 (2002 est)
Military expenditures - dollar figure: $55 million
(FY98)
Military expenditures - percent of GDP: 4.2%
(FY96/97)','b7e52f2e30f9663dbc55d87860ebc06ba0a263ac8ee2c35d72bbea5ead747a39','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('700f6d3ee89bed441c24e2bdd895d32a993d6cb18a2f418764e7ba0417a43eaf',2002,'UG','Uganda','military-and-security',287,'Military branches: Royal Cambodian Armed Forces
(RCAF): Army, Navy, Air Force
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 2,990,790 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1,673,713 (2002 est.)
Military manpower - reaching military age
annually:
males: 162,643 (2002 est.)
Military expenditures - dollar figure: $112 million
(FY01 est.)
Military expenditures - percent of GDP: 3%
(FY01 est.)
Military - note: defense is the responsibility of the
UK','1523a745fbb3f2ff1412fad376d88d656079f0439791f0aa4d8b8312439d3600','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c78abb0fef644663108ff17cf46c3c618b77b96f67ce119a494691ad9c9a0004',2002,'CA','Canada','military-and-security',289,'Military branches: Army, Navy (includes naval
infantry), Air Force, National Gendarmerie,
Presidential Guard
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 3,872,965 (2002 est.)
Military manpower - fit for military service:
males age 1549: 1 ,959,357 (2002 est.)
Military manpower - reaching military age
annually:
males: 174,308 (2002 est.)
Military expenditures - dollar figure: $1 1 8.6
million (FYO0/01)
Military expenditures - percent of GDP: 1 .4%
(FY98/99)
Military branches: Canadian Armed Forces
(comprising Land Forces Command, Maritime
Command, Air Command, Communications
Command, Training Command)
Military manpower - military age: 17 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 8,361 ,475 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 7,139,068 (2002 est.)
Military manpower - reaching military age
annually:
males: 217,516 (2002 est.)
Military expenditures - dollar figure:
$7,860,500,000 (FY01/02)
Military expenditures - percent of GDP: 1.1%
(FY01/02)','5743e576f51b42c95b0e458e59e74d5b1d624160bf1bef75a46a8205aa244cff','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('94bb4529f81d087d28ca4610b3e02c476b5232869bbde0d9e6fe5c2a980cd992',2002,'PT','Portugal','military-and-security',301,'Military branches: Army, Coast Guard
Military manpower - availability:
males age 15-49: 92,486 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 52,215 (2002 est.)
Military expenditures - dollar figure: $9.3 million
(FY01)
Military expenditures - percent of GDP: 1 .6%
(FY01)
Military branches: Army, Navy (PON) (includes
Marines), Air Force, Republican Guard (includes
Fiscal Guard)
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 2,525,848 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 2,024,526 (2002 est.)
Military manpower - reaching military age
annually:
males: 71 ,404 {2002 est.)
Military expenditures * dollar figure: $1 .286 billion
(FY99/00)
Military expenditures ■ percent of GDP: 2.2%
(FY99/00)','39918ede5c92eeab4eef417e3ef15f8bad2b24dfb722dd7693da1d893531ee90','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('22c9855483245f83506e2f681ef0fdd215dd152629c63d0127f048437c91c73d',2002,'HN','Honduras','military-and-security',314,'Military branches: Central African Armed Forces
(FACA) (including Republican Guard, Ground Forces,
Naval Forces, and Air Force), Presidential Security
Guard, Gendarmerie, National Police
Military manpower - availability:
males age 1549: 845,182 (2002 est.)
Military manpower - fit for military service:
males age 15-49:442,220 (2002 est.)
Military expenditures - dollar figure: $29 million
(FY96)
Military expenditures - percent of GDP: 2.2%
(FY96)
Military branches: Armed Forces (including
National Army, Air Force, and Gendarmerie), Rapid
intervention Force, National and Nomadic Guard
(GNNT), Presidential Security Guard, Police
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower - availability:
mates age 15-49: 1 ,881 ,769 (2002 est.)
Military manpower • fit for military service:
males age 15-49: 985,094 (2002 est.)
Military manpower • reaching military age
annually:
mates: 82,003 (2002 est.)
Military expenditures -dollar figure: $31 million
(FY01)
Military expenditures • percent of GDP: 1 .9%
(FY01)
Military branches: Army, Navy (FNES), Air Force
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 ,500,712 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 951 ,715 (2002 est.)
Military manpower - reaching military age
annually:
males: 68,103 (2002 est.)
Military expenditures - dollar figure: $1 1 2 million
(FY99)
Military expenditures - percent of GDP: 0.7%
(FY99)','40b3d2db059a01b1d7f384a15143a367a317c7ce368749a5b34e5be4b474c2fd','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ae1c1c88862542157939a139af80811658a0be1c6cef53e9ba68f497e1344e96',2002,'PE','Peru','military-and-security',323,'Military branches: Army of the Nation, National
Navy (including naval air, coast guard, and marines),
Air Force of the Nation, Chilean Carabineros (National
Police), Investigations Police
Military manpower • military age: 19 years of age
(2002 est.)
Military manpower • availability:
males age 15-49: 4,104,197 (2002 est.)
Military manpower - fit for military service:
ma/es age 15-49: 3,034,912 (2002 est.)
Military manpower - reaching military age
annually:
males: 136,830(2002 est.)
Military expenditures * dollar figure: $2.5 billion
(FY99)
Military expenditures - percent of GDP: 3.1%
(FY99)
Military branches: Army, Navy (including Marines),
Air Force, National Police
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 3,468,678 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 2,337,944 (2002 est.)
Military manpower - reaching military age
annually:
males: 132,978 (2002 est.)
Military expenditures - dollar figure: $720 million
(FY98)
Military expenditures - percent of GDP: 3.4%
(FY98)','52f2848a82d09abc97ca73ec56845b90ad8757b56c3910117740637b01aa859c','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('89d739a203d48af1d903ae8701a2aefcf621bf0339b995144f63eafd1999cca2',2002,'CG','Congo','military-and-security',337,'Military branches: Army, Navy, Air Force, Special
Security Battalion
Military manpower - availability:
males age 15-49: 1 1 ,996,1 75 (2002 est.)
Military manpower - tit for military service:
mates age 15-49: 6,1 10,595 (2002 est.)
Military expenditures - dollar figure: $250 million
(FY97)
Military expenditures • percent of GDP: 4.6%
(FY97)
Military branches: Army, Air Force, Navy,
Gendarmerie, National Police
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 702,048 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 356,388 (2002 est.)
Military manpower - reaching military age
annually:
males: 32,350 (2002 est.)
Military expenditures - dollar figure: $84 million
(FY01)
Military expenditures - percent of GDP: 2.8%
(FY01)','46d4d101f318acc54099fe4da74d9f43f89b51c0a5d2dbf130d1d4b43a487eb8','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1fd076cd15fdf4c4e0e8d8ab3b180818f73b7af27a81b35acf78b09164d566ca',2002,'CK','Cook Islands','military-and-security',350,'Military - note: defense is the responsibility of New
Zealand, in consultation with the Cook Islands and at
its request
Military - note: defense is the responsibility of
Australia; visited regularly by the Royal Australian
Navy; Australia has control over the activities of
visitors','1d4928eae29e1439992c31274db099d464c78370e89d859b5caf4260f29b8573','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d77892e5346d42af5e83493cecefea77189b48bed5b65dfb75f348352a014f87',2002,'CR','Costa Rica','military-and-security',359,'Military branches: no regular indigenous military
forces; Air Section, Ministry of Public Forces (Fuerza
Publica)
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 ,058,283 (2002 est.)
Military manpower - fit for military service:
males age 1549: 707,927 (2002 est.)
Military manpower - reaching military age
annually:
males: 39,41 1 (2002 est.)
Military expenditures - dollar figure: $69 million
(FY99)
Military expenditures - percent of GOP: 1 ,6%
(FY99)','4745348af9637a75b18b140e8dce50bcb9f6d1f36ab33b88b749db783c9eafc7','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ef7a62c86c50ae33722d1c1c62b7c153f8aa551a6c065e9a85fd6527946cc636',2002,'SI','Slovenia','military-and-security',371,'Military branches: Ground Forces (Hrvatska
Vojska, HV), Naval Forces, Air and Air Defense
Forces
Military manpower - military age: 1 9 years of age
(2002 est.)
Military manpower - availability:
males age 75-49; 1 ,086,578 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 860,497 (2002 est.)
Military manpower - reaching military age
annually:
males: 30,037 (2002 est.)
Military expenditures - dollar figure: $520 million
(2002 est.)
Military expenditures - percent of GDP: 2.39%
(2002 est.)','26abf5f6642666656683ffb6fe312dc9d60c738880fe6361e2c19a700b2f8d81','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ed064e3eff5e0627554bdeaf97bc0f87a4d271ed94a7db40a45e105a3840464e',2002,'CU','Cuba','military-and-security',381,'Military branches: Revolutionary Armed Forces
(FAR) including Ground Forces, Revolutionary Navy
(MGR), Air and Air Defense Force (DAAFAR),
Territorial Militia Troops (MTT), and Youth Labor Army
(EJT); note * the Border Guard Troops (TGF) are
controlled by the Interior Ministry
Military manpower - military age: 17 years of age
(2002 est.)
Military manpower • availability:
males age 15-49: 3,102,312
females age 15-49: 3,036,549 (2002 est.)
Military manpower - fit for military service:
males age 75-49: 1,915,586
females age 1549: 1 ,869,867 (2002 est.)
Military manpower - reaching military age
annually:
males: 86,632
females: 79,562 (2002 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: roughly
4% (FY95 est.)
Military • note: Moscow, for decades the key military
supporter and supplier of Cuba, cut off almost all
military aid by 1993
Military branches:
Greek area: Greek Cypriot National Guard (GCNG;
including air and naval elements), Greek Cypriot
Police
Turkish area: Turkish Cypriot Security Force (GKK)
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 1549: 200,071 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 137,322 (2002 est.)
Military manpower - reaching military age
annually:
males: 6,61 6 (2002 est.)
Military expenditures - dollar figure: $370 million
(FY00)
Military expenditures - percent of GDP: 4.2%
(FY00)
Military branches: Army, Air and Air Defense
Forces. Territorial Defense Force
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower * availability:
males age 15-49: 2,637,128 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 2,012,779 (2002 est.)
Military manpower - reaching military age
annually:
males: 69,393 (2002 est.)
Military expenditures - dollar figure:
$1,190,200,000 (FY01)
Military expenditures ■ percent of GDP: 2.1 %
(FY01)','1100d0f039b446354713da017f83ad049847f9df345670270d843b264c693456','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2960427fbb02b9a4a4c0b01bc81b2840cc56950720266df07d565587cdea4caa',2002,'SE','Sweden','military-and-security',391,'Military branches: Royal Danish Army, Royal
Danish Navy, Royal Danish Air Force, Home Guard
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower • availability:
males age 15-49: 1 ,287,168 (2002 est.)
Military manpower - fit for military service:
males age 1549: 1,099,900 (2002 est.)
Military manpower - reaching military age
annually:
mates: 29,21 2 (2002 est,)
Military expenditures - dollar figure: $2.47 billion
(FY99/00)
Military expenditures - percent of GDP: 1 .4%
(FY99/00)
Disputes • international: Rockall continental shelf
dispute involving Denmark, Iceland, and the UK
(Ireland and the UK have signed a boundary
agreement in the Rockall area); dispute with Iceland
overthe Faroe Islands'' fisheries median line boundary
within 200 NM; disputes with Iceland, the UK, and
Ireland over the Faroe Islands continental shelf
boundary outside 200 NM; Faroese are considering
proposals for full independence
144
Military branches: Army, Royal Navy (including
Coast Artillery and Naval Helicopter Service), Air
Force
Military manpower ■ military age: 19 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 2,060,205 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,800,991 (2002 est.)
Military manpower - reaching military age
annually:
males: 51 ,506 (2002 est.)
Military expenditures - dollar figure:
$4,395,100,000 (FY01)
Military expenditures - percent of GDP: 2.1%
(FY01)
494','6ea26122d57e53e581c291d3055eb6a7d9f3df844e899bdc11c1b2852bdd034a','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29ac919dfe6edb9b674a322caec2d28a3ae41e93366f2726284c593ef85d7dea',2002,'DJ','Djibouti','military-and-security',399,'Military branches: Djibouti National Army (including
Navy and Air Force)
Military manpower - availability:
males age 15-49:110,221 (2002 est.)
Military manpower • fit for military service:
males age 15-49: 64,940 (2002 est.)
Military expenditures * dollar figure: $26.5 million
(FY01)
Military expenditures • percent of GDP: 4.4%
(FY01)
Military branches: Commonwealth of Dominica
Police Force (including Special Service Unit, Coast
Guard)
Military expenditures - dollar figure: SNA
Military expenditures - percent of GDP: NA%','7b37304bfcd988d9dd18c56ac7888d6442ae675698f4d7a06ebc8f7db4886e43','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('45d8a474fdaa1308d17ebd97d381d5c493abcb8c602d602db0bb266bd16ae684',2002,'DO','Dominican Republic','military-and-security',409,'Military branches: Army, Navy, Air Force, National
Police
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 2,323,088 (2002 est.)
150
Dominican Republic (continued)
Military manpower - fit for military service:
males age 15-49: 1 ,455,887 (2002 est.)
Military manpower - reaching military age
annually:
males: 87,404 (2002 est.)
Military expenditures - dollar figure: $1 80 million
(FY98)
Military expenditures - percent of GDP: 1.1%
(FY98)
Military branches: no regular indigenous military
forces; paramilitary National Guard, Police Force
Military - note: defense is the responsibility of the
US','9c9cdd1bdab90f31c9d65bedf72925e629a26197ef4f02b6d05676fe3ee2f248','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('722ae5737be84c7aacb2028786065ef7ba168098991428d70fa259c5dc6940f1',2002,'ID','Indonesia','military-and-security',416,'Military branches: the East Timor Defense Force or
FALINTIL-FDTL comprises a light-infantry Army and a
small Naval component; note - plans are to develop a
force of 1 ,500 active personnel and 1 ,500 reserve
personnel over the next five years
Military manpower - military age: 18-21 years of
age
Military manpower -availability: NA
Military manpower - fit for military service: NA
Military manpower - reaching military age
annually: NA
Military expenditures • dollar figure: $4.4 million
(FV03)
Military expenditures - percent of GDP: NA%
Military branches: Army, Navy (including marines
and naval air arm), Air Force
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 1549: 65,013,184 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 37,942,329 (2002 est.)
Military manpower - reaching military age
annually:
males: 2,263,706 (2002 est.)
Military expenditures -dollar figure: $1 billion
(FY98/99)
Military expenditures - percent of GDP: 1 .3%
(FY98/99)
Military branches: Islamic Republic of Iran regular
forces (includes Ground Forces, Navy, Air Force and
Air Defense Command), Iranian Revolutionary
Guards Corps (IRGC) (includes Ground Forces, Air
Force, Navy, Qods [special operations], and Basij
[Popular Mobilization Army] forces), Law Enforcement
Forces
Military manpower - military age: 21 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 18,868,571 (2002 est.)
Military manpower * fit for military service:
wales age 1549: 11,1 92,731 (2002 est.)
Military manpower * reaching military age
annually:
mates; 823,041 (2002 est.)
Military expenditures - dollar figure: $9.7 billion
(FY00)
Military expenditures - percent of GDP: 3.1%
(FY00)
Military branches: Army, Republican Guard, Navy,
Air Force, Air Defense Force, Border Guard Force,
Fedayeen Saddam
Military manpower - military age: 18 years of age
(2002 est)
Military manpower * availability:
mates age 15-49: 6,135,847 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 3,430,819 (2002 est.)
Military manpower - reaching military age
annually:
mates: 274,035 (2002 est.)
Military expenditures - dollar figure: $1 .3 billion
(FY00)
Military expenditures - percent of GDP: NA%
Military branches: Malaysian Army, Royal
Malaysian Navy, Royal Malaysian Air Force, Royaf
Malaysian Police Field Force, Marine Police, Sarawak
Border Scouts
Military manpower - military age: 21 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 5,933,296 (2002 est.)
321
Malaysia (continued)
Military manpower - fit for military service:
males age 1549: 3,592,997 (2002 est.)
Military manpower - reaching military age
annually:
males: 196,042 (2002 est.)
Military expenditures • dollar figure: $1 .69 billion
(FYOOest.)
Military expenditures • percent of GDP: 2.03%
(FYO0)
Military branches: Papua New Guinea Defense
Force (includes Ground Force, Maritime Operations
Element, and Air Operations Element)
Military manpower * availability:
males age 15-49: 1,338,003 (2002 est.)
Military manpower - fit lor military service:
males age 15-49: 740,085 (2002 est.)
Military expenditures * dollar figure: $42 million
(FY98)
Military expenditures - percent of GDP: 1%
(FY9B)
Military branches: Army, Navy, Air Force, People''s
Defense Force, Police Force
Military manpower - availability:
males age 15-49: 1,354,857 (2002 est.)
Military manpower • fit for military service:
males age 15-49: 986,101 (2002 est.)
Military expenditures - dollar figure: $4.47 billion
(FY01/02 est.)
Military expenditures - percent of GDP: 4.9%
(FY01/02)
462
Singapore (continued)','db55beedc59c1fbd069c92e3d2502f6056e9bbbe27ee0eafa51b27d1d8bb9759','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('85e20ee1a8a10960f30870fb900d02acf515e994b85df98409efb41a8ab01d90',2002,'LY','Libya','military-and-security',426,'Military branches: Army, Navy, Air Force, Air
Defense Command
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 19,030,030 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 12,320,902 (2002 est.)
Military manpower - reaching military age
annually:
males: 712,983 (2002 est.)
Military expenditures * dollar figure: $4.04 billion
(FY99/00)
Military expenditures - percent of GDP: 4.1%
(FY99/00)','a86b376030e789c2444c2f1b7910da4c01959d1aea60c2137c3abe3385ede43e','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e8257ebf391504e78aae1740b80c5a8dbbdfa513d0ff65a3f2281cbedbd659c8',2002,'GN','Guinea','military-and-security',436,'Military branches: Army, Navy, Air Force, Rapid
Intervention Force, National Police
Military manpower - availability:
males age 15-49: 1 12,664 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 57,194 (2002 est.)
Military expenditures - dollar figure: $27.5 million
(FY01)
Military expenditures - percent of GDP: 2.5%
(FY01)
Military branches: Army, Navy, Air Force
Military expenditures • dollar figure: $1 38.3
million (FY01)
Military expenditures - percent of GDP: 19.8%
(FY01)
Military branches: Army, Navy, Air Force, Police
Force
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 30,808,598 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 17,698,91 1 (2002 est.) ■
Military manpower - reaching military age
annually:
males: 1,375,112 (2002 est.)
Military expenditures * dollar figure: $374.9
million (FY01)
Military expenditures - percent of GDP: 1%
(FY01)','89054f46ca9a01dbc1e3069d746281dc2ff4fb7c3a53546a372d835962f19550','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c46f47aa11cfca564b40e3543e7ed54078d8e1fbbb13abae9ebabb0f4cfc96b',2002,'EE','Estonia','military-and-security',448,'Military branches: Estonia Defense Forces
(including Ground Forces, Navy, Air Force), Republic
Security Forces (internal and border troops),
Volunteer Defense League (Kaitseliit), Maritime
Border Guard, Coast Guard
note; Border Guards and Ministry of Internal Affairs
become part of the Estonian Defense Forces in
wartime; the Coast Guard is subordinate to the
Ministry of Defense in peacetime and the Estonian
Navy in wartime
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 359,902 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 282,716 (2002 est.)
Military manpower - reaching military age
annually:
males: 11,164 (2002 est.)
Military expenditures - dollar figure: $155 million
(2002 est.)
Military expenditures - percent of GDP: 2%
(2002 est.)
Military branches: Ethiopian National Defense
Force (Ground Forces, Air Force, militia, police)
note: Ethiopia is landlocked and has no navy;
following the secession of Eritrea, Ethiopian naval
facilities remained in Eritrean possession
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 14,925,883 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 7,790,977 (2002 est.)
Military manpower - reaching military age
annually:
males: 703,625 (2002 est.)
Military expenditures - dollar figure: $800 million
(FY00)
Military expenditures - percent of GDP: 12.6%
(FY00)','8268fa8374d4d5b245a6057e6d413912bbb88c96f4b016fe099fb70650ef7a4f','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fb1a4aba81a10e01b65a2f458b251075de497fdc349c24123c20da502ac4f2e',2002,'FO','Faroe Islands','military-and-security',458,'Military branches: no regular indigenous military
forces; small Police Force and Coast Guard are
maintained
Military expenditures - dollar figure: $NA
Military expenditures ■ percent of GDP: NA%
Military - note: defense is the responsibility of','3602af29320a04ecb084035eb0b9e6d07461f5407a52613e19db6390acf137e7','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a53d91c3d82fb46e845b8006d58f4c5fb2e72064c37871d9d4da8694770eb887',2002,'JE','Jersey','military-and-security',469,'Military branches: Republic of Fiji Military Forces
(RFMF), includes ground forces, naval division
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 231,649 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 127,384 (2002 est.)
Military manpower • reaching military age
annually:
males: 9,471 (2002 est.)
Military expenditures - dollar figure: $35 million
(FY00)
Military expenditures - percent of GDP: 2.2%
(FY00)
Military branches: Army, Navy, Air Force, Frontier
Guard (including Sea Guard)
Military manpower - military age: 1 7 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1,240,762 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1,024,379 (2002 est.)
Military manpower - reaching military age
annually:
males: 33,883 (2002 est.)
Military expenditures - dollar figure: $1 .8 billion
(FY98/99)
Military expenditures - percent of GDP: 2%
(FY98/99)
Military branches: Israel Defense Forces (IDF)
(includes ground, naval, and air components with Air
Defense Forces), Pioneer Fighting Youth (Nahal),
Frontier Guard, Chen (women); note - historically
there have been no separate Israeli military services
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1,542,835
females age 15-49: 1,499,830 (2002 est.)
Military manpower - tit for military service:
males age 1549: 1,262,973
females age 15-49: 1 ,223,939 (2002 est.)
Military manpower - reaching military age
annually:
males: 51,666
females: 49,207 (2002 est.)
Military expenditures - dollar figure: $8,866 bilion
(FY01)
Military expenditures - percent of GDP: 8%
(FY01)
Military - note: defense is the responsibility of the
UK
Military branches: Army, Navy, Air Force (including
Air Defense Force), National Police Force, National
Guard, Coast Guard
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 812,059 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 486,906 (2002 est.)
Military manpower - reaching military age
annually:
males: 18,309 (2002 est.)
Military expenditures • dollar figure:
$1 ,967,300,000 (FY01)
note: Kuwait is changing its fiscal year; the above
figure is for July-March 2001; future budget years will
be April-March annually
Military expenditures - percent of GDP: 6.5%
(FY01)
Military branches: no regular indigenous military
forces; French Armed Forces (including Army, Navy,
Air Force, Gendarmerie); Police Force
Military expenditures - dollar figure: $1 92.3
million (FY96)
Military expenditures • percent of GDP: 5.3%
(FY96)
Military • note: defense is the responsibility of
Military branches: Slovenian Army (includes Air
and Naval Forces)
Military manpower - military age: 19 years of age
(2002 est.)
Military manpower - availability:
mates age 15-49: 521 ,881 (2002 est.) .
Military manpower - fit for military service:
males age 15-49: 414,878 (2002 est.)
Military manpower - reaching military age
annually:
males: 14,513 (2002 est.)
Military expenditures - dollar figure: S370 million
(FY00)
Military expenditures - percent of GDP: 1 7%
(FY00)
Military branches: Umbutfo Swaziland Defense
Force (Army), Royal Swaziland Police Force
Military manpower - availability:
males age 15-49: 253,510 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 146,805 (2002 est.)
Military expenditures - dollar figure: $20 million
(FY01/02)
Military expenditures • percent of GDP: 4.75%
(FY00/01)','63aeaaecb0b9f4aa7a3325bf917882f621e8afe9b75319845a21d23b74cf5227','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('897c8844236432853e5f05d05913c25e1e4c341594edb6d65daf903b44c30e6b',2002,'WF','Wallis and Futuna','military-and-security',476,'Military branches: Army (includes marines), Navy
(includes naval air), Air Force (includes Air Defense),
National Gendarmerie
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
mates age 15-49: 14,534,480 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 2,092,938 (2002 est.)
Military manpower - reaching military age
annually:
males: 390,064 (2002 est.)
Military expenditures - dollar figure: $46.5 billion
(2000)
Military expenditures - percent of GDP: 2.57%
(2002)','9f0396deadf3c8b42dee49da057155ae723fc15795404845e9e4f76e79553b1b','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('520f93194af42e85d717a7cd87f52bdd0f3254a7bbfba4c5775519b2a589d3a1',2002,'PF','French Polynesia','military-and-security',492,'Military branches: no regular indigenous military
forces; French Forces (including Army, Navy, Air
Force), Gendarmerie
Military - note: defense is the responsibility of','d637cc04e69aa16f3b5e2f99d433a9130d74ecdff4536c7f2b17b354b87d7e21','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3f1a8e8ce63b34d6cb45fd29ad04506086968cf3a38f2658f009ad5855ccfad8',2002,'GW','Guinea-Bissau','military-and-security',500,'Military branches: Gambian National Army (GNA)
(includes marine unit), National Police, Presidential
Guard
Military manpower - availability:
males age 15-49: 327,677 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 165,249 (2002 est.)
Military expenditures - dollar figure: $1 .2 million
(FY01)
Military expenditures - percent of GDP: 0.3%
(FY01)','cbf01130a2f94c00ec0461f099d97e98556653a286ff5107894301fa24a781d9','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4a3240b9a33f760823a4ca5615dcc5581b3d78a1b7300af4acd7c2ed4fa8dd5d',2002,'IL','Israel','military-and-security',510,'Military branches: in accordance with the peace
agreement, the Palestinian Authority is not permitted
conventional military forces; there are, however, a
Public Security Force and a civil Police Force
Military expenditures - dollar figure: SNA
Military expenditures - percent of GDP: NA%','7274e2447752bda5abae51116a6b1bc866d01836f69612c2e939e38667b6221a','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a4b4a61a881fdf38be67d18e3327bb18e71f1fba31a0351fa643bbcc60738517',2002,'GE','Georgia','military-and-security',518,'Military branches: Ground Forces (includes
National Guard), combined Air and Air Defense
Forces, Naval Forces, Republic Security and Police
Forces (internal and border troops)
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 ,300,259 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,027,407 (2002 est.)
Military manpower - reaching military age
annually:
males: 41 ,561 (2002 est.)
Military expenditures - dollar figure: $23 million
(FY00)
Military expenditures - percent of GDP: 0.59%
(FY00)
Military - note: a CIS peacekeeping force of Russian
troops is deployed in the Abkhazia region of Georgia
together with a UN military observer group; a Russian
peacekeeping battalion is deployed in South Ossetia
Military branches: Army, Navy (including naval air
arm), Air Force, Medical Corps, Joint Support Service
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 20,854,329 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 17,734,977 (2002 est.)
Military manpower - reaching military age
annually:
males: 482,31 8 (2002 est.)
Military expenditures - dollar figure: $38.8 billion
(2002)
Military expenditures - percent of GDP: 1 .38%
(2002)
Military branches: Army, Navy, Air Force, National
Police Force
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 5,045,355 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 2,799,292 (2002 est.)
Military manpower - reaching military age
annually:
mates: 213,237 (2002 est.)
Military expenditures - dollar figure; $35.2 million
(FY01)
Military expenditures - percent of GDP: 0.7%
(FY01)','05dfc2d8c3b9283230b8596a58df213b14dbaf31f6e78cc34e974d1763e5c9d8','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e5edd618fc8895d7019d39c2a46e6626d8669e5f58a1cda4b6a27d20dfa23d6c',2002,'GR','Greece','military-and-security',529,'Military branches: Hellenic Army, Hellenic Navy,
Hellenic Air Force, Police, National Guard
Military manpower - military age: 21 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 2,668,872 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 2,034,192 (2002 est.)
Military manpower - reaching military age
annually:
males: 77,976 (2002 est.)
Military expenditures - dollar figure: $6.12 billion
(FY99/00 est.)
Military expenditures - percent of GDP: 4.91%
(FY99/00 est.)','2cb12023abc5d205fd0e23b4beeac2530ce43df15bb92c1228b723f4775fb0ab','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c1a6819b7dce4a922f4c6336ec8f73d68f3e0f70a1542014c94c1bc51d13a7e0',2002,'GD','Grenada','military-and-security',546,'Military branches: Royal Grenada Police Force,
Coast Guard
Military expenditures - dollar figure: $NA
Military expenditures ■ percent of GDP: NA%','611a57986091be32163aa3ff0dc5aef699166ff17c3816b93a364dbb3d65b0eb','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2c7487d5563621b280c76a3d7719a52e851300f19a78aadf9ae79cfc970dbc42',2002,'GU','Guam','military-and-security',557,'Military - note: defense is the responsibility of the
US
Military branches: Army, Navy (includes Marines),
Air Force
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 3,1 86,894 (2002 est.)
Military manpower - fit for military service:
mates age 15-49: 2,080,504 (2002 est,)
Military manpower - reaching military age
annually:
males: 140,358 (2002 est.)
Military expenditures - dollar figure: $1 20 million
(FY99)
Military expenditures - percent of GDP: 0.6%
(FY99)','3ea1a7998550dac17191c63b1bc61a11cd9ade1fd06b7b0f3411f2c18f91734d','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a67f5134adc97c314182ef4498fdc5b35d494ec805f40f29bd13c1394a11e6dc',2002,'GG','Guernsey','military-and-security',566,'Military - note: defense is the responsibility of the
UK
Military branches: Army, Navy, Air Force,
Republican Guard, Presidential Guard, paramilitary
National Gendarmerie, National Police Force (Surete
National)
Military manpower - availability:
males age 15-49: 1,812,131 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 915,028 (2002 est.)
Military expenditures - dollar figure: $1 37.6
million (FY01)
Military expenditures • percent of GDP: 3.3%
(FY01)','65a436607294071a1402539cdd2d05b1cdf46f35fe07e01bc03b4b2caab3d0b4','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('da04265a9eca569473c680f29d11a278f941c6909d5129d813be4be9455ee068',2002,'GY','Guyana','military-and-security',575,'Military branches: Guyana Defense Force
(including Ground Forces, Coast Guard, and Air
Corps), Guyana Police Force, Guyana People''s
Militia, Guyana National Service
Military manpower - availability:
males age 15-49: 206,199 (2002 est.)
Military manpower - fit for military service:
males age 155,058 (2002 est.)
Military expenditures - dollar figure: SNA
Military expenditures - percent of GDP: NA%
Military branches: National Army (including small
Navy and Air Force elements), Civil Police
Military manpower - availability:
males age 15-49: 123,072 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 72,059 (2002 est.)
Military expenditures ■ dollar figure: $NA
Military expenditures • percent of GDP: 1 ,6%
(FY97 est.)
Military • note: demilitarized by treaty (9 February
1920)','515710ca4b0aa9bde300a3cebd75744cd9c937d7b5e38251c51cd7c9cc25f503','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('133ee677c7f2cb987213c29750ea5eb024bfad5e692cd0992c886856a17d4d37',2002,'HT','Haiti','military-and-security',585,'Military branches: Haitian National Police (HNP)
note: the regular Haitian Army, Navy, and Air Force
have been demobilized but still exist on paper until or
unless they are constitutionally abolished
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 ,691 ,585 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 919,275 (2002 est.)
Military manpower - reaching military age
annually:
males: 87,049 (2002 est.)
Military expenditures - dollar figure: $50 million
(FYCO)
Military expenditures - percent of GDP: 1 .3%
(FY00)','fc64837519f18f2d7719df807a1a926202ca84991330be48de2585eec943bf6f','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f71f19bff1540c11a88d16184765a3ede821d53c503b138970f956a253703b76',2002,'HM','Heard Island and McDonald Islands','military-and-security',589,'Military - note: defense is the responsibility of
Australia: Australia conducts fisheries patrols','e546f5cdacc51ecf4d69aeaeb53999d1bc9d5b863d3d317dc0e8be7fc0d89e2d','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('270de5ea94e7ceed1c50f4a75898d4caba16ecbcff6710cb1e4559cc2a62d214',2002,'IS','Iceland','military-and-security',600,'Military branches: no regular armed forces; Police,
Coast Guard
Military manpower • availability:
males age 15-49: 71 ,142 (2002 est.)
Military manpower * fit for military service:
males age 15-49: 62,556 (2002 est.)
Military expenditures - dollar figure: $0
Military ■ note: defense is provided by the
US-manned Icelandic Defense Force (IDF)
headquartered at Keflavik
Military - note: defense is the responsibility of','05663e96d2d3a01f4c2f76e52936dc72daba320942122b2ec41515ad08da426d','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bcae7747fae602a13bf9cf1159f20c873ae7f9269764815514cb0964dd39c5ce',2002,'IN','India','military-and-security',608,'Military branches: Army, Navy (including naval air
arm), Air Force, Strategic Nuclear Command (SNC),
Coast Guard, various security or paramilitary forces
(including Border Security Force, Assam Rifles,
Rashtriya Rifles, National Security Guards,
Indo-Tibetan Border Police, Special Frontier Force,
Ladakh Scouts, Centra! Reserve Police Force, Central
242
India (continued)
Industrial Security Force, Railway Protection Force,
Defense Security Corps, and Indian Reserve
Battalions)
Military manpower - military age: 17 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 285,729,565 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 67,599,380 (2002 est.)
Military manpower - reaching military age
annually:
mates; 10,879,384 (2002 est.)
Military expenditures - dollar figure:
$12,079,700,000 (FY01)
Military expenditures - percent of GDP: 2.5%
(FY01)','ebde07497a768972826902ee663cb48079170c6c00c48b0b1e58c18e03c16502','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5bfc7e025415074ec9bafc7a525b473464c4e6824a81c3725e2e7b1b1fdc1c76',2002,'IE','Ireland','military-and-security',617,'Military branches: Army (including Naval Service
and Air Corps), National Police (Garda Siochana)
Military manpower - military age: 17 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1,013,739 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 81 6,744 (2002 est.)
Military manpower - reaching military age
annually:
males: 32,287 (2002 est.)
Military expenditures - dollar figure: $700 million
(FY00/01)
Military expenditures - percent of GDP: 0.9%
(FY00/01)','a1068e09172d4cf834b98f54d1d8ace8e734a78c31ddd590dd990726d2ad8448','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a41b6d22306867b663a1fa05cae7891fef3a159022caba35ff24f46869c3b712',2002,'TN','Tunisia','military-and-security',627,'Military branches: Army, Navy, Air Force,
Carabinieri
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
maiesage 15-49: 14,184,307 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 12,157,753 (2002 est.)
Military manpower - reaching military age
annually:
males: 304,369 (2002 est.)
Military expenditures - dollar figure: $20.2 billion
(2002)
Military expenditures - percent of GDP: 1 .64%
(2002)
Military branches: Army, Navy, Air Force,
paramilitary forces, National Guard
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower - availability:
mates age 15-45:2,806,881 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,597,565 (2002 est.)
Military manpower - reaching military age
annually:
mates: 105,146 (2002 est.)
Military expenditures - dollar figure: $356 million
(FY99)
Military expenditures - percent of GDP: 1 .5%
(FY99)
Military branches: Land Forces, Navy (includes
Naval Air and Naval Infantry), Air Force, Coast Guard,
Gendarmerie
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 19,219,177 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 1 ,623,675 (2002 est.)
Military manpower - reaching military age
annually:
males: 674,805 (2002 est.)
Military expenditures - dollar figure: $8.1 billion
(2002 est.)
Military expenditures - percent of GDP: 4.5%
(2002 est.)','f5173c0d85b0161f2f4f1d93691eaff2fb898e2764018b2f6d6c7cf9a37451bc','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('614a90c023e578f64d5b86a922d85f7d8d59c70a3942516e51cc90fcaa949213',2002,'JM','Jamaica','military-and-security',637,'Military branches: Jamaica Defense Force
(including Ground Forces, Coast Guard, and Air
Wing), Jamaica Constabulary Force
Military manpower - military age: 18 years of age
(2002 est.)
261
Jamaica (continued)
Military manpower - availability:
males age 15-49:747,043 (2002 est.)
Military manpower - fit for military service:
mates age 15-49: 523,550 (2002 est.)
Military manpower - reaching military age
annually:
males: 27,729 (2002 est.)
Military expenditures - dollar figure: $30 million
(FY95/96 est.)
Military expenditures - percent of GDP: NA%','d9ba716fa51e7e79327ff91f94bb4723f38c43cda7c27872ba08d5e5301b59e1','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4afd0646eda6a79559cfc239bf47325d808ce5b25abe5db16358481a84654e3',2002,'NO','Norway','military-and-security',645,'Military branches: Japan Ground Self-Defense
Force (Army), Japan Maritime Self-Defense Force
(Navy), Japan Air Self-Defense Force (Air Force),
Japanese Coast Guard
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 29,644,498 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 25,637,387 (2002 est.)
Military manpower - reaching military age
annually;
males: 765,81 7 (2002 est.)
Military expenditures - dollar figure:
$40,774,300,000 (FY01)
Military expenditures - percent of GDP: 1 %
(FY01)
Military - note: defense is the responsibility of the
US; visited annually by the US Coast Guard','bd5ba83074b9a931a683a0a73a20ac7ef79c120e57fc52e151b54821a2e298a3','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0487f03f5c9fdcbbd14ac405b9ec6433862c1fc9328b2cbce8b9ee3a3dce1b81',2002,'MH','Marshall Islands','military-and-security',652,'Military • note: defense is the responsibility of the
US
Military branches: no regular military forces; Police
Force
Military expenditures - dollar figure: SNA
Military expenditures - percent of GDP: NA7©
Military - note: defense is the responsibility of the
US','c9918d7483722218b46712dc2374e624476c263e434024d79878bee7efed7701','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b50a6038d07ac3a199ca11e8c3687e814412bbe72df6fb3d25f4116405b2e25b',2002,'KZ','Kazakhstan','military-and-security',664,'Military branches: Ground Forces, Air and Air
Defense Forces, Naval Force, Border Service,
Republican Guard
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 4,545,168 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 3,629,219 (2002 est.)
Military manpower - reaching military age
annually:
males: 163,628 (2002 est.)
Military expenditures * dollar figure: $173 million
(Ministry of Defense expenditures) (FY01)
Military expenditures • percent of GDP: 1%
(Ministry of Defense expenditures) (FY01)
Military branches: Army, Navy, Air Force
Military manpower - availability:
males age 15-49: 7,938,865 (2002 est.)
Military manpower - fit for military service:
males age 75-49:4,915,090 (2002 est.)
Military expenditures - dollar figure: $179.2
million (FY01)
Military expenditures - percent of GDP: 1 .8%
(FY01)
Military - note: defense is the responsibility of
the US','7c83e0e23066c2e1229b759ca955cc1b4beca9400599f2cef2590a27d2b113c8','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4076cbbd60ecc924402fa84f96d3569b98add904684d2d34e963e33a12691576',2002,'KI','Kiribati','military-and-security',674,'Military branches: no regular military forces; Police
Force (carries out law enforcement functions and
paramilitary duties; small pofice posts are on all
islands)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: Kiribati does not have military forces;
defense assistance is provided by Australia and NZ
Military branches: Korean People''s Army (includes
Army, Navy, Air Force), Civil Security Forces
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
mates age 15-49: 6,032,376 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 3,619,535 (2002 est.)
Military manpower - reaching military age
annually:
males: 179,136 (2002 est.)
Military expenditures - dollar figure:
$5,124,100,000 (FY01)
Military expenditures - percent of GDP: 31 .3%
(FY01)
Military branches: Army, Navy, Air Force, Marine
Corps, National Maritime Police (Coast Guard)
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 14,194,960 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 8,990,488 (2002 est.)
Military manpower - reaching military age
annually:
males: 394,397 (2002 est.)
Military expenditures - dollar figure: $1 2.8 billion
(FY00)
Military expenditures - percent of GDP: 2.8%
(FY00)','243fae22a31630179be7fb154a943a27deb13e4f36a247ff7e8c37625954176f','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c5f0e6cad1bae32a5585bcb478d0772f6d6c1cdbd52d11935b47728082809811',2002,'LV','Latvia','military-and-security',686,'Military branches: Ground Forces, Navy, Air and Air
Defense Forces, Border Guard, National Guard
Military manpower - military age: 1 6 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 591 ,592 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 464,843 (2002 est.)
Military manpower - reaching military age
annually:
mates: 19,114 (2002 est.)
Military expenditures - dollar figure: $87 million
(FY01)
Military expenditures - percent of GDP: 1 .2%
(FY01)
Military branches: Lebanese Armed Forces (LAF;
includes Army, Navy, and Air Force)
Military manpower - availability:
mates age 15-49: 1,003,174 (2002 est.)
Military manpower - fit for military service:
males age 1549: 618,129 (2002 est.)
Military expenditures - dollar figure: $343 million
(FY99/00)
Military expenditures - percent of GDP: 4.8%
(FY99/00)','6bf339af656fd439c1a63290730352eb33bdedbbf684f60903e1cf79ac7600e1','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7b21558a70978383392fdbe2fcb1d65f1616f76fe8389eedcb76ebe248903798',2002,'ZA','South Africa','military-and-security',690,'Military branches: Lesotho Defense Force (LDF;
including Army and Air Wing), Royal Lesotho Mounted
Police
Military manpower • availability:
males age 15-49: 526,332 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 283,203 (2002 est.)
Military expenditures - dollar figure: $34 million
(1999)
Military expenditures - percent of GDP: NA%
Military ■ note: The Lesotho Government in 1999
began an open debate on the future structure, size,
and role of the armed forces, especially considering
the Lesotho Defense Force''s (LDF) history of
intervening in political affairs.
Military branches: Army, Navy, Air Force
Military manpower -availability:
ma/es age 15-49: 729,469 (2002 est.)
Military manpower - fit for military service:
mates age 15-49: 393,028 (2002 est.)
Military expenditures - dollar figure; $7.8 million
(FY01)
Military expenditures - percent of GDP: 1 .3%
(FY01)
Military branches: Armed Peoples on Duty (Army),
Navy, Air and Air Defense Command (includes Air
Force)
Military manpower - military age: 1 7 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 ,503,647 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 890,783 (2002 est.)
Military manpower - reaching military age
annually:
males: 61 ,694 (2002 est.)
Military expenditures - dollar figure: $1 .3 billion
(FY99/00)
Military expenditures - percent of GDP: 3.9%
(FY99/00)','08cc89a249e0ef221725e1844f0749203f24f986ab0ba7fbdbbc5f0395460b78','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('af4c64d34743d10c907aef3a0786b849701671b3a86f036f787f2a9e48fc6948',2002,'CH','Switzerland','military-and-security',709,'Military branches: Ground Forces, Navy, Air and Air
Defense Force, National Volunteer Defense Forces
(SKAT)
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability;
males age 15-49: 933,638 (2002 est.)
Military manpower - fit for military service:
mates agre 15-49: 733,41 5 (2002 est.)
Military manpower - reaching military age
annually:
males: 28,506 (2002 est)
Military expenditures - dollar figure: $230.8
miliion (FY01)
Military expenditures * percent of GDP: 1 .9%
(FY01)
Background: Switzerland''s independence and
neutrality have long been honored by the major
European powers and Switzerland was not involved in
either of the two World Wars. The political and
economic integration of Europe over the past half
century, as well as Switzerland''s role in many UN and
international organizations has strengthened
Switzerland''s ties with its neighbors. Switzerland is
active in many UN and international organizations, but
retains a strong commitment to neutrality.','ab68fe597b9c65ca7b4465c8c98d7074a5332742ad304ff044b2a5fbef766d5c','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2a82a184db942444eda71ead179f5a028c32728607929267da677a3dbfb6aa44',2002,'DE','Germany','military-and-security',716,'Military branches: Army, Grand Ducal Police
Military manpower - military age: 19 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 13,557 (2002 est.)
Military manpower • fit for military service:
mates age 15-49: 93,429 (2002 est.)
Military manpower - reaching military age
annually:
males: 2,565 (2002 est.)
Military expenditures - dollar figure: $147.8
million (FY01/02)
Military expenditures - percent of GDP: 0.8%
(FY01/02)','4b69151f33d34bc71a1c0873dea280680e20247d1286a34b928eadbf277e6d39','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('860c07387c08175056b91d87bd27df80ceda08805bf05c59f91afd3be58ff505',2002,'YT','Mayotte','military-and-security',726,'Military branches: People''s Armed Forces
(comprising Intervention Force, Development Force,
Aeronaval [Navy and Air] Force), Gendarmerie,
Presidential Security Regiment
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 3,758,940 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 2,229,304 (2002 est.)
Military manpower - reaching military age
annually:
males: 153,856 (2002 est.)
Military expenditures - dollar figure: $48.7 million
(FY01)
Military expenditures - percent of GDP: 1 .2%
(FY01)
Military branches: Army (including Air Wing and
Naval Detachment), Police (including paramilitary
Mobile Force Unit)
Military manpower - availability:
males age 15-49: 2,535,207 (2002 est.)
Military manpower ■ fit for military service:
males age 15-49: 1,301,625 (2002 est.)
Military expenditures - dollar figure: $9.5 million
(FY00/01)
Military expenditures - percent of GDP: 0.76%
(FY00/01)
318
Malawi (continued)','83fb73e5c5330ec40da8edc57c72395dd5501ab413de9860f4eb22d6dfec915a','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('684b4670b5f23822ce0b3e5c5b20c75994c44788d4a5eb7f931c11318a92a6c5',2002,'MV','Maldives','military-and-security',735,'Military branches: National Security Service
Military manpower - availability:
mates age 15-49: 74,893 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 41 ,672 (2002 est.)
Military expenditures - dollar figure: $34.5 million
(FY01)
Military expenditures - percent of GDP: 8.6%
(FY01)
Military branches: Army, Air Force, Gendarmerie,
Republican Guard, National Guard, National Police
(Surete Nationale)
Military manpower - availability:
males age 15-49: 2,369,578 (2002 est.)
Military manpower • fit for military service:
males age 15-49: 1 ,358,646 (2002 est.)
Military expenditures - dollar figure: $50 million
(FY01)
Military expenditures - percent of GDP: 2%
(FY01)','394af3103e13d626e77d59f801158328ecc41ea7228c4a6ffb35508c22843bc9','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3896bca131289ba5bc6f3abe5ae0e12ccf84d331bc6f0b872586e9e80ad9fb03',2002,'MT','Malta','military-and-security',744,'Military branches: Armed Forces (including land
forces [with subordinate air squadron and maritime
squadron] and the Revenue Security Corps). Maltese
Police Force
Military manpower - availability:
males age 15-49: 99,107 (2002 est.)
Military manpower - fit for military service:
males age 75-49:78,909 (2002 est.)
Military expenditures - dollar figure: $60 million
(2000 est.)
Military expenditures - percent of GDP: 1 .7%
(2000)
Military • note: defense is the responsibility of the
UK','7d9d97f8075cda13abd6157243c357689c4a8ca1dd6e7758d1f0207b21a3d845','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3481a17911c61aecebe38e921cf4ddd29c028d8cae2324677f37d0897f1e308',2002,'MR','Mauritania','military-and-security',757,'Military branches: Army, Navy, Air Force, National
Gendarmerie, National Guard, National Police,
Presidential Guard
Military manpower - availability:
males age 15-49: 644,294 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 312,276 (2002 est.)
Military expenditures - dollar figure: $37.1 million
(FY01)
Military expenditures - percent of GDP: 3.7%
(FY01)','1697e9eb860856ea194d840c9bb8d77d8940bd5544f4faf9eab9270df3cb40d6','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a1a53b4c1b9625ad705e3c640184491c0971b20fdd652dad94dbd72e4cb9febf',2002,'MU','Mauritius','military-and-security',767,'Military branches: National Police Force (includes
the paramilitary Special Mobile Force or SMF and
National Coast Guard)
Military manpower - availability:
males age 15-49: 340,050 (2002 est.)
Military manpower * fit for military service:
males age 15-49: 171 ,239 (2002 est.)
Military expenditures -dollar figure: $9.1 million
(FY01)
Military expenditures - percent of GDP: 0.2%
(FY01)','3e53743628f8cd2e1f9467a525db57ce79fed25af045055188cfc8644ec0ba2e','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('48f5faddd26e107607c0ea449c6502187aec5ef85849d951a8b9bbb786e61e73',2002,'MX','Mexico','military-and-security',770,'Military • note: defense is the responsibility of
France; small contingent of French forces stationed
on the island
Military branches: National Defense Secretariat
(SEDENA) (including Army and Air Force), Navy
Secretariat (including Naval Air and Marines)
Military manpower - military age: 1 8 years of age
note; starting in 2000, females were allowed to
volunteer for military service (2002 est.)
Military manpower • availability:
males age 15-49; 27,229,581 (2002 est.)
Military manpower - fit for military service:
wales age 1549: 19,761,440 (2002 est.)
Military manpower - reaching military age
annually;
073/55:1,077,536(2002 651.)
Military expenditures - dollar figure: $4 billion
(FY99)
Military expenditures - percent of GDP: 1 %
(FY99)
Military branches: Army, Navy, Air and Air Defense
Force
Military manpower - military age: 19 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 10,415,598 (2002 est.)
Military manpower - fit for military service:
mates age 15-49: 8,120,098 (2002 est.)
Military manpower - reaching military age
annually:
males: 344,781 (2002 est.)
Military expenditures - dollar figure: $3.5 billion
(2002)
Military expenditures - percent of GDP: 1 .71 %
(2002)','52d9895975fbd655c3b5ce5deba2e6da7241dcbf0490cec04ec8a85ac49c76e5','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('861ff01661c6c4b52345184db31152e3ddcbf115621ac08df56c8814f79ea05c',2002,'FM','Micronesia, Federated States of','military-and-security',777,'Military - note: Federated States of Micronesia
(FSM) is a sovereign, self-governing state in free
association with the US; FSM is totally dependent on
the US for its defense
Military - note: defense is the responsibility of the
US','6d84aa649679c2bb33d00471e8ba2801854295cb58edb264f86d5af232e47f90','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('295d9de471372a5486c268e02fa30a8d5f6f4e47966554e473367527b523115f',2002,'UA','Ukraine','military-and-security',793,'Military branches: Ground Forces (includes Air and
Air Defense Forces), Republic Security Forces
(includes paramilitary Internal Troops and Border
Troops)
Military manpower • military age: 18 years of age
(2002 est.)
Military manpower ■ availability:
males age 15-49: 1,172,714 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 929,316 (2002 est.)
Military manpower - reaching military age
annually:
males: 42,268 (2002 est.)
Military expenditures - dollar figure: $6 million
(FY01)
Military expenditures - percent of GDP: 0.4%
(FY01)
Military branches: Army, Navy, Air and Air Defense
Forces (AMR), Paramilitary Forces, Civil Defense,
Border Guards
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower - availability:
males age 75-49; 5,906,601 (2002 est.)
Military manpower * fit for military service:
males age 15-49: 4,970,496 (2002 est.)
Military manpower - reaching military age
annually:
males: 179,951 (2002 est.)
Military expenditures * dollar figure: $985 million
(2002)
Military expenditures - percent of GDP: 2.47%
(2002)
Military branches: Ground Forces, Navy, Air
Forces, Space Forces, Airborne Forces, Strategic
Rocket Forces
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 38,906,796 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 30,392,946 (2002 est.)
Military manpower - reaching military age
annually:
males: 1,242,778 (2002 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: Army, Navy, Air Force,
Gendarmerie
Military manpower - availability:
males age 15-49: 1,858,443 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 946,990 (2002 est.)
Military expenditures - dollar figure: $58 million
(FY01)
Military expenditures - percent of GDP: 3.1%
(FY01)
Military branches: Ground Forces, Naval Forces,
Air Force, Air Defense Forces, Interior Troops, Border
Troops
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 12,263,178 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 9,616,864 (2002 est.)
Military manpower - reaching military age
annually:
males: 390,823 (2002 est.)
Military expenditures - dollar figure: $500 million
(FY99)
Military expenditures - percent of GDP: 1 .4%
(FY99)','4b142d078f4348a5d5b1c86e37cd60acd2c6622545efd5312004f9c821228443','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f2b403942f12a80b5edf77a8bacf4289694f17bb7abac30a45fe40179004ef3',2002,'GI','Gibraltar','military-and-security',807,'Military branches: Royal Armed Forces (includes
Army, Navy, Air Force), Gendarmerie, Auxiliary
Forces
Military manpower ■ military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 8,393,772 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 5,289.283 (2002 est.)
Military manpower - reaching military age
annually:
mates: 348,380 (2002 est)
356
MorOCCO (continued)
Military expenditures ■ dollar figure: $1 .4 billion
(FY99/00)
Military expenditures - percent of GDP: 4%
(FY99/00)
Military branches: Army, Naval Command, Air and
Air Defense Forces, Special Forces, Militia
Military manpower - availability:
mates age 15-49: 4,71 1 ,31 8 (2002 est.)
Military manpower - fit for military service:
males age 15-49; 2,720,583 (2002 est.)
Military expenditures - dollar figure: $35.1 million
(2000 est.)
Military expenditures - percent of GDP: 1%
(2000 est.)','09712b82196fad778c406286a8092b85a4143335da156168e95f6fc1b3be15d6','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d0d5cd93ce0c8680efb103aec834151f3dbec9985bc7494f57d53a70013bde4c',2002,'BW','Botswana','military-and-security',820,'Military branches: National Defense Force (Army,
including Air Wing), Police
Military manpower - availability:
males age 15-49: 436,642 (2002 est.)
Military manpower - fit for military service:
mates age 15-49: 260,879 (2002 est.)
Military expenditures -dollar figure: $104.4
million (2001)
Military expenditures * percent of GDP: 2.6%
(FY97/98)
Military branches: no regular military forces; Nauru
Police Force
Military manpower - availability:
mates age 15-49: 3,103 (2002 est.)
Military manpower • fit for military service:
males age 15-49: 1 ,710 (2002 est.)
Military expenditures - dollar figure: SNA
Military expenditures - percent of GDP: NA%
Military • note: Nauru maintains no defense forces;
under an informal agreement, defense is the
responsibility of Australia
Military - note: defense is the responsibility of the
US
Military branches: Royal Nepalese Army (includes
Royal Nepalese Army Air Service), Nepalese Police
Force
Military manpower - military age: 1 7 years of age
(2002 est.)
Military manpower - availability:
males age f 5-49: 6,484,343 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 3,369,454 (2002 est.)
Military manpower • reaching military age
annually:
males: 292,589 (2002 est.)
Military expenditures - dottar figure: $51 .5 million
(FY01)
Military expenditures - percent of GDP: 1 %
(FY01)','cc2c722c8bf90bdb9813abe67844e645564600b86d5a6433af827397ad6ce6e8','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('866f8b783a606c800c6f8695705dda816887c88aeda71df4ee4df8b8807e1e23',2002,'NL','Netherlands','military-and-security',828,'Military branches: Royal Netherlands Army, Royal
Netherlands Navy (including Naval Air Service and
Marine Corps), Royal Netherlands Air Force, Royal
Constabulary
Military manpower - military age: 20 years of age
(note - age 17 for cadets and midshipmen) (2002 est.)
Military manpower - availability:
males age 15*49; 4,077,917 (2002 est.)
Military manpower - fit for military service:
males age 75-45; 3,546,030 (2002 est.)
369
Netherlands (continued)
Military manpower - reaching military age
annually:
males: 96,082
note: Netherlands has an all-volunteer, 74,100 force
in 2001 (2002 est.)
Military expenditures - dollar figure: $6.5 billion
(FY00/01 est.)
Military expenditures - percent of GDP: 1 .5%
(FYO0/01 est.)
Military branches: no regular indigenous military
forces; Royal Netherlands Navy, Marine Corps, Royal
Netherlands Air Force, National Guard, Police Force
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower • availability:
mates age 15-49: 54,752 (2002 est.)
Military manpower * fit for military service:
mates age 1549: 30,642 (2002 est.)
Military manpower - reaching military age
annually:
males: 1,61 0(2002 est.)
Military - note: defense is the responsibility of the
Kingdom of the Netherlands','97fab0aefd5694516283e2a1951caec62cc93076d77874d66800c2cef55483b5','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63bbf57281c2828bea2724dabc4b5230c673987d52832419bb8e2a67e70e1276',2002,'NI','Nicaragua','military-and-security',837,'Military branches: Army, Navy, Air Force
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1,308,430 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 802,779 (2002 est.)
Military manpower - reaching military age
annually:
mates: 58,232 (2002 est.)
Military expenditures - dollar figure: $26 million
(FY98)
Military expenditures - percent of GDP: 1 .2%
(FY98)','edc8e3a6818e42935a754699e736124c4cd731ccf4699e42ac82933089fdcba8','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('fee11ac8b9c40c89ac8895d8a8a11c29e79916ded505ed9bff7983f56b6e8455',2002,'NE','Niger','military-and-security',846,'Military branches: Army, Air Force, Gendarmerie,
National Intervention and Security Force
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49:2,270.793 (2002 est.)
Military manpower - fit for military service:
mates age 15-49: 1 ,227,994 (2002 est.)
Military manpower - reaching military age
annually:
males: 108,993 (2002 est.)
Military expenditures - dollar figure: $20.9 million
(FY01)
Military expenditures - percent of GDP: 1 .3%
(FY01)','6d158d6eea6d98ee3e03d4ac92f02a97b1fec329334f52a014bbe855d0f169b0','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5abb5fea21a042fc1ffc141dd94a462efefb3496daffbb0a3c79c9eb28550ad3',2002,'MP','Northern Mariana Islands','military-and-security',864,'Military - note: defense is the responsibility of the
US
Military branches: Norwegian Army, Roya!
Norwegian Navy (including Coast Artillery and Coast
Guard), Royal Norwegian Air Force, Home Guard
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower - availability:
mates age 75-49: 1 ,099,966 (2002 est.)
Military manpower - fit for military service:
mates age 15-49: 91 1 ,632 (2002 est.)
Military manpower - reaching military age
annually:
males: 27,341 (2002 est.)
Military expenditures - dollar figure: $3,113 billion
(FY98/99)
Military expenditures - percent of GDP: 2.13%
(2002)
Military branches: Royal Omani Armed Forces
(Army, Navy, Air Force), Roya! Omani Police
Military manpower - military age: 14 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 780,292 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 434,026 (2002 est.)
Military manpower - reaching military age
annually:
males: 26,470 (2002 est.)
Military expenditures - dollar figure:
$2,424,400,000 (FY01)
Military expenditures - percent of GDP: 1 2.2%
(FY01)
Military • note: defense is the responsibility of the
US','05d1e9c613eb2269aa085c47dbbe2dfe85edbae0e077198071bb75033828d4c9','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e5761d43e17cbc542ba46a46f389a86222c8ad80fc3938b269862b1c0bcb3c9',2002,'PK','Pakistan','military-and-security',876,'Military branches: Army, Navy, Air Force, Civil
Armed Forces, National Guard
Military manpower - military age: 17 years of age
(2002 est.)
Military manpower • availability:
males age 15-49: 36,941 ,592 (2002 est.)
Military manpower • fit for military service:
males age 1549: 22,606,576 (2002 est.)
Military manpower - reaching military age
annually:
males: 1,657,724 (2002 est.)
Military expenditures - dollar figure:
$2,545,500,000 (FY01)
Military expenditures ■ percent of GDP: 4.6%
(FY01)','7338df1b168873542406ed121dfbc30bf74fc7bc29b3064dbd6e4217693de676','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7901e51eb090ca0fa8dccfb3b6b20b51ee26c21077ef981d07cefe8af316a7b1',2002,'PW','Palau','military-and-security',886,'Military branches: NA
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of the
US; under a Compact of Free Association between
Palau and the US, the US military is granted access to
the islands for 50 years
Military - note: defense is the responsibility of the
US','6b6361ddebb5cf36ba68c99d7fb5dc5cede02d16ee4a21bbe0bdb036925e86bd','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6bbfd4ece3a10c9040b5e2a85ab126ccfe735aab990fa48f228414c690801f3e',2002,'AR','Argentina','military-and-security',902,'Military branches: Army, Navy (includes Naval Air
and Marines), Air Force
Military manpower - military age: 17 years of age
(2002 est.)
Military manpower - availability:
mates age 15-49: 1 ,427,160 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,028,935 (2002 est.)
Military manpower - reaching military age
annually:
males: 58,359 (2002 est.)
Military expenditures - dollar figure: $125 million
(FY98)
Military expenditures - percent of GDP: 1 .4%
(FY98)
Military branches: Army (Ejercito Peruano), Navy
(Marina de Guerra del Peru; includes Naval Air,
Marines, and Coast Guard), Air Force (Fuerza Aerea
del Peru; FAP), National Police (includes General
Police, Security Police, and Technical Police)
Military manpower - military age: 17 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 7,356,395 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 4,944,952 (2002 est.)
Military manpower - reaching military age
annually:
males: 276,458 (2002 est.)
Military expenditures - dollar figure: $1 billion
(FY01)
Military expenditures - percent of GDP: 1 .8%
(FY01)
Military branches: Army, Navy (including Coast
Guard and Marine Corps), Air Force, paramilitary units
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 21718,304 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 15,285,248 (2002 est.)
Military manpower - reaching military age
annually:
males: 848,181 (2002 est.)
Military expenditures - dollar figure: $995 million
(FY98)
Military expenditures - percent of GDP: 1 .5%
(FY98)
Military - note: defense is the responsibility of the
UK','f7d6696cea18b53010926ebd0dad7cca0e4ead07da06c9462f9d7f38fd248c52','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58c7f07774cdafb1cf37caa5d008e7796a1df6a3299647fe35e982c30667f985',2002,'QA','Qatar','military-and-security',918,'Military branches: Army, Navy, Air Force
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49:316,885 ■
note: includes non-nationals (2002 est.)
Military manpower - fit for military service:
males age 15-49: 166,214 (2002 est.)
Military manpower - reaching military age
annually:
mates: 6,797 (2002 est.)
Military expenditures - dollar figure: $723 million
(FY00/O1)
Military expenditures - percent of GDP: 1 0%
(FY00/01)','56ddaedd976e0fb671f608d24b8ff3e9b724f2b249fe540bcfd460f292441ef6','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7651a2520c4fc4526f0bda536dda7dcdc72b12c22fef8f64d9dcee80fe15d67b',2002,'TT','Trinidad and Tobago','military-and-security',925,'Military branches: Saint Kitts and Nevis Defense
Force (including Coast Guard), Royal Saint Kitts and
Nevis Police Force (including Special Service Unit)
Military expenditures - dollar figure: SNA
Military expenditures - percent of GDP: NA%','37d02e81e7265e86f42c92494e3b0fdc68e200890981bc9eed1655366e95ea59','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5f9bffb9a28c6a3964eeea2e983dd7c84e384ffe0e639c5b754d76a50b5e4a9f',2002,'MQ','Martinique','military-and-security',934,'Military branches: Royal Saint Lucia Police Force
(includes Special Service Unit and Coast Guard)
Military expenditures - dollar figure: SNA
Military expenditures - percent of GDP: $NA
Military - note: defense is the responsibility of','05cd3e34f66357a3b073d578f9aee63dd4d97e2d67eb262b1a844e88f01e2761','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3811f286aaf10f11398922bae1e50d09342d3f3014928da317ca09dcd620824a',2002,'WS','Samoa','military-and-security',937,'Military branches: Royal Saint Vincent and the
Grenadines Police Force (includes Special Service
Unit), Coast Guard
Military expenditures - dollar figure: SNA
Military expenditures - percent of GDP: NA%
Military branches: no regular armed services;
Samoa Police Force
Military expenditures - dollar figure: SNA
Military expenditures - percent of GDP: NA%
Military - note: Samoa has no formal defense
structure or regular armed forces; informal defense
ties exist with NZr which Is required to consider any
Samoan request for assistance under the 1962 Treaty
of Friendship','893f48c51394bec580ac4cf4396794056237978a8cfdc4a485959da499ba808f','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16e0ed1810fa1d9c4841873b12bd56511417b2043d7300f47d96163388610f09',2002,'SN','Senegal','military-and-security',951,'Military branches: Army, Navy, Air Force, National
Gendarmerie, National Police (Surete Nationale)
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 2,406,337 (2002 est.)
Military manpower - fit for military service:
males age 15*49: 1 ,257,423 (2002 est.)
Military manpower - reaching military age
annually:
males: 114,189 (2002 est.)
Military expenditures - dollar figure: $68.6 million
(FY02)
Military expenditures - percent of GDP: 14%
(FY02)','ddf9c282bdc9e5af25a0de7fc3c0105d89789e31ba12ffd2b01fe1eb43e98041','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73e6ab1324a2b10244397044e0872be5f9ab95dc47c3fb0bad0ea7bd3ae0b8c8',2002,'SC','Seychelles','military-and-security',961,'Military branches: Army, Coast Guard (includes Air
Wing), Presidential Protection Unit (includes
Presidential Guard), Police Force (includes Police
Mobile Unit, a special weapons and tactics unit
capable of assisting the Army in maintaining internal
stability)
Military manpower - availability:
males age 15-49: 23,210 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 1 ,554 (2002 est.) ,
Military expenditures -dollar figure: $11 million
(FY01)
Military expenditures - percent of GDP: 1 .8%
(FY01)','2fb2cf14c6cfd64d423981722be7f93f706e043a23c03b266abc98310983d785','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16ea3efcd66ee328788a9e76557561ebea5f4885764f638d5593bbc968985683',2002,'SL','Sierra Leone','military-and-security',970,'Military branches: Army (RSLAF)
Military manpower - availability:
males age 15-49: 1 ,203,682 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 583,946 (2002 est.)
Military expenditures - dollar figure: $10.3 million
(FY01)
Military expenditures - percent of GDP: 1 .5%
(FY01)','171b6c5c5307f3b3fab9bfca37890eae614ed28b64659bf66d8d4a5992d44ccd','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8d13ccede2a829967f2c7141553209fa17087573605a656f3411510020393dcc',2002,'HU','Hungary','military-and-security',984,'Military branches: Army (Ground Forces), Air and
Air Defense Forces, Home Guards (Territorial
Defense Forces), Civil Defense Force, Railway Armed
Forces (subordinate to the Ministry of Transportation,
Post, and Telecommunications)
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1,486,728 (2002 est)
Military manpower - fit for military service:
males age 15-49: 1 ,1 36,775 (2002 est.)
Military manpower - reaching military age
annually:
males: 45,502 (2002 est)
Military expenditures - dollar figure: $406 million
(2002)
Military expenditures - percent of GDP: 1 .89%
(2002)','37b59e68ae1ff22a5a7cb81facb4fa817bf5ddcbbf12b07c54f45fcd4df2a891','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('21c90b4a0f2829593ae0b276bba26975ac10a3ea0e55c79d62f9da1174f9599d',2002,'SB','Solomon Islands','military-and-security',994,'Military branches: no regular military forces;
Solomon Islands National Reconnaissance and
Surveillance Force; Royal Solomon Islands Police
(RSIP)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','997a0316d3ec8cddc0d6681e98e9a91d7c5be93a9ba99ebd9a2afcaddf5b859c','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ebc66f5f99bc9abb87a771841403531e95c6d22319d048314dc419fdd7d1ed8',2002,'SO','Somalia','military-and-security',1003,'Military branches: A Somali National Army is being
reformed under the interim government; numerous
factions and clans maintain independent militias, and
the Somaliland and Puntland regional governments
maintain their own security and police forces
Military manpower - availability:
mates age 15-49: 1,881,634 (2002 est.)
Military manpower - fit for military service:
males age 75-49: 1 ,040,662 (2002 est.)
Military expenditures - dollar figure: $15.3 million
(FY01)
Military expenditures - percent of GDP: 0.9%
(FY01)
Military branches: South African National Defense
Force (including Army, Navy, Air Force, and Medical
Services), South African Police Service
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 1 ,557,242 (2002 est.)
Military manpower - fit for military service:
males age 1549: 7,031 ,337 (2002 est.)
Military manpower - reaching military age
annually:
males: 466,399 (2002 est.)
Military expenditures - dollar figure: $1 .79 billion
(FY01)
Military expenditures - percent of GDP: 1 .6%
(FY01)
Military - note: the National Defense Force
continues to integrate former military, black
homelands forces, and ex-opposition forces
Military - note: defense is the responsibility of the
UK','db66432f1239fa79ba51ddf60e355ff12b1f61c8d7d4e9c710ee1ebe951f4e07','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9c634abb694eba5c95716132db149cb420ed9f08062d6ef940ac0438b4426631',2002,'LK','Sri Lanka','military-and-security',1012,'Military branches: Army, Navy, Air Force, Police
Force
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 5,347,153 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 4,148,825 (2002 est.)
Military manpower - reaching military age
annually:
males: 193,522 (2002 est.)
Military expenditures - dollar figure: $71 9 million
(FY98)
Military expenditures -percent of GDP: 4.2%
(FY98)
Military branches: Army, Navy, Air Force, Popular
Defense Force Militia
Military manpower • military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 8,739,982 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 5,380,917 (2002 est.)
Military manpower - reaching military age
annually:
males: 398,294 (2002 est.)
Military expenditures -dollar figure: $581 million
(2001 est.)
Military expenditures - percent of GDP: 2.5%
(1999)','97a4331995e8dc64c1b47451d0200e7dd3fa92a43bc954815cbbabf439fbe5a4','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a0a04d201d1a72fe7d7a2d76bb20c12197f92e70efdc1ed7a592434ccd13b5d3',2002,'AF','Afghanistan','military-and-security',1022,'Military branches: Army, Air Force and Air Defense
Force, Presidential National Guard, Security Forces
(internal and border troops)
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
mates age 15-49: 1,646,278 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,349,505 (2002 est.)
Military manpower » reaching military age
annually:
mates: 72,056 (2002 est.)
Military expenditures - dollar figure: $35.4 million
(FY01)
Military expenditures - percent of GDP: 3.9%
(FY01)
Military branches: Tanzanian People''s Defense
Force (including Army, Navy, and Air Force),
paramilitary Police Field Force Unit (including Police
Marine Unit and Police Air Wing), territorial militia
Military manpower - availability:
males age 15-49: 8,636,817 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 4,997,257 (2002 est.)
Military expenditures - dollar figure: $19 million
(FY01)
Military expenditures - percent of GDP: 0.2%
(FY01)
Military branches: Royal Thai Army, Royal Thai
Navy (includes Royal Thai Marine Corps), Royal Thai
Air Force, paramilitary forces (includes the Border
Patrol Police [including Police Aerial Reinforcement
Unit], Thahan Phran, Special Action Forces, Police
Aviation Division, Thai Marine Police, and the
Volunteer Defense Corps)
507
Thailand (continued)
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 17,766,501 (2002 est.)
Military manpower - fit for military service:
males age 75-49: 1 0,660,530 (2002 est.)
Military manpower - reaching military age
annually:
males: 567,659 (2002 est.)
Military expenditures • dollar figure: $1 .775 billion
(FY00)
Military expenditures - percent of GDP: 1 .4%
(FY00)
Military branches: Army, Navy, Air Force,
Gendarmerie
Military manpower - availability:
males age 15-49: 1 ,220,758 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 640,280 (2002 est.)
Military expenditures - dollar figure: $21 .9 million
(FY01)
Military expenditures -percent of GDP: 1.8%
(FY01)
Military - note: defense is the responsibility of the
UK','44b50e791da99d7b041fc2952560c4cd67b716a77a2d85401989fa3646ad2fa8','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('054270d737ddb6edc17308e2e4dceb751153746e7671cce7f38012ee10c5a2fa',2002,'TM','Turkmenistan','military-and-security',1040,'Military branches: Ministry of Defense (Army, Air
and Air Defense, Navy, Border Troops, and Internal
Troops), National Guard
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 ,206,920 (2002 est.)
Military manpower - fit for military service:
males age 75-49; 979,282 (2002 est.)
Military manpower - reaching military age
annually:
males: 48,292 (2002 est.)
Military expenditures - dollar figure: $90 million
(FY99)
Military expenditures • percent of GDP: 3.4%
(FY99)','85f256989cf91e033724f4932b551b33387624ae348576e0974c9a1004c5594f','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('63092828c5842c75f6a58b8237a5c5ff2fdbc33c8e70c7790ed4f9fdacf123e7',2002,'TV','Tuvalu','military-and-security',1049,'Military branches: no regular military forces; Police
Force (includes Maritime Surveillance Unit for search
and rescue missions and surveillance operations)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: Ugandan Peoples'' Defense
Force (including Army, Marine unit, Air Wing)
Military manpower - availability:
males age 15-49: 5,302,787 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 2,879,083 (2002 est.)
Military expenditures - dollar figure: $121.3
million (FY01)
Military expenditures - percent of GDP: 21%
(FY01)','e13d6eaf0ad7cf8f3930bc7d778ccd953fd8f2c730d0213a01450d98e18fa36b','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b48af5201b39dfc95f13d2208ee7218335756ecea5396913f37dfa8da5a8d213',2002,'OM','Oman','military-and-security',1060,'Military branches: Army, Navy (including Marines
and Coast Guard), Air Force, Air Defense,
paramilitary forces (includes Federal Police Force)
Military manpower - military age: 18 years of age
(2002 est)
Military manpower - availability:
males age 15-49: 773,938
no/e: includes non-nationals (2002 est.)
Military manpower • fit for military service:
males age 15-49: 41 9,851 (2002 est.)
Military manpower - reaching military age
annually:
males: 25,482 (2002 est.)
Military expenditures - dollar figure: $1 .6 billion
(FYOO)
Military expenditures - percent of GDP: 3.1%
(FYOO)','c3ed17c8f0ce819811e2eb5b2f7bd1b258a35c5efee25e7bf1d3b309e979b39c','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ff0c076a515e6ceee43d8cf4b2a22795d766795de885ba33dd5d7d815f92bf6b',2002,'US','United States','military-and-security',1068,'Military branches: Department of the Army,
Department of the Navy (includes Marine Corps),
Department of the Air Force
note: the Coast Guard is normally subordinate to the
Department of Transportation, but in wartime reports
to the Department of the Navy
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 70,81 9,436 (2001 est.)
Military manpower - fit for military service:
NA (2002 est.)
542
United States (continued)
Military manpower - reaching military age
annually:
males: 2,053,179 (2002 est.)
Military expenditures - dollar figure: $2767 billion
(FY99 est.)
Military expenditures - percent of GDP: 3.2%
(FY99 est.)
Military - note:
note: 2002 estimates for military manpower are based
on projections that do not take into consideration the
results of the 2000 census
Military branches: Army, Navy (including Naval Air
Arm, Coast Guard, Marines), Air Force, Police
(Coracero Guard, Grenadier Guard)
Military manpower - availability:
males age 15-49: 824,395 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 666,880 (2002 est.)
Military expenditures - dollar figure: $250 million
(1999)
Military expenditures - percent of GDP: 1 .1%
(2000)','8b95565112065f284a7bbd5d1f1d6af2ad880fc7a93d3ed4b6dc76e14c0aec08','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6c6aa0df2bbbb37ca632fc7e6473fed8ae595966c2636aab9aeaa6fbe1dd9341',2002,'UZ','Uzbekistan','military-and-security',1077,'Military branches: Army, Air and Air Defense
Forces, National Guard, Security Forces (internal
security and border troops)
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 6,747,221 (2002 est.)
Military manpower • fit for military service:
males age 15-49: 5,478,766 (2002 est.)
Military manpower - reaching military age
annually:
males: 274,602 (2002 est.)
Military expenditures - dollar figure: $200 million
(FY97)
Military expenditures - percent of GDP: 2%
(FY97)','fc0208bd905381642ad67b70de91057e089fb3bb6f55ea4f1c221796f67b6af3','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d18521492847a160140b150dda85c76debef5b0afbef24f08d0bbf800fc3e4dc',2002,'VU','Vanuatu','military-and-security',1087,'Military branches: no regular military forces;
Vanuatu Police Force (VPF; including the paramilitary
Mobile Force or VMF)
Military expenditures - dollar figure: SNA
Military expenditures - percent of GDP: NA%
Military branches: National Armed Forces (Fuerzas
Armadas Nacionales or FAN) includes Ground Forces
or Army (Fuerzas Terrestres or Ejercito), Naval
Forces (Fuerzas Navales or Armada - including
marines and Coast Guard), Air Force (Fuerzas
Aereas or Aviacion), Armed Forces of Cooperation or
National Guard (Fuerzas Armadas de Cooperacion or
Guardia Nacional)
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 6,647718 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 4,786,849 (2002 est.)
Military manpower - reaching military age
annually:
males: 246,185 (2002 est.)
Military expenditures * dollar figure: $934 million
(FY99)
Military expenditures • percent of GDP: 0.9%
(FY99)
Military branches: People''s Army of Vietnam
(includes Ground Forces, People''s Navy Command
(including Naval Infantry], Air and Air Defense Force,
Coast Guard)
Military manpower - military age: 1 7 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 22,220,891 (2002 est,)
Military manpower - fit for military service:
males age 15-49: 13,978,653 (2002 est.)
Military manpower - reaching military age
annually:
males: 961 ,124 (2002 est.)
Military expenditures - dollar figure: $650 million
(FY98) ''
Military expenditures - percent of GDP: 2.5%
(FY98)','1e1123560b8b080821b8cf94ebcddc2d137fed6f31cb66732b6f6c58b67b81a7','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8fc02dbaac352a680f573ff32e7c72bc699d41f335382ecc504ba1456aaabc11',2002,'DZ','Algeria','military-and-security',1105,'Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military expenditures - dollar figure: aggregate
real expenditure on arms worldwide in 1999 remained
at approximately the 1998 level, about three-quarters
of a trillion dollars (1999 est.)
Military expenditures - percent of GDP: roughly
2% of gross world product (1 999 est.)
565
Military branches: Army (includes Special Forces,
established in 1999), Navy, Air Force, Air Defense
Forces, Republican Guard
Military manpower - military age: 14 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 4,272,156 (2002 est.)
Military manpower • fit for military service:
males age 15-49: 2,397,914 (2002 est.)
Military manpower - reaching military age
annually:
males: 238,690 (2002 est.)
Military expenditures • dollar figure: $482 .5
million (FY01)
Military expenditures • percent of GDP: 5.2%
(FY01)
Military - note: establishement of a Coast Guard,
scheduled for May 2001, has been delayed
Military branches: Army (VJ) (including ground
forces with border troops, naval forces, air and air
defense forces)
Military manpower - military age: 19 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 2,589,437 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 2,082,322 (2002 est.)
Military manpower - reaching military age
annually:
males: 82,542 (2002 est.)
Military expenditures - dollar figure: $654 million
(2002)
Military expenditures - percent of GDP: NA%
570
Yugoslavia (continued)
Military branches: Army, Air Force, Police,
paramilitary forces
Military manpower - availability:
males age 15-49: 2,313,567 (2002 est.)
Military manpower - fit for military service:
males age 1 5-49: 1,228,385 (2002 est.)
Military expenditures - dollar figure: $32.5 mitiion
<FY01)
Military expenditures - percent of GDP: 0.9%
(FY01)','85c816d795e06777de0f15033a9345dcba990a3a384ad37968613a40b35baa54','internet-archive','2002CIAWorldFactbook','txt','6107f004d74f838e04ad7acdaf60f02a17fa35f27863569e86e2895a45a78d65','https://archive.org/download/2002CIAWorldFactbook/2002CIAWorldFactbook_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('946676f1d340b285f3f81e386cee6ca76c36bb944a519376a688d53f584cc8d4',2002,'','','military-and-security',4,'branches:
manpower -
military age:
manpower -
availability:
manpower - fit
for military
service:
manpower -
reaching military
age annually:
expenditures -
dollar figure:
expenditures -
percent of GDP:
re
mee
LAST hs
pais
Dispu
ites
a ws poy
ie os ee cas SUSAR ease ated cnet eAc i Nace aE LS Sada RON Mee Ld
- demarcation of boundaries with Cambodia, Thailand, and Vietnam is
| ARLLpti Ww oe
i
i
‘Royal Cambodian Armed Forces (RCAF): Army, Navy, Air Force
H
18 years df age (2002 est.)
{ !
i
males age 15-49: 2,990,790 (2002 est.)
j
males age 15-49: 1,673;713 (2002 est.)
males: 162,643 (2002 est.)
$112 million (FY01 est.)
3% (FYOI est.)
international: nearing completion; accuses Thailand of moving or destroying boundary
markers and encroachment, of not respecting its claims, and of sealing
off accessito the Preah Vihear temple ruin awarded to Cambodia by the
ICJ in 1962; accuses Vietnam of territorial encroachments and initiating
armed border incidents in seven provinces, despite substantial
demarcation efforts to date; disputes several offshore islands with
Vietham, which prevents delimitation of a maritime boundary
iticit drugs: possible money laundering; narcotics-related corruption reportedly
involving some in the government, military, and police; possible
small-scale opium, heroin, and amphetamine production; large producer
of cannabis for the international market
|
pile page was last updated on 1 January 2002
i
!
!
i
i
t
i
t
Approved for Release: 2022/12/08 C06979339
a for Release: 2022/12/08 C06979339....ia/publications/factbook/print/cb html
: 10/24/2002 11:07 AM','70265386243e1413ed68eabac72f7cf1928094208b6e0077ab68d214db37bc0b','internet-archive','cia-readingroom-document-06979339','txt','23fb86984440c69281d1cc4dda66f178c921f20ab0df412f204fc36999179dcb','https://archive.org/download/cia-readingroom-document-06979339/06979339_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2dce9a40f2dd9d57eba58600952a60c29902507c22ee5032d4f5c342ae7471c8',2002,'AU','Australia','military-and-security',40,'Military branches
Military manpower - military age
Military manpower - availability
males age 15-49
females age 15-49
Military manpower - fit for military service
males age 15-49
females age 15-49
Military manpower - reaching military age
annually
males
females
Military expenditures - dollar figure
Military expenditures - percent of GDP
Military - note
Military branches: Royal Australian Army, Royal
Australian Navy, Royal Australian Air Force
Military manpower • military age: 17 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 5,013,406 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 4,321 ,387 (2002 est.)
Military manpower - reaching military age
annually:
males: 142,686 (2002 est.)
Military expenditures - dollar figure: $9.3 billion
(FY01/02 est.)
Military expenditures • percent of GDP: 2%
(FY01/02)
32
Australia (continued)
Military - note: defense is the responsibility of
Military - note: defense is the responsibility of
Australia; visited regularly by the Royal Australian
Navy; Australia has control over the activities of
visitors
Military branches: no regular indigenous military
forces; Police Force
Military - note: defense is the responsibility of New
Zealand
Military - note: defense is the responsibility of','aacff1412a0d327b0d6e261e99a2d90768d54747bf1c10a43ff1355d38166e6a','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('29539410690a9eab572d45eccd7119271a2a87128d270f4d98488727ab95d0b0',2002,'AF','Afghanistan','military-and-security',50,'Military branches: NA; note - the December 2001
Bonn Agreement calls for all militia forces to come
under Afghan Interim Authority (AIA) control, but
formation of a national army is likely to be a gradual
process; Afghanistan''s forces continue to be
facfa''onalized largely along ethnic lines
Military manpower - military age: 22 years of age
(2002 est.)
Military manpower • availability:
males age 15-49: 6,896,623 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 3,696,379 (2002 est.)
Military manpower - reaching military age
annually:
males: 252,869 (2002 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: Army, Air Force and Air Defense
Force, Presidential National Guard, Security Forces
(internal and border troops)
Military manpower • military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 ,646,278 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,349,505 (2002 est.)
Military manpower - reaching military age
annually:
males: 72,056 (2002 est.)
Military expenditures - dollar figure: $35.4 million
(FY01)
Military expenditures - percent of GDP: 3.9%
(FY01)
Military branches: Tanzanian People''s Defense
Force (including Army, Navy, and Air Force),
paramilitary Police Field Force Unit (including Police
Marine Unit and Police Air Wing), territorial militia
Military manpower - availability:
males age 15-49: B, 636, 81 7 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 4,997,257 (2002 est.)
Military expenditures ■ dollar figure: $19 million
(FY01)
Military expenditures • percent of GDP: 0.2%
(FY01)
Military - note: defense is the responsibility of the
UK','608aaea202f0a22e2973d83b22ae8d1cecdcda56373c13a0441b0193b09e2f1b','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4895e7d95c2604fa762dfdf929ade8723049dc424a8c636e279e00f812a92180',2002,'AL','Albania','military-and-security',59,'Military branches: Army, Navy, Air and Air Defense
Forces, Interior Ministry Troops, Border Guards
Military manpower • military age: 19 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 888,086 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 727,406 (2002 est.)
Military manpower - reaching military age
annually:
males: 35,792 (2002 est.)
Military expenditures - dollar figure: $56.5 million
(FY02)
Military expenditures - percent of GDP: 1 .49%
(FY02)
Military branches: Peoples National Army (ANP),
Algerian National Navy (ANN), Air Force, Territorial
Air Defense, National Gendarmerie
Military manpower - military age: 19 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 9,016,048 (2002 est.)
Military manpower - fit for military service:
males age 15-49:5,513,317 (2002 est.)
Military manpower • reaching military age
annually:
males: 388,939 (2002 est.)
Military expenditures • dollar figure: $1 .87 billion
(FY99)
Military expenditures - percent of GDP: 4.1%
(FY99)','cb2b2adabc63e12b9382937329e85d2ed52e985e4a986ccd3213bb95c68ef0e2','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4fc1deda8e4246437ff7f48cb0548dc6f967d64fe57274ddd70a60b0085d5417',2002,'NZ','New Zealand','military-and-security',70,'Military - note: defense is the responsibility of the
US
Military branches: Tonga Defense Services (made
up of three operational command components and
two support elements, including the Royal Marines,
Royal Guards, Maritime Force, a support/logistics
group, and a training group), Police; note - a new air
wing that will be subordinate to the Ministry of Defense
is being developed
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: Trinidad and Tobago Defense
Force (including Ground Force, Coast Guard, and Air
Wing), Trinidad and Tobago Police Service
Military manpower ■ availability:
males age 15-49: 347,831 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 248,324 (2002 est.)
Military expenditures • dollar figure: $90 million
(1999)
Military expenditures - percent of GDP: 1 .4%
(1999)
Military - note: defense is the responsibility of
Military - note: defense is the responsibility of','e22d075f49cbd0cc6eb1f6c72abdffff776ff225077c230d79c48be521106ef1','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f71875a4be3517abec8706f127bcb293b0553642a8e60dd978fd66010d3018a',2002,'AD','Andorra','military-and-security',79,'Military branches: no regular military forces, but
there is a police force
Military ■ note: defense is the responsibility of
France and Spain','6c4e88b5583f49eb87a15f8fd394214b262f9fdc398d2fc0bcd9678ba55927d2','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7817e4d7d448bdd126303504c0d987be3ac9fc7e7c3b41c32edc2f50798d7990',2002,'AO','Angola','military-and-security',88,'Military branches: Army, Navy, Air and Air Defense
Forces, National Police Force
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 2,532,469 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,272,509 (2002 est.)
Military manpower - reaching military age
annually:
males: 103,807 (2002 est.)
Military expenditures • dollar figure: $1.2 billion
(FY97)
Military expenditures - percent of GDP: 22%
(1999)
Military - note: defense is the responsibility of the
UK','1faac14cc0228e8179524ea9320f92a2ef7983ce3ffbeafb96784750a6a1886f','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('54fb3f2d25463fbfd5754ea5d8158234cbe326da6688e44a4050682bad0b80e1',2002,'AQ','Antarctica','military-and-security',98,'Military - note: the Antarctic Treaty prohibits any
measures of a military nature, such as the
establishment of military bases and fortifications, the
carrying out of military maneuvers, or the testing of
any type of weapon; it permits the use of military
personnel or equipment for scientific research or for
any other peaceful purposes
Military branches: Argentine Army, Navy of the
Argentine Republic (includes naval aviation and
Marines), Coast Guard, Argentine Air Force, National
Gendarmerie, National Aeronautical Police Force
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower • availability:
males age 15-49: 9,521,633 (2002 est.)
Military manpower • fit for military service:
males age 15-49:7,721,219 (2002 est.)
Military branches: Army, Air and Air Defense
Forces, Border Guards
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 912,650 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 722,035 (2002 est.)
Military manpower - reaching military age
annually:
males: 34,998 (2002 est, )
Military expenditures - dollar figure: $135 million
(FY01)
Military expenditures - percent of GDP: 6.5%
(FY01)
Military branches: no regular indigenous military
forces; Royal Dutch Navy and Marines, Coast Guard
Military - note: defense is the responsibility of the
Kingdom of the Netherlands
Military - note: defense is the responsibility of
Australia; periodic visits by the Royal Australian Navy
and Royal Australian Air Force
Atlantic Ocean','aa31ce91eccb1ffd1d0e41a5b7a76970fb2aadfedb082a74fd64c9ef6109d584','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5988bf3d38efc94a40be4ffcb7b37b7461bf1463aab39a32355c614a1e41c356',2002,'GP','Guadeloupe','military-and-security',107,'Military branches: Royal Antigua and Barbuda
Defense Force, Royal Antigua and Barbuda Police
Force (including the Coast Guard)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','6a726d44b331c7b83b5870a5c3f0418618d1acde981c23730c811c5d2d94bf37','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6bd3acd020a54bd4b143bfc19bd2c859b0e14e28b05b24063bd42f96eefdcf4c',2002,'AT','Austria','military-and-security',124,'Military branches: Land Forces (KdoLdSK), Air
Forces (KdoLuSK)
Military manpower - military age: 19 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 2,092,623 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1,728,191 (2002 est.)
Military manpower - reaching military age
annually:
males: 50,580 (2002 est.)
Military expenditures - dollar figure:
$1,497,100,000 (FY01/02)
Military expenditures - percent of GDP: 0.8%
(FY01/02)','137640492824aef8f97e879ff746b1b01ba87d95fdc85759a4980e05595938f8','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e4e41446272f49f2549b6ec5624ffe1961cfa00249908f0ca97f3dd45d3027c6',2002,'AZ','Azerbaijan','military-and-security',132,'Military branches: Army, Navy, Air and Air Defense
Forces
Military manpower • military age: 18 years of age
(2002 est.)
Military manpower - availability:
malesage 15-49: 2.131,331 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1,706,325 (2002 est.)
Military manpower - reaching military age
annually:
males: 77,099 (2002 est.)
Military expenditures - dollar figure: $121 million
(FY99)
Military expenditures - percent of GDP: 2.6%
(FY99)','b3bdb351567fb734afe76dbce15d61d11c644cfd8a6813d968f0b7dc2a43118c','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7581d0599030623620faa8ec469fe2a4cb07b106fe931089ef29564147466107',2002,'BS','Bahamas','military-and-security',142,'Military branches: Royal Bahamas Defense Force
(Coast Guard only), Royal Bahamas Police Force
Military expenditures - dollar figure: $20 million
(FY95/96)
Military expenditures - percent of GDP: 0.7%
(FY99)','a82ff68f830f7bab0df4eed8e3962877740ac46f3eddc0470f3ba1164d6fe1a5','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8b888c92945555751331941708870c7daf838e72546d6433b0c7896b55a316da',2002,'BH','Bahrain','military-and-security',152,'Military branches: Bahrain Defense Forces (BDF)
comprising Ground Force (includes Air Defense),
Navy, Air Force, Coast Guard, Police Force, Amiri
Guards, National Guard
Military manpower - military age: 15 years of age
(2002 est.)
Military manpower - availability:
males age 15-49 : 222,572 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 121,955 (2002 est.)
Military manpower • reaching military age
annually:
males: 5,926 (2002 est.)
Military expenditures - dollar figure: $526.2
million (FV01)
Military expenditures ■ percent of GDP: 6.7%
(FY01)
Military - note: defense is the responsibility of the
US; visited annually by the US Coast Guard','20bbb06c237d1973a9b350e4f13dc4a97a23deaaeee18a8fa4e9506f4acbfa66','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('8f365166467d9b1e257affb46d0f5cc74443265fc3479aa4706efe668b554464',2002,'BD','Bangladesh','military-and-security',160,'Military branches: Army, Navy, Air Force, Coast
Guard, paramilitary forces (includes Bangladesh
Rifles, Bangladesh Ansars, Village Defense Parties,
Armed Police Battalions, National Cadet Corps)
Military manpower - availability:
males age 15-49: 37,303,372 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 22,1 39,736 (2002 est.)
Military expenditures - dollar figure: $559 million
(FY96/97)
Military expenditures • percent of GDP: 1 8%
(FY96/97)','f4149254095b0d35d0666f0c49f872b76c1fa7333d14170ee62e5d81490595de','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc4b9cc541a364b254edc84f78562542b54b9763e5f0c4024ebf90964d46edee',2002,'LC','Saint Lucia','military-and-security',164,'Military branches: Royal Barbados Defense Force
(including Ground Forces and Coast Guard), Royal
Barbados Police Force
Military manpower • availability:
males age 15-49: 78,132 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 53,532 (2002 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of','1d3611c13806a998908aae9e33393056c760cbeb1a6e5d22be60c6175778a54b','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3fe9780292df90db8ef81c2ca2c8c87600188a0afe12c3c5d9b2175718a7a9ba',2002,'BY','Belarus','military-and-security',179,'Military branches: Army, Air Force (including air
defense), Interior Ministry Troops, Border Guards
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 2,744,267 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 2,149,873 (2002 est.)
Military manpower - reaching military age
annually:
males: 86,396 (2002 est.)
Military expenditures • dollar figure: $1 56 million
(FY98)
Military expenditures - percent of GDP: 1%
(FY01)
Military branches: Army, Navy, Air Components,
National Gendarmerie
Military manpower - military age: 19 years of age
(2002 est.)
Military manpower - availability:
mates age 15-49: 2,508,557 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 2,070,016 (2002 est.)
Military manpower - reaching military age
annually:
males: 63,247 (2002 est.)
Military expenditures - dollar figure:
$3,076,500,000 (FY01/02)
Military expenditures - percent of GDP: 1 .4%
(FY01/02)
Military branches: Ground Forces, Navy, Air and Air
Defense Forces, Border Guard, National Guard
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 591 ,592 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 464,843 (2002 est.)
Military manpower - reaching military age
annually:
males: 19,114 (2002 est.)
Military expenditures • dollar figure: $87 million
(FY01)
Military expenditures ■ percent of GDP: 1 .2%
(FY01)','b8c4dbc46327c2a97166416416c359668bbfb8fafb2434bda95dd426ecc7f0ee','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e72807314ce9bae22ff0f6be32c3e69612ba0585eab713c8154b6047997b1edb',2002,'BZ','Belize','military-and-security',188,'Military branches: Belize Defense Force (includes
Army, Maritime Wing, Air Wing, and Volunteer Guard)
Military manpower • military age: 1 8 years of age
(2002 est.)
Military manpower • availability:
mates age 15-49: 64,909 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 38,472 (2002 est.)
Military manpower - reaching military age
annually:
males: 2,847 (2002 est.)
Military expenditures - dollar figure: $7.7 million
(FY00/01 )
Military expenditures - percent of GDP: 1 .87%
(FY00/01)','0ba9b749130d04fbf368ea4fa45fc23a2920b639954d81b275b2dec296f55ee8','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39106025066f1bb3d2c7919d0e4469256e4de9ba9c742643be30cc9a51db1cdd',2002,'BJ','Benin','military-and-security',196,'Military branches: Armed Forces (including Army,
Navy, Air Force), National Gendarmerie
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1,509,760
females age 15-49:1,536,036
note: both sexes are liable for military service
(2002 est.)
Military manpower - fit for military service:
males age 15-49: 771 ,373
females age 15-49: 778,730 (2002 est.)
Military manpower - reaching military age
annually:
males: 71,278
females: 70,088 (2002 est.)
Military expenditures - dollar figure: $27 million
(FY96)
Military expenditures - percent of GDP: 1 .2%
(FY96)
Military branches: no regular indigenous military
forces; Bermuda Regiment, Bermuda Police Force,
Bermuda Reserve Constabulary
Military expenditures ■ dollar figure: $4,027,970
(January 2002)
Military expenditures - percent of GDP: 0.1 1%
(FY00/01 )
Military - note: defense is the responsibility of the
UK','873e52a656480e94870b9a790258b08d13ba13c703f46df0f2e9b7a84cd19871','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d7394ed7b80d7467adfa82feeb9a9a33052805c4e166308e7283f6e0f48998cf',2002,'BT','Bhutan','military-and-security',205,'Military branches: Royal Bhutan Army, Royal
Bodyguard, National Militia, Royal Bhutan Police,
Forest Guards
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 517,470 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 276,303 (2002 est.)
Military manpower - reaching military age
annually:
ma/es:21,167 (2002 est.)
Military expenditures - dollar figure: $9.3 million
(FY01)
Military expenditures - percent of GDP: 1 .9%
(FY01)','4221f90d3f5b8e2a0fbce8a2651127fa5ca626f65296633961d5bbedc6d9230c','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('66b918fc4cdd0f6ec316fa609e375a0392586fbbccbf3e5d39fba40e1e12a9e4',2002,'PY','Paraguay','military-and-security',215,'Military branches: Army (Ejercito Boliviano), Navy
(Fuerza Naval, includes Marines), Air Force (Fuerza
Aerea Bolivians), National Police Force (Policia
Nacional de Bolivia)
Military manpower - military age: 19 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 2,062.321 (2002 est.)
Military manpower - fit for military service:
males age 15-49 : 1 ,343,755 (2002 est.)
Military manpower - reaching military age
annually:
ma/es:90.120 (2002 est.)
Military expenditures - dollar figure: S147 million
(FY99)
Military expenditures - percent of GDP: 1 .8%
(FY99)','45f1aefbe90505b0b6a41bcda851177a8eb22dfd0b3af3c6d2f8498f4c413222','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7da84726a0e254b19acf0a4649f868ada84ce960b39bc0513444ea3a41faaa5b',2002,'IT','Italy','military-and-security',225,'Military branches: VF Army (the air and air defense
forces are subordinate commands within the Army),
VRS Army (the air and air defense forces are
subordinate commands within the Army)
Military manpower - military age: 19 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 , 1 31 ,537 (2002 est.)
Military manpower ■ fit for military service:
males age 15-49: 898,117 (2002 est.)
Military manpower - reaching military age
annually:
males: 29,757 (2002 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: Botswana Defense Force
(including Army and Air Wing), Botswana National
Police
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 384,888 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 202,685 (2002 est.)
Military manpower - reaching military age
annually:
males: 19,479 (2002 est.)
Military expenditures - dollar figure: $1 35 million
(FY01/02)
Military expenditures - percent of GDP: 3.5%
(FY01/02)
Military branches: Army, Air Force, Frontier
Guards, Fortification Guards
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 ,841 ,867 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,561 ,689 (2002 esl.)
Military manpower - reaching military age
annually:
males: 42,597 (2002 est.)
Military expenditures - dollar figure: $2,548 billion
(FY01)
Military expenditures - percent of GDP: 1%
(FY01)
Military branches: Syrian Arab Army, Syrian Arab
Navy, Syrian Arab Air Force (includes Air Defense
Forces), Police and Security Force
Military manpower - military age: 19 years of age
(2002 est.)
Military manpower - availability:
males age 15-49:4,550,496 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 2,539,342 (2002 est.)
Military manpower - reaching military age
annually:
males: 200,859 (2002 est.)
Military expenditures - dollar figure: $921 million
(FY00 est.); note - based on official budget data that
may understate actual spending
Military expenditures - percent of GDP: 5.9%
(FY98)','2e9437a2c0e3f274ca096aa80d032fe8a8b13a69b62abf98de2ad2303ba4efec','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('871f23494eface926c9b80f86c5bde5d406af6f05d1112fce51bdb457f877882',2002,'SR','Suriname','military-and-security',234,'Military - note: defense is the responsibility of
Military branches: Army, Navy, Air Force, Popular
Defense Force Militia
Military manpower • military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 8,739,982 (2002 est.)
Background: Independence from the Netherlands
was granted in 1 975. Five years later the civilian
government was replaced by a military regime that
soon declared a socialist republic. It continued to rule
through a succession of nominally civilian
administrations until 1987, when international
pressure finally forced a democratic election. In 1 9B9,
the military overthrew the civilian government, but a
democratically-elected government returned to power
in 1991.','fdb90a10904a46ee15c6b3796ac4bd31d82294fe221435b1ce99712b62ddee2b','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4cfe0895db11fc6cf351efa0352eb99b1cc828cb5685510b50a85daa81002dcb',2002,'NO','Norway','military-and-security',243,'Military branches: Brazilian Army, Brazilian Navy
(includes naval air and marines), Brazilian Air Force,
Federal Police (paramilitary)
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower • availability:
males age 15-49 : 48,859,610 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 32,743,504 (2002 est.)
Military manpower - reaching military age
annually:
males: 1, 762,740 (2002 est.)
Military expenditures - dollar figure: $13,408
billion (FY99)
Military expenditures - percent of GDP: 1 .9%
(FY99)
Military branches: Japan Ground Self-Defense
Force (Army), Japan Maritime Self-Defense Force
(Navy), Japan Air Self-Defense Force (Air Force),
Japanese Coast Guard
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower • availability:
males age 15-49: 29,644,498 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 25,637,387 (2002 est.)
Military manpower - reaching military age
annually:
males: 765,81 7 (2002 est.)
Military expenditures • dollar figure:
$40,774,300,000 (FY01)
Military expenditures - percent of GDP: 1 %
(FY01)
Military - note: defense is the responsibility of the
US; visited annually by the US Coast Guard
Military branches: Army, Royal Navy (including
Coast Artillery and Naval Helicopter Service), Air
Force
Military manpower - military age: 19 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 2,060,205 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1,800,991 (2002 est.)
Military manpower - reaching military age
annually:
mates: 51 ,506 (2002 est.)
Military expenditures • dollar figure:
$4,395,100,000 (FY01)
Military expenditures - percent of GDP: 2.1%
(FY01)
494','3bbcb7d19eeb1904b232e172f4d86d9fcdd9625e10faa27f372e226e0fb4a12e','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('03c4dd173a70eca786b7a201a9d85c1b54ec00b4afabfbd3d0af4773a31176f9',2002,'IO','British Indian Ocean Territory','military-and-security',252,'Military - note: defense is the responsibility of the
UK; the US lease on Diego Garcia expires in 2016
Military - note: defense is the responsibility of the
UK
Military branches: Land Forces, Navy, Air Force,
Royal Brunei Police
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 108,921 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 62,864 (2002 est.)
Military manpower - reaching military age
annually:
males: 3,005 (2002 est.)
Military expenditures - dollar figure: $343 million
(FY98)
Military expenditures - percent of GDP: 5.1%
(FY98)
77
Brunei (continued)','bc74359e9e978f7c42cf983779081986d2a285dbe70dad0e40da08860ae7b55e','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b3d627eb671ada34677b02421e582d494236f3870ee049568cb45c3527212379',2002,'BG','Bulgaria','military-and-security',264,'Military branches: Army, Navy, Air and Air Defense
Forces (subordinate to Ministry of Defense), Internal
Forces (subordinate to Ministry of Interior), Civil
Defense Forces (subordinate to the president)
Military manpower - military age: 19 years of age
(2002 est.)
Military manpower - availability:
mates age 15-49: 1 ,873,052 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1,566,816 (2002 est.)
Military manpower - reaching military age
annually:
males: 56,104 (2002 est.)
Military expenditures - dollar figure: $356 million
(FY02)
Military expenditures - percent of GDP: 2.7%
(FY02)','7450330412e87046898ea0ca16b6cb4bb645b9c9b36b556e2a84ae278a17383e','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('f7881a762ae994751d8e4806d49586337273ad22b702ab0ac4954fc6fc450bc7',2002,'ET','Ethiopia','military-and-security',269,'Military branches: Army, Air Force, National
Gendarmerie, National Police, People''s Militia
Military manpower - availability:
males age 15-49: 2,688,072 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1,379,010 (2002 est.)
Military expenditures -dollar figure: $40.1 million
(FY01)
Military expenditures - percent of GDP: 1 .4%
(FY01)
Military branches: Ethiopian National Defense
Force (Ground Forces, Air Force, militia, police)
note: Ethiopia is landlocked and has no navy;
following the secession of Eritrea, Ethiopian naval
facilities remained in Eritrean possession
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 14,925,883 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 7,790,977 (2002 est.)
Military manpower - reaching military age
annually:
males: 703,625 (2002 est.)
Military expenditures - dollar figure: $800 million
(FY00)
Military expenditures - percent of GDP: 12.6%
(FY 00)
Military - note: defense is the responsibility of
Military branches: People''s Revolutionary Armed
Force (FARP; includes Army, Navy, and Air Force),
paramilitary force
Military manpower - availability:
males age 15-49 : 313,573 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 178,404 (2002 est.)
Military expenditures - dollar figure: $5.6 million
(FY01)
Military expenditures • percent of GDP: 2.8%
(FY01)
Military branches: Army, Navy, Security Police
Military manpower - availability:
males age 15-49: 35,524 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 18,727 (2002 est.)
Military expenditures - dollar figure: $400,000
(FY01)
Military expenditures - percent of GDP: 0.8%
(FY01)','fb4546f369f9af270087c97365ad11d6c4c32b883750f337f7cdfb65101f03cb','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('874e7bf9731cb4e0d6b8d5b9e5efb830a7002344d169e5bf0ab7ccaaab906edf',2002,'TH','Thailand','military-and-security',277,'Military branches: Army, Navy, Air Force
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
malesage 15-49: 12,211,144
females age 15-49: 12,223,069
note: both sexes liable for military service (2002 est.)
Military manpower - fit for military service:
malesage 75-49; 6,502,01 3
females age 15-49: 6,491 ,732 (2002 est.)
Military manpower • reaching military age
annually:
males: 486,432
females: 470,667 (2002 est.)
Military expenditures - dollar figure: $39 million
(FY97/98)
Military expenditures - percent of GDP: 21%
(FY97/98)
Military branches: Army (including naval and air
units), Gendarmerie
Military manpower • military age: 1 6 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 ,439,032 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 752.584 (2002 est.)
Military manpower - reaching military age
annually:
males: 79,360 (2002 est.)
Military expenditures - dollar figure: $36.9 million
(FY01)
Military expenditures - percent of GDP: 5.3%
(FY01)
Military branches: Lao People''s Army (LPA;
including Riverine Force), Air Force, National Police
Department
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 ,365,027 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 734,945 (2002 est.)
Military manpower - reaching military age
annually:
males: 64,437 (2002 est.)
Military expenditures - dollar figure: $55 million
(FY98)
Military expenditures - percent of GDP: 4.2%
(FY96/97)
Military branches: Royal Thai Army, Royal Thai
Navy (includes Royal Thai Marine Corps), Royal Thai
Air Force, paramilitary forces (includes the Border
Patrol Police [including Police Aerial Reinforcement
Unit], Thahan Phran, Special Action Forces, Police
Aviation Division, Thai Marine Police, and the
Volunteer Defense Corps)
507
Thailand (continued)
Military manpower • military age: 1 8 years of age
(2002 est.)
Military manpower • availability:
males age T5-49: 17,766,501 (2002 est.)
Military manpower - tit for military service:
males age 15-49: 10,660,530 (2002 est.)
Military manpower - reaching military age
annually:
males: 567,659 (2002 est.)
Military expenditures - dollar figure: $1 .775 billion
(FY00)
Military expenditures - percent of GDP: 1 .4%
(FY00)
Military branches: Army, Navy, Air Force,
Gendarmerie
Military manpower - availability:
males age 15-49: 1 ,220,758 (2002 est.)
Military manpower • fit for military service:
males age 15-49: 640,280 (2002 est.)
Military expenditures ■ dollar figure: $21.9 million
(FY01)
Military expenditures - percent of GDP: 1 .8%
(FY01)','54c6139d34ca77ff44fc209e3a734d5116e60dbe1d17a485a3c8f5b757236c5d','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('282b6938d7ea2b59acdf041c97bce37e88cad1d9778a71d548a00c2827d81c6d',2002,'KH','Cambodia','military-and-security',290,'Military branches: Royal Cambodian Armed Forces
(RCAF): Army, Navy, Air Force
Military manpower • military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 2,990,790 (2002 est.)
Military manpower - tit for military service:
males age 15-49: 1,673,713 (2002 est.)
Military manpower - reaching military age
annually:
ma/es: 162,643 (2002 esl.)
Military expenditures - dollar figure: $1 12 million
(FV01 est.)
Military expenditures - percent of GDP: 3%
(FY01 est.)
Military branches: Army, Navy (includes naval
infantry), Air Force, National Gendarmerie,
Presidential Guard
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 3,872,965 (2002 est.)
Military manpower - fit tor military service:
males age 15-49: 1 ,959,357 (2002 est.)
Military manpower - reaching military age
annually:
males: 174,308 (2002 est.)
Military expenditures - dollar figure: $1 1 8.6
million (FYO0/01)
Military expenditures - percent of GDP: 1 .4%
(FY98/99)','52c53554b76c40a90a1f784e3ca45f82fa97afd3f853fc9fb1279eea515edfc6','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('64d076271a75558b2bdade0baf0ec9f25cd9ea39fdb45ade9eab13d37215ec9f',2002,'US','United States','military-and-security',301,'Military branches: Canadian Armed Forces
(comprising Land Forces Command, Maritime
Command, Air Command, Communications
Command, Training Command)
Military manpower - military age: 17 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 8,361,475 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 7,139,068 (2002 est.)
Military manpower - reaching military age
annually:
mates: 217,516 (2002 est.)
Military expenditures - dollar figure:
$7,860,500,000 (FY01/02)
Military expenditures - percent of GDP: 1.1%
(FY01/02)
Military branches: Department of the Army,
Department of the Navy (includes Marine Corps),
Department of the Air Force
note: the Coast Guard is normally subordinate to the
Department of Transportation, but in wartime reports
to the Department of the Navy
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 70,819,436 (2001 est.)
Military manpower - fit for military service:
NA (2002 est.)
542
United States (continued)
Military manpower • reaching military age
annually:
males: 2,053,179 (2002 est.)
Military expenditures - dollar figure: $276.7 billion
(FY99 est.)
Military expenditures ■ percent of GDP: 3.2%
(FY99 est.)
Military - note:
note: 2002 estimates for military manpower are based
on projections that do not take into consideration the
results of the 2000 census','371ae0adc57a4498edffa97a1ad66889a6883c55ab4318c2db3a0971599f3ce7','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1ae0a6feb131e3eaa296e434421e0ceb0d633580af1adf358edfa4248a323623',2002,'PT','Portugal','military-and-security',306,'Military branches: Army, Coast Guard
Military manpower - availability:
males age 15-49: 92,486 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 52,215 (2002 est.)
Military expenditures - dollar figure: $9.3 million
(FY01)
Military expenditures - percent of GDP: 1 ,6%
(FY01)
Military branches: Army, Navy (PON) (includes
Marines), Air Force, Republican Guard (includes
Fiscal Guard)
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower • availability:
males age 15-49: 2,525,848 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 2,024,526 (2002 est.)
Military manpower - reaching military age
annually:
males: 71 ,404 (2002 est.)
Military expenditures - dollar figure: $1 .286 billion
(FV99/00)
Military expenditures • percent of GDP: 2.2%
(FY99/00)','73c17e616a40862a1a5f477d743fba2c8ebb216176b47c8c73195d1d0ef668b9','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3010f09988de52c85d45fde9e3b214eadead18152025b05fcd19b74b6086941a',2002,'HN','Honduras','military-and-security',319,'Military branches: Central African Armed Forces
(FACA) (including Republican Guard, Ground Forces,
Naval Forces, and Air Force), Presidential Security
Guard, Gendarmerie, National Police
Military manpower - availability:
males age 15-49: 845,182 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 442,220 (2002 est.)
Military expenditures • dollar figure: $29 million
(FY96)
Military expenditures - percent of GDP: 2.2%
(FY96)
Military branches: Armed Forces (including
National Army, Air Force, and Gendarmerie), Rapid
Intervention Force, National and Nomadic Guard
(GNNT), Presidential Security Guard, Police
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 ,881 ,769 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 985,094 (2002 est.)
Military manpower - reaching military age
annually:
males: 82,003 (2002 est.)
Military expenditures -dollar figure: $31 million
(FY01)
Military expenditures - percent of GDP: 1.9%
(FY01)
Military branches: Army of the Nation, National
Navy (including naval air, coast guard, and marines),
Air Force of the Nation, Chilean Carabineros (National
Police), Investigations Police
Military manpower - military age: 19 years of age
(2002 est.)
Military manpower • availability:
males age 15-49: 4,104,197 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 3,034,912 (2002 est.)
Military manpower - reaching military age
annually:
males: 136,830 (2002 est.)
Military expenditures • dollar figure: $2.5 billion
(FY99)
Military expenditures - percent of GDP: 3.1%
(FY99)
Military branches: Army, Navy (including marines),
Air Force
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
mates age 15-49: 1 ,563,174 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 930,718 (2002 est.)
Military manpower - reaching military age
annually:
males: 72,335 (2002 est.)
Military expenditures - dollar figure: $35 million
(FY99)
Military expenditures - percent of GDP: 0.6%
(FY99)
231
Honduras (continued)','db3c001bdf8673c2dff58624c66e278c7f669844e904da8214ea87945187cb12','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9eb45ed7cdeb54b45b01a821e3489608de1a0b57f5aa5d75e55f3ad00ef3e025',2002,'CN','China','military-and-security',327,'Military branches: People''s Liberation Army (PLA):
comprises ground forces, Navy (including naval
infantry and naval aviation), Air Force, and II Artillery
Corps (strategic missile force), People''s Armed Police
Force (internal security troops, nominally a state
security body but included by the Chinese as part of
the "armed forces" and considered to be an adjunct to
the PLA), militia
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 370,087,489 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 203,003,036 (2002 est.)
Military manpower - reaching military age
annually:
males: 10,089,458 (2002 est.)
Military expenditures - dollar figure: $20,048
billion (2002); note - this is the officially announced
figure, but actual defense spending more likely ranges
from $45 billion to $65 billion for 2002
Military expenditures - percent of GDP: 1 .6%
(2002); note - this is the officially announced figure,
but actual defense spending is more likely between
3.5% to 5.0% of GDP for 2002
Military branches: no regular indigenous military
forces; Hong Kong garrison of China''s People''s
Liberation Army (PLA) including elements of the PLA
Ground Forces, PLA Navy, and PLA Air Force; these
forces are under the direct leadership of the Central
Military Commission in Beijing and under
administrative control of the adjacent Guangzhou
Military Region
Military manpower • military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 2,028,208 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,523,378 (2002 est.)
Military manpower - reaching military age
annually:
mates: 47, 139 (2002 est.)
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of China
Howland Island
(territory of the US)
C 0.25 0.5 krr.
\\ '' 4
Military branches: Jordanian Armed Forces (JAF)
Royal Jordanian Land Force, Royal Naval Force,
Royal Jordanian Air Force, and Special Operations
Command or Socom); note ■ Public Security
Directorate normally falls under Ministry of Interior but
comes under JAF in wartime or crisis situations
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 ,51 7,751 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,073,991 (2002 est.)
Military manpower • reaching military age ''
annually:
mates: 57,131 (2002 est.)
Military expenditures • dollar figure: $757.5
million (FY01)
Military expenditures - percent of GDP: 8.6%
(FY01)
Military - note: defense is the responsibility of','72565689bc3ce4c8b13adc7f18923f4805cc901d3ee53679b9488cac42581839','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('17282c42b6e44d5fdb83147dfeb8b3cb4f5f69eccbecfd2d85ab272868d48e04',2002,'FR','France','military-and-security',345,'Military - note: defense is the responsibility of
Australia; the territory does have a five-person police
force
Military branches: Army, Navy, Air Force,
paramilitary Gendarmerie, Republican Guard
(includes Presidential Guard)
Military manpower • military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 3,963,166 (2002 est.)
Military manpower ■ fit for military service:
males age 15-49: 2,071 ,01 1 (2002 est.)
Military manpower • reaching military age
annually:
males: 1 88,41 1 (2002 est.)
Military expenditures - dollar figure: $1 27.7
million (FY01)
Military expenditures - percent of GDP: 1 .3%
(FY01)
Military branches: British Forces Falkland Islands
no regular indigenous military forces; (includes Army,
Royal Air Force, and Royal Navy), Police Force
Military expenditures - dollar figure: SNA
Military expenditures • percent of GDP: NA%
Military - note: defense is the responsibility of the UK
Military branches: no regular indigenous military
forces; French Forces, Gendarmerie
Military manpower - availability:
males age 15-49: 50,504 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 32,720 (2002 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of
Military - note: defense is the responsibility of
Military branches: no regular indigenous military
forces; French Forces, Gendarmerie
Military - note: defense is the responsibility of
Military branches: no regular indigenous military
forces; French Forces (Army, Navy, Air Force),
Gendarmerie
, Military - note: defense is the responsibility of
Military branches: Mongolian Armed Forces
(includes General Purpose Forces, Air and Air
Defense Forces, Civil Defense Troops); note - Border
Troops are under Ministry of Justice and Home Affairs
in peacetime
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 772,619 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 501,493 (2002 est.)
Military manpower - reaching military age
annually:
males: 30,230 (2002 est.)
Military expenditures - dollar figure: $24.3 million
(FY01)
Military expenditures - percent of GDP: 2.5%
(FY01)
Military branches: no regular indigenous military
forces; French forces (including Army, Navy, Air
Force, and Gendarmerie)
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 94,485 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 99,251 (2002 est.)
Military manpower - reaching military age
annually:
males: 6,243 (2002 est.)
Military - note: defense is the responsibility of
Military branches: Army, Navy, Air Force,
paramilitary forces, National Guard
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 2,806,881 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,597,565 (2002 est.)
Military manpower - reaching military age
annually:
mates: 105,146 (2002 est.)
Military expenditures - dollar figure: $356 million
(FY99)
Military expenditures - percent of GDP: 1 .5%
(FY99)
Military branches: Land Forces, Navy (includes
Naval Air and Naval Infantry), Air Force, Coast Guard,
Gendarmerie
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 19,219,177 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 1 ,623,675 (2002 est.)
Military manpower - reaching military age
annually:
males: 674,805 (2002 est.)
Military expenditures - dollar figure: $8.1 billion
(2002 est.)
Military expenditures - percent of GDP: 4.5%
(2002 est.)
Military branches: Army, Royal Navy (including
Royal Marines), Royal Air Force
Military manpower - availability:
mates age 15-49: 14,632,418 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 12,151 ,734 (2002 est.)
Military expenditures - dollar figure: $31 .7 billion
(2002)
Military expenditures - percent of GDP: 2.32%
(2002)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','de2186df5d38ed5913bda7ecd94a72d4376bf22118e23e8b398752c72ba0c15a','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1df88298e6f15c3f6d90eaa19d4e3a61532d39dbec35f4a5c33d100555eb645c',2002,'CO','Colombia','military-and-security',353,'Military branches: Army (Ejercito Nacional), Navy
(Armada Nacional, including Marines and Coast
Guard), Air Force (Fuerza Aerea Colombiana),
National Police (Policia Nacional)
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
mates age 15-49: 1 0,946,932 (2002 est.)
Military manpower - fit for military service:
mates age 15-49: 7,308,703 (2002 est.)
Military manpower • reaching military age
annually:
males: 379,295 (2002 est.)
Military expenditures - dollar figure: $3.3 billion
(FY01)
Military expenditures ■ percent of GDP: 3.4%
(FY01)','96851f0847c156ebdb6f6aa5e22d3eeb29ba681756d5d26519ce12496e5dd503','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2231ccc1ca9b17ca76fa0c933ba0f3e5517644424fdd37e5475f8660f3354263',2002,'MZ','Mozambique','military-and-security',364,'Military branches: Comoran Security Force
Military manpower - availability:
males age 15-49: 145,509 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 86,455 (2002 est.)
Military expenditures - dollar figure: $6 million
(FY01)
117
Comoros (continued)
Military expenditures • percent of GDP: 3%
(FY01)
Military branches: Army, Naval Command, Air and
Air Defense Forces, Special Forces, Militia
Military manpower - availability:
mates age 15-49: 4,71 1 ,31 8 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 2,720,583 (2002 est.)
Military expenditures - dollar figure: $35.1 million
(2000 est.)
Military expenditures - percent of GDP: 1 %
(2000 est.)
Military branches: Zimbabwe National Army, Air
Force of Zimbabwe, Zimbabwe Republic Police
(includes Police Support Unit, Paramilitary Police)
Military manpower - availability:
males age 15-49: 3,057,381 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1,898,383 (2002 est.)
Military expenditures - dollar figure: $350.6
million (FY01)
Military expenditures - percent of GDP: 3.8%
(FY01)
Military branches: Army, Navy (including Marine
Corps), Air Force, Coast Guard Administration, Armed
Forces Reserve Command, Combined Service
Forces Command
Military manpower - military age: 19 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 6,575,625 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 5,018,882 (2002 est.)
Military manpower - reaching military age
annually:
males: 198,766 (2002 est.)
Military expenditures - dollar figure:
$8,041,200,000 (FY01)
Military expenditures • percent of GDP: 2.8%
(FY01)','829cea139fe97f7e02ac57dd028b6b01217ee34787c9a9fe24f38754964ff33c','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4da5e7b44b5c0b6b1cf851f80964b83c51f15128f031ddd02233f34e9173de91',2002,'CG','Congo','military-and-security',370,'Military branches: Army, Navy, Air Force, Special
Security Battalion
Military manpower - availability:
males age 15-49: 11,996,175 (2002 est.)
Military manpower - fit for military service:
males age 15-49 : 6, 1 1 0,595 (2002 est.)
Military expenditures - dollar figure: $250 million
(FY97)
Military expenditures - percent of GDP: 4.6%
(FY97)
Military branches: Army, Air Force, Navy,
Gendarmerie, National Police
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 702,048 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 356,388 (2002 est.)
Military manpower - reaching military age
annually:
males: 32,350 (2002 est.)
Military expenditures • dollar figure: $84 million
(FY01)
Military expenditures - percent of GDP: 2.8%
(FY01)','56a9c0e90f0a3362fb78dabb966dc786051fb30826a3395ca5650ca6fe7b14cf','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7ca22217b980bc1bc647dcd333be3d6bd2408b0fe9cf0fee146ccad362cef9cf',2002,'CK','Cook Islands','military-and-security',383,'Military - note: defense is the responsibility of New
Zealand, in consultation with the Cook Islands and at
its request','25c7b2878c30c701ee772aa86ccf06273d2db06d391313073254f9a94bb34b92','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0f58f410695a2172c1d8960bb154acccc03ea47a1d243acb706d106e6aad7eee',2002,'CR','Costa Rica','military-and-security',391,'Military branches: no regular indigenous military
forces: Air Section, Ministry of Public Forces (Fuerza
Publics)
Military manpower • military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 ,058,283 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 707,927 (2002 est.)
Military manpower - reaching military age
annually:
males: 39,411 (2002 est.)
Military expenditures - dollar figure: $69 million
(FY99)
Military expenditures - percent of GDP: 1 .6%
(FY99)','ff3a9e263be4fcc0b2566a6b2b0019b77a7140d7727f95d5825ffcd98195dd50','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0206d5b342e1ac285a9d276e00fdfe36d4e292ee0e151e824dc16f3d568cec97',2002,'SI','Slovenia','military-and-security',403,'Military branches: Ground Forces (Hrvatska
Vojska, HV), Naval Forces, Air and Air Defense
Forces
Military manpower - military age: 1 9 years of age
(2002 est.)
Military manpower • availability:
males age 15-49: 1,086,578 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 860,497 (2002 est.)
Military manpower - reaching military age
annually:
males: 30,037 (2002 est.)
Military expenditures - dollar figure: $520 million
(2002 est.)
Military expenditures - percent of GDP: 2.39%
(2002 est.)','1747c0d0807af7d827b741829c7001731e0f362d52347c9a3a125e9ac4be5e45','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('71c6f7ffdc5e5cfb2a90e58fdde715860161702fc902693b83475020871210fd',2002,'CU','Cuba','military-and-security',414,'Military branches: Revolutionary Armed Forces
(FAR) including Ground Forces, Revolutionary Navy
(MGR), Air and Air Defense Force (DAAFAR),
Territorial Militia Troops (MTT), and Youth Labor Army
(EJT); note • the Border Guard Troops (TGF) are
controlled by the Interior Ministry
Military manpower - military age: 17 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 3,102,312
females age 15-49: 3,036,549 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1,915,586
females age 15-49: 1,869,867 (2002 est.)
Military manpower - reaching military age
annually:
males: 86,632
females: 79,562 (2002 est.)
Military expenditures - dollar figure: SNA
Military expenditures - percent of GDP: roughly
4% (FY95 est.)
Military - note: Moscow, for decades the key military
supporter and supplier of Cuba, cut off almost all
military aid by 1993','eb387e020fe924fe0f5fea6045da53754a17161ddd7aac624204e1943a1d52c6','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('28255e96db81509d3c95d450eded831d81a5563803cff67210a40746c908c925',2002,'CY','Cyprus','military-and-security',422,'Military branches:
Greek area: Greek Cypriot National Guard (GCNG;
including air and naval elements), Greek Cypriot
Police
Turkish area: Turkish Cypriot Security Force (GKK)
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 200,071 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 137,322 (2002 est.)
Military manpower - reaching military age
annually:
males: 6, 61 6 (2002 est.)
Military expenditures - dollar figure: $370 million
(FY00)
Military expenditures - percent of GDP: 4.2%
(FY00)
Military branches: Army, Air and Air Defense
Forces. Territorial Defense Force
Military manpower - military age: 18 years of age
(2002 est, )
Military manpower - availability:
males age 15-49: 2,637,128 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 2,012,779 (2002 est.)
Military manpower - reaching military age
annually:
males: 69,393 (2002 est.)
Military expenditures - dollar figure:
$1,190,200,000 (FY01)
Military expenditures - percent of GDP: 2.1 %
(FY01)','b96d71de937f1ea06974053c3eb725d8c547cc4c5748890abb9ac576ea8ef61f','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ead10317b5f253abe6f6f012fafa75d40edacfd1343c253b29042d654c5f684d',2002,'SE','Sweden','military-and-security',433,'Military branches: Royal Danish Army, Royal
Danish Navy, Royal Danish Air Force, Home Guard
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 1 5-49: 1,287,168 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,099,900 (2002 est.)
Military manpower - reaching military age
annually:
ma/es: 29,21 2 (2002 est.)
Military expenditures - dollar figure: $2.47 billion
(FY99/00)
Military expenditures - percent of GDP: 1 .4%
(FY99/00)
Military branches: Djibouti National Army (including
Navy and Air Force)
Military manpower - availability:
males age 15-49: 110,221 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 64,940 (2002 est.)
Military expenditures - dollar figure: $26.5 million
(FY01)
Military expenditures - percent of GDP: 4.4%
(FY01)
Military branches: Commonwealth of Dominica
Police Force (including Special Service Unit, Coast
Guard)
Military expenditures - dollar figure: SNA
Military expenditures - percent of GDP: NA%','ce93c8128d67aa02b407d9d5e2b7f7bbfdac8dc167f296e9c3066cb651c1595a','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9f343fd058b674aad342623b59cdd2e73a85653e1add165f04f4be9bb9caa946',2002,'DO','Dominican Republic','military-and-security',441,'Military branches: Army, Navy, Air Force, National
Police
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 2,323,088 (2002 est.)
Dominican Republic (continued)
Military manpower - fit for military service:
males age 15-49: 1 ,455,887 (2002 est.)
Military manpower ■ reaching military age
annually:
males: 87,404 (2002 est.)
Military expenditures • dollar figure: $1 80 million
(FY98)
Military expenditures - percent of GDP: 1.1%
(FY98)
Military branches: no regular indigenous military
forces; paramilitary National Guard, Police Force
Military - note: defense is the responsibility of the
US','d434b42d80325432e348262c669ac8a7cf4ca66d01afa3ec5d1f5c54098f5fd4','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('39f4927e69f442c0d821165488c9dbb5a5e304934ffa535ab55617b98547ffbb',2002,'ID','Indonesia','military-and-security',445,'Military branches: the East Timor Defense Force or
FALINTIL-FDTL comprises a light-infantry Army and a
small Naval component; note - plans are to develop a
force of 1 ,500 active personnel and 1 ,500 reserve
personnel over the next five years
Military manpower - military age: 18-21 years of
age
Military manpower - availability: NA
Military manpower - fit for military service: NA
Military manpower - reaching military age
annually: NA
Military expenditures - dollar figure: $4.4 million
(FY03)
Military expenditures - percent of GDP: NA%
Military branches: Army, Navy (including marines
and naval air arm), Air Force
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 65,013,184 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 37,942,329 (2002 est.)
Military manpower - reaching military age
annually:
males: 2,263,706 (2002 est.)
Military expenditures - dollar figure: $1 billion
(FY98/99)
Military expenditures - percent of GDP: 1 .3%
(FY98/99)
Military branches: Islamic Republic of Iran regular
forces (includes Ground Forces, Navy, Air Force and
Air Defense Command), Iranian Revolutionary
Guards Corps (IRGC) (includes Ground Forces, Air
Force, Navy, Qods [special operalions], and Basij
[Popular Mobilization Army] forces), Law Enforcement
Forces
Military manpower - military age: 21 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 8,868,571 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 1 ,1 92,731 (2002 est.)
Military manpower • reaching military age
annually:
mates: 823,041 (2002 est.)
Military expenditures - dollar figure: $9.7 billion
(FY00)
Military expenditures - percent of GDP: 3.1%
(FY00)
Military branches: Army, Navy (including Coast
Guard and Marine Corps), Air Force, paramilitary units
Military manpower - military age; 20 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 21,718,304 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 15,285,248 (2002 est.)
Military manpower ■ reaching military age
annually:
mates: 848,181 (2002 est.)
Military expenditures • dollar figure: $995 million
(FY98)
Military expenditures • percent of GDP: 1 .5%
(FY98)
Military - note: defense is the responsibility of the
UK
Military branches: Army, Navy, Air Force, People''s
Defense Force, Police Force
Military manpower - availability:
males age 15-49: 1,354,857 (2002 est.)
Military manpower • fit for military service:
males age 15-49: 986,101 (2002 est.)
Military expenditures - dollar figure: $4.47 billion
(FY01/02 est.)
Military expenditures - percent of GDP: 4.9%
(FY01/02)
462
Singapore (continued)','9fab9130205c64431090d5cd67ac0e85d9b877aa55c4c24b45170a50543540ac','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cc60f47a96697b36b40f49a70941d79460da8f5a06dcc20c7c6e5ed15638bea7',2002,'PE','Peru','military-and-security',456,'Military branches: Army, Navy (including Marines),
Air Force, National Police
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 3,468,678 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 2,337,944 (2002 est.)
Military manpower - reaching military age
annually:
males: 132,978 (2002 est.)
Military expenditures ■ dollar figure: $720 million
(FY98)
Military expenditures ■ percent of GDP: 3.4%
(FY98)
Military branches: Army, Navy, Air Force, Air
Defense Command
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 19,030,030 (2002 est.)
Military manpower - fit for military service:
mates age 15-49: 12,320,902 (2002 est.)
Military manpower - reaching military age
annually:
males: 712,983 (2002 est.)
Military expenditures - dollar figure: $4.04 billion
(FY99/00)
Military expenditures • percent of GDP: 4.1%
(FY99/00)
Military branches: Army, Navy (FNES), Air Force
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 1 5-49: 1,500,712 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 951 ,715 (2002 est.)
Military manpower - reaching military age
annually:
males: 68,103 (2002 est.)
Military expenditures - dollar figure: $112 million
(FY99)
Military expenditures • percent of GDP: 0.7%
(FY99)
Military branches: Army (Ejercito Peruano), Navy
(Marina de Guerra del Peru; includes Naval Air,
Marines, and Coast Guard), Air Force (Fuerza Aerea
del Peru; FAP), National Police (includes General
Police, Security Police, and Technical Police)
Military manpower - military age: 17 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 7,356,395 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 4,944,952 (2002 est.)
Military manpower - reaching military age
annually:
males: 276,458 (2002 est.)
Military expenditures - dollar figure: $1 billion
(FY01)
Military expenditures - percent of GDP: 1 .8%
(FY01)','446e7f730ee2aef9a4408cdfca51c80e089e35f5a9c03c832d1e4d0e577b73a7','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a2d165ea89abd110aeb610baf8de4b1bee6a375cb24d51fa9c11fb480e44093d',2002,'GN','Guinea','military-and-security',465,'Military branches: Army, Navy, Air Force, Rapid
Intervention Force, National Police
Military manpower ■ availability:
males age 15-49: 1 12,664 (2002 est.)
Military manpower ■ fit for military service:
mates age 15-49: 57,194 (2002 est.)
Military expenditures ■ dollar figure: $27.5 million
(FY01)
Military expenditures ■ percent of GDP: 2.5%
(FY01)
Military branches: Army, Navy, Air Force
Military expenditures - dollar figure: $138.3
million (FY01)
Military expenditures - percent of GDP: 19.8%
(FY01)
Military branches: Army, Navy, Air Force, Police
Force
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 30,808,598 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 17,698,91 1 (2002 est.)
Military manpower - reaching military age
annually:
males: 1,375,112 (2002 est.)
Military expenditures - doliar figure: $374.9
million (FY01)
Military expenditures - percent of GDP: 1%
(FY01)','9864a744187a73f8c5c35fb9fb54e72b560606d2c295e4109e6a0df9fe3e38d3','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c3cc33a2b062c7c611d5a238efea53d2e73f634ab93807cf0164cd4b05b0ef3b',2002,'EE','Estonia','military-and-security',476,'Military branches: Estonia Defense Forces
(including Ground Forces, Navy, Air Force), Republic
Security Forces (internal and border troops),
Volunteer Defense League (Kaitseliit), Maritime
Border Guard, Coast Guard
note: Border Guards and Ministry of Internal Affairs
become part of the Estonian Defense Forces in
wartime; the Coast Guard is subordinate to the
Ministry of Defense in peacetime and the Estonian
Navy in wartime
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 359,902 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 282,716 (2002 est.)
Military manpower - reaching military age
annually:
males: 11,164 (2002 est.)
Military expenditures - dollar figure: $155 million
(2002 est.)
Military expenditures - percent of GDP: 2%
(2002 est.)','a5ecfa9faf67ec486a2d0c015f736e51bea105ae3685b4ac814bf3467d4509f7','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eb29335e37b2d3284d905f1bae3fafd649601245e7d6d7166ed4a45dd21ffcae',2002,'FO','Faroe Islands','military-and-security',485,'Military branches: no regular indigenous military
forces; small Police Force and Coast Guard are
maintained
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of','97f4c9e9da20c9cb6f34f7adb74940c230e6939b1a2bb288c773aea13b6385f1','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('175b90ecba73fe4f9d21342316aea310c9bde79bc4bef731c45dd60e1888e385',2002,'JE','Jersey','military-and-security',495,'Military branches: Republic of Fiji Military Forces
(RFMF), includes ground forces, naval division
Military manpower • military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 231 ,649 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 127,384 (2002 est.)
Military manpower - reaching military age
annually:
males: 9,471 (2002 est.)
Military expenditures - dollar figure: $35 million
(FY00)
Military expenditures - percent of GDP: 2.2%
(FY00)
Military branches: Israel Defense Forces (IDF)
(includes ground, naval, and air components with Air
Defense Forces), Pioneer Fighting Youth (Nahal),
Frontier Guard, Chen (women); note - historically
there have been no separate Israeli military services
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 1 5-49: 1,542,835
females age 15-49: 1,499,830 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1,262,973
females age 15-49: 1 ,223,939 (2002 est.)
Military manpower - reaching military age
annually:
males: 51,666
females: 49,207 (2002 est.)
Military expenditures - dollar figure: $8,866 bilion
(FY01)
Military expenditures - percent of GDP: 8%
(FY01)
Military - note: defense is the responsibility of the
UK
Military branches: Army, Navy, Air Force (including
Air Defense Force), National Police Force, National
Guard, Coast Guard
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 812,059 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 486,906 (2002 est.)
Military manpower - reaching military age
annually:
males: 18,309 (2002 est.)
Military expenditures - dollar figure:
$1 ,967,300,000 (FY01)
note: Kuwait is changing its fiscal year; the above
figure is for July-March 2001; future budget years will
be April-March annually
Military expenditures - percent of GDP: 5.5%
(FY01)
Military branches: no regular indigenous military
forces; French Armed Forces (including Army, Navy,
Air Force, Gendarmerie); Police Force
Military expenditures - dollar figure: $192.3
million (FY96)
Military expenditures • percent of GDP: 5.3%
(FY96)
Military • note: defense is the responsibility of
Military branches: Slovenian Army (includes Air
and Naval Forces)
Military manpower - military age: 19 years of age
(2002 est.)
Military manpower • availability:
males age 15-49: 521 ,881 (2002 est.)
Military manpower • fit for military service:
males age 15-49: 414,878 (2002 est.)
Military manpower • reaching military age
annually:
males: 14,513 (2002 est.)
Military expenditures - dollar figure: S370 million
(FY00)
Military expenditures - percent of GDP: 1 .7%
(FY00)
Military branches: no regular military forces;
Solomon Islands National Reconnaissance and
Surveillance Force; Royal Solomon Islands Police
(RSIP)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: Umbutfo Swaziland Defense
Force (Army), Royal Swaziland Police Force
Military manpower - availability:
males age 15-49: 253,510 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 146,805 (2002 est.)
Military expenditures • dollar figure: $20 million
(FY01/02)
Military expenditures - percent of GDP: 4.75%
(FY00/01)','e9d5b1c14febe2d12943a9d1c77038f247e541c680a36a467419d83c3b5c4fe7','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d71beb19139956a3764579aa74a81ee440e9ee276fd7256c51293cb35ff88a7c',2002,'FI','Finland','military-and-security',504,'Military branches: Army, Navy, Air Force, Frontier
Guard (including Sea Guard)
Military manpower - military age: 1 7 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1,240,762 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1,024,379 (2002 est.)
Military manpower - reaching military age
annually:
males: 33,883 (2002 est.)
Military expenditures - dollar figure: $1 .8 billion
(FY98/99)
Military expenditures - percent of GDP: 2%
(FY98/99)
Military branches: Norwegian Army, Royal
Norwegian Navy (including Coast Artillery and Coast
Guard), Royal Norwegian Air Force, Home Guard
Military manpower • military age: 20 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1,099,966 (2002 est.)
Military manpower - tit for military service:
mates age 15-49: 91 1 ,632 (2002 est.)
Military manpower - reaching military age
annually:
mates: 27,341 (2002 est.)
Military expenditures • dollar figure: $3. 1 1 3 billion
(FY98/99)
Military expenditures - percent of GDP: 2.13%
(2002)
Military branches: Royal Omani Armed Forces
(Army, Navy, Air Force), Royal Omani Police
Military manpower - military age: 14 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 780,292 (2002 est.)
Military manpower - fit for military service:
males age 15-49 434,026 (2002 est.)
Military manpower - reaching military age
annually:
males: 26,470 (2002 est.)
Military expenditures • dollar figure:
$2,424,400,000 (FY01)
Military expenditures - percent of GDP: 12.2%
(FY01)','ecf1cc40727463d4f9d6e1bef74b6998ca682108f205919bed40b78abd86c48b','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('129844137cf4f1f73fa1dfa1eb15055f82b90f59ce4a5492a8b391dc84854587',2002,'WF','Wallis and Futuna','military-and-security',514,'Military branches: Army (includes marines), Navy
(includes naval air), Air Force (includes Air Defense),
National Gendarmerie
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 14,534,480 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 2,092,938 (2002 est.)
Military manpower - reaching military age
annually:
males: 390,064 (2002 est.)
Military expenditures - dollar figure: $46.5 billion
(2000)
Military expenditures - percent of GDP: 2.57%
(2002)','113a24a9cbee2fe97f6b7e478e37f98260443abf06d3c52fca08f100c50663b2','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('36b104de76196dad81c534e44afaba439ba31678f2f1649a6ec4371d1f8372fe',2002,'PF','French Polynesia','military-and-security',529,'Military branches: no regular indigenous military
forces; French Forces (including Army, Navy, Air
Force), Gendarmerie
Military - note: defense is the responsibility of','d637cc04e69aa16f3b5e2f99d433a9130d74ecdff4536c7f2b17b354b87d7e21','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('14fc4c5e71b469d50ffe8c4981d72330e3b407fb576ab02379fdebd3bfe87b1f',2002,'GA','Gabon','military-and-security',537,'Military branches: Army, Navy, Air Force,
Presidential (Republican) Guard (charged with
protecting the president and other senior officials),
National Gendarmerie, National Police
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower • availability:
males age 15-49: 284,358 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 146,908 (2002 est.)
Military manpower - reaching military age
annually:
males: 11,304 (2002 est.)
Military expenditures - dollar figure: $70.8 million
(FY01)
Military expenditures - percent of GDP: 2%
(FY01)
Military branches: Gambian National Army (GNA)
(includes marine unit), National Police, Presidential
Guard
Military manpower - availability:
males age 15-49: 327,677 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 165,249 (2002 est .)
Military expenditures - dollar figure: $1 .2 million
(FY01)
Military expenditures - percent of GDP: 0.3%
(FY01)
Military branches: in accordance with the peace
agreement, the Palestinian Authority is not permitted
conventional military forces; there are, however, a
Public Security Force and a civil Police Force
Military expenditures - dollar figure: SNA
Military expenditures - percent of GDP: NA%','3f64141a7713404300687739d085f8767f0bdb85d136af0d172353c9d0560fd4','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73d76cb2269ac6d43d2960dc1562bdc3fefc1731e7a834e06b0572be2b535f56',2002,'GE','Georgia','military-and-security',544,'Military branches: Ground Forces (includes
National Guard), combined Air and Air Defense
Forces, Naval Forces, Republic Security and Police
Forces (internal and border troops)
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 ,300,259 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,027,407 (2002 est.)
Military manpower - reaching military age
annually:
males: 41 ,561 (2002 est.)
Military expenditures - dollar figure: $23 million
(FY00)
Military expenditures - percent of GDP: 0.59%
(FY00)
Military - note: a CIS peacekeeping force of Russian
troops is deployed in the Abkhazia region of Georgia
together with a UN military observer group; a Russian
peacekeeping battalion is deployed in South Ossetia','a01e4bd863f0f1a7ea99c3b1db7e2d4d791ac8a038c17cc9edcb174cc3c2524d','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('87deccf37d68a983c9f309aabbb06f99b2ae4f0c79f0a33c5775d47bc3779bcd',2002,'DE','Germany','military-and-security',552,'Military branches: Army, Navy (including naval air
arm), Air Force, Medical Corps, Joint Support Service
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 20,854,329 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 17,734,977 (2002 est.)
Military manpower - reaching military age
annually:
males: 482,31 8 (2002 est.)
Military expenditures • dollar figure: $38.8 billion
(2002)
Military expenditures - percent of GDP: 1 .38%
(2002)
Military branches: Army, Navy, Air Force, National
Police Force
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 5,045,355 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 2,799,292 (2002 est.)
Military manpower - reaching military age
annually:
males: 213,237 (2002 est.)
Military expenditures - dollar figure: $35.2 million
(FY01)
Military expenditures • percent of GDP: 0.7%
(FY01)
Military branches: Army, Grand Ducal Police
Military manpower - military age: 19 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 113,557 (2002 est.)
Military manpower • fit for military service:
males age 15-49: 93,429 (2002 est.)
Military manpower - reaching military age
annually:
males: 2,565(2002 est.)
Military expenditures - dollar figure: $147.8
million (FY01/02)
Military expenditures - percent of GDP: 0.8%
(FY01/02)
Military branches: no regular indigenous military
forces; responsibility for defense reverted to China on
20 December 1999; there is a local police force
Military manpower - availability:
males age 15-49: 128,005 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 70,508 (2002 est.)
Military - note: responsibility for defense reverted to
China on 20 December 1999
Military branches: Army (ARM), Air and Air Defense
Forces, Police Force
Military manpower - military age: 19 years of age
(2002 est.)
Military manpower • availability:
males age 15-49: 551,523 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 444,575 (2002 est.)
Military manpower • reaching military age
annually:
males: 17,905 (2002 est.)
Military expenditures - dollar figure: $200 million
(FY01/02est.)
Military expenditures - percent of GDP: 6%
(FY01/02 est.)','32f3c75152a4b6bd2d6d11e1a9c4b23805daa046e27a7eae0508303020171976','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bac5c7bf16869f2d998e1b8194d5d85783e2d5c9b55d0fa93f948aabf6a709fd',2002,'GI','Gibraltar','military-and-security',561,'Military branches: no regular indigenous military
forces; British Army, Royal Navy, Royal Air Force
Military - note: defense is the responsibility of the
UK
Military - note: defense is the responsibility of
Military branches: Royal Armed Forces (includes
Army, Navy, Air Force), Gendarmerie, Auxiliary
Forces
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 8,393,772 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 5,289.283 (2002 est.)
Military manpower - reaching military age
annually:
males: 348,380 (2002 est.)
356
Morocco (continued)
Military expenditures - dollar figure: $1 .4 billion
(FY99/00)
Military expenditures - percent of GDP: 4%
(FY99/00)','e15234afa89b92a873c3f31a35261b173b1209b171ccac4e61485a12c4067816','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2696bb0d98661070161ab3724c0333876910f1cb8f5c98db5f4c1d4ca6946973',2002,'GR','Greece','military-and-security',570,'Military branches: Hellenic Army, Hellenic Navy,
Hellenic Air Force, Police, National Guard
Military manpower - military age: 21 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 2,668,872 (2002 est.)
Military manpower - fit for military service:
males age 75-49:2,034,192 (2002 est.)
Military manpower - reaching military age
annually:
males: 77,976 (2002 est.)
Military expenditures - dollar figure: $6.12 billion
(FY99/00 est.)
Military expenditures - percent of GDP: 4.91%
(FY99/00 est.)','a4e628dfa51523d234c598cc2c746cbc2e25bd347822a27e4793b984000b2ec0','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('06d24ff770a0c717076e8586ac52c47a9f9fcb7f50b8ed50a8868b2e2f1553aa',2002,'GD','Grenada','military-and-security',587,'Military branches: Royal Grenada Police Force,
Coast Guard
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','7f2be39f58bb57833bb2351a235cdca1788740f848b71c2c569aeb72661e024b','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('305a555799eaafd826bd11695bca23040e43756a8bee5a8a97a11bb78b1165f2',2002,'GU','Guam','military-and-security',596,'Military - note: defense is the responsibility of the
US
Military branches: Army, Navy (includes Marines),
Air Force
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 3,186,894 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 2,080,504 (2002 est.)
Military manpower - reaching military age
annually:
males: 140,358 (2002 est.)
Military expenditures - dollar figure: $120 million
(FY99)
Military expenditures • percent of GDP: 0.6%
(FY99)','d1e11c90f6e0871389bdace897b7aacbdbbe797f1a6e966f40f94a5620d81a15','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('00e3a13cbccf63aff3664898b20f297de4bceba6be71ac0396199958af42b71e',2002,'GW','Guinea-Bissau','military-and-security',608,'Military branches: Army, Navy, Air Force,
Republican Guard, Presidential Guard, paramilitary
National Gendarmerie, National Police Force (Surete
National)
Military manpower - availability:
males age 15-49: 1,812,131 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 915,028 (2002 est.)
Military expenditures - dollar figure: $1 37.6
million (FY01)
Military expenditures - percent of GDP: 3.3%
(FY01)','403423b8978d7e830dd43af957a87448a930cafabf8872bf9ca58cee476269dd','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9e635f5bd3d87b71093d5952bed3d4945fc7d73a61285bb6e07f6644da433727',2002,'GY','Guyana','military-and-security',621,'Military branches: Guyana Defense Force
(including Ground Forces, Coast Guard, and Air
Corps), Guyana Police Force, Guyana People''s
Militia, Guyana National Service
Military manpower - availability:
males age 15-49: 206,199 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 155,058 (2002 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: National Army (including small
Navy and Air Force elements), Civil Police
Military manpower - availability:
males age 15-49: 123,072 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 72,059 (2002 est.)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: 1 ,6%
(FY97 est.)
Military - note: demilitarized by treaty (9 February
1920)','5afe5d2b45dac7f14ac6cab0b7a623408d3891cc40649dc6de4a17be904e7a82','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0254b7302ebdacbb847be7709d0961839e2a877bf4a7a781ae750810d1b42f70',2002,'HT','Haiti','military-and-security',630,'Military branches: Haitian National Police (HNP)
note: the regular Haitian Army, Navy, and Air Force
have been demobilized but still exist on paper until or
unless they are constitutionally abolished
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 ,691 ,585 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 919,275 (2002 est.)
Military manpower - reaching military age
annually:
males: 87,049 (2002 est.)
Military expenditures - dollar figure: $50 million
(FY00)
Military expenditures - percent of GDP: 1 .3%
(FY00)','d6b3da23432b97dbebe95d34f36915ad22c73e07254046182767acc11b0b5ce7','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('67d1bdde4fb228cd8268ea839331c7f99dc50115c88cc6fcb4ac5c62b8c9ba46',2002,'HM','Heard Island and McDonald Islands','military-and-security',638,'Military - note: defense is the responsibility of
Australia; Australia conducts fisheries patrols
Military branches: Swiss Guards Corps (Corpo
della Guardia Svizzera)
Military - note: defense is the responsibility of Italy;
Swiss Papal Guards are posted at entrances to the
Vatican City to provide security and protect the Pope','934bcaa56cbe282470deb54679d7ea9062821c7641416b3dab6e71bb9af783a2','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('52e962d0afc536739722f0ba5e4765e7667f01ad131e6b7d0d09dc5acce44519',2002,'HU','Hungary','military-and-security',647,'Military - note: defense is the responsibility of the
US; visited annually by the US Coast Guard
Military branches: Ground Forces, Air Forces
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower • availability:
males age 15-49: 2,559,260 (2002 est,)
Military manpower - fit for military service:
males age 15-49: 2,039,710 (2002 est.)
Military manpower - reaching military age
annually:
mates: 64, 121 (2002 est.)
Military expenditures - dollar figure: $1 .08 billion
(2002 est.)
Military expenditures - percent of GDP: 1 .75%
(2002 est.)
Military branches: no regular armed forces; Police,
Coast Guard
Military manpower • availability:
males age 15-49: 71 ,142 (2002 est.)
Military manpower • fit for military service:
males age 15-49: 62,556 (2002 est.)
Military expenditures • dollar figure: $0
Military - note: defense is provided by the
US-manned Icelandic Defense Force (IDF)
headquartered at Keflavik','da3970d81233732d74c430b8e4a54de32cf63b04ec8cc7287d6ce8c439edbe3c','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2806a7f13cf7f8a00dafd4a6ccd2df9d1e832b2630a0d75c132304aee8db0104',2002,'IN','India','military-and-security',658,'Military branches: Army, Navy (including naval air
arm), Air Force, Strategic Nuclear Command (SNC),
Coast Guard, various security or paramilitary forces
(including Border Security Force, Assam Rifles,
Rashtriya Rifles, National Security Guards,
Indo-Tibetan Border Police, Special Frontier Force,
Ladakh Scouts, Central Reserve Police Force, Central
242
India (continued)
Industrial Security Force, Railway Protection Force,
Defense Security Corps, and Indian Reserve
Battalions)
Military manpower - military age: 17 years of age
(2002 est.)
Military manpower - availability:
mates age 15-49: 285,729,565 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 167,599,380 (2002 est.)
Military manpower - reaching military age
annually:
mates; 10,879,384 (2002 est.)
Military expenditures • dollar figure:
$12,079,700,000 (FY01)
Military expenditures - percent of GDP: 2.5%
(FY01)','6fe598600bde3eaf455b69e05a5829d7fc9c30c4900687b6f016b9eee7e30774','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('90c32c0dd730adfcc440a1cb3c1f8fe99c2d775b0efd71892f729d2388b0675e',2002,'IQ','Iraq','military-and-security',668,'Military branches: Army, Republican Guard, Navy,
Air Force, Air Defense Force, Border Guard Force,
Fedayeen Saddam
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 6,135,847 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 3,430,819 (2002 est.)
Military manpower - reaching military age
annually:
males: 274,035 (2002 est.)
Military expenditures - dollar figure; $1 .3 billion
(FY00)
Military expenditures - percent of GDP: NA%','6e52fe3f03a1474337493e60ea4a8f5118b66eca086f09cc70b8a8213c7b8b43','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5b72458e23825cec7e5e9a394405feaab876a26e651643bef9139461a81d4283',2002,'IE','Ireland','military-and-security',678,'Military branches: Army (including Naval Service
and Air Corps), National Police (Garda Siochana)
Military manpower - military age: 1 7 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 ,013,739 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 81 6,744 (2002 est.)
Military manpower - reaching military age
annually:
males: 32,287 (2002 est.)
Military expenditures - dollar figure: $700 million
(FY00/01)
Military expenditures - percent of GDP: 0.9%
(FY00/01)
Military branches: Papua New Guinea Defense
Force (includes Ground Force, Maritime Operations
Element, and Air Operations Element)
Military manpower - availability:
males age 15-49: 1,338,003 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 740,085 (2002 est.)
Military expenditures - dollar figure: $42 million
(FY98)
Military expenditures - percent of GDP: 1%
(FY98)','ef238c85700b11bda3d49a767cb4c1ce30afb45603b7099252e5806e4eaf5f32','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('0d6b57774adf46528999d0e86f872838527a81cab8e4a07713a91eb9b937e31c',2002,'TN','Tunisia','military-and-security',688,'Military branches: Army, Navy, Air Force,
Carabinieri
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 14,184,307 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 12,157,753 (2002 est.)
Military manpower - reaching military age
annually:
males: 304,369 (2002 est.)
Military expenditures - dollar figure: $20.2 billion
(2002)
Military expenditures - percent of GDP: 1 .64%
(2002)','41ea28447b3e2b5f8a633bae821227ce572858cdb201eed9bf7c104ca0973674','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6dc66faec9313d6df003914ab68280b246467e959483b0c8ed2132596093ae64',2002,'JM','Jamaica','military-and-security',697,'Military branches: Jamaica Defense Force
(including Ground Forces, Coast Guard, and Air
Wing), Jamaica Constabulary Force
Military manpower - military age: 18 years of age
(2002 est.)
261
Jamaica (continued)
Military manpower • availability:
males age 15-49: 747,043 (2002 est.)
Military manpower - tit for military service:
males age 15-49: 523,550 (2002 est.)
Military manpower - reaching military age
annually:
males: 27,729 (2002 est.)
Military expenditures - dollar figure: $30 million
(FY95/96 est.)
Military expenditures - percent of GDP: NA%','e34975fc02e669fb6db852635e610d8f7b772165b90f21ac50d6c088463843dd','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('cb535b0eaa4b89ebc32d8f302df3a2403371cbe73c52fc3c2284ece218b6388b',2002,'KZ','Kazakhstan','military-and-security',719,'Military branches: Ground Forces, Air and Air
Defense Forces, Naval Force, Border Service,
Republican Guard
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 4,545,168 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 3,629,219 (2002 est.)
Military manpower • reaching military age
annually:
males: 163,628 (2002 est.)
Military expenditures - dollar figure: $173 million
(Ministry of Defense expenditures) (FY01)
Military expenditures - percent of GDP: 1 %
(Ministry of Defense expenditures) (FY01)','edf1612e46e3ca11618de3ace9b76d51be6115f5c595a193d58205420e87ee87','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('948e9e74405dd9bd03c53b955f854bd7913cc46c56fc6f8c01427af879dcf0d7',2002,'KE','Kenya','military-and-security',728,'Military branches: Army, Navy, Air Force
Military manpower - availability:
males age 15-49: 7,938,865 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 4,915,090 (2002 est.)
Military expenditures - dollar figure: $179.2
million (FY01)
Military expenditures - percent of GDP: 1 .8%
(FY01)
Military - note: defense is the responsibility of
the US','2c24d70cf2da03e20495cb090b52c824e634e07074cae8eca39c9c488680b2f6','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('23d9ebdee431cc5c0ca9b117785df68418e9fbbc124510620fb134fc7ea056e7',2002,'KI','Kiribati','military-and-security',734,'Military branches: no regular military forces; Police
Force (carries out law enforcement functions and
paramilitary duties; small police posts are on all
islands)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: Kiribati does not have military forces;
defense assistance is provided by Australia and NZ
Military branches: Korean People''s Army (includes
Army, Navy, Air Force), Civil Security Forces
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 6,032,376 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 3,619,535 (2002 est.)
Military manpower - reaching military age
annually:
males: 179,136 (2002 est.)
Military expenditures - dollar figure:
$5,124,100,000 (FY01)
Military expenditures - percent of GDP: 31 .3%
(FY01)
Military branches: Army, Navy, Air Force, Marine
Corps, National Maritime Police (Coast Guard)
Military manpower • military age: 18 years of age
(2002 est.)
Military manpower • availability:
males age 15-49: 14,194,960 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 8,990,488 (2002 est.)
Military manpower • reaching military age
annually:
males: 394,397 (2002 est.)
Military expenditures - dollar figure: $12.8 billion
(FY00)
Military expenditures - percent of GDP: 2.8%
(FY00)','c9f4865eb972aeebc52c6d4eb55e6008f71503504b2d61071009b783e60b3d45','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ecb1f7eb9bb8413d1f8cdacc9b04c5fb0fac9c2b798eae39a1bd4e4a7310c14c',2002,'KG','Kyrgyzstan','military-and-security',742,'Military branches: Army, Air and Air Defense,
Security Forces, Border Troops
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 ,234,457 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,001 ,274 (2002 est.)
Military manpower - reaching military age
annually:
mates: 50,590 (2002 est.)
Military expenditures - dollar figure: $19.2 million
(FY01)
Military expenditures - percent of GDP: 1 .4%
(FY01)','76450c65d4a4e6ac6f607fb8f0c6ae9555d3290481284b60ba8b71d225c5ed3f','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6fbdac727598adb2965683a5831fa1270df42eca8d123afc2e9506e5656c1d93',2002,'LB','Lebanon','military-and-security',753,'Military branches: Lebanese Armed Forces (LAF;
includes Army, Navy, and Air Force)
Military manpower - availability:
males age 15-49: 1,003,174 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 618,129 (2002 est.)
Military expenditures - dollar figure: $343 million
(FY99/00)
Military expenditures - percent of GDP: 4.8%
(FY99/00)','c17528b0857cf98b49bad750573d10c68b8061af3108cd6a6bb27f3b63c50ac8','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('4e574a46c6ce7f6a45a45f4b69248d621d88a367fc239e422c5d0deb6461a599',2002,'ZA','South Africa','military-and-security',758,'Military branches: Lesotho Defense Force (LDF;
including Army and Air Wing), Royal Lesotho Mounted
Police
Military manpower - availability:
males age 15-49: 526,332 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 283,203 (2002 est.)
Military expenditures - dollar figure: $34 million
(1999)
Military expenditures - percent of GDP: NA%
Military - note: The Lesotho Government in 1999
began an open debate on the future structure, size,
and role of the armed forces, especially considering
the Lesotho Defense Force''s (LDF) history of
intervening in political affairs.
Military branches: Army, Navy, Air Force
Military manpower - availability:
mates age 15-49: 729,469 (2002 est.)
Military manpower • fit for military service:
mates age 15-49: 393,028 (2002 est.)
Military expenditures - dollar figure: $7.8 million
(FY01)
Military expenditures - percent of GDP: 1 .3%
(FY01)
Military branches: South African National Defense
Force (including Army, Navy, Air Force, and Medical
Services), South African Police Service
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 1 ,557,242 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 7,031 ,337 (2002 est.)
Military manpower - reaching military age
annually:
males: 466,399 (2002 est.)
Military expenditures - dollar figure: $1 .79 billion
(FY01)
Military expenditures - percent of GDP: 1 .6%
(FY01)
Military - note: the National Defense Force
continues to integrate former military, black
homelands forces, and ex-opposition forces
Military - note: defense is the responsibility of the
UK','eee64a64811cb9f81b0b945badb5f4453c8897e233573ea9ccf7d857e060710f','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('338c2a87c663145e6afbb025540f71973eba6eea42a5f01cc0d8c4193c2d5f85',2002,'LY','Libya','military-and-security',770,'Military branches: Armed Peoples on Duty (Army),
Navy, Air and Air Defense Command (includes Air
Force)
Military manpower - military age: 17 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 ,503,647 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 890,783 (2002 est.)
Military manpower - reaching mifitary age
annually:
males: 61 ,694 (2002 est.)
Military expenditures - dollar figure: $1 .3 billion
(FY99/00)
Military expenditures - percent of GDP: 3.9%
(FY99/00)','ceedd9f901df36ee0ccb6b137d6b8af5ccd6e84b5888d2ac77bde5484fb1b8a7','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d408d77d347f221829d6987fb8da7ad20fb5a0929572404773b6c7d5a847aece',2002,'LT','Lithuania','military-and-security',786,'Military branches: Ground Forces, Navy, Air and Air
Defense Force, National Volunteer Defense Forces
(SKAT)
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 933,638 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 733,415 (2002 est.)
Military manpower - reaching military age
annually:
males: 28,506 (2002 est.)
Military expenditures * dollar figure: $230.8
million (FY01)
Military expenditures - percent of GDP: 1 .9%
(FY01)','bda8b26b276992d1baf6100e9aea3e2ca884cd51fc8060b237633735b49a4dbe','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('1261f576c4b77c114cc53116d84a4bb5db49967f49c6da263065e3f034f85211',2002,'KM','Comoros','military-and-security',795,'Military branches: People''s Armed Forces
(comprising Intervention Force, Development Force,
Aeronaval [Navy and Air] Force). Gendarmerie,
Presidential Security Regiment
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 3,758,940 (2002 est.)
Military manpower - fit for military service:
mates age 15-49: 2,229,304 (2002 est.)
Military manpower - reaching military age
annually:
males: 153,856 (2002 est.)
Military expenditures - dollar figure: $48.7 million
(FY01)
Military expenditures - percent of GDP: 1 .2%
(FY01)','f44da7da575ad08747eb3717a3d818f210230db99aff8bba8d9f4b8672649246','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('842633a4c8eefdaf10603c5ae8e1a15105df63e1d553dc2b762162ced0c62f87',2002,'MW','Malawi','military-and-security',803,'Military branches: Army (including Air Wing and
Naval Detachment), Police (including paramilitary
Mobile Force Unit)
Military manpower - availability:
males age 15-49: 2,535,207 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,301 ,625 (2002 est.)
Military expenditures - dollar figure: $9.5 million
(FY00/01)
Military expenditures - percent of GDP: 0.76%
(FY00/01)
318
Malawi (continued)
Military branches: Malaysian Army, Royal
Malaysian Navy, Royal Malaysian Air Force, Royal
Malaysian Police Field Force, Marine Police, Sarawak
Border Scouts
Military manpower - military age: 21 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 5,933,296 (2002 est.)
321
Malaysia (continued)
Military manpower - tit for military service:
males age 15-49: 3,592,997 (2002 est.)
Military manpower - reaching military age
annually:
males: 196,042 (2002 est.)
Military expenditures • dollar figure: $1 .69 billion
(FYOO est.)
Military expenditures - percent of GDP: 2.03%
(FYOO)','b7d00fd712d5c3c6270dc99dd5927b224eb164e5b4717a3a6552ea8406359ad1','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('336f9eeda3e225e569a52d521c80f8ef2ff661745e988a45c0ae6d439291358a',2002,'MV','Maldives','military-and-security',812,'Military branches: National Security Service
Military manpower - availability:
mates age 15-49: 74,893 (2002 est.)
Military manpower • fit for military service:
males age 15-49: 41 ,672 (2002 est.)
Military expenditures - dollar figure: $34.5 million
(FY01)
Military expenditures - percent of GDP: 8.6%
(FY01)','01b8eaceb189a73dcb35ae9b72118eb3654baf798bf0ff3d2d4366adb50645ad','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('70b29c161c44e9e318e352e662513f648ed5e5b5cbff2dfdbaa9093b5eb4de66',2002,'ML','Mali','military-and-security',820,'Military branches: Army, Air Force, Gendarmerie,
Republican Guard, National Guard, National Police
(Surete Nationale)
Military manpower - availability:
males age 15-49: 2,369,578 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,358,646 (2002 est.)
Military expenditures - dollar figure: $50 million
(FY01)
Military expenditures - percent of GDP: 2%
(FY01)
Military branches: Armed Forces (including land
forces [with subordinate air squadron and maritime
squadron] and the Revenue Security Corps). Maltese
Police Force
Military manpower - availability:
males age 15-49: 99,107 (2002 est.)
Military manpower • fit for military service:
males age 15-49: 78,909 (2002 est.)
Military expenditures - dollar figure: $60 million
(2000 est.)
Military expenditures - percent of GDP: 1.7%
(2000)
Military - note: defense is the responsibility of the
UK
Military branches: no regular military forces; Police
Force
Military expenditures - dollar figure: SNA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of the
US','41cc25e551beeefe331971452f4712e46e40cf23f5e77f0fd21630f6d6678994','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('dcd6efd98303245a7201e8bc8d4907cfbe5874af50030042734907842c0e2919',2002,'MR','Mauritania','military-and-security',834,'Military branches: Army, Navy, Air Force, National
Gendarmerie, National Guard, National Police,
Presidential Guard
Military manpower - availability:
mates age 15-49: 644,294 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 312,276 (2002 est.)
Military expenditures - dollar figure: $37.1 million
(FY01)
Military expenditures - percent of GDP: 3.7%
(FY01)','19d93686792505e7a5206d011b55226163af70572e164f5da58ef363cac27ca5','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('610f9d819086fbdff1947d4660c1cfca8c09df211b08c029a91d317de00ed6fd',2002,'MU','Mauritius','military-and-security',843,'Military branches: National Police Force (includes
the paramilitary Special Mobile Force or SMF and
National Coast Guard)
Military manpower - availability:
males age 15-49: 340,050 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 171,239 (2002 est.)
Military expenditures - dollar figure: $9.1 million
(FV01)
Military expenditures • percent of GDP: 0.2%
(FY01)','3cab64fec9f4ce1afd553d320c85f6bf9cc02fb077f19b42d8d6026b7294d4a7','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16586e4f52d593394c587b710ed8f938a72abc72d4831a61f77c64153d643fff',2002,'YT','Mayotte','military-and-security',848,'Military • note: defense is the responsibility of
France; small contingent of French forces stationed
on the island','d4471f66711d3f4efab56e31efb0920f05afa79ac0df8c2baa27a0addce002af','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('046de18b353eaa3818fc817ff1b6c226982605d356a63a6f019a45d328dc955c',2002,'MX','Mexico','military-and-security',849,'Military branches: National Defense Secretariat
(SEDENA) (including Army and Air Force), Navy
Secretariat (including Naval Air and Marines)
Military manpower - military age: 1 8 years of age
nofe; starting in 2000, females were allowed to
volunteer for military service (2002 est.)
Military manpower - availability:
males age 15-49:27,229,581 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 19,761,440 (2002 est.)
Military manpower - reaching military age
annually:
males: 1,077,536 (2002 est.)
Military expenditures - dollar figure: $4 billion
(FY99)
Military expenditures • percent of GDP: 1 %
(FY99)
Military branches: Army, Navy, Air and Air Defense
Force
Military manpower - military age: 19 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 0,41 5,598 (2002 est.)
Military manpower • fit for military service:
males age 15-49: 8,120,098 (2002 est.)
Military manpower • reaching military age
annually:
mates: 344,781 (2002 est.)
Military expenditures - dollar figure: $3.5 billion
(2002)
Military expenditures - percent of GDP: 1.71%
(2002)','a0eddf1d7678acbe7b0234f5624487904af7dd17099c0c28a57b28f1cb164ead','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c4535ea6074ec6fb339ec80a262c130aa7693173ac14da53de7cbd991dfcc3f2',2002,'FM','Micronesia, Federated States of','military-and-security',851,'Military - note: Federated States of Micronesia
(FSM) is a sovereign, self-governing state in free
association with the US; FSM is totally dependent on
the US for its defense
Military - note: defense is the responsibility of the
US
Military branches: Ground Forces (includes Air and
Air Defense Forces), Republic Security Forces
(includes paramilitary internal Troops and Border
Troops)
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1,172,714 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 929,316 (2002 est.)
Military manpower - reaching military age
annually:
males: 42,268 (2002 est.)
Military expenditures - dollar figure: $6 million
(FY01)
Military expenditures - percent of GDP: 0.4%
(FY01)','15a057343b5e33fd8b914a030d2cd9342a52e4c6912efd04cf1f83be4cb37ce7','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('73b3701244903c6edda71a6b00d223b66cb743d4024fa82694dd4cdcd47c2369',2002,'MS','Montserrat','military-and-security',873,'Military branches: no regular indigenous military
forces; Police Force
Military - note: defense is the responsibility of the
UK','a738c350b6a0315a5877128d7d982750f6cf0c713ab091d32129a7d2fde27d32','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6725d52b3034daa2fabe1b66767ee86d2e77b001263be6011b62937c379f94b3',2002,'NA','Namibia','military-and-security',883,'Military branches: National Defense Force (Army,
including Air Wing), Police
Military manpower - availability:
males age 15-49: 436,642 (2002 est.)
Military manpower - fit for military service:
mates age 15-49: 260,879 (2002 est.)
Military expenditures • dollar figure: $1 04.4
million (2001)
Military expenditures • percent of GDP: 2.6%
(FY97/98)
Military branches: no regular military forces; Nauru
Police Force
Military manpower - availability:
males age 15-49: 3,103 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1,710 (2002 est )
Military expenditures - dollar figure: SNA
Military expenditures - percent of GDP: NA%
Military - note: Nauru maintains no defense forces;
under an informal agreement, defense is the
responsibility of Australia
Military - note: defense is the responsibility of the
US','f84d2f4409849f807d5d1a844e790a289016e581c239e11b7ab082db035c605b','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('e20f0c30b7ed77c955a64e834ccc5ddbfad79d5c5e00903484028c6bd860eadd',2002,'NL','Netherlands','military-and-security',887,'Military branches: Royal Nepalese Army (includes
Royal Nepalese Army Air Service), Nepalese Police
Force
Military manpower - military age: 17 years of age
(2002 est.)
Military branches: Royal Netherlands Army, Royal
Netherlands Navy (including Naval Air Service and
Marine Corps), Royal Netherlands Air Force, Royal
Constabulary
Military manpower - military age: 20 years of age
(note - age 17 for cadets and midshipmen) (2002 est.)
Military manpower - availability:
males age 15-49: 4,077,917 (2002 est.)
Military manpower - fit for military service:
males age 15-49:3,546,030 (2002 est.)
369
Netherlands (continued)
Military manpower - reaching military age
annually:
males: 96,082
note: Netherlands has an all-volunteer, 74,100 force
in 2001 (2002 est.)
Military expenditures - dollar figure: $6.5 billion
(FY00/01 est.)
Military expenditures - percent of GDP: 1 .5%
(FY00/01 est.)','30e9576fcb4acd1cfe540a53be9df8764ea09b1c9689076c311d41d750c11c86','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('43221b47fd9aa1afa4bb99391e1c4505c1194ba2a974fa764dc57c6e2974288b',2002,'VU','Vanuatu','military-and-security',894,'Military branches: no regular indigenous military
forces; Royal Netherlands Navy, Marine Corps, Royal
Netherlands Air Force, National Guard, Police Force
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 54,752 (2002 est.)
Military manpower • fit for military service:
males age 15-49: 30,642 (2002 est.)
Military manpower - reaching military age
annually:
males: 1,610 (2002 est.)
Military branches: New Zealand Army, Royal New
Zealand Navy, Royal New Zealand Air Force
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1,010,316 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 850,185 (2002 est.)
Military manpower - reaching military age
annually:
males: 26,480 (2002 est.)
Military expenditures - dollar figure: $515.6
million (2002 est.)
Military expenditures • percent of GDP: 1 .2%
(FY2001/02)
Military branches: Army, Navy, Air Force
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1,308,430 (2002 est.)
Military manpower - fit for military service:
mates age 15-49: 802,779 (2002 est.)
Military manpower • reaching military age
annually:
males: 58,232 (2002 est.)
Military expenditures - dollar figure: $26 million
(FY98)
Military expenditures - percent of GDP: 1 .2%
(FY98)
Military branches: no regular military forces;
Vanuatu Police Force (VPF; including the paramilitary
Mobile Force or VMF)
Military expenditures * dollar figure: SNA
Military expenditures - percent of GDP: NA%
Military branches: National Armed Forces (Fuerzas
Armadas Nacionales or FAN) includes Ground Forces
or Army (Fuerzas Terrestres or Ejercito), Naval
Forces (Fuerzas Navales or Armada - including
marines and Coast Guard), Air Force (Fuerzas
Aereas or Aviacion), Armed Forces of Cooperation or
National Guard (Fuerzas Armadas de Cooperacion or
Guardia Nacional)
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 6,647,718 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 4,786,849 (2002 est.)
Military manpower - reaching military age
annually:
males: 246,185 (2002 est.)
Military expenditures * dollar figure: $934 million
(FY99)
Military expenditures - percent of GDP: 0.9%
(FY99)
Military branches: People''s Army of Vietnam
(includes Ground Forces, People''s Navy Command
[including Naval Infantry], Air and Air Defense Force,
Coast Guard)
Military manpower - military age: 1 7 years of age
(2002 est.)
Military manpower ■ availability:
males age 15-49: 22,220,891 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 13,978,653 (2002 est.)
Military manpower - reaching military age
annually:
males: 961 ,124 (2002 est.)
Military expenditures - dollar figure: $650 million
(FY98) ''
Military expenditures - percent of GDP: 2.5%
(FY98)','a4f691d8399e2f2e5c5311898de22f188e9dc855168f5e37f0bace0ce528d8d7','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('bc94dfdfa4c0a2a68c8291d4649c3c8feb46ae2883379815d4b94512d17d409f',2002,'NE','Niger','military-and-security',905,'Military branches: Army, Air Force, Gendarmerie,
National Intervention and Security Force
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 2,270,793 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,227,994 (2002 est.)
Military manpower - reaching military age
annually:
males: 108,993 (2002 est.)
Military expenditures - dollar figure: $20.9 million
(FY01)
Military expenditures • percent of GDP: 1 .3%
(FY01)','ca3e0c31eea7a9ccea897933b27b0f038fee4ee8ffb2ac939882038b9c46ad71','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a71c52e9b3525c8e9f18159e543db1004f7aa176d1d4e5524bc5fc5044b76e04',2002,'MP','Northern Mariana Islands','military-and-security',919,'Military - note: defense is the responsibility of the
US
Military - note: defense is the responsibility of the
US','6f75d34e097b117b9add09a066dae95e2d2a46a6e85ab39c03b02681b0c6af76','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2f6b5c5fa37dc5e76a3a9c74343d2adac9034996fd8f5225ea03a775feaa28c7',2002,'PK','Pakistan','military-and-security',929,'Military branches: Army, Navy, Air Force, Civil
Armed Forces, National Guard
Military manpower - military age: 17 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 36,941 ,592 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 22,606,576 (2002 est.)
Military manpower - reaching military age
annually:
mates: 1,657,724 (2002 est.)
Military expenditures - dollar figure:
$2,545,500,000 (FY01)
Military expenditures - percent of GDP: 4.6%
(FY01)','25d2db28dac9f0d68a42c538c3b508a72213bc4c2eb45be0100d54f6fa115b74','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('179468b2833b3391aafae4bbab07292035396857abdd20a37773f78214e123ed',2002,'PW','Palau','military-and-security',938,'Military branches: NA
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military - note: defense is the responsibility of the
US; under a Compact of Free Association between
Palau and the US, the US military is granted access to
the islands for 50 years
Military - note: defense is the responsibility of the
US','6b6361ddebb5cf36ba68c99d7fb5dc5cede02d16ee4a21bbe0bdb036925e86bd','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c10de3727adf7682946a69bee96943551e5354d1cdb9a054ba20595104b42591',2002,'PA','Panama','military-and-security',946,'Military branches: an amendment to the
Constitution abolished the armed forces, but there are
security forces (Panamanian Public Forces or PPF
includes the Panamanian National Police, National
Maritime Service, and National Air Service)
Military manpower - availability:
males age 15-49: 789,973 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 540,052 (2002 est.)
Military expenditures - dollar figure: $128 million
(FY99)
Military expenditures - percent of GDP: 1 .3%
(FY99)
Military - note: on 10 February 1990, the
government of then President ENDARA abolished
Panama''s military and reformed the security
apparatus by creating the Panamanian Public Forces;
in October 1994, Panama''s Legislative Assembly
approved a constitutional amendment prohibiting the
creation of a standing military force, but allowing the
temporary establishment of special police units to
counter acts of “external aggression’','e6a9a474b752e6cc2e2b074be22f453d5e0f4d7cb1df63ba777fd7d048f80111','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3d06952a0cd3dac2fb62c569c982a45b4858bc823f590899b7b75f20c46a9091',2002,'AR','Argentina','military-and-security',958,'Military branches: Army, Navy (includes Naval Air
and Marines), Air Force
Military manpower - military age: 17 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 ,427,160 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 ,028,935 (2002 est.)
Military manpower - reaching military age
annually:
males: 58,359 (2002 est.)
Military expenditures - dollar figure: $125 million
(FV98)
Military expenditures - percent of GDP: 1 .4%
(FY98)','ae636d9d28ef4d0e6975dc7f71b3f752cf1a724f62b11e508361db9e0690c9e6','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('2fa60b9789d3a497cf32b2491c3d4995894561f9fb489423634b837fd16be9b3',2002,'QA','Qatar','military-and-security',974,'Military branches: Army, Navy, Air Force
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 316,885
note: includes non-nationals (2002 est.)
Military manpower - fit lor military service:
males age 15-49: 166,214 (2002 est.)
Military manpower - reaching military age
annually:
males: 6,797 (2002 est.)
Military expenditures • dollar figure: $723 million
(FY00/01)
Military expenditures - percent of GDP: 1 0%
(FY00/01)','55dc2a17facbd22a226e68c16fbfcfa901a61ef3d5ce5f92252e005f40fbd742','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('b4f63e46c64e8515b6bbc66a31be459d6fcc7299b66ca981e16923bb00406baa',2002,'UA','Ukraine','military-and-security',981,'Military branches: Army, Navy, Air and Air Defense
Forces (AMR), Paramilitary Forces, Civil Defense,
Border Guards
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 5,906,601 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 4,970,496 (2002 est.)
Military manpower • reaching military age
annually:
males: 179,951 (2002 est.)
Military expenditures - dollar figure: $985 million
(2002)
Military expenditures - percent of GDP: 2.47%
(2002)
Military branches: Ground Forces, Navy, Air
Forces, Space Forces, Airborne Forces, Strategic
Rocket Forces
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 38,906,796 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 30,392,946 (2002 est.)
Military manpower - reaching military age
annually:
mates: 1,242,778 (2002 est.)
Military expenditures ■ dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military branches: Army. Navy. Air Force,
Gendarmerie
Military manpower - availability:
males age 15-49: 1,858,443 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 946.990 (2002 est.)
Military expenditures - dollar figure: $58 million
(FY01)
Military expenditures - percent of GDP: 3.1%
(FY01)
Military branches: Ground Forces, Naval Forces,
Air Force, Air Defense Forces, Interior Troops, Border
Troops
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 12,263,178 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 9,616,864 (2002 est.)
Military manpower - reaching military age
annually:
males: 390,823 (2002 est.)
Military expenditures - dollar figure: $500 million
(FY99)
Military expenditures - percent of GDP: 1 .4%
(FY99)','71708971adf752f430e0f992faa62c21a91462aad3fa37568fd05faf989b6e80','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7eaadcd347669ca693fd7b103d5ce29ec95de95b5cfe723adddbdfbcfa2835ec',2002,'TT','Trinidad and Tobago','military-and-security',999,'Military branches: Saint Kitts and Nevis Defense
Force (including Coast Guard), Royal Saint Kitts and
Nevis Police Force (including Special Service Unit)
Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%','d2191b473b8dbf23e898fc1937c51c6d5d62bab62989bb3f999b835b7bf294c8','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('d4b466db7551fbee810d5d3c8084ccc3b584bb485ce50f05ef15e33f6f3992ee',2002,'MQ','Martinique','military-and-security',1003,'Military branches: Royal Saint Lucia Police Force
(includes Special Service Unit and Coast Guard)
Military expenditures - dollar figure: SNA
Military expenditures - percent of GDP: $NA
Military - note: defense is the responsibility of','05cd3e34f66357a3b073d578f9aee63dd4d97e2d67eb262b1a844e88f01e2761','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('44cb21c71a37e2ec1d843d6d167e30f82413911a85f3c7ca28237eacf17c9a21',2002,'VC','Saint Vincent and the Grenadines','military-and-security',1006,'Military branches: Royal Saint Vincent and the
Grenadines Police Force (includes Special Service
Unit), Coast Guard
Military expenditures - dollar figure: SNA
Military expenditures - percent of GDP: NA%','913976f02b4d5c41779d37bc71c5299b1c2e84e294b44ee6557223fbc7b69475','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c2a438994476abeca08325f04cfa30cb21f2527535459286cca672b880123646',2002,'WS','Samoa','military-and-security',1014,'Military branches: no regular armed services;
Samoa Police Force
Military expenditures - dollar figure: SNA
Military expenditures - percent of GDP: NA%
Military - note: Samoa has no formal defense
structure or regular armed forces; informal defense
ties exist with NZ, which is required to consider any
Samoan request for assistance under the 1 962 T reaty
of Friendship','8e0a72671bcd3e26987521626d863e4ecd8fc45cf81b724dffdc2b9a8261ef08','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('27eebecd988942ef0b03d287061a8ce4a3099c58306b67c4468c75050a09e9cc',2002,'SM','San Marino','military-and-security',1022,'Military branches: Voluntary Military Force (Corpi
Militari Voluntar), Gendarmerie; note - the Voluntary
Military Force performs ceremonial duties and limited
police assistance
Military expenditures - dollar figure: $700,000
(FY00/01)
Military expenditures - percent of GDP: NA%','83844aa8076549e17ce9bbd41160f71fb8e35ea007effe45dc52564525b50ed6','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6967a3d63f3d29164f7a654fea9ffb7168cf5a9f8afe7bbdf1883bde9e42d4c1',2002,'SA','Saudi Arabia','military-and-security',1031,'Military branches: Land Force (Army), Navy, Air
Force, Air Defense Force, National Guard, Ministry of
Interior Forces (paramilitary)
Military manpower • military age: 17 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 6,007,635 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 3,359,849 (2002 est.)
Military manpower - reaching military age
annually:
males: 233,402 (2002 est.)
Military expenditures - dollar figure: SI 8.3 billion
(FY00)
Military expenditures - percent of GDP: 1 3%
(FY00)','c969a6982657122f34fe505c359c5b2e41b37e8f7a5fd114e8cc7653b9f30e14','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('358583f4b544472aa14e4ea9344f0d2b90a7eea5e287db3c8a698907829f3909',2002,'SN','Senegal','military-and-security',1039,'Military branches: Army, Navy, Air Force, National
Gendarmerie, National Police (Surete Nationale)
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 2,406.337 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1,257,423 (2002 est.)
Military manpower - reaching military age
annually:
males: 1 14,189 (2002 est.)
Military expenditures - dollar figure: $68.6 million
(FY02)
Military expenditures - percent of GDP: 1.4%
(FY02)','61dfdc329b2c2525afffe4c0d99b6778bcf0faf43c62ecd06612d65e9332fee4','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a453c50d6a1bafa05070ff39e57950cd9b5983178cdbed8264abc4cead355be2',2002,'SC','Seychelles','military-and-security',1048,'Military branches: Army, Coast Guard (includes Air
Wing), Presidential Protection Unit (includes
Presidential Guard), Police Force (includes Police
Mobile Unit, a special weapons and tactics unit
capable of assisting the Army in maintaining internal
stability)
Military manpower - availability:
males age 15-49: 23,210 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1 1 ,554 (2002 est.)
Military expenditures -dollar figure: $11 million
(FY01)
Military expenditures - percent of GDP: 1 .8%
(FY01)','90d5d8c10812dc6d428a030ae2b6f15da8701ac4e2974e4f1167a044315efa74','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('a5a60360456fad2f9ba28f3ac21a68c2512058fb56766e538810e9152682eb43',2002,'SL','Sierra Leone','military-and-security',1056,'Military branches: Army (RSLAF)
Military manpower - availability:
males age 15-49: 1,203,682 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 583,946 (2002 est.)
Military expenditures - dollar figure: $10.3 million
(FY01)
Military expenditures - percent of GDP: 1 .5%
(FY01)','af78f0f0954fd6b0f45f23026beaf04181849d33131e9b667ec66c37183bbbcb','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('5e4ae8be58a5cccd21968e1f3b033e111c2754145f1de65fc9d42ebf489f723a',2002,'SK','Slovakia','military-and-security',1065,'Military branches: Army (Ground Forces), Air and
Air Defense Forces, Home Guards (Territorial
Defense Forces), Civil Defense Force, Railway Armed
Forces (subordinate to the Ministry of Transportation,
Post, and Telecommunications)
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1,486,728 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1,136,775 (2002 est.)
Military manpower - reaching military age
annually:
males: 45,502 (2002 est.)
Military expenditures - dollar figure: $406 million
(2002)
Military expenditures - percent of GDP: 1 .89%
(2002)','2eeb86b140006e7d725ae9a5d6b63b3052e0d4117b9e8b32d99af1a428a4e8da','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('6ea7b3898b187f11ed86e59637f3583b29bc465cf3359dd5650720e10632eedc',2002,'SO','Somalia','military-and-security',1074,'Military branches: A Somali National Army is being
reformed under the interim government; numerous
factions and clans maintain independent militias, and
the Somaliland and Puntland regional governments
maintain their own security and police forces
Military manpower - availability:
males age 15-49: 1,881,634 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1,040,662 (2002 est.)
Military expenditures - dollar figure: $15.3 million
(FY01)
Military expenditures - percent of GDP: 0.9%
(FY01)','0b81e95ce8c5bd62cbf3aba487a533c00991ff6a1a8d5f2599292aa27a2339ae','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('279432bc3268a5fcdbc1996ab011ec0d19f8b9d47faf8b1e6bc76244e8b9db20',2002,'DZ','Algeria','military-and-security',1085,'Military branches: Army, Navy, Air Force, Marines,
Civil Guard, National Police, Coastal Civil Guard
Military manpower - military age: 20 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 10,520,561 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 8,403,430 (2002 est.)
Military manpower - reaching military age
annually:
males: 281 ,043 (2002 est.)
Military expenditures - dollar figure: $8.6 billion
(2002)
Military expenditures - percent of GDP: 1 .1 5%
(2002)
Military - note: Spratly Islands consist of more than
100 small islands or reefs, of which about 45 are
claimed and occupied by China, Malaysia, the
Philippines, Taiwan, and Vietnam
Military branches: Army, Navy, Air Force, Police
Force
Military manpower - military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 5,347,153 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 4,148,825 (2002 est.)
Military manpower - reaching military age
annually:
males: 193,522 (2002 est.)
Military expenditures - dollar figure: $71 9 million
(FY98)
Military expenditures - percent of GDP: 4.2%
(FY98)','a25c5ffacc9019106655071e9574844e04f2fc34c418538f39ced3447587611e','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('c277944b09cbe20de17ba92b24b1efd32ba9bbb90a03adc3e9f81be899382c26',2002,'CH','Switzerland','military-and-security',1095,'Background: Switzerland''s independence and
neutrality have long been honored by the major
European powers and Switzerland was not involved in
either of the two World Wars. The political and
economic integration of Europe over the past half
century, as well as Switzerland''s role in many UN and
international organizations has strengthened
Switzerland''s ties with its neighbors. Switzerland is
active In many UN and international organizations, but
retains a strong commitment to neutrality.','a66e865ebda746cf8995550748cf6574899c853f5e0277f416d9f08c701a2452','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('82121749ae28149f1fd5d0a50eb11f1b2e3338ad27f88245e654d56af52f3d6d',2002,'TM','Turkmenistan','military-and-security',1121,'Military branches: Ministry of Defense (Army, Air
and Air Defense, Navy, Border Troops, and Internal
Troops), National Guard
Military manpower - military age: 1 8 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 1 ,206,920 (2002 est.)
Military manpower ■ fit for military service:
males age 15-49: 979,282 (2002 est.)
Military manpower ■ reaching military age
annually:
males: 48,292 (2002 est.)
Military expenditures - dollar figure: $90 million
(FY99)
Military expenditures • percent of GDP: 3.4%
(FY99)','307b0494dc932d6e226be0392bf941c27658591cc070c412227b094c56e3bf35','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('eba15ddb980c9859a57162920369c146a6e41082509505a53edf7af93a43ac2e',2002,'TV','Tuvalu','military-and-security',1131,'Military branches: no regular military forces; Police
Force (includes Maritime Surveillance Unit for search
and rescue missions and surveillance operations)
Military expenditures - dollar figure: SNA
Military expenditures - percent of GDP: NA%
Military branches: Ugandan Peoples'' Defense
Force (including Army. Marine unit, Air Wing)
Military manpower - availability:
males age 15-49: 5,302,787 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 2,879,083 (2002 est.)
Military expenditures - dollar figure: $121 .3
million (FY01)
Military expenditures - percent of GDP: 2.1%
(FY01)','db3b7ab878b97e9a87ff2d3064b882ff783790ed2e8f1d1b94ab5e11bc208744','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('58825c0f3d69dee58bdc1c17ccb41db91000e9f970109d21ba739cbdfe29d53c',2002,'OM','Oman','military-and-security',1141,'Military branches: Army, Navy (including Marines
and Coast Guard), Air Force, Air Defense,
paramilitary forces (includes Federal Police Force)
Military manpower • military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 773,938
note: includes non-nationals (2002 est.)
Military manpower • fit for military service:
males age 15-49:419,851 (2002 est.)
Military manpower - reaching military age
annually:
males: 25,482 (2002 est.)
Military expenditures - dollar figure: $1 6 billion
(FY00)
Military expenditures - percent of GDP: 3.1%
(FY00)','5a922bc0b3d0273bc307d8a16ba540be2070d913980d1c35596122a620776040','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('3499aea3661d1fb45ea729fcec3d9c74ceddb8cf88c259cc6f8b0329a316a8bb',2002,'UY','Uruguay','military-and-security',1150,'Military branches: Army, Navy (including Naval Air
Arm, Coast Guard, Marines), Air Force, Police
(Coracero Guard, Grenadier Guard)
Military manpower - availability:
males age 15-49: 824,395 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 666,880 (2002 est.)
Military expenditures - dollar figure: $250 million
(1999)
Military expenditures - percent of GDP: 1 .1%
(2000)','d793a57dd7b6affed2cc9acc5c4cd17369bb8c605185d559a2e3d4e0034cb85b','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('ebfdbd1667cd79adb5102f51d8fa6b8eff680dabb6adce9b831b0ab392db852d',2002,'UZ','Uzbekistan','military-and-security',1159,'Military branches: Army, Air and Air Defense
Forces, National Guard, Security Forces (internal
security and border troops)
Military manpower ■ military age: 18 years of age
(2002 est.)
Military manpower - availability:
males age 15-49: 6,747,221 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 5,478,766 (2002 est.)
Military manpower - reaching military age
annually:
males: 274,602 (2002 est.)
Military expenditures - dollar figure: $200 million
(FY97)
Military expenditures - percent of GDP: 2%
(FY97)','dc668ca880d9a947966cd3ccd5995537991425ab25de6478e2712d2662435763','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('16fe20d7978645cea5346d866404e3b3d51a71f588657e9ddfb80c1ac96ddf4e',2002,'EH','Western Sahara','military-and-security',1177,'Military expenditures - dollar figure: $NA
Military expenditures - percent of GDP: NA%
Military expenditures - dollar figure: aggregate
real expenditure on arms worldwide in 1999 remained
at approximately the 1998 level, about three-quarters
of a trillion dollars (1999 est.)
Military expenditures - percent of GDP: roughly
2% of gross world product (1 999 est.)
565','d70bcfdc3df09b7e645053f1e5b79b062b2ef8b92f08876ca5f909733b490430','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('7489feec1bd2b0b113ccdb6d5e084e7ce84e103234c1cd521f1d138a945da086',2002,'YE','Yemen','military-and-security',1179,'Background: North Yemen became independent of
the Ottoman Empire in 1 918. The British, who had set
up a protectorate area around the southern port of
Aden in the 19th century, withdrew in 1967 from what
became South Yemen. Three years later, the
southern government adopted a Marxist orientation.
The massive exodus of hundreds of thousands of
Yemenis from the south to the north contributed to two
decades of hostility between the states. The two
countries were formally unified as the Republic of
Yemen in 1 990. A southern secessionist movement in
1994 was quickly subdued. In 2000, Saudi Arabia and
Yemen agreed to a delimitation of their border.
Military branches: Army (includes Special Forces,
established in 1999), Navy, Air Force, Air Defense
Forces, Republican Guard
Military manpower - military age: 14 years of age
(2002 est.)
Military manpower • availability:
males age 15-49: 4,272,156 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 2,397,914 (2002 est.)
Military manpower - reaching military age
annually:
males: 238,690 (2002 est.)
Military expenditures - dollar figure: $482.5
million (FY01)
Military expenditures - percent of GDP: 5.2%
(FY01)
Military - note: establishement of a Coast Guard,
scheduled for May 2001 , has been delayed
Military branches: Army (VJ) (including ground
forces with border troops, naval forces, air and air
defense forces)
Military manpower - military age: 19 years of age
(2002 est.)
Military manpower - availability:
mates age 15-49: 2,589,437 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 2,082,322 (2002 est.)
Military manpower - reaching military age
annually:
males: 82,542 (2002 est.)
Military expenditures • dollar figure: $654 million
(2002)
Military expenditures - percent of GDP: NA%
570
Yugoslavia (continued)','e1f1f6336a3b047c296d85f277159defc0dc802eb5ecb52781f15737c2237264','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('9d71c48b2388a1c557b968eb1a8873bb4a8eacf9e4e5c4738de1e44532aa315e',2002,'ZM','Zambia','military-and-security',1194,'Military branches: Army, Air Force, Police,
paramilitary forces
Military manpower - availability:
males age 15-49: 2,313,567 (2002 est.)
Military manpower - fit for military service:
males age 15-49: 1,228,385 (2002 est.)
Military expenditures - dollar figure: $32.5 million
(FY01)
Military expenditures - percent of GDP: 0.9%
(FY01)','8460e23a5f0b5af374dd93641ccca5d28746ae5fe2593d29416ea72c60f70f69','internet-archive','DTIC_ADA411066','txt','915d84083a71400433c4884908329ddbff7cd01596235021a001e6da09f7880d','https://archive.org/download/DTIC_ADA411066/DTIC_ADA411066_djvu.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);

SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS worldfactbook_chunks (
  chunk_id CHAR(64) NOT NULL,
  edition_year SMALLINT UNSIGNED NOT NULL,
  entity_code VARCHAR(24) NOT NULL DEFAULT '',
  entity_name VARCHAR(160) NOT NULL DEFAULT '',
  category VARCHAR(96) NOT NULL,
  ordinal INT UNSIGNED NOT NULL,
  content MEDIUMTEXT NOT NULL,
  content_sha256 CHAR(64) NOT NULL,
  source_provider VARCHAR(64) NOT NULL,
  source_identifier VARCHAR(255) NOT NULL,
  source_format VARCHAR(32) NOT NULL,
  source_sha256 CHAR(64) NOT NULL,
  source_url TEXT NOT NULL,
  extractor VARCHAR(64) NOT NULL,
  PRIMARY KEY (chunk_id),
  KEY idx_wfb_year_category (edition_year, category),
  KEY idx_wfb_entity_year (entity_code, edition_year),
  KEY idx_wfb_source_sha (source_sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO worldfactbook_chunks (chunk_id,edition_year,entity_code,entity_name,category,ordinal,content,content_sha256,source_provider,source_identifier,source_format,source_sha256,source_url,extractor) VALUES ('787f2796b2d4d012d454b4ff80fd4b2beb2d29b921091e0f486126663f18f0ba',2002,'KG','Kyrgyzstan','terrorism',124,'Geography Kyrgyzstan
Location: Central Asia, west of China
Geographic coordinates: 41 00 N, 75 00 E
Map references: Asia
Area: total: 198,500 sq km water: 7,200 sq km land: 191,300 sq km
Area - comparative: slightly smaller than South Dakota
Land boundaries: total: 3,878 km border countries: China 858 km,
Kazakhstan 1,051 km, Tajikistan 870 km, Uzbekistan 1,099 km
Coastline: 0 km (landlocked)
Maritime claims: none (landlocked)
Climate: dry continental to polar in high Tien Shan; subtropical in
southwest (Fergana Valley); temperate in northern foothill zone
Terrain: peaks of Tien Shan and associated valleys and basins encompass
entire nation
Elevation extremes: lowest point: Kara-Daryya (Karadar''ya) 132 m highest
point: Jengish Chokusu (Pik Pobedy) 7,439 m
Natural resources: abundant hydropower; significant deposits of gold
and rare earth metals; locally exploitable coal, oil, and natural gas;
other deposits of nepheline, mercury, bismuth, lead, and zinc
Land use: arable land: 7% permanent crops: 0% note: Kyrgyzstan has the
world''s largest natural growth walnut forest (1998 est.) other: 93%
Irrigated land: 10,740 sq km (1998 est.)
Natural hazards: NA
Environment - current issues: water pollution; many people get
their water directly from contaminated streams and wells; as a result,
water-borne diseases are prevalent; increasing soil salinity from faulty
irrigation practices
Environment - international agreements: party to: Air Pollution,
Biodiversity, Climate Change, Desertification, Hazardous Wastes, Ozone
Layer Protection signed, but not ratified: Geography - note: landlocked;
entirely mountainous, dominated by the Tien Shan range; many tall peaks,
glaciers, and high-altitude lakes
People Kyrgyzstan
Population: 4,822,166 (July 2002 est.)
Age structure: 0-14 years: 34.4% (male 838,224; female 821,230) 15-64
years: 59.4% (male 1,403,328; female 1,459,914) 65 years and over: 6.2%
(male 113,861; female 185,609) (2002 est.)
Population growth rate: 1.45% (2002 est.)
Birth rate: 26.11 births/1,000 population (2002 est.)
Death rate: 9.1 deaths/1,000 population (2002 est.)
Net migration rate: -2.51 migrant(s)/1,000 population (2002 est.)
Sex ratio: at birth: 1.05 male(s)/female under 15 years: 1.02
male(s)/female 15-64 years: 0.96 male(s)/female 65 years and over:
0.61 male(s)/female total population: 0.96 male(s)/female (2002 est.)
Infant mortality rate: 75.92 deaths/1,000 live births (2002 est.)
Life expectancy at birth: 67.98 years (2002 est.) male: Total fertility
rate: 3.16 children born/woman (2002 est.)
HIV/AIDS - adult prevalence rate: less than 0.01% (1999 est.)
HIV/AIDS - people living with HIV/AIDS: less than 100 (1999 est.)
HIV/AIDS - deaths: less than 100 (1999 est.)
Nationality: noun: Kyrgyzstani(s) adjective: Kyrgyzstani
Ethnic groups: Kyrgyz 52.4%, Russian 18%, Uzbek 12.9%, Ukrainian 2.5%,
German 2.4%, other 11.8%
Religions: Muslim 75%, Russian Orthodox 20%, other 5%
Languages: Kyrgyz - official language, Russian - official language note:
in December 2001, the Kyrgyzstani legislature made Russian an official
language, equal in status to Kyrgyz
Literacy: definition: age 15 and over can read and write total
population: 97% male: 99% female: 96% (1989 est.)
Government Kyrgyzstan
Country name: Kyrgyz Republic conventional short form: Republic local
long form: Kyrgyz Respublikasy
Government type: republic
Capital: Bishkek
Administrative divisions: 7 provinces (oblastlar, singular - oblasty) and
1 city* (shaar); Batken Oblasty, Bishkek Shaary*, Chuy Oblasty (Bishkek),
Jalal-Abad Oblasty, Naryn Oblasty, Osh Oblasty, Talas Oblasty, Ysyk-Kol
Oblasty (Karakol) note: administrative divisions have the same names as
their administrative centers (exceptions have the administrative center
name following in parentheses)
Independence: 31 August 1991 (from Soviet Union)
National holiday: Independence Day, 31 August (1991)
Constitution: adopted 5 May 1993; note - amendment proposed by
President AKAYEV and passed in a national referendum on 10 February
1996 significantly expands the powers of the president at the expense
of the legislature
Legal system: based on civil law system
Suffrage: 18 years of age; universal
Executive branch: chief of state: President Askar AKAYEV (since
28 October 1990) head of government: Prime Minister Nikolay TANAYEV
(since 22 May 2002); note - Prime Minister Kurmanbek BAKIYEV resigned
on 22 May 2002 when five demonstrators were killed in clashes with
the police cabinet: Cabinet of Ministers appointed by the president
on the recommendation of the prime minister election results: Askar
AKAYEV reelected president; percent of vote - Askar AKAYEV 74%, Omurbek
TEKEBAYEV 14%, other candidates 12%; note - election marred by serious
irregularities elections: president reelected by popular vote for a
five-year term; elections last held 29 October 2000 (next to be held
November or December 2005); prime minister appointed by the president
Legislative branch: bicameral Supreme Council or Zhogorku Kenesh consists
of the Assembly of People''s Representatives (70 seats; members are elected
by popular vote to serve five-year terms) and the Legislative Assembly
(35 seats; members are elected by popular vote to serve five-year terms)
election results: Assembly of People''s Representatives - percent of vote
by party - NA%; percent of vote by party - NA; and Legislative Assembly -
percent of vote by party - NA%; seats by party - NA; note - total seats
by party in the Supreme Council were as follows: Union of Democratic
Forces 12, Communists 6, My Country Party of Action 4, independents 73,
other 10 note: the legislature became bicameral for the 5 February
1995 elections; the 2000 election results include both the Assembly
of People''s Representatives and the Legislative Assembly elections:
March 2000 (next to be held NA February 2005); Legislative Assembly -
last held 20 February and 12 March 2000 (next to be held NA February 2005)
Judicial branch: Supreme Court (judges are appointed for 10-year
terms by the Supreme Council on the recommendation of the president);
Constitutional Court; Higher Court of Arbitration
Political parties and leaders: Agrarian Labor Party of Kyrgyzstan [Uson
S. SYDYKOV]; Agrarian Party of Kyrgyzstan [Arkin ALIYEV]; Ata-Meken or
Fatherland [Omurbek TEKEBAYEV]; Banner National Revival Party or ASABA
[Chaprashty BAZARBAY]; Democratic Movement of Kyrgyzstan or DDK [Jypar
JEKSHEYEV]; Democratic Women''s Party of Kyrgyzstan [T. A. SHAILIYEVA];
Dignity Party [Feliks KULOV]; Erkin Kyrgyzstan Progressive and Democratic
Party [Tursunbay Bakir UULU]; Justice Party [Chingiz AYTMATOV]; Movement
for the People''s Salvation [Jumgalbek AMAMBAYEV]; Mutual Help Movement
or Ashar [Jumagazy USUPOV]; My Country of Action [Almazbek ISMANKULOV];
National Unity Democratic Movement or DDNE [Yury RAZGULYAYEV]; Party of
Communists of Kyrgyzstan or KCP [Absamat M. MASALIYEV]; Party of the
Veterans of the War in Afghanistan [leader NA]; Peasant Party [leader NA];
People''s Party [Melis ESHIMKANOV]; Republican Popular Party of Kyrgyzstan
[J. SHARSHENALIYEV]; Social Democratic Party or PSD [J. IBRAMOV]; Union
of Democratic Forces (composed of Social Democratic Party of Kyrgyzstan
or PSD [J. IBRAMOV], Economic Revival Party, and Birimdik Party
Political pressure groups and leaders: Council of Free Trade Unions;
Kyrgyz Committee on Human Rights [Ramazan DYRYLDAYEV]; National Unity
Democratic Movement; Union of Entrepreneurs
International organization participation: AsDB, CCC, CIS, EAPC, EBRD,
ECE, ECO, ESCAP, FAO, IBRD, ICAO, ICRM, IDA, IDB, IFAD, IFC, IFRCS, ILO,
IMF, Interpol, IOC, IOM, ISO (correspondent), ITU, NAM (observer), OIC,
OPCW (signatory), OSCE, PCA, PFP, UN, UNAMSIL, UNCTAD, UNESCO, UNIDO,
UNMIK, UPU, WFTU, WHO, WIPO, WMO, WToO, WTrO
Diplomatic representation in the US: chief of mission: Ambassador Bakyt
ABDRISAYEV FAX: [1] (202) 338-5139 consulate(s): New York telephone: [1]
(202) 338-5141 chancery: 1732 Wisconsin Avenue NW, Washington, DC 20007
Diplomatic representation from the US: chief of mission: Ambassador
John M. O''KEEFE embassy: 171 Prospect Mira,
use embassy street address telephone:
Flag description: red field with a yellow sun in the center having 40
rays representing the 40 Kyrgyz tribes; on the obverse side the rays run
counterclockwise, on the reverse, clockwise; in the center of the sun is
a red ring crossed by two sets of three lines, a stylized representation
of the roof of the traditional Kyrgyz yurt
Economy Kyrgyzstan
Economy - overview: Kyrgyzstan is a small, poor, mountainous country
with a predominantly agricultural economy. Cotton, wool, and meat are
the main agricultural products and exports. Industrial exports include
gold, mercury, uranium, and electricity. Kyrgyzstan has been one of
the most progressive countries of the former Soviet Union in carrying
out market reforms. With fits and starts, inflation has been lowered to
an estimated 7% in 2001. Much of the government''s stock in enterprises
has been sold. Drops in production had been severe since the breakup
of the Soviet Union in December 1991, but by mid-1995 production began
to recover and exports began to increase. Growth was held down to
2.1% in 1998 largely because of the spillover from Russia''s economic
difficulties, but moved ahead to 3.6% in 1999, 5% in 2000, and 5% again
in 2001. Despite these gains, poverty indicators are no better in 2001
than in 1996. On the positive side, the government and the international
financial institutions have embarked on a comprehensive medium-term
poverty reduction and economic growth strategy. In November 2001,
with financing assurance from the Paris Club, the IMF Board approved a
three-year, $93 million Poverty Reduction and Growth Facility.
GDP: purchasing power parity - $13.5 billion (2001 est.)
GDP - real growth rate: 5% (2001 est.)
GDP - per capita: purchasing power parity - $2,800 (2001 est.)
GDP - composition by sector: agriculture: 38% industry: 27% services:
35% (2000 est.)
Population below poverty line: 55% (2001 est.)
Household income or consumption by percentage share: lowest 10%: 2.7%
highest 10%: 31.7% (1997)
Distribution of family income - Gini index: 40.5 (1997)
Inflation rate (consumer prices): 7% (2001 est.)
Labor force: 2.7 million (2000)
Labor force - by occupation: agriculture 55%, industry 15%, services 30%
(2000 est.)
Unemployment rate: 7.2% (1999 est.)
Budget: revenues: $207.4 million expenditures: $238.7 million, including
capital expenditures of $NA (1999 est.)
Industries: small machinery, textiles, food processing, cement, shoes,
sawn logs, refrigerators, furniture, electric motors, gold, rare earth
metals
Industrial production growth rate: 6% (2000 est.)
Electricity - production: 14.677 billion kWh (2000)
Electricity - production by source: fossil fuel: 7.62% hydro: 92.38%
other: 0% (2000) nuclear: 0%
Electricity - consumption: 9.818 billion kWh (2000)
Electricity - exports: 4.153 billion kWh (2000)
Electricity - imports: 321 million kWh (2000)
Agriculture - products: tobacco, cotton, potatoes, vegetables, grapes,
fruits and berries; sheep, goats, cattle, wool
Exports: $475 million (f.o.b., 2001 est.)
Exports - commodities: cotton, wool, meat, tobacco; gold, mercury,
uranium, hydropower; machinery; shoes
Exports - partners: Germany 28.7%, Uzbekistan 17.7%, Russia 12.9%,
China 8.7%, Kazakhstan 6.6% (2000)
Imports: $420 million (f.o.b., 2001 est.)
Imports - commodities: oil and gas, machinery and equipment, foodstuffs
Imports - partners: Russia 23.9%, Uzbekistan 13.5%, Kazakhstan 10.3%,
US 9.7%, Turkey 4.8% (2000)
Debt - external: $1.6 billion (2001 est.)
Economic aid - recipient: $50 million from the US (2001)
Currency: Kyrgyzstani som (KGS)
Currency code: KGS
Exchange rates: soms per US dollar - 47.972 (January 2002), 48.378
(2001), 47.704 (2000), 39.008 (1999), 20.838 (1998), 17.362 (1997)
Fiscal year: calendar year
Communications Kyrgyzstan
Telephones - main lines in use: 351,000 (1997)
Telephones - mobile cellular: NA
Telephone system: general assessment: poorly developed; about 100,000
unsatisfied applications for household telephones domestic: principally
microwave radio relay; one cellular provider, probably limited to Bishkek
region international: connections with other CIS countries by landline or
microwave radio relay and with other countries by leased connections with
Moscow international gateway switch and by satellite; satellite earth
stations - 1 Intersputnik and 1 Intelsat; connected internationally by
the Trans-Asia-Europe (TAE) fiber-optic line
Radio broadcast stations: AM 12 (plus 10 repeater stations), FM 14,
shortwave 2 (1998)
Radios: 520,000 (1997)
Television broadcast stations: NA (repeater stations throughout the
country relay programs from Russia, Uzbekistan, Kazakhstan, and Turkey)
(1997)
Televisions: 210,000 (1997)
Internet country code: .kg
Internet Service Providers (ISPs): NA
Internet users: 51,600 (2001)
Transportation Kyrgyzstan
Railways: total: 370 km in common carrier service; does not include
industrial lines broad gauge: 370 km 1.520-m gauge (1990)
Highways: total: 30,300 km (including 140 km of expressways) paved:
22,600 km (includes some all-weather gravel-surfaced roads) unpaved:
7,700 km (these roads are made of unstabilized earth and are difficult
to negotiate in wet weather) (1990)
Waterways: 600 km (1990)
Pipelines: natural gas 200 km
Ports and harbors: Balykchy (Ysyk-Kol or Rybach''ye)
Airports: 50 (2001)
Airports - with paved runways: total: 4 over 3,047 m: 1 2,438 to 3,047 m:
1 1,524 to 2,437 m: 1 914 to 1,523 m: 1 (2001)
Airports - with unpaved runways: 5 914 to 1,523 m: Military Kyrgyzstan
Military branches: Army, Air and Air Defense, Security Forces, Border
Troops
Military manpower - military age: 18 years of age (2002 est.)
Military manpower - availability: males age 15-49: 1,234,457 (2002 est.)
Military manpower - fit for military service: males age 15-49: 1,001,274
(2002 est.)
Military manpower - reaching military age annually: males: 50,590
(2002 est.)
Military expenditures - dollar figure: $19.2 million (FY01)
Military expenditures - percent of GDP: 1.4% (FY01)
Transnational Issues Kyrgyzstan
Disputes - international: territorial dispute with Tajikistan on
southwestern boundary in Isfara Valley area; dispute over access to
Sokh and other Uzbek enclaves in Kyrgyzstan mars progress on boundary
delimitation; disputes over provision of water and hydroelectric power
to Kazakhstan; periodic target of Islamic insurgents from Uzbekistan,
Tajikistan, and Afghanistan
Illicit drugs: limited illicit cultivator of cannabis and opium poppy,
mostly for CIS consumption; limited government eradication program;
increasingly used as transshipment point for illicit drugs to Russia
and Western Europe from Southwest Asia
This page was last updated on 1 January 2002
========================================================================
Korea, North','c550d879b8ecd24e0359cb99a63bdf1c84367f64d115e13ab281398c9a810e7f','internet-archive','theciaworldfactb06344gut','txt','d1e0886a5e3d24e75b9c8b303bc9f80f92ea353273399eda2f6c505e0dbcc90a','https://archive.org/download/theciaworldfactb06344gut/6344.txt','plain-text') ON DUPLICATE KEY UPDATE edition_year=VALUES(edition_year),entity_code=VALUES(entity_code),entity_name=VALUES(entity_name),category=VALUES(category),ordinal=VALUES(ordinal),content=VALUES(content),content_sha256=VALUES(content_sha256),source_provider=VALUES(source_provider),source_identifier=VALUES(source_identifier),source_format=VALUES(source_format),source_sha256=VALUES(source_sha256),source_url=VALUES(source_url),extractor=VALUES(extractor);
